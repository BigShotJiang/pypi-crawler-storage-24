"""Device Code (RFC 8628) authentication flow for the OpenCosmo CLI."""

import time
from dataclasses import dataclass, field
from typing import Any, cast

import click
import httpx

from ocp.auth.tokens import save_tokens
from ocp.config.store import get_api_url
from ocp.utils.api import CLIENT_ID

# Device code grant type identifier per RFC 8628
DEVICE_CODE_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"

# Maximum attempts for entering the confirmation code
MAX_CONFIRMATION_ATTEMPTS = 3


@dataclass
class DeviceCodeResponse:
    """Parsed response from the device authorization endpoint."""

    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str
    expires_in: int
    interval: int


@dataclass
class DeviceCodeFlow:
    """Manages the OAuth Device Code authentication flow (RFC 8628)."""

    profile: str
    base_url: str = field(init=False)

    def __post_init__(self) -> None:
        """Initialize flow with API base URL."""
        self.base_url = get_api_url(self.profile)

    def request_device_code(self) -> DeviceCodeResponse:
        """Request a device code from the authorization server.

        Returns:
            Device code response with user_code and verification URI.

        Raises:
            ValueError: If the request fails or device auth is disabled.
        """
        response = httpx.post(
            f"{self.base_url}/api/v1/auth/device",
            json={"client_id": CLIENT_ID},
            timeout=30.0,
        )

        if response.status_code == 403:
            raise ValueError(
                "Device authorization is not enabled on this server.\n"
                "Use 'ocp auth login --browser' or ask the server admin "
                "to set ENABLE_DEVICE_AUTH=true."
            )

        if response.status_code != 200:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise ValueError(f"Device code request failed: {detail}")

        data = response.json()
        return DeviceCodeResponse(
            device_code=data["device_code"],
            user_code=data["user_code"],
            verification_uri=data["verification_uri"],
            verification_uri_complete=data["verification_uri_complete"],
            expires_in=data["expires_in"],
            interval=data["interval"],
        )

    def _parse_poll_error(self, response: httpx.Response) -> dict[str, Any]:
        """Parse error detail from a token endpoint error response.

        Args:
            response: HTTP response from the token endpoint.

        Returns:
            Error detail dict with at least an "error" key.

        Raises:
            ValueError: If the response cannot be parsed.
        """
        try:
            error_data = response.json()
        except Exception:
            raise ValueError(f"Unexpected response: {response.text}")

        detail = error_data.get("detail", error_data)
        if isinstance(detail, dict):
            return detail
        return {"error": str(detail)}

    def _poll_once(
        self,
        device_code: str,
        confirmation_code: str | None = None,
    ) -> httpx.Response:
        """Make a single poll request to the token endpoint.

        Args:
            device_code: The device code.
            confirmation_code: Optional confirmation code.

        Returns:
            HTTP response from the token endpoint.
        """
        body: dict[str, str] = {
            "grant_type": DEVICE_CODE_GRANT_TYPE,
            "device_code": device_code,
            "client_id": CLIENT_ID,
        }
        if confirmation_code is not None:
            body["confirmation_code"] = confirmation_code

        return httpx.post(
            f"{self.base_url}/api/v1/auth/token",
            json=body,
            timeout=30.0,
        )

    def poll_for_token(self, device_code_response: DeviceCodeResponse) -> dict[str, Any]:
        """Poll the token endpoint until authorization completes.

        Args:
            device_code_response: Response from request_device_code().

        Returns:
            Token response dict with access_token, expires_in, etc.

        Raises:
            ValueError: If the device code expires or an unexpected error occurs.
        """
        interval = device_code_response.interval
        deadline = time.monotonic() + device_code_response.expires_in

        while time.monotonic() < deadline:
            time.sleep(interval)

            response = self._poll_once(device_code_response.device_code)

            if response.status_code == 200:
                return cast(dict[str, Any], response.json())

            detail = self._parse_poll_error(response)
            error = str(detail.get("error", ""))

            if error == "authorization_pending":
                if detail.get("confirmation_pending"):
                    return self._handle_confirmation(device_code_response.device_code)
                continue
            elif error == "slow_down":
                interval += 5
                continue
            elif error == "expired_token":
                raise ValueError("Device code has expired. Please try again.")
            else:
                desc = str(detail.get("error_description", error))
                raise ValueError(f"Token request failed: {desc}")

        raise ValueError("Device code has expired. Please try again.")

    def _handle_confirmation(self, device_code: str) -> dict[str, Any]:
        """Prompt user for confirmation code and exchange for tokens.

        Args:
            device_code: The device code.

        Returns:
            Token response dict.

        Raises:
            ValueError: If all attempts fail.
        """
        for attempt in range(1, MAX_CONFIRMATION_ATTEMPTS + 1):
            code = click.prompt("\nEnter the confirmation code from your browser").strip()
            if not code:
                click.echo("Code cannot be empty.")
                if attempt == MAX_CONFIRMATION_ATTEMPTS:
                    raise ValueError("Too many failed attempts. Please try again.")
                continue

            response = self._poll_once(device_code, confirmation_code=code)

            if response.status_code == 200:
                return cast(dict[str, Any], response.json())

            detail = self._parse_poll_error(response)
            error = str(detail.get("error", ""))

            if error == "access_denied":
                remaining = MAX_CONFIRMATION_ATTEMPTS - attempt
                if remaining > 0:
                    click.echo(f"Invalid code. {remaining} attempt(s) remaining.")
                else:
                    raise ValueError("Invalid confirmation code. Please try again.")
            else:
                desc = str(detail.get("error_description", error))
                raise ValueError(f"Token request failed: {desc}")

        raise ValueError("Too many failed attempts. Please try again.")


def run_device_flow(profile: str) -> bool:
    """Run the complete device code login flow.

    Args:
        profile: Profile to authenticate.

    Returns:
        True if authentication succeeded.

    Raises:
        ValueError: On authentication failure.
    """
    flow = DeviceCodeFlow(profile=profile)

    # Request device code
    device_code_response = flow.request_device_code()

    # Display instructions
    click.echo("\nTo sign in, open this URL in a browser:\n")
    click.echo(f"  {device_code_response.verification_uri_complete}\n")
    click.echo(f"And enter the code: {device_code_response.user_code}\n")
    click.echo("Waiting for authorization...")

    # Poll for authorization (will prompt for confirmation code when needed)
    tokens = flow.poll_for_token(device_code_response)

    # Save tokens
    save_tokens(
        access_token=str(tokens["access_token"]),
        expires_in=int(tokens["expires_in"]),
        refresh_token=str(tokens["refresh_token"]) if tokens.get("refresh_token") else None,
        profile=profile,
    )

    return True
