"""Typed API service layer for the OpenCosmo CLI."""

from typing import Any

import httpx

from ocp.api._generated import (
    AdminRunListResponse,
    AdminTaskListResponse,
    AdminUserDetailResponse,
    AdminUserListResponse,
    ArchiveResponse,
    AuditLogListResponse,
    CancelResponse,
    RunListResponse,
    RunResponse,
    RunSummaryStats,
    SubmitTaskResponse,
    SystemStats,
    TaskListResponse,
    TaskResponse,
    TaskResults,
    TaskToggleResponse,
    UserResponse,
)
from ocp.mcp.api_client import AsyncAPIClient
from ocp.utils.api import APIClient, check_response
from ocp.utils.errors import APIError, RunNotFoundError, TaskNotFoundError

# ==================== Sync Services ====================


class TaskService:
    """Typed wrapper over task API endpoints."""

    def __init__(self, client: APIClient) -> None:
        self._client = client

    def list_tasks(self) -> TaskListResponse:
        """List all available tasks."""
        response = self._client.get("/api/v1/tasks")
        check_response(response, "Tasks")
        return TaskListResponse.model_validate(response.json())

    def get_task(self, slug: str) -> TaskResponse:
        """Get task details by slug.

        Raises:
            TaskNotFoundError: If task does not exist.
        """
        response = self._client.get(f"/api/v1/tasks/{slug}")
        if response.status_code == 404:
            raise TaskNotFoundError(slug)
        check_response(response, "Task")
        return TaskResponse.model_validate(response.json())

    def submit_task(self, slug: str, input_data: dict[str, Any]) -> SubmitTaskResponse:
        """Submit a task for execution.

        Raises:
            TaskNotFoundError: If task does not exist.
        """
        response = self._client.post(
            f"/api/v1/tasks/{slug}",
            json={"input_data": input_data},
        )
        if response.status_code == 404:
            raise TaskNotFoundError(slug)
        check_response(response, "Task submission")
        return SubmitTaskResponse.model_validate(response.json())


class RunService:
    """Typed wrapper over run API endpoints."""

    def __init__(self, client: APIClient) -> None:
        self._client = client

    def list_runs(
        self,
        *,
        limit: int = 20,
        status: str | None = None,
        include_archived: bool = False,
    ) -> RunListResponse:
        """List runs with optional filters."""
        params: dict[str, Any] = {"limit": limit}
        if status:
            params["status"] = status
        if include_archived:
            params["include_archived"] = "true"
        response = self._client.get("/api/v1/runs", params=params)
        check_response(response, "Runs")
        return RunListResponse.model_validate(response.json())

    def get_run(self, run_id: str) -> RunResponse:
        """Get run status and details.

        Raises:
            RunNotFoundError: If run does not exist.
        """
        response = self._client.get(f"/api/v1/runs/{run_id}")
        if response.status_code == 404:
            raise RunNotFoundError(run_id)
        check_response(response, "Run")
        return RunResponse.model_validate(response.json())

    def get_logs(self, run_id: str) -> list[dict[str, Any]]:
        """Get run execution logs.

        Returns raw dicts because the logs endpoint has no typed schema.

        Raises:
            RunNotFoundError: If run does not exist.
        """
        response = self._client.get(f"/api/v1/runs/{run_id}/logs")
        if response.status_code == 404:
            raise RunNotFoundError(run_id)
        check_response(response, "Logs")
        result: list[dict[str, Any]] = response.json()
        return result

    def get_results(self, run_id: str) -> TaskResults | None:
        """Get run results.

        Returns:
            TaskResults if available, None if results not ready.

        Raises:
            RunNotFoundError: If run does not exist.
        """
        response = self._client.get(f"/api/v1/runs/{run_id}/results")
        if response.status_code == 404:
            raise RunNotFoundError(run_id)
        check_response(response, "Results")
        data = response.json()
        if data is None:
            return None
        return TaskResults.model_validate(data)

    def cancel(self, run_id: str) -> CancelResponse:
        """Cancel a running task.

        Raises:
            RunNotFoundError: If run does not exist.
        """
        response = self._client.delete(f"/api/v1/runs/{run_id}")
        if response.status_code == 404:
            raise RunNotFoundError(run_id)
        check_response(response, "Cancel")
        return CancelResponse.model_validate(response.json())

    def archive(self, run_id: str) -> ArchiveResponse:
        """Archive a completed run.

        Raises:
            RunNotFoundError: If run does not exist.
        """
        response = self._client.post(f"/api/v1/runs/{run_id}/archive")
        if response.status_code == 404:
            raise RunNotFoundError(run_id)
        check_response(response, "Archive")
        return ArchiveResponse.model_validate(response.json())


class UserService:
    """Typed wrapper over user API endpoints."""

    def __init__(self, client: APIClient) -> None:
        self._client = client

    def whoami(self) -> UserResponse:
        """Get the current user's profile."""
        response = self._client.get("/api/v1/users/me")
        check_response(response, "User")
        return UserResponse.model_validate(response.json())


# ==================== Async Services ====================


class AsyncTaskService:
    """Async typed wrapper over task API endpoints."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def list_tasks(self) -> TaskListResponse:
        """List all available tasks."""
        response = await self._client.get("/api/v1/tasks")
        _check_async(response, "Tasks")
        return TaskListResponse.model_validate(response.json())

    async def get_task(self, slug: str) -> TaskResponse:
        """Get task details by slug."""
        response = await self._client.get(f"/api/v1/tasks/{slug}")
        _check_async(response, "Task", not_found=f"Task not found: {slug}")
        return TaskResponse.model_validate(response.json())

    async def submit_task(self, slug: str, input_data: dict[str, Any]) -> SubmitTaskResponse:
        """Submit a task for execution."""
        response = await self._client.post(
            f"/api/v1/tasks/{slug}",
            json={"input_data": input_data},
        )
        _check_async(
            response, "Task submission", not_found=f"Task not found: {slug}", entity="task"
        )
        return SubmitTaskResponse.model_validate(response.json())


class AsyncRunService:
    """Async typed wrapper over run API endpoints."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def list_runs(
        self,
        *,
        limit: int = 20,
        status: str | None = None,
    ) -> RunListResponse:
        """List runs with optional filters."""
        params: dict[str, Any] = {}
        if limit != 20:
            params["limit"] = min(max(limit, 1), 100)
        if status:
            params["status"] = status
        response = await self._client.get("/api/v1/runs", params=params)
        _check_async(response, "Runs")
        return RunListResponse.model_validate(response.json())

    async def get_run(self, run_id: str) -> RunResponse:
        """Get run status and details."""
        response = await self._client.get(f"/api/v1/runs/{run_id}")
        _check_async(response, "Run", not_found=f"Run not found: {run_id}")
        return RunResponse.model_validate(response.json())

    async def get_logs(self, run_id: str) -> list[dict[str, Any]]:
        """Get run execution logs."""
        response = await self._client.get(f"/api/v1/runs/{run_id}/logs")
        _check_async(response, "Logs", not_found=f"Run not found: {run_id}", entity="run")
        result: list[dict[str, Any]] = response.json()
        return result

    async def get_results(self, run_id: str) -> TaskResults | None:
        """Get run results."""
        response = await self._client.get(f"/api/v1/runs/{run_id}/results")
        _check_async(response, "Results", not_found=f"Run not found: {run_id}", entity="run")
        data = response.json()
        if data is None:
            return None
        return TaskResults.model_validate(data)

    async def cancel(self, run_id: str) -> CancelResponse:
        """Cancel a running task."""
        response = await self._client.delete(f"/api/v1/runs/{run_id}")
        _check_async(response, "Cancel", not_found=f"Run not found: {run_id}", entity="run")
        return CancelResponse.model_validate(response.json())


class AsyncUserService:
    """Async typed wrapper over user API endpoints."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def whoami(self) -> UserResponse:
        """Get the current user's profile."""
        response = await self._client.get("/api/v1/users/me")
        _check_async(response, "User")
        return UserResponse.model_validate(response.json())


# ==================== Admin Services ====================


class AdminService:
    """Typed wrapper over admin API endpoints."""

    def __init__(self, client: APIClient) -> None:
        self._client = client

    def list_runs(
        self,
        *,
        user_id: str | None = None,
        status: str | None = None,
        task_slug: str | None = None,
        client_type: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        include_archived: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> AdminRunListResponse:
        """List all runs across all users."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if user_id:
            params["user_id"] = user_id
        if status:
            params["status"] = status
        if task_slug:
            params["task_slug"] = task_slug
        if client_type:
            params["client_type"] = client_type
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before
        if include_archived:
            params["include_archived"] = "true"
        response = self._client.get("/api/v1/admin/runs", params=params)
        _check_admin(response, resource="Runs")
        return AdminRunListResponse.model_validate(response.json())

    def get_run_stats(self) -> RunSummaryStats:
        """Get aggregated run statistics."""
        response = self._client.get("/api/v1/admin/runs/stats")
        _check_admin(response, resource="Run stats")
        return RunSummaryStats.model_validate(response.json())

    def get_system_stats(self, *, days: int = 30) -> SystemStats:
        """Get system-wide statistics.

        Args:
            days: Number of days of history (1-365).
        """
        response = self._client.get("/api/v1/admin/system/stats", params={"days": days})
        _check_admin(response, resource="System stats")
        return SystemStats.model_validate(response.json())

    def list_users(
        self,
        *,
        search: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> AdminUserListResponse:
        """List all users."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if search:
            params["search"] = search
        response = self._client.get("/api/v1/admin/users", params=params)
        _check_admin(response, resource="Users")
        return AdminUserListResponse.model_validate(response.json())

    def get_user(self, user_id: str) -> AdminUserDetailResponse:
        """Get detailed user information.

        Raises:
            APIError: If user not found.
        """
        response = self._client.get(f"/api/v1/admin/users/{user_id}")
        _check_admin(response, resource="User")
        return AdminUserDetailResponse.model_validate(response.json())

    def list_tasks(
        self,
        *,
        include_disabled: bool = True,
        limit: int = 50,
        offset: int = 0,
    ) -> AdminTaskListResponse:
        """List all tasks including disabled ones."""
        params: dict[str, Any] = {
            "include_disabled": str(include_disabled).lower(),
            "limit": limit,
            "offset": offset,
        }
        response = self._client.get("/api/v1/admin/tasks", params=params)
        _check_admin(response, resource="Tasks")
        return AdminTaskListResponse.model_validate(response.json())

    def toggle_task(self, slug: str, *, disabled: bool) -> TaskToggleResponse:
        """Enable or disable a task.

        Args:
            slug: Task slug.
            disabled: True to disable, False to enable.

        Raises:
            APIError: If task not found.
        """
        response = self._client.patch(
            f"/api/v1/admin/tasks/{slug}",
            json={"disabled": disabled},
        )
        _check_admin(response, resource="Task")
        return TaskToggleResponse.model_validate(response.json())

    def list_audit_logs(
        self,
        *,
        user_id: str | None = None,
        method: str | None = None,
        path_prefix: str | None = None,
        status_code: int | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> AuditLogListResponse:
        """Query audit logs."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if user_id:
            params["user_id"] = user_id
        if method:
            params["method"] = method
        if path_prefix:
            params["path_prefix"] = path_prefix
        if status_code is not None:
            params["status_code"] = status_code
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before
        response = self._client.get("/api/v1/admin/audit-logs", params=params)
        _check_admin(response, resource="Audit logs")
        return AuditLogListResponse.model_validate(response.json())


class AsyncAdminService:
    """Async typed wrapper over admin API endpoints."""

    def __init__(self, client: AsyncAPIClient) -> None:
        self._client = client

    async def list_runs(
        self,
        *,
        user_id: str | None = None,
        status: str | None = None,
        task_slug: str | None = None,
        client_type: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        include_archived: bool = False,
        limit: int = 50,
        offset: int = 0,
    ) -> AdminRunListResponse:
        """List all runs across all users."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if user_id:
            params["user_id"] = user_id
        if status:
            params["status"] = status
        if task_slug:
            params["task_slug"] = task_slug
        if client_type:
            params["client_type"] = client_type
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before
        if include_archived:
            params["include_archived"] = "true"
        response = await self._client.get("/api/v1/admin/runs", params=params)
        _check_async_admin(response, "Runs")
        return AdminRunListResponse.model_validate(response.json())

    async def get_run_stats(self) -> RunSummaryStats:
        """Get aggregated run statistics."""
        response = await self._client.get("/api/v1/admin/runs/stats")
        _check_async_admin(response, "Run stats")
        return RunSummaryStats.model_validate(response.json())

    async def get_system_stats(self, *, days: int = 30) -> SystemStats:
        """Get system-wide statistics."""
        response = await self._client.get("/api/v1/admin/system/stats", params={"days": days})
        _check_async_admin(response, "System stats")
        return SystemStats.model_validate(response.json())

    async def list_users(
        self,
        *,
        search: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> AdminUserListResponse:
        """List all users."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if search:
            params["search"] = search
        response = await self._client.get("/api/v1/admin/users", params=params)
        _check_async_admin(response, "Users")
        return AdminUserListResponse.model_validate(response.json())

    async def get_user(self, user_id: str) -> AdminUserDetailResponse:
        """Get detailed user information."""
        response = await self._client.get(f"/api/v1/admin/users/{user_id}")
        _check_async_admin(response, "User", not_found=f"User not found: {user_id}")
        return AdminUserDetailResponse.model_validate(response.json())

    async def list_tasks(
        self,
        *,
        include_disabled: bool = True,
        limit: int = 50,
        offset: int = 0,
    ) -> AdminTaskListResponse:
        """List all tasks including disabled ones."""
        params: dict[str, Any] = {
            "include_disabled": str(include_disabled).lower(),
            "limit": limit,
            "offset": offset,
        }
        response = await self._client.get("/api/v1/admin/tasks", params=params)
        _check_async_admin(response, "Tasks")
        return AdminTaskListResponse.model_validate(response.json())

    async def toggle_task(self, slug: str, *, disabled: bool) -> TaskToggleResponse:
        """Enable or disable a task."""
        response = await self._client.patch(
            f"/api/v1/admin/tasks/{slug}",
            json={"disabled": disabled},
        )
        _check_async_admin(response, "Task", not_found=f"Task not found: {slug}")
        return TaskToggleResponse.model_validate(response.json())

    async def list_audit_logs(
        self,
        *,
        user_id: str | None = None,
        method: str | None = None,
        path_prefix: str | None = None,
        status_code: int | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> AuditLogListResponse:
        """Query audit logs."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if user_id:
            params["user_id"] = user_id
        if method:
            params["method"] = method
        if path_prefix:
            params["path_prefix"] = path_prefix
        if status_code is not None:
            params["status_code"] = status_code
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before
        response = await self._client.get("/api/v1/admin/audit-logs", params=params)
        _check_async_admin(response, "Audit logs")
        return AuditLogListResponse.model_validate(response.json())


# ==================== Helpers ====================


def _check_async(
    response: httpx.Response,
    resource: str,
    *,
    not_found: str | None = None,
    entity: str | None = None,
) -> None:
    """Check async response status and raise on errors.

    Args:
        response: HTTP response.
        resource: Resource name for error messages.
        not_found: Custom 404 message. If None, uses default.
        entity: Entity name for 403 messages (e.g., "run" when resource is
            "Logs"). Defaults to resource if not provided.

    Raises:
        RuntimeError: On error responses.
    """
    if response.status_code == 404:
        raise RuntimeError(not_found or f"{resource} not found")
    if response.status_code == 403:
        name = (entity or resource).lower()
        raise RuntimeError(f"Access denied to {name}")
    if response.status_code >= 400:
        raise RuntimeError(f"Failed to fetch {resource.lower()} (HTTP {response.status_code})")


def _check_async_admin(
    response: httpx.Response,
    resource: str = "Resource",
    *,
    not_found: str | None = None,
) -> None:
    """Check async admin endpoint response and raise on errors.

    Args:
        response: HTTP response.
        resource: Resource name for error messages.
        not_found: Custom 404 message. If None, uses default.

    Raises:
        RuntimeError: On error responses with admin-specific 403 message.
    """
    if response.status_code == 403:
        raise RuntimeError("Access denied. This command requires admin or monitor permissions.")
    _check_async(response, resource, not_found=not_found)


def _check_admin(
    response: httpx.Response,
    resource: str = "Resource",
) -> None:
    """Check admin endpoint response and raise appropriate errors.

    Args:
        response: HTTP response.
        resource: Resource name for error messages.

    Raises:
        APIError: On error responses with admin-specific messages.
    """
    if response.status_code == 403:
        raise APIError(
            "Access denied. This command requires admin or monitor permissions.",
            status_code=403,
        )
    check_response(response, resource)
