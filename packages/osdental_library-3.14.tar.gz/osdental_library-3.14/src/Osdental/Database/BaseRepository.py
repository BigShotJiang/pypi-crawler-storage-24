from typing import Any
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from Osdental.Exception.ControlledException import DatabaseException, OSDException
from Osdental.Shared.Utils.DataNormalizer import normalize

class BaseRepository:

    def __init__(self, async_session: AsyncSession):
        self.async_session = async_session
    
    def _get_status_value(self, rows: dict, *possible_keys: str):
        for key in possible_keys:
            if key in rows:
                return rows[key]
        return None

    async def _execute_query(
        self,
        query: str,
        params: dict | None = None,
        *,
        many: bool = False,
        as_dict: bool = False
    ) -> Any:
        
        result = await self.async_session.execute(
            text(query),
            params or {}
        )
        
        data = (
            result.mappings().all()
            if many
            else result.mappings().first()
        )

        if as_dict and data is not None:
            return normalize(data)

        return data


    async def _execute_command(
        self,
        query: str,
        params: dict | None = None,
        *,
        validate: bool = True,
        success_codes: str | int | tuple[str | int, ...] | None = None,
        as_dict: bool = False
    ) -> Any:
        
        result = await self.async_session.execute(
            text(query),
            params or {}
        )

        row = result.mappings().first()

        if not validate or not row:
            return normalize(row) if as_dict else row


        status_code = self._get_status_value(
            row,
            "statusCode",
            "STATUS_CODE",
            "status_code"
        )

        status_message = self._get_status_value(
            row,
            "statusMessage",
            "STATUS_MESSAGE",
            "status_message"
        )

        # Si no se define success_codes, solo valida que no sea None
        if success_codes is None:
            if status_code is None:
                raise DatabaseException(
                    message="Status code missing",
                    error="Status code missing",
                    status_code=500
                )

        else:

            if not isinstance(success_codes, tuple):
                success_codes = (success_codes,)

            if status_code not in success_codes:
                raise DatabaseException(
                    message=status_message,
                    error=status_message,
                    status_code=status_code
                )

        return normalize(row) if as_dict else row
    

    async def _execute_scalar(
        self,
        query: str,
        params: dict | None = None
    ) -> Any | None:
        result = await self.async_session.execute(
            text(query),
            params or {}
        )
        return result.scalar_one_or_none()