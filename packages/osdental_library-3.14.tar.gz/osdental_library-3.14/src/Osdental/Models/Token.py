from typing import Optional
from dataclasses import dataclass

@dataclass
class AuthToken:
    id_token: str
    id_user: str
    id_external_enterprise: str
    id_profile: str
    id_legacy: str
    id_authorization: str
    id_item_report: str
    id_enterprise: str
    user_full_name: str
    abbreviation: str
    aes_key_auth: str
    aes_key_user: Optional[str] = None
    access_token: Optional[str] = None
    base_id_external_enterprise: Optional[str] = None
    mk_id_external_enterprise: Optional[str] = None