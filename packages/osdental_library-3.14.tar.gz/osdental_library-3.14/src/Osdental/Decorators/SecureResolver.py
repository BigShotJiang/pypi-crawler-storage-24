import inspect
import copy
from functools import wraps
from typing import Callable, Dict, Any
from Osdental.Models.Token import AuthToken
from Osdental.Models.Response import Response
from Osdental.Shared.Enums.Profile import Profile
from Osdental.Exception.ControlledException import OSDException, AccessDeniedException
from Osdental.Encryptor.Aes import AES
from Osdental.Graphql.Models import BaseGraphQLContext

def secure_resolver(action = None):
    def decorator(func: Callable):

        signature = inspect.signature(func)
        params = signature.parameters

        @wraps(func)
        async def wrapper(obj: Any, context: BaseGraphQLContext, **kwargs: Dict[str, Any]):
            try:
                token: AuthToken = context.token
                payload = getattr(context, "decrypted_payload", None)
                aes_auth = getattr(context, "aes_auth", None)

                if action:
                    if Profile(token.abbreviation) not in action.allowed_roles:
                        raise AccessDeniedException(error="The user's profile is not allowed to perform this action.")

                if "token" in params:
                    kwargs["token"] = token

                if "data" in params:
                    kwargs["data"] = payload

                result: Response = await func(obj, **kwargs)

                context.audit_plain_response = copy.deepcopy(result)

                if result.data is not None:
                    result.data = AES.encrypt(aes_auth, result.data)

                return result.send()

            except (Exception, OSDException) as e:
                result = Response(
                    status=getattr(e, "status_code", "DB_ERROR_UNEXPECTED"),
                    message=getattr(e, "message", "Could not process request."),
                    error=f"{type(e).__name__}: {str(e)}"
                )
                context.audit_plain_response = result
                return result.send()

        return wrapper
    return decorator