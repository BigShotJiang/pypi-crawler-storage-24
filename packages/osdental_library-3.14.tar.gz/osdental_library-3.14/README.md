# osdental-library

`osdental-library` centralizes the core components and shared utilities of the ecosystem. Its goal is to ensure technical consistency, reduce code duplication, and accelerate delivery time for our digital products.

## What's new in v3.14

## Features

- Centralized Secret Management (Azure Key Vault): * A new specialized class is integrated for the consumption of Azure Key Vault.
- security through Managed Identity: * Migration of key services (Blob Storage, Service Bus, etc.) and the connection to the database to operate through Managed Identity.
- Replaced the traditional audit decorator with a native Ariadne extension.
- The AES class has been optimized with class methods (@classmethod). It is no longer necessary to instantiate the class to perform encryption/decryption operations.
- Introduction of Abstract Base Classes (ABC) for repositories. They include standardized logic and the native ability to transform entities or results directly into dictionaries.

## Breaking Changes
- Removed the database execution methods from the connection class.
- Removed internal gRPC connections. Now, these must be injected from the client microservice, allowing greater flexibility and avoiding circular dependencies.
- Classes that connected directly via .env were removed. Access to Azure has been restructured to support Dependency Injection correctly.
- The base structure generation CLI commands have been temporarily removed to adapt them to the new library architecture.

## What's Next
- Migration plan for all base libraries to their most recent stable versions.
- Refinement of methods for hybrid environments that require switching between Managed Identity and Connection Strings depending on the environment.
- Continuous monitoring to resolve bugs and improve performance in the consumption of Azure resources.

We continue to work to deliver a superior development experience, ensuring our internal infrastructure is robust, secure and easy to deploy.

## Installation

You can easily install `osdental-library` using `pip`:

```bash
pip install osdental-library
