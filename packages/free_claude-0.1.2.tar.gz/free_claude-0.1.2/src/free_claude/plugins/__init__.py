"""Bundled MCP plugin definitions for free-claude."""
