"""free-claude: Free Claude AI agent with tools and MCP support."""
__version__ = "0.1.2"
__author__ = "free-claude contributors"

from .agent import Agent
from .auth import get_token, refresh_token, login, is_logged_in

__all__ = ["Agent", "get_token", "refresh_token", "login", "is_logged_in"]
