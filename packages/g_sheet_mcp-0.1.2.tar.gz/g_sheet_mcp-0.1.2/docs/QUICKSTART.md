# ⚡ Quick Start — 5 minutes to first data

## Prerequisites

| Tool | Install |
|---|---|
| Python 3.11+ | `brew install python` or [python.org](https://python.org) |
| uv | `brew install uv` or `curl -LsSf https://astral.sh/uv/install.sh \| sh` |
| Google Cloud SDK | `brew install google-cloud-sdk` or [cloud.google.com/sdk](https://cloud.google.com/sdk/docs/install) |

---

## Step 1 — Run the published package (recommended)

This is the simplest setup for most users now that `g-sheet-mcp` is published on PyPI.

```bash
uvx g-sheet-mcp --help

# Optional: pin an exact release
uvx --from g-sheet-mcp==0.1.2 g-sheet-mcp --help
```

Need unreleased changes or a local development checkout instead?

```bash
# Run directly from GitHub
uvx --from git+https://github.com/mariadb-RupeshBiswas/google-sheets-mcp g-sheet-mcp --help

# Run from a local path
uvx --from /absolute/path/to/google-sheets-mcp g-sheet-mcp --help

# Clone the repo for development
git clone https://github.com/mariadb-RupeshBiswas/google-sheets-mcp.git
cd google-sheets-mcp
uv sync
```

---

## Step 2 — Authenticate (once)

```bash
gcloud auth login --enable-gdrive-access --update-adc
```

A browser window opens. Sign in with the Google account that has access to your spreadsheets.

> **What this does:** Writes `~/.config/gcloud/application_default_credentials.json` with
> Drive + Sheets scopes. The server auto-detects and uses this file on every run — no extra
> configuration needed.

---

## Step 3 — Connect to your editor

Pick your editor from the table below and follow the link:

| Editor | Guide |
|---|---|
| **Windsurf** | [EDITOR_SETUP.md → Windsurf](EDITOR_SETUP.md#windsurf) |
| **Cursor** | [EDITOR_SETUP.md → Cursor](EDITOR_SETUP.md#cursor) |
| **Claude Desktop** | [EDITOR_SETUP.md → Claude Desktop](EDITOR_SETUP.md#claude-desktop) |
| **VS Code + Copilot** | [EDITOR_SETUP.md → VS Code](EDITOR_SETUP.md#vs-code--github-copilot) |
| **Zed** | [EDITOR_SETUP.md → Zed](EDITOR_SETUP.md#zed) |
| **Claude Code (CLI)** | [EDITOR_SETUP.md → Claude Code](EDITOR_SETUP.md#claude-code-cli) |

---

## Step 4 — Ask your AI a question

Once connected, try prompts like:

```
Read all sheet tabs from https://docs.google.com/spreadsheets/d/YOUR_ID/edit
```

```
Show me the first 10 rows of 'Sheet1' as a table
```

```
Find all cells containing "invoice" in this spreadsheet: YOUR_SPREADSHEET_URL
```

---

## What's next?

- Full tool reference → [README.md](../README.md#available-mcp-tools--reference)
- Editor setup details → [EDITOR_SETUP.md](EDITOR_SETUP.md)
- Development setup → [../CONTRIBUTING.md](../CONTRIBUTING.md)
- Authentication details → [AUTH.md](AUTH.md)
- Troubleshooting → [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
