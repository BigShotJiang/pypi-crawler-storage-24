# This file is part of Torch Lens Maker
# Copyright (C) 2024-present Victor Poughon
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import pytest

import torch
import torchlensmaker as tlm


def test_paraxial1() -> None:
    mat1 = tlm.NonDispersiveMaterial(1.517)
    mat2 = tlm.NonDispersiveMaterial(1.649)
    doublet = tlm.Lens(
        tlm.RefractiveSurface(
            tlm.SphereByCurvature(4.0, C=0.135327), materials=("air", mat1)
        ),
        tlm.Gap(1.05),
        tlm.RefractiveSurface(
            tlm.SphereByCurvature(3.8, C=-0.19311), materials=(mat1, mat2)
        ),
        tlm.Gap(0.4),
        tlm.RefractiveSurface(
            tlm.SphereByCurvature(4.0, C=-0.06164), materials=(mat2, "air")
        ),
    )

    # Lens stuff
    print("Lens minimal diameter:", doublet.minimal_diameter().detach().item())
    print("Lens inner thickness:", doublet.inner_thickness().detach().item())
    print("Lens outer thickness:", doublet.outer_thickness().detach().item())

    # Rear Paraxial points
    rear_principal_point = tlm.paraxial.rear_principal_point(doublet, wavelength=550)
    rear_focal_point = tlm.paraxial.rear_focal_point(doublet, wavelength=550, h=0.01)
    rear_focal_length = rear_focal_point - rear_principal_point

    print("Lens rear principal point:", rear_principal_point.detach().item())
    print("Lens rear focal point:", rear_focal_point.detach().item())
    print("Lens rear focal length:", rear_focal_length.detach().item())

    # Front paraxial points
    front_principal_point = tlm.paraxial.front_principal_point(doublet, wavelength=550)
    front_focal_point = tlm.paraxial.front_focal_point(doublet, wavelength=550, h=0.01)
    front_focal_length = front_focal_point - front_principal_point

    print("Lens front principal point:", front_principal_point.detach().item())
    print("Lens front focal point:", front_focal_point.detach().item())
    print("Lens front focal length:", front_focal_length.detach().item())
