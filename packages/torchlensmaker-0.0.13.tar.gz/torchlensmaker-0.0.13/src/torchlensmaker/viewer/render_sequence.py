# This file is part of Torch Lens Maker
# Copyright (C) 2024-present Victor Poughon
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import torch
import torch.nn as nn

from typing import Any, Optional, Dict

from torchlensmaker.types import Direction
from torchlensmaker.optical_data import default_input
from torchlensmaker.kinematics.kinematics_elements import KinematicElement
from torchlensmaker.elements.sequential import Sequential, SubChain, Reversed
from torchlensmaker.optical_surfaces.reflective_surface import ReflectiveSurface
from torchlensmaker.optical_surfaces.refractive_surface import RefractiveSurface, SurfacePropagator
from torchlensmaker.optical_surfaces.aperture import Aperture
from torchlensmaker.elements.focal_point import FocalPoint
from torchlensmaker.optical_surfaces.image_plane import ImagePlane

from torchlensmaker.lens.lens import Lens

# from torchlensmaker.lenses import LensBase
from torchlensmaker.core.deep_forward import deep_forward
from torchlensmaker.light_sources.light_sources_elements import LightSourceBase
from torchlensmaker.light_sources.light_sources_query import (
    set_sampling2d,
    set_sampling3d,
)
from torchlensmaker.elements.utils import get_elements_by_type

from .rendering import Collective
from . import tlmviewer
from .rendering import Artist
from .artists import (
    SequentialArtist,
    ForwardArtist,
    KinematicArtist,
    SurfacePropagatorArtist,
    FocalPointArtist,
    ray_variables_dict,
)

import json

Tensor = torch.Tensor


def inspect_stack(execute_list: list[tuple[nn.Module, Any, Any]]) -> None:
    for module, inputs, outputs in execute_list:
        print(type(module))
        print("inputs.transform:")
        for t in inputs.transforms:
            print(t)
        print()
        print("outputs.transform:")
        for t in outputs.transforms:
            print(t)
        print()


default_artists: Dict[type, list[Artist]] = {
    Sequential: [SequentialArtist()],
    FocalPoint: [FocalPointArtist()],
    Lens: [ForwardArtist(lambda mod: mod.sequence)],
    SubChain: [ForwardArtist(lambda mod: mod._sequential)],
    SurfacePropagator: [SurfacePropagatorArtist()],
    RefractiveSurface: [ForwardArtist(lambda mod: mod.propagator)],
    ReflectiveSurface: [ForwardArtist(lambda mod: mod.propagator)],
    Aperture: [ForwardArtist(lambda mod: mod.propagator)],
    ImagePlane: [ForwardArtist(lambda mod: mod.propagator)],
    Reversed: [ForwardArtist(lambda mod: mod.element)],
    KinematicElement: [KinematicArtist()],
}


def get_domain(optics: nn.Module, dim: int) -> dict[str, list[float]]:
    light_sources = get_elements_by_type(optics, LightSourceBase)

    if len(light_sources) == 0:
        return {}

    # TODO handle multiple light sources
    ls = light_sources[0]

    return ls.domain(dim)


# TODO rename
def render_sequence(
    optics: nn.Module,
    dim: int,
    dtype: torch.dtype | None = None,
    end: Optional[float] = None,
    title: str = "",
    extra_artists: Dict[type, Artist] = {},
    reverse: bool = False,
) -> Any:
    if dtype is None:
        dtype = torch.get_default_dtype()

    # Evaluate the model with deep_forward to keep all intermediate outputs
    direction = Direction("prograde" if not reverse else "retrograde")
    with deep_forward(optics) as trace:
        _ = optics(default_input(dim=dim, dtype=dtype, direction=direction))

    # Figure out available ray variables and their range, this will be used for coloring info by tlmviewer
    ray_variables_domains = get_domain(optics, dim)

    # Initialize the artist collective
    collective = Collective(
        {**default_artists, **extra_artists},
        ray_variables_domains,
        trace.inputs,
        trace.outputs,
    )

    # Initialize the scene
    scene = tlmviewer.new_scene("2D" if dim == 2 else "3D")

    # Render the top level module
    scene["data"].extend(collective.render(optics))

    # Render output rays with end argument
    if end is not None:
        outputs = collective.output_tree[optics]
        scene["data"].extend(
            tlmviewer.render_rays_length(
                outputs.rays.P,
                outputs.rays.V,
                end,
                variables=ray_variables_dict(outputs.rays),
                domain=collective.ray_variables_domains,
                default_color=tlmviewer.color_valid,
                layer=tlmviewer.LAYER_OUTPUT_RAYS,
            )
        )

    if title != "":
        scene["title"] = title

    return scene


def show(
    optics: nn.Module,
    dim: int = 2,
    dtype: torch.dtype | None = None,
    end: Optional[float] = None,
    title: str = "",
    ndigits: int | None = 8,
    controls: object | None = None,
    return_scene: bool = False,
    extra_artists: Dict[type, Artist] = {},
    pupil: Any | None = None,
    field: Any | None = None,
    wavelength: Any | None = None,
    reverse: bool = False,
) -> None | Any:
    "Render an optical stack and show it with ipython display"

    if dtype is None:
        dtype = torch.get_default_dtype()

    if dim == 2:
        set_sampling2d(optics, pupil, field, wavelength)
    elif dim == 3:
        set_sampling3d(optics, pupil, field, wavelength)

    scene = render_sequence(optics, dim, dtype, end, title, extra_artists, reverse)

    if controls is not None:
        scene["controls"] = controls

    tlmviewer.display_scene(scene, ndigits)

    return scene if return_scene else None


def show2d(*args, **kwargs):
    kwargs["dim"] = 2
    return show(*args, **kwargs)


def show3d(*args, **kwargs):
    kwargs["dim"] = 3
    return show(*args, **kwargs)


def export_json(
    optics: nn.Module,
    filename: str,
    dim: int = 2,
    dtype: torch.dtype | None = None,
    sampling: Optional[Dict[str, Any]] = None,
    end: Optional[float] = None,
    title: str = "",
    ndigits: int | None = 8,
    controls: object | None = None,
) -> None:
    "Render and export an optical stack to a tlmviewer json file"

    if dtype is None:
        dtype = torch.get_default_dtype()

    if sampling is None:
        # TODO figure out a better default based on stack content?
        sampling = {"base": 10, "object": 5, "wavelength": 8}

    scene = render_sequence(optics, dim, dtype, end, title)

    if controls is not None:
        scene["controls"] = controls

    if ndigits is not None:
        scene = tlmviewer.truncate_scene(scene, ndigits)

    with open(filename, "w") as f:
        json.dump(scene, f)
