# This file is part of Torch Lens Maker
# Copyright (C) 2024-present Victor Poughon
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import torch
import torch.nn as nn

from itertools import chain
from dataclasses import dataclass
from typing import Any, Dict, Optional, TypeAlias


from torchlensmaker.optical_data import OpticalData

Tensor: TypeAlias = torch.Tensor

LAYER_VALID_RAYS = 1
LAYER_BLOCKED_RAYS = 2
LAYER_OUTPUT_RAYS = 3
LAYER_JOINTS = 4


class Artist:
    def render(self, collective: "Collective", module: nn.Module) -> list[Any]:
        raise NotImplementedError


@dataclass
class Collective:
    "Group of artists"

    artists: Dict[type, Artist]
    ray_variables_domains: dict[str, list[float]]
    input_tree: dict[nn.Module, Any]
    output_tree: dict[nn.Module, Any]

    def match_artists(self, module: nn.Module) -> list[Artist]:
        "Match an artist to a module"

        artists: list[Artist] = [
            a for typ, a in self.artists.items() if isinstance(module, typ)
        ]

        return [] if len(artists) == 0 else artists[0]

    def render(self, module: nn.Module) -> list[Any]:
        artists = self.match_artists(module)

        if len(artists) == 0:
            return []

        # Let the artists render and flatten their returned lists
        renders = [a.render(self, module) for a in artists]
        return list(chain(*renders))
