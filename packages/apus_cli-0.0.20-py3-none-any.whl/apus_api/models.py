from datetime import datetime
from enum import Enum
from functools import reduce
from typing import Annotated, Any, Literal, Optional, Union

from apus_shared.fields import expand_dict, expand_obj, reference
from apus_shared.models import BaseModel, Connection, create_resource
from pydantic import Field
from pyxis.enum import EnumMixin

Primitive = Union[str, int, float, bool]


class Parameter(BaseModel):
    """An abstract class to represent a parameter."""

    name: Annotated[
        str, Field(..., min_length=1, max_length=64, pattern='^[A-Za-z][A-Za-z0-9_-]+$', serialization_alias='alias')
    ]
    description: Annotated[Optional[str], Field(default=None, min_length=1, max_length=256)]


class PathParameter(Parameter):
    """Represents a path parameter in a HTTP request."""


class QueryParameter(Parameter):
    """Represents a query parameter in a HTTP request."""

    required: Annotated[bool, Field(default=True)]
    default: Annotated[Optional[Primitive], Field(default=None)]
    deprecated: Annotated[bool, Field(default=False)]


class StringFormat(str, EnumMixin, Enum):
    """String format mixin."""

    DATE = 'date'
    DATE_TIME = 'date-time'
    UUID = 'uuid'


class StringMixin(BaseModel):
    """String validation mixin."""

    type: Annotated[Literal['string'], Field('string')]
    min_length: Annotated[Optional[int], Field(default=None, ge=0, alias='minLength')]
    max_length: Annotated[Optional[int], Field(default=None, ge=0, alias='maxLength')]
    pattern: Annotated[Optional[str], Field(default=None, min_length=1, max_length=256)]
    format: Annotated[Optional[StringFormat], Field(default=None)]


class NumberMixin(BaseModel):
    """Number validation mixin."""

    type: Annotated[Literal['number', 'integer'], Field('number')]
    minimum: Annotated[Optional[float], Field(default=None, serialization_alias='ge')]
    maximum: Annotated[Optional[float], Field(default=None, serialization_alias='le')]
    exclusive_minimum: Annotated[
        Optional[bool], Field(default=None, alias='exclusiveMinimum', serialization_alias='gt')
    ]
    exclusive_maximum: Annotated[
        Optional[bool], Field(default=None, alias='exclusiveMaximum', serialization_alias='lt')
    ]
    multiple_of: Annotated[Optional[float], Field(default=None, alias='multipleOf')]


class BooleanMixin(BaseModel):
    """Boolean validation mixin."""

    type: Annotated[Literal['boolean'], Field('boolean')]


def mixin(cls):
    """Make a union of the given class with the mixins."""

    return dict[
        str,
        Annotated[
            reduce(
                lambda accumulator, resource: Union[accumulator, resource],
                [
                    type(f'{cls.__name__}{obj_mixin.__name__}', (cls, obj_mixin), {})
                    for obj_mixin in [StringMixin, NumberMixin, BooleanMixin]
                ],
            ),
            Field(..., discriminator='type'),
        ],
    ]


class Request(BaseModel):
    """A http request definition."""

    path: Annotated[str, ...]
    http_method: Annotated[str, Field(pattern='^(GET|POST)$', alias='httpMethod')]
    path_parameters: Annotated[
        mixin(PathParameter), expand_dict('name'), Field(min_length=0, max_length=16, alias='pathParameters')
    ]
    query_parameters: Annotated[
        mixin(QueryParameter), expand_dict('name'), Field(min_length=0, max_length=16, alias='queryParameters')
    ]
    body: Annotated[Optional[dict[str, Any]], Field(default=None)]


class Envelope(BaseModel):
    """An envelope definition for wrapping response data."""

    type: Annotated[Literal['object', 'array'], Field(default='array')]
    property: Annotated[str, Field('data')]


class Response(BaseModel):
    """A http response definition."""

    status_code: Annotated[int, Field(default=200, ge=100, le=599, alias='statusCode')]
    envelope: Annotated[Optional[Envelope], Field(default=Envelope())]
    content_schema: Annotated[Optional[dict[str, Any]], Field(default=None, alias='schema')]


class Authentication(BaseModel):
    """An authentication definition."""

    __api_version__ = 'apus/v1'
    __kind__ = 'Authentication'

    domain: Annotated[Optional[str], Field(None, min_length=1, max_length=256, pattern='^[A-Za-z][A-Za-z0-9._-]+$')]
    path: Annotated[str, Field(..., min_length=1, max_length=256, pattern='^[A-Za-z0-9._/-]+$')]
    expires_in: Annotated[int, Field(..., ge=60, alias='expiresIn')]
    user_pool: Annotated[Optional[str], Field(None, alias='userPool')]
    client_id: Annotated[Optional[str], Field(None, alias='clientId')]


class DataGateway(BaseModel):
    """A Data Gateway resource specification."""

    __api_version__ = 'apus/v1'
    __kind__ = 'DataGateway'

    domain: Annotated[Optional[str], Field(None, min_length=1, max_length=256, pattern='^[A-Za-z][A-Za-z0-9._-]+$')]
    authentication: Annotated[Optional[str], Field(default=None)]
    request: Annotated[Request, ...]
    response: Annotated[Optional[Response], Field(default=Response())]
    connection: Annotated[reference(Connection), expand_obj()]
    query_template: Annotated[str, ...]


class Identity(BaseModel):
    """A user identity definition."""

    username: Annotated[str, Field(..., alias='sub')]
    expired_at: Annotated[datetime, Field(..., alias='exp')]


Resource = create_resource()
