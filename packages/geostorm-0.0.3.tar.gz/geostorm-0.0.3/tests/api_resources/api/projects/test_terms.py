# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from geostorm import Geostorm, AsyncGeostorm
from tests.utils import assert_matches_type
from geostorm.types.api.projects import Term, TermListResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestTerms:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Geostorm) -> None:
        term = client.api.projects.terms.create(
            project_id="project_id",
            name="x",
        )
        assert_matches_type(Term, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Geostorm) -> None:
        term = client.api.projects.terms.create(
            project_id="project_id",
            name="x",
            description="description",
        )
        assert_matches_type(Term, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Geostorm) -> None:
        response = client.api.projects.terms.with_raw_response.create(
            project_id="project_id",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        term = response.parse()
        assert_matches_type(Term, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Geostorm) -> None:
        with client.api.projects.terms.with_streaming_response.create(
            project_id="project_id",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            term = response.parse()
            assert_matches_type(Term, term, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_create(self, client: Geostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            client.api.projects.terms.with_raw_response.create(
                project_id="",
                name="x",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Geostorm) -> None:
        term = client.api.projects.terms.list(
            "project_id",
        )
        assert_matches_type(TermListResponse, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Geostorm) -> None:
        response = client.api.projects.terms.with_raw_response.list(
            "project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        term = response.parse()
        assert_matches_type(TermListResponse, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Geostorm) -> None:
        with client.api.projects.terms.with_streaming_response.list(
            "project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            term = response.parse()
            assert_matches_type(TermListResponse, term, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list(self, client: Geostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            client.api.projects.terms.with_raw_response.list(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete(self, client: Geostorm) -> None:
        term = client.api.projects.terms.delete(
            term_id="term_id",
            project_id="project_id",
        )
        assert_matches_type(object, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Geostorm) -> None:
        response = client.api.projects.terms.with_raw_response.delete(
            term_id="term_id",
            project_id="project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        term = response.parse()
        assert_matches_type(object, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Geostorm) -> None:
        with client.api.projects.terms.with_streaming_response.delete(
            term_id="term_id",
            project_id="project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            term = response.parse()
            assert_matches_type(object, term, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Geostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            client.api.projects.terms.with_raw_response.delete(
                term_id="term_id",
                project_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `term_id` but received ''"):
            client.api.projects.terms.with_raw_response.delete(
                term_id="",
                project_id="project_id",
            )


class TestAsyncTerms:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncGeostorm) -> None:
        term = await async_client.api.projects.terms.create(
            project_id="project_id",
            name="x",
        )
        assert_matches_type(Term, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncGeostorm) -> None:
        term = await async_client.api.projects.terms.create(
            project_id="project_id",
            name="x",
            description="description",
        )
        assert_matches_type(Term, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.projects.terms.with_raw_response.create(
            project_id="project_id",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        term = await response.parse()
        assert_matches_type(Term, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.projects.terms.with_streaming_response.create(
            project_id="project_id",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            term = await response.parse()
            assert_matches_type(Term, term, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_create(self, async_client: AsyncGeostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            await async_client.api.projects.terms.with_raw_response.create(
                project_id="",
                name="x",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncGeostorm) -> None:
        term = await async_client.api.projects.terms.list(
            "project_id",
        )
        assert_matches_type(TermListResponse, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.projects.terms.with_raw_response.list(
            "project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        term = await response.parse()
        assert_matches_type(TermListResponse, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.projects.terms.with_streaming_response.list(
            "project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            term = await response.parse()
            assert_matches_type(TermListResponse, term, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list(self, async_client: AsyncGeostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            await async_client.api.projects.terms.with_raw_response.list(
                "",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncGeostorm) -> None:
        term = await async_client.api.projects.terms.delete(
            term_id="term_id",
            project_id="project_id",
        )
        assert_matches_type(object, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.projects.terms.with_raw_response.delete(
            term_id="term_id",
            project_id="project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        term = await response.parse()
        assert_matches_type(object, term, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.projects.terms.with_streaming_response.delete(
            term_id="term_id",
            project_id="project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            term = await response.parse()
            assert_matches_type(object, term, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncGeostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            await async_client.api.projects.terms.with_raw_response.delete(
                term_id="term_id",
                project_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `term_id` but received ''"):
            await async_client.api.projects.terms.with_raw_response.delete(
                term_id="",
                project_id="project_id",
            )
