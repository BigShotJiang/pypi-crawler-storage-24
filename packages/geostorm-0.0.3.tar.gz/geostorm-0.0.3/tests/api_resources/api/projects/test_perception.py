# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from geostorm import Geostorm, AsyncGeostorm
from tests.utils import assert_matches_type
from geostorm.types.api.projects import (
    PerceptionListResponse,
    PerceptionRetrieveBreakdownResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPerception:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Geostorm) -> None:
        perception = client.api.projects.perception.list(
            project_id="project_id",
        )
        assert_matches_type(PerceptionListResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Geostorm) -> None:
        perception = client.api.projects.perception.list(
            project_id="project_id",
            end_date="end_date",
            start_date="start_date",
        )
        assert_matches_type(PerceptionListResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Geostorm) -> None:
        response = client.api.projects.perception.with_raw_response.list(
            project_id="project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        perception = response.parse()
        assert_matches_type(PerceptionListResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Geostorm) -> None:
        with client.api.projects.perception.with_streaming_response.list(
            project_id="project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            perception = response.parse()
            assert_matches_type(PerceptionListResponse, perception, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_list(self, client: Geostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            client.api.projects.perception.with_raw_response.list(
                project_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve_breakdown(self, client: Geostorm) -> None:
        perception = client.api.projects.perception.retrieve_breakdown(
            "project_id",
        )
        assert_matches_type(PerceptionRetrieveBreakdownResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve_breakdown(self, client: Geostorm) -> None:
        response = client.api.projects.perception.with_raw_response.retrieve_breakdown(
            "project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        perception = response.parse()
        assert_matches_type(PerceptionRetrieveBreakdownResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_breakdown(self, client: Geostorm) -> None:
        with client.api.projects.perception.with_streaming_response.retrieve_breakdown(
            "project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            perception = response.parse()
            assert_matches_type(PerceptionRetrieveBreakdownResponse, perception, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve_breakdown(self, client: Geostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            client.api.projects.perception.with_raw_response.retrieve_breakdown(
                "",
            )


class TestAsyncPerception:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncGeostorm) -> None:
        perception = await async_client.api.projects.perception.list(
            project_id="project_id",
        )
        assert_matches_type(PerceptionListResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncGeostorm) -> None:
        perception = await async_client.api.projects.perception.list(
            project_id="project_id",
            end_date="end_date",
            start_date="start_date",
        )
        assert_matches_type(PerceptionListResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.projects.perception.with_raw_response.list(
            project_id="project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        perception = await response.parse()
        assert_matches_type(PerceptionListResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.projects.perception.with_streaming_response.list(
            project_id="project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            perception = await response.parse()
            assert_matches_type(PerceptionListResponse, perception, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_list(self, async_client: AsyncGeostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            await async_client.api.projects.perception.with_raw_response.list(
                project_id="",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve_breakdown(self, async_client: AsyncGeostorm) -> None:
        perception = await async_client.api.projects.perception.retrieve_breakdown(
            "project_id",
        )
        assert_matches_type(PerceptionRetrieveBreakdownResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_breakdown(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.projects.perception.with_raw_response.retrieve_breakdown(
            "project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        perception = await response.parse()
        assert_matches_type(PerceptionRetrieveBreakdownResponse, perception, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_breakdown(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.projects.perception.with_streaming_response.retrieve_breakdown(
            "project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            perception = await response.parse()
            assert_matches_type(PerceptionRetrieveBreakdownResponse, perception, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve_breakdown(self, async_client: AsyncGeostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `project_id` but received ''"):
            await async_client.api.projects.perception.with_raw_response.retrieve_breakdown(
                "",
            )
