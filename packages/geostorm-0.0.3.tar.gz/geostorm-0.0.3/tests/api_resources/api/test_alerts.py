# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from geostorm import Geostorm, AsyncGeostorm
from tests.utils import assert_matches_type
from geostorm.types.api import AlertListResponse, AlertAcknowledgeResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAlerts:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Geostorm) -> None:
        alert = client.api.alerts.list(
            project_id="project_id",
        )
        assert_matches_type(AlertListResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Geostorm) -> None:
        alert = client.api.alerts.list(
            project_id="project_id",
            acknowledged=True,
            limit=0,
            offset=0,
            severity="info",
        )
        assert_matches_type(AlertListResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Geostorm) -> None:
        response = client.api.alerts.with_raw_response.list(
            project_id="project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        alert = response.parse()
        assert_matches_type(AlertListResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Geostorm) -> None:
        with client.api.alerts.with_streaming_response.list(
            project_id="project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            alert = response.parse()
            assert_matches_type(AlertListResponse, alert, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_acknowledge(self, client: Geostorm) -> None:
        alert = client.api.alerts.acknowledge(
            "alert_id",
        )
        assert_matches_type(AlertAcknowledgeResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_acknowledge(self, client: Geostorm) -> None:
        response = client.api.alerts.with_raw_response.acknowledge(
            "alert_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        alert = response.parse()
        assert_matches_type(AlertAcknowledgeResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_acknowledge(self, client: Geostorm) -> None:
        with client.api.alerts.with_streaming_response.acknowledge(
            "alert_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            alert = response.parse()
            assert_matches_type(AlertAcknowledgeResponse, alert, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_acknowledge(self, client: Geostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `alert_id` but received ''"):
            client.api.alerts.with_raw_response.acknowledge(
                "",
            )


class TestAsyncAlerts:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncGeostorm) -> None:
        alert = await async_client.api.alerts.list(
            project_id="project_id",
        )
        assert_matches_type(AlertListResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncGeostorm) -> None:
        alert = await async_client.api.alerts.list(
            project_id="project_id",
            acknowledged=True,
            limit=0,
            offset=0,
            severity="info",
        )
        assert_matches_type(AlertListResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.alerts.with_raw_response.list(
            project_id="project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        alert = await response.parse()
        assert_matches_type(AlertListResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.alerts.with_streaming_response.list(
            project_id="project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            alert = await response.parse()
            assert_matches_type(AlertListResponse, alert, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_acknowledge(self, async_client: AsyncGeostorm) -> None:
        alert = await async_client.api.alerts.acknowledge(
            "alert_id",
        )
        assert_matches_type(AlertAcknowledgeResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_acknowledge(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.alerts.with_raw_response.acknowledge(
            "alert_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        alert = await response.parse()
        assert_matches_type(AlertAcknowledgeResponse, alert, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_acknowledge(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.alerts.with_streaming_response.acknowledge(
            "alert_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            alert = await response.parse()
            assert_matches_type(AlertAcknowledgeResponse, alert, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_acknowledge(self, async_client: AsyncGeostorm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `alert_id` but received ''"):
            await async_client.api.alerts.with_raw_response.acknowledge(
                "",
            )
