# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from geostorm import Geostorm, AsyncGeostorm
from tests.utils import assert_matches_type
from geostorm.types.api import SetupAutofillResponse, SetupRetrieveStatusResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSetup:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_autofill(self, client: Geostorm) -> None:
        setup = client.api.setup.autofill(
            input="x",
        )
        assert_matches_type(SetupAutofillResponse, setup, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_autofill(self, client: Geostorm) -> None:
        response = client.api.setup.with_raw_response.autofill(
            input="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        setup = response.parse()
        assert_matches_type(SetupAutofillResponse, setup, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_autofill(self, client: Geostorm) -> None:
        with client.api.setup.with_streaming_response.autofill(
            input="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            setup = response.parse()
            assert_matches_type(SetupAutofillResponse, setup, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve_status(self, client: Geostorm) -> None:
        setup = client.api.setup.retrieve_status()
        assert_matches_type(SetupRetrieveStatusResponse, setup, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve_status(self, client: Geostorm) -> None:
        response = client.api.setup.with_raw_response.retrieve_status()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        setup = response.parse()
        assert_matches_type(SetupRetrieveStatusResponse, setup, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_status(self, client: Geostorm) -> None:
        with client.api.setup.with_streaming_response.retrieve_status() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            setup = response.parse()
            assert_matches_type(SetupRetrieveStatusResponse, setup, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncSetup:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_autofill(self, async_client: AsyncGeostorm) -> None:
        setup = await async_client.api.setup.autofill(
            input="x",
        )
        assert_matches_type(SetupAutofillResponse, setup, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_autofill(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.setup.with_raw_response.autofill(
            input="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        setup = await response.parse()
        assert_matches_type(SetupAutofillResponse, setup, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_autofill(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.setup.with_streaming_response.autofill(
            input="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            setup = await response.parse()
            assert_matches_type(SetupAutofillResponse, setup, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve_status(self, async_client: AsyncGeostorm) -> None:
        setup = await async_client.api.setup.retrieve_status()
        assert_matches_type(SetupRetrieveStatusResponse, setup, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_status(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.setup.with_raw_response.retrieve_status()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        setup = await response.parse()
        assert_matches_type(SetupRetrieveStatusResponse, setup, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_status(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.setup.with_streaming_response.retrieve_status() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            setup = await response.parse()
            assert_matches_type(SetupRetrieveStatusResponse, setup, path=["response"])

        assert cast(Any, response.is_closed) is True
