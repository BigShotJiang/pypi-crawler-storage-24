# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from geostorm import Geostorm, AsyncGeostorm
from tests.utils import assert_matches_type
from geostorm.types.api import SettingRetrieveModelsResponse, SettingRetrieveAPIKeyStatusResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSettings:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve_api_key_status(self, client: Geostorm) -> None:
        setting = client.api.settings.retrieve_api_key_status()
        assert_matches_type(SettingRetrieveAPIKeyStatusResponse, setting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve_api_key_status(self, client: Geostorm) -> None:
        response = client.api.settings.with_raw_response.retrieve_api_key_status()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        setting = response.parse()
        assert_matches_type(SettingRetrieveAPIKeyStatusResponse, setting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_api_key_status(self, client: Geostorm) -> None:
        with client.api.settings.with_streaming_response.retrieve_api_key_status() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            setting = response.parse()
            assert_matches_type(SettingRetrieveAPIKeyStatusResponse, setting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve_models(self, client: Geostorm) -> None:
        setting = client.api.settings.retrieve_models()
        assert_matches_type(SettingRetrieveModelsResponse, setting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve_models(self, client: Geostorm) -> None:
        response = client.api.settings.with_raw_response.retrieve_models()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        setting = response.parse()
        assert_matches_type(SettingRetrieveModelsResponse, setting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_models(self, client: Geostorm) -> None:
        with client.api.settings.with_streaming_response.retrieve_models() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            setting = response.parse()
            assert_matches_type(SettingRetrieveModelsResponse, setting, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncSettings:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve_api_key_status(self, async_client: AsyncGeostorm) -> None:
        setting = await async_client.api.settings.retrieve_api_key_status()
        assert_matches_type(SettingRetrieveAPIKeyStatusResponse, setting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_api_key_status(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.settings.with_raw_response.retrieve_api_key_status()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        setting = await response.parse()
        assert_matches_type(SettingRetrieveAPIKeyStatusResponse, setting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_api_key_status(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.settings.with_streaming_response.retrieve_api_key_status() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            setting = await response.parse()
            assert_matches_type(SettingRetrieveAPIKeyStatusResponse, setting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve_models(self, async_client: AsyncGeostorm) -> None:
        setting = await async_client.api.settings.retrieve_models()
        assert_matches_type(SettingRetrieveModelsResponse, setting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_models(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.settings.with_raw_response.retrieve_models()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        setting = await response.parse()
        assert_matches_type(SettingRetrieveModelsResponse, setting, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_models(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.settings.with_streaming_response.retrieve_models() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            setting = await response.parse()
            assert_matches_type(SettingRetrieveModelsResponse, setting, path=["response"])

        assert cast(Any, response.is_closed) is True
