# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from geostorm import Geostorm, AsyncGeostorm
from tests.utils import assert_matches_type
from geostorm.types.api.settings import APIKeyAPIKeyResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAPIKey:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_api_key(self, client: Geostorm) -> None:
        api_key = client.api.settings.api_key.api_key(
            key="x",
        )
        assert_matches_type(APIKeyAPIKeyResponse, api_key, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_api_key(self, client: Geostorm) -> None:
        response = client.api.settings.api_key.with_raw_response.api_key(
            key="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        api_key = response.parse()
        assert_matches_type(APIKeyAPIKeyResponse, api_key, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_api_key(self, client: Geostorm) -> None:
        with client.api.settings.api_key.with_streaming_response.api_key(
            key="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            api_key = response.parse()
            assert_matches_type(APIKeyAPIKeyResponse, api_key, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete_api_key(self, client: Geostorm) -> None:
        api_key = client.api.settings.api_key.delete_api_key()
        assert_matches_type(object, api_key, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete_api_key(self, client: Geostorm) -> None:
        response = client.api.settings.api_key.with_raw_response.delete_api_key()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        api_key = response.parse()
        assert_matches_type(object, api_key, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete_api_key(self, client: Geostorm) -> None:
        with client.api.settings.api_key.with_streaming_response.delete_api_key() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            api_key = response.parse()
            assert_matches_type(object, api_key, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncAPIKey:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_api_key(self, async_client: AsyncGeostorm) -> None:
        api_key = await async_client.api.settings.api_key.api_key(
            key="x",
        )
        assert_matches_type(APIKeyAPIKeyResponse, api_key, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_api_key(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.settings.api_key.with_raw_response.api_key(
            key="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        api_key = await response.parse()
        assert_matches_type(APIKeyAPIKeyResponse, api_key, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_api_key(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.settings.api_key.with_streaming_response.api_key(
            key="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            api_key = await response.parse()
            assert_matches_type(APIKeyAPIKeyResponse, api_key, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete_api_key(self, async_client: AsyncGeostorm) -> None:
        api_key = await async_client.api.settings.api_key.delete_api_key()
        assert_matches_type(object, api_key, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete_api_key(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.settings.api_key.with_raw_response.delete_api_key()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        api_key = await response.parse()
        assert_matches_type(object, api_key, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete_api_key(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.settings.api_key.with_streaming_response.delete_api_key() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            api_key = await response.parse()
            assert_matches_type(object, api_key, path=["response"])

        assert cast(Any, response.is_closed) is True
