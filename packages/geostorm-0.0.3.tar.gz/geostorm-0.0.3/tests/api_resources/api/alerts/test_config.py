# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from geostorm import Geostorm, AsyncGeostorm
from tests.utils import assert_matches_type
from geostorm.types.api.alerts import (
    ConfigListResponse,
    ConfigPatchAllResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestConfig:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Geostorm) -> None:
        config = client.api.alerts.config.list(
            project_id="project_id",
        )
        assert_matches_type(ConfigListResponse, config, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Geostorm) -> None:
        response = client.api.alerts.config.with_raw_response.list(
            project_id="project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        config = response.parse()
        assert_matches_type(ConfigListResponse, config, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Geostorm) -> None:
        with client.api.alerts.config.with_streaming_response.list(
            project_id="project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            config = response.parse()
            assert_matches_type(ConfigListResponse, config, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_patch_all(self, client: Geostorm) -> None:
        config = client.api.alerts.config.patch_all(
            project_id="project_id",
            configs=[
                {
                    "channel": "channel",
                    "endpoint": "endpoint",
                }
            ],
        )
        assert_matches_type(ConfigPatchAllResponse, config, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_patch_all(self, client: Geostorm) -> None:
        response = client.api.alerts.config.with_raw_response.patch_all(
            project_id="project_id",
            configs=[
                {
                    "channel": "channel",
                    "endpoint": "endpoint",
                }
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        config = response.parse()
        assert_matches_type(ConfigPatchAllResponse, config, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_patch_all(self, client: Geostorm) -> None:
        with client.api.alerts.config.with_streaming_response.patch_all(
            project_id="project_id",
            configs=[
                {
                    "channel": "channel",
                    "endpoint": "endpoint",
                }
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            config = response.parse()
            assert_matches_type(ConfigPatchAllResponse, config, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncConfig:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncGeostorm) -> None:
        config = await async_client.api.alerts.config.list(
            project_id="project_id",
        )
        assert_matches_type(ConfigListResponse, config, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.alerts.config.with_raw_response.list(
            project_id="project_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        config = await response.parse()
        assert_matches_type(ConfigListResponse, config, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.alerts.config.with_streaming_response.list(
            project_id="project_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            config = await response.parse()
            assert_matches_type(ConfigListResponse, config, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_patch_all(self, async_client: AsyncGeostorm) -> None:
        config = await async_client.api.alerts.config.patch_all(
            project_id="project_id",
            configs=[
                {
                    "channel": "channel",
                    "endpoint": "endpoint",
                }
            ],
        )
        assert_matches_type(ConfigPatchAllResponse, config, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_patch_all(self, async_client: AsyncGeostorm) -> None:
        response = await async_client.api.alerts.config.with_raw_response.patch_all(
            project_id="project_id",
            configs=[
                {
                    "channel": "channel",
                    "endpoint": "endpoint",
                }
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        config = await response.parse()
        assert_matches_type(ConfigPatchAllResponse, config, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_patch_all(self, async_client: AsyncGeostorm) -> None:
        async with async_client.api.alerts.config.with_streaming_response.patch_all(
            project_id="project_id",
            configs=[
                {
                    "channel": "channel",
                    "endpoint": "endpoint",
                }
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            config = await response.parse()
            assert_matches_type(ConfigPatchAllResponse, config, path=["response"])

        assert cast(Any, response.is_closed) is True
