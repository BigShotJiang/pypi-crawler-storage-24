# API

Types:

```python
from geostorm.types import APIRetrieveVersionResponse
```

Methods:

- <code title="get /api/version">client.api.<a href="./src/geostorm/resources/api/api.py">retrieve_version</a>() -> <a href="./src/geostorm/types/api_retrieve_version_response.py">APIRetrieveVersionResponse</a></code>

## Projects

Types:

```python
from geostorm.types.api import (
    Project,
    ProjectCreateResponse,
    ProjectRetrieveResponse,
    ProjectListResponse,
    ProjectMonitorResponse,
    ProjectRetrieveRunsResponse,
    ProjectRetrieveTrajectoryResponse,
)
```

Methods:

- <code title="post /api/projects">client.api.projects.<a href="./src/geostorm/resources/api/projects/projects.py">create</a>(\*\*<a href="src/geostorm/types/api/project_create_params.py">params</a>) -> <a href="./src/geostorm/types/api/project_create_response.py">ProjectCreateResponse</a></code>
- <code title="get /api/projects/{project_id}">client.api.projects.<a href="./src/geostorm/resources/api/projects/projects.py">retrieve</a>(project_id) -> <a href="./src/geostorm/types/api/project_retrieve_response.py">ProjectRetrieveResponse</a></code>
- <code title="patch /api/projects/{project_id}">client.api.projects.<a href="./src/geostorm/resources/api/projects/projects.py">update</a>(project_id, \*\*<a href="src/geostorm/types/api/project_update_params.py">params</a>) -> <a href="./src/geostorm/types/api/project.py">Project</a></code>
- <code title="get /api/projects">client.api.projects.<a href="./src/geostorm/resources/api/projects/projects.py">list</a>() -> <a href="./src/geostorm/types/api/project_list_response.py">ProjectListResponse</a></code>
- <code title="delete /api/projects/{project_id}">client.api.projects.<a href="./src/geostorm/resources/api/projects/projects.py">delete</a>(project_id) -> object</code>
- <code title="post /api/projects/{project_id}/monitor">client.api.projects.<a href="./src/geostorm/resources/api/projects/projects.py">monitor</a>(project_id) -> <a href="./src/geostorm/types/api/project_monitor_response.py">ProjectMonitorResponse</a></code>
- <code title="get /api/projects/{project_id}/runs">client.api.projects.<a href="./src/geostorm/resources/api/projects/projects.py">retrieve_runs</a>(project_id, \*\*<a href="src/geostorm/types/api/project_retrieve_runs_params.py">params</a>) -> <a href="./src/geostorm/types/api/project_retrieve_runs_response.py">ProjectRetrieveRunsResponse</a></code>
- <code title="get /api/projects/{project_id}/trajectory">client.api.projects.<a href="./src/geostorm/resources/api/projects/projects.py">retrieve_trajectory</a>(project_id, \*\*<a href="src/geostorm/types/api/project_retrieve_trajectory_params.py">params</a>) -> <a href="./src/geostorm/types/api/project_retrieve_trajectory_response.py">ProjectRetrieveTrajectoryResponse</a></code>

### Brand

Types:

```python
from geostorm.types.api.projects import Brand
```

Methods:

- <code title="put /api/projects/{project_id}/brand">client.api.projects.brand.<a href="./src/geostorm/resources/api/projects/brand.py">create</a>(project_id, \*\*<a href="src/geostorm/types/api/projects/brand_create_params.py">params</a>) -> <a href="./src/geostorm/types/api/projects/brand.py">Brand</a></code>
- <code title="get /api/projects/{project_id}/brand">client.api.projects.brand.<a href="./src/geostorm/resources/api/projects/brand.py">list</a>(project_id) -> <a href="./src/geostorm/types/api/projects/brand.py">Brand</a></code>

### Competitors

Types:

```python
from geostorm.types.api.projects import Competitor, CompetitorListResponse
```

Methods:

- <code title="post /api/projects/{project_id}/competitors">client.api.projects.competitors.<a href="./src/geostorm/resources/api/projects/competitors.py">create</a>(project_id, \*\*<a href="src/geostorm/types/api/projects/competitor_create_params.py">params</a>) -> <a href="./src/geostorm/types/api/projects/competitor.py">Competitor</a></code>
- <code title="get /api/projects/{project_id}/competitors">client.api.projects.competitors.<a href="./src/geostorm/resources/api/projects/competitors.py">list</a>(project_id) -> <a href="./src/geostorm/types/api/projects/competitor_list_response.py">CompetitorListResponse</a></code>
- <code title="delete /api/projects/{project_id}/competitors/{competitor_id}">client.api.projects.competitors.<a href="./src/geostorm/resources/api/projects/competitors.py">delete</a>(competitor_id, \*, project_id) -> object</code>

### Terms

Types:

```python
from geostorm.types.api.projects import Term, TermListResponse
```

Methods:

- <code title="post /api/projects/{project_id}/terms">client.api.projects.terms.<a href="./src/geostorm/resources/api/projects/terms.py">create</a>(project_id, \*\*<a href="src/geostorm/types/api/projects/term_create_params.py">params</a>) -> <a href="./src/geostorm/types/api/projects/term.py">Term</a></code>
- <code title="get /api/projects/{project_id}/terms">client.api.projects.terms.<a href="./src/geostorm/resources/api/projects/terms.py">list</a>(project_id) -> <a href="./src/geostorm/types/api/projects/term_list_response.py">TermListResponse</a></code>
- <code title="delete /api/projects/{project_id}/terms/{term_id}">client.api.projects.terms.<a href="./src/geostorm/resources/api/projects/terms.py">delete</a>(term_id, \*, project_id) -> object</code>

### Schedule

Types:

```python
from geostorm.types.api.projects import Schedule
```

Methods:

- <code title="get /api/projects/{project_id}/schedule">client.api.projects.schedule.<a href="./src/geostorm/resources/api/projects/schedule.py">list</a>(project_id) -> <a href="./src/geostorm/types/api/projects/schedule.py">Schedule</a></code>
- <code title="patch /api/projects/{project_id}/schedule">client.api.projects.schedule.<a href="./src/geostorm/resources/api/projects/schedule.py">patch_all</a>(project_id, \*\*<a href="src/geostorm/types/api/projects/schedule_patch_all_params.py">params</a>) -> <a href="./src/geostorm/types/api/projects/schedule.py">Schedule</a></code>

### Perception

Types:

```python
from geostorm.types.api.projects import (
    TrendDirection,
    PerceptionListResponse,
    PerceptionRetrieveBreakdownResponse,
)
```

Methods:

- <code title="get /api/projects/{project_id}/perception">client.api.projects.perception.<a href="./src/geostorm/resources/api/projects/perception.py">list</a>(project_id, \*\*<a href="src/geostorm/types/api/projects/perception_list_params.py">params</a>) -> <a href="./src/geostorm/types/api/projects/perception_list_response.py">PerceptionListResponse</a></code>
- <code title="get /api/projects/{project_id}/perception/breakdown">client.api.projects.perception.<a href="./src/geostorm/resources/api/projects/perception.py">retrieve_breakdown</a>(project_id) -> <a href="./src/geostorm/types/api/projects/perception_retrieve_breakdown_response.py">PerceptionRetrieveBreakdownResponse</a></code>

### Providers

Types:

```python
from geostorm.types.api.projects import LlmProvider, ProviderListResponse
```

Methods:

- <code title="post /api/projects/{project_id}/providers">client.api.projects.providers.<a href="./src/geostorm/resources/api/projects/providers.py">create</a>(project_id, \*\*<a href="src/geostorm/types/api/projects/provider_create_params.py">params</a>) -> <a href="./src/geostorm/types/api/projects/llm_provider.py">LlmProvider</a></code>
- <code title="patch /api/projects/{project_id}/providers/{provider_id}">client.api.projects.providers.<a href="./src/geostorm/resources/api/projects/providers.py">update</a>(provider_id, \*, project_id, \*\*<a href="src/geostorm/types/api/projects/provider_update_params.py">params</a>) -> <a href="./src/geostorm/types/api/projects/llm_provider.py">LlmProvider</a></code>
- <code title="get /api/projects/{project_id}/providers">client.api.projects.providers.<a href="./src/geostorm/resources/api/projects/providers.py">list</a>(project_id) -> <a href="./src/geostorm/types/api/projects/provider_list_response.py">ProviderListResponse</a></code>
- <code title="delete /api/projects/{project_id}/providers/{provider_id}">client.api.projects.providers.<a href="./src/geostorm/resources/api/projects/providers.py">delete</a>(provider_id, \*, project_id) -> object</code>

## Alerts

Types:

```python
from geostorm.types.api import AlertSeverity, AlertListResponse, AlertAcknowledgeResponse
```

Methods:

- <code title="get /api/alerts">client.api.alerts.<a href="./src/geostorm/resources/api/alerts/alerts.py">list</a>(\*\*<a href="src/geostorm/types/api/alert_list_params.py">params</a>) -> <a href="./src/geostorm/types/api/alert_list_response.py">AlertListResponse</a></code>
- <code title="post /api/alerts/{alert_id}/acknowledge">client.api.alerts.<a href="./src/geostorm/resources/api/alerts/alerts.py">acknowledge</a>(alert_id) -> <a href="./src/geostorm/types/api/alert_acknowledge_response.py">AlertAcknowledgeResponse</a></code>

### Config

Types:

```python
from geostorm.types.api.alerts import (
    AlertConfig,
    AlertType,
    ConfigListResponse,
    ConfigPatchAllResponse,
)
```

Methods:

- <code title="get /api/alerts/config">client.api.alerts.config.<a href="./src/geostorm/resources/api/alerts/config.py">list</a>(\*\*<a href="src/geostorm/types/api/alerts/config_list_params.py">params</a>) -> <a href="./src/geostorm/types/api/alerts/config_list_response.py">ConfigListResponse</a></code>
- <code title="patch /api/alerts/config">client.api.alerts.config.<a href="./src/geostorm/resources/api/alerts/config.py">patch_all</a>(\*\*<a href="src/geostorm/types/api/alerts/config_patch_all_params.py">params</a>) -> <a href="./src/geostorm/types/api/alerts/config_patch_all_response.py">ConfigPatchAllResponse</a></code>

## Runs

Types:

```python
from geostorm.types.api import (
    RunStatus,
    TriggerType,
    RunRetrieveResponse,
    RunRetrieveResponsesResponse,
)
```

Methods:

- <code title="get /api/runs/{run_id}">client.api.runs.<a href="./src/geostorm/resources/api/runs.py">retrieve</a>(run_id) -> <a href="./src/geostorm/types/api/run_retrieve_response.py">RunRetrieveResponse</a></code>
- <code title="get /api/runs/{run_id}/progress">client.api.runs.<a href="./src/geostorm/resources/api/runs.py">retrieve_progress</a>(run_id) -> object</code>
- <code title="get /api/runs/{run_id}/responses">client.api.runs.<a href="./src/geostorm/resources/api/runs.py">retrieve_responses</a>(run_id, \*\*<a href="src/geostorm/types/api/run_retrieve_responses_params.py">params</a>) -> <a href="./src/geostorm/types/api/run_retrieve_responses_response.py">RunRetrieveResponsesResponse</a></code>

## Setup

Types:

```python
from geostorm.types.api import SetupAutofillResponse, SetupRetrieveStatusResponse
```

Methods:

- <code title="post /api/setup/autofill">client.api.setup.<a href="./src/geostorm/resources/api/setup.py">autofill</a>(\*\*<a href="src/geostorm/types/api/setup_autofill_params.py">params</a>) -> <a href="./src/geostorm/types/api/setup_autofill_response.py">SetupAutofillResponse</a></code>
- <code title="get /api/setup/status">client.api.setup.<a href="./src/geostorm/resources/api/setup.py">retrieve_status</a>() -> <a href="./src/geostorm/types/api/setup_retrieve_status_response.py">SetupRetrieveStatusResponse</a></code>

## Settings

Types:

```python
from geostorm.types.api import SettingRetrieveAPIKeyStatusResponse, SettingRetrieveModelsResponse
```

Methods:

- <code title="get /api/settings/api-key-status">client.api.settings.<a href="./src/geostorm/resources/api/settings/settings.py">retrieve_api_key_status</a>() -> <a href="./src/geostorm/types/api/setting_retrieve_api_key_status_response.py">SettingRetrieveAPIKeyStatusResponse</a></code>
- <code title="get /api/settings/models">client.api.settings.<a href="./src/geostorm/resources/api/settings/settings.py">retrieve_models</a>() -> <a href="./src/geostorm/types/api/setting_retrieve_models_response.py">SettingRetrieveModelsResponse</a></code>

### APIKey

Types:

```python
from geostorm.types.api.settings import APIKeyAPIKeyResponse
```

Methods:

- <code title="post /api/settings/api-key">client.api.settings.api_key.<a href="./src/geostorm/resources/api/settings/api_key.py">api_key</a>(\*\*<a href="src/geostorm/types/api/settings/api_key_api_key_params.py">params</a>) -> <a href="./src/geostorm/types/api/settings/api_key_api_key_response.py">APIKeyAPIKeyResponse</a></code>
- <code title="delete /api/settings/api-key">client.api.settings.api_key.<a href="./src/geostorm/resources/api/settings/api_key.py">delete_api_key</a>() -> object</code>

# Health

Types:

```python
from geostorm.types import HealthCheckResponse
```

Methods:

- <code title="get /health">client.health.<a href="./src/geostorm/resources/health.py">check</a>() -> <a href="./src/geostorm/types/health_check_response.py">HealthCheckResponse</a></code>
