# Changelog

## 0.0.3 (2026-03-21)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/geostorm-ai/geostorm-python/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([7700460](https://github.com/geostorm-ai/geostorm-python/commit/770046011d2642ce66ee4e68ccddad76e1c9c066))

## 0.0.2 (2026-03-21)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/geostorm-ai/geostorm-python/compare/v0.0.1...v0.0.2)

### Bug Fixes

* **deps:** bump minimum typing-extensions version ([18c93da](https://github.com/geostorm-ai/geostorm-python/commit/18c93dab5a918ea4c50d80bea057bac7547af50b))
* **pydantic:** do not pass `by_alias` unless set ([38d53d6](https://github.com/geostorm-ai/geostorm-python/commit/38d53d66e8150a8384a9c2eb06ab1d004cfa4a48))
* sanitize endpoint path params ([b60cd9c](https://github.com/geostorm-ai/geostorm-python/commit/b60cd9cd9480b9dc53d479be235d9caa11e82943))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([bc86015](https://github.com/geostorm-ai/geostorm-python/commit/bc8601527a1479973743bd12d3f4c4ee5f6eba11))
* **internal:** refactor authentication internals ([dba2697](https://github.com/geostorm-ai/geostorm-python/commit/dba2697b33ce9762a189f9359a1de5eee8bee6d0))
* **internal:** tweak CI branches ([9e36151](https://github.com/geostorm-ai/geostorm-python/commit/9e36151988b216292b3ce755dbe7d534ac3f532a))
* update SDK settings ([a566332](https://github.com/geostorm-ai/geostorm-python/commit/a56633210728363b81fcf9f383a090e2ea70199a))
* update SDK settings ([9b0390a](https://github.com/geostorm-ai/geostorm-python/commit/9b0390a2c64100bbe547077e2787117caa698a27))
* update SDK settings ([430e174](https://github.com/geostorm-ai/geostorm-python/commit/430e1746ae2c149f3980ea65b3d16aba183dc7fb))
* update SDK settings ([3bffd0d](https://github.com/geostorm-ai/geostorm-python/commit/3bffd0d742c9735cd0ec82fcab5c10c8e3419890))
