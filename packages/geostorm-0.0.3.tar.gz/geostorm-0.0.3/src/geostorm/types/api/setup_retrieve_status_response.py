# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["SetupRetrieveStatusResponse"]


class SetupRetrieveStatusResponse(BaseModel):
    """Setup status check."""

    has_api_key: Optional[bool] = None

    has_projects: Optional[bool] = None

    project_count: Optional[int] = None
