# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ..._models import BaseModel
from .run_status import RunStatus
from .trigger_type import TriggerType

__all__ = ["ProjectRetrieveRunsResponse", "Item"]


class Item(BaseModel):
    """Run summary."""

    id: str

    created_at: datetime

    project_id: str

    status: RunStatus
    """Status of a monitoring run."""

    trigger_type: TriggerType
    """How a run was triggered."""

    completed_at: Optional[datetime] = None

    completed_queries: Optional[int] = None

    failed_queries: Optional[int] = None

    started_at: Optional[datetime] = None

    total_queries: Optional[int] = None

    triggered_by: Optional[str] = None


class ProjectRetrieveRunsResponse(BaseModel):
    items: List[Item]

    limit: int

    offset: int

    total: int
