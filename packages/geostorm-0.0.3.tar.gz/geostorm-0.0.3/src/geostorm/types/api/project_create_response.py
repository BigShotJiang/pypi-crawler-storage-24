# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ..._models import BaseModel

__all__ = ["ProjectCreateResponse"]


class ProjectCreateResponse(BaseModel):
    """Response after creating a project."""

    id: str

    brand_id: str

    created_at: datetime

    name: str

    schedule_id: str

    providers_count: Optional[int] = None
