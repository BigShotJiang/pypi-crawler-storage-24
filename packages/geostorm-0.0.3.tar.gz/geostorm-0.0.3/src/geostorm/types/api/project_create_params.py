# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

from ..._types import SequenceNotStr

__all__ = ["ProjectCreateParams"]


class ProjectCreateParams(TypedDict, total=False):
    name: Required[str]

    brand_aliases: SequenceNotStr[str]

    brand_description: Optional[str]

    brand_name: Optional[str]

    brand_website: Optional[str]

    description: Optional[str]
