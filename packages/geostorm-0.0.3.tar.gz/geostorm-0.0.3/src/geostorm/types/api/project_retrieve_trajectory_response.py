# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from ..._models import BaseModel
from .projects.trend_direction import TrendDirection

__all__ = ["ProjectRetrieveTrajectoryResponse", "Data"]


class Data(BaseModel):
    """Single data point in trajectory time-series."""

    date: str

    competitor_delta: Optional[float] = None

    position_avg: Optional[float] = None

    recommendation_share: Optional[float] = None

    trend_direction: Optional[TrendDirection] = None
    """Trend direction indicators."""


class ProjectRetrieveTrajectoryResponse(BaseModel):
    """Historical trajectory data for a project."""

    project_id: str

    data: Optional[List[Data]] = None
