# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

from ...._types import SequenceNotStr

__all__ = ["BrandCreateParams"]


class BrandCreateParams(TypedDict, total=False):
    aliases: Optional[SequenceNotStr[str]]

    description: Optional[str]

    name: Optional[str]

    website: Optional[str]
