# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import TypedDict

__all__ = ["PerceptionListParams"]


class PerceptionListParams(TypedDict, total=False):
    end_date: Optional[str]

    start_date: Optional[str]
