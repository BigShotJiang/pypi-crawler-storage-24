# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ...._models import BaseModel

__all__ = ["Competitor"]


class Competitor(BaseModel):
    """Competitor detail."""

    id: str

    created_at: datetime

    name: str

    project_id: str

    updated_at: datetime

    aliases: Optional[List[str]] = None

    is_active: Optional[bool] = None

    website: Optional[str] = None
