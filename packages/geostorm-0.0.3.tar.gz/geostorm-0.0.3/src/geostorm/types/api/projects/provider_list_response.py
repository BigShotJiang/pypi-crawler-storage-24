# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .llm_provider import LlmProvider

__all__ = ["ProviderListResponse"]

ProviderListResponse: TypeAlias = List[LlmProvider]
