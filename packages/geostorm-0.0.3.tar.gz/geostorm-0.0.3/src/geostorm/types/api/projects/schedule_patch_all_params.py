# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional
from typing_extensions import TypedDict

__all__ = ["SchedulePatchAllParams"]


class SchedulePatchAllParams(TypedDict, total=False):
    days_of_week: Optional[Iterable[int]]

    hour_of_day: Optional[int]

    is_active: Optional[bool]
