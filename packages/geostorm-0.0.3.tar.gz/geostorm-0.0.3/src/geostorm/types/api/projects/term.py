# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ...._models import BaseModel

__all__ = ["Term"]


class Term(BaseModel):
    """Term detail."""

    id: str

    created_at: datetime

    name: str

    project_id: str

    updated_at: datetime

    description: Optional[str] = None

    is_active: Optional[bool] = None
