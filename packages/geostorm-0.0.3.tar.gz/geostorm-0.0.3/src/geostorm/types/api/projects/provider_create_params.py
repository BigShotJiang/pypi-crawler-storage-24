# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ProviderCreateParams"]


class ProviderCreateParams(TypedDict, total=False):
    model_name: Required[str]

    provider_name: Required[str]
