# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .term import Term

__all__ = ["TermListResponse"]

TermListResponse: TypeAlias = List[Term]
