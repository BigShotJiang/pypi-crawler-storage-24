# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from ...._models import BaseModel

__all__ = ["PerceptionRetrieveBreakdownResponse", "ByProvider", "ByTerm"]


class ByProvider(BaseModel):
    """Per-provider breakdown in perception data."""

    provider_name: str

    recommendation_share: float

    position_avg: Optional[float] = None


class ByTerm(BaseModel):
    """Per-term breakdown in perception data."""

    recommendation_share: float

    term_id: str

    term_name: str

    position_avg: Optional[float] = None


class PerceptionRetrieveBreakdownResponse(BaseModel):
    """Perception breakdown with per-term and per-provider aggregated scores."""

    project_id: str

    brand_mentions: Optional[int] = None

    by_provider: Optional[List[ByProvider]] = None

    by_term: Optional[List[ByTerm]] = None

    ranked_responses: Optional[int] = None

    total_responses: Optional[int] = None
