# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["TrendDirection"]

TrendDirection: TypeAlias = Literal["up", "down", "stable"]
