# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ...._models import BaseModel

__all__ = ["Schedule"]


class Schedule(BaseModel):
    """Schedule detail."""

    id: str

    created_at: datetime

    days_of_week: List[int]

    hour_of_day: int

    project_id: str

    updated_at: datetime

    is_active: Optional[bool] = None

    last_run_at: Optional[datetime] = None

    next_run_at: Optional[datetime] = None
