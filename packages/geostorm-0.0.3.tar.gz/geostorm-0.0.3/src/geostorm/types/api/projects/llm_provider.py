# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from ...._models import BaseModel

__all__ = ["LlmProvider"]


class LlmProvider(BaseModel):
    """LLM provider detail."""

    id: str

    created_at: datetime

    api_model_name: str = FieldInfo(alias="model_name")

    project_id: str

    provider_name: str

    updated_at: datetime

    is_enabled: Optional[bool] = None
