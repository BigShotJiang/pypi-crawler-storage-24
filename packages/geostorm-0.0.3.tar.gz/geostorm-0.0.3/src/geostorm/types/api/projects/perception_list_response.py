# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from ...._models import BaseModel
from .trend_direction import TrendDirection

__all__ = ["PerceptionListResponse", "Data"]


class Data(BaseModel):
    """Single data point in perception time-series."""

    date: str

    competitor_delta: Optional[float] = None

    overall_score: Optional[float] = None

    position_avg: Optional[float] = None

    recommendation_share: Optional[float] = None

    trend_direction: Optional[TrendDirection] = None
    """Trend direction indicators."""


class PerceptionListResponse(BaseModel):
    """Perception time-series data."""

    project_id: str

    data: Optional[List[Data]] = None
