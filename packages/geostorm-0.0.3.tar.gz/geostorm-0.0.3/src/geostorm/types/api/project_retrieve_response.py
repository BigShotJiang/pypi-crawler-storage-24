# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ..._models import BaseModel
from .projects.term import Term
from .projects.brand import Brand
from .projects.schedule import Schedule
from .projects.competitor import Competitor

__all__ = ["ProjectRetrieveResponse"]


class ProjectRetrieveResponse(BaseModel):
    """Full project detail with related entities."""

    id: str

    created_at: datetime

    name: str

    updated_at: datetime

    brand: Optional[Brand] = None
    """Brand detail."""

    competitors: Optional[List[Competitor]] = None

    description: Optional[str] = None

    is_demo: Optional[bool] = None

    run_count: Optional[int] = None

    schedule: Optional[Schedule] = None
    """Schedule detail."""

    terms: Optional[List[Term]] = None
