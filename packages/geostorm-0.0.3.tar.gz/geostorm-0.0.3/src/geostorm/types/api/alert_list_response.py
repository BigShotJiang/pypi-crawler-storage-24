# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ..._models import BaseModel
from .alert_severity import AlertSeverity
from .alerts.alert_type import AlertType

__all__ = ["AlertListResponse", "Item"]


class Item(BaseModel):
    """Alert detail."""

    id: str

    alert_type: AlertType
    """Types of alerts the system can generate."""

    created_at: datetime

    message: str

    project_id: str

    severity: AlertSeverity
    """Severity levels for alerts."""

    title: str

    acknowledged_at: Optional[datetime] = None

    acknowledged_by: Optional[str] = None

    explanation: Optional[str] = None

    is_acknowledged: Optional[bool] = None


class AlertListResponse(BaseModel):
    items: List[Item]

    limit: int

    offset: int

    total: int
