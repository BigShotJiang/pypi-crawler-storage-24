# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

from .alert_severity import AlertSeverity

__all__ = ["AlertListParams"]


class AlertListParams(TypedDict, total=False):
    project_id: Required[str]

    acknowledged: Optional[bool]

    limit: int

    offset: int

    severity: Optional[AlertSeverity]
    """Severity levels for alerts."""
