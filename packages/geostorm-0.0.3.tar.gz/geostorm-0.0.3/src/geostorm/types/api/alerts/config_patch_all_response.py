# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .alert_config import AlertConfig

__all__ = ["ConfigPatchAllResponse"]

ConfigPatchAllResponse: TypeAlias = List[AlertConfig]
