# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["AlertType"]

AlertType: TypeAlias = Literal[
    "competitor_emergence",
    "configuration_error",
    "disappearance",
    "recommendation_share_drop",
    "position_degradation",
    "model_divergence",
    "citation_domain_shift",
]
