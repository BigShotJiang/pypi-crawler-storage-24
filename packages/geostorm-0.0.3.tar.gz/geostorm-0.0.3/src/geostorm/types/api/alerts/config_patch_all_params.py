# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Iterable
from typing_extensions import Required, TypedDict

from .alert_type import AlertType
from ..alert_severity import AlertSeverity

__all__ = ["ConfigPatchAllParams", "Config"]


class ConfigPatchAllParams(TypedDict, total=False):
    project_id: Required[str]

    configs: Required[Iterable[Config]]


class Config(TypedDict, total=False):
    """Alert configuration item for request/response."""

    channel: Required[str]

    endpoint: Required[str]

    alert_types: List[AlertType]

    is_enabled: bool

    min_severity: AlertSeverity
    """Severity levels for alerts."""
