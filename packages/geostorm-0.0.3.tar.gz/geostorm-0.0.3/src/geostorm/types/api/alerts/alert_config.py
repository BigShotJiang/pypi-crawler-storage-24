# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ...._models import BaseModel
from .alert_type import AlertType
from ..alert_severity import AlertSeverity

__all__ = ["AlertConfig"]


class AlertConfig(BaseModel):
    """Alert configuration detail."""

    id: str

    channel: str

    created_at: datetime

    endpoint: str

    project_id: str

    updated_at: datetime

    alert_types: Optional[List[AlertType]] = None

    is_enabled: Optional[bool] = None

    min_severity: Optional[AlertSeverity] = None
    """Severity levels for alerts."""
