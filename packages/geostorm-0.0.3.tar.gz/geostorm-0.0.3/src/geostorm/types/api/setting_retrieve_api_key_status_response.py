# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["SettingRetrieveAPIKeyStatusResponse"]


class SettingRetrieveAPIKeyStatusResponse(BaseModel):
    """API key status."""

    configured: Optional[bool] = None

    source: Optional[str] = None
