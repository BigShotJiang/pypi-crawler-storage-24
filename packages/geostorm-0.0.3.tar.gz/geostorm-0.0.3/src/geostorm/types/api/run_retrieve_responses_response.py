# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["RunRetrieveResponsesResponse", "Item", "ItemMention"]


class ItemMention(BaseModel):
    """Mention within a response."""

    id: str

    mention_type: Literal["brand", "competitor"]
    """Type of mention detected in a response."""

    target_name: str

    context_after: Optional[str] = None

    context_before: Optional[str] = None

    list_position: Optional[int] = None

    position_chars: Optional[int] = None

    position_words: Optional[int] = None


class Item(BaseModel):
    """Response with nested mentions."""

    id: str

    created_at: datetime

    api_model_name: str = FieldInfo(alias="model_name")

    provider_name: str

    response_text: str

    run_id: str

    term_id: str

    term_name: str

    cost_usd: Optional[float] = None

    error_message: Optional[str] = None

    latency_ms: Optional[int] = None

    mentions: Optional[List[ItemMention]] = None


class RunRetrieveResponsesResponse(BaseModel):
    items: List[Item]

    limit: int

    offset: int

    total: int
