# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, TypedDict

__all__ = ["ProjectRetrieveTrajectoryParams"]


class ProjectRetrieveTrajectoryParams(TypedDict, total=False):
    end_date: Optional[str]

    period: Literal["daily", "weekly", "monthly"]

    start_date: Optional[str]
