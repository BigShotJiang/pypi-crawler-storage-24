# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from ..._models import BaseModel

__all__ = ["SetupAutofillResponse"]


class SetupAutofillResponse(BaseModel):
    """AI-generated project details."""

    brand_name: str

    description: str

    project_name: str

    brand_aliases: Optional[List[str]] = None

    competitors: Optional[List[str]] = None

    monitoring_terms: Optional[List[str]] = None
