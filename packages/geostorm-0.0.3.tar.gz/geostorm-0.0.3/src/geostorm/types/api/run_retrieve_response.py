# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from ..._models import BaseModel
from .run_status import RunStatus
from .trigger_type import TriggerType

__all__ = ["RunRetrieveResponse"]


class RunRetrieveResponse(BaseModel):
    """Run detail with perception data."""

    id: str

    created_at: datetime

    project_id: str

    status: RunStatus
    """Status of a monitoring run."""

    trigger_type: TriggerType
    """How a run was triggered."""

    competitors_detected: Optional[List[str]] = None

    completed_at: Optional[datetime] = None

    completed_queries: Optional[int] = None

    failed_queries: Optional[int] = None

    perception_score: Optional[float] = None

    recommendation_share: Optional[float] = None

    started_at: Optional[datetime] = None

    total_queries: Optional[int] = None

    triggered_by: Optional[str] = None
