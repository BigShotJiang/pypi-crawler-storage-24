# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ..._models import BaseModel

__all__ = ["Project"]


class Project(BaseModel):
    """Project summary."""

    id: str

    created_at: datetime

    name: str

    updated_at: datetime

    active_alert_count: Optional[int] = None

    description: Optional[str] = None

    is_demo: Optional[bool] = None

    latest_score: Optional[float] = None

    run_count: Optional[int] = None
