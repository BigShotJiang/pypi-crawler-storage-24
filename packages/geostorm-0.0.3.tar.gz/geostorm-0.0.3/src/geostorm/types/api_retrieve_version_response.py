# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel

__all__ = ["APIRetrieveVersionResponse"]


class APIRetrieveVersionResponse(BaseModel):
    """Version info response."""

    build_time: Optional[str] = None

    version: str
