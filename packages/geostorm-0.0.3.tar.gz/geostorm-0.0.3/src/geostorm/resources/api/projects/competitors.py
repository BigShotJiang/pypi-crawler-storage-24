# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.api.projects import competitor_create_params
from ....types.api.projects.competitor import Competitor
from ....types.api.projects.competitor_list_response import CompetitorListResponse

__all__ = ["CompetitorsResource", "AsyncCompetitorsResource"]


class CompetitorsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> CompetitorsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#accessing-raw-response-data-eg-headers
        """
        return CompetitorsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CompetitorsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#with_streaming_response
        """
        return CompetitorsResourceWithStreamingResponse(self)

    def create(
        self,
        project_id: str,
        *,
        name: str,
        aliases: SequenceNotStr[str] | Omit = omit,
        website: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Competitor:
        """
        Create Competitor

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        return self._post(
            path_template("/api/projects/{project_id}/competitors", project_id=project_id),
            body=maybe_transform(
                {
                    "name": name,
                    "aliases": aliases,
                    "website": website,
                },
                competitor_create_params.CompetitorCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Competitor,
        )

    def list(
        self,
        project_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompetitorListResponse:
        """
        List Competitors

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        return self._get(
            path_template("/api/projects/{project_id}/competitors", project_id=project_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CompetitorListResponse,
        )

    def delete(
        self,
        competitor_id: str,
        *,
        project_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Delete Competitor

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        if not competitor_id:
            raise ValueError(f"Expected a non-empty value for `competitor_id` but received {competitor_id!r}")
        return self._delete(
            path_template(
                "/api/projects/{project_id}/competitors/{competitor_id}",
                project_id=project_id,
                competitor_id=competitor_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class AsyncCompetitorsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncCompetitorsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#accessing-raw-response-data-eg-headers
        """
        return AsyncCompetitorsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCompetitorsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#with_streaming_response
        """
        return AsyncCompetitorsResourceWithStreamingResponse(self)

    async def create(
        self,
        project_id: str,
        *,
        name: str,
        aliases: SequenceNotStr[str] | Omit = omit,
        website: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Competitor:
        """
        Create Competitor

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        return await self._post(
            path_template("/api/projects/{project_id}/competitors", project_id=project_id),
            body=await async_maybe_transform(
                {
                    "name": name,
                    "aliases": aliases,
                    "website": website,
                },
                competitor_create_params.CompetitorCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Competitor,
        )

    async def list(
        self,
        project_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompetitorListResponse:
        """
        List Competitors

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        return await self._get(
            path_template("/api/projects/{project_id}/competitors", project_id=project_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CompetitorListResponse,
        )

    async def delete(
        self,
        competitor_id: str,
        *,
        project_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Delete Competitor

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        if not competitor_id:
            raise ValueError(f"Expected a non-empty value for `competitor_id` but received {competitor_id!r}")
        return await self._delete(
            path_template(
                "/api/projects/{project_id}/competitors/{competitor_id}",
                project_id=project_id,
                competitor_id=competitor_id,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class CompetitorsResourceWithRawResponse:
    def __init__(self, competitors: CompetitorsResource) -> None:
        self._competitors = competitors

        self.create = to_raw_response_wrapper(
            competitors.create,
        )
        self.list = to_raw_response_wrapper(
            competitors.list,
        )
        self.delete = to_raw_response_wrapper(
            competitors.delete,
        )


class AsyncCompetitorsResourceWithRawResponse:
    def __init__(self, competitors: AsyncCompetitorsResource) -> None:
        self._competitors = competitors

        self.create = async_to_raw_response_wrapper(
            competitors.create,
        )
        self.list = async_to_raw_response_wrapper(
            competitors.list,
        )
        self.delete = async_to_raw_response_wrapper(
            competitors.delete,
        )


class CompetitorsResourceWithStreamingResponse:
    def __init__(self, competitors: CompetitorsResource) -> None:
        self._competitors = competitors

        self.create = to_streamed_response_wrapper(
            competitors.create,
        )
        self.list = to_streamed_response_wrapper(
            competitors.list,
        )
        self.delete = to_streamed_response_wrapper(
            competitors.delete,
        )


class AsyncCompetitorsResourceWithStreamingResponse:
    def __init__(self, competitors: AsyncCompetitorsResource) -> None:
        self._competitors = competitors

        self.create = async_to_streamed_response_wrapper(
            competitors.create,
        )
        self.list = async_to_streamed_response_wrapper(
            competitors.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            competitors.delete,
        )
