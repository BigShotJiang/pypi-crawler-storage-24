# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ...._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ...._utils import path_template, maybe_transform, async_maybe_transform
from ...._compat import cached_property
from ...._resource import SyncAPIResource, AsyncAPIResource
from ...._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...._base_client import make_request_options
from ....types.api.projects import perception_list_params
from ....types.api.projects.perception_list_response import PerceptionListResponse
from ....types.api.projects.perception_retrieve_breakdown_response import PerceptionRetrieveBreakdownResponse

__all__ = ["PerceptionResource", "AsyncPerceptionResource"]


class PerceptionResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PerceptionResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#accessing-raw-response-data-eg-headers
        """
        return PerceptionResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PerceptionResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#with_streaming_response
        """
        return PerceptionResourceWithStreamingResponse(self)

    def list(
        self,
        project_id: str,
        *,
        end_date: Optional[str] | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PerceptionListResponse:
        """
        Time-series perception data for a project.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        return self._get(
            path_template("/api/projects/{project_id}/perception", project_id=project_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "start_date": start_date,
                    },
                    perception_list_params.PerceptionListParams,
                ),
            ),
            cast_to=PerceptionListResponse,
        )

    def retrieve_breakdown(
        self,
        project_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PerceptionRetrieveBreakdownResponse:
        """
        Per-term and per-provider perception breakdown from the latest scoring period.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        return self._get(
            path_template("/api/projects/{project_id}/perception/breakdown", project_id=project_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PerceptionRetrieveBreakdownResponse,
        )


class AsyncPerceptionResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPerceptionResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#accessing-raw-response-data-eg-headers
        """
        return AsyncPerceptionResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPerceptionResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#with_streaming_response
        """
        return AsyncPerceptionResourceWithStreamingResponse(self)

    async def list(
        self,
        project_id: str,
        *,
        end_date: Optional[str] | Omit = omit,
        start_date: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PerceptionListResponse:
        """
        Time-series perception data for a project.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        return await self._get(
            path_template("/api/projects/{project_id}/perception", project_id=project_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "start_date": start_date,
                    },
                    perception_list_params.PerceptionListParams,
                ),
            ),
            cast_to=PerceptionListResponse,
        )

    async def retrieve_breakdown(
        self,
        project_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PerceptionRetrieveBreakdownResponse:
        """
        Per-term and per-provider perception breakdown from the latest scoring period.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not project_id:
            raise ValueError(f"Expected a non-empty value for `project_id` but received {project_id!r}")
        return await self._get(
            path_template("/api/projects/{project_id}/perception/breakdown", project_id=project_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PerceptionRetrieveBreakdownResponse,
        )


class PerceptionResourceWithRawResponse:
    def __init__(self, perception: PerceptionResource) -> None:
        self._perception = perception

        self.list = to_raw_response_wrapper(
            perception.list,
        )
        self.retrieve_breakdown = to_raw_response_wrapper(
            perception.retrieve_breakdown,
        )


class AsyncPerceptionResourceWithRawResponse:
    def __init__(self, perception: AsyncPerceptionResource) -> None:
        self._perception = perception

        self.list = async_to_raw_response_wrapper(
            perception.list,
        )
        self.retrieve_breakdown = async_to_raw_response_wrapper(
            perception.retrieve_breakdown,
        )


class PerceptionResourceWithStreamingResponse:
    def __init__(self, perception: PerceptionResource) -> None:
        self._perception = perception

        self.list = to_streamed_response_wrapper(
            perception.list,
        )
        self.retrieve_breakdown = to_streamed_response_wrapper(
            perception.retrieve_breakdown,
        )


class AsyncPerceptionResourceWithStreamingResponse:
    def __init__(self, perception: AsyncPerceptionResource) -> None:
        self._perception = perception

        self.list = async_to_streamed_response_wrapper(
            perception.list,
        )
        self.retrieve_breakdown = async_to_streamed_response_wrapper(
            perception.retrieve_breakdown,
        )
