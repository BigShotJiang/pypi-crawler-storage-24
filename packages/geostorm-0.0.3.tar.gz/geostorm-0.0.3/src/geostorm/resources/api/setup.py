# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...types.api import setup_autofill_params
from ..._base_client import make_request_options
from ...types.api.setup_autofill_response import SetupAutofillResponse
from ...types.api.setup_retrieve_status_response import SetupRetrieveStatusResponse

__all__ = ["SetupResource", "AsyncSetupResource"]


class SetupResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SetupResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#accessing-raw-response-data-eg-headers
        """
        return SetupResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SetupResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#with_streaming_response
        """
        return SetupResourceWithStreamingResponse(self)

    def autofill(
        self,
        *,
        input: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SetupAutofillResponse:
        """
        Autofill Project

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/api/setup/autofill",
            body=maybe_transform({"input": input}, setup_autofill_params.SetupAutofillParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SetupAutofillResponse,
        )

    def retrieve_status(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SetupRetrieveStatusResponse:
        """Get Setup Status"""
        return self._get(
            "/api/setup/status",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SetupRetrieveStatusResponse,
        )


class AsyncSetupResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSetupResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#accessing-raw-response-data-eg-headers
        """
        return AsyncSetupResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSetupResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/geostorm-ai/geostorm-python#with_streaming_response
        """
        return AsyncSetupResourceWithStreamingResponse(self)

    async def autofill(
        self,
        *,
        input: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SetupAutofillResponse:
        """
        Autofill Project

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/api/setup/autofill",
            body=await async_maybe_transform({"input": input}, setup_autofill_params.SetupAutofillParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SetupAutofillResponse,
        )

    async def retrieve_status(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SetupRetrieveStatusResponse:
        """Get Setup Status"""
        return await self._get(
            "/api/setup/status",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=SetupRetrieveStatusResponse,
        )


class SetupResourceWithRawResponse:
    def __init__(self, setup: SetupResource) -> None:
        self._setup = setup

        self.autofill = to_raw_response_wrapper(
            setup.autofill,
        )
        self.retrieve_status = to_raw_response_wrapper(
            setup.retrieve_status,
        )


class AsyncSetupResourceWithRawResponse:
    def __init__(self, setup: AsyncSetupResource) -> None:
        self._setup = setup

        self.autofill = async_to_raw_response_wrapper(
            setup.autofill,
        )
        self.retrieve_status = async_to_raw_response_wrapper(
            setup.retrieve_status,
        )


class SetupResourceWithStreamingResponse:
    def __init__(self, setup: SetupResource) -> None:
        self._setup = setup

        self.autofill = to_streamed_response_wrapper(
            setup.autofill,
        )
        self.retrieve_status = to_streamed_response_wrapper(
            setup.retrieve_status,
        )


class AsyncSetupResourceWithStreamingResponse:
    def __init__(self, setup: AsyncSetupResource) -> None:
        self._setup = setup

        self.autofill = async_to_streamed_response_wrapper(
            setup.autofill,
        )
        self.retrieve_status = async_to_streamed_response_wrapper(
            setup.retrieve_status,
        )
