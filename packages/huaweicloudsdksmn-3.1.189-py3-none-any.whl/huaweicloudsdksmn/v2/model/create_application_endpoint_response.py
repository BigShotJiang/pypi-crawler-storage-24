# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateApplicationEndpointResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'request_id': 'str',
        'endpoint_urn': 'str'
    }

    attribute_map = {
        'request_id': 'request_id',
        'endpoint_urn': 'endpoint_urn'
    }

    def __init__(self, request_id=None, endpoint_urn=None):
        r"""CreateApplicationEndpointResponse

        The model defined in huaweicloud sdk

        :param request_id: 请求的唯一标识ID。
        :type request_id: str
        :param endpoint_urn: Endpoint的唯一资源标识。
        :type endpoint_urn: str
        """
        
        super().__init__()

        self._request_id = None
        self._endpoint_urn = None
        self.discriminator = None

        if request_id is not None:
            self.request_id = request_id
        if endpoint_urn is not None:
            self.endpoint_urn = endpoint_urn

    @property
    def request_id(self):
        r"""Gets the request_id of this CreateApplicationEndpointResponse.

        请求的唯一标识ID。

        :return: The request_id of this CreateApplicationEndpointResponse.
        :rtype: str
        """
        return self._request_id

    @request_id.setter
    def request_id(self, request_id):
        r"""Sets the request_id of this CreateApplicationEndpointResponse.

        请求的唯一标识ID。

        :param request_id: The request_id of this CreateApplicationEndpointResponse.
        :type request_id: str
        """
        self._request_id = request_id

    @property
    def endpoint_urn(self):
        r"""Gets the endpoint_urn of this CreateApplicationEndpointResponse.

        Endpoint的唯一资源标识。

        :return: The endpoint_urn of this CreateApplicationEndpointResponse.
        :rtype: str
        """
        return self._endpoint_urn

    @endpoint_urn.setter
    def endpoint_urn(self, endpoint_urn):
        r"""Sets the endpoint_urn of this CreateApplicationEndpointResponse.

        Endpoint的唯一资源标识。

        :param endpoint_urn: The endpoint_urn of this CreateApplicationEndpointResponse.
        :type endpoint_urn: str
        """
        self._endpoint_urn = endpoint_urn

    def to_dict(self):
        import warnings
        warnings.warn("CreateApplicationEndpointResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateApplicationEndpointResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
