import sys
from os import path

from bclearer_orchestration_services.datetime_service.time_helpers.time_getter import (
    now_time_as_string_for_files,
)

_LOG_INIT_HELP = (
    "Log file writing requires prior initialisation. "
    "Ensure your application calls run_b_application() "
    "or LogFiles.open_log_file(folder_path=<output_dir>) "
    "before any code that emits log messages. "
    "If using set_up_output_folder_and_logger(), verify that "
    "output_root_folder points to a valid, writable directory."
)


class LogFiles:
    log_file = None

    folder_path = None

    first_open_time = None

    @staticmethod
    def open_log_file(
        folder_path=None,
        now_time=None,
    ):
        if now_time is None:
            now_time = now_time_as_string_for_files()

        if folder_path is None:
            raise ValueError(
                "Cannot open log file: folder_path is None. "
                + _LOG_INIT_HELP
            )

        if not isinstance(folder_path, (str, bytes)):
            from os import PathLike

            if not isinstance(folder_path, PathLike):
                raise TypeError(
                    f"Cannot open log file: folder_path must be a string or path, "
                    f"got {type(folder_path).__name__}. "
                    + _LOG_INIT_HELP
                )

        LogFiles.folder_path = (
            folder_path
        )

        LogFiles.first_open_time = (
            now_time
        )

        file_name = (
            "log_file"
            + LogFiles.first_open_time
            + ".txt"
        )

        file_path = path.join(
            folder_path,
            file_name,
        )

        LogFiles.log_file = open(
            file_path,
            "w+",
        )

    @staticmethod
    def close_log_file():
        if LogFiles.log_file is not None:
            try:
                LogFiles.log_file.close()
            finally:
                LogFiles.log_file = None

    @staticmethod
    def write_to_log_file(
        message: str,
    ):
        if LogFiles.log_file is None or LogFiles.log_file.closed:
            if LogFiles.folder_path is None:
                print(
                    "WARNING: Log file not initialised — skipping file write. "
                    + _LOG_INIT_HELP,
                    file=sys.stderr,
                )
                return

            now_time = now_time_as_string_for_files()

            LogFiles.open_log_file(
                LogFiles.folder_path,
                now_time,
            )

        try:
            LogFiles.log_file.write(message)
            LogFiles.log_file.flush()
        except Exception as e:
            print(
                f"ERROR: Failed to write to log file: {e}",
                file=sys.stderr,
            )

            try:
                LogFiles.log_file = None
                LogFiles.open_log_file(
                    LogFiles.folder_path,
                    now_time_as_string_for_files(),
                )

                LogFiles.log_file.write(message)
                LogFiles.log_file.flush()
            except Exception as reopen_exception:
                print(
                    "ERROR: Unable to reopen log file for writing: "
                    f"{reopen_exception}",
                    file=sys.stderr,
                )
