import sys

from bclearer_core.configurations.b_configurations.b_configurations import (
    BConfigurations,
)
from bclearer_interop_services.file_system_service.objects.folders import (
    Folders,
)
from bclearer_orchestration_services.reporting_service.reporters.log_file import (
    LogFiles,
)


def set_up_application_output_folder_and_logger() -> (
    None
):
    __validate_output_root_folder_is_configured()

    app_run_output_file_system_folder = (
        __get_app_run_output_file_system_folder()
    )

    app_run_output_file_system_folder.make_me_on_disk()

    LogFiles.open_log_file(
        folder_path=app_run_output_file_system_folder.absolute_path
    )


def __validate_output_root_folder_is_configured() -> (
    None
):
    output_root = (
        BConfigurations.OUTPUT_ROOT_FOLDER
    )

    if (
        output_root is None
        or not output_root.absolute_path_string
    ):
        print(
            "WARNING: BConfigurations.OUTPUT_ROOT_FOLDER is not set. "
            "Log file output is disabled. "
            "To enable file logging, set BConfigurations.OUTPUT_ROOT_FOLDER "
            "to a Folders instance with a valid directory path before calling "
            "run_b_application(). Example:\n"
            "    from bclearer_core.configurations.b_configurations.b_configurations import BConfigurations\n"
            "    from bclearer_interop_services.file_system_service.objects.folders import Folders\n"
            "    BConfigurations.OUTPUT_ROOT_FOLDER = Folders(absolute_path_string='/path/to/output')\n",
            file=sys.stderr,
        )


def __get_app_run_output_file_system_folder() -> (
    Folders
):
    BConfigurations.set_up_app_run_output_folder_name()

    BConfigurations.set_app_run_output_folder()

    return (
        BConfigurations.APP_RUN_OUTPUT_FOLDER
    )
