"""Tests for metacognitive observation level and evidence metadata."""
import time
import pytest
from neo_cortex.models import ObservationLevel, MemoryRecord


class TestMetacognitiveObservationLevel:
    """METACOGNITIVE must be a valid ObservationLevel."""

    def test_metacognitive_exists_in_enum(self):
        assert hasattr(ObservationLevel, "METACOGNITIVE")
        assert ObservationLevel.METACOGNITIVE.value == "metacognitive"

    def test_enum_has_five_members(self):
        assert len(ObservationLevel) == 5

    def test_memory_record_accepts_metacognitive(self):
        record = MemoryRecord(
            id="v3_test_0_99999",
            session_id="test-session",
            timestamp=time.time(),
            summary="I tend to use Protocol D systematically",
            concepts=["debugging", "protocol-d"],
            energy=1.0,
            stability=1.0,
            observation_level=ObservationLevel.METACOGNITIVE,
        )
        assert record.observation_level == ObservationLevel.METACOGNITIVE

    def test_memory_record_stores_evidence_ids(self):
        record = MemoryRecord(
            id="v3_test_0_99998",
            session_id="test-session",
            timestamp=time.time(),
            summary="I debug better when I read error messages first",
            concepts=["debugging", "self-reflection"],
            energy=1.0,
            stability=1.0,
            observation_level=ObservationLevel.METACOGNITIVE,
            evidence_ids=["v3_abc_0_1", "v3_abc_0_2", "v3_abc_0_3"],
        )
        assert record.evidence_ids == ["v3_abc_0_1", "v3_abc_0_2", "v3_abc_0_3"]

    def test_memory_record_evidence_ids_default_empty(self):
        record = MemoryRecord(
            id="v3_test_0_99997",
            session_id="test-session",
            timestamp=time.time(),
            summary="Normal memory without evidence",
            concepts=["test"],
            energy=1.0,
            stability=1.0,
        )
        assert record.evidence_ids == []


class TestEvidenceIdsRoundtrip:
    """evidence_ids survives store insert → retrieve cycle."""

    def test_evidence_ids_stored_and_retrieved_in_chromadb(self, tmp_path):
        from neo_cortex.store import MemoryStore
        from neo_cortex.models import MemoryRecord, ObservationLevel
        import time

        store = MemoryStore(str(tmp_path), collection_name="test_meta")
        record = MemoryRecord(
            id="v3_meta_test_1",
            session_id="test",
            timestamp=time.time(),
            document="I debug systematically",
            observation_level=ObservationLevel.METACOGNITIVE,
            evidence_ids=["v3_a_0_1", "v3_a_0_2"],
        )
        embedding = [0.1] * 1024
        store.insert(record, embedding)

        results = store.query(embedding, n=1)
        assert len(results) == 1
        retrieved, sim = results[0]
        # Check evidence_ids survived roundtrip through MemoryRecord
        assert retrieved.evidence_ids == ["v3_a_0_1", "v3_a_0_2"]
        # Also verify raw ChromaDB metadata
        meta = store._collection.get(ids=["v3_meta_test_1"], include=["metadatas"])
        assert meta["metadatas"][0]["evidence_ids"] == "v3_a_0_1,v3_a_0_2"
