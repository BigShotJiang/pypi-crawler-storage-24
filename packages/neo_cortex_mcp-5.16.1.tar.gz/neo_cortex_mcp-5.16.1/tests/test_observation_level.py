import pytest
from neo_cortex.models import ObservationLevel, MemoryRecord


def test_observation_level_values():
    """ObservationLevel enum has 4 values."""
    assert ObservationLevel.DIRECT == "direct"
    assert ObservationLevel.INFERRED == "inferred"
    assert ObservationLevel.ABSTRACT == "abstract"
    assert ObservationLevel.REPORTED == "reported"


def test_observation_level_all_members():
    """ObservationLevel has exactly 5 members."""
    assert len(ObservationLevel) == 5


def test_memory_record_default_level():
    """MemoryRecord defaults to DIRECT observation level."""
    m = MemoryRecord(
        id="test", session_id="s1",
        question="q", answer_preview="a", document="doc"
    )
    assert m.observation_level == ObservationLevel.DIRECT


def test_memory_record_explicit_level():
    """MemoryRecord accepts explicit observation level."""
    m = MemoryRecord(
        id="test", session_id="s1",
        question="q", answer_preview="a", document="doc",
        observation_level=ObservationLevel.INFERRED,
    )
    assert m.observation_level == ObservationLevel.INFERRED


def test_memory_record_serializes_level():
    """Observation level appears in model_dump with string value."""
    m = MemoryRecord(
        id="test", session_id="s1",
        question="q", answer_preview="a", document="doc",
        observation_level=ObservationLevel.ABSTRACT,
    )
    d = m.model_dump()
    assert d["observation_level"] == "abstract"


def test_memory_record_from_string_level():
    """MemoryRecord can be created with string observation_level."""
    m = MemoryRecord(
        id="test", session_id="s1",
        question="q", answer_preview="a", document="doc",
        observation_level="reported",
    )
    assert m.observation_level == ObservationLevel.REPORTED
