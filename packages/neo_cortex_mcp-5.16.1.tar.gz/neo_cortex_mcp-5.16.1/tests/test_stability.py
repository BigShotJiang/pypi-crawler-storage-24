import pytest
from neo_cortex.decay import reinforce


def test_reinforce_increases_stability():
    """Stability increases by increment on each recall."""
    assert reinforce(1.0, 0.1) == 1.1
    assert reinforce(2.5, 0.1) == 2.6


def test_reinforce_default_increment():
    """Default increment is 1.0."""
    assert reinforce(1.0) == 2.0


def test_reinforce_accumulates():
    """Multiple reinforcements accumulate."""
    s = 1.0
    for _ in range(5):
        s = reinforce(s, 0.1)
    assert abs(s - 1.5) < 0.001
