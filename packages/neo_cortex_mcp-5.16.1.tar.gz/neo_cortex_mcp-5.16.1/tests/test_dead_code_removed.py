"""Tests verifying dead code has been removed."""

import importlib

import pytest


class TestDeadCodeRemoved:
    def test_no_server_module(self):
        """server.py must be deleted — import should fail."""
        with pytest.raises(ModuleNotFoundError):
            importlib.import_module("neo_cortex.server")

    def test_no_post_fallback_in_ingest(self):
        """_post() proxy fallback must be removed from mcp.py."""
        import neo_cortex.mcp as mcp_module
        import inspect
        src = inspect.getsource(mcp_module)
        assert "_post(" not in src

    def test_neo_cortex_entry_point_removed(self):
        """The 'neo-cortex' script entry point (server:main) must be removed."""
        from importlib.metadata import distribution
        dist = distribution("neo-cortex-mcp")
        eps = [ep for ep in dist.entry_points if ep.name == "neo-cortex"]
        assert len(eps) == 0, f"Entry point 'neo-cortex' still exists: {eps}"
