"""Tests for project foundation practices: __all__ exports and frozen DTOs."""

import pytest

from neo_cortex import models, config
from neo_cortex.models import (
    MemoryRecord,
    RecalledMemory,
    ClassificationResult,
    CompactMemory,
    StructuredFields,
    QueryAnalysis,
    CortexStats,
    RecallResult,
    DreamResult,
    TimelineResult,
)


class TestAllExports:
    def test_models_has_all(self):
        assert hasattr(models, "__all__")

    def test_models_all_contains_public(self):
        expected = {
            "MemoryType", "Activity", "ObservationLevel",
            "MemoryRecord", "IngestRequest", "RecalledMemory",
            "ClassificationResult", "QueryAnalysis", "CortexStats",
            "RecallResult", "DreamResult", "TimelineResult",
            "StructuredFields", "CompactMemory",
            "ConversationAppendRequest", "ConversationEntry",
        }
        assert expected.issubset(set(models.__all__))

    def test_config_has_all(self):
        assert hasattr(config, "__all__")


class TestFrozenDTOs:
    def test_memory_record_frozen(self):
        r = MemoryRecord(id="x", session_id="y")
        with pytest.raises(Exception):  # ValidationError for frozen
            r.id = "z"

    def test_recalled_memory_frozen(self):
        r = RecalledMemory(
            record=MemoryRecord(id="x", session_id="y"),
            similarity=0.9,
        )
        with pytest.raises(Exception):
            r.similarity = 0.1

    def test_classification_result_frozen(self):
        c = ClassificationResult()
        with pytest.raises(Exception):
            c.project = "changed"

    def test_compact_memory_frozen(self):
        m = CompactMemory(id="x", timestamp=1.0)
        with pytest.raises(Exception):
            m.id = "changed"

    def test_structured_fields_frozen(self):
        s = StructuredFields()
        with pytest.raises(Exception):
            s.title = "changed"

    def test_query_analysis_frozen(self):
        q = QueryAnalysis(refined_query="test")
        with pytest.raises(Exception):
            q.refined_query = "changed"

    def test_cortex_stats_frozen(self):
        s = CortexStats(
            total_memories=0, sessions=0, avg_energy=0.0,
            max_energy=0.0, min_energy=0.0, dream_count=0, projects={},
        )
        with pytest.raises(Exception):
            s.total_memories = 99
