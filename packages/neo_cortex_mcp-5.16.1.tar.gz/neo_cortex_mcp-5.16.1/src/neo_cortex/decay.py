"""Ebbinghaus decay model — execution-day based memory forgetting curve."""

import math

FLOOR = 0.05


def ebbinghaus_weight(execution_days: float, stability: float, slowdown: float = 1.0) -> float:
    """Compute memory weight: exp(-(execution_days / slowdown) / stability).

    Args:
        execution_days: Runtime days since last access (not calendar days)
        stability: Memory strength — increases with each recall
        slowdown: Decay speed divisor (10 = 10x slower than human Ebbinghaus)

    Returns value between FLOOR and 1.0.
    """
    if stability <= 0:
        return FLOOR
    effective_days = execution_days / slowdown if slowdown > 0 else execution_days
    w = math.exp(-(effective_days / stability))
    return max(FLOOR, min(1.0, w))


def reinforce(stability: float, increment: float = 1.0) -> float:
    """Each recall increases stability."""
    return stability + increment
