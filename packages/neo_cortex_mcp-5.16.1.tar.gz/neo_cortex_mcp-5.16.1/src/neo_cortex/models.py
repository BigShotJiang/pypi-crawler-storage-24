"""Typed models for the Neo Cortex memory system."""

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field
import time

__all__ = [
    "MemoryType", "Activity", "ObservationLevel",
    "MemoryRecord", "IngestRequest", "RecalledMemory",
    "ClassificationResult", "QueryAnalysis", "CortexStats",
    "RecallResult", "DreamResult", "TimelineResult",
    "StructuredFields", "CompactMemory",
    "ConversationAppendRequest", "ConversationEntry",
]


class MemoryType(str, Enum):
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    EMOTIONAL = "emotional"
    RELATIONAL = "relational"
    TENSION = "tension"


class Activity(str, Enum):
    BUGFIX = "bugfix"
    FEATURE = "feature"
    DEBUG = "debug"
    CONFIG = "config"
    DEPLOY = "deploy"
    RESEARCH = "research"
    DISCUSSION = "discussion"
    LEARNING = "learning"
    IDENTITY = "identity"
    BEHAVIOR = "behavior"
    GROWTH = "growth"


class ObservationLevel(str, Enum):
    """How certain/direct is this knowledge?"""
    DIRECT = "direct"           # Saw it, did it, explicit statement
    INFERRED = "inferred"       # Deduced from evidence, logical conclusion
    ABSTRACT = "abstract"       # Pattern, generalization, theoretical
    REPORTED = "reported"       # Someone else said it, secondhand
    METACOGNITIVE = "metacognitive"  # Self-reflection, how I think/work/decide


class MemoryRecord(BaseModel):
    model_config = {"frozen": True}
    id: str
    session_id: str
    timestamp: float = Field(default_factory=time.time)
    turn_number: int = 0
    question: str = ""
    answer_preview: str = ""
    document: str = ""
    project: str = "general"
    topic: str = "unknown"
    activity: Activity = Activity.DISCUSSION
    memory_type: MemoryType = MemoryType.EPISODIC
    energy: float = 1.0
    model: str = "opus"
    source: str = "neo-cortex"
    tools_used: list[str] = Field(default_factory=list)
    observation_level: ObservationLevel = ObservationLevel.DIRECT
    stability: float = 1.0
    evidence_ids: list[str] = Field(default_factory=list)


# --- Request/Response models ---


class IngestRequest(BaseModel):
    session_id: str
    question: str
    answer: str
    model: str = "opus"
    source: str = "neo-cortex"
    tools_used: list[str] = Field(default_factory=list)
    turn_number: int = 0


class RecalledMemory(BaseModel):
    model_config = {"frozen": True}
    record: MemoryRecord
    similarity: float


class ClassificationResult(BaseModel):
    model_config = {"frozen": True}
    project: str = "general"
    topic: str = "unknown"
    activity: Activity = Activity.DISCUSSION
    worth_remembering: bool = True
    title: Optional[str] = None
    summary: Optional[str] = None
    facts: list[str] = Field(default_factory=list)
    concepts: list[str] = Field(default_factory=list)
    files_touched: list[str] = Field(default_factory=list)
    observation_level: str = "direct"


class QueryAnalysis(BaseModel):
    model_config = {"frozen": True}
    project: Optional[str] = None
    topic: Optional[str] = None
    activity_filter: Optional[str] = None
    time_hint: str = "any"
    refined_query: str


class CortexStats(BaseModel):
    model_config = {"frozen": True}
    total_memories: int
    sessions: int
    avg_energy: float
    max_energy: float
    min_energy: float
    dream_count: int
    projects: dict[str, int]


class RecallResult(BaseModel):
    model_config = {"frozen": True}
    query: str
    count: int
    memories: list[RecalledMemory]
    mbel: Optional[str] = None


class DreamResult(BaseModel):
    model_config = {"frozen": True}
    status: str
    dream_count: int
    cluster: list[str]
    surprisal: list[str] = Field(default_factory=list)


class TimelineResult(BaseModel):
    model_config = {"frozen": True}
    count: int
    memories: list[MemoryRecord]
    mbel: Optional[str] = None


# --- Conversation log models ---


class StructuredFields(BaseModel):
    model_config = {"frozen": True}
    """Structured observation extracted by classifier."""
    title: Optional[str] = None
    summary: Optional[str] = None
    facts: list[str] = Field(default_factory=list)
    concepts: list[str] = Field(default_factory=list)
    files_touched: list[str] = Field(default_factory=list)


class CompactMemory(BaseModel):
    model_config = {"frozen": True}
    """Lightweight memory reference for search results (low token cost)."""
    id: str
    title: Optional[str] = None
    project: str = "general"
    topic: str = "unknown"
    activity: str = "discussion"
    timestamp: float
    energy: float = 1.0


# --- Conversation log models ---


class ConversationAppendRequest(BaseModel):
    session_id: str
    role: str  # user, assistant, tool_use, tool_result, system, error
    content: str
    event_type: Optional[str] = None
    model: Optional[str] = None
    timestamp: Optional[float] = None
    metadata: Optional[dict] = None


class ConversationEntry(BaseModel):
    model_config = {"frozen": True}
    id: int
    timestamp: float
    session_id: str
    role: str
    content: str
    event_type: Optional[str] = None
    model: Optional[str] = None
    metadata: Optional[dict] = None
