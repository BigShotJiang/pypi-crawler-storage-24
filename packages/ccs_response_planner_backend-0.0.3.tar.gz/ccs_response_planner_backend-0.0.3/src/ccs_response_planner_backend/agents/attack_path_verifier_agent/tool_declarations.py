"""
Gemini function-calling declarations for the AttackPathVerifierAgent tools.

Provides ``TOOL_DECLARATIONS`` containing dt_exec, dt_restart,
and produce_attack_path_verifier_report.
"""
from google.genai import types as genai_types  # type: ignore[attr-defined]

DT_EXEC_DECL = genai_types.FunctionDeclaration(
    name="dt_exec",
    description=(
        "Execute a shell command on a digital-twin "
        "container. Use this to run attack commands, "
        "inspect processes, check connectivity, and "
        "gather evidence. "
        "Valid container names: i1_gateway, "
        "i1_firewall, i1_log_collector, "
        "i1_server_1\u2013i1_server_6 (Incident 1) or "
        "i2_server_1\u2013i2_server_6 (Incident 2)."
    ),
    parameters={  # type: ignore[arg-type]
        "type": "object",
        "properties": {
            "container": {
                "type": "string",
                "description": (
                    "The host id of the container "
                    "(e.g. i1_firewall, i1_server_1)."
                ),
            },
            "command": {
                "type": "string",
                "description": (
                    "The shell command to execute."
                ),
            },
        },
        "required": ["container", "command"],
    },
)

DT_RESTART_DECL = genai_types.FunctionDeclaration(
    name="dt_restart",
    description=(
        "Restart a digital-twin container that has "
        "crashed or stopped. Use when dt_exec fails "
        "with a 'container is not running' error. "
        "Pass a specific container name to restart "
        "just that host, or pass 'all' to redeploy "
        "the entire digital twin."
    ),
    parameters={  # type: ignore[arg-type]
        "type": "object",
        "properties": {
            "container": {
                "type": "string",
                "description": (
                    "The host id to restart "
                    "(e.g. i1_server_2), or 'all' "
                    "to redeploy the entire DT."
                ),
            },
        },
        "required": ["container"],
    },
)

PRODUCE_ATTACK_PATH_VERIFIER_REPORT_DECL = genai_types.FunctionDeclaration(
    name="produce_attack_path_verifier_report",
    description=(
        "Produce the final structured attack path verifier report. "
        "Call this ONLY after attempting all steps of "
        "the attack path and gathering evidence."
    ),
    parameters={  # type: ignore[arg-type]
        "type": "object",
        "properties": {
            "executive_summary": {
                "type": "string",
                "description": (
                    "High-level overview of the "
                    "penetration test results."
                ),
            },
            "attack_path_steps": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "step_name": {
                            "type": "string",
                            "description": (
                                "Name of this attack "
                                "path step."
                            ),
                        },
                        "step_description": {
                            "type": "string",
                            "description": (
                                "Description of what "
                                "this step attempts."
                            ),
                        },
                        "target_host": {
                            "type": "string",
                            "description": (
                                "The host targeted "
                                "in this step."
                            ),
                        },
                        "commands_executed": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "Shell commands executed "
                                "during this step."
                            ),
                        },
                        "command_outputs": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "Outputs from the "
                                "executed commands."
                            ),
                        },
                        "success": {
                            "type": "boolean",
                            "description": (
                                "Whether this step "
                                "succeeded."
                            ),
                        },
                        "evidence": {
                            "type": "string",
                            "description": (
                                "Evidence gathered "
                                "during this step."
                            ),
                        },
                        "notes": {
                            "type": "string",
                            "description": (
                                "Additional notes "
                                "about this step."
                            ),
                        },
                    },
                    "required": [
                        "step_name",
                        "step_description",
                        "target_host",
                        "commands_executed",
                        "command_outputs",
                        "success",
                        "evidence",
                    ],
                },
            },
            "overall_verdict": {
                "type": "string",
                "description": (
                    "One of: Attack path validated, "
                    "Attack path partially validated, "
                    "Attack path not feasible."
                ),
            },
            "hosts_compromised": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "List of hosts that were "
                    "successfully compromised."
                ),
            },
            "reproduction_commands": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Ordered list of commands that "
                    "reproduce the full attack."
                ),
            },
            "defensive_recommendations": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Recommendations for defending "
                    "against this attack path."
                ),
            },
        },
        "required": [
            "executive_summary",
            "attack_path_steps",
            "overall_verdict",
            "hosts_compromised",
            "reproduction_commands",
            "defensive_recommendations",
        ],
    },
)

TOOL_DECLARATIONS = [
    DT_EXEC_DECL, DT_RESTART_DECL, PRODUCE_ATTACK_PATH_VERIFIER_REPORT_DECL,
]
