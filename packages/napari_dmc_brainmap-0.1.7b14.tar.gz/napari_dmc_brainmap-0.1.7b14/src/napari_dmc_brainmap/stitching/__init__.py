from .stitching import StitchingWidget

