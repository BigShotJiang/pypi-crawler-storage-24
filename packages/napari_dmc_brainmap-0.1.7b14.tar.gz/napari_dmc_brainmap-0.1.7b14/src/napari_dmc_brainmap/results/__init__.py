from .results import ResultsWidget
