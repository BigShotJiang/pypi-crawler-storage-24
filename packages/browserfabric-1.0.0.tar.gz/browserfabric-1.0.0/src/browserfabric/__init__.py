"""
browserfabric - Python SDK for BrowserFabric API

Simple Usage:
    import browserfabric

    # Super simple interface
    mcp = browserfabric.MCP("browseruse")
    session = await mcp.create_session()
    await session.navigate("https://example.com")
    await session.screenshot("page.png")

    # Or even simpler with context manager
    async with browserfabric.browser() as browser:
        await browser.navigate("https://example.com")
        await browser.click("#button")
        await browser.screenshot("result.png")

    # One-liner screenshot
    await browserfabric.screenshot("https://example.com", "example.png")
"""

__version__ = "1.0.0"
__author__ = "BrowserFabric Contributors"
__email__ = "info@example.com"

# Simple client interface
from .client import MCP, MCPError, browser, ensure_server_running, screenshot, test_form

__all__ = [
    # Simple client interface
    "MCP",
    "browser",
    "screenshot",
    "test_form",
    "ensure_server_running",
    "MCPError",
]
