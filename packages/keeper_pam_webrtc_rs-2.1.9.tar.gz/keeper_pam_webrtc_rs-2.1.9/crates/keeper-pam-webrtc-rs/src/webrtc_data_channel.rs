use crate::unlikely;
use bytes::Bytes;
#[cfg(test)]
use futures::future::BoxFuture;
use log::{debug, warn};
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::Duration;
use webrtc::data_channel::RTCDataChannel;

// Lock-free queue for pending frames - uses crossbeam's SegQueue
use crossbeam_queue::SegQueue;

/// Standard buffer threshold for optimal WebRTC performance.
/// This value (8KB) is optimized for mixed interactive + bulk workloads:
/// - Research: SMALLER thresholds achieve HIGHER throughput (2KB → 135 Mbps on LAN)
/// - 8KB enables ~200-500 drain events/sec (2x more frequent than 16KB)
/// - Combined with 2000-frame drain batches = 8x faster queue clearing vs 16KB/500 frames
/// - Reduces interactive latency (keyboard echo) from 100-500ms to 10-50ms
/// - Still maintains high throughput for bulk transfers (4K video, 100GB files)
/// - Marginal CPU increase (~1-2% per connection) for dramatic latency improvement
pub const STANDARD_BUFFER_THRESHOLD: u64 = 8 * 1024; // 8KB - balanced for latency + throughput

// Error message constants to avoid repeated allocations in hot paths
const QUEUE_FULL_ERROR: &str = "Queue full - backpressure required (loss-intolerant protocol)";
const DATACHANNEL_CLOSED_ERROR: &str = "DataChannel closed";
/// Timeout for dc.send() to prevent the outbound task from blocking indefinitely
/// on webrtc-sctp's PendingQueue semaphore (128KB capacity). Under SCTP congestion,
/// semaphore.acquire_many().await blocks until the write_loop drains the queue,
/// but the write_loop is starved by mutex contention with the read_loop that
/// processes SACKs. A 100ms timeout breaks this cycle by returning control to
/// the caller, which queues the frame at the application level instead.
const DC_SEND_TIMEOUT: Duration = Duration::from_millis(100);

// Type alias for complex callback type - callbacks still need Mutex (can't be atomic)
type BufferedAmountLowCallback =
    Arc<std::sync::Mutex<Option<Box<dyn Fn() + Send + Sync + 'static>>>>;

#[cfg(test)]
type TestSendHook = Arc<
    std::sync::Mutex<Option<Box<dyn Fn(Bytes) -> BoxFuture<'static, ()> + Send + Sync + 'static>>>,
>;

// Async-first wrapper for data channel functionality
pub struct WebRTCDataChannel {
    pub data_channel: Arc<RTCDataChannel>,
    pub(crate) is_closing: Arc<AtomicBool>,
    /// Buffered amount threshold - lock-free with AtomicU64
    pub(crate) buffered_amount_low_threshold: Arc<AtomicU64>,
    /// Callback for buffered amount low - still needs Mutex (callback is not Copy)
    pub(crate) on_buffered_amount_low_callback: BufferedAmountLowCallback,
    pub(crate) threshold_monitor: Arc<AtomicBool>,
    /// Notification for when data channel opens - allows multiple waiters without callback conflicts
    pub(crate) open_notify: Arc<tokio::sync::Notify>,
    /// Flag indicating if data channel is open - set once and never reset
    pub(crate) is_open: Arc<AtomicBool>,

    /// Early message buffer - captures messages arriving before handlers are ready.
    /// This is critical for on_data_channel callbacks where messages can arrive
    /// before setup_channel_for_data_channel completes (~100ms race window).
    /// Uses lock-free SegQueue for zero-contention message capture.
    pub(crate) early_message_buffer: Arc<SegQueue<Bytes>>,
    /// Count of messages in early buffer (for logging/debugging)
    pub(crate) early_message_count: Arc<AtomicUsize>,
    /// Flag indicating if early buffering is active (set to false once real handler takes over)
    pub(crate) early_buffering_active: Arc<AtomicBool>,

    #[cfg(test)]
    pub(crate) test_send_hook: TestSendHook,
}

impl Clone for WebRTCDataChannel {
    fn clone(&self) -> Self {
        Self {
            data_channel: Arc::clone(&self.data_channel),
            is_closing: Arc::clone(&self.is_closing),
            buffered_amount_low_threshold: Arc::clone(&self.buffered_amount_low_threshold),
            on_buffered_amount_low_callback: Arc::clone(&self.on_buffered_amount_low_callback),
            threshold_monitor: Arc::clone(&self.threshold_monitor),
            open_notify: Arc::clone(&self.open_notify),
            is_open: Arc::clone(&self.is_open),
            early_message_buffer: Arc::clone(&self.early_message_buffer),
            early_message_count: Arc::clone(&self.early_message_count),
            early_buffering_active: Arc::clone(&self.early_buffering_active),

            #[cfg(test)]
            test_send_hook: Arc::clone(&self.test_send_hook),
        }
    }
}

impl WebRTCDataChannel {
    pub fn new(data_channel: Arc<RTCDataChannel>) -> Self {
        let open_notify = Arc::new(tokio::sync::Notify::new());
        let is_open = Arc::new(AtomicBool::new(false));

        // Early message buffering - captures messages before real handler is set up
        let early_message_buffer = Arc::new(SegQueue::new());
        let early_message_count = Arc::new(AtomicUsize::new(0));
        let early_buffering_active = Arc::new(AtomicBool::new(true));

        // Check if already open (for received data channels that may already be open)
        let already_open = data_channel.ready_state()
            == webrtc::data_channel::data_channel_state::RTCDataChannelState::Open;
        if already_open {
            is_open.store(true, Ordering::Release);
            open_notify.notify_waiters();
        }

        // Set up on_open callback to notify waiters (this is the ONLY place on_open is set)
        let is_open_for_callback = Arc::clone(&is_open);
        let open_notify_for_callback = Arc::clone(&open_notify);
        data_channel.on_open(Box::new(move || {
            is_open_for_callback.store(true, Ordering::Release);
            open_notify_for_callback.notify_waiters();
            Box::pin(async {})
        }));

        // CRITICAL: Set up early message buffering IMMEDIATELY.
        // This captures messages that arrive before setup_channel_for_data_channel
        // completes (there can be a ~100ms race window in on_data_channel callbacks).
        let early_buffer_for_callback = Arc::clone(&early_message_buffer);
        let early_count_for_callback = Arc::clone(&early_message_count);
        let early_active_for_callback = Arc::clone(&early_buffering_active);
        let label_for_log = data_channel.label().to_string();
        data_channel.on_message(Box::new(move |msg| {
            let buffer = Arc::clone(&early_buffer_for_callback);
            let count = Arc::clone(&early_count_for_callback);
            let active = Arc::clone(&early_active_for_callback);
            let label = label_for_log.clone();
            let data = Bytes::copy_from_slice(&msg.data);

            Box::pin(async move {
                // Only buffer if early buffering is still active
                if active.load(Ordering::Acquire) {
                    let msg_count = count.fetch_add(1, Ordering::AcqRel) + 1;
                    buffer.push(data);
                    debug!(
                        "[EARLY_BUFFER] Captured early message #{} ({} bytes) on channel '{}' before handler ready",
                        msg_count, buffer.len(), label
                    );
                }
                // If early_buffering_active is false, this callback should have been
                // replaced by the real handler - but if not, the message is dropped
                // (this shouldn't happen in normal operation)
            })
        }));

        Self {
            data_channel,
            is_closing: Arc::new(AtomicBool::new(false)),
            buffered_amount_low_threshold: Arc::new(AtomicU64::new(0)),
            on_buffered_amount_low_callback: Arc::new(std::sync::Mutex::new(None)),
            threshold_monitor: Arc::new(AtomicBool::new(false)),
            open_notify,
            is_open,
            early_message_buffer,
            early_message_count,
            early_buffering_active,

            #[cfg(test)]
            test_send_hook: Arc::new(std::sync::Mutex::new(None)),
        }
    }

    /// Set the buffered amount low threshold (lock-free)
    pub fn set_buffered_amount_low_threshold(&self, threshold: u64) {
        // Lock-free store
        self.buffered_amount_low_threshold
            .store(threshold, Ordering::Release);

        // Log the threshold change
        debug!("Set buffered amount low threshold to {} bytes", threshold);

        // Set the native WebRTC bufferedAmountLowThreshold
        if threshold > 0 {
            let dc = self.clone();
            let threshold_clone = threshold;

            // Spawn a task to set the threshold and register the callback on the native data channel
            tokio::spawn(async move {
                // Set the native threshold - convert u64 to usize
                let threshold_usize = threshold_clone.try_into().unwrap_or(usize::MAX);
                dc.data_channel
                    .set_buffered_amount_low_threshold(threshold_usize)
                    .await;

                // Make a separate clone for the callback
                let callback_dc = dc.clone();

                // Register the onBufferedAmountLow callback
                dc.data_channel
                    .on_buffered_amount_low(Box::new(move || {
                        let callback_dc = callback_dc.clone();
                        let threshold_value = threshold_clone;

                        Box::pin(async move {
                            // Buffer drain event logging - verbose only (can be frequent)
                            if unlikely!(crate::logger::is_verbose_logging()) {
                                debug!(
                                    "Native bufferedAmountLow event triggered (buffer below {})",
                                    threshold_value
                                );
                            }

                            // Get and call our callback (callback mutex is infrequent, not hot path)
                            if let Ok(callback_guard) =
                                callback_dc.on_buffered_amount_low_callback.lock()
                            {
                                if let Some(ref callback) = *callback_guard {
                                    callback();
                                }
                            }
                        })
                    }))
                    .await;
            });
        }
    }

    /// Set the callback to be called when the buffered amount drops below the threshold
    pub fn on_buffered_amount_low(&self, callback: Option<Box<dyn Fn() + Send + Sync + 'static>>) {
        // Check is_some() before moving the callback
        let has_callback = callback.is_some();

        // Callback registration is infrequent - mutex is acceptable here
        if let Ok(mut guard) = self.on_buffered_amount_low_callback.lock() {
            *guard = callback;
            debug!("Set buffered amount low callback: {}", has_callback);
        } else {
            warn!("Failed to set buffered amount low callback - mutex poisoned");
        }
    }

    // Add a test method to set the sending hook for testing
    #[cfg(test)]
    pub fn set_test_send_hook<F>(&self, hook: F)
    where
        F: Fn(Bytes) -> BoxFuture<'static, ()> + Send + Sync + 'static,
    {
        if let Ok(mut guard) = self.test_send_hook.lock() {
            *guard = Some(Box::new(hook));
        }
    }

    pub async fn send(&self, data: Bytes) -> Result<(), String> {
        // Check if closing
        if self.is_closing.load(Ordering::Acquire) {
            return Err("Channel is closing".to_string());
        }

        // For testing: call the test hook if set
        #[cfg(test)]
        {
            if let Ok(hook_guard) = self.test_send_hook.lock() {
                if let Some(ref hook) = *hook_guard {
                    // Clone the data for the hook
                    let data_clone = data.clone();

                    // Call the hook with a clone of the data
                    let hook_future = hook(data_clone);

                    // Spawn the hook execution to avoid blocking
                    tokio::spawn(hook_future);
                }
            }
        }

        // Send data with detailed error handling
        let result = self
            .data_channel
            .send(&data)
            .await
            .map(|_| ())
            .map_err(|e| format!("Failed to send data: {e}"));

        // No need to manually monitor buffered amount - we rely on the native WebRTC event
        // The onBufferedAmountLow event will fire when the buffer drops below the threshold

        result
    }

    pub async fn buffered_amount(&self) -> u64 {
        // Early return if the channel is closing
        if self.is_closing.load(Ordering::Acquire) {
            return 0;
        }

        self.data_channel.buffered_amount().await as u64
    }

    /// Wait for the data channel to be open, with an optional timeout.
    /// Returns Ok(true) if channel opened, Ok(false) if closed/timeout, Err if closing.
    /// This is essential for server-mode channels to wait before accepting TCP connections.
    ///
    /// This uses a simple polling approach combined with the shared notification to be
    /// robust against callback conflicts. Even if callbacks are overwritten elsewhere,
    /// we'll still detect the open state via polling.
    pub async fn wait_for_channel_open(&self, timeout: Option<Duration>) -> Result<bool, String> {
        let timeout_duration = timeout.unwrap_or(Duration::from_secs(10));
        let poll_interval = Duration::from_millis(50);
        let deadline = tokio::time::Instant::now() + timeout_duration;
        let label = self.data_channel.label().to_string();

        debug!(
            "Waiting for data channel to open: {} (timeout: {:?})",
            label, timeout_duration
        );

        loop {
            let current_state = self.data_channel.ready_state();

            // Check if already closed (expected during cleanup, not an error)
            if self.is_closing.load(Ordering::Acquire) {
                debug!(
                    "wait_for_channel_open: channel closing (expected during cleanup): channel={}",
                    label
                );
                return Err("Data channel is closing".to_string());
            }

            // Check if open via our flag (set by on_open callback)
            if self.is_open.load(Ordering::Acquire) {
                return Ok(true);
            }

            // Also check native state (in case callback was overwritten)
            if current_state == webrtc::data_channel::data_channel_state::RTCDataChannelState::Open
            {
                // Update our flag to match
                debug!(
                    "Data channel opened (detected via native state polling): {}",
                    label
                );
                self.is_open.store(true, Ordering::Release);
                self.open_notify.notify_waiters();
                return Ok(true);
            }

            // Check for timeout
            if tokio::time::Instant::now() >= deadline {
                warn!(
                    "Data channel did not open within timeout ({:?}), final state: {:?} (channel: {})",
                    timeout_duration, current_state, label
                );
                return Ok(false);
            }

            // Use select to wait for either notification or poll interval
            // This combines event-driven and polling for robustness
            tokio::select! {
                _ = self.open_notify.notified() => {
                    // Notification received, check state again
                    continue;
                }
                _ = tokio::time::sleep(poll_interval) => {
                    // Poll interval, check state again
                    continue;
                }
            }
        }
    }

    pub async fn close(&self) -> Result<(), String> {
        // Avoid duplicate close operations
        if self.is_closing.swap(true, Ordering::AcqRel) {
            return Ok(()); // Already closing or closed
        }

        // Close with timeout to avoid hanging
        match tokio::time::timeout(Duration::from_secs(3), self.data_channel.close()).await {
            Ok(result) => result.map_err(|e| format!("Failed to close data channel: {e}")),
            Err(_) => {
                warn!("Data channel close operation timed out, forcing abandonment");
                Ok(()) // Force success even though it timed out
            }
        }
    }

    /// Wait for the WebRTC buffer to drain (without closing the channel).
    ///
    /// Use this when you've just sent an important message (like an error or
    /// disconnect notification) and want to ensure it's transmitted before
    /// the connection task exits. Does NOT close the channel.
    ///
    /// # Arguments
    /// * `timeout` - Maximum time to wait for buffer to drain
    ///
    /// # Returns
    /// * `true` - Buffer drained completely
    /// * `false` - Timeout reached, data may still be buffered
    pub async fn drain(&self, timeout: Duration) -> bool {
        let start = std::time::Instant::now();

        while start.elapsed() < timeout {
            // Check if already closing (buffer will report 0)
            if self.is_closing.load(Ordering::Acquire) {
                return true;
            }

            let buffered = self.data_channel.buffered_amount().await;
            if buffered == 0 {
                return true;
            }
            // Cooperative yield - avoids busy loop, no timer overhead
            tokio::task::yield_now().await;
        }

        warn!(
            "WebRTC buffer drain timeout after {:?}, data may still be buffered",
            timeout
        );
        false
    }

    pub fn ready_state(&self) -> String {
        // Fast path for closing
        if self.is_closing.load(Ordering::Acquire) {
            return "Closed".to_string();
        }

        format!("{:?}", self.data_channel.ready_state())
    }

    pub fn label(&self) -> String {
        self.data_channel.label().to_string()
    }

    /// Take ownership of all early-buffered messages and disable early buffering.
    ///
    /// CRITICAL: This must be called by setup_channel_for_data_channel AFTER
    /// setting the real on_message handler. The correct order is:
    /// 1. Set new on_message handler (replaces early buffer callback)
    /// 2. Call take_early_messages() to drain buffer
    /// 3. Forward returned messages to the channel
    ///
    /// This order ensures no messages are lost:
    /// - Messages arriving after step 1 go directly to new handler
    /// - Messages that arrived before step 1 are returned by step 2
    ///
    /// After this call:
    /// - early_buffering_active is set to false
    /// - All buffered messages are returned
    ///
    /// # Returns
    /// Vec of early messages in arrival order, empty if none were buffered
    pub fn take_early_messages(&self) -> Vec<Bytes> {
        // Disable early buffering FIRST (atomic release)
        self.early_buffering_active.store(false, Ordering::Release);

        // Drain all buffered messages
        let mut messages = Vec::new();
        while let Some(msg) = self.early_message_buffer.pop() {
            messages.push(msg);
        }

        let count = self.early_message_count.load(Ordering::Acquire);
        if !messages.is_empty() {
            log::info!(
                "[EARLY_BUFFER] Drained {} early messages from channel '{}' (total captured: {})",
                messages.len(),
                self.label(),
                count
            );
        }

        messages
    }
}

/// Retry state for exponential backoff
/// Uses atomic timestamp (nanoseconds since epoch) for lock-free access
struct RetryState {
    /// Number of retry attempts
    attempts: AtomicUsize,
    /// Timestamp of last retry attempt (nanoseconds since Unix epoch, 0 = None)
    last_retry_ns: AtomicU64,
}

impl RetryState {
    fn new() -> Self {
        Self {
            attempts: AtomicUsize::new(0),
            last_retry_ns: AtomicU64::new(0), // 0 = None
        }
    }

    // Note: get_backoff_delay() reserved for future use when implementing
    // actual retry with backoff delays. Currently retries happen via queue.

    /// Record a retry attempt (lock-free)
    fn record_retry(&self) {
        self.attempts.fetch_add(1, Ordering::Release);
        let now_ns = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;
        self.last_retry_ns.store(now_ns, Ordering::Release);
    }

    /// Reset retry state on success (lock-free)
    fn reset(&self) {
        self.attempts.store(0, Ordering::Release);
        self.last_retry_ns.store(0, Ordering::Release); // 0 = None
    }

    /// Get current attempt count (lock-free)
    fn get_attempts(&self) -> usize {
        self.attempts.load(Ordering::Acquire)
    }

    /// Get elapsed time since last retry (lock-free)
    fn get_last_retry_elapsed(&self) -> Option<Duration> {
        let last_ns = self.last_retry_ns.load(Ordering::Acquire);
        if last_ns == 0 {
            return None;
        }
        let now_ns = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;
        if now_ns >= last_ns {
            Some(Duration::from_nanos(now_ns - last_ns))
        } else {
            None // Clock went backwards
        }
    }
}

/// Event-driven sender that uses WebRTC native bufferedAmountLow events
/// Eliminates polling and provides natural backpressure
/// Uses lock-free SegQueue for zero-contention frame queueing
pub struct EventDrivenSender {
    data_channel: Arc<WebRTCDataChannel>,
    /// Lock-free queue for pending frames - SegQueue provides MPSC without locks
    pending_frames: Arc<SegQueue<Bytes>>,
    /// Priority re-queue for frames that failed a previous send attempt.
    /// Drained BEFORE pending_frames to preserve strict ordering.
    requeue_frames: Arc<SegQueue<Bytes>>,
    can_send: Arc<AtomicBool>,
    threshold: u64,               // Backpressure threshold for monitoring
    queue_size: Arc<AtomicUsize>, // Lock-free queue depth counter (covers both queues)

    // Queue monitoring for alerts (lock-free atomics)
    /// Timestamp when queue first exceeded 75% threshold (nanoseconds since Unix epoch, 0 = None)
    high_queue_start_ns: Arc<AtomicU64>,
    /// Count of frames that were blocked (queue full) - for metrics
    frames_blocked: Arc<AtomicUsize>,

    // Retry state for exponential backoff
    retry_state: Arc<RetryState>,
}

impl EventDrivenSender {
    /// Create a new event-driven sender with the specified threshold
    pub fn new(data_channel: Arc<WebRTCDataChannel>, threshold: u64) -> Self {
        let sender = Self {
            data_channel: data_channel.clone(),
            pending_frames: Arc::new(SegQueue::new()),
            requeue_frames: Arc::new(SegQueue::new()),
            can_send: Arc::new(AtomicBool::new(true)),
            threshold,
            queue_size: Arc::new(AtomicUsize::new(0)),
            high_queue_start_ns: Arc::new(AtomicU64::new(0)), // 0 = None
            frames_blocked: Arc::new(AtomicUsize::new(0)),
            retry_state: Arc::new(RetryState::new()),
        };

        // Set up WebRTC native event handling
        data_channel.set_buffered_amount_low_threshold(threshold);

        let can_send_clone = sender.can_send.clone();
        let pending_clone = sender.pending_frames.clone();
        let requeue_clone = sender.requeue_frames.clone();
        let queue_size_clone = sender.queue_size.clone();
        let dc_clone = data_channel.clone();

        // EVENT-DRIVEN: Only wake up when buffer space available
        data_channel.on_buffered_amount_low(Some(Box::new(move || {
            can_send_clone.store(true, Ordering::Release);

            // Drain frames when space becomes available (batched, lock-free).
            // Pop from requeue_frames FIRST to preserve ordering of frames
            // that failed a previous send attempt, then from pending_frames.
            let mut to_send = Vec::with_capacity(2000);
            while to_send.len() < 2000 {
                match requeue_clone.pop() {
                    Some(frame) => to_send.push(frame),
                    None => break,
                }
            }
            while to_send.len() < 2000 {
                match pending_clone.pop() {
                    Some(frame) => to_send.push(frame),
                    None => break,
                }
            }

            // Update atomic counter after draining (covers both queues)
            let old_size = queue_size_clone.fetch_sub(to_send.len(), Ordering::AcqRel);

            // Sanity check: counter should never underflow (indicates a bug in increment/decrement logic)
            // In development: panic to catch the bug immediately
            // In production: log error and reset counter to prevent permanent corruption
            debug_assert!(
                old_size >= to_send.len(),
                "Queue size counter underflowed! old_size={}, to_send.len()={} - this indicates a race condition in queue management",
                old_size,
                to_send.len()
            );

            if old_size < to_send.len() {
                log::error!(
                    "CRITICAL: Queue size counter underflowed! old_size={}, to_send.len()={} - resetting counter to 0. This indicates a bug in queue increment/decrement logic.",
                    old_size,
                    to_send.len()
                );
                queue_size_clone.store(0, Ordering::Release);
            }

            if !to_send.is_empty() {
                let dc = dc_clone.clone();
                let can_send_for_batch = can_send_clone.clone();
                let requeue_for_batch = requeue_clone.clone();
                let requeue_counter = queue_size_clone.clone();

                tokio::spawn(async move {
                    let total = to_send.len();
                    let mut failed_at = total; // assume all succeed

                    for (i, frame) in to_send.iter().enumerate() {
                        // Timeout prevents blocking on SCTP semaphore during congestion
                        match tokio::time::timeout(DC_SEND_TIMEOUT, dc.send(frame.clone())).await {
                            Ok(Ok(_)) => continue,
                            Ok(Err(_)) | Err(_) => {
                                can_send_for_batch.store(false, Ordering::Release);
                                failed_at = i;
                                break;
                            }
                        }
                    }

                    // Re-queue unsent frames into the priority requeue_frames queue
                    // to preserve strict ordering on the next drain cycle.
                    if failed_at < total {
                        let unsent = &to_send[failed_at..];
                        let requeue_count = unsent.len();
                        for frame in unsent {
                            requeue_for_batch.push(frame.clone());
                        }
                        requeue_counter.fetch_add(requeue_count, Ordering::AcqRel);
                    }
                });
            }
        })));

        sender
    }

    /// Send with zero-polling natural backpressure (lock-free!)
    /// Returns immediately - either sends or queues for later
    pub async fn send_with_natural_backpressure(&self, frame: Bytes) -> Result<(), &'static str> {
        let frame_len = frame.len(); // Capture for logging

        // Fast path: send immediately if buffer has space AND no queued frames.
        // When queue is non-empty, ALL frames must go through the queue to preserve
        // strict ordering — otherwise a new frame could bypass older queued frames.
        if self.can_send.load(Ordering::Acquire) && self.queue_size.load(Ordering::Acquire) == 0 {
            // Timeout prevents blocking on SCTP's PendingQueue semaphore (128KB)
            // which causes outbound task starvation under congestion.
            match tokio::time::timeout(DC_SEND_TIMEOUT, self.data_channel.send(frame.clone())).await
            {
                Ok(Ok(_)) => return Ok(()),
                Ok(Err(e)) => {
                    let error_str = e.to_string();

                    // Detect permanent failures (WebRTC closed) vs temporary failures (buffer full)
                    // When WebRTC is permanently closed, we must return error to trigger cleanup
                    // Otherwise backend tasks become zombies, guacd keeps responding, 15s timeout leak
                    if error_str.contains("DataChannel is not opened")
                        || error_str.contains("Channel is closing")
                        || error_str.contains("closed")
                    {
                        // Permanent failure - WebRTC is dead, don't queue
                        // Only log once per channel to avoid spam during shutdown
                        if unlikely!(crate::logger::is_verbose_logging()) {
                            debug!(
                                "WebRTC permanently closed, failing send (frame_size: {} bytes)",
                                frame_len
                            );
                        }
                        return Err(DATACHANNEL_CLOSED_ERROR);
                    }

                    // Temporary failure (buffer full, congestion) - queue for retry
                    // Record retry attempt for exponential backoff tracking
                    self.retry_state.record_retry();
                    let attempts = self.retry_state.get_attempts();

                    if unlikely!(crate::logger::is_verbose_logging()) {
                        debug!(
                            "WebRTC send failed temporarily (frame_size: {} bytes, retry_attempt: {}), queueing for retry. Error: {}",
                            frame_len, attempts, e
                        );
                    }

                    self.can_send.store(false, Ordering::Release);
                    // Fall through to queueing
                }
                Err(_elapsed) => {
                    // Timeout: SCTP PendingQueue semaphore is full (congestion).
                    // Don't block — queue at application level for retry.
                    self.can_send.store(false, Ordering::Release);
                    // Fall through to queueing
                }
            }
        }

        // Slow path: queue for later when buffer drains (lock-free!)
        // CRITICAL: Check size BEFORE incrementing to avoid race condition where
        // counter is incremented but frame is never queued (window of incorrect state)
        let current_queue_size = self.queue_size.load(Ordering::Acquire);

        // Prevent unbounded growth - increased from 1000 to 10000 frames
        // Check BEFORE incrementing counter to maintain accurate queue depth
        // CRITICAL: Never drop frames for loss-intolerant protocols (RDP/SSH/SFTP)
        // Return error to trigger backpressure instead (caller pauses reads)
        if current_queue_size >= 10000 {
            // Track blocked frames for metrics
            self.frames_blocked.fetch_add(1, Ordering::Relaxed);

            warn!(
                "EventDrivenSender queue FULL - backpressure required (queue_size: {}, threshold: {}, frame_bytes: {})",
                current_queue_size,
                self.threshold,
                frame_len
            );
            // Return error to trigger backpressure - caller will pause reads
            // This prevents frame loss for loss-intolerant protocols
            return Err(QUEUE_FULL_ERROR);
        }

        // Queue monitoring: Track sustained high queue pressure for alerts (lock-free)
        const HIGH_QUEUE_THRESHOLD: usize = 7500; // 75% of max capacity
        const SUSTAINED_PRESSURE_DURATION: Duration = Duration::from_secs(30);

        if current_queue_size > HIGH_QUEUE_THRESHOLD {
            // Track when queue first exceeded threshold (lock-free compare-and-swap)
            let now_ns = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_nanos() as u64;

            // Only set if currently 0 (None) - lock-free initialization
            let _ = self.high_queue_start_ns.compare_exchange(
                0,
                now_ns,
                Ordering::AcqRel,
                Ordering::Acquire,
            );

            // Check if sustained pressure for alert threshold (lock-free read)
            let start_ns = self.high_queue_start_ns.load(Ordering::Acquire);
            if start_ns != 0 {
                let elapsed = Duration::from_nanos(now_ns.saturating_sub(start_ns));
                if elapsed >= SUSTAINED_PRESSURE_DURATION {
                    warn!(
                        "Sustained queue pressure detected: {}/10000 frames ({:.1}% full) for {:?} - network may be degraded",
                        current_queue_size,
                        (current_queue_size as f64 / 10000.0) * 100.0,
                        elapsed
                    );
                    // Record metrics for sustained pressure (non-blocking)
                    // Note: conversation_id not available here, will be tracked at channel level
                }
            }

            // Log warning at 75% threshold
            // Re-check queue size to avoid stale warnings if it dropped during processing
            let final_queue_size = self.queue_size.load(Ordering::Acquire);
            if final_queue_size > HIGH_QUEUE_THRESHOLD {
                warn!(
                    "EventDrivenSender queue critically high: {}/10000 frames ({:.1}% full) - backpressure active",
                    final_queue_size,
                    (final_queue_size as f64 / 10000.0) * 100.0
                );
            }
        } else {
            // Queue below threshold - reset tracking (lock-free)
            self.high_queue_start_ns.store(0, Ordering::Release); // 0 = None

            // Log at 50% threshold (every 500 frames for monitoring)
            if current_queue_size > 5000
                && current_queue_size.is_multiple_of(500)
                && unlikely!(crate::logger::is_verbose_logging())
            {
                debug!(
                    "EventDrivenSender queue growing: {}/10000 frames ({:.1}% full)",
                    current_queue_size,
                    (current_queue_size as f64 / 10000.0) * 100.0
                );
            }
        }

        // Push to queue FIRST (SegQueue::push is infallible - always succeeds)
        self.pending_frames.push(frame);

        // Then increment counter (atomic operation)
        // This ensures counter never exceeds actual queue size
        self.queue_size.fetch_add(1, Ordering::Release);

        // Reset retry state on successful queue (frame will be sent when buffer drains)
        self.retry_state.reset();

        Ok(()) // Queued successfully - no blocking!
    }

    /// Get retry statistics for monitoring (lock-free)
    #[allow(dead_code)] // Reserved for future metrics API
    pub fn get_retry_stats(&self) -> (usize, Option<Duration>) {
        let attempts = self.retry_state.get_attempts();
        let last_retry = self.retry_state.get_last_retry_elapsed();
        (attempts, last_retry)
    }

    /// Get queue depth for monitoring (lock-free)
    pub fn queue_depth(&self) -> usize {
        self.queue_size.load(Ordering::Acquire)
    }

    /// Check if sender can send immediately (useful for monitoring)
    pub fn can_send_immediate(&self) -> bool {
        self.can_send.load(Ordering::Acquire)
    }

    /// Check if queue depth exceeds threshold (for monitoring/alerting)
    pub fn is_over_threshold(&self) -> bool {
        self.queue_depth() as u64 > self.threshold
    }

    /// Get the configured threshold for monitoring
    pub fn get_threshold(&self) -> u64 {
        self.threshold
    }

    /// Get count of frames that were blocked (queue full) - for metrics
    #[allow(dead_code)] // Reserved for future metrics API
    pub fn get_frames_blocked(&self) -> usize {
        self.frames_blocked.load(Ordering::Acquire)
    }

    /// Check if queue has been high for sustained period (for alerts) - lock-free
    #[allow(dead_code)] // Reserved for future metrics API
    pub fn has_sustained_pressure(&self) -> bool {
        let start_ns = self.high_queue_start_ns.load(Ordering::Acquire);
        if start_ns == 0 {
            return false;
        }
        let now_ns = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;
        if now_ns >= start_ns {
            Duration::from_nanos(now_ns - start_ns) >= Duration::from_secs(30)
        } else {
            false // Clock went backwards
        }
    }
}

#[cfg(test)]
mod drain_callback_tests {
    use bytes::Bytes;
    use crossbeam_queue::SegQueue;
    use std::sync::atomic::{AtomicU32, AtomicUsize, Ordering};

    fn make_frame(seq: u32) -> Bytes {
        Bytes::from(seq.to_be_bytes().to_vec())
    }

    fn seq_of(frame: &Bytes) -> u32 {
        u32::from_be_bytes(frame[..4].try_into().unwrap())
    }

    /// Simulate the drain callback logic with a controllable "send" function.
    /// Returns the sequence numbers in the order they were "sent".
    fn simulate_drain_cycle(
        pending: &SegQueue<Bytes>,
        requeue: &SegQueue<Bytes>,
        queue_size: &AtomicUsize,
        batch_size: usize,
        send_fn: &dyn Fn(&Bytes) -> bool,
    ) -> Vec<u32> {
        let mut to_send = Vec::with_capacity(batch_size);

        // Pop requeue FIRST (priority), then pending
        while to_send.len() < batch_size {
            match requeue.pop() {
                Some(frame) => to_send.push(frame),
                None => break,
            }
        }
        while to_send.len() < batch_size {
            match pending.pop() {
                Some(frame) => to_send.push(frame),
                None => break,
            }
        }

        queue_size.fetch_sub(to_send.len(), Ordering::AcqRel);

        let mut sent = Vec::new();
        let mut failed_at = to_send.len();

        for (i, frame) in to_send.iter().enumerate() {
            if send_fn(frame) {
                sent.push(seq_of(frame));
            } else {
                failed_at = i;
                break;
            }
        }

        // Re-queue unsent frames to the separate requeue
        if failed_at < to_send.len() {
            let unsent = &to_send[failed_at..];
            for frame in unsent {
                requeue.push(frame.clone());
            }
            queue_size.fetch_add(unsent.len(), Ordering::AcqRel);
        }

        sent
    }

    #[test]
    fn test_drain_no_failures_sends_all() {
        let pending = SegQueue::new();
        let requeue = SegQueue::new();
        let queue_size = AtomicUsize::new(5);

        for i in 0..5 {
            pending.push(make_frame(i));
        }

        let sent = simulate_drain_cycle(&pending, &requeue, &queue_size, 10, &|_| true);

        assert_eq!(sent, vec![0, 1, 2, 3, 4]);
        assert_eq!(queue_size.load(Ordering::Acquire), 0);
        assert!(requeue.pop().is_none());
    }

    #[test]
    fn test_drain_partial_failure_requeues_unsent() {
        let pending = SegQueue::new();
        let requeue = SegQueue::new();
        let queue_size = AtomicUsize::new(5);

        for i in 0..5 {
            pending.push(make_frame(i));
        }

        // Fail on frame #2 (seq=2)
        let sent = simulate_drain_cycle(&pending, &requeue, &queue_size, 10, &|f| seq_of(f) < 2);

        assert_eq!(sent, vec![0, 1], "Only F0, F1 should be sent");
        assert_eq!(
            queue_size.load(Ordering::Acquire),
            3,
            "F2, F3, F4 should be requeued"
        );

        // Verify requeue contains F2, F3, F4 in order
        assert_eq!(seq_of(&requeue.pop().unwrap()), 2);
        assert_eq!(seq_of(&requeue.pop().unwrap()), 3);
        assert_eq!(seq_of(&requeue.pop().unwrap()), 4);
        assert!(requeue.pop().is_none());
    }

    #[test]
    fn test_requeue_drained_before_pending_preserves_ordering() {
        let pending = SegQueue::new();
        let requeue = SegQueue::new();
        let queue_size = AtomicUsize::new(0);

        // Simulate: F2, F3, F4 failed previously and are in requeue
        requeue.push(make_frame(2));
        requeue.push(make_frame(3));
        requeue.push(make_frame(4));
        queue_size.fetch_add(3, Ordering::AcqRel);

        // F5, F6, F7 arrived from producer while drain was running
        pending.push(make_frame(5));
        pending.push(make_frame(6));
        pending.push(make_frame(7));
        queue_size.fetch_add(3, Ordering::AcqRel);

        // Next drain: should send F2, F3, F4, F5, F6, F7 IN ORDER
        let sent = simulate_drain_cycle(&pending, &requeue, &queue_size, 10, &|_| true);

        assert_eq!(
            sent,
            vec![2, 3, 4, 5, 6, 7],
            "Requeued frames must precede new frames"
        );
        assert_eq!(queue_size.load(Ordering::Acquire), 0);
    }

    #[test]
    fn test_reorder_bug_with_single_queue() {
        // Demonstrates WHY a separate requeue is needed.
        // If we re-queue to the SAME queue (pending), ordering breaks.
        let pending = SegQueue::new();
        let queue_size = AtomicUsize::new(5);

        for i in 0..5 {
            pending.push(make_frame(i));
        }

        // Pop batch, simulate partial send failure at F2
        let mut batch = Vec::new();
        for _ in 0..5 {
            batch.push(pending.pop().unwrap());
        }
        queue_size.fetch_sub(5, Ordering::AcqRel);

        // F0, F1 sent OK. F2 fails.
        // Meanwhile, producer adds F10, F11 to pending
        pending.push(make_frame(10));
        pending.push(make_frame(11));
        queue_size.fetch_add(2, Ordering::AcqRel);

        // BAD: re-queue F2, F3, F4 to TAIL of same pending queue
        for frame in &batch[2..] {
            pending.push(frame.clone());
        }
        queue_size.fetch_add(3, Ordering::AcqRel);

        // Next drain from pending: F10, F11, F2, F3, F4 — OUT OF ORDER!
        let mut drain_order = Vec::new();
        while let Some(f) = pending.pop() {
            drain_order.push(seq_of(&f));
        }

        assert_eq!(
            drain_order,
            vec![10, 11, 2, 3, 4],
            "Single-queue requeue puts F10 before F2 — REORDERING BUG"
        );

        // F10 appears before F2: this is the security vulnerability
        let idx_f2 = drain_order.iter().position(|&s| s == 2).unwrap();
        let idx_f10 = drain_order.iter().position(|&s| s == 10).unwrap();
        assert!(
            idx_f10 < idx_f2,
            "Security: F10 (new) arrives before F2 (failed) — credential data mixing"
        );
    }

    #[test]
    fn test_multiple_drain_cycles_preserve_ordering() {
        let pending = SegQueue::new();
        let requeue = SegQueue::new();
        let queue_size = AtomicUsize::new(0);

        // Enqueue F0..F19
        for i in 0..20 {
            pending.push(make_frame(i));
            queue_size.fetch_add(1, Ordering::AcqRel);
        }

        let mut all_sent = Vec::new();
        let mut send_budget = 3u32; // Only allow 3 successful sends per cycle

        for _cycle in 0..20 {
            if queue_size.load(Ordering::Acquire) == 0 {
                break;
            }

            let cycle_sent_count = AtomicU32::new(0);
            let budget = send_budget;
            let sent = simulate_drain_cycle(&pending, &requeue, &queue_size, 5, &|_f| {
                if cycle_sent_count.load(Ordering::Acquire) < budget {
                    cycle_sent_count.fetch_add(1, Ordering::AcqRel);
                    true
                } else {
                    false
                }
            });
            all_sent.extend(sent);

            // Increase budget over time (simulates SCTP draining)
            send_budget = (send_budget + 1).min(10);
        }

        // Verify ALL frames sent
        assert_eq!(
            all_sent.len(),
            20,
            "All 20 frames should eventually be sent"
        );

        // Verify strict ordering
        for i in 1..all_sent.len() {
            assert!(
                all_sent[i] > all_sent[i - 1],
                "Ordering violation at index {}: seq {} followed by seq {}",
                i,
                all_sent[i - 1],
                all_sent[i]
            );
        }
    }

    #[test]
    fn test_first_frame_failure_requeues_entire_batch() {
        let pending = SegQueue::new();
        let requeue = SegQueue::new();
        let queue_size = AtomicUsize::new(3);

        pending.push(make_frame(0));
        pending.push(make_frame(1));
        pending.push(make_frame(2));

        // All sends fail
        let sent = simulate_drain_cycle(&pending, &requeue, &queue_size, 10, &|_| false);

        assert!(sent.is_empty(), "No frames should be sent");
        assert_eq!(
            queue_size.load(Ordering::Acquire),
            3,
            "All frames should be requeued"
        );

        // Verify requeue has all 3 in order
        assert_eq!(seq_of(&requeue.pop().unwrap()), 0);
        assert_eq!(seq_of(&requeue.pop().unwrap()), 1);
        assert_eq!(seq_of(&requeue.pop().unwrap()), 2);
    }
}

/// Tests proving that dc.send() blocking on SCTP's 128KB PendingQueue semaphore
/// causes outbound task starvation under congestion, and that a timeout fixes it.
#[cfg(test)]
mod sctp_send_timeout_tests {
    use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
    use std::sync::Arc;
    use std::time::{Duration, Instant};
    use tokio::sync::{Mutex, Semaphore};

    const QUEUE_PERMITS: usize = 4; // Smaller for fast tests

    /// Without timeout: dc.send() blocks on semaphore when drain is slow.
    /// Uses tokio::time::pause() for deterministic, instant execution.
    #[tokio::test]
    async fn test_send_blocks_under_congestion_without_timeout() {
        let sem = Arc::new(Semaphore::new(QUEUE_PERMITS));
        let done = Arc::new(AtomicBool::new(false));

        // Slow drainer: releases 1 permit every 50ms
        let drain_sem = sem.clone();
        let drain_done = done.clone();
        let drainer = tokio::spawn(async move {
            while !drain_done.load(Ordering::Acquire) {
                tokio::time::sleep(Duration::from_millis(50)).await;
                drain_sem.add_permits(1);
            }
        });

        // Send QUEUE_PERMITS + 5 messages — last 5 must wait for drain
        let mut blocked_count = 0usize;
        for _ in 0..(QUEUE_PERMITS + 5) {
            let before = Instant::now();
            let permit = sem.acquire().await.unwrap();
            permit.forget();
            if before.elapsed() >= Duration::from_millis(20) {
                blocked_count += 1;
            }
        }

        done.store(true, Ordering::Release);
        drainer.abort();

        assert!(
            blocked_count >= 3,
            "Expected at least 3 blocked sends, got {}",
            blocked_count
        );
    }

    /// With timeout: send never blocks longer than the timeout.
    /// Uses tokio::time::pause() for deterministic, instant execution.
    #[tokio::test]
    async fn test_send_timeout_prevents_long_block() {
        let sem = Arc::new(Semaphore::new(QUEUE_PERMITS));
        let done = Arc::new(AtomicBool::new(false));
        let timeouts = Arc::new(AtomicUsize::new(0));

        // Slow drainer: 50ms per permit
        let drain_sem = sem.clone();
        let drain_done = done.clone();
        let drainer = tokio::spawn(async move {
            while !drain_done.load(Ordering::Acquire) {
                tokio::time::sleep(Duration::from_millis(50)).await;
                drain_sem.add_permits(1);
            }
        });

        let send_timeout = Duration::from_millis(50);
        for _ in 0..(QUEUE_PERMITS + 10) {
            match tokio::time::timeout(send_timeout, sem.acquire()).await {
                Ok(Ok(permit)) => {
                    permit.forget();
                }
                _ => {
                    timeouts.fetch_add(1, Ordering::AcqRel);
                }
            }
        }

        done.store(true, Ordering::Release);
        drainer.abort();

        let timeout_count = timeouts.load(Ordering::Acquire);
        assert!(
            timeout_count > 0,
            "Should have timeouts under congestion, had {}",
            timeout_count
        );
    }

    /// Mutex starvation: write_loop holding mutex starves read_loop.
    /// Uses tokio::time::pause() for deterministic, instant execution.
    #[tokio::test]
    async fn test_read_loop_starved_by_write_loop_mutex() {
        let mutex = Arc::new(Mutex::new(()));
        let blocked = Arc::new(AtomicUsize::new(0));
        let done = Arc::new(AtomicBool::new(false));

        // Write loop holds mutex for 50ms per iteration
        let w_mutex = mutex.clone();
        let w_done = done.clone();
        let writer = tokio::spawn(async move {
            while !w_done.load(Ordering::Acquire) {
                let _lock = w_mutex.lock().await;
                tokio::time::sleep(Duration::from_millis(50)).await;
                drop(_lock);
                tokio::time::sleep(Duration::from_millis(1)).await;
            }
        });

        // Read loop tries to acquire mutex every 5ms
        let r_mutex = mutex.clone();
        let r_done = done.clone();
        let r_blocked = blocked.clone();
        let reader = tokio::spawn(async move {
            while !r_done.load(Ordering::Acquire) {
                let before = tokio::time::Instant::now();
                let _lock = r_mutex.lock().await;
                drop(_lock);
                if before.elapsed() > Duration::from_millis(10) {
                    r_blocked.fetch_add(1, Ordering::AcqRel);
                }
                tokio::time::sleep(Duration::from_millis(5)).await;
            }
        });

        // Let contention run for 500ms
        tokio::time::sleep(Duration::from_millis(500)).await;
        done.store(true, Ordering::Release);
        writer.abort();
        reader.abort();

        let block_count = blocked.load(Ordering::Acquire);
        assert!(
            block_count > 3,
            "Read loop should be starved by write loop, blocked only {} times",
            block_count
        );
    }
}
