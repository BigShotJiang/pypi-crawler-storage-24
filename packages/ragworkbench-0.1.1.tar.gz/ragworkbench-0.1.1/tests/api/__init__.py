"""Tests for API module."""
