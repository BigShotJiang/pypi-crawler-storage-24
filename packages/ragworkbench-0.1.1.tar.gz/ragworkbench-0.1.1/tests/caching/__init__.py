"""Tests for caching module."""
