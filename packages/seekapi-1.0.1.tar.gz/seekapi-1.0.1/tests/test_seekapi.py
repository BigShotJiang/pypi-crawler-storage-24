import os
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import seekapi


class _FakeContext:
    aws_request_id = "req-123"

    def __init__(self, remaining_ms: int) -> None:
        self._remaining_ms = remaining_ms

    def get_remaining_time_in_millis(self) -> int:
        return self._remaining_ms


class RunTimeoutTests(unittest.TestCase):
    def test_run_caps_network_timeouts_to_remaining_budget(self) -> None:
        event = {"job_uuid": "job-1", "execution_token": "tok", "input_presigned_url": "http://input"}
        ctx = _FakeContext(remaining_ms=3_000)

        with patch("seekapi.register_request_id") as register_mock, patch(
            "seekapi.get_input", return_value={"name": "Alice"}
        ) as get_input_mock, patch("seekapi.push_data") as push_data_mock:
            out = seekapi.run(event, ctx, lambda data: {"message": f"hello {data['name']}"})

        self.assertEqual(out["ok"], True)
        register_mock.assert_called_once_with("job-1", "req-123", timeout=1)
        get_input_mock.assert_called_once_with(event, timeout=1)
        push_data_mock.assert_called_once()
        self.assertEqual(push_data_mock.call_args.kwargs["timeout"], 1)

    def test_run_returns_failure_on_push_error(self) -> None:
        event = {"job_uuid": "job-1", "execution_token": "tok", "input_presigned_url": "http://input"}
        ctx = _FakeContext(remaining_ms=30_000)

        with patch("seekapi.get_input", return_value={"name": "Alice"}), patch(
            "seekapi.push_data", side_effect=TimeoutError("push timeout")
        ):
            out = seekapi.run(event, ctx, lambda data: {"message": f"hello {data['name']}"})

        self.assertEqual(out["ok"], False)
        self.assertEqual(out["error"]["code"], "WORKER_ERROR")
        self.assertIn("push timeout", out["error"]["message"])


if __name__ == "__main__":
    unittest.main()
