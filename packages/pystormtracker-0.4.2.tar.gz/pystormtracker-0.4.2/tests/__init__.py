"""Test suite for pystormtracker."""
