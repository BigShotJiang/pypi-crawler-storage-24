def hello() -> str:
    return "Hello from pty-mcp!"
