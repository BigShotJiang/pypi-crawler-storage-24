from __future__ import annotations

import json as _json_mod
import logging
import os
import subprocess
import sys
import tempfile
import time

from fastmcp import FastMCP

from codespine.config import SETTINGS

_LOGGER = logging.getLogger(__name__)

from codespine import __version__
from codespine.analysis.community import detect_communities, symbol_community
from codespine.analysis.context import build_symbol_context
from codespine.analysis.coupling import get_coupling
from codespine.analysis.deadcode import detect_dead_code as detect_dead_code_analysis
from codespine.analysis.flow import trace_execution_flows as trace_flows_analysis
from codespine.analysis.impact import analyze_impact
from codespine.diff.branch_diff import compare_branches as compare_branches_analysis
from codespine.overlay.git_state import current_head
from codespine.overlay.merge import overlay_summary
from codespine.search.hybrid import hybrid_search
from codespine.watch.watcher import (
    clear_overlay as clear_overlay_state,
    get_overlay_status as get_overlay_status_state,
    promote_overlay as promote_overlay_state,
)


def _json(data: dict) -> str:
    """Serialize response dict to a JSON string.

    FastMCP double-serialises dict return values on many transports (SSE,
    stdio) producing duplicate JSON payloads that waste ~50 K tokens/session.
    Returning a pre-serialised string guarantees a single TextContent block.
    """
    return _json_mod.dumps(data, separators=(",", ":"))


def _git_available(path: str) -> bool:
    """Return True if path is inside a git repository."""
    try:
        r = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=path,
            capture_output=True,
            timeout=5,
        )
        return r.returncode == 0
    except Exception:
        return False


def _resolve_repo_path(store, project: str | None, repo_path_provider) -> str:
    """Resolve the filesystem path for a given project_id, falling back to cwd."""
    if project:
        try:
            recs = store.query_records(
                "MATCH (p:Project) WHERE p.id = $pid RETURN p.path as path LIMIT 1",
                {"pid": project},
            )
            if recs and recs[0].get("path"):
                return recs[0]["path"]
        except Exception:
            pass
    return repo_path_provider()


def _no_symbols_response(note: str = "No symbols indexed. Run 'codespine analyse <path>' first.") -> str:
    return _json({"available": False, "note": note})


def _parse_indexed_at(raw) -> int:
    """Robustly parse an indexed_at value that may be str, int, float, or None."""
    if raw is None:
        return 0
    try:
        val = int(float(str(raw)))
        # Sanity check: must look like a Unix timestamp (> year 2000)
        return val if val > 946684800 else 0
    except (ValueError, TypeError):
        return 0


def _staleness_meta(
    store,
    response: dict,
    project: str | None = None,
    overlay_store=None,
    deep_scope: bool = False,
) -> str:
    """Inject index staleness metadata into every tool response and serialise.

    Adds ``index_age_seconds`` and ``stale_warning`` when the index is old.
    Returns a JSON string (not a dict) to avoid FastMCP double-serialisation.
    """
    try:
        if project:
            recs = store.query_records(
                "MATCH (p:Project) WHERE p.id = $pid RETURN p.indexed_at as ts",
                {"pid": project},
            )
        else:
            recs = store.query_records(
                "MATCH (p:Project) RETURN p.indexed_at as ts ORDER BY p.indexed_at ASC LIMIT 1"
            )
        if recs:
            ts = _parse_indexed_at(recs[0].get("ts"))
            if ts:
                age = int(time.time()) - ts
                response["index_age_seconds"] = age
                response["indexed_at_epoch"] = ts
                if age > 3600:
                    response["stale_warning"] = (
                        f"Index is {age // 3600}h {(age % 3600) // 60}m old. "
                        "Run analyse_project() or start_watch() to refresh."
                    )
    except Exception:
        pass
    if overlay_store is not None:
        try:
            summary = overlay_summary(overlay_store, project=project)
            response.update(summary)
            if project:
                meta = store.get_project_metadata(project) or {}
                response["base_indexed_commit"] = meta.get("indexed_commit", "")
                response["working_head_commit"] = current_head(meta.get("path") or response.get("path") or "")
            if deep_scope and summary.get("overlay_present"):
                response["overlay_excluded"] = True
                response["note"] = "Results reflect committed index only; uncommitted overlay changes are excluded."
        except Exception:
            pass
    return _json(response)


class _StoreProxy:
    """Wraps a GraphStore and hot-reloads from the read replica when the
    post-analyse sentinel file is touched.

    After `codespine analyse` finishes it copies the write DB to
    ``~/.codespine_db_read`` and writes ``~/.codespine_db_read.updated``.
    This proxy checks that sentinel's mtime before every attribute access and
    silently swaps in a fresh read-only GraphStore so the MCP daemon picks up
    the new index without restarting.
    """

    def __init__(self, store) -> None:
        object.__setattr__(self, "_store", store)
        object.__setattr__(self, "_sentinel", SETTINGS.db_snapshot_path + ".updated")
        object.__setattr__(self, "_last_mtime", self._sentinel_mtime())

    def _sentinel_mtime(self) -> float:
        try:
            return os.path.getmtime(object.__getattribute__(self, "_sentinel"))
        except FileNotFoundError:
            return 0.0

    def _maybe_reload(self) -> None:
        current = self._sentinel_mtime()
        if current > object.__getattribute__(self, "_last_mtime"):
            from codespine.db.store import GraphStore as _GS
            try:
                new_store = _GS(read_only=True)
                object.__setattr__(self, "_store", new_store)
                object.__setattr__(self, "_last_mtime", current)
                _LOGGER.info("MCP: hot-reloaded GraphStore from updated snapshot")
            except Exception as exc:
                _LOGGER.warning("MCP: hot-reload failed: %s", exc)

    def __getattr__(self, name: str):
        self._maybe_reload()
        return getattr(object.__getattribute__(self, "_store"), name)


def build_mcp_server(store, repo_path_provider):
    store = _StoreProxy(store)
    _raw_mcp = FastMCP("codespine")
    overlay_store = getattr(store, "overlay_store", None)

    # ── Anti-duplicate-JSON wrapper ────────────────────────────────────
    # FastMCP double-serialises dict return values on many transports,
    # producing duplicate JSON payloads that waste ~50 K tokens/session.
    # We intercept tool registration so every tool's dict return is
    # pre-serialised to a JSON string (single TextContent block).
    import functools as _functools

    class _JsonMCP:
        """Thin proxy that wraps tool functions to return JSON strings."""
        def __getattr__(self, name):
            return getattr(_raw_mcp, name)

        def tool(self, *args, **kwargs):
            original_decorator = _raw_mcp.tool(*args, **kwargs)
            def wrapper(fn):
                @_functools.wraps(fn)
                def json_fn(*a, **kw):
                    result = fn(*a, **kw)
                    if isinstance(result, dict):
                        return _json(result)
                    return result
                return original_decorator(json_fn)
            return wrapper

        def run(self):
            return _raw_mcp.run()

    mcp = _JsonMCP()

    # Background job state (per-server-instance, persists across tool calls)
    _watch: dict = {"proc": None, "path": None, "started_at": None, "interval": 30}
    _analyse: dict = {"proc": None, "path": None, "started_at": None, "log_path": None, "returncode": None}

    # ------------------------------------------------------------------
    # Connectivity / feature discovery
    # ------------------------------------------------------------------

    @mcp.tool()
    def ping():
        """Verify the MCP server is alive. Call this first to confirm connectivity."""
        return _json({"status": "ok", "version": __version__})

    @mcp.tool()
    def get_capabilities():
        """
        Return what is indexed and which features are available RIGHT NOW.
        Call this before other tools so you know what's ready without trial-and-error.
        Features marked false may need 'codespine analyse --deep' or optional dependencies.
        """
        try:
            projects = store.query_records(
                """
                MATCH (p:Project)
                RETURN p.id as id,
                       p.path as path,
                       p.indexed_at as indexed_at,
                       p.indexed_commit as indexed_commit,
                       p.overlay_dirty as overlay_dirty
                """
            )
        except Exception:
            # Old DB schema (pre-0.4.0) doesn't have indexed_at column yet.
            # Falls back gracefully; column is added next time 'analyse' runs.
            projects = store.query_records(
                "MATCH (p:Project) RETURN p.id as id, p.path as path"
            )
        sym_q = store.query_records("MATCH (s:Symbol) RETURN count(s) as count")
        comm_q = store.query_records("MATCH (c:Community) RETURN count(c) as count")
        flow_q = store.query_records("MATCH (f:Flow) RETURN count(f) as count")
        coup_q = store.query_records("MATCH ()-[r:CO_CHANGED_WITH]->() RETURN count(r) as count")

        from codespine.search.vector import _load_model
        has_embeddings = _load_model() is not None

        repo = repo_path_provider()
        git_ok = _git_available(repo)

        n_sym = sym_q[0]["count"] if sym_q else 0
        n_comm = comm_q[0]["count"] if comm_q else 0
        n_flows = flow_q[0]["count"] if flow_q else 0
        n_coup = coup_q[0]["count"] if coup_q else 0

        # Check if any symbols have embeddings stored
        emb_q = store.query_records(
            "MATCH (s:Symbol) WHERE s.embedding IS NOT NULL RETURN count(s) as count"
        )
        has_stored_embeddings = (emb_q[0]["count"] if emb_q else 0) > 0

        watch_running = _watch["proc"] is not None and _watch["proc"].poll() is None
        analyse_running = _analyse["proc"] is not None and _analyse["proc"].poll() is None
        overlay_meta = overlay_summary(overlay_store) if overlay_store is not None else {}
        overlay_status = get_overlay_status_state(store) if overlay_store is not None else []

        now = int(time.time())
        stale_projects = []
        for p in projects:
            ts = int(p.get("indexed_at") or 0)
            if ts and (now - ts) > 3600 and not watch_running:
                age_h = (now - ts) // 3600
                stale_projects.append(f"{p['id']} ({age_h}h old)")

        notes: dict[str, str] = {}
        if stale_projects:
            notes["stale_index"] = (
                f"Index is stale for: {', '.join(stale_projects)}. "
                "Run analyse_project() or start_watch() to refresh."
            )
        if not n_comm:
            notes["community_detection"] = "Run 'codespine analyse --deep' to enable"
        if not n_flows:
            notes["execution_flows"] = "Run 'codespine analyse --deep' to enable"
        if not n_coup:
            notes["change_coupling"] = "Run 'codespine analyse --deep' to enable"
        if not has_embeddings:
            notes["semantic_embeddings"] = "Install 'codespine[ml]' for real vector search (hash fallback active)"
        if not has_stored_embeddings and n_sym > 0:
            notes["stored_embeddings"] = "Symbols indexed without embeddings. Rerun 'codespine analyse --embed' for semantic search."
        if not git_ok:
            notes["git_log"] = "Not a git repository, or git is not installed"
            notes["git_diff"] = "Not a git repository, or git is not installed"
        if not watch_running:
            notes["watch_mode"] = (
                "Watch mode is not active. Call start_watch(path) to enable real-time re-indexing. "
                "RECOMMENDED: start watch mode during active development."
            )

        # Detect unresolved imports → hint about unindexed sibling projects
        unresolved_imports: dict[str, list[str]] = {}
        try:
            from codespine.indexer.engine import JavaIndexer as _JI
            unresolved_imports = _JI.detect_unresolved_imports(store)
            if unresolved_imports:
                pkgs = list(unresolved_imports.keys())[:5]
                notes["unresolved_imports"] = (
                    f"Imports from unindexed packages detected: {', '.join(pkgs)}. "
                    "Consider indexing these projects for complete cross-project tracing."
                )
        except Exception:
            pass

        return {
            "available": True,
            "indexed_projects": projects,
            "symbol_count": n_sym,
            **overlay_meta,
            "features": {
                "ping": True,
                "list_projects": True,
                "search_hybrid": n_sym > 0,
                "get_impact": n_sym > 0,
                "get_symbol_context": n_sym > 0,
                "detect_dead_code": n_sym > 0,
                "trace_execution_flows": n_sym > 0,
                "community_detection": n_comm > 0,
                "execution_flows": n_flows > 0,
                "change_coupling": n_coup > 0,
                "semantic_embeddings": has_embeddings,
                "stored_embeddings": has_stored_embeddings,
                "git_log": git_ok,
                "git_diff": git_ok,
                "compare_branches": git_ok,
                "get_neighborhood": n_sym > 0,
                "reindex_file": True,
                "watch_mode": True,
                "analyse_project": True,
                "get_overlay_status": True,
                "promote_overlay": True,
                "clear_overlay": True,
                "force_reset_index": True,
            },
            "background_jobs": {
                "watch_running": watch_running,
                "watch_path": _watch["path"] if watch_running else None,
                "analyse_running": analyse_running,
                "analyse_path": _analyse["path"] if analyse_running else None,
            },
            "overlay_projects": overlay_status,
            "notes": notes,
        }

    # ------------------------------------------------------------------
    # Guide – static tool catalog + workflows for agents
    # ------------------------------------------------------------------

    @mcp.tool()
    def guide():
        """
        How to use CodeSpine: system overview, tool catalog, recommended
        workflows, and tips.  Call this FIRST if you have never used
        CodeSpine before.  For live index state (what is indexed right now),
        call get_capabilities() instead.
        """
        from codespine.guide import GUIDE_SECTIONS

        return _json({"version": __version__, "sections": GUIDE_SECTIONS})

    # ------------------------------------------------------------------
    # Project listing
    # ------------------------------------------------------------------

    @mcp.tool()
    def list_projects():
        """List all indexed projects with their symbol and file counts."""
        try:
            projects = store.query_records(
                "MATCH (p:Project) RETURN p.id as id, p.path as path, p.indexed_at as indexed_at"
            )
        except Exception:
            projects = store.query_records(
                "MATCH (p:Project) RETURN p.id as id, p.path as path"
            )
        if not projects:
            return {"available": False, "note": "No projects indexed yet. Run 'codespine analyse <path>'."}
        now = int(time.time())
        result = []
        for p in projects:
            sym = store.query_records(
                """
                MATCH (s:Symbol), (f:File)
                WHERE s.file_id = f.id AND f.project_id = $pid
                RETURN count(s) as count
                """,
                {"pid": p["id"]},
            )
            files = store.query_records(
                "MATCH (f:File) WHERE f.project_id = $pid RETURN count(f) as count",
                {"pid": p["id"]},
            )
            indexed_at_ts = int(p.get("indexed_at") or 0)
            age_s = now - indexed_at_ts if indexed_at_ts else None
            entry: dict = {
                "project_id": p["id"],
                "path": p["path"],
                "symbol_count": sym[0]["count"] if sym else 0,
                "file_count": files[0]["count"] if files else 0,
                "indexed_at_epoch": indexed_at_ts or None,
                "index_age_seconds": age_s,
            }
            if age_s is not None and age_s > 3600:
                entry["stale_warning"] = (
                    f"Index is {age_s // 3600}h {(age_s % 3600) // 60}m old. "
                    "Run analyse_project() or start_watch() to refresh."
                )
            result.append(entry)
        return {"available": True, "projects": result}

    # ------------------------------------------------------------------
    # Search & analysis (all support optional project scoping)
    # ------------------------------------------------------------------

    @mcp.tool()
    def search_hybrid(query: str, k: int = 20, project: str | None = None):
        """
        Hybrid symbol search (BM25 + vector + fuzzy, fused with RRF).
        Pass project=<project_id> to scope results to a single indexed project.
        Use list_projects to see available project IDs.
        """
        results = hybrid_search(store, query, k=k, project=project)
        if not results:
            return _no_symbols_response()
        return _staleness_meta(store, {"available": True, "results": results}, project, overlay_store=overlay_store)

    @mcp.tool()
    def get_impact(symbol: str, max_depth: int = 4, project: str | None = None):
        """
        Caller-tree impact analysis for a symbol.
        project scopes the target symbol lookup; cross-project callers are always included.
        """
        result = analyze_impact(store, symbol, max_depth=max_depth, project=project)
        if not result.get("targets_resolved"):
            return {"available": False, "note": f"Symbol '{symbol}' not found in the index."}
        return _staleness_meta(store, {"available": True, **result}, project, overlay_store=overlay_store)

    @mcp.tool()
    def detect_dead_code(limit: int = 200, project: str | None = None, strict: bool = False):
        """
        Detect methods with no incoming calls (after Java-aware exemptions).
        Pass project to scope to a single module.

        Parameters:
          strict – When True, only main()/@Test and explicit entry-point
                   annotations are exempted. Constructors, getters/setters,
                   contract methods (toString, hashCode, equals), and method
                   overrides are NOT exempt. Use this for a thorough audit.
                   Each result includes a confidence level (high/medium/low):
                     high   = private method, almost certainly dead
                     medium = package-private or protected
                     low    = public method, could be called via reflection

        Returns dead_code list, count, and an exemption_stats dict showing
        how many candidates were found and how many were filtered out by the
        exemption rules — useful for validating that the feature is working
        even when the dead list is empty.
        """
        raw = detect_dead_code_analysis(store, limit=limit, project=project, strict=strict)
        if raw is None:
            return _no_symbols_response()

        # Separate the sentinel stats entry appended by the analysis function.
        stats: dict = {}
        dead = []
        for entry in raw:
            if "_stats" in entry:
                stats = entry["_stats"]
            else:
                dead.append(entry)

        return _staleness_meta(store, {
            "available": True,
            "dead_code": dead,
            "count": len(dead),
            "exemption_stats": stats,
        }, project, overlay_store=overlay_store, deep_scope=True)

    @mcp.tool()
    def trace_execution_flows(entry_symbol: str | None = None, max_depth: int = 6, project: str | None = None):
        """
        Trace execution flows from entry points (main methods, tests).
        Pass project to scope entry-point discovery to a single module.
        """
        flows = trace_flows_analysis(store, entry_symbol=entry_symbol, max_depth=max_depth, project=project)
        if not flows:
            return _no_symbols_response("No entry points found. Run 'codespine analyse --deep' or provide entry_symbol.")
        return _staleness_meta(store, {"available": True, "flows": flows}, project, overlay_store=overlay_store, deep_scope=True)

    @mcp.tool()
    def get_symbol_community(symbol: str):
        """Return the architectural community cluster a symbol belongs to."""
        # NOTE: do NOT call detect_communities() here — the MCP server opens the
        # graph DB read-only, so any write attempt raises "Cannot execute write
        # operations in a read-only database!".  Communities are computed once
        # during 'codespine analyse --deep' and persisted; we just read them.
        result = symbol_community(store, symbol)
        if not result.get("matches"):
            return {"available": False, "note": "No community data yet. Run 'codespine analyse --deep'."}
        return _staleness_meta(store, {"available": True, **result}, overlay_store=overlay_store, deep_scope=True)

    @mcp.tool()
    def get_change_coupling(
        symbol: str | None = None,
        months: int = 6,
        min_strength: float = 0.3,
        min_cochanges: int = 3,
    ):
        """
        Files that historically change together (git co-change coupling).
        Requires 'codespine analyse --deep' to have been run.
        """
        result = get_coupling(store, symbol=symbol, months=months, min_strength=min_strength, min_cochanges=min_cochanges)
        if not result:
            return {
                "available": False,
                "note": "No coupling data. Run 'codespine analyse --deep' with a git repository.",
            }
        return _staleness_meta(store, {"available": True, "coupling": result}, overlay_store=overlay_store, deep_scope=True)

    @mcp.tool()
    def get_symbol_context(query: str, max_depth: int = 3, project: str | None = None):
        """
        One-shot deep context for a symbol: search + impact + community + flows.
        Pass project to scope the search to a single indexed module.
        """
        result = build_symbol_context(store, query, max_depth=max_depth, project=project)
        if not result.get("search_candidates"):
            return _no_symbols_response()
        return _staleness_meta(store, {"available": True, **result}, project, overlay_store=overlay_store)

    @mcp.tool()
    def get_codebase_stats():
        """
        Per-project and aggregate stats: files, classes, methods, call edges, embeddings.

        Use this to understand the size and coverage of each indexed project before
        deciding which project= scope to pass to analysis tools.
        """
        projects = store.query_records(
            """
            MATCH (p:Project)
            RETURN p.id as id, p.path as path, p.indexed_commit as indexed_commit, p.overlay_dirty as overlay_dirty
            ORDER BY p.id
            """
        )
        if not projects:
            return {"available": False, "note": "No projects indexed yet. Run 'codespine analyse <path>'."}

        per_project = []
        total_files = total_classes = total_methods = total_calls = total_emb = 0
        for p in projects:
            pid = p["id"]
            files = store.query_records(
                "MATCH (f:File) WHERE f.project_id = $pid RETURN count(f) as n", {"pid": pid}
            )
            classes = store.query_records(
                "MATCH (c:Class), (f:File) WHERE c.file_id = f.id AND f.project_id = $pid RETURN count(c) as n",
                {"pid": pid},
            )
            methods = store.query_records(
                "MATCH (m:Method), (c:Class), (f:File) WHERE m.class_id = c.id AND c.file_id = f.id AND f.project_id = $pid RETURN count(m) as n",
                {"pid": pid},
            )
            calls = store.query_records(
                "MATCH (ma:Method)-[:CALLS]->(mb:Method), (ca:Class), (fa:File) WHERE ma.class_id = ca.id AND ca.file_id = fa.id AND fa.project_id = $pid RETURN count(*) as n",
                {"pid": pid},
            )
            emb = store.query_records(
                "MATCH (s:Symbol), (f:File) WHERE s.file_id = f.id AND f.project_id = $pid AND s.embedding IS NOT NULL RETURN count(s) as n",
                {"pid": pid},
            )
            n_files = files[0]["n"] if files else 0
            n_classes = classes[0]["n"] if classes else 0
            n_methods = methods[0]["n"] if methods else 0
            n_calls = calls[0]["n"] if calls else 0
            n_emb = emb[0]["n"] if emb else 0
            per_project.append({
                "project_id": pid,
                "path": p["path"],
                "files": n_files,
                "classes": n_classes,
                "methods": n_methods,
                "calls_out": n_calls,
                "embeddings": n_emb,
                "indexed_commit": p.get("indexed_commit", ""),
                "overlay_dirty": bool(p.get("overlay_dirty", False)),
            })
            total_files += n_files
            total_classes += n_classes
            total_methods += n_methods
            total_calls += n_calls
            total_emb += n_emb

        return _staleness_meta(store, {
            "available": True,
            "per_project": per_project,
            "totals": {
                "projects": len(projects),
                "files": total_files,
                "classes": total_classes,
                "methods": total_methods,
                "calls": total_calls,
                "embeddings": total_emb,
            },
        }, overlay_store=overlay_store)

    # ------------------------------------------------------------------
    # Ambiguity resolution + structural exploration
    # ------------------------------------------------------------------

    @mcp.tool()
    def find_symbol(
        name: str,
        kind: str | None = None,
        project: str | None = None,
        limit: int = 50,
    ):
        """
        Exact / prefix name lookup – returns ALL matching symbols across every project.

        Use this to resolve ambiguity when a name appears in multiple projects or
        packages. Unlike search_hybrid (which ranks by relevance), find_symbol
        returns every match so you can inspect the full set and pick the right one.

        Parameters:
          name    – Simple class/method name, fully-qualified name, or prefix.
                    Matching is case-insensitive on the simple name; exact on the FQCN.
          kind    – Optional filter: "class" or "method".
          project – Optional project_id to restrict the search.
          limit   – Max results per kind (default 50).

        Returns results grouped by kind and project, each with:
          id, name, fqname, project_id, file_path, line, col.
        """
        name_lower = name.lower()
        project_clause = "AND f.project_id = $proj" if project else ""
        # Note: only $namel and $lim are referenced in the queries below.
        # Do NOT add extra keys here — some Kuzu versions raise "Parameter not found"
        # when the params dict contains keys absent from the query string.
        params: dict = {"namel": name_lower, "lim": limit}
        if project:
            params["proj"] = project

        from codespine.overlay.merge import merged_class_records, merged_method_records

        classes: list[dict] = []
        methods: list[dict] = []
        if kind != "method":
            for rec in merged_class_records(store, overlay_store, project=project):
                rec_name = str(rec.get("name") or "").lower()
                rec_fqcn = str(rec.get("fqcn") or "").lower()
                if rec_name == name_lower or rec_fqcn == name_lower or name_lower in rec_fqcn or name_lower in rec_name:
                    classes.append(
                        {
                            "id": rec.get("id"),
                            "name": rec.get("name"),
                            "fqname": rec.get("fqcn"),
                            "package": rec.get("package"),
                            "project_id": rec.get("project_id"),
                            "file_path": rec.get("file_path"),
                        }
                    )
                    if len(classes) >= limit:
                        break

        if kind != "class":
            for rec in merged_method_records(store, overlay_store, project=project):
                rec_name = str(rec.get("name") or "").lower()
                signature = str(rec.get("signature") or "").lower()
                if rec_name == name_lower or name_lower in signature:
                    methods.append(
                        {
                            "id": rec.get("id"),
                            "name": rec.get("name"),
                            "fqname": rec.get("signature"),
                            "class_fqcn": rec.get("class_fqcn"),
                            "project_id": rec.get("project_id"),
                            "file_path": rec.get("file_path"),
                            "return_type": rec.get("return_type"),
                        }
                    )
                    if len(methods) >= limit:
                        break

        total = len(classes) + len(methods)
        if total == 0:
            return {
                "available": False,
                "note": f"No symbols found matching '{name}'. Try a shorter prefix or use search_hybrid for fuzzy matching.",
            }

        # Group by project_id so agents can see the landscape at a glance
        by_project: dict[str, dict] = {}
        for c in classes:
            pid = c.get("project_id", "?")
            by_project.setdefault(pid, {"classes": [], "methods": []})
            by_project[pid]["classes"].append(c)
        for m in methods:
            pid = m.get("project_id", "?")
            by_project.setdefault(pid, {"classes": [], "methods": []})
            by_project[pid]["methods"].append(m)

        return _staleness_meta(store, {
            "available": True,
            "query": name,
            "total_matches": total,
            "by_project": by_project,
            "note": (
                f"Found {total} match(es). If multiple projects contain the same name, "
                "pass project=<project_id> to subsequent tools to avoid cross-project ambiguity."
            ) if total > 1 else None,
        }, project, overlay_store=overlay_store)

    @mcp.tool()
    def get_overlay_status(project: str | None = None):
        """Report uncommitted overlay state by project/module."""
        return _staleness_meta(
            store,
            {"available": True, "overlay": get_overlay_status_state(store, project=project)},
            project,
            overlay_store=overlay_store,
        )

    @mcp.tool()
    def promote_overlay(project: str | None = None):
        """Promote dirty overlay state into the committed base index immediately."""
        result = promote_overlay_state(store, project=project, require_head_change=False)
        return _staleness_meta(
            store,
            {"available": True, "promoted": result},
            project,
            overlay_store=overlay_store,
        )

    @mcp.tool()
    def clear_overlay(project: str | None = None):
        """Discard dirty overlay state without changing the committed base index."""
        result = clear_overlay_state(store, project=project)
        return _staleness_meta(
            store,
            {"available": True, "cleared": result},
            project,
            overlay_store=overlay_store,
        )

    @mcp.tool()
    def list_packages(project: str | None = None, limit: int = 200):
        """
        List all Java packages in the index, optionally scoped to one project.

        Use this to explore the structural layout of a codebase before searching.
        Returns each package with the project it belongs to and a class count,
        sorted by project then package.

        Tip: when you have multiple projects with overlapping package names (e.g.
        both have 'com.example.service'), pass project= to the other tools to avoid
        mixing results from different codebases.
        """
        project_clause = "AND f.project_id = $proj" if project else ""
        params: dict = {"lim": limit}
        if project:
            params["proj"] = project

        recs = store.query_records(
            f"""
            MATCH (c:Class), (f:File)
            WHERE c.file_id = f.id {project_clause}
            RETURN c.package as package, f.project_id as project_id, count(c) as class_count
            ORDER BY project_id, package
            LIMIT $lim
            """,
            params,
        )
        if not recs:
            return _no_symbols_response("No packages found. Run 'codespine analyse <path>' first.")

        # Group by project
        by_project: dict[str, list[dict]] = {}
        for r in recs:
            pid = r.get("project_id", "?")
            by_project.setdefault(pid, [])
            by_project[pid].append({
                "package": r.get("package") or "(default)",
                "class_count": r.get("class_count", 0),
            })

        return _staleness_meta(store, {
            "available": True,
            "total_packages": len(recs),
            "by_project": by_project,
        }, project, overlay_store=overlay_store)

    # ------------------------------------------------------------------
    # Git tools
    # ------------------------------------------------------------------

    @mcp.tool()
    def git_log(file_path: str | None = None, limit: int = 20, project: str | None = None):
        """
        Recent git commits for the project (or a specific file).
        Returns available=false if the directory is not a git repository.
        Use project=<project_id> to target a specific indexed module's repo.
        TIP: Always pass project= to ensure the correct repo is used.
        """
        repo = _resolve_repo_path(store, project, repo_path_provider)
        if not os.path.isdir(repo):
            return {
                "available": False,
                "note": f"Path does not exist: {repo}. Pass project=<project_id> to resolve the repo from the index.",
            }
        if not _git_available(repo):
            return {
                "available": False,
                "note": (
                    f"Not a git repository at {repo}. "
                    "Pass project=<project_id> so the tool resolves the correct repo root. "
                    "Use list_projects() to see available IDs."
                ),
            }
        cmd = ["git", "log", f"--max-count={limit}", "--oneline", "--no-decorate"]
        if file_path:
            cmd += ["--", file_path]
        r = subprocess.run(cmd, cwd=repo, capture_output=True, text=True, timeout=30)
        if r.returncode != 0:
            return {"available": False, "error": r.stderr.strip(), "repo_path": repo}
        log_lines = r.stdout.strip().splitlines()
        return {
            "available": True,
            "project": project or repo,
            "repo_path": repo,
            "log": log_lines,
            "note": f"{len(log_lines)} commit(s)" + (" (no commits yet)" if not log_lines else ""),
        }

    @mcp.tool()
    def git_diff(ref: str = "HEAD", file_path: str | None = None, project: str | None = None):
        """
        Show git diff (working tree vs ref, or between two refs separated by '...').
        Output is truncated to 200 lines.
        Returns available=false if the directory is not a git repository.
        TIP: Always pass project= to ensure the correct repo is used.
        """
        repo = _resolve_repo_path(store, project, repo_path_provider)
        if not os.path.isdir(repo):
            return {
                "available": False,
                "note": f"Path does not exist: {repo}. Pass project=<project_id> to resolve the repo from the index.",
            }
        if not _git_available(repo):
            return {
                "available": False,
                "note": (
                    f"Not a git repository at {repo}. "
                    "Pass project=<project_id> so the tool resolves the correct repo root. "
                    "Use list_projects() to see available IDs."
                ),
            }
        cmd = ["git", "diff", ref]
        if file_path:
            cmd += ["--", file_path]
        r = subprocess.run(cmd, cwd=repo, capture_output=True, text=True, timeout=30)
        if r.returncode != 0:
            return {"available": False, "error": r.stderr.strip(), "repo_path": repo}
        lines = r.stdout.splitlines()
        truncated = False
        if len(lines) > 200:
            lines = lines[:200]
            truncated = True
        diff_text = "\n".join(lines)
        return {
            "available": True,
            "project": project or repo,
            "repo_path": repo,
            "diff": diff_text,
            "truncated": truncated,
            "note": f"{len(lines)} line(s)" + (" — no changes" if not diff_text.strip() else ""),
        }

    @mcp.tool()
    def compare_branches(base_ref: str, head_ref: str, project: str | None = None):
        """
        Symbol-level diff between two git refs (branches, tags, commits).
        Pass project=<project_id> so the tool can resolve the correct git
        repository root from the indexed project path rather than relying on
        the MCP server's working directory (which may point to the graph DB
        location, not the source tree).
        """
        repo = _resolve_repo_path(store, project, repo_path_provider)
        if not _git_available(repo):
            return {
                "available": False,
                "note": (
                    "Not a git repository (or git not installed). "
                    "Pass project=<project_id> so the tool can resolve the repo "
                    "from the indexed project path. Use list_projects() to see available IDs."
                ),
            }
        result = compare_branches_analysis(repo, base_ref, head_ref)
        return {"available": True, **result}

    # ------------------------------------------------------------------
    # Watch mode tools
    # ------------------------------------------------------------------

    @mcp.tool()
    def start_watch(
        path: str,
        global_interval: int = 30,
        overlay_debounce_ms: int = 1500,
        promote_on_commit: bool = True,
    ):
        """
        Start watching a project directory for Java file changes and update the dirty overlay.

        Watch mode monitors .java files for changes, debounces saves, and updates
        the dirty overlay instead of mutating the committed base index immediately.
        When local HEAD changes, dirty overlay state is promoted into the base index.

        Fast tools (search/context/impact) read merged base+overlay state. Deep
        analyses stay on the committed base index until promotion.

        Returns the PID of the background watch process and the path being watched.
        Use get_watch_status() to check if it's still running.
        Use stop_watch() to stop it.
        """
        import os

        # Stop any previous watch process first
        if _watch["proc"] is not None and _watch["proc"].poll() is None:
            return {
                "available": True,
                "running": True,
                "path": _watch["path"],
                "pid": _watch["proc"].pid,
                "note": "Watch mode already running. Call stop_watch() first to restart on a different path.",
            }

        abs_path = os.path.abspath(path)
        if not os.path.isdir(abs_path):
            return {"available": False, "note": f"Path does not exist or is not a directory: {abs_path}"}

        import tempfile as _tempfile
        watch_err_file = _tempfile.NamedTemporaryFile(
            mode="w", suffix=".log", prefix="codespine_watch_", delete=False
        )
        watch_err_path = watch_err_file.name
        watch_err_file.close()

        cmd = [
            sys.executable, "-m", "codespine.cli",
            "watch", "--path", abs_path,
            "--global-interval", str(global_interval),
            "--overlay-debounce-ms", str(overlay_debounce_ms),
        ]
        if not promote_on_commit:
            cmd.append("--no-promote-on-commit")

        proc = subprocess.Popen(
            cmd,
            stdout=open(watch_err_path, "w", encoding="utf-8"),
            stderr=subprocess.STDOUT,
        )

        # Brief health check — if the process dies within 1 s it crashed at startup.
        time.sleep(1)
        if proc.poll() is not None:
            try:
                with open(watch_err_path, "r", encoding="utf-8", errors="replace") as fh:
                    err_tail = fh.read().strip().splitlines()[-10:]
            except Exception:
                err_tail = []
            return {
                "available": False,
                "note": (
                    f"Watch mode process exited immediately (code {proc.returncode}). "
                    "Check that the path is valid and watchfiles is installed."
                ),
                "error_tail": err_tail,
            }

        _watch["proc"] = proc
        _watch["path"] = abs_path
        _watch["started_at"] = time.time()
        _watch["interval"] = global_interval

        return {
            "available": True,
            "running": True,
            "path": abs_path,
            "pid": proc.pid,
            "global_interval_s": global_interval,
            "overlay_debounce_ms": overlay_debounce_ms,
            "promote_on_commit": promote_on_commit,
            "note": (
                "Watch mode started. CodeSpine will update the dirty overlay after Java file changes "
                "and promote it into the committed index when local HEAD changes."
            ),
        }

    @mcp.tool()
    def stop_watch():
        """Stop the background watch mode process."""
        import signal as _signal

        proc = _watch.get("proc")
        if proc is None or proc.poll() is not None:
            _watch["proc"] = None
            _watch["path"] = None
            return {"available": True, "running": False, "note": "Watch mode was not running."}

        path = _watch["path"]
        try:
            proc.send_signal(_signal.SIGTERM)
            proc.wait(timeout=5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        _watch["proc"] = None
        _watch["path"] = None
        _watch["started_at"] = None
        return {"available": True, "running": False, "stopped_path": path}

    @mcp.tool()
    def get_watch_status():
        """Get the current status of watch mode (running/stopped, path, uptime)."""
        proc = _watch.get("proc")
        running = proc is not None and proc.poll() is None
        result: dict = {"available": True, "running": running}
        if running:
            result["path"] = _watch["path"]
            result["pid"] = proc.pid
            result["global_interval_s"] = _watch.get("interval", 30)
            started = _watch.get("started_at")
            if started:
                result["uptime_s"] = round(time.time() - started)
        else:
            result["note"] = (
                "Watch mode is not running. Call start_watch(path) to enable real-time re-indexing. "
                "RECOMMENDED during active development."
            )
        return result

    # ------------------------------------------------------------------
    # Analysis trigger tools
    # ------------------------------------------------------------------

    @mcp.tool()
    def analyse_project(
        path: str,
        full: bool = False,
        deep: bool = False,
        embed: bool = False,
    ):
        """
        Trigger indexing of a Java project (or workspace) as a background job.

        This starts 'codespine analyse' in a subprocess and returns immediately.
        Use get_analyse_status() to poll progress and completion.

        Parameters:
          path  – Absolute or relative path to the project/workspace to index.
          full  – If True, re-index every file even if unchanged (default: incremental).
          deep  – If True, also run community detection, flows, and coupling (slower).
          embed – If True, generate vector embeddings for semantic search (slow when
                  sentence-transformers is installed; BM25/fuzzy search works without them).

        RECOMMENDATION: Run without embed=True first for a fast initial index (<1 min).
        Add --embed later if you need semantic similarity search.
        """
        import os

        # If already running an analysis, report status instead of starting another
        if _analyse["proc"] is not None and _analyse["proc"].poll() is None:
            return {
                "available": True,
                "running": True,
                "path": _analyse["path"],
                "note": "Analysis already running. Call get_analyse_status() to check progress.",
            }

        abs_path = os.path.abspath(path)
        if not os.path.isdir(abs_path):
            return {"available": False, "note": f"Path does not exist or is not a directory: {abs_path}"}

        cmd = [sys.executable, "-m", "codespine.cli", "analyse", abs_path, "--allow-running"]
        if full:
            cmd.append("--full")
        else:
            cmd.append("--incremental")
        if deep:
            cmd.append("--deep")
        if embed:
            cmd.append("--embed")
        else:
            cmd.append("--no-embed")

        # Capture output to a temp file for progress inspection
        log_file = tempfile.NamedTemporaryFile(
            mode="w", suffix=".log", prefix="codespine_analyse_", delete=False
        )
        log_path = log_file.name
        log_file.close()

        proc = subprocess.Popen(
            cmd,
            stdout=open(log_path, "w", encoding="utf-8"),
            stderr=subprocess.STDOUT,
        )
        _analyse["proc"] = proc
        _analyse["path"] = abs_path
        _analyse["started_at"] = time.time()
        _analyse["log_path"] = log_path
        _analyse["returncode"] = None

        embed_note = " (with embeddings)" if embed else " (no embeddings – fast)"
        deep_note = " + deep analyses" if deep else ""
        return {
            "available": True,
            "running": True,
            "path": abs_path,
            "pid": proc.pid,
            "log_path": log_path,
            "note": (
                f"Analysis started{embed_note}{deep_note}. "
                "Call get_analyse_status() to check progress. "
                "Results will be available in the index as soon as the job completes."
            ),
        }

    @mcp.tool()
    def get_analyse_status():
        """
        Get the status of the current or most recent background analysis job.

        Returns running=True while analysis is in progress.
        Returns running=False with elapsed_s and tail of output when done.
        """
        proc = _analyse.get("proc")
        if proc is None:
            return {
                "available": True,
                "running": False,
                "note": "No analysis has been started this session. Call analyse_project(path) to begin.",
            }

        rc = proc.poll()
        running = rc is None
        started = _analyse.get("started_at") or time.time()
        elapsed = round(time.time() - started)

        result: dict = {
            "available": True,
            "running": running,
            "path": _analyse["path"],
            "elapsed_s": elapsed,
        }

        if not running:
            result["returncode"] = rc
            result["success"] = rc == 0

        # Read last 30 lines of output log for context
        log_path = _analyse.get("log_path")
        if log_path:
            try:
                with open(log_path, "r", encoding="utf-8", errors="replace") as fh:
                    lines = fh.read().splitlines()
                result["output_tail"] = lines[-30:] if len(lines) > 30 else lines
            except Exception:
                pass

        if running:
            result["note"] = f"Analysis in progress ({elapsed}s elapsed). Call get_analyse_status() again to check."
        elif rc == 0:
            result["note"] = f"Analysis completed successfully in {elapsed}s. Index is now updated."
        else:
            result["note"] = f"Analysis exited with code {rc} after {elapsed}s. Check output_tail for errors."

        return result

    # ------------------------------------------------------------------
    # Index reset tools
    # ------------------------------------------------------------------

    @mcp.tool()
    def reset_project(project_id: str):
        """
        Remove all indexed data for a single project – clean slate for that project.

        Deletes the project's files, classes, methods, symbols, and the Project
        node itself from the graph. The meta cache is also cleared.

        This is different from watch mode (which tracks live changes) – reset
        removes everything so you can re-index from scratch with analyse_project().

        Typical workflow:
          1. reset_project("my-app")
          2. analyse_project("/path/to/my-app", full=True)

        Returns the project path that was cleared (for confirmation).
        """
        import os as _os

        # Look up path before clearing so we can return it and suggest re-indexing
        recs = store.query_records(
            "MATCH (p:Project) WHERE p.id = $pid RETURN p.path as path LIMIT 1",
            {"pid": project_id},
        )
        if not recs:
            return {
                "available": False,
                "note": f"Project '{project_id}' not found. Use list_projects() to see available project IDs.",
            }
        project_path = recs[0].get("path", "")

        proc = subprocess.run(
            [sys.executable, "-m", "codespine.cli", "clear-project", project_id, "--allow-running"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if proc.returncode != 0:
            error_text = (proc.stderr.strip() or proc.stdout.strip())[:300]
            return {
                "available": False,
                "note": (
                    f"Reset failed: {error_text}. "
                    "If this is a buffer pool or DB corruption error, use force_reset_index() instead."
                ),
            }
        return {
            "available": True,
            "cleared_project": project_id,
            "path": project_path,
            "note": (
                f"Project '{project_id}' has been cleared from the index. "
                f"Call analyse_project('{project_path}', full=True) to re-index from scratch."
            ),
        }

    @mcp.tool()
    def reset_index():
        """
        Remove ALL indexed data – complete clean slate across every project.

        Deletes every project, file, class, method, symbol, community, and flow
        from the graph. The database file itself is kept so the MCP server remains
        usable without a restart.

        This is a destructive but fast operation. After calling this, no projects
        will be indexed until you run analyse_project() again for each one.

        Typical workflow:
          1. reset_index()
          2. analyse_project("/path/to/project-a")
          3. analyse_project("/path/to/project-b")
        """
        # Capture the list of projects before clearing so we can report them
        projects = store.query_records("MATCH (p:Project) RETURN p.id as id, p.path as path")

        proc = subprocess.run(
            [sys.executable, "-m", "codespine.cli", "clear-index", "--allow-running"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if proc.returncode != 0:
            error_text = (proc.stderr.strip() or proc.stdout.strip())[:300]
            return {
                "available": False,
                "note": (
                    f"Reset failed: {error_text}. "
                    "If this is a buffer pool or DB corruption error, use force_reset_index() instead."
                ),
            }

        cleared = [{"project_id": p["id"], "path": p["path"]} for p in projects]
        paths = [p["path"] for p in projects]
        re_index_hint = " ".join(f"analyse_project('{p}')" for p in paths[:3])
        if len(paths) > 3:
            re_index_hint += f" ... ({len(paths) - 3} more)"

        return {
            "available": True,
            "cleared_count": len(cleared),
            "cleared_projects": cleared,
            "note": (
                f"Index cleared. {len(cleared)} project(s) removed. "
                f"Re-index with: {re_index_hint}" if paths else
                "Index cleared. No projects were indexed."
            ),
        }

    @mcp.tool()
    def force_reset_index():
        """
        Emergency reset: delete ALL CodeSpine data files without touching the
        DB engine.

        Use this when the buffer pool is exhausted and normal reset/clear
        commands also fail with OOM errors.  This bypasses Kuzu entirely by
        removing all data files from disk.

        After calling this, restart the MCP server and re-index all projects
        with analyse_project().

        This is the nuclear option — only use when reset_project() and
        reset_index() fail with buffer pool errors.
        """
        from codespine.db.store import GraphStore as _GS

        removed = _GS.force_delete_all_data()
        return {
            "available": True,
            "removed_paths": removed,
            "removed_count": len(removed),
            "note": (
                f"Force-reset complete. {len(removed)} path(s) removed. "
                "Restart the MCP server (codespine stop && codespine start) "
                "and re-index projects with analyse_project()."
                if removed else
                "Nothing to remove — already clean."
            ),
        }

    # ------------------------------------------------------------------
    # Neighborhood exploration
    # ------------------------------------------------------------------

    @mcp.tool()
    def get_neighborhood(symbol: str, project: str | None = None):
        """
        One-shot structural context for a symbol: callers (upstream), callees
        (downstream), sibling methods in the same class, and override /
        implements relationships.

        This is the tool to call when you want to understand a method's
        immediate surroundings in the call graph without traversing the
        full impact tree.

        Parameters:
          symbol  – Method name, signature fragment, or fully-qualified name.
          project – Optional project_id to scope the symbol lookup.
        """
        from codespine.analysis.impact import _resolve_method_metadata

        project_clause = "AND f.project_id = $proj" if project else ""
        params: dict = {"q": symbol}
        if project:
            params["proj"] = project

        # 1. Resolve the symbol to method IDs
        method_recs = store.query_records(
            f"""
            MATCH (m:Method), (c:Class), (f:File)
            WHERE m.class_id = c.id AND c.file_id = f.id {project_clause}
              AND (m.id = $q OR lower(m.name) = lower($q)
                   OR lower(m.signature) CONTAINS lower($q))
            RETURN m.id as id, m.name as name, m.signature as signature,
                   c.id as class_id, c.fqcn as class_fqcn,
                   f.path as file_path, f.project_id as project_id
            LIMIT 5
            """,
            params,
        )
        if not method_recs:
            return {"available": False, "note": f"Symbol '{symbol}' not found. Try find_symbol or search_hybrid."}

        target = method_recs[0]
        mid = target["id"]
        cid = target["class_id"]

        # 2. Callers (upstream)
        callers = store.query_records(
            """
            MATCH (caller:Method)-[r:CALLS]->(m:Method {id: $mid})
            RETURN caller.id as id, coalesce(r.confidence, 0.5) as confidence,
                   coalesce(r.reason, 'unknown') as reason
            """,
            {"mid": mid},
        )

        # 3. Callees (downstream)
        callees = store.query_records(
            """
            MATCH (m:Method {id: $mid})-[r:CALLS]->(callee:Method)
            RETURN callee.id as id, coalesce(r.confidence, 0.5) as confidence,
                   coalesce(r.reason, 'unknown') as reason
            """,
            {"mid": mid},
        )

        # 4. Siblings (same class, excluding self)
        siblings = store.query_records(
            """
            MATCH (m:Method)
            WHERE m.class_id = $cid AND m.id <> $mid
            RETURN m.id as id, m.name as name, m.signature as signature
            """,
            {"cid": cid, "mid": mid},
        )

        # 5. Override / implements relationships
        overrides_up = store.query_records(
            "MATCH (m:Method {id: $mid})-[:OVERRIDES]->(parent:Method) RETURN parent.id as id",
            {"mid": mid},
        )
        overrides_down = store.query_records(
            "MATCH (child:Method)-[:OVERRIDES]->(m:Method {id: $mid}) RETURN child.id as id",
            {"mid": mid},
        )

        # Bulk-resolve all referenced method IDs for human-readable output
        all_ids = (
            [c["id"] for c in callers]
            + [c["id"] for c in callees]
            + [o["id"] for o in overrides_up]
            + [o["id"] for o in overrides_down]
        )
        meta = _resolve_method_metadata(store, all_ids) if all_ids else {}

        def _enrich(items, extra_keys=None):
            enriched = []
            for item in items:
                m = meta.get(item["id"], {})
                entry = {
                    "id": item["id"],
                    "name": m.get("name") or item.get("name"),
                    "fqname": m.get("fqname") or item.get("signature"),
                    "class_fqcn": m.get("class_fqcn"),
                    "file_path": m.get("file_path"),
                    "project_id": m.get("project_id"),
                }
                if extra_keys:
                    for k in extra_keys:
                        if k in item:
                            entry[k] = item[k]
                enriched.append(entry)
            return enriched

        result = {
            "available": True,
            "target": {
                "id": mid,
                "name": target["name"],
                "signature": target["signature"],
                "class_fqcn": target["class_fqcn"],
                "file_path": target["file_path"],
                "project_id": target["project_id"],
            },
            "callers": _enrich(callers, extra_keys=["confidence", "reason"]),
            "callees": _enrich(callees, extra_keys=["confidence", "reason"]),
            "siblings": [
                {"name": s["name"], "signature": s["signature"]}
                for s in siblings
            ],
            "overrides": _enrich(overrides_up),
            "overridden_by": _enrich(overrides_down),
            "summary": {
                "callers": len(callers),
                "callees": len(callees),
                "siblings": len(siblings),
                "overrides": len(overrides_up),
                "overridden_by": len(overrides_down),
            },
        }
        return _staleness_meta(store, result)

    # ------------------------------------------------------------------
    # Single-file re-index
    # ------------------------------------------------------------------

    @mcp.tool()
    def reindex_file(file_path: str, project: str | None = None):
        """
        Incrementally re-index a single Java file (<1 s for typical files).

        Use this after editing a file to immediately refresh the graph without
        waiting for watch mode or running a full analysis.

        The file is parsed and its symbols are stored in the overlay (just like
        watch mode), so the updated data is immediately visible in search and
        find_symbol results.

        Parameters:
          file_path – Absolute path to the .java file.
          project   – Optional project_id. If omitted, the tool infers the
                      project by matching the file path against indexed projects.
        """
        import os as _os

        abs_fp = _os.path.abspath(file_path)
        if not _os.path.isfile(abs_fp) or not abs_fp.endswith(".java"):
            return {"available": False, "note": f"Not a valid .java file: {abs_fp}"}

        # Resolve project from indexed projects if not given
        if not project:
            try:
                projects = store.query_records(
                    "MATCH (p:Project) RETURN p.id as id, p.path as path"
                )
            except Exception as exc:
                return {"available": False, "note": f"DB read failed: {exc}"}
            for p in projects:
                if abs_fp.startswith(p["path"] + _os.sep):
                    project = p["id"]
                    break
            if not project:
                return {
                    "available": False,
                    "note": (
                        "Cannot determine project for this file. "
                        "Pass project=<project_id> explicitly."
                    ),
                }

        # Find the project path to use as root for indexing
        try:
            proj_recs = store.query_records(
                "MATCH (p:Project) WHERE p.id = $pid RETURN p.path as path LIMIT 1",
                {"pid": project},
            )
        except Exception as exc:
            return {"available": False, "note": f"DB read failed: {exc}"}
        if not proj_recs:
            return {"available": False, "note": f"Project '{project}' not found in index."}

        proj_path = proj_recs[0]["path"]

        # Use overlay-based single-file update (same mechanism as watch mode).
        # This avoids spawning a subprocess and contending with the write DB.
        from codespine.watch.watcher import _update_overlay_for_files

        t0 = time.time()
        try:
            result = _update_overlay_for_files(store, proj_path, project, [abs_fp])
            elapsed = round(time.time() - t0, 2)
        except Exception as exc:
            elapsed = round(time.time() - t0, 2)
            _LOGGER.warning("reindex_file failed: %s", exc)
            # Fall back to subprocess approach
            cmd = [
                sys.executable, "-m", "codespine.cli",
                "analyse", proj_path,
                "--incremental", "--no-embed", "--allow-running",
            ]
            try:
                proc = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                )
                stdout, stderr = proc.communicate(timeout=60)
                elapsed = round(time.time() - t0, 2)
                if proc.returncode != 0:
                    return {
                        "available": False,
                        "note": f"Re-index failed (code {proc.returncode})",
                        "error": (stderr or stdout or "").strip()[:500],
                    }
                return {
                    "available": True,
                    "file": abs_fp,
                    "project": project,
                    "elapsed_s": elapsed,
                    "note": f"Overlay update failed; fell back to full incremental re-index in {elapsed}s.",
                }
            except Exception as fallback_exc:
                return {"available": False, "note": f"Re-index error: overlay={exc}, subprocess={fallback_exc}"}

        return {
            "available": True,
            "file": abs_fp,
            "project": project,
            "elapsed_s": elapsed,
            "changed": result.get("changed", 0),
            "note": f"Re-indexed {abs_fp} via overlay in {elapsed}s.",
        }

    # ------------------------------------------------------------------
    # Advanced / raw access
    # ------------------------------------------------------------------

    @mcp.tool()
    def run_cypher(query: str):
        """Run a raw Cypher query against the graph. For advanced exploration."""
        records = store.query_records(query)
        return {"available": True, "records": records, "count": len(records)}

    return _raw_mcp
