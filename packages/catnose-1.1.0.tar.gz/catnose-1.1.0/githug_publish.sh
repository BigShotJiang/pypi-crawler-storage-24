#!/bin/sh
GIT_ASKPASS= GIT_TERMINAL_PROMPT=1 git push https://github.com/lagor-github/catnose.git

