# -*- coding: utf-8 -*-

from setuptools import find_packages, setup

with open("README.md", "r") as fh:
    readme_description = fh.read()

setup(
    name='catnose',
    packages=find_packages(),
    include_package_data=True,  # -- para que se incluyan archivos sin extension .py
    version='1.1.0',
    description='Catnose loads JSON input and applies transformation rules to generate JSON output',
    long_description=readme_description,
    long_description_content_type="text/markdown",
    zip_safe=False,
    install_requires=[
        'Pillow',
    ],
    author='Luis A. González',
    author_email="lagor55@gmail.com",
    license="MIT",
    license_files=["LICENSE"],
    url="https://github.com/lagor-github/catnose",
    classifiers=["Programming Language :: Python :: 3",
        "Development Status :: 5 - Production/Stable", "Intended Audience :: Developers",
        "Operating System :: OS Independent"],
    )
