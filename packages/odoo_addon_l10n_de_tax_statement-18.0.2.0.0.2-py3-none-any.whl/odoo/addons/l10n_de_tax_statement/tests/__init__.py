# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from . import test_l10n_de_tax_statement
