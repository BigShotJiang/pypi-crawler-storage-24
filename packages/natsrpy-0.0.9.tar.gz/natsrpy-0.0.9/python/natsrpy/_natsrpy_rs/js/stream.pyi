from datetime import datetime, timedelta
from typing import Any, final

from typing_extensions import Self

from .managers import ConsumersManager

__all__ = [
    "ClusterInfo",
    "Compression",
    "ConsumerLimits",
    "DiscardPolicy",
    "External",
    "PeerInfo",
    "PersistenceMode",
    "Placement",
    "Republish",
    "RetentionPolicy",
    "Source",
    "SourceInfo",
    "StorageType",
    "Stream",
    "StreamConfig",
    "StreamInfo",
    "StreamMessage",
    "StreamState",
    "SubjectTransform",
]

@final
class StorageType:
    FILE: StorageType
    MEMORY: StorageType

@final
class DiscardPolicy:
    OLD: DiscardPolicy
    NEW: DiscardPolicy

@final
class RetentionPolicy:
    LIMITS: RetentionPolicy
    INTEREST: RetentionPolicy
    WORKQUEUE: RetentionPolicy

@final
class Compression:
    S2: Compression
    NONE: Compression

@final
class PersistenceMode:
    Default: PersistenceMode
    Async: PersistenceMode

@final
class ConsumerLimits:
    inactive_threshold: timedelta
    max_ack_pending: int

    def __new__(cls, inactive_threshold: timedelta, max_ack_pending: int) -> Self: ...

@final
class External:
    api_prefix: str
    delivery_prefix: str | None

    def __new__(cls, api_prefix: str, delivery_prefix: str | None = None) -> Self: ...

@final
class SubjectTransform:
    source: str
    destination: str

    def __new__(cls, source: str, destination: str) -> Self: ...

@final
class Source:
    name: str
    filter_subject: str | None = None
    external: External | None = None
    start_sequence: int | None = None
    start_time: int | None = None
    domain: str | None = None
    subject_transforms: SubjectTransform | None = None

    def __new__(
        cls,
        name: str,
        filter_subject: str | None = None,
        external: External | None = None,
        start_sequence: int | None = None,
        start_time: int | None = None,
        domain: str | None = None,
        subject_transforms: SubjectTransform | None = None,
    ) -> Self: ...

@final
class Placement:
    cluster: str | None
    tags: list[str] | None

    def __new__(
        cls,
        cluster: str | None = None,
        tags: list[str] | None = None,
    ) -> Self: ...

@final
class Republish:
    source: str
    destination: str
    headers_only: bool

    def __new__(cls, source: str, destination: str, headers_only: bool) -> Self: ...

@final
class StreamConfig:
    name: str
    subjects: list[str]
    max_bytes: int | None
    max_messages: int | None
    max_messages_per_subject: int | None
    discard: DiscardPolicy | None
    discard_new_per_subject: bool | None
    retention: RetentionPolicy | None
    max_consumers: int | None
    max_age: timedelta | None
    max_message_size: int | None
    storage: StorageType | None
    num_replicas: int | None
    no_ack: bool | None
    duplicate_window: timedelta | None
    template_owner: str | None
    sealed: bool | None
    description: str | None
    allow_rollup: bool | None
    deny_delete: bool | None
    deny_purge: bool | None
    republish: Republish | None
    allow_direct: bool | None
    mirror_direct: bool | None
    mirror: Source | None
    sources: list[Source] | None
    metadata: dict[str, str] | None
    subject_transform: SubjectTransform | None
    compression: Compression | None
    consumer_limits: ConsumerLimits | None
    first_sequence: int | None
    placement: Placement | None
    persist_mode: PersistenceMode | None
    pause_until: int | None
    allow_message_ttl: bool | None
    subject_delete_marker_ttl: timedelta | None
    allow_atomic_publish: bool | None
    allow_message_schedules: bool | None
    allow_message_counter: bool | None

    def __new__(
        cls,
        name: str,
        subjects: list[str],
        max_bytes: int | None = None,
        max_messages: int | None = None,
        max_messages_per_subject: int | None = None,
        discard: DiscardPolicy | None = None,
        discard_new_per_subject: bool | None = None,
        retention: RetentionPolicy | None = None,
        max_consumers: int | None = None,
        max_age: timedelta | None = None,
        max_message_size: int | None = None,
        storage: StorageType | None = None,
        num_replicas: int | None = None,
        no_ack: bool | None = None,
        duplicate_window: timedelta | None = None,
        template_owner: str | None = None,
        sealed: bool | None = None,
        description: str | None = None,
        allow_rollup: bool | None = None,
        deny_delete: bool | None = None,
        deny_purge: bool | None = None,
        republish: Republish | None = None,
        allow_direct: bool | None = None,
        mirror_direct: bool | None = None,
        mirror: Source | None = None,
        sources: list[Source] | None = None,
        metadata: dict[str, str] | None = None,
        subject_transform: SubjectTransform | None = None,
        compression: Compression | None = None,
        consumer_limits: ConsumerLimits | None = None,
        first_sequence: int | None = None,
        placement: Placement | None = None,
        persist_mode: PersistenceMode | None = None,
        pause_until: int | None = None,
        allow_message_ttl: bool | None = None,
        subject_delete_marker_ttl: timedelta | None = None,
        allow_atomic_publish: bool | None = None,
        allow_message_schedules: bool | None = None,
        allow_message_counter: bool | None = None,
    ) -> Self: ...

@final
class StreamMessage:
    subject: str
    sequence: int
    headers: dict[str, Any]
    payload: bytes
    time: datetime

@final
class StreamState:
    messages: int
    bytes: int
    first_sequence: int
    first_timestamp: int
    last_sequence: int
    last_timestamp: int
    consumer_count: int
    subjects_count: int
    deleted_count: int | None
    deleted: list[int] | None

@final
class SourceInfo:
    name: str
    lag: int
    active: timedelta | None
    filter_subject: str | None
    subject_transform_dest: str | None
    subject_transforms: list[SubjectTransform]

@final
class PeerInfo:
    name: str
    current: bool
    active: timedelta
    offline: bool
    lag: int | None

@final
class ClusterInfo:
    name: str | None
    raft_group: str | None
    leader: str | None
    leader_since: int | None
    system_account: bool
    traffic_account: str | None
    replicas: list[PeerInfo]

@final
class StreamInfo:
    config: StreamConfig
    created: float
    state: StreamState
    cluster: ClusterInfo | None
    mirror: SourceInfo | None
    sources: list[SourceInfo]

@final
class Stream:
    async def direct_get(
        self,
        sequence: int,
        timeout: float | datetime | None = None,
    ) -> StreamMessage:
        """
        Get direct message from the stream.

        :param sequence: sequence number of the message to get.
        :return: Message.
        """

    async def get_info(self, timeout: float | datetime | None = None) -> StreamInfo:
        """
        Get information about the stream.

        :return: Stream info.
        """

    async def purge(
        self,
        filter: str | None = None,
        sequence: int | None = None,
        keep: int | None = None,
        timeout: float | datetime | None = None,
    ) -> int:
        """
        Purge current stream.

        :param filter: filter of subjects to purge, defaults to None
        :param sequence: Message sequence to purge up to (inclusive), defaults to None
        :param keep: Message count to keep starting from the end of the stream,
            defaults to None
        :return: number of messages purged
        """

    @property
    def consumers(self) -> ConsumersManager: ...
