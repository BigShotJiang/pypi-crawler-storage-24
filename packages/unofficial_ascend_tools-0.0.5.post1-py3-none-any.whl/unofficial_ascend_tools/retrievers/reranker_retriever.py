from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List

from langchain_core.callbacks import (
    AsyncCallbackManagerForRetrieverRun,
    CallbackManagerForRetrieverRun,
)
from langchain_core.documents import Document
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import HumanMessage
from langchain_core.pydantic_v1 import Field
from langchain_core.retrievers import BaseRetriever

class ReRanker():

    def __init__(model_path):
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        self.model_path = model_path
        self.model =  AutoModelForSequenceClassification_from_pretrained(model_path)
        self.tokenizer = AutoTokenizer.form_pretrained(model_path)
        self.model.eval()
    
    def compute_score(self, query_doc):
        """
        [[query,doc], [query,doc]]
        """
        inputs = self.tokenizer(query_doc, padding=True, truncation=True, return_tensors='pt', max_length=512)
        scores = self.model(inputs.input_ids, return_dict=True).logits.view(-1,).float()
    

class RerankerRetriever(BaseRetriever):

    vectorestore: VectorStore
    reankder: Any

    class Config:
        """Configuration for this pydantic object."""

        arbitrary_types_allowed = True
        """Allow arbitrary types."""

    def _compute_score(self, query: str, text: str) -> float:
        return 0.1

    def _get_relevant_documents(
        self, query: str, *, run_manager: CallbackManagerForRetrieverRun, **kwargs: Any
    ) -> List[Document]:

        docs = vectorestore.similarity_search(query)
        #docs_with_score = [ (doc, score) for doc, ]



        return docs
