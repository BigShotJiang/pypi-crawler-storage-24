# Schift SDK

Canonical Embedding Space — one API for all embedding models.

```bash
pip install schift
```

## Quickstart: RAG in 30 seconds

```python
import schift

client = schift.Client(api_key="sk-...")

# 1. Upload documents
bucket = client.bucket("my-docs")
bucket.upload_file("report.pdf")

# 2. Search
results = bucket.search("매출 현황 알려줘")
print(results[0]["text"])
```

That's it. Schift handles OCR, chunking, embedding, and vector search.

## Embed

```python
# Single
emb = client.embed("hello world", task="retrieval_query")
print(len(emb.values))  # 1024

# Batch
embs = client.embed_batch(["doc 1", "doc 2"], task="retrieval_document")
```

### Task Types

| Task | Use case |
|------|----------|
| `retrieval_query` | Search queries |
| `retrieval_document` | Documents to be searched |
| `semantic_similarity` | Compare two texts |
| `question_answering` | QA systems |
| `clustering` | Group similar texts |
| `classification` | Categorize texts |
| `code_retrieval` | Code search |

## Collections

```python
col = client.collection("products")

# Add documents (embed + store in one call)
col.add(
    documents=["iPhone 16 review", "Galaxy S25 specs"],
    ids=["doc1", "doc2"],
    task="retrieval_document",
)

# Search
results = col.search("best phone 2025", task="retrieval_query", top_k=5)
for r in results:
    print(f"{r.id}: {r.score:.3f}")
```

## Buckets (File Upload + RAG)

```python
bucket = client.bucket("company-docs")

# Upload files — processed async (OCR → chunk → embed)
result = bucket.upload([("report.pdf", open("report.pdf", "rb").read())])
print(result.jobs[0].status)  # "queued"

# Check job status
jobs = bucket.jobs()
for job in jobs:
    print(f"{job.file_name}: {job.status}")

# Search when ready
results = bucket.search("Q4 revenue")
```

## Task Helpers

```python
# Similarity
score = client.similarity("cat sleeping", "고양이가 잔다")
print(score)  # 0.87

# Zero-shot classification
result = client.classify(
    "This product is amazing!",
    labels=["positive", "negative", "neutral"]
)
print(result.label)  # "positive"

# Clustering
clusters = client.cluster(
    texts=["cat", "dog", "python", "java", "seoul", "tokyo"],
    n_clusters=3,
)
print(clusters.labels)  # [0, 0, 1, 1, 2, 2]
```

## Workflows

Build and run RAG pipelines as composable DAGs.

### Quick Start

```python
# Create from template
wf = client.workflow.create_rag("Product Search")

# Run with inputs
result = client.workflow.run(wf.id, inputs={"query": "best laptop"})
print(result.outputs["answer"])
```

### CRUD

```python
# Create
wf = client.workflow.create("My Pipeline", description="Custom RAG")

# List / Get / Update / Delete
workflows = client.workflow.list()
wf = client.workflow.get(wf.id)
wf = client.workflow.update(wf.id, name="Renamed")
client.workflow.delete(wf.id)
```

### Building a Graph

```python
wf = client.workflow.create("Custom RAG")

# Add blocks
start = client.workflow.add_block(wf.id, "start", title="Start")
retriever = client.workflow.add_block(wf.id, "retriever", config={
    "collection": "my-docs",
    "top_k": 5,
    "rerank": True,
    "rerank_top_k": 3,
})
prompt = client.workflow.add_block(wf.id, "prompt_template", config={
    "template": "Answer based on:\n{{results}}\n\nQuestion: {{query}}",
})
llm = client.workflow.add_block(wf.id, "llm", config={
    "model": "openai/gpt-4o-mini",  # or "anthropic/claude-sonnet-4-20250514", "gemini-2.5-flash"
    "temperature": 0.7,
})
end = client.workflow.add_block(wf.id, "end")

# Connect blocks
client.workflow.add_edge(wf.id, start["id"], retriever["id"])
client.workflow.add_edge(wf.id, retriever["id"], prompt["id"])
client.workflow.add_edge(wf.id, prompt["id"], llm["id"])
client.workflow.add_edge(wf.id, llm["id"], end["id"])
```

### Multiple Inputs

Pass any number of variables; the start node forwards all of them:

```python
result = client.workflow.run(wf.id, inputs={
    "query": "maternity leave policy",
    "user_id": "u-123",
    "language": "ko",
})
```

### Validation & Run History

```python
# Validate graph (cycles, missing connections, etc.)
v = client.workflow.validate(wf.id)
print(v.valid, v.errors)

# List past runs
runs = client.workflow.runs(wf.id)
for r in runs:
    print(r.run_id, r.status, r.outputs)
```

### YAML Import / Export

```python
# Export
yaml_str = client.workflow.to_yaml(wf.id, path="pipeline.yaml")

# Import from file
definition = client.workflow.from_yaml("pipeline.yaml")

# Push YAML to create a new workflow
wf = client.workflow.push_yaml("pipeline.yaml")
```

### Templates

```python
client.workflow.create_rag("RAG Pipeline")       # retriever -> prompt -> LLM
client.workflow.create_doc_qa("Doc QA")           # document QA with sources
client.workflow.create_chat("Chat")               # conversational RAG
client.workflow.create_ocr_ingest("OCR Ingest")   # OCR -> chunk -> embed
```

### Block Types

| Category | Types |
|----------|-------|
| Control | `start`, `end`, `conditional`, `loop` |
| Retrieval | `retriever`, `reranker` |
| LLM | `llm`, `prompt_template`, `answer` |
| Data | `document_loader`, `chunker`, `embedder`, `text_processor` |
| Integration | `api_call`, `webhook`, `code_executor` |
| Storage | `vector_store`, `cache` |

## Async

```python
async with schift.AsyncClient(api_key="sk-...") as client:
    emb = await client.embed("hello")
    results = await client.bucket("docs").search("query")
```

## Cross-Model Search

Schift's Canonical Space lets you search across different embedding models:

```python
# Index with OpenAI
col.add(documents=["doc1"], model="openai/text-embedding-3-large", task="retrieval_document")

# Search with Gemini — still finds it!
results = col.search("query", model="google/gemini-embedding-001", task="retrieval_query")
```

Different models, same search space. No re-embedding needed.

## API Reference

| Method | Description |
|--------|-------------|
| `client.embed(text, task)` | Embed single text |
| `client.embed_batch(texts, task)` | Embed batch |
| `client.similarity(a, b)` | Cosine similarity |
| `client.classify(text, labels)` | Zero-shot classify |
| `client.cluster(texts, n)` | K-means cluster |
| `client.collection(name)` | Get/create collection |
| `col.add(documents, task)` | Embed + store |
| `col.search(query, task)` | Embed + search |
| `client.bucket(id)` | Get bucket |
| `bucket.upload(files)` | Upload files (async) |
| `bucket.search(query)` | Search bucket |
| `bucket.jobs()` | List processing jobs |
| `client.workflow.create(name)` | Create workflow |
| `client.workflow.get(id)` | Get workflow |
| `client.workflow.list()` | List workflows |
| `client.workflow.update(id, **kw)` | Update workflow |
| `client.workflow.delete(id)` | Delete workflow |
| `client.workflow.run(id, inputs)` | Run workflow |
| `client.workflow.runs(id)` | List past runs |
| `client.workflow.validate(id)` | Validate graph |
| `client.workflow.add_block(id, type)` | Add block |
| `client.workflow.add_edge(id, src, tgt)` | Add edge |
| `client.workflow.to_yaml(id)` | Export as YAML |
| `client.workflow.push_yaml(path)` | Import from YAML |
| `client.workflow.create_rag(name)` | RAG template |
| `client.workflow.create_doc_qa(name)` | Doc QA template |
| `client.workflow.create_chat(name)` | Chat template |

## Links

- API: https://api.schift.io
- PyPI: https://pypi.org/project/schift/
- npm: https://www.npmjs.com/package/@schift-io/sdk
