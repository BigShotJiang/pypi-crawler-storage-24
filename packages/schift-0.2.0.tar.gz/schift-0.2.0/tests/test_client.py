import pytest
import respx
from schift import Client
from schift.models import EmbedResponse, SearchResult, ClassifyResult

@respx.mock
def test_embed():
    respx.post("https://api.schift.io/v1/embed").respond(json={"embedding": [0.1, 0.2], "model": "schift-embed-1", "dimensions": 2})
    client = Client(api_key="sk-test", base_url="https://api.schift.io")
    result = client.embed("hello", task="retrieval_query")
    assert isinstance(result, EmbedResponse)
    assert result.values == [0.1, 0.2]

@respx.mock
def test_embed_batch():
    respx.post("https://api.schift.io/v1/embed/batch").respond(json={"embeddings": [[0.1], [0.2]], "model": "m", "dimensions": 1})
    client = Client(api_key="sk-test", base_url="https://api.schift.io")
    results = client.embed_batch(["a", "b"], task="retrieval_document")
    assert len(results) == 2

@respx.mock
def test_similarity():
    respx.post("https://api.schift.io/v1/similarity").respond(json={"score": 0.87})
    client = Client(api_key="sk-test", base_url="https://api.schift.io")
    assert client.similarity("a", "b") == 0.87

@respx.mock
def test_classify():
    respx.post("https://api.schift.io/v1/classify").respond(json={"label": "pos", "scores": {"pos": 0.9, "neg": 0.1}})
    client = Client(api_key="sk-test", base_url="https://api.schift.io")
    result = client.classify("good!", labels=["pos", "neg"])
    assert result.label == "pos"

@respx.mock
def test_collection_add_and_search():
    respx.post("https://api.schift.io/v1/collections/docs/add").respond(json={"collection": "docs", "added": 1, "ids": ["d1"]})
    respx.post("https://api.schift.io/v1/collections/docs/search").respond(json={"collection": "docs", "results": [{"id": "d1", "metadata": {}, "score": 0.95}]})
    client = Client(api_key="sk-test", base_url="https://api.schift.io")
    col = client.collection("docs")
    col.add(documents=["hello"], ids=["d1"], task="retrieval_document")
    results = col.search("hello", task="retrieval_query")
    assert len(results) == 1
    assert results[0].id == "d1"

def test_client_requires_api_key():
    import os
    os.environ.pop("SCHIFT_API_KEY", None)
    with pytest.raises(ValueError):
        Client()
