import pytest
import respx
from schift import Client
from schift.bucket import JobInfo, UploadResult

BASE = "https://api.schift.io"

@respx.mock
def test_create_bucket():
    respx.post(f"{BASE}/v1/buckets").respond(json={"id": "b1", "name": "docs"})
    c = Client(api_key="sk-test", base_url=BASE)
    b = c.create_bucket("docs")
    assert b["id"] == "b1"

@respx.mock
def test_list_buckets():
    respx.get(f"{BASE}/v1/buckets").respond(json=[{"id": "b1"}, {"id": "b2"}])
    c = Client(api_key="sk-test", base_url=BASE)
    assert len(c.list_buckets()) == 2

@respx.mock
def test_bucket_upload():
    respx.post(f"{BASE}/v1/buckets/b1/upload").respond(json={
        "jobs": [{"job_id": "j1", "file_name": "doc.pdf", "status": "queued", "estimated_cost": 1.5}],
        "total_estimated_cost": 1.5, "credit_balance_after_hold": 98.5
    })
    c = Client(api_key="sk-test", base_url=BASE)
    result = c.bucket("b1").upload([("doc.pdf", b"fake")])
    assert isinstance(result, UploadResult)
    assert result.jobs[0].status == "queued"

@respx.mock
def test_bucket_jobs():
    respx.get(f"{BASE}/v1/jobs").respond(json=[
        {"job_id": "j1", "file_name": "a.pdf", "status": "completed"}
    ])
    c = Client(api_key="sk-test", base_url=BASE)
    jobs = c.bucket("b1").jobs()
    assert len(jobs) == 1
    assert jobs[0].status == "completed"

@respx.mock
def test_bucket_search():
    respx.post(f"{BASE}/v1/buckets/b1/search").respond(json={
        "results": [{"id": "doc1", "score": 0.95, "metadata": {}}]
    })
    c = Client(api_key="sk-test", base_url=BASE)
    results = c.bucket("b1").search("AI가 뭐야?")
    assert len(results) == 1

@respx.mock
def test_bucket_delete():
    respx.delete(f"{BASE}/v1/buckets/b1").respond(status_code=204)
    c = Client(api_key="sk-test", base_url=BASE)
    c.bucket("b1").delete()  # should not raise

@respx.mock
def test_cancel_job():
    respx.post(f"{BASE}/v1/jobs/j1/cancel").respond(json={"status": "cancelled", "refunded": 1.5})
    c = Client(api_key="sk-test", base_url=BASE)
    result = c.bucket("b1").cancel_job("j1")
    assert result["status"] == "cancelled"
