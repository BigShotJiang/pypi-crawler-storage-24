"""Tests for Workflow YAML serialization."""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from schift.workflow_models import (
    BlockDef,
    EdgeDef,
    Position,
    WorkflowDefinition,
)
from schift.workflow_yaml import (
    definition_from_api_response,
    validate_definition,
    workflow_from_yaml,
    workflow_from_yaml_file,
    workflow_to_yaml,
    workflow_to_yaml_file,
)

# ---- Fixtures ----

BASIC_YAML = textwrap.dedent("""\
    version: 1
    name: test-pipeline
    description: A test workflow

    blocks:
      - id: start
        type: start
      - id: embedder
        type: embedder
        config:
          model: bge-m3
      - id: end
        type: end

    edges:
      - source: start
        target: embedder
      - source: embedder
        target: end
""")

MINIMAL_YAML = textwrap.dedent("""\
    version: 1
    name: minimal
    blocks:
      - id: start
        type: start
""")

FULL_YAML = textwrap.dedent("""\
    version: 1
    name: full-pipeline
    description: Full featured
    status: published

    blocks:
      - id: start
        type: start
        title: Begin
        position:
          x: 0
          y: 100
      - id: loader
        type: document_loader
        config:
          source_type: upload
      - id: end
        type: end

    edges:
      - source: start
        target: loader
        source_handle: output
        target_handle: input
      - source: loader
        target: end
""")


def _make_definition() -> WorkflowDefinition:
    return WorkflowDefinition(
        version=1,
        name="test-pipeline",
        description="A test workflow",
        blocks=[
            BlockDef(id="start", type="start", title="Start"),
            BlockDef(id="embedder", type="embedder", title="Embedder", config={"model": "bge-m3"}),
            BlockDef(id="end", type="end", title="End"),
        ],
        edges=[
            EdgeDef(source="start", target="embedder"),
            EdgeDef(source="embedder", target="end"),
        ],
    )


# ---- Round-trip Tests ----

class TestRoundTrip:
    def test_from_yaml_to_yaml_round_trip(self):
        wf = workflow_from_yaml(BASIC_YAML)
        yaml_out = workflow_to_yaml(wf)
        wf2 = workflow_from_yaml(yaml_out)

        assert wf.name == wf2.name
        assert wf.description == wf2.description
        assert len(wf.blocks) == len(wf2.blocks)
        assert len(wf.edges) == len(wf2.edges)
        for b1, b2 in zip(wf.blocks, wf2.blocks):
            assert b1.id == b2.id
            assert b1.type == b2.type
            assert b1.config == b2.config
        for e1, e2 in zip(wf.edges, wf2.edges):
            assert e1.source == e2.source
            assert e1.target == e2.target

    def test_definition_to_dict_round_trip(self):
        wf = _make_definition()
        d = wf.to_dict()
        assert d["version"] == 1
        assert d["name"] == "test-pipeline"
        assert len(d["blocks"]) == 3
        assert len(d["edges"]) == 2

    def test_to_api_dict_converts_blocks_to_nodes_and_wraps_config(self):
        wf = _make_definition()
        api = wf.to_api_dict()

        assert "graph" in api
        assert "nodes" in api["graph"]
        assert "edges" in api["graph"]
        assert len(api["graph"]["nodes"]) == 3

        embedder = [n for n in api["graph"]["nodes"] if n["id"] == "embedder"][0]
        assert embedder["config"]["params"]["model"] == "bge-m3"


# ---- File I/O Tests ----

class TestFileIO:
    def test_from_yaml_file(self, tmp_path: Path):
        f = tmp_path / "test.yaml"
        f.write_text(BASIC_YAML, encoding="utf-8")
        wf = workflow_from_yaml_file(f)
        assert wf.name == "test-pipeline"
        assert len(wf.blocks) == 3

    def test_to_yaml_file(self, tmp_path: Path):
        wf = _make_definition()
        f = tmp_path / "out.yaml"
        workflow_to_yaml_file(wf, f)
        assert f.exists()
        wf2 = workflow_from_yaml_file(f)
        assert wf2.name == wf.name

    def test_file_round_trip(self, tmp_path: Path):
        wf = _make_definition()
        f = tmp_path / "round.yaml"
        workflow_to_yaml_file(wf, f)
        wf2 = workflow_from_yaml_file(f)
        assert wf2.name == wf.name
        assert len(wf2.blocks) == len(wf.blocks)
        assert len(wf2.edges) == len(wf.edges)


# ---- Optional Fields ----

class TestOptionalFields:
    def test_minimal_yaml_defaults(self):
        wf = workflow_from_yaml(MINIMAL_YAML)
        assert wf.name == "minimal"
        assert wf.description == ""
        assert wf.status == "draft"
        assert len(wf.blocks) == 1
        assert wf.blocks[0].title == "Start"
        assert wf.edges == []

    def test_full_yaml_with_all_fields(self):
        wf = workflow_from_yaml(FULL_YAML)
        assert wf.status == "published"
        assert wf.blocks[0].title == "Begin"
        assert wf.blocks[0].position is not None
        assert wf.blocks[0].position.x == 0
        assert wf.blocks[0].position.y == 100

    def test_title_defaults_to_type_title_case(self):
        wf = workflow_from_yaml(BASIC_YAML)
        embedder = [b for b in wf.blocks if b.id == "embedder"][0]
        assert embedder.title == "Embedder"

    def test_position_none_when_omitted(self):
        wf = workflow_from_yaml(BASIC_YAML)
        assert wf.blocks[0].position is None


# ---- Negative Cases ----

class TestNegativeCases:
    def test_empty_yaml_raises(self):
        with pytest.raises(ValueError, match="Invalid YAML"):
            workflow_from_yaml("")

    def test_none_yaml_raises(self):
        with pytest.raises(ValueError, match="Invalid YAML"):
            workflow_from_yaml("null")

    def test_missing_version_raises(self):
        yaml_str = "name: test\nblocks:\n  - id: s\n    type: start\n"
        with pytest.raises(ValueError, match="version"):
            workflow_from_yaml(yaml_str)

    def test_wrong_version_raises(self):
        yaml_str = "version: 99\nname: test\nblocks:\n  - id: s\n    type: start\n"
        with pytest.raises(ValueError, match="Unsupported schema version"):
            workflow_from_yaml(yaml_str)

    def test_missing_name_raises(self):
        yaml_str = "version: 1\nblocks:\n  - id: s\n    type: start\n"
        with pytest.raises(ValueError, match="name"):
            workflow_from_yaml(yaml_str)

    def test_missing_blocks_raises(self):
        yaml_str = "version: 1\nname: test\n"
        with pytest.raises(ValueError, match="blocks"):
            workflow_from_yaml(yaml_str)

    def test_empty_blocks_raises(self):
        yaml_str = "version: 1\nname: test\nblocks: []\n"
        with pytest.raises(ValueError, match="blocks"):
            workflow_from_yaml(yaml_str)

    def test_duplicate_block_id_raises(self):
        yaml_str = textwrap.dedent("""\
            version: 1
            name: dup
            blocks:
              - id: a
                type: start
              - id: a
                type: end
        """)
        with pytest.raises(ValueError, match="Duplicate block ID.*a"):
            workflow_from_yaml(yaml_str)

    def test_edge_references_nonexistent_source(self):
        yaml_str = textwrap.dedent("""\
            version: 1
            name: bad-edge
            blocks:
              - id: a
                type: start
            edges:
              - source: ghost
                target: a
        """)
        with pytest.raises(ValueError, match="non-existent source.*ghost"):
            workflow_from_yaml(yaml_str)

    def test_edge_references_nonexistent_target(self):
        yaml_str = textwrap.dedent("""\
            version: 1
            name: bad-edge
            blocks:
              - id: a
                type: start
            edges:
              - source: a
                target: ghost
        """)
        with pytest.raises(ValueError, match="non-existent target.*ghost"):
            workflow_from_yaml(yaml_str)

    def test_unknown_block_type_is_preserved(self):
        yaml_str = textwrap.dedent("""\
            version: 1
            name: custom
            blocks:
              - id: x
                type: my_custom_node
        """)
        wf = workflow_from_yaml(yaml_str)
        assert wf.blocks[0].type == "my_custom_node"

    def test_block_missing_id_raises(self):
        yaml_str = textwrap.dedent("""\
            version: 1
            name: noid
            blocks:
              - type: start
        """)
        with pytest.raises(ValueError, match="id"):
            workflow_from_yaml(yaml_str)

    def test_block_missing_type_raises(self):
        yaml_str = textwrap.dedent("""\
            version: 1
            name: notype
            blocks:
              - id: a
        """)
        with pytest.raises(ValueError, match="type"):
            workflow_from_yaml(yaml_str)

    def test_edges_only_no_blocks_raises(self):
        yaml_str = textwrap.dedent("""\
            version: 1
            name: edges-only
            edges:
              - source: a
                target: b
        """)
        with pytest.raises(ValueError, match="blocks"):
            workflow_from_yaml(yaml_str)


# ---- Validation ----

class TestValidation:
    def test_valid_linear_pipeline(self):
        wf = _make_definition()
        errors = validate_definition(wf)
        # start/end/embedder are server-only or tier2, so we may get warnings
        # but no structural errors
        structural = [e for e in errors if "server-only" not in e]
        assert structural == []

    def test_cycle_detection(self):
        wf = WorkflowDefinition(
            version=1,
            name="cycle",
            blocks=[
                BlockDef(id="a", type="start"),
                BlockDef(id="b", type="end"),
            ],
            edges=[
                EdgeDef(source="a", target="b"),
                EdgeDef(source="b", target="a"),
            ],
        )
        errors = validate_definition(wf)
        assert any("cycle" in e.lower() for e in errors)

    def test_disconnected_block_warning(self):
        wf = WorkflowDefinition(
            version=1,
            name="disconnected",
            blocks=[
                BlockDef(id="a", type="start"),
                BlockDef(id="b", type="end"),
                BlockDef(id="c", type="embedder"),
            ],
            edges=[
                EdgeDef(source="a", target="b"),
            ],
        )
        errors = validate_definition(wf)
        assert any("disconnected" in e.lower() for e in errors)

    def test_tier3_server_only_warning(self):
        wf = WorkflowDefinition(
            version=1,
            name="tier3",
            blocks=[
                BlockDef(id="a", type="start"),
                BlockDef(id="b", type="code"),
            ],
            edges=[
                EdgeDef(source="a", target="b"),
            ],
        )
        errors = validate_definition(wf)
        assert any("server-only" in e for e in errors)

    def test_definition_validate_method(self):
        wf = workflow_from_yaml(BASIC_YAML)
        errors = wf.validate()
        assert isinstance(errors, list)


# ---- API Response Conversion ----

class TestAPIConversion:
    def test_definition_from_api_response(self):
        api_data = {
            "name": "api-wf",
            "description": "from server",
            "status": "published",
            "graph": {
                "nodes": [
                    {
                        "id": "s",
                        "type": "start",
                        "title": "Start",
                        "position": {"x": 0, "y": 0},
                        "config": {"params": {}},
                    },
                    {
                        "id": "e",
                        "type": "embedder",
                        "title": "Embedder",
                        "position": {"x": 250, "y": 0},
                        "config": {"params": {"model": "bge-m3"}},
                    },
                ],
                "edges": [
                    {"source": "s", "target": "e", "source_handle": "output", "target_handle": "input"},
                ],
            },
        }
        wf = definition_from_api_response(api_data)
        assert wf.name == "api-wf"
        assert wf.status == "published"
        assert len(wf.blocks) == 2
        assert wf.blocks[1].config == {"model": "bge-m3"}
        assert wf.blocks[1].position is not None
        assert wf.blocks[1].position.x == 250

    def test_api_round_trip(self):
        """definition -> to_api_dict -> definition_from_api_response -> same data."""
        wf = _make_definition()
        api_dict = wf.to_api_dict()
        wf2 = definition_from_api_response(api_dict)
        assert wf2.name == wf.name
        assert len(wf2.blocks) == len(wf.blocks)
        for b1, b2 in zip(wf.blocks, wf2.blocks):
            assert b1.id == b2.id
            assert b1.type == b2.type
            assert b1.config == b2.config
