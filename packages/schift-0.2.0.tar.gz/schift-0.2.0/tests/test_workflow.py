"""Tests for Workflow SDK client."""
import pytest
import respx
from schift import Client
from schift.workflow_models import WorkflowResponse, RunResponse, WorkflowTemplate

BASE = "https://api.schift.io"


@respx.mock
def test_create_workflow():
    respx.post(f"{BASE}/v1/workflows").respond(json={
        "id": "wf-1", "name": "My RAG", "status": "draft", "description": "", "graph": {}
    })
    c = Client(api_key="sk-test", base_url=BASE)
    wf = c.workflow.create(name="My RAG", template="BASIC_RAG")
    assert isinstance(wf, WorkflowResponse)
    assert wf.id == "wf-1"
    assert wf.name == "My RAG"
    assert wf.status == "draft"


@respx.mock
def test_list_workflows():
    respx.get(f"{BASE}/v1/workflows").respond(json=[
        {"id": "wf-1", "name": "A", "status": "draft"},
        {"id": "wf-2", "name": "B", "status": "published"},
    ])
    c = Client(api_key="sk-test", base_url=BASE)
    wfs = c.workflow.list()
    assert len(wfs) == 2
    assert all(isinstance(wf, WorkflowResponse) for wf in wfs)
    assert wfs[0].id == "wf-1"
    assert wfs[1].status == "published"


@respx.mock
def test_run_workflow():
    respx.post(f"{BASE}/v1/workflows/wf-1/run").respond(json={
        "run_id": "run-1", "status": "completed",
        "outputs": {"answer": "AI is..."}, "error": None, "block_states": {}
    })
    c = Client(api_key="sk-test", base_url=BASE)
    run = c.workflow.run("wf-1", inputs={"query": "What is AI?"})
    assert isinstance(run, RunResponse)
    assert run.run_id == "run-1"
    assert run.status == "completed"
    assert run.outputs["answer"] == "AI is..."
    assert run.error is None


@respx.mock
def test_get_runs():
    respx.get(f"{BASE}/v1/workflows/wf-1/runs").respond(json=[
        {"run_id": "r1", "status": "completed", "outputs": {}, "error": None, "block_states": {}},
    ])
    c = Client(api_key="sk-test", base_url=BASE)
    runs = c.workflow.runs("wf-1")
    assert len(runs) == 1
    assert isinstance(runs[0], RunResponse)
    assert runs[0].run_id == "r1"


@respx.mock
def test_validate():
    respx.post(f"{BASE}/v1/workflows/wf-1/validate").respond(json={"valid": True, "errors": []})
    c = Client(api_key="sk-test", base_url=BASE)
    result = c.workflow.validate("wf-1")
    assert result.valid is True
    assert result.errors == []


@respx.mock
def test_delete():
    respx.delete(f"{BASE}/v1/workflows/wf-1").respond(status_code=204)
    c = Client(api_key="sk-test", base_url=BASE)
    c.workflow.delete("wf-1")  # should not raise


@respx.mock
def test_create_rag():
    respx.post(f"{BASE}/v1/workflows").respond(json={
        "id": "wf-rag", "name": "My RAG", "status": "draft", "description": "", "graph": {}
    })
    c = Client(api_key="sk-test", base_url=BASE)
    wf = c.workflow.create_rag("My RAG")
    assert isinstance(wf, WorkflowResponse)
    assert wf.id == "wf-rag"
    # Verify template was passed in request body
    request = respx.calls.last.request
    import json
    body = json.loads(request.content)
    assert body.get("template") == "BASIC_RAG"


@respx.mock
def test_create_doc_qa():
    respx.post(f"{BASE}/v1/workflows").respond(json={
        "id": "wf-qa", "name": "QA", "status": "draft", "description": "", "graph": {}
    })
    c = Client(api_key="sk-test", base_url=BASE)
    wf = c.workflow.create_doc_qa("QA")
    assert isinstance(wf, WorkflowResponse)
    assert wf.id == "wf-qa"
    # Verify template was passed in request body
    request = respx.calls.last.request
    import json
    body = json.loads(request.content)
    assert body.get("template") == "DOCUMENT_QA"
