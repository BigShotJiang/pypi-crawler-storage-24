import pytest
import respx
from schift import AsyncClient
from schift.models import EmbedResponse

@pytest.mark.asyncio
@respx.mock
async def test_async_embed():
    respx.post("https://api.schift.io/v1/embed").respond(json={"embedding": [0.1], "model": "m", "dimensions": 1})
    async with AsyncClient(api_key="sk-test", base_url="https://api.schift.io") as client:
        result = await client.embed("hello")
        assert isinstance(result, EmbedResponse)

@pytest.mark.asyncio
@respx.mock
async def test_async_similarity():
    respx.post("https://api.schift.io/v1/similarity").respond(json={"score": 0.9})
    async with AsyncClient(api_key="sk-test", base_url="https://api.schift.io") as client:
        assert await client.similarity("a", "b") == 0.9
