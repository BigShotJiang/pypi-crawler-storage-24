"""Tests for the SDK workflow execution engine."""
from __future__ import annotations

import asyncio
import textwrap

import pytest

from schift.workflow_models import BlockDef, EdgeDef, WorkflowDefinition
from schift.workflow_engine import (
    AsyncWorkflowRunner,
    BlockRunResult,
    SDKExecutionContext,
    WorkflowRunResult,
    WorkflowRunner,
)
from schift.workflow_nodes import (
    SDKBaseNode,
    get_node_handler,
    register_custom_node,
    unregister_custom_node,
)


# ---- Helpers ----

def _linear_pipeline(*block_types: str) -> WorkflowDefinition:
    """Build a simple linear pipeline: block0 -> block1 -> ... -> blockN."""
    blocks = [BlockDef(id=f"b{i}", type=t) for i, t in enumerate(block_types)]
    edges = [
        EdgeDef(source=f"b{i}", target=f"b{i+1}")
        for i in range(len(block_types) - 1)
    ]
    return WorkflowDefinition(version=1, name="test", blocks=blocks, edges=edges)


# ============================================================
# SDKExecutionContext
# ============================================================

class TestSDKExecutionContext:
    def test_auto_generates_run_id(self):
        ctx = SDKExecutionContext()
        assert len(ctx.run_id) == 12

    def test_explicit_run_id(self):
        ctx = SDKExecutionContext(run_id="custom123")
        assert ctx.run_id == "custom123"

    def test_get_set_var(self):
        ctx = SDKExecutionContext()
        ctx.set_var("key", "value")
        assert ctx.get_var("key") == "value"
        assert ctx.get_var("missing", "default") == "default"

    def test_variables_from_init(self):
        ctx = SDKExecutionContext(variables={"a": 1, "b": 2})
        assert ctx.get_var("a") == 1


# ============================================================
# WorkflowRunner — basic execution
# ============================================================

class TestWorkflowRunner:
    def test_start_end_passthrough(self):
        wf = _linear_pipeline("start", "end")
        runner = WorkflowRunner(wf)
        result = runner.run(inputs={"query": "hello"})

        assert result.status == "completed"
        assert result.outputs["result"]["query"] == "hello"

    def test_empty_inputs(self):
        wf = _linear_pipeline("start", "end")
        runner = WorkflowRunner(wf)
        result = runner.run()

        assert result.status == "completed"
        assert result.outputs == {"result": {}}

    def test_block_states_recorded(self):
        wf = _linear_pipeline("start", "end")
        runner = WorkflowRunner(wf)
        result = runner.run(inputs={"x": 1})

        assert "b0" in result.block_states
        assert "b1" in result.block_states
        assert result.block_states["b0"].status == "completed"
        assert result.block_states["b1"].status == "completed"

    def test_timing_recorded(self):
        wf = _linear_pipeline("start", "end")
        runner = WorkflowRunner(wf)
        result = runner.run()

        assert result.started_at
        assert result.finished_at
        assert result.block_states["b0"].duration_ms >= 0

    def test_run_id_in_result(self):
        wf = _linear_pipeline("start", "end")
        runner = WorkflowRunner(wf)
        result = runner.run()
        assert len(result.run_id) == 12

    def test_validate_delegates_to_definition(self):
        wf = _linear_pipeline("start", "end")
        runner = WorkflowRunner(wf)
        errors = runner.validate()
        assert isinstance(errors, list)


# ============================================================
# AsyncWorkflowRunner
# ============================================================

class TestAsyncWorkflowRunner:
    def test_async_start_end(self):
        wf = _linear_pipeline("start", "end")
        runner = AsyncWorkflowRunner(wf)
        result = asyncio.run(runner.run(inputs={"q": "hi"}))

        assert result.status == "completed"
        assert result.outputs["result"]["q"] == "hi"


# ============================================================
# DAG Topology
# ============================================================

class TestDAGTopology:
    def test_cycle_raises(self):
        wf = WorkflowDefinition(
            version=1, name="cycle",
            blocks=[
                BlockDef(id="a", type="start"),
                BlockDef(id="b", type="end"),
            ],
            edges=[
                EdgeDef(source="a", target="b"),
                EdgeDef(source="b", target="a"),
            ],
        )
        runner = WorkflowRunner(wf)
        result = runner.run()
        assert result.status == "failed"
        assert "cycle" in result.error.lower()

    def test_diamond_dag(self):
        """A -> B, A -> C, B -> D, C -> D."""
        wf = WorkflowDefinition(
            version=1, name="diamond",
            blocks=[
                BlockDef(id="a", type="start"),
                BlockDef(id="b", type="variable", config={"mode": "set", "variables": {"from_b": True}}),
                BlockDef(id="c", type="variable", config={"mode": "set", "variables": {"from_c": True}}),
                BlockDef(id="d", type="end"),
            ],
            edges=[
                EdgeDef(source="a", target="b"),
                EdgeDef(source="a", target="c"),
                EdgeDef(source="b", target="d"),
                EdgeDef(source="c", target="d"),
            ],
        )
        runner = WorkflowRunner(wf)
        result = runner.run(inputs={"x": 1})
        assert result.status == "completed"

    def test_terminal_block_fallback_output(self):
        """When no END node exists, outputs come from terminal blocks."""
        wf = WorkflowDefinition(
            version=1, name="no-end",
            blocks=[
                BlockDef(id="a", type="start"),
                BlockDef(id="b", type="variable", config={"mode": "set_get", "variables": {"out": 42}}),
            ],
            edges=[EdgeDef(source="a", target="b")],
        )
        runner = WorkflowRunner(wf)
        result = runner.run(inputs={"in": 1})
        assert result.status == "completed"
        assert "out" in result.outputs


# ============================================================
# Condition Branching
# ============================================================

class TestConditionBranching:
    def test_true_branch_executes(self):
        wf = WorkflowDefinition(
            version=1, name="cond",
            blocks=[
                BlockDef(id="start", type="start"),
                BlockDef(id="cond", type="condition", config={
                    "field": "x", "operator": "gt", "value": 5,
                }),
                BlockDef(id="yes", type="end"),
                BlockDef(id="no", type="end"),
            ],
            edges=[
                EdgeDef(source="start", target="cond"),
                EdgeDef(source="cond", target="yes", source_handle="true"),
                EdgeDef(source="cond", target="no", source_handle="false"),
            ],
        )
        runner = WorkflowRunner(wf)
        result = runner.run(inputs={"x": 10})
        assert result.status == "completed"
        # "no" branch should be skipped
        assert result.block_states["no"].outputs.get("_skipped") is True
        # "yes" branch should execute
        assert result.block_states["yes"].status == "completed"

    def test_false_branch_executes(self):
        wf = WorkflowDefinition(
            version=1, name="cond-false",
            blocks=[
                BlockDef(id="start", type="start"),
                BlockDef(id="cond", type="condition", config={
                    "field": "x", "operator": "gt", "value": 5,
                }),
                BlockDef(id="yes", type="end"),
                BlockDef(id="no", type="end"),
            ],
            edges=[
                EdgeDef(source="start", target="cond"),
                EdgeDef(source="cond", target="yes", source_handle="true"),
                EdgeDef(source="cond", target="no", source_handle="false"),
            ],
        )
        runner = WorkflowRunner(wf)
        result = runner.run(inputs={"x": 2})
        assert result.block_states["yes"].outputs.get("_skipped") is True
        assert result.block_states["no"].status == "completed"


# ============================================================
# Tier 1 Node Handlers
# ============================================================

class TestTier1Nodes:
    def test_condition_operators(self):
        pairs = [
            ("eq", 5, 5, True),
            ("eq", 5, 6, False),
            ("neq", 5, 6, True),
            ("gt", 10, 5, True),
            ("gt", 3, 5, False),
            ("lt", 3, 5, True),
            ("gte", 5, 5, True),
            ("lte", 5, 5, True),
            ("contains", "hello world", "world", True),
            ("contains", "hello", "xyz", False),
            ("empty", None, None, True),
            ("empty", "notempty", None, False),
            ("not_empty", "x", None, True),
            ("not_empty", None, None, False),
        ]
        from schift.workflow_nodes import ConditionNode
        for op, actual, expected, want in pairs:
            assert ConditionNode._evaluate(actual, op, expected) is want, f"Failed: {op} {actual} {expected}"

    def test_variable_set_get(self):
        wf = WorkflowDefinition(
            version=1, name="var",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="v", type="variable", config={
                    "mode": "set_get",
                    "variables": {"greeting": "hello"},
                    "keys": ["greeting"],
                }),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="v"),
                EdgeDef(source="v", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run()
        assert result.status == "completed"
        assert result.block_states["v"].outputs["greeting"] == "hello"

    def test_prompt_template(self):
        wf = WorkflowDefinition(
            version=1, name="prompt",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="p", type="prompt_template", config={
                    "template": "Answer this: {{query}}",
                    "system_prompt": "You are a helpful assistant.",
                }),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="p"),
                EdgeDef(source="p", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"query": "What is 2+2?"})
        assert result.status == "completed"
        prompt_out = result.block_states["p"].outputs
        assert "Answer this: What is 2+2?" == prompt_out["prompt"]
        assert prompt_out["system_prompt"] == "You are a helpful assistant."

    def test_prompt_template_list_variable(self):
        wf = WorkflowDefinition(
            version=1, name="prompt-list",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="p", type="prompt_template", config={
                    "template": "Sources:\n{{results}}",
                }),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="p"),
                EdgeDef(source="p", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={
            "results": [{"text": "doc1"}, {"text": "doc2"}],
        })
        prompt_out = result.block_states["p"].outputs["prompt"]
        assert "doc1" in prompt_out
        assert "doc2" in prompt_out

    def test_loop_node(self):
        wf = WorkflowDefinition(
            version=1, name="loop",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="l", type="loop", config={"input_key": "items"}),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="l"),
                EdgeDef(source="l", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"items": ["a", "b", "c"]})
        assert result.status == "completed"
        loop_out = result.block_states["l"].outputs
        assert loop_out["count"] == 3
        assert len(loop_out["iterations"]) == 3
        assert loop_out["item"] == "a"

    def test_loop_exceeds_max_iterations(self):
        wf = WorkflowDefinition(
            version=1, name="loop-max",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="l", type="loop", config={
                    "input_key": "items", "max_iterations": 2,
                }),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="l"),
                EdgeDef(source="l", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"items": [1, 2, 3]})
        assert result.status == "failed"
        assert "max_iterations" in result.error

    def test_merge_node(self):
        wf = WorkflowDefinition(
            version=1, name="merge",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="m", type="merge"),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="m"),
                EdgeDef(source="m", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"a": 1, "b": 2})
        assert result.status == "completed"
        assert result.block_states["m"].outputs["merged"] == {"a": 1, "b": 2}

    def test_router_keyword(self):
        wf = WorkflowDefinition(
            version=1, name="router",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="r", type="router", config={
                    "strategy": "keyword",
                    "routes": [
                        {"name": "tech", "condition": ["python", "code", "api"]},
                        {"name": "sales", "condition": ["buy", "price", "discount"]},
                    ],
                    "default_route": "general",
                }),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="r"),
                EdgeDef(source="r", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"query": "how to use python api"})
        assert result.status == "completed"
        router_out = result.block_states["r"].outputs
        assert router_out["route"] == "tech"
        assert router_out["confidence"] > 0

    def test_router_regex(self):
        wf = WorkflowDefinition(
            version=1, name="router-regex",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="r", type="router", config={
                    "strategy": "regex",
                    "routes": [
                        {"name": "email", "condition": r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b"},
                        {"name": "phone", "condition": r"\d{3}-\d{4}"},
                    ],
                    "default_route": "other",
                }),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="r"),
                EdgeDef(source="r", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"query": "contact me at user@test.com"})
        assert result.block_states["r"].outputs["route"] == "email"

    def test_answer_node_text(self):
        wf = WorkflowDefinition(
            version=1, name="answer",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="a", type="answer", config={"format": "text"}),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="a"),
                EdgeDef(source="a", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"text": "The answer is 42."})
        assert result.block_states["a"].outputs["answer"] == "The answer is 42."

    def test_answer_node_max_length(self):
        wf = WorkflowDefinition(
            version=1, name="answer-trunc",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="a", type="answer", config={"max_length": 10}),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="a"),
                EdgeDef(source="a", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"text": "A very long answer here"})
        assert result.block_states["a"].outputs["answer"].endswith("...")

    def test_field_selector(self):
        wf = WorkflowDefinition(
            version=1, name="field-sel",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="f", type="field_selector", config={
                    "fields": ["name", "address.city"],
                }),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="f"),
                EdgeDef(source="f", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={
            "name": "Alice",
            "address": {"city": "Seoul", "zip": "12345"},
        })
        out = result.block_states["f"].outputs["out"]
        assert out["name"] == "Alice"
        assert out["address_city"] == "Seoul"

    def test_model_selector(self):
        wf = WorkflowDefinition(
            version=1, name="model-sel",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="m", type="model_selector", config={"model": "bge-m3"}),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="m"),
                EdgeDef(source="m", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"query": "test"})
        assert result.block_states["m"].outputs["model"] == "bge-m3"

    def test_reranker(self):
        wf = WorkflowDefinition(
            version=1, name="rerank",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="r", type="reranker", config={"top_k": 2}),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="r"),
                EdgeDef(source="r", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={
            "results": [
                {"id": "1", "score": 0.3},
                {"id": "2", "score": 0.9},
                {"id": "3", "score": 0.6},
            ],
        })
        reranked = result.block_states["r"].outputs["results"]
        assert len(reranked) == 2
        assert reranked[0]["id"] == "2"
        assert reranked[1]["id"] == "3"


# ============================================================
# Tier 3 — Server-Only Stubs
# ============================================================

class TestTier3Stubs:
    @pytest.mark.parametrize("block_type", [
        "document_loader", "document_parser", "chunker", "code",
        "http_request", "webhook", "webhook_source",
        "ingest_bridge", "feed_poll", "ai_router",
    ])
    def test_server_only_raises(self, block_type):
        wf = WorkflowDefinition(
            version=1, name="server-only",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="x", type=block_type),
            ],
            edges=[EdgeDef(source="s", target="x")],
        )
        result = WorkflowRunner(wf).run(inputs={})
        assert result.status == "failed"
        assert "server-only" in result.error.lower()

    def test_notify_is_skipped(self):
        wf = WorkflowDefinition(
            version=1, name="notify-skip",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="n", type="notify"),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="n"),
                EdgeDef(source="n", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run()
        assert result.status == "completed"
        assert result.block_states["n"].outputs.get("_skipped") is True

    def test_unknown_type_passthrough(self):
        wf = WorkflowDefinition(
            version=1, name="unknown",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="x", type="my_custom_unknown_type"),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="x"),
                EdgeDef(source="x", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={"data": "hello"})
        assert result.status == "completed"


# ============================================================
# Custom Node Registration
# ============================================================

class TestCustomNodes:
    def test_register_and_execute(self):
        class DoubleNode(SDKBaseNode):
            async def execute(self, inputs, ctx):
                val = inputs.get("value", 0)
                return {"result": val * 2}

        register_custom_node("doubler", DoubleNode)
        try:
            wf = WorkflowDefinition(
                version=1, name="custom",
                blocks=[
                    BlockDef(id="s", type="start"),
                    BlockDef(id="d", type="doubler"),
                    BlockDef(id="e", type="end"),
                ],
                edges=[
                    EdgeDef(source="s", target="d"),
                    EdgeDef(source="d", target="e"),
                ],
            )
            result = WorkflowRunner(wf).run(inputs={"value": 21})
            assert result.status == "completed"
            assert result.block_states["d"].outputs["result"] == 42
        finally:
            unregister_custom_node("doubler")

    def test_cannot_override_builtin(self):
        class FakeStart(SDKBaseNode):
            async def execute(self, inputs, ctx):
                return {}

        with pytest.raises(ValueError, match="Cannot override"):
            register_custom_node("start", FakeStart)

    def test_custom_node_with_config(self):
        class MultiplierNode(SDKBaseNode):
            async def execute(self, inputs, ctx):
                factor = self.config.get("factor", 1)
                val = inputs.get("value", 0)
                return {"result": val * factor}

        register_custom_node("multiplier", MultiplierNode)
        try:
            wf = WorkflowDefinition(
                version=1, name="custom-config",
                blocks=[
                    BlockDef(id="s", type="start"),
                    BlockDef(id="m", type="multiplier", config={"factor": 10}),
                    BlockDef(id="e", type="end"),
                ],
                edges=[
                    EdgeDef(source="s", target="m"),
                    EdgeDef(source="m", target="e"),
                ],
            )
            result = WorkflowRunner(wf).run(inputs={"value": 5})
            assert result.block_states["m"].outputs["result"] == 50
        finally:
            unregister_custom_node("multiplier")


# ============================================================
# Error Handling
# ============================================================

class TestErrorHandling:
    def test_block_failure_stops_pipeline(self):
        class FailingNode(SDKBaseNode):
            async def execute(self, inputs, ctx):
                raise RuntimeError("Something broke")

        register_custom_node("failing", FailingNode)
        try:
            wf = WorkflowDefinition(
                version=1, name="fail",
                blocks=[
                    BlockDef(id="s", type="start"),
                    BlockDef(id="f", type="failing"),
                    BlockDef(id="e", type="end"),
                ],
                edges=[
                    EdgeDef(source="s", target="f"),
                    EdgeDef(source="f", target="e"),
                ],
            )
            result = WorkflowRunner(wf).run()
            assert result.status == "failed"
            assert "Something broke" in result.error
            assert result.block_states["f"].status == "failed"
            # End node should not have been executed
            assert "e" not in result.block_states
        finally:
            unregister_custom_node("failing")

    def test_no_client_for_embedder(self):
        wf = WorkflowDefinition(
            version=1, name="no-client",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="emb", type="embedder"),
            ],
            edges=[EdgeDef(source="s", target="emb")],
        )
        result = WorkflowRunner(wf).run(inputs={"text": "hello"})
        assert result.status == "failed"
        assert "Client" in result.error

    def test_no_client_for_retriever(self):
        wf = WorkflowDefinition(
            version=1, name="no-client",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="ret", type="retriever", config={"collection": "test"}),
            ],
            edges=[EdgeDef(source="s", target="ret")],
        )
        result = WorkflowRunner(wf).run(inputs={"query": "hello"})
        assert result.status == "failed"
        assert "Client" in result.error

    def test_retriever_missing_collection_config(self):
        wf = WorkflowDefinition(
            version=1, name="no-collection",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="ret", type="retriever", config={}),
            ],
            edges=[EdgeDef(source="s", target="ret")],
        )
        # Need a mock client — use a simple object
        class FakeClient:
            pass
        result = WorkflowRunner(wf, client=FakeClient()).run(inputs={"query": "hello"})
        assert result.status == "failed"
        assert "collection" in result.error.lower()


# ============================================================
# Context Variable Propagation
# ============================================================

class TestContextVariables:
    def test_outputs_published_as_context_vars(self):
        """Each block's outputs are available as {block_id}.{key} variables."""
        class CheckContextNode(SDKBaseNode):
            async def execute(self, inputs, ctx):
                # Should be able to read start block's output
                query = ctx.get_var("s.query")
                return {"found_query": query}

        register_custom_node("check_ctx", CheckContextNode)
        try:
            wf = WorkflowDefinition(
                version=1, name="ctx-vars",
                blocks=[
                    BlockDef(id="s", type="start"),
                    BlockDef(id="c", type="check_ctx"),
                    BlockDef(id="e", type="end"),
                ],
                edges=[
                    EdgeDef(source="s", target="c"),
                    EdgeDef(source="c", target="e"),
                ],
            )
            result = WorkflowRunner(wf).run(inputs={"query": "test123"})
            assert result.status == "completed"
            assert result.block_states["c"].outputs["found_query"] == "test123"
        finally:
            unregister_custom_node("check_ctx")


# ============================================================
# Node Handler Registry
# ============================================================

class TestNodeRegistry:
    def test_builtin_types_resolve(self):
        for btype in ["start", "end", "condition", "router", "loop",
                       "merge", "variable", "prompt_template", "answer",
                       "embedder", "retriever", "reranker", "vector_store"]:
            block = BlockDef(id="test", type=btype)
            handler = get_node_handler(block)
            assert handler is not None
            assert handler.block.id == "test"

    def test_unknown_type_gets_passthrough(self):
        block = BlockDef(id="test", type="totally_unknown_xyz")
        handler = get_node_handler(block)
        from schift.workflow_nodes import PassthroughNode
        assert isinstance(handler, PassthroughNode)


# ============================================================
# Metadata Extractor (Regex)
# ============================================================

class TestMetadataExtractor:
    def test_regex_extraction(self):
        wf = WorkflowDefinition(
            version=1, name="metadata",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="m", type="metadata_extractor", config={
                    "strategy": "regex",
                    "fields": [
                        {"name": "email", "pattern": r"([\w.+-]+@[\w-]+\.[\w.-]+)", "type": "str"},
                        {"name": "amount", "pattern": r"\$(\d+(?:\.\d+)?)", "type": "float"},
                    ],
                }),
                BlockDef(id="e", type="end"),
            ],
            edges=[
                EdgeDef(source="s", target="m"),
                EdgeDef(source="m", target="e"),
            ],
        )
        result = WorkflowRunner(wf).run(inputs={
            "text": "Contact user@test.com, total $99.50",
        })
        assert result.status == "completed"
        meta = result.block_states["m"].outputs["metadata"]
        assert len(meta) == 1
        assert meta[0]["email"] == "user@test.com"
        assert meta[0]["amount"] == 99.50

    def test_llm_mode_raises(self):
        wf = WorkflowDefinition(
            version=1, name="metadata-llm",
            blocks=[
                BlockDef(id="s", type="start"),
                BlockDef(id="m", type="metadata_extractor", config={
                    "strategy": "llm",
                    "schema": {"name": "str"},
                }),
            ],
            edges=[EdgeDef(source="s", target="m")],
        )
        result = WorkflowRunner(wf).run(inputs={"text": "hello"})
        assert result.status == "failed"
        assert "not supported" in result.error.lower()
