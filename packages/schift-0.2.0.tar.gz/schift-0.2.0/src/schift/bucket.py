"""Bucket operations for Schift SDK."""
from __future__ import annotations
from typing import TYPE_CHECKING
from dataclasses import dataclass, field

if TYPE_CHECKING:
    import httpx

@dataclass
class JobInfo:
    job_id: str
    file_name: str
    status: str
    estimated_cost: float = 0
    actual_cost: float | None = None
    chunks_count: int | None = None
    error_message: str | None = None
    created_at: str = ""
    completed_at: str | None = None

@dataclass
class BucketStats:
    vector_count: int
    file_count: int
    total_cost: float

@dataclass
class UploadResult:
    jobs: list[JobInfo]
    total_estimated_cost: float
    credit_balance_after_hold: float


class Bucket:
    """Sync bucket operations."""

    def __init__(self, bucket_id: str, http: httpx.Client, headers: dict):
        self._id = bucket_id
        self._http = http
        self._headers = headers

    def upload(self, files: list[tuple[str, bytes]], task: str = "retrieval_document") -> UploadResult:
        """Upload files to bucket. files = [(filename, bytes), ...]"""
        multipart = [("files", (name, data)) for name, data in files]
        resp = self._http.post(
            f"/v1/buckets/{self._id}/upload",
            files=multipart,
            headers=self._headers,
        )
        resp.raise_for_status()
        d = resp.json()
        return UploadResult(
            jobs=[JobInfo(**j) for j in d.get("jobs", [])],
            total_estimated_cost=d.get("total_estimated_cost", 0),
            credit_balance_after_hold=d.get("credit_balance_after_hold", 0),
        )

    def upload_file(self, filepath: str, task: str = "retrieval_document") -> UploadResult:
        """Upload a single file by path."""
        import os
        name = os.path.basename(filepath)
        with open(filepath, "rb") as f:
            data = f.read()
        return self.upload([(name, data)], task=task)

    def jobs(self, status: str | None = None) -> list[JobInfo]:
        """List processing jobs for this bucket."""
        params = {"bucket_id": self._id}
        if status:
            params["status"] = status
        resp = self._http.get("/v1/jobs", params=params, headers=self._headers)
        resp.raise_for_status()
        return [JobInfo(**{k: j.get(k) for k in JobInfo.__dataclass_fields__}) for j in resp.json()]

    def job(self, job_id: str) -> JobInfo:
        """Get specific job status."""
        resp = self._http.get(f"/v1/jobs/{job_id}", headers=self._headers)
        resp.raise_for_status()
        j = resp.json()
        return JobInfo(**{k: j.get(k) for k in JobInfo.__dataclass_fields__})

    def cancel_job(self, job_id: str) -> dict:
        """Cancel a queued job."""
        resp = self._http.post(f"/v1/jobs/{job_id}/cancel", json={}, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    def search(self, query: str, top_k: int = 10, task: str = "retrieval_query",
               filter: dict | None = None) -> list[dict]:
        """Search within bucket."""
        body = {"query": query, "top_k": top_k, "task": task}
        if filter:
            body["filter"] = filter
        resp = self._http.post(f"/v1/buckets/{self._id}/search", json=body, headers=self._headers)
        resp.raise_for_status()
        return resp.json().get("results", [])

    def stats(self) -> BucketStats:
        """Get bucket stats."""
        resp = self._http.get(f"/v1/collections/{self._id}/stats", headers=self._headers)
        resp.raise_for_status()
        d = resp.json()
        return BucketStats(
            vector_count=d.get("vector_count", 0),
            file_count=d.get("file_count", 0),
            total_cost=d.get("total_cost", 0),
        )

    def delete(self) -> None:
        """Delete the bucket and all its data."""
        resp = self._http.delete(f"/v1/buckets/{self._id}", headers=self._headers)
        resp.raise_for_status()


class AsyncBucket:
    """Async bucket operations."""

    def __init__(self, bucket_id: str, http: httpx.AsyncClient, headers: dict):
        self._id = bucket_id
        self._http = http
        self._headers = headers

    async def upload(self, files: list[tuple[str, bytes]], task: str = "retrieval_document") -> UploadResult:
        multipart = [("files", (name, data)) for name, data in files]
        resp = await self._http.post(f"/v1/buckets/{self._id}/upload", files=multipart, headers=self._headers)
        resp.raise_for_status()
        d = resp.json()
        return UploadResult(
            jobs=[JobInfo(**j) for j in d.get("jobs", [])],
            total_estimated_cost=d.get("total_estimated_cost", 0),
            credit_balance_after_hold=d.get("credit_balance_after_hold", 0),
        )

    async def jobs(self, status: str | None = None) -> list[JobInfo]:
        params = {"bucket_id": self._id}
        if status:
            params["status"] = status
        resp = await self._http.get("/v1/jobs", params=params, headers=self._headers)
        resp.raise_for_status()
        return [JobInfo(**{k: j.get(k) for k in JobInfo.__dataclass_fields__}) for j in resp.json()]

    async def search(self, query: str, top_k: int = 10, task: str = "retrieval_query",
                     filter: dict | None = None) -> list[dict]:
        body = {"query": query, "top_k": top_k, "task": task}
        if filter:
            body["filter"] = filter
        resp = await self._http.post(f"/v1/buckets/{self._id}/search", json=body, headers=self._headers)
        resp.raise_for_status()
        return resp.json().get("results", [])

    async def delete(self) -> None:
        resp = await self._http.delete(f"/v1/buckets/{self._id}", headers=self._headers)
        resp.raise_for_status()
