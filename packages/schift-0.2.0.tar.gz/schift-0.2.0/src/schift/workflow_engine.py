"""Local workflow execution engine for Schift SDK.

Runs WorkflowDefinition DAGs locally, delegating API calls
through the Schift Client. Supports custom node registration.

Usage::

    from schift import Client
    from schift.workflow_engine import WorkflowRunner

    client = Client(api_key="...")
    wf = Workflow.from_yaml("pipeline.yaml")
    runner = WorkflowRunner(wf, client=client)
    result = runner.run(inputs={"query": "hello"})
"""
from __future__ import annotations

import asyncio
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, TYPE_CHECKING

from schift.workflow_models import BlockDef, EdgeDef, WorkflowDefinition

if TYPE_CHECKING:
    from schift.client import Client
    from schift.async_client import AsyncClient


# ---- Context & Result Types ----

@dataclass
class SDKExecutionContext:
    """Execution context for SDK-side workflow runs.

    Replaces the backend's ``ExecutionContext`` — carries a Schift ``Client``
    (or ``AsyncClient``) instead of ``store`` / ``vectordb_resolver``.
    """
    client: Any = None
    run_id: str = ""
    variables: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.run_id:
            self.run_id = uuid.uuid4().hex[:12]

    def get_var(self, key: str, default: Any = None) -> Any:
        return self.variables.get(key, default)

    def set_var(self, key: str, value: Any) -> None:
        self.variables[key] = value


@dataclass
class BlockRunResult:
    """Result of executing a single block."""
    block_id: str
    status: str = "completed"
    inputs: dict[str, Any] = field(default_factory=dict)
    outputs: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    duration_ms: int = 0


@dataclass
class WorkflowRunResult:
    """Result of executing a complete workflow."""
    run_id: str = ""
    status: str = "completed"
    inputs: dict[str, Any] = field(default_factory=dict)
    outputs: dict[str, Any] = field(default_factory=dict)
    block_states: dict[str, BlockRunResult] = field(default_factory=dict)
    error: str | None = None
    started_at: str = ""
    finished_at: str = ""


# ---- Internal Async Engine ----

class _Engine:
    """Async DAG execution engine (ported from api/server/workflow/engine.py)."""

    def __init__(self, definition: WorkflowDefinition, client: Any = None):
        self.definition = definition
        self.client = client
        self._adjacency: dict[str, list[EdgeDef]] = defaultdict(list)
        self._reverse: dict[str, list[EdgeDef]] = defaultdict(list)
        self._blocks: dict[str, BlockDef] = {}

        for block in definition.blocks:
            self._blocks[block.id] = block
        for edge in definition.edges:
            self._adjacency[edge.source].append(edge)
            self._reverse[edge.target].append(edge)

    async def run(self, inputs: dict[str, Any] | None = None) -> WorkflowRunResult:
        from schift.workflow_nodes import get_node_handler

        ctx = SDKExecutionContext(
            client=self.client,
            variables=dict(inputs or {}),
        )

        result = WorkflowRunResult(
            run_id=ctx.run_id,
            inputs=inputs or {},
            started_at=datetime.now(timezone.utc).isoformat(),
            status="running",
        )

        try:
            order = self._topo_sort()
            block_outputs: dict[str, dict[str, Any]] = {}

            for block_id in order:
                block = self._blocks[block_id]

                resolved_inputs = self._resolve_inputs(block_id, block_outputs, ctx)

                # Skip blocks on inactive condition branches
                if self._is_skipped(block_id, block_outputs):
                    state = BlockRunResult(
                        block_id=block_id,
                        outputs={"_skipped": True},
                    )
                    result.block_states[block_id] = state
                    block_outputs[block_id] = state.outputs
                    continue

                # Notify blocks are not executed by the DAG
                if block.type == "notify":
                    state = BlockRunResult(
                        block_id=block_id,
                        outputs={"_skipped": True},
                    )
                    result.block_states[block_id] = state
                    block_outputs[block_id] = state.outputs
                    continue

                # Execute block
                handler = get_node_handler(block)
                t0 = time.monotonic()
                state = BlockRunResult(
                    block_id=block_id,
                    inputs=resolved_inputs,
                )
                try:
                    outputs = await handler.execute(resolved_inputs, ctx)
                    state.outputs = outputs
                    state.status = "completed"
                except Exception as exc:
                    state.error = str(exc)
                    state.status = "failed"
                finally:
                    state.duration_ms = int((time.monotonic() - t0) * 1000)

                result.block_states[block_id] = state
                block_outputs[block_id] = state.outputs

                if state.status == "failed":
                    result.status = "failed"
                    result.error = (
                        f"Block '{block.title or block.id}' failed: {state.error}"
                    )
                    break

                # Publish outputs as context variables
                for key, value in state.outputs.items():
                    ctx.set_var(f"{block_id}.{key}", value)

            else:
                result.status = "completed"

            result.outputs = self._collect_outputs(block_outputs)

        except Exception as exc:
            result.status = "failed"
            result.error = str(exc)
        finally:
            result.finished_at = datetime.now(timezone.utc).isoformat()

        return result

    # -- DAG helpers (ported from backend engine.py) --

    def _topo_sort(self) -> list[str]:
        """Kahn's algorithm for topological sort."""
        in_degree: dict[str, int] = {bid: 0 for bid in self._blocks}
        for edge in self.definition.edges:
            in_degree[edge.target] = in_degree.get(edge.target, 0) + 1

        queue = [bid for bid, deg in in_degree.items() if deg == 0]
        order: list[str] = []

        while queue:
            node = queue.pop(0)
            order.append(node)
            for edge in self._adjacency[node]:
                in_degree[edge.target] -= 1
                if in_degree[edge.target] == 0:
                    queue.append(edge.target)

        if len(order) != len(self._blocks):
            raise ValueError("Workflow contains a cycle — not a valid DAG")

        return order

    def _resolve_inputs(
        self,
        block_id: str,
        block_outputs: dict[str, dict[str, Any]],
        ctx: SDKExecutionContext,
    ) -> dict[str, Any]:
        """Gather inputs from upstream block outputs."""
        block = self._blocks[block_id]
        if block.type == "start":
            return dict(ctx.variables)

        inputs: dict[str, Any] = {}
        for edge in self._reverse.get(block_id, []):
            upstream_outputs = block_outputs.get(edge.source, {})
            if edge.source_handle == "output":
                inputs.update(upstream_outputs)
            else:
                inputs[edge.source_handle] = upstream_outputs

        return inputs

    def _is_skipped(
        self,
        block_id: str,
        block_outputs: dict[str, dict[str, Any]],
    ) -> bool:
        """Check if a block should be skipped due to condition branching."""
        for edge in self._reverse.get(block_id, []):
            upstream_outputs = block_outputs.get(edge.source, {})
            branch = upstream_outputs.get("branch")
            if branch is not None:
                expected = edge.source_handle  # "true" or "false"
                if branch != expected:
                    return True
        return False

    def _collect_outputs(
        self,
        block_outputs: dict[str, dict[str, Any]],
    ) -> dict[str, Any]:
        """Collect outputs from END blocks, or fallback to terminal blocks."""
        final: dict[str, Any] = {}

        for block_id, block in self._blocks.items():
            if block.type == "end":
                out = block_outputs.get(block_id, {})
                final.update(out)

        if final:
            return final

        # Fallback: blocks with no downstream edges
        terminal_ids = set(self._blocks.keys()) - {
            e.source for e in self.definition.edges
        }
        for tid in terminal_ids:
            out = block_outputs.get(tid, {})
            final.update(out)

        return final


# ---- Public API ----

class WorkflowRunner:
    """Sync workflow runner.

    Usage::

        from schift import Client
        from schift.workflow_engine import WorkflowRunner

        client = Client(api_key="...")
        wf = Workflow.from_yaml("pipeline.yaml")
        runner = WorkflowRunner(wf, client=client)
        result = runner.run(inputs={"query": "hello"})
        print(result.status, result.outputs)
    """

    def __init__(
        self,
        definition: WorkflowDefinition,
        client: "Client | AsyncClient | None" = None,
    ):
        self._engine = _Engine(definition, client=client)

    def run(self, inputs: dict[str, Any] | None = None) -> WorkflowRunResult:
        """Execute the workflow synchronously."""
        return asyncio.run(self._engine.run(inputs))

    def validate(self) -> list[str]:
        """Validate the workflow DAG locally."""
        return self._engine.definition.validate()


class AsyncWorkflowRunner:
    """Async workflow runner.

    Usage::

        from schift import AsyncClient
        from schift.workflow_engine import AsyncWorkflowRunner

        client = AsyncClient(api_key="...")
        runner = AsyncWorkflowRunner(wf, client=client)
        result = await runner.run(inputs={"query": "hello"})
    """

    def __init__(
        self,
        definition: WorkflowDefinition,
        client: "Client | AsyncClient | None" = None,
    ):
        self._engine = _Engine(definition, client=client)

    async def run(self, inputs: dict[str, Any] | None = None) -> WorkflowRunResult:
        """Execute the workflow asynchronously."""
        return await self._engine.run(inputs)

    def validate(self) -> list[str]:
        """Validate the workflow DAG locally."""
        return self._engine.definition.validate()
