from __future__ import annotations
from typing import TYPE_CHECKING
from schift.models import SearchResult

if TYPE_CHECKING:
    import httpx

class Collection:
    def __init__(self, name: str, http: httpx.Client, headers: dict):
        self._name = name
        self._http = http
        self._headers = headers

    def add(self, documents: list[str], ids: list[str] | None = None,
            metadata: list[dict] | None = None, task: str | None = None,
            model: str | None = None) -> dict:
        body: dict = {"documents": documents}
        if ids: body["ids"] = ids
        if metadata: body["metadata"] = metadata
        if task: body["task"] = task
        if model: body["model"] = model
        resp = self._http.post(f"/v1/collections/{self._name}/add", json=body, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    def search(self, query: str, task: str | None = None, top_k: int = 10,
               filter: dict | None = None, model: str | None = None) -> list[SearchResult]:
        body: dict = {"query": query, "top_k": top_k}
        if task: body["task"] = task
        if filter: body["filter"] = filter
        if model: body["model"] = model
        resp = self._http.post(f"/v1/collections/{self._name}/search", json=body, headers=self._headers)
        resp.raise_for_status()
        return [SearchResult(**r) for r in resp.json().get("results", [])]

    def upsert(self, vectors: list[dict]) -> dict:
        resp = self._http.post(f"/v1/collections/{self._name}/vectors", json={"vectors": vectors}, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    def search_by_vector(self, query_vector: list[float], top_k: int = 10) -> list[SearchResult]:
        resp = self._http.post("/v1/query", json={"query_vector": query_vector, "collection": self._name, "top_k": top_k}, headers=self._headers)
        resp.raise_for_status()
        data = resp.json()
        return [SearchResult(**r) for r in (data.get("results", data) if isinstance(data, dict) else data)]


class AsyncCollection:
    def __init__(self, name: str, http: httpx.AsyncClient, headers: dict):
        self._name = name
        self._http = http
        self._headers = headers

    async def add(self, documents: list[str], ids: list[str] | None = None,
                  metadata: list[dict] | None = None, task: str | None = None,
                  model: str | None = None) -> dict:
        body: dict = {"documents": documents}
        if ids: body["ids"] = ids
        if metadata: body["metadata"] = metadata
        if task: body["task"] = task
        if model: body["model"] = model
        resp = await self._http.post(f"/v1/collections/{self._name}/add", json=body, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    async def search(self, query: str, task: str | None = None, top_k: int = 10,
                     filter: dict | None = None, model: str | None = None) -> list[SearchResult]:
        body: dict = {"query": query, "top_k": top_k}
        if task: body["task"] = task
        if filter: body["filter"] = filter
        if model: body["model"] = model
        resp = await self._http.post(f"/v1/collections/{self._name}/search", json=body, headers=self._headers)
        resp.raise_for_status()
        return [SearchResult(**r) for r in resp.json().get("results", [])]

    async def upsert(self, vectors: list[dict]) -> dict:
        resp = await self._http.post(f"/v1/collections/{self._name}/vectors", json={"vectors": vectors}, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    async def search_by_vector(self, query_vector: list[float], top_k: int = 10) -> list[SearchResult]:
        resp = await self._http.post("/v1/query", json={"query_vector": query_vector, "collection": self._name, "top_k": top_k}, headers=self._headers)
        resp.raise_for_status()
        data = resp.json()
        return [SearchResult(**r) for r in (data.get("results", data) if isinstance(data, dict) else data)]
