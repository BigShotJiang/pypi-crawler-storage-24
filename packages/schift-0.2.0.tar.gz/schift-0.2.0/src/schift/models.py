from __future__ import annotations
from dataclasses import dataclass

@dataclass
class EmbedResponse:
    values: list[float]
    model: str
    dimensions: int

@dataclass
class SearchResult:
    id: str
    metadata: dict
    score: float

@dataclass
class ClusterResult:
    labels: list[int]
    centroids: list[list[float]]
    n_clusters: int

@dataclass
class ClassifyResult:
    label: str
    scores: dict[str, float]
