"""Workflow operations for Schift SDK."""
from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING, Any
from schift.workflow_models import WorkflowResponse, RunResponse, ValidationResult, WorkflowDefinition

if TYPE_CHECKING:
    import httpx


class Workflow:
    """Sync workflow operations."""

    def __init__(self, http: httpx.Client, headers: dict):
        self._http = http
        self._headers = headers

    def _post(self, path: str, body: dict | None = None):
        resp = self._http.post(path, json=body or {}, headers=self._headers)
        resp.raise_for_status()
        return resp.json() if resp.content else None

    def _get(self, path: str):
        resp = self._http.get(path, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    def _patch(self, path: str, body: dict):
        resp = self._http.patch(path, json=body, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    def _delete(self, path: str):
        resp = self._http.delete(path, headers=self._headers)
        resp.raise_for_status()

    def _parse_workflow(self, data: dict) -> WorkflowResponse:
        return WorkflowResponse(
            id=data.get("id", ""),
            name=data.get("name", ""),
            status=data.get("status", ""),
            description=data.get("description", ""),
            graph=data.get("graph", {}),
        )

    def _parse_run(self, data: dict) -> RunResponse:
        return RunResponse(
            run_id=data.get("run_id", ""),
            status=data.get("status", ""),
            outputs=data.get("outputs") or {},
            error=data.get("error"),
            block_states=data.get("block_states") or {},
        )

    def create(self, name: str, template: str | None = None,
               description: str = "") -> WorkflowResponse:
        body: dict = {"name": name, "description": description}
        if template:
            body["template"] = template
        data = self._post("/v1/workflows", body)
        return self._parse_workflow(data)

    def get(self, workflow_id: str) -> WorkflowResponse:
        data = self._get(f"/v1/workflows/{workflow_id}")
        return self._parse_workflow(data)

    def list(self) -> list[WorkflowResponse]:
        data = self._get("/v1/workflows")
        return [self._parse_workflow(d) for d in data]

    def update(self, workflow_id: str, **kwargs) -> WorkflowResponse:
        data = self._patch(f"/v1/workflows/{workflow_id}", kwargs)
        return self._parse_workflow(data)

    def delete(self, workflow_id: str) -> None:
        self._delete(f"/v1/workflows/{workflow_id}")

    def run(self, workflow_id: str, inputs: dict | None = None) -> RunResponse:
        data = self._post(f"/v1/workflows/{workflow_id}/run", {"inputs": inputs or {}})
        return self._parse_run(data)

    def runs(self, workflow_id: str) -> list[RunResponse]:
        data = self._get(f"/v1/workflows/{workflow_id}/runs")
        return [self._parse_run(d) for d in data]

    def validate(self, workflow_id: str) -> ValidationResult:
        data = self._post(f"/v1/workflows/{workflow_id}/validate")
        return ValidationResult(valid=data.get("valid", False), errors=data.get("errors", []))

    def add_block(self, workflow_id: str, block_type: str, title: str = "",
                  config: dict | None = None) -> dict:
        return self._post(f"/v1/workflows/{workflow_id}/blocks",
                          {"type": block_type, "title": title, "config": config or {}})

    def add_edge(self, workflow_id: str, source: str, target: str) -> dict:
        return self._post(f"/v1/workflows/{workflow_id}/edges",
                          {"source": source, "target": target})

    # ---- YAML ----

    @staticmethod
    def from_yaml(path_or_str: str | Path) -> WorkflowDefinition:
        """Load a WorkflowDefinition from a YAML file or string.

        If path_or_str is a path to an existing file, reads it.
        Otherwise, treats it as a YAML string.
        """
        from schift.workflow_yaml import workflow_from_yaml, workflow_from_yaml_file
        p = Path(path_or_str) if not isinstance(path_or_str, Path) else path_or_str
        if p.exists() and p.is_file():
            return workflow_from_yaml_file(p)
        return workflow_from_yaml(str(path_or_str))

    def to_yaml(self, workflow_id: str, path: str | Path | None = None) -> str:
        """Export a server-side workflow as YAML.

        Args:
            workflow_id: The workflow to export.
            path: Optional file path to write the YAML to.

        Returns:
            The YAML string.
        """
        from schift.workflow_yaml import workflow_to_yaml, workflow_to_yaml_file, definition_from_api_response
        data = self._get(f"/v1/workflows/{workflow_id}")
        definition = definition_from_api_response(data)
        if path:
            workflow_to_yaml_file(definition, path)
        return workflow_to_yaml(definition)

    def push_yaml(self, path_or_str: str | Path) -> WorkflowResponse:
        """Create a workflow on the server from a YAML file or string."""
        definition = self.from_yaml(path_or_str)
        api_dict = definition.to_api_dict()
        data = self._post("/v1/workflows", api_dict)
        return self._parse_workflow(data)

    # Template shortcuts
    def create_rag(self, name: str = "RAG Pipeline") -> WorkflowResponse:
        return self.create(name, template="BASIC_RAG")

    def create_doc_qa(self, name: str = "Document QA") -> WorkflowResponse:
        return self.create(name, template="DOCUMENT_QA")

    def create_chat(self, name: str = "Chat RAG") -> WorkflowResponse:
        return self.create(name, template="CHAT_RAG")

    def create_ocr_ingest(self, name: str = "OCR Ingest") -> WorkflowResponse:
        return self.create(name, template="IMAGE_OCR_INGEST")


class AsyncWorkflow:
    """Async workflow operations."""

    def __init__(self, http: httpx.AsyncClient, headers: dict):
        self._http = http
        self._headers = headers

    async def _post(self, path: str, body: dict | None = None):
        resp = await self._http.post(path, json=body or {}, headers=self._headers)
        resp.raise_for_status()
        return resp.json() if resp.content else None

    async def _get(self, path: str):
        resp = await self._http.get(path, headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    def _parse_workflow(self, data: dict) -> WorkflowResponse:
        return WorkflowResponse(
            id=data.get("id", ""),
            name=data.get("name", ""),
            status=data.get("status", ""),
            description=data.get("description", ""),
            graph=data.get("graph", {}),
        )

    def _parse_run(self, data: dict) -> RunResponse:
        return RunResponse(
            run_id=data.get("run_id", ""),
            status=data.get("status", ""),
            outputs=data.get("outputs") or {},
            error=data.get("error"),
            block_states=data.get("block_states") or {},
        )

    async def create(self, name: str, template: str | None = None,
                     description: str = "") -> WorkflowResponse:
        body: dict = {"name": name, "description": description}
        if template:
            body["template"] = template
        data = await self._post("/v1/workflows", body)
        return self._parse_workflow(data)

    async def get(self, workflow_id: str) -> WorkflowResponse:
        data = await self._get(f"/v1/workflows/{workflow_id}")
        return self._parse_workflow(data)

    async def list(self) -> list[WorkflowResponse]:
        data = await self._get("/v1/workflows")
        return [self._parse_workflow(d) for d in data]

    async def update(self, workflow_id: str, **kwargs) -> WorkflowResponse:
        resp = await self._http.patch(f"/v1/workflows/{workflow_id}",
                                      json=kwargs, headers=self._headers)
        resp.raise_for_status()
        return self._parse_workflow(resp.json())

    async def delete(self, workflow_id: str) -> None:
        resp = await self._http.delete(f"/v1/workflows/{workflow_id}",
                                       headers=self._headers)
        resp.raise_for_status()

    async def run(self, workflow_id: str, inputs: dict | None = None) -> RunResponse:
        data = await self._post(f"/v1/workflows/{workflow_id}/run", {"inputs": inputs or {}})
        return self._parse_run(data)

    async def runs(self, workflow_id: str) -> list[RunResponse]:
        data = await self._get(f"/v1/workflows/{workflow_id}/runs")
        return [self._parse_run(d) for d in data]

    async def validate(self, workflow_id: str) -> ValidationResult:
        data = await self._post(f"/v1/workflows/{workflow_id}/validate")
        return ValidationResult(valid=data.get("valid", False), errors=data.get("errors", []))

    async def add_block(self, workflow_id: str, block_type: str, title: str = "",
                        config: dict | None = None) -> dict:
        return await self._post(f"/v1/workflows/{workflow_id}/blocks",
                                {"type": block_type, "title": title, "config": config or {}})

    async def add_edge(self, workflow_id: str, source: str, target: str) -> dict:
        return await self._post(f"/v1/workflows/{workflow_id}/edges",
                                {"source": source, "target": target})

    # ---- YAML ----

    @staticmethod
    def from_yaml(path_or_str: str | Path) -> WorkflowDefinition:
        """Load a WorkflowDefinition from a YAML file or string."""
        from schift.workflow_yaml import workflow_from_yaml, workflow_from_yaml_file
        p = Path(path_or_str) if not isinstance(path_or_str, Path) else path_or_str
        if p.exists() and p.is_file():
            return workflow_from_yaml_file(p)
        return workflow_from_yaml(str(path_or_str))

    async def to_yaml(self, workflow_id: str, path: str | Path | None = None) -> str:
        """Export a server-side workflow as YAML."""
        from schift.workflow_yaml import workflow_to_yaml, workflow_to_yaml_file, definition_from_api_response
        data = await self._get(f"/v1/workflows/{workflow_id}")
        definition = definition_from_api_response(data)
        if path:
            workflow_to_yaml_file(definition, path)
        return workflow_to_yaml(definition)

    async def push_yaml(self, path_or_str: str | Path) -> WorkflowResponse:
        """Create a workflow on the server from a YAML file or string."""
        definition = self.from_yaml(path_or_str)
        api_dict = definition.to_api_dict()
        data = await self._post("/v1/workflows", api_dict)
        return self._parse_workflow(data)

    # Template shortcuts
    async def create_rag(self, name: str = "RAG Pipeline") -> WorkflowResponse:
        return await self.create(name, template="BASIC_RAG")

    async def create_doc_qa(self, name: str = "Document QA") -> WorkflowResponse:
        return await self.create(name, template="DOCUMENT_QA")

    async def create_chat(self, name: str = "Chat RAG") -> WorkflowResponse:
        return await self.create(name, template="CHAT_RAG")

    async def create_ocr_ingest(self, name: str = "OCR Ingest") -> WorkflowResponse:
        return await self.create(name, template="IMAGE_OCR_INGEST")
