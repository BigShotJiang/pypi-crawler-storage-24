"""YAML serialization for Schift workflows.

Converts between YAML files and WorkflowDefinition objects.
Uses yaml.safe_load() exclusively — yaml.load() is forbidden (RCE risk).

Install: pip install schift[yaml]
"""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any

from schift.workflow_models import (
    BlockDef,
    EdgeDef,
    Position,
    WorkflowDefinition,
    _title_from_type,
)

_CURRENT_SCHEMA_VERSION = 1


def _import_yaml():
    try:
        import yaml
        return yaml
    except ImportError:
        raise ImportError(
            "PyYAML is required for YAML support. "
            "Install it with: pip install schift[yaml]"
        ) from None


# ---- Public API ----

def workflow_from_yaml(yaml_str: str) -> WorkflowDefinition:
    """Parse a YAML string into a WorkflowDefinition.

    Raises:
        ValueError: On invalid/empty YAML, duplicate block IDs, or dangling edge refs.
    """
    yaml = _import_yaml()
    data = yaml.safe_load(yaml_str)
    return _parse_data(data)


def workflow_from_yaml_file(path: str | Path) -> WorkflowDefinition:
    """Load a WorkflowDefinition from a YAML file."""
    text = Path(path).read_text(encoding="utf-8")
    return workflow_from_yaml(text)


def workflow_to_yaml(definition: WorkflowDefinition) -> str:
    """Serialize a WorkflowDefinition to a YAML string."""
    yaml = _import_yaml()
    d = definition.to_dict()
    return yaml.dump(d, default_flow_style=False, allow_unicode=True, sort_keys=False)


def workflow_to_yaml_file(definition: WorkflowDefinition, path: str | Path) -> None:
    """Write a WorkflowDefinition to a YAML file."""
    text = workflow_to_yaml(definition)
    Path(path).write_text(text, encoding="utf-8")


def validate_definition(definition: WorkflowDefinition) -> list[str]:
    """Validate a WorkflowDefinition locally.

    Returns a list of error/warning strings (empty = valid).
    """
    errors: list[str] = []

    if not definition.blocks:
        errors.append("Workflow has no blocks")
        return errors

    # Check duplicate IDs
    block_ids = set()
    for b in definition.blocks:
        if b.id in block_ids:
            errors.append(f"Duplicate block ID: '{b.id}'")
        block_ids.add(b.id)

    # Check edge references
    for e in definition.edges:
        if e.source not in block_ids:
            errors.append(f"Edge references non-existent source block: '{e.source}'")
        if e.target not in block_ids:
            errors.append(f"Edge references non-existent target block: '{e.target}'")

    # Check for cycles (Kahn's algorithm)
    in_degree: dict[str, int] = defaultdict(int)
    adjacency: dict[str, list[str]] = defaultdict(list)
    for bid in block_ids:
        in_degree[bid] = 0
    for e in definition.edges:
        if e.source in block_ids and e.target in block_ids:
            adjacency[e.source].append(e.target)
            in_degree[e.target] += 1

    queue = [bid for bid in block_ids if in_degree[bid] == 0]
    visited = 0
    while queue:
        node = queue.pop(0)
        visited += 1
        for neighbor in adjacency[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if visited != len(block_ids):
        errors.append("Workflow contains a cycle")

    # Check for disconnected blocks
    connected = set()
    for e in definition.edges:
        connected.add(e.source)
        connected.add(e.target)
    if len(definition.blocks) > 1:
        for b in definition.blocks:
            if b.id not in connected:
                errors.append(f"Block '{b.id}' is disconnected")

    # Warn about server-only (Tier 3) types
    _TIER3_TYPES = {
        "webhook_source", "ingest_bridge", "feed_poll", "notify",
        "webhook", "http_request", "document_loader", "document_parser",
        "chunker", "code", "ai_router",
    }
    for b in definition.blocks:
        if b.type in _TIER3_TYPES:
            errors.append(
                f"Block '{b.id}' (type={b.type}) is server-only; "
                "local SDK execution may not support it"
            )

    return errors


def definition_from_api_response(data: dict[str, Any]) -> WorkflowDefinition:
    """Convert an API workflow response (nodes/params format) to WorkflowDefinition."""
    graph = data.get("graph", {})
    raw_nodes = graph.get("nodes", [])
    raw_edges = graph.get("edges", [])

    blocks = []
    for n in raw_nodes:
        config_raw = n.get("config", {})
        config = config_raw.get("params", config_raw) if isinstance(config_raw, dict) else {}
        pos_raw = n.get("position")
        position = Position(x=pos_raw["x"], y=pos_raw["y"]) if pos_raw else None
        blocks.append(BlockDef(
            id=n["id"],
            type=n["type"],
            title=n.get("title", ""),
            position=position,
            config=config,
        ))

    edges = []
    for e in raw_edges:
        edges.append(EdgeDef(
            source=e["source"],
            target=e["target"],
            source_handle=e.get("source_handle", "output"),
            target_handle=e.get("target_handle", "input"),
        ))

    return WorkflowDefinition(
        version=_CURRENT_SCHEMA_VERSION,
        name=data.get("name", ""),
        description=data.get("description", ""),
        status=data.get("status", "draft"),
        blocks=blocks,
        edges=edges,
    )


# ---- Internal ----

def _parse_data(data: Any) -> WorkflowDefinition:
    """Parse a raw dict (from yaml.safe_load) into WorkflowDefinition."""
    if not data or not isinstance(data, dict):
        raise ValueError("Invalid YAML: expected a mapping with at least 'name' and 'blocks'")

    # Version check
    version = data.get("version")
    if version is None:
        raise ValueError("Missing required field: 'version'")
    if version != _CURRENT_SCHEMA_VERSION:
        raise ValueError(
            f"Unsupported schema version: {version} (expected {_CURRENT_SCHEMA_VERSION})"
        )

    name = data.get("name")
    if not name:
        raise ValueError("Missing required field: 'name'")

    raw_blocks = data.get("blocks")
    if not raw_blocks or not isinstance(raw_blocks, list):
        raise ValueError("Missing or empty required field: 'blocks'")

    # Parse blocks
    seen_ids: set[str] = set()
    blocks: list[BlockDef] = []
    for i, rb in enumerate(raw_blocks):
        if not isinstance(rb, dict):
            raise ValueError(f"Block at index {i} is not a mapping")
        bid = rb.get("id")
        if not bid:
            raise ValueError(f"Block at index {i} missing required field: 'id'")
        btype = rb.get("type")
        if not btype:
            raise ValueError(f"Block '{bid}' missing required field: 'type'")
        if bid in seen_ids:
            raise ValueError(f"Duplicate block ID: '{bid}'")
        seen_ids.add(bid)

        pos_raw = rb.get("position")
        position = None
        if pos_raw and isinstance(pos_raw, dict):
            position = Position(x=float(pos_raw.get("x", 0)), y=float(pos_raw.get("y", 0)))

        blocks.append(BlockDef(
            id=bid,
            type=btype,
            title=rb.get("title", "") or _title_from_type(btype),
            position=position,
            config=rb.get("config") or {},
        ))

    # Parse edges
    edges: list[EdgeDef] = []
    raw_edges = data.get("edges") or []
    if not isinstance(raw_edges, list):
        raise ValueError("'edges' must be a list")
    for i, re_ in enumerate(raw_edges):
        if not isinstance(re_, dict):
            raise ValueError(f"Edge at index {i} is not a mapping")
        source = re_.get("source")
        target = re_.get("target")
        if not source or not target:
            raise ValueError(f"Edge at index {i} missing 'source' or 'target'")
        if source not in seen_ids:
            raise ValueError(f"Edge references non-existent source block: '{source}'")
        if target not in seen_ids:
            raise ValueError(f"Edge references non-existent target block: '{target}'")
        edges.append(EdgeDef(
            source=source,
            target=target,
            source_handle=re_.get("source_handle", "output"),
            target_handle=re_.get("target_handle", "input"),
        ))

    return WorkflowDefinition(
        version=version,
        name=name,
        description=data.get("description", ""),
        status=data.get("status", "draft"),
        blocks=blocks,
        edges=edges,
    )
