from __future__ import annotations
import os, time
import httpx
from schift.collection import Collection
from schift.models import EmbedResponse, ClusterResult, ClassifyResult
from schift.workflow import Workflow
from schift.bucket import Bucket

_DEFAULT_BASE_URL = "https://api.schift.io"

class Client:
    def __init__(self, api_key: str | None = None, base_url: str | None = None, timeout: float = 60.0):
        self._api_key = api_key or os.environ.get("SCHIFT_API_KEY", "")
        if not self._api_key:
            raise ValueError("api_key required (or set SCHIFT_API_KEY env var)")
        self._base_url = base_url or os.environ.get("SCHIFT_BASE_URL", _DEFAULT_BASE_URL)
        self._headers = {"Authorization": f"Bearer {self._api_key}"}
        self._http = httpx.Client(base_url=self._base_url, timeout=timeout)

    def _post(self, path: str, body: dict) -> dict:
        for _ in range(3):
            resp = self._http.post(path, json=body, headers=self._headers)
            if resp.status_code == 429:
                time.sleep(float(resp.headers.get("retry-after", 1)))
                continue
            resp.raise_for_status()
            return resp.json()
        resp.raise_for_status()
        return {}

    def embed(self, text: str, task: str | None = None, model: str | None = None, dimensions: int | None = None) -> EmbedResponse:
        body: dict = {"text": text}
        if task: body["task_type"] = task
        if model: body["model"] = model
        if dimensions: body["dimensions"] = dimensions
        data = self._post("/v1/embed", body)
        return EmbedResponse(values=data["embedding"], model=data.get("model", ""), dimensions=data.get("dimensions", len(data["embedding"])))

    def embed_batch(self, texts: list[str], task: str | None = None, model: str | None = None, dimensions: int | None = None) -> list[EmbedResponse]:
        body: dict = {"texts": texts}
        if task: body["task_type"] = task
        if model: body["model"] = model
        if dimensions: body["dimensions"] = dimensions
        data = self._post("/v1/embed/batch", body)
        return [EmbedResponse(values=emb, model=data.get("model", ""), dimensions=data.get("dimensions", len(emb))) for emb in data["embeddings"]]

    def collection(self, name: str) -> Collection:
        return Collection(name, self._http, self._headers)

    def bucket(self, bucket_id: str) -> Bucket:
        return Bucket(bucket_id, self._http, self._headers)

    def create_bucket(self, name: str, model: str | None = None, dimension: int = 1024) -> dict:
        body: dict = {"name": name, "dimension": dimension}
        if model:
            body["model"] = model
        return self._post("/v1/buckets", body)

    def list_buckets(self) -> list[dict]:
        resp = self._http.get("/v1/buckets", headers=self._headers)
        resp.raise_for_status()
        return resp.json()

    def similarity(self, text_a: str, text_b: str, model: str | None = None) -> float:
        body: dict = {"text_a": text_a, "text_b": text_b}
        if model: body["model"] = model
        return self._post("/v1/similarity", body)["score"]

    def cluster(self, texts: list[str], n_clusters: int = 5, model: str | None = None) -> ClusterResult:
        body: dict = {"texts": texts, "n_clusters": n_clusters}
        if model: body["model"] = model
        return ClusterResult(**self._post("/v1/cluster", body))

    def classify(self, text: str, labels: list[str], model: str | None = None) -> ClassifyResult:
        body: dict = {"text": text, "labels": labels}
        if model: body["model"] = model
        return ClassifyResult(**self._post("/v1/classify", body))

    @property
    def workflow(self) -> Workflow:
        if not hasattr(self, "_workflow"):
            self._workflow = Workflow(self._http, self._headers)
        return self._workflow

    def close(self): self._http.close()
    def __enter__(self): return self
    def __exit__(self, *a): self.close()
