"""Workflow models — response types, definitions, and YAML-compatible structures."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


# ---- Block Types (synced with api/server/workflow/models.py) ----

class BlockType(str, Enum):
    # Control flow
    START = "start"
    END = "end"

    # Document processing
    DOCUMENT_LOADER = "document_loader"
    DOCUMENT_PARSER = "document_parser"
    CHUNKER = "chunker"

    # Embedding
    EMBEDDER = "embedder"
    MODEL_SELECTOR = "model_selector"

    # Storage
    VECTOR_STORE = "vector_store"
    COLLECTION = "collection"

    # Retrieval
    RETRIEVER = "retriever"
    RERANKER = "reranker"

    # LLM
    LLM = "llm"
    PROMPT_TEMPLATE = "prompt_template"

    # Logic
    CONDITION = "condition"
    ROUTER = "router"
    AI_ROUTER = "ai_router"
    LOOP = "loop"

    # Data transform
    CODE = "code"
    MERGE = "merge"
    VARIABLE = "variable"

    # Integration
    HTTP_REQUEST = "http_request"
    WEBHOOK = "webhook"

    # Automated ingest
    WEBHOOK_SOURCE = "webhook_source"
    INGEST_BRIDGE = "ingest_bridge"
    FEED_POLL = "feed_poll"
    NOTIFY = "notify"

    # Selector
    FIELD_SELECTOR = "field_selector"

    # Output
    ANSWER = "answer"
    METADATA_EXTRACTOR = "metadata_extractor"


class WorkflowTemplate(str, Enum):
    BASIC_RAG = "basic_rag"
    DOCUMENT_QA = "document_qa"
    CONVERSATIONAL_RAG = "conversational_rag"
    IMAGE_OCR_INGEST = "image_ocr_ingest"
    CHAT_RAG = "chat_rag"


class WorkflowStatus(str, Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    ARCHIVED = "archived"


# ---- API Response Models ----

@dataclass
class WorkflowResponse:
    id: str
    name: str
    status: str
    description: str = ""
    graph: dict = field(default_factory=dict)


@dataclass
class RunResponse:
    run_id: str
    status: str
    outputs: dict = field(default_factory=dict)
    error: str | None = None
    block_states: dict = field(default_factory=dict)


@dataclass
class ValidationResult:
    valid: bool
    errors: list[str] = field(default_factory=list)


# ---- Local Workflow Definition (for YAML/SDK engine) ----

@dataclass
class Position:
    x: float = 0.0
    y: float = 0.0


@dataclass
class BlockDef:
    """A block in a workflow definition (YAML-friendly flat config)."""
    id: str
    type: str
    title: str = ""
    position: Position | None = None
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class EdgeDef:
    """An edge connecting two blocks."""
    source: str
    target: str
    source_handle: str = "output"
    target_handle: str = "input"


@dataclass
class WorkflowDefinition:
    """A complete workflow loaded from YAML or constructed programmatically.

    This is the SDK-side representation used for local validation and execution.
    Config values are flat (no ``params`` wrapper), and the graph key is ``blocks``
    (not ``nodes``).
    """
    version: int
    name: str
    blocks: list[BlockDef] = field(default_factory=list)
    edges: list[EdgeDef] = field(default_factory=list)
    description: str = ""
    status: str = "draft"

    def to_dict(self) -> dict[str, Any]:
        """Convert to a plain dict (YAML-schema format)."""
        d: dict[str, Any] = {
            "version": self.version,
            "name": self.name,
        }
        if self.description:
            d["description"] = self.description
        if self.status != "draft":
            d["status"] = self.status
        d["blocks"] = []
        for b in self.blocks:
            bd: dict[str, Any] = {"id": b.id, "type": b.type}
            if b.title and b.title != _title_from_type(b.type):
                bd["title"] = b.title
            if b.position is not None:
                bd["position"] = {"x": b.position.x, "y": b.position.y}
            if b.config:
                bd["config"] = b.config
            d["blocks"].append(bd)
        if self.edges:
            d["edges"] = []
            for e in self.edges:
                ed: dict[str, Any] = {"source": e.source, "target": e.target}
                if e.source_handle != "output":
                    ed["source_handle"] = e.source_handle
                if e.target_handle != "input":
                    ed["target_handle"] = e.target_handle
                d["edges"].append(ed)
        return d

    def to_api_dict(self) -> dict[str, Any]:
        """Convert to API-compatible dict (nodes key, config.params wrapper)."""
        nodes = []
        for b in self.blocks:
            node: dict[str, Any] = {
                "id": b.id,
                "type": b.type,
                "title": b.title or _title_from_type(b.type),
                "position": {"x": b.position.x, "y": b.position.y} if b.position else {"x": 0, "y": 0},
                "config": {"params": b.config} if b.config else {"params": {}},
            }
            nodes.append(node)
        edges = []
        for e in self.edges:
            edges.append({
                "id": f"{e.source}_{e.target}",
                "source": e.source,
                "target": e.target,
                "source_handle": e.source_handle,
                "target_handle": e.target_handle,
            })
        return {
            "name": self.name,
            "description": self.description,
            "status": self.status,
            "graph": {"nodes": nodes, "edges": edges},
        }

    def validate(self) -> list[str]:
        """Local DAG validation. Returns list of error/warning strings."""
        from schift.workflow_yaml import validate_definition
        return validate_definition(self)


def _title_from_type(block_type: str) -> str:
    """Convert block type to display title: 'document_loader' -> 'Document Loader'."""
    return block_type.replace("_", " ").title()
