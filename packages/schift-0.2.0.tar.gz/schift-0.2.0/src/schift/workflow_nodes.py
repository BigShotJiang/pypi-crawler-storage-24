"""Node handlers for the SDK workflow execution engine.

Tier 1 — fully local execution (control, logic, transform).
Tier 2 — delegates to Schift API or external LLM APIs.
Tier 3 — server-only stubs (raise NotImplementedError).

Custom nodes::

    from schift.workflow_nodes import SDKBaseNode, register_custom_node

    class SentimentNode(SDKBaseNode):
        async def execute(self, inputs, ctx):
            text = inputs.get("text", "")
            return {"score": 0.9, "label": "positive"}

    register_custom_node("sentiment_analyzer", SentimentNode)
"""
from __future__ import annotations

import inspect
import os
import re
from abc import ABC, abstractmethod
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from schift.workflow_engine import SDKExecutionContext
    from schift.workflow_models import BlockDef


# ---- Base Node ----

class SDKBaseNode(ABC):
    """Abstract base for all SDK node handlers."""

    def __init__(self, block: "BlockDef"):
        self.block = block
        self.config: dict[str, Any] = block.config  # flat dict (no .params wrapper)

    @abstractmethod
    async def execute(
        self,
        inputs: dict[str, Any],
        ctx: "SDKExecutionContext",
    ) -> dict[str, Any]:
        ...

    def validate_config(self) -> list[str]:
        return []


async def _maybe_await(result: Any) -> Any:
    """Await if the result is a coroutine (handles sync/async Client)."""
    if inspect.isawaitable(result):
        return await result
    return result


def _get_env_api_key(provider: str) -> str:
    """Resolve API key from environment variables."""
    env_map = {
        "openai": "OPENAI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "google": "GOOGLE_API_KEY",
    }
    env_var = env_map.get(provider, f"{provider.upper()}_API_KEY")
    key = os.environ.get(env_var, "")
    if not key:
        raise ValueError(
            f"No API key for provider '{provider}'. "
            f"Set the {env_var} environment variable."
        )
    return key


# ============================================================
# Tier 1 — Control Flow
# ============================================================

class StartNode(SDKBaseNode):
    """Entry point — passes workflow inputs through."""

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        return inputs


class EndNode(SDKBaseNode):
    """Terminal node — wraps inputs in ``result``."""

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        return {"result": inputs}


class PassthroughNode(SDKBaseNode):
    """Fallback for unimplemented or unknown block types."""

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        return inputs


# ============================================================
# Tier 1 — Logic
# ============================================================

class ConditionNode(SDKBaseNode):
    """If/else branching based on field comparison.

    Config: field, operator (eq/neq/gt/lt/gte/lte/contains/empty/not_empty), value.
    Outputs: branch ("true"/"false"), data (passthrough).
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        field = self.config.get("field", "")
        operator = self.config.get("operator", "eq")
        expected = self.config.get("value")
        actual = inputs.get(field)
        result = self._evaluate(actual, operator, expected)
        return {"branch": "true" if result else "false", "data": inputs}

    @staticmethod
    def _evaluate(actual: Any, op: str, expected: Any) -> bool:
        match op:
            case "eq":
                return actual == expected
            case "neq":
                return actual != expected
            case "gt":
                return float(actual or 0) > float(expected or 0)
            case "lt":
                return float(actual or 0) < float(expected or 0)
            case "gte":
                return float(actual or 0) >= float(expected or 0)
            case "lte":
                return float(actual or 0) <= float(expected or 0)
            case "contains":
                return str(expected or "") in str(actual or "")
            case "empty":
                return not actual
            case "not_empty":
                return bool(actual)
            case _:
                return False


class MergeNode(SDKBaseNode):
    """Merge outputs from multiple branches."""

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        return {"merged": inputs}


class LoopNode(SDKBaseNode):
    """Iterate over a list.

    Config: input_key, item_key, index_key, max_iterations.
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        input_key = self.config.get("input_key", "items")
        item_key = self.config.get("item_key", "item")
        index_key = self.config.get("index_key", "index")
        max_iter = self.config.get("max_iterations", 100)

        items = inputs.get(input_key, [])
        if not isinstance(items, list):
            items = [items]

        if len(items) > max_iter:
            raise ValueError(
                f"Loop has {len(items)} items, exceeds max_iterations={max_iter}"
            )

        results = []
        for i, item in enumerate(items):
            results.append({
                item_key: item,
                index_key: i,
                "total": len(items),
                "is_last": i == len(items) - 1,
            })

        ctx.set_var(f"{self.block.id}.iterations", results)
        ctx.set_var(f"{self.block.id}.count", len(items))

        return {
            "iterations": results,
            "count": len(items),
            item_key: items[0] if items else None,
            index_key: 0,
            "total": len(items),
            "is_last": len(items) <= 1,
        }

    def validate_config(self) -> list[str]:
        errors = []
        max_iter = self.config.get("max_iterations", 100)
        if not isinstance(max_iter, int) or max_iter < 1:
            errors.append("max_iterations must be a positive integer")
        return errors


class RouterNode(SDKBaseNode):
    """Multi-path routing (keyword/regex strategies).

    Config: strategy, routes [{name, condition}], default_route.
    LLM routing raises NotImplementedError in SDK — register a custom node instead.
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        query = str(inputs.get("query", "")).lower()
        strategy = self.config.get("strategy", "keyword")
        routes = self.config.get("routes", [])
        default = self.config.get("default_route", "default")

        if not query or not routes:
            return {"route": default, "confidence": 0.0, "data": inputs}

        if strategy == "keyword":
            return self._route_keyword(query, routes, default, inputs)
        elif strategy == "regex":
            return self._route_regex(query, routes, default, inputs)
        elif strategy == "llm":
            raise NotImplementedError(
                "LLM-based routing is not supported in the SDK engine. "
                "Use 'keyword' or 'regex' strategy, or register a custom node."
            )
        return {"route": default, "confidence": 0.0, "data": inputs}

    @staticmethod
    def _route_keyword(
        query: str, routes: list[dict], default: str, inputs: dict,
    ) -> dict[str, Any]:
        best_route = default
        best_score = 0.0
        for route in routes:
            name = route.get("name", "")
            keywords = route.get("condition", [])
            if isinstance(keywords, str):
                keywords = [k.strip() for k in keywords.split(",")]
            hits = sum(1 for kw in keywords if kw.lower() in query)
            score = hits / max(len(keywords), 1)
            if score > best_score:
                best_score = score
                best_route = name
        return {"route": best_route, "confidence": best_score, "data": inputs}

    @staticmethod
    def _route_regex(
        query: str, routes: list[dict], default: str, inputs: dict,
    ) -> dict[str, Any]:
        for route in routes:
            name = route.get("name", "")
            pattern = route.get("condition", "")
            if pattern and re.search(pattern, query, re.IGNORECASE):
                return {"route": name, "confidence": 1.0, "data": inputs}
        return {"route": default, "confidence": 0.0, "data": inputs}

    def validate_config(self) -> list[str]:
        errors = []
        strategy = self.config.get("strategy", "keyword")
        if strategy not in ("keyword", "regex", "llm"):
            errors.append(f"Invalid strategy: {strategy}")
        routes = self.config.get("routes", [])
        if not routes:
            errors.append("At least one route is required")
        for r in routes:
            if not r.get("name"):
                errors.append("Each route must have a name")
        return errors


# ============================================================
# Tier 1 — Transform / Output
# ============================================================

class VariableNode(SDKBaseNode):
    """Set or get workflow-level variables.

    Config: mode (set/get/set_get), variables (dict), keys (list).
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        mode = self.config.get("mode", "set_get")
        result: dict[str, Any] = {}

        if mode in ("set", "set_get"):
            for key, value in self.config.get("variables", {}).items():
                ctx.set_var(key, value)
            for key, value in inputs.items():
                ctx.set_var(key, value)

        if mode in ("get", "set_get"):
            keys = self.config.get("keys", [])
            if keys:
                for key in keys:
                    result[key] = ctx.get_var(key)
            else:
                result = dict(ctx.variables)

        return result


class PromptTemplateNode(SDKBaseNode):
    """Construct a prompt from ``{{variable}}`` template.

    Config: template, system_prompt.
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        template = self.config.get("template", "{{query}}")
        system_prompt = self.config.get("system_prompt", "")

        def replace_var(match: re.Match) -> str:
            var_name = match.group(1).strip()
            value = inputs.get(var_name, ctx.get_var(var_name, ""))
            if isinstance(value, list):
                return "\n".join(f"- {_format_item(item)}" for item in value)
            return str(value)

        prompt = re.sub(r"\{\{(.+?)\}\}", replace_var, template)
        system_prompt = re.sub(r"\{\{(.+?)\}\}", replace_var, system_prompt)
        return {"prompt": prompt, "system_prompt": system_prompt}


def _format_item(item: Any) -> str:
    if isinstance(item, dict):
        text = item.get("text") or item.get("metadata", {}).get("text", "")
        score = item.get("score", "")
        parts = [text]
        if score:
            parts.append(f"(score: {score})")
        return " ".join(parts)
    return str(item)


class AnswerNode(SDKBaseNode):
    """Format a response for the end user.

    Config: format (text/markdown/json), include_sources, max_length.
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        text = inputs.get("text", "")
        results = inputs.get("results", [])
        fmt = self.config.get("format", "text")
        include_sources = self.config.get("include_sources", True)
        max_length = self.config.get("max_length")

        if max_length and len(text) > max_length:
            text = text[:max_length] + "..."

        sources: list[dict] = []
        if include_sources and results:
            for r in results:
                source: dict[str, Any] = {
                    "id": r.get("id", ""),
                    "score": r.get("score", 0),
                }
                meta = r.get("metadata", {})
                if meta.get("source"):
                    source["source"] = meta["source"]
                if meta.get("text"):
                    source["snippet"] = meta["text"][:200]
                sources.append(source)

        if fmt == "markdown" and sources:
            source_section = "\n\n---\n**Sources:**\n" + "\n".join(
                f"- {s.get('source', s['id'])} (score: {s.get('score', 'N/A')})"
                for s in sources
            )
            answer = text + source_section
        elif fmt == "json":
            import json
            answer = json.dumps({"text": text, "sources": sources}, ensure_ascii=False)
        else:
            answer = text

        return {"answer": answer, "sources": sources, "format": fmt}


class ModelSelectorNode(SDKBaseNode):
    """Select embedding model — passes config through as output."""

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        model = self.config.get("model", "")
        return {"model": model, **inputs}


class FieldSelectorNode(SDKBaseNode):
    """Select specific fields from structured data using dot-notation paths.

    Config: fields (list[str]), rename (dict), source ("auto"), flatten (bool).
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        fields = self.config.get("fields", [])
        rename = self.config.get("rename", {})
        flatten = self.config.get("flatten", False)

        if not fields:
            return {"out": {}, "columns": {}}

        data = inputs.get("in", inputs)
        if isinstance(data, str):
            import json
            try:
                data = json.loads(data)
            except (json.JSONDecodeError, ValueError):
                data = {}

        result: dict[str, Any] = {}
        columns: dict[str, Any] = {}

        for field_path in fields:
            output_key = rename.get(
                field_path, field_path.replace("[]", "").replace(".", "_")
            )
            value = _resolve_path(data, field_path)
            result[output_key] = value
            if isinstance(value, list):
                columns[output_key] = value

        if flatten:
            flat: dict[str, Any] = {}
            for k, v in result.items():
                if isinstance(v, dict):
                    for sk, sv in v.items():
                        flat[f"{k}_{sk}"] = sv
                else:
                    flat[k] = v
            result = flat

        return {"out": result, "columns": columns}


def _resolve_path(data: Any, path: str) -> Any:
    """Resolve a dot-notation path (e.g. ``items[].name``)."""
    parts = path.split(".")
    current: Any = data

    for i, part in enumerate(parts):
        if current is None:
            return None

        m = re.match(r"^(\w+)\[(\d*)\]$", part)
        if m:
            key, idx = m.group(1), m.group(2)
            current = current.get(key) if isinstance(current, dict) else None
            if current is None:
                return None
            if idx:
                idx_int = int(idx)
                if isinstance(current, list) and idx_int < len(current):
                    current = current[idx_int]
                else:
                    return None
            else:
                remaining = ".".join(parts[i + 1:])
                if not remaining:
                    return current
                if isinstance(current, list):
                    results = [_resolve_path(item, remaining) for item in current]
                    flat = []
                    for r in results:
                        if isinstance(r, list):
                            flat.extend(r)
                        elif r is not None:
                            flat.append(r)
                    return flat
                return None
        else:
            current = current.get(part) if isinstance(current, dict) else None

    return current


# ============================================================
# Tier 2 — API Delegation (Schift API)
# ============================================================

class EmbedderNode(SDKBaseNode):
    """Generate embeddings via Schift API.

    Config: model.
    Inputs: text (str) or texts (list[str]).
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        if not ctx.client:
            raise RuntimeError("EmbedderNode requires a Schift Client in the execution context")

        model = self.config.get("model")
        text = inputs.get("text", "")
        texts = inputs.get("texts", [])

        if texts:
            results = await _maybe_await(
                ctx.client.embed_batch(texts, model=model)
            )
            embeddings = [r.values for r in results]
            return {"embeddings": embeddings, "model": model or ""}
        elif text:
            result = await _maybe_await(
                ctx.client.embed(text, model=model)
            )
            return {"embedding": result.values, "model": result.model}
        return {"embedding": [], "model": model or ""}


class RetrieverNode(SDKBaseNode):
    """Search a collection via Schift API.

    Config: collection, top_k.
    Inputs: query (str).
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        if not ctx.client:
            raise RuntimeError("RetrieverNode requires a Schift Client")

        collection_name = self.config.get("collection", "")
        top_k = self.config.get("top_k", 10)
        query = inputs.get("query", "")

        if not collection_name:
            raise ValueError("RetrieverNode requires 'collection' in config")
        if not query:
            return {"results": []}

        collection = ctx.client.collection(collection_name)
        results = await _maybe_await(
            collection.search(query, top_k=top_k)
        )

        return {
            "results": [
                {
                    "id": getattr(r, "id", ""),
                    "score": getattr(r, "score", 0),
                    "text": getattr(r, "text", ""),
                    "metadata": getattr(r, "metadata", {}),
                }
                for r in results
            ],
            "query": query,
        }


class RerankerNode(SDKBaseNode):
    """Re-rank retrieved results by score (simple sort).

    Config: top_k.
    Inputs: results (list[dict]).
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        results = inputs.get("results", [])
        top_k = self.config.get("top_k", 10)

        sorted_results = sorted(
            results, key=lambda r: r.get("score", 0), reverse=True
        )[:top_k]

        return {"results": sorted_results}


class VectorStoreNode(SDKBaseNode):
    """Store documents/vectors in a collection via Schift API.

    Config: collection, model.
    Inputs: documents (list[str]) or vectors (list[dict]).
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        if not ctx.client:
            raise RuntimeError("VectorStoreNode requires a Schift Client")

        collection_name = self.config.get("collection", "")
        if not collection_name:
            raise ValueError("VectorStoreNode requires 'collection' in config")

        collection = ctx.client.collection(collection_name)

        documents = inputs.get("documents", [])
        vectors = inputs.get("vectors", [])

        if documents:
            model = self.config.get("model")
            result = await _maybe_await(
                collection.add(documents, model=model)
            )
            return {"stored": len(documents), "result": result}
        elif vectors:
            result = await _maybe_await(collection.upsert(vectors))
            return {"stored": len(vectors), "result": result}

        return {"stored": 0}


class CollectionNode(SDKBaseNode):
    """Reference or create a collection.

    Config: collection, model, dimension.
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        if not ctx.client:
            raise RuntimeError("CollectionNode requires a Schift Client")

        name = self.config.get("collection", self.config.get("name", ""))
        return {"collection": name, **inputs}


# ============================================================
# Tier 2 — External LLM APIs
# ============================================================

class LLMNode(SDKBaseNode):
    """Call an external LLM (OpenAI-compatible) for text generation.

    Config: model (e.g. "openai/gpt-4o-mini"), temperature, max_tokens.
    Inputs: prompt, system_prompt (optional), context (optional).
    Requires OPENAI_API_KEY or ANTHROPIC_API_KEY env var.
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        import httpx

        model = self.config.get("model", "openai/gpt-4o-mini")
        temperature = self.config.get("temperature", 0.7)
        max_tokens = self.config.get("max_tokens", 1024)

        prompt = inputs.get("prompt", "")
        system_prompt = inputs.get("system_prompt", "")
        context = inputs.get("context", "")

        if context and "{{context}}" not in prompt:
            prompt = f"Context:\n{context}\n\n{prompt}"

        messages: list[dict] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        provider, model_name = (
            model.split("/", 1) if "/" in model else ("openai", model)
        )

        api_key = _get_env_api_key(provider)

        async with httpx.AsyncClient(timeout=60) as http:
            resp = await http.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model_name,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
            )
            resp.raise_for_status()
            data = resp.json()

        text = data["choices"][0]["message"]["content"]
        usage = data.get("usage", {})

        return {"text": text, "usage": usage}


class MetadataExtractorNode(SDKBaseNode):
    """Extract metadata from text using regex patterns.

    Config: strategy ("regex"), fields [{name, pattern, type}].
    LLM strategy is not supported in SDK — use regex or register a custom node.
    """

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        strategy = self.config.get("strategy", "regex")

        texts: list[str] = []
        text = inputs.get("text")
        if text:
            texts.append(text)
        for doc in inputs.get("documents", []):
            texts.append(doc.get("content", ""))

        if not texts:
            return {"metadata": []}

        if strategy == "llm":
            raise NotImplementedError(
                "LLM-based metadata extraction is not supported in the SDK engine. "
                "Use 'regex' strategy or register a custom node."
            )

        return self._extract_regex(texts)

    def _extract_regex(self, texts: list[str]) -> dict[str, Any]:
        fields = self.config.get("fields", [])
        all_metadata = []
        for text in texts:
            meta: dict[str, Any] = {}
            for field_def in fields:
                name = field_def.get("name", "")
                pattern = field_def.get("pattern", "")
                field_type = field_def.get("type", "str")
                if not name or not pattern:
                    continue
                match = re.search(pattern, text)
                if match:
                    value = match.group(1) if match.lastindex else match.group(0)
                    meta[name] = self._cast(value, field_type)
                else:
                    meta[name] = None
            all_metadata.append(meta)
        return {"metadata": all_metadata}

    @staticmethod
    def _cast(value: str, field_type: str) -> Any:
        try:
            if field_type == "int":
                return int(value)
            elif field_type == "float":
                return float(value)
            elif field_type == "bool":
                return value.lower() in ("true", "1", "yes")
        except (ValueError, AttributeError):
            pass
        return value


# ============================================================
# Tier 3 — Server-Only Stubs
# ============================================================

class _ServerOnlyNode(SDKBaseNode):
    """Stub for server-only block types that cannot run locally."""

    async def execute(self, inputs: dict[str, Any], ctx: "SDKExecutionContext") -> dict[str, Any]:
        raise NotImplementedError(
            f"Block type '{self.block.type}' is server-only and cannot be "
            f"executed in the local SDK engine. Use the Schift API to run "
            f"workflows containing this block type."
        )


# ============================================================
# Registry
# ============================================================

_BUILTIN_HANDLERS: dict[str, type[SDKBaseNode]] = {
    # Tier 1 — Control
    "start": StartNode,
    "end": EndNode,
    # Tier 1 — Logic
    "condition": ConditionNode,
    "router": RouterNode,
    "loop": LoopNode,
    "merge": MergeNode,
    # Tier 1 — Transform / Output
    "variable": VariableNode,
    "prompt_template": PromptTemplateNode,
    "answer": AnswerNode,
    "field_selector": FieldSelectorNode,
    "model_selector": ModelSelectorNode,
    # Tier 2 — Schift API
    "embedder": EmbedderNode,
    "retriever": RetrieverNode,
    "reranker": RerankerNode,
    "vector_store": VectorStoreNode,
    "collection": CollectionNode,
    # Tier 2 — External LLM
    "llm": LLMNode,
    "metadata_extractor": MetadataExtractorNode,
    # Tier 3 — Server-only
    "ai_router": _ServerOnlyNode,
    "document_loader": _ServerOnlyNode,
    "document_parser": _ServerOnlyNode,
    "chunker": _ServerOnlyNode,
    "code": _ServerOnlyNode,
    "http_request": _ServerOnlyNode,
    "webhook": _ServerOnlyNode,
    "webhook_source": _ServerOnlyNode,
    "ingest_bridge": _ServerOnlyNode,
    "feed_poll": _ServerOnlyNode,
    "notify": PassthroughNode,
}

_CUSTOM_NODES: dict[str, type[SDKBaseNode]] = {}


def register_custom_node(block_type: str, handler_cls: type[SDKBaseNode]) -> None:
    """Register a custom node handler.

    Args:
        block_type: Unique type identifier (e.g. ``"sentiment_analyzer"``).
        handler_cls: A class extending ``SDKBaseNode``.

    Raises:
        ValueError: If the type collides with a built-in type.
    """
    if block_type in _BUILTIN_HANDLERS:
        raise ValueError(
            f"Cannot override built-in block type '{block_type}'. "
            "Choose a unique type name for your custom node."
        )
    _CUSTOM_NODES[block_type] = handler_cls


def unregister_custom_node(block_type: str) -> None:
    """Remove a previously registered custom node."""
    _CUSTOM_NODES.pop(block_type, None)


def get_node_handler(block: "BlockDef") -> SDKBaseNode:
    """Instantiate the correct node handler for a block.

    Checks custom nodes first, then falls back to built-in types.
    Unknown types get ``PassthroughNode``.
    """
    if block.type in _CUSTOM_NODES:
        return _CUSTOM_NODES[block.type](block)
    cls = _BUILTIN_HANDLERS.get(block.type, PassthroughNode)
    return cls(block)
