import Foundation

/// Schift Swift SDK — unified client for embeddings, search, RAG chat, and vector operations.
///
/// ```swift
/// let schift = try SchiftClient(apiKey: "sch_live_...")
///
/// // Embed
/// let resp = try await schift.embed(.init(text: "hello world"))
/// print(resp.embedding.count) // 1024
///
/// // Search
/// let results = try await schift.search(.init(query: "quantum computing", collection: "my-docs"))
///
/// // RAG Chat
/// let answer = try await schift.chat(.init(bucketId: "my-bucket", message: "summarize the report"))
///
/// // Streaming RAG Chat
/// for try await event in schift.chatStream(.init(bucketId: "my-bucket", message: "explain")) {
///     switch event {
///     case .chunk(let text): print(text, terminator: "")
///     case .sources(let sources): print("Sources: \(sources.count)")
///     case .done: print("\n--- done ---")
///     case .error(let msg): print("Error: \(msg)")
///     }
/// }
/// ```
public final class SchiftClient: Sendable {

    private let http: HTTP

    // MARK: - Init

    /// Create a new Schift client.
    /// - Parameter config: Configuration with API key and optional base URL / timeout.
    /// - Throws: `SchiftError.invalidAPIKey` if the key doesn't start with `sch_`.
    public init(config: SchiftConfig) throws {
        guard config.apiKey.hasPrefix("sch_") else {
            throw SchiftError.invalidAPIKey
        }
        self.http = HTTP(
            baseURL: config.baseURL,
            apiKey: config.apiKey,
            timeout: config.timeout
        )
    }

    /// Convenience initializer with just an API key.
    public convenience init(apiKey: String) throws {
        try self.init(config: SchiftConfig(apiKey: apiKey))
    }

    // MARK: - Catalog

    /// List all available embedding models.
    public func listModels() async throws -> [CatalogModel] {
        try await http.get("/v1/catalog")
    }

    /// Get details for a specific model.
    public func getModel(_ modelId: String) async throws -> CatalogModel {
        try await http.get("/v1/catalog/\(modelId)")
    }

    // MARK: - Embed

    /// Embed a single text string.
    public func embed(_ request: EmbedRequest) async throws -> EmbedResponse {
        var body: [String: Any] = ["text": request.text]
        body["model"] = request.model
        body["dimensions"] = request.dimensions
        body["task_type"] = request.taskType?.rawValue
        return try await http.post("/v1/embed", body: body)
    }

    /// Embed multiple texts in a single request.
    public func embedBatch(_ request: EmbedBatchRequest) async throws -> EmbedBatchResponse {
        var body: [String: Any] = ["texts": request.texts]
        body["model"] = request.model
        body["dimensions"] = request.dimensions
        body["task_type"] = request.taskType?.rawValue
        return try await http.post("/v1/embed/batch", body: body)
    }

    // MARK: - Search

    /// Semantic search over a collection.
    public func search(_ request: SearchRequest) async throws -> [SearchResult] {
        var body: [String: Any] = [
            "query": request.query,
            "collection": request.collection,
        ]
        body["top_k"] = request.topK
        if let mods = request.modalities {
            body["modalities"] = mods.map(\.rawValue)
        }
        return try await http.post("/v1/query", body: body)
    }

    // MARK: - Project (Canonical Projection)

    /// Project vectors from one model's space to the Schift canonical space.
    public func project(_ request: ProjectRequest) async throws -> ProjectResponse {
        var body: [String: Any] = [
            "vectors": request.vectors.map { $0.map { Double($0) } },
            "source": request.source,
        ]
        body["target_dimensions"] = request.targetDimensions
        return try await http.post("/v1/project", body: body)
    }

    // MARK: - RAG Chat

    /// RAG Chat — search bucket + generate answer in one call.
    public func chat(_ request: ChatRequest) async throws -> ChatResponse {
        try await http.post("/v1/chat", body: chatBody(request, stream: false))
    }

    /// RAG Chat with SSE streaming. Returns an `AsyncThrowingStream` of events.
    public func chatStream(
        _ request: ChatRequest
    ) async throws -> AsyncThrowingStream<ChatStreamEvent, Error> {
        let (bytes, _) = try await http.postSSE("/v1/chat", body: chatBody(request, stream: true))

        return AsyncThrowingStream { continuation in
            let task = Task {
                do {
                    var buffer = ""
                    for try await byte in bytes {
                        let char = String(UnicodeScalar(byte))
                        buffer += char
                        if char == "\n" {
                            let line = buffer.trimmingCharacters(in: .newlines)
                            buffer = ""

                            guard line.hasPrefix("data: ") else { continue }
                            let data = String(line.dropFirst(6)).trimmingCharacters(in: .whitespaces)
                            if data.isEmpty || data == "[DONE]" {
                                if data == "[DONE]" {
                                    continuation.yield(.done)
                                }
                                continue
                            }

                            guard let jsonData = data.data(using: .utf8) else { continue }
                            if let event = Self.parseSSEEvent(jsonData) {
                                continuation.yield(event)
                            }
                        }
                    }
                    continuation.finish()
                } catch {
                    continuation.finish(throwing: error)
                }
            }
            continuation.onTermination = { _ in task.cancel() }
        }
    }

    // MARK: - Collections

    /// List all collections.
    public func listCollections() async throws -> [Collection] {
        try await http.get("/v1/collections")
    }

    /// Get collection details.
    public func getCollection(_ id: String) async throws -> Collection {
        try await http.get("/v1/collections/\(id)")
    }

    /// Delete a collection.
    public func deleteCollection(_ id: String) async throws {
        try await http.delete("/v1/collections/\(id)")
    }

    // MARK: - Buckets / DB

    /// Upload a file to a named bucket. Creates the bucket if it doesn't exist.
    public func upload(
        bucket: String,
        fileData: Data,
        fileName: String,
        mimeType: String = "application/octet-stream"
    ) async throws -> BucketUploadResult {
        // 1. Get or create bucket
        let buckets: [Bucket] = try await http.get("/v1/buckets")
        let bucketId: String

        if let existing = buckets.first(where: { $0.name == bucket }) {
            bucketId = existing.id
        } else {
            let created: Bucket = try await http.post("/v1/buckets", body: ["name": bucket])
            bucketId = created.id
        }

        // 2. Upload file
        let result: Data = try await http.postMultipart(
            "/v1/buckets/\(bucketId)/upload",
            fileData: fileData,
            fileName: fileName,
            mimeType: mimeType
        )

        return BucketUploadResult(
            bucketId: bucketId,
            bucketName: bucket,
            uploaded: [result]
        )
    }

    // MARK: - Internals

    private func chatBody(_ request: ChatRequest, stream: Bool) -> [String: Any] {
        var body: [String: Any] = [
            "bucket_id": request.bucketId,
            "message": request.message,
            "stream": stream,
        ]
        if let history = request.history {
            body["history"] = history.map { ["role": $0.role.rawValue, "content": $0.content] }
        }
        body["model"] = request.model
        body["top_k"] = request.topK
        body["system_prompt"] = request.systemPrompt
        body["temperature"] = request.temperature
        body["max_tokens"] = request.maxTokens
        return body
    }

    private static func parseSSEEvent(_ data: Data) -> ChatStreamEvent? {
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let type = json["type"] as? String else {
            return nil
        }

        switch type {
        case "sources":
            guard let sourcesData = try? JSONSerialization.data(withJSONObject: json["sources"] ?? []),
                  let sources = try? JSONDecoder().decode([ChatSource].self, from: sourcesData) else {
                return nil
            }
            return .sources(sources)

        case "chunk":
            return .chunk(json["content"] as? String ?? "")

        case "done":
            return .done

        case "error":
            return .error(json["message"] as? String ?? "Unknown error")

        default:
            return nil
        }
    }
}
