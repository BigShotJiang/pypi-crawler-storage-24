import Foundation

public enum SchiftError: LocalizedError, Sendable {
    case invalidAPIKey
    case authError(String)
    case quotaExceeded(String)
    case apiError(status: Int, detail: String)
    case networkError(Error)
    case decodingError(Error)
    case noResponseBody

    public var errorDescription: String? {
        switch self {
        case .invalidAPIKey:
            return "Invalid API key. Keys start with 'sch_'"
        case .authError(let msg):
            return "Authentication failed: \(msg)"
        case .quotaExceeded(let msg):
            return "Quota exceeded: \(msg)"
        case .apiError(let status, let detail):
            return "API error \(status): \(detail)"
        case .networkError(let err):
            return "Network error: \(err.localizedDescription)"
        case .decodingError(let err):
            return "Decoding error: \(err.localizedDescription)"
        case .noResponseBody:
            return "No response body"
        }
    }

    public var statusCode: Int? {
        switch self {
        case .authError: return 401
        case .quotaExceeded: return 402
        case .apiError(let s, _): return s
        default: return nil
        }
    }
}
