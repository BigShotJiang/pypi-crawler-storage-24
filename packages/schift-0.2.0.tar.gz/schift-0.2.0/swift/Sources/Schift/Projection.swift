import Foundation

/// Client-side W_private projection for zero-knowledge vector storage.
///
/// Generates a random projection matrix and applies it to embedding vectors
/// before uploading to the Schift Engine. The server stores only the projected
/// (lower-dimensional) vectors and cannot reverse them to the original space.
///
/// ```swift
/// // Generate once, store in Keychain
/// let matrix = WPrivateProjection.generate(inputDim: 1024, outputDim: 256)
/// let data = try WPrivateProjection.serialize(matrix)
/// // ... store `data` in Keychain ...
///
/// // Apply to embeddings before upsert
/// let projected = WPrivateProjection.project(vector: embedding, matrix: matrix)
/// ```
public enum WPrivateProjection {

    /// Generate a random orthogonal-ish projection matrix using Gaussian random values
    /// scaled by 1/sqrt(outputDim) for variance preservation.
    ///
    /// - Parameters:
    ///   - inputDim: Source embedding dimension (e.g. 1024 for schift-embed-1)
    ///   - outputDim: Target dimension for projected vectors (e.g. 256)
    /// - Returns: A `[outputDim][inputDim]` matrix of Float values.
    public static func generate(inputDim: Int, outputDim: Int) -> [[Float]] {
        let scale = 1.0 / sqrt(Float(outputDim))
        return (0..<outputDim).map { _ in
            (0..<inputDim).map { _ in gaussianRandom() * scale }
        }
    }

    /// Project a single vector through the W_private matrix.
    ///
    /// - Parameters:
    ///   - vector: Input vector of dimension `inputDim`.
    ///   - matrix: Projection matrix `[outputDim][inputDim]`.
    /// - Returns: Projected vector of dimension `outputDim`.
    public static func project(vector: [Float], matrix: [[Float]]) -> [Float] {
        matrix.map { row in
            zip(row, vector).reduce(Float(0)) { $0 + $1.0 * $1.1 }
        }
    }

    /// Project a batch of vectors.
    public static func projectBatch(vectors: [[Float]], matrix: [[Float]]) -> [[Float]] {
        vectors.map { project(vector: $0, matrix: matrix) }
    }

    /// Serialize the matrix to JSON data for Keychain storage.
    public static func serialize(_ matrix: [[Float]]) throws -> Data {
        try JSONEncoder().encode(matrix)
    }

    /// Deserialize a matrix from JSON data.
    public static func deserialize(_ data: Data) throws -> [[Float]] {
        try JSONDecoder().decode([[Float]].self, from: data)
    }

    // MARK: - Gaussian random (Box-Muller)

    private static func gaussianRandom() -> Float {
        let u1 = Float.random(in: Float.ulpOfOne...1.0)
        let u2 = Float.random(in: 0.0...1.0)
        return sqrt(-2.0 * log(u1)) * cos(2.0 * .pi * u2)
    }
}
