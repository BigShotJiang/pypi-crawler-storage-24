import Foundation

/// Internal HTTP transport layer for the Schift SDK.
struct HTTP: Sendable {
    let baseURL: String
    let apiKey: String
    let timeout: TimeInterval

    private static let version = "0.1.0"

    private var headers: [String: String] {
        [
            "Authorization": "Bearer \(apiKey)",
            "User-Agent": "schift-swift/\(Self.version)",
        ]
    }

    // MARK: - GET

    func get<T: Decodable>(_ path: String) async throws -> T {
        var request = URLRequest(url: url(path))
        request.httpMethod = "GET"
        request.timeoutInterval = timeout
        applyHeaders(&request)
        return try await execute(request)
    }

    // MARK: - POST (JSON)

    func post<T: Decodable>(_ path: String, body: [String: Any]) async throws -> T {
        var request = URLRequest(url: url(path))
        request.httpMethod = "POST"
        request.timeoutInterval = timeout
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        applyHeaders(&request)
        request.httpBody = try JSONSerialization.data(withJSONObject: body.compactMapValues { $0 })
        return try await execute(request)
    }

    // MARK: - POST (Multipart)

    func postMultipart<T: Decodable>(
        _ path: String,
        fileData: Data,
        fileName: String,
        mimeType: String
    ) async throws -> T {
        let boundary = UUID().uuidString
        var request = URLRequest(url: url(path))
        request.httpMethod = "POST"
        request.timeoutInterval = timeout
        request.setValue(
            "multipart/form-data; boundary=\(boundary)",
            forHTTPHeaderField: "Content-Type"
        )
        applyHeaders(&request)

        var body = Data()
        body.append("--\(boundary)\r\n")
        body.append("Content-Disposition: form-data; name=\"files\"; filename=\"\(fileName)\"\r\n")
        body.append("Content-Type: \(mimeType)\r\n\r\n")
        body.append(fileData)
        body.append("\r\n--\(boundary)--\r\n")
        request.httpBody = body

        return try await execute(request)
    }

    // MARK: - PATCH

    func patch<T: Decodable>(_ path: String, body: [String: Any]) async throws -> T {
        var request = URLRequest(url: url(path))
        request.httpMethod = "PATCH"
        request.timeoutInterval = timeout
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        applyHeaders(&request)
        request.httpBody = try JSONSerialization.data(withJSONObject: body.compactMapValues { $0 })
        return try await execute(request)
    }

    // MARK: - DELETE

    func delete(_ path: String) async throws {
        var request = URLRequest(url: url(path))
        request.httpMethod = "DELETE"
        request.timeoutInterval = timeout
        applyHeaders(&request)

        let (data, response) = try await URLSession.shared.data(for: request)
        let httpResponse = response as! HTTPURLResponse
        if httpResponse.statusCode >= 400 {
            throw Self.errorFromResponse(statusCode: httpResponse.statusCode, data: data)
        }
    }

    // MARK: - SSE Streaming POST

    func postSSE(
        _ path: String,
        body: [String: Any]
    ) async throws -> (URLSession.AsyncBytes, HTTPURLResponse) {
        var request = URLRequest(url: url(path))
        request.httpMethod = "POST"
        request.timeoutInterval = timeout
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        applyHeaders(&request)
        request.httpBody = try JSONSerialization.data(withJSONObject: body.compactMapValues { $0 })

        let (bytes, response) = try await URLSession.shared.bytes(for: request)
        let httpResponse = response as! HTTPURLResponse

        if httpResponse.statusCode >= 400 {
            // Collect error body
            var errorData = Data()
            for try await byte in bytes {
                errorData.append(byte)
                if errorData.count > 4096 { break }
            }
            throw Self.errorFromResponse(statusCode: httpResponse.statusCode, data: errorData)
        }

        return (bytes, httpResponse)
    }

    // MARK: - Internals

    private func url(_ path: String) -> URL {
        URL(string: baseURL.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + path)!
    }

    private func applyHeaders(_ request: inout URLRequest) {
        for (key, value) in headers {
            request.setValue(value, forHTTPHeaderField: key)
        }
    }

    private func execute<T: Decodable>(_ request: URLRequest) async throws -> T {
        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw SchiftError.networkError(error)
        }

        let httpResponse = response as! HTTPURLResponse
        if httpResponse.statusCode >= 400 {
            throw Self.errorFromResponse(statusCode: httpResponse.statusCode, data: data)
        }

        do {
            let decoder = JSONDecoder()
            return try decoder.decode(T.self, from: data)
        } catch {
            throw SchiftError.decodingError(error)
        }
    }

    static func errorFromResponse(statusCode: Int, data: Data) -> SchiftError {
        let text = String(data: data, encoding: .utf8) ?? ""
        let detail: String = {
            if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let d = json["detail"] as? String {
                return d
            }
            return text
        }()

        switch statusCode {
        case 401: return .authError(detail)
        case 402: return .quotaExceeded(detail)
        default: return .apiError(status: statusCode, detail: detail)
        }
    }
}

// MARK: - Data + String append helper

extension Data {
    mutating func append(_ string: String) {
        if let data = string.data(using: .utf8) {
            append(data)
        }
    }
}
