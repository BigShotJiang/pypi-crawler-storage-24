import Foundation

// MARK: - Configuration

public struct SchiftConfig: Sendable {
    public let apiKey: String
    public let baseURL: String
    public let timeout: TimeInterval

    public init(
        apiKey: String,
        baseURL: String = "https://api.schift.io",
        timeout: TimeInterval = 60
    ) {
        self.apiKey = apiKey
        self.baseURL = baseURL
        self.timeout = timeout
    }
}

// MARK: - Enums

public enum Modality: String, Codable, Sendable {
    case text
    case image
    case audio
    case video
    case document
}

public enum TaskType: String, Codable, Sendable {
    case retrievalDocument = "RETRIEVAL_DOCUMENT"
    case retrievalQuery = "RETRIEVAL_QUERY"
    case semanticSimilarity = "SEMANTIC_SIMILARITY"
    case classification = "CLASSIFICATION"
    case clustering = "CLUSTERING"
    case questionAnswering = "QUESTION_ANSWERING"
    case factVerification = "FACT_VERIFICATION"
    case codeRetrieval = "CODE_RETRIEVAL"
}

// MARK: - Catalog

public struct CatalogModel: Codable, Sendable, Identifiable {
    public let modelId: String
    public let provider: String
    public let displayName: String
    public let dimensions: Int
    public let maxTokens: Int
    public let supportsDimensions: Bool
    public let pricingPer1kTokens: Double
    public let modalities: [Modality]?
    public let `internal`: Bool?

    public var id: String { modelId }

    enum CodingKeys: String, CodingKey {
        case modelId = "model_id"
        case provider
        case displayName = "display_name"
        case dimensions
        case maxTokens = "max_tokens"
        case supportsDimensions = "supports_dimensions"
        case pricingPer1kTokens = "pricing_per_1k_tokens"
        case modalities
        case `internal`
    }
}

// MARK: - Embed

public struct EmbedRequest: Sendable {
    public let text: String
    public let model: String?
    public let dimensions: Int?
    public let taskType: TaskType?

    public init(
        text: String,
        model: String? = nil,
        dimensions: Int? = nil,
        taskType: TaskType? = nil
    ) {
        self.text = text
        self.model = model
        self.dimensions = dimensions
        self.taskType = taskType
    }
}

public struct EmbedBatchRequest: Sendable {
    public let texts: [String]
    public let model: String?
    public let dimensions: Int?
    public let taskType: TaskType?

    public init(
        texts: [String],
        model: String? = nil,
        dimensions: Int? = nil,
        taskType: TaskType? = nil
    ) {
        self.texts = texts
        self.model = model
        self.dimensions = dimensions
        self.taskType = taskType
    }
}

public struct EmbedResponse: Codable, Sendable {
    public let embedding: [Float]
    public let model: String
    public let dimensions: Int
    public let usage: EmbedUsage
}

public struct EmbedUsage: Codable, Sendable {
    public let tokens: Int
}

public struct EmbedBatchResponse: Codable, Sendable {
    public let embeddings: [[Float]]
    public let model: String
    public let dimensions: Int
    public let usage: EmbedBatchUsage
}

public struct EmbedBatchUsage: Codable, Sendable {
    public let tokens: Int
    public let count: Int
}

// MARK: - Search

public struct SearchRequest: Sendable {
    public let query: String
    public let collection: String
    public let topK: Int?
    public let modalities: [Modality]?

    public init(
        query: String,
        collection: String,
        topK: Int? = nil,
        modalities: [Modality]? = nil
    ) {
        self.query = query
        self.collection = collection
        self.topK = topK
        self.modalities = modalities
    }
}

public struct SearchResult: Codable, Sendable, Identifiable {
    public let id: String
    public let score: Double
    public let modality: Modality?
    public let metadata: [String: String]?
    public let location: SearchLocation?
}

public struct SearchLocation: Codable, Sendable {
    public let page: Int?
    public let timestamp: Double?
    public let frame: Int?
}

// MARK: - Project (Canonical Projection)

public struct ProjectRequest: Sendable {
    public let vectors: [[Float]]
    public let source: String
    public let targetDimensions: Int?

    public init(
        vectors: [[Float]],
        source: String,
        targetDimensions: Int? = nil
    ) {
        self.vectors = vectors
        self.source = source
        self.targetDimensions = targetDimensions
    }
}

public struct ProjectResponse: Codable, Sendable {
    public let vectors: [[Float]]
    public let source: String
    public let target: String
    public let dimensions: Int
}

// MARK: - Chat (RAG)

public struct ChatMessage: Codable, Sendable {
    public let role: ChatRole
    public let content: String

    public init(role: ChatRole, content: String) {
        self.role = role
        self.content = content
    }
}

public enum ChatRole: String, Codable, Sendable {
    case user
    case assistant
    case system
}

public struct ChatRequest: Sendable {
    public let bucketId: String
    public let message: String
    public let history: [ChatMessage]?
    public let model: String?
    public let topK: Int?
    public let systemPrompt: String?
    public let temperature: Double?
    public let maxTokens: Int?

    public init(
        bucketId: String,
        message: String,
        history: [ChatMessage]? = nil,
        model: String? = nil,
        topK: Int? = nil,
        systemPrompt: String? = nil,
        temperature: Double? = nil,
        maxTokens: Int? = nil
    ) {
        self.bucketId = bucketId
        self.message = message
        self.history = history
        self.model = model
        self.topK = topK
        self.systemPrompt = systemPrompt
        self.temperature = temperature
        self.maxTokens = maxTokens
    }
}

public struct ChatSource: Codable, Sendable, Identifiable {
    public let id: String
    public let score: Double
    public let text: String
}

public struct ChatResponse: Codable, Sendable {
    public let reply: String
    public let sources: [ChatSource]
    public let model: String
}

public enum ChatStreamEvent: Sendable {
    case sources([ChatSource])
    case chunk(String)
    case done
    case error(String)
}

// MARK: - Collections

public struct Collection: Codable, Sendable, Identifiable {
    public let id: String
    public let name: String?
    public let dimension: Int?
    public let count: Int?
}

// MARK: - Buckets

public struct Bucket: Codable, Sendable, Identifiable {
    public let id: String
    public let name: String
}

public struct BucketUploadResult: Sendable {
    public let bucketId: String
    public let bucketName: String
    public let uploaded: [Data]
}
