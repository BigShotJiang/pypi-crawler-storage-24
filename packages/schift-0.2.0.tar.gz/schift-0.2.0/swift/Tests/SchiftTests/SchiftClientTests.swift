import Foundation
import Testing
@testable import Schift

@Suite("SchiftClient")
struct SchiftClientTests {

    @Test("rejects invalid API key")
    func invalidAPIKey() throws {
        #expect(throws: SchiftError.self) {
            try SchiftClient(apiKey: "bad_key")
        }
    }

    @Test("accepts valid API key prefix")
    func validAPIKey() throws {
        let _ = try SchiftClient(apiKey: "sch_test_abc123")
    }

    @Test("config defaults")
    func configDefaults() {
        let config = SchiftConfig(apiKey: "sch_test_x")
        #expect(config.baseURL == "https://api.schift.io")
        #expect(config.timeout == 60)
    }

    @Test("config custom values")
    func configCustom() {
        let config = SchiftConfig(
            apiKey: "sch_test_x",
            baseURL: "https://custom.api.io",
            timeout: 30
        )
        #expect(config.baseURL == "https://custom.api.io")
        #expect(config.timeout == 30)
    }
}

@Suite("WPrivateProjection")
struct ProjectionTests {

    @Test("generate creates correct dimensions")
    func generateDimensions() {
        let matrix = WPrivateProjection.generate(inputDim: 1024, outputDim: 256)
        #expect(matrix.count == 256)
        #expect(matrix[0].count == 1024)
    }

    @Test("project produces correct output dimension")
    func projectDim() {
        let matrix = WPrivateProjection.generate(inputDim: 4, outputDim: 2)
        let input: [Float] = [1.0, 0.5, 0.3, 0.1]
        let output = WPrivateProjection.project(vector: input, matrix: matrix)
        #expect(output.count == 2)
    }

    @Test("projectBatch handles multiple vectors")
    func projectBatch() {
        let matrix = WPrivateProjection.generate(inputDim: 4, outputDim: 2)
        let inputs: [[Float]] = [
            [1.0, 0.5, 0.3, 0.1],
            [0.2, 0.8, 0.4, 0.6],
        ]
        let outputs = WPrivateProjection.projectBatch(vectors: inputs, matrix: matrix)
        #expect(outputs.count == 2)
        #expect(outputs[0].count == 2)
        #expect(outputs[1].count == 2)
    }

    @Test("serialize/deserialize roundtrip")
    func serializeRoundtrip() throws {
        let matrix = WPrivateProjection.generate(inputDim: 8, outputDim: 4)
        let data = try WPrivateProjection.serialize(matrix)
        let restored = try WPrivateProjection.deserialize(data)
        #expect(matrix.count == restored.count)
        for (row1, row2) in zip(matrix, restored) {
            for (a, b) in zip(row1, row2) {
                #expect(a == b)
            }
        }
    }

    @Test("projection is deterministic for same matrix")
    func deterministic() {
        let matrix = WPrivateProjection.generate(inputDim: 4, outputDim: 2)
        let input: [Float] = [1.0, 2.0, 3.0, 4.0]
        let out1 = WPrivateProjection.project(vector: input, matrix: matrix)
        let out2 = WPrivateProjection.project(vector: input, matrix: matrix)
        #expect(out1 == out2)
    }

    @Test("different matrices produce different projections")
    func differentMatrices() {
        let m1 = WPrivateProjection.generate(inputDim: 4, outputDim: 2)
        let m2 = WPrivateProjection.generate(inputDim: 4, outputDim: 2)
        let input: [Float] = [1.0, 2.0, 3.0, 4.0]
        let out1 = WPrivateProjection.project(vector: input, matrix: m1)
        let out2 = WPrivateProjection.project(vector: input, matrix: m2)
        #expect(out1 != out2)
    }
}

@Suite("Types")
struct TypeTests {

    @Test("TaskType raw values")
    func taskTypeRawValues() {
        #expect(TaskType.retrievalDocument.rawValue == "RETRIEVAL_DOCUMENT")
        #expect(TaskType.retrievalQuery.rawValue == "RETRIEVAL_QUERY")
        #expect(TaskType.codeRetrieval.rawValue == "CODE_RETRIEVAL")
    }

    @Test("Modality raw values")
    func modalityRawValues() {
        #expect(Modality.text.rawValue == "text")
        #expect(Modality.image.rawValue == "image")
        #expect(Modality.document.rawValue == "document")
    }

    @Test("CatalogModel decoding")
    func catalogDecoding() throws {
        let json = """
        {
            "model_id": "schift-embed-1",
            "provider": "schift",
            "display_name": "Schift Embed 1",
            "dimensions": 1024,
            "max_tokens": 8192,
            "supports_dimensions": false,
            "pricing_per_1k_tokens": 0.01
        }
        """.data(using: .utf8)!

        let model = try JSONDecoder().decode(CatalogModel.self, from: json)
        #expect(model.modelId == "schift-embed-1")
        #expect(model.dimensions == 1024)
        #expect(model.maxTokens == 8192)
        #expect(model.supportsDimensions == false)
    }

    @Test("EmbedRequest defaults")
    func embedRequestDefaults() {
        let req = EmbedRequest(text: "hello")
        #expect(req.text == "hello")
        #expect(req.model == nil)
        #expect(req.dimensions == nil)
        #expect(req.taskType == nil)
    }

    @Test("ChatMessage encoding")
    func chatMessageEncoding() throws {
        let msg = ChatMessage(role: .user, content: "hello")
        let data = try JSONEncoder().encode(msg)
        let decoded = try JSONDecoder().decode(ChatMessage.self, from: data)
        #expect(decoded.role == .user)
        #expect(decoded.content == "hello")
    }
}
