// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "Schift",
    platforms: [
        .macOS(.v14),
        .iOS(.v17),
        .tvOS(.v17),
        .watchOS(.v10),
        .visionOS(.v1),
    ],
    products: [
        .library(name: "Schift", targets: ["Schift"]),
    ],
    targets: [
        .target(
            name: "Schift",
            path: "Sources/Schift"
        ),
        .testTarget(
            name: "SchiftTests",
            dependencies: ["Schift"],
            path: "Tests/SchiftTests"
        ),
    ]
)
