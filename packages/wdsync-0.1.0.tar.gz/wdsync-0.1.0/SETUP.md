# Setup

This guide is for getting `wdsync` running right after cloning the repo.

If you want to work on the codebase itself, use
[DEVELOPER_SETUP.md](docs/DEVELOPER_SETUP.md).

## Prerequisites

Run this from WSL with:

- `git`
- `git.exe`
- `rsync`
- `wslpath`
- Python 3.11+
- `uv`

You also need:

- WSL installed
- Git for Windows installed and callable as `git.exe`
- a Windows source repo reachable as `/mnt/<drive>/...`

## 1. Clone The Repo

```bash
git clone <your-repo-url>
cd wdsync
```

## 2. Install The CLI

Install it as a normal command:

```bash
uv tool install .
```

Reinstall from the current checkout later if needed:

```bash
uv tool install --reinstall .
```

Run it directly from the repo without installing globally:

```bash
uv run wdsync --help
```

## 3. Optional Shell Integration

The CLI works without shell-specific setup, but you can install optional shell
helpers and completions:

```bash
wdsync shell install
```

Override shell detection when needed:

```bash
wdsync shell install --shell fish
wdsync shell install --shell bash
wdsync shell install --shell zsh
```

## 4. Initialize A Destination Repo

From inside the WSL repo that should receive synced files:

```bash
cd /path/to/your/wsl/repo
wdsync init /mnt/c/Users/YourName/path/to/WindowsRepo
```

That writes a local `.wdsync` file like:

```ini
SRC=/mnt/c/Users/YourName/path/to/WindowsRepo
```

You can edit `.wdsync` manually later if the source path changes. `wdsync init`
also adds `.wdsync` to `.git/info/exclude` in that destination repo so the file
stays local.

## 5. Daily Use

Preview the current Windows dirty set:

```bash
wdsync
```

Or explicitly:

```bash
wdsync preview
```

Sync the dirty files into the current WSL repo:

```bash
wdsync sync
```

Compatibility alias:

```bash
wdsync -f
```

Run advisory checks:

```bash
wdsync doctor
```

## 6. Useful Checks

Verify the command is available:

```bash
wdsync --help
```

Verify the module entry point also works:

```bash
python -m wdsync --help
```

## Notes

- `wdsync` must be run from inside the destination Git repo.
- It helps to be on the same branch in both repos, but it is not required.
- Source dirty detection comes from `git.exe`, not Linux Git.
- Sync copies file contents only.
- Deleted files are previewed but skipped in v1.
- A source staged file does not remain staged in the destination repo.
