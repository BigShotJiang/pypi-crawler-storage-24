"""
FlowgentraAI - Build AI agent workflows with graphs

Python bindings for the FlowgentraAI Rust library via PyO3.

Quick Start:
    from flowgentra_ai import StateGraphBuilder, SharedState, END

    def process(state):
        state["output"] = state["input"].upper()
        return state

    builder = StateGraphBuilder()
    builder.add_node("process", process)
    builder.set_entry_point("process")
    builder.add_edge("process", END)
    graph = builder.compile()

    result = graph.invoke(SharedState({"input": "hello"}))
    print(result["output"])  # "HELLO"
"""

from flowgentra_ai._native import (
    # State
    SharedState,
    PlainState,
    # Agent (config-driven)
    Agent,
    # Prebuilt Agents
    AgentType,
    ToolSpec,
    AgentBuilder,
    GraphBasedAgent,
    # Config
    AgentConfig,
    StateField,
    # Graph (code-driven workflow API)
    StateGraph,
    StateGraphBuilder,
    END,
    # LLM
    LLMConfig,
    Message,
    ToolCall,
    ToolDefinition,
    TokenUsage,
    LLMClient,
    # Tools & Registry
    ToolCallRequest,
    ToolCallResult,
    ToolRegistry,
    JsonSchema,
    # RAG
    Document,
    SearchResult,
    TextChunk,
    # Text Splitters
    RecursiveCharacterTextSplitter,
    MarkdownTextSplitter,
    HTMLTextSplitter,
    TokenTextSplitter,
    CodeTextSplitter,
    # Memory
    Checkpoint,
    CheckpointMetadata,
    ConversationMemory,
    # Evaluation
    EvaluationResult,
    # Prompt & Parsers
    PromptTemplate,
    JsonOutputParser,
    ListOutputParser,
    # Vector Store & Embeddings
    Embeddings,
    InMemoryVectorStore,
    RetrievalConfig,
    Retriever,
    # Message Graph
    MessageGraph,
    MessageGraphBuilder,
    # Supervisor
    Supervisor,
    OrchestrationStrategy,
    SupervisorNodeConfig,
    ParallelAggregation,
    ParallelMergeStrategy,
    ChildExecutionStats,
    # Planner Node
    PlannerNode,
    # Builtin Nodes
    RetryNode,
    TimeoutNode,
    # Evaluation Node Config (for add_evaluation_node)
    EvaluationNodeConfig,
    # Routing Conditions
    ComparisonOp,
    Condition,
    ConditionBuilder,
    # Observability
    ExecutionTrace,
    ExecutionTracer,
    py_init_tracing as init_tracing,
    # MCP
    MCPConfig,
    # Document Loaders
    FileType,
    LoadedDocument,
    # Ingestion
    IngestionPipeline,
    IngestionStats,
    # RAG Evaluation
    EvalQuery,
    EvalResults,
    QueryResult,
    # PDF
    PdfDocument,
    # Rerankers
    NoopReranker,
    RRFReranker,
    CrossEncoderReranker,
    LLMReranker,
    # Response Format
    ResponseFormat,
    # Advanced Memory
    TokenBufferMemory,
    SummaryConfig,
    SummaryMemory,
    # File Checkpointer
    FileCheckpointer,
    # ChromaDB
    ChromaStore,
    # Built-in Tools
    CalculatorTool,
    SearchTool,
    WebRequestTool,
    FilesTool,
    # Tool Node
    ToolNode,
    # Visualization
    VisualizationConfig,
    # Advanced Nodes
    JoinType,
    MergeStrategy,
    BranchConfig,
    LoopNodeConfig,
    ParallelNodeConfig,
    SubgraphNodeConfig,
    JoinNodeConfig,
    # Memory-Aware Agent
    MemoryAwareAgent,
    MemoryStats,
    # RAG Config Types
    VectorStoreType,
    RAGConfig,
    VectorStoreConfig,
    EmbeddingsConfig,
    RetrievalSettings,
    PdfSettings,
    RAGGraphConfig,
    # Evaluation Config & Reporting
    ScoringConfig,
    GradingConfig,
    EvaluationConfig,
    NodeResult,
    EvaluationReport,
    # Remaining Types
    ChunkMetadata,
    RetrieverStrategy,
    RerankStrategy,
    VectorStore,
    # Free functions
    py_from_config_path as from_config_path,
    py_chunk_text as chunk_text,
    py_extract_text as extract_text,
    py_estimate_tokens as estimate_tokens,
    py_model_pricing as model_pricing,
    py_chunk_text_by_tokens as chunk_text_by_tokens,
    py_extract_and_chunk as extract_and_chunk,
    py_extract_pdf as extract_pdf,
    py_load_document as load_document,
    py_load_directory as load_directory,
    py_hit_rate as hit_rate,
    py_mrr as mrr,
    py_mean_ndcg as mean_ndcg,
    py_rag_evaluate as rag_evaluate,
    py_bm25_score as bm25_score,
    py_hybrid_merge as hybrid_merge,
    py_dedup_by_id as dedup_by_id,
    py_dedup_by_similarity as dedup_by_similarity,
    py_decompose_query as decompose_query,
    # Tool node functions
    py_create_tool_node as create_tool_node,
    py_store_tool_calls as store_tool_calls,
    py_check_tools_condition as check_tools_condition,
    # Visualization functions
    py_evaluate_output_score as evaluate_output_score,
    py_visualize_graph as visualize_graph,
    py_graph_to_dot as graph_to_dot,
    py_graph_to_mermaid as graph_to_mermaid,
)

__version__ = "0.1.3"
__all__ = [
    # State
    "SharedState",
    "PlainState",
    # Agent
    "Agent",
    # Prebuilt Agents
    "AgentType",
    "ToolSpec",
    "AgentBuilder",
    "GraphBasedAgent",
    # Config
    "AgentConfig",
    "StateField",
    # Graph
    "StateGraph",
    "StateGraphBuilder",
    "END",
    # LLM
    "LLMConfig",
    "Message",
    "ToolCall",
    "ToolDefinition",
    "TokenUsage",
    "LLMClient",
    # Tools & Registry
    "ToolCallRequest",
    "ToolCallResult",
    "ToolRegistry",
    "JsonSchema",
    # RAG
    "Document",
    "SearchResult",
    "TextChunk",
    # Text Splitters
    "RecursiveCharacterTextSplitter",
    "MarkdownTextSplitter",
    "HTMLTextSplitter",
    "TokenTextSplitter",
    "CodeTextSplitter",
    # Memory
    "Checkpoint",
    "CheckpointMetadata",
    "ConversationMemory",
    # Evaluation
    "EvaluationResult",
    # Prompt & Parsers
    "PromptTemplate",
    "JsonOutputParser",
    "ListOutputParser",
    # Vector Store & Embeddings
    "Embeddings",
    "InMemoryVectorStore",
    "RetrievalConfig",
    "Retriever",
    # Message Graph
    "MessageGraph",
    "MessageGraphBuilder",
    # Supervisor
    "Supervisor",
    "OrchestrationStrategy",
    "SupervisorNodeConfig",
    "ParallelAggregation",
    "ParallelMergeStrategy",
    "ChildExecutionStats",
    # Planner Node
    "PlannerNode",
    # Builtin Nodes
    "RetryNode",
    "TimeoutNode",
    # Evaluation Node
    "EvaluationNodeConfig",
    # Routing Conditions
    "ComparisonOp",
    "Condition",
    "ConditionBuilder",
    # Observability
    "ExecutionTrace",
    "ExecutionTracer",
    "init_tracing",
    # MCP
    "MCPConfig",
    # Response Format
    "ResponseFormat",
    # Advanced Memory
    "TokenBufferMemory",
    "SummaryConfig",
    "SummaryMemory",
    # File Checkpointer
    "FileCheckpointer",
    # Document Loaders
    "FileType",
    "LoadedDocument",
    "load_document",
    "load_directory",
    # Ingestion
    "IngestionPipeline",
    "IngestionStats",
    # RAG Evaluation
    "EvalQuery",
    "EvalResults",
    "QueryResult",
    "hit_rate",
    "mrr",
    "mean_ndcg",
    "rag_evaluate",
    # PDF
    "PdfDocument",
    "extract_pdf",
    "chunk_text_by_tokens",
    "extract_and_chunk",
    # Rerankers
    "NoopReranker",
    "RRFReranker",
    "CrossEncoderReranker",
    "LLMReranker",
    # ChromaDB
    "ChromaStore",
    # Built-in Tools
    "CalculatorTool",
    "SearchTool",
    "WebRequestTool",
    "FilesTool",
    # Tool Node
    "ToolNode",
    "create_tool_node",
    "store_tool_calls",
    "check_tools_condition",
    # Visualization
    "VisualizationConfig",
    "visualize_graph",
    "graph_to_dot",
    "graph_to_mermaid",
    # Advanced Nodes
    "JoinType",
    "MergeStrategy",
    "BranchConfig",
    "LoopNodeConfig",
    "ParallelNodeConfig",
    "SubgraphNodeConfig",
    "JoinNodeConfig",
    # Memory-Aware Agent
    "MemoryAwareAgent",
    "MemoryStats",
    # RAG Config Types
    "VectorStoreType",
    "RAGConfig",
    "VectorStoreConfig",
    "EmbeddingsConfig",
    "RetrievalSettings",
    "PdfSettings",
    "RAGGraphConfig",
    # Evaluation Config & Reporting
    "ScoringConfig",
    "GradingConfig",
    "EvaluationConfig",
    "NodeResult",
    "EvaluationReport",
    # Remaining Types
    "ChunkMetadata",
    "RetrieverStrategy",
    "RerankStrategy",
    "VectorStore",
    "evaluate_output_score",
    # Hybrid & Dedup
    "bm25_score",
    "hybrid_merge",
    "dedup_by_id",
    "dedup_by_similarity",
    "decompose_query",
    # Functions
    "from_config_path",
    "chunk_text",
    "extract_text",
    "estimate_tokens",
    "model_pricing",
]
