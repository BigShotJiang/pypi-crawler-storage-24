# FlowgentraAI

**Build AI agent workflows with graphs.**

FlowgentraAI is a Python library for building LLM-powered agent workflows using a graph-based architecture. It's powered by a high-performance Rust engine via PyO3, giving you Python's ease of use with Rust's speed.

## Why FlowgentraAI?

- **Graph-first**: Model your agent logic as nodes and edges -- easy to understand, test, and debug
- **Rust-powered**: Core engine written in Rust for maximum performance
- **Multi-provider LLM support**: OpenAI, Anthropic, Mistral, Groq, Ollama, HuggingFace, Azure
- **Built-in RAG**: Vector stores, embeddings, text splitting, retrieval pipelines
- **Human-in-the-loop**: Interrupt and resume graph execution with checkpointing
- **Multi-agent**: Supervisor pattern for orchestrating multiple agent graphs
- **Observability**: Execution tracing, visualization (DOT, Mermaid)

## Quick Example

```python
from flowgentra_ai import StateGraphBuilder, SharedState, END

def process(state):
    state["output"] = state["input"].upper()
    return state

builder = StateGraphBuilder()
builder.add_node("process", process)
builder.set_entry_point("process")
builder.add_edge("process", END)
graph = builder.compile()

result = graph.invoke(SharedState({"input": "hello"}))
print(result["output"])  # "HELLO"
```

## Get Started

<div class="grid cards" markdown>

- :material-download: **[Installation](getting-started/installation.md)** -- Install FlowgentraAI
- :material-rocket-launch: **[Quick Start](getting-started/quickstart.md)** -- Build your first graph workflow
- :material-book-open-variant: **[Guides](guides/graphs.md)** -- In-depth tutorials
- :material-api: **[API Reference](api/state.md)** -- Full API documentation

</div>
