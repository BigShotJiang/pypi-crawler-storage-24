# Quick Start

This guide walks you through building your first graph workflow with FlowgentraAI.

## Your First Graph

A graph workflow consists of:

1. **Nodes** -- Python functions that transform state
2. **Edges** -- Connections between nodes that define execution order
3. **State** -- A shared dict-like container that flows through the graph

```python
from flowgentra_ai import StateGraphBuilder, SharedState, END

# Step 1: Define node functions
# Each node receives a SharedState and must return a SharedState
def greet(state):
    name = state["name"]
    state["greeting"] = f"Hello, {name}!"
    return state

def shout(state):
    state["greeting"] = state["greeting"].upper()
    return state

# Step 2: Build the graph
builder = StateGraphBuilder()
builder.add_node("greet", greet)
builder.add_node("shout", shout)
builder.set_entry_point("greet")
builder.add_edge("greet", "shout")
builder.add_edge("shout", END)  # END terminates the graph
graph = builder.compile()

# Step 3: Run it
result = graph.invoke(SharedState({"name": "World"}))
print(result.to_dict())
# {"name": "World", "greeting": "HELLO, WORLD!"}
```

## Adding Conditional Routing

Instead of fixed edges, route dynamically based on state:

```python
from flowgentra_ai import StateGraphBuilder, SharedState, END

def classify(state):
    text = state["input"]
    state["is_greeting"] = "hello" in text.lower()
    return state

def greet_response(state):
    state["output"] = "Hi there! How can I help?"
    return state

def default_response(state):
    state["output"] = "Let me look into that for you."
    return state

def router(state):
    """Router function: returns the name of the next node."""
    if state["is_greeting"]:
        return "greet_response"
    return "default_response"

builder = StateGraphBuilder()
builder.add_node("classify", classify)
builder.add_node("greet_response", greet_response)
builder.add_node("default_response", default_response)
builder.set_entry_point("classify")
builder.add_conditional_edge("classify", router)
builder.add_edge("greet_response", END)
builder.add_edge("default_response", END)
graph = builder.compile()

result = graph.invoke(SharedState({"input": "hello world"}))
print(result["output"])  # "Hi there! How can I help?"
```

## Adding an LLM

Integrate an LLM into your graph nodes:

```python
from flowgentra_ai import (
    StateGraphBuilder, SharedState, END,
    LLMConfig, LLMClient, Message,
)

# Create an LLM client
config = LLMConfig("openai", "gpt-4", api_key="sk-...")
client = LLMClient.from_config(config)

def generate(state):
    prompt = state["prompt"]
    response = client.chat([
        Message.system("You are a helpful assistant."),
        Message.user(prompt),
    ])
    state["response"] = response.content
    return state

builder = StateGraphBuilder()
builder.add_node("generate", generate)
builder.set_entry_point("generate")
builder.add_edge("generate", END)
graph = builder.compile()

result = graph.invoke(SharedState({"prompt": "Explain Rust in one sentence."}))
print(result["response"])
```

## What's Next?

- [State Management](../guides/state.md) -- Deep dive into SharedState
- [Graph Workflows](../guides/graphs.md) -- Subgraphs, max steps, checkpointing
- [LLM Client](../guides/llm-client.md) -- All providers, tool calling, caching
- [RAG Pipeline](../guides/rag.md) -- Build retrieval-augmented generation
- [API Reference](../api/state.md) -- Full API documentation
