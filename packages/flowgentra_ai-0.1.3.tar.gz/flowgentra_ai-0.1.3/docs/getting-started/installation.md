# Installation

## From PyPI

```bash
pip install flowgentra-ai
```

Requires Python 3.9+. Pre-built wheels are available for major platforms.

## From Source

If you need to build from source (e.g., for development or unsupported platforms):

### Prerequisites

- Python 3.9+
- Rust toolchain (install from [rustup.rs](https://rustup.rs))
- [maturin](https://www.maturin.rs) build tool

### Development install

```bash
git clone https://github.com/oussamabenhariz/FlowgentraAI.git
cd FlowgentraAI/flowgentra-ai-py
pip install maturin
maturin develop
```

This compiles the Rust code and installs it as an editable Python package.

### Build a wheel

```bash
maturin build --release
pip install target/wheels/flowgentra_ai-*.whl
```

## Verify Installation

```python
import flowgentra_ai
print(flowgentra_ai.__version__)
```
