# Memory API Reference

## ConversationMemory

In-memory conversation message storage with optional sliding window.

```python
from flowgentra_ai import ConversationMemory
```

### Constructor

```python
ConversationMemory(max_messages: int | None = None)
```

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `add_message(thread_id, message)` | `None` | Add a message to a thread |
| `messages(thread_id, limit=None)` | `list[Message]` | Get messages (oldest first) |
| `clear(thread_id)` | `None` | Clear all messages for a thread |

---

## Checkpoint

A saved state checkpoint for persistence/resume.

```python
from flowgentra_ai import Checkpoint
```

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `metadata` | `CheckpointMetadata` | Checkpoint metadata |
| `state` | `dict` | Saved state data |

---

## CheckpointMetadata

Metadata for a checkpoint.

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `last_node` | `str \| None` | Last executed node |
| `execution_path` | `list[str]` | Ordered list of executed nodes |
| `extra` | `dict` | Additional metadata |

---

## FileCheckpointer

File-based checkpoint storage.

```python
from flowgentra_ai import FileCheckpointer
```

Typically used via `StateGraphBuilder.set_checkpointer(base_dir)` rather than directly.

---

## TokenBufferMemory

Conversation memory that stays within a token budget.

```python
from flowgentra_ai import TokenBufferMemory
```

---

## SummaryMemory

Memory that automatically summarizes older messages.

```python
from flowgentra_ai import SummaryMemory, SummaryConfig
```
