# Supervisor API Reference

## OrchestrationStrategy

Defines how the supervisor orchestrates child agents.

```python
from flowgentra_ai import OrchestrationStrategy
```

| Factory method | Description |
|----------------|-------------|
| `OrchestrationStrategy.sequential()` | Children run one after another; state flows through each |
| `OrchestrationStrategy.parallel()` | All children run simultaneously; results are merged |
| `OrchestrationStrategy.autonomous()` | Loop-based, runs agents until required outputs are present |
| `OrchestrationStrategy.dynamic()` | LLM decides which agents to call at runtime |
| `OrchestrationStrategy.round_robin()` | Distributes tasks across agents in rotation |
| `OrchestrationStrategy.hierarchical()` | Delegates to sub-supervisors |
| `OrchestrationStrategy.broadcast()` | Sends same task to all agents; picks best result |
| `OrchestrationStrategy.map_reduce()` | Splits input, processes in parallel, merges results |
| `OrchestrationStrategy.conditional_routing()` | Routes to agent based on state conditions |
| `OrchestrationStrategy.retry_fallback()` | Tries agents in order until one succeeds |
| `OrchestrationStrategy.debate()` | Agents generate and critique each other's outputs |
| `OrchestrationStrategy.custom(name)` | Placeholder for user-defined strategies |

---

## ParallelAggregation

How to aggregate results from parallel child executions.

```python
from flowgentra_ai import ParallelAggregation
```

| Factory method | Description |
|----------------|-------------|
| `ParallelAggregation.first_success()` | Use first child that succeeds |
| `ParallelAggregation.all()` | Require all children to succeed |
| `ParallelAggregation.majority()` | Succeed if more than half succeed |

---

## ParallelMergeStrategy

How to merge state from parallel child executions.

```python
from flowgentra_ai import ParallelMergeStrategy
```

| Factory method | Description |
|----------------|-------------|
| `ParallelMergeStrategy.first_success()` | Use first successful child's state |
| `ParallelMergeStrategy.latest()` | Use last successful child's state |
| `ParallelMergeStrategy.deep_merge()` | Deep-merge all successful states |
| `ParallelMergeStrategy.custom(name)` | Placeholder for user-defined merge |

---

## ChildExecutionStats

Per-child execution statistics (read-only properties).

```python
from flowgentra_ai import ChildExecutionStats
```

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Child agent name |
| `duration_ms` | `int` | Execution time in milliseconds |
| `success` | `bool` | Whether the child succeeded |
| `error` | `str \| None` | Error message if failed |
| `timeout` | `bool` | Whether the child timed out |

---

## SupervisorNodeConfig

Full configuration for a strategy-based supervisor.

```python
from flowgentra_ai import SupervisorNodeConfig, OrchestrationStrategy

config = SupervisorNodeConfig(
    name="coordinator",
    children=["researcher", "writer"],
    strategy=OrchestrationStrategy.parallel(),
)
```

### Constructor

```python
SupervisorNodeConfig(
    name: str,
    children: list[str],
    strategy: OrchestrationStrategy | None = None,  # defaults to Sequential
)
```

### General Methods

| Method | Description |
|--------|-------------|
| `set_strategy(strategy)` | Set the orchestration strategy |
| `set_fail_fast(bool)` | Stop on first child error |
| `set_child_timeout_ms(ms)` | Per-child timeout |
| `set_timeout_ms(ms)` | Global timeout |
| `set_merge_strategy(strategy)` | How to merge parallel states |
| `set_parallel_aggregation(agg)` | Parallel aggregation policy |
| `set_collect_stats(bool)` | Enable per-child stats |
| `set_max_retries_per_child(n)` | Max retries per child |
| `set_max_concurrent(n)` | Max concurrent children (parallel) |
| `add_skip_condition(child, expr)` | Skip child when condition is true |

### Strategy-Specific Methods

| Method | Strategy | Description |
|--------|----------|-------------|
| `set_goal(str)` | Autonomous | Human-readable goal description |
| `set_required_outputs(list)` | Autonomous | State keys that must be present |
| `add_output_owner(key, child)` | Autonomous | Map output key to responsible child |
| `set_max_iterations(n)` | Autonomous/Dynamic/Debate | Max orchestration iterations |
| `set_selector_prompt(str)` | Dynamic | System prompt for LLM agent selector |
| `set_tasks_key(str)` | RoundRobin | State key with tasks array |
| `set_selection_criteria(str)` | Broadcast | "first_success", "highest_score" |
| `set_score_key(str)` | Broadcast | State key for quality score |
| `set_map_key(str)` | MapReduce | State key for input chunks |
| `set_reduce_key(str)` | MapReduce | State key for reduced output |
| `add_routing_rule(condition, child)` | ConditionalRouting | Route condition → child |
| `set_fallback_order(list)` | RetryFallback | Ordered agent fallback list |
| `set_debate_rounds(n)` | Debate | Number of debate rounds |
| `set_debate_key(str)` | Debate | State key for debate topic |

---

## Supervisor

Multi-agent orchestrator with two modes:

### Simple Mode (Router Function)

```python
from flowgentra_ai import Supervisor, SharedState

def router(state):
    task = state.get_string("task") or ""
    if "research" in task:
        return "researcher"
    return "FINISH"

sup = Supervisor(router)
sup.add_agent("researcher", research_graph)
sup.max_rounds(5)
result = sup.run(SharedState({"task": "research AI"}))
```

### Strategy Mode (Config-Based)

```python
from flowgentra_ai import (
    Supervisor, SupervisorNodeConfig, OrchestrationStrategy,
    ParallelMergeStrategy, SharedState,
)

config = SupervisorNodeConfig(
    "coordinator",
    ["researcher", "writer"],
    OrchestrationStrategy.parallel(),
)
config.set_child_timeout_ms(30000)
config.set_merge_strategy(ParallelMergeStrategy.latest())

sup = Supervisor.from_config(config)
sup.add_agent("researcher", research_graph)
sup.add_agent("writer", writer_graph)
result = sup.run(SharedState({"task": "write article"}))
```

### Constructor & Factory

| Signature | Description |
|-----------|-------------|
| `Supervisor(router)` | Simple router-based mode |
| `Supervisor.from_config(config)` | Strategy-based mode |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `add_agent(name, agent)` | `None` | Register agent (StateGraph or callable) |
| `max_rounds(rounds)` | `None` | Set max routing rounds (simple mode) |
| `finish_marker(marker)` | `None` | Set finish string (default: "FINISH") |
| `run(state)` | `SharedState` | Execute the supervisor |
| `agent_names()` | `list[str]` | List registered agent names |
