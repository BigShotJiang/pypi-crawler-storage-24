# State API Reference

## SharedState

Thread-safe shared state container. The primary state type for all graph workflows.

```python
from flowgentra_ai import SharedState
```

### Constructor

```python
SharedState(initial: dict | None = None)
```

Creates a new SharedState, optionally with initial data.

### Class Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `SharedState.from_dict(dict)` | `SharedState` | Create from a Python dict |
| `SharedState.from_json(json_str)` | `SharedState` | Create from a JSON string |

### Instance Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `get(key)` | `Any \| None` | Get value by key, returns `None` if missing |
| `set(key, value)` | `None` | Set a value |
| `contains_key(key)` | `bool` | Check if key exists |
| `remove(key)` | `Any \| None` | Remove a key, returns its value |
| `keys()` | `list[str]` | Get all keys |
| `get_string(key)` | `str \| None` | Get as string, `None` if not a string |
| `to_dict()` | `dict` | Convert to Python dict |
| `to_json()` | `str` | Serialize to JSON string |
| `deep_clone()` | `SharedState` | Create an independent deep copy |

### Dict Protocol

Supports standard Python dict operations:

```python
state["key"] = value    # __setitem__
val = state["key"]      # __getitem__ (raises KeyError if missing)
del state["key"]        # __delitem__
"key" in state          # __contains__
len(state)              # __len__
```

---

## PlainState

Non-thread-safe state for direct ownership. Use `SharedState` unless you have a specific reason.

```python
from flowgentra_ai import PlainState
```

### Constructor

```python
PlainState(initial: dict | None = None)
```

### Additional Typed Getters

| Method | Returns | Description |
|--------|---------|-------------|
| `get_string(key)` | `str \| None` | Get as string |
| `get_int(key)` | `int \| None` | Get as integer |
| `get_float(key)` | `float \| None` | Get as float |
| `get_bool(key)` | `bool \| None` | Get as boolean |

Has the same dict protocol support as `SharedState`.
