# Observability API Reference

## init_tracing

Initialize the tracing subscriber for structured logging.

```python
from flowgentra_ai import init_tracing

init_tracing()           # default "info" level
init_tracing("debug")    # verbose
init_tracing("warn")     # quiet
```

Call once at program start.

---

## ExecutionTrace

A recorded execution trace.

```python
from flowgentra_ai import ExecutionTrace
```

### Constructor

```python
ExecutionTrace(agent_name: str | None = None)
```

### Class Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `ExecutionTrace.from_json(json_str)` | `ExecutionTrace` | Deserialize from JSON |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `execution_path()` | `list[str]` | Ordered list of executed nodes |
| `total_duration_ms()` | `int \| None` | Total duration in milliseconds |
| `to_json()` | `str` | Serialize to JSON |

---

## ExecutionTracer

Records execution events for visualization and debugging.

```python
from flowgentra_ai import ExecutionTracer
```

### Constructor

```python
ExecutionTracer()
```

### Methods

| Method | Description |
|--------|-------------|
| `trace_node_start(node_id)` | Record node start |
| `trace_node_end(node_id, duration_ms, success)` | Record node completion |
| `trace_edge_traversal(from_node, to_node, condition_met)` | Record edge traversal |
| `trace_state_update(key, value)` | Record state change |
| `trace_custom(event_name, details=None)` | Record custom event |
| `get_events_json()` | Get all events as JSON string |
| `clear()` | Clear all recorded events |
