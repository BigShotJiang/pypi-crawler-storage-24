# Tools API Reference

## ToolRegistry

Central registry for managing and calling tools.

```python
from flowgentra_ai import ToolRegistry
```

### Constructor

```python
ToolRegistry()                    # empty registry
ToolRegistry.with_builtins()      # with built-in tools pre-registered
```

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `call_tool(name, input)` | `Any` | Call a tool by name with JSON-compatible input |
| `validate_input(name, input)` | `None` | Validate input without calling (raises on error) |
| `list_names()` | `list[str]` | Get all tool names |
| `__len__()` | `int` | Number of registered tools |

---

## JsonSchema

JSON Schema for validation.

```python
from flowgentra_ai import JsonSchema
```

### Factory Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `JsonSchema.object()` | `JsonSchema` | Object schema |
| `JsonSchema.string()` | `JsonSchema` | String schema |
| `JsonSchema.number()` | `JsonSchema` | Number schema |
| `JsonSchema.integer()` | `JsonSchema` | Integer schema |
| `JsonSchema.boolean()` | `JsonSchema` | Boolean schema |
| `JsonSchema.array()` | `JsonSchema` | Array schema |

### Methods

| Method | Description |
|--------|-------------|
| `with_description(desc)` | Set description |
| `with_required(fields)` | Set required fields (object schemas) |
| `validate(value)` | Validate a value (raises on error) |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `schema_type` | `str` | Schema type string |
| `description` | `str \| None` | Schema description |

---

## Built-in Tools

```python
from flowgentra_ai import CalculatorTool, SearchTool, WebRequestTool, FilesTool
```

| Class | Description |
|-------|-------------|
| `CalculatorTool` | Arithmetic operations (add, subtract, multiply, divide) |
| `SearchTool` | Web search |
| `WebRequestTool` | HTTP requests |
| `FilesTool` | File system operations |

---

## ToolNode

Integrates tool execution into a graph workflow.

```python
from flowgentra_ai import ToolNode, create_tool_node, store_tool_calls, check_tools_condition
```

| Function | Description |
|----------|-------------|
| `create_tool_node(...)` | Create a tool node for a graph |
| `store_tool_calls(...)` | Store tool call results in state |
| `check_tools_condition(...)` | Check if tools should be called |

---

## ToolCallRequest / ToolCallResult

Types for tool call request/response flow.

```python
from flowgentra_ai import ToolCallRequest, ToolCallResult
```
