# RAG API Reference

## Document

A document for retrieval-augmented generation.

```python
from flowgentra_ai import Document
```

### Constructor

```python
Document(id: str, text: str, metadata: dict | None = None)
```

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `id` | `str` | Document ID |
| `text` | `str` | Document text (read/write) |
| `metadata` | `dict` | Metadata dict |
| `embedding` | `list[float] \| None` | Embedding vector |

---

## SearchResult

A result from a vector store search.

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `id` | `str` | Document ID |
| `text` | `str` | Document text |
| `score` | `float` | Similarity score |
| `metadata` | `dict` | Document metadata |

---

## TextChunk

A chunk of text from text splitting.

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `text` | `str` | Chunk text |
| `metadata` | `ChunkMetadata` | Chunk metadata (source, index, offsets) |

---

## Embeddings

Embedding generation from text.

```python
from flowgentra_ai import Embeddings
```

### Factory Methods

| Method | Description |
|--------|-------------|
| `Embeddings.mock(dimension)` | Hash-based mock (no API needed) |
| `Embeddings.openai(api_key, model="text-embedding-3-small")` | OpenAI embeddings |
| `Embeddings.openai_with_dimension(api_key, model, dimension)` | OpenAI with custom dimension |
| `Embeddings.openai_cached(api_key, model="text-embedding-3-small")` | OpenAI with cache |
| `Embeddings.ollama(model, base_url=None, dimension=None)` | Ollama (local) |
| `Embeddings.mistral(api_key, model=None)` | Mistral embeddings |
| `Embeddings.huggingface(model, api_key, endpoint=None, dimension=None)` | HuggingFace |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `embed(text)` | `list[float]` | Embed a single text |
| `embed_batch(texts)` | `list[list[float]]` | Batch embed |
| `get_dimension()` | `int` | Get embedding dimension |

---

## InMemoryVectorStore

In-memory vector store with cosine similarity search.

```python
from flowgentra_ai import InMemoryVectorStore
```

### Constructor

```python
InMemoryVectorStore()
```

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `index(doc, embedding)` | `None` | Index a document with its embedding |
| `search(query_embedding, top_k=5, filter=None)` | `list[SearchResult]` | Search by embedding |
| `get(doc_id)` | `Document` | Get document by ID |
| `delete(doc_id)` | `None` | Delete by ID |
| `list()` | `list[Document]` | List all documents |
| `clear()` | `None` | Remove all documents |

---

## RetrievalConfig

Configuration for retrieval strategies.

```python
from flowgentra_ai import RetrievalConfig
```

### Factory Methods

| Method | Description |
|--------|-------------|
| `RetrievalConfig.semantic(top_k=5, threshold=0.7)` | Semantic search config |
| `RetrievalConfig.hybrid(keyword_weight=0.3, top_k=5, threshold=0.7)` | Hybrid search config |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `top_k` | `int` | Number of results |
| `similarity_threshold` | `float` | Minimum score threshold |

---

## Retriever

Full retrieval pipeline: embed, search, hybrid, rerank, dedup.

```python
from flowgentra_ai import Retriever
```

### Constructor

```python
Retriever(store: InMemoryVectorStore, embeddings: Embeddings, config: RetrievalConfig)
```

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `retrieve(query)` | `list[SearchResult]` | Execute the full retrieval pipeline |
| `with_dedup(threshold)` | `None` | Enable deduplication |

---

## PdfDocument

An extracted PDF document.

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `source` | `str` | File path |
| `page_count` | `int` | Number of pages |
| `text` | `str` | Extracted text |

---

## Free Functions

| Function | Returns | Description |
|----------|---------|-------------|
| `chunk_text(text, chunk_size, overlap=0)` | `list[str]` | Split text by character count |
| `chunk_text_by_tokens(text, max_tokens, overlap_tokens=0)` | `list[str]` | Split by token count |
| `extract_text(path)` | `str` | Extract text from a PDF |
| `extract_pdf(path)` | `PdfDocument` | Extract PDF as object |
| `extract_and_chunk(path, chunk_size=1000, overlap=200)` | `list[(str, str)]` | Extract + chunk |
| `estimate_tokens(text)` | `int` | Estimate token count |
| `bm25_score(query, documents)` | `list[float]` | BM25 keyword scores |
| `hybrid_merge(results, query, keyword_weight=0.3)` | `list[SearchResult]` | Merge semantic + keyword |
| `dedup_by_id(results)` | `list[SearchResult]` | Deduplicate by ID |
| `dedup_by_similarity(results, threshold=0.85)` | `list[SearchResult]` | Deduplicate by similarity |
| `decompose_query(query, max_depth=2)` | `list[str]` | Split compound queries |
| `load_document(path)` | `LoadedDocument` | Load a file |
| `load_directory(path)` | `list[LoadedDocument]` | Load all files in a directory |
