# LLM API Reference

## LLMConfig

LLM provider configuration.

```python
from flowgentra_ai import LLMConfig
```

### Constructor

```python
LLMConfig(
    provider: str,          # "openai", "anthropic", "mistral", "groq", "ollama", "huggingface", "azure"
    model: str,             # e.g. "gpt-4", "claude-3-opus-20240229"
    api_key: str = "",
    temperature: float | None = None,   # 0.0-2.0
    max_tokens: int | None = None,
    top_p: float | None = None,         # 0.0-1.0
)
```

### Properties (read/write)

| Property | Type | Description |
|----------|------|-------------|
| `provider` | `str` | Provider name (read-only) |
| `model` | `str` | Model identifier (read-only) |
| `api_key` | `str` | API key (read-only) |
| `temperature` | `float \| None` | Response randomness |
| `max_tokens` | `int \| None` | Max response tokens |
| `top_p` | `float \| None` | Nucleus sampling |

### Methods

| Method | Description |
|--------|-------------|
| `set_response_format(format)` | Set structured output format |

---

## LLMClient

Client for sending messages to an LLM.

```python
from flowgentra_ai import LLMClient
```

### Class Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `LLMClient.from_config(config)` | `LLMClient` | Create from an `LLMConfig` |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `chat(messages)` | `Message` | Send messages, get response |
| `chat_with_usage(messages)` | `(Message, TokenUsage \| None)` | Chat with token usage stats |
| `chat_with_tools(messages, tools)` | `Message` | Chat with function calling |
| `cached(max_entries=100)` | `LLMClient` | Wrap with response cache |
| `with_fallback(client)` | `LLMClient` | Add fallback provider |
| `with_retry(max_retries=3)` | `LLMClient` | Add retry with backoff |

---

## Message

A message in a conversation.

```python
from flowgentra_ai import Message
```

### Constructor

```python
Message(role: str, content: str, tool_call_id: str | None = None)
```

### Factory Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `Message.system(content)` | `Message` | System message |
| `Message.user(content)` | `Message` | User message |
| `Message.assistant(content)` | `Message` | Assistant message |
| `Message.tool(content, tool_call_id=None)` | `Message` | Tool result message |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `role` | `str` | `"system"`, `"user"`, `"assistant"`, or `"tool"` |
| `content` | `str` | Message text (read/write) |
| `tool_call_id` | `str \| None` | Associated tool call ID |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `is_system()` | `bool` | Check role |
| `is_user()` | `bool` | Check role |
| `is_assistant()` | `bool` | Check role |
| `is_tool()` | `bool` | Check role |
| `has_tool_calls()` | `bool` | Whether message has tool calls |
| `tool_calls()` | `list[ToolCall]` | Get tool calls |

---

## ToolCall

A tool call from an LLM response.

```python
from flowgentra_ai import ToolCall
```

### Constructor

```python
ToolCall(id: str, name: str, arguments: Any)
```

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `id` | `str` | Unique call ID |
| `name` | `str` | Tool name |
| `arguments` | `Any` | Call arguments (dict) |

---

## ToolDefinition

Tool definition for LLM function calling.

```python
from flowgentra_ai import ToolDefinition
```

### Constructor

```python
ToolDefinition(name: str, description: str, parameters: Any)
```

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Tool name |
| `description` | `str` | Tool description |
| `parameters` | `Any` | JSON Schema for parameters |

---

## TokenUsage

Token usage statistics.

```python
from flowgentra_ai import TokenUsage
```

### Constructor

```python
TokenUsage(prompt_tokens: int, completion_tokens: int)
```

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `prompt_tokens` | `int` | Input token count |
| `completion_tokens` | `int` | Output token count |
| `total_tokens` | `int` | Total tokens |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `estimated_cost(model)` | `float \| None` | Estimated cost in USD |

---

## ResponseFormat

Structured output format for LLM responses.

```python
from flowgentra_ai import ResponseFormat
```

### Factory Methods

| Method | Description |
|--------|-------------|
| `ResponseFormat.text()` | Plain text (default) |
| `ResponseFormat.json()` | Force JSON output |
| `ResponseFormat.json_schema(name, schema)` | JSON matching a schema |
