# Utilities API Reference

## Model Pricing

```python
from flowgentra_ai import model_pricing

pricing = model_pricing("gpt-4")  # (input_price, output_price) per million tokens
# Returns None if model not found
```

## Text Splitters

Specialized text splitters for different content types:

```python
from flowgentra_ai import (
    RecursiveCharacterTextSplitter,
    MarkdownTextSplitter,
    HTMLTextSplitter,
    TokenTextSplitter,
    CodeTextSplitter,
)
```

## Prompt & Parsers

```python
from flowgentra_ai import PromptTemplate, JsonOutputParser, ListOutputParser
```

### PromptTemplate

Template string formatting for prompts.

### JsonOutputParser

Parse LLM output as JSON.

### ListOutputParser

Parse LLM output as a list.

## Routing Conditions

Build conditional routing logic declaratively:

```python
from flowgentra_ai import ComparisonOp, Condition, ConditionBuilder
```

## Evaluation

```python
from flowgentra_ai import (
    EvaluationResult,
    EvaluationConfig,
    ScoringConfig,
    GradingConfig,
    EvaluationReport,
    NodeResult,
    evaluate_output_score,
)
```

## Rerankers

Rerank search results for better relevance:

```python
from flowgentra_ai import NoopReranker, RRFReranker, CrossEncoderReranker, LLMReranker
```

| Class | Description |
|-------|-------------|
| `NoopReranker` | Pass-through (no reranking) |
| `RRFReranker` | Reciprocal Rank Fusion |
| `CrossEncoderReranker` | Cross-encoder neural reranking |
| `LLMReranker` | LLM-based reranking |

## Advanced Nodes

Node types for complex graph patterns:

```python
from flowgentra_ai import (
    BranchConfig,
    LoopNodeConfig,
    ParallelNodeConfig,
    SubgraphNodeConfig,
    JoinNodeConfig,
    JoinType,
    MergeStrategy,
)
```

## MCP (Model Context Protocol)

```python
from flowgentra_ai import MCPConfig
```

## Visualization

```python
from flowgentra_ai import (
    VisualizationConfig,
    visualize_graph,
    graph_to_dot,
    graph_to_mermaid,
)
```

## RAG Configuration

```python
from flowgentra_ai import (
    VectorStoreType,
    RAGConfig,
    VectorStoreConfig,
    EmbeddingsConfig,
    RetrievalSettings,
    PdfSettings,
    RAGGraphConfig,
)
```
