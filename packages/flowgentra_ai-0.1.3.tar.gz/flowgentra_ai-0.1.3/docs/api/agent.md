# Agent API Reference

## Agent

Config-driven agent that auto-discovers handlers from YAML configuration.

```python
from flowgentra_ai import Agent
```

### Class Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `Agent.from_config_path(path)` | `Agent` | Create from a YAML config file |
| `Agent.from_config(config)` | `Agent` | Create from an `AgentConfig` object |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `state` | `SharedState` | The agent's current state |
| `config` | `AgentConfig` | The agent's configuration |
| `name` | `str` | Agent name from config |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `run()` | `SharedState` | Execute the agent, returns final state |
| `run_with_thread(thread_id)` | `SharedState` | Execute with checkpointing |
| `set_state(key, value)` | `None` | Set a value in the agent's state |

---

## AgentConfig

Agent configuration loaded from YAML.

```python
from flowgentra_ai import AgentConfig
```

### Class Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `AgentConfig.from_file(path)` | `AgentConfig` | Load from a YAML file |
| `AgentConfig.from_yaml(yaml_str)` | `AgentConfig` | Load from a YAML string |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Agent name |
| `description` | `str \| None` | Agent description |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `validate()` | `None` | Validate the configuration (raises on error) |
| `to_json()` | `str` | Serialize to JSON string |

---

## AgentBuilder

Builder for creating prebuilt agents (ReAct, Conversational).

```python
from flowgentra_ai import AgentBuilder, AgentType
```

### Constructor

```python
AgentBuilder(agent_type: AgentType)
```

### Methods

| Method | Description |
|--------|-------------|
| `with_name(name)` | Set agent name |
| `with_llm_config(model)` | Set model (e.g., `"gpt-4"`) |
| `with_temperature(temp)` | Set temperature |
| `with_max_tokens(tokens)` | Set max tokens |
| `with_tool(tool_spec)` | Add a tool |
| `with_system_prompt(prompt)` | Set system prompt |
| `with_memory_steps(steps)` | Set memory window size |
| `with_evaluation()` | Enable evaluation |
| `with_retries(max_retries)` | Set retry count |
| `with_param(key, value)` | Set a custom parameter |
| `build_graph()` | Build into a `GraphBasedAgent` |

---

## AgentType

Prebuilt agent type selector.

```python
from flowgentra_ai import AgentType
```

| Method | Description |
|--------|-------------|
| `AgentType.zero_shot_react()` | Reasoning + Action without examples |
| `AgentType.few_shot_react()` | Reasoning + Action with example demonstrations |
| `AgentType.conversational()` | Multi-turn dialogue with memory |

---

## GraphBasedAgent

A built prebuilt agent. Created by `AgentBuilder.build_graph()`.

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `execute_input(input)` | `str` | Execute with text input, returns text response |
| `node_names()` | `list[str]` | Get node names of the underlying graph |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Agent name |

---

## ToolSpec

Tool specification for prebuilt agents.

```python
from flowgentra_ai import ToolSpec
```

### Constructor

```python
ToolSpec(name: str, description: str)
```

### Methods

| Method | Description |
|--------|-------------|
| `add_parameter(name, param_type)` | Add a parameter (type as string: `"string"`, `"number"`, etc.) |
| `set_required(param_name)` | Mark a parameter as required |

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `name` | `str` | Tool name |
| `description` | `str` | Tool description |

---

## MemoryAwareAgent

Agent with automatic conversation memory management.

```python
from flowgentra_ai import MemoryAwareAgent
```

### Class Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `MemoryAwareAgent.from_config(path)` | `MemoryAwareAgent` | Create from YAML config |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `set_thread_id(thread_id)` | `None` | Set conversation thread |
| `thread_id()` | `str` | Get current thread ID |
| `run_turn(input)` | `str` | Run a conversation turn |
| `clear_memory()` | `None` | Clear memory for current thread |
| `memory_stats()` | `MemoryStats` | Get memory usage stats |

---

## MemoryStats

Memory usage statistics.

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `message_count` | `int` | Total messages stored |
| `user_messages` | `int` | User message count |
| `assistant_messages` | `int` | Assistant message count |
| `approximate_tokens` | `int` | Approximate token count |

---

## StateField

A field in the state schema (used in config).

```python
from flowgentra_ai import StateField
```

### Constructor

```python
StateField(field_type: str, description: str)
```

### Properties

| Property | Type | Description |
|----------|------|-------------|
| `field_type` | `str` | Type of the field |
| `description` | `str` | Field description |
