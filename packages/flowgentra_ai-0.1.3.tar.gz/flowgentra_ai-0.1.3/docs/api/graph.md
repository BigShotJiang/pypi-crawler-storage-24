# Graph API Reference

## StateGraphBuilder

Builds a state graph with Python callables as nodes.

```python
from flowgentra_ai import StateGraphBuilder
```

### Constructor

```python
StateGraphBuilder()
```

### Methods

| Method | Description |
|--------|-------------|
| `add_node(name, func)` | Add a node. `func(state: SharedState) -> SharedState` |
| `add_edge(from_node, to_node)` | Add a fixed edge. Use `END` as `to_node` to terminate |
| `add_conditional_edge(from_node, router)` | Add dynamic routing. `router(state) -> str` |
| `set_entry_point(name)` | Set the first node to execute |
| `set_max_steps(n)` | Max execution steps (default: 1000) |
| `interrupt_before(name)` | Pause before this node (human-in-the-loop) |
| `interrupt_after(name)` | Pause after this node |
| `add_subgraph(name, graph)` | Embed a compiled `StateGraph` as a node |
| `add_retry_node(name, func, ...)` | Add a node with automatic retry + backoff |
| `add_timeout_node(name, func, timeout_ms, ...)` | Add a node with timeout enforcement |
| `add_llm_node(name, llm_client, ...)` | Add an LLM-integrated node (reads prompt from state) |
| `add_planner_node(name, llm_client, ...)` | Add LLM-driven planner for dynamic routing |
| `add_evaluation_node(handler, config, ...)` | Add iterative evaluation/refinement node |
| `set_checkpointer(base_dir)` | Enable file-based checkpointing |
| `compile()` | Compile into a runnable `StateGraph` |

### add_retry_node

```python
builder.add_retry_node(
    name="fetch_data",
    func=fetch_fn,
    max_retries=3,        # default: 3
    backoff_ms=1000,      # default: 1000
    backoff_multiplier=2.0,  # default: 2.0
    max_backoff_ms=30000,    # default: 30000
)
```

### add_timeout_node

```python
builder.add_timeout_node(
    name="slow_op",
    func=slow_fn,
    timeout_ms=5000,
    on_timeout="error",  # "error" (default) or "skip"
)
```

### add_llm_node

```python
builder.add_llm_node(
    name="generate",
    llm_client=client,
    prompt_key="prompt",         # state key to read prompt from
    output_key="llm_response",   # state key to write response to
    system_prompt="You are a helpful assistant.",
)
```

### add_planner_node

```python
builder.add_planner_node(
    name="planner",
    llm_client=client,
    prompt=None,  # optional custom planner prompt
)
```

The planner reads `_reachable_nodes` from state and sets `_next_node`.

### add_evaluation_node

```python
from flowgentra_ai import EvaluationNodeConfig

config = EvaluationNodeConfig(
    name="refine",
    field_state="llm_output",
    min_confidence=0.8,
    max_retries=3,
    rubric="Is the output clear and accurate?",
)

# scorer is optional: (output, attempt) -> (score, feedback)
builder.add_evaluation_node(handler=refine_fn, config=config, scorer=my_scorer)
```

---

## StateGraph

A compiled, runnable state graph. Created by `StateGraphBuilder.compile()`.

```python
from flowgentra_ai import StateGraph
```

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `invoke(state)` | `SharedState` | Execute the graph with initial state |
| `invoke_with_thread(thread_id, state)` | `SharedState` | Execute with checkpointing |
| `resume(thread_id)` | `SharedState` | Resume an interrupted graph |
| `resume_with_state(thread_id, updates)` | `SharedState` | Resume with state modifications |
| `node_names()` | `list[str]` | List all node names |
| `entry_point()` | `str` | Get entry point node name |
| `to_dot()` | `str` | Export as Graphviz DOT |
| `to_mermaid()` | `str` | Export as Mermaid diagram |
| `to_json()` | `dict` | Export structure as JSON |

---

## END

Sentinel constant for terminating edge targets.

```python
from flowgentra_ai import END

builder.add_edge("last_node", END)
```

---

## MessageGraphBuilder

Convenience builder for chat-focused workflows with automatic message accumulation.

```python
from flowgentra_ai import MessageGraphBuilder
```

### Constructor

```python
MessageGraphBuilder()
```

### Methods

| Method | Description |
|--------|-------------|
| `add_node(name, func)` | Add a node. `func(messages: list[Message]) -> list[Message]` |
| `add_edge(from_node, to_node)` | Add a fixed edge |
| `set_entry_point(name)` | Set entry point |
| `compile()` | Compile into a `MessageGraph` |

---

## MessageGraph

A compiled message-centric graph.

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `invoke(messages)` | `list[Message]` | Execute with initial messages |
