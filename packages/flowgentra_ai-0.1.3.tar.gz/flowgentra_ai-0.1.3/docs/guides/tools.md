# Tools & Registry

FlowgentraAI includes a tool system with built-in tools and a registry for managing them.

## Tool Registry

```python
from flowgentra_ai import ToolRegistry

# Create with built-in tools
registry = ToolRegistry.with_builtins()
print(registry.list_names())  # ["calculator", "search", ...]
print(len(registry))          # number of tools

# Call a tool
result = registry.call_tool("calculator", {
    "operation": "add",
    "a": 2,
    "b": 3,
})
print(result)  # 5

# Validate input without calling
registry.validate_input("calculator", {
    "operation": "add",
    "a": 2,
    "b": 3,
})

# Empty registry
registry = ToolRegistry()
```

## Built-in Tools

```python
from flowgentra_ai import CalculatorTool, SearchTool, WebRequestTool, FilesTool
```

| Tool | Description |
|------|-------------|
| `CalculatorTool` | Basic arithmetic operations |
| `SearchTool` | Web search |
| `WebRequestTool` | HTTP requests |
| `FilesTool` | File system operations |

## Tool Node

Use `ToolNode` to integrate tool execution into a graph:

```python
from flowgentra_ai import ToolNode, create_tool_node, store_tool_calls, check_tools_condition
```

## JSON Schema

Define schemas for tool input/output validation:

```python
from flowgentra_ai import JsonSchema

# Create schemas
schema = JsonSchema.object()
schema.with_description("Calculator input")
schema.with_required(["operation", "a", "b"])

# Other types
JsonSchema.string()
JsonSchema.number()
JsonSchema.integer()
JsonSchema.boolean()
JsonSchema.array()

# Validate a value
schema.validate({"operation": "add", "a": 1, "b": 2})
```

## LLM Function Calling

Use `ToolDefinition` with the LLM client for function calling:

```python
from flowgentra_ai import LLMClient, LLMConfig, Message, ToolDefinition

client = LLMClient.from_config(LLMConfig("openai", "gpt-4", api_key="sk-..."))

tools = [
    ToolDefinition(
        "calculator",
        "Perform arithmetic",
        {
            "type": "object",
            "properties": {
                "operation": {"type": "string", "enum": ["add", "subtract", "multiply", "divide"]},
                "a": {"type": "number"},
                "b": {"type": "number"},
            },
            "required": ["operation", "a", "b"],
        },
    )
]

response = client.chat_with_tools(
    [Message.user("What is 42 * 17?")],
    tools,
)

if response.has_tool_calls():
    for tc in response.tool_calls():
        print(f"Call: {tc.name}({tc.arguments})")
        result = registry.call_tool(tc.name, tc.arguments)
        print(f"Result: {result}")
```
