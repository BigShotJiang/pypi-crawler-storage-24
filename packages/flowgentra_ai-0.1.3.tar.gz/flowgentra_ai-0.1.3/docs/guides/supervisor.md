# Multi-Agent Supervisor

The `Supervisor` orchestrates multiple agent graphs. It supports two modes:

- **Simple mode**: A Python router function decides the next agent
- **Strategy mode**: One of 11 orchestration strategies manages the flow automatically

## Simple Mode (Router Function)

```python
from flowgentra_ai import Supervisor, SharedState

def router(state):
    """Returns the name of the next agent, or 'FINISH' to stop."""
    task = state.get_string("task") or ""
    if "research" in task:
        return "researcher"
    if "write" in task:
        return "writer"
    return "FINISH"

sup = Supervisor(router)
sup.add_agent("researcher", research_graph)
sup.add_agent("writer", writer_graph)
sup.max_rounds(5)

result = sup.run(SharedState({"task": "research AI trends"}))
```

## Strategy Mode (Config-Based)

Use `Supervisor.from_config()` with a `SupervisorNodeConfig` to access all 11 orchestration strategies from the Rust engine.

### Parallel Execution

Run all agents simultaneously and merge results:

```python
from flowgentra_ai import (
    Supervisor, SupervisorNodeConfig, OrchestrationStrategy,
    ParallelMergeStrategy, SharedState,
)

config = SupervisorNodeConfig(
    "coordinator",
    ["researcher", "analyst", "writer"],
    OrchestrationStrategy.parallel(),
)
config.set_child_timeout_ms(30000)
config.set_merge_strategy(ParallelMergeStrategy.latest())

sup = Supervisor.from_config(config)
sup.add_agent("researcher", research_graph)
sup.add_agent("analyst", analyst_graph)
sup.add_agent("writer", writer_graph)

result = sup.run(SharedState({"topic": "AI trends"}))
```

### Sequential Pipeline

Run agents one after another, passing state through:

```python
config = SupervisorNodeConfig(
    "pipeline",
    ["extract", "transform", "load"],
    OrchestrationStrategy.sequential(),
)
config.set_fail_fast(True)  # stop on first error
```

### Retry Fallback

Try agents in order until one succeeds:

```python
config = SupervisorNodeConfig(
    "resilient",
    ["primary_api", "backup_api", "local_fallback"],
    OrchestrationStrategy.retry_fallback(),
)
config.set_fallback_order(["primary_api", "backup_api", "local_fallback"])
```

### MapReduce

Split input, process in parallel, merge results:

```python
config = SupervisorNodeConfig(
    "batch_processor",
    ["worker_a", "worker_b"],
    OrchestrationStrategy.map_reduce(),
)
config.set_map_key("input_chunks")   # state key with JSON array
config.set_reduce_key("results")     # state key for merged output
```

### Conditional Routing

Route to the right agent based on state:

```python
config = SupervisorNodeConfig(
    "router",
    ["code_agent", "writing_agent", "math_agent"],
    OrchestrationStrategy.conditional_routing(),
)
config.add_routing_rule("task_type == code", "code_agent")
config.add_routing_rule("task_type == writing", "writing_agent")
# First match wins; if none match, uses first child as default
```

### Broadcast (Fan-Out)

Send the same task to all agents and pick the best result:

```python
config = SupervisorNodeConfig(
    "best_of",
    ["agent_a", "agent_b", "agent_c"],
    OrchestrationStrategy.broadcast(),
)
config.set_selection_criteria("highest_score")
config.set_score_key("confidence")
```

### Debate

Agents critique each other's work across multiple rounds:

```python
config = SupervisorNodeConfig(
    "debate",
    ["optimist", "pessimist", "realist"],
    OrchestrationStrategy.debate(),
)
config.set_debate_rounds(3)
config.set_debate_key("question")
```

### Round Robin

Distribute tasks from an array across agents:

```python
config = SupervisorNodeConfig(
    "distributor",
    ["worker_1", "worker_2", "worker_3"],
    OrchestrationStrategy.round_robin(),
)
config.set_tasks_key("tasks")  # state["tasks"] should be a JSON array
```

### Autonomous

Loop until all required outputs are present:

```python
config = SupervisorNodeConfig(
    "autonomous",
    ["researcher", "analyst"],
    OrchestrationStrategy.autonomous(),
)
config.set_goal("Produce a complete market analysis")
config.set_required_outputs(["raw_data", "analysis", "summary"])
config.add_output_owner("raw_data", "researcher")
config.add_output_owner("analysis", "analyst")
config.set_max_iterations(10)
```

## All 11 Strategies

| Strategy | Use Case |
|----------|----------|
| `sequential` | Dependent pipeline steps |
| `parallel` | Independent tasks, speed priority |
| `autonomous` | Goal-driven, loop until done |
| `dynamic` | LLM-driven runtime decisions |
| `round_robin` | Load balancing interchangeable agents |
| `hierarchical` | Large tasks with sub-supervisors |
| `broadcast` | Quality-critical, pick best result |
| `map_reduce` | Batch processing with merge |
| `conditional_routing` | Type-based task routing |
| `retry_fallback` | Fault-tolerant execution |
| `debate` | High-accuracy via multi-agent critique |

## Agents as Callables

You can register Python callables (not just StateGraphs) as agents:

```python
def simple_agent(state):
    state["result"] = "processed"
    return state

sup.add_agent("simple", simple_agent)
```
