//! Python bindings for the EvaluationNode (iterative quality refinement)
//!
//! The evaluation node runs a handler function repeatedly, scoring the output
//! each time, until a confidence threshold is met or max retries are exhausted.

use pyo3::prelude::*;
use pyo3::exceptions::PyRuntimeError;

use flowgentra_ai::core::node::evaluation_node::EvaluationNodeConfig;
use flowgentra_ai::core::state::SharedState;
use flowgentra_ai::core::state_graph::node::Node;
use flowgentra_ai::core::state_graph::StateGraphError;

use crate::state::PySharedState;

// ─── PyEvaluationNodeConfig ─────────────────────────────────────────────────

/// Configuration for an evaluation node.
///
/// The evaluation node runs a handler, scores the output, and retries
/// until `min_confidence` is reached or `max_retries` is exhausted.
///
/// Example:
///     config = EvaluationNodeConfig(
///         name="refine",
///         field_state="llm_output",
///         min_confidence=0.8,
///         max_retries=3,
///         rubric="Is the output clear and accurate?",
///     )
#[pyclass(name = "EvaluationNodeConfig")]
#[derive(Clone)]
pub struct PyEvaluationNodeConfig {
    pub(crate) inner: EvaluationNodeConfig,
}

#[pymethods]
impl PyEvaluationNodeConfig {
    #[new]
    #[pyo3(signature = (name, field_state=None, min_confidence=0.8, max_retries=3, rubric=None))]
    fn new(
        name: &str,
        field_state: Option<String>,
        min_confidence: f64,
        max_retries: u32,
        rubric: Option<String>,
    ) -> PyResult<Self> {
        if min_confidence < 0.0 || min_confidence > 1.0 {
            return Err(PyRuntimeError::new_err(
                "min_confidence must be between 0.0 and 1.0",
            ));
        }
        Ok(PyEvaluationNodeConfig {
            inner: EvaluationNodeConfig {
                name: name.to_string(),
                handler: String::new(),
                field_state,
                min_confidence,
                max_retries,
                rubric,
                config: std::collections::HashMap::new(),
            },
        })
    }

    #[getter]
    fn name(&self) -> String {
        self.inner.name.clone()
    }

    #[getter]
    fn field_state(&self) -> Option<String> {
        self.inner.field_state.clone()
    }

    #[getter]
    fn min_confidence(&self) -> f64 {
        self.inner.min_confidence
    }

    #[getter]
    fn max_retries(&self) -> u32 {
        self.inner.max_retries
    }

    #[getter]
    fn rubric(&self) -> Option<String> {
        self.inner.rubric.clone()
    }

    fn __repr__(&self) -> String {
        format!(
            "EvaluationNodeConfig(name='{}', field_state={:?}, min_confidence={}, max_retries={})",
            self.inner.name, self.inner.field_state, self.inner.min_confidence, self.inner.max_retries
        )
    }
}

// ─── EvaluationGraphNode ────────────────────────────────────────────────────

/// Graph-integrated evaluation node that wraps a Python handler + scorer.
///
/// This node:
/// 1. Calls the handler function with the current state
/// 2. Scores the output using the scorer function
/// 3. If score >= min_confidence, returns the state
/// 4. Otherwise retries up to max_retries times, passing feedback
pub(crate) struct EvaluationGraphNode {
    pub name: String,
    pub handler: PyObject,
    pub scorer: Option<PyObject>,
    pub config: EvaluationNodeConfig,
}

#[async_trait::async_trait]
impl Node<SharedState> for EvaluationGraphNode {
    async fn execute(&self, state: &SharedState) -> Result<SharedState, StateGraphError> {
        let handler = Python::with_gil(|py| self.handler.clone_ref(py));
        let scorer = self.scorer.as_ref().map(|s| Python::with_gil(|py| s.clone_ref(py)));
        let field_state = self.config.get_field_name();
        let min_confidence = self.config.min_confidence;
        let max_retries = self.config.max_retries;
        let mut current_state = state.clone();

        for attempt in 0..=max_retries {
            // Call the handler
            let call_result = Python::with_gil(|py| -> PyResult<SharedState> {
                let f = handler.clone_ref(py);
                let py_state = PySharedState { inner: current_state.clone() };
                let py_result = f.call1(py, (py_state,))?;
                let result_state: PySharedState = py_result.extract(py)?;
                Ok(result_state.inner)
            });

            current_state = call_result.map_err(|e| StateGraphError::ExecutionError {
                node: self.name.clone(),
                reason: format!("Handler error on attempt {}: {}", attempt, e),
            })?;

            // Score the output
            let (score, feedback) = if let Some(ref scorer_fn) = scorer {
                let output_val = field_state
                    .as_ref()
                    .and_then(|k| current_state.get(k))
                    .unwrap_or(serde_json::json!(null));

                Python::with_gil(|py| -> PyResult<(f64, String)> {
                    let s = scorer_fn.clone_ref(py);
                    let py_result = s.call1(py, (crate::json_to_py(py, &output_val)?, attempt))?;
                    let tuple: (f64, String) = py_result.extract(py)?;
                    Ok(tuple)
                })
                .unwrap_or((0.0, "Scorer error".to_string()))
            } else {
                // Default scorer: check if field is non-null and non-empty
                let output_val = field_state
                    .as_ref()
                    .and_then(|k| current_state.get(k));
                let score = match output_val {
                    Some(v) if !v.is_null() => {
                        if let Some(s) = v.as_str() {
                            if s.is_empty() { 0.3 } else { 0.85 }
                        } else {
                            0.85
                        }
                    }
                    _ => 0.0,
                };
                (score, if score >= min_confidence { "OK".to_string() } else { "Output missing or empty".to_string() })
            };

            // Store evaluation metadata
            current_state.set(
                &format!("__eval_score__{}", self.name),
                serde_json::json!(score),
            );
            current_state.set(
                &format!("__eval_attempt__{}", self.name),
                serde_json::json!(attempt),
            );

            if score >= min_confidence {
                current_state.set(
                    &format!("__eval_needs_retry__{}", self.name),
                    serde_json::json!(false),
                );
                return Ok(current_state);
            }

            // Provide feedback for next attempt
            current_state.set(
                &format!("__eval_feedback__{}", self.name),
                serde_json::json!(feedback),
            );
        }

        // Max retries exhausted
        current_state.set(
            &format!("__eval_needs_retry__{}", self.name),
            serde_json::json!(false),
        );
        Ok(current_state)
    }

    fn name(&self) -> &str {
        &self.name
    }
}
