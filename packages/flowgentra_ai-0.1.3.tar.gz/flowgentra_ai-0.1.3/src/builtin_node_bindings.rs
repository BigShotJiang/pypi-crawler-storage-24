//! Python bindings for built-in node types (Retry, Timeout, LLM Node)
//!
//! These nodes wrap Python callables with retry/timeout/LLM logic and can
//! be added to a StateGraph via the builder.

use pyo3::prelude::*;
use pyo3::exceptions::PyRuntimeError;
use std::sync::Arc;
use std::time::Duration;

use flowgentra_ai::core::state::SharedState;
use flowgentra_ai::core::state_graph::node::Node;
use flowgentra_ai::core::state_graph::StateGraphError;

use crate::get_runtime;
use crate::state::PySharedState;

// ─── RetryNode ──────────────────────────────────────────────────────────────

/// A node that wraps another Python callable with retry logic.
///
/// Retries the inner function up to `max_retries` times with exponential backoff.
///
/// Example:
///     retry = RetryNode("fetch_data", fetch_fn, max_retries=3, backoff_ms=1000)
///     # Add to graph:
///     builder.add_retry_node("fetch_data", fetch_fn, max_retries=3)
#[pyclass(name = "RetryNode")]
pub struct PyRetryNode {
    name: String,
    func: PyObject,
    max_retries: usize,
    backoff_ms: u64,
    backoff_multiplier: f64,
    max_backoff_ms: u64,
}

#[pymethods]
impl PyRetryNode {
    #[new]
    #[pyo3(signature = (name, func, max_retries=3, backoff_ms=1000, backoff_multiplier=2.0, max_backoff_ms=30000))]
    fn new(
        name: &str,
        func: PyObject,
        max_retries: usize,
        backoff_ms: u64,
        backoff_multiplier: f64,
        max_backoff_ms: u64,
    ) -> Self {
        PyRetryNode {
            name: name.to_string(),
            func,
            max_retries,
            backoff_ms,
            backoff_multiplier,
            max_backoff_ms,
        }
    }

    /// Execute the retry node with the given state.
    fn run(&self, state: &PySharedState) -> PyResult<PySharedState> {
        let rt = get_runtime();
        let func = Python::with_gil(|py| self.func.clone_ref(py));
        let max_retries = self.max_retries;
        let mut backoff = self.backoff_ms;
        let multiplier = self.backoff_multiplier;
        let max_backoff = self.max_backoff_ms;
        let current_state = state.inner.clone();

        let result = rt.block_on(async move {
            let mut last_error = String::new();
            for attempt in 0..=max_retries {
                let call_result = Python::with_gil(|py| -> PyResult<SharedState> {
                    let f = func.clone_ref(py);
                    let py_state = PySharedState { inner: current_state.clone() };
                    let py_result = f.call1(py, (py_state,))?;
                    let result_state: PySharedState = py_result.extract(py)?;
                    Ok(result_state.inner)
                });

                match call_result {
                    Ok(new_state) => return Ok(new_state),
                    Err(e) => {
                        last_error = format!("{}", e);
                        if attempt < max_retries {
                            tokio::time::sleep(Duration::from_millis(backoff)).await;
                            backoff = ((backoff as f64 * multiplier) as u64).min(max_backoff);
                        }
                    }
                }
            }
            Err(last_error)
        });

        match result {
            Ok(new_state) => Ok(PySharedState { inner: new_state }),
            Err(e) => Err(PyRuntimeError::new_err(format!(
                "RetryNode '{}' failed after {} retries: {}",
                self.name, self.max_retries, e
            ))),
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "RetryNode(name='{}', max_retries={}, backoff_ms={})",
            self.name, self.max_retries, self.backoff_ms
        )
    }
}

// ─── TimeoutNode ────────────────────────────────────────────────────────────

/// A node that wraps a Python callable with a timeout.
///
/// If the inner function does not complete within `timeout_ms`, the node
/// raises an error or returns a default value based on `on_timeout`.
///
/// Example:
///     timeout = TimeoutNode("slow_op", slow_fn, timeout_ms=5000)
#[pyclass(name = "TimeoutNode")]
pub struct PyTimeoutNode {
    name: String,
    func: PyObject,
    timeout_ms: u64,
    on_timeout: String, // "error", "skip", "default_value"
}

#[pymethods]
impl PyTimeoutNode {
    #[new]
    #[pyo3(signature = (name, func, timeout_ms, on_timeout="error"))]
    fn new(name: &str, func: PyObject, timeout_ms: u64, on_timeout: &str) -> Self {
        PyTimeoutNode {
            name: name.to_string(),
            func,
            timeout_ms,
            on_timeout: on_timeout.to_string(),
        }
    }

    /// Execute the timeout node with the given state.
    fn run(&self, state: &PySharedState) -> PyResult<PySharedState> {
        let rt = get_runtime();
        let func = Python::with_gil(|py| self.func.clone_ref(py));
        let timeout = Duration::from_millis(self.timeout_ms);
        let current_state = state.inner.clone();
        let on_timeout = self.on_timeout.clone();
        let name = self.name.clone();

        let result = rt.block_on(async move {
            let inner_future = async {
                Python::with_gil(|py| -> PyResult<SharedState> {
                    let f = func.clone_ref(py);
                    let py_state = PySharedState { inner: current_state.clone() };
                    let py_result = f.call1(py, (py_state,))?;
                    let result_state: PySharedState = py_result.extract(py)?;
                    Ok(result_state.inner)
                })
            };

            match tokio::time::timeout(timeout, inner_future).await {
                Ok(Ok(new_state)) => Ok(new_state),
                Ok(Err(e)) => Err(format!("Node '{}' error: {}", name, e)),
                Err(_) => match on_timeout.as_str() {
                    "skip" => Ok(current_state),
                    _ => Err(format!("Node '{}' timed out after {}ms", name, timeout.as_millis())),
                },
            }
        });

        match result {
            Ok(new_state) => Ok(PySharedState { inner: new_state }),
            Err(e) => Err(PyRuntimeError::new_err(e)),
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "TimeoutNode(name='{}', timeout_ms={}, on_timeout='{}')",
            self.name, self.timeout_ms, self.on_timeout
        )
    }
}

// ─── Graph node adapters for use in StateGraphBuilder ───────────────────────

/// Wraps a Python callable with retry logic as a Node<SharedState>.
pub(crate) struct RetryGraphNode {
    pub name: String,
    pub func: PyObject,
    pub max_retries: usize,
    pub backoff_ms: u64,
    pub backoff_multiplier: f64,
    pub max_backoff_ms: u64,
}

#[async_trait::async_trait]
impl Node<SharedState> for RetryGraphNode {
    async fn execute(&self, state: &SharedState) -> Result<SharedState, StateGraphError> {
        let func = Python::with_gil(|py| self.func.clone_ref(py));
        let mut backoff = self.backoff_ms;
        let mut last_error = String::new();

        for attempt in 0..=self.max_retries {
            let call_result = Python::with_gil(|py| -> PyResult<SharedState> {
                let f = func.clone_ref(py);
                let py_state = PySharedState { inner: state.clone() };
                let py_result = f.call1(py, (py_state,))?;
                let result_state: PySharedState = py_result.extract(py)?;
                Ok(result_state.inner)
            });

            match call_result {
                Ok(new_state) => return Ok(new_state),
                Err(e) => {
                    last_error = format!("{}", e);
                    if attempt < self.max_retries {
                        tokio::time::sleep(Duration::from_millis(backoff)).await;
                        backoff = ((backoff as f64 * self.backoff_multiplier) as u64)
                            .min(self.max_backoff_ms);
                    }
                }
            }
        }

        Err(StateGraphError::ExecutionError {
            node: self.name.clone(),
            reason: format!("Failed after {} retries: {}", self.max_retries, last_error),
        })
    }

    fn name(&self) -> &str {
        &self.name
    }
}

/// Wraps a Python callable with a timeout as a Node<SharedState>.
pub(crate) struct TimeoutGraphNode {
    pub name: String,
    pub func: PyObject,
    pub timeout_ms: u64,
    pub on_timeout: String,
}

#[async_trait::async_trait]
impl Node<SharedState> for TimeoutGraphNode {
    async fn execute(&self, state: &SharedState) -> Result<SharedState, StateGraphError> {
        let func = Python::with_gil(|py| self.func.clone_ref(py));
        let timeout = Duration::from_millis(self.timeout_ms);
        let state_clone = state.clone();

        let inner_future = async {
            Python::with_gil(|py| -> PyResult<SharedState> {
                let f = func.clone_ref(py);
                let py_state = PySharedState { inner: state_clone };
                let py_result = f.call1(py, (py_state,))?;
                let result_state: PySharedState = py_result.extract(py)?;
                Ok(result_state.inner)
            })
        };

        match tokio::time::timeout(timeout, inner_future).await {
            Ok(Ok(new_state)) => Ok(new_state),
            Ok(Err(e)) => Err(StateGraphError::ExecutionError {
                node: self.name.clone(),
                reason: format!("Python node error: {}", e),
            }),
            Err(_) => match self.on_timeout.as_str() {
                "skip" => Ok(state.clone()),
                _ => Err(StateGraphError::ExecutionError {
                    node: self.name.clone(),
                    reason: format!("Timed out after {}ms", self.timeout_ms),
                }),
            },
        }
    }

    fn name(&self) -> &str {
        &self.name
    }
}

/// Wraps a Python callable as an LLM-integrated node.
/// The node calls the LLM with a prompt derived from state, then stores the response.
pub(crate) struct LLMGraphNode {
    pub name: String,
    pub llm_client: Arc<dyn flowgentra_ai::core::llm::LLMClient>,
    pub system_prompt: Option<String>,
    pub prompt_key: String,
    pub output_key: String,
}

#[async_trait::async_trait]
impl Node<SharedState> for LLMGraphNode {
    async fn execute(&self, state: &SharedState) -> Result<SharedState, StateGraphError> {
        use flowgentra_ai::core::llm::Message;

        let user_prompt = state
            .get(&self.prompt_key)
            .and_then(|v| v.as_str().map(String::from))
            .unwrap_or_default();

        if user_prompt.is_empty() {
            return Err(StateGraphError::ExecutionError {
                node: self.name.clone(),
                reason: format!("No prompt found at state key '{}'", self.prompt_key),
            });
        }

        let mut messages = Vec::new();
        if let Some(ref sys) = self.system_prompt {
            messages.push(Message::system(sys));
        }
        messages.push(Message::user(&user_prompt));

        let response = self.llm_client.chat(messages).await.map_err(|e| {
            StateGraphError::ExecutionError {
                node: self.name.clone(),
                reason: format!("LLM call failed: {}", e),
            }
        })?;

        state.set(&self.output_key, serde_json::json!(response.content));
        Ok(state.clone())
    }

    fn name(&self) -> &str {
        &self.name
    }
}
