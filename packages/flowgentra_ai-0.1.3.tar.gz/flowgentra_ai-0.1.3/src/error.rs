//! Error conversion from various error types to Python exceptions

use pyo3::prelude::*;
use pyo3::exceptions::PyRuntimeError;
use flowgentra_ai::core::error::FlowgentraError;

/// Convert FlowgentraError to PyErr
pub fn to_py_err(e: FlowgentraError) -> PyErr {
    let msg = format!("{}", e);
    if let Some(hint) = e.hint() {
        PyRuntimeError::new_err(format!("{}\nHint: {}", msg, hint))
    } else {
        PyRuntimeError::new_err(msg)
    }
}

/// Convert any Display error to PyErr
pub fn to_py_err_generic(e: impl std::fmt::Display) -> PyErr {
    PyRuntimeError::new_err(format!("{}", e))
}
