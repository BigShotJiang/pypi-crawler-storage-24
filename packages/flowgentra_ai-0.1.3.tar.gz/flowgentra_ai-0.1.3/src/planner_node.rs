//! Python bindings for the Planner Node (LLM-driven dynamic routing)
//!
//! The planner node uses an LLM to decide the next node to execute
//! based on the current state and reachable nodes.

use pyo3::prelude::*;
use pyo3::exceptions::PyRuntimeError;
use std::sync::Arc;

use flowgentra_ai::core::llm::LLMClient;
use flowgentra_ai::core::node::planner::create_planner_handler;
use flowgentra_ai::core::state::SharedState;
use flowgentra_ai::core::state_graph::node::Node;
use flowgentra_ai::core::state_graph::StateGraphError;

use crate::get_runtime;
use crate::llm_client::PyLLMClient;
use crate::state::PySharedState;

// ─── Planner as a Node for StateGraphBuilder ────────────────────────────────

/// Wraps the Rust planner handler as a Node<SharedState> so it can be
/// plugged into a StateGraphBuilder.
struct PlannerHandlerNode {
    name: String,
    llm_client: Arc<dyn LLMClient>,
    prompt_template: Option<String>,
}

#[async_trait::async_trait]
impl Node<SharedState> for PlannerHandlerNode {
    async fn execute(&self, state: &SharedState) -> Result<SharedState, StateGraphError> {
        // Create a fresh handler each time (the handler is cheap — it's just a closure)
        let handler = create_planner_handler::<SharedState>(
            Arc::clone(&self.llm_client),
            self.prompt_template.clone(),
        );
        // The handler takes ownership of state, so clone it
        let result = handler(state.clone());
        result.await.map_err(|e| StateGraphError::ExecutionError {
            node: self.name.clone(),
            reason: format!("Planner error: {}", e),
        })
    }

    fn name(&self) -> &str {
        &self.name
    }
}

// ─── PyPlannerNode ──────────────────────────────────────────────────────────

/// LLM-driven planner node for dynamic routing in a StateGraph.
///
/// The planner reads `_reachable_nodes` from state and uses an LLM
/// to decide which node should run next, setting `_next_node` in state.
///
/// Usage:
///     planner = PlannerNode("planner", llm_client)
///     planner.set_prompt("You are a task planner...")
///
///     # Add to graph via StateGraphBuilder
///     builder.add_planner_node("planner", llm_client)
///     # Or manually:
///     result = planner.run(state)  # sets state["_next_node"]
///
/// The planner expects these state keys:
///   - `_current_node`: name of the current node (set by runtime)
///   - `_reachable_nodes`: JSON array of valid next node names
///
/// It sets:
///   - `_next_node`: the chosen next node name (or "END")
#[pyclass(name = "PlannerNode")]
pub struct PyPlannerNode {
    name: String,
    llm_client: Arc<dyn LLMClient>,
    prompt_template: Option<String>,
}

#[pymethods]
impl PyPlannerNode {
    /// Create a new planner node.
    ///
    /// Args:
    ///     name: Node name for the graph
    ///     llm_client: LLMClient instance for making LLM calls
    ///     prompt: Optional custom system prompt (replaces default planner prompt)
    #[new]
    #[pyo3(signature = (name, llm_client, prompt=None))]
    fn new(
        name: &str,
        llm_client: &PyLLMClient,
        prompt: Option<String>,
    ) -> Self {
        PyPlannerNode {
            name: name.to_string(),
            llm_client: llm_client.inner.clone(),
            prompt_template: prompt,
        }
    }

    /// Set a custom system prompt for the planner LLM.
    fn set_prompt(&mut self, prompt: &str) {
        self.prompt_template = Some(prompt.to_string());
    }

    /// Run the planner on the given state.
    ///
    /// Sets `_next_node` in the returned state.
    fn run(&self, state: &PySharedState) -> PyResult<PySharedState> {
        let rt = get_runtime();
        let handler = create_planner_handler::<SharedState>(
            Arc::clone(&self.llm_client),
            self.prompt_template.clone(),
        );

        let result = rt.block_on(handler(state.inner.clone()));
        match result {
            Ok(new_state) => Ok(PySharedState { inner: new_state }),
            Err(e) => Err(PyRuntimeError::new_err(format!("Planner error: {}", e))),
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "PlannerNode(name='{}', custom_prompt={})",
            self.name,
            self.prompt_template.is_some()
        )
    }
}

/// Helper: create a Node<SharedState> from a PlannerNode for use in StateGraphBuilder.
pub(crate) fn create_planner_graph_node(
    name: &str,
    llm_client: Arc<dyn LLMClient>,
    prompt_template: Option<String>,
) -> Arc<dyn Node<SharedState>> {
    Arc::new(PlannerHandlerNode {
        name: name.to_string(),
        llm_client,
        prompt_template,
    })
}
