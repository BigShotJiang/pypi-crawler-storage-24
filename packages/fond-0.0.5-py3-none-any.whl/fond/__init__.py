"""Fond Package."""

from pathlib import Path
from typing import cast

from fond._internal.cli import main
from fond._internal.info import METADATA

__version__: str = METADATA.version

_PACKAGE_DIR: Path = Path(__file__).parent
_INCLUDE_PATH = _PACKAGE_DIR / "include"
_LIBS_PATH = _PACKAGE_DIR / "libs"


def get_include[T = str](t: type[T] = str) -> T:  # ty:ignore[invalid-parameter-default]
    """Return path to the C++ header files directory.

    Usage in build systems:
        include_dirs = [fond.get_include(str)]

    Or with compiler flags:
        -I$(python -c "import fond; print(fond.get_include(str))")

        Usage in Python code:
        include_path = fond.get_include(Path) # Returns a pathlib.Path object
        include_path = fond.get_include() # Returns a string path (default)
    """
    return cast("T", _INCLUDE_PATH) if t is Path else cast("T", str(_INCLUDE_PATH))


def get_libs[T = str](t: type[T] = str) -> T:  # ty:ignore[invalid-parameter-default]
    """Return path to the C++ library files directory."""
    return cast("T", _LIBS_PATH) if t is Path else cast("T", str(_LIBS_PATH))


__all__: list[str] = ["METADATA", "__version__", "get_include", "get_libs", "main"]
