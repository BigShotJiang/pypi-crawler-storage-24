#include <Python.h>
#include <cstdint>
#include <cstring>
#include <vector>
#include <stdexcept>
#include <unordered_map>
#include "constants.hpp"
#include "../byte_buffer.hpp"

namespace Fond::Python {

class Packer {
private:
    uint8Buffer buffer_;
    void pack_object(PyObject* obj);

public:
    Packer() { buffer_.reserve(buffer::MAX_BUFFER_SIZE_); }
    void pack(PyObject* obj) { pack_object(obj); }
    PyObject* get_bytes() {return PyBytes_FromStringAndSize( reinterpret_cast<const char*>(buffer_.data()), buffer_.size() ); }
    void clear() { buffer_.clear(); }
    uint8Buffer get_buffer() const { return buffer_; }
    const uint8_t* data() const { return buffer_.data(); }
    size_t size() const { return buffer_.size();}
    void pack_int(int64_t value) { buffer::pack_int(buffer_, value); }
    void pack_string(const std::string& str) { buffer::pack_string(buffer_, str.c_str(), str.size()); }
    void pack_vector(const std::vector<int>& vec) {
        buffer::pack_array_header(buffer_, vec.size());
        for (int val : vec) buffer::pack_int(buffer_, val);
    }

    void pack_map(const std::unordered_map<std::string, int>& map) {
        buffer::pack_map_header(buffer_, map.size());
        for (const auto& [key, value] : map) {
            buffer::pack_string(buffer_, key.c_str(), key.size());
            buffer::pack_int(buffer_, value);
        }
    }

    template<typename T> void pack_value(const T& value);
};

inline void Packer::pack_object(PyObject* obj) {
    if (obj == Py_None) { buffer::pack_nil(buffer_); return; }
    if (PyBool_Check(obj)) { buffer::pack_bool(buffer_, obj == Py_True); return; }
    if (PyLong_Check(obj)) {
        int64_t value = PyLong_AsLongLong(obj);
        if (value == -1 && PyErr_Occurred()) {
            // Handle overflow - could be unsigned 64-bit
            PyErr_Clear();
            uint64_t uvalue = PyLong_AsUnsignedLongLong(obj);
            if (uvalue == static_cast<uint64_t>(-1) && PyErr_Occurred()) throw std::runtime_error("Integer too large for MessagePack");
            buffer_.write_byte(tag::UINT64);
            buffer_.write_uint64(uvalue);
            return;
        }
        buffer::pack_int(buffer_, value);
        return;
    }
    if (PyFloat_Check(obj)) {
        buffer_.write_byte(tag::FLOAT64);
        buffer_.write_float64(PyFloat_AS_DOUBLE(obj));
        return;
    }

    if (PyUnicode_Check(obj)) {
        Py_ssize_t size;
        const char* data = PyUnicode_AsUTF8AndSize(obj, &size);
        if (!data) throw std::runtime_error("Failed to encode string as UTF-8");
        buffer::pack_string(buffer_, data, size);
        return;
    }
    if (PyBytes_Check(obj)) {
        char* data;
        Py_ssize_t size;
        if (PyBytes_AsStringAndSize(obj, &data, &size) < 0) throw std::runtime_error("Failed to get bytes data");
        buffer::pack_binary(buffer_, reinterpret_cast<const uint8_t*>(data), size);
        return;
    }

    if (PyList_Check(obj) || PyTuple_Check(obj)) {
        Py_ssize_t len = PySequence_Size(obj);
        buffer::pack_array_header(buffer_, len);

        for (Py_ssize_t i = 0; i < len; ++i) {
            PyObject* item = PySequence_GetItem(obj, i);
            if (!item) throw std::runtime_error("Failed to get sequence item");
            pack_object(item);
            Py_DECREF(item);
        }
        return;
    }

    if (PyDict_Check(obj)) {
        Py_ssize_t len = PyDict_Size(obj);
        buffer::pack_map_header(buffer_, len);
        PyObject *key, *value;
        Py_ssize_t pos = 0;
        while (PyDict_Next(obj, &pos, &key, &value)) { pack_object(key); pack_object(value); }
        return;
    }

    PyObject* type_name = PyObject_GetAttrString(reinterpret_cast<PyObject*>(Py_TYPE(obj)), "__name__");
    const char* name = type_name ? PyUnicode_AsUTF8(type_name) : "unknown";
    Py_XDECREF(type_name);
    throw std::runtime_error(std::string("Unsupported type for packing: ") + name);
}

} // namespace msgpack
