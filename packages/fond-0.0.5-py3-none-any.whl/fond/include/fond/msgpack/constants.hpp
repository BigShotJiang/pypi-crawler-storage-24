#pragma once
#include "../byte_buffer.hpp"
#include <cstdint>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>

namespace Fond {

struct MsgPackValue; // Forward declare for recursive type

using MsgPackArray = std::vector<MsgPackValue>;
using MsgPackMap = std::unordered_map<std::string, MsgPackValue>;

struct MsgPackValue {
    std::variant<
        std::nullptr_t,
        bool,
        int64_t,
        uint64_t,
        double,
        std::string,
        std::vector<uint8_t>,
        MsgPackArray,
        MsgPackMap
    >
    data;
};

namespace tag {
    constexpr uint8_t NIL = 0xC0;
    constexpr uint8_t FALSE = 0xC2;
    constexpr uint8_t TRUE = 0xC3;
    constexpr uint8_t UINT8 = 0xCC;
    constexpr uint8_t UINT16 = 0xCD;
    constexpr uint8_t UINT32 = 0xCE;
    constexpr uint8_t UINT64 = 0xCF;
    constexpr uint8_t INT8 = 0xD0;
    constexpr uint8_t INT16 = 0xD1;
    constexpr uint8_t INT32 = 0xD2;
    constexpr uint8_t INT64 = 0xD3;
    constexpr uint8_t FLOAT64 = 0xCB;
    constexpr uint8_t STR8 = 0xD9;
    constexpr uint8_t STR16 = 0xDA;
    constexpr uint8_t STR32 = 0xDB;
    constexpr uint8_t BIN8 = 0xC4;
    constexpr uint8_t BIN16 = 0xC5;
    constexpr uint8_t BIN32 = 0xC6;
    constexpr uint8_t ARRAY16 = 0xDC;
    constexpr uint8_t ARRAY32 = 0xDD;
    constexpr uint8_t MAP16 = 0xDE;
    constexpr uint8_t MAP32 = 0xDF;

    // Fix family masks and bases
    constexpr uint8_t FIXMAP_MASK = 0xF0;
    constexpr uint8_t FIXMAP_BASE = 0x80;
    constexpr uint8_t FIXARRAY_MASK = 0xF0;
    constexpr uint8_t FIXARRAY_BASE = 0x90;
    constexpr uint8_t FIXSTR_MASK = 0xE0;
    constexpr uint8_t FIXSTR_BASE = 0xA0;
    constexpr uint8_t POS_FIXINT_MASK = 0x80;
    constexpr uint8_t NEG_FIXINT_MASK = 0xE0;
    constexpr uint8_t NEG_FIXINT_BASE = 0xE0;

    // Custom Types
    //constexpr uint8_t 

} // namespace tag

namespace buffer {

constexpr size_t MAX_BUFFER_SIZE_ = 1024 * 1024; // 1 MB

static inline void pack_int(uint8Buffer& buffer, int64_t value) {
      // Positive fixint: 0..127
      if (value >= 0 && value <= 127) { buffer.write_byte(static_cast<uint8_t>(value)); return; }
      // Negative fixint: -32..-1
      if (value >= -32 && value < 0) { buffer.write_byte(static_cast<uint8_t>(value & 0xFF)); return; }

      if (value >= 0) { // Choose smallest representation
        if (value <= UINT8_MAX) {
          buffer.write_byte(tag::UINT8);
          buffer.write_byte(static_cast<uint8_t>(value));
        } else if (value <= UINT16_MAX) {
          buffer.write_byte(tag::UINT16);
          buffer.write_uint16(static_cast<uint16_t>(value));
        } else if (value <= UINT32_MAX) {
          buffer.write_byte(tag::UINT32);
          buffer.write_uint32(static_cast<uint32_t>(value));
        } else {
          buffer.write_byte(tag::UINT64);
          buffer.write_uint64(static_cast<uint64_t>(value));
        }
      } else {
        if (value >= INT8_MIN) {
          buffer.write_byte(tag::INT8);
          buffer.write_byte(static_cast<uint8_t>(value & 0xFF));
        } else if (value >= INT16_MIN) {
          buffer.write_byte(tag::INT16);
          buffer.write_uint16(static_cast<uint16_t>(value & 0xFFFF));
        } else if (value >= INT32_MIN) {
          buffer.write_byte(tag::INT32);
          buffer.write_uint32(static_cast<uint32_t>(value & 0xFFFFFFFF));
        } else {
          buffer.write_byte(tag::INT64);
          buffer.write_uint64(static_cast<uint64_t>(value));
        }
    }
}
static inline void pack_nil(uint8Buffer& buffer) { buffer.write_byte(tag::NIL);}
static inline void pack_bool(uint8Buffer& buffer, bool value) { buffer.write_byte(value ? tag::TRUE : tag::FALSE); }
static inline void pack_uint(uint8Buffer& buffer, uint64_t value) {
    if (value <= 127) {
        buffer.write_byte(static_cast<uint8_t>(value));
    } else if (value <= UINT8_MAX) {
        buffer.write_byte(tag::UINT8);
        buffer.write_byte(static_cast<uint8_t>(value));
    } else if (value <= UINT16_MAX) {
        buffer.write_byte(tag::UINT16);
        buffer.write_uint16(static_cast<uint16_t>(value));
    } else if (value <= UINT32_MAX) {
        buffer.write_byte(tag::UINT32);
        buffer.write_uint32(static_cast<uint32_t>(value));
    } else {
        buffer.write_byte(tag::UINT64);
        buffer.write_uint64(value);
    }
}

static inline void pack_double(uint8Buffer& buffer, double value) {
    buffer.write_byte(tag::FLOAT64);
    buffer.write_float64(value);
}

static inline void pack_string(uint8Buffer& buffer, const char* data, size_t len) {
    // fixstr: 0-31 bytes
    if (len <= 31) {
        buffer.write_byte(tag::FIXSTR_BASE | static_cast<uint8_t>(len));
    } else if (len <= UINT8_MAX) {
        buffer.write_byte(tag::STR8);
        buffer.write_byte(static_cast<uint8_t>(len));
    } else if (len <= UINT16_MAX) {
        buffer.write_byte(tag::STR16);
        buffer.write_uint16(static_cast<uint16_t>(len));
    } else if (len <= UINT32_MAX) {
        buffer.write_byte(tag::STR32);
        buffer.write_uint32(static_cast<uint32_t>(len));
    } else { throw std::runtime_error("String too long for MessagePack"); }
    buffer.write_bytes(reinterpret_cast<const uint8_t*>(data), len);
}

static inline void pack_binary(uint8Buffer& buffer, const uint8_t* data, size_t len) {
    if (len <= UINT8_MAX) {
        buffer.write_byte(tag::BIN8);
        buffer.write_byte(static_cast<uint8_t>(len));
    } else if (len <= UINT16_MAX) {
        buffer.write_byte(tag::BIN16);
        buffer.write_uint16(static_cast<uint16_t>(len));
    } else if (len <= UINT32_MAX) {
        buffer.write_byte(tag::BIN32);
        buffer.write_uint32(static_cast<uint32_t>(len));
    } else { throw std::runtime_error("Binary data too long for MessagePack"); }
    buffer.write_bytes(data, len);
}

static inline void pack_array_header(uint8Buffer& buffer, size_t len) {
    if (len <= 15) {
        buffer.write_byte(tag::FIXARRAY_BASE | static_cast<uint8_t>(len));
    } else if (len <= UINT16_MAX) {
        buffer.write_byte(tag::ARRAY16);
        buffer.write_uint16(static_cast<uint16_t>(len));
    } else if (len <= UINT32_MAX) {
        buffer.write_byte(tag::ARRAY32);
        buffer.write_uint32(static_cast<uint32_t>(len));
    } else { throw std::runtime_error("Array too long for MessagePack"); }
}

static inline void pack_map_header(uint8Buffer& buffer, size_t len) {
    if (len <= 15) {
        buffer.write_byte(tag::FIXMAP_BASE | static_cast<uint8_t>(len));
    } else if (len <= UINT16_MAX) {
        buffer.write_byte(tag::MAP16);
        buffer.write_uint16(static_cast<uint16_t>(len));
    } else if (len <= UINT32_MAX) {
        buffer.write_byte(tag::MAP32);
        buffer.write_uint32(static_cast<uint32_t>(len));
    } else { throw std::runtime_error("Map too long for MessagePack"); }
}

} // namespace buffer
} // namespace Fond
