#pragma once

#ifdef _WIN32
    #include <windows.h>
#else
    #include <pthread.h>
#endif

namespace Fond {

class RLock {
public:
    using LockFunc = void (RLock::*)() noexcept;

    explicit RLock(bool enabled = true) noexcept 
        : count_(0)
    {
#ifdef _WIN32
        InitializeCriticalSection(&lock_);
        owner_ = not_owned();
#else
        pthread_mutex_init(&lock_, nullptr);
        owner_ = not_owned();
#endif
        if (enabled) {
            acquire_func_ = &RLock::acquire_impl;
            release_func_ = &RLock::release_impl;
        } else {
            acquire_func_ = &RLock::noop;
            release_func_ = &RLock::noop;
        }
    }

    ~RLock() noexcept {
#ifdef _WIN32
        DeleteCriticalSection(&lock_);
#else
        pthread_mutex_destroy(&lock_);
#endif
    }

    RLock(const RLock&) = delete;
    RLock& operator=(const RLock&) = delete;
    RLock(RLock&&) = delete;
    RLock& operator=(RLock&&) = delete;

    void acquire() noexcept { (this->*acquire_func_)(); }
    void release() noexcept { (this->*release_func_)(); }

    class ScopedLock {
    public:
        explicit ScopedLock(RLock& lock) noexcept : lock_(lock) { lock_.acquire(); }
        ~ScopedLock() noexcept { lock_.release(); }

        ScopedLock(const ScopedLock&) = delete;
        ScopedLock& operator=(const ScopedLock&) = delete;
        ScopedLock(ScopedLock&&) = delete;
        ScopedLock& operator=(ScopedLock&&) = delete;

    private:
        RLock& lock_;
    };

private:
    void noop() noexcept {}

    void acquire_impl() noexcept {
#ifdef _WIN32
        DWORD me = GetCurrentThreadId();
#else
        pthread_t me = pthread_self();
#endif
        
        if (owner_ == me) {
            ++count_;
            return;
        }
        
#ifdef _WIN32
        EnterCriticalSection(&lock_);
#else
        pthread_mutex_lock(&lock_);
#endif
        owner_ = me;
        count_ = 1;
    }

    void release_impl() noexcept {
        --count_;
        if (count_ == 0) {
            owner_ = not_owned();
#ifdef _WIN32
            LeaveCriticalSection(&lock_);
#else
            pthread_mutex_unlock(&lock_);
#endif
        }
    }

#ifdef _WIN32
    static constexpr DWORD not_owned() noexcept { return static_cast<DWORD>(-1); }
    
    CRITICAL_SECTION lock_;
    DWORD owner_;
#else
    static constexpr pthread_t not_owned() noexcept { return static_cast<pthread_t>(0); }
    
    pthread_mutex_t lock_;
    pthread_t owner_;
#endif
    
    unsigned int count_;
    LockFunc acquire_func_;
    LockFunc release_func_;
};

} // namespace Fond
