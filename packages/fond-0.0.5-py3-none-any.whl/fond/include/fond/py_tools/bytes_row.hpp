#pragma once

#include <string>
#include <vector>
#include <map>
#include <variant>
#include <memory>
#include <cstdint>
#include <cstring>

namespace Fond::RowCodec {

enum class FieldType {
    INT64 = 0,
    UINT64 = 1,
    FLOAT32 = 2,
    STRING = 3,
    BINARY = 4,
    BOOLEAN = 5,
    LIST_INT64 = 6,
    LIST_STRING = 7,
    LIST_FLOAT32 = 8
};

using Value = std::variant<
    std::monostate,
    int64_t,
    uint64_t,
    float,
    std::string,
    bool,
    std::vector<int64_t>,
    std::vector<std::string>,
    std::vector<float>
>;

struct FieldMeta {
    std::string name;
    FieldType data_type;
    int offset;
    int id;
    Value default_value;
};

struct FieldDef {
    std::string name;
    FieldType data_type;
    int id;
    Value default_value;
};

// Default extractors for variant types
template <typename T>
const T* get_default(const Value& val) {
    if (std::holds_alternative<T>(val)) return &std::get<T>(val);
    return nullptr;
}

// Write helpers for variable-length fields
namespace detail {

inline void write_string(const std::string& s, char* dest) {
    uint16_t len = static_cast<uint16_t>(s.length());
    std::memcpy(dest, &len, 2);
    if (len > 0) std::memcpy(dest + 2, s.data(), len);
}

inline void write_binary(const std::string& s, char* dest) {
    uint32_t len = static_cast<uint32_t>(s.length());
    std::memcpy(dest, &len, 4);
    if (len > 0) std::memcpy(dest + 4, s.data(), len);
}

inline void write_list_int64(const std::vector<int64_t>& vec, char* dest) {
    uint16_t len = static_cast<uint16_t>(vec.size());
    std::memcpy(dest, &len, 2);
    if (len > 0) std::memcpy(dest + 2, vec.data(), len * sizeof(int64_t));
}

inline void write_list_float32(const std::vector<float>& vec, char* dest) {
    uint16_t len = static_cast<uint16_t>(vec.size());
    std::memcpy(dest, &len, 2);
    if (len > 0) std::memcpy(dest + 2, vec.data(), len * sizeof(float));
}

inline void write_list_string(const std::vector<std::string>& vec, char* dest) {
    uint16_t len = static_cast<uint16_t>(vec.size());
    std::memcpy(dest, &len, 2);
    char* cur = dest + 2;
    for (const auto& s : vec) {
        uint16_t slen = static_cast<uint16_t>(s.length());
        std::memcpy(cur, &slen, 2);
        cur += 2;
        if (slen > 0) std::memcpy(cur, s.data(), slen);
        cur += slen;
    }
}

inline int list_string_content_len(const std::vector<std::string>& vec) {
    int total = 0;
    for (const auto& s : vec) total += static_cast<int>(s.length());
    return total;
}

} // namespace detail

class Schema {
public:
    Schema(const std::vector<FieldDef>& fields);

    const std::vector<FieldMeta>& get_field_order() const { return field_orders_; }
    int get_total_byte_length() const { return total_byte_length_; }
    const FieldMeta* get_field_meta(const std::string& name) const;

private:
    std::vector<FieldMeta> field_orders_;
    std::map<std::string, FieldMeta> field_metas_;
    int total_byte_length_;
};

class BytesRow {
public:
    explicit BytesRow(std::shared_ptr<Schema> schema) : schema_(std::move(schema)) {}

    std::string serialize(const std::vector<Value>& row_data) const;

    // Accessor must implement:
    //   bool has_value(const RowT& row, int field_idx) const;
    //   int64_t get_int64(const RowT& row, int field_idx) const;
    //   uint64_t get_uint64(const RowT& row, int field_idx) const;
    //   float get_float(const RowT& row, int field_idx) const;
    //   bool get_bool(const RowT& row, int field_idx) const;
    //   int get_string_len(const RowT& row, int field_idx) const;
    //   int get_binary_len(const RowT& row, int field_idx) const;
    //   int get_list_len(const RowT& row, int field_idx) const;
    //   int get_list_string_content_len(const RowT& row, int field_idx) const;
    //   void write_string(const RowT& row, int field_idx, char* dest) const;
    //   void write_binary(const RowT& row, int field_idx, char* dest) const;
    //   void write_list_int64(const RowT& row, int field_idx, char* dest) const;
    //   void write_list_float32(const RowT& row, int field_idx, char* dest) const;
    //   void write_list_string(const RowT& row, int field_idx, char* dest) const;
    template <typename RowT, typename AccessorT>
    std::string serialize_template(const RowT& row, const AccessorT& accessor) const {
        const auto& field_order = schema_->get_field_order();

        struct VarFieldInfo { int offset; int length; };
        std::vector<VarFieldInfo> var_infos(field_order.size());

        // Pass 1: calculate total size
        int variable_region_offset = schema_->get_total_byte_length();

        for (size_t i = 0; i < field_order.size(); ++i) {
            const auto& meta = field_order[i];

            switch (meta.data_type) {
                case FieldType::STRING: {
                    int len = accessor.has_value(row, i) ? accessor.get_string_len(row, i)
                        : (get_default<std::string>(meta.default_value) ? static_cast<int>(get_default<std::string>(meta.default_value)->length()) : 0);
                    var_infos[i] = {variable_region_offset, len};
                    variable_region_offset += 2 + len;
                    break;
                }
                case FieldType::BINARY: {
                    int len = accessor.has_value(row, i) ? accessor.get_binary_len(row, i)
                        : (get_default<std::string>(meta.default_value) ? static_cast<int>(get_default<std::string>(meta.default_value)->length()) : 0);
                    var_infos[i] = {variable_region_offset, len};
                    variable_region_offset += 4 + len;
                    break;
                }
                case FieldType::LIST_INT64: {
                    int len = accessor.has_value(row, i) ? accessor.get_list_len(row, i)
                        : (get_default<std::vector<int64_t>>(meta.default_value) ? static_cast<int>(get_default<std::vector<int64_t>>(meta.default_value)->size()) : 0);
                    var_infos[i] = {variable_region_offset, len};
                    variable_region_offset += 2 + len * 8;
                    break;
                }
                case FieldType::LIST_FLOAT32: {
                    int len = accessor.has_value(row, i) ? accessor.get_list_len(row, i)
                        : (get_default<std::vector<float>>(meta.default_value) ? static_cast<int>(get_default<std::vector<float>>(meta.default_value)->size()) : 0);
                    var_infos[i] = {variable_region_offset, len};
                    variable_region_offset += 2 + len * 4;
                    break;
                }
                case FieldType::LIST_STRING: {
                    int list_len = 0, content_len = 0;
                    if (accessor.has_value(row, i)) {
                        list_len = accessor.get_list_len(row, i);
                        content_len = accessor.get_list_string_content_len(row, i);
                    } else if (auto* def = get_default<std::vector<std::string>>(meta.default_value)) {
                        list_len = static_cast<int>(def->size());
                        content_len = detail::list_string_content_len(*def);
                    }
                    var_infos[i] = {variable_region_offset, list_len};
                    variable_region_offset += 2 + (2 * list_len) + content_len;
                    break;
                }
                default: break;
            }
        }

        std::string buffer;
        buffer.resize(variable_region_offset);
        char* ptr = &buffer[0];
        ptr[0] = static_cast<uint8_t>(field_order.size());

        // Pass 2: write data
        for (size_t i = 0; i < field_order.size(); ++i) {
            const auto& meta = field_order[i];
            char* field_ptr = ptr + meta.offset;
            bool has_val = accessor.has_value(row, i);

            switch (meta.data_type) {
                case FieldType::INT64: {
                    int64_t v = has_val ? accessor.get_int64(row, i)
                        : (std::holds_alternative<int64_t>(meta.default_value) ? std::get<int64_t>(meta.default_value)
                        : (std::holds_alternative<uint64_t>(meta.default_value) ? static_cast<int64_t>(std::get<uint64_t>(meta.default_value)) : 0));
                    std::memcpy(field_ptr, &v, sizeof(v));
                    break;
                }
                case FieldType::UINT64: {
                    uint64_t v = has_val ? accessor.get_uint64(row, i)
                        : (std::holds_alternative<uint64_t>(meta.default_value) ? std::get<uint64_t>(meta.default_value)
                        : (std::holds_alternative<int64_t>(meta.default_value) ? static_cast<uint64_t>(std::get<int64_t>(meta.default_value)) : 0));
                    std::memcpy(field_ptr, &v, sizeof(v));
                    break;
                }
                case FieldType::FLOAT32: {
                    float v = has_val ? accessor.get_float(row, i)
                        : (std::holds_alternative<float>(meta.default_value) ? std::get<float>(meta.default_value) : 0.0f);
                    std::memcpy(field_ptr, &v, sizeof(v));
                    break;
                }
                case FieldType::BOOLEAN: {
                    bool v = has_val ? accessor.get_bool(row, i)
                        : (std::holds_alternative<bool>(meta.default_value) ? std::get<bool>(meta.default_value) : false);
                    uint8_t b = v ? 1 : 0;
                    std::memcpy(field_ptr, &b, sizeof(b));
                    break;
                }
                case FieldType::STRING:
                case FieldType::BINARY:
                case FieldType::LIST_INT64:
                case FieldType::LIST_FLOAT32:
                case FieldType::LIST_STRING: {
                    uint32_t offset = static_cast<uint32_t>(var_infos[i].offset);
                    std::memcpy(field_ptr, &offset, sizeof(offset));
                    char* var_ptr = ptr + offset;
                    write_variable_field(meta.data_type, row, i, has_val, meta.default_value, accessor, var_ptr);
                    break;
                }
            }
        }
        return buffer;
    }

    std::map<std::string, Value> deserialize(const std::string& serialized_data) const;
    Value deserialize_field(const std::string& serialized_data, const std::string& field_name) const;
    const Schema& get_schema() const { return *schema_; }

private:
    std::shared_ptr<Schema> schema_;

    template <typename RowT, typename AccessorT>
    void write_variable_field(FieldType type, const RowT& row, size_t i, bool has_val,
                              const Value& default_value, const AccessorT& accessor, char* dest) const {
        switch (type) {
            case FieldType::STRING:
                if (has_val) accessor.write_string(row, i, dest);
                else if (auto* d = get_default<std::string>(default_value)) detail::write_string(*d, dest);
                else { uint16_t z = 0; std::memcpy(dest, &z, 2); }
                break;
            case FieldType::BINARY:
                if (has_val) accessor.write_binary(row, i, dest);
                else if (auto* d = get_default<std::string>(default_value)) detail::write_binary(*d, dest);
                else { uint32_t z = 0; std::memcpy(dest, &z, 4); }
                break;
            case FieldType::LIST_INT64:
                if (has_val) accessor.write_list_int64(row, i, dest);
                else if (auto* d = get_default<std::vector<int64_t>>(default_value)) detail::write_list_int64(*d, dest);
                else { uint16_t z = 0; std::memcpy(dest, &z, 2); }
                break;
            case FieldType::LIST_FLOAT32:
                if (has_val) accessor.write_list_float32(row, i, dest);
                else if (auto* d = get_default<std::vector<float>>(default_value)) detail::write_list_float32(*d, dest);
                else { uint16_t z = 0; std::memcpy(dest, &z, 2); }
                break;
            case FieldType::LIST_STRING:
                if (has_val) accessor.write_list_string(row, i, dest);
                else if (auto* d = get_default<std::vector<std::string>>(default_value)) detail::write_list_string(*d, dest);
                else { uint16_t z = 0; std::memcpy(dest, &z, 2); }
                break;
            default: break;
        }
    }
};

} // namespace Fond::RowCodec
