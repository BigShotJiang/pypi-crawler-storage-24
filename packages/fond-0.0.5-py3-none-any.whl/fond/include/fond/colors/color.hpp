#pragma once

#include <cstdint>
#include <format>
#include <string>

#ifdef HAS_IMGUI
#include <imgui.h>
#endif

namespace Fond {

constexpr float RGB_MAX = 255.0f;

struct Color {
    uint8_t r, g, b, a = 255;

    constexpr float norm_r() const { return r / RGB_MAX; }
    constexpr float norm_g() const { return g / RGB_MAX; }
    constexpr float norm_b() const { return b / RGB_MAX; }
    constexpr float norm_a() const { return a / RGB_MAX; }

    constexpr uint32_t to_rgba() const {
        return (static_cast<uint32_t>(r) << 24) |
               (static_cast<uint32_t>(g) << 16) |
               (static_cast<uint32_t>(b) << 8) | a;
    }

    std::string to_ansi() const { return std::format("\033[38;2;{};{};{}m", r, g, b); }
    std::string to_ansi_bold() const { return std::format("\033[1;38;2;{};{};{}m", r, g, b); }
    std::string to_ansi_dim() const { return std::format("\033[2;38;2;{};{};{}m", r, g, b); }
    std::string to_ansi_bg() const { return std::format("\033[48;2;{};{};{}m", r, g, b); }

    constexpr bool operator==(const Color& other) const { return r == other.r && g == other.g && b == other.b && a == other.a; }

    #ifdef HAS_IMGUI
    ImVec4 to_imgui() const { return ImVec4{norm_r(), norm_g(), norm_b(), norm_a()}; }
    ImU32 to_imgui_u32() const { return IM_COL32(r, g, b, a); }
    #endif
};

} // namespace Fond
