#pragma once

#ifdef LOGGER_COLORS

namespace Fond::Ansi {

constexpr const char* RESET = "\033[0m";
constexpr const char* BOLD  = "\033[1m";
constexpr const char* DIM   = "\033[2m";

constexpr const char* BLACK   = "\033[30m";
constexpr const char* RED     = "\033[31m";
constexpr const char* GREEN   = "\033[32m";
constexpr const char* YELLOW  = "\033[33m";
constexpr const char* BLUE    = "\033[34m";
constexpr const char* MAGENTA = "\033[35m";
constexpr const char* CYAN    = "\033[36m";
constexpr const char* WHITE   = "\033[37m";

constexpr const char* BOLD_RED     = "\033[1;31m";
constexpr const char* BOLD_GREEN   = "\033[1;32m";
constexpr const char* BOLD_YELLOW  = "\033[1;33m";
constexpr const char* BOLD_BLUE    = "\033[1;34m";
constexpr const char* BOLD_MAGENTA = "\033[1;35m";
constexpr const char* BOLD_CYAN    = "\033[1;36m";
constexpr const char* BOLD_WHITE   = "\033[1;37m";

constexpr const char* DIM_RED     = "\033[2;31m";
constexpr const char* DIM_GREEN   = "\033[2;32m";
constexpr const char* DIM_YELLOW  = "\033[2;33m";
constexpr const char* DIM_BLUE    = "\033[2;34m";
constexpr const char* DIM_MAGENTA = "\033[2;35m";
constexpr const char* DIM_CYAN    = "\033[2;36m";
constexpr const char* DIM_WHITE   = "\033[2;37m";

// For exact palette RGB colors, use:
//   Colors::RED.to_ansi()      → "\033[38;2;230;41;55m"
//   Colors::RED.to_ansi_bold() → "\033[1;38;2;230;41;55m"
//   Colors::RED.to_ansi_dim()  → "\033[2;38;2;230;41;55m"

} // namespace Fond::Ansi

#endif
