#pragma once
// key_store.hpp — File-backed key/value store using MsgPack
// =========================================================
//
// Intended for persisting runtime game state between sessions:
// scores, unlocks, last position, etc. NOT for hand-authored config
// (use Lua for that).
//
// Supported value types: bool, int64_t, uint64_t, double, std::string, std::vector<uint8_t>
// Convenience: float, int, int32_t coerce automatically via set<T>.
//
// Quick start:
//   KeyStore store("save.bin");
//   store.load();                             // no-op if file missing
//   store.set("volume", 0.8);
//   store.set("fullscreen", true);
//   store.set("last_map", std::string("e1m1"));
//   store.save();
//
//   double vol  = store.get<double>("volume", 1.0);
//   bool   fs   = store.get<bool>("fullscreen", false);
//   bool   has  = store.has("last_map");

#include "msgpack/packer.hpp"
#include "msgpack/unpacker.hpp"

#include <concepts>
#include <filesystem>
#include <fstream>
#include <string>
#include <type_traits>

namespace Fond {

// Concept covering the types MsgPackValue can hold
template<typename T>
concept KeyStoreType =
    std::same_as<T, bool>                    ||
    std::same_as<T, int64_t>                 ||
    std::same_as<T, uint64_t>                ||
    std::same_as<T, double>                  ||
    std::same_as<T, std::string>             ||
    std::same_as<T, std::vector<uint8_t>>    ||
    std::same_as<T, float>                   || // convenience coercions
    std::integral<T>;

class KeyStore {
public:
    explicit KeyStore(std::filesystem::path path) : path_(std::move(path)) {}

    // ---- load -------------------------------------------------------
    // Reads and deserializes from file. Silent no-op if file doesn't exist.
    // Returns false if file exists but failed to parse.
    bool load() {
        if (!std::filesystem::exists(path_)) return true;

        std::ifstream f(path_, std::ios::binary | std::ios::ate);
        if (!f) return false;

        auto size = f.tellg();
        f.seekg(0);
        std::vector<uint8_t> buf(static_cast<size_t>(size));
        f.read(reinterpret_cast<char*>(buf.data()), size);

        try {
            Unpacker u(buf.data(), buf.size());
            auto val = u.unpack();
            map_ = std::get<MsgPackMap>(val.data);
        } catch (...) {
            return false;
        }
        return true;
    }

    bool save() const {
        std::ofstream f(path_, std::ios::binary | std::ios::trunc);
        if (!f) return false;

        Packer p;
        p.pack(MsgPackValue{map_});
        f.write(reinterpret_cast<const char*>(p.data()), static_cast<std::streamsize>(p.size()));
        return f.good();
    }

    void set(const std::string& key, bool v)                        { map_[key] = {v}; }
    void set(const std::string& key, double v)                      { map_[key] = {v}; }
    void set(const std::string& key, float v)                       { map_[key] = {static_cast<double>(v)}; }
    void set(const std::string& key, int64_t v)                     { map_[key] = {v}; }
    void set(const std::string& key, uint64_t v)                    { map_[key] = {v}; }
    void set(const std::string& key, const std::string& v)          { map_[key] = {v}; }
    void set(const std::string& key, std::string&& v)               { map_[key] = {std::move(v)}; }
    void set(const std::string& key, const std::vector<uint8_t>& v) { map_[key] = {v}; }

    // Catch-all for int, int32_t, etc.
    template<std::integral T> requires (!std::same_as<T, bool>)
    void set(const std::string& key, T v) { map_[key] = {static_cast<int64_t>(v)}; }

    // unordered_map<string, T> — stored as a nested MsgPackMap
    template<typename T> void set(const std::string& key, const std::unordered_map<std::string, T>& m) {
        MsgPackMap packed;
        for (const auto& [k, v] : m) packed[k] = to_msgpack_value(v);
        map_[key] = {std::move(packed)};
    }

    // Returns the value cast to T, or default_val if key missing or wrong type.
    template<typename T> T get(const std::string& key, T default_val = T{}) const {
        auto it = map_.find(key);
        if (it == map_.end()) return default_val;
        return extract<T>(it->second, default_val);
    }

    bool has(const std::string& key) const { return map_.contains(key); }
    void erase(const std::string& key)     { map_.erase(key); }
    void clear()                           { map_.clear(); }

    const std::filesystem::path& path() const { return path_; }

private:
    std::filesystem::path    path_;
    MsgPackMap   map_;

    template<typename T>
    static MsgPackValue to_msgpack_value(const T& v) {
        if constexpr (std::same_as<T, bool>)                 return {v};
        else if constexpr (std::same_as<T, double>)          return {v};
        else if constexpr (std::same_as<T, float>)           return {static_cast<double>(v)};
        else if constexpr (std::same_as<T, std::string>)     return {v};
        else if constexpr (std::same_as<T, uint64_t>)        return {v};
        else if constexpr (std::integral<T>)                 return {static_cast<int64_t>(v)};
        else static_assert(false, "Unsupported type for KeyStore map value");
    }

    template<typename T>
    static T extract(const MsgPackValue& v, T fallback) {
        return std::visit([&](auto&& arg) -> T {
            using V = std::decay_t<decltype(arg)>;
            if constexpr (std::same_as<T, bool>) {
                if constexpr (std::same_as<V, bool>) return arg;
            } else if constexpr (std::same_as<T, double> || std::same_as<T, float>) {
                if constexpr (std::same_as<V, double>) return static_cast<T>(arg);
                if constexpr (std::integral<V>)        return static_cast<T>(arg);
            } else if constexpr (std::integral<T>) {
                if constexpr (std::same_as<V, int64_t>)  return static_cast<T>(arg);
                if constexpr (std::same_as<V, uint64_t>) return static_cast<T>(arg);
            } else if constexpr (std::same_as<T, std::string>) {
                if constexpr (std::same_as<V, std::string>) return arg;
            } else if constexpr (std::same_as<T, std::vector<uint8_t>>) {
                if constexpr (std::same_as<V, std::vector<uint8_t>>) return arg;
            } else if constexpr (std::same_as<T, MsgPackMap>) {
                if constexpr (std::same_as<V, MsgPackMap>) return arg;
            } else if constexpr (std::same_as<T, MsgPackArray>) {
                if constexpr (std::same_as<V, MsgPackArray>) return arg;
            }
            return fallback;
        }, v.data);
    }
};

} // namespace Fond
