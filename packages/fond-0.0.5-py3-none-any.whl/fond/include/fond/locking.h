#ifndef FOND_LOCKING_H
#define FOND_LOCKING_H

static inline void NOOP(void* ptr) { (void)ptr; }

#ifdef _WIN32
    #include <windows.h>
    typedef struct {
        CRITICAL_SECTION lock;
        DWORD owner;
        unsigned long count;
        void (*acquire_lock)(void* ptr);
        void (*release_lock)(void* ptr);
    } RLock;
    #define FC_NOT_OWNED ((DWORD)-1)
#else
    #include <pthread.h>
    typedef struct {
        pthread_mutex_t lock;
        pthread_t owner;
        unsigned int count;
        void (*acquire_lock)(void* ptr);
        void (*release_lock)(void* ptr);
    } RLock;
    #define FC_NOT_OWNED ((pthread_t)0)
    
#endif

static inline void Acquire_RLock(void* ptr);
static inline void Release_RLock(void* ptr);

static inline void RLock_New(RLock* r_lock, int enabled) {
#ifdef _WIN32
    InitializeCriticalSection(&r_lock->lock);
#else
    pthread_mutex_init(&r_lock->lock, NULL);
#endif
    r_lock->owner = FC_NOT_OWNED;
    r_lock->count = 0;
    r_lock->acquire_lock = &NOOP;
    r_lock->release_lock = &NOOP;
    if (enabled) {
        r_lock->acquire_lock = &Acquire_RLock;
        r_lock->release_lock = &Release_RLock;
    }
}

static inline void RLock_Free(RLock* r_lock) {
#ifdef _WIN32
    DeleteCriticalSection(&r_lock->lock);
#else
    pthread_mutex_destroy(&r_lock->lock);
#endif
}

static inline void Acquire_RLock(void* ptr) {
    RLock* l = (RLock*)ptr;
#ifdef _WIN32
    DWORD me = GetCurrentThreadId();
#else
    pthread_t me = pthread_self();
#endif
    
    if (l->owner == me) {
        l->count += 1;
        return;
    }
    
#ifdef _WIN32
    EnterCriticalSection(&l->lock);
#else
    pthread_mutex_lock(&l->lock);
#endif
    l->owner = me;
    l->count = 1;
}

static inline void Release_RLock(void* ptr) {
    RLock* l = (RLock*)ptr;
    l->count -= 1;
    if (l->count == 0) {
        l->owner = FC_NOT_OWNED;
#ifdef _WIN32
        LeaveCriticalSection(&l->lock);
#else
        pthread_mutex_unlock(&l->lock);
#endif
    }
}
#endif // FOND_LOCKING_H
