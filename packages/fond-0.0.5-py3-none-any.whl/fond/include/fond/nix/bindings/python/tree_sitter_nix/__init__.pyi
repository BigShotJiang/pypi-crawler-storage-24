from types import CapsuleType

HIGHLIGHTS_QUERY: str | None
"""The syntax highlighting query for this grammar."""

INJECTIONS_QUERY: str | None
"""The language injection query for this grammar."""

LOCALS_QUERY: str | None
"""The local variable query for this grammar."""

TAGS_QUERY: str | None
"""The symbol tagging query for this grammar."""

def language() -> CapsuleType:
    """Returns a pointer to the compiled tree-sitter grammar for this language."""  # noqa: PYI021
