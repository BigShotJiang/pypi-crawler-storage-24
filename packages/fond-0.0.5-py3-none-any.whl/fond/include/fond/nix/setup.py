"""Setup script for the tree-sitter-nix Python bindings."""

from os import path
from sysconfig import get_config_var

from setuptools import Extension, find_packages, setup
from setuptools.command.build import build
from setuptools.command.build_ext import build_ext
from setuptools.command.egg_info import egg_info
from wheel.bdist_wheel import bdist_wheel


class Build(build):
    """Custom build command to copy the queries directory to the build directory."""

    def run(self):
        """Copy the queries directory to the build directory if it exists."""
        if path.isdir("queries"):
            dest = path.join(self.build_lib, "tree_sitter_nix", "queries")
            self.copy_tree("queries", dest)
        super().run()


class BuildExt(build_ext):
    """Custom build_ext command to add extra compile arguments and include the scanner source file if it exists."""

    def build_extension(self, ext: Extension):
        """Add some extra compile arguments to the extension."""
        if self.compiler.compiler_type != "msvc":
            ext.extra_compile_args = ["-std=c11", "-fvisibility=hidden"]
        else:
            ext.extra_compile_args = ["/std:c11", "/utf-8"]
        if path.exists("src/scanner.c"):
            ext.sources.append("src/scanner.c")
        if ext.py_limited_api:
            ext.define_macros.append(("Py_LIMITED_API", "0x030A0000"))
        super().build_extension(ext)


class BdistWheel(bdist_wheel):
    """Custom bdist_wheel command to set the appropriate wheel tags for Python 3.10+ when using the limited API."""

    def get_tag(self):
        """Set the wheel tags to cp310-abi3 for Python 3.10+ when using the limited API."""
        python, abi, platform = super().get_tag()
        if python.startswith("cp") and not get_config_var("Py_GIL_DISABLED"):
            python, abi = "cp310", "abi3"
        return python, abi, platform


class EggInfo(egg_info):
    """Custom egg_info command to include the .scm query files in the package data."""

    def find_sources(self):
        """Include the .scm query files in the package data."""
        super().find_sources()
        self.filelist.recursive_include("queries", "*.scm")
        self.filelist.include("src/tree_sitter/*.h")


setup(
    packages=find_packages("bindings/python"),
    package_dir={"": "bindings/python"},
    package_data={
        "tree_sitter_nix": ["*.pyi", "py.typed"],
        "tree_sitter_nix.queries": ["*.scm"],
    },
    ext_package="tree_sitter_nix",
    ext_modules=[
        Extension(
            name="_binding",
            sources=[
                "bindings/python/tree_sitter_nix/binding.c",
                "src/parser.c",
            ],
            define_macros=[
                ("PY_SSIZE_T_CLEAN", None),
                ("TREE_SITTER_HIDE_SYMBOLS", None),
            ],
            include_dirs=["src"],
            py_limited_api=not get_config_var("Py_GIL_DISABLED"),
        )
    ],
    cmdclass={
        "build": Build,
        "build_ext": BuildExt,
        "bdist_wheel": BdistWheel,
        "egg_info": EggInfo,
    },
    zip_safe=False,
)
