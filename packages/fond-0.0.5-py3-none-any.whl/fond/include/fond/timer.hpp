#pragma once

#include <chrono>
#include <cstdio>
#include <format>
#include <functional>
#include <string>

#ifdef LOGGER_ENABLED
#include "logger/logger.hpp"
#endif

namespace Fond::Timer {

using Clock = std::chrono::high_resolution_clock;
using TimePoint = Clock::time_point;

static inline std::string format_duration(double ns) {
    if (ns < 1'000.0) return std::format("{:.2f} ns", ns);
    if (ns < 1'000'000.0) return std::format("{:.2f} µs", ns / 1'000.0);
    if (ns < 1'000'000'000.0) return std::format("{:.2f} ms", ns / 1'000'000.0);
    return std::format("{:.2f} s", ns / 1'000'000'000.0);
}

inline void default_report(const char* name, double ns) {
#ifdef LOGGER_ENABLED
    LogCub::g_logger.Info("Timer [{}] took {}", name, format_duration(ns));
#else
    printf("Timer [%s] took %s\n", name, format_duration(ns).c_str());
#endif
}

using ReportFn = std::function<void(const char*, double)>;

struct ScopedTimer {
    const char* name;
    TimePoint start;
    ReportFn report;

    ScopedTimer(const char* n, ReportFn fn = default_report) : name(n), start(Clock::now()), report(std::move(fn)) {}

    ~ScopedTimer() {
        double ns = static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
        report(name, ns);
    }

    // Lap: report elapsed so far without stopping
    void lap(const char* label = nullptr) const {
        double ns = static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
        report(label ? label : name, ns);
    }

    double elapsed_ns() const {
        return static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
    }

    double elapsed_ms() const { return elapsed_ns() / 1'000'000.0; }
};

// Simple one-shot: returns elapsed nanoseconds
inline double time_it(std::invocable<> auto&& fn) {
    auto start = Clock::now();
    fn();
    return static_cast<double>(std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count());
}

} // namespace Fond::Timer

// Macro needs two levels of indirection to expand __LINE__ properly
#define FOND_TIMER_CONCAT_(a, b) a##b
#define FOND_TIMER_CONCAT(a, b) FOND_TIMER_CONCAT_(a, b)
#define PROFILE_SCOPE(name) Fond::Timer::ScopedTimer FOND_TIMER_CONCAT(timer_, __LINE__)(name)
