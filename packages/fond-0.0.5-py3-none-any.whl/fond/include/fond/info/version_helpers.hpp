#pragma once

#include "project_info.hpp"

#include <pybind11/pybind11.h>
#include <iostream>

namespace py = pybind11;

namespace VersionHelpers {

using ProjectInfo::Version;
using ProjectInfo::VersionParts;
using ProjectInfo::ExitCode;

// Helper to get version from generated _version.hpp constants
// Expects PROJECT_VERSION_MAJOR, PROJECT_VERSION_MINOR, PROJECT_VERSION_PATCH to be defined
#ifndef PROJECT_VERSION_MAJOR
#define PROJECT_VERSION_MAJOR 0
#endif
#ifndef PROJECT_VERSION_MINOR
#define PROJECT_VERSION_MINOR 0
#endif
#ifndef PROJECT_VERSION_PATCH
#define PROJECT_VERSION_PATCH 0
#endif

inline Version current_version() {
    return Version(PROJECT_VERSION_MAJOR, PROJECT_VERSION_MINOR, PROJECT_VERSION_PATCH);
}

inline std::string current_version_string() {
    return current_version().to_string();
}

inline bool is_default_version() {
    return PROJECT_VERSION_MAJOR == 0 && PROJECT_VERSION_MINOR == 0 && PROJECT_VERSION_PATCH == 0;
}

// Bump current version, print result, return exit code
// Python wrapper becomes: def bump(part): return cpp_bump(part)
inline int bump_version(const std::string& part) {
    if (is_default_version()) {
        std::cerr << "Current version is 0.0.0, cannot bump version.\n";
        return static_cast<int>(ExitCode::Failure);
    }
    try {
        std::cout << current_version().bump(part).to_string() << "\n";
        return static_cast<int>(ExitCode::Success);
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return static_cast<int>(ExitCode::Failure);
    }
}

// Full version string with package name: "my-project v1.2.3"
inline std::string full_version_string() {
    return std::string(PROJECT_PACKAGE_NAME) + " v" + current_version_string();
}

template <typename Module>
inline void bind_version_helpers(Module& m) {
    m.def("current_version", &current_version, "Get current version as Version object");
    m.def("current_version_string", &current_version_string, "Get current version as string");
    m.def("bump_version", &bump_version, py::arg("part"), "Bump version (major/minor/patch), print result, return exit code");
    m.def("full_version_string", &full_version_string, "Get full version string with package name");
    m.def("is_default_version", &is_default_version, "Check if version is 0.0.0");

    // Convenience attributes
    m.attr("VERSION") = current_version_string();
    m.attr("VERSION_TUPLE") = py::make_tuple(PROJECT_VERSION_MAJOR, PROJECT_VERSION_MINOR, PROJECT_VERSION_PATCH);
}

}  // namespace VersionHelpers
