#pragma once

#include <pybind11/pybind11.h>
#include <stdexcept>

namespace py = pybind11;

// Expects these to be defined via compiler flags (-D):
//   PROJECT_PACKAGE_NAME   e.g. "ecs_cub"
//   PROJECT_NAME           e.g. "ecs_cub"
//   PROJECT_NAME_UPPER     e.g. "ECS_CUB"
//   PROJECT_ENV_VARIABLE   e.g. "ECS_CUB_ENV"
//
// Example in bear_build.toml:
//   extra_compile_args = [
//       "-DPROJECT_PACKAGE_NAME=\"my_project\"",
//       "-DPROJECT_NAME=\"my_project\"",
//       "-DPROJECT_NAME_UPPER=\"MY_PROJECT\"",
//       "-DPROJECT_ENV_VARIABLE=\"MY_PROJECT_ENV\"",
//   ]

#ifndef PROJECT_PACKAGE_NAME
#define PROJECT_PACKAGE_NAME ""
#endif
#ifndef PROJECT_NAME
#define PROJECT_NAME ""
#define PROJECT_VERSION_IMPORT_PATH PROJECT_NAME "._internal._version"
#endif
#ifndef PROJECT_NAME_UPPER
#define PROJECT_NAME_UPPER ""
#endif
#ifndef PROJECT_ENV_VARIABLE
#define PROJECT_ENV_VARIABLE ""
#endif

#define NULL_VERSION "0.0.0"
constexpr auto NULL_VERSION_TUPLE = std::make_tuple(0, 0, 0);
constexpr int ALL_VERSION_PARTS = 3;

namespace ProjectInfo {

enum class ExitCode : int {
    Success = 0,
    Failure = 1,
    MisuseOfShellCommand = 2,
    CommandCannotExecute = 126,
    CommandNotFound = 127,
    InvalidArgumentToExit = 128,
    ScriptTerminatedByControlC = 130,
    ProcessKilledBySigkill = 137,
    SegmentationFault = 139,
    ProcessTerminatedBySigterm = 143,
    ExitStatusOutOfRange = 255
};

enum class VersionParts : int {
    Major = 0,
    Minor = 1,
    Patch = 2
};

struct Version {
    int major = 0;
    int minor = 0;
    int patch = 0;

    Version() = default;
    Version(int maj, int min, int pat) : major(maj), minor(min), patch(pat) {}

    Version bump(VersionParts part) const {
        switch (part) {
            case VersionParts::Major:
                return Version(major + 1, 0, 0);
            case VersionParts::Minor:
                return Version(major, minor + 1, 0);
            case VersionParts::Patch:
                return Version(major, minor, patch + 1);
            default:
                throw std::invalid_argument("Invalid version part");
        }
    }

    static Version as_default() { return Version(0, 0, 0); }

    Version bump(const std::string& part_name) const {
        if (part_name == "major") return bump(VersionParts::Major);
        if (part_name == "minor") return bump(VersionParts::Minor);
        if (part_name == "patch") return bump(VersionParts::Patch);
        throw std::invalid_argument("Invalid bump type: " + part_name);
    }

    static Version from_string(const std::string& version_str) {
        Version v;
        std::istringstream ss(version_str);
        char dot;
        ss >> v.major;
        if (ss.peek() == '.') { ss >> dot >> v.minor; }
        if (ss.peek() == '.') { ss >> dot >> v.patch; }
        return v;
    }

    std::string to_string() const {
        return std::to_string(major) + "." + std::to_string(minor) + "." + std::to_string(patch);
    }

    bool operator==(const Version& other) const {
        return major == other.major && minor == other.minor && patch == other.patch;
    }

    bool operator<(const Version& other) const {
        if (major != other.major) return major < other.major;
        if (minor != other.minor) return minor < other.minor;
        return patch < other.patch;
    }
};

struct Variable {
    std::string name;
    std::string value;
};

struct Package {
    std::string name;
    std::string version;
    Version version_tuple;
    std::string description;

    static Package new_package(const std::string& name) {
        auto metadata = py::module_::import("importlib.metadata");
        std::string ver = [&]() -> std::string {
            try {
                return metadata.attr("version")(name).cast<std::string>();
            } catch (const py::error_already_set&) {
                return NULL_VERSION;
            }
        }();
        std::string desc = [&]() -> std::string {
            try {
                auto distrib = metadata.attr("distribution")(name);
                auto summary = distrib.attr("metadata").attr("get")("summary", py::none());
                if (summary.is_none()) return "No description available.";
                return summary.cast<std::string>();
            } catch (const py::error_already_set&) {
                return "No description available.";
            }
        }();
        return Package{
            .name = name,
            .version = ver,
            .version_tuple = Version::from_string(ver),
            .description = desc,
        };
    }

    static Package package_info(const std::string& name) { auto version = py::module_::import(PROJECT_VERSION_IMPORT_PATH); return new_package(name); }
};

struct Environment {
    Variable interpreter_info;
    std::string interpreter_path;
    std::string platform;
    std::vector<Package> packages;
    std::vector<Variable> variables;
};


// Usage:
//   PYBIND11_MODULE(my_module, m) {
//       ProjectInfo::bind_project_info(m);
//   }
template <typename Module>
inline void bind_project_info(Module& m) {
    py::enum_<ExitCode>(m, "ExitCode")
        .value("SUCCESS", ExitCode::Success)
        .value("FAILURE", ExitCode::Failure)
        .value("MISUSE_OF_SHELL_COMMAND", ExitCode::MisuseOfShellCommand)
        .value("COMMAND_CANNOT_EXECUTE", ExitCode::CommandCannotExecute)
        .value("COMMAND_NOT_FOUND", ExitCode::CommandNotFound)
        .value("INVALID_ARGUMENT_TO_EXIT", ExitCode::InvalidArgumentToExit)
        .value("SCRIPT_TERMINATED_BY_CONTROL_C", ExitCode::ScriptTerminatedByControlC)
        .value("PROCESS_KILLED_BY_SIGKILL", ExitCode::ProcessKilledBySigkill)
        .value("SEGMENTATION_FAULT", ExitCode::SegmentationFault)
        .value("PROCESS_TERMINATED_BY_SIGTERM", ExitCode::ProcessTerminatedBySigterm)
        .value("EXIT_STATUS_OUT_OF_RANGE", ExitCode::ExitStatusOutOfRange);

    py::enum_<VersionParts>(m, "VersionParts")
        .value("MAJOR", VersionParts::Major)
        .value("MINOR", VersionParts::Minor)
        .value("PATCH", VersionParts::Patch);

    py::class_<Version>(m, "Version")
        .def(py::init<>())
        .def(py::init<int, int, int>(), py::arg("major"), py::arg("minor") = 0, py::arg("patch") = 0)
        .def_readwrite("major", &Version::major)
        .def_readwrite("minor", &Version::minor)
        .def_readwrite("patch", &Version::patch)
        .def("bump", py::overload_cast<VersionParts>(&Version::bump, py::const_), py::arg("part"))
        .def("bump", py::overload_cast<const std::string&>(&Version::bump, py::const_), py::arg("part_name"))
        .def_static("as_default", &Version::as_default)
        .def_static("from_string", &Version::from_string, py::arg("version_str"))
        .def("__str__", &Version::to_string)
        .def("__repr__", [](const Version& v) {
            return "Version(" + std::to_string(v.major) + ", " + std::to_string(v.minor) + ", " + std::to_string(v.patch) + ")";
        })
        .def("__eq__", &Version::operator==)
        .def("__lt__", &Version::operator<);

    py::class_<Variable>(m, "Variable")
        .def(py::init<>())
        .def_readwrite("name", &Variable::name)
        .def_readwrite("value", &Variable::value);

    py::class_<Package>(m, "Package")
        .def(py::init<>())
        .def_readwrite("name", &Package::name)
        .def_readwrite("version", &Package::version)
        .def_readwrite("version_tuple", &Package::version_tuple)
        .def_readwrite("description", &Package::description);
    
    py::class_<Environment>(m, "Environment")
        .def(py::init<>())
        .def_readwrite("interpreter_info", &Environment::interpreter_info)
        .def_readwrite("interpreter_path", &Environment::interpreter_path)
        .def_readwrite("platform", &Environment::platform)
        .def_readwrite("packages", &Environment::packages)
        .def_readwrite("variables", &Environment::variables);

    m.attr("NULL_VERSION") = NULL_VERSION;
    m.attr("NULL_VERSION_TUPLE") = 
    m.attr("ALL_VERSION_PARTS") = 3;
    // Expose project constants (from -D compiler flags)
    m.attr("PACKAGE_NAME") = PROJECT_PACKAGE_NAME;
    m.attr("PROJECT_NAME") = PROJECT_NAME;
    m.attr("PROJECT_NAME_UPPER") = PROJECT_NAME_UPPER;
    m.attr("ENV_VARIABLE") = PROJECT_ENV_VARIABLE;
    m.attr("VALID_BUMP_TYPES") = py::make_tuple("major", "minor", "patch");

    
}

}  // namespace ProjectInfo
