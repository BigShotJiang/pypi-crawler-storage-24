#pragma once

#include <cstring>
#include <stdexcept>
#include <string>
#include <cstdint>
#include <vector>

namespace Fond {

template <typename T> struct ByteBuffer {
  std::vector<T> buf_;

  size_t pos_;   // Reading Cursor

  ByteBuffer() : pos_(0) {} // Writing
  ByteBuffer(const T* buf, size_t buf_len) : buf_(buf, buf + buf_len), pos_(0) {} // Reading

  const T *data() const { return buf_.data(); }
  size_t size() const { return buf_.size(); }
  void reserve(size_t size) { buf_.reserve(size); }
  void clear() { buf_.clear(); }

  void write_byte(T byte) { buf_.push_back(byte); }
  void write_bytes(const T *data, size_t len) { buf_.insert(buf_.end(), data, data + len); }

  void write_uint16(uint16_t value) {
    T bytes[2] = {static_cast<T>(value >> 8), static_cast<T>(value & 0xFF)};
    write_bytes(bytes, 2);
  }

  void write_uint32(uint32_t value) {
    T bytes[4] = {static_cast<T>((value >> 24) & 0xFF),
                  static_cast<T>((value >> 16) & 0xFF),
                  static_cast<T>((value >> 8) & 0xFF),
                  static_cast<T>(value & 0xFF)};
    write_bytes(bytes, 4);
  }

  void write_uint64(uint64_t value) {
    T bytes[8] = {static_cast<T>((value >> 56) & 0xFF),
                  static_cast<T>((value >> 48) & 0xFF),
                  static_cast<T>((value >> 40) & 0xFF),
                  static_cast<T>((value >> 32) & 0xFF),
                  static_cast<T>((value >> 24) & 0xFF),
                  static_cast<T>((value >> 16) & 0xFF),
                  static_cast<T>((value >> 8) & 0xFF),
                  static_cast<T>(value & 0xFF)};
    write_bytes(bytes, 8);
  }

  void write_float64(double value) {
    uint64_t bits;
    std::memcpy(&bits, &value, sizeof(double));
    write_uint64(bits);
  }

  // Reading

  bool within_bounds(size_t n) const { return pos_ + n <= size(); }

  void tick(size_t n) { pos_ += n; } // We don't do a bounds check here
  T eat() { // returns byte at current position and advances cursor 💙
    if (!within_bounds(1)) throw std::runtime_error("Buffer overflow reading byte");
    return buf_[pos_++];
  }
  void reset_pos() { pos_ = 0; }

  inline uint16_t read_uint16() {
    if (!within_bounds(2)) throw std::runtime_error("Buffer overflow reading uint16");
    const T* ptr = data();
    uint16_t result = (static_cast<uint16_t>(ptr[pos_]) << 8) | static_cast<uint16_t>(ptr[pos_ + 1]);
    tick(2);
    return result;
  }

  inline uint32_t read_uint32() {
    if (!within_bounds(4)) throw std::runtime_error("Buffer overflow reading uint32");
    const T* ptr = data();
    uint32_t result = (static_cast<uint32_t>(ptr[pos_]) << 24) |
                      (static_cast<uint32_t>(ptr[pos_ + 1]) << 16) |
                      (static_cast<uint32_t>(ptr[pos_ + 2]) << 8) |
                      static_cast<uint32_t>(ptr[pos_ + 3]);
    tick(4);
    return result;
  }

  inline uint64_t read_uint64() {
    if (!within_bounds(8)) throw std::runtime_error("Buffer overflow reading uint64");
    const T* ptr = data();
    uint64_t result = (static_cast<uint64_t>(ptr[pos_]) << 56) |
                      (static_cast<uint64_t>(ptr[pos_ + 1]) << 48) |
                      (static_cast<uint64_t>(ptr[pos_ + 2]) << 40) |
                      (static_cast<uint64_t>(ptr[pos_ + 3]) << 32) |
                      (static_cast<uint64_t>(ptr[pos_ + 4]) << 24) |
                      (static_cast<uint64_t>(ptr[pos_ + 5]) << 16) |
                      (static_cast<uint64_t>(ptr[pos_ + 6]) << 8) |
                      static_cast<uint64_t>(ptr[pos_ + 7]);
    tick(8);
    return result;
  }

  inline double read_float64() {
    uint64_t bits = read_uint64();
    double result;
    std::memcpy(&result, &bits, sizeof(double));
    return result;
  }

  inline std::string read_string(size_t length) {
    if (!within_bounds(length)) throw std::runtime_error("Buffer overflow reading string");
    const T* ptr = data();
    std::string result(reinterpret_cast<const char *>(&ptr[pos_]), length);
    tick(length);
    return result;
  }

  inline std::vector<T> read_bytes(size_t length) {
    if (!within_bounds(length)) throw std::runtime_error("Buffer overflow reading bytes");
    const T* ptr = data();
    std::vector<T> result(&ptr[pos_], &ptr[pos_ + length]);
    tick(length);
    return result;
  }
};

using uint8Buffer = ByteBuffer<uint8_t>;

} // namespace Fond
