#pragma once

#include "../info/project_info.hpp"
#include "../info/version_helpers.hpp"

#include <cstdio>
#include <cstring>
#include <string>

#ifdef _WIN32
#include <process.h>
#else
#include <unistd.h>
#endif

namespace Fond::CLI {

using namespace ProjectInfo;
using namespace VersionHelpers;

// Hand off to Python for commands C++ can't handle
[[noreturn]] static inline void exec_python(const char* module, int argc, char* argv[]) {
    // Build: python -m <module> <remaining args>
    std::vector<const char*> args;
    args.push_back("python");
    args.push_back("-m");

    std::string mod_path = std::string(PROJECT_NAME) + "._internal.cli";
    if (module) mod_path = module;
    args.push_back(mod_path.c_str());

    // Forward remaining args (skip program name and command)
    for (int i = 2; i < argc; ++i) args.push_back(argv[i]);
    args.push_back(nullptr);

#ifdef _WIN32
    _execvp("python", const_cast<char* const*>(args.data()));
#else
    execvp("python", const_cast<char* const*>(args.data()));
#endif
    // execvp only returns on error
    perror("execvp");
    _exit(1);
}

static inline void print_usage(const char* prog) {
    printf("Usage: %s <command> [options]\n\n", prog);
    printf("Commands:\n");
    printf("  version [--name]           Print version\n");
    printf("  bump <major|minor|patch>   Bump version and print\n");
    printf("\nOther commands are handled by Python.\n");
}

// Returns exit code, or -1 if the command should be forwarded to Python
static inline int handle_command(int argc, char* argv[]) {
    if (argc < 2) {
        print_usage(argv[0]);
        return static_cast<int>(ExitCode::MisuseOfShellCommand);
    }

    const char* cmd = argv[1];

    if (strcmp(cmd, "--help") == 0 || strcmp(cmd, "-h") == 0) {
        print_usage(argv[0]);
        return static_cast<int>(ExitCode::Success);
    }

    if (strcmp(cmd, "version") == 0) {
        bool name_flag = (argc > 2 && (strcmp(argv[2], "--name") == 0 || strcmp(argv[2], "-n") == 0));
        if (name_flag) {
            printf("%s\n", full_version_string().c_str());
        } else {
            printf("%s\n", current_version_string().c_str());
        }
        return static_cast<int>(ExitCode::Success);
    }

    if (strcmp(cmd, "bump") == 0) {
        if (argc < 3) {
            fprintf(stderr, "Error: bump requires a part (major, minor, patch)\n");
            return static_cast<int>(ExitCode::MisuseOfShellCommand);
        }
        return bump_version(argv[2]);
    }

    // Unknown command → forward to Python
    return -1;
}

// Main entry point — call this from your CLI's main()
//
// Usage:
//   int main(int argc, char* argv[]) {
//       return Fond::CLI::run(argc, argv);
//   }
static inline int run(int argc, char* argv[], const char* python_module = nullptr) {
    int result = handle_command(argc, argv);
    if (result >= 0) return result;

    // C++ couldn't handle it — hand off to Python
    exec_python(python_module, argc, argv);
}

}  // namespace Fond::CLI
