#pragma once

#include <array>
#include <bitset>
#include <cmath>
#include <cstddef>
#include <functional>


namespace CollectionsCub {

/**
 * @brief Probabilistic set with zero false negatives.
 *
 * "Definitely not in set" or "probably in set."
 *
 * Template params:
 *   N — number of bits (more bits = fewer false positives)
 *   K — number of hash functions (sweet spot is roughly (N/count) * ln(2))
 *
 * Uses double hashing: h(i) = hash1 + i * hash2
 * This generates K independent hashes from just 2 hash computations!
 */
template <size_t N, size_t K = 3>
class BloomFilter {
    static_assert(N > 0, "BloomFilter needs at least 1 bit");
    static_assert(K > 0, "BloomFilter needs at least 1 hash function");

    std::bitset<N> bits_;
    size_t count_ = 0;

    // Double hashing: generate K positions from 2 base hashes
    // Kirsch-Mitzenmacker optimization — proven equivalent to K independent hashes
    template <typename T>
    std::array<size_t, K> hash_positions(const T& value) const {
        size_t h1 = std::hash<T>{}(value);
        size_t h2 = h1 >> 17 ^ (h1 * 0x9e3779b97f4a7c15ULL);

        std::array<size_t, K> positions{};
        for (size_t i = 0; i < K; ++i) { positions[i] = (h1 + i * h2) % N; }
        return positions;
    }

public:
    BloomFilter() = default;
    ~BloomFilter() = default;

    // --- Insert ---

    template <typename T>
    void insert(const T& value) {
        auto positions = hash_positions(value);
        for (size_t pos : positions) {
            bits_.set(pos);
        }
        ++count_;
    }

    // --- Query ---

    // Returns false = DEFINITELY not in set
    // Returns true  = PROBABLY in set (may be false positive)
    template <typename T>
    bool maybe_contains(const T& value) const {
        auto positions = hash_positions(value);
        for (size_t pos : positions) {
            if (!bits_.test(pos)) return false;
        }
        return true;
    }

    // Alias for readability
    template <typename T>
    bool definitely_not(const T& value) const { return !maybe_contains(value); }

    // --- Capacity ---

    size_t count() const { return count_; }
    constexpr size_t num_bits() const { return N; }
    constexpr size_t num_hashes() const { return K; }
    size_t bits_set() const { return bits_.count(); }

    // Approximate false positive rate: (1 - e^(-K*count/N))^K
    double false_positive_rate() const {
        if (count_ == 0) return 0.0;
        double exponent = -static_cast<double>(K * count_) / static_cast<double>(N);
        double base = 1.0 - std::exp(exponent);
        double result = 1.0;
        for (size_t i = 0; i < K; ++i) result *= base;
        return result;
    }

    // --- Modification ---

    void clear() {
        bits_.reset();
        count_ = 0;
    }

    // --- Set operations ---

    // Union: if it's in either filter, it's in the result
    BloomFilter operator|(const BloomFilter& other) const {
        BloomFilter result;
        result.bits_ = bits_ | other.bits_;
        result.count_ = count_ + other.count_;
        return result;
    }

    // Intersection: conservative — only bits set in BOTH
    BloomFilter operator&(const BloomFilter& other) const {
        BloomFilter result;
        result.bits_ = bits_ & other.bits_;
        result.count_ = 0;  // can't know true count after intersection
        return result;
    }

    // --- Raw access ---

    const std::bitset<N>& raw() const { return bits_; }
    double fill_ratio() const { return static_cast<double>(bits_.count()) / static_cast<double>(N); }
};

// --- Preset sizes for common use cases ---

// ~1% false positive rate at expected count
template <size_t ExpectedCount> using BloomSmall  = BloomFilter<ExpectedCount * 10, 7>;
template <size_t ExpectedCount> using BloomMedium = BloomFilter<ExpectedCount * 15, 10>;
template <size_t ExpectedCount> using BloomLarge  = BloomFilter<ExpectedCount * 20, 14>;

}  // namespace CollectionsCub
