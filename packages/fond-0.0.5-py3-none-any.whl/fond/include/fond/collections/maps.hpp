#pragma once

#include <list>
#include <stdexcept>
#include <unordered_map>
#include <utility>
#include <vector>

#include "fwd.hpp"

namespace CollectionsCub {

template <typename K, typename V, typename Policy, typename Hash, typename KeyEqual>
class Map {
public:
    using Entry = std::pair<K, V>;

private:
    // Ordered: list for order + map for O(1) key→iterator lookup
    // Unordered: just an unordered_map
    using OrderedStorage = std::list<Entry>;
    using UnorderedStorage = std::unordered_map<K, V, Hash, KeyEqual>;
    using IndexMap = std::unordered_map<K, typename std::list<Entry>::iterator, Hash, KeyEqual>;

    std::conditional_t<Policy::ordered, OrderedStorage, UnorderedStorage> data_;
    std::conditional_t<Policy::ordered, IndexMap, EmptyIndex> index_;

    // Private bulk insert — bypasses immutable check for construction
    void _bulk_insert(const K& key, V value) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it != index_.end()) {
                it->second->second = std::move(value);
                return;
            }
            data_.emplace_back(key, std::move(value));
            index_[key] = std::prev(data_.end());
        } else {
            data_.insert_or_assign(key, std::move(value));
        }
    }

public:
    Map() = default;
    ~Map() = default;

    Map(std::initializer_list<Entry> init) { for (auto& [k, v] : init) _bulk_insert(k, v); }
    template <typename Iter> Map(Iter first, Iter last) { for (auto it = first; it != last; ++it) _bulk_insert(it->first, it->second); }


    size_t size() const {
        if constexpr (Policy::ordered) {
            return data_.size();
        } else {
            return data_.size();
        }
    }

    bool empty() const { return size() == 0; }

    bool contains(const K& key) const {
        if constexpr (Policy::ordered) {
            return index_.count(key) > 0;
        } else {
            return data_.count(key) > 0;
        }
    }

    // --- Lookup ---

    V& at(const K& key) requires (!Policy::immutable) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) throw std::out_of_range("Key not found");
            return it->second->second;
        } else {
            return data_.at(key);
        }
    }

    const V& at(const K& key) const {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) throw std::out_of_range("Key not found");
            return it->second->second;
        } else {
            return data_.at(key);
        }
    }

    V& operator[](const K& key) requires (!Policy::immutable) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it != index_.end()) return it->second->second;
            data_.emplace_back(key, V{});
            auto list_it = std::prev(data_.end());
            index_[key] = list_it;
            return list_it->second;
        } else {
            return data_[key];
        }
    }

    void set(const K& key, V value) requires (!Policy::immutable) {
        _bulk_insert(key, std::move(value));
    }

    V* get(const K& key) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) return nullptr;
            return &it->second->second;
        } else {
            auto it = data_.find(key);
            if (it == data_.end()) return nullptr;
            return &it->second;
        }
    }

    const V* get(const K& key) const {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) return nullptr;
            return &it->second->second;
        } else {
            auto it = data_.find(key);
            if (it == data_.end()) return nullptr;
            return &it->second;
        }
    }

    // --- Modification (mutable only) ---

    void insert(const K& key, V value) requires (!Policy::immutable) {
        _bulk_insert(key, std::move(value));
    }

    template <typename... Args>
    V& emplace(const K& key, Args&&... args) requires (!Policy::immutable) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it != index_.end()) {
                it->second->second = V(std::forward<Args>(args)...);
                return it->second->second;
            }
            data_.emplace_back(std::piecewise_construct,
                std::forward_as_tuple(key),
                std::forward_as_tuple(std::forward<Args>(args)...));
            auto list_it = std::prev(data_.end());
            index_[key] = list_it;
            return list_it->second;
        } else {
            auto [it, _] = data_.try_emplace(key, std::forward<Args>(args)...);
            return it->second;
        }
    }

    bool remove(const K& key) requires (!Policy::immutable) {
        if constexpr (Policy::ordered) {
            auto it = index_.find(key);
            if (it == index_.end()) return false;
            data_.erase(it->second);
            index_.erase(it);
        } else {
            return data_.erase(key) > 0;
        }
        return true;
    }

    void clear() requires (!Policy::immutable) {
        data_.clear();
        if constexpr (Policy::ordered) index_.clear();
    }

    Entry& front() requires (Policy::ordered && !Policy::immutable) { return data_.front(); }
    const Entry& front() const requires (Policy::ordered) { return data_.front(); }

    Entry& back() requires (Policy::ordered && !Policy::immutable) { return data_.back(); }
    const Entry& back() const requires (Policy::ordered) { return data_.back(); }

    void pop_front() requires (Policy::ordered && !Policy::immutable) {
        if (data_.empty()) return;
        index_.erase(data_.front().first);
        data_.pop_front();
    }

    void pop_back() requires (Policy::ordered && !Policy::immutable) {
        if (data_.empty()) return;
        index_.erase(data_.back().first);
        data_.pop_back();
    }

    bool move_to_end(const K& key) requires (Policy::ordered && !Policy::immutable) {
        auto it = index_.find(key);
        if (it == index_.end()) return false;
        data_.splice(data_.end(), data_, it->second);
        return true;
    }

    bool move_to_front(const K& key) requires (Policy::ordered && !Policy::immutable) {
        auto it = index_.find(key);
        if (it == index_.end()) return false;
        data_.splice(data_.begin(), data_, it->second);
        return true;
    }


    std::vector<K> keys() const {
        std::vector<K> result;
        result.reserve(size());
        for (const auto& [k, v] : *this) result.push_back(k);
        return result;
    }

    std::vector<V> values() const {
        std::vector<V> result;
        result.reserve(size());
        for (const auto& [k, v] : *this) result.push_back(v);
        return result;
    }

    std::vector<Entry> items() const { return std::vector<Entry>(begin(), end()); }

    Map<K, V, Freeze<Policy>, Hash, KeyEqual> freeze() const requires (!Policy::immutable) { return Map<K, V, Freeze<Policy>, Hash, KeyEqual>(begin(), end()); }
    Map<K, V, Unfreeze<Policy>, Hash, KeyEqual> unfreeze() const requires (Policy::immutable) { return Map<K, V, Unfreeze<Policy>, Hash, KeyEqual>(begin(), end()); }

    bool operator==(const Map& other) const {
        if (size() != other.size()) return false;
        if constexpr (Policy::ordered) {
            auto it1 = begin();
            auto it2 = other.begin();
            while (it1 != end()) {
                if (it1->first != it2->first || it1->second != it2->second) return false;
                ++it1;
                ++it2;
            }
        } else {
            for (const auto& [k, v] : data_) {
                auto it = other.data_.find(k);
                if (it == other.data_.end() || it->second != v) return false;
            }
        }
        return true;
    }

    bool operator!=(const Map& other) const { return !(*this == other); }

    auto begin() { return data_.begin(); }
    auto end() { return data_.end(); }
    auto begin() const { return data_.begin(); }
    auto end() const { return data_.end(); }
    auto cbegin() const { return data_.cbegin(); }
    auto cend() const { return data_.cend(); }
};

}  // namespace CollectionsCub
