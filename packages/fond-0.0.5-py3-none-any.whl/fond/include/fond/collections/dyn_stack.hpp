#pragma once

#include "common.hpp"
#include <algorithm>
#include <concepts>
#include <cstddef>
#include <memory>
#include <optional>
#include <utility>

namespace CollectionsCub {

/**
 * @brief Dynamic LIFO stack. Also works well as a freelist for index/ID recycling:
 *
 *   DynStack<size_t> freelist;
 *   freelist.push(released_id);              // return ID to pool
 *   size_t id = freelist.pop_or([&] {        // reuse or generate new
 *       return next_id++;
 *   });
 */

template <typename T, size_t InitialCapacity = INITIAL_FREELIST_CAPACITY> class DynStack {
private:
  std::unique_ptr<T[]> items_;
  size_t count_;
  size_t capacity_;
  size_t max_size_; // 0 = unbounded

  void grow() {
    if (capacity_ >= MAX_STACK_SIZE) throw std::bad_alloc();
    size_t new_capacity = std::min(capacity_ * 2, MAX_STACK_SIZE);
    auto new_items = std::make_unique<T[]>(new_capacity);
    for (size_t i = 0; i < count_; ++i) { new_items[i] = std::move(items_[i]); }
    items_ = std::move(new_items);
    capacity_ = new_capacity;
  }

public:
  DynStack()
      : items_(std::make_unique<T[]>(InitialCapacity)), count_(0),
        capacity_(InitialCapacity), max_size_(0) {}

  explicit DynStack(size_t initial_capacity, size_t max_size = 0)
      : items_(std::make_unique<T[]>(initial_capacity)), count_(0),
        capacity_(initial_capacity), max_size_(max_size) {}

  ~DynStack() = default;

  DynStack(DynStack &&other) noexcept
      : items_(std::move(other.items_)), count_(other.count_),
        capacity_(other.capacity_), max_size_(other.max_size_) {
    other.count_ = 0;
    other.capacity_ = 0;
  }

  DynStack &operator=(DynStack &&other) noexcept {
    if (this != &other) {
      items_ = std::move(other.items_);
      count_ = other.count_;
      capacity_ = other.capacity_;
      max_size_ = other.max_size_;
      other.count_ = 0;
      other.capacity_ = 0;
    }
    return *this;
  }

  DynStack(const DynStack &) = delete;
  DynStack &operator=(const DynStack &) = delete;

  void push(T value) {
    if (max_size_ > 0 && count_ >= max_size_) {
      // Drop oldest (index 0) by shifting everything down
      for (size_t i = 0; i < count_ - 1; ++i)
        items_[i] = std::move(items_[i + 1]);
      --count_;
    }
    if (count_ >= capacity_) grow();
    items_[count_++] = std::move(value);
  }

  [[nodiscard]] std::optional<T> pop() {
    if (count_ == 0) return std::nullopt;
    return std::move(items_[--count_]);
  }

  [[nodiscard]] T pop_or(std::invocable<> auto &&callback) {
    if (auto value = pop()) return std::move(*value);
    return callback();
  }

  void reset() {
    count_ = 0;
    if (capacity_ != InitialCapacity) {
      items_ = std::make_unique<T[]>(InitialCapacity);
      capacity_ = InitialCapacity;
    }
  }

  [[nodiscard]] size_t size() const noexcept { return count_; }
  [[nodiscard]] size_t capacity() const noexcept { return capacity_; }
  [[nodiscard]] bool empty() const noexcept { return count_ == 0; }
  [[nodiscard]] T *data() noexcept { return items_.get(); }
  [[nodiscard]] const T *data() const noexcept { return items_.get(); }
};

} // namespace CollectionsCub
