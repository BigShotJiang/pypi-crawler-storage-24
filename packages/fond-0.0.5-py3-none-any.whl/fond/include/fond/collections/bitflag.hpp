#pragma once

#include <bitset>
#include <cstddef>

namespace CollectionsCub {

/**
 * @brief Type-safe bitflag wrapper around std::bitset.
 *
 * Uses an enum as the key type so the compiler catches invalid flag names.
 *
 * Usage:
 *   enum class Flag : size_t { Visible = 0, Active = 1, Static = 2 };
 *   BitFlag<Flag, 8> flags;
 *   flags.set(Flag::Visible);
 *   flags.test(Flag::Active);
 */
template <typename E, size_t N> class BitFlag {
    std::bitset<N> bits_;

    static constexpr size_t idx(E flag) { return static_cast<size_t>(flag); }

public:
    BitFlag() = default;
    ~BitFlag() = default;

    void set(E flag) { bits_.set(idx(flag)); }
    void unset(E flag) { bits_.reset(idx(flag)); }
    void toggle(E flag) { bits_.flip(idx(flag)); }
    bool test(E flag) const { return bits_.test(idx(flag)); }

    void clear() { bits_.reset(); }
    void set_all() { bits_.set(); }

    bool any() const { return bits_.any(); }
    bool none() const { return bits_.none(); }
    bool all() const { return bits_.all(); }
    size_t count() const { return bits_.count(); }
    constexpr size_t size() const { return N; }

    const std::bitset<N>& raw() const { return bits_; }

    BitFlag operator&(const BitFlag& other) const { BitFlag r; r.bits_ = bits_ & other.bits_; return r; }
    BitFlag operator|(const BitFlag& other) const { BitFlag r; r.bits_ = bits_ | other.bits_; return r; }
    BitFlag operator^(const BitFlag& other) const { BitFlag r; r.bits_ = bits_ ^ other.bits_; return r; }
    BitFlag operator~() const { BitFlag r; r.bits_ = ~bits_; return r; }

    bool operator==(const BitFlag& other) const { return bits_ == other.bits_; }
    bool operator!=(const BitFlag& other) const { return bits_ != other.bits_; }
};

}  // namespace CollectionsCub
