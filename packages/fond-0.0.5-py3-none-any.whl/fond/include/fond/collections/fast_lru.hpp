#pragma once

#include <cstddef>
#include <stdexcept>
#include <utility>

#include "core/open_map.hpp"

namespace CollectionsCub::core {

/**
 * @brief High-performance LRU cache built on OpenMap.
 *
 * Uses open-addressing, node pool, intrusive list — zero allocations
 * per get/put after construction. The hot-path version of lru_cache.hpp.
 *
 * When full, evicts the least recently used entry automatically.
 */
template <typename K, typename V, typename Hash = std::hash<K>, typename KeyEqual = std::equal_to<K>>
class FastLRU {
    OpenMap<K, V, Hash, KeyEqual> map_;
    size_t capacity_;

public:
    FastLRU(size_t capacity) : map_(capacity), capacity_(capacity) {
        if (capacity == 0) throw std::invalid_argument("FastLRU capacity must be > 0");
    }

    ~FastLRU() = default;

    FastLRU(const FastLRU&) = delete;
    FastLRU& operator=(const FastLRU&) = delete;
    FastLRU(FastLRU&&) = default;
    FastLRU& operator=(FastLRU&&) = default;

    size_t size() const { return map_.size(); }
    size_t capacity() const { return capacity_; }
    bool empty() const { return map_.empty(); }
    bool full() const { return map_.size() >= capacity_; }

    bool contains(const K& key) const { return map_.contains(key); }

    // Get and mark as recently used
    V* get(const K& key) {
        V* val = map_.get(key);
        if (!val) return nullptr;
        map_.touch(key);
        return val;
    }

    V get_or(const K& key, const V& default_value) {
        V* val = get(key);
        return val ? *val : default_value;
    }

    const V* peek(const K& key) const { return map_.get(key); }

    void put(const K& key, V value) {
        // Update existing — touch moves it to back
        if (map_.contains(key)) {
            map_.insert(key, std::move(value));
            map_.touch(key);
            return;
        }

        // Evict oldest if at capacity
        if (full()) map_.evict_oldest();

        map_.insert(key, std::move(value));
    }

    bool remove(const K& key) { return map_.remove(key); }
    void clear() { map_.clear(); }

    std::pair<const K&, V&> oldest() { return map_.oldest(); }
    std::pair<const K&, V&> newest() { return map_.newest(); }

    size_t bucket_count() const { return map_.bucket_count(); }
    size_t tombstone_count() const { return map_.tombstone_count(); }

    auto begin() { return map_.begin(); }
    auto end() { return map_.end(); }
    auto begin() const { return map_.begin(); }
    auto end() const { return map_.end(); }
};

}  // namespace CollectionsCub::core
