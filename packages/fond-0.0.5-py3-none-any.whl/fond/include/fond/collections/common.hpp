#pragma once

#include <cstddef>

#ifndef SET_INITIAL_FREELIST_CAPACITY
#define SET_INITIAL_FREELIST_CAPACITY 64
#endif
#ifndef SET_MAX_STACK_SIZE
#define SET_MAX_STACK_SIZE 1048576
#endif

constexpr size_t INITIAL_FREELIST_CAPACITY = SET_INITIAL_FREELIST_CAPACITY;
constexpr size_t MAX_STACK_SIZE = SET_MAX_STACK_SIZE;
constexpr size_t NOT_SET_ENTRY = ((size_t)(-1));
