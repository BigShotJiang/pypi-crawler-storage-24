#pragma once

#include <cstddef>

namespace CollectionsCub::core {

/**
 * @brief Mixin for nodes that participate in an intrusive doubly-linked list.
 *
 * Inherit from this or embed it in your node struct. The list operations
 * work directly on node pointers — no container, no allocation, no ownership.
 */
struct ListNode {
    ListNode* prev = nullptr;
    ListNode* next = nullptr;
};

/**
 * @brief Intrusive doubly-linked list operating on ListNode pointers.
 *
 * Does NOT own the nodes. The caller (node pool, arena, etc.) manages memory.
 * All operations are O(1).
 */
class IntrusiveList {
    ListNode* head_ = nullptr;
    ListNode* tail_ = nullptr;
    size_t count_ = 0;

public:
    IntrusiveList() = default;
    ~IntrusiveList() = default;

size_t size() const { return count_; }
    bool empty() const { return count_ == 0; }
    ListNode* head() const { return head_; }
    ListNode* tail() const { return tail_; }

void push_back(ListNode* node) {
        node->prev = tail_;
        node->next = nullptr;
        if (tail_) {
            tail_->next = node;
        } else {
            head_ = node;
        }
        tail_ = node;
        ++count_;
    }

    void push_front(ListNode* node) {
        node->prev = nullptr;
        node->next = head_;
        if (head_) {
            head_->prev = node;
        } else {
            tail_ = node;
        }
        head_ = node;
        ++count_;
    }

void unlink(ListNode* node) {
        if (node->prev) {
            node->prev->next = node->next;
        } else {
            head_ = node->next;
        }
        if (node->next) {
            node->next->prev = node->prev;
        } else {
            tail_ = node->prev;
        }
        node->prev = nullptr;
        node->next = nullptr;
        --count_;
    }

    ListNode* pop_front() {
        if (!head_) return nullptr;
        ListNode* node = head_;
        unlink(node);
        return node;
    }

    ListNode* pop_back() {
        if (!tail_) return nullptr;
        ListNode* node = tail_;
        unlink(node);
        return node;
    }

void move_to_back(ListNode* node) {
        if (node == tail_) return;
        unlink(node);
        push_back(node);
    }

    void move_to_front(ListNode* node) {
        if (node == head_) return;
        unlink(node);
        push_front(node);
    }

void clear() {
        head_ = nullptr;
        tail_ = nullptr;
        count_ = 0;
    }

class iterator {
        ListNode* current_;
    public:
        iterator(ListNode* node) : current_(node) {}
        ListNode* operator*() { return current_; }
        iterator& operator++() { current_ = current_->next; return *this; }
        bool operator!=(const iterator& other) const { return current_ != other.current_; }
    };

    iterator begin() { return iterator(head_); }
    iterator end() { return iterator(nullptr); }
};

/**
 * @brief Helper to cast from ListNode* back to the containing struct.
 *
 * Usage:
 *   struct MyNode : ListNode { int key; int value; };
 *   ListNode* raw = list.pop_front();
 *   MyNode* node = node_cast<MyNode>(raw);
 */
template <typename T> static inline T* node_cast(ListNode* node) { return static_cast<T*>(node); }

}  // namespace CollectionsCub::core
