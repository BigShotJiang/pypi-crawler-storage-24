#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>

namespace CollectionsCub::core {

// Fibonacci hashing constant (golden ratio * 2^64)
constexpr uint64_t GOLDEN_RATIO = 0x9e3779b97f4a7c15ULL;
constexpr size_t EMPTY_SLOT = SIZE_MAX;

constexpr size_t next_power_of_2(size_t n) {
  if (n == 0) return 1;
  --n;
  n |= n >> 1;
  n |= n >> 2;
  n |= n >> 4;
  n |= n >> 8;
  n |= n >> 16;
  n |= n >> 32;
  return n + 1;
}

constexpr bool is_power_of_2(size_t n) { return n > 0 && (n & (n - 1)) == 0; }
constexpr size_t mask_for(size_t bucket_count) { return bucket_count - 1; }

// Spread bits to reduce clustering in open-addressing tables
constexpr size_t mix_hash(size_t h) {
  h ^= h >> 33;
  h *= 0xff51afd7ed558ccdULL;
  h ^= h >> 33;
  h *= 0xc4ceb9fe1a85ec53ULL;
  h ^= h >> 33;
  return h;
}

// Combine two hashes (boost-style)
constexpr size_t hash_combine(size_t seed, size_t value) {
  seed ^= value + GOLDEN_RATIO + (seed << 6) + (seed >> 2);
  return seed;
}

// Linear probing
constexpr size_t probe_next(size_t idx, size_t mask) { return (idx + 1) & mask;}

// Compute hash for any type with std::hash
template <typename T> static inline size_t compute_hash(const T &value) { return mix_hash(std::hash<T>{}(value)); }

constexpr size_t MIN_BUCKETS = 16;
constexpr size_t LOAD_FACTOR_NUM = 7; // 70% load factor
constexpr size_t LOAD_FACTOR_DEN = 10;

constexpr bool should_grow(size_t count, size_t tombstones, size_t num_buckets) {
  return (count + tombstones) * LOAD_FACTOR_DEN > num_buckets * LOAD_FACTOR_NUM;
}

constexpr size_t buckets_for_capacity(size_t capacity) {
  size_t min = capacity * LOAD_FACTOR_DEN / LOAD_FACTOR_NUM;
  size_t result = next_power_of_2(std::max(min, MIN_BUCKETS));
  return result;
}

} // namespace CollectionsCub::core
