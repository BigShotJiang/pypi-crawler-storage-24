#ifndef SIMPLE_STACK_H
#define SIMPLE_STACK_H

#ifdef __cplusplus
#include "common.hpp"
#include <cstddef>
#include <cstdlib>
#include <functional>
namespace CollectionsCub {
#else
#include <stddef.h>
#include <stdlib.h>
#ifndef SET_INITIAL_FREELIST_CAPACITY
#define SET_INITIAL_FREELIST_CAPACITY 64
#endif
#ifndef SET_MAX_STACK_SIZE
#define SET_MAX_STACK_SIZE 1048576
#endif
#define INITIAL_FREELIST_CAPACITY SET_INITIAL_FREELIST_CAPACITY
#define MAX_STACK_SIZE SET_MAX_STACK_SIZE
#define NOT_SET_ENTRY ((size_t)(-1))
#endif

struct SimpleStack {
    size_t* items;
    size_t count;
    size_t capacity;
};

static inline bool init_simple_stack(SimpleStack* stack) {
    stack->items = (size_t*)malloc(INITIAL_FREELIST_CAPACITY * sizeof(size_t));
    if (!stack->items) return false;
    stack->count = 0;
    stack->capacity = INITIAL_FREELIST_CAPACITY;
    return true;
}

static inline bool reset_simple_stack(SimpleStack* stack) {
    stack->items = (size_t*)realloc(stack->items, INITIAL_FREELIST_CAPACITY * sizeof(size_t));
    if (!stack->items) return false;
    stack->capacity = INITIAL_FREELIST_CAPACITY;
    stack->count = 0;
    return true;
}

static inline bool stack_grow(SimpleStack* stack) {
    if (stack->capacity >= MAX_STACK_SIZE) return false;
    size_t new_capacity = std::min(stack->capacity * 2, MAX_STACK_SIZE);
    size_t* new_items = (size_t*)realloc(stack->items, new_capacity * sizeof(size_t));
    if (!new_items) return false;
    stack->items = new_items;
    stack->capacity = new_capacity;
    return true;
}

static inline bool stack_push(SimpleStack* stack, size_t value) {
    if (stack->count >= stack->capacity) if (!stack_grow(stack)) return false;
    stack->items[stack->count++] = value;
    return true;
}

static inline size_t stack_pop(SimpleStack* stack) {
    if (stack->count == 0) return NOT_SET_ENTRY;
    return stack->items[--stack->count];
}

#ifdef __cplusplus
static inline size_t pop_or_callback(SimpleStack* stack, std::function<size_t()> callback) {
    size_t value = stack_pop(stack);
    if (value == NOT_SET_ENTRY) return callback();
    return value;
}
#else
static inline size_t pop_or_callback(SimpleStack* stack, size_t (*callback)()) {
    size_t value = stack_pop(stack);
    if (value == NOT_SET_ENTRY) return callback();
    return value;
}
#endif

#ifdef __cplusplus
} // namespace CollectionsCub
#endif

#endif
