#pragma once

#include <vector>
#include <cstddef>

namespace CollectionsCub {

/**
 * @brief Generic Sparse Set data structure
 *
 * O(1) add, remove, has-check
 * Dense iteration (cache-friendly)
 * Memory scales with actual usage, not capacity
 */
template <typename T>
struct SparseSet {
    static constexpr size_t INVALID = SIZE_MAX;

    struct DenseElement {
        size_t sparse_idx;
        T value;
    };

    std::vector<size_t> sparse;       // key → dense index
    std::vector<DenseElement> dense;  // packed values

    bool contains(size_t key) const { return key < sparse.size() && sparse[key] != INVALID; }
    T& get(size_t key) { return dense[sparse[key]].value; }
    T* try_get(size_t key) { if (!contains(key)) return nullptr; return &dense[sparse[key]].value; }
    DenseElement* try_get_element(size_t key) { if (!contains(key)) return nullptr; return &dense[sparse[key]]; }

    void add(size_t key, T value) {
        if (key >= sparse.size()) sparse.resize(key + 1, INVALID);
        if (contains(key)) {
            dense[sparse[key]].value = std::move(value);
            return;
        }
        sparse[key] = dense.size();
        dense.push_back({key, std::move(value)});
    }

    void remove(size_t key) {
        if (!contains(key)) return;
        size_t dense_idx = sparse[key];
        size_t last_key = dense.back().sparse_idx;
        dense[dense_idx] = std::move(dense.back());
        sparse[last_key] = dense_idx;
        sparse[key] = INVALID;
        dense.pop_back();
    }

    void clear() { for (auto& elem : dense) sparse[elem.sparse_idx] = INVALID; dense.clear(); }
    size_t size() const { return dense.size(); }
    auto begin() { return dense.begin(); }
    auto end() { return dense.end(); }
};

}  // namespace SparseSetCub
