#pragma once

#include "policies.hpp"
#include <functional>

namespace CollectionsCub {

template <typename T, typename Policy = Default, typename Hash = std::hash<T>, typename KeyEqual = std::equal_to<T>> class Set;
template <typename T, typename Policy = Ordered> class List;
template <typename K, typename V, typename Policy = Default, typename Hash = std::hash<K>, typename KeyEqual = std::equal_to<K>> class Map;

template <typename T> using UnorderedSet = Set<T, Default>;
template <typename T> using OrderedSet = Set<T, Ordered>;
template <typename T> using FrozenUnorderedSet = Set<T, Frozen>;
template <typename T> using FrozenOrderedSet = Set<T, FrozenOrdered>;

template <typename T> using Tuple = List<T, FrozenOrdered>;

template <typename K, typename V> using UnorderedMap = Map<K, V, Default>;
template <typename K, typename V> using OrderedMap = Map<K, V, Ordered>;
template <typename K, typename V> using FrozenUnorderedMap = Map<K, V, Frozen>;
template <typename K, typename V> using FrozenOrderedMap = Map<K, V, FrozenOrdered>;

}  // namespace CollectionsCub
