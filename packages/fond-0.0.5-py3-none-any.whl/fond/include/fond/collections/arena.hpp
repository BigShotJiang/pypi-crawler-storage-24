#pragma once

#include <cstddef>
#include <memory>
#include <vector>

namespace CollectionsCub {

/**
 * @brief Bump allocator — pre-allocates memory, hands out chunks by bumping a pointer.
 *
 * No per-object deallocation. Reset or destroy frees everything at once.
 * Great for per-frame game allocations, AST nodes, parsers.
 */
class Arena {
    struct Block {
        std::unique_ptr<std::byte[]> data;
        size_t size;
    };

    std::vector<Block> blocks_;
    size_t block_size_;
    size_t offset_ = 0;
    size_t total_allocated_ = 0;

    void add_block(size_t min_size) {
        size_t size = std::max(block_size_, min_size);
        blocks_.push_back({std::make_unique<std::byte[]>(size), size});
        offset_ = 0;
    }

    std::byte* current_block() { return blocks_.back().data.get(); }
    size_t current_capacity() { return blocks_.back().size; }
    static size_t align_up(size_t offset, size_t alignment) { return (offset + alignment - 1) & ~(alignment - 1); }

public:
    Arena(size_t block_size = 4096) : block_size_(block_size) { add_block(block_size); }

    ~Arena() = default;

    // No copying — each arena owns its memory
    Arena(const Arena&) = delete;
    Arena& operator=(const Arena&) = delete;
    Arena(Arena&&) = default;
    Arena& operator=(Arena&&) = default;

    // --- Raw allocation ---

    void* alloc(size_t size, size_t alignment = alignof(std::max_align_t)) {
        offset_ = align_up(offset_, alignment);
        if (offset_ + size > current_capacity()) { add_block(size); }
        void* ptr = current_block() + offset_;
        offset_ += size;
        total_allocated_ += size;
        return ptr;
    }

    // --- Typed allocation ---

    template <typename T, typename... Args>
    T* create(Args&&... args) {
        void* mem = alloc(sizeof(T), alignof(T));
        return new (mem) T(std::forward<Args>(args)...);
    }

    // Allocate an array of T (default constructed)
    template <typename T>
    T* create_array(size_t count) {
        void* mem = alloc(sizeof(T) * count, alignof(T));
        T* arr = static_cast<T*>(mem);
        for (size_t i = 0; i < count; ++i) { new (&arr[i]) T(); }
        return arr;
    }

    // --- Reset (keep memory, reuse it) ---

    void reset() {
        // Keep only the first block, reuse it
        if (blocks_.size() > 1) {
            // Merge into one big block
            size_t total = 0;
            for (auto& b : blocks_) total += b.size;
            blocks_.clear();
            add_block(total);
        }
        offset_ = 0;
        total_allocated_ = 0;
    }

    size_t total_allocated() const { return total_allocated_; }
    size_t block_count() const { return blocks_.size(); }
    size_t block_size() const { return block_size_; }
};

/**
 * @brief std::allocator-compatible adapter for Arena.
 *
 * Plugs into std::allocate_shared, std::vector, etc. so STL containers
 * can use arena memory without API changes.
 *
 * deallocate() is a no-op — the arena frees everything on reset/destroy.
 */
template <typename T>
class ArenaAllocator {
    Arena* arena_;

public:
    using value_type = T;

    ArenaAllocator(Arena& arena) noexcept : arena_(&arena) {}

    template <typename U>
    ArenaAllocator(const ArenaAllocator<U>& other) noexcept : arena_(other.arena()) {}

    T* allocate(size_t n) { return static_cast<T*>(arena_->alloc(n * sizeof(T), alignof(T))); }
    void deallocate(T*, size_t) noexcept {}  // arena frees everything at once

    Arena* arena() const noexcept { return arena_; }

    template <typename U> bool operator==(const ArenaAllocator<U>& other) const noexcept { return arena_ == other.arena(); }
};

struct DynamicBitset {
    uint64_t* bits;
    size_t n_words;

    DynamicBitset(Arena& arena, size_t n) {
        n_words = (n + 63) / 64;
        bits = arena.create_array<uint64_t>(n_words);
        reset_all();
    }

    void set(size_t i) { bits[i / 64] |= (1ULL << (i % 64)); }
    bool test(size_t i) const { return bits[i / 64] & (1ULL << (i % 64)); }
    void reset_all() { memset(bits, 0, n_words * 8); }
};

}  // namespace CollectionsCub
