#pragma once

#include <array>
#include <memory>
#include <string>
#include <vector>

namespace CollectionsCub {

/**
 * @brief Prefix tree for fast string lookup, prefix search, and autocomplete.
 *
 * Each node represents a character. Paths from root to marked nodes spell words.
 * ASCII-based (128 slots per node).
 */
class Trie {
    struct Node {
        std::array<std::unique_ptr<Node>, 128> children{};
        bool is_end = false;
    };

    std::unique_ptr<Node> root_ = std::make_unique<Node>();
    size_t count_ = 0;

    Node* walk(const std::string& prefix) const {
        Node* current = root_.get();
        for (char c : prefix) {
            auto idx = static_cast<unsigned char>(c);
            if (!current->children[idx]) return nullptr;
            current = current->children[idx].get();
        }
        return current;
    }

    void collect(Node* node, const std::string& prefix, std::vector<std::string>& results) const {
        if (node->is_end) results.push_back(prefix);
        for (int i = 0; i < 128; ++i) {
            if (node->children[i]) collect(node->children[i].get(), prefix + static_cast<char>(i), results); 
        }
    }

public:
    Trie() = default;
    ~Trie() = default;

    size_t size() const { return count_; }
    bool empty() const { return count_ == 0; }

    void insert(const std::string& word) {
        Node* current = root_.get();
        for (char c : word) {
            auto idx = static_cast<unsigned char>(c);
            if (!current->children[idx]) {
                current->children[idx] = std::make_unique<Node>();
            }
            current = current->children[idx].get();
        }
        if (!current->is_end) {
            current->is_end = true;
            ++count_;
        }
    }

    bool contains(const std::string& word) const {
        Node* node = walk(word);
        return node && node->is_end;
    }

    bool has_prefix(const std::string& prefix) const { return walk(prefix) != nullptr; }

    // --- Prefix search / autocomplete ---

    std::vector<std::string> find_all(const std::string& prefix) const {
        std::vector<std::string> results;
        Node* node = walk(prefix);
        if (node) collect(node, prefix, results);
        return results;
    }

    std::vector<std::string> autocomplete(const std::string& prefix, size_t max_results = 10) const {
        std::vector<std::string> all = find_all(prefix);
        if (all.size() > max_results) all.resize(max_results);
        return all;
    }

    bool remove(const std::string& word) {
        if (!contains(word)) return false;
        return remove_recursive(root_.get(), word, 0);
    }

    std::vector<std::string> all_words() const {
        std::vector<std::string> results;
        collect(root_.get(), "", results);
        return results;
    }

private:
    bool remove_recursive(Node* node, const std::string& word, size_t depth) {
        if (depth == word.size()) {
            if (!node->is_end) return false;
            node->is_end = false;
            --count_;
            return is_empty_node(node);
        }

        auto idx = static_cast<unsigned char>(word[depth]);
        if (!node->children[idx]) return false;

        bool should_delete = remove_recursive(node->children[idx].get(), word, depth + 1);
        if (should_delete) {
            node->children[idx].reset();
            return !node->is_end && is_empty_node(node);
        }
        return false;
    }

    static bool is_empty_node(Node* node) {
        for (auto& child : node->children) { if (child) return false; }
        return true;
    }
};

}  // namespace CollectionsCub
