from enum import IntEnum
from typing import Literal, overload

type BumpType = Literal["major", "minor", "patch"]
VALID_BUMP_TYPES: tuple[BumpType, ...] = ("major", "minor", "patch")
PACKAGE_NAME: Literal["fond"]
PROJECT_NAME: Literal["fond"]
PROJECT_NAME_UPPER: Literal["FOND"]
ENV_VARIABLE: Literal["FOND_ENV"]
NULL_VERSION: Literal["0.0.0"]
NULL_VERSION_TUPLE: tuple[int, int, int]
ALL_VERSION_PARTS: int

class ExitCode(IntEnum):
    SUCCESS = 0
    FAILURE = 1
    MISUSE_OF_SHELL_COMMAND = 126
    COMMAND_CANNOT_EXECUTE = 126
    COMMAND_NOT_FOUND = 127
    INVALID_ARGUMENT_TO_EXIT = 128
    SCRIPT_TERMINATED_BY_CONTROL_C = 130
    PROCESS_KILLED_BY_SIGKILL = 137
    SEGMENTATION_FAULT = 139
    PROCESS_TERMINATED_BY_SIGTERM = 143
    EXIT_STATUS_OUT_OF_RANGE = 255

class VersionParts(IntEnum):
    MAJOR = 0
    MINOR = 1
    PATCH = 2

class Version:
    major: int
    minor: int
    patch: int

    def __init__(self, major: int = 0, minor: int = 0, patch: int = 0): ...
    @overload
    def bump(self, part: VersionParts) -> Version: ...
    @overload
    def bump(self, part_name: str) -> Version: ...
    @staticmethod
    def from_string(version_str: str) -> Version: ...
    @staticmethod
    def as_default() -> Version: ...
    def to_string(self) -> str: ...
    def __eq__(self, other: object) -> bool: ...
    def __lt__(self, other: object) -> bool: ...
