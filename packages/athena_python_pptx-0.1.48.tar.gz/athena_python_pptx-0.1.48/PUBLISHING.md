# Publishing the Python SDK to PyPI

This guide covers how to bump, build, and publish the `athena-python-pptx` package to PyPI.

## Quick Start

```bash
# Bump to version 0.1.26 and publish to PyPI
./scripts/publish-python-sdk.sh 0.1.26
```

## Prerequisites

The script will check for and install these if missing:

- Python 3.10+
- `build` module (`pip install build`)
- `twine` (`pip install twine`)

## PyPI Credentials

You'll need PyPI credentials configured. Options:

### Option 1: API Token (Recommended)

1. Go to https://pypi.org/manage/account/token/
2. Create a token scoped to the `athena-python-pptx` project
3. Configure in `~/.pypirc`:

```ini
[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmc...
```

### Option 2: Environment Variables

```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmc...
```

### Option 3: Interactive

The script will prompt for credentials if not configured.

## Usage

### Basic Usage

```bash
# Publish a new version
./scripts/publish-python-sdk.sh 0.1.26
```

### Options

| Flag | Description |
|------|-------------|
| `--dry-run` | Preview changes without executing |
| `--test-pypi` | Upload to TestPyPI instead of PyPI |
| `--skip-build` | Skip build step (use existing `dist/`) |
| `-h, --help` | Show help message |

### Examples

```bash
# Preview what would happen
./scripts/publish-python-sdk.sh --dry-run 0.1.26

# Test on TestPyPI first
./scripts/publish-python-sdk.sh --test-pypi 0.1.26

# Then publish to production PyPI
./scripts/publish-python-sdk.sh 0.1.26

# Re-upload without rebuilding
./scripts/publish-python-sdk.sh --skip-build 0.1.26
```

## What the Script Does

1. **Checks prerequisites** - Python, pip, build, twine
2. **Validates version** - Ensures semver format (X.Y.Z)
3. **Bumps version** in both files:
   - `pyproject.toml` (line 7)
   - `pptx/__init__.py` (line 98)
4. **Builds package** - Creates wheel and sdist in `dist/`
5. **Uploads to PyPI** - Uses twine to publish

## Version Locations

The version must be updated in two places (the script handles this):

```
python-sdk/
├── pyproject.toml      # version = "X.Y.Z"
└── pptx/
    └── __init__.py     # __version__ = "X.Y.Z"
```

## Manual Process

If you prefer to do it manually:

```bash
cd python-sdk

# 1. Update version in pyproject.toml and pptx/__init__.py

# 2. Clean and build
rm -rf dist/ build/ *.egg-info
python -m build

# 3. Upload to TestPyPI (optional)
twine upload --repository testpypi dist/*

# 4. Upload to PyPI
twine upload dist/*
```

## After Publishing

1. **Commit the version bump:**
   ```bash
   git add python-sdk/pyproject.toml python-sdk/pptx/__init__.py
   git commit -m "Bump python-sdk to 0.1.26"
   ```

2. **Create a git tag:**
   ```bash
   git tag python-sdk-v0.1.26
   ```

3. **Push:**
   ```bash
   git push && git push --tags
   ```

## Testing the Published Package

### From TestPyPI

```bash
pip install -i https://test.pypi.org/simple/ athena-python-pptx==0.1.26
```

### From PyPI

```bash
pip install athena-python-pptx==0.1.26
```

### Verify Installation

```python
import pptx
print(pptx.__version__)  # Should print: 0.1.26
```

## Troubleshooting

### "File already exists" Error

PyPI doesn't allow re-uploading the same version. Bump the version number.

### Authentication Failed

Check your `~/.pypirc` or environment variables. For tokens, username must be `__token__`.

### Build Fails

Ensure you're in the `python-sdk/` directory and have the build module installed:

```bash
pip install build
```
