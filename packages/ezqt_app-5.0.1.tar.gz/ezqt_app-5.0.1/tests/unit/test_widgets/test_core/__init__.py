# ///////////////////////////////////////////////////////////////
# TESTS.UNIT.TEST_WIDGETS.TEST_CORE - Core widget unit tests package
# Project: ezqt_app
# ///////////////////////////////////////////////////////////////

"""Core widget unit tests package for ezqt_app."""

from __future__ import annotations
