"""Data models for Cosmos DB prompt data validation and serialization."""

from typing import Any


class PromptModel:
    """
    Flexible data model representing a Cosmos DB prompt document.

    Required fields:
        id: Unique identifier for the prompt
        prompt_name: Name of the prompt
        prompt_template: The actual prompt template content

    Optional fields are stored dynamically via kwargs. Reserved attribute names
    (id, prompt_name, prompt_template, to_dict, from_cosmos_doc) cannot be
    overwritten through kwargs.

    """

    _RESERVED_ATTRS: frozenset[str] = frozenset({
        "id", "prompt_name", "prompt_template",
        "to_dict", "from_cosmos_doc", "_RESERVED_ATTRS",
    })

    def __init__(self, id: str, prompt_name: str, prompt_template: str, **kwargs: Any):
        """
        Initialize a PromptModel with required fields and arbitrary optional fields.

        Args:
            id: Unique identifier for the prompt
            prompt_name: Name of the prompt (typically same as id)
            prompt_template: The actual prompt template content
            **kwargs: Any additional optional fields to store in the model

        Raises:
            ValueError: If required fields are empty or kwargs collide with reserved attrs

        """
        if not id:
            msg = "id is required and cannot be empty"
            raise ValueError(msg)
        if not prompt_name:
            msg = "prompt_name is required and cannot be empty"
            raise ValueError(msg)
        if not prompt_template:
            msg = "prompt_template is required and cannot be empty"
            raise ValueError(msg)

        reserved_collisions = set(kwargs.keys()) & self._RESERVED_ATTRS
        if reserved_collisions:
            msg = f"kwargs cannot overwrite reserved attributes: {reserved_collisions}"
            raise ValueError(msg)

        self.id = id
        self.prompt_name = prompt_name
        self.prompt_template = prompt_template

        for key, value in kwargs.items():
            setattr(self, key, value)

    def to_dict(self) -> dict[str, Any]:
        """
        Convert the model to a dictionary suitable for Cosmos DB storage.

        Returns:
            Dictionary containing all model fields including required and optional fields

        """
        result = {
            "id": self.id,
            "prompt_name": self.prompt_name,
            "prompt_template": self.prompt_template,
        }

        for key, value in self.__dict__.items():
            if key not in result:
                result[key] = value

        return result

    @classmethod
    def from_cosmos_doc(cls, doc: dict[str, Any]) -> "PromptModel":
        """
        Create a PromptModel instance from a raw Cosmos DB document.

        Args:
            doc: Raw dictionary from Cosmos DB

        Returns:
            PromptModel instance

        Raises:
            ValueError: If required fields (id, prompt_template, prompt_name) are missing or empty

        """
        if not doc.get("id"):
            msg = "Invalid prompt document: missing required field 'id'"
            raise ValueError(msg)
        if not doc.get("prompt_template"):
            msg = "Invalid prompt document: missing required field 'prompt_template'"
            raise ValueError(msg)

        prompt_name = doc.get("prompt_name") or doc.get("name") or doc["id"]
        if not prompt_name:
            msg = "Invalid prompt document: could not resolve 'prompt_name' from document"
            raise ValueError(msg)

        kwargs = {k: v for k, v in doc.items() if k not in {"id", "prompt_name", "prompt_template"}}

        return cls(id=doc["id"], prompt_name=prompt_name, prompt_template=doc["prompt_template"], **kwargs)

    def __repr__(self) -> str:
        """String representation of the PromptModel."""
        attrs = ", ".join(f"{k}={v!r}" for k, v in self.__dict__.items())
        return f"PromptModel({attrs})"

    def __eq__(self, other: object) -> bool:
        """Check equality based on all attributes."""
        if not isinstance(other, PromptModel):
            return False
        return self.__dict__ == other.__dict__

    def __hash__(self) -> int:
        """Hash based on all attributes to stay consistent with __eq__."""
        return hash(tuple(sorted(
            (k, v) for k, v in self.__dict__.items() if isinstance(v, (str, int, float, bool, type(None)))
        )))
