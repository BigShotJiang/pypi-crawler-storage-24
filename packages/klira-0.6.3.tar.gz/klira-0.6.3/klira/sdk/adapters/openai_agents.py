# Copyright 2024 Klira AI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""OpenAI Agents SDK adapter.

Suppresses the Agents SDK's native tracing (PROD-288) and adapts
agent/tool functions for Klira span creation.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from klira.sdk.adapters.base_framework import BaseFrameworkAdapter

logger = logging.getLogger(__name__)


class OpenAIAgentsAdapter(BaseFrameworkAdapter):
    """Adapter for OpenAI Agents SDK."""

    @property
    def framework_name(self) -> str:
        return "openai_agents"

    def adapt_workflow(self, func: Callable[..., Any]) -> Callable[..., Any]:
        return func

    def adapt_agent(self, func: Callable[..., Any]) -> Callable[..., Any]:
        return func

    def adapt_tool(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """Must preserve callability (Learning #12)."""
        return func

    def adapt_task(self, func: Callable[..., Any]) -> Callable[..., Any]:
        return func

    def patch_framework(self) -> None:
        """Suppress OpenAI Agents SDK native tracing (PROD-288)."""
        try:
            from agents import set_tracing_disabled  # type: ignore[import-untyped]

            set_tracing_disabled(True)
            logger.debug("OpenAI Agents SDK tracing disabled")
        except ImportError:
            logger.debug("OpenAI Agents SDK not available, skipping suppression")

    def verify_suppression(self) -> bool:
        """Verify native tracing is disabled."""
        try:
            from agents import get_tracing_disabled  # type: ignore[import-untyped]

            return get_tracing_disabled()  # type: ignore[no-any-return]
        except ImportError:
            return True
