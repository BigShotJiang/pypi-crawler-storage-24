# Copyright 2024 Klira AI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Anthropic Claude adapter.

Patches anthropic.Anthropic.messages.create to create
klira.llm.anthropic spans with standard gen_ai attributes.
"""

from __future__ import annotations

import logging
from typing import Any

from klira.sdk.adapters.base_llm import BaseLLMAdapter
from klira.sdk.guardrails.augmentation import build_augmented_system_kwarg

logger = logging.getLogger(__name__)

PROVIDER = "anthropic"


class AnthropicAdapter(BaseLLMAdapter):
    """Adapter for Anthropic Claude API."""

    # ------------------------------------------------------------------
    # Helpers shared by sync and async patches
    # ------------------------------------------------------------------

    def _resolve_messages_cls(self) -> type | None:
        """Resolve the real Messages resource class."""
        try:
            import anthropic.resources.messages.messages as _msg_mod

            return _msg_mod.Messages
        except (ImportError, AttributeError):
            return None

    def _extract_response_attrs(self, response: Any, model: str) -> dict[str, Any]:
        """Extract common response attributes from an Anthropic response."""
        resp_model = getattr(response, "model", model)
        usage = getattr(response, "usage", None)
        input_tokens = getattr(usage, "input_tokens", None) if usage else None
        output_tokens = getattr(usage, "output_tokens", None) if usage else None
        stop_reason = getattr(response, "stop_reason", None)
        finish_reasons = [stop_reason] if stop_reason else []
        return {
            "model": resp_model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "finish_reasons": finish_reasons,
        }

    def _extract_output_text(self, response: Any) -> str:
        """Extract output text from Anthropic content blocks."""
        content_blocks = getattr(response, "content", [])
        parts: list[str] = []
        for block in content_blocks:
            text = getattr(block, "text", None)
            if text:
                parts.append(text)
        return "".join(parts)

    def _set_span_output(self, span: Any, output_text: str) -> None:
        """Set klira.output attribute on the span."""
        if output_text:
            if len(output_text) > self.OUTPUT_TRUNCATION_LIMIT:
                output_text = output_text[: self.OUTPUT_TRUNCATION_LIMIT]
            span.set_attribute("klira.output", output_text)

    # ------------------------------------------------------------------
    # patch()
    # ------------------------------------------------------------------

    def patch(self, client_class: type) -> None:
        """Patch the Anthropic Messages resource's create method.

        Patches both sync ``Messages.create`` and async
        ``AsyncMessages.create`` so that LLM spans are captured regardless
        of whether the caller uses ``invoke`` or ``ainvoke``.
        """
        adapter = self

        messages_cls = self._resolve_messages_cls() or client_class

        if self._is_already_patched(messages_cls):
            logger.debug("Anthropic Messages already patched, skipping")
            return

        original_create = messages_cls.create  # type: ignore[attr-defined]

        def patched_create(self_messages: Any, *args: Any, **kwargs: Any) -> Any:
            model = kwargs.get("model", "unknown")
            messages = kwargs.get("messages", [])

            guidelines = adapter._get_and_clear_guidelines()
            if guidelines:
                kwargs["system"] = build_augmented_system_kwarg(
                    kwargs.get("system"), guidelines
                )

            with adapter.create_llm_span(PROVIDER) as span:
                adapter.set_request_attributes(span, model, messages)
                response = original_create(self_messages, *args, **kwargs)
                attrs = adapter._extract_response_attrs(response, model)
                adapter.set_response_attributes(span, **attrs)
                adapter._set_span_output(span, adapter._extract_output_text(response))
                return response

        self._mark_function(patched_create)
        messages_cls.create = patched_create  # type: ignore[attr-defined]

        # Patch AsyncMessages.create (used by ainvoke / async callers)
        try:
            import anthropic.resources.messages.messages as _msg_mod

            async_messages_cls = _msg_mod.AsyncMessages
            if not self._is_already_patched(async_messages_cls):
                original_async_create = async_messages_cls.create  # type: ignore[attr-defined]

                async def patched_async_create(
                    self_messages: Any, *args: Any, **kwargs: Any
                ) -> Any:
                    model = kwargs.get("model", "unknown")
                    messages = kwargs.get("messages", [])

                    guidelines = adapter._get_and_clear_guidelines()
                    if guidelines:
                        kwargs["system"] = build_augmented_system_kwarg(
                            kwargs.get("system"), guidelines
                        )

                    async with adapter.create_async_llm_span(PROVIDER) as span:
                        adapter.set_request_attributes(span, model, messages)
                        response = await original_async_create(
                            self_messages, *args, **kwargs
                        )
                        attrs = adapter._extract_response_attrs(response, model)
                        adapter.set_response_attributes(span, **attrs)
                        adapter._set_span_output(
                            span, adapter._extract_output_text(response)
                        )
                        return response

                self._mark_function(patched_async_create)
                async_messages_cls.create = patched_async_create  # type: ignore[method-assign, assignment]
                self._mark_as_patched(async_messages_cls)
        except (ImportError, AttributeError):
            pass

        self._mark_as_patched(messages_cls)
        self.verify_patch(client_class)

    def verify_patch(self, client_class: type) -> bool:
        """Verify the patch took effect by inspecting the actual method."""
        messages_cls = self._resolve_messages_cls() or client_class
        method = getattr(messages_cls, "create", None)
        if method is None or not getattr(method, "_klira_patched", False):
            raise RuntimeError(
                f"Anthropic adapter: patch not applied to {messages_cls}"
            )
        return True
