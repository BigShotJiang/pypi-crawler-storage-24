# Copyright 2024 Klira AI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""SDK exceptions."""

from __future__ import annotations


class KliraError(Exception):
    """Base exception for all Klira SDK errors."""


class KliraInitError(KliraError):
    """Raised when Klira.init() fails."""


class KliraConfigError(KliraError):
    """Raised when configuration is invalid."""


class KliraPolicyViolation(KliraError):
    """Raised when a guardrails policy blocks content."""

    def __init__(
        self,
        message: str,
        policy_id: str | None = None,
        violation_response: str | None = None,
    ) -> None:
        super().__init__(message)
        self.policy_id = policy_id
        self.violation_response = violation_response


class KliraAdapterError(KliraError):
    """Raised when an adapter fails to patch or verify."""


class KliraExportError(KliraError):
    """Raised when trace export fails."""
