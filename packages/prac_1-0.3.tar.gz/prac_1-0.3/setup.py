from setuptools import setup, find_packages

setup(
    name="prac-1",
    version="0.3",
    packages=find_packages(),
    include_package_data=True,
)