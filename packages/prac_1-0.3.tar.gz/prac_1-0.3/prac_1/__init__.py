import os

data_path = os.path.join(os.path.dirname(__file__), "data.txt")

with open(data_path, "r") as f:
    text = f.read()

print(text)