"""llmpm — LLM Package Manager."""

__version__ = "3.0.8"
__author__ = "llmpm contributors"
