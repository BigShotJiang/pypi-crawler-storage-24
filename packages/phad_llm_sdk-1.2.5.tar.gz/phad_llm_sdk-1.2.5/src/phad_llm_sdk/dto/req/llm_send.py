#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2026/2/10 13:48
# @Author  : linghu
# @File    : llm_send.py
# @Software: PyCharm
"""
新GPU模型对话实体封装
"""


class LLMRequest:
    """
       用于标准化请求参数，方便创建和管理 API 请求体
       """

    def __init__(self,
                 messages,
                 model="",
                 max_tokens=None,
                 temperature=None,
                 top_p=None,
                 stream=False,
                 think=False):
        """
        初始化请求对象

        参数说明：
        - messages: list[dict]，对话消息列表，每个元素包含 role（角色）和 content（内容）
        - model: str，使用的模型名称，默认 "qwen2.5:7b"
        - max_tokens: int，生成回复的最大令牌数，默认 200
        - temperature: float，生成文本的随机性，0-1 之间，默认 0.2
        - top_p: float，采样的核概率，0-1 之间，默认 0.1
        - stream: bool，是否流式返回结果，默认 False
        - think: bool，是否返回思考过程，默认 False
        """
        self.messages = messages
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.top_p = top_p
        self.stream = stream
        self.think = think

    def to_dict(self):
        """
        将类实例转换为字典（对应完整的 JSON 请求结构），方便发送 API 请求

        返回：
        - dict: 符合格式的请求参数字典
        """
        result = {
            "stream": self.stream,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "messages": self.messages,
            "max_tokens": self.max_tokens
        }

        # 只有当 model 不为空时才添加 model 字段
        if self.model:
            result["model"] = self.model

        return result


class VLLMRequest:
    """
    多模态大模型
    用于标准化请求参数，方便创建和管理 API 请求体
    """

    def __init__(self,
                 messages,
                 model="/data/models/Qwen2.5-VL-7B-Instruct-AWQ/Qwen2.5-VL-7B-Instruct-AWQ",
                 temperature=0.7,
                 max_tokens=1024,
                 stream=False):
        """
        初始化请求对象

        参数说明：
        - messages: list[dict]，对话消息列表，每个元素包含 role（角色）和 content（内容）
        - model: str，使用的模型路径，默认 "/data/models/Qwen2.5-VL-7B-Instruct-AWQ/Qwen2.5-VL-7B-Instruct-AWQ"
        - temperature: float，生成文本的随机性，0-1 之间，默认 0.7
        - max_tokens: int，生成回复的最大令牌数，默认 1024
        - stream: bool，是否流式返回结果，默认 False
        """
        # 核心参数类型校验
        if not isinstance(messages, list):
            raise TypeError("messages 必须是列表类型")
        if not isinstance(model, str):
            raise TypeError("model 必须是字符串类型")

        # 数值型参数校验
        numeric_params = {
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        for param_name, param_value in numeric_params.items():
            if not isinstance(param_value, (int, float)):
                raise TypeError(f"{param_name} 必须是数字类型（int/float）")

        # 布尔型参数校验
        if not isinstance(stream, bool):
            raise TypeError("stream 必须是布尔类型")

        # 初始化所有属性
        self.messages = messages
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.stream = stream

    def to_dict(self):
        """
        将类实例转换为字典（对应完整的 JSON 请求结构），方便发送 API 请求

        返回：
        - dict: 符合格式的请求参数字典
        """
        return {
            "model": self.model,
            "messages": self.messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "stream": self.stream
        }


# ------------------- 使用示例 -------------------
if __name__ == "__main__":
    # 示例1: LLMRequest 使用示例
    # 1. 创建和你示例一致的消息列表
    user_messages = [
        {
            "role": "system",
            "content": "你是一个AI，喜欢帮助别人。"
        },
        {
            "role": "user",
            "content": "你参数多大"
        }
    ]

    # 2. 创建请求对象（使用默认参数，完全匹配你的示例）
    request = LLMRequest(messages=user_messages)

    # 3. 转换为字典（可直接用于 API 请求）
    request_dict = request.to_dict()
    print("LLMRequest 转换后的请求字典：")
    # 格式化输出，更易读
    import json

    print(json.dumps(request_dict, ensure_ascii=False, indent=4))

    # 示例2: VLLMRequest 使用示例（多模态大模型）
    # 1. 创建多模态消息列表
    multimodal_messages = [
        {
            "role": "user",
            "content": [
                {
                    "type": "image_url",
                    "image_url": {
                        "url": "https://picsum.photos/id/10/800/600"
                    }
                },
                {
                    "type": "text",
                    "text": "请详细描述这张图片的内容，包括场景、颜色、物体等"
                }
            ]
        }
    ]

    # 2. 创建请求对象
    vllm_request = VLLMRequest(
        messages=multimodal_messages,
        temperature=0.7,
        max_tokens=1024
    )

    # 3. 转换为字典（可直接用于 API 请求）
    vllm_request_dict = vllm_request.to_dict()
    print("\nVLLMRequest 转换后的请求字典：")
    print(json.dumps(vllm_request_dict, ensure_ascii=False, indent=4))
