#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2026/2/10 13:58
# @Author  : linghu
# @File    : HttpUtils.py
# @Software: PyCharm
import requests

from phad_llm_sdk.dto.req.llm_send import LLMRequest, VLLMRequest
from phad_llm_sdk.dto.resp.llm_resp import LLMResponse


def request_vllm(url, request: VLLMRequest):
    """
    请求VLLM多模态大模型的底层封装
    :return:
    """



def request_llm(url, request: LLMRequest):
    """
    请求文本大模型LLM接口，底层工具的封装
    
    Args:
        url: 大模型接口地址，例如 "http://192.168.130.220:8002/v1/chat/completions"
        request: LLMRequest对象，包含请求参数
    
    Returns:
        如果 stream=True，返回响应对象
        如果 stream=False，返回 {"message": {"content": "回答内容"}}
    """
    # 获取请求参数字典
    payload = request.to_dict()
    try:
        if request.stream:
            # 流式响应
            response = requests.post(url, json=payload, timeout=60, stream=True)
            response.raise_for_status()
            return response
        else:
            # 非流式响应
            response = requests.post(url, json=payload, timeout=60)
            response.raise_for_status()
            result = response.json()
            resp = LLMResponse.from_dict(result)
            return resp
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] HTTP API 调用失败: {e}")
        if request.stream:
            # 流式响应失败，返回None
            return None
        else:
            # 非流式响应失败，返回空内容
            return {
                "message": {
                    "content": ""
                }
            }

# 示例用法
if __name__ == "__main__":
    # 示例1: 非流式请求
    url = "http://192.168.130.220:8002/v1/chat/completions"
    messages = [
        {"role": "user", "content": "你好，请问你是谁？"}
    ]
    
    # 创建LLMRequest对象
    request_obj = LLMRequest(messages)

    request_obj.max_tokens=200
    request_obj.temperature=0.7
    response = request_llm(url, request_obj)
    print("resp:",response)


