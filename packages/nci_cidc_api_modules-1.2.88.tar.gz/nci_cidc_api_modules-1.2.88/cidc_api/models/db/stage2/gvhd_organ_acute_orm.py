from __future__ import annotations

from sqlalchemy import ForeignKey, ForeignKeyConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from cidc_api.code_systems.other import Organ, OrganAcuteStage
from cidc_api.models.db.stage2.base_orm import BaseORM
from cidc_api.models.db.stage2.trial_orm import TrialORM


class GVHDOrganAcuteORM(BaseORM):
    __tablename__ = "gvhd_organ_acute"
    __repr_attrs__ = ["gvhd_organ_acute_id", "organ"]
    __data_category__ = "gvhd_organ_acute"
    __table_args__ = (
        ForeignKeyConstraint(["trial_id", "version"], [TrialORM.trial_id, TrialORM.version], ondelete="CASCADE"),
    )

    gvhd_organ_acute_id: Mapped[int] = mapped_column(primary_key=True)
    gvhd_diagnosis_acute_id: Mapped[int] = mapped_column(
        ForeignKey("stage2.gvhd_diagnosis_acute.gvhd_diagnosis_acute_id", ondelete="CASCADE")
    )
    organ: Mapped[Organ]
    acute_stage: Mapped[OrganAcuteStage]

    trial: Mapped[TrialORM] = relationship(back_populates="gvhd_organ_acutes", cascade="all, delete")
    gvhd_diagnosis_acute: Mapped[GVHDDiagnosisAcuteORM] = relationship(
        back_populates="gvhd_organ_acutes", cascade="all, delete"
    )
