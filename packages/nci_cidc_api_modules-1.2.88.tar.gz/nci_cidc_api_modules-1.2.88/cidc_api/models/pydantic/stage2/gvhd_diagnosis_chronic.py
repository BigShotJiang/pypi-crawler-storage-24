from cidc_api.code_systems.other import (
    DiagnosisChronicAssessmentSystem,
    DiagnosisChronicAssessmentSystemVersion,
    DiagnosisChronicGlobalSeverity,
)
from cidc_api.models.pydantic.base import Base
from cidc_api.models.types import PreOrPostEnrollment


class GVHDDiagnosisChronic(Base):
    __data_category__ = "gvhd_diagnosis_chronic"
    __cardinality__ = "many"

    # The unique internal identifier for the GVHD chronic diagnosis
    gvhd_diagnosis_chronic_id: int | None = None

    # The unique internal identifier for the associated participant
    participant_id: int | None = None

    # The standardized clinical system used to evaluate and grade the extent and severity
    # of organ involvement in chronic GVHD, resulting in an overall disease severity score.
    chronic_assessment_system: DiagnosisChronicAssessmentSystem

    # Release version of the clinical grading system used in the evaluation of chronic GVHD.
    system_version: DiagnosisChronicAssessmentSystemVersion

    # An overall score reflecting the combined severity of chronic graft-versus-host disease
    # across all affected organs, summarizing the participant’s total disease burden.
    chronic_global_severity: DiagnosisChronicGlobalSeverity

    # Indicator for whether the chronic GVHD diagnosis was made before or after trial enrollment.
    pre_or_post_enrollment: PreOrPostEnrollment
