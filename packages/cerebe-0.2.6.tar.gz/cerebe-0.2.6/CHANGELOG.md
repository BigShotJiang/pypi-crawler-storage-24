# Changelog

## [0.2.6](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.5...cerebe-v0.2.6) (2026-03-16)


### Bug Fixes

* **cerebe:** add missing scopes (prompts/prompt/product-planning) + fix SDK memory.update 422 ([#822](https://github.com/alien8d/sage3c/issues/822)) ([ed556ed](https://github.com/alien8d/sage3c/commit/ed556edc2c1617ef8eb1d4da3d9c1659075fc501))

## [0.2.5](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.4...cerebe-v0.2.5) (2026-03-16)


### Bug Fixes

* **sdk:** storage SDK fixes — analyzeContent query params, extract type ([#818](https://github.com/alien8d/sage3c/issues/818)) ([83107c6](https://github.com/alien8d/sage3c/commit/83107c61d29fbff3bab7040e2153d201e43726f9))

## [0.2.4](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.3...cerebe-v0.2.4) (2026-03-14)


### Bug Fixes

* address PR review — Python SDK get(), TS test, tenant-scoped dedup ([dbd2f03](https://github.com/alien8d/sage3c/commit/dbd2f03d622a4253dc8f6177ea70c7afe37b534f))

## [0.2.3](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.2...cerebe-v0.2.3) (2026-03-14)


### Bug Fixes

* **cerebe:** fix remaining secret shopper issues — scores, get, enum ([ded8c90](https://github.com/alien8d/sage3c/commit/ded8c901c5c00b6e88030fb056d624eefd684010))

## [0.2.2](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.1...cerebe-v0.2.2) (2026-03-14)


### Features

* **cerebe:** Cycle 137 Phases 3-5 — test lifecycle, portal mode toggle, SDK env awareness ([#799](https://github.com/alien8d/sage3c/issues/799)) ([f945add](https://github.com/alien8d/sage3c/commit/f945add6cc79bc9eeae05d4aa8593fd17d3456d0))

## [0.2.1](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.0...cerebe-v0.2.1) (2026-03-13)


### Features

* Cerebe Cognitive Services Platform — productization foundation (Cycles 123-128) ([85e98b8](https://github.com/alien8d/sage3c/commit/85e98b8e4f1719c5a09b436016cc93e47ef7c3cb))
* Cycle 129 — Sage SDK migration + build integration ([adfa0d6](https://github.com/alien8d/sage3c/commit/adfa0d65e1a2fce492730c7a563b1ea434e54d56))
* **sdks:** add unit tests, CI/CD workflows, and release-please automation ([efb0c36](https://github.com/alien8d/sage3c/commit/efb0c363562da368c6597ca493abdaaa5eeb90fe))
* **sdks:** sync both SDKs to 100% API coverage + OpenAPI auto-gen pipeline ([614f69f](https://github.com/alien8d/sage3c/commit/614f69f7310ed2046b4ee1edbad4e917e27a9215))


### Bug Fixes

* **sdks:** mypy strict compliance, portal code examples, openapi-export target ([aab5e16](https://github.com/alien8d/sage3c/commit/aab5e1666c3e6ae8f7387e5a5604ffd7815375b8))


### Documentation

* **sdks:** add comprehensive README for TypeScript and Python SDKs ([f5aebf7](https://github.com/alien8d/sage3c/commit/f5aebf7d4f8f16bc7fe8120c2da540a1d222e821))
