import unittest
from unittest.mock import patch, MagicMock
import sys
from monxcli.commands import commands

# Test the MCP bridge logic
class TestMCPBridge(unittest.TestCase):

    def setUp(self):
        commands._reset()

    def test_mcp_bridge_import_no_fastmcp(self):
        # Force FastMCP to be missing
        with patch.dict(sys.modules, {'mcp.server': None}):
            # Re-import or reload to test the logic
            if 'monxcli.mcp_bridge' in sys.modules:
                del sys.modules['monxcli.mcp_bridge']
            
            import monxcli.mcp_bridge as mcp_bridge
            self.assertIsNone(mcp_bridge.server)
            
            # Test decorators still work for MonxCLI
            def my_tool(a: int):
                return a
            my_tool.__module__ = "testmod.testscript"
            
            decorated = mcp_bridge.monx_tool(desc="Test tool")(my_tool)
            self.assertEqual(decorated(5), 5)

    def test_mcp_bridge_import_with_fastmcp(self):
        # Mock FastMCP
        mock_fastmcp = MagicMock()
        with patch.dict(sys.modules, {'mcp.server': MagicMock(FastMCP=mock_fastmcp)}):
            if 'monxcli.mcp_bridge' in sys.modules:
                del sys.modules['monxcli.mcp_bridge']
            
            import monxcli.mcp_bridge as mcp_bridge
            self.assertIsNotNone(mcp_bridge.server)

            def my_tool(a: int):
                return a
            my_tool.__module__ = "testmod.testscript"

            mcp_bridge.monx_tool(name="custom_tool", desc="Test tool")(my_tool)
            
            # Ensure it registered with MCP
            mcp_bridge.server.tool.assert_called()

if __name__ == '__main__':
    unittest.main()
