import unittest
from unittest.mock import patch, MagicMock
import io
import contextlib
import importlib
import mcp_cli.server_command
from monxcli.commands import commands
import monxcli.mcp_bridge

class TestServerCommand(unittest.TestCase):

    def setUp(self):
        # Reset the shared commands registry
        commands._reset()

    def test_start_no_server(self):
        # Patch the server instance in the mcp_bridge module
        with patch('monxcli.mcp_bridge.server', None):
            # Reload to pick up the patched server
            importlib.reload(mcp_cli.server_command)
            from mcp_cli.server_command import start
            
            f = io.StringIO()
            with contextlib.redirect_stdout(f):
                start(port=8888)
            
            output = f.getvalue()
            self.assertIn("fastmcp' is not installed", output)

    def test_start_with_server(self):
        mock_server = MagicMock()
        with patch('monxcli.mcp_bridge.server', mock_server):
            # Reload to pick up the patched server
            importlib.reload(mcp_cli.server_command)
            from mcp_cli.server_command import start
            
            f = io.StringIO()
            with contextlib.redirect_stdout(f):
                start(port=8888)
            
            mock_server.run.assert_called_with(transport="streamable-http")

if __name__ == '__main__':
    unittest.main()
