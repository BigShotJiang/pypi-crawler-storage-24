import unittest
from unittest.mock import MagicMock, patch
from monxcli.command_parser import LazyCommandParser, CommandProxy
import sys

# Mock modules for the test to satisfy the 2-level module requirement
class MockModule:
    pass

class TestCommandParser(unittest.TestCase):

    def test_command_registration(self):
        parser = LazyCommandParser()
        
        # Manually set __module__ to something that looks like 'folder.script'
        def my_func(a: int, b: str = "default"):
            """Docstring for my_func"""
            return f"{a}, {b}"
        
        my_func.__module__ = "testmodule.testscript"
        
        # Register the command
        parser.command()(my_func)
        
        # Check if registered correctly in CommandProxy
        proxy = parser._proxy
        self.assertIn("testmodule", proxy.commands)
        self.assertIn("testscript", proxy.commands["testmodule"])
        self.assertIn("my_func", proxy.commands["testmodule"]["testscript"])

    def test_execution(self):
        parser = LazyCommandParser()
        
        mock_func = MagicMock()
        mock_func.__name__ = "mock_func"
        mock_func.__doc__ = "Docstring"
        mock_func.__module__ = "testmodule.testscript"
        # Since inspect.signature(mock_func) might fail if it's a MagicMock, we'll use a real one
        def real_func(arg1: int):
            mock_func(arg1=arg1)
        real_func.__module__ = "testmodule.testscript"

        parser.command()(real_func)
        
        # Mock sys.argv to simulate calling the CLI
        with patch.object(sys, 'argv', ['prog', 'testmodule', 'testscript', 'real_func', '--arg1', '42']):
            parser()
            mock_func.assert_called_with(arg1=42)

if __name__ == '__main__':
    unittest.main()
