# monxcli/mcp_bridge.py

try:
    from mcp.server import FastMCP
    # Shared MCP server instance
    server = FastMCP("monxcli-mcp", stateless_http=True, host="0.0.0.0", port=1919)
except ImportError:
    server = None

from monxcli.commands import commands as monx_cli_commands


def monx_tool(func=None, *, name=None, desc=None):
    """
    Use this decorator ONCE on a function.
    It becomes:
        - a MonxCLI command
        - an MCP tool

    Example:
        @monx_tool(desc="Adds two numbers")
        def add(a: int, b: int):
            return a + b
    """

    if func is None:
        return lambda f: monx_tool(f, name=name, desc=desc)

    # Register for MonxCLI
    monx_wrapped = monx_cli_commands.command()(func)

    # Register for MCP
    if server:
        tool_name = name or func.__name__
        server.tool(name=tool_name, description=desc)(func)

    return monx_wrapped

def monx_prompt(func=None, *, name=None, desc=None):
    """
    Use this decorator ONCE on a function.
    It becomes:
        - a MonxCLI command
        - an MCP prompt

    Example:
        @monx_prompt(desc="Generates a greeting prompt")
        def greeting_prompt(name: str):
            return f"Hello, {name}!"
    """

    if func is None:
        return lambda f: monx_prompt(f, name=name, desc=desc)

    # Register for MonxCLI
    monx_wrapped = monx_cli_commands.command()(func)

    # Register for MCP
    if server:
        prompt_name = name or func.__name__
        server.prompt(name=prompt_name, description=desc)(func)

    return monx_wrapped

def monx_resource(func=None, *, name=None, desc=None):
    """
    Use this decorator ONCE on a function.
    It becomes:
        - a MonxCLI command
        - an MCP resource

    Example:
        @monx_resource(desc="Provides available colors")
        def get_colors():
            return ["red", "blue", "green"]
    """

    if func is None:
        return lambda f: monx_resource(f, name=name, desc=desc)

    # Register for MonxCLI
    monx_wrapped = monx_cli_commands.command()(func)

    # Register for MCP
    if server:
        resource_name = name or func.__name__
        server.resource(name=resource_name, description=desc)(func)

    return monx_wrapped
