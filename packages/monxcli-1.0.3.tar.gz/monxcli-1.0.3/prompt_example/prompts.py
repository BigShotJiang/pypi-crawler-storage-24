from monxcli.mcp_bridge import monx_prompt



@monx_prompt(desc="Generates a prompt to summarize a given document.")
def summarize_document(document_text: str, length: str = "short"):
    """
    Generates a prompt to summarize a given document.
    The length can be 'short', 'medium', or 'long'.
    """
    if length == "short":
        return f"Please provide a concise summary of the following document:\n\n{document_text}"
    elif length == "medium":
        return f"Summarize the key points of the following document:\n\n{document_text}"
    else:
        return f"Provide a detailed summary of the following document, including all important aspects:\n\n{document_text}"

@monx_prompt(desc="Generates a prompt to translate text to a target language.")
def translate_text(text: str, target_language: str):
    """
    Generates a prompt to translate text to a target language.
    """
    return f"Translate the following text to {target_language}:\n\n{text}"