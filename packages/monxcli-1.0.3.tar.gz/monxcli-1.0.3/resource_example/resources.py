from monxcli.mcp_bridge import monx_resource

@monx_resource()
def available_languages():
    """
    Provides a list of languages supported for translation.
    """
    return ["English", "Spanish", "French", "German", "Italian", "Portuguese"]

@monx_resource()
def get_user_preferences(user_id: str):
    """
    Retrieves user-specific preferences.
    """
    # In a real application, this would fetch data from a database or API
    preferences = {
        "user123": {"theme": "dark", "notifications": True},
        "user456": {"theme": "light", "notifications": False},
    }
    return preferences.get(user_id, {"theme": "system", "notifications": True})
