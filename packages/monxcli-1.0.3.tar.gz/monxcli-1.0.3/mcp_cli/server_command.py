import asyncio
from monxcli.mcp_bridge import server, monx_tool

@monx_tool(desc="Starts the MCP server.")
def start(port: int = 8000):
    """Starts the MCP server to listen for client connections."""
    if server is None:
        print("Error: MCP server could not be started because 'fastmcp' is not installed.")
        print("Please install it with: pip install monxcli[mcp]")
        return
    print(f"Starting MCP server on port {port}...")
    server.run(transport="streamable-http")

