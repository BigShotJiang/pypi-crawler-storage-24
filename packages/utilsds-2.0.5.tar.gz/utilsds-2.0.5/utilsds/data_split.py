"""
Train test validation split function
"""

# pylint: disable=too-many-arguments
# pylint: disable=too-many-locals

from typing import Any, Dict, Tuple

import pandas as pd
from sklearn.model_selection import train_test_split


def train_test_validation_split(
    data: pd.DataFrame,
    col_target: str,
    # Parametry dla podziału procentowego
    train_percent: float | None = None,
    test_percent: float | None = None,
    validate_percent: float | None = None,
    random_state: int = 2024,
    col_order: str | None = None,
    task: str = "reg",
    # Parametry dla podziału według okresów (YYYY-MM)
    train_periods: list[str] | None = None,
    test_periods: list[str] | None = None,
    val_periods: list[str] | None = None,
    col_date: str | None = None,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.Series, pd.Series, pd.Series]:
    """
    Splits a Pandas dataframe into three subsets (train, val, and test).

    Supports two modes:
    1. PERCENTAGE MODE: Uses sklearn's train_test_split with percentage splits
    2. PERIOD MODE: Splits data based on year-month periods (YYYY-MM format)

    Mode is automatically selected based on provided parameters:
    - If train_periods is provided -> PERIOD MODE
    - Otherwise -> PERCENTAGE MODE

    Parameters
    ----------
    data: pd.DataFrame
        Data to split
    col_target: str
        Name of column target

    PERCENTAGE MODE parameters:
    ---------------------------
    train_percent: float (0,1) | None
        Percent of train data. Defaults to 0.7 if None in percentage mode.
    test_percent: float (0,1) | None
        Percent of test data. Defaults to 0.15 if None in percentage mode.
    validate_percent: float (0,1) | None
        Percent of validate data. Defaults to 0.15 if None in percentage mode.
    random_state: int
        Random state for reproducibility. Defaults to 2024.
    col_order: str | None
        Column to sort values for train/test/validation split by date.
        If provided, standard split is done without shuffling.
    task: str
        Type of task - 'reg' for regression, 'bin' for binary classification,
        or 'multi' for multiclass classification. Defaults to "reg".

    PERIOD MODE parameters:
    -----------------------
    train_periods: list[str] | None
        List of periods in 'YYYY-MM' format for training set.
        E.g. ['2023-01', '2023-02', '2024-01']
    test_periods: list[str] | None
        List of periods in 'YYYY-MM' format for test set
    val_periods: list[str] | None
        List of periods in 'YYYY-MM' format for validation set.
        If None in period mode, validation set will be empty.
    col_date: str | None
        Name of date column (e.g., 'ftd_date') to extract periods from.
        Required for period mode.

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.Series, pd.Series, pd.Series]
        X_train : Training data features
        X_test : Test data features
        X_val : Validation data features
        y_train : Training data target
        y_test : Test data target
        y_val : Validation data target

    Raises
    ------
    ValueError
        Various validation errors depending on mode

    Examples
    --------
    # PERIOD MODE (recommended for time series)
    >>> train_p, test_p, val_p = get_train_test_val_periods(
    ...     df, 'ftd_date', exclude_periods=['2024-06']
    ... )
    >>> X_train, X_test, X_val, y_train, y_test, y_val = train_test_validation_split(
    ...     data=df,
    ...     col_target='remaining_ngr',
    ...     col_date='ftd_date',
    ...     train_periods=train_p,
    ...     test_periods=test_p,
    ...     val_periods=val_p
    ... )

    # PERCENTAGE MODE
    >>> X_train, X_test, X_val, y_train, y_test, y_val = train_test_validation_split(
    ...     data=df,
    ...     col_target='remaining_ngr',
    ...     train_percent=0.7,
    ...     test_percent=0.15,
    ...     validate_percent=0.15,
    ...     task='reg'
    ... )
    """

    # Determine mode
    period_mode = train_periods is not None

    if period_mode:
        return _split_by_periods(
            data=data,
            col_target=col_target,
            col_date=col_date,
            train_periods=train_periods,
            test_periods=test_periods,
            val_periods=val_periods,
        )
    else:
        return _split_by_percentage(
            data=data,
            col_target=col_target,
            train_percent=train_percent if train_percent is not None else 0.7,
            test_percent=test_percent if test_percent is not None else 0.15,
            validate_percent=validate_percent if validate_percent is not None else 0.15,
            random_state=random_state,
            col_order=col_order,
            task=task,
        )


def _split_by_percentage(
    data: pd.DataFrame,
    col_target: str,
    train_percent: float,
    test_percent: float,
    validate_percent: float,
    random_state: int,
    col_order: str | None,
    task: str,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.Series, pd.Series, pd.Series]:
    """Internal function for percentage-based split."""

    if train_percent + validate_percent + test_percent != 1.0:
        raise ValueError("Sum of train, validate and test is not 1.0")
    if col_target not in data.columns:
        raise ValueError(f"{col_target} is not a column in the dataframe")

    if col_order is not None:
        data = data.sort_values(by=col_order, ignore_index=True)
        data = data.drop(col_order, axis=1)

    y = data[[col_target]]
    data = data.drop(col_target, axis=1)

    train_temp_params = {} if task == "reg" or col_order is not None else {"stratify": y}
    X_train, X_temp, y_train, y_temp = train_test_split(
        data, y, test_size=(1.0 - train_percent), random_state=random_state, **train_temp_params
    )

    test_val_params = {} if task == "reg" or col_order is not None else {"stratify": y_temp}
    validate_to_split = validate_percent / (validate_percent + test_percent)
    X_test, X_val, y_test, y_val = train_test_split(
        X_temp, y_temp, test_size=validate_to_split, random_state=random_state, **test_val_params
    )

    assert len(data) == len(X_train) + len(X_test) + len(
        X_val
    ), "Length of X is different than sum of x_train + x_test + x_val"
    assert len(y) == len(y_train) + len(y_test) + len(
        y_val
    ), "Length of y is different than sum of y_train + y_test + y_val"
    assert len(X_train) == len(y_train), "Length of X_train is different than y_train"
    assert len(X_test) == len(y_test), "Length of X_test is different than y_test"
    assert len(X_val) == len(y_val), "Length of X_val is different than y_val"

    return X_train, X_test, X_val, y_train, y_test, y_val


def _split_by_periods(
    data: pd.DataFrame,
    col_target: str,
    col_date: str | None,
    train_periods: list[str] | None,
    test_periods: list[str] | None,
    val_periods: list[str] | None,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.Series, pd.Series, pd.Series]:
    """Internal function for period-based split (YYYY-MM format)."""

    # Validation checks
    if col_target not in data.columns:
        raise ValueError(f"{col_target} is not a column in the dataframe")
    if col_date is None:
        raise ValueError("col_date is required for period split mode")
    if col_date not in data.columns:
        raise ValueError(f"{col_date} is not a column in the dataframe")
    if train_periods is None:
        raise ValueError("train_periods is required for period split mode")
    if test_periods is None:
        raise ValueError("test_periods is required for period split mode")

    # Create a copy to avoid modifying original data
    df = data.copy()

    # Extract period from date column
    df["_date"] = pd.to_datetime(df[col_date], errors="coerce")

    # Check for invalid dates
    if df["_date"].isna().any():
        n_invalid = df["_date"].isna().sum()
        raise ValueError(f"Column '{col_date}' contains {n_invalid} invalid dates or NaN values")

    df["_period"] = df["_date"].dt.to_period("M")

    # Convert string periods to Period objects
    train_period_objs = [pd.Period(p, freq="M") for p in train_periods]
    test_period_objs = [pd.Period(p, freq="M") for p in test_periods]
    val_period_objs = [pd.Period(p, freq="M") for p in val_periods] if val_periods else []

    # Check for overlapping periods
    train_set = set(train_period_objs)
    test_set = set(test_period_objs)
    val_set = set(val_period_objs) if val_periods else set()

    overlap_train_test = train_set & test_set
    overlap_train_val = train_set & val_set
    overlap_test_val = test_set & val_set

    if overlap_train_test or overlap_train_val or overlap_test_val:
        raise ValueError(
            f"Periods cannot overlap between datasets. "
            f"Train∩Test: {overlap_train_test}, "
            f"Train∩Val: {overlap_train_val}, "
            f"Test∩Val: {overlap_test_val}"
        )

    # Check which periods are actually available in data
    available_periods = set(df["_period"].unique())
    missing_train = train_set - available_periods
    missing_test = test_set - available_periods
    missing_val = val_set - available_periods

    if missing_train:
        raise ValueError(f"Training periods not found in data: {missing_train}")
    if missing_test:
        raise ValueError(f"Test periods not found in data: {missing_test}")
    if val_periods and missing_val:
        raise ValueError(f"Validation periods not found in data: {missing_val}")

    # Split data by periods
    train_mask = df["_period"].isin(train_period_objs)
    test_mask = df["_period"].isin(test_period_objs)

    df_train = df[train_mask].copy()
    df_test = df[test_mask].copy()

    if val_periods is not None and len(val_periods) > 0:
        val_mask = df["_period"].isin(val_period_objs)
        df_val = df[val_mask].copy()
    else:
        df_val = pd.DataFrame(columns=df.columns)

    # Check that datasets are not empty
    if len(df_train) == 0:
        raise ValueError(f"Training set is empty. No data found for periods: {train_periods}")
    if len(df_test) == 0:
        raise ValueError(f"Test set is empty. No data found for periods: {test_periods}")
    if val_periods is not None and len(val_periods) > 0 and len(df_val) == 0:
        raise ValueError(f"Validation set is empty. No data found for periods: {val_periods}")

    # Remove temporary columns and split X/y
    df_train = df_train.drop(["_date", "_period"], axis=1)
    df_test = df_test.drop(["_date", "_period"], axis=1)
    df_val = df_val.drop(["_date", "_period"], axis=1) if len(df_val) > 0 else df_val

    # Split features and target (use single brackets for Series)
    X_train = df_train.drop(col_target, axis=1)
    y_train = df_train[col_target]

    X_test = df_test.drop(col_target, axis=1)
    y_test = df_test[col_target]

    if len(df_val) > 0:
        X_val = df_val.drop(col_target, axis=1)
        y_val = df_val[col_target]
    else:
        X_val = pd.DataFrame(columns=X_train.columns)
        y_val = pd.Series(dtype=y_train.dtype, name=col_target)

    # Assertions
    assert len(X_train) == len(y_train), "Length of X_train is different than y_train"
    assert len(X_test) == len(y_test), "Length of X_test is different than y_test"
    assert len(X_val) == len(y_val), "Length of X_val is different than y_val"

    # Print split summary
    print("\nData split summary:")
    print(f"  Train: {len(X_train):,} samples (periods: {train_periods[0]} to {train_periods[-1]})")
    print(f"  Test:  {len(X_test):,} samples (periods: {test_periods[0]} to {test_periods[-1]})")
    if val_periods:
        print(f"  Val:   {len(X_val):,} samples (periods: {val_periods[0]} to {val_periods[-1]})")
    else:
        print(f"  Val:   {len(X_val):,} samples (no validation set)")

    return X_train, X_test, X_val, y_train, y_test, y_val


def resample_X_y(
    X_train: pd.DataFrame, y_train: pd.Series, sampler_object: Any, params: Dict[str, Any] | None = None
) -> Tuple[pd.DataFrame, pd.Series]:
    """Function for resampling train data and target column.

    Parameters
    ----------
    X_train : pd.DataFrame
        Data with all columns to train model
    y_train : pd.Series
        Target column
    sampler_object : Any
        Object of selected sampler to execute
    params : Dict[str, Any], optional
        Dictionary of params for selected sampler, by default None

    Returns
    -------
    Tuple[pd.DataFrame, pd.Series]
        - X_resampled : Resampled training data
        - y_resampled : Resampled target column
    """
    if params is None:
        params = {}

    if "id_client" in X_train.columns:
        X_train = X_train.drop("id_client", axis=1)
    sampler = sampler_object(**params)
    X_resampled, y_resampled = sampler.fit_resample(X_train, y_train)
    return X_resampled, y_resampled


def get_train_test_val_periods(
    df: pd.DataFrame,
    date_column: str,
    n_val_periods: int = 1,
    n_test_periods: int = 2,
    exclude_periods: list[str] | None = None,
) -> tuple[list[str], list[str], list[str]]:
    """
    Automatically extracts periods (YYYY-MM) for train/test/val in chronological order.
    Handles data from different years and allows excluding specific periods.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame with data
    date_column : str
        Name of the date column
    n_val_periods : int, default=1
        Number of last periods for validation
    n_test_periods : int, default=2
        Number of periods before validation for testing
    exclude_periods : list[str] | None, default=None
        List of specific periods to exclude in 'YYYY-MM' format.
        E.g. ['2024-06'] excludes June 2024, ['2024-11', '2024-12'] excludes Nov-Dec 2024.

    Returns
    -------
    tuple[list[str], list[str], list[str]]
        train_periods, test_periods, val_periods (in 'YYYY-MM' format)

    Examples
    --------
    >>> # Exclude June 2024 (e.g. incomplete data)
    >>> train_p, test_p, val_p = get_train_test_val_periods(
    ...     df, 'ftd_date', exclude_periods=['2024-06']
    ... )
    >>> # Returns: (['2024-01', '2024-02', ...], ['2024-07', '2024-08'], ['2024-09'])

    >>> # Exclude multiple specific periods
    >>> train_p, test_p, val_p = get_train_test_val_periods(
    ...     df, 'ftd_date', exclude_periods=['2024-11', '2024-12', '2025-01']
    ... )
    """
    df_copy = df.copy()
    df_copy["_date"] = pd.to_datetime(df_copy[date_column], errors="coerce")

    # Check for invalid dates
    if df_copy["_date"].isna().any():
        n_invalid = df_copy["_date"].isna().sum()
        raise ValueError(f"Column '{date_column}' contains {n_invalid} invalid dates or NaN values")

    # Find unique year-month and sort chronologically
    df_copy["_year_month"] = df_copy["_date"].dt.to_period("M")
    unique_periods = sorted(df_copy["_year_month"].unique())

    # Exclude selected periods
    if exclude_periods is not None and len(exclude_periods) > 0:
        original_count = len(unique_periods)

        # Convert string periods to Period objects
        exclude_periods_set = {pd.Period(p, freq="M") for p in exclude_periods}
        unique_periods = [p for p in unique_periods if p not in exclude_periods_set]

        excluded_count = original_count - len(unique_periods)

        if excluded_count > 0:
            print(f"Excluded {excluded_count} period(s): {exclude_periods}")

    total_periods = len(unique_periods)

    if total_periods < (n_val_periods + n_test_periods + 1):
        raise ValueError(
            f"Insufficient number of periods in data after exclusion. "
            f"Need minimum {n_val_periods + n_test_periods + 1}, "
            f"available {total_periods}"
        )

    # Split periods chronologically
    val_periods = unique_periods[-n_val_periods:]
    test_periods = unique_periods[-(n_val_periods + n_test_periods) : -n_val_periods]
    train_periods = unique_periods[: -(n_val_periods + n_test_periods)]

    # Convert Period objects to 'YYYY-MM' strings
    train_periods_str = [str(p) for p in train_periods]
    test_periods_str = [str(p) for p in test_periods]
    val_periods_str = [str(p) for p in val_periods]

    print(f"Periods in data: {unique_periods[0]} to {unique_periods[-1]}")
    print(f"Train periods: {train_periods_str[0]} to {train_periods_str[-1]} ({len(train_periods_str)} periods)")
    print(f"Test periods:  {test_periods_str[0]} to {test_periods_str[-1]} ({len(test_periods_str)} periods)")
    print(f"Val periods:   {val_periods_str[0]} to {val_periods_str[-1]} ({len(val_periods_str)} periods)")

    return train_periods_str, test_periods_str, val_periods_str
