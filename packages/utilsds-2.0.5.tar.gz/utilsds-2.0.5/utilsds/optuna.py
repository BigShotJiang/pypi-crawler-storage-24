"""
Hyperparameter Optimization using Optuna
"""

import json
from pathlib import Path
from typing import Any, Callable, Dict

import numpy as np
import optuna
import pandas as pd
from optuna.visualization import (
    plot_optimization_history,
    plot_parallel_coordinate,
    plot_param_importances,
    plot_slice,
)

from .algorithm import Algorithm
from .metrics import Metrics


class Optuna:
    """Class for obtaining best hyperparams by optuna.

    Parameters
    ----------
    model : object
        Model object (Classifier or Regressor) to optimize
    X_train : pd.DataFrame
        Training features
    X_test : pd.DataFrame
        Testing features
    y_train : pd.Series
        Training target
    y_test : pd.Series
        Testing target
    task : str
        Type of task ('classification' or 'regression')
    main_metric : str
        Name of the metric to optimize
    model_params : Dict[str, Any]
        Model parameters
    proba : float
        Probability threshold for classification
    own_metrics : Dict[str, Any]
        Dictionary of custom metrics
    metrics_average : str
        Averaging method for metrics calculation
    beta : float
        Beta parameter for F-beta score
    fbeta_average : str
        Averaging method for F-beta score
    fbeta_weights : list[float]
        Weights for F-beta score calculation
    is_loss_function : bool
        Defines if main_metric is loss_function or needs to be adjusted as loss function
    fit_params : dict, optional
        Additional parameters to pass to fit() method (e.g., eval_set, eval_metric). Defaults to None.
    run_name : str, optional
        Run name from Vertex Experiments (used for file naming to maintain consistency). Defaults to None.
    """

    def __init__(
        self,
        model: Any,
        X_train: pd.DataFrame,
        X_test: pd.DataFrame,
        y_train: pd.Series,
        y_test: pd.Series,
        task: str,
        main_metric: str,
        model_params: Dict[str, Any],
        proba: float,
        own_metrics: Dict[str, Any],
        metrics_average: str,
        beta: float,
        fbeta_average: str,
        fbeta_weights: list[float],
        is_loss_function: bool,
        fit_params: Dict[str, Any] | None = None,
        run_name: str | None = None,
    ):

        self.trial_model = Algorithm(
            model=model,
            X_train=X_train,
            X_test=X_test,
            y_train=y_train,
            y_test=y_test,
            task=task,
            params=model_params,
            proba=proba,
            fit_params=fit_params,
        )

        self.trial_metricser = Metrics(
            y_test=self.trial_model.y_test,
            y_pred=self.trial_model.y_pred,
            main_metric=main_metric,
            task=task,
            metrics_average=metrics_average,
            beta=beta,
            fbeta_average=fbeta_average,
            fbeta_weights=fbeta_weights,
            own_metrics=own_metrics,
        )
        self.is_loss_function = is_loss_function
        self.best_params: Dict[str, Any] = {}
        self.study = None
        self.space_function: Callable[[optuna.Trial], Dict[str, Any]] | None = None
        self.run_name = run_name
        self.use_pruner = False  # Will be set in calculate_optuna_best_params

    def _fit_predict_metrics(self, params: Dict[str, Any]) -> None:
        """Fit predict model with given parameters and calculate metrics.

        Parameters
        ----------
        params : Dict[str, Any]
            Parameters for model fitting
        """
        self.trial_model.fit_predict(params)
        self.trial_metricser.y_pred = self.trial_model.y_pred
        self.trial_metricser.calculate_metrics()

    def objective(self, trial: optuna.Trial) -> float:  # noqa: C901
        """Objective function for Optuna to fit, predict and calculate loss.

        Parameters
        ----------
        trial : optuna.Trial
            Optuna trial object for suggesting hyperparameters

        Returns
        -------
        float
            Metric value to optimize (minimize or maximize based on direction)
        """
        # Get parameters from the space function
        if self.space_function is None:
            raise ValueError("Space function must be set before calling objective")

        params = self.space_function(trial)

        try:
            self._fit_predict_metrics(params)
            main_metric_score = self.trial_metricser.get_main_metric()["score"]

            # Save all metrics as user attributes
            all_metrics = self.trial_metricser.metrics
            if all_metrics:
                for metric_name, metric_value in all_metrics.items():
                    try:
                        trial.set_user_attr(metric_name, float(metric_value))
                    except (ValueError, TypeError):
                        trial.set_user_attr(metric_name, metric_value)

            # Mark trial as successful
            trial.set_user_attr("failed", False)

            # Report value for pruning and check if should be pruned (only if pruner is enabled)
            if self.use_pruner:
                trial.report(main_metric_score, step=0)

                if trial.should_prune():
                    print(f"\n  Iteration {trial.number} PRUNED (unpromising performance)")
                    print(f"    Params: {params}")
                    print(f"    Score: {main_metric_score}")
                    raise optuna.TrialPruned()

            # Print current iteration parameters and score
            print(f"\nIteration {trial.number}")
            print(f"Current params: {params}")
            print(f"Current score: {main_metric_score}")

            # Get current best parameters and print them if we have completed trials
            if trial.number > 0 and self.study is not None:
                try:  # type: ignore
                    print(f"The best params so far: {self.study.best_params}")
                    print(f"The best score so far: {self.study.best_value}")
                except (ValueError, AttributeError):
                    pass

            return main_metric_score  # type: ignore

        except optuna.TrialPruned:
            # Re-raise TrialPruned so Optuna can handle it properly
            raise
        except Exception as e:
            # Log the error
            error_msg = f"{type(e).__name__}: {str(e)}"
            trial.set_user_attr("failed", True)
            trial.set_user_attr("error", error_msg)

            print(f"\n⚠️  Iteration {trial.number} FAILED")
            print(f"    Params: {params}")
            print(f"    Error: {error_msg}")

            # Return worst possible value so this trial is not selected by Optuna
            if self.is_loss_function:
                return float("inf")  # For minimization
            else:
                return float("-inf")  # For maximization

    def calculate_optuna_best_params(
        self,
        space: Callable[[optuna.Trial], Dict[str, Any]],
        model: Any,
        metricser: Any,
        n_startup_jobs: int = 10,
        optuna_iter: int = 100,
        catch_exceptions: bool = True,
        use_pruner: bool = False,
        pruner_type: str = "median",
    ) -> Dict[str, Any]:
        """Calculate models and return the best parameters using optuna.

        Parameters
        ----------
        space : Callable[[optuna.Trial], Dict[str, Any]]
            Function that takes an Optuna trial and returns a dictionary of parameters.
            Example:
            ```python
            def space(trial):
                return {
                    'C': trial.suggest_float('C', 0.1, 100.0),
                    'max_iter': trial.suggest_int('max_iter', 100, 1000)
                }
            ```
        model : Any
            Model object to be optimized
        metricser : Any
            Metrics object for evaluation
        n_startup_jobs : int, optional
            Number of random trials before using TPE sampler, by default 10
        optuna_iter : int, optional
            Number of optimization iterations, by default 100
        catch_exceptions : bool, optional
            If True, catches exceptions in trials and continues optimization.
            If False, raises exceptions (useful for debugging), by default True
        use_pruner : bool, optional
            If True, enables pruning to stop unpromising trials early, by default False
        pruner_type : str, optional
            Type of pruner: "median", "percentile", "hyperband"
            - "median": Prunes if worse than median of previous trials
            - "percentile": Prunes if in bottom 25%
            - "hyperband": Adaptive budget allocation (for iterative models)
            By default "median"

        Returns
        -------
        Dict[str, Any]
            Dictionary containing the best parameters found
        """
        self.space_function = space
        self.catch_exceptions = catch_exceptions
        self.use_pruner = use_pruner

        # Determine optimization direction based on whether we're minimizing or maximizing
        direction = "minimize" if self.is_loss_function else "maximize"

        optuna.logging.set_verbosity(optuna.logging.WARNING)

        # Create pruner if enabled
        pruner = None
        if use_pruner:
            if pruner_type == "median":
                pruner = optuna.pruners.MedianPruner(n_startup_trials=n_startup_jobs, n_warmup_steps=5)
            elif pruner_type == "percentile":
                pruner = optuna.pruners.PercentilePruner(
                    percentile=25.0, n_startup_trials=n_startup_jobs, n_warmup_steps=5
                )
            elif pruner_type == "hyperband":
                pruner = optuna.pruners.HyperbandPruner()

        # Create Optuna study with TPE sampler and optional pruner
        sampler = optuna.samplers.TPESampler(n_startup_trials=n_startup_jobs)
        self.study = optuna.create_study(direction=direction, sampler=sampler, pruner=pruner)

        # Optimize with exception catching
        if catch_exceptions:
            self.study.optimize(  # type: ignore
                self.objective,
                n_trials=optuna_iter,
                show_progress_bar=True,
                catch=(Exception,),
            )
        else:
            self.study.optimize(self.objective, n_trials=optuna_iter, show_progress_bar=True)  # type: ignore

        # Get best parameters
        self.best_params = self.study.best_params  # type: ignore

        # Fit model with best parameters and calculate metrics
        model.fit_predict(self.best_params)
        metricser.calculate_metrics()

        # Print summary with failed trials info
        self._print_optimization_summary()

        return self.best_params

    def _print_optimization_summary(self) -> None:
        """Print summary of optimization including failed trials statistics."""
        if self.study is None:
            return

        # Count failed and pruned trials
        failed_trials = [t for t in self.study.trials if t.user_attrs.get("failed", False)]  # type: ignore
        pruned_trials = [t for t in self.study.trials if t.state == optuna.trial.TrialState.PRUNED]
        n_failed = len(failed_trials)
        n_pruned = len(pruned_trials)
        n_total = len(self.study.trials)
        n_success = n_total - n_failed - n_pruned

        print(f"\n{'=' * 60}")
        print("Optimization Summary")
        print(f"{'=' * 60}")
        print(f"Total trials: {n_total}")
        print(f"Successful: {n_success}")
        if n_pruned > 0:
            print(f"Pruned: {n_pruned}")
        print(f"Failed: {n_failed}")

        if n_failed > 0:
            failure_rate = (n_failed / n_total) * 100
            print(f"Failure rate: {failure_rate:.1f}%")

            if failure_rate > 20:
                print(f"\n⚠️  WARNING: High failure rate ({failure_rate:.1f}%)")
                print("   Consider reviewing your parameter space or model constraints.")

        if n_pruned > 0:
            prune_rate = (n_pruned / n_total) * 100
            print(f"\n Pruned {n_pruned} unpromising trials early ({prune_rate:.1f}%)")
            print("   This saved computation time.")

        print(f"\nBest trial: {self.study.best_trial.number}")
        print(f"Best score: {self.study.best_value}")
        print(f"Best params: {self.best_params}")
        print(f"{'=' * 60}\n")

    def get_optimization_history(self) -> pd.DataFrame:
        """Get complete optimization history as DataFrame with all metrics.

        Returns
        -------
        pd.DataFrame
            DataFrame containing all trials with parameters, scores, and metrics

        Raises
        ------
        ValueError
            If no study is available (optimization hasn't been run yet)

        Examples
        --------
        >>> optimizer.calculate_optuna_best_params(space, model, metricser, optuna_iter=50)
        >>> history = optimizer.get_optimization_history()
        >>> print(history[['value', 'user_attrs_accuracy', 'user_attrs_precision']])
        """
        if self.study is None:
            raise ValueError("No study available. Run calculate_optuna_best_params() first.")

        return self.study.trials_dataframe()  # type: ignore

    def save_results(self, filepath: str | None = None) -> None:
        """Save optimization results with all trials and metrics to JSON file.

        Uses the same run_name as Vertex Experiments for consistency.

        Parameters
        ----------
        filepath : str, optional
            Path to JSON file. If None, uses the run_name from Vertex Experiments
            to create "notebooks/data/{run_name}.json"
        """
        if self.study is None:
            raise ValueError("No study available. Run calculate_optuna_best_params() first.")

        if filepath is None:  # type: ignore
            filepath = f"notebooks/data/optuna_results_{self.run_name}.json"

        # Create directory if it doesn't exist
        filepath_obj = Path(filepath)
        filepath_obj.parent.mkdir(parents=True, exist_ok=True)

        history_df = self.get_optimization_history()
        best_trial_number = self.study.best_trial.number
        history_df["is_best"] = history_df["number"] == best_trial_number

        # Replace NaN and Infinity values with None for JSON compatibility
        history_df = history_df.replace([np.inf, -np.inf], None)
        history_df = history_df.replace({np.nan: None})

        data = history_df.to_dict(orient="records")

        with open(filepath_obj, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

    def create_visualizations(  # noqa: C901
        self, show_plots: bool = True, plot_types: list[str] | None = None
    ) -> Dict[str, Any]:
        """Create visualization plots for optimization results.

        Parameters
        ----------
        show_plots : bool, optional
            If True, displays plots interactively, by default True
        plot_types : list[str], optional
            List of plot types to create. Available: "history", "importance",
            "parallel", "slice". If None, creates ["history", "importance"].

        Returns
        -------
        Dict[str, Any]
            Dictionary with plotly figure objects for each plot type

        Raises
        ------
        ValueError
            If no study is available

        Examples
        --------
        >>> optimizer.calculate_optuna_best_params(space, model, metricser, optuna_iter=50)
        >>> figs = optimizer.create_visualizations()
        >>> figs = optimizer.create_visualizations(plot_types=["history", "importance"])
        """
        if self.study is None:
            raise ValueError("No study available. Run calculate_optuna_best_params() first.")

        if plot_types is None:  # type: ignore
            plot_types = ["history", "importance"]

        figures = {}

        if "history" in plot_types:
            fig = plot_optimization_history(self.study)
            fig.update_layout(title="Optimization History - Best Value Over Time")
            figures["history"] = fig
            if show_plots:
                fig.show()

        if "importance" in plot_types:
            fig = plot_param_importances(self.study)
            fig.update_layout(title="Hyperparameter Importance")
            figures["importance"] = fig
            if show_plots:
                fig.show()

        if "parallel" in plot_types:
            fig = plot_parallel_coordinate(self.study)
            fig.update_layout(title="Parallel Coordinate Plot - All Trials")
            figures["parallel"] = fig
            if show_plots:
                fig.show()

        if "slice" in plot_types:
            fig = plot_slice(self.study)
            fig.update_layout(title="Parameter vs Objective Value")
            figures["slice"] = fig
            if show_plots:
                fig.show()

        return None
