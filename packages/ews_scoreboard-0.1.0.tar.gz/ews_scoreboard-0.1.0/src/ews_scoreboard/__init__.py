"""EWS Scoreboard Pipeline."""
__version__ = "0.1.0"
