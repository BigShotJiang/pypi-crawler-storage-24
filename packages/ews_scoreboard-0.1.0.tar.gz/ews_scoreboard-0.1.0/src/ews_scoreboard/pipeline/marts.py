"""
Marts: silver → mart tables (scoreboard, trending lists).
"""

import json
import duckdb
from pathlib import Path


def _build_scoreboard(con) -> dict:
    """Build scoreboard mart and return as dict for JSON export."""
    donemler = [r[0] for r in con.execute(
        "SELECT DISTINCT donem FROM fact_periodic ORDER BY donem"
    ).fetchall()]

    if not donemler:
        print("    [WARN] No periods in fact_periodic")
        return {"meta": {}, "rows": []}

    son_donem = donemler[-1]

    base_df = con.execute("""
        WITH risk_filter AS (
            SELECT DISTINCT entity_id FROM fact_periodic
            WHERE ABS(COALESCE(kombine_risk, 0)) > 1
        ),
        yi_transition AS (
            SELECT DISTINCT entity_id FROM fact_periodic WHERE ews_skor = 'YI'
            INTERSECT
            SELECT DISTINCT entity_id FROM fact_periodic WHERE ews_skor IS NOT NULL AND ews_skor != 'YI'
        )
        SELECT entity_id FROM risk_filter
        UNION
        SELECT entity_id FROM yi_transition
    """).fetchdf()

    entity_ids = base_df["entity_id"].tolist()
    if not entity_ids:
        return {"meta": {"donemler": donemler, "son_donem": son_donem, "n_muta": 0}, "rows": []}

    rows_data = con.execute("""
        SELECT
            de.entity_id,
            mi.unvan,
            de.segment,
            de.sube_kodu,
            sb.sube_adi,
            de.bolge_kodu,
            sb2.bolge_adi
        FROM dim_entity de
        LEFT JOIN map_identity mi ON de.entity_id = mi.entity_id
        LEFT JOIN ref_sube_bolge sb ON de.sube_kodu = sb.sube_kodu
        LEFT JOIN (
            SELECT DISTINCT ON (bolge_kodu) bolge_kodu, bolge_adi
            FROM ref_sube_bolge ORDER BY bolge_kodu
        ) sb2 ON de.bolge_kodu = sb2.bolge_kodu
        WHERE de.entity_id = ANY($1)
    """, [entity_ids]).fetchdf()

    period_data = con.execute("""
        SELECT entity_id, donem, ews_skor, kombine_risk, risk_degisim, tfrs_rating, rating_tarihi
        FROM fact_periodic
        WHERE entity_id = ANY($1)
    """, [entity_ids]).fetchdf()

    period_lookup = {}
    for _, r in period_data.iterrows():
        eid = r["entity_id"]
        d = r["donem"]
        if eid not in period_lookup:
            period_lookup[eid] = {}
        period_lookup[eid][d] = r

    son_risk_map = {}
    for _, r in period_data[period_data["donem"] == son_donem].iterrows():
        son_risk_map[r["entity_id"]] = int(r["kombine_risk"]) if r["kombine_risk"] is not None and str(r["kombine_risk"]) != '<NA>' else 0

    rows = []
    for _, static in rows_data.iterrows():
        eid = static["entity_id"]
        row = {
            "muta": eid,
            "unvan": static["unvan"] if static["unvan"] and str(static["unvan"]) not in ("None", "<NA>", "nan") else None,
            "segment": static["segment"] if static["segment"] and str(static["segment"]) not in ("None", "<NA>", "nan") else None,
            "son_risk": son_risk_map.get(eid, 0),
            "sube_kodu": int(static["sube_kodu"]) if static["sube_kodu"] is not None and str(static["sube_kodu"]) not in ("None", "<NA>", "nan") else None,
            "sube_adi": static["sube_adi"] if static["sube_adi"] and str(static["sube_adi"]) not in ("None", "<NA>", "nan") else None,
            "bolge_kodu": int(static["bolge_kodu"]) if static["bolge_kodu"] is not None and str(static["bolge_kodu"]) not in ("None", "<NA>", "nan") else None,
            "bolge_adi": static["bolge_adi"] if static["bolge_adi"] and str(static["bolge_adi"]) not in ("None", "<NA>", "nan") else None,
        }

        periods = period_lookup.get(eid, {})
        for d in donemler:
            pr = periods.get(d)
            if pr is not None:
                ews_val = pr["ews_skor"]
                if ews_val is not None and str(ews_val) not in ("None", "<NA>", "nan"):
                    row[f"ews{d}"] = str(ews_val) if ews_val == "YI" else _safe_int(ews_val)
                else:
                    row[f"ews{d}"] = None

                row[f"r{d}"] = _safe_int(pr["kombine_risk"])
                row[f"rd{d}"] = _safe_int(pr["risk_degisim"])
                row[f"df{d}"] = row["son_risk"] - (row[f"r{d}"] or 0) if row[f"r{d}"] is not None else None

                tfrs = pr["tfrs_rating"]
                row[f"tfrs_{d}"] = str(tfrs) if tfrs is not None and str(tfrs) not in ("None", "<NA>", "nan") else None
                rtar = pr["rating_tarihi"]
                row[f"rtar_{d}"] = str(rtar) if rtar is not None and str(rtar) not in ("None", "<NA>", "nan") else None
            else:
                for prefix in ["ews", "r", "rd", "df"]:
                    row[f"{prefix}{d}"] = None
                row[f"tfrs_{d}"] = None
                row[f"rtar_{d}"] = None

        rows.append(row)

    rows.sort(key=lambda r: r.get("son_risk", 0) or 0, reverse=True)

    bolge_list = sorted(set(r["bolge_adi"] for r in rows if r.get("bolge_adi")))
    sube_list = sorted(set(r["sube_adi"] for r in rows if r.get("sube_adi")))

    meta = {
        "donemler": donemler,
        "son_donem": son_donem,
        "n_muta": len(rows),
        "bolge_listesi": bolge_list,
        "sube_listesi": sube_list,
        "pipeline_ts": "dummy_run",
        "notebook": "pipeline_runner",
    }

    return {"meta": meta, "rows": rows}


def _safe_int(val):
    if val is None or str(val) in ("None", "<NA>", "nan", ""):
        return None
    try:
        return int(float(str(val)))
    except (ValueError, TypeError):
        return None


def _build_trending_lists(con, scoreboard: dict) -> dict:
    """Build trending lists from scoreboard data."""
    rows = scoreboard.get("rows", [])
    donemler = scoreboard.get("meta", {}).get("donemler", [])

    if len(donemler) < 2:
        return {"fastest_rising": [], "regime_change": [], "persistent_high": [], "low_but_rising": []}

    son = donemler[-1]
    son_1 = donemler[-2] if len(donemler) >= 2 else None
    son_3 = donemler[-4] if len(donemler) >= 4 else donemler[0]

    def _ews_num(row, d):
        v = row.get(f"ews{d}")
        if v is None:
            return None
        if v == "YI" or v == -1:
            return 1000
        try:
            return int(v)
        except (ValueError, TypeError):
            return None

    enriched = []
    for r in rows:
        s_last = _ews_num(r, son)
        s_prev1 = _ews_num(r, son_1) if son_1 else None
        s_prev3 = _ews_num(r, son_3)

        delta_1 = (s_last - s_prev1) if s_last is not None and s_prev1 is not None else None
        delta_3 = (s_last - s_prev3) if s_last is not None and s_prev3 is not None else None

        consec = 0
        for i in range(len(donemler) - 1, 0, -1):
            curr = _ews_num(r, donemler[i])
            prev = _ews_num(r, donemler[i - 1])
            if curr is not None and prev is not None and curr > prev:
                consec += 1
            else:
                break

        enriched.append({
            **r,
            "_score_last": s_last,
            "_delta_1": delta_1,
            "_delta_3": delta_3,
            "_consec": consec,
        })

    fastest = [e for e in enriched if e["_delta_3"] is not None and e["_delta_3"] > 0 and e.get("_delta_1", 0) and e["_delta_1"] > 0]
    fastest.sort(key=lambda x: x["_delta_3"], reverse=True)
    fastest_out = [{
        "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
        "score_last": e["_score_last"], "delta_3": e["_delta_3"],
        "reason": f"Son 3 dönemde +{e['_delta_3']} puan artış"
    } for e in fastest[:50]]

    regime = []
    for e in enriched:
        s_prev = _ews_num(e, son_1) if son_1 else None
        s_curr = e["_score_last"]
        if s_prev is not None and s_curr is not None:
            if s_prev < 500 and s_curr >= 500 and s_curr != 1000:
                regime.append({
                    "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
                    "score_last": s_curr,
                    "reason": "EUS bandından YIS bandına geçiş"
                })
    regime.sort(key=lambda x: x.get("score_last", 0), reverse=True)

    persistent = []
    for e in enriched:
        all_high = True
        for d in donemler[-min(6, len(donemler)):]:
            s = _ews_num(e, d)
            if s is None or s < 700:
                all_high = False
                break
        if all_high and e["son_risk"] and e["son_risk"] > 0:
            persistent.append({
                "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
                "score_last": e["_score_last"],
                "reason": f"Son {min(6, len(donemler))} dönemdir EWS >= 700"
            })
    persistent.sort(key=lambda x: x.get("son_risk", 0), reverse=True)

    low_rising = [e for e in enriched
                  if e["_score_last"] is not None and 0 < e["_score_last"] < 500
                  and e["_delta_3"] is not None and e["_delta_3"] > 100]
    low_rising.sort(key=lambda x: x["_delta_3"], reverse=True)
    low_rising_out = [{
        "muta": e["muta"], "unvan": e.get("unvan"), "son_risk": e["son_risk"],
        "score_last": e["_score_last"], "delta_3": e["_delta_3"],
        "reason": f"Düşük skor ({e['_score_last']}) ama +{e['_delta_3']} artış"
    } for e in low_rising[:50]]

    return {
        "fastest_rising": fastest_out,
        "regime_change": regime,
        "persistent_high": persistent,
        "low_but_rising": low_rising_out,
    }


def run_marts(db_path: Path, output_dir: Path = None):
    """Run all mart builds."""
    con = duckdb.connect(str(db_path))

    if output_dir is None:
        output_dir = Path(db_path).parent.parent / "outputs" / "json"
    output_dir.mkdir(parents=True, exist_ok=True)

    print("  Building scoreboard mart...")
    scoreboard = _build_scoreboard(con)
    n_rows = len(scoreboard.get("rows", []))
    n_periods = len(scoreboard.get("meta", {}).get("donemler", []))
    print(f"    scoreboard: {n_rows} entities, {n_periods} periods")

    scoreboard_path = output_dir / "sample_scoreboard.json"
    with open(scoreboard_path, "w", encoding="utf-8") as f:
        json.dump(scoreboard, f, ensure_ascii=False, indent=2, default=str)
    print(f"    → {scoreboard_path}")

    print("  Building trending lists...")
    trending = _build_trending_lists(con, scoreboard)
    for k, v in trending.items():
        print(f"    {k}: {len(v)} entities")

    trending_path = output_dir / "sample_trending_lists.json"
    with open(trending_path, "w", encoding="utf-8") as f:
        json.dump(trending, f, ensure_ascii=False, indent=2, default=str)
    print(f"    → {trending_path}")

    con.close()
    return scoreboard, trending
