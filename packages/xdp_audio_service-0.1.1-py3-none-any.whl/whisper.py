import numpy as np
from optimum.intel import OVModelForSpeechSeq2Seq
from transformers import AutoProcessor, AutoTokenizer
import librosa
import torch
from pathlib import Path
import json
import time
import logging

class WhisperOVInference:
    def __init__(self, model_path, device="CPU", inference_precision="fp32"):
        """
        初始化OpenVINO Whisper模型

        Args:
            model_path: OpenVINO模型目录路径
            device: 推理设备 (CPU, GPU等)
            inference_precision: 推理精度 ("fp32", "bf16", "fp16")
        """
        self.model_path = Path(model_path)
        self.device = device
        precision = str(inference_precision or "").strip().lower()
        if precision in {"f16", "float16", "half"}:
            precision = "fp16"
        elif precision in {"f32", "float32"}:
            precision = "fp32"
        elif precision in {"bfloat16"}:
            precision = "bf16"
        if not precision:
            precision = "fp32"
        self.inference_precision = precision

        print(f"加载模型从: {model_path}")
        print(f"使用设备: {device}")
        print(f"推理精度: {precision}")

        # 优化的OpenVINO配置
        ov_config = {
            "PERFORMANCE_HINT": "THROUGHPUT",  # 优化吞吐量
            "NUM_STREAMS": "1",  # 单流推理
        }

        # 根据精度设置推理模式
        if precision == "bf16":
            # BF16优化配置
            ov_config["INFERENCE_PRECISION_HINT"] = "bf16"
            # 启用AMX加速
            ov_config["CPU_RUNTIME_CACHE_CAPACITY"] = "0"  # 禁用缓存避免开销
        elif precision == "fp16":
            ov_config["INFERENCE_PRECISION_HINT"] = "fp16"
        else:  # fp32
            ov_config["INFERENCE_PRECISION_HINT"] = "f32"

        print(f"OpenVINO配置: {ov_config}")

        # 本地路径：禁止联网下载（避免误走 HuggingFace）
        local_files_only = self.model_path.exists()

        # OpenVINO 后端需要已导出的 IR 文件（*.xml/*.bin）
        if local_files_only:
            has_ir = any(self.model_path.glob("*.xml")) or any(self.model_path.glob("*/*.xml"))
            if not has_ir:
                raise RuntimeError(
                    "检测到本地模型目录但未找到 OpenVINO IR 文件（*.xml/*.bin）。"
                    "\n当前 whisper.py 使用 optimum-intel 的 OpenVINO 推理，需要先将模型导出为 OpenVINO IR，"
                    "然后把 config 里的 model 指向导出后的目录（通常包含 openvino*.xml）。"
                )
        # 加载模型和处理器
        self.model = OVModelForSpeechSeq2Seq.from_pretrained(
            Path(self.model_path) if local_files_only else model_path,
            device=device,
            ov_config=ov_config,
            local_files_only=local_files_only,
        )
        self.processor = AutoProcessor.from_pretrained(
            Path(self.model_path) if local_files_only else model_path,
            local_files_only=local_files_only,
        )
        self.tokenizer = AutoTokenizer.from_pretrained(
            Path(self.model_path) if local_files_only else model_path,
            local_files_only=local_files_only,
        )

        # 预热模型
        print("预热模型...")
        self._warmup()

    def _warmup(self):
        """预热模型，消除首次推理的冷启动影响"""
        try:
            # 创建假数据预热
            dummy_audio = np.random.randn(16000).astype(np.float32)  # 1秒音频
            dummy_inputs = self.processor(
                dummy_audio,
                sampling_rate=16000,
                return_tensors="pt"
            )

            with torch.no_grad():
                _ = self.model.generate(
                    dummy_inputs.input_features,
                    attention_mask=getattr(dummy_inputs, "attention_mask", None),
                    max_length=10  # 只生成很少的token
                )
            print("预热完成")
        except Exception as e:
            print(f"预热失败 (可忽略): {e}")

    def load_audio(self, audio_path, sr=16000):
        """
        加载音频文件

        Args:
            audio_path: 音频文件路径
            sr: 采样率
        """
        print(f"\n加载音频: {audio_path}")
        audio, _ = librosa.load(audio_path, sr=sr)
        print(f"音频长度: {len(audio)/sr:.2f}秒")
        return audio

    def transcribe(self, audio_path, language="en", task="transcribe", num_runs=3):
        """
        转录音频（多次运行取平均）

        Args:
            audio_path: 音频文件路径
            language: 语言代码 (ar=阿拉伯语)
            task: transcribe 或 translate
            num_runs: 运行次数（取平均时间）
        """
        # 加载音频
        audio = self.load_audio(audio_path)

        # 预处理（只做一次）
        print("预处理音频...")
        inputs = self.processor(
            audio,
            sampling_rate=16000,
            return_tensors="pt"
        )

        # 设置生成参数
        generate_kwargs = {
            "language": language,
            "task": task,
        }

        # 多次推理取平均时间
        print(f"开始推理 (精度: {self.inference_precision}, 运行{num_runs}次)...")
        times = []

        for i in range(num_runs):
            start_time = time.time()

            with torch.no_grad():
                predicted_ids = self.model.generate(
                    inputs.input_features,
                    attention_mask=getattr(inputs, "attention_mask", None),
                    **generate_kwargs
                )

            elapsed = time.time() - start_time
            times.append(elapsed)
            print(f"  第{i+1}次: {elapsed:.3f}秒")

        # 计算平均时间（去掉最快和最慢）
        if num_runs >= 3:
            times_sorted = sorted(times)
            avg_time = sum(times_sorted[1:-1]) / (num_runs - 2)
            print(f"平均时间（去掉极值）: {avg_time:.3f}秒")
        else:
            avg_time = sum(times) / num_runs
            print(f"平均时间: {avg_time:.3f}秒")

        # 解码
        transcription = self.processor.batch_decode(
            predicted_ids,
            skip_special_tokens=True
        )[0]

        return transcription, predicted_ids, avg_time, times

    def transcribe_batch(
        self,
        audio_paths,
        language="en",
        task="transcribe",
        num_runs=3,
        batch_size=8,
    ):
        """Batch transcription over multiple audio files.

        Notes:
        - This performs *true* batch inference by stacking features (with padding)
          and calling `model.generate()` on a tensor with batch dimension.
        - Timing is measured per batch (chunk). Per-file timings are not available
          without running batch=1.

        Returns:
            items: list of {"file": str, "text": str, "token_count": int}
            stats: dict with overall and per-chunk timing information
        """
        if not audio_paths:
            raise ValueError("audio_paths 不能为空")

        if isinstance(audio_paths, (str, Path)):
            audio_paths = [str(audio_paths)]
        else:
            audio_paths = [str(p) for p in list(audio_paths)]

        try:
            bs = int(batch_size) if batch_size is not None else 0
        except Exception:
            bs = 0
        # Auto: pick a conservative batch cap to avoid OOM/padding blowups.
        if bs <= 0:
            bs = min(len(audio_paths), 8)

        def _avg_from_runs(run_times):
            if not run_times:
                return 0.0
            if len(run_times) >= 3:
                times_sorted = sorted(run_times)
                return sum(times_sorted[1:-1]) / (len(run_times) - 2)
            return sum(run_times) / len(run_times)

        all_items = []
        chunks = []
        overall_sum = 0.0
        overall_batches = 0

        for start in range(0, len(audio_paths), bs):
            chunk_paths = audio_paths[start : start + bs]

            audios = [self.load_audio(p) for p in chunk_paths]
            inputs = self.processor(
                audios,
                sampling_rate=16000,
                return_tensors="pt",
                padding=True,
            )

            generate_kwargs = {
                "language": language,
                "task": task,
            }

            run_times = []
            predicted_ids = None
            for _ in range(max(1, int(num_runs))):
                start_time = time.time()
                with torch.no_grad():
                    predicted_ids = self.model.generate(
                        inputs.input_features,
                        attention_mask=getattr(inputs, "attention_mask", None),
                        **generate_kwargs,
                    )
                run_times.append(time.time() - start_time)

            avg_s = _avg_from_runs(run_times)
            overall_sum += float(avg_s)
            overall_batches += 1

            texts = self.processor.batch_decode(
                predicted_ids,
                skip_special_tokens=True,
            )

            # Best-effort token count (generated ids are padded to same length).
            token_counts = []
            pad_id = getattr(self.tokenizer, "pad_token_id", None)
            try:
                if pad_id is not None:
                    for row in predicted_ids:
                        token_counts.append(int((row != pad_id).sum().item()))
                else:
                    token_counts = [int(predicted_ids.shape[-1])] * int(predicted_ids.shape[0])
            except Exception:
                token_counts = [int(predicted_ids.shape[-1])] * len(texts)

            for p, txt, tc in zip(chunk_paths, texts, token_counts):
                all_items.append({"file": str(p), "text": str(txt), "token_count": int(tc)})

            chunks.append(
                {
                    "batch_size": int(len(chunk_paths)),
                    "avg_s": float(avg_s),
                    "times_list": [float(x) for x in run_times],
                    "avg_s_per_file": float(avg_s / max(1, len(chunk_paths))),
                }
            )

        overall_avg_batch_s = float(overall_sum / max(1, overall_batches))
        overall_avg_per_file_s = float(overall_avg_batch_s / max(1, min(bs, len(audio_paths))))

        stats = {
            "num_files": int(len(audio_paths)),
            "batch_size": int(bs),
            "avg_batch_s": overall_avg_batch_s,
            "avg_per_file_s_est": overall_avg_per_file_s,
            "chunks": chunks,
        }
        return all_items, stats


def run_whisper(config, num_runs=1, output_file=None):
    """
    运行Whisper模型的主函数
    
    Args:
        config: 配置字典，包含model, language, task, backend, input等
        num_runs: 运行次数（用于benchmark）
        output_file: 输出文件路径（可选）
    
    Returns:
        dict: 包含转录结果和性能信息的字典
    """
    logger = logging.getLogger(__name__)
    
    try:
        # 从配置中提取参数
        model_path = config.get('model')
        language = config.get('language', 'en')
        task = config.get('task', 'transcribe')
        input_file = config.get('input')
        device = config.get('device', 'CPU')
        inference_precision = config.get('inference_precision', 'fp32')
        
        logger.info(f"运行Whisper模型: {model_path}")
        logger.info(f"输入文件: {input_file}")
        logger.info(f"语言: {language}, 任务: {task}")
        
        # 创建推理实例
        inference = WhisperOVInference(
            model_path=model_path,
            device=device,
            inference_precision=inference_precision
        )
        
        # 执行转录
        transcription, token_ids, avg_time, all_times = inference.transcribe(
            audio_path=input_file,
            language=language,
            task=task,
            num_runs=num_runs
        )
        
        # 准备结果
        result = {
            'transcription': transcription,
            'token_ids': token_ids.tolist(),
            'token_count': token_ids.shape[-1],
            'word_count': len(transcription.split()),
            'avg_inference_time': avg_time,
            'all_times': all_times,
            'min_time': min(all_times),
            'max_time': max(all_times),
            'config': config
        }
        
        # 打印结果
        print("\n" + "="*80)
        print("Whisper 转录结果")
        print("="*80)
        print(f"转录文本: {transcription}")
        print(f"Token数量: {token_ids.shape[-1]}")
        print(f"单词数量: {len(transcription.split())}")
        print(f"平均推理时间: {avg_time:.3f}秒")
        if num_runs > 1:
            print(f"最快时间: {min(all_times):.3f}秒")
            print(f"最慢时间: {max(all_times):.3f}秒")
        print("="*80)
        
        # 保存到文件（如果指定）
        if output_file:
            save_whisper_result(result, output_file)
            logger.info(f"结果已保存到: {output_file}")
        
        return result
        
    except Exception as e:
        logger.error(f"运行Whisper时发生错误: {e}")
        raise


def benchmark_whisper(config, num_runs=5, output_file=None):
    """
    对Whisper模型进行性能基准测试
    
    Args:
        config: 配置字典
        num_runs: 基准测试运行次数
        output_file: 结果保存文件路径
    
    Returns:
        dict: 基准测试结果
    """
    logger = logging.getLogger(__name__)
    logger.info(f"开始Whisper基准测试，运行{num_runs}次")
    
    # 运行基准测试
    result = run_whisper(config, num_runs=num_runs)
    
    # 计算额外的统计信息
    times = result['all_times']
    benchmark_stats = {
        'num_runs': num_runs,
        'avg_time': result['avg_inference_time'],
        'min_time': result['min_time'],
        'max_time': result['max_time'],
        'std_time': np.std(times),
        'median_time': np.median(times),
        'times_list': times
    }
    
    result['benchmark_stats'] = benchmark_stats
    
    # 打印基准测试结果
    print("\n" + "="*80)
    print("Whisper 基准测试结果")
    print("="*80)
    print(f"运行次数: {num_runs}")
    print(f"平均时间: {benchmark_stats['avg_time']:.3f}秒")
    print(f"最快时间: {benchmark_stats['min_time']:.3f}秒")
    print(f"最慢时间: {benchmark_stats['max_time']:.3f}秒")
    print(f"标准差: {benchmark_stats['std_time']:.3f}秒")
    print(f"中位数: {benchmark_stats['median_time']:.3f}秒")
    print("="*80)
    
    # 保存结果
    if output_file:
        save_whisper_result(result, output_file)
        logger.info(f"基准测试结果已保存到: {output_file}")
    
    return result


def compare_whisper_precisions(config, precisions=None, num_runs=3, output_file=None):
    """
    比较不同推理精度的Whisper性能
    
    Args:
        config: 基础配置字典
        precisions: 要比较的精度列表，默认为["fp32", "bf16", "fp16"]
        num_runs: 每个精度的运行次数
        output_file: 结果保存文件路径
    
    Returns:
        dict: 比较结果
    """
    if precisions is None:
        precisions = ["fp32", "bf16", "fp16"]
    
    logger = logging.getLogger(__name__)
    logger.info(f"开始比较Whisper推理精度: {precisions}")
    
    results = {}
    
    for precision in precisions:
        print("\n" + "="*80)
        print(f"使用 {precision.upper()} 推理精度")
        print("="*80)
        
        try:
            # 创建该精度的配置
            precision_config = config.copy()
            precision_config['inference_precision'] = precision
            
            # 创建推理实例
            inference = WhisperOVInference(
                model_path=precision_config['model'],
                device=precision_config.get('device', 'CPU'),
                inference_precision=precision
            )
            
            # 执行推理
            text, token_ids, avg_time, all_times = inference.transcribe(
                audio_path=precision_config['input'],
                language=precision_config.get('language', 'en'),
                task=precision_config.get('task', 'transcribe'),
                num_runs=num_runs
            )
            
            # 保存结果
            results[precision] = {
                "text": text,
                "token_ids": token_ids.tolist(),
                "token_count": token_ids.shape[-1],
                "word_count": len(text.split()),
                "avg_inference_time": avg_time,
                "all_times": all_times,
                "min_time": min(all_times),
                "max_time": max(all_times),
                "supported": True
            }
            
            print("\n转录结果:")
            print("-" * 80)
            print(text)
            print("-" * 80)
            print(f"Token数量: {token_ids.shape[-1]}")
            print(f"单词数量: {len(text.split())}")
            print(f"平均时间: {avg_time:.3f}秒")
            print(f"最快时间: {min(all_times):.3f}秒")
            print(f"最慢时间: {max(all_times):.3f}秒")
            
        except Exception as e:
            print(f"\n⚠️  {precision.upper()} 推理失败: {str(e)}")
            print("错误详情:")
            import traceback
            traceback.print_exc()
            results[precision] = {
                "error": str(e),
                "supported": False
            }
            continue
    
    # 进行对比分析
    comparison_analysis = analyze_precision_comparison(results)
    
    # 组合最终结果
    final_results = {
        'precision_results': results,
        'comparison_analysis': comparison_analysis,
        'config': config,
        'test_parameters': {
            'precisions_tested': precisions,
            'num_runs': num_runs
        }
    }
    
    # 保存结果
    if output_file:
        save_whisper_result(final_results, output_file)
        logger.info(f"精度比较结果已保存到: {output_file}")
    
    return final_results


def analyze_precision_comparison(results):
    """
    分析精度比较结果
    
    Args:
        results: 精度比较的原始结果
    
    Returns:
        dict: 分析结果
    """
    analysis = {}
    
    # 对比分析
    print("\n" + "="*80)
    print("精度对比分析")
    print("="*80)
    
    if "fp32" in results and "bf16" in results:
        fp32_res = results["fp32"]
        bf16_res = results["bf16"]
        
        if fp32_res.get("supported", False) and bf16_res.get("supported", False):
            # 文本对比
            fp32_text = fp32_res["text"]
            bf16_text = bf16_res["text"]
            
            print(f"\n📊 文本长度:")
            print(f"  FP32: {len(fp32_text)} 字符, {fp32_res['word_count']} 单词")
            print(f"  BF16: {len(bf16_text)} 字符, {bf16_res['word_count']} 单词")
            
            # Token对比 - 修改这部分来处理不同长度的token序列
            fp32_tokens = torch.tensor(fp32_res["token_ids"])
            bf16_tokens = torch.tensor(bf16_res["token_ids"])
            
            print(f"\n🔢 Token信息:")
            print(f"  FP32 Token数量: {fp32_tokens.shape[-1]}")
            print(f"  BF16 Token数量: {bf16_tokens.shape[-1]}")
            
            # 处理不同长度的token序列
            token_match = False
            diff_count = 0
            diff_rate = 0
            
            if fp32_tokens.shape[-1] == bf16_tokens.shape[-1]:
                # 长度相同，可以直接比较
                token_match = torch.equal(fp32_tokens, bf16_tokens)
                print(f"  Token完全匹配: {'✅ 是' if token_match else '❌ 否'}")
                
                if not token_match:
                    diff_positions = (fp32_tokens != bf16_tokens).nonzero(as_tuple=True)
                    diff_count = len(diff_positions[0]) if len(diff_positions[0]) > 0 else 0
                    diff_rate = diff_count / fp32_tokens.shape[-1] * 100 if fp32_tokens.shape[-1] > 0 else 0
                    
                    print(f"  不同的token位置数: {diff_count}")
                    print(f"  差异率: {diff_rate:.2f}%")
            else:
                # 长度不同，无法直接比较
                print(f"  Token完全匹配: ❌ 否 (长度不同)")
                
                # 比较公共部分
                min_length = min(fp32_tokens.shape[-1], bf16_tokens.shape[-1])
                if min_length > 0:
                    fp32_common = fp32_tokens[:, :min_length]
                    bf16_common = bf16_tokens[:, :min_length]
                    
                    common_match = torch.equal(fp32_common, bf16_common)
                    print(f"  前{min_length}个Token匹配: {'✅ 是' if common_match else '❌ 否'}")
                    
                    if not common_match:
                        diff_positions = (fp32_common != bf16_common).nonzero(as_tuple=True)
                        diff_count = len(diff_positions[0]) if len(diff_positions[0]) > 0 else 0
                        diff_rate = diff_count / min_length * 100 if min_length > 0 else 0
                        
                        print(f"  公共部分不同token数: {diff_count}")
                        print(f"  公共部分差异率: {diff_rate:.2f}%")
                
                # 显示额外的token
                length_diff = abs(fp32_tokens.shape[-1] - bf16_tokens.shape[-1])
                longer_precision = "FP32" if fp32_tokens.shape[-1] > bf16_tokens.shape[-1] else "BF16"
                print(f"  {longer_precision}额外生成了{length_diff}个token")
            
            # 文本相似度
            fp32_words = set(fp32_text.split())
            bf16_words = set(bf16_text.split())
            
            jaccard_sim = 0
            if len(fp32_words) > 0 or len(bf16_words) > 0:
                common_words = fp32_words & bf16_words
                union_words = fp32_words | bf16_words
                jaccard_sim = len(common_words) / len(union_words) * 100 if len(union_words) > 0 else 0
                
                print(f"\n📝 词汇 Jaccard 相似度: {jaccard_sim:.2f}%")
                print(f"  共同单词: {len(common_words)}")
                print(f"  FP32独有: {len(fp32_words - bf16_words)}")
                print(f"  BF16独有: {len(bf16_words - fp32_words)}")
                
                # 显示独有单词（如果不多的话）
                fp32_unique = fp32_words - bf16_words
                bf16_unique = bf16_words - fp32_words
                
                if len(fp32_unique) <= 10 and len(fp32_unique) > 0:
                    print(f"  FP32独有单词: {list(fp32_unique)}")
                if len(bf16_unique) <= 10 and len(bf16_unique) > 0:
                    print(f"  BF16独有单词: {list(bf16_unique)}")
            
            # 性能对比（使用平均时间）
            print(f"\n⚡ 推理性能 (平均时间):")
            print(f"  FP32: {fp32_res['avg_inference_time']:.3f}秒")
            print(f"  BF16: {bf16_res['avg_inference_time']:.3f}秒")
            
            speedup = 0
            speedup_best = 0
            if fp32_res['avg_inference_time'] > 0:
                speedup = fp32_res['avg_inference_time'] / bf16_res['avg_inference_time']
                if speedup > 1:
                    print(f"  ✅ BF16加速比: {speedup:.2f}x (更快)")
                elif speedup < 1:
                    print(f"  ⚠️  BF16减速比: {speedup:.2f}x (更慢！)")
                    print(f"  减速: {(1-speedup)*100:.1f}%")
                else:
                    print(f"  速度相同")
            
            # 最快时间对比
            print(f"\n⚡ 推理性能 (最快时间):")
            print(f"  FP32: {fp32_res['min_time']:.3f}秒")
            print(f"  BF16: {bf16_res['min_time']:.3f}秒")
            
            if fp32_res['min_time'] > 0:
                speedup_best = fp32_res['min_time'] / bf16_res['min_time']
                print(f"  最佳加速比: {speedup_best:.2f}x")
            
            # 文本差异详情
            text_identical = fp32_text == bf16_text
            if not text_identical:
                print(f"\n📄 文本差异:")
                print(f"  文本完全相同: ❌ 否")
                print(f"\n  FP32文本:")
                print(f"  {fp32_text[:200]}..." if len(fp32_text) > 200 else f"  {fp32_text}")
                print(f"\n  BF16文本:")
                print(f"  {bf16_text[:200]}..." if len(bf16_text) > 200 else f"  {bf16_text}")
                
                # 计算文本编辑距离
                try:
                    from difflib import SequenceMatcher
                    similarity_ratio = SequenceMatcher(None, fp32_text, bf16_text).ratio()
                    print(f"\n  文本相似度 (编辑距离): {similarity_ratio*100:.2f}%")
                except:
                    pass
            else:
                print(f"\n📄 文本完全相同: ✅ 是")
            
            # 保存分析结果
            analysis = {
                "token_match": bool(token_match),
                "token_diff_count": diff_count,
                "token_diff_rate": diff_rate,
                "text_identical": text_identical,
                "jaccard_similarity": jaccard_sim,
                "speedup_avg": speedup,
                "speedup_best": speedup_best,
                "fp32_stats": {
                    "avg_time": fp32_res['avg_inference_time'],
                    "min_time": fp32_res['min_time'],
                    "max_time": fp32_res['max_time'],
                    "word_count": fp32_res['word_count'],
                    "token_count": fp32_res['token_count']
                },
                "bf16_stats": {
                    "avg_time": bf16_res['avg_inference_time'],
                    "min_time": bf16_res['min_time'],
                    "max_time": bf16_res['max_time'],
                    "word_count": bf16_res['word_count'],
                    "token_count": bf16_res['token_count']
                },
                "token_length_match": fp32_tokens.shape[-1] == bf16_tokens.shape[-1]
            }
    
    # 如果有FP16结果，也进行类似的比较
    if "fp16" in results and "fp32" in results:
        fp32_res = results["fp32"]
        fp16_res = results["fp16"]
        
        if fp32_res.get("supported", False) and fp16_res.get("supported", False):
            print(f"\n" + "="*40)
            print("FP32 vs FP16 比较")
            print("="*40)
            
            fp32_text = fp32_res["text"]
            fp16_text = fp16_res["text"]
            
            # 性能比较
            if fp32_res['avg_inference_time'] > 0:
                fp16_speedup = fp32_res['avg_inference_time'] / fp16_res['avg_inference_time']
                print(f"FP16 vs FP32 加速比: {fp16_speedup:.2f}x")
            
            # 文本相似度
            text_match = fp32_text == fp16_text
            print(f"FP32 vs FP16 文本匹配: {'✅ 是' if text_match else '❌ 否'}")
            
            if not text_match:
                try:
                    from difflib import SequenceMatcher
                    similarity_ratio = SequenceMatcher(None, fp32_text, fp16_text).ratio()
                    print(f"FP32 vs FP16 文本相似度: {similarity_ratio*100:.2f}%")
                except:
                    pass
    
    return analysis

def save_whisper_result(result, output_file):
    """
    保存Whisper结果到文件
    
    Args:
        result: 结果字典
        output_file: 输出文件路径
    """
    try:
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"\n💾 结果已保存到: {output_file}")
    except Exception as e:
        print(f"保存结果时发生错误: {e}")


# 为了向后兼容，保留原始函数
def compare_inference_precisions(model_path, audio_path, language="ar", device="CPU", num_runs=3):
    """
    向后兼容的精度比较函数
    """
    config = {
        'model': model_path,
        'input': audio_path,
        'language': language,
        'device': device,
        'task': 'transcribe'
    }
    
    return compare_whisper_precisions(config, num_runs=num_runs, output_file="precision_comparison_results.json")


# 使用示例
if __name__ == "__main__":
    # 示例配置
    config = {
        "model": "whisper-large-v3-fp32-ov",
        "language": "ar",
        "task": "transcribe",
        "backend": "openvino",
        "input": "7184a192e882c87276778a96423a29c6_835.655.wav",
        "device": "CPU",
        "inference_precision": "fp32"
    }
    
    print("="*80)
    print("Whisper OpenVINO 推理测试")
    print("="*80)
    
    # 基本运行
    result = run_whisper(config)
    
    # 基准测试
    # benchmark_result = benchmark_whisper(config, num_runs=5)
    
    # 精度比较
    # comparison_result = compare_whisper_precisions(config, num_runs=3)