import argparse
import sys
import os
import tempfile
import logging
import shutil
import time

from typing import Dict, Any


def parse_args():
    parser = argparse.ArgumentParser(
        description="FireRed ASR Flask Server"
    )
    parser.add_argument(
        "--server",
        action="store_true",
        help="启动 Flask 服务（兼容占位参数）",
    )
    parser.add_argument(
        "--host", default="0.0.0.0", help="服务绑定地址 (默认: 0.0.0.0)"
    )
    parser.add_argument(
        "--port", type=int, default=5001, help="服务端口 (默认: 5001)"
    )
    parser.add_argument(
        "--debug", action="store_true", help="启用 Flask Debug 模式"
    )
    parser.add_argument(
        "--config", default="audio_config.json", help="配置文件路径 (默认: audio_config.json)"
    )
    return parser.parse_args()


def setup_logging(verbose: bool = True):
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


def create_app(config_file: str = "audio_config.json"):
    try:
        from flask import Flask, request, jsonify
    except Exception:
        raise RuntimeError("未安装 Flask。请先安装: pip install Flask")

    from config_manager import ConfigManager

    app = Flask(__name__)
    config_manager = ConfigManager(config_file)
    config_manager.load_config()

    qwen3_aliases = {
        "qwen3_asr_ov",
        "qwen3",
        "qwen3-asr-0.6b-int8_asym-openvino",
        "qwen3-asr-0.6b-int8-asym-openvino",
    }

    def _guess_suffix_from_request() -> str:
        ctype = (request.headers.get("Content-Type") or "").lower()
        if "wav" in ctype:
            return ".wav"
        if "mpeg" in ctype or "mp3" in ctype:
            return ".mp3"
        if "ogg" in ctype:
            return ".ogg"
        if "amr" in ctype:
            return ".amr"
        if "silk" in ctype or "slk" in ctype:
            return ".silk"
        if "pcm" in ctype:
            return ".pcm"
        return ".wav"

    def _save_request_audio_to_temp() -> str:
        """Accept both multipart(file=...) and raw binary request body."""
        if "file" in request.files:
            in_file = request.files["file"]
            if in_file.filename == "":
                raise ValueError("未选择文件")
            suffix = os.path.splitext(in_file.filename)[1] or ".wav"
            fd, tmp_path = tempfile.mkstemp(suffix=suffix)
            os.close(fd)
            in_file.save(tmp_path)
            return tmp_path

        body = request.get_data(cache=False) or b""
        if not body:
            raise ValueError("缺少文件字段 'file' (multipart/form-data) 或原始音频二进制请求体")

        suffix = _guess_suffix_from_request()
        fd, tmp_path = tempfile.mkstemp(suffix=suffix)
        os.close(fd)
        with open(tmp_path, "wb") as f:
            f.write(body)
        return tmp_path

    @app.get("/health")
    def health():
        return jsonify({"status": "ok"})

    @app.get("/models")
    def models():
        models_list = config_manager.get_available_models() if config_manager.config_data else []
        return jsonify({"models": models_list})

    @app.post("/transcribe")
    def transcribe():
        try:
            from flask import request, jsonify

            started_ms = int(time.time() * 1000)

            payload: Dict[str, Any] = {}
            if request.form:
                payload.update(request.form.to_dict())
            if request.is_json:
                payload.update(request.get_json(silent=True) or {})

            raw_model_name = str(payload.get('model') or 'qwen3').strip().lower()
            model_name = 'qwen3_asr_ov' if raw_model_name in qwen3_aliases else raw_model_name
            num_runs = int(payload.get('num_runs') or 1)
            device = payload.get('device')
            precision = payload.get('precision') or payload.get('inference_precision')
            language = payload.get('language')
            task = payload.get('task')
            json_file = payload.get('json_file')

            try:
                tmp_path = _save_request_audio_to_temp()
            except ValueError as ve:
                return jsonify({"success": False, "error": str(ve)}), 400

            if not config_manager.config_data:
                config_manager.load_config()

            base_config = config_manager.get_model_config(model_name) or {}
            base_config = dict(base_config)
            base_config['input'] = tmp_path
            if device:
                base_config['device'] = device
            if precision:
                base_config['inference_precision'] = precision
            if language:
                base_config['language'] = language
            if task:
                base_config['task'] = task
            if model_name == 'fireasr' and json_file:
                base_config['json_file'] = json_file

            # FireRedASR: honor requested precision by mapping to enc/dec types.
            if model_name == 'fireasr' and (precision or base_config.get('inference_precision')):
                req = precision or base_config.get('inference_precision')
                s = str(req or '').strip().lower()
                if s in {'f16', 'fp16', 'float16', 'half'}:
                    s = 'fp16'
                elif s in {'f32', 'fp32', 'float32'}:
                    s = 'fp32'
                elif s in {'bf16', 'bfloat16'}:
                    s = 'bf16'
                if s in {'bf16', 'fp16', 'fp32'}:
                    base_config['enc_type'] = s
                    base_config['dec_type'] = s

            try:
                if model_name == 'whisper':
                    from whisper import run_whisper
                    result = run_whisper(base_config, num_runs=max(1, num_runs))
                    transcription = result.get('transcription')
                    data = {
                        "success": True,
                        "model": model_name,
                        "transcription": transcription,
                        "text": transcription,
                        "avg_inference_time": result.get('avg_inference_time'),
                        "token_count": result.get('token_count'),
                        "config": {k: base_config.get(k) for k in ["model", "language", "task", "device", "inference_precision"]},
                        "elapsed_ms": int(time.time() * 1000) - started_ms,
                    }
                    return jsonify(data)
                elif model_name == 'fireasr':
                    from firered_asr import run_fireasr
                    # Keep server runs clean: use temp output dir for sliced segments.
                    tmp_outdir = tempfile.mkdtemp(prefix="xdp_fireasr_out_")
                    try:
                        base_config = dict(base_config)
                        base_config.setdefault('output_dir', tmp_outdir)
                        result = run_fireasr(base_config, num_runs=max(1, num_runs))
                    finally:
                        try:
                            shutil.rmtree(tmp_outdir, ignore_errors=True)
                        except Exception:
                            pass
                    transcription = result.get('transcription')
                    data = {
                        "success": True,
                        "model": model_name,
                        "transcription": transcription,
                        "text": transcription,
                        "avg_inference_time": result.get('avg_inference_time'),
                        "token_count": None,
                        "num_segments": result.get('num_segments'),
                        "summary": result.get('summary'),
                        "config": {k: base_config.get(k) for k in ["model", "language", "task", "device", "inference_precision", "json_file", "enc_type", "dec_type"]},
                        "elapsed_ms": int(time.time() * 1000) - started_ms,
                    }
                    return jsonify(data)
                elif model_name == 'qwen3_asr_ov':
                    from qwen3_asr_ov import run_qwen3_asr_ov

                    result = run_qwen3_asr_ov(base_config, num_runs=max(1, num_runs))
                    transcription = result.get('transcription')
                    data = {
                        "success": True,
                        "model": model_name,
                        "transcription": transcription,
                        "text": transcription,
                        "avg_inference_time": result.get('avg_inference_time'),
                        "token_count": result.get('token_count'),
                        "config": {k: base_config.get(k) for k in ["model", "language", "task", "device", "inference_precision", "max_new_tokens"]},
                        "elapsed_ms": int(time.time() * 1000) - started_ms,
                    }
                    return jsonify(data)
                else:
                    return jsonify({"success": False, "error": f"不支持的模型: {model_name}"}), 400
            finally:
                try:
                    if os.path.exists(tmp_path):
                        os.remove(tmp_path)
                except Exception:
                    pass
        except Exception as e:
            logging.getLogger(__name__).exception("/transcribe 发生异常")
            from flask import jsonify
            return jsonify({"success": False, "error": str(e)}), 500

    return app


def main():
    args = parse_args()
    setup_logging(verbose=True)

    try:
        app = create_app(config_file=args.config)
    except RuntimeError as e:
        print(str(e))
        print("提示: pip install Flask")
        sys.exit(1)
    except Exception as e:
        print(f"创建应用失败: {e}")
        sys.exit(1)

    print(f"启动 Flask 服务: http://{args.host}:{args.port}")
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
