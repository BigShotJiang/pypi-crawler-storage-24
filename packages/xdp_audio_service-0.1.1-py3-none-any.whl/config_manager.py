import json
import os
from typing import Dict, Any, Optional
import logging

class ConfigManager:
    """配置管理器，负责读取和验证配置文件"""
    
    def __init__(self, config_file: str = "audio_config.json"):
        self.config_file = config_file
        self.config_data = {}
        self.logger = logging.getLogger(__name__)
        
    def load_config(self) -> bool:
        """加载配置文件"""
        try:
            if not os.path.exists(self.config_file):
                self.logger.error(f"配置文件 {self.config_file} 不存在")
                return False
                
            with open(self.config_file, 'r', encoding='utf-8') as f:
                self.config_data = json.load(f)
                
            self.logger.info(f"成功加载配置文件: {self.config_file}")
            return True
            
        except json.JSONDecodeError as e:
            self.logger.error(f"配置文件JSON格式错误: {e}")
            return False
        except Exception as e:
            self.logger.error(f"加载配置文件时发生错误: {e}")
            return False
    
    def get_model_config(self, model_name: str) -> Optional[Dict[str, Any]]:
        """获取指定模型的配置"""
        if not self.config_data:
            self.logger.warning("配置数据为空，请先加载配置文件")
            return None
            
        if model_name not in self.config_data:
            self.logger.error(f"模型 '{model_name}' 在配置文件中不存在")
            return None
            
        config = self.config_data[model_name]
        
        # 验证必要字段
        required_fields = ['model', 'language', 'task', 'backend', 'input']
        missing_fields = [field for field in required_fields if field not in config]
        
        if missing_fields:
            self.logger.error(f"模型 '{model_name}' 配置缺少必要字段: {missing_fields}")
            return None
            
        return config
    
    def get_available_models(self) -> list:
        """获取所有可用的模型名称"""
        return list(self.config_data.keys())
    
    def validate_config(self, model_name: str, config: Dict[str, Any]) -> bool:
        """验证配置的有效性"""
        try:
            # 检查输入文件是否存在
            input_file = config.get('input')
            if input_file and not os.path.exists(input_file):
                self.logger.warning(f"输入文件 {input_file} 不存在")
                
            # TODO：可以添加更多验证逻辑
            # 比如检查语言代码是否有效，后端是否支持等
            
            return True
        except Exception as e:
            self.logger.error(f"验证配置时发生错误: {e}")
            return False