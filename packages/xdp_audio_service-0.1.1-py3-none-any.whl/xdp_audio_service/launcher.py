from __future__ import annotations

import argparse
from importlib import resources
from pathlib import Path
import shutil


def main() -> int:
    from server_main import main as server_main

    server_main()
    return 0


def init_config() -> int:
    parser = argparse.ArgumentParser(description="Write bundled audio_config.example.json to target path")
    parser.add_argument("--output", default="./audio_config.json", help="Target config path")
    parser.add_argument("--force", action="store_true", help="Overwrite existing file")
    args = parser.parse_args()

    target = Path(args.output).expanduser().resolve()
    if target.exists() and not args.force:
        raise SystemExit(f"Refusing to overwrite existing file: {target} (use --force)")

    target.parent.mkdir(parents=True, exist_ok=True)
    with resources.as_file(resources.files("xdp_audio_service") / "audio_config.example.json") as src:
        shutil.copyfile(src, target)

    print(f"Wrote config template: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
