from pathlib import Path
import sys
import os
import tempfile
import shutil
import uuid
import threading
import time


def _ensure_fireredasr_on_syspath() -> None:
    """Ensure the FireRedASR submodule is importable.

    The repository is vendored under `audio/external/FireRedASR`, but that folder
    is not automatically on `sys.path` when running `python main.py` from
    `audio/src`. If `fireredasr` isn't installed as a site package, we add the
    submodule root to `sys.path`.
    """

    submodule_root = Path(__file__).resolve().parents[1] / "external" / "FireRedASR"
    if submodule_root.exists():
        submodule_root_str = str(submodule_root)
        if submodule_root_str not in sys.path:
            sys.path.insert(0, submodule_root_str)


try:
    from fireredasr.models.fireredasr import FireRedAsr
except ModuleNotFoundError:
    _ensure_fireredasr_on_syspath()
    from fireredasr.models.fireredasr import FireRedAsr

import json
from pydub import AudioSegment
import difflib
import logging
import numpy as np


_FIREASR_MODEL_CACHE: dict[tuple[str, int, str, str], FireRedAsr] = {}
_FIREASR_MODEL_CACHE_LOCK = threading.Lock()


def clear_fireasr_model_cache() -> None:
    with _FIREASR_MODEL_CACHE_LOCK:
        _FIREASR_MODEL_CACHE.clear()


def _get_cached_fireasr_model(model_path: str, implement_type: int, enc_type: str, dec_type: str) -> FireRedAsr:
    key = (str(model_path), int(implement_type), str(enc_type), str(dec_type))
    with _FIREASR_MODEL_CACHE_LOCK:
        m = _FIREASR_MODEL_CACHE.get(key)
        if m is not None:
            return m

        logger = logging.getLogger(__name__)
        logger.info("FireRedASR model cache miss; loading model=%s impl=%s enc=%s dec=%s", model_path, implement_type, enc_type, dec_type)
        m = FireRedAsr.from_pretrained("aed", model_path, int(implement_type), str(enc_type), str(dec_type))
        _FIREASR_MODEL_CACHE[key] = m
        return m


def _normalize_fireasr_precision(raw, fallback: str = "bf16") -> str:
    """Normalize precision names for upstream FireRedASR.

    Upstream code expects OpenVINO-style names: 'bf16'/'f16'/'f32'.
    If we pass 'fp16', some FireRedASR code paths skip OV init and later
    crash with missing attributes like 'enc_request'.
    """

    def _map(v: str) -> str:
        vv = (v or "").strip().lower()
        if vv in {"bf16", "f16", "f32"}:
            return vv
        if vv == "fp16":
            return "f16"
        if vv == "fp32":
            return "f32"
        return ""

    mapped = _map(str(raw or ""))
    if mapped:
        return mapped
    mapped_fb = _map(str(fallback or ""))
    if mapped_fb:
        return mapped_fb
    return "bf16"


def _export_wav_pcm16k_mono(audio: AudioSegment, out_path: str) -> None:
    """Export audio as 16kHz mono 16-bit PCM WAV.

    FireRedASR upstream README requires 16kHz 16-bit PCM. Whisper resamples
    internally, but FireRedASR expects properly formatted WAVs.
    """
    a = audio.set_frame_rate(16000).set_channels(1).set_sample_width(2)
    # Force PCM codec for best compatibility.
    a.export(out_path, format="wav", parameters=["-acodec", "pcm_s16le"])


def _make_single_segment_json(audio_path: str, language: str | None = None) -> str:
    audio = AudioSegment.from_file(audio_path)
    duration_s = max(0.0, float(len(audio)) / 1000.0)
    seg_id = f"xdp_{Path(audio_path).stem}_{uuid.uuid4().hex[:8]}"
    payload = {
        "gpu_meta": {
            "vad_results": {
                "segments": [
                    {
                        "segment_wav_id": seg_id,
                        "start_time": "0.000",
                        "end_time": f"{duration_s:.3f}",
                        "segment_duration": duration_s,
                        "language": language or "",
                        "predict_firered_asr_aed_text": "",
                    }
                ]
            }
        }
    }
    fd, tmp_path = tempfile.mkstemp(prefix="xdp_fireasr_segments_", suffix=".json")
    os.close(fd)
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    return tmp_path


def run_fireasr(config, num_runs=1, output_file=None):
    """
    运行FireRedAsr模型的主函数
    
    Args:
        config: 配置字典，包含:
            - model: 模型路径
            - input: 输入音频文件路径
            - json_file: JSON文件路径（可选；未提供会自动生成单段 segments JSON）
            - enc_type: 编码器类型（默认"bf16"）
            - dec_type: 解码器类型（默认"bf16"）
            - output_dir: 输出目录（默认"tests"）
            - decode_config: 解码配置字典（可选，有默认值）
        num_runs: 运行次数（用于benchmark）
        output_file: 输出文件路径（可选）
    
    Returns:
        dict: 包含转录结果和性能信息的字典
    """
    logger = logging.getLogger(__name__)
    
    try:
        # 从配置中提取参数
        model_path = config.get('model')
        input_file_path = config.get('input')
        json_file_path = config.get('json_file')
        implement_type = config.get('implement_type', 1)
        # FireRedASR only supports bf16/fp16 packs in most releases; map fp32 -> bf16.
        requested_precision = config.get('enc_type') or config.get('inference_precision')
        enc_type = _normalize_fireasr_precision(requested_precision, fallback=config.get('enc_type') or 'bf16')
        dec_type = _normalize_fireasr_precision(config.get('dec_type') or requested_precision, fallback=enc_type)
        output_dir = config.get('output_dir', 'tests')
        language = config.get('language')
        
        # 获取解码配置，如果没有提供则使用默认值
        decode_config = config.get('decode_config', {
            "beam_size": 3,
            "nbest": 1,
            "decode_max_len": 0,
            "softmax_smoothing": 1.25,
            "aed_length_penalty": 0.6,
            "eos_penalty": 1.0,
            "decode_min_len": 0,
            "repetition_penalty": 1.0,
            "llm_length_penalty": 0.0,
            "temperature": 1.0
        })
        
        logger.info(f"运行FireRedAsr模型: {model_path}")
        logger.info(f"输入文件: {input_file_path}")
        
        print("="*80)
        print("FireRedAsr 推理")
        print("="*80)
        print(f"模型: {model_path}")
        print(f"编码器: {enc_type}, 解码器: {dec_type}")
        print(f"运行次数: {num_runs}")
        print("="*80)
        
        if not input_file_path:
            raise ValueError("config.input 不能为空")
        if not os.path.exists(input_file_path):
            raise FileNotFoundError(f"找不到输入音频文件: {input_file_path}")

        # 加载JSON（如果没给 json_file，则自动生成一个 single-segment JSON）
        tmp_json_path = None
        if (not json_file_path) or (not os.path.exists(str(json_file_path))):
            tmp_json_path = _make_single_segment_json(input_file_path, language=language)
            json_file_path = tmp_json_path

        with open(json_file_path, 'r', encoding='utf-8') as file:
            inputs = json.load(file)
        audio = AudioSegment.from_file(input_file_path)
        audio_duration_s = max(0.0, float(len(audio)) / 1000.0)
        
        # 初始化模型（使用进程内缓存，避免 benchmark/compare/offline_compare 反复冷启动）
        try:
            impl = int(implement_type)
        except Exception:
            impl = 1
        model = _get_cached_fireasr_model(str(model_path), impl, str(enc_type), str(dec_type))
        models = [[model, f"{enc_type}-{dec_type}"]]
        
        # 获取segments
        try:
            segments = inputs['gpu_meta']['vad_results']['segments']
        except Exception:
            segments = []
        if not segments:
            # fallback: still allow wav-only
            tmp_json_path2 = _make_single_segment_json(input_file_path, language=language)
            if tmp_json_path is None:
                tmp_json_path = tmp_json_path2
                json_file_path = tmp_json_path2
            with open(tmp_json_path2, 'r', encoding='utf-8') as f:
                inputs2 = json.load(f)
            segments = inputs2['gpu_meta']['vad_results']['segments']
        try:
            max_segments = int(config.get('max_segments') or 0)
        except Exception:
            max_segments = 0
        if max_segments > 0:
            segments = segments[:max_segments]
        Path(output_dir).mkdir(exist_ok=True)
        
        # 用于收集结果
        all_results = []
        
        # 对每个segment进行推理
        for i in range(len(segments)):
            batch_uttid = segments[i].get('segment_wav_id') or f"seg_{i}"
            start_time = float(segments[i].get('start_time') or 0.0) * 1000
            end_time = float(segments[i].get('end_time') or (len(audio) / 1000.0)) * 1000
            predict_result = segments[i].get('predict_firered_asr_aed_text') or ""
            batch_wav_path = f"{output_dir}/{batch_uttid}.wav"
            batch_wav_path_ath = Path(batch_wav_path)
            
            if not batch_wav_path_ath.exists():
                sliced_audio = audio[start_time:end_time]
                _export_wav_pcm16k_mono(sliced_audio, batch_wav_path)

            seg_duration_s = max(0.0, float(end_time - start_time) / 1000.0)
            
            # 注意：原始代码这里把变量改成了列表
            batch_uttid_list = [batch_uttid]
            batch_wav_path_list = [batch_wav_path]
            
            rtf = []
            result_text = []
            similarity = []
            rtf_output = ""
            similarity_output = ""
            
            print(f"tid:{i} {batch_uttid_list}\tpredict_result:{predict_result}", flush=True)
            
            # 多次运行（用于benchmark）
            all_rtfs = []
            all_sims = []
            final_text = None
            
            for run_idx in range(num_runs):
                for model, typename in models:
                    results = model.transcribe(
                        batch_uttid_list,
                        batch_wav_path_list,
                        decode_config
                    )
                    
                    current_rtf = results[0]['rtf']
                    current_text = results[0]['text']
                    
                    # 确保RTF是数字类型
                    if isinstance(current_rtf, str):
                        current_rtf = float(current_rtf)
                    all_rtfs.append(current_rtf)
                    final_text = current_text
                    
                    if run_idx == 0:  # 只在第一次运行时打印
                        print(f"infer_mode:{typename}\trtf={current_rtf}, results= {current_text}")
                    
                    # Similarity is only meaningful when reference is provided.
                    sim = None
                    if str(predict_result or "").strip():
                        sim = difflib.SequenceMatcher(None, current_text, predict_result).ratio()
                        all_sims.append(sim)
                        if run_idx == 0:
                            similarity_output += f", {typename}={sim:.2f}"

                    if run_idx == 0:  # 只在第一次运行时添加到输出
                        # 保持原始RTF值的显示（可能是字符串或数字）
                        rtf_output += f", {typename}={results[0]['rtf']}"
            
            # 计算平均值
            avg_rtf = sum(all_rtfs) / len(all_rtfs)
            avg_sim = (sum(all_sims) / len(all_sims)) if all_sims else None

            # Estimated wall time: rtf * segment_audio_seconds
            infer_time_s_est = float(avg_rtf) * float(seg_duration_s)
            
            if str(predict_result or "").strip():
                print(f"tid:{i} {batch_uttid_list}\tsimilarity:{similarity_output}\trtf:{rtf_output}", flush=True)
            else:
                print(f"tid:{i} {batch_uttid_list}\trtf:{rtf_output}", flush=True)
            
            if num_runs > 1:
                if avg_sim is None:
                    print(f"  Average over {num_runs} runs: rtf={avg_rtf:.4f}")
                else:
                    print(f"  Average over {num_runs} runs: rtf={avg_rtf:.4f}, similarity={avg_sim:.4f}")
            
            # 收集结果
            all_results.append({
                'segment_id': i,
                'uttid': batch_uttid,
                'transcription': final_text,
                'reference': predict_result,
                'similarity': avg_sim,
                'rtf': avg_rtf,
                'segment_duration_s': seg_duration_s,
                'inference_time_s_est': infer_time_s_est,
                'all_rtfs': all_rtfs,
                'all_similarities': all_sims
            })
        
        # 计算汇总统计
        valid_sims = [r.get('similarity') for r in all_results if r.get('similarity') is not None]
        avg_similarity = (sum(float(x) for x in valid_sims) / len(valid_sims)) if valid_sims else None
        avg_rtf = sum(r['rtf'] for r in all_results) / len(all_results) if all_results else 0
        total_infer_time_s_est = sum(float(r.get('inference_time_s_est') or 0.0) for r in all_results) if all_results else 0.0
        
        transcription_joined = "".join([
            (r.get('transcription') or "") + ("\n" if idx < (len(all_results) - 1) else "")
            for idx, r in enumerate(all_results)
        ])

        final_result = {
            'config': config,
            'num_segments': len(segments),
            'num_runs': num_runs,
            'results': all_results,
            'transcription': transcription_joined,
            # Whisper-compatible fields (best-effort):
            'avg_inference_time': total_infer_time_s_est,
            'token_count': None,
            'audio_duration_s': audio_duration_s,
            'inference_time_s_est': total_infer_time_s_est,
            'summary': {
                'avg_similarity': avg_similarity,
                'avg_rtf': avg_rtf,
                'audio_duration_s': audio_duration_s,
                'inference_time_s_est': total_infer_time_s_est
            }
        }
        
        print("\n" + "="*80)
        print("推理完成")
        print("="*80)
        print(f"音频片段数量: {len(segments)}")
        if avg_similarity is not None:
            print(f"平均相似度: {avg_similarity:.4f}")
        print(f"平均RTF: {avg_rtf:.4f}")
        print("="*80)
        
        # 保存结果
        if output_file:
            save_result(final_result, output_file)
            logger.info(f"结果已保存到: {output_file}")

        return final_result
    
    except Exception as e:
        logger.error(f"运行FireRedAsr时发生错误: {e}")
        import traceback
        traceback.print_exc()
        raise

    finally:
        # best-effort cleanup for auto-generated json
        try:
            if 'tmp_json_path' in locals() and tmp_json_path and os.path.exists(tmp_json_path):
                os.remove(tmp_json_path)
        except Exception:
            pass


def benchmark_fireasr(config, num_runs=5, output_file=None):
    """
    对FireRedAsr模型进行性能基准测试
    
    Args:
        config: 配置字典
        num_runs: 基准测试运行次数
        output_file: 结果保存文件路径
    
    Returns:
        dict: 基准测试结果
    """
    logger = logging.getLogger(__name__)
    logger.info(f"开始FireRedAsr基准测试，运行{num_runs}次")
    
    print("\n" + "="*80)
    print(f"FireRedAsr 基准测试 (运行{num_runs}次)")
    print("="*80)
    
    # 运行基准测试（默认只跑一个 segment，避免太慢；如需全量请在 config 里显式设置 max_segments）
    bench_cfg = dict(config or {})
    if bench_cfg.get('max_segments') is None:
        bench_cfg['max_segments'] = 1
    result = run_fireasr(bench_cfg, num_runs=num_runs)
    
    # 收集所有RTF和相似度
    all_rtfs = []
    all_similarities = []
    
    for r in result['results']:
        all_rtfs.extend(r['all_rtfs'])
        all_similarities.extend(r['all_similarities'])
    
    # 计算统计信息
    similarity_stats = None
    if all_similarities:
        similarity_stats = {
            'avg': float(np.mean(all_similarities)),
            'min': float(np.min(all_similarities)),
            'max': float(np.max(all_similarities)),
            'std': float(np.std(all_similarities))
        }

    benchmark_stats = {
        'num_runs': num_runs,
        'num_segments': result['num_segments'],
        'total_inferences': len(all_rtfs),
        'rtf_stats': {
            'avg': float(np.mean(all_rtfs)),
            'min': float(np.min(all_rtfs)),
            'max': float(np.max(all_rtfs)),
            'std': float(np.std(all_rtfs)),
            'median': float(np.median(all_rtfs))
        },
        'similarity_stats': similarity_stats
    }
    
    result['benchmark_stats'] = benchmark_stats
    
    # 打印基准测试结果
    print("\n" + "="*80)
    print("基准测试统计")
    print("="*80)
    print(f"运行次数: {num_runs}")
    print(f"音频片段数: {result['num_segments']}")
    print(f"总推理次数: {len(all_rtfs)}")
    print("\nRTF统计:")
    print(f"  平均: {benchmark_stats['rtf_stats']['avg']:.4f}")
    print(f"  最小: {benchmark_stats['rtf_stats']['min']:.4f}")
    print(f"  最大: {benchmark_stats['rtf_stats']['max']:.4f}")
    print(f"  标准差: {benchmark_stats['rtf_stats']['std']:.4f}")
    print(f"  中位数: {benchmark_stats['rtf_stats']['median']:.4f}")
    if benchmark_stats.get('similarity_stats'):
        print("\n相似度统计:")
        print(f"  平均: {benchmark_stats['similarity_stats']['avg']:.4f}")
        print(f"  最小: {benchmark_stats['similarity_stats']['min']:.4f}")
        print(f"  最大: {benchmark_stats['similarity_stats']['max']:.4f}")
    print("="*80)
    
    # 保存结果
    if output_file:
        save_result(result, output_file)
        logger.info(f"基准测试结果已保存到: {output_file}")
    
    return result


def compare_fireasr_precisions(config, precisions=None, num_runs=3, output_file=None):
    """
    比较不同推理精度的FireRedAsr性能
    
    Args:
        config: 基础配置字典
        precisions: 要比较的精度列表，格式为[(enc_type, dec_type), ...]
                   默认为[("bf16", "bf16"), ("fp16", "fp16")]
        num_runs: 每个精度的运行次数
        output_file: 结果保存文件路径
    
    Returns:
        dict: 比较结果
    """
    if precisions is None:
        precisions = [("bf16", "bf16"), ("fp16", "fp16")]
    
    logger = logging.getLogger(__name__)
    logger.info(f"开始比较FireRedAsr推理精度: {precisions}")
    
    print("\n" + "="*80)
    print("FireRedAsr 精度比较")
    print("="*80)
    print(f"比较配置: {precisions}")
    print(f"每个配置运行次数: {num_runs}")
    
    results = {}
    
    for enc_type, dec_type in precisions:
        precision_name = f"{enc_type}-{dec_type}"
        
        print("\n" + "="*80)
        print(f"测试精度: {precision_name.upper()}")
        print("="*80)
        
        try:
            # 创建该精度的配置（默认只跑一个 segment，避免太慢；如需全量请在 config 里显式设置 max_segments）
            precision_config = dict(config or {})
            if precision_config.get('max_segments') is None:
                precision_config['max_segments'] = 1
            precision_config['enc_type'] = enc_type
            precision_config['dec_type'] = dec_type
            
            # 运行推理
            result = run_fireasr(precision_config, num_runs=num_runs)
            
            results[precision_name] = {
                'result': result,
                'supported': True
            }
            
        except Exception as e:
            print(f"\n⚠️ {precision_name.upper()} 推理失败: {str(e)}")
            import traceback
            traceback.print_exc()
            
            results[precision_name] = {
                'error': str(e),
                'supported': False
            }
            continue
    
    # 进行对比分析
    comparison_analysis = analyze_fireasr_comparison(results)
    
    # 组合最终结果
    final_results = {
        'precision_results': results,
        'comparison_analysis': comparison_analysis,
        'config': config,
        'test_parameters': {
            'precisions_tested': precisions,
            'num_runs': num_runs
        }
    }
    
    # 保存结果
    if output_file:
        save_result(final_results, output_file)
        logger.info(f"精度比较结果已保存到: {output_file}")
    
    return final_results


def analyze_fireasr_comparison(results):
    """
    分析精度比较结果
    
    Args:
        results: 精度比较的原始结果
    
    Returns:
        dict: 分析结果
    """
    analysis = {}
    
    # 找到所有支持的精度
    supported_precisions = [k for k, v in results.items() if v.get('supported', False)]
    
    if len(supported_precisions) < 2:
        print("\n没有足够的精度配置可以比较")
        return analysis
    
    print("\n" + "="*80)
    print("精度对比分析")
    print("="*80)

    def _fmt4(v) -> str:
        if v is None:
            return "N/A"
        try:
            return f"{float(v):.4f}"
        except Exception:
            return "N/A"
    
    # 两两比较
    base_precision = supported_precisions[0]
    base_result = results[base_precision]['result']
    
    for compare_precision in supported_precisions[1:]:
        comp_result = results[compare_precision]['result']
        
        print(f"\n比较: {base_precision} vs {compare_precision}")
        print("-"*80)
        
        # RTF对比
        base_rtf = base_result['summary']['avg_rtf']
        comp_rtf = comp_result['summary']['avg_rtf']
        
        print(f"平均RTF:")
        print(f"  {base_precision}: {_fmt4(base_rtf)}")
        print(f"  {compare_precision}: {_fmt4(comp_rtf)}")
        
        speedup = 0
        if base_rtf is not None and comp_rtf is not None:
            try:
                base_rtf_f = float(base_rtf)
                comp_rtf_f = float(comp_rtf)
            except Exception:
                base_rtf_f = 0.0
                comp_rtf_f = 0.0
            if base_rtf_f > 0 and comp_rtf_f > 0:
                speedup = base_rtf_f / comp_rtf_f
            if speedup > 1:
                print(f"  ✅ {compare_precision} 比 {base_precision} 快 {speedup:.2f}x")
            elif speedup < 1:
                print(f"  ⚠️ {compare_precision} 比 {base_precision} 慢 {1/speedup:.2f}x")
            else:
                print(f"  速度相同")
        
        # 相似度对比
        base_sim = base_result['summary']['avg_similarity']
        comp_sim = comp_result['summary']['avg_similarity']
        
        print(f"\n平均相似度:")
        print(f"  {base_precision}: {_fmt4(base_sim)}")
        print(f"  {compare_precision}: {_fmt4(comp_sim)}")
        sim_diff = None
        if base_sim is not None and comp_sim is not None:
            try:
                sim_diff = abs(float(base_sim) - float(comp_sim))
            except Exception:
                sim_diff = None
        print(f"  差异: {_fmt4(sim_diff)}")
        
        analysis[f"{base_precision}_vs_{compare_precision}"] = {
            'base_rtf': base_rtf,
            'comp_rtf': comp_rtf,
            'rtf_speedup': speedup,
            'base_similarity': base_sim,
            'comp_similarity': comp_sim,
            'similarity_diff': sim_diff
        }
    
    return analysis


def save_result(result, output_file):
    """
    保存结果到文件
    
    Args:
        result: 结果字典
        output_file: 输出文件路径
    """
    try:
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"\n💾 结果已保存到: {output_file}")
    except Exception as e:
        print(f"保存结果时发生错误: {e}")


def transcribe_fireasr_files(config: dict, file_paths: list[str], num_runs: int = 1, batch_size: int = 8) -> dict:
    """Transcribe multiple audio files with FireRedASR using true batching.

    This is intended for demo batch endpoints. It avoids JSON/VAD slicing and
    reuses a cached model instance in the current process.
    """

    if not file_paths:
        bs0 = max(1, int(batch_size or 1))
        runs0 = max(1, int(num_runs or 1))
        return {
            "items": [],
            "stats": {
                "requested_batch_size": bs0,
                "effective_batch_size": bs0,
                "batch_size": bs0,
                "num_files": 0,
                "num_runs": runs0,
                "batching_supported": True,
                "batching_note": None,
                "batching_fallback": False,
                "batching_fallback_reason": None,
            },
        }

    model_path = config.get("model")
    if not model_path:
        raise ValueError("config.model 不能为空")

    try:
        impl = int(config.get("implement_type") or 1)
    except Exception:
        impl = 1

    req_prec = config.get("enc_type") or config.get("inference_precision")
    enc_type = _normalize_fireasr_precision(req_prec, fallback=config.get("enc_type") or "bf16")
    dec_type = _normalize_fireasr_precision(config.get("dec_type") or req_prec, fallback=enc_type)

    decode_config = config.get(
        "decode_config",
        {
            "beam_size": 3,
            "nbest": 1,
            "decode_max_len": 0,
            "softmax_smoothing": 1.25,
            "aed_length_penalty": 0.6,
            "eos_penalty": 1.0,
            "decode_min_len": 0,
            "repetition_penalty": 1.0,
            "llm_length_penalty": 0.0,
            "temperature": 1.0,
        },
    )

    requested_bs = max(1, int(batch_size or 1))
    runs = max(1, int(num_runs or 1))

    # Current FireRedASR OpenVINO graphs in this repo frequently fail for batch>1
    # (Concat/shape inference errors in CPU plugin). Treat bs>1 as unsupported and
    # run sequentially to guarantee a result.
    batching_supported = True
    batching_note: str | None = None
    if requested_bs > 1:
        bs = 1
        batching_supported = False
        batching_note = "当前 FireRedASR(OpenVINO) 模型不支持 batch_size>1，将自动降级为 batch_size=1。"
        batching_fallback = True
        batching_fallback_reason = (
            "FireRedASR(OpenVINO) 当前不支持 batch_size>1：已自动降级为 batch_size=1（避免 Concat/shape 推理错误）"
        )
    else:
        bs = requested_bs
        batching_fallback = False
        batching_fallback_reason: str | None = None

    m = _get_cached_fireasr_model(str(model_path), impl, str(enc_type), str(dec_type))

    # Keep stable ordering. FireRedASR prefers 16kHz mono 16-bit PCM WAV.
    # Convert inputs to a temp directory so mixed formats/sample rates don't
    # silently degrade recognition.
    paths_in = [str(p) for p in file_paths]
    tmp_dir = tempfile.mkdtemp(prefix="xdp_fireasr_batchwav_")
    paths: list[str] = []
    orig_by_converted: dict[str, str] = {}
    try:
        for p in paths_in:
            safe = Path(p).name.replace("/", "_").replace("\\", "_")
            out_wav = str(Path(tmp_dir) / (safe if safe.lower().endswith(".wav") else (safe + ".wav")))
            seg = AudioSegment.from_file(p)
            _export_wav_pcm16k_mono(seg, out_wav)
            paths.append(out_wav)
            orig_by_converted[out_wav] = p
    except Exception:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass
        raise

    # Capture text from the first run; collect RTFs across runs.
    text_by_path: dict[str, str] = {p: "" for p in paths}
    tokens_by_path: dict[str, int | None] = {p: None for p in paths}
    rtfs: list[float] = []
    elapsed_list: list[float] = []

    def _run_all(current_bs: int) -> None:
        """Run all requested files for all runs at a given batch size."""
        nonlocal m

        # Reset collectors for a clean measurement.
        rtfs.clear()
        elapsed_list.clear()
        for p in paths:
            text_by_path[p] = ""
            tokens_by_path[p] = None

        for run_idx in range(runs):
            for i in range(0, len(paths), current_bs):
                chunk = paths[i : i + current_bs]
                uttids = [f"b{run_idx}_{j}_{Path(p).stem}" for j, p in enumerate(chunk)]

                t0 = time.time()
                results = m.transcribe(uttids, chunk, decode_config)
                elapsed = time.time() - t0
                elapsed_list.append(float(elapsed))

                # Upstream returns same rtf for all items in the batch.
                if results and isinstance(results, list):
                    rtf0 = results[0].get("rtf")
                    try:
                        rtfs.append(float(rtf0))
                    except Exception:
                        pass

                if run_idx == 0 and results and isinstance(results, list):
                    for r in results:
                        wav = r.get("wav")
                        txt = r.get("text")
                        if wav in text_by_path:
                            text_by_path[wav] = str(txt or "")
                        tok = r.get("tokens")
                        if wav in tokens_by_path and tok is not None:
                            try:
                                tokens_by_path[wav] = int(tok)
                            except Exception:
                                tokens_by_path[wav] = None

    try:
        _run_all(bs)
    except Exception as e:
        # Even with bs=1, OpenVINO can still fail due to runtime issues. Keep the
        # original exception so callers can surface it.
        raise

    items = []
    for p in paths:
        orig = orig_by_converted.get(p, p)
        items.append(
            {
                "file": Path(orig).name,
                "path": orig,
                "text": text_by_path.get(p, ""),
                "token_count": tokens_by_path.get(p),
            }
        )

    avg_rtf = (sum(rtfs) / len(rtfs)) if rtfs else None
    total_elapsed_s = float(sum(elapsed_list)) if elapsed_list else None
    avg_batch_s = (float(sum(elapsed_list)) / len(elapsed_list)) if elapsed_list else None
    avg_per_file_s_est = (float(sum(elapsed_list)) / (len(paths) * runs)) if elapsed_list else None

    out = {
        "items": items,
        "stats": {
            "requested_batch_size": requested_bs,
            "effective_batch_size": bs,
            "batch_size": bs,
            "num_files": len(paths),
            "num_runs": runs,
            "num_batches_per_run": (len(paths) + bs - 1) // bs,
            "avg_batch_s": avg_batch_s,
            "avg_per_file_s_est": avg_per_file_s_est,
            "total_elapsed_s": total_elapsed_s,
            "avg_rtf": avg_rtf,
            "effective_precision": f"{enc_type}-{dec_type}",
            "batching_supported": batching_supported,
            "batching_note": batching_note,
            "batching_fallback": batching_fallback,
            "batching_fallback_reason": batching_fallback_reason,
        },
    }
    try:
        shutil.rmtree(tmp_dir, ignore_errors=True)
    except Exception:
        pass
    return out


# 主函数调用示例
if __name__ == "__main__":
    # 配置日志
    logging.basicConfig(level=logging.INFO)
    
    # 示例配置
    config = {
        "model": "/data1/finetune/asr/wishper/chinese_whisper_model_benchmark/READ-ASR/new_asr/FireRedASR/pretrained_models/FireRedASR-AED-L",
        "input": "/data1/finetune/asr/wishper/FireRedASR.bak/examples/wav/4bR5h-ecBZg-all.wav",
        "json_file": "/data1/finetune/asr/wishper/FireRedASR.bak/examples/wav/testwav.json",
        "enc_type": "bf16",
        "dec_type": "bf16",
        "output_dir": "tests"
    }
    
    # 基本运行（与原始代码完全相同的行为）
    result = run_fireasr(config, num_runs=1)
    
    # 基准测试（运行5次）
    # benchmark_result = benchmark_fireasr(config, num_runs=5, output_file="benchmark_results.json")
    
    # 精度比较
    # comparison_result = compare_fireasr_precisions(
    #     config, 
    #     precisions=[("bf16", "bf16"), ("fp16", "fp16")],
    #     num_runs=3,
    #     output_file="precision_comparison_results.json"
    # )