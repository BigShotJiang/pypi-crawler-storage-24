#!/usr/bin/env python3
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, Optional

import librosa
import numpy as np
from openvino import Core
from transformers import AutoTokenizer, WhisperFeatureExtractor


def _build_prompt_ids(tokenizer, chat_template: str, audio_path: Path) -> np.ndarray:
    messages = [
        {
            "role": "system",
            "content": "You are a speech recognition assistant. Return only transcription text.",
        },
        {
            "role": "user",
            "content": [{"type": "audio", "audio": str(audio_path)}],
        },
    ]
    ids = tokenizer.apply_chat_template(
        messages,
        chat_template=chat_template,
        add_generation_prompt=True,
        return_tensors="np",
    )
    return ids.astype(np.int64)


def _clean_asr_text(text: str) -> str:
    out = (text or "").strip()
    marker = "<asr_text>"
    if marker in out:
        out = out.split(marker, 1)[1].strip()
    return out


def _run_single(model_dir: Path, audio_path: Path, device: str, max_new_tokens: int) -> tuple[str, list[int]]:
    chat_template = json.loads((model_dir / "chat_template.json").read_text(encoding="utf-8"))["chat_template"]

    core = Core()
    audio_encoder = core.compile_model(str(model_dir / "audio_encoder_model.xml"), device)
    thinker_embeddings = core.compile_model(str(model_dir / "thinker_embeddings_model.xml"), device)
    decoder = core.compile_model(str(model_dir / "decoder_model.xml"), device)
    decoder_request = decoder.create_infer_request()
    decoder_request.reset_state()

    tokenizer = AutoTokenizer.from_pretrained(model_dir, trust_remote_code=True, fix_mistral_regex=True)
    feature_extractor = WhisperFeatureExtractor.from_pretrained(model_dir)

    audio, _ = librosa.load(str(audio_path), sr=16000, mono=True)
    input_features = feature_extractor(audio, sampling_rate=16000, return_tensors="np").input_features.astype(np.float32)

    audio_hidden_states = audio_encoder({"mel": input_features})[audio_encoder.output(0)]

    prompt_ids = _build_prompt_ids(tokenizer, chat_template, audio_path)
    audio_pad_id = tokenizer.convert_tokens_to_ids("<|audio_pad|>")
    audio_pad_pos = np.where(prompt_ids[0] == audio_pad_id)[0]
    if len(audio_pad_pos) != 1:
        raise RuntimeError(f"Expected exactly one <|audio_pad|> token, found {len(audio_pad_pos)}")

    split_idx = int(audio_pad_pos[0])
    left_emb = thinker_embeddings({"input_ids": prompt_ids[:, :split_idx]})[thinker_embeddings.output(0)]
    right_emb = thinker_embeddings({"input_ids": prompt_ids[:, split_idx + 1:]})[thinker_embeddings.output(0)]
    prompt_embeds = np.concatenate([left_emb, audio_hidden_states, right_emb], axis=1).astype(np.float32)

    position_ids = np.arange(prompt_embeds.shape[1], dtype=np.int64)[None, :]
    decoder_request.infer({"1001": prompt_embeds, "position_ids": position_ids})
    logits = decoder_request.get_output_tensor(0).data
    next_token_id = int(np.argmax(logits[0, -1]))

    generated_ids = [next_token_id]
    cur_pos = prompt_embeds.shape[1]

    stop_ids = {
        tokenizer.eos_token_id,
        tokenizer.convert_tokens_to_ids("<|im_end|>"),
        tokenizer.convert_tokens_to_ids("<|endoftext|>"),
    }
    stop_ids = {tid for tid in stop_ids if tid is not None and tid >= 0}

    for _ in range(max(1, int(max_new_tokens)) - 1):
        if next_token_id in stop_ids:
            break

        token_array = np.array([[next_token_id]], dtype=np.int64)
        token_emb = thinker_embeddings({"input_ids": token_array})[thinker_embeddings.output(0)]
        pos_array = np.array([[cur_pos]], dtype=np.int64)

        decoder_request.infer({"1001": token_emb.astype(np.float32), "position_ids": pos_array})
        logits = decoder_request.get_output_tensor(0).data
        next_token_id = int(np.argmax(logits[0, -1]))
        generated_ids.append(next_token_id)
        cur_pos += 1

    raw_text = tokenizer.decode(generated_ids, skip_special_tokens=True)
    return _clean_asr_text(raw_text), generated_ids


def run_qwen3_asr_ov(config: Dict[str, Any], num_runs: int = 1, output_file: Optional[str] = None) -> Dict[str, Any]:
    logger = logging.getLogger(__name__)

    model_dir = Path(str(config.get("model") or "")).expanduser().resolve()
    audio_path = Path(str(config.get("input") or "")).expanduser().resolve()
    device = str(config.get("device") or "CPU")
    max_new_tokens = int(config.get("max_new_tokens") or 256)

    if not model_dir.exists():
        raise FileNotFoundError(f"Model dir not found: {model_dir}")
    if not audio_path.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    runs = max(1, int(num_runs))
    times: list[float] = []
    text = ""
    token_ids: list[int] = []

    for _ in range(runs):
        t0 = time.perf_counter()
        text, token_ids = _run_single(model_dir, audio_path, device, max_new_tokens)
        t1 = time.perf_counter()
        times.append(float(t1 - t0))

    result = {
        "transcription": text,
        "token_ids": token_ids,
        "token_count": len(token_ids),
        "word_count": len(str(text).split()),
        "avg_inference_time": float(sum(times) / len(times)) if times else None,
        "all_times": times,
        "min_time": min(times) if times else None,
        "max_time": max(times) if times else None,
        "config": config,
    }

    if output_file:
        out = Path(output_file)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        logger.info("结果已保存到: %s", output_file)

    return result


def benchmark_qwen3_asr_ov(config: Dict[str, Any], num_runs: int = 5, output_file: Optional[str] = None) -> Dict[str, Any]:
    result = run_qwen3_asr_ov(config, num_runs=max(1, int(num_runs)), output_file=None)
    stats = {
        "num_runs": max(1, int(num_runs)),
        "avg_time": result.get("avg_inference_time"),
        "min_time": result.get("min_time"),
        "max_time": result.get("max_time"),
    }
    result["benchmark_stats"] = stats
    if output_file:
        out = Path(output_file)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def compare_qwen3_asr_ov_precisions(
    config: Dict[str, Any],
    precisions: Optional[list[str]] = None,
    num_runs: int = 3,
    output_file: Optional[str] = None,
) -> Dict[str, Any]:
    # The provided model is a fixed INT8 OpenVINO graph; precision switching is not applicable.
    result = run_qwen3_asr_ov(config, num_runs=max(1, int(num_runs)), output_file=None)
    final = {
        "precision_results": {
            "int8_fixed": {
                "supported": True,
                "result": result,
                "note": "Qwen3-ASR-0.6B-INT8_ASYM-OpenVINO is fixed INT8; precision compare is skipped.",
            }
        },
        "comparison_analysis": {},
        "config": config,
        "test_parameters": {
            "precisions_tested": precisions or ["int8_fixed"],
            "num_runs": max(1, int(num_runs)),
        },
    }
    if output_file:
        out = Path(output_file)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(final, ensure_ascii=False, indent=2), encoding="utf-8")
    return final
