# mathlib2

A math library.

## Installation

```bash
pip install mathlib2
```

## Usage

```python
import mathlib2
```

## License

MIT
