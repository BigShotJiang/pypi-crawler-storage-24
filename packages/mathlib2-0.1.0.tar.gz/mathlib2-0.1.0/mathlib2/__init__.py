"""mathlib2 - A math library."""

from mathlib2.core import main

__all__ = ["main"]
