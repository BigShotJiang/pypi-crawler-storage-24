from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.send_portal_invitation_response_200 import SendPortalInvitationResponse200
from ...types import Response


def _get_kwargs(
    end_user_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/end-users/{end_user_id}/invite".format(
            end_user_id=quote(str(end_user_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | SendPortalInvitationResponse200 | None:
    if response.status_code == 200:
        response_200 = SendPortalInvitationResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | SendPortalInvitationResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    end_user_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Error | SendPortalInvitationResponse200]:
    """Send portal invitation email

     **Enterprise feature.**

    Send a portal invitation email to the end user with a 30-day authentication link. The end user must
    have an email address configured.

    Args:
        end_user_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | SendPortalInvitationResponse200]
    """

    kwargs = _get_kwargs(
        end_user_id=end_user_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    end_user_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Error | SendPortalInvitationResponse200 | None:
    """Send portal invitation email

     **Enterprise feature.**

    Send a portal invitation email to the end user with a 30-day authentication link. The end user must
    have an email address configured.

    Args:
        end_user_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | SendPortalInvitationResponse200
    """

    return sync_detailed(
        end_user_id=end_user_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    end_user_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Error | SendPortalInvitationResponse200]:
    """Send portal invitation email

     **Enterprise feature.**

    Send a portal invitation email to the end user with a 30-day authentication link. The end user must
    have an email address configured.

    Args:
        end_user_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | SendPortalInvitationResponse200]
    """

    kwargs = _get_kwargs(
        end_user_id=end_user_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    end_user_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Error | SendPortalInvitationResponse200 | None:
    """Send portal invitation email

     **Enterprise feature.**

    Send a portal invitation email to the end user with a 30-day authentication link. The end user must
    have an email address configured.

    Args:
        end_user_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | SendPortalInvitationResponse200
    """

    return (
        await asyncio_detailed(
            end_user_id=end_user_id,
            client=client,
        )
    ).parsed
