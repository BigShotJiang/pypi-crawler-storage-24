from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_end_user_body import CreateEndUserBody
from ...models.create_end_user_response_201 import CreateEndUserResponse201
from ...models.error import Error
from ...types import Response


def _get_kwargs(
    *,
    body: CreateEndUserBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/end-users",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateEndUserResponse201 | Error | None:
    if response.status_code == 201:
        response_201 = CreateEndUserResponse201.from_dict(response.json())

        return response_201

    if response.status_code == 409:
        response_409 = Error.from_dict(response.json())

        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateEndUserResponse201 | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateEndUserBody,
) -> Response[CreateEndUserResponse201 | Error]:
    """Create end user

     **Enterprise feature.**

    Create a new end user. An API key is automatically generated and returned in the response.
    Returns 409 if an end user with the same externalId already exists.

    Args:
        body (CreateEndUserBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateEndUserResponse201 | Error]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateEndUserBody,
) -> CreateEndUserResponse201 | Error | None:
    """Create end user

     **Enterprise feature.**

    Create a new end user. An API key is automatically generated and returned in the response.
    Returns 409 if an end user with the same externalId already exists.

    Args:
        body (CreateEndUserBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateEndUserResponse201 | Error
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateEndUserBody,
) -> Response[CreateEndUserResponse201 | Error]:
    """Create end user

     **Enterprise feature.**

    Create a new end user. An API key is automatically generated and returned in the response.
    Returns 409 if an end user with the same externalId already exists.

    Args:
        body (CreateEndUserBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateEndUserResponse201 | Error]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateEndUserBody,
) -> CreateEndUserResponse201 | Error | None:
    """Create end user

     **Enterprise feature.**

    Create a new end user. An API key is automatically generated and returned in the response.
    Returns 409 if an end user with the same externalId already exists.

    Args:
        body (CreateEndUserBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateEndUserResponse201 | Error
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
