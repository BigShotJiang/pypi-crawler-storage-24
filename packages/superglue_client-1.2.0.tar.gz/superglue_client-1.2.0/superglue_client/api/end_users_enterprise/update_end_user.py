from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.update_end_user_body import UpdateEndUserBody
from ...models.update_end_user_response_200 import UpdateEndUserResponse200
from ...types import Response


def _get_kwargs(
    end_user_id: UUID,
    *,
    body: UpdateEndUserBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/end-users/{end_user_id}".format(
            end_user_id=quote(str(end_user_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | UpdateEndUserResponse200 | None:
    if response.status_code == 200:
        response_200 = UpdateEndUserResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | UpdateEndUserResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    end_user_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateEndUserBody,
) -> Response[Error | UpdateEndUserResponse200]:
    """Update end user

     **Enterprise feature.**

    Update an existing end user. Only provided fields will be updated.

    Args:
        end_user_id (UUID):
        body (UpdateEndUserBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | UpdateEndUserResponse200]
    """

    kwargs = _get_kwargs(
        end_user_id=end_user_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    end_user_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateEndUserBody,
) -> Error | UpdateEndUserResponse200 | None:
    """Update end user

     **Enterprise feature.**

    Update an existing end user. Only provided fields will be updated.

    Args:
        end_user_id (UUID):
        body (UpdateEndUserBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | UpdateEndUserResponse200
    """

    return sync_detailed(
        end_user_id=end_user_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    end_user_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateEndUserBody,
) -> Response[Error | UpdateEndUserResponse200]:
    """Update end user

     **Enterprise feature.**

    Update an existing end user. Only provided fields will be updated.

    Args:
        end_user_id (UUID):
        body (UpdateEndUserBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | UpdateEndUserResponse200]
    """

    kwargs = _get_kwargs(
        end_user_id=end_user_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    end_user_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateEndUserBody,
) -> Error | UpdateEndUserResponse200 | None:
    """Update end user

     **Enterprise feature.**

    Update an existing end user. Only provided fields will be updated.

    Args:
        end_user_id (UUID):
        body (UpdateEndUserBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | UpdateEndUserResponse200
    """

    return (
        await asyncio_detailed(
            end_user_id=end_user_id,
            client=client,
            body=body,
        )
    ).parsed
