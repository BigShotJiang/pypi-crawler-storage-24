from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.trigger_webhook_body import TriggerWebhookBody
from ...models.trigger_webhook_mode import TriggerWebhookMode
from ...models.trigger_webhook_response_202 import TriggerWebhookResponse202
from ...types import UNSET, Response, Unset


def _get_kwargs(
    tool_id: str,
    *,
    body: TriggerWebhookBody | Unset = UNSET,
    mode: TriggerWebhookMode | Unset = TriggerWebhookMode.PROD,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_mode: str | Unset = UNSET
    if not isinstance(mode, Unset):
        json_mode = mode.value

    params["mode"] = json_mode

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/hooks/{tool_id}".format(
            tool_id=quote(str(tool_id), safe=""),
        ),
        "params": params,
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | TriggerWebhookResponse202 | None:
    if response.status_code == 202:
        response_202 = TriggerWebhookResponse202.from_dict(response.json())

        return response_202

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | TriggerWebhookResponse202]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    tool_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: TriggerWebhookBody | Unset = UNSET,
    mode: TriggerWebhookMode | Unset = TriggerWebhookMode.PROD,
) -> Response[Error | TriggerWebhookResponse202]:
    r"""Handle incoming webhook

     **Enterprise feature.**

    Trigger a tool execution from an external webhook (Stripe, GitHub, etc.).

    The request body becomes the tool's input payload.
    Returns 202 Accepted immediately and executes the tool asynchronously.

    Also handles webhook challenge/verification patterns inline:
    - **monday.com, Slack:** POST body `{ challenge: \"...\" }` → echoes challenge as JSON
    - **Generic:** POST body `{ verification_token: \"...\", type: \"verification\" }` → echoes token as
    JSON

    Args:
        tool_id (str):
        mode (TriggerWebhookMode | Unset):  Default: TriggerWebhookMode.PROD.
        body (TriggerWebhookBody | Unset):  Example: {'id': 'evt_1234', 'type':
            'customer.created', 'data': {'object': {'id': 'cus_abc123', 'email':
            'user@example.com'}}}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | TriggerWebhookResponse202]
    """

    kwargs = _get_kwargs(
        tool_id=tool_id,
        body=body,
        mode=mode,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    tool_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: TriggerWebhookBody | Unset = UNSET,
    mode: TriggerWebhookMode | Unset = TriggerWebhookMode.PROD,
) -> Error | TriggerWebhookResponse202 | None:
    r"""Handle incoming webhook

     **Enterprise feature.**

    Trigger a tool execution from an external webhook (Stripe, GitHub, etc.).

    The request body becomes the tool's input payload.
    Returns 202 Accepted immediately and executes the tool asynchronously.

    Also handles webhook challenge/verification patterns inline:
    - **monday.com, Slack:** POST body `{ challenge: \"...\" }` → echoes challenge as JSON
    - **Generic:** POST body `{ verification_token: \"...\", type: \"verification\" }` → echoes token as
    JSON

    Args:
        tool_id (str):
        mode (TriggerWebhookMode | Unset):  Default: TriggerWebhookMode.PROD.
        body (TriggerWebhookBody | Unset):  Example: {'id': 'evt_1234', 'type':
            'customer.created', 'data': {'object': {'id': 'cus_abc123', 'email':
            'user@example.com'}}}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | TriggerWebhookResponse202
    """

    return sync_detailed(
        tool_id=tool_id,
        client=client,
        body=body,
        mode=mode,
    ).parsed


async def asyncio_detailed(
    tool_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: TriggerWebhookBody | Unset = UNSET,
    mode: TriggerWebhookMode | Unset = TriggerWebhookMode.PROD,
) -> Response[Error | TriggerWebhookResponse202]:
    r"""Handle incoming webhook

     **Enterprise feature.**

    Trigger a tool execution from an external webhook (Stripe, GitHub, etc.).

    The request body becomes the tool's input payload.
    Returns 202 Accepted immediately and executes the tool asynchronously.

    Also handles webhook challenge/verification patterns inline:
    - **monday.com, Slack:** POST body `{ challenge: \"...\" }` → echoes challenge as JSON
    - **Generic:** POST body `{ verification_token: \"...\", type: \"verification\" }` → echoes token as
    JSON

    Args:
        tool_id (str):
        mode (TriggerWebhookMode | Unset):  Default: TriggerWebhookMode.PROD.
        body (TriggerWebhookBody | Unset):  Example: {'id': 'evt_1234', 'type':
            'customer.created', 'data': {'object': {'id': 'cus_abc123', 'email':
            'user@example.com'}}}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | TriggerWebhookResponse202]
    """

    kwargs = _get_kwargs(
        tool_id=tool_id,
        body=body,
        mode=mode,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    tool_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: TriggerWebhookBody | Unset = UNSET,
    mode: TriggerWebhookMode | Unset = TriggerWebhookMode.PROD,
) -> Error | TriggerWebhookResponse202 | None:
    r"""Handle incoming webhook

     **Enterprise feature.**

    Trigger a tool execution from an external webhook (Stripe, GitHub, etc.).

    The request body becomes the tool's input payload.
    Returns 202 Accepted immediately and executes the tool asynchronously.

    Also handles webhook challenge/verification patterns inline:
    - **monday.com, Slack:** POST body `{ challenge: \"...\" }` → echoes challenge as JSON
    - **Generic:** POST body `{ verification_token: \"...\", type: \"verification\" }` → echoes token as
    JSON

    Args:
        tool_id (str):
        mode (TriggerWebhookMode | Unset):  Default: TriggerWebhookMode.PROD.
        body (TriggerWebhookBody | Unset):  Example: {'id': 'evt_1234', 'type':
            'customer.created', 'data': {'object': {'id': 'cus_abc123', 'email':
            'user@example.com'}}}.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | TriggerWebhookResponse202
    """

    return (
        await asyncio_detailed(
            tool_id=tool_id,
            client=client,
            body=body,
            mode=mode,
        )
    ).parsed
