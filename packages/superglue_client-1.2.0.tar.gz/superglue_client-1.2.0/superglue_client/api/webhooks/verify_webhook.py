from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...types import Response


def _get_kwargs(
    tool_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/hooks/{tool_id}".format(
            tool_id=quote(str(tool_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if response.status_code == 405:
        response_405 = Error.from_dict(response.json())

        return response_405

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Error | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    tool_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Error | str]:
    """Handle webhook challenge verification

     **Enterprise feature.**

    Handle webhook challenge/verification requests from external services.
    GET requests are only supported for challenge verification (not tool execution).

    Supported challenge patterns:
    - **Meta/Facebook/WhatsApp:** `?hub.mode=subscribe&hub.challenge=...` → echoes challenge as plain
    text
    - **Microsoft Graph:** `?validationToken=...` → echoes token as plain text
    - **Nylas/generic:** `?challenge=...` → echoes challenge as plain text

    Args:
        tool_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | str]
    """

    kwargs = _get_kwargs(
        tool_id=tool_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    tool_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Error | str | None:
    """Handle webhook challenge verification

     **Enterprise feature.**

    Handle webhook challenge/verification requests from external services.
    GET requests are only supported for challenge verification (not tool execution).

    Supported challenge patterns:
    - **Meta/Facebook/WhatsApp:** `?hub.mode=subscribe&hub.challenge=...` → echoes challenge as plain
    text
    - **Microsoft Graph:** `?validationToken=...` → echoes token as plain text
    - **Nylas/generic:** `?challenge=...` → echoes challenge as plain text

    Args:
        tool_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | str
    """

    return sync_detailed(
        tool_id=tool_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    tool_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Error | str]:
    """Handle webhook challenge verification

     **Enterprise feature.**

    Handle webhook challenge/verification requests from external services.
    GET requests are only supported for challenge verification (not tool execution).

    Supported challenge patterns:
    - **Meta/Facebook/WhatsApp:** `?hub.mode=subscribe&hub.challenge=...` → echoes challenge as plain
    text
    - **Microsoft Graph:** `?validationToken=...` → echoes token as plain text
    - **Nylas/generic:** `?challenge=...` → echoes challenge as plain text

    Args:
        tool_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | str]
    """

    kwargs = _get_kwargs(
        tool_id=tool_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    tool_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Error | str | None:
    """Handle webhook challenge verification

     **Enterprise feature.**

    Handle webhook challenge/verification requests from external services.
    GET requests are only supported for challenge verification (not tool execution).

    Supported challenge patterns:
    - **Meta/Facebook/WhatsApp:** `?hub.mode=subscribe&hub.challenge=...` → echoes challenge as plain
    text
    - **Microsoft Graph:** `?validationToken=...` → echoes token as plain text
    - **Nylas/generic:** `?challenge=...` → echoes challenge as plain text

    Args:
        tool_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | str
    """

    return (
        await asyncio_detailed(
            tool_id=tool_id,
            client=client,
        )
    ).parsed
