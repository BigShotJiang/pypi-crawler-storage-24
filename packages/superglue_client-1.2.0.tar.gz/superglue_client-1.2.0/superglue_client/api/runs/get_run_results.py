from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.get_run_results_response_200 import GetRunResultsResponse200
from ...models.get_run_results_truncate import GetRunResultsTruncate
from ...types import UNSET, Response, Unset


def _get_kwargs(
    run_id: str,
    *,
    truncate: GetRunResultsTruncate | Unset = GetRunResultsTruncate.FALSE,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_truncate: str | Unset = UNSET
    if not isinstance(truncate, Unset):
        json_truncate = truncate.value

    params["truncate"] = json_truncate

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/runs/{run_id}/results".format(
            run_id=quote(str(run_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | GetRunResultsResponse200 | None:
    if response.status_code == 200:
        response_200 = GetRunResultsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if response.status_code == 503:
        response_503 = Error.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | GetRunResultsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    run_id: str,
    *,
    client: AuthenticatedClient | Client,
    truncate: GetRunResultsTruncate | Unset = GetRunResultsTruncate.FALSE,
) -> Response[Error | GetRunResultsResponse200]:
    """Get full run results

     **Enterprise feature.**

    Fetch the full (non-truncated) results for a run from storage.
    Returns null data if run result storage is not enabled.

    Args:
        run_id (str):
        truncate (GetRunResultsTruncate | Unset):  Default: GetRunResultsTruncate.FALSE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | GetRunResultsResponse200]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        truncate=truncate,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    run_id: str,
    *,
    client: AuthenticatedClient | Client,
    truncate: GetRunResultsTruncate | Unset = GetRunResultsTruncate.FALSE,
) -> Error | GetRunResultsResponse200 | None:
    """Get full run results

     **Enterprise feature.**

    Fetch the full (non-truncated) results for a run from storage.
    Returns null data if run result storage is not enabled.

    Args:
        run_id (str):
        truncate (GetRunResultsTruncate | Unset):  Default: GetRunResultsTruncate.FALSE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | GetRunResultsResponse200
    """

    return sync_detailed(
        run_id=run_id,
        client=client,
        truncate=truncate,
    ).parsed


async def asyncio_detailed(
    run_id: str,
    *,
    client: AuthenticatedClient | Client,
    truncate: GetRunResultsTruncate | Unset = GetRunResultsTruncate.FALSE,
) -> Response[Error | GetRunResultsResponse200]:
    """Get full run results

     **Enterprise feature.**

    Fetch the full (non-truncated) results for a run from storage.
    Returns null data if run result storage is not enabled.

    Args:
        run_id (str):
        truncate (GetRunResultsTruncate | Unset):  Default: GetRunResultsTruncate.FALSE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | GetRunResultsResponse200]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        truncate=truncate,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    run_id: str,
    *,
    client: AuthenticatedClient | Client,
    truncate: GetRunResultsTruncate | Unset = GetRunResultsTruncate.FALSE,
) -> Error | GetRunResultsResponse200 | None:
    """Get full run results

     **Enterprise feature.**

    Fetch the full (non-truncated) results for a run from storage.
    Returns null data if run result storage is not enabled.

    Args:
        run_id (str):
        truncate (GetRunResultsTruncate | Unset):  Default: GetRunResultsTruncate.FALSE.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | GetRunResultsResponse200
    """

    return (
        await asyncio_detailed(
            run_id=run_id,
            client=client,
            truncate=truncate,
        )
    ).parsed
