from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.run_request_options_mode import RunRequestOptionsMode
from ..models.run_request_options_request_source import RunRequestOptionsRequestSource
from ..types import UNSET, Unset

T = TypeVar("T", bound="RunRequestOptions")


@_attrs_define
class RunRequestOptions:
    """
    Attributes:
        async_ (bool | Unset): If true, return immediately (202) and execute asynchronously. If false, wait for
            completion (200). Default: False.
        timeout (int | Unset): Request timeout in milliseconds Default: 60000.
        webhook_url (str | Unset): Callback URL or tool chain trigger when the run finishes. Supports two formats:

            **HTTP webhook (notify external service):**
            Standard URL (e.g., `https://your-app.com/webhooks/superglue`).
            Receives a POST request with the Run object in the body.

            **Tool chain (trigger another tool):**
            Use `tool:{toolId}` format (e.g., `tool:process-results`).
            Automatically triggers the specified tool with the current tool's output as its input payload.
            The chained tool run will have `requestSource: "tool-chain"`.

            Tool chaining enables building multi-tool workflows where one tool's output feeds into another.
             Example: https://your-app.com/webhooks/superglue.
        mode (RunRequestOptionsMode | Unset): Execution mode for system resolution. Controls which system credentials
            are used:
            - prod: Uses production system credentials (default)
            - dev: Uses development/sandbox system credentials
             Default: RunRequestOptionsMode.PROD. Example: prod.
        request_source (RunRequestOptionsRequestSource | Unset): Override the request source identifier. Only
            "frontend", "mcp", and "cli" are honored;
            other values are derived from the request context.
             Example: frontend.
        trace_id (str | Unset): Custom trace ID for log tracking Example: a1b2c3d4-e5f6-7890-abcd-ef1234567890.
    """

    async_: bool | Unset = False
    timeout: int | Unset = 60000
    webhook_url: str | Unset = UNSET
    mode: RunRequestOptionsMode | Unset = RunRequestOptionsMode.PROD
    request_source: RunRequestOptionsRequestSource | Unset = UNSET
    trace_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        async_ = self.async_

        timeout = self.timeout

        webhook_url = self.webhook_url

        mode: str | Unset = UNSET
        if not isinstance(self.mode, Unset):
            mode = self.mode.value

        request_source: str | Unset = UNSET
        if not isinstance(self.request_source, Unset):
            request_source = self.request_source.value

        trace_id = self.trace_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if async_ is not UNSET:
            field_dict["async"] = async_
        if timeout is not UNSET:
            field_dict["timeout"] = timeout
        if webhook_url is not UNSET:
            field_dict["webhookUrl"] = webhook_url
        if mode is not UNSET:
            field_dict["mode"] = mode
        if request_source is not UNSET:
            field_dict["requestSource"] = request_source
        if trace_id is not UNSET:
            field_dict["traceId"] = trace_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        async_ = d.pop("async", UNSET)

        timeout = d.pop("timeout", UNSET)

        webhook_url = d.pop("webhookUrl", UNSET)

        _mode = d.pop("mode", UNSET)
        mode: RunRequestOptionsMode | Unset
        if isinstance(_mode, Unset):
            mode = UNSET
        else:
            mode = RunRequestOptionsMode(_mode)

        _request_source = d.pop("requestSource", UNSET)
        request_source: RunRequestOptionsRequestSource | Unset
        if isinstance(_request_source, Unset):
            request_source = UNSET
        else:
            request_source = RunRequestOptionsRequestSource(_request_source)

        trace_id = d.pop("traceId", UNSET)

        run_request_options = cls(
            async_=async_,
            timeout=timeout,
            webhook_url=webhook_url,
            mode=mode,
            request_source=request_source,
            trace_id=trace_id,
        )

        run_request_options.additional_properties = d
        return run_request_options

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
