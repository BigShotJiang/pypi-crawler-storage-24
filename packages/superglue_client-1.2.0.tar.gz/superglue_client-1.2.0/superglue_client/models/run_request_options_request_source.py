from enum import Enum


class RunRequestOptionsRequestSource(str, Enum):
    CLI = "cli"
    FRONTEND = "frontend"
    MCP = "mcp"

    def __str__(self) -> str:
        return str(self.value)
