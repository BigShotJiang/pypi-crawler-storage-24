from enum import Enum


class RunRequestSource(str, Enum):
    API = "api"
    CLI = "cli"
    FRONTEND = "frontend"
    MCP = "mcp"
    SCHEDULER = "scheduler"
    TOOL_CHAIN = "tool-chain"
    WEBHOOK = "webhook"

    def __str__(self) -> str:
        return str(self.value)
