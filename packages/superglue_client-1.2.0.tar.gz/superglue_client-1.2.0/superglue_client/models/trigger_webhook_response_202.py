from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.trigger_webhook_response_202_status import TriggerWebhookResponse202Status

T = TypeVar("T", bound="TriggerWebhookResponse202")


@_attrs_define
class TriggerWebhookResponse202:
    """
    Attributes:
        run_id (str): ID of the created run Example: 7f3e9c1a-2b4d-4e8f-9a3b-1c5d7e9f2a4b.
        status (TriggerWebhookResponse202Status):  Example: accepted.
        tool_id (str): ID of the triggered tool Example: handle-stripe-webhook.
    """

    run_id: str
    status: TriggerWebhookResponse202Status
    tool_id: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        run_id = self.run_id

        status = self.status.value

        tool_id = self.tool_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "runId": run_id,
                "status": status,
                "toolId": tool_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        run_id = d.pop("runId")

        status = TriggerWebhookResponse202Status(d.pop("status"))

        tool_id = d.pop("toolId")

        trigger_webhook_response_202 = cls(
            run_id=run_id,
            status=status,
            tool_id=tool_id,
        )

        trigger_webhook_response_202.additional_properties = d
        return trigger_webhook_response_202

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
