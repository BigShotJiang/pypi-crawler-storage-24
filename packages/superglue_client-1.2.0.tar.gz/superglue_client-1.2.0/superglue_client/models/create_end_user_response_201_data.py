from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.end_user_metadata import EndUserMetadata


T = TypeVar("T", bound="CreateEndUserResponse201Data")


@_attrs_define
class CreateEndUserResponse201Data:
    """
    Attributes:
        id (UUID): Internal superglue user ID Example: 550e8400-e29b-41d4-a716-446655440000.
        external_id (str): Your application's user ID Example: user-123.
        email (str | Unset):  Example: user@example.com.
        name (str | Unset):  Example: John Doe.
        metadata (EndUserMetadata | Unset): Custom metadata for this user
        allowed_systems (list[str] | Unset): System IDs this user can access, or ["*"] for all systems Example: ['*'].
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        api_key (str | Unset): The API key for this end user (only returned on creation) Example: abc123def456....
    """

    id: UUID
    external_id: str
    email: str | Unset = UNSET
    name: str | Unset = UNSET
    metadata: EndUserMetadata | Unset = UNSET
    allowed_systems: list[str] | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    api_key: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        external_id = self.external_id

        email = self.email

        name = self.name

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        allowed_systems: list[str] | Unset = UNSET
        if not isinstance(self.allowed_systems, Unset):
            allowed_systems = self.allowed_systems

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        api_key = self.api_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "externalId": external_id,
            }
        )
        if email is not UNSET:
            field_dict["email"] = email
        if name is not UNSET:
            field_dict["name"] = name
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if allowed_systems is not UNSET:
            field_dict["allowedSystems"] = allowed_systems
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if api_key is not UNSET:
            field_dict["apiKey"] = api_key

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.end_user_metadata import EndUserMetadata

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        external_id = d.pop("externalId")

        email = d.pop("email", UNSET)

        name = d.pop("name", UNSET)

        _metadata = d.pop("metadata", UNSET)
        metadata: EndUserMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = EndUserMetadata.from_dict(_metadata)

        allowed_systems = cast(list[str], d.pop("allowedSystems", UNSET))

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        api_key = d.pop("apiKey", UNSET)

        create_end_user_response_201_data = cls(
            id=id,
            external_id=external_id,
            email=email,
            name=name,
            metadata=metadata,
            allowed_systems=allowed_systems,
            created_at=created_at,
            updated_at=updated_at,
            api_key=api_key,
        )

        create_end_user_response_201_data.additional_properties = d
        return create_end_user_response_201_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
