from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.run_results_data import RunResultsData
    from ..models.run_results_tool_payload import RunResultsToolPayload
    from ..models.step_result import StepResult


T = TypeVar("T", bound="RunResults")


@_attrs_define
class RunResults:
    """Full (non-truncated) run results fetched from storage

    Attributes:
        run_id (str):  Example: 7f3e9c1a-2b4d-4e8f-9a3b-1c5d7e9f2a4b.
        success (bool):
        data (RunResultsData | Unset): Full tool execution result data
        step_results (list[StepResult] | Unset): Per-step execution results
        tool_payload (RunResultsToolPayload | Unset): The inputs provided when running the tool
        error (str | Unset):
        stored_at (datetime.datetime | Unset):
    """

    run_id: str
    success: bool
    data: RunResultsData | Unset = UNSET
    step_results: list[StepResult] | Unset = UNSET
    tool_payload: RunResultsToolPayload | Unset = UNSET
    error: str | Unset = UNSET
    stored_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        run_id = self.run_id

        success = self.success

        data: dict[str, Any] | Unset = UNSET
        if not isinstance(self.data, Unset):
            data = self.data.to_dict()

        step_results: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.step_results, Unset):
            step_results = []
            for step_results_item_data in self.step_results:
                step_results_item = step_results_item_data.to_dict()
                step_results.append(step_results_item)

        tool_payload: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tool_payload, Unset):
            tool_payload = self.tool_payload.to_dict()

        error = self.error

        stored_at: str | Unset = UNSET
        if not isinstance(self.stored_at, Unset):
            stored_at = self.stored_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "runId": run_id,
                "success": success,
            }
        )
        if data is not UNSET:
            field_dict["data"] = data
        if step_results is not UNSET:
            field_dict["stepResults"] = step_results
        if tool_payload is not UNSET:
            field_dict["toolPayload"] = tool_payload
        if error is not UNSET:
            field_dict["error"] = error
        if stored_at is not UNSET:
            field_dict["storedAt"] = stored_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.run_results_data import RunResultsData
        from ..models.run_results_tool_payload import RunResultsToolPayload
        from ..models.step_result import StepResult

        d = dict(src_dict)
        run_id = d.pop("runId")

        success = d.pop("success")

        _data = d.pop("data", UNSET)
        data: RunResultsData | Unset
        if isinstance(_data, Unset):
            data = UNSET
        else:
            data = RunResultsData.from_dict(_data)

        _step_results = d.pop("stepResults", UNSET)
        step_results: list[StepResult] | Unset = UNSET
        if _step_results is not UNSET:
            step_results = []
            for step_results_item_data in _step_results:
                step_results_item = StepResult.from_dict(step_results_item_data)

                step_results.append(step_results_item)

        _tool_payload = d.pop("toolPayload", UNSET)
        tool_payload: RunResultsToolPayload | Unset
        if isinstance(_tool_payload, Unset):
            tool_payload = UNSET
        else:
            tool_payload = RunResultsToolPayload.from_dict(_tool_payload)

        error = d.pop("error", UNSET)

        _stored_at = d.pop("storedAt", UNSET)
        stored_at: datetime.datetime | Unset
        if isinstance(_stored_at, Unset):
            stored_at = UNSET
        else:
            stored_at = isoparse(_stored_at)

        run_results = cls(
            run_id=run_id,
            success=success,
            data=data,
            step_results=step_results,
            tool_payload=tool_payload,
            error=error,
            stored_at=stored_at,
        )

        run_results.additional_properties = d
        return run_results

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
