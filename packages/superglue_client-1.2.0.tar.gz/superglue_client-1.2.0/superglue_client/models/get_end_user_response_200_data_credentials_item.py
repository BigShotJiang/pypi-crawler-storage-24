from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetEndUserResponse200DataCredentialsItem")


@_attrs_define
class GetEndUserResponse200DataCredentialsItem:
    """
    Attributes:
        system_id (str | Unset):
        system_name (str | Unset):
        has_credentials (bool | Unset):
    """

    system_id: str | Unset = UNSET
    system_name: str | Unset = UNSET
    has_credentials: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        system_id = self.system_id

        system_name = self.system_name

        has_credentials = self.has_credentials

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if system_id is not UNSET:
            field_dict["systemId"] = system_id
        if system_name is not UNSET:
            field_dict["systemName"] = system_name
        if has_credentials is not UNSET:
            field_dict["hasCredentials"] = has_credentials

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        system_id = d.pop("systemId", UNSET)

        system_name = d.pop("systemName", UNSET)

        has_credentials = d.pop("hasCredentials", UNSET)

        get_end_user_response_200_data_credentials_item = cls(
            system_id=system_id,
            system_name=system_name,
            has_credentials=has_credentials,
        )

        get_end_user_response_200_data_credentials_item.additional_properties = d
        return get_end_user_response_200_data_credentials_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
