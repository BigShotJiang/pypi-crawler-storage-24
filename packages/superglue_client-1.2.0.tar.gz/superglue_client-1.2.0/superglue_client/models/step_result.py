from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.step_result_data import StepResultData


T = TypeVar("T", bound="StepResult")


@_attrs_define
class StepResult:
    """Execution result for a single tool step

    Attributes:
        step_id (str): ID of the step that was executed
        success (bool): Whether the step completed successfully
        data (StepResultData | Unset): Step result data
        error (str | Unset): Error message if the step failed
    """

    step_id: str
    success: bool
    data: StepResultData | Unset = UNSET
    error: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        step_id = self.step_id

        success = self.success

        data: dict[str, Any] | Unset = UNSET
        if not isinstance(self.data, Unset):
            data = self.data.to_dict()

        error = self.error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "stepId": step_id,
                "success": success,
            }
        )
        if data is not UNSET:
            field_dict["data"] = data
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.step_result_data import StepResultData

        d = dict(src_dict)
        step_id = d.pop("stepId")

        success = d.pop("success")

        _data = d.pop("data", UNSET)
        data: StepResultData | Unset
        if isinstance(_data, Unset):
            data = UNSET
        else:
            data = StepResultData.from_dict(_data)

        error = d.pop("error", UNSET)

        step_result = cls(
            step_id=step_id,
            success=success,
            data=data,
            error=error,
        )

        step_result.additional_properties = d
        return step_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
