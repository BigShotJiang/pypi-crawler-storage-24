from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateEndUserBody")


@_attrs_define
class UpdateEndUserBody:
    """
    Attributes:
        external_id (str | Unset): Your application's user ID Example: user-123.
        email (str | Unset):  Example: user@example.com.
        name (str | Unset):  Example: John Doe.
        allowed_systems (list[str] | Unset): Array of system IDs, or ["*"] for all systems Example: ['*'].
    """

    external_id: str | Unset = UNSET
    email: str | Unset = UNSET
    name: str | Unset = UNSET
    allowed_systems: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        external_id = self.external_id

        email = self.email

        name = self.name

        allowed_systems: list[str] | Unset = UNSET
        if not isinstance(self.allowed_systems, Unset):
            allowed_systems = self.allowed_systems

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if external_id is not UNSET:
            field_dict["externalId"] = external_id
        if email is not UNSET:
            field_dict["email"] = email
        if name is not UNSET:
            field_dict["name"] = name
        if allowed_systems is not UNSET:
            field_dict["allowedSystems"] = allowed_systems

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        external_id = d.pop("externalId", UNSET)

        email = d.pop("email", UNSET)

        name = d.pop("name", UNSET)

        allowed_systems = cast(list[str], d.pop("allowedSystems", UNSET))

        update_end_user_body = cls(
            external_id=external_id,
            email=email,
            name=name,
            allowed_systems=allowed_systems,
        )

        update_end_user_body.additional_properties = d
        return update_end_user_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
