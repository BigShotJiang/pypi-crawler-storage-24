from enum import Enum


class TriggerWebhookMode(str, Enum):
    DEV = "dev"
    PROD = "prod"

    def __str__(self) -> str:
        return str(self.value)
