from enum import Enum


class TriggerWebhookResponse202Status(str, Enum):
    ACCEPTED = "accepted"

    def __str__(self) -> str:
        return str(self.value)
