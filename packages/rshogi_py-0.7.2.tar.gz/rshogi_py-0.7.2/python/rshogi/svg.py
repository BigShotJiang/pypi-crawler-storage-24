"""SVG rendering for shogi board positions."""

from rshogi._rshogi import Svg

__all__ = ["Svg"]
