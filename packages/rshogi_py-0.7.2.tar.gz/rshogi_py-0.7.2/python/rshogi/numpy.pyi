"""Type stubs for rshogi.numpy — NumPy dtypes for packed SFEN data structures."""

from __future__ import annotations

from typing import Any


PackedSfen: Any
PackedSfenValue: Any

__all__ = ["PackedSfen", "PackedSfenValue"]
