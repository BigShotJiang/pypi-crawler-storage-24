"""NumPy dtypes for packed SFEN and related data structures."""

from rshogi._rshogi import dtype

# Re-export the dtype module contents
__getattr__ = dtype.__getattr__

try:
    PackedSfen = dtype.PackedSfen
    PackedSfenValue = dtype.PackedSfenValue
    __all__ = ["PackedSfen", "PackedSfenValue"]
except (ImportError, AttributeError):
    # numpy is not available
    __all__ = []
