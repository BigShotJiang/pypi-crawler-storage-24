import os
import pytest
import base64
from src.py_aide.images import ImageHandler
from src.py_aide.storage import Path

# Small 1x1 base64 transparent PNG
IMAGE_DATA_B64 = (
    "iVBORw0KGgoKCgoNSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
)

@pytest.fixture
def test_image_dir(tmp_path):
    """Fixture to provide a temporary directory for image tests."""
    img_dir = tmp_path / "images"
    img_dir.mkdir()
    return str(img_dir)

def test_save_images_success(test_image_dir):
    """Test successful image saving from base64."""
    images = [
        {"img": IMAGE_DATA_B64, "name": "test_pixel"}
    ]
    
    saved_paths = ImageHandler.save_images(images, test_image_dir)
    
    assert len(saved_paths) == 1
    assert os.path.exists(saved_paths[0])
    assert saved_paths[0].lower().endswith(".png")
    assert "test_pixel" in saved_paths[0]

def test_save_images_collision(test_image_dir):
    """Test image saving handles filename collisions."""
    images = [
        {"img": IMAGE_DATA_B64, "name": "duplicate"}
    ]
    
    # Save first time
    path1 = ImageHandler.save_images(images, test_image_dir)[0]
    # Save second time with same name
    path2 = ImageHandler.save_images(images, test_image_dir)[0]
    
    assert path1 != path2
    assert "copy" in path2
    assert os.path.exists(path1)
    assert os.path.exists(path2)

def test_is_base64_image_valid():
    """Test base64 image validation."""
    assert ImageHandler.is_base64_image(IMAGE_DATA_B64) is True

def test_is_base64_image_invalid():
    """Test validation with non-image base64 content."""
    invalid_b64 = base64.b64encode(b"not an image").decode()
    assert ImageHandler.is_base64_image(invalid_b64) is False

def test_detect_ext_png():
    """Test extension detection for PNG."""
    png_data = base64.b64decode(IMAGE_DATA_B64)
    assert ImageHandler._detect_ext(png_data) == "png"

def test_detect_ext_jpg():
    """Test extension detection for JPG (via magic numbers)."""
    jpg_data = b"\xff\xd8\xff\xe0" # Start of JPG header
    assert ImageHandler._detect_ext(jpg_data) == "jpg"
