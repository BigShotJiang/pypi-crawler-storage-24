import pytest
from datetime import datetime, date
from src.py_aide.dates import DateUtils

def test_current_timestamp():
    """Test standard date string generation."""
    ts = DateUtils.current_timestamp()
    assert isinstance(ts, str)
    # Basic YYYY-MM-DD check
    assert len(ts) >= 10

def test_get_past_date():
    """Test date subtraction logic."""
    base_date = "2026-03-24"
    past_date = DateUtils.get_past_date(base_date, days=2)
    assert past_date == "2026-03-22"

def test_get_future_date():
    """Test date addition logic."""
    base_date = "2026-03-24"
    future_date = DateUtils.get_future_date(base_date, days=2)
    assert future_date == "2026-03-26"

def test_is_leap_year():
    """Test leap year identification."""
    # 2024 is a leap year
    assert DateUtils.is_leap_year(2024) is True
    # 2023 is not a leap year
    assert DateUtils.is_leap_year(2023) is False

def test_start_of_month():
    """Test first day of month calculation."""
    assert DateUtils.start_of_month("2026-03-24") == "2026-03-01"

def test_end_of_month():
    """Test last day of month calculation (considering leap years)."""
    assert DateUtils.end_of_month("2026-03-24") == "2026-03-31"
    # February 2024 (Leap Year)
    assert DateUtils.end_of_month("2024-02-15") == "2024-02-29"
    # February 2023 (Non-Leap Year)
    assert DateUtils.end_of_month("2023-02-15") == "2023-02-28"
