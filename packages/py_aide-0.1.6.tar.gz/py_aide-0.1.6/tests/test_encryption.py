import pytest
from src.py_aide.encryption import Codec, generate_key

@pytest.fixture
def codec_instance():
    """Fixture to provide a Codec instance with a fresh key."""
    key = generate_key()
    return Codec(key)

def test_encryption_bytes_success(codec_instance):
    """Test standard bytes encryption and decryption."""
    original_data = b"secret_message"
    resp_encrypt = codec_instance.encrypt(data=original_data)
    
    assert resp_encrypt.status is True
    encrypted_data = resp_encrypt.data
    assert encrypted_data != original_data

    resp_decrypt = codec_instance.decrypt(ciphertext=encrypted_data)
    assert resp_decrypt.status is True
    assert resp_decrypt.data == original_data.decode()

def test_encryption_str_success(codec_instance):
    """Test standard string encryption and decryption."""
    original_data = "hello world"
    resp_encrypt = codec_instance.encrypt(data=original_data)
    
    assert resp_encrypt.status is True
    encrypted_data = resp_encrypt.data
    
    resp_decrypt = codec_instance.decrypt(ciphertext=encrypted_data)
    assert resp_decrypt.status is True
    assert resp_decrypt.data == original_data

def test_encryption_corruption_failure(codec_instance):
    """Test that tampering with ciphertext fails decryption safely."""
    resp_encrypt = codec_instance.encrypt(data="secure")
    tampered_data = bytearray(resp_encrypt.data)
    tampered_data[10] ^= 0xFF # Corrupt one byte
    
    resp_decrypt = codec_instance.decrypt(ciphertext=bytes(tampered_data))
    assert resp_decrypt.status is False
    assert "Invalid key or corrupted data" in resp_decrypt.log

def test_wrong_key_decryption():
    """Test that decryption with wrong key fails."""
    key1 = generate_key()
    codec1 = Codec(key1)
    
    key2 = generate_key()
    codec2 = Codec(key2)
    
    resp_encrypt = codec1.encrypt(data="secret")
    
    # Try decrypting with key2
    resp_decrypt = codec2.decrypt(ciphertext=resp_encrypt.data)
    assert resp_decrypt.status is False
    assert "Invalid key or corrupted data" in resp_decrypt.log
