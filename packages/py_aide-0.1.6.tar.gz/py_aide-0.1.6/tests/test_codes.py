import pytest
import string
from src.py_aide.codes import generate_code, CodeType

def test_generate_code_default_length():
    """Test default 12-character code generation."""
    code = generate_code()
    assert len(code) == 12
    assert isinstance(code, str)

def test_generate_code_custom_length():
    """Test custom length code generation."""
    code = generate_code(8)
    assert len(code) == 8

def test_generate_code_numeric_only():
    """Test purely numeric code generation."""
    code = generate_code(6, xterSet=CodeType.NUMERIC)
    assert len(code) == 6
    assert code.isdigit()

def test_generate_code_alphanumeric():
    """Test alphanumeric code generation."""
    code = generate_code(10, xterSet=CodeType.ALPHANUMERIC)
    assert len(code) == 10
    # Check if it only contains allowed characters (digits and letters)
    allowed = string.digits + string.ascii_letters
    assert all(c in allowed for c in code)

def test_generate_code_alpha_only():
    """Test alpha-only code generation."""
    code = generate_code(5, xterSet=CodeType.ALPHA)
    assert len(code) == 5
    assert code.isalpha()
