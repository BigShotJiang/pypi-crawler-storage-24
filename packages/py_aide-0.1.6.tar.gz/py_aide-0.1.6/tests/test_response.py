import pytest
from src.py_aide.response import Response, ok, error

def get_client_details(id: str) -> Response:
    """Mock client retrieval returning a Response object."""
    data = {
        "123u": {"name": "doug", "age": 29},
        "vvc4": {"name": "jan", "age": 24}
    }.get(id)

    if not data:
        return error(message=f"user {id} not found")

    return ok(data=data)

def test_response_success():
    """Test successful Response creation."""
    resp = get_client_details("123u")
    assert resp.status is True
    assert resp.data["name"] == "doug"
    assert hasattr(resp, "log")

def test_response_failure():
    """Test error Response creation."""
    resp = get_client_details("invalid_id")
    assert resp.status is False
    assert "user invalid_id not found" in resp.log

def test_response_boolean_check():
    """Test Response object evaluates as True/False based on status."""
    assert bool(ok()) is True
    assert bool(error(message="Fail")) is False

def test_ok_and_error_helpers():
    """Test ok() and error() helper functions."""
    resp_ok = ok(data={"val": 123})
    assert resp_ok.status is True
    assert resp_ok.data == {"val": 123}

    resp_error = error(message="Failed", errorLogs={"code": 500})
    assert resp_error.status is False
    assert resp_error.log == "Failed"
    assert resp_error.errorLogs == {"code": 500}
