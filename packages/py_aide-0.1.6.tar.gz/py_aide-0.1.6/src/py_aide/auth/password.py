"""
Secure Password Hashing Module with Argon2 and Background Rehashing.

This module provides secure password hashing and verification using Argon2id,
with mandatory callback support for background hash updates when rehashing is needed.

Requirements:
    argon2-cffi>=21.3.0

Usage:
    from auth.password import hash_password, verify_password
    
    # Define your callback (MANDATORY for verify_password)
    def update_hash_in_db(user_id: str, new_hash: str) -> None:
        # Your database update logic here
        # This runs in background via run_once
        database.update_user(user_id, {"password_hash": new_hash})
    
    # Hash a new password
    hashed = hash_password("user_password")
    
    # Verify a password (triggers background rehash if needed)
    is_valid = verify_password(
        password="input_password",
        stored_hash=hashed,
        user_identifier="user_123",
        rehash_callback=update_hash_in_db  # REQUIRED
    )
"""

import hashlib
import secrets
import base64
import hmac
import binascii
import threading
import logging
import time
from typing import Dict, Any, Optional, Callable, Union

# Third-party imports
from argon2 import PasswordHasher
from argon2.exceptions import (
    VerifyMismatchError,
    InvalidHashError,
    VerificationError,
    HashingError
)
from argon2.profiles import RFC_9106_HIGH_MEMORY

from ..enforcer import enforce_requirements
from ..threading import run_once  # Your existing utility

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ============================================================================
# CONFIGURATION
# ============================================================================

class Argon2Config:
    """
    Configuration for Argon2 password hashing.
    
    Using RFC 9106 "High Memory" profile as default:
    - time_cost=2: Number of iterations (~2 passes)
    - memory_cost=19456: 19 MiB of memory (memory-hard parameter)
    - parallelism=1: Single thread (prevents DoS via parallelization)
    - hash_len=32: 256-bit output hash
    - salt_len=16: 128-bit random salt
    """
    __slots__ = ('time_cost', 'memory_cost', 'parallelism', 'hash_len', 'salt_len')
    
    def __init__(
        self,
        time_cost: int = RFC_9106_HIGH_MEMORY.time_cost,
        memory_cost: int = RFC_9106_HIGH_MEMORY.memory_cost,
        parallelism: int = RFC_9106_HIGH_MEMORY.parallelism,
        hash_len: int = RFC_9106_HIGH_MEMORY.hash_len,
        salt_len: int = RFC_9106_HIGH_MEMORY.salt_len
    ):
        self.time_cost = time_cost
        self.memory_cost = memory_cost
        self.parallelism = parallelism
        self.hash_len = hash_len
        self.salt_len = salt_len


# Global configuration
_DEFAULT_CONFIG = Argon2Config()
_DEFAULT_HASHER = None
_HASHER_LOCK = threading.Lock()


def _get_default_hasher() -> PasswordHasher:
    """Get or create the default PasswordHasher (thread-safe)."""
    global _DEFAULT_HASHER
    if _DEFAULT_HASHER is None:
        with _HASHER_LOCK:
            if _DEFAULT_HASHER is None:
                _DEFAULT_HASHER = PasswordHasher(
                    time_cost=_DEFAULT_CONFIG.time_cost,
                    memory_cost=_DEFAULT_CONFIG.memory_cost,
                    parallelism=_DEFAULT_CONFIG.parallelism,
                    hash_len=_DEFAULT_CONFIG.hash_len,
                    salt_len=_DEFAULT_CONFIG.salt_len,
                )
    return _DEFAULT_HASHER


# ============================================================================
# CORE HASHING FUNCTIONS
# ============================================================================

@enforce_requirements
def hash_password(
    raw_password: str,/,*,
    config: Argon2Config|None = None
) -> str:
    """
    Hash a plain-text password using Argon2id with secure defaults.
    
    Args:
        raw_password: Plain-text password string to hash.
        config: Optional Argon2Config instance. Uses default config if None.
        
    Returns:
        Argon2 hash string containing all parameters.
        
    Raises:
        TypeError: If password is not a string.
        ValueError: If password is empty.
    """
    if not isinstance(raw_password, str):
        raise TypeError("Password must be a string")
    
    raw_password = raw_password.strip()
    if not raw_password:
        raise ValueError("Password cannot be empty")
    
    # Use specific hasher if config provided, otherwise default
    if config is None:
        hasher = _get_default_hasher()
    else:
        hasher = PasswordHasher(
            time_cost=config.time_cost,
            memory_cost=config.memory_cost,
            parallelism=config.parallelism,
            hash_len=config.hash_len,
            salt_len=config.salt_len,
        )
    
    return hasher.hash(raw_password)


@enforce_requirements
def verify_password(
    *,
    input_password: str,
    stored_hash: str,
    user_identifier: str,
    rehash_callback: Callable[[str, str], None],
    config: Argon2Config|None = None
) -> bool:
    """
    Verify a password and trigger background rehash if needed.
    
    This function:
    1. Synchronously verifies the password (blocks until complete)
    2. If valid, checks if hash needs rehashing
    3. If rehashing needed, triggers background rehash via run_once
    4. Returns verification result immediately
    
    Args:
        input_password: Password to verify.
        stored_hash: Previously stored hash to verify against.
        user_identifier: Unique identifier for the user (for callback).
        rehash_callback: REQUIRED callback function that updates hash in storage.
                         Must accept (user_identifier: str, new_hash: str).
        config: Optional Argon2Config for rehash checking. Uses default if None.
        
    Returns:
        True if password is valid, False otherwise.
        
    Raises:
        ValueError: If rehash_callback is not provided or user_identifier is empty.
        
    Note:
        The rehash_callback runs in a background thread via run_once.
        Verification result is returned immediately without waiting for rehash.
    """
    # Input validation
    if not isinstance(input_password, str) or not isinstance(stored_hash, str):
        return False
    
    input_password = input_password.strip()
    if not input_password or not stored_hash:
        return False
    
    # Validate mandatory parameters
    if not rehash_callback:
        raise ValueError("rehash_callback is required for verify_password")
    
    if not user_identifier:
        raise ValueError("user_identifier must be provided when rehash_callback is used")
    
    # Get appropriate hasher
    hasher = _get_default_hasher() if config is None else PasswordHasher(
        time_cost=config.time_cost,
        memory_cost=config.memory_cost,
        parallelism=config.parallelism,
        hash_len=config.hash_len,
        salt_len=config.salt_len,
    )
    
    try:
        is_valid = hasher.verify(stored_hash, input_password)
        
        if not is_valid:
            return False
        
        # Check if needs rehashing (synchronous, but fast)
        needs_rehash = hasher.check_needs_rehash(stored_hash)

        needs_rehash = True
        
        if needs_rehash:
            _trigger_background_rehash(
                input_password=input_password,
                old_hash=stored_hash,
                user_identifier=user_identifier,
                rehash_callback=rehash_callback,
                config=config
            )
        
        return True
        
    except VerifyMismatchError:
        # Password doesn't match
        return False
    except (InvalidHashError, VerificationError, HashingError) as e:
        logger.warning(f"Hash verification error for user {user_identifier}: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error during verification for user {user_identifier}: {e}")
        return False


def _trigger_background_rehash(
    input_password: str,
    old_hash: str,
    user_identifier: str,
    rehash_callback: Callable[[str, str], None],
    config: Argon2Config|None = None
) -> None:
    """
    Trigger background rehash using run_once.
    
    This function:
    1. Is called from verify_password when rehash is needed
    2. Uses run_once to execute rehash in background thread
    3. Creates new hash with current parameters
    4. Calls the provided callback with the new hash
    """
    # Create a unique identifier for this rehash operation
    # This helps run_once prevent duplicate concurrent rehashes
    rehash_id = f"rehash_{user_identifier}_{hash(old_hash) & 0xFFFFFFFF}"
    
    # Define the actual rehash function
    def perform_rehash() -> None:
        """Perform the actual rehashing and callback execution."""
        try:
            # Get appropriate hasher
            hasher = _get_default_hasher() if config is None else PasswordHasher(
                time_cost=config.time_cost,
                memory_cost=config.memory_cost,
                parallelism=config.parallelism,
                hash_len=config.hash_len,
                salt_len=config.salt_len,
            )
            
            # Create new hash with current parameters
            new_hash = hasher.hash(input_password)
            
            # Log the rehash operation
            logger.info(f"Rehashing password for user {user_identifier}")
            
            # Extract parameters for logging (optional)
            old_params = _extract_hash_parameters(old_hash)
            new_params = _extract_hash_parameters(new_hash)
            
            if old_params and new_params:
                logger.debug(
                    f"Rehash parameters for {user_identifier}: "
                    f"Old: {old_params['parameters']}, New: {new_params['parameters']}"
                )
            
            # Call the callback
            rehash_callback(user_identifier, new_hash)
            
            logger.debug(f"Successfully updated hash for user {user_identifier}")
            
        except Exception as e:
            logger.error(f"Background rehash failed for user {user_identifier}: {e}")
            # Re-raise if you want the error to be visible in the thread
            # For fire-and-forget, we just log and swallow
    
    # Run in background via run_once
    # run_once ensures we don't have multiple concurrent rehashes for same user
    thread = run_once(perform_rehash, task_id=rehash_id, delay=0.1)  # Small delay
    
    # Optional: Store thread reference if you want to monitor
    if thread:
        logger.debug(f"Started background rehash thread {thread.name} for user {user_identifier}")


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def needs_rehash(
    stored_hash: str,
    config: Optional[Argon2Config] = None
) -> bool:
    """
    Check if a stored hash needs rehashing.
    
    Args:
        stored_hash: Hash string to check.
        config: Configuration to check against. Uses default config if None.
        
    Returns:
        True if hash should be rehashed, False otherwise.
    """
    hasher = _get_default_hasher() if config is None else PasswordHasher(
        time_cost=config.time_cost,
        memory_cost=config.memory_cost,
        parallelism=config.parallelism,
        hash_len=config.hash_len,
        salt_len=config.salt_len,
    )
    
    try:
        return hasher.check_needs_rehash(stored_hash)
    except Exception:
        # If we can't parse the hash, it definitely needs rehashing
        return True


def _extract_hash_parameters(stored_hash: str) -> Optional[Dict[str, Any]]:
    """
    Extract parameters from an Argon2 hash string.
    
    Useful for debugging or logging.
    """
    try:
        # Format: $argon2id$v=19$m=19456,t=2,p=1$salt$hash
        parts = stored_hash.split('$')
        
        if len(parts) != 5:
            return None
        
        # Parse components
        variant = parts[1]  # argon2id, argon2i, or argon2d
        
        # Parse version: v=19
        version_part = parts[2]
        version = int(version_part.split('=')[1]) if '=' in version_part else 0
        
        # Parse parameters: m=19456,t=2,p=1
        params_part = parts[3]
        params = {}
        for param in params_part.split(','):
            if '=' in param:
                key, value = param.split('=')
                params[key] = int(value) if value.isdigit() else value
        
        return {
            'variant': variant,
            'version': version,
            'parameters': params,
            'hash_prefix': stored_hash[-20:]  # Last 20 chars
        }
        
    except Exception:
        return None


def set_default_config(config: Argon2Config) -> None:
    """
    Update the default Argon2 configuration globally.
    
    Warning: This affects all future hash operations.
    Use with caution in production.
    """
    global _DEFAULT_CONFIG, _DEFAULT_HASHER
    with _HASHER_LOCK:
        _DEFAULT_CONFIG = config
        _DEFAULT_HASHER = None  # Force re-creation with new config
    logger.info(f"Updated default Argon2 config: {config.__dict__}")


def get_default_config() -> Argon2Config:
    """Get a copy of the current default configuration."""
    return Argon2Config(
        time_cost=_DEFAULT_CONFIG.time_cost,
        memory_cost=_DEFAULT_CONFIG.memory_cost,
        parallelism=_DEFAULT_CONFIG.parallelism,
        hash_len=_DEFAULT_CONFIG.hash_len,
        salt_len=_DEFAULT_CONFIG.salt_len,
    )


# # ============================================================================
# # MODULE EXPORTS
# # ============================================================================

# __all__ = [
#     'hash_password',
#     'verify_password',
#     'needs_rehash',
#     'Argon2Config',
#     'set_default_config',
#     'get_default_config',
#     'migrate_from_pbkdf2',
# ]


# # ============================================================================
# # EXAMPLE USAGE
# # ============================================================================

# if __name__ == "__main__":
#     """
#     Example demonstrating the module usage.
#     """
    
#     # Mock database update function
#     def update_hash_in_db(user_id: str, new_hash: str) -> None:
#         """Example callback that updates hash in database."""
#         print(f"[DB Background] Updating hash for user {user_id}")
#         print(f"[DB Background] New hash: {new_hash[:50]}...")
#         # In real code: database.update(user_id, {"password_hash": new_hash})
    
#     print("=== Example 1: Basic password hashing ===")
    
#     # Hash a new password
#     password = "SecurePassword123!"
#     hashed = hash_password(password)
#     print(f"1. Hashed password: {hashed[:60]}...")
    
#     print("\n=== Example 2: Password verification with callback ===")
    
#     # Verify with correct password
#     is_valid = verify_password(
#         input_password=password,
#         stored_hash=hashed,
#         user_identifier="user_789",
#         rehash_callback=update_hash_in_db  # REQUIRED
#     )
#     print(f"2. Password valid: {is_valid}")
    
#     # Verify with wrong password
#     is_wrong = verify_password(
#         input_password="WrongPassword",
#         stored_hash=hashed,
#         user_identifier="user_789",
#         rehash_callback=update_hash_in_db
#     )
#     print(f"3. Wrong password valid: {is_wrong}")
    
#     print("\n=== Example 3: Check if hash needs rehashing ===")
    
#     # Simulate an old hash with weaker parameters
#     old_hasher = PasswordHasher(time_cost=1, memory_cost=8192)  # Old weak params
#     old_hash = old_hasher.hash(password)
    
#     needs_update = needs_rehash(old_hash)
#     print(f"4. Old hash needs rehash: {needs_update}")
    
#     # Verify with old hash (will trigger background rehash)
#     print("\n=== Example 4: Triggering background rehash ===")
#     is_valid_old = verify_password(
#         input_password=password,
#         stored_hash=old_hash,
#         user_identifier="user_old",
#         rehash_callback=update_hash_in_db
#     )
#     print(f"5. Old hash verification: {is_valid_old}")
#     print("   (Background rehash started via run_once)")
    
#     # Wait a bit to see background thread output
#     import time
#     time.sleep(0.5)
    
#     print("\n✅ All examples completed!")