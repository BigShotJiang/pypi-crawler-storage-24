"""
py_aide - Main package
This framework uses EVENTLET for WebSocket support.
Eventlet monkey patching happens IMMEDIATELY when this package is imported.
"""

# ============================================================================
# CRITICAL: Eventlet monkey patching - MUST be the first thing that runs
# ============================================================================

import sys

try:
    import eventlet
    eventlet.monkey_patch()
    print(f"[py_aide] Eventlet patched successfully (Python {sys.version_info.major}.{sys.version_info.minor})")
except ImportError:
    print("\n" + "="*70)
    print("CRITICAL: Eventlet not installed")
    print("="*70)
    print("This framework REQUIRES eventlet for WebSocket support.")
    print("Install it with: pip install eventlet")
    print("If you don't need WebSockets, set enable_websocket=False")
    print("="*70 + "\n")
    raise  # Stop execution - don't proceed without eventlet

from .response import Response, ok, error
from . import structures
from . import codes
from . import database
from . import enforcer
from . import encryption
from . import dates
from . import servers
from . import threading
from . import images
from . import tokens

from .customTypes import Definition, Options
from . import auth

