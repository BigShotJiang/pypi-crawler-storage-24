import re
import copy
from typing import Any, List, Tuple
from .cacheConfig import (
    PATH_SEP, OP_MERGE, OP_ADD, OP_SUB, OP_MULT, OP_DIV, 
    OP_INC, OP_DEC, OP_APPEND, CacheError
)

class CacheEngine:
    """
    Handles path parsing and data mutations.
    Separated from I/O and threading to ensure pure logic testing.
    """

    @staticmethod
    def parse_path(path: str) -> Tuple[List[str], str | None]:
        """Splits path into segments and identifies the bracket operator."""
        if not path:
            return [], None
        
        operator = None
        match = re.search(r'\[(.*?)]$', path)
        
        if match:
            operator = match.group(1)
            path = path[:match.start()]
            
        segments = [s for s in path.split(PATH_SEP) if s]
        return segments, operator

    @classmethod
    def apply_mutation(cls, data: dict, path: str, value: Any):
        """The core logic for applying decoupled operators with strict type checking."""
        segments, op = cls.parse_path(path)
        if not segments:
            return

        # Navigate/Create nesting
        current = data
        for i in range(len(segments) - 1):
            seg = segments[i]
            if seg not in current or not isinstance(current[seg], dict):
                current[seg] = {}
            current = current[seg]

        target_key = segments[-1]

        # --- Logic Branching ---

        # 1. Strict Merge (|=) - Only for dicts
        if op == OP_MERGE:
            target_val = current.get(target_key, {})
            if not isinstance(target_val, dict) or not isinstance(value, dict):
                raise TypeError(CacheError.TYPE_MISMATCH.format(
                    op=OP_MERGE, expected="dict", actual=f"{type(target_val).__name__}/{type(value).__name__}", path=path
                ))
            target_val.update(value)
            current[target_key] = target_val

        # 2. Arithmetic Block (+=, -=, *=, /=)
        elif op in (OP_ADD, OP_SUB, OP_MULT, OP_DIV):
            current_val = current.get(target_key, 0)
            
            # Strict check: Both existing and incoming must be numeric
            if not isinstance(current_val, (int, float)) or not isinstance(value, (int, float)):
                 raise TypeError(CacheError.TYPE_MISMATCH.format(
                    op=op, expected="numeric", actual=type(value).__name__, path=path
                ))

            if op == OP_ADD:
                current[target_key] = current_val + value
            elif op == OP_SUB:
                current[target_key] = current_val - value
            elif op == OP_MULT:
                current[target_key] = current_val * value
            elif op == OP_DIV:
                if value == 0:
                    raise ZeroDivisionError(CacheError.ZERO_DIVISION.format(path=path))
                current[target_key] = current_val / value

        # 3. List Operations (+)
        elif op == OP_APPEND:
            if target_key not in current:
                current[target_key] = []
            if not isinstance(current[target_key], list):
                 raise TypeError(CacheError.TYPE_MISMATCH.format(
                    op=OP_APPEND, expected="list", actual=type(current[target_key]).__name__, path=path
                ))
            current[target_key].append(value)

        # 4. Increments (++, --)
        elif op == OP_INC:
            current[target_key] = current.get(target_key, 0) + 1
        elif op == OP_DEC:
            current[target_key] = current.get(target_key, 0) - 1

        # 5. Default Overwrite (No operator)
        elif op is None:
            current[target_key] = value