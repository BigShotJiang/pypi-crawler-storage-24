import copy
from typing import Dict, Any, List
from .cacheConfig import CacheError, DirectMutation, FollowUpMutation
from .cacheEngine import CacheEngine

class TransactionManager:
    """
    Manages atomic updates to the cache.
    Ensures that if one part of a patch fails, the entire scope is preserved.
    """

    @staticmethod
    def execute_patch(
        storage: Dict[str, Any], 
        scope: str, 
        mutations: List[DirectMutation],
        follow_ups: List[FollowUpMutation] = None
    ) -> bool:
        """
        Executes a series of mutations on a local snapshot.
        If any mutation fails, the changes are discarded.
        """
        # 1. Create a deepcopy snapshot of the targeted scope
        # This ensures we don't modify the live cache until we're sure everything works.
        original_state = storage.get(scope)
        if original_state is None:
            # If scope doesn't exist, we start with an empty state
            snapshot = {}
        else:
            snapshot = copy.deepcopy(original_state)

        try:
            # 2. Apply primary mutations via CacheEngine
            for mutation in mutations:
                paths = mutation.get("paths", [])
                values = mutation.get("values", [])

                if len(paths) != len(values):
                    raise ValueError(CacheError.BATCH_SIZE_MISMATCH.format(
                        p_len=len(paths), v_len=len(values)
                    ))

                for path, val in zip(paths, values):
                    CacheEngine.apply_mutation(snapshot, path, val)

            # 3. Apply follow-up mutations (cross-category updates)
            if follow_ups:
                for f_mut in follow_ups:
                    f_paths = f_mut.get("paths", [])
                    f_vals = f_mut.get("values", [])
                    f_cat = f_mut.get("category")

                    # We navigate to the category within our snapshot
                    if f_cat not in snapshot:
                        snapshot[f_cat] = {}
                    
                    for p, v in zip(f_paths, f_vals):
                        CacheEngine.apply_mutation(snapshot[f_cat], p, v)

            # 4. If we reached here, everything succeeded.
            # Commit the snapshot back to the main storage.
            storage[scope] = snapshot
            return True

        except Exception as e:
            # 5. Rollback: We simply don't update storage[scope].
            # The error is re-raised to be caught by the Orchestrator for logging.
            raise RuntimeError(CacheError.TRANSACTION_ROLLBACK.format(reason=str(e)))