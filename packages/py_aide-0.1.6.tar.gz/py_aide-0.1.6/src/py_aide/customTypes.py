from typing import Any, Annotated, get_type_hints

# --- The Implementation ---

class _SchemaDescriptor:
    def __init__(self, schema):
        self.schema = schema
    
    def __repr__(self):
        # This string is what the IDE often pulls into the hover tooltip
        return str(self.schema)

class Definition:
    def __class_getitem__(cls, schema: dict[str, Any]) -> Any:
        # print(_SchemaDescriptor(schema))
        return Annotated[dict, _SchemaDescriptor(schema)]

class Options:
    def __class_getitem__(cls, params: Any) -> Any:
        base_type, choices = params
        return Annotated[base_type, f"Options: {choices}"]