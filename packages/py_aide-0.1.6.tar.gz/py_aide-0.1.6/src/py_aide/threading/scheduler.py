import threading
import time
from datetime import datetime, timedelta
import sys
from typing import Callable, Any, Iterable

def _report_error(func_name: str, task_type: str, error: Exception | str) -> None:
    """Prints background errors clearly to the console using sys.stderr."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n{'!'*40}", file=sys.stderr)
    print(f"SCHEDULER ERROR | {timestamp}", file=sys.stderr)
    print(f"Task: {func_name} ({task_type})", file=sys.stderr)
    print(f"Details: {error}", file=sys.stderr)
    print(f"{'!'*40}\n", file=sys.stderr)

# Track running tasks to prevent duplicates
_active_tasks = set()
_tasks_lock = threading.Lock()

def run_once(func: Callable[..., Any], *args: Any, delay: float = 0, task_id: str|None = None, **kwargs: Any) -> threading.Thread|None:
    """
    Executes a function in a background thread exactly one time.
    If task_id is provided, guarantees no other instance with that ID runs concurrently.
    """
    if task_id:
        with _tasks_lock:
            if task_id in _active_tasks:
                return None
            _active_tasks.add(task_id)

    def wrapper() -> None:
        try:
            if delay > 0:
                time.sleep(delay)
            try:
                result = func(*args, **kwargs)
                if hasattr(result, "to_dict") and hasattr(result, "status") and not result.status:
                    _report_error(func.__name__, "run_once", getattr(result, "log", "Response Error"))
            except Exception as e:
                _report_error(func.__name__, "run_once", e)
        finally:
            if task_id:
                with _tasks_lock:
                    _active_tasks.discard(task_id)

    t = threading.Thread(target=wrapper, daemon=True)
    t.start()
    return t

def run_every(interval_seconds: float, func: Callable[..., Any], *args: Any, **kwargs: Any) -> threading.Event:
    """
    Repeats a function indefinitely at the specified interval.

    - This function returns a threading.Event..
    - The background thread 'naps' using .wait(). If you call .set() on 
      the returned event, the thread wakes up instantly and exits the loop.
    - If you NEVER call .set(), the thread repeats until the main program closes.

    Example:
        stop_bell = run_every(60, sync_data)
        
        # ... later in your code ...
        stop_bell.set()  # The background loop stops immediately.
    """
    stop_event = threading.Event()

    def wrapper() -> None:
        while not stop_event.is_set():
            try:
                result = func(*args, **kwargs)
                if hasattr(result, "to_dict") and hasattr(result, "status") and not result.status:
                    _report_error(func.__name__, "run_every", getattr(result, "log", "Response Error"))
            except Exception as e:
                _report_error(func.__name__, "run_every", e)
            
            # The 'Wait' logic:
            # Returns True immediately if .set() is called
            # Returns False after 'timeout' seconds if nothing happens
            if stop_event.wait(timeout=interval_seconds):
                break
                
    threading.Thread(target=wrapper, daemon=True).start()
    return stop_event

def run_at(
    time_tuple: tuple[int, int], 
    days: Iterable[int], 
    func: Callable[..., Any], 
    *args: Any, 
    **kwargs: Any
) -> threading.Event|None:
    """
    Executes a function at a specific time (24h format) on specific days.

    - Returns a threading.Event used to cancel the upcoming scheduled runs.
    - The thread calculates the time until the next HH:MM and 'waits' for that duration.
    - If you stop the event (.set()), the thread stops waiting and cancels the schedule.
    - If days is empty, it returns None and does not start a thread.

    Example:
        # Schedule for 14:30 on Mon(0) and Wed(2)
        cancel_handle = run_at((14, 30), [0, 2], backup_task)
        
        # To cancel the daily schedule:
        if cancel_handle:
            cancel_handle.set()
    """
    if not days:
        print(f"[SCHEDULER] Warning: {func.__name__} ignored (no days provided).")
        return None

    stop_event = threading.Event()
    hour, minute = time_tuple

    def wrapper() -> None:
        while not stop_event.is_set():
            now = datetime.now()
            target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)

            if target <= now:
                target += timedelta(days=1)

            delay = (target - now).total_seconds()
            
            # Waits until the clock hits the target time OR the event is stopped
            if stop_event.wait(timeout=delay):
                break

            if datetime.now().weekday() in days:
                try:
                    result = func(*args, **kwargs)
                    if hasattr(result, "to_dict") and hasattr(result, "status") and not result.status:
                        _report_error(func.__name__, "run_at", getattr(result, "log", "Response Error"))
                except Exception as e:
                    _report_error(func.__name__, "run_at", e)

    threading.Thread(target=wrapper, daemon=True).start()
    return stop_event