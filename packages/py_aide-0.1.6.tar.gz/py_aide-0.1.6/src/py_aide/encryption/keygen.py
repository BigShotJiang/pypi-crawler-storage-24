from cryptography.fernet import Fernet
import os
from ..enforcer import enforce_requirements
from ..response import Response, ok, error

def generate_key() -> bytes:
    """Creates a new high-entropy 32-byte key."""
    return Fernet.generate_key()

@enforce_requirements
def save_key(*, key: bytes, path: str) -> Response:
    """Saves the key to a file with strict permissions."""
    try:
        with open(path, "wb") as key_file:
            key_file.write(key)
        return ok()
    except Exception as e:
        return error(message=f"Failed to save key at {path}: {str(e)}")

@enforce_requirements
def load_key(*, path: str) -> Response:
    """Reads a key from a file. Returns error Response if missing."""
    if not os.path.exists(path):
        return error(message=f"Key file not found at: {path}")
    try:
        with open(path, "rb") as key_file:
            return ok(data=key_file.read())
    except Exception as e:
        return error(message=f"Failed to load key from {path}: {str(e)}")