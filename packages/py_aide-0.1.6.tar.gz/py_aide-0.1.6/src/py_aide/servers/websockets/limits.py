"""
WebSocket Limits Module - Rate Limiting, Quotas, and Backpressure with Runtime Updates

This module provides comprehensive limits for WebSocket connections:
1. Rate limiting (messages per time window)
2. Connection caps (total, per IP, per user)
3. Message size enforcement
4. Backpressure handling for slow clients
5. Quota management for different user tiers
6. Runtime updates to limits and quotas

All limits are designed to be:
- Efficient (minimal overhead)
- Configurable (per-endpoint, per-user)
- Observable (clear metrics on who's hitting limits)
- Fair (prevents single user from degrading service)
- Dynamically updatable at runtime
"""

import time
import threading
import logging
from collections import defaultdict, deque
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from enum import Enum

# Import from WebSocket modules
from .engine import WebSocketEngine, ConnectionInfo


# ============================================================================
# ENUMS
# ============================================================================

class LimitType(str, Enum):
    """Types of limits that can be enforced."""
    MESSAGES_PER_MINUTE = "messages_per_minute"
    MESSAGES_PER_HOUR = "messages_per_hour"
    CONNECTIONS_PER_IP = "connections_per_ip"
    CONNECTIONS_PER_USER = "connections_per_user"
    TOTAL_CONNECTIONS = "total_connections"
    MESSAGE_SIZE = "message_size"
    BANDWIDTH_PER_MINUTE = "bandwidth_per_minute"
    BANDWIDTH_PER_HOUR = "bandwidth_per_hour"


class LimitAction(str, Enum):
    """What happens when a limit is exceeded."""
    BLOCK = "block"      # Reject the message/connection
    DELAY = "delay"       # Slow down processing
    DROP = "drop"         # Silently drop the message
    THROTTLE = "throttle" # Reduce priority
    NOTIFY = "notify"     # Only notify, don't block


class LimitScope(str, Enum):
    """Scope at which limits are applied."""
    GLOBAL = "global"           # Across entire server
    PER_IP = "per_ip"            # Per client IP
    PER_USER = "per_user"        # Per authenticated user
    PER_CONNECTION = "per_connection"  # Per WebSocket connection
    PER_EVENT = "per_event"       # Per event type
    PER_MESSAGE = "per_message"    # Per individual message


# ============================================================================
# LIMITS CONFIGURATION
# ============================================================================

@dataclass
class LimitRule:
    """
    Defines a single limit rule with validation for runtime updates.
    
    Example:
        >>> rule = LimitRule(
        ...     limit_type=LimitType.MESSAGES_PER_MINUTE,
        ...     scope=LimitScope.PER_USER,
        ...     value=60,
        ...     action=LimitAction.BLOCK
        ... )
    """
    limit_type: LimitType
    """What kind of limit this is"""
    
    scope: LimitScope
    """Who this limit applies to"""
    
    value: int
    """The limit value (e.g., 60 messages)"""
    
    action: LimitAction = LimitAction.BLOCK
    """What to do when limit exceeded"""
    
    window_seconds: int = 60
    """Time window for rate limits (seconds)"""
    
    name: Optional[str] = None
    """Optional friendly name for this rule"""
    
    priority: int = 10
    """Lower numbers = higher priority (checked first)"""
    
    def __post_init__(self):
        if not self.name:
            self.name = f"{self.scope.value}_{self.limit_type.value}"
    
    def key_for(self, conn_info: ConnectionInfo, event: Optional[str] = None) -> Optional[str]:
        """
        Generate a unique key for tracking this limit for a specific entity.
        
        Args:
            conn_info: Connection information
            event: Event name (for per-event limits)
            
        Returns:
            String key for tracking in rate limit stores, or None if not applicable
        """
        if self.scope == LimitScope.GLOBAL:
            return f"global:{self.limit_type.value}"
        
        elif self.scope == LimitScope.PER_IP:
            return f"ip:{conn_info.client_ip}:{self.limit_type.value}"
        
        elif self.scope == LimitScope.PER_USER:
            if not conn_info.user_id:
                return None  # Can't apply user limit to unauthenticated
            return f"user:{conn_info.user_id}:{self.limit_type.value}"
        
        elif self.scope == LimitScope.PER_CONNECTION:
            return f"conn:{conn_info.sid}:{self.limit_type.value}"
        
        elif self.scope == LimitScope.PER_EVENT:
            if not event:
                return None
            return f"event:{event}:{self.limit_type.value}:{conn_info.sid}"
        
        return None
    
    # ========================================================================
    # VALIDATION METHODS (for runtime updates)
    # ========================================================================
    
    def validate_value(self, value: int) -> None:
        """Validate rule value before runtime update."""
        if value < 0:
            raise ValueError(f"Rule value cannot be negative, got {value}")
        
        if self.limit_type in [LimitType.MESSAGE_SIZE, LimitType.BANDWIDTH_PER_MINUTE]:
            if value < 1024:  # 1KB
                logging.warning(f"Very low limit value: {value} bytes")
    
    def validate_window_seconds(self, window: int) -> None:
        """Validate window seconds before runtime update."""
        if window <= 0:
            raise ValueError(f"Window seconds must be positive, got {window}")
        
        if window > 86400:  # 24 hours
            logging.warning(f"Very large window: {window} seconds")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'name': self.name,
            'limit_type': self.limit_type.value,
            'scope': self.scope.value,
            'value': self.value,
            'action': self.action.value,
            'window_seconds': self.window_seconds,
            'priority': self.priority
        }


@dataclass
class Quota:
    """
    User quota information with validation for runtime updates.
    
    Different user tiers can have different quotas.
    """
    user_id: str
    """User this quota applies to"""
    
    user_tier: str = "default"
    """Tier/role of the user"""
    
    message_limit_per_minute: int = 60
    """Messages per minute allowed"""
    
    message_limit_per_hour: int = 1000
    """Messages per hour allowed"""
    
    connection_limit: int = 5
    """Max concurrent connections"""
    
    max_message_size: int = 256 * 1024  # 256KB
    """Max message size in bytes"""
    
    bandwidth_per_minute: int = 10 * 1024 * 1024  # 10MB/min
    """Bandwidth limit per minute"""
    
    priority: int = 0
    """Higher priority users get better service"""
    
    expires_at: Optional[float] = None
    """When this quota expires (for temporary upgrades)"""
    
    @property
    def is_valid(self) -> bool:
        """Whether this quota is still valid."""
        if self.expires_at:
            return time.time() < self.expires_at
        return True
    
    # ========================================================================
    # VALIDATION METHODS (for runtime updates)
    # ========================================================================
    
    def validate_message_limit_per_minute(self, value: int) -> None:
        """Validate message limit before runtime update."""
        if value < 0:
            raise ValueError(f"Message limit cannot be negative, got {value}")
    
    def validate_message_limit_per_hour(self, value: int) -> None:
        """Validate hourly message limit before runtime update."""
        if value < 0:
            raise ValueError(f"Hourly message limit cannot be negative, got {value}")
        if value < self.message_limit_per_minute:
            logging.warning(f"Hourly limit ({value}) is less than minute limit ({self.message_limit_per_minute})")
    
    def validate_connection_limit(self, value: int) -> None:
        """Validate connection limit before runtime update."""
        if value < 1:
            raise ValueError(f"Connection limit must be at least 1, got {value}")
    
    def validate_max_message_size(self, value: int) -> None:
        """Validate max message size before runtime update."""
        if value < 1024:
            raise ValueError(f"Max message size too low: {value} bytes (minimum 1024)")
        if value > 100 * 1024 * 1024:
            raise ValueError(f"Max message size too high: {value} bytes (maximum 100MB)")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'user_id': self.user_id,
            'user_tier': self.user_tier,
            'message_limit_per_minute': self.message_limit_per_minute,
            'message_limit_per_hour': self.message_limit_per_hour,
            'connection_limit': self.connection_limit,
            'max_message_size': self.max_message_size,
            'bandwidth_per_minute': self.bandwidth_per_minute,
            'priority': self.priority,
            'expires_at': self.expires_at,
            'is_valid': self.is_valid
        }


@dataclass
class LimitsConfig:
    """
    Limits configuration for WebSocket connections.
    
    All limits-specific settings are defined here with validation methods
    to support runtime updates through the WebSocketConfigManager.
    """
    
    # ========================================================================
    # DEFAULT LIMITS (from engine config, but we duplicate for clarity)
    # ========================================================================
    
    max_connections_per_ip: int = 100
    """Maximum concurrent connections from single IP."""
    
    max_connections_per_user: int = 5
    """Maximum concurrent connections per authenticated user."""
    
    max_message_size: int = 256 * 1024
    """Maximum allowed message size in bytes."""
    
    max_messages_per_minute_per_user: int = 60
    """Maximum messages per minute per user."""
    
    # ========================================================================
    # QUEUE/BACKPRESSURE SETTINGS
    # ========================================================================
    
    max_message_queue_size: int = 10000
    """Maximum messages queued for slow clients."""
    
    message_queue_timeout: float = 30.0
    """Seconds before queued message expires."""
    
    # ========================================================================
    # CUSTOM RULES (can be updated at runtime)
    # ========================================================================
    
    custom_rules: List[LimitRule] = field(default_factory=list)
    """Custom rate limit rules (in addition to defaults)."""
    
    # ========================================================================
    # VALIDATION METHODS (for runtime updates)
    # ========================================================================
    
    def validate_max_connections_per_ip(self, value: int) -> None:
        """Validate max_connections_per_ip before runtime update."""
        if value < 0:
            raise ValueError(f"max_connections_per_ip cannot be negative, got {value}")
        if value > 10000:
            logging.warning(f"Very high max_connections_per_ip: {value}")
    
    def validate_max_connections_per_user(self, value: int) -> None:
        """Validate max_connections_per_user before runtime update."""
        if value < 0:
            raise ValueError(f"max_connections_per_user cannot be negative, got {value}")
    
    def validate_max_message_size(self, value: int) -> None:
        """Validate max_message_size before runtime update."""
        if value < 1024:
            raise ValueError(f"max_message_size too low ({value} bytes). Minimum 1024 bytes.")
        if value > 100 * 1024 * 1024:
            raise ValueError(f"max_message_size too high ({value} bytes). Maximum 100MB.")
    
    def validate_max_messages_per_minute_per_user(self, value: int) -> None:
        """Validate max_messages_per_minute_per_user before runtime update."""
        if value < 0:
            raise ValueError(f"max_messages_per_minute_per_user cannot be negative, got {value}")
    
    def validate_max_message_queue_size(self, value: int) -> None:
        """Validate max_message_queue_size before runtime update."""
        if value < 0:
            raise ValueError(f"max_message_queue_size cannot be negative, got {value}")
        if value > 1000000:
            logging.warning(f"Very large message queue: {value}")
    
    def validate_message_queue_timeout(self, value: float) -> None:
        """Validate message_queue_timeout before runtime update."""
        if value < 0:
            raise ValueError(f"message_queue_timeout cannot be negative, got {value}")
        if value > 3600:
            logging.warning(f"Very long queue timeout: {value}s")
    
    # ========================================================================
    # UPDATE HOOKS (called after successful runtime updates)
    # ========================================================================
    
    def on_max_connections_per_ip_updated(self, value: int) -> None:
        """Hook called after max_connections_per_ip is updated."""
        logging.info(f"Limits: max_connections_per_ip updated to {value}")
    
    def on_max_connections_per_user_updated(self, value: int) -> None:
        """Hook called after max_connections_per_user is updated."""
        logging.info(f"Limits: max_connections_per_user updated to {value}")
    
    def on_max_message_size_updated(self, value: int) -> None:
        """Hook called after max_message_size is updated."""
        logging.info(f"Limits: max_message_size updated to {value} bytes")
    
    def on_max_messages_per_minute_per_user_updated(self, value: int) -> None:
        """Hook called after message rate limit is updated."""
        logging.info(f"Limits: message rate limit updated to {value}/min")
    
    # ========================================================================
    # INITIAL VALIDATION (called at startup)
    # ========================================================================
    
    def __post_init__(self):
        """Validate configuration at startup."""
        self._validate_limits()
    
    def _validate_limits(self):
        """Ensure numeric limits are reasonable."""
        if self.max_message_size < 1024:
            logging.warning(
                f"Very low max_message_size ({self.max_message_size} bytes) "
                "may reject legitimate messages"
            )
        
        if self.max_message_size > 10 * 1024 * 1024:
            logging.warning(
                f"Very high max_message_size ({self.max_message_size} bytes) "
                "may expose server to memory exhaustion attacks"
            )


# ============================================================================
# RATE LIMIT STORAGE
# ============================================================================

class SlidingWindowCounter:
    """
    Efficient sliding window counter for rate limiting.
    
    Uses a deque to track timestamps, providing O(1) operations.
    Thread-safe for concurrent access.
    """
    
    def __init__(self, max_window_size: int = 1000):
        """
        Args:
            max_window_size: Maximum number of events to track per key
        """
        self._counters: Dict[str, deque] = defaultdict(
            lambda: deque(maxlen=max_window_size)
        )
        self._lock = threading.RLock()
    
    def add(self, key: str, timestamp: Optional[float] = None) -> int:
        """
        Add an event for a key.
        
        Args:
            key: The rate limit key
            timestamp: Event timestamp (default: now)
            
        Returns:
            Current count in the window
        """
        with self._lock:
            ts = timestamp or time.time()
            self._counters[key].append(ts)
            return len(self._counters[key])
    
    def count_in_window(self, key: str, window_seconds: int) -> int:
        """
        Count events in the last window_seconds.
        
        Args:
            key: The rate limit key
            window_seconds: Time window to count
            
        Returns:
            Number of events in the window
        """
        with self._lock:
            if key not in self._counters:
                return 0
            
            cutoff = time.time() - window_seconds
            timestamps = self._counters[key]
            
            # Remove old timestamps (while we're at it)
            while timestamps and timestamps[0] < cutoff:
                timestamps.popleft()
            
            return len(timestamps)
    
    def get_rate(self, key: str, window_seconds: int) -> float:
        """
        Get current rate (events per second).
        
        Args:
            key: The rate limit key
            window_seconds: Window to calculate rate over
            
        Returns:
            Events per second
        """
        count = self.count_in_window(key, window_seconds)
        return count / window_seconds if window_seconds > 0 else 0
    
    def reset(self, key: str):
        """Reset counter for a key."""
        with self._lock:
            if key in self._counters:
                del self._counters[key]
    
    def cleanup(self, max_age_seconds: int = 3600):
        """Remove old entries to free memory."""
        with self._lock:
            cutoff = time.time() - max_age_seconds
            keys_to_delete = []
            
            for key, timestamps in self._counters.items():
                # Remove old timestamps
                while timestamps and timestamps[0] < cutoff:
                    timestamps.popleft()
                
                # If empty, mark for deletion
                if not timestamps:
                    keys_to_delete.append(key)
            
            # Delete empty keys
            for key in keys_to_delete:
                del self._counters[key]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get counter statistics."""
        with self._lock:
            return {
                'active_keys': len(self._counters),
                'total_events': sum(len(q) for q in self._counters.values())
            }


class TokenBucket:
    """
    Token bucket algorithm for rate limiting.
    
    Good for smoothing out bursts while enforcing average rate.
    Thread-safe for concurrent access.
    """
    
    def __init__(self, capacity: int, fill_rate: float):
        """
        Args:
            capacity: Maximum tokens in bucket
            fill_rate: Tokens added per second
        """
        self.capacity = capacity
        self.fill_rate = fill_rate
        self.tokens = capacity
        self.last_update = time.time()
        self._lock = threading.RLock()
    
    def consume(self, tokens: int = 1) -> bool:
        """
        Try to consume tokens from the bucket.
        
        Args:
            tokens: Number of tokens to consume
            
        Returns:
            True if tokens were available, False otherwise
        """
        with self._lock:
            self._refill()
            
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            return False
    
    def _refill(self):
        """Add tokens based on time passed."""
        now = time.time()
        elapsed = now - self.last_update
        self.tokens = min(self.capacity, self.tokens + elapsed * self.fill_rate)
        self.last_update = now
    
    @property
    def fill_time(self) -> float:
        """Time to completely fill an empty bucket."""
        return self.capacity / self.fill_rate


# ============================================================================
# BACKPRESSURE MANAGER
# ============================================================================

class BackpressureManager:
    """
    Manages backpressure for slow clients.
    
    When clients can't keep up, we need to:
    1. Queue messages (up to a limit)
    2. Drop messages if queue is full
    3. Disconnect clients that are too slow
    
    Thread-safe for concurrent access.
    """
    
    def __init__(self, max_queue_size: int = 10000, queue_timeout: float = 30.0):
        """
        Args:
            max_queue_size: Maximum messages queued per connection
            queue_timeout: Maximum time message can stay in queue
        """
        self.max_queue_size = max_queue_size
        self.queue_timeout = queue_timeout
        
        # Per-connection message queues
        self._queues: Dict[str, deque] = defaultdict(
            lambda: deque(maxlen=max_queue_size)
        )
        
        # Per-connection queue timestamps (for timeout)
        self._timestamps: Dict[str, deque] = defaultdict(deque)
        
        # Connections under backpressure
        self._backpressure_connections: Set[str] = set()
        
        self._lock = threading.RLock()
    
    def push(self, sid: str, message: Any) -> bool:
        """
        Push a message to a client's queue.
        
        Args:
            sid: Session ID
            message: Message to queue
            
        Returns:
            True if message was queued, False if queue is full
        """
        with self._lock:
            queue = self._queues[sid]
            timestamps = self._timestamps[sid]
            
            # Check queue size limit
            if len(queue) >= self.max_queue_size:
                self._backpressure_connections.add(sid)
                return False
            
            # Add to queue
            queue.append(message)
            timestamps.append(time.time())
            
            return True
    
    def pop(self, sid: str) -> Optional[Any]:
        """
        Pop the next message for a client.
        
        Args:
            sid: Session ID
            
        Returns:
            Next message or None if queue empty
        """
        with self._lock:
            if sid not in self._queues or not self._queues[sid]:
                return None
            
            queue = self._queues[sid]
            timestamps = self._timestamps[sid]
            
            # Check timeout
            if timestamps and (time.time() - timestamps[0]) > self.queue_timeout:
                # Message expired - discard it
                queue.popleft()
                timestamps.popleft()
                return self.pop(sid)  # Try next
            
            # Return next message
            if queue:
                timestamps.popleft()
                return queue.popleft()
            
            return None
    
    def queue_size(self, sid: str) -> int:
        """Get current queue size for a connection."""
        with self._lock:
            return len(self._queues.get(sid, []))
    
    def is_under_backpressure(self, sid: str) -> bool:
        """Check if a connection is under backpressure."""
        with self._lock:
            return sid in self._backpressure_connections
    
    def clear_backpressure(self, sid: str):
        """Clear backpressure flag for a connection."""
        with self._lock:
            self._backpressure_connections.discard(sid)
    
    def cleanup(self, sid: str):
        """Remove all data for a disconnected client."""
        with self._lock:
            self._queues.pop(sid, None)
            self._timestamps.pop(sid, None)
            self._backpressure_connections.discard(sid)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get backpressure statistics."""
        with self._lock:
            return {
                'connections_under_backpressure': len(self._backpressure_connections),
                'total_queued_messages': sum(len(q) for q in self._queues.values()),
                'max_queue_size': self.max_queue_size
            }


# ============================================================================
# QUOTA MANAGER
# ============================================================================

class QuotaManager:
    """
    Manages user quotas based on tiers/roles with runtime update support.
    
    Different user types (free, premium, admin) get different limits.
    Supports dynamic updates to quotas at runtime.
    """
    
    def __init__(self):
        # Default quotas by tier
        self._default_quotas = {
            "anonymous": Quota(
                user_id="anonymous",
                user_tier="anonymous",
                message_limit_per_minute=10,
                message_limit_per_hour=100,
                connection_limit=2,
                max_message_size=64 * 1024,  # 64KB
                bandwidth_per_minute=1 * 1024 * 1024,  # 1MB/min
                priority=-10
            ),
            "free": Quota(
                user_id="free",
                user_tier="free",
                message_limit_per_minute=30,
                message_limit_per_hour=500,
                connection_limit=3,
                max_message_size=128 * 1024,  # 128KB
                bandwidth_per_minute=5 * 1024 * 1024,  # 5MB/min
                priority=0
            ),
            "premium": Quota(
                user_id="premium",
                user_tier="premium",
                message_limit_per_minute=120,
                message_limit_per_hour=5000,
                connection_limit=10,
                max_message_size=1 * 1024 * 1024,  # 1MB
                bandwidth_per_minute=50 * 1024 * 1024,  # 50MB/min
                priority=10
            ),
            "admin": Quota(
                user_id="admin",
                user_tier="admin",
                message_limit_per_minute=1000,
                message_limit_per_hour=50000,
                connection_limit=50,
                max_message_size=10 * 1024 * 1024,  # 10MB
                bandwidth_per_minute=500 * 1024 * 1024,  # 500MB/min
                priority=100
            ),
        }
        
        # Active quotas for specific users (overrides defaults)
        self._user_quotas: Dict[str, Quota] = {}
        
        self._lock = threading.RLock()
    
    def get_quota(self, user_id: Optional[str], user_tier: str = "free") -> Quota:
        """
        Get quota for a user.
        
        Args:
            user_id: User ID (if authenticated)
            user_tier: User tier/role
            
        Returns:
            Quota for the user
        """
        with self._lock:
            # Check for user-specific quota
            if user_id and user_id in self._user_quotas:
                quota = self._user_quotas[user_id]
                if quota.is_valid:
                    return quota
            
            # Fall back to tier-based quota
            if user_tier in self._default_quotas:
                quota = self._default_quotas[user_tier]
                # Create a copy with the actual user_id
                return Quota(
                    user_id=user_id or "anonymous",
                    user_tier=quota.user_tier,
                    message_limit_per_minute=quota.message_limit_per_minute,
                    message_limit_per_hour=quota.message_limit_per_hour,
                    connection_limit=quota.connection_limit,
                    max_message_size=quota.max_message_size,
                    bandwidth_per_minute=quota.bandwidth_per_minute,
                    priority=quota.priority
                )
            
            # Ultimate fallback
            return self._default_quotas["free"]
    
    # ========================================================================
    # RUNTIME UPDATE METHODS
    # ========================================================================
    
    def set_user_quota(self, user_id: str, quota: Quota) -> None:
        """
        Set a custom quota for a specific user at runtime.
        
        Args:
            user_id: User ID
            quota: Quota to assign
        """
        with self._lock:
            self._user_quotas[user_id] = quota
            logging.info(f"QuotaManager: Set custom quota for user {user_id} (tier: {quota.user_tier})")
    
    def set_tier_quota(self, tier: str, quota: Quota) -> None:
        """
        Set default quota for a tier at runtime.
        
        Args:
            tier: Tier name (free, premium, admin, etc.)
            quota: Quota for this tier
        """
        with self._lock:
            self._default_quotas[tier] = quota
            logging.info(f"QuotaManager: Updated quota for tier '{tier}'")
    
    def remove_user_quota(self, user_id: str) -> None:
        """
        Remove custom quota for a user at runtime.
        
        Args:
            user_id: User ID
        """
        with self._lock:
            if user_id in self._user_quotas:
                del self._user_quotas[user_id]
                logging.info(f"QuotaManager: Removed custom quota for user {user_id}")
    
    def get_tier_quota(self, tier: str) -> Optional[Quota]:
        """Get quota for a tier."""
        with self._lock:
            return self._default_quotas.get(tier)
    
    def get_user_quota(self, user_id: str) -> Optional[Quota]:
        """Get custom quota for a user."""
        with self._lock:
            return self._user_quotas.get(user_id)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get quota manager statistics."""
        with self._lock:
            return {
                'active_user_quotas': len(self._user_quotas),
                'tiers': list(self._default_quotas.keys()),
                'total_users_with_custom_quotas': len(self._user_quotas)
            }


# ============================================================================
# LIMITS MANAGER
# ============================================================================

class WebSocketLimitsManager:
    """
    Main manager for all WebSocket limits with runtime update support.
    
    This class:
    1. Enforces rate limits on messages
    2. Checks connection caps
    3. Validates message sizes
    4. Manages backpressure
    5. Applies user quotas
    6. Supports runtime updates to limits and quotas
    """
    
    def __init__(
        self,
        engine: WebSocketEngine,
        config: LimitsConfig,
        quota_manager: Optional[QuotaManager] = None
    ):
        """
        Initialize limits manager.
        
        Args:
            engine: WebSocket engine instance
            config: Limits configuration
            quota_manager: Optional quota manager
        """
        self.engine = engine
        self.config = config
        self.quota_manager = quota_manager or QuotaManager()
        
        # Rate limit counters
        self._message_counters = SlidingWindowCounter()
        self._bandwidth_counters = SlidingWindowCounter()
        
        # Token buckets for smoothing
        self._buckets: Dict[str, TokenBucket] = {}
        
        # Backpressure manager
        self._backpressure = BackpressureManager(
            max_queue_size=config.max_message_queue_size,
            queue_timeout=config.message_queue_timeout
        )
        
        # Custom limit rules (copy from config)
        self._custom_rules: List[LimitRule] = list(config.custom_rules)
        
        # Statistics
        self.stats = {
            'messages_checked': 0,
            'messages_allowed': 0,
            'messages_blocked': 0,
            'messages_dropped': 0,
            'connections_rejected': 0,
            'backpressure_events': 0,
            'size_violations': 0,
            'rate_violations': 0,
            'current_backpressure': 0,
        }
        
        # Violations log (for monitoring)
        self._recent_violations: deque = deque(maxlen=1000)
        
        # Locks for thread safety
        self._lock = threading.RLock()
        
        # Register hooks
        self._register_hooks()
        
        # Create default rules
        self._setup_default_rules()
        
        logging.info("[WebSocketLimits] Limits manager initialized")
        logging.info(f"  - Message rate limit: {config.max_messages_per_minute_per_user}/min per user")
        logging.info(f"  - Message size limit: {config.max_message_size} bytes")
        logging.info(f"  - Connections per IP: {config.max_connections_per_ip}")
        logging.info(f"  - Connections per user: {config.max_connections_per_user}")
        logging.info(f"  - Backpressure queue: {config.max_message_queue_size} messages")
    
    # ========================================================================
    # RUNTIME UPDATE METHODS
    # ========================================================================
    
    def update_config(self, new_config: LimitsConfig) -> None:
        """
        Update limits configuration at runtime.
        
        This method is called by the WebSocketConfigManager when
        limits settings are updated.
        
        Args:
            new_config: Updated limits configuration
        """
        with self._lock:
            old_config = self.config
            self.config = new_config
            
            # Update backpressure manager if settings changed
            if (old_config.max_message_queue_size != new_config.max_message_queue_size or
                old_config.message_queue_timeout != new_config.message_queue_timeout):
                self._backpressure = BackpressureManager(
                    max_queue_size=new_config.max_message_queue_size,
                    queue_timeout=new_config.message_queue_timeout
                )
            
            # Update custom rules
            self._custom_rules = list(new_config.custom_rules)
            
            logging.info("[WebSocketLimits] Configuration updated at runtime")
    
    def add_rule(self, rule: LimitRule) -> None:
        """
        Add a custom limit rule at runtime.
        
        Args:
            rule: Limit rule to add
        """
        with self._lock:
            self._custom_rules.append(rule)
            self._custom_rules.sort(key=lambda r: r.priority)
            self.config.custom_rules.append(rule)
            logging.info(f"[WebSocketLimits] Added rule: {rule.name}")
    
    def remove_rule(self, rule_name: str) -> bool:
        """
        Remove a custom rule by name at runtime.
        
        Args:
            rule_name: Name of rule to remove
            
        Returns:
            True if rule was removed, False if not found
        """
        with self._lock:
            initial_len = len(self._custom_rules)
            self._custom_rules = [r for r in self._custom_rules if r.name != rule_name]
            self.config.custom_rules = [r for r in self.config.custom_rules if r.name != rule_name]
            
            if len(self._custom_rules) < initial_len:
                logging.info(f"[WebSocketLimits] Removed rule: {rule_name}")
                return True
            return False
    
    def update_rule(self, rule_name: str, **updates) -> bool:
        """
        Update a specific rule at runtime.
        
        Args:
            rule_name: Name of rule to update
            **updates: Fields to update (value, action, window_seconds, priority)
            
        Returns:
            True if rule was updated, False if not found
        """
        with self._lock:
            for rule in self._custom_rules:
                if rule.name == rule_name:
                    for key, value in updates.items():
                        if hasattr(rule, key):
                            # Validate if there's a validator
                            validator = getattr(rule, f"validate_{key}", None)
                            if validator:
                                validator(value)
                            setattr(rule, key, value)
                    
                    logging.info(f"[WebSocketLimits] Updated rule: {rule_name}")
                    return True
            return False
    
    # ========================================================================
    # HOOK REGISTRATION
    # ========================================================================
    
    def _register_hooks(self):
        """Register hooks with the WebSocket engine."""
        
        @self.engine.before_connect
        def check_connection_limits(conn_info: ConnectionInfo) -> bool:
            """Check if connection is allowed."""
            return self._check_connection_limits(conn_info)
        
        @self.engine.before_event
        def check_message_limits(event: str, data: Any, conn_info: ConnectionInfo) -> bool:
            """Check if message is allowed."""
            return self._check_message_limits(event, data, conn_info)
        
        @self.engine.after_disconnect
        def cleanup_limits(conn_info: ConnectionInfo):
            """Clean up limit data on disconnect."""
            self._cleanup_connection(conn_info.sid)
    
    def _setup_default_rules(self):
        """Create default limit rules from config."""
        rules = []
        
        # Connection limits
        if self.config.max_connections_per_ip > 0:
            rules.append(LimitRule(
                limit_type=LimitType.CONNECTIONS_PER_IP,
                scope=LimitScope.PER_IP,
                value=self.config.max_connections_per_ip,
                action=LimitAction.BLOCK,
                priority=1,
                name="default_ip_connections"
            ))
        
        if self.config.max_connections_per_user > 0:
            rules.append(LimitRule(
                limit_type=LimitType.CONNECTIONS_PER_USER,
                scope=LimitScope.PER_USER,
                value=self.config.max_connections_per_user,
                action=LimitAction.BLOCK,
                priority=1,
                name="default_user_connections"
            ))
        
        # Message rate limits (from config)
        if self.config.max_messages_per_minute_per_user > 0:
            rules.append(LimitRule(
                limit_type=LimitType.MESSAGES_PER_MINUTE,
                scope=LimitScope.PER_USER,
                value=self.config.max_messages_per_minute_per_user,
                window_seconds=60,
                action=LimitAction.BLOCK,
                priority=5,
                name="default_user_message_rate"
            ))
        
        # Message size limit
        if self.config.max_message_size > 0:
            rules.append(LimitRule(
                limit_type=LimitType.MESSAGE_SIZE,
                scope=LimitScope.PER_MESSAGE,
                value=self.config.max_message_size,
                action=LimitAction.BLOCK,
                priority=1,
                name="default_message_size"
            ))
        
        # Add to custom rules (but don't duplicate if already there)
        for rule in rules:
            if not any(r.name == rule.name for r in self._custom_rules):
                self._custom_rules.append(rule)
    
    # ========================================================================
    # CONNECTION LIMITS
    # ========================================================================
    
    def _check_connection_limits(self, conn_info: ConnectionInfo) -> bool:
        """
        Check if a new connection should be allowed.
        
        Returns:
            True if allowed, False if rejected
        """
        # Check IP-based limit
        if self.config.max_connections_per_ip > 0:
            ip_connections = len(self.engine.get_connections_by_ip(conn_info.client_ip))
            if ip_connections >= self.config.max_connections_per_ip:
                self.stats['connections_rejected'] += 1
                self._log_violation(
                    "ip_limit",
                    conn_info,
                    f"Too many connections from IP {conn_info.client_ip}",
                    {'current': ip_connections, 'limit': self.config.max_connections_per_ip}
                )
                return False
        
        # Check user-based limit (if authenticated)
        if conn_info.user_id and self.config.max_connections_per_user > 0:
            user_connections = len(self.engine.get_connections_by_user(conn_info.user_id))
            if user_connections >= self.config.max_connections_per_user:
                self.stats['connections_rejected'] += 1
                self._log_violation(
                    "user_limit",
                    conn_info,
                    f"Too many connections for user {conn_info.user_id}",
                    {'current': user_connections, 'limit': self.config.max_connections_per_user}
                )
                return False
        
        # Check quota-based limits
        if conn_info.user_id:
            quota = self.quota_manager.get_quota(conn_info.user_id)
            user_connections = len(self.engine.get_connections_by_user(conn_info.user_id))
            if user_connections >= quota.connection_limit:
                self.stats['connections_rejected'] += 1
                self._log_violation(
                    "quota_limit",
                    conn_info,
                    f"User {conn_info.user_id} exceeded connection quota",
                    {'current': user_connections, 'limit': quota.connection_limit}
                )
                return False
        
        return True
    
    # ========================================================================
    # MESSAGE LIMITS
    # ========================================================================
    
    def _check_message_limits(self, event: str, data: Any, conn_info: ConnectionInfo) -> bool:
        """
        Check if a message should be processed.
        
        Returns:
            True if allowed, False if blocked
        """
        self.stats['messages_checked'] += 1
        
        # Check message size first (fastest check)
        if not self._check_size_limit(data, conn_info):
            self.stats['messages_blocked'] += 1
            self.stats['size_violations'] += 1
            return False
        
        # Check rate limits
        if not self._check_rate_limits(event, conn_info):
            self.stats['messages_blocked'] += 1
            self.stats['rate_violations'] += 1
            return False
        
        # Check quota-based limits
        if not self._check_quota_limits(event, conn_info):
            self.stats['messages_blocked'] += 1
            return False
        
        # Check if connection is under backpressure
        if self._backpressure.is_under_backpressure(conn_info.sid):
            # Client is too slow - either block or queue
            if self.config.max_message_queue_size > 0:
                # Queue the message
                if self._backpressure.push(conn_info.sid, (event, data)):
                    # Message queued - we'll process it later
                    self.stats['backpressure_events'] += 1
                    return False  # Don't process now
                else:
                    # Queue full - client is too slow, maybe disconnect?
                    self.stats['messages_dropped'] += 1
                    if conn_info.message_count > 100:  # Heuristic
                        # Client is consistently slow - disconnect
                        self.engine.disconnect_client(conn_info.sid)
                    return False
        
        self.stats['messages_allowed'] += 1
        return True
    
    def _check_size_limit(self, data: Any, conn_info: ConnectionInfo) -> bool:
        """
        Check if message size is within limits.
        
        Returns:
            True if size OK, False if too large
        """
        # Estimate message size
        try:
            import json
            size = len(json.dumps(data).encode('utf-8'))
        except:
            # Can't serialize - assume safe
            return True
        
        # Get user-specific quota
        if conn_info.user_id:
            quota = self.quota_manager.get_quota(conn_info.user_id)
            if size > quota.max_message_size:
                self._log_violation(
                    "size_limit",
                    conn_info,
                    f"Message size {size} exceeds quota {quota.max_message_size}",
                    {'size': size, 'limit': quota.max_message_size}
                )
                return False
        
        # Check global limit
        if size > self.config.max_message_size:
            self._log_violation(
                "size_limit",
                conn_info,
                f"Message size {size} exceeds global limit {self.config.max_message_size}",
                {'size': size, 'limit': self.config.max_message_size}
            )
            return False
        
        # Track bandwidth
        if conn_info.user_id:
            bw_key = f"bw:{conn_info.user_id}"
            self._bandwidth_counters.add(bw_key)
        
        return True
    
    def _check_rate_limits(self, event: str, conn_info: ConnectionInfo) -> bool:
        """
        Check rate limits for this message.
        
        Returns:
            True if within limits, False if exceeded
        """
        # Check each rule
        for rule in sorted(self._custom_rules, key=lambda r: r.priority):
            # Skip non-rate-limit rules
            if rule.limit_type not in [LimitType.MESSAGES_PER_MINUTE, LimitType.MESSAGES_PER_HOUR]:
                continue
            
            # Generate key for this rule
            key = rule.key_for(conn_info, event)
            if not key:
                continue
            
            # Count in window
            count = self._message_counters.count_in_window(key, rule.window_seconds)
            
            # Check if exceeded
            if count >= rule.value:
                self._log_violation(
                    "rate_limit",
                    conn_info,
                    f"Rate limit exceeded for {rule.name}",
                    {
                        'rule': rule.name,
                        'current': count,
                        'limit': rule.value,
                        'window': rule.window_seconds
                    },
                    event=event
                )
                
                # Take action based on rule
                if rule.action == LimitAction.BLOCK:
                    return False
                elif rule.action == LimitAction.DELAY:
                    # TODO: Implement delay
                    pass
                elif rule.action == LimitAction.DROP:
                    # Silently drop
                    return False
            
            # Add to counter
            self._message_counters.add(key)
        
        return True
    
    def _check_quota_limits(self, event: str, conn_info: ConnectionInfo) -> bool:
        """
        Check quota-based limits for authenticated users.
        
        Returns:
            True if within quota, False if exceeded
        """
        if not conn_info.user_id:
            return True  # No quota for anonymous
        
        quota = self.quota_manager.get_quota(conn_info.user_id)
        
        # Check minute rate
        minute_key = f"quota_min:{conn_info.user_id}"
        minute_count = self._message_counters.count_in_window(minute_key, 60)
        
        if minute_count >= quota.message_limit_per_minute:
            self._log_violation(
                "quota_minute",
                conn_info,
                f"User {conn_info.user_id} exceeded minute quota",
                {'current': minute_count, 'limit': quota.message_limit_per_minute}
            )
            return False
        
        # Check hour rate
        hour_key = f"quota_hour:{conn_info.user_id}"
        hour_count = self._message_counters.count_in_window(hour_key, 3600)
        
        if hour_count >= quota.message_limit_per_hour:
            self._log_violation(
                "quota_hour",
                conn_info,
                f"User {conn_info.user_id} exceeded hour quota",
                {'current': hour_count, 'limit': quota.message_limit_per_hour}
            )
            return False
        
        # Add to counters
        self._message_counters.add(minute_key)
        self._message_counters.add(hour_key)
        
        return True
    
    # ========================================================================
    # BACKPRESSURE HANDLING
    # ========================================================================
    
    def process_queued_messages(self, sid: str):
        """
        Process any queued messages for a connection.
        
        This should be called when a client is ready to receive more messages.
        """
        while True:
            # Get next queued message
            queued = self._backpressure.pop(sid)
            if not queued:
                break
            
            # Process the message
            event, data = queued
            # This would need integration with engine's event system
            # For now, just log
            logging.debug(f"[Limits] Processing queued message for {sid}: {event}")
        
        # Clear backpressure flag if queue is manageable
        if self._backpressure.queue_size(sid) < self.config.max_message_queue_size / 2:
            self._backpressure.clear_backpressure(sid)
            self.stats['current_backpressure'] = len(self._backpressure._backpressure_connections)
    
    # ========================================================================
    # UTILITY METHODS
    # ========================================================================
    
    def _log_violation(
        self,
        violation_type: str,
        conn_info: ConnectionInfo,
        message: str,
        details: Dict[str, Any],
        event: Optional[str] = None
    ):
        """Log a limit violation."""
        violation = {
            'type': violation_type,
            'timestamp': time.time(),
            'sid': conn_info.sid,
            'ip': conn_info.client_ip,
            'user_id': conn_info.user_id,
            'event': event,
            'message': message,
            'details': details
        }
        
        self._recent_violations.append(violation)
        
        # Log if configured (would need log_level from config)
        logging.info(f"[Limits] {violation_type}: {message}")
    
    def _cleanup_connection(self, sid: str):
        """Clean up all data for a disconnected connection."""
        self._backpressure.cleanup(sid)
        
        # Note: We don't clean up rate limit counters automatically
        # They will expire naturally via the sliding window
    
    # ========================================================================
    # STATISTICS
    # ========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive limits statistics."""
        self.stats['current_backpressure'] = len(self._backpressure._backpressure_connections)
        
        return {
            'counts': self.stats.copy(),
            'recent_violations': list(self._recent_violations)[-10:],  # Last 10
            'active_rules': len(self._custom_rules),
            'quotas': self.quota_manager.get_stats(),
            'backpressure': self._backpressure.get_stats(),
            'counters': self._message_counters.get_stats()
        }
    
    def get_violations(self, limit: int = 100) -> List[Dict]:
        """Get recent limit violations."""
        return list(self._recent_violations)[-limit:]
    
    def reset_counters(self):
        """Reset all statistics counters."""
        for key in self.stats:
            if isinstance(self.stats[key], int):
                self.stats[key] = 0


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def setup_websocket_limits(
    engine: WebSocketEngine,
    config: LimitsConfig,
    quota_manager: Optional[QuotaManager] = None
) -> WebSocketLimitsManager:
    """
    Set up WebSocket limits management.
    
    Args:
        engine: WebSocket engine instance
        config: Limits configuration
        quota_manager: Optional quota manager
        
    Returns:
        Configured WebSocketLimitsManager
    """
    manager = WebSocketLimitsManager(engine, config, quota_manager)
    return manager