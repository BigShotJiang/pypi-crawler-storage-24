"""
WebSocket Security Module - GatePipeline Integration with Runtime Updates

This module bridges the existing GatePipeline security system with WebSocket connections,
ensuring that:
1. All WebSocket connections are authenticated using the same tokens as HTTP
2. Banned users are blocked at connection time
3. Token expiration is handled gracefully
4. Permissions are enforced per-event
5. Security audit logging works for WebSocket
6. Supports runtime updates to security settings

The key insight: We reuse the EXACT same GatePipeline logic, just wrapped in a
WebSocket context.
"""

import time
import logging
import threading
from typing import Dict, Any, Optional, Callable, List, Tuple
from dataclasses import dataclass, field
from functools import wraps
import traceback

from flask import request, session
from flask_socketio import emit

# Import from parent modules
from ..gate import GatePipeline, GateConfig, AuthType, GateResult
from ...tokens import TokenManager

# Import WebSocket modules
from .engine import WebSocketEngine, ConnectionInfo


# ============================================================================
# SECURITY CONFIGURATION
# ============================================================================

@dataclass
class SecurityConfig:
    """
    Security configuration for WebSocket connections.
    
    All security-specific settings are defined here with validation methods
    to support runtime updates through the WebSocketConfigManager.
    
    Each setting can have:
    - A validate_<setting> method for runtime updates
    - An on_<setting>_updated hook to react to changes
    """
    
    # ========================================================================
    # AUTHENTICATION SETTINGS
    # ========================================================================
    
    default_auth_required: bool = True
    """
    If True, all events require authentication by default.
    Can be overridden per-event using event_auth_requirements.
    """
    
    token_sources: List[str] = field(default_factory=lambda: ['query', 'header', 'auth'])
    """
    Where to look for tokens in WebSocket connection:
    - 'query': ?token=xxx in connection URL
    - 'header': Authorization header in WebSocket upgrade request
    - 'auth': Socket.IO auth field during connection
    
    Order matters - sources are checked in the order listed.
    """
    
    reject_unauthenticated: bool = True
    """
    Whether to reject connections that fail authentication.
    If False, unauthenticated connections are allowed but cannot access
    events that require authentication.
    """
    
    # ========================================================================
    # TOKEN REFRESH SETTINGS
    # ========================================================================
    
    allow_token_refresh: bool = True
    """
    Whether to allow token refresh over WebSocket.
    If True, clients can refresh expired tokens without reconnecting.
    """
    
    refresh_event_name: str = "refresh_token"
    """
    Event name for token refresh requests.
    Clients should emit to this event to refresh their token.
    """
    
    refresh_grace_period: int = 300  # 5 minutes
    """
    How long after token expiry to allow refresh (seconds).
    Gives clients time to refresh before being disconnected.
    """
    
    # ========================================================================
    # PER-EVENT REQUIREMENTS
    # ========================================================================
    
    event_auth_requirements: Dict[str, bool] = field(default_factory=dict)
    """
    Map event names to whether they require authentication.
    These override the default_auth_required setting.
    
    Example:
        {
            'public.announcement': False,  # Public event
            'private.chat': True,           # Requires auth
            'admin.status': True             # Requires auth
        }
    """
    
    # ========================================================================
    # BLOCKLISTS (for runtime updates)
    # ========================================================================
    
    blocked_identities: List[str] = field(default_factory=list)
    """
    List of raw identities (IDs, keys) that are blocked from connecting.
    Updated at runtime via security manager.
    """
    
    blocked_ips: List[str] = field(default_factory=list)
    """
    List of IP addresses that are blocked from connecting.
    Updated at runtime via security manager.
    """
    
    # ========================================================================
    # VALIDATION METHODS (for runtime updates)
    # ========================================================================
    
    def validate_default_auth_required(self, value: bool) -> None:
        """
        Validate default_auth_required before runtime update.
        
        Args:
            value: New default_auth_required value
            
        Raises:
            ValueError: If validation fails
        """
        if not isinstance(value, bool):
            raise ValueError(f"default_auth_required must be boolean, got {type(value)}")
    
    def validate_token_sources(self, value: List[str]) -> None:
        """
        Validate token_sources before runtime update.
        
        Args:
            value: New token_sources value
            
        Raises:
            ValueError: If validation fails
        """
        valid_sources = ['query', 'header', 'auth']
        
        if not isinstance(value, list):
            raise ValueError(f"token_sources must be a list, got {type(value)}")
        
        for source in value:
            if source not in valid_sources:
                raise ValueError(
                    f"Invalid token source '{source}'. "
                    f"Must be one of {valid_sources}"
                )
    
    def validate_reject_unauthenticated(self, value: bool) -> None:
        """
        Validate reject_unauthenticated before runtime update.
        
        Args:
            value: New reject_unauthenticated value
            
        Raises:
            ValueError: If validation fails
        """
        if not isinstance(value, bool):
            raise ValueError(f"reject_unauthenticated must be boolean, got {type(value)}")
    
    def validate_allow_token_refresh(self, value: bool) -> None:
        """
        Validate allow_token_refresh before runtime update.
        
        Args:
            value: New allow_token_refresh value
            
        Raises:
            ValueError: If validation fails
        """
        if not isinstance(value, bool):
            raise ValueError(f"allow_token_refresh must be boolean, got {type(value)}")
    
    def validate_refresh_event_name(self, value: str) -> None:
        """
        Validate refresh_event_name before runtime update.
        
        Args:
            value: New refresh_event_name value
            
        Raises:
            ValueError: If validation fails
        """
        if not isinstance(value, str) or not value.strip():
            raise ValueError("refresh_event_name must be a non-empty string")
    
    def validate_refresh_grace_period(self, value: int) -> None:
        """
        Validate refresh_grace_period before runtime update.
        
        Args:
            value: New refresh_grace_period value in seconds
            
        Raises:
            ValueError: If validation fails
        """
        if not isinstance(value, int) or value < 0:
            raise ValueError(f"refresh_grace_period must be a non-negative integer, got {value}")
        
        if value > 86400:  # 24 hours
            logging.warning(f"Very high refresh_grace_period: {value}s")
    
    def validate_blocked_identities(self, value: List[str]) -> None:
        """
        Validate blocked_identities before runtime update.
        
        Args:
            value: New blocked_identities list
            
        Raises:
            ValueError: If validation fails
        """
        if not isinstance(value, list):
            raise ValueError(f"blocked_identities must be a list, got {type(value)}")
    
    def validate_blocked_ips(self, value: List[str]) -> None:
        """
        Validate blocked_ips before runtime update.
        
        Args:
            value: New blocked_ips list
            
        Raises:
            ValueError: If validation fails
        """
        if not isinstance(value, list):
            raise ValueError(f"blocked_ips must be a list, got {type(value)}")
    
    # ========================================================================
    # UPDATE HOOKS (called after successful runtime updates)
    # ========================================================================
    
    def on_default_auth_required_updated(self, value: bool) -> None:
        """
        Hook called after default_auth_required is updated at runtime.
        
        Args:
            value: New default_auth_required value
        """
        logging.info(f"Security: default_auth_required updated to {value}")
    
    def on_token_sources_updated(self, value: List[str]) -> None:
        """
        Hook called after token_sources is updated at runtime.
        
        Args:
            value: New token_sources value
        """
        logging.info(f"Security: token_sources updated to {value}")
    
    def on_reject_unauthenticated_updated(self, value: bool) -> None:
        """
        Hook called after reject_unauthenticated is updated at runtime.
        
        Args:
            value: New reject_unauthenticated value
        """
        logging.info(f"Security: reject_unauthenticated updated to {value}")
    
    def on_allow_token_refresh_updated(self, value: bool) -> None:
        """
        Hook called after allow_token_refresh is updated at runtime.
        
        Args:
            value: New allow_token_refresh value
        """
        logging.info(f"Security: allow_token_refresh updated to {value}")
        
        # If token refresh was disabled, we might want to clean up refresh handlers
        if not value:
            logging.info("Security: Token refresh disabled - refresh handlers will be removed")
    
    # ========================================================================
    # INITIAL VALIDATION (called at startup)
    # ========================================================================
    
    def __post_init__(self):
        """Validate configuration at startup."""
        self._validate_token_sources()
        self._validate_refresh_settings()
        self._validate_event_requirements()
    
    def _validate_token_sources(self):
        """Validate token sources configuration."""
        valid_sources = ['query', 'header', 'auth']
        
        for source in self.token_sources:
            if source not in valid_sources:
                raise ValueError(
                    f"Invalid token source '{source}' in configuration. "
                    f"Must be one of {valid_sources}"
                )
    
    def _validate_refresh_settings(self):
        """Validate token refresh settings."""
        if self.refresh_grace_period < 0:
            raise ValueError("refresh_grace_period cannot be negative")
        
        if self.allow_token_refresh and not self.refresh_event_name:
            raise ValueError("refresh_event_name must be set when token refresh is enabled")
    
    def _validate_event_requirements(self):
        """Validate event authentication requirements."""
        for event, required in self.event_auth_requirements.items():
            if not isinstance(required, bool):
                raise ValueError(
                    f"Event auth requirement for '{event}' must be boolean, "
                    f"got {type(required)}"
                )
    
    # ========================================================================
    # HELPER METHODS
    # ========================================================================
    
    def requires_auth(self, event: str) -> bool:
        """
        Check if a specific event requires authentication.
        
        Args:
            event: Event name
            
        Returns:
            True if event requires auth, False otherwise
        """
        return self.event_auth_requirements.get(event, self.default_auth_required)
    
    def get_gate_config(self) -> GateConfig:
        """
        Get base GateConfig for WebSocket connections.
        
        This creates a GateConfig appropriate for WebSocket authentication.
        """
        return GateConfig(
            auth_required=True,  # We'll handle this at WebSocket level
            auth_type=AuthType.TOKEN_PAYLOAD,  # Use token payload (flexible)
            tokenized_fields=None,  # No tokenization needed
            # Rate limiting is handled separately by limits module
        )


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class WebSocketAuthResult:
    """
    Result of WebSocket authentication attempt.
    
    This mirrors GateResult but adds WebSocket-specific fields.
    """
    success: bool
    """Whether authentication succeeded"""
    
    initial_value: Optional[Any] = None
    """Recovered raw identity (if successful)"""
    
    user_data: Optional[Dict[str, Any]] = None
    """Full user data from token"""
    
    error_code: Optional[str] = None
    """Error code if authentication failed"""
    
    error_message: Optional[str] = None
    """Human-readable error message"""
    
    connection_allowed: bool = True
    """Whether connection should be allowed (even if unauthenticated)"""
    
    @classmethod
    def from_gate_result(cls, gate_result: GateResult) -> 'WebSocketAuthResult':
        """Create from a GatePipeline result."""
        if gate_result.success:
            return cls(
                success=True,
                initial_value=gate_result.context.get("session_identity_raw"),
                user_data=gate_result.context.user if gate_result.context else None,
                connection_allowed=True
            )
        else:
            return cls(
                success=False,
                error_code=gate_result.error.get("code") if gate_result.error else "auth_failed",
                error_message=gate_result.error.get("message") if gate_result.error else "Authentication failed",
                connection_allowed=False
            )
    
    @classmethod
    def anonymous(cls) -> 'WebSocketAuthResult':
        """Create result for unauthenticated (but allowed) connection."""
        return cls(
            success=False,
            initial_value=None,
            connection_allowed=True,
            error_code="not_authenticated",
            error_message="Connection allowed but not authenticated"
        )
    
    @classmethod
    def rejected(cls, code: str, message: str) -> 'WebSocketAuthResult':
        """Create result for rejected connection."""
        return cls(
            success=False,
            connection_allowed=False,
            error_code=code,
            error_message=message
        )


# ============================================================================
# MOCK REQUEST CLASS
# ============================================================================

class MockWebSocketRequest:
    """
    A mock Flask request object that makes GatePipeline think it's handling an HTTP request.
    
    This is the key to reusing GatePipeline - we wrap WebSocket connection data
    in something that looks like a Flask request.
    """
    
    def __init__(self, environ: Dict[str, Any], auth_data: Dict[str, Any], client_ip: str):
        """
        Create mock request from WebSocket connection data.
        
        Args:
            environ: WSGI environ from Socket.IO connection
            auth_data: Authentication data from Socket.IO auth field
            client_ip: Client IP address
        """
        self.environ = environ
        self._auth_data = auth_data
        self.remote_addr = client_ip
        
        # Headers from environ
        self.headers = self._extract_headers(environ)
        
        # Mock request data
        self._json_data = None
        self._args_data = None
    
    def _extract_headers(self, environ: Dict[str, Any]) -> Dict[str, str]:
        """Extract HTTP headers from WSGI environ."""
        headers = {}
        for key, value in environ.items():
            if key.startswith('HTTP_'):
                header_name = key[5:].replace('_', '-').title()
                headers[header_name] = value
        
        # Add content type if present
        if 'CONTENT_TYPE' in environ:
            headers['Content-Type'] = environ['CONTENT_TYPE']
        
        return headers
    
    @property
    def is_json(self) -> bool:
        """Mock is_json property."""
        return self.headers.get('Content-Type') == 'application/json'
    
    def get_json(self, silent: bool = False) -> Optional[Dict]:
        """Mock get_json method."""
        if self._json_data is None and self._auth_data:
            # Use auth data as JSON body
            self._json_data = self._auth_data
        return self._json_data
    
    @property
    def args(self) -> Dict:
        """Mock args property (query parameters)."""
        if self._args_data is None:
            # Parse query string from environ
            from urllib.parse import parse_qs
            query_string = self.environ.get('QUERY_STRING', '')
            self._args_data = {k: v[0] if len(v) == 1 else v 
                              for k, v in parse_qs(query_string).items()}
        return self._args_data
    
    @property
    def form(self) -> Dict:
        """Mock form property (always empty for WebSocket)."""
        return {}
    
    @property
    def method(self) -> str:
        """Mock HTTP method."""
        return "WEBSOCKET"
    
    @property
    def path(self) -> str:
        """Mock request path."""
        return self.environ.get('PATH_INFO', '/socket.io')


# ============================================================================
# SECURITY MANAGER
# ============================================================================

class WebSocketSecurityManager:
    """
    Manages security for all WebSocket connections.
    
    This class:
    1. Intercepts connections to authenticate via GatePipeline
    2. Enforces authentication requirements per event
    3. Handles token refresh over WebSocket
    4. Provides audit logging for WebSocket security events
    5. Supports runtime updates to security configuration
    
    The manager uses SecurityConfig for all settings and supports runtime updates
    through the WebSocketConfigManager.
    """
    
    def __init__(
        self,
        engine: WebSocketEngine,
        gate_pipeline: GatePipeline,
        token_manager: TokenManager,
        config: SecurityConfig
    ):
        """
        Initialize security manager.
        
        Args:
            engine: WebSocket engine instance
            gate_pipeline: GatePipeline for authentication
            token_manager: TokenManager for token operations
            config: Security configuration
        """
        self.engine = engine
        self.gate_pipeline = gate_pipeline
        self.token_manager = token_manager
        self.config = config
        
        # Track authenticated connections
        self._authenticated_connections: Dict[str, Dict[str, Any]] = {}
        """Maps connection SID to auth data"""
        
        # Token refresh tracking
        self._refresh_tokens: Dict[str, Dict[str, Any]] = {}
        """Maps connection SID to refresh token data"""
        
        # Statistics
        self.stats = {
            'auth_attempts': 0,
            'auth_successes': 0,
            'auth_failures': 0,
            'rejected_connections': 0,
            'token_refreshes': 0,
            'refresh_failures': 0,
            'blocked_ips_hits': 0,
            'blocked_identities_hits': 0,
        }
        
        # Locks for thread safety
        self._lock = threading.RLock()
        
        # Register hooks with engine
        self._register_hooks()
        
        # Set up token refresh if enabled
        if self.config.allow_token_refresh:
            self.setup_token_refresh()
        
        logging.info("[WebSocketSecurity] Security manager initialized")
        logging.info(f"  - Default auth required: {self.config.default_auth_required}")
        logging.info(f"  - Token sources: {self.config.token_sources}")
        logging.info(f"  - Reject unauthenticated: {self.config.reject_unauthenticated}")
        logging.info(f"  - Token refresh: {self.config.allow_token_refresh}")
    
    # ========================================================================
    # RUNTIME UPDATE METHODS
    # ========================================================================
    
    def update_config(self, new_config: SecurityConfig) -> None:
        """
        Update security configuration at runtime.
        
        This method is called by the WebSocketConfigManager when
        security settings are updated.
        
        Args:
            new_config: Updated security configuration
        """
        with self._lock:
            old_config = self.config
            self.config = new_config
            
            # Handle token refresh setup/teardown if changed
            if old_config.allow_token_refresh != new_config.allow_token_refresh:
                if new_config.allow_token_refresh:
                    self.setup_token_refresh()
                    logging.info("[WebSocketSecurity] Token refresh enabled at runtime")
                else:
                    # Token refresh disabled - cleanup will happen naturally
                    logging.info("[WebSocketSecurity] Token refresh disabled at runtime")
            
            logging.info("[WebSocketSecurity] Configuration updated at runtime")
    
    def block_user(self, user_id: str) -> None:
        """
        Block a user at runtime.
        
        Args:
            user_id: User ID to block
        """
        with self._lock:
            if user_id not in self.config.blocked_users:
                self.config.blocked_users.append(user_id)
                
                # Disconnect any existing connections for this user
                connections = self.engine.get_connections_by_user(user_id)
                for conn in connections:
                    self.engine.disconnect_client(conn.sid)
                    logging.info(f"[WebSocketSecurity] Blocked user {user_id} disconnected")
                
                logging.info(f"[WebSocketSecurity] User {user_id} added to blocklist")
    
    def unblock_user(self, user_id: str) -> None:
        """
        Unblock a user at runtime.
        
        Args:
            user_id: User ID to unblock
        """
        with self._lock:
            if user_id in self.config.blocked_users:
                self.config.blocked_users.remove(user_id)
                logging.info(f"[WebSocketSecurity] User {user_id} removed from blocklist")
    
    def block_ip(self, ip: str) -> None:
        """
        Block an IP address at runtime.
        
        Args:
            ip: IP address to block
        """
        with self._lock:
            if ip not in self.config.blocked_ips:
                self.config.blocked_ips.append(ip)
                
                # Disconnect any existing connections from this IP
                connections = self.engine.get_connections_by_ip(ip)
                for conn in connections:
                    self.engine.disconnect_client(conn.sid)
                    logging.info(f"[WebSocketSecurity] Blocked IP {ip} disconnected")
                
                logging.info(f"[WebSocketSecurity] IP {ip} added to blocklist")
    
    def unblock_ip(self, ip: str) -> None:
        """
        Unblock an IP address at runtime.
        
        Args:
            ip: IP address to unblock
        """
        with self._lock:
            if ip in self.config.blocked_ips:
                self.config.blocked_ips.remove(ip)
                logging.info(f"[WebSocketSecurity] IP {ip} removed from blocklist")
    
    # ========================================================================
    # HOOK REGISTRATION
    # ========================================================================
    
    def _register_hooks(self):
        """Register security hooks with the WebSocket engine."""
        
        @self.engine.before_connect
        def authenticate_connection(conn_info: ConnectionInfo) -> bool:
            """Authenticate connection before accepting."""
            return self._handle_connection_attempt(conn_info)
        
        @self.engine.before_event
        def check_event_auth(event: str, data: Any, conn_info: ConnectionInfo) -> bool:
            """Check if event requires authentication."""
            return self._check_event_auth(event, conn_info)
        
        @self.engine.after_disconnect
        def cleanup_auth(conn_info: ConnectionInfo):
            """Clean up authentication data on disconnect."""
            self._cleanup_connection(conn_info.sid)
    
    # ========================================================================
    # CONNECTION HANDLING
    # ========================================================================
    
    def _handle_connection_attempt(self, conn_info: ConnectionInfo) -> bool:
        """
        Handle a new connection attempt with security checks.
        
        Args:
            conn_info: Connection information
            
        Returns:
            True if connection allowed, False if rejected
        """
        # Check IP blocklist
        if conn_info.client_ip in self.config.blocked_ips:
            self.stats['blocked_ips_hits'] += 1
            logging.info(f"[WebSocketSecurity] Blocked connection from blocked IP: {conn_info.client_ip}")
            return False
        
        # Authenticate the connection
        result = self._authenticate_connection(conn_info)
        
        if result.success:
            # Connection authenticated
            self.engine.authenticate_connection(
                result.initial_value,
                conn_info.sid,
                result.user_data
            )
            
            # Check identity blocklist
            if result.initial_value and str(result.initial_value) in self.config.blocked_identities:
                self.stats['blocked_identities_hits'] += 1
                logging.info(f"[WebSocketSecurity] Blocked connection from blocked identity: {result.initial_value}")
                return False
            
            return True
        
        elif result.connection_allowed and not self.config.reject_unauthenticated:
            # Allow unauthenticated connection
            logging.info(f"[WebSocketSecurity] Allowing unauthenticated connection: {conn_info.sid}")
            return True
        
        else:
            # Reject connection
            logging.info(f"[WebSocketSecurity] Rejecting connection {conn_info.sid}: {result.error_message}")
            self.stats['rejected_connections'] += 1
            
            # Send rejection reason if possible
            try:
                emit('auth_error', {
                    'code': result.error_code,
                    'message': result.error_message
                })
            except:
                pass
            
            return False
    
    def _authenticate_connection(self, conn_info: ConnectionInfo) -> WebSocketAuthResult:
        """
        Authenticate a WebSocket connection using GatePipeline.
        
        This is the core method that bridges WebSocket and HTTP security.
        
        Args:
            conn_info: Connection information
            
        Returns:
            Authentication result
        """
        self.stats['auth_attempts'] += 1
        
        # Extract token from connection
        token, token_source = self._extract_token(conn_info)
        
        if not token:
            # No token provided - handle based on config
            if self.config.default_auth_required:
                return WebSocketAuthResult.rejected(
                    "missing_token",
                    "Authentication token required"
                )
            else:
                return WebSocketAuthResult.anonymous()
        
        # Create mock request for GatePipeline
        mock_request = self._create_mock_request(conn_info, token, token_source)
        
        # Get base GateConfig
        gate_config = self.config.get_gate_config()
        
        # Run through GatePipeline
        try:
            gate_result = self.gate_pipeline.process(mock_request, gate_config)
            result = WebSocketAuthResult.from_gate_result(gate_result)
        except Exception as e:
            # GatePipeline itself failed
            logging.error(f"[WebSocketSecurity] GatePipeline error: {e}")
            traceback.print_exc()
            
            result = WebSocketAuthResult.rejected(
                "gate_pipeline_error",
                f"Security system error: {str(e)}"
            )
        
        # Update statistics
        if result.success:
            self.stats['auth_successes'] += 1
            
            # Store auth data
            with self._lock:
                self._authenticated_connections[conn_info.sid] = {
                    'user_id': result.user_id,
                    'user_data': result.user_data,
                    'token': token,
                    'token_source': token_source,
                    'auth_time': time.time()
                }
        else:
            self.stats['auth_failures'] += 1
        
        return result
    
    def _extract_token(self, conn_info: ConnectionInfo) -> Tuple[Optional[str], Optional[str]]:
        """
        Extract authentication token from connection.
        
        Checks multiple sources based on config.token_sources.
        
        Returns:
            Tuple of (token, source) or (None, None) if not found
        """
        for source in self.config.token_sources:
            if source == 'query':
                query_token = getattr(conn_info, 'query_token', None)
                if query_token:
                    return query_token, 'query'
            
            elif source == 'header':
                auth_header = getattr(conn_info, 'auth_header', None)
                if auth_header and auth_header.startswith('Bearer '):
                    return auth_header[7:], 'header'
            
            elif source == 'auth':
                auth_data = getattr(conn_info, 'auth_data', {})
                if isinstance(auth_data, dict):
                    token = auth_data.get('token') or auth_data.get('access_token')
                    if token:
                        return token, 'auth'
        
        return None, None
    
    def _create_mock_request(
        self,
        conn_info: ConnectionInfo,
        token: str,
        token_source: str
    ) -> MockWebSocketRequest:
        """
        Create mock Flask request for GatePipeline.
        
        This wraps the token in a format that GatePipeline expects.
        """
        # Build auth data based on token source
        auth_data = {'token': token}
        
        # Build WSGI environ
        environ = {
            'PATH_INFO': '/websocket',
            'QUERY_STRING': f"token={token}" if token_source == 'query' else '',
            'REMOTE_ADDR': conn_info.client_ip,
        }
        
        # Add Authorization header if from header source
        if token_source == 'header':
            environ['HTTP_AUTHORIZATION'] = f'Bearer {token}'
        
        # Create mock request
        mock_request = MockWebSocketRequest(
            environ=environ,
            auth_data=auth_data,
            client_ip=conn_info.client_ip
        )
        
        return mock_request
    
    # ========================================================================
    # EVENT AUTHORIZATION
    # ========================================================================
    
    def _check_event_auth(self, event: str, conn_info: ConnectionInfo) -> bool:
        """
        Check if connection is authorized to emit an event.
        
        Args:
            event: Event name
            conn_info: Connection information
            
        Returns:
            True if authorized, False if should be blocked
        """
        # Check if event requires authentication
        requires_auth = self.config.requires_auth(event)
        
        # Check if connection is authenticated
        is_authenticated = conn_info.is_authenticated
        
        if requires_auth and not is_authenticated:
            # Unauthenticated connection trying to access protected event
            logging.info(f"[WebSocketSecurity] Blocked unauthenticated event '{event}' from {conn_info.sid}")
            
            # Send error to client
            try:
                emit('error', {
                    'code': 'unauthorized',
                    'message': f"Event '{event}' requires authentication"
                })
            except:
                pass
            
            return False
        
        return True
    
    # ========================================================================
    # TOKEN REFRESH
    # ========================================================================
    
    def setup_token_refresh(self):
        """
        Set up token refresh event handler.
        
        This allows clients to refresh expired tokens over WebSocket.
        """
        if not self.config.allow_token_refresh:
            return
        
        @self.engine.on(self.config.refresh_event_name)
        def handle_token_refresh(data: Dict[str, Any]):
            """Handle token refresh requests."""
            sid = request.sid
            conn_info = self.engine.get_connection_info(sid)
            
            if not conn_info:
                return {'success': False, 'error': 'Connection not found'}
            
            # Extract refresh token
            refresh_token = None
            if isinstance(data, dict):
                refresh_token = data.get('refresh_token') or data.get('token')
            
            if not refresh_token:
                return {
                    'success': False,
                    'error': 'missing_token',
                    'message': 'Refresh token required'
                }
            
            # Attempt to refresh
            result = self._refresh_token(refresh_token, conn_info)
            
            if result['success']:
                # Update authentication
                self.engine.authenticate_connection(
                    result['user_id'],
                    sid,
                    result.get('user_data', {})
                )
                
                # Store refresh data
                with self._lock:
                    self._refresh_tokens[sid] = {
                        'refreshed_at': time.time(),
                        'old_token': refresh_token,
                        'new_token': result.get('new_token')
                    }
                
                self.stats['token_refreshes'] += 1
            
            return result
        
        logging.info(f"[WebSocketSecurity] Token refresh handler registered on '{self.config.refresh_event_name}'")
    
    def _refresh_token(self, refresh_token: str, conn_info: ConnectionInfo) -> Dict[str, Any]:
        """
        Attempt to refresh an authentication token.
        
        Args:
            refresh_token: The refresh token
            conn_info: Connection information
            
        Returns:
            Dictionary with refresh result
        """
        try:
            # Validate refresh token
            is_valid = self.token_manager.validate_token(refresh_token, 'refresh')
            
            if not is_valid:
                self.stats['refresh_failures'] += 1
                return {
                    'success': False,
                    'error': 'invalid_token',
                    'message': 'Invalid or expired refresh token'
                }
            
            # Decode to get user data
            payload = self.token_manager.decode_token(refresh_token, 'refresh')
            
            if not payload:
                self.stats['refresh_failures'] += 1
                return {
                    'success': False,
                    'error': 'invalid_payload',
                    'message': 'Invalid token payload'
                }
            
            # Create new access token
            raw_identity = payload.get('session_identity_raw') or payload.get('user_id') or payload.get('sub')
            if not raw_identity:
                return {
                    'success': False,
                    'error': 'no_identity',
                    'message': 'Token missing identity identification'
                }
            
            # Use the default token type to create the new session token
            new_token = self.token_manager.create_session_token(raw_identity)
            
            # Refresh tokens are handled as sub-sessions of the primary auth
            new_refresh_token = self.token_manager.create_session_token(raw_identity)
            
            return {
                'success': True,
                'identity': raw_identity,
                'token': new_token,
                'refresh_token': new_refresh_token,
                'expires_in': self.config.refresh_grace_period
            }
            
        except Exception as e:
            self.stats['refresh_failures'] += 1
            logging.error(f"[WebSocketSecurity] Token refresh error: {e}")
            return {
                'success': False,
                'error': 'refresh_failed',
                'message': f'Token refresh failed: {str(e)}'
            }
    
    # ========================================================================
    # CLEANUP
    # ========================================================================
    
    def _cleanup_connection(self, sid: str):
        """Remove authentication data for disconnected connection."""
        with self._lock:
            if sid in self._authenticated_connections:
                del self._authenticated_connections[sid]
            
            if sid in self._refresh_tokens:
                del self._refresh_tokens[sid]
    
    # ========================================================================
    # PUBLIC API
    # ========================================================================
    
    def require_auth(self, event: Optional[str] = None):
        """
        Decorator to require authentication for an event handler.
        
        This is a developer-friendly way to mark events as requiring auth.
        
        Example:
            >>> @portal.on_event('secret_chat')
            >>> @security.require_auth()
            >>> def handle_secret(data):
            >>>     return {"message": "This is secure"}
        
        Args:
            event: Event name (if None, uses function name)
        """
        def decorator(func: Callable):
            @wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)
            
            # Register requirement
            event_name = event or func.__name__
            with self._lock:
                self.config.event_auth_requirements[event_name] = True
            
            logging.info(f"[WebSocketSecurity] Event '{event_name}' marked as requiring auth")
            return wrapper
        return decorator
    
    def public(self, event: Optional[str] = None):
        """
        Decorator to mark an event as public (no auth required).
        
        Example:
            >>> @portal.on_event('public_chat')
            >>> @security.public()
            >>> def handle_public(data):
            >>>     return {"message": "Anyone can send this"}
        """
        def decorator(func: Callable):
            @wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)
            
            # Register as public
            event_name = event or func.__name__
            with self._lock:
                self.config.event_auth_requirements[event_name] = False
            
            logging.info(f"[WebSocketSecurity] Event '{event_name}' marked as public")
            return wrapper
        return decorator
    
    def get_authenticated_user(self, sid: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Get authenticated user data for a connection.
        
        Args:
            sid: Session ID (None for current connection)
            
        Returns:
            User data dict or None if not authenticated
        """
        sid = sid or request.sid
        return self._authenticated_connections.get(sid)
    
    def get_security_stats(self) -> Dict[str, Any]:
        """Get security statistics."""
        with self._lock:
            return {
                **self.stats,
                'active_authenticated': len(self._authenticated_connections),
                'blocked_users': len(self.config.blocked_users),
                'blocked_ips': len(self.config.blocked_ips),
                'config': {
                    'default_auth_required': self.config.default_auth_required,
                    'token_sources': self.config.token_sources,
                    'reject_unauthenticated': self.config.reject_unauthenticated,
                    'allow_token_refresh': self.config.allow_token_refresh,
                }
            }


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def setup_websocket_security(
    engine: WebSocketEngine,
    gate_pipeline: GatePipeline,
    token_manager: TokenManager,
    config: SecurityConfig
) -> WebSocketSecurityManager:
    """
    Set up WebSocket security with GatePipeline integration.
    
    This is the main entry point for enabling WebSocket security.
    
    Args:
        engine: WebSocket engine instance
        gate_pipeline: GatePipeline instance
        token_manager: TokenManager instance
        config: Security configuration
        
    Returns:
        Configured WebSocketSecurityManager
    """
    # Create manager
    manager = WebSocketSecurityManager(
        engine=engine,
        gate_pipeline=gate_pipeline,
        token_manager=token_manager,
        config=config
    )
    
    return manager