import logging

# Library best-practice: attach NullHandler so that py_aide emits no output
# unless the consuming application configures its own log handlers.
logging.getLogger(__name__).addHandler(logging.NullHandler())

from .flask import ServicePortal
try:
    from .fastApi import FastAPIServicePortal
except ImportError:
    FastAPIServicePortal = None

from .gate import GatePipeline, GateConfig, AuthType, RequestContext
from .websockets.config import WebSocketConfig
from .breaker import CircuitBreaker, circuit_breaker, CircuitOpenError

