"""
CUSTOM CIRCUIT BREAKER IMPLEMENTATION

A lightweight, production-ready circuit breaker pattern implementation.
Designed specifically for the gate system with thread safety and monitoring.

Three States:
1. CLOSED:   Normal operation, requests pass through
2. OPEN:     Circuit tripped, requests fail fast
3. HALF_OPEN: Testing if service recovered

Key Features:
- Thread-safe state management
- Configurable failure thresholds and timeouts
- Monitoring and metrics collection
- Fallback function support
- No external dependencies
"""

import time
import threading
import weakref
from enum import Enum
from typing import Any, Callable, Optional, Dict, List, Set
from functools import wraps
import logging

logger = logging.getLogger(__name__)

# ============================================================================
# ENUMS AND CONSTANTS
# ============================================================================

class CircuitState(Enum):
    """Three states of the circuit breaker."""
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Circuit tripped, failing fast
    HALF_OPEN = "half_open"  # Testing recovery

class CircuitEvent(Enum):
    """Events that can occur in the circuit breaker."""
    SUCCESS = "success"
    FAILURE = "failure"
    TIMEOUT = "timeout"
    CIRCUIT_OPEN = "circuit_open"
    CIRCUIT_CLOSED = "circuit_closed"
    CIRCUIT_HALF_OPEN = "circuit_half_open"
    FALLBACK_CALLED = "fallback_called"


# ============================================================================
# CORE CIRCUIT BREAKER CLASS
# ============================================================================

class CircuitBreaker:
    """
    Thread-safe circuit breaker implementation.
    
    Usage:
        cb = CircuitBreaker(
            failure_threshold=5,
            recovery_timeout=60,
            name="auth_service"
        )
        
        @cb
        def call_service():
            # Your code here
            pass
        
        # Or programmatically:
        result = cb.call(call_service)
    """
    
    # Class-level registry: maps name → weakref so the registry itself
    # never prevents a CircuitBreaker from being garbage-collected.
    _registry: Dict[str, weakref.ref] = {}
    _registry_lock = threading.RLock()
    
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
        half_open_max_requests: int = 1,
        name: Optional[str] = None,
        expected_exceptions: Optional[Set[Exception]] = None,
        failure_timeout: Optional[float] = None,
        logger: Optional[logging.Logger] = None
    ):
        """
        Initialize a circuit breaker.
        
        Args:
            failure_threshold: Number of failures before circuit opens
            recovery_timeout: Seconds to wait before testing recovery (half-open)
            half_open_max_requests: Max test requests in half-open state
            name: Unique name for this circuit (auto-generated if None)
            expected_exceptions: Exceptions that count as failures (None = all)
            failure_timeout: Operation timeout in seconds (None = no timeout)
            logger: Custom logger (uses module logger if None)
        """
        # Configuration
        self.failure_threshold = max(1, failure_threshold)
        self.recovery_timeout = max(1.0, recovery_timeout)
        self.half_open_max_requests = max(1, half_open_max_requests)
        self.failure_timeout = failure_timeout
        self.expected_exceptions = expected_exceptions or {Exception}
        
        # State
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._half_open_test_count = 0
        self._last_failure_time = 0.0
        self._state_change_time = time.time()
        self._last_exception: Optional[Exception] = None
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Monitoring
        self.name = name or f"circuit_{id(self)}"
        self.logger = logger or logging.getLogger(f"circuit_breaker.{self.name}")
        self.metrics = {
            "total_calls": 0,
            "successful_calls": 0,
            "failed_calls": 0,
            "circuit_open_calls": 0,
            "fallback_calls": 0,
            "state_changes": 0,
            "last_state_change": time.time()
        }
        
        # Event callbacks
        self._event_callbacks: Dict[CircuitEvent, List[Callable]] = {}
        
        # Fallback function
        self._fallback_func: Optional[Callable] = None
        
        # Register instance via weakref.
        # If a stale entry already exists for this name (e.g. from a previous
        # instance that was GC'd or from a module hot-reload), it is silently
        # replaced.  A warning is emitted so the developer sees it during
        # development, but the server is never crashed by a collision.
        with self._registry_lock:
            existing_ref = self._registry.get(self.name)
            if existing_ref is not None and existing_ref() is not None:
                logger.warning(
                    "CircuitBreaker '%s' already exists and is still live — "
                    "replacing the old instance. Call .close() explicitly to "
                    "suppress this warning.",
                    self.name
                )
            self._registry[self.name] = weakref.ref(self)

        self.logger.info(
            "Circuit breaker '%s' initialized: threshold=%d, timeout=%.1fs",
            self.name, failure_threshold, recovery_timeout
        )
    
    # ============================================================================
    # DECORATOR INTERFACE
    # ============================================================================
    
    def __call__(self, func: Callable) -> Callable:
        """
        Decorator interface: @circuit_breaker
        """
        @wraps(func)
        def wrapper(*args, **kwargs):
            return self.call(func, *args, **kwargs)
        return wrapper
    
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Programmatic interface to call a function with circuit breaker protection.
        
        Args:
            func: Function to call
            *args: Function arguments
            **kwargs: Function keyword arguments
            
        Returns:
            Function result or fallback result
            
        Raises:
            CircuitOpenError: If circuit is open
            Exception: If function raises and no fallback
        """
        self.metrics["total_calls"] += 1
        
        # Check circuit state
        if not self._allow_request():
            self.metrics["circuit_open_calls"] += 1
            self._trigger_event(CircuitEvent.CIRCUIT_OPEN)
            
            # Try fallback
            if self._fallback_func:
                self.metrics["fallback_calls"] += 1
                self._trigger_event(CircuitEvent.FALLBACK_CALLED)
                return self._fallback_func(*args, **kwargs)
            
            # No fallback, raise circuit open error
            raise CircuitOpenError(
                f"Circuit '{self.name}' is OPEN",
                circuit_name=self.name,
                state=self._state.value,
                last_exception=str(self._last_exception) if self._last_exception else None,
                recovery_in=self._recovery_time_remaining()
            )
        
        # Execute the function
        try:
            # Handle timeout if configured
            if self.failure_timeout:
                result = self._call_with_timeout(func, *args, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            # Success - update state
            self._on_success()
            self.metrics["successful_calls"] += 1
            self._trigger_event(CircuitEvent.SUCCESS)
            return result
            
        except Exception as e:
            # Check if this exception should count as failure
            should_count = False
            for expected_exc in self.expected_exceptions:
                if isinstance(e, expected_exc):
                    should_count = True
                    break
            
            if should_count:
                # Failure - update state
                self._on_failure(e)
                self.metrics["failed_calls"] += 1
                self._trigger_event(CircuitEvent.FAILURE, exception=e)
            
            # Re-raise the exception
            raise
    
    def _call_with_timeout(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute function with timeout using threads.
        """
        result = None
        exception = None
        done = threading.Event()
        
        def worker():
            nonlocal result, exception
            try:
                result = func(*args, **kwargs)
            except Exception as e:
                exception = e
            finally:
                done.set()
        
        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        
        # Wait for completion or timeout
        if done.wait(timeout=self.failure_timeout):
            thread.join()
            if exception:
                raise exception
            return result
        else:
            # Timeout occurred
            self._trigger_event(CircuitEvent.TIMEOUT)
            raise TimeoutError(
                f"Function call exceeded timeout of {self.failure_timeout}s"
            )
    
    # ============================================================================
    # STATE MANAGEMENT
    # ============================================================================
    
    def _allow_request(self) -> bool:
        """
        Check if a request should be allowed based on circuit state.
        
        Returns:
            True if request should be executed, False if should fail fast
        """
        with self._lock:
            current_time = time.time()
            
            if self._state == CircuitState.CLOSED:
                return True
            
            elif self._state == CircuitState.OPEN:
                # Check if recovery timeout has passed
                time_since_open = current_time - self._state_change_time
                if time_since_open >= self.recovery_timeout:
                    # Move to HALF_OPEN state
                    self._transition_to(CircuitState.HALF_OPEN)
                    self._half_open_test_count = 0
                    return True
                else:
                    return False
            
            elif self._state == CircuitState.HALF_OPEN:
                # Allow limited test requests
                if self._half_open_test_count < self.half_open_max_requests:
                    self._half_open_test_count += 1
                    return True
                else:
                    return False
    
    def _on_success(self) -> None:
        """
        Handle successful execution.
        """
        with self._lock:
            if self._state == CircuitState.HALF_OPEN:
                # Success in half-open state → close circuit
                self._transition_to(CircuitState.CLOSED)
                self._reset_counters()
            elif self._state == CircuitState.CLOSED:
                # Reset failure count on success streak
                self._failure_count = max(0, self._failure_count - 1)
    
    def _on_failure(self, exception: Exception) -> None:
        """
        Handle failed execution.
        
        Args:
            exception: The exception that was raised
        """
        with self._lock:
            self._last_failure_time = time.time()
            self._last_exception = exception
            
            if self._state == CircuitState.HALF_OPEN:
                # Failure in half-open state → back to open
                self._transition_to(CircuitState.OPEN)
            elif self._state == CircuitState.CLOSED:
                # Increment failure count
                self._failure_count += 1
                
                # Check if we should open circuit
                if self._failure_count >= self.failure_threshold:
                    self._transition_to(CircuitState.OPEN)
    
    def _transition_to(self, new_state: CircuitState) -> None:
        """
        Transition to a new state with logging and event triggering.
        
        Args:
            new_state: State to transition to
        """
        if self._state == new_state:
            return
        
        old_state = self._state
        self._state = new_state
        self._state_change_time = time.time()
        self.metrics["state_changes"] += 1
        self.metrics["last_state_change"] = self._state_change_time
        
        # Log state change
        self.logger.info(
            f"Circuit '{self.name}' state change: {old_state.value} → {new_state.value}"
        )
        
        # Trigger appropriate event
        if new_state == CircuitState.CLOSED:
            self._trigger_event(CircuitEvent.CIRCUIT_CLOSED)
        elif new_state == CircuitState.OPEN:
            self._trigger_event(CircuitEvent.CIRCUIT_OPEN)
        elif new_state == CircuitState.HALF_OPEN:
            self._trigger_event(CircuitEvent.CIRCUIT_HALF_OPEN)
    
    def _reset_counters(self) -> None:
        """Reset failure and success counters."""
        with self._lock:
            self._failure_count = 0
            self._success_count = 0
            self._half_open_test_count = 0
            self._last_exception = None
    
    def _recovery_time_remaining(self) -> float:
        """
        Calculate time remaining until circuit can test recovery.
        
        Returns:
            Seconds until recovery test, 0 if not in OPEN state
        """
        if self._state != CircuitState.OPEN:
            return 0.0
        
        elapsed = time.time() - self._state_change_time
        remaining = max(0.0, self.recovery_timeout - elapsed)
        return remaining
    
    # ============================================================================
    # PUBLIC API
    # ============================================================================
    
    def get_state(self) -> CircuitState:
        """Get current circuit state."""
        with self._lock:
            return self._state
    
    def get_metrics(self) -> Dict:
        """Get current metrics snapshot."""
        with self._lock:
            metrics = self.metrics.copy()
            metrics.update({
                "state": self._state.value,
                "failure_count": self._failure_count,
                "success_count": self._success_count,
                "half_open_test_count": self._half_open_test_count,
                "last_failure_time": self._last_failure_time,
                "state_change_time": self._state_change_time,
                "recovery_time_remaining": self._recovery_time_remaining(),
                "is_closed": self._state == CircuitState.CLOSED,
                "is_open": self._state == CircuitState.OPEN,
                "is_half_open": self._state == CircuitState.HALF_OPEN
            })
            return metrics
    
    def force_close(self) -> None:
        """Force circuit to CLOSED state (manual override)."""
        with self._lock:
            self._transition_to(CircuitState.CLOSED)
            self._reset_counters()
    
    def force_open(self) -> None:
        """Force circuit to OPEN state (manual override)."""
        with self._lock:
            self._transition_to(CircuitState.OPEN)
    
    def reset(self) -> None:
        """Reset circuit to initial state (CLOSED with cleared counters)."""
        with self._lock:
            self._transition_to(CircuitState.CLOSED)
            self._reset_counters()
    
    def set_fallback(self, func: Callable) -> None:
        """
        Set fallback function to call when circuit is open.
        
        Args:
            func: Fallback function with same signature as protected function
        """
        self._fallback_func = func
    
    def on_event(self, event: CircuitEvent, callback: Callable) -> None:
        """
        Register callback for circuit events.
        
        Args:
            event: Event type to listen for
            callback: Function to call when event occurs
        """
        with self._lock:
            if event not in self._event_callbacks:
                self._event_callbacks[event] = []
            self._event_callbacks[event].append(callback)
    
    def _trigger_event(self, event: CircuitEvent, **kwargs) -> None:
        """Trigger event callbacks."""
        if event in self._event_callbacks:
            for callback in self._event_callbacks[event]:
                try:
                    callback(self, event, **kwargs)
                except Exception as e:
                    self.logger.error(f"Error in event callback for {event}: {e}")
    
    def close(self) -> None:
        """Explicitly deregister this circuit breaker.

        Under normal operation this is not required — the weakref registry
        auto-expires when the object is garbage-collected.  Call this when
        you want *immediate* deregistration, e.g. in test teardowns.
        """
        with self._registry_lock:
            ref = self._registry.get(self.name)
            # Only delete if the entry still points to *this* instance,
            # not to a newer replacement with the same name.
            if ref is not None and ref() is self:
                del self._registry[self.name]
    
    # ============================================================================
    # CLASS METHODS
    # ============================================================================
    
    @classmethod
    def _prune_registry(cls) -> None:
        """Remove dead weakrefs from the registry (called while lock is held)."""
        dead = [name for name, ref in cls._registry.items() if ref() is None]
        for name in dead:
            del cls._registry[name]

    @classmethod
    def get_all_circuits(cls) -> Dict[str, Dict]:
        """Get status of all live registered circuit breakers."""
        with cls._registry_lock:
            cls._prune_registry()
            return {
                name: ref().get_metrics()
                for name, ref in cls._registry.items()
                if ref() is not None
            }

    @classmethod
    def get_circuit(cls, name: str) -> Optional['CircuitBreaker']:
        """Get a live circuit breaker by name, or None if not found / GC'd."""
        with cls._registry_lock:
            ref = cls._registry.get(name)
            if ref is None:
                return None
            obj = ref()
            if obj is None:   # GC collected it between lookup and deref
                del cls._registry[name]
                return None
            return obj

    @classmethod
    def close_all(cls) -> None:
        """Explicitly deregister all circuit breakers."""
        with cls._registry_lock:
            for ref in list(cls._registry.values()):
                obj = ref()
                if obj is not None:
                    obj.close()
            cls._registry.clear()


# ============================================================================
# EXCEPTIONS
# ============================================================================

class CircuitOpenError(Exception):
    """Exception raised when circuit is open."""
    
    def __init__(self, message: str, **kwargs):
        super().__init__(message)
        self.circuit_info = kwargs


class CircuitBreakerError(Exception):
    """Base exception for circuit breaker errors."""
    pass


# ============================================================================
# FACTORY AND DECORATOR FUNCTIONS
# ============================================================================

def circuit_breaker(
    failure_threshold: int = 5,
    recovery_timeout: float = 60.0,
    name: Optional[str] = None,
    **kwargs
):
    """
    Decorator factory for circuit breaker.
    
    Usage:
        @circuit_breaker(failure_threshold=3, recovery_timeout=30)
        def my_function():
            pass
    """
    def decorator(func):
        # Create circuit breaker instance
        cb = CircuitBreaker(
            failure_threshold=failure_threshold,
            recovery_timeout=recovery_timeout,
            name=name or func.__name__,
            **kwargs
        )
        
        # Apply as decorator
        return cb(func)
    
    return decorator


def create_circuit_breaker(
    name: str,
    failure_threshold: int = 5,
    recovery_timeout: float = 60.0,
    **kwargs
) -> CircuitBreaker:
    """
    Create a named circuit breaker.
    
    Args:
        name: Unique name for the circuit
        failure_threshold: Failures before opening
        recovery_timeout: Seconds to wait before testing recovery
        **kwargs: Additional CircuitBreaker arguments
        
    Returns:
        CircuitBreaker instance
    """
    return CircuitBreaker(
        name=name,
        failure_threshold=failure_threshold,
        recovery_timeout=recovery_timeout,
        **kwargs
    )


# ============================================================================
# MONITORING AND HEALTH CHECK
# ============================================================================

class CircuitMonitor:
    """
    Monitor for multiple circuit breakers with health checks.
    """
    
    def __init__(self):
        self.circuits = {}
    
    def add_circuit(self, circuit: CircuitBreaker) -> None:
        """Add circuit to monitor."""
        self.circuits[circuit.name] = circuit
        
        # Add monitoring callback
        def on_state_change(cb, event, **kwargs):
            self._log_state_change(cb, event)
        
        circuit.on_event(CircuitEvent.CIRCUIT_OPEN, on_state_change)
        circuit.on_event(CircuitEvent.CIRCUIT_CLOSED, on_state_change)
        circuit.on_event(CircuitEvent.CIRCUIT_HALF_OPEN, on_state_change)
    
    def _log_state_change(self, circuit: CircuitBreaker, event: CircuitEvent) -> None:
        """Log circuit state changes."""
        metrics = circuit.get_metrics()
        logger.info(
            "[CircuitMonitor] %s: %s | state=%s failures=%d/%d total=%d failed=%d",
            circuit.name, event.value, metrics['state'],
            metrics['failure_count'], circuit.failure_threshold,
            metrics['total_calls'], metrics['failed_calls']
        )
    
    def get_health_report(self) -> Dict:
        """Generate health report for all monitored circuits."""
        report = {
            "timestamp": time.time(),
            "total_circuits": len(self.circuits),
            "healthy_circuits": 0,
            "unhealthy_circuits": 0,
            "circuits": {}
        }
        
        for name, circuit in self.circuits.items():
            metrics = circuit.get_metrics()
            is_healthy = metrics["is_closed"]
            
            if is_healthy:
                report["healthy_circuits"] += 1
            else:
                report["unhealthy_circuits"] += 1
            
            report["circuits"][name] = {
                "state": metrics["state"],
                "healthy": is_healthy,
                "failure_count": metrics["failure_count"],
                "total_calls": metrics["total_calls"],
                "failed_calls": metrics["failed_calls"],
                "last_state_change": metrics["last_state_change"],
                "recovery_time_remaining": metrics["recovery_time_remaining"]
            }
        
        return report
    
    def close_all(self) -> None:
        """Close all monitored circuits."""
        for circuit in self.circuits.values():
            circuit.close()
        self.circuits.clear()


# ============================================================================
# INTEGRATION WITH GATE SYSTEM
# ============================================================================

class CircuitProtectedGate:
    """
    Mixin that wraps any BaseGate subclass with circuit breaker protection.

    Usage — list this mixin BEFORE the gate class in the MRO so that this
    class's ``execute()`` intercepts calls from GatePipeline:

        class ProtectedAuthenticationGate(CircuitProtectedGate, AuthenticationGate):
            pass

    The circuit breaker sits around the *entire* ``BaseGate.execute()`` call,
    which already includes the should_run check, timing, and audit logging.
    When the circuit is open the fallback returns a proper ``GateResult`` so
    the pipeline continues to run safely rather than raising an exception.

    Configuration is intentionally conservative (5 failures, 30 s recovery)
    but can be overridden by passing ``circuit_config`` to ``__init__``.
    """

    def __init__(self, *args, circuit_config: Optional[Dict] = None, **kwargs):
        """
        Args:
            circuit_config: Optional dict of CircuitBreaker kwargs, e.g.:
                ``{'failure_threshold': 3, 'recovery_timeout': 60}``
        """
        # Must initialise the gate first so self.__class__.__name__ resolves
        super().__init__(*args, **kwargs)

        cfg = {
            "failure_threshold": 5,
            "recovery_timeout": 30.0,
            "expected_exceptions": {ConnectionError, TimeoutError, RuntimeError},
        }
        if circuit_config:
            cfg.update(circuit_config)

        self.circuit = CircuitBreaker(
            name=f"gate_{self.__class__.__name__}",
            **cfg
        )
        self.circuit.set_fallback(self._circuit_fallback)
        self.circuit.on_event(CircuitEvent.CIRCUIT_OPEN, self._on_circuit_open)
        self.circuit.on_event(CircuitEvent.CIRCUIT_CLOSED, self._on_circuit_closed)

    # ------------------------------------------------------------------
    # Core interception — this is the only method that needs to change.
    # GatePipeline calls gate.execute(context, config), so we intercept
    # here and route through self.circuit.  super().execute() resolves to
    # BaseGate.execute() via normal MRO.
    # ------------------------------------------------------------------

    def execute(self, context, config):
        """
        Execute gate logic protected by the circuit breaker.

        If the circuit is open the fallback is called immediately and a
        ``GateResult`` is returned without touching the underlying gate.
        """
        return self.circuit.call(super().execute, context, config)

    # ------------------------------------------------------------------
    # Fallback & callbacks
    # ------------------------------------------------------------------

    def _circuit_fallback(self, *args, **kwargs):
        """
        Called when the circuit is open.  Returns a GateResult so the
        pipeline receives a well-formed response rather than an exception.
        """
        from .gate import GateResult  # avoid circular import at module level

        # super().execute() is called as: call(super().execute, context, config)
        # so args = (context, config)
        context = args[0] if args else kwargs.get('context')

        return GateResult.error(
            "service_unavailable",
            "Service temporarily unavailable (circuit open)",
            context,
            {
                "circuit_name": self.circuit.name,
                "state": self.circuit.get_state().value,
                "recovery_in": self.circuit._recovery_time_remaining(),
            }
        )

    def _on_circuit_open(self, circuit, event, **kwargs):
        logger.warning("Gate '%s' circuit OPEN — failing fast", self.__class__.__name__)

    def _on_circuit_closed(self, circuit, event, **kwargs):
        logger.info("Gate '%s' circuit CLOSED — back to normal", self.__class__.__name__)

    def get_circuit_metrics(self) -> Dict:
        """Expose circuit breaker metrics alongside gate metrics."""
        return self.circuit.get_metrics()


# Example — a production authentication gate with circuit breaker:
#
#   class ProtectedAuthenticationGate(CircuitProtectedGate, AuthenticationGate):
#       """Auth gate that opens the circuit after 5 consecutive auth failures."""
#
#       def __init__(self, token_manager):
#           super().__init__(
#               token_manager,
#               circuit_config={'failure_threshold': 3, 'recovery_timeout': 60}
#           )