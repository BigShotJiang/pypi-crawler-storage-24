
class JSONParser:
    OPERATORS = {"+", "+=", "-=", "*=", "/=", "-", "|="}

    @classmethod
    def parse_read_column(cls, *, column_string: str):
        comp = cls._isolate_components(column_string)
        path, op = cls._format_json_path(comp["raw_path"])

        if path:
            safe_path = path.replace("'", "''")
            frag = f"{comp['column']} ->> '{safe_path}'"
        else:
            frag = comp["column"]

        return f'{frag} AS {comp["alias"]}' if comp["alias"] else frag

    @classmethod
    def parse_write_columns(cls, *, columns: list, values: list):
        col_map = {}
        for dsl, val in zip(columns, values):
            comp = cls._isolate_components(dsl)
            col = comp["column"]
            if col not in col_map: 
                col_map[col] = []
            col_map[col].append((dsl, val))

        final_set_parts = []
        flattened_values = []

        for col, updates in col_map.items():
            # Start the SQL chain with the base column name
            current_sql = col
            
            for dsl, val in updates:
                comp = cls._isolate_components(dsl)
                path, op = cls._format_json_path(comp["raw_path"])
                
                # 1. Handle Values
                if op == "+" and isinstance(val, (list, tuple)):
                    l_len = len(val)
                    flattened_values.extend(val)
                else:
                    l_len = 1
                    flattened_values.append(val)

                # 2. Build SQL Chain iteratively
                if not path:
                    # STANDARD COLUMN: No JSON logic allowed
                    current_sql = "?"
                else:
                    # JSON COLUMN: Pass the previously built nested SQL fragment
                    # to be wrapped cleanly inside the next operation
                    current_sql = cls._assemble_sql(current_sql, path, op, l_len)

            final_set_parts.append(f"{col} = {current_sql}")

        return final_set_parts, flattened_values

    @classmethod
    def _validate_syntax(cls, dsl: str):
        # Rule: No concurrent separators ::::
        if "::" in dsl and any(p == "" for p in dsl.split("::")):
            raise ValueError(f"Invalid DSL Syntax: Concurrent separators '::::' in {dsl}")

        # Rule: No elements after operator, and check brackets
        terminal_op = None
        start = 0
        while True:
            start_idx = dsl.find('[', start)
            if start_idx == -1: break
            
            end_idx = dsl.find(']', start_idx)
            if end_idx == -1:
                raise ValueError(f"Unclosed bracket at index {start_idx} in {dsl}")
            
            content = dsl[start_idx + 1:end_idx].strip()
            
            if terminal_op:
                raise ValueError(f"No elements allowed after operator '{terminal_op}' at index {start_idx}")
            
            if content in cls.OPERATORS:
                terminal_op = content
            elif not content.isdigit():
                raise ValueError(f"Unexpected bracket content '{content}' (must be digit or operator: {cls.OPERATORS})")
            
            start = end_idx + 1

    @classmethod
    def _isolate_components(cls, dsl: str):
        res = {"column": "", "raw_path": "", "alias": None}
        
        # Handle Alias (case-insensitive ' as ')
        lower_dsl = dsl.lower()
        if " as " in lower_dsl:
            idx = lower_dsl.find(" as ")
            working = dsl[:idx].strip()
            res["alias"] = dsl[idx + 4:].strip().lower() # Forced to lower per rule
        else:
            working = dsl.strip()

        c_idx = working.find("::")
        b_idx = working.find("[")
        indices = [i for i in [c_idx, b_idx] if i != -1]
        
        if not indices:
            col_part = working
            res["raw_path"] = ""
        else:
            split_pt = min(indices)
            col_part = working[:split_pt]
            res["raw_path"] = working[split_pt:]

        # Quote each part of the identifier (table and column)
        if "." in col_part:
            res["column"] = ".".join(f'{p.strip()}' for p in col_part.split("."))
        else:
            res["column"] = f'{col_part.strip()}'
            
        return res

    @classmethod
    def _format_json_path(cls, raw_path: str):
        if not raw_path: return None, None
        
        operator = None
        if raw_path.endswith(']'):
            last_b = raw_path.rfind('[')
            content = raw_path[last_b + 1 : -1].strip()
            if content in cls.OPERATORS:
                operator = content
                raw_path = raw_path[:last_b]

        formatted = "$"
        segments = raw_path.split("::")
        for seg in segments:
            if not seg: continue
            if "[" in seg:
                b_pos = seg.find("[")
                key, index = seg[:b_pos], seg[b_pos:]
                formatted += f".{key}{index}" if key else index
            else:
                formatted += f".{seg}"
        return formatted, operator

    @classmethod
    def _assemble_sql(cls, target, path, op, list_len=1):
        """The core engine that builds and intelligently nests the SQL string."""
        safe_path = path.replace("'", "''")

        # Special Case: Root Dictionary Merge (submissions[|=])
        if op == "|=" and path == "$":
            return f"json_patch(IFNULL({target}, json('{{}}')), ?)"

        # Path-based Dictionary Merge (submissions::meta[|=])
        if op == "|=":
            p_base = f"IFNULL(json_extract({target}, '{safe_path}'), json('{{}}'))"
            return f"json_set({target}, '{safe_path}', json_patch({p_base}, ?))"

        # Math
        if op in ("+=", "-=", "*=", "/="):
            cur = f"IFNULL({target} ->> '{safe_path}', 0)"
            return f"json_set({target}, '{safe_path}', {cur} {op[0]} ?)"

        # List Append
        if op == "+":
            placeholders = ", ".join(["?"] * list_len)
            return f"json_insert({target}, '{safe_path}[#]', {placeholders})"

        # Default Set
        return f"json_set({target}, '{safe_path}', ?)"

    @classmethod
    def parse_condition(cls, sql: str) -> str:
        """
        Parses raw SQL querying strings, translating `col::path` DSL notation 
        safely into SQLite JSON extract syntax, completely ignoring DSL syntax 
        hidden safely inside SQL string literals.
        """
        if not sql or "::" not in sql:
            return sql

        in_single_quote = False
        in_double_quote = False
        i = 0

        while i < len(sql):
            char = sql[i]
            
            # 1. Safely track SQL literal string states to avoid corruption
            if char == "'": in_single_quote = not in_single_quote
            elif char == '"': in_double_quote = not in_double_quote
            
            # 2. Only process DSL if we are NOT inside a SQL string literal
            if not in_single_quote and not in_double_quote and sql[i:i+2] == "::":
                # SCAN LEFT: Find the start of the Table/Column
                start = i
                while start > 0:
                    prev = sql[start-1]
                    if not (prev.isalnum() or prev in ('_', '.')):
                        break
                    start -= 1
                    
                # SCAN RIGHT: Find the end of the JSON Path
                end = i + 2
                in_bracket = False
                break_chars = (' ', ',', ')', '(', '=', '>', '<', '!', '+', '-', '*', '/', '\n')
                
                while end < len(sql):
                    c = sql[end]
                    if c == '[': in_bracket = True
                    elif c == ']': in_bracket = False
                    
                    if not in_bracket and c in break_chars:
                        break
                    end += 1
                    
                # EXTRACT AND REPLACE
                dsl_chunk = sql[start:end]
                translated = cls.parse_read_column(column_string=dsl_chunk)
                
                # Replace the DSL chunk identically with the translated SQL
                sql = sql[:start] + translated + sql[end:]
                
                # Fast-forward the scanner to the end of the translation 
                # so we don't infinitely lock up re-scanning it
                i = start + len(translated) - 1
            
            i += 1
            
        return sql