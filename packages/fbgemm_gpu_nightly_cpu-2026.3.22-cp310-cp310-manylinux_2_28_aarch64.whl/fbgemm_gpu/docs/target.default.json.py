
{
    "version": "2026.3.22",
    "target": "default",
    "variant": "cpu"
}
