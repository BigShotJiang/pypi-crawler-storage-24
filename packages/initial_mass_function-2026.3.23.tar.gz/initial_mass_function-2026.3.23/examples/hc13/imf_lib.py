"""
This program calculates the IMF predicted by the analytical calculation 
(Hennebelle & Chabrier)

Translated from IDL to Python
"""

import numpy as np


def calc_dM_dR2(mass, R, gamma, eta, Mach2_et, gamma2, const, nind, const_mag, gammag):
    """
    Calculate dM/dR derivative.

    Parameters:
    -----------
    mass : float
        Mass value
    R : float
        Radius value
    gamma, gamma2 : float
        Polytropic indices
    eta : float
        Velocity dispersion index
    Mach2_et : float
        Squared Mach number at Jeans length
    const : float
        Cooling constant
    nind : float
        Index for calculation
    const_mag : float
        Magnetic constant
    gammag : float
        Magnetic gamma parameter

    Returns:
    --------
    dM_dR : float
        Derivative of mass with respect to radius
    """
    M_R3 = mass / R**3

    ind1 = (gamma - 1.0) * nind
    ind2 = (gamma2 - 1.0) * nind

    dgammag_1 = 2.0 * gammag - 1.0

    A = (M_R3)**ind1 + (const**nind) * ((M_R3)**ind2)

    dA_drho = ind1 * (M_R3)**(ind1 - 1.0) + ind2 * (const**nind) * ((M_R3)**(ind2 - 1.0))

    therm_mag = (1.0 / nind) * A**(1.0 / nind - 1.0) * dA_drho + dgammag_1 * const_mag * (M_R3)**(dgammag_1 - 1.0)

    dM_dR = -3.0 * (M_R3) * therm_mag

    dM_dR = dM_dR + A**(1.0 / nind) + (2.0 * eta + 1.0) * Mach2_et * R**(2.0 * eta) + const_mag * (M_R3)**dgammag_1

    dM_dR = dM_dR / (1.0 - therm_mag / R**2)

    return dM_dR


def sign_mass2(mass, R, eta, gamma, Mach2_et, gamma2, const, nind, const_mag, gammag):
    """
    Calculate the sign function for mass equation.

    Returns the residual of the mass equation that should equal zero.
    """
    gamma2 = float(gamma2)
    gamma = float(gamma)
    mass = float(mass)
    R = float(R)
    gammag = float(gammag)

    dgammag_1 = 2.0 * gammag - 1.0

    M_R3 = mass / R**3

    A = (((M_R3)**(gamma - 1.0))**nind + (const * (M_R3)**(gamma2 - 1.0))**nind)

    sign = mass - R * ((A**(1.0 / nind)) + Mach2_et * R**(2.0 * eta) + const_mag * (M_R3)**dgammag_1)

    return sign


def calc_mass(R, eta, gamma, Mach2_et, gamma2, const, nint, const_mag, gammag):
    """
    Calculate mass for a given radius using bisection method.

    Parameters:
    -----------
    R : float
        Radius
    eta : float
        Velocity dispersion index
    gamma, gamma2 : float
        Polytropic indices
    Mach2_et : float
        Squared Mach number at Jeans length
    const : float
        Cooling constant
    nint : float
        Index for calculation
    const_mag : float
        Magnetic constant
    gammag : float
        Magnetic gamma parameter

    Returns:
    --------
    mass : float
        Calculated mass
    """
    dgammag_1 = 2.0 * gammag - 1.0

    # Calculate initial mass bounds
    mass_min = max([
        R**(2.0 * eta + 1.0) * Mach2_et,
        R**((4.0 - 3.0 * gamma) / (2.0 - gamma)),
        const**(1.0 / (2.0 - gamma2)) * R**((4.0 - 3.0 * gamma2) / (2.0 - gamma2)),
        const_mag**(1.0 / (1.0 - dgammag_1)) * R**((1.0 - 3.0 * dgammag_1) / (1.0 - dgammag_1))
    ])
    mass_max = 3.0 * mass_min

    ii = 0
    while (1.0 - mass_min / mass_max > 1e-4):
        mass_moy = (mass_min + mass_max) / 2.0

        sign_min = sign_mass2(mass_min, R, eta, gamma, Mach2_et, gamma2, const, nint, const_mag, gammag)
        sign_moy = sign_mass2(mass_moy, R, eta, gamma, Mach2_et, gamma2, const, nint, const_mag, gammag)
        sign_max = sign_mass2(mass_max, R, eta, gamma, Mach2_et, gamma2, const, nint, const_mag, gammag)

        if sign_min * sign_moy < 0.0:
            mass_max = mass_moy
        else:
            if sign_moy * sign_max > 0.0:
                print('probleme de borne (boundary problem)')
                raise ValueError("Boundary problem in bisection")
            mass_min = mass_moy

        ii += 1
        if ii > 1000:
            print('probleme de convergence (convergence problem)')
            print(R, eta, gamma, Mach2_et)
            print(mass_min, mass_max)
            raise ValueError("Convergence problem")

    mass = (mass_min + mass_max) / 2.0

    return mass


def calc_imf2(Mach, Mach2_et, eta, Li, gamma, b, gamma2, const, nint,
              const_mag=0.0, gammag=0.5, time=True, nbin=1000,
              karman=False, L_coef=1.0):
    """
    Calculate IMF with a Karman type power spectrum or standard power law.
    Only eta=0.5 is accepted when karman=True.

    Parameters:
    -----------
    Mach : float
        Mach number
    Mach2_et : float
        Squared Mach number at Jeans length
    eta : float
        Velocity dispersion index
    Li : float
        Cloud size
    gamma, gamma2 : float
        Polytropic indices
    b : float
        Turbulent driving parameter
    const : float
        Cooling constant
    nint : float
        Index for calculation
    const_mag : float, optional
        Magnetic constant (default: 0.0)
    gammag : float, optional
        Magnetic gamma parameter (default: 0.5)
    time : bool, optional
        Include time correction (default: True)
    nbin : int, optional
        Number of bins (default: 1000)
    karman : bool, optional
        Use von Karman spectrum (default: False)
    L_coef : float, optional
        Length coefficient (default: 1.0)

    Returns:
    --------
    Mass_v : array
        Mass values
    dens_v : array
        Density values
    Lfrac : array
        Size fractions relative to cloud size
    """
    if eta != 0.5 and karman:
        print("sorry calc_imf2 accepts only eta=0.5")
        print("eta is reset to this value")
        eta = 0.5

    # Li_t is the total size until which integration is performed
    Li_t = Li * L_coef

    # Li_p is the position of the energy power spectrum peak when von Karman spectrum is used
    Li_p = Li_t / 2.0  # just a try

    R_sup = 60.0
    R_inf = 0.0001

    logR_sup = np.log10(R_sup)
    logR_inf = np.log10(R_inf)

    Nbin = nbin

    # Lfrac contains the size of the fluctuations in terms of the total cloud size
    Lfrac = np.zeros(Nbin)

    interval = (logR_sup - logR_inf) / (Nbin - 1)

    Mass_v = np.zeros(Nbin)
    dens_v = np.zeros(Nbin)

    for i in range(Nbin):
        R = 10.0**(logR_inf + i * interval)

        Lfrac[i] = R / Li

        if R < Li_t:
            mass = calc_mass(R, eta, gamma, Mach2_et, gamma2, const, nint, const_mag, gammag)

            Mass_v[i] = mass

            rho = mass / R**3

            sigma_2_0 = np.log(1.0 + (b**2) * (Mach**2))

            if not karman:
                # The factor 2 in 2*Li_t is there to avoid singularities
                sigma_2 = sigma_2_0 * (1.0 - (R / (2.0 * Li_t))**(2.0 * eta))

                # dsigma_dR
                dsigma_dR = -(2.0 * eta) / (2.0 * np.sqrt(sigma_2)) * sigma_2_0 / R * (R / Li_t)**(2.0 * eta)
            else:
                i_R = 2.0 * np.pi / R * Li_p

                sigma_2 = sigma_2_0 * 2.0 / np.pi * (np.arctan(i_R) - i_R / (i_R**2 + 1.0))

                dsigma_dR = 4.0 / np.pi * (i_R**2 / (i_R**2 + 1.0)**2)
                dsigma_dR = sigma_2_0 * dsigma_dR * (-i_R / R) / (2.0 * np.sqrt(sigma_2))

            dM_dR = calc_dM_dR2(mass, R, gamma, eta, Mach2_et, gamma2, const, nint, const_mag, gammag)

            delta = np.log(mass / R**3)

            ddelta_dR = dM_dR / mass - 3.0 / R

            dens_v[i] = 1.0 / (dM_dR * mass) * (-ddelta_dR - abs(dsigma_dR / np.sqrt(sigma_2) * (delta + sigma_2 / 2.0)))

            dens_v[i] = dens_v[i] * np.exp(-delta**2 / (2.0 * sigma_2) - sigma_2 / 8.0 + delta / 2.0) / np.sqrt(2.0 * np.pi) / np.sqrt(sigma_2)

            # Correcting factor that takes into account the perturbation replenishment
            if time:
                dens_v[i] = dens_v[i] * np.sqrt(rho)

            if dens_v[i] < 0:
                dens_v[i] = 0.0
                print(f'negative density {i}')
        else:
            dens_v[i] = 0.0

    return Mass_v, dens_v, Lfrac


def density_proj(dens_v, Mass_v, log_mmin=-4.0, log_mmax=3.0, nn=100):
    """
    Project density onto a regular grid of masses.

    Parameters:
    -----------
    dens_v : array
        Density values
    Mass_v : array
        Mass values
    log_mmin : float, optional
        Minimum log mass (default: -4.0)
    log_mmax : float, optional
        Maximum log mass (default: 3.0)
    nn : int, optional
        Number of bins (default: 100)

    Returns:
    --------
    vect_mass : array
        Mass vector
    dens_proj : array
        Projected density
    """
    vect_mass = np.zeros(nn)
    dens_proj = np.zeros(nn)

    vect_mass = log_mmin + (log_mmax - log_mmin) * np.arange(nn) / nn

    for j in range(nn):
        masse = 10.0**vect_mass[j]

        a = np.where(Mass_v > masse)[0]

        if len(a) > 0 and a[0] != 0:
            a_idx = a[0]
            Mass_inf = Mass_v[a_idx - 1]
            Mass_sup = Mass_v[a_idx]
            Mass_diff = Mass_sup - Mass_inf

            dens_proj[j] = (dens_v[a_idx - 1] * (Mass_sup - masse) / Mass_diff +
                           dens_v[a_idx] * (masse - Mass_inf) / Mass_diff)

    vect_mass = 10.0**vect_mass

    return vect_mass, dens_proj


def read_chabrier_imf(filename='fmlog_sys_Chabrier03.dat'):
    """
    Read Chabrier IMF from file.

    Parameters:
    -----------
    filename : str
        Path to Chabrier IMF data file

    Returns:
    --------
    logm_v : array
        Log mass values
    num_v : array
        Number density values
    """
    logm_v = []
    num_v = []

    try:
        with open(filename, 'r') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 2:
                    logm_v.append(float(parts[0]))
                    num_v.append(float(parts[1]))

        logm_v = np.array(logm_v)
        num_v = np.array(num_v)

        # Filter values where logm_v > -2.5
        a = np.where(logm_v > -2.5)[0]
        logm_v = logm_v[a]
        num_v = num_v[a]

    except FileNotFoundError:
        print(f"Warning: {filename} not found, returning empty arrays")
        logm_v = np.array([])
        num_v = np.array([])

    return logm_v, num_v
