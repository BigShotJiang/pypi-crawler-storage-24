#!/usr/bin/env python
"""
Simple example demonstrating how to use the translated IMF code.
"""

from imf_ff_noff import imf_ff_noff
import numpy as np


def example_1_basic():
    """Example 1: Basic IMF calculation with default parameters."""
    print("="*60)
    print("Example 1: Basic IMF Calculation")
    print("="*60)

    result = imf_ff_noff(ncl=5, Lc=0.5, num='_example1')

    print(f"\nResults:")
    print(f"  Star Formation Rate: {result['sfr']:.6f}")
    print(f"  Number of mass bins: {len(result['vect_mass'])}")
    print(f"  Mass range: {result['vect_mass'].min():.3e} to {result['vect_mass'].max():.3e} M☉")
    print(f"\nPlot saved as: imf_time_scale_example1.png")
    print()


def example_2_high_density():
    """Example 2: High density cloud."""
    print("="*60)
    print("Example 2: High Density Cloud")
    print("="*60)

    result = imf_ff_noff(ncl=30, Lc=0.5, num='_example2_highdens', short=True)

    print(f"\nResults:")
    print(f"  Cloud density factor (ncl): 30")
    print(f"  Cloud size (Lc): 0.5 pc")
    print(f"  Star Formation Rate: {result['sfr']:.6f}")
    print()


def example_3_large_cloud():
    """Example 3: Large cloud."""
    print("="*60)
    print("Example 3: Large Cloud")
    print("="*60)

    result = imf_ff_noff(ncl=2, Lc=20.0, num='_example3_large', short=True)

    print(f"\nResults:")
    print(f"  Cloud density factor (ncl): 2")
    print(f"  Cloud size (Lc): 20.0 pc")
    print(f"  Star Formation Rate: {result['sfr']:.6f}")
    print()


def example_4_magnetic():
    """Example 4: IMF with magnetic fields."""
    print("="*60)
    print("Example 4: IMF with Magnetic Fields")
    print("="*60)

    # No magnetic field
    result_no_mag = imf_ff_noff(ncl=5, Lc=0.5, Va0=0.0, gmag=0.1,
                                 num='_example4_nomag', short=True)

    # With magnetic field
    result_with_mag = imf_ff_noff(ncl=5, Lc=0.5, Va0=1.0, gmag=0.1,
                                   num='_example4_mag', short=True)

    print(f"\nResults:")
    print(f"  Without magnetic field:")
    print(f"    SFR: {result_no_mag['sfr']:.6f}")
    print(f"  With magnetic field (Va0=1.0):")
    print(f"    SFR: {result_with_mag['sfr']:.6f}")
    print(f"  Difference: {abs(result_with_mag['sfr'] - result_no_mag['sfr']):.6f}")
    print()


def example_5_custom_parameters():
    """Example 5: Custom parameters."""
    print("="*60)
    print("Example 5: Custom Parameters")
    print("="*60)

    result = imf_ff_noff(
        eta=0.5,          # Velocity dispersion index
        gamma=1.0,        # Polytropic index
        g2=1.3,           # Second polytropic index
        b=0.5,            # Turbulent driving parameter
        ncl=5,            # Cloud density factor
        Lc=1.0,           # Cloud size in pc
        mach=6.0,         # Mach number
        m2_et=2.0,        # Mach number at Jeans length
        Li=1000.0,        # Inertial/Jeans length ratio
        num='_example5_custom',
        short=True
    )

    print(f"\nResults with custom parameters:")
    print(f"  Mach number: 6.0")
    print(f"  Li (inertial/Jeans length): 1000.0")
    print(f"  Star Formation Rate: {result['sfr']:.6f}")
    print()


def main():
    """Run all examples."""
    print("\n" + "="*60)
    print("IMF Calculation Examples")
    print("Translated from IDL (Hennebelle & Chabrier)")
    print("="*60 + "\n")

    try:
        example_1_basic()
        example_2_high_density()
        example_3_large_cloud()
        example_4_magnetic()
        example_5_custom_parameters()

        print("="*60)
        print("✓ All examples completed successfully!")
        print("="*60)
        print("\nCheck the generated PNG files for visualizations.")

    except Exception as e:
        print(f"\n✗ Error running examples: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0


if __name__ == '__main__':
    import sys
    sys.exit(main())
