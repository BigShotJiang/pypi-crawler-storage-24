"""
Test script for the translated IDL files.
Tests individual functions and runs basic simulations.
"""

import numpy as np
import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))

from imf_lib import calc_mass, calc_dM_dR2, sign_mass2, calc_imf2, density_proj
from imf_ff_noff import imf_ff_noff
from launch_simu import launch_simu


def test_calc_mass():
    """Test the calc_mass function."""
    print("Testing calc_mass function...")

    R = 1.0
    eta = 0.5
    gamma = 0.7
    Mach2_et = 2.0
    gamma2 = 1.0
    const = 1.0
    nint = 3.0
    const_mag = 0.0
    gammag = 0.5

    try:
        mass = calc_mass(R, eta, gamma, Mach2_et, gamma2, const, nint, const_mag, gammag)
        print(f"  R={R}, calculated mass={mass}")
        assert mass > 0, "Mass should be positive"
        print("  ✓ calc_mass test passed")
        return True
    except Exception as e:
        print(f"  ✗ calc_mass test failed: {e}")
        return False


def test_sign_mass2():
    """Test the sign_mass2 function."""
    print("\nTesting sign_mass2 function...")

    mass = 1.0
    R = 1.0
    eta = 0.5
    gamma = 0.7
    Mach2_et = 2.0
    gamma2 = 1.0
    const = 1.0
    nint = 3.0
    const_mag = 0.0
    gammag = 0.5

    try:
        sign = sign_mass2(mass, R, eta, gamma, Mach2_et, gamma2, const, nint, const_mag, gammag)
        print(f"  mass={mass}, R={R}, sign={sign}")
        print("  ✓ sign_mass2 test passed")
        return True
    except Exception as e:
        print(f"  ✗ sign_mass2 test failed: {e}")
        return False


def test_calc_dM_dR2():
    """Test the calc_dM_dR2 function."""
    print("\nTesting calc_dM_dR2 function...")

    mass = 1.0
    R = 1.0
    gamma = 0.7
    eta = 0.5
    Mach2_et = 2.0
    gamma2 = 1.0
    const = 1.0
    nint = 3.0
    const_mag = 0.0
    gammag = 0.5

    try:
        dM_dR = calc_dM_dR2(mass, R, gamma, eta, Mach2_et, gamma2, const, nint, const_mag, gammag)
        print(f"  mass={mass}, R={R}, dM_dR={dM_dR}")
        print("  ✓ calc_dM_dR2 test passed")
        return True
    except Exception as e:
        print(f"  ✗ calc_dM_dR2 test failed: {e}")
        return False


def test_calc_imf2():
    """Test the calc_imf2 function."""
    print("\nTesting calc_imf2 function...")

    Mach = 6.0
    Mach2_et = 2.0
    eta = 0.5
    Li = 100.0
    gamma = 0.7
    b = 0.5
    gamma2 = 1.0
    const = 1.0
    nint = 3.0

    try:
        Mass_v, dens_v, Lfrac = calc_imf2(Mach, Mach2_et, eta, Li, gamma, b, gamma2, const, nint,
                                          time=True, nbin=100)
        print(f"  Generated {len(Mass_v)} mass bins")
        print(f"  Mass range: {np.min(Mass_v):.3e} to {np.max(Mass_v):.3e}")
        print(f"  Density range: {np.min(dens_v):.3e} to {np.max(dens_v):.3e}")
        assert len(Mass_v) == 100, "Should have 100 bins"
        assert len(dens_v) == 100, "Should have 100 bins"
        assert len(Lfrac) == 100, "Should have 100 bins"
        print("  ✓ calc_imf2 test passed")
        return True
    except Exception as e:
        print(f"  ✗ calc_imf2 test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_density_proj():
    """Test the density_proj function."""
    print("\nTesting density_proj function...")

    # Create simple test data
    Mass_v = np.logspace(-2, 2, 100)
    dens_v = np.exp(-(np.log10(Mass_v))**2 / 2.0)  # Gaussian-like distribution

    try:
        vect_mass, dens_proj = density_proj(dens_v, Mass_v, nn=50)
        print(f"  Generated {len(vect_mass)} projected mass bins")
        print(f"  Projected mass range: {np.min(vect_mass):.3e} to {np.max(vect_mass):.3e}")
        assert len(vect_mass) == 50, "Should have 50 bins"
        assert len(dens_proj) == 50, "Should have 50 bins"
        print("  ✓ density_proj test passed")
        return True
    except Exception as e:
        print(f"  ✗ density_proj test failed: {e}")
        return False


def test_imf_ff_noff():
    """Test the imf_ff_noff function."""
    print("\nTesting imf_ff_noff function...")

    try:
        result = imf_ff_noff(ncl=5, Lc=0.5, num='_test', short=True)
        print(f"  SFR: {result['sfr']:.4f}")
        print(f"  Mass bins: {len(result['vect_mass'])}")
        print(f"  Density bins: {len(result['dens_proj'])}")
        assert 'sfr' in result, "Result should contain 'sfr'"
        assert 'vect_mass' in result, "Result should contain 'vect_mass'"
        assert 'dens_proj' in result, "Result should contain 'dens_proj'"
        print("  ✓ imf_ff_noff test passed")
        return True
    except Exception as e:
        print(f"  ✗ imf_ff_noff test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_basic_simulation():
    """Run a basic simulation."""
    print("\nRunning basic simulation...")

    try:
        result = imf_ff_noff(ncl=5, Lc=0.5, num='_basic_test')
        print(f"  Simulation completed successfully")
        print(f"  SFR: {result['sfr']:.4f}")
        print("  ✓ Basic simulation passed")
        return True
    except Exception as e:
        print(f"  ✗ Basic simulation failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests."""
    print("="*60)
    print("Testing IDL to Python Translation")
    print("="*60)

    tests = [
        test_calc_mass,
        test_sign_mass2,
        test_calc_dM_dR2,
        test_calc_imf2,
        test_density_proj,
        test_imf_ff_noff,
        run_basic_simulation,
    ]

    results = []
    for test in tests:
        results.append(test())

    print("\n" + "="*60)
    print(f"Test Summary: {sum(results)}/{len(results)} tests passed")
    print("="*60)

    if all(results):
        print("\n✓ All tests passed! The translation appears to be working correctly.")
        print("\nYou can now run the full simulation suite with:")
        print("  python launch_simu.py")
        return 0
    else:
        print("\n✗ Some tests failed. Please review the errors above.")
        return 1


if __name__ == '__main__':
    sys.exit(main())
