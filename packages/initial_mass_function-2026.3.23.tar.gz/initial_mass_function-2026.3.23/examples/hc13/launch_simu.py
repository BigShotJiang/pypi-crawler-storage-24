"""
Launch simulations for IMF calculations.
Runs multiple IMF calculations with different parameters.

Translated from IDL to Python
"""

import numpy as np
from imf_ff_noff import imf_ff_noff
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def launch_simu():
    """
    Launch multiple IMF simulations with varying parameters.
    """
    # Physical constants
    Ms = 2.0e33  # grams
    yr = 3.0e7  # seconds
    Mp = 2.3 * 1.6e-24  # grams
    pc = 3.08e18  # cm
    G = 6.6e-8

    print("Running simulation 1...")
    result1 = imf_ff_noff(eta=0.5, nint=3.0, b=0.5, ncrit=1.0e99, ncl=30, num='_01',
                         g2=1.3, gamma=1.0, mach=6, m2_et=2.0, Li=1.0e3)

    print("\nRunning simulation 2...")
    result2 = imf_ff_noff(eta=0.5, nint=3.0, b=0.5, ncrit=1.0e99, ncl=5, num='_02',
                         g2=1.3, gamma=1.0, mach=6, m2_et=2.0, Li=1.0e3)

    print("\nRunning simulation 3...")
    result3 = imf_ff_noff(ncl=5, Lc=0.5, num='_03')

    print("\nRunning simulation 4...")
    result4 = imf_ff_noff(ncl=4, Lc=2.0, num='_04')

    print("\nRunning simulation 5...")
    result5 = imf_ff_noff(ncl=3, Lc=5.0, num='_05')

    print("\nRunning simulation 6...")
    result6 = imf_ff_noff(ncl=2, Lc=20.0, num='_06')

    # Loop for magnetic field variations
    configurations = [
        {'num': '_mag_03', 'ncl0': 5, 'Lc0': 0.5},
        {'num': '_mag_04', 'ncl0': 4, 'Lc0': 2.0},
        {'num': '_mag_05', 'ncl0': 3, 'Lc0': 5.0},
        {'num': '_mag_06', 'ncl0': 2, 'Lc0': 20.0}
    ]

    for i, config in enumerate(configurations):
        num = config['num']
        ncl0 = config['ncl0']
        Lc0 = config['Lc0']

        print(f"\nRunning magnetic simulation {i+1} with Lc={Lc0} pc...")

        # Va=0, gmag=0.1
        Va = 0.0
        gmag = 0.1
        result = imf_ff_noff(ncl=ncl0, Lc=Lc0, short=True,
                            Va0=Va * (ncl0**gmag), gmag=gmag)

        vect_mass = result['vect_mass']
        dens_proj = result['dens_proj']

        # Filter out zeros for max calculation
        valid = (dens_proj * vect_mass) > 0
        if np.any(valid):
            dens_max = np.max(np.log10(dens_proj[valid] * vect_mass[valid]))
        else:
            dens_max = 0

        # Va=1, gmag=0.1
        Va = 1.0
        gmag = 0.1
        result1 = imf_ff_noff(ncl=ncl0, Lc=Lc0, short=True,
                             Va0=Va * (ncl0**gmag), gmag=gmag)

        vect_mass1 = result1['vect_mass']
        dens_proj1 = result1['dens_proj']

        valid1 = (dens_proj1 * vect_mass1) > 0
        if np.any(valid1):
            dens_max1 = np.max(np.log10(dens_proj1[valid1] * vect_mass1[valid1]))
        else:
            dens_max1 = 0

        # Va=3, gmag=0.1
        Va = 3.0
        gmag = 0.1
        result2 = imf_ff_noff(ncl=ncl0, Lc=Lc0, short=True,
                             Va0=Va * (ncl0**gmag), gmag=gmag)

        vect_mass2 = result2['vect_mass']
        dens_proj2 = result2['dens_proj']

        valid2 = (dens_proj2 * vect_mass2) > 0
        if np.any(valid2):
            dens_max2 = np.max(np.log10(dens_proj2[valid2] * vect_mass2[valid2]))
        else:
            dens_max2 = 0

        # Va=1, gmag=0.3
        Va = 1.0
        gmag = 0.3
        result3 = imf_ff_noff(ncl=ncl0, Lc=Lc0, short=True,
                             Va0=Va * (ncl0**gmag), gmag=gmag)

        vect_mass3 = result3['vect_mass']
        dens_proj3 = result3['dens_proj']

        valid3 = (dens_proj3 * vect_mass3) > 0
        if np.any(valid3):
            dens_max3 = np.max(np.log10(dens_proj3[valid3] * vect_mass3[valid3]))
        else:
            dens_max3 = 0

        # Create plot
        plt.figure(figsize=(10, 5))

        titre = f'R={Lc0:.1f} pc'

        # Plot all magnetic field variations
        if np.any(valid):
            plt.plot(np.log10(vect_mass[valid]),
                    np.log10(dens_proj[valid] * vect_mass[valid]),
                    linewidth=3, label='Va=0')

        if np.any(valid1):
            plt.plot(np.log10(vect_mass1[valid1]),
                    np.log10(dens_proj1[valid1] * vect_mass1[valid1]) + dens_max - dens_max1,
                    linestyle='--', linewidth=3, label='Va=1, gmag=0.1')

        if np.any(valid2):
            plt.plot(np.log10(vect_mass2[valid2]),
                    np.log10(dens_proj2[valid2] * vect_mass2[valid2]) + dens_max - dens_max2,
                    linestyle=':', linewidth=3, label='Va=3, gmag=0.1')

        if np.any(valid3):
            plt.plot(np.log10(vect_mass3[valid3]),
                    np.log10(dens_proj3[valid3] * vect_mass3[valid3]) + dens_max - dens_max3,
                    linestyle='-.', linewidth=3, label='Va=1, gmag=0.3')

        plt.xlim(-2.0, 2.0)
        plt.ylim(dens_max - 2.0, dens_max)
        plt.xlabel('log(M) (M$_\\odot$)', fontsize=14)
        plt.ylabel('log(dN/dlogM)', fontsize=14)
        plt.title(titre, fontsize=16)
        plt.legend()
        plt.grid(True, alpha=0.3)

        output_file = f'imf_time_scale{num}.png'
        plt.savefig(output_file, dpi=150, bbox_inches='tight')
        print(f'Saved plot to {output_file}')
        plt.close()

    print("\nAll simulations completed!")


if __name__ == '__main__':
    launch_simu()
