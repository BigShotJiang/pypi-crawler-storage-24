"""
Compute the standard HC08 IMF and the IMF which takes into account
the correction of the crossing time.

Translated from IDL to Python
"""

import numpy as np
from imf_lib import calc_imf2, density_proj, read_chabrier_imf
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt


def imf_ff_noff(eta=0.45, g2=1.0, gamma=0.7, nint=3.0, b=0.5, ncrit=4.0e5,
                ncl=1.0, Lc=1.0, sig0=1.0, Cs0=2.0e4, num='', mach=None,
                m2_et=None, Li=None, L_coef=None, sfr=None, short=False,
                Va0=None, gmag=None, notime=False, ng=None, viriel=None):
    """
    Compute the IMF with or without time correction.

    Parameters:
    -----------
    eta : float, optional
        Velocity dispersion index (default: 0.45)
    g2 : float, optional
        Gamma2 parameter (default: 1.0)
    gamma : float, optional
        Polytropic index (default: 0.7)
    nint : float, optional
        Integration parameter (default: 3.0)
    b : float, optional
        Turbulent driving parameter (default: 0.5)
    ncrit : float, optional
        Critical density for cooling in cm^-3 (default: 4e5)
    ncl : float, optional
        Cloud density normalization (default: 1.0)
    Lc : float, optional
        Cloud size in pc (default: 1.0)
    sig0 : float, optional
        Velocity dispersion normalization (default: 1.0)
    Cs0 : float, optional
        Sound speed at 10^4 cm^-3 in cm/s (default: 2e4)
    num : str, optional
        Label for output files (default: '')
    mach : float, optional
        Mach number (calculated if not provided)
    m2_et : float, optional
        Squared Mach number at Jeans length (calculated if not provided)
    Li : float, optional
        Inertial/Jeans length ratio (calculated if not provided)
    L_coef : float, optional
        Length coefficient (default: 1.0)
    sfr : float, optional
        Star formation rate (output)
    short : bool, optional
        Short output mode (default: False)
    Va0 : float, optional
        Alfven speed normalization (default: None)
    gmag : float, optional
        Magnetic gamma parameter (default: None)
    notime : bool, optional
        Disable time correction (default: False)
    ng : float, optional
        Gas density override in cm^-3 (default: None)
    viriel : float, optional
        Virial parameter (default: None)

    Returns:
    --------
    dict : Dictionary containing results
        - sfr : Star formation rate
        - vect_mass : Mass vector
        - dens_proj : Projected density
        - cumul_mass : Cumulative mass
        - Lfrac : Size fractions
        - c2_mass : Mass cumulative with respect to size fraction
    """
    # Physical constants
    Ms = 2.0e33  # g (solar mass)
    Mp = 2.3 * 1.6e-24  # g (proton mass)
    G = 6.6e-8  # gravitational constant
    pc = 3.08e18  # cm (parsec)

    # Cloud characteristics
    gamma2 = g2

    # Cloud density (factor that multiplies Larson relation)
    # Assume that the density varies as Larson laws
    nc = ncl * 1000.0 / (Lc**0.7)
    nc_g = nc  # gas density equals total density (not the case in presence of stars)

    # If ng is set, override nc_g
    if ng is not None:
        nc_g = ng

    # Cloud mass (note: Lc is assumed to be cloud radius rather than diameter)
    Mc = 4.0 * np.pi / 3.0 * (nc * Mp) * (Lc * pc)**3 / Ms

    if not short:
        print(f'cloud mass {Mc}')

    # Velocity dispersion at 1 pc
    sigma0 = sig0 * 8.0e4  # cm/s

    # If viriel keyword is set, it takes over sigma0
    if viriel is not None:
        sigma0 = max([np.sqrt(viriel * 3.0 / 5.0 * Mc * Ms * G / (Lc * pc)), sigma0])

    # Number of bins for projected mass grid
    nproj = 5000

    # Freefall time at mean density
    tff = np.sqrt(3.0 * np.pi / 32.0) / np.sqrt(G * nc_g * Mp)

    # Sound speed
    Cs = Cs0 * np.sqrt((nc_g / 1.0e4)**(gamma - 1.0))

    if not short:
        print(f'Cs {Cs}')

    # Mach number
    if mach is None:
        Mach = sigma0 * (Lc)**eta / Cs  # the factor of 2 because L is the radius
    else:
        Mach = mach

    # Jeans length
    lambda_0 = (np.sqrt(np.pi) / 2.0)**0.333 * Cs / np.sqrt(G * nc_g * Mp) * gamma**0.5 / pc

    if not short:
        print(f'Lc {Lc}, lambda_0 {lambda_0}')

    # Jeans mass
    MJ_0 = (np.pi**2.5 / 6.0) * Cs**3 / G**1.5 / (nc_g * Mp)**0.5 * gamma**1.5 / Ms

    # The constant for the cooling
    const = (ncrit / nc_g)**(gamma - gamma2)

    # Inertial over Jeans length
    if Li is None:
        Li = Lc / lambda_0

    # Mach number at the Jeans length
    if m2_et is None:
        Mach2_et = (Mach / Li**eta / np.sqrt(3.0))**2
    else:
        Mach2_et = m2_et

    # Alfven speed
    Va = 10.0 * 1.0e-6 / np.sqrt(4.0 * np.pi) / np.sqrt(nc_g * Mp)
    if Va0 is not None:
        Va = Va * Va0
    else:
        Va = 0.0
    const_mag = (Va / Cs)**2 / 6.0

    print(f'const_mag {const_mag}')

    # Set gmag if not provided
    if gmag is None:
        gmag = 0.5

    if not short:
        print('mach,mach2_et,eta,Li,gamma,b,gamma2,const,nint')
        print(Mach, Mach2_et, eta, Li, gamma, b, gamma2, const, nint)

    # Time dependent theory by default
    time = not notime

    # Calculate the IMF taking into account the time correction
    Mass, dens, Lfrac = calc_imf2(Mach, Mach2_et, eta, Li, gamma, b, gamma2, const, nint,
                                   time=time, nbin=500, L_coef=L_coef if L_coef is not None else 1.0,
                                   const_mag=const_mag, gammag=gmag)

    # Calculate the cumulative with respect to the size fraction (Lfrac)
    ndist = len(Mass)
    dM = Mass - np.roll(Mass, 1)
    dM[0] = dM[1]

    cumul = 0.0
    c2_mass = np.zeros_like(Mass)
    for i in range(ndist):
        cumul = cumul + (Mass[i] * dens[i] * dM[i])
        c2_mass[i] = cumul

    # Normalize the mass
    Mass_norm = Mass * MJ_0

    # Check that the fraction put into stars is equal (or smaller) than 1
    dM = Mass - np.roll(Mass, 1)
    dM[0] = dM[1]
    mtot = np.sum(Mass * dens * dM)

    # Define the star formation rate per freefall time (at mean cloud density)
    sfr = mtot

    # Project the density onto a regular grid of masses
    vect_mass, dens_proj = density_proj(dens, Mass_norm, nn=nproj, log_mmax=5.0)

    # We have to express dens_proj in MJ_0 because dens is now in MJ_0
    dens_proj = dens_proj / MJ_0

    dens_max = np.max(np.log10(dens_proj * vect_mass + 1e-100))  # Add small value to avoid log(0)

    # Check the mass fraction on the reprojected grid is ok
    dM = vect_mass - np.roll(vect_mass, 1)
    dM[0] = dM[1]
    mtot_proj = np.sum(vect_mass * dens_proj * dM) / MJ_0

    cumul_mass = np.zeros_like(dens_proj)
    cumul = 0.0

    for i in range(nproj):
        # Division by MJ_0 because cumul is dimensionless
        cumul = cumul + (vect_mass[i] * dens_proj[i] * dM[i]) / MJ_0
        cumul_mass[i] = cumul

    if abs(mtot - mtot_proj) / mtot > 0.05:
        print(f'mtot: {mtot}, mtot_proj: {mtot_proj}')

    if short:
        return {
            'sfr': sfr,
            'vect_mass': vect_mass,
            'dens_proj': dens_proj,
            'cumul_mass': cumul_mass,
            'Lfrac': Lfrac,
            'c2_mass': c2_mass
        }

    # Calculate the IMF without any time correction
    Mass2, dens2, _ = calc_imf2(Mach, Mach2_et, eta, Li, gamma, b, gamma2, const, nint,
                                time=False, nbin=500, const_mag=const_mag, gammag=gmag)

    # Normalize the mass
    Mass_norm2 = Mass2 * MJ_0

    # Check that the fraction put into stars is equal (or smaller) than 1
    dM2 = Mass2 - np.roll(Mass2, 1)
    dM2[0] = dM2[1]
    mtot2 = np.sum(Mass2 * dens2 * dM2)

    # Project the density onto a regular grid of masses
    vect_mass2, dens_proj2 = density_proj(dens2, Mass_norm2, nn=nproj, log_mmax=5.0)

    dens_proj2 = dens_proj2 / MJ_0

    # Check mass fraction
    dM2 = vect_mass2 - np.roll(vect_mass2, 1)
    dM2[0] = dM2[1]
    mtot_proj2 = np.sum(vect_mass2 * dens_proj2 * dM2) / MJ_0

    if abs(mtot2 - mtot_proj2) / mtot2 > 0.05:
        print(f'mtot2: {mtot2}, mtot_proj2: {mtot_proj2}')

    dens_max2 = np.max(np.log10(dens_proj2 * vect_mass2 + 1e-100))

    # Read Chabrier IMF
    logm_v, num_v = read_chabrier_imf()

    # Create plots
    plt.figure(figsize=(10, 5))

    # Normalize Chabrier's IMF
    if len(num_v) > 0:
        num_v = num_v - np.max(num_v) + dens_max

        # Shift Chabrier's IMF
        logm_v = logm_v + np.log10(3.0)

    if Li < 100.0:
        titre = f'R={Lc:.1f} pc'
    else:
        titre = ''

    # Filter out zero or negative values for plotting
    valid_idx = (dens_proj * vect_mass) > 0
    plot_mass = vect_mass[valid_idx]
    plot_dens = dens_proj[valid_idx] * plot_mass

    valid_idx2 = (dens_proj2 * vect_mass2) > 0
    plot_mass2 = vect_mass2[valid_idx2]
    plot_dens2 = dens_proj2[valid_idx2] * plot_mass2

    plt.plot(np.log10(plot_mass), np.log10(plot_dens),
             linewidth=3, label='With time correction')
    plt.plot(np.log10(plot_mass2), np.log10(plot_dens2) + dens_max - dens_max2,
             linestyle='--', linewidth=3, label='Without time correction')

    if len(num_v) > 0:
        plt.plot(logm_v, num_v, linestyle=':', linewidth=3, label='Chabrier IMF')

    plt.xlim(-2.0, 2.0)
    plt.ylim(dens_max - 2.0, dens_max)
    plt.xlabel('log(M) (M$_\\odot$)', fontsize=14)
    plt.ylabel('log(dN/dlogM)', fontsize=14)
    plt.title(titre, fontsize=16)
    plt.legend()
    plt.grid(True, alpha=0.3)

    output_file = f'imf_time_scale{num}.png'
    plt.savefig(output_file, dpi=150, bbox_inches='tight')
    print(f'Saved plot to {output_file}')
    plt.close()

    return {
        'sfr': sfr,
        'vect_mass': vect_mass,
        'dens_proj': dens_proj,
        'cumul_mass': cumul_mass,
        'Lfrac': Lfrac,
        'c2_mass': c2_mass
    }


if __name__ == '__main__':
    # Test run
    result = imf_ff_noff(ncl=5, Lc=0.5, num='_test')
    print(f"SFR: {result['sfr']}")
