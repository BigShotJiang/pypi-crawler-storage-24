#!/usr/bin/env python
"""Quick validation that the modules can be imported."""

import sys
import os

print("Python version:", sys.version)
print("Working directory:", os.getcwd())
print()

try:
    import numpy as np
    print("✓ NumPy imported successfully, version:", np.__version__)
except ImportError as e:
    print("✗ Failed to import NumPy:", e)
    sys.exit(1)

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    print("✓ Matplotlib imported successfully, version:", matplotlib.__version__)
except ImportError as e:
    print("✗ Failed to import Matplotlib:", e)
    sys.exit(1)

print()
print("Checking translated modules...")

try:
    from imf_lib import calc_mass, calc_imf2, density_proj
    print("✓ imf_lib.py imported successfully")
    print("  - calc_mass function available")
    print("  - calc_imf2 function available")
    print("  - density_proj function available")
except Exception as e:
    print("✗ Failed to import imf_lib.py:", e)
    import traceback
    traceback.print_exc()
    sys.exit(1)

try:
    from imf_ff_noff import imf_ff_noff
    print("✓ imf_ff_noff.py imported successfully")
    print("  - imf_ff_noff function available")
except Exception as e:
    print("✗ Failed to import imf_ff_noff.py:", e)
    import traceback
    traceback.print_exc()
    sys.exit(1)

try:
    from launch_simu import launch_simu
    print("✓ launch_simu.py imported successfully")
    print("  - launch_simu function available")
except Exception as e:
    print("✗ Failed to import launch_simu.py:", e)
    import traceback
    traceback.print_exc()
    sys.exit(1)

print()
print("="*60)
print("✓ All modules imported successfully!")
print("="*60)
print()
print("You can now run:")
print("  1. Test suite: python test_translation.py")
print("  2. Full simulations: python launch_simu.py")
print("  3. Single simulation: python -c 'from imf_ff_noff import imf_ff_noff; imf_ff_noff()'")
