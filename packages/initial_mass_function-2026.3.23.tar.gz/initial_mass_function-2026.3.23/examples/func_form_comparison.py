import numpy as np
import pylab as pl
import imf

# Set up plotting parameters
pl.rc('font', size=20)
pl.ion()

# Create mass array for comparison
masses = np.logspace(-2, 2, 500)

# Create different IMF models
salpeter = imf.Salpeter()(masses)
kroupa = imf.Kroupa()(masses)
chabrier = imf.chabrier2005(masses)
kirkpatrick = imf.Kirkpatrick2024()(masses)

# Create comparison plot
pl.figure(figsize=(10, 8))
pl.loglog(masses, salpeter*masses, label='Salpeter')
pl.loglog(masses, kroupa*masses, label='Kroupa')
pl.loglog(masses, chabrier*masses, label='Chabrier')
pl.loglog(masses, kirkpatrick*masses, label='Kirkpatrick')

# Add labels and legend
pl.xlabel("Stellar Mass (M$_\odot$)")
pl.ylabel("m dN / dM")
pl.legend(loc='best')

# Save the figure
pl.savefig('func_form_comparison.png', bbox_inches='tight')
pl.savefig('func_form_comparison.pdf', bbox_inches='tight')

pl.figure(figsize=(10, 8))
pl.loglog(masses, salpeter, label='Salpeter')
pl.loglog(masses, kroupa, label='Kroupa')
pl.loglog(masses, chabrier, label='Chabrier')
pl.loglog(masses, kirkpatrick, label='Kirkpatrick')

# Add labels and legend
pl.xlabel("Stellar Mass (M$_\odot$)")
pl.ylabel("dN / dM")
pl.legend(loc='best')

# Save the figure
pl.savefig('func_form_comparison_number.png', bbox_inches='tight')
pl.savefig('func_form_comparison_number.pdf', bbox_inches='tight')


# Create individual plots for different Salpeter slopes
for alpha, name in [(1.5, 'Alpha1p5'),
                    (2.0, 'Alpha2p0'),
                    (1.0, 'Alpha1p0'),
                    (3.0, 'Alpha3p0')]:
    pl.figure(figsize=(10, 8))
    pl.clf()

    # Generate cluster data
    cluster, yax, colors = imf.coolplot(1000, massfunc=imf.Salpeter(alpha=alpha))

    # Plot cluster data
    pl.scatter(cluster, yax, c=colors, s=np.log10(cluster+3)*85,
               linewidths=0.5, edgecolors=(0, 0, 0, 0.25), alpha=0.95)

    # Plot theoretical IMF
    masses = np.logspace(np.log10(cluster.min()), np.log10(cluster.max()), 10000)
    pl.plot(masses, np.log10(imf.Salpeter(alpha=alpha)(masses)), 'r--',
            linewidth=2, alpha=0.5)

    # Add labels and set scale
    pl.xlabel("Stellar Mass")
    pl.ylabel("log(dN(M)/dM)")
    pl.gca().set_xscale('log')
    pl.gca().axis([min(cluster)/1.1, max(cluster)*1.1,
                   min(yax)-0.2, max(yax)+0.5])

    # Save figures
    pl.savefig(f"{name}_imf_figure_log.png", bbox_inches='tight', dpi=150)
    pl.savefig(f"{name}_imf_figure_log.pdf", bbox_inches='tight')

# Optional: Display the figures
pl.show()
