########################################################
# Started Logging At: 2026-03-23 13:25:18
########################################################
########################################################
# # Started Logging At: 2026-03-23 13:25:19
########################################################
import numpy as np
import matplotlib.pyplot as plt
from imf import KoenConvolvedPowerLaw, SpotKoenConvolvedPowerLaw
from time import perf_counter
L = 0.03
U = 120
gamma = 0.9; alpha = gamma + 1
sigma = 0.4
ntrials = 10
t0 = perf_counter()
for n in range(ntrials):
    spot_koc = SpotKoenConvolvedPowerLaw(L,U,alpha,sigma)
avg_spot_time = (perf_counter() - t0)/ntrials
print(f'Average time to create on-the-spot powerlaw: {avg_spot_time} s')
t0 = perf_counter()
for n in range(ntrials):
    int_koc = KoenConvolvedPowerLaw(L,U,alpha,sigma)
avg_int_time = (perf_counter() - t0)/ntrials
print(f'Average time to create interpolated powerlaw: {avg_int_time} s')
print(f'Interp/spot creation ratio: {avg_int_time/avg_spot_time}')
integral_form = False
t0 = perf_counter()
for n in range(ntrials):
    spot_func = spot_koc(10,integral_form=integral_form)
avg_spot_time = (perf_counter() - t0)/ntrials
print(f'Average time to evaluate scalar on the spot: {avg_spot_time} s')
t0 = perf_counter()
for n in range(ntrials):
    int_func = int_koc(10,integral_form=integral_form)
avg_int_time = (perf_counter() - t0)/ntrials
print(f'Average time to interpolate scalar: {avg_int_time} s')
print(f'Interp/spot scalar evaluation ratio: {avg_int_time/avg_spot_time}')
m = np.geomspace(L,U,100)
t0 = perf_counter()
for n in range(ntrials):
    spot_func = spot_koc(m,integral_form=integral_form)
avg_spot_time = (perf_counter() - t0)/ntrials
print(f'Average time to evaluate array on the spot: {avg_spot_time} s')
t0 = perf_counter()
for n in range(ntrials):
    int_func = int_koc(m,integral_form=integral_form)
avg_int_time = (perf_counter() - t0)/ntrials
print(f'Average time to interpolate array: {avg_int_time} s')
print(f'Interp/spot array evaluation ratio: {avg_int_time/avg_spot_time}')
plt.plot(m,spot_func,label='on-the-spot')
plt.plot(m,int_func,label='interpolated')
plt.xscale('log'); plt.yscale('log')
plt.legend()
plt.xlabel(r'Mass ($M_\odot$)')
plt.ylabel('PDF')
#[Out]# Text(0, 0.5, 'PDF')
percent_diff = ((int_func-spot_func) / spot_func * 100)

plt.plot(m,percent_diff)
plt.xscale('log')
plt.title('Ratio')
plt.xlabel(r'Mass ($M_\odot$)')
plt.ylabel('Interpolated/On-the-spot difference (%)')
#[Out]# Text(0, 0.5, 'Interpolated/On-the-spot difference (%)')
########################################################
# Started Logging At: 2026-03-23 13:29:47
########################################################
########################################################
# # Started Logging At: 2026-03-23 13:29:48
########################################################
import numpy as np
import matplotlib.pyplot as plt
from imf import KoenConvolvedPowerLaw, SpotKoenConvolvedPowerLaw
from time import perf_counter
L = 0.03
U = 120
gamma = 0.9; alpha = gamma + 1
sigma = 0.4
ntrials = 10
t0 = perf_counter()
for n in range(ntrials):
    spot_koc = SpotKoenConvolvedPowerLaw(L,U,alpha,sigma)
avg_spot_time = (perf_counter() - t0)/ntrials
print(f'Average time to create on-the-spot powerlaw: {avg_spot_time} s')
t0 = perf_counter()
for n in range(ntrials):
    int_koc = KoenConvolvedPowerLaw(L,U,alpha,sigma)
avg_int_time = (perf_counter() - t0)/ntrials
print(f'Average time to create interpolated powerlaw: {avg_int_time} s')
print(f'Interp/spot creation ratio: {avg_int_time/avg_spot_time}')
integral_form = False
t0 = perf_counter()
for n in range(ntrials):
    spot_func = spot_koc(10,integral_form=integral_form)
avg_spot_time = (perf_counter() - t0)/ntrials
print(f'Average time to evaluate scalar on the spot: {avg_spot_time} s')
t0 = perf_counter()
for n in range(ntrials):
    int_func = int_koc(10,integral_form=integral_form)
avg_int_time = (perf_counter() - t0)/ntrials
print(f'Average time to interpolate scalar: {avg_int_time} s')
print(f'Interp/spot scalar evaluation ratio: {avg_int_time/avg_spot_time}')
m = np.geomspace(L,U,100)
t0 = perf_counter()
for n in range(ntrials):
    spot_func = spot_koc(m,integral_form=integral_form)
avg_spot_time = (perf_counter() - t0)/ntrials
print(f'Average time to evaluate array on the spot: {avg_spot_time} s')
t0 = perf_counter()
for n in range(ntrials):
    int_func = int_koc(m,integral_form=integral_form)
avg_int_time = (perf_counter() - t0)/ntrials
print(f'Average time to interpolate array: {avg_int_time} s')
print(f'Interp/spot array evaluation ratio: {avg_int_time/avg_spot_time}')
plt.plot(m,spot_func,label='on-the-spot')
plt.plot(m,int_func,label='interpolated')
plt.xscale('log'); plt.yscale('log')
plt.legend()
plt.xlabel(r'Mass ($M_\odot$)')
plt.ylabel('PDF')
#[Out]# Text(0, 0.5, 'PDF')
percent_diff = ((int_func-spot_func) / spot_func * 100)

plt.plot(m,percent_diff)
plt.xscale('log')
plt.title('Ratio')
plt.xlabel(r'Mass ($M_\odot$)')
plt.ylabel('Interpolated/On-the-spot difference (%)')
#[Out]# Text(0, 0.5, 'Interpolated/On-the-spot difference (%)')
########################################################
# Started Logging At: 2026-03-23 13:31:02
########################################################
########################################################
# # Started Logging At: 2026-03-23 13:31:03
########################################################
from imf import Salpeter,Kroupa,ChabrierLogNormal,ChabrierPowerLaw,KoenConvolvedPowerLaw
from imf import make_cluster
import numpy as np
import matplotlib.pyplot as plt
from time import perf_counter
def normalization(max_star,massfunc):
    return 1/massfunc.integrate(max_star,massfunc.mmax)[0]

def hist_props(stars,massfunc):
    edges = [stars[0]*1.01]
    for i in range(1,np.floor_divide(len(stars),10)):
        try:
            edge = (stars[10*i-1]+stars[10*i])/2
            edges.append(edge)
        except(IndexError):
            continue
    edges.append(massfunc.mmin)
    edges = np.array(edges)[::-1]
    dm = edges[1:]-edges[:-1]

    weights = np.ones(len(stars))
    for i in range(len(dm)):
        weights[np.logical_and(stars > edges[i],stars < edges[i+1])] *= 1/dm[i]
        
    return edges,weights
opt_cl = make_cluster(1e3,'kroupa',sampling='optimal')
rand_cl = make_cluster(1e3,'kroupa')
plt.figure()
massfunc = Kroupa()
k = normalization(opt_cl[0],massfunc)
plt.plot(opt_cl,k*massfunc(opt_cl),label='IMF')

edges,weights = hist_props(opt_cl,massfunc)
n,bins,patches = plt.hist(opt_cl,bins=edges,weights=weights,histtype='step',
                          label='optimal',zorder=-2)

rand_cl.sort()
rand_cl = rand_cl[::-1]
edges,weights = hist_props(rand_cl,massfunc)
n,bins,patches = plt.hist(rand_cl,bins=edges,weights=weights,histtype='step',
                          label='random (nearest)',zorder=-1)

plt.title('Random vs. Optimally Sampled Kroupa IMF')
plt.xscale('log'); plt.yscale('log')
plt.xlabel('M'); plt.ylabel('dN/dM')
plt.legend()
#[Out]# <matplotlib.legend.Legend at 0x16e75b380>
def make_hist(stars,massfunc):
    edges,weights = hist_props(stars,massfunc)
    plt.figure()
    k = normalization(stars[0],massfunc)
    plt.plot(stars,k*massfunc(stars),label='IMF')
    n,bins,patches = plt.hist(stars,bins=edges,weights=weights,histtype='step',label='sampled')
    #plt.title('Random vs. Optimally Sampled Kroupa IMF')
    plt.xscale('log'); plt.yscale('log')
    plt.xlabel('M'); plt.ylabel('dN/dM')
    plt.legend()
M_res = 1000
sp = Salpeter()
cl = make_cluster(M_res,massfunc=sp,sampling='optimal')
assert M_res-cl.sum() <= sp.mmin
make_hist(cl,sp)
kr = Kroupa()
cl = make_cluster(M_res,massfunc=kr,sampling='optimal')
assert M_res-cl.sum() <= kr.mmin
make_hist(cl,kr)
chl = ChabrierLogNormal(mmin=0.03)
cl = make_cluster(M_res,massfunc=chl,sampling='optimal')
assert M_res-cl.sum() <= chl.mmin
make_hist(cl,chl)
chp = ChabrierPowerLaw(mmin=0.03)
cl = make_cluster(M_res,massfunc=chp,sampling='optimal')
assert M_res-cl.sum() <= chp.mmin
make_hist(cl,chp)
koc = KoenConvolvedPowerLaw(0.03,120,1.9,0.4)
cl = make_cluster(M_res,massfunc=koc,sampling='optimal')
assert M_res-cl.sum() <= koc.mmin
make_hist(cl,koc)
print(koc.quad_sub_limit)
koc.quad_sub_limit = 100
print(koc.quad_sub_limit)
chl = ChabrierLogNormal()
try:
    cl = make_cluster(1e3,massfunc=chl,sampling='optimal')
except(ValueError):
    print('Caught exception due to zero mmin and tolerance.')
tolerance = 0.1
cl = make_cluster(1e3,massfunc=chl,sampling='optimal',tolerance=tolerance)
assert M_res-cl.sum() <= tolerance
make_hist(cl,chl)
chl = ChabrierLogNormal(mmin=0.03,mmax=150)
t0 = perf_counter()
cl = make_cluster(M_res*100,massfunc=chl,sampling='optimal')
tot_time = perf_counter() - t0
print(f'Total time to make this cluster was {np.round(tot_time)} seconds.')
assert M_res-cl.sum() <= chl.mmin
make_hist(cl,chl)
