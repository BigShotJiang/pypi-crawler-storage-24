from typing import Optional
import logging
import time

from .base import AIProvider

logger = logging.getLogger(__name__)


class GeminiProvider(AIProvider):
    def __init__(self, api_key: str, model: str = "gemini-2.5-flash", temperature: float = 0.7):
        super().__init__(api_key, model, temperature)
        try:
            from google import genai
            from google.genai import types

            self.client = genai.Client(api_key=api_key)
            self.types = types
            logger.info(f"Initialized Gemini AI provider with model {model}")
        except ImportError:
            raise ImportError("google-genai not installed. Run: pip install google-genai")

    def complete(
        self,
        prompt: str,
        temperature: Optional[float] = None,
        max_tokens: int = 4096,
        timeout: int = 30,
    ) -> str:
        """Send a prompt to Gemini and return the text response."""
        temp = temperature if temperature is not None else self.temperature

        config = self.types.GenerateContentConfig(
            temperature=temp,
            max_output_tokens=max_tokens,
        )

        # Retry with exponential backoff
        max_retries = 3
        base_delay = 1

        for attempt in range(max_retries):
            try:
                logger.debug(f"[Gemini] API call attempt {attempt + 1}/{max_retries}")
                response = self.client.models.generate_content(
                    model=self.model,
                    contents=prompt,
                    config=config,
                )

                if not response:
                    raise ValueError("Empty response from Gemini")

                try:
                    text = response.text
                    if text is None:
                        raise ValueError("Empty text response from Gemini")
                    return text
                except (ValueError, AttributeError):
                    if (
                        response.candidates
                        and response.candidates[0].content is not None
                        and response.candidates[0].content.parts
                    ):
                        return "".join(
                            str(part.text)
                            for part in response.candidates[0].content.parts
                            if hasattr(part, "text")
                        )
                    raise ValueError("Could not extract text from Gemini response")

            except Exception as e:
                error_str = str(e).lower()
                is_retryable = any(
                    x in error_str for x in ["504", "timeout", "429", "quota", "rate"]
                )

                if is_retryable and attempt < max_retries - 1:
                    delay = base_delay * (2**attempt)
                    logger.warning(
                        f"[Gemini] Retryable error on attempt {attempt + 1}: {e}. Retrying in {delay}s..."
                    )
                    time.sleep(delay)
                    continue
                raise

        raise RuntimeError("Failed to get response from Gemini after retries")
