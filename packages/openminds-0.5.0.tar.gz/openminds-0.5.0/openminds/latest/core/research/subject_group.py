"""
<description not available>
"""

# this file was auto-generated!

from openminds.base import LinkedMetadata
from openminds.properties import Property


class SubjectGroup(LinkedMetadata):
    """
    <description not available>
    """

    type_ = "https://openminds.om-i.org/types/SubjectGroup"
    context = {"@vocab": "https://openminds.om-i.org/props/"}
    schema_version = "latest"

    properties = [
        Property(
            "additional_remarks",
            str,
            "additionalRemarks",
            formatting="text/markdown",
            multiline=True,
            description="Mention of what deserves additional attention or notice.",
            instructions="Enter any additional remarks concerning this specimen set.",
        ),
        Property(
            "biological_sexes",
            "openminds.latest.controlled_terms.BiologicalSex",
            "biologicalSex",
            multiple=True,
            unique_items=True,
            min_items=1,
            description="Differentiation of individuals of most species (animals and plants) based on the type of gametes they produce.",
            instructions="Add the biological sex of all specimen in this set.",
        ),
        Property(
            "internal_identifier",
            str,
            "internalIdentifier",
            formatting="text/plain",
            description="Term or code that identifies the subject group within a particular product.",
            instructions="Enter the identifier (or label) of this specimen set that is used within the corresponding data files to identify this specimen set.",
        ),
        Property(
            "is_part_of",
            "openminds.latest.core.SubjectGroup",
            "isPartOf",
            multiple=True,
            unique_items=True,
            min_items=1,
            description="Reference to the ensemble of multiple things or beings.",
            instructions="Add all subject groups of which this subject group is a subgroup.",
        ),
        Property(
            "lookup_label",
            str,
            "lookupLabel",
            formatting="text/plain",
            description="no description available",
            instructions="Enter a lookup label for this specimen set that may help you to find this instance more easily.",
        ),
        Property(
            "number_of_subjects",
            int,
            "numberOfSubjects",
            required=True,
            description="no description available",
            instructions="Enter the number of subjects that belong to this subject group.",
        ),
        Property(
            "species",
            ["openminds.latest.controlled_terms.Species", "openminds.latest.core.Strain"],
            "species",
            multiple=True,
            unique_items=True,
            min_items=1,
            required=True,
            description="Category of biological classification comprising related organisms or populations potentially capable of interbreeding, and being designated by a binomial that consists of the name of a genus followed by a Latin or latinized uncapitalized noun or adjective.",
            instructions="Add the species and/or strain (a sub-type of a genetic variant of species) of all specimen in this set.",
        ),
        Property(
            "studied_states",
            "openminds.latest.core.SubjectGroupState",
            "studiedState",
            multiple=True,
            unique_items=True,
            min_items=1,
            required=True,
            description="Reference to a point in time at which the subject group was studied in a particular mode or condition.",
            instructions="Add all states in which this subject group was studied.",
        ),
    ]

    def __init__(
        self,
        id=None,
        additional_remarks=None,
        biological_sexes=None,
        internal_identifier=None,
        is_part_of=None,
        lookup_label=None,
        number_of_subjects=None,
        species=None,
        studied_states=None,
    ):
        return super().__init__(
            id=id,
            additional_remarks=additional_remarks,
            biological_sexes=biological_sexes,
            internal_identifier=internal_identifier,
            is_part_of=is_part_of,
            lookup_label=lookup_label,
            number_of_subjects=number_of_subjects,
            species=species,
            studied_states=studied_states,
        )
