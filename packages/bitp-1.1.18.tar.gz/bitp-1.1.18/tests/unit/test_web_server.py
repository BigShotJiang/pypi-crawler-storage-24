#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for the web server, SSE, and API route matching."""

import json
import os
import queue
import re
import threading
import time
import unittest
from http.client import HTTPConnection
from unittest.mock import MagicMock, patch

from bitbake_project.web.sse import SSEManager, format_sse
from bitbake_project.web.server import _routes, STATIC_DIR, BitWebHandler


# =============================================================================
# SSE Manager Tests
# =============================================================================

class TestSSEManager(unittest.TestCase):
    """Test SSE subscriber management."""

    def setUp(self):
        self.sse = SSEManager()

    def test_subscribe_returns_queue(self):
        q = self.sse.subscribe()
        self.assertIsInstance(q, queue.Queue)

    def test_subscribe_sends_connected_event(self):
        q = self.sse.subscribe()
        event_type, data = q.get_nowait()
        self.assertEqual(event_type, "connected")
        self.assertEqual(data["status"], "ok")

    def test_subscriber_count(self):
        self.assertEqual(self.sse.subscriber_count(), 0)
        q1 = self.sse.subscribe()
        self.assertEqual(self.sse.subscriber_count(), 1)
        q2 = self.sse.subscribe()
        self.assertEqual(self.sse.subscriber_count(), 2)

    def test_unsubscribe(self):
        q = self.sse.subscribe()
        self.assertEqual(self.sse.subscriber_count(), 1)
        self.sse.unsubscribe(q)
        self.assertEqual(self.sse.subscriber_count(), 0)

    def test_unsubscribe_nonexistent(self):
        q = queue.Queue()
        # Should not raise
        self.sse.unsubscribe(q)

    def test_broadcast(self):
        q1 = self.sse.subscribe()
        q2 = self.sse.subscribe()
        # Drain connected events
        q1.get_nowait()
        q2.get_nowait()

        self.sse.broadcast("test_event", {"key": "value"})

        et1, d1 = q1.get_nowait()
        et2, d2 = q2.get_nowait()
        self.assertEqual(et1, "test_event")
        self.assertEqual(d1["key"], "value")
        self.assertEqual(et2, "test_event")
        self.assertEqual(d2["key"], "value")

    def test_broadcast_no_subscribers(self):
        # Should not raise
        self.sse.broadcast("test", {"data": 1})

    def test_format_sse(self):
        result = format_sse("my_event", {"foo": "bar"})
        self.assertIsInstance(result, bytes)
        text = result.decode("utf-8")
        self.assertIn("event: my_event\n", text)
        self.assertIn('"foo": "bar"', text)
        self.assertTrue(text.endswith("\n\n"))


# =============================================================================
# SSE Coexistence Tests
# =============================================================================

class TestSSECoexistence(unittest.TestCase):
    """Test SSE detects changes for TUI-web coexistence."""

    def test_projects_file_change_detected(self):
        """SSE broadcasts when projects.json mtime changes."""
        import tempfile
        sse = SSEManager()
        q = sse.subscribe()
        q.get_nowait()  # drain connected

        # Create a temp file to serve as projects.json
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write('{}')
            projects_file = f.name

        try:
            sse._projects_file_fn = lambda: projects_file
            sse._get_current_project_fn = lambda: "/some/project"
            # Set initial state
            sse._last_projects_mtime = 0.0
            sse._last_project_path = "/some/project"

            # Trigger check — mtime will differ from 0.0
            sse._check_changes()

            # Should have broadcast projects_list_changed
            event_type, data = q.get_nowait()
            self.assertEqual(event_type, "projects_list_changed")
        finally:
            os.unlink(projects_file)

    def test_project_switch_detected(self):
        """SSE broadcasts when current project changes."""
        sse = SSEManager()
        q = sse.subscribe()
        q.get_nowait()  # drain connected

        sse._projects_file_fn = lambda: None  # no file to check
        sse._get_current_project_fn = lambda: "/new/project"
        sse._last_projects_mtime = 0.0
        sse._last_project_path = "/old/project"

        sse._check_changes()

        event_type, data = q.get_nowait()
        self.assertEqual(event_type, "project_changed")
        self.assertEqual(data["path"], "/new/project")


# =============================================================================
# Route Registration Tests
# =============================================================================

class TestRouteRegistration(unittest.TestCase):
    """Test that API routes are properly registered."""

    @classmethod
    def setUpClass(cls):
        # Import to trigger route registration
        from bitbake_project.web import api, api_commands  # noqa: F401

    def test_routes_registered(self):
        """Verify routes are registered."""
        self.assertGreater(len(_routes), 0)

    def test_core_routes_exist(self):
        """Key API routes must be present."""
        route_patterns = [r[1].pattern for r in _routes]
        expected = [
            "/api/projects",
            "/api/projects/current",
            "/api/repos",
            "/api/config",
        ]
        for ep in expected:
            found = any(p == f"^{ep}$" for p in route_patterns)
            self.assertTrue(found, f"Route {ep} not found in registered routes")

    def test_parametric_routes_exist(self):
        """Routes with path params must match correctly."""
        # Find the repo commits route
        for method, pattern, handler in _routes:
            if "commits" in pattern.pattern:
                m = pattern.match("/api/repos/my-repo/commits")
                self.assertIsNotNone(m, f"Pattern {pattern.pattern} should match /api/repos/my-repo/commits")
                self.assertEqual(m.group(1), "my-repo")
                break
        else:
            self.fail("No commits route found")

    def test_route_methods(self):
        """Routes should have correct HTTP methods."""
        method_map = {}
        for method, pattern, handler in _routes:
            key = pattern.pattern
            method_map.setdefault(key, set()).add(method)

        # GET endpoints
        self.assertIn("GET", method_map.get("^/api/projects$", set()))
        self.assertIn("GET", method_map.get("^/api/repos$", set()))
        self.assertIn("GET", method_map.get("^/api/config$", set()))

        # POST endpoints
        self.assertIn("POST", method_map.get("^/api/refresh$", set()))


# =============================================================================
# Static File Serving Tests
# =============================================================================

class TestStaticFiles(unittest.TestCase):
    """Test static file configuration."""

    def test_static_dir_exists(self):
        self.assertTrue(os.path.isdir(STATIC_DIR))

    def test_index_html_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "index.html")))

    def test_style_css_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "style.css")))

    def test_app_js_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "js", "app.js")))

    def test_api_js_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "js", "api.js")))

    def test_utils_js_exists(self):
        """New shared utilities file must exist."""
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "js", "utils.js")))

    def test_column_resizer_js_exists(self):
        """New column resizer file must exist."""
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "js", "column-resizer.js")))

    def test_commits_js_exists(self):
        """New commits view file must exist."""
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "js", "views", "commits.js")))

    def test_vendor_dir_exists(self):
        """Vendor directory for third-party libs must exist."""
        self.assertTrue(os.path.isdir(os.path.join(STATIC_DIR, "vendor")))

    def test_vendor_diff2html_css_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "vendor", "diff2html.min.css")))

    def test_vendor_diff2html_js_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "vendor", "diff2html-ui.min.js")))

    def test_vendor_highlight_js_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "vendor", "highlight.min.js")))

    def test_vendor_github_dark_css_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "vendor", "github-dark.min.css")))

    def test_view_files_exist(self):
        views_dir = os.path.join(STATIC_DIR, "js", "views")
        expected_views = [
            "dashboard.js", "explore.js", "commits.js", "branch.js", "update.js",
            "config.js", "patches.js", "b4.js", "recipes.js",
            "fragments.js", "deps.js", "info.js", "export.js", "terminal.js",
        ]
        for v in expected_views:
            self.assertTrue(
                os.path.isfile(os.path.join(views_dir, v)),
                f"View file missing: {v}"
            )

    def test_index_html_includes_utils_js(self):
        """index.html must load utils.js before view scripts."""
        with open(os.path.join(STATIC_DIR, "index.html")) as f:
            content = f.read()
        utils_pos = content.find('utils.js')
        dashboard_pos = content.find('dashboard.js')
        self.assertGreater(utils_pos, -1, "utils.js not found in index.html")
        self.assertGreater(dashboard_pos, -1, "dashboard.js not found in index.html")
        self.assertLess(utils_pos, dashboard_pos, "utils.js must load before dashboard.js")

    def test_index_html_includes_column_resizer(self):
        """index.html must load column-resizer.js."""
        with open(os.path.join(STATIC_DIR, "index.html")) as f:
            content = f.read()
        self.assertIn('column-resizer.js', content)

    def test_index_html_includes_vendor_diff2html(self):
        """index.html must load vendor diff2html CSS and JS."""
        with open(os.path.join(STATIC_DIR, "index.html")) as f:
            content = f.read()
        self.assertIn('diff2html.min.css', content)
        self.assertIn('diff2html-ui.min.js', content)
        self.assertIn('highlight.min.js', content)
        self.assertIn('github-dark.min.css', content)

    def test_index_html_includes_commits_js(self):
        """index.html must load commits.js."""
        with open(os.path.join(STATIC_DIR, "index.html")) as f:
            content = f.read()
        self.assertIn('commits.js', content)

    def test_vendor_loads_before_utils(self):
        """Vendor scripts must load before utils.js."""
        with open(os.path.join(STATIC_DIR, "index.html")) as f:
            content = f.read()
        hljs_pos = content.find('highlight.min.js')
        utils_pos = content.find('utils.js')
        self.assertGreater(hljs_pos, -1)
        self.assertLess(hljs_pos, utils_pos, "highlight.min.js must load before utils.js")


# =============================================================================
# View Files: _esc() Removal Verification
# =============================================================================

class TestCommitShowRoute(unittest.TestCase):
    """Test the commit show route is registered."""

    @classmethod
    def setUpClass(cls):
        from bitbake_project.web import api  # noqa: F401

    def test_commit_show_route_exists(self):
        """Route /api/repos/{name}/commits/{hash}/show must be registered."""
        for method, pattern, handler in _routes:
            if "show" in pattern.pattern and "commits" in pattern.pattern:
                m = pattern.match("/api/repos/my-repo/commits/abc1234/show")
                self.assertIsNotNone(m)
                self.assertEqual(m.group(1), "my-repo")
                self.assertEqual(m.group(2), "abc1234")
                break
        else:
            self.fail("No commit show route found")

    def test_commit_show_route_method(self):
        """Commit show must be a GET route."""
        for method, pattern, handler in _routes:
            if "show" in pattern.pattern and "commits" in pattern.pattern:
                self.assertEqual(method, "GET")
                break


class TestEscMigration(unittest.TestCase):
    """Verify that view files use global esc() not this._esc()."""

    def _check_view(self, filename):
        filepath = os.path.join(STATIC_DIR, "js", "views", filename)
        with open(filepath) as f:
            content = f.read()
        # terminal.js never had _esc, skip it
        if filename == "terminal.js":
            return
        self.assertNotIn("this._esc(", content,
                         f"{filename} still uses this._esc() — should use global esc()")
        self.assertNotIn("_esc(s)", content,
                         f"{filename} still defines _esc method")

    def test_dashboard_no_local_esc(self):
        self._check_view("dashboard.js")

    def test_explore_no_local_esc(self):
        self._check_view("explore.js")

    def test_commits_no_local_esc(self):
        self._check_view("commits.js")

    def test_branch_no_local_esc(self):
        self._check_view("branch.js")

    def test_update_no_local_esc(self):
        self._check_view("update.js")

    def test_config_no_local_esc(self):
        self._check_view("config.js")

    def test_patches_no_local_esc(self):
        self._check_view("patches.js")

    def test_b4_no_local_esc(self):
        self._check_view("b4.js")

    def test_recipes_no_local_esc(self):
        self._check_view("recipes.js")

    def test_fragments_no_local_esc(self):
        self._check_view("fragments.js")

    def test_deps_no_local_esc(self):
        self._check_view("deps.js")

    def test_info_no_local_esc(self):
        self._check_view("info.js")

    def test_export_no_local_esc(self):
        self._check_view("export.js")


# =============================================================================
# Path Traversal Guard Tests
# =============================================================================

class TestPathTraversalGuard(unittest.TestCase):
    """Ensure static file serving prevents path traversal."""

    def test_traversal_blocked(self):
        """Paths like /../../../etc/passwd must resolve inside STATIC_DIR."""
        malicious = "/../../../etc/passwd"
        rel = malicious.lstrip("/")
        filepath = os.path.normpath(os.path.join(STATIC_DIR, rel))
        self.assertFalse(
            filepath.startswith(os.path.normpath(STATIC_DIR)),
            "Path traversal was not blocked"
        )

    def test_normal_path_allowed(self):
        """Normal paths resolve inside STATIC_DIR."""
        normal = "/style.css"
        rel = normal.lstrip("/")
        filepath = os.path.normpath(os.path.join(STATIC_DIR, rel))
        self.assertTrue(filepath.startswith(os.path.normpath(STATIC_DIR)))


# =============================================================================
# API Response Shape Tests
# =============================================================================

class TestAPIResponseShapes(unittest.TestCase):
    """Test API handler response shapes using mocked dependencies."""

    def _make_handler(self):
        """Create a mock handler with JSON helpers."""
        handler = MagicMock(spec=BitWebHandler)
        handler._query = {}
        handler._url_path = "/"

        captured = {}

        def send_json(data, status=200):
            captured['data'] = data
            captured['status'] = status

        def send_error_json(status, msg):
            captured['data'] = {"error": msg}
            captured['status'] = status

        def query_param(name, default=""):
            return handler._query.get(name, [default])[0] if isinstance(handler._query.get(name), list) else handler._query.get(name, default)

        handler._send_json = send_json
        handler._send_error_json = send_error_json
        handler._query_param = query_param
        handler.sse = MagicMock()

        return handler, captured

    @patch('bitbake_project.web.api.API' if False else 'bitbake_project.commands.projects.load_projects')
    @patch('bitbake_project.commands.projects.gather_all_project_summaries')
    def test_projects_response_shape(self, mock_summaries, mock_load):
        """GET /api/projects returns list of project dicts."""
        mock_load.return_value = {
            "/test/project": {"name": "test", "description": "A test project"}
        }
        mock_summaries.return_value = {
            "/test/project": {"repo_count": 3, "dirty_count": 0, "ahead": 1, "behind": 0, "branch": "main"}
        }

        from bitbake_project.web.api import api_projects
        handler, captured = self._make_handler()
        api_projects(handler)

        self.assertEqual(captured['status'], 200)
        data = captured['data']
        self.assertIsInstance(data, list)
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]['path'], '/test/project')
        self.assertEqual(data[0]['name'], 'test')
        self.assertIn('summary', data[0])
        self.assertEqual(data[0]['summary']['repo_count'], 3)

    @patch('bitbake_project.commands.projects.get_current_project')
    def test_current_project_response(self, mock_current):
        """GET /api/projects/current returns {path: ...}."""
        mock_current.return_value = "/test/project"

        from bitbake_project.web.api import api_projects_current
        handler, captured = self._make_handler()
        api_projects_current(handler)

        self.assertEqual(captured['status'], 200)
        self.assertEqual(captured['data']['path'], '/test/project')


# =============================================================================
# Path Resolution Tests (no-chdir web server)
# =============================================================================

class _FakeRepoSets:
    """Minimal stand-in for RepoSets returned by resolve_base_and_layers."""
    hidden = set()
    external = set()
    discovered = set()
    configured_layers = set()


class TestPathResolution(unittest.TestCase):
    """Test that API helpers resolve paths from project dir, not CWD.

    The bug: _resolve_current_repos() originally passed None to
    load_defaults() and resolve_base_and_layers(), which crashed with
    'stat: path should be string ... not NoneType'. Now it builds
    absolute paths from the project directory.
    """

    @patch('bitbake_project.commands.projects.get_current_project',
           return_value="/opt/bruce/poky")
    def test_get_defaults_file_with_project(self, _):
        """_get_defaults_file() returns absolute path under project dir."""
        from bitbake_project.web.api import _get_defaults_file
        self.assertEqual(_get_defaults_file(), "/opt/bruce/poky/.bit.defaults")

    @patch('bitbake_project.commands.projects.get_current_project',
           return_value=None)
    def test_get_defaults_file_no_project(self, _):
        """_get_defaults_file() falls back when no project is set."""
        from bitbake_project.web.api import _get_defaults_file
        self.assertEqual(_get_defaults_file(), ".bit.defaults")

    @patch('bitbake_project.commands.projects.get_current_project',
           return_value=None)
    def test_resolve_current_repos_no_project(self, _):
        """_resolve_current_repos() returns empty when no project."""
        from bitbake_project.web.api import _resolve_current_repos
        repos, defaults, repo_layers, configured_layers, discovered, external, hidden = _resolve_current_repos()
        self.assertEqual(repos, [])
        self.assertEqual(defaults, {})
        self.assertEqual(repo_layers, {})
        self.assertEqual(configured_layers, set())
        self.assertEqual(hidden, set())

    @patch('os.path.isdir', return_value=False)
    @patch('bitbake_project.commands.projects.get_current_project',
           return_value="/nonexistent/path")
    def test_resolve_current_repos_missing_dir(self, *_):
        """_resolve_current_repos() returns empty when project dir missing."""
        from bitbake_project.web.api import _resolve_current_repos
        repos, defaults, *_ = _resolve_current_repos()
        self.assertEqual(repos, [])

    def test_resolve_passes_absolute_defaults_path(self):
        """load_defaults() receives project-relative path, not None."""
        from bitbake_project.web.api import _resolve_current_repos

        with patch('bitbake_project.commands.projects.get_current_project',
                    return_value="/opt/bruce/poky"), \
             patch('os.path.isdir', return_value=True), \
             patch('os.path.exists',
                    side_effect=lambda p: p == "/opt/bruce/poky/conf/bblayers.conf"), \
             patch('bitbake_project.core.load_defaults',
                    return_value={}) as mock_ld, \
             patch('bitbake_project.commands.common.resolve_base_and_layers',
                    return_value=([("/opt/bruce/poky/meta", "/opt/bruce/poky")],
                                  _FakeRepoSets())):

            _resolve_current_repos()
            mock_ld.assert_called_once_with("/opt/bruce/poky/.bit.defaults")

    def test_resolve_passes_absolute_bblayers_path(self):
        """resolve_base_and_layers() receives absolute bblayers path, not None."""
        from bitbake_project.web.api import _resolve_current_repos

        with patch('bitbake_project.commands.projects.get_current_project',
                    return_value="/opt/bruce/poky"), \
             patch('os.path.isdir', return_value=True), \
             patch('os.path.exists',
                    side_effect=lambda p: p == "/opt/bruce/poky/conf/bblayers.conf"), \
             patch('bitbake_project.core.load_defaults', return_value={}), \
             patch('bitbake_project.commands.common.resolve_base_and_layers',
                    return_value=([("/opt/bruce/poky/meta", "/opt/bruce/poky")],
                                  _FakeRepoSets())) as mock_rbl:

            _resolve_current_repos()
            bblayers_arg = mock_rbl.call_args[0][0]
            self.assertEqual(bblayers_arg, "/opt/bruce/poky/conf/bblayers.conf")

    def test_resolve_passes_none_when_no_bblayers_conf(self):
        """When no bblayers.conf exists, passes None (not a bad path)."""
        from bitbake_project.web.api import _resolve_current_repos

        with patch('bitbake_project.commands.projects.get_current_project',
                    return_value="/opt/bruce/poky"), \
             patch('os.path.isdir', return_value=True), \
             patch('os.path.exists', return_value=False), \
             patch('bitbake_project.core.load_defaults', return_value={}), \
             patch('bitbake_project.commands.common.resolve_base_and_layers',
                    return_value=([], _FakeRepoSets())) as mock_rbl:

            _resolve_current_repos()
            bblayers_arg = mock_rbl.call_args[0][0]
            self.assertIsNone(bblayers_arg)


# =============================================================================
# Service Function Extraction Tests
# =============================================================================

class TestServiceFunctions(unittest.TestCase):
    """Test that extracted service functions exist and are importable."""

    def test_gather_repo_status_importable(self):
        from bitbake_project.commands.explore import gather_repo_status
        self.assertTrue(callable(gather_repo_status))

    def test_gather_all_project_summaries_importable(self):
        from bitbake_project.commands.projects import gather_all_project_summaries
        self.assertTrue(callable(gather_all_project_summaries))

    def test_gather_repo_status_in_commands_init(self):
        from bitbake_project.commands import gather_repo_status
        self.assertTrue(callable(gather_repo_status))

    def test_gather_all_project_summaries_in_commands_init(self):
        from bitbake_project.commands import gather_all_project_summaries
        self.assertTrue(callable(gather_all_project_summaries))

    @patch('bitbake_project.commands.explore.current_branch')
    @patch('bitbake_project.commands.explore.repo_is_clean')
    @patch('bitbake_project.commands.explore.repo_display_name')
    @patch('bitbake_project.commands.explore.subprocess')
    def test_gather_repo_status_returns_dict(self, mock_sub, mock_display, mock_clean, mock_branch):
        """gather_repo_status returns expected dict shape."""
        mock_branch.return_value = "main"
        mock_clean.return_value = True
        mock_display.return_value = "test-repo"
        mock_sub.check_output.return_value = "abc123 Test commit\n"

        from bitbake_project.commands.explore import gather_repo_status
        result = gather_repo_status("/fake/repo", {})

        self.assertIsInstance(result, dict)
        self.assertIn("display_name", result)
        self.assertIn("branch", result)
        self.assertIn("is_dirty", result)
        self.assertIn("local_count", result)
        self.assertIn("upstream_count", result)
        self.assertIn("default_action", result)
        self.assertEqual(result["branch"], "main")
        self.assertEqual(result["is_dirty"], False)
        self.assertEqual(result["default_action"], "rebase")

    @patch('bitbake_project.commands.projects._get_dashboard_summary')
    @patch('bitbake_project.commands.projects._project_key_valid')
    def test_gather_all_project_summaries_returns_dict(self, mock_valid, mock_summary):
        """gather_all_project_summaries returns {path: summary}."""
        mock_valid.return_value = True
        mock_summary.return_value = {"repo_count": 2, "dirty_count": 0, "ahead": 0, "behind": 0, "branch": "main"}

        from bitbake_project.commands.projects import gather_all_project_summaries
        result = gather_all_project_summaries({"/test": {"name": "test"}})

        self.assertIsInstance(result, dict)
        self.assertIn("/test", result)
        self.assertEqual(result["/test"]["repo_count"], 2)


# =============================================================================
# Web Server Launch Helper Tests
# =============================================================================

class TestWebServerLaunch(unittest.TestCase):
    """Test the _launch_web_server() helper function."""

    def test_launch_web_server_importable(self):
        from bitbake_project.commands.projects import _launch_web_server
        self.assertTrue(callable(_launch_web_server))

    def test_launch_creates_daemon_thread(self):
        """_launch_web_server starts a daemon thread on a free port."""
        import bitbake_project.commands.projects as proj_mod
        from bitbake_project.commands.projects import _launch_web_server

        # Reset thread state
        proj_mod._web_server_thread = None

        # Use a high port unlikely to conflict
        msg = _launch_web_server(port=18999, host="127.0.0.1")

        self.assertIsNotNone(proj_mod._web_server_thread)
        self.assertTrue(proj_mod._web_server_thread.daemon)
        self.assertIn("started", msg)

        # Cleanup — can't easily stop serve_forever, but daemon thread
        # will die when tests end
        proj_mod._web_server_thread = None

    def test_launch_reuses_running_thread(self):
        """If thread is alive, returns 'already running' message."""
        import bitbake_project.commands.projects as proj_mod
        from bitbake_project.commands.projects import _launch_web_server

        # Create a fake alive thread
        fake_thread = MagicMock()
        fake_thread.is_alive.return_value = True
        proj_mod._web_server_thread = fake_thread

        msg = _launch_web_server(port=8123, host="127.0.0.1")

        self.assertIn("already running", msg)

        # Cleanup
        proj_mod._web_server_thread = None

    def test_launch_returns_error_on_port_conflict(self):
        """If port is in use, returns error message."""
        import socket
        import bitbake_project.commands.projects as proj_mod
        from bitbake_project.commands.projects import _launch_web_server

        proj_mod._web_server_thread = None

        # Occupy a port
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", 18998))
        sock.listen(1)
        try:
            msg = _launch_web_server(port=18998, host="127.0.0.1")
            self.assertIn("already in use", msg)
        finally:
            sock.close()


# =============================================================================
# CLI Integration Tests
# =============================================================================

class TestCLIIntegration(unittest.TestCase):
    """Test CLI integration for the serve command."""

    def test_serve_in_generic_commands(self):
        from bitbake_project.cli import GENERIC_COMMANDS
        cmd_names = [c[0] for c in GENERIC_COMMANDS]
        self.assertIn("serve", cmd_names)

    def test_serve_in_generic_categories(self):
        from bitbake_project.cli import GENERIC_CATEGORIES
        config_cmds = GENERIC_CATEGORIES["config"][1]
        self.assertIn("serve", config_cmds)

    def test_run_serve_importable(self):
        from bitbake_project.commands import run_serve
        self.assertTrue(callable(run_serve))


# =============================================================================
# HTTP Server Integration Test (lightweight)
# =============================================================================

class TestHTTPServerIntegration(unittest.TestCase):
    """Integration test: start server, make requests, verify responses."""

    @classmethod
    def setUpClass(cls):
        from http.server import ThreadingHTTPServer
        from bitbake_project.web.server import BitWebHandler
        from bitbake_project.web.sse import SSEManager
        from bitbake_project.web import api, api_commands  # noqa: F401

        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), BitWebHandler)
        cls.server.sse_manager = SSEManager()
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def _get(self, path):
        conn = HTTPConnection("127.0.0.1", self.port, timeout=5)
        conn.request("GET", path)
        resp = conn.getresponse()
        body = resp.read()
        conn.close()
        return resp.status, body

    def _post(self, path, data=None):
        conn = HTTPConnection("127.0.0.1", self.port, timeout=5)
        body = json.dumps(data or {}).encode()
        conn.request("POST", path, body=body, headers={"Content-Type": "application/json"})
        resp = conn.getresponse()
        resp_body = resp.read()
        conn.close()
        return resp.status, resp_body

    def test_index_html_served(self):
        status, body = self._get("/")
        self.assertEqual(status, 200)
        self.assertIn(b"bit", body)
        self.assertIn(b"<html", body)

    def test_style_css_served(self):
        status, body = self._get("/style.css")
        self.assertEqual(status, 200)
        self.assertIn(b"--bg-primary", body)

    def test_js_served(self):
        status, body = self._get("/js/app.js")
        self.assertEqual(status, 200)
        self.assertIn(b"App", body)

    def test_utils_js_served(self):
        """New utils.js should be served."""
        status, body = self._get("/js/utils.js")
        self.assertEqual(status, 200)
        self.assertIn(b"esc", body)
        self.assertIn(b"modal", body)

    def test_column_resizer_js_served(self):
        """New column-resizer.js should be served."""
        status, body = self._get("/js/column-resizer.js")
        self.assertEqual(status, 200)
        self.assertIn(b"initColumnResizer", body)

    def test_404_for_missing_static(self):
        status, body = self._get("/nonexistent.xyz")
        self.assertEqual(status, 404)

    def test_path_traversal_blocked(self):
        status, body = self._get("/../../../etc/passwd")
        self.assertIn(status, [403, 404])

    def test_api_projects_current(self):
        status, body = self._get("/api/projects/current")
        self.assertEqual(status, 200)
        data = json.loads(body)
        self.assertIn("path", data)

    def test_options_cors(self):
        conn = HTTPConnection("127.0.0.1", self.port, timeout=5)
        conn.request("OPTIONS", "/api/projects")
        resp = conn.getresponse()
        resp.read()
        conn.close()
        self.assertEqual(resp.status, 200)
        self.assertEqual(resp.getheader("Access-Control-Allow-Origin"), "*")

    def test_switch_route_removed(self):
        """Project activation is TUI-only — switch endpoint must not exist."""
        status, body = self._post("/api/projects/switch", {})
        self.assertEqual(status, 404)

    def test_vendor_diff2html_css_served(self):
        """Vendor diff2html.min.css should be served."""
        status, body = self._get("/vendor/diff2html.min.css")
        self.assertEqual(status, 200)
        self.assertGreater(len(body), 1000)

    def test_vendor_diff2html_js_served(self):
        """Vendor diff2html-ui.min.js should be served."""
        status, body = self._get("/vendor/diff2html-ui.min.js")
        self.assertEqual(status, 200)
        self.assertGreater(len(body), 1000)

    def test_vendor_highlight_js_served(self):
        """Vendor highlight.min.js should be served."""
        status, body = self._get("/vendor/highlight.min.js")
        self.assertEqual(status, 200)
        self.assertGreater(len(body), 1000)

    def test_commits_js_served(self):
        """Commits view JS should be served."""
        status, body = self._get("/js/views/commits.js")
        self.assertEqual(status, 200)
        self.assertIn(b"CommitsView", body)


# =============================================================================
# Utils.js Content Verification Tests
# =============================================================================

class TestUtilsJSContent(unittest.TestCase):
    """Verify utils.js contains all expected functions."""

    @classmethod
    def setUpClass(cls):
        utils_path = os.path.join(STATIC_DIR, "js", "utils.js")
        with open(utils_path) as f:
            cls.content = f.read()

    def test_has_esc_function(self):
        self.assertIn("function esc(", self.content)

    def test_has_modal_function(self):
        self.assertIn("function modal(", self.content)

    def test_has_confirm_modal(self):
        self.assertIn("function confirmModal(", self.content)

    def test_has_prompt_modal(self):
        self.assertIn("function promptModal(", self.content)

    def test_has_format_diff(self):
        self.assertIn("function formatDiff(", self.content)

    def test_has_debounce(self):
        self.assertIn("function debounce(", self.content)

    def test_has_relative_time(self):
        self.assertIn("function relativeTime(", self.content)

    def test_has_save_preference(self):
        self.assertIn("function savePreference(", self.content)

    def test_has_load_preference(self):
        self.assertIn("function loadPreference(", self.content)

    def test_iife_pattern(self):
        self.assertIn("(function()", self.content)
        self.assertIn("'use strict'", self.content)

    def test_has_render_diff(self):
        self.assertIn("function renderDiff(", self.content)

    def test_exposes_globals(self):
        self.assertIn("window.esc = esc", self.content)
        self.assertIn("window.modal = modal", self.content)
        self.assertIn("window.formatDiff = formatDiff", self.content)
        self.assertIn("window.renderDiff = renderDiff", self.content)


# =============================================================================
# Dashboard Keybinding Tests
# =============================================================================

class TestCommitsViewContent(unittest.TestCase):
    """Verify commits.js and app.js registration."""

    def test_commits_view_defines_object(self):
        """commits.js must define CommitsView."""
        path = os.path.join(STATIC_DIR, "js", "views", "commits.js")
        with open(path) as f:
            content = f.read()
        self.assertIn("CommitsView", content)
        self.assertIn("render(container", content)
        self.assertIn("handleKeyboard", content)

    def test_commits_view_registered_in_app(self):
        """app.js must register commits view."""
        path = os.path.join(STATIC_DIR, "js", "app.js")
        with open(path) as f:
            content = f.read()
        self.assertIn("commits: CommitsView", content)

    def test_explore_navigates_to_commits(self):
        """explore.js must navigate to commits view on click."""
        path = os.path.join(STATIC_DIR, "js", "views", "explore.js")
        with open(path) as f:
            content = f.read()
        self.assertIn("selectedRepo", content)
        self.assertIn("'commits'", content)

    def test_api_js_has_get_commit_show(self):
        """api.js must have getCommitShow method."""
        path = os.path.join(STATIC_DIR, "js", "api.js")
        with open(path) as f:
            content = f.read()
        self.assertIn("getCommitShow", content)

    def test_api_js_no_switch_project(self):
        """api.js must not have switchProject — activation is TUI-only."""
        path = os.path.join(STATIC_DIR, "js", "api.js")
        with open(path) as f:
            content = f.read()
        self.assertNotIn("switchProject", content)

    def test_dashboard_no_switch_project(self):
        """dashboard.js must not call switchProject."""
        path = os.path.join(STATIC_DIR, "js", "views", "dashboard.js")
        with open(path) as f:
            content = f.read()
        self.assertNotIn("switchProject", content)

    def test_dashboard_has_activate_action(self):
        """dashboard.js must have an activate action."""
        path = os.path.join(STATIC_DIR, "js", "views", "dashboard.js")
        with open(path) as f:
            content = f.read()
        self.assertIn("data-act=\"activate\"", content)
        self.assertIn("_activateProject", content)

    def test_api_js_has_project_param_support(self):
        """api.js must support ?project= parameter via _projUrl."""
        path = os.path.join(STATIC_DIR, "js", "api.js")
        with open(path) as f:
            content = f.read()
        self.assertIn("_projUrl", content)
        self.assertIn("project=", content)


class TestDashboardWebKeybinding(unittest.TestCase):
    """Verify the 'w' keybinding is registered in the TUI dashboard."""

    def test_webserver_keybinding_in_projects(self):
        """The WEBSERVER action must appear in projects.py."""
        import inspect
        from bitbake_project.commands.projects import fzf_dashboard
        source = inspect.getsource(fzf_dashboard)
        self.assertIn("WEBSERVER", source)

    def test_webserver_header_hint(self):
        """The header line must include w=web."""
        import inspect
        from bitbake_project.commands.projects import fzf_dashboard
        source = inspect.getsource(fzf_dashboard)
        self.assertIn("w=web", source)


# =============================================================================
# Rename Project API Tests
# =============================================================================

class TestRenameProjectAPI(unittest.TestCase):
    """Test POST /api/projects/rename endpoint."""

    def _make_handler(self):
        handler = MagicMock(spec=BitWebHandler)
        handler._query = {}
        captured = {}

        def send_json(data, status=200):
            captured['data'] = data
            captured['status'] = status

        def send_error_json(status, msg):
            captured['data'] = {"error": msg}
            captured['status'] = status

        handler._send_json = send_json
        handler._send_error_json = send_error_json
        handler.sse = MagicMock()
        return handler, captured

    @patch('bitbake_project.commands.projects.save_projects')
    @patch('bitbake_project.commands.projects.load_projects')
    def test_rename_happy_path(self, mock_load, mock_save):
        """Rename should update project name and save."""
        mock_load.return_value = {
            "/test/proj": {"name": "old-name", "description": ""}
        }

        from bitbake_project.web.api import api_projects_rename
        handler, captured = self._make_handler()
        handler._read_json = MagicMock(return_value={"path": "/test/proj", "name": "new-name"})
        api_projects_rename(handler)

        self.assertEqual(captured['status'], 200)
        self.assertTrue(captured['data']['ok'])
        mock_save.assert_called_once()
        saved = mock_save.call_args[0][0]
        self.assertEqual(saved["/test/proj"]["name"], "new-name")

    def test_rename_missing_fields(self):
        """Rename with missing path or name should return 400."""
        from bitbake_project.web.api import api_projects_rename
        handler, captured = self._make_handler()
        handler._read_json = MagicMock(return_value={"path": "/test/proj"})
        api_projects_rename(handler)
        self.assertEqual(captured['status'], 400)

    @patch('bitbake_project.commands.projects.load_projects')
    def test_rename_project_not_found(self, mock_load):
        """Rename nonexistent project should return 404."""
        mock_load.return_value = {}

        from bitbake_project.web.api import api_projects_rename
        handler, captured = self._make_handler()
        handler._read_json = MagicMock(return_value={"path": "/no/such", "name": "x"})
        api_projects_rename(handler)
        self.assertEqual(captured['status'], 404)

    def test_rename_invalid_json(self):
        """Rename with invalid JSON should return 400."""
        from bitbake_project.web.api import api_projects_rename
        handler, captured = self._make_handler()
        handler._read_json = MagicMock(return_value=None)
        api_projects_rename(handler)
        self.assertEqual(captured['status'], 400)


# =============================================================================
# Union Branches API Tests
# =============================================================================

class TestUnionBranchesAPI(unittest.TestCase):
    """Test GET /api/repos/branches/union endpoint."""

    def _make_handler(self):
        handler = MagicMock(spec=BitWebHandler)
        handler._query = {}
        captured = {}

        def send_json(data, status=200):
            captured['data'] = data
            captured['status'] = status

        def query_param(name, default=""):
            return handler._query.get(name, default)

        handler._send_json = send_json
        handler._query_param = query_param
        return handler, captured

    @patch('bitbake_project.web.api._ssh_query', return_value=None)
    @patch('bitbake_project.commands.query._resolve_repos')
    @patch('bitbake_project.commands.branch.collect_union_branches')
    def test_union_branches_response(self, mock_collect, mock_resolve, _ssh):
        """Union branches returns list with name, count, total."""
        mock_resolve.return_value = (["/repo1", "/repo2"], {}, {}, set(), set(), set())
        mock_collect.return_value = [("main", 2), ("dev", 1)]

        from bitbake_project.web.api import api_repos_branches_union
        handler, captured = self._make_handler()
        api_repos_branches_union(handler)

        self.assertEqual(captured['status'], 200)
        data = captured['data']
        self.assertEqual(len(data), 2)
        self.assertEqual(data[0]['name'], 'main')
        self.assertEqual(data[0]['count'], 2)
        self.assertEqual(data[0]['total'], 2)
        self.assertEqual(data[1]['name'], 'dev')
        self.assertEqual(data[1]['count'], 1)


# =============================================================================
# Branch-All API Tests
# =============================================================================

class TestBranchAllAPI(unittest.TestCase):
    """Test POST /api/repos/branch-all endpoint."""

    def _make_handler(self):
        handler = MagicMock(spec=BitWebHandler)
        handler._query = {}
        captured = {}

        def send_json(data, status=200):
            captured['data'] = data
            captured['status'] = status

        def send_error_json(status, msg):
            captured['data'] = {"error": msg}
            captured['status'] = status

        def query_param(name, default=""):
            return handler._query.get(name, default)

        handler._send_json = send_json
        handler._send_error_json = send_error_json
        handler._query_param = query_param
        handler.sse = MagicMock()
        return handler, captured

    @patch('bitbake_project.web.api._ssh_query', return_value=None)
    @patch('bitbake_project.commands.query._resolve_repos')
    @patch('bitbake_project.core.current_branch')
    @patch('bitbake_project.commands.branch.checkout_branch')
    def test_branch_all_happy_path(self, mock_checkout, mock_cur, mock_resolve, _ssh):
        """Branch-all switches repos and returns results."""
        mock_resolve.return_value = (["/repo1", "/repo2"], {}, {}, set(), set(), set())
        mock_cur.side_effect = ["main", "dev"]
        mock_checkout.return_value = (True, "switched to main")

        from bitbake_project.web.api import api_repos_branch_all
        handler, captured = self._make_handler()
        handler._read_json = MagicMock(return_value={"branch": "main"})
        api_repos_branch_all(handler)

        self.assertEqual(captured['status'], 200)
        results = captured['data']['results']
        self.assertEqual(len(results), 2)
        # First repo already on main
        self.assertEqual(results[0]['status'], 'already')
        # Second repo switched
        self.assertEqual(results[1]['status'], 'ok')

    def test_branch_all_missing_branch(self):
        """Branch-all without branch field returns 400."""
        from bitbake_project.web.api import api_repos_branch_all
        handler, captured = self._make_handler()
        handler._read_json = MagicMock(return_value={"branch": ""})
        api_repos_branch_all(handler)
        self.assertEqual(captured['status'], 400)


# =============================================================================
# Route Registration for New Endpoints
# =============================================================================

class TestNewRouteRegistration(unittest.TestCase):
    """Verify new API routes are registered."""

    @classmethod
    def setUpClass(cls):
        from bitbake_project.web import api  # noqa: F401

    def test_rename_route_exists(self):
        """POST /api/projects/rename must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern == "^/api/projects/rename$":
                self.assertEqual(method, "POST")
                return
        self.fail("Rename route not found")

    def test_union_branches_route_exists(self):
        """GET /api/repos/branches/union must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern == "^/api/repos/branches/union$":
                self.assertEqual(method, "GET")
                return
        self.fail("Union branches route not found")

    def test_branch_all_route_exists(self):
        """POST /api/repos/branch-all must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern == "^/api/repos/branch-all$":
                self.assertEqual(method, "POST")
                return
        self.fail("Branch-all route not found")


# =============================================================================
# Dashboard Feature Parity Tests
# =============================================================================

class TestDashboardFeatureParity(unittest.TestCase):
    """Verify dashboard.js has rename, refresh, search features."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "views", "dashboard.js")
        with open(path) as f:
            cls.content = f.read()

    def test_has_rename_action(self):
        """Dashboard submenu must include rename action."""
        self.assertIn('data-act="rename"', self.content)

    def test_has_refresh_action(self):
        """Dashboard submenu must include refresh action."""
        self.assertIn('data-act="refresh"', self.content)

    def test_has_search_bar(self):
        """Dashboard must have search bar with id dash-search."""
        self.assertIn('dash-search', self.content)

    def test_has_rename_keyboard_shortcut(self):
        """Dashboard must handle 'n' key for rename."""
        self.assertIn("'n'", self.content)
        self.assertIn('_renameProject', self.content)

    def test_has_refresh_keyboard_shortcut(self):
        """Dashboard must handle 'R' key for refresh."""
        self.assertIn("'R'", self.content)
        self.assertIn('_refreshRow', self.content)

    def test_has_config_keyboard_shortcut(self):
        """Dashboard must handle 'c' key for config."""
        self.assertIn("'c'", self.content)

    def test_has_search_keyboard_shortcut(self):
        """Dashboard must handle '/' key to focus search."""
        self.assertIn("'/'", self.content)

    def test_has_filter_logic(self):
        """Dashboard must have _applyFilter method."""
        self.assertIn('_applyFilter', self.content)

    def test_search_count_display(self):
        """Dashboard must show filter result count."""
        self.assertIn('dash-search-count', self.content)


# =============================================================================
# Branch View Redesign Tests
# =============================================================================

class TestBranchViewRedesign(unittest.TestCase):
    """Verify branch.js uses expand/collapse tree pattern."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "views", "branch.js")
        with open(path) as f:
            cls.content = f.read()

    def test_uses_expand_collapse(self):
        """Branch view must use expand/collapse tree, not dropdowns."""
        self.assertIn('_expandedRepos', self.content)
        self.assertIn('_toggleExpand', self.content)
        self.assertNotIn('form-select', self.content)

    def test_has_switch_all(self):
        """Branch view must have Switch All button."""
        self.assertIn('Switch All', self.content)
        self.assertIn('branch-switch-all', self.content)

    def test_has_data_table(self):
        """Branch view must use data-table layout."""
        self.assertIn('data-table', self.content)
        self.assertIn('branch-table', self.content)

    def test_has_project_context(self):
        """Branch view must use _project() helper."""
        self.assertIn('_project()', self.content)
        self.assertIn('selectedProject', self.content)

    def test_has_keyboard_nav(self):
        """Branch view must have handleKeyboard method."""
        self.assertIn('handleKeyboard', self.content)

    def test_has_switch_all_modal(self):
        """Branch view must have _switchAllModal method."""
        self.assertIn('_switchAllModal', self.content)

    def test_uses_union_branches_api(self):
        """Branch view must call getUnionBranches."""
        self.assertIn('getUnionBranches', self.content)

    def test_uses_branch_all_api(self):
        """Branch view must call branchAll."""
        self.assertIn('branchAll', self.content)


# =============================================================================
# Update View Project Context Tests
# =============================================================================

class TestUpdateViewProjectContext(unittest.TestCase):
    """Verify update.js passes project context to API calls."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "views", "update.js")
        with open(path) as f:
            cls.content = f.read()

    def test_has_project_helper(self):
        """Update view must use _project() helper."""
        self.assertIn('_project()', self.content)

    def test_passes_project_to_get_repos(self):
        """Update view must pass project to getRepos."""
        self.assertIn('getRepos(this._project())', self.content)

    def test_passes_project_to_fetch(self):
        """Update view must pass project to fetchRepo."""
        self.assertIn('this._project()', self.content)
        self.assertIn('fetchRepo', self.content)

    def test_passes_project_to_update(self):
        """Update view must pass project to updateRepo."""
        self.assertIn('updateRepo', self.content)


# =============================================================================
# API.js New Methods Tests
# =============================================================================

class TestApiJsNewMethods(unittest.TestCase):
    """Verify api.js has new methods for rename, union branches, branch-all."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "api.js")
        with open(path) as f:
            cls.content = f.read()

    def test_has_rename_project(self):
        self.assertIn('renameProject', self.content)

    def test_has_get_union_branches(self):
        self.assertIn('getUnionBranches', self.content)

    def test_has_branch_all(self):
        self.assertIn('branchAll', self.content)


# =============================================================================
# Font Inheritance CSS Tests
# =============================================================================

class TestFontInheritanceCSS(unittest.TestCase):
    """Verify font-family inherit rule in style.css."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "style.css")
        with open(path) as f:
            cls.content = f.read()

    def test_has_font_inherit_rule(self):
        """style.css must have font-family: inherit for form controls."""
        self.assertIn('font-family: inherit', self.content)

    def test_inherit_applies_to_select(self):
        """The inherit rule must cover select elements."""
        # Find the rule containing both 'select' and 'font-family: inherit'
        self.assertRegex(self.content, r'select.*\{[^}]*font-family:\s*inherit')


class TestKeybindingHelp(unittest.TestCase):
    """Test keybinding help sidebar and expand/collapse patterns."""

    @classmethod
    def setUpClass(cls):
        cls.html = open(os.path.join(STATIC_DIR, "index.html")).read()
        cls.css = open(os.path.join(STATIC_DIR, "style.css")).read()
        cls.app_js = open(os.path.join(STATIC_DIR, "js", "app.js")).read()
        cls.dashboard_js = open(os.path.join(STATIC_DIR, "js", "views", "dashboard.js")).read()
        cls.explore_js = open(os.path.join(STATIC_DIR, "js", "views", "explore.js")).read()
        cls.branch_js = open(os.path.join(STATIC_DIR, "js", "views", "branch.js")).read()
        cls.commits_js = open(os.path.join(STATIC_DIR, "js", "views", "commits.js")).read()

    # --- Part 1: Keys section in sidebar ---

    def test_keys_section_in_html(self):
        """index.html has keys-section and keys-content."""
        self.assertIn('id="keys-section"', self.html)
        self.assertIn('id="keys-content"', self.html)

    def test_keys_section_is_nav_section(self):
        """Keys section uses collapsible nav-section pattern."""
        self.assertIn('data-section="keys"', self.html)

    def test_css_has_keys_row(self):
        """style.css defines .keys-row class."""
        self.assertIn('.keys-row', self.css)

    def test_css_has_keys_key(self):
        """style.css defines .keys-key class."""
        self.assertIn('.keys-key', self.css)

    def test_css_has_keys_desc(self):
        """style.css defines .keys-desc class."""
        self.assertIn('.keys-desc', self.css)

    def test_css_has_keys_sep(self):
        """style.css defines .keys-sep class."""
        self.assertIn('.keys-sep', self.css)

    def test_app_js_has_update_keys_panel(self):
        """app.js defines updateKeysPanel."""
        self.assertIn('updateKeysPanel', self.app_js)

    def test_app_js_exposes_update_keys_panel(self):
        """app.js exposes updateKeysPanel on window.App."""
        self.assertRegex(self.app_js, r'updateKeysPanel')

    def test_app_js_question_mark_toggle(self):
        """app.js handles ? key to toggle keys section."""
        self.assertIn("e.key === '?'", self.app_js)

    # --- Part 2: View keyBindings ---

    def test_dashboard_has_keybindings(self):
        """dashboard.js defines keyBindings array."""
        self.assertIn('keyBindings', self.dashboard_js)

    def test_explore_has_keybindings(self):
        """explore.js defines keyBindings array."""
        self.assertIn('keyBindings', self.explore_js)

    def test_branch_has_keybindings(self):
        """branch.js defines keyBindings array."""
        self.assertIn('keyBindings', self.branch_js)

    def test_commits_has_keybindings(self):
        """commits.js defines keyBindings array."""
        self.assertIn('keyBindings', self.commits_js)

    # --- Part 3: Branch expand/collapse ---

    def test_branch_has_expanded_repos(self):
        """branch.js uses _expandedRepos for expand state."""
        self.assertIn('_expandedRepos', self.branch_js)

    def test_branch_has_tree_connectors(self):
        """branch.js uses CSS tree-line class for branch children."""
        self.assertIn('tree-line', self.branch_js)
        self.assertIn('tree-last', self.branch_js)

    def test_branch_no_form_select(self):
        """branch.js no longer uses form-select dropdowns."""
        self.assertNotIn('form-select', self.branch_js)

    def test_branch_handles_backslash(self):
        """branch.js handles backslash key for expand/collapse all."""
        self.assertIn("e.key === '\\\\'", self.branch_js)

    def test_branch_has_checkout(self):
        """branch.js has _checkoutBranch method."""
        self.assertIn('_checkoutBranch', self.branch_js)

    def test_branch_has_switch_all(self):
        """branch.js retains _switchAllModal."""
        self.assertIn('_switchAllModal', self.branch_js)

    # --- Part 4: Explore expand/collapse ---

    def test_explore_has_expanded_repos(self):
        """explore.js uses _expandedRepos for layer expand state."""
        self.assertIn('_expandedRepos', self.explore_js)

    def test_explore_has_expand_marker(self):
        """explore.js renders expand marker for repos with layers (shared with dashboard)."""
        self.assertIn('dash-row-toggle', self.explore_js)

    def test_explore_handles_backslash(self):
        """explore.js handles backslash key."""
        self.assertIn("e.key === '\\\\'", self.explore_js)

    def test_explore_filters_redundant_layers(self):
        """explore.js filters layers where basename matches repo name."""
        self.assertIn('base !== name', self.explore_js)

    def test_explore_has_action_buttons(self):
        """explore.js has per-row action icon buttons."""
        self.assertIn('explore-actions', self.explore_js)

    def test_explore_handles_r_key(self):
        """explore.js handles 'r' key for fetch repo."""
        self.assertIn("e.key === 'r'", self.explore_js)
        self.assertIn('fetchRepo', self.explore_js)

    def test_explore_handles_u_key(self):
        """explore.js handles 'u' key for update repo."""
        self.assertIn("e.key === 'u'", self.explore_js)
        self.assertIn('updateRepo', self.explore_js)

    def test_explore_handles_B_key(self):
        """explore.js handles 'B' key for branch all."""
        self.assertIn("e.key === 'B'", self.explore_js)

    def test_explore_has_switch_all_modal(self):
        """explore.js has _switchAllModal method."""
        self.assertIn('_switchAllModal', self.explore_js)

    def test_explore_handles_b_key(self):
        """explore.js handles 'b' key for branches view."""
        self.assertIn("e.key === 'b'", self.explore_js)

    def test_css_explore_actions(self):
        """style.css has .explore-actions rules for per-row action icon bar."""
        self.assertIn('.explore-actions', self.css)

    # --- Part 5: CSS for tree patterns ---

    def test_css_has_tree_line(self):
        """style.css defines td.tree-line for CSS-drawn tree connectors."""
        self.assertIn('td.tree-line', self.css)

    def test_css_has_branch_child_row(self):
        """style.css defines .branch-child-row."""
        self.assertIn('.branch-child-row', self.css)

    def test_css_has_explore_layer_row(self):
        """style.css defines .explore-layer-row."""
        self.assertIn('.explore-layer-row', self.css)

    def test_css_has_explore_expand_marker(self):
        """style.css defines .explore-expand-marker."""
        self.assertIn('.explore-expand-marker', self.css)

    # --- Part 6: Clickable action keys ---

    def test_app_js_has_action_key_attribute(self):
        """app.js renders data-action-key for clickable sidebar keys."""
        self.assertIn('data-action-key', self.app_js)

    def test_css_has_keys_row_action(self):
        """style.css defines .keys-row-action for hover styling."""
        self.assertIn('.keys-row-action', self.css)

    # --- Part 7: Message bar ---

    def test_html_has_message_bar(self):
        """index.html contains message-bar markup."""
        self.assertIn('id="message-bar"', self.html)

    def test_css_has_message_bar(self):
        """style.css contains .message-bar styles."""
        self.assertIn('.message-bar', self.css)

    def test_app_js_has_show_message(self):
        """app.js defines showMessage function."""
        self.assertIn('showMessage', self.app_js)

    def test_dashboard_warns_no_selection(self):
        """dashboard.js shows message when no row selected."""
        self.assertIn("Select a project first", self.dashboard_js)

    def test_explore_warns_no_selection(self):
        """explore.js shows message when no row selected."""
        self.assertIn("Select a repo first", self.explore_js)

    # --- Part 8: Drag-and-drop reordering ---

    def test_html_has_sortable_vendor(self):
        """index.html includes SortableJS vendor script."""
        self.assertIn('Sortable.min.js', self.html)

    def test_html_has_sidebar_sections_container(self):
        """index.html wraps nav-sections in sidebar-sections container."""
        self.assertIn('id="sidebar-sections"', self.html)

    def test_html_has_drag_handles(self):
        """index.html has drag-handle spans in sidebar section titles."""
        self.assertIn('class="drag-handle"', self.html)

    def test_css_has_drag_handle(self):
        """style.css defines .drag-handle class."""
        self.assertIn('.drag-handle', self.css)

    def test_css_has_nav_section_ghost(self):
        """style.css defines .nav-section-ghost for sidebar drag."""
        self.assertIn('.nav-section-ghost', self.css)

    def test_css_has_dash_row_ghost(self):
        """style.css defines .dash-row-ghost for dashboard drag."""
        self.assertIn('.dash-row-ghost', self.css)

    def test_sortable_js_exists(self):
        """sortable.js exists in static/js directory."""
        path = os.path.join(STATIC_DIR, "js", "sortable.js")
        self.assertTrue(os.path.isfile(path))

    def test_sortable_js_has_sidebar_init(self):
        """sortable.js initializes sidebar sortable."""
        js = open(os.path.join(STATIC_DIR, "js", "sortable.js")).read()
        self.assertIn('initSidebarSortable', js)

    def test_sortable_js_has_dashboard_init(self):
        """sortable.js exposes initDashboardSortable."""
        js = open(os.path.join(STATIC_DIR, "js", "sortable.js")).read()
        self.assertIn('initDashboardSortable', js)

    def test_dashboard_calls_sortable(self):
        """dashboard.js calls initDashboardSortable after rendering."""
        self.assertIn('initDashboardSortable', self.dashboard_js)

    def test_dashboard_has_drag_handles(self):
        """dashboard.js renders drag-handle in project rows."""
        self.assertIn('drag-handle', self.dashboard_js)

    def test_dashboard_uses_per_group_tbody(self):
        """dashboard.js renders separate tbody per group."""
        self.assertIn('data-group=', self.dashboard_js)
        self.assertIn('<tbody', self.dashboard_js)

    def test_css_has_dash_group_ghost(self):
        """style.css defines .dash-group-ghost for group drag."""
        self.assertIn('.dash-group-ghost', self.css)

    def test_sortable_js_has_reset(self):
        """sortable.js exposes reset functions."""
        js = open(os.path.join(STATIC_DIR, "js", "sortable.js")).read()
        self.assertIn('resetDashboardOrder', js)
        self.assertIn('resetSidebarOrder', js)

    def test_dashboard_has_reset_button(self):
        """dashboard.js renders a Reset Order button."""
        self.assertIn('dash-reset-order', self.dashboard_js)

    def test_html_has_sidebar_reset_button(self):
        """index.html has sidebar reset order button."""
        self.assertIn('sidebar-reset-order', self.html)

    def test_app_js_no_keyboard_event_constructor(self):
        """app.js click handler uses plain object, not KeyboardEvent."""
        self.assertNotIn('new KeyboardEvent', self.app_js)


# =============================================================================
# Dashboard c/x/u Fallback Navigation Tests
# =============================================================================

class TestDashboardNavFallback(unittest.TestCase):
    """Verify c/x/u keys fall back to currentProject, R/n require selection."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "views", "dashboard.js")
        with open(path) as f:
            cls.content = f.read()

    def test_c_key_uses_current_project_fallback(self):
        """'c' key must fall back to App.state.currentProject."""
        self.assertIn('App.state.currentProject', self.content)
        # Should NOT show 'Select a project first' for c key
        # The c key block should reference currentProject
        idx_c = self.content.index("e.key === 'c'")
        block_c = self.content[idx_c:idx_c + 300]
        self.assertIn('currentProject', block_c)

    def test_x_key_uses_current_project_fallback(self):
        """'x' key must fall back to App.state.currentProject."""
        idx_x = self.content.index("e.key === 'x'")
        block_x = self.content[idx_x:idx_x + 300]
        self.assertIn('currentProject', block_x)

    def test_u_key_uses_current_project_fallback(self):
        """'u' key must fall back to App.state.currentProject."""
        idx_u = self.content.index("e.key === 'u'")
        block_u = self.content[idx_u:idx_u + 300]
        self.assertIn('currentProject', block_u)

    def test_R_key_requires_row_selection(self):
        """'R' key must require row selection (no fallback)."""
        idx_R = self.content.index("e.key === 'R'")
        block_R = self.content[idx_R:idx_R + 200]
        self.assertIn('Select a project first', block_R)

    def test_n_key_requires_row_selection(self):
        """'n' key must require row selection (no fallback)."""
        idx_n = self.content.index("e.key === 'n'")
        block_n = self.content[idx_n:idx_n + 200]
        self.assertIn('Select a project first', block_n)

    def test_no_active_project_message(self):
        """Fallback keys show 'No active project' when no currentProject."""
        self.assertIn('No active project', self.content)


# =============================================================================
# Config API Endpoint Tests
# =============================================================================

class TestConfigAPIRoutes(unittest.TestCase):
    """Verify config API routes are registered."""

    @classmethod
    def setUpClass(cls):
        from bitbake_project.web import api  # noqa: F401

    def test_config_get_route_exists(self):
        """GET /api/config must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern == "^/api/config$" and method == "GET":
                return
        self.fail("GET /api/config route not found")

    def test_config_post_route_exists(self):
        """POST /api/config must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern == "^/api/config$" and method == "POST":
                return
        self.fail("POST /api/config route not found")

    def test_config_repo_post_route_exists(self):
        """POST /api/config/repo/<name> must be registered."""
        for method, pattern, handler in _routes:
            if "config/repo" in pattern.pattern and method == "POST":
                return
        self.fail("POST /api/config/repo/<name> route not found")

    def test_config_settings_post_route_exists(self):
        """POST /api/config/settings must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern == "^/api/config/settings$" and method == "POST":
                return
        self.fail("POST /api/config/settings route not found")

    def test_config_branches_post_route_exists(self):
        """POST /api/config/branches must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern == "^/api/config/branches$" and method == "POST":
                return
        self.fail("POST /api/config/branches route not found")

    def test_config_properties_post_route_exists(self):
        """POST /api/config/properties must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern == "^/api/config/properties$" and method == "POST":
                return
        self.fail("POST /api/config/properties route not found")

    def test_config_project_get_route_exists(self):
        """GET /api/config/project must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern == "^/api/config/project$" and method == "GET":
                return
        self.fail("GET /api/config/project route not found")


class TestConfigAPIResponseShape(unittest.TestCase):
    """Test GET /api/config response shape."""

    def _make_handler(self):
        handler = MagicMock(spec=BitWebHandler)
        handler._query = {}
        captured = {}

        def send_json(data, status=200):
            captured['data'] = data
            captured['status'] = status

        def send_error_json(status, msg):
            captured['data'] = {"error": msg}
            captured['status'] = status

        def query_param(name, default=""):
            return handler._query.get(name, default)

        handler._send_json = send_json
        handler._send_error_json = send_error_json
        handler._query_param = query_param
        handler.sse = MagicMock()
        return handler, captured

    @patch('bitbake_project.web.api._resolve_current_repos')
    @patch('bitbake_project.commands.common.get_repo_display_info')
    @patch('bitbake_project.commands.common.get_push_target')
    @patch('bitbake_project.core.get_custom_commands')
    @patch('bitbake_project.commands.projects.load_projects')
    @patch('bitbake_project.commands.projects.get_current_project')
    @patch('bitbake_project.commands.projects.get_directory_browser', return_value='auto')
    @patch('bitbake_project.commands.projects.get_git_viewer', return_value='auto')
    @patch('bitbake_project.commands.projects.get_preview_layout', return_value='down')
    @patch('bitbake_project.commands.projects.get_editor', return_value='auto')
    @patch('bitbake_project.commands.projects.get_recipe_use_bitbake_layers', return_value=True)
    @patch('bitbake_project.commands.projects.get_backup_prune_age', return_value='7')
    def test_config_response_has_all_sections(self, mock_prune, mock_recipe,
            mock_editor, mock_preview, mock_viewer, mock_browser,
            mock_current, mock_projects, mock_custom, mock_push, mock_display,
            mock_resolve):
        """GET /api/config returns repos, project, branches, settings."""
        mock_resolve.return_value = (["/repo1"], {"__branch_priorities__": ["main*"]}, {}, set())
        mock_display.return_value = ("repo1", False)
        mock_push.return_value = None
        mock_custom.return_value = {}
        mock_projects.return_value = {"/test": {"name": "test", "description": "A project"}}
        mock_current.return_value = "/test"

        from bitbake_project.web.api import api_config_get
        handler, captured = self._make_handler()
        api_config_get(handler)

        self.assertEqual(captured['status'], 200)
        data = captured['data']
        self.assertIn('repos', data)
        self.assertIn('project', data)
        self.assertIn('branches', data)
        self.assertIn('settings', data)

        # Repos shape
        self.assertEqual(len(data['repos']), 1)
        repo = data['repos'][0]
        self.assertIn('path', repo)
        self.assertIn('display_name', repo)
        self.assertIn('default_action', repo)

        # Project shape
        self.assertEqual(data['project']['path'], '/test')
        self.assertEqual(data['project']['name'], 'test')

        # Branches shape
        self.assertIn('priorities', data['branches'])
        self.assertIn('excludes', data['branches'])
        self.assertIn('stale_days', data['branches'])

        # Settings shape
        self.assertEqual(data['settings']['directory_browser'], 'auto')
        self.assertEqual(data['settings']['editor'], 'auto')


# =============================================================================
# Config View Content Tests
# =============================================================================

class TestConfigViewContent(unittest.TestCase):
    """Verify config.js has tree layout with section headers."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "views", "config.js")
        with open(path) as f:
            cls.content = f.read()

    def test_has_config_view_object(self):
        """config.js must define ConfigView."""
        self.assertIn('ConfigView', self.content)

    def test_has_render_tree_method(self):
        """config.js must have _renderTree method."""
        self.assertIn('_renderTree', self.content)

    def test_has_repos_section(self):
        """config.js must render Repositories section."""
        self.assertIn('Repositories', self.content)

    def test_has_branches_section(self):
        """config.js must render branches section."""
        self.assertIn('branches', self.content)
        self.assertIn('priorities', self.content)

    def test_has_properties_section(self):
        """config.js must render properties section."""
        self.assertIn('properties', self.content)

    def test_has_settings_section(self):
        """config.js must render settings section."""
        self.assertIn('configure options', self.content)

    def test_has_inline_panel(self):
        """config.js must have inline panel rendering."""
        self.assertIn('config-inline-panel', self.content)

    def test_has_radio_buttons(self):
        """config.js must use radio buttons for action selection."""
        self.assertIn('config-repo-action-radio', self.content)

    def test_has_project_context(self):
        """config.js must use _project() helper."""
        self.assertIn('_project()', self.content)
        self.assertIn('selectedProject', self.content)

    def test_saves_on_change(self):
        """config.js must save on change, not with a save button."""
        self.assertIn('addEventListener', self.content)
        self.assertIn('_saveRepoSetting', self.content)

    def test_no_save_button(self):
        """config.js must not have a save button (save on change)."""
        self.assertNotIn('config-save', self.content)

    def test_settings_uses_dropdowns(self):
        """config.js must use select dropdowns for settings."""
        self.assertIn('config-setting-select', self.content)
        self.assertIn('form-select', self.content)

    def test_branches_are_editable(self):
        """config.js must have add/remove for branch patterns."""
        self.assertIn('config-branch-add-btn', self.content)
        self.assertIn('config-branch-remove', self.content)
        self.assertIn('config-stale-input', self.content)

    def test_properties_are_editable(self):
        """config.js must have editable name and description fields."""
        self.assertIn('config-prop-name', self.content)
        self.assertIn('config-prop-desc', self.content)

    def test_save_methods_for_all_sections(self):
        """config.js must have save methods for all editable sections."""
        self.assertIn('_saveBranches', self.content)
        self.assertIn('_saveProperties', self.content)
        self.assertIn('_saveSetting', self.content)

    def test_project_section_is_expandable(self):
        """config.js must have expandable project section with conf browser."""
        self.assertIn('_renderProjectPanel', self.content)
        self.assertIn('getProjectConf', self.content)

    def test_project_conf_file_browser(self):
        """config.js must show conf files with variables."""
        self.assertIn('config-conf-file', self.content)
        self.assertIn('config-conf-vars', self.content)
        self.assertIn('config-var-name', self.content)

    def test_no_unicode_tree_connectors(self):
        """config.js must not use Unicode box-drawing characters."""
        # Should use CSS indentation instead of ├─ └─ │
        self.assertNotIn('\\u251c\\u2500', self.content)
        self.assertNotIn('\\u2514\\u2500', self.content)
        self.assertNotIn('\\u2502', self.content)


# =============================================================================
# Config CSS Tests
# =============================================================================

class TestConfigCSS(unittest.TestCase):
    """Verify config tree styles exist in style.css."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "style.css")
        with open(path) as f:
            cls.content = f.read()

    def test_has_section_header_style(self):
        self.assertIn('.config-section-header', self.content)

    def test_has_tree_row_style(self):
        self.assertIn('.config-tree-row', self.content)

    def test_has_inline_panel_style(self):
        self.assertIn('.config-inline-panel', self.content)

    def test_has_radio_style(self):
        self.assertIn('.config-radio', self.content)

    def test_has_children_indent_style(self):
        """CSS tree uses border-left indentation, not Unicode connectors."""
        self.assertIn('.config-children', self.content)

    def test_has_tag_list_style(self):
        """CSS must have tag list styles for branch patterns."""
        self.assertIn('.config-tag-list', self.content)
        self.assertIn('.config-tag', self.content)

    def test_has_conf_file_browser_styles(self):
        """CSS must have conf file browser styles for project section."""
        self.assertIn('.config-conf-file', self.content)
        self.assertIn('.config-conf-vars', self.content)
        self.assertIn('.config-var-name', self.content)


# =============================================================================
# Theme CSS Tests
# =============================================================================

class TestThemeCSS(unittest.TestCase):
    """Verify theme selectors and variables in CSS and HTML."""

    @classmethod
    def setUpClass(cls):
        cls.css = open(os.path.join(STATIC_DIR, "style.css")).read()
        cls.html = open(os.path.join(STATIC_DIR, "index.html")).read()

    def test_light_theme_selector(self):
        self.assertIn('[data-theme="light"]', self.css)

    def test_high_contrast_theme_selector(self):
        self.assertIn('[data-theme="high-contrast"]', self.css)

    def test_ocean_theme_selector(self):
        self.assertIn('[data-theme="ocean"]', self.css)

    def test_forest_theme_selector(self):
        self.assertIn('[data-theme="forest"]', self.css)

    def test_nord_theme_selector(self):
        self.assertIn('[data-theme="nord"]', self.css)

    def test_dracula_theme_selector(self):
        self.assertIn('[data-theme="dracula"]', self.css)

    def test_themes_override_bg_primary(self):
        """Each theme selector must override --bg-primary."""
        for theme in ('light', 'high-contrast', 'ocean', 'forest', 'nord', 'dracula'):
            selector = f'[data-theme="{theme}"]'
            idx = self.css.index(selector)
            block = self.css[idx:idx + 600]
            self.assertIn('--bg-primary', block, f"{theme} missing --bg-primary")

    def test_theme_select_in_html(self):
        self.assertIn('id="theme-select"', self.html)

    def test_theme_select_has_options(self):
        for theme in ('light', 'high-contrast', 'ocean', 'forest', 'nord', 'dracula'):
            self.assertIn(f'value="{theme}"', self.html)


# =============================================================================
# Keyboard Nav Helper Tests
# =============================================================================

class TestKeyboardNavHelper(unittest.TestCase):
    """Verify KeyboardNav factory in utils.js."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "utils.js")
        with open(path) as f:
            cls.content = f.read()

    def test_keyboard_nav_defined(self):
        self.assertIn('function KeyboardNav', self.content)

    def test_has_handle_basic_keys(self):
        self.assertIn('handleBasicKeys', self.content)

    def test_has_move_active(self):
        self.assertIn('moveActive', self.content)

    def test_has_set_rows(self):
        self.assertIn('setRows', self.content)

    def test_exposed_as_global(self):
        self.assertIn('window.KeyboardNav', self.content)


# =============================================================================
# View Keyboard Handler Tests
# =============================================================================

class TestViewKeyboardHandlers(unittest.TestCase):
    """Verify all 10 views have handleKeyboard and keyBindings."""

    @classmethod
    def setUpClass(cls):
        cls.views = {}
        view_dir = os.path.join(STATIC_DIR, "js", "views")
        for name in ('update', 'config', 'patches', 'b4', 'recipes',
                      'fragments', 'deps', 'info', 'export', 'terminal'):
            path = os.path.join(view_dir, name + '.js')
            with open(path) as f:
                cls.views[name] = f.read()

    def test_update_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['update'])
        self.assertIn('keyBindings', self.views['update'])

    def test_config_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['config'])
        self.assertIn('keyBindings', self.views['config'])

    def test_patches_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['patches'])
        self.assertIn('keyBindings', self.views['patches'])

    def test_b4_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['b4'])
        self.assertIn('keyBindings', self.views['b4'])

    def test_recipes_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['recipes'])
        self.assertIn('keyBindings', self.views['recipes'])

    def test_fragments_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['fragments'])
        self.assertIn('keyBindings', self.views['fragments'])

    def test_deps_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['deps'])
        self.assertIn('keyBindings', self.views['deps'])

    def test_info_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['info'])
        self.assertIn('keyBindings', self.views['info'])

    def test_export_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['export'])
        self.assertIn('keyBindings', self.views['export'])

    def test_terminal_has_keyboard(self):
        self.assertIn('handleKeyboard', self.views['terminal'])
        self.assertIn('keyBindings', self.views['terminal'])


# =============================================================================
# File Editor API Tests
# =============================================================================

class TestFileEditorAPI(unittest.TestCase):
    """Verify file read/write and themes API routes are registered."""

    @classmethod
    def setUpClass(cls):
        from bitbake_project.web import api_commands  # noqa: F401

    def test_file_read_route_exists(self):
        for method, pattern, handler in _routes:
            if "file/read" in pattern.pattern and method == "GET":
                return
        self.fail("GET /api/file/read route not found")

    def test_file_write_route_exists(self):
        for method, pattern, handler in _routes:
            if "file/write" in pattern.pattern and method == "POST":
                return
        self.fail("POST /api/file/write route not found")

    def test_config_themes_route_exists(self):
        for method, pattern, handler in _routes:
            if "config/themes" in pattern.pattern and method == "GET":
                return
        self.fail("GET /api/config/themes route not found")


# =============================================================================
# File Editor JS Tests
# =============================================================================

class TestFileEditorJS(unittest.TestCase):
    """Verify fileEditor in utils.js and readFile/writeFile in api.js."""

    @classmethod
    def setUpClass(cls):
        cls.utils = open(os.path.join(STATIC_DIR, "js", "utils.js")).read()
        cls.api = open(os.path.join(STATIC_DIR, "js", "api.js")).read()

    def test_file_editor_defined(self):
        self.assertIn('function fileEditor', self.utils)

    def test_file_editor_exposed(self):
        self.assertIn('window.fileEditor', self.utils)

    def test_api_has_read_file(self):
        self.assertIn('readFile', self.api)

    def test_api_has_write_file(self):
        self.assertIn('writeFile', self.api)

    def test_api_has_get_themes(self):
        self.assertIn('getThemes', self.api)


# =============================================================================
# View Drag Handle Tests
# =============================================================================

class TestViewDragHandles(unittest.TestCase):
    """Verify 6 views have drag handles and initViewSortable calls."""

    @classmethod
    def setUpClass(cls):
        cls.views = {}
        view_dir = os.path.join(STATIC_DIR, "js", "views")
        for name in ('explore', 'update', 'branch', 'patches', 'fragments', 'info'):
            path = os.path.join(view_dir, name + '.js')
            with open(path) as f:
                cls.views[name] = f.read()

    def test_explore_has_drag_handle(self):
        self.assertIn('drag-handle', self.views['explore'])

    def test_explore_has_view_sortable(self):
        self.assertIn('initViewSortable', self.views['explore'])

    def test_update_has_drag_handle(self):
        self.assertIn('drag-handle', self.views['update'])

    def test_update_has_view_sortable(self):
        self.assertIn('initViewSortable', self.views['update'])

    def test_branch_has_drag_handle(self):
        self.assertIn('drag-handle', self.views['branch'])

    def test_branch_has_view_sortable(self):
        self.assertIn('initViewSortable', self.views['branch'])

    def test_patches_has_grouped_tree(self):
        self.assertIn('_expandedRepos', self.views['patches'])

    def test_patches_has_repo_grouping(self):
        self.assertIn('_toggleRepo', self.views['patches'])

    def test_fragments_has_grouped_tree(self):
        self.assertIn('_expandedDomains', self.views['fragments'])

    def test_fragments_has_domain_grouping(self):
        self.assertIn('_toggleDomain', self.views['fragments'])

    def test_info_has_drag_handle(self):
        self.assertIn('drag-handle', self.views['info'])

    def test_info_has_view_sortable(self):
        self.assertIn('initViewSortable', self.views['info'])

    def test_sortable_js_has_view_functions(self):
        path = os.path.join(STATIC_DIR, "js", "sortable.js")
        with open(path) as f:
            content = f.read()
        self.assertIn('initViewSortable', content)
        self.assertIn('resetViewOrder', content)
        self.assertIn('window.initViewSortable', content)
        self.assertIn('window.resetViewOrder', content)

    def test_css_has_view_row_ghost(self):
        path = os.path.join(STATIC_DIR, "style.css")
        with open(path) as f:
            content = f.read()
        self.assertIn('.view-row-ghost', content)


# =============================================================================
# Dashboard Manage / Configure / Sync Tests
# =============================================================================

class TestDashboardManageSync(unittest.TestCase):
    """Verify dashboard.js has Manage, Configure, and remoteSync features."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "views", "dashboard.js")
        with open(path) as f:
            cls.content = f.read()

    def test_has_manage_button(self):
        self.assertIn('dash-manage', self.content)

    def test_has_configure_button(self):
        self.assertIn('dash-configure', self.content)

    def test_has_manage_modal(self):
        self.assertIn('_manageModal', self.content)

    def test_has_configure_modal(self):
        self.assertIn('_configureModal', self.content)

    def test_has_remote_sync(self):
        self.assertIn('remoteSync', self.content)

    def test_has_sync_row(self):
        self.assertIn('dash-sync-row', self.content)

    def test_has_update_settings(self):
        self.assertIn('updateSettings', self.content)

    def test_manage_has_add_dir(self):
        self.assertIn('add-dir', self.content)

    def test_manage_has_sync_remote(self):
        self.assertIn('sync-remote', self.content)

    def test_configure_has_settings_dropdowns(self):
        self.assertIn('dash-config-select', self.content)
        self.assertIn('directory_browser', self.content)
        self.assertIn('git_viewer', self.content)


# =============================================================================
# WebSocket Protocol Tests
# =============================================================================

class TestWebSocketProtocol(unittest.TestCase):
    """Test pure-Python WebSocket implementation."""

    def test_ws_accept_key_computation(self):
        """Accept key follows RFC 6455 SHA1+base64 algorithm."""
        from bitbake_project.web.websocket import ws_accept_key
        # RFC 6455 Section 4.2.2 test vector:
        # key "dGhlIHNhbXBsZSBub25jZQ==" → accept "s3pPLMBiTxaQ9kYGzzhZRbK+xOo="
        client_key = "dGhlIHNhbXBsZSBub25jZQ=="
        result = ws_accept_key(client_key)
        self.assertEqual(result, "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=")

    def test_write_read_frame_roundtrip(self):
        """Write a frame, then read it back."""
        import io
        from bitbake_project.web.websocket import write_frame, read_frame, OP_TEXT
        buf = io.BytesIO()
        payload = b"hello world"
        write_frame(buf, OP_TEXT, payload)
        buf.seek(0)
        opcode, data = read_frame(buf)
        self.assertEqual(opcode, OP_TEXT)
        self.assertEqual(data, payload)

    def test_write_read_binary_frame(self):
        """Binary frame roundtrip."""
        import io
        from bitbake_project.web.websocket import write_frame, read_frame, OP_BINARY
        buf = io.BytesIO()
        payload = bytes(range(256))
        write_frame(buf, OP_BINARY, payload)
        buf.seek(0)
        opcode, data = read_frame(buf)
        self.assertEqual(opcode, OP_BINARY)
        self.assertEqual(data, payload)

    def test_masked_frame_decoding(self):
        """Client-style masked frame is correctly unmasked."""
        import io
        import struct
        from bitbake_project.web.websocket import read_frame, OP_TEXT
        # Build a masked frame manually
        payload = b"test"
        mask_key = b"\x37\xfa\x21\x3d"
        masked = bytes(b ^ mask_key[i % 4] for i, b in enumerate(payload))
        frame = bytes([0x81, 0x80 | len(payload)]) + mask_key + masked
        buf = io.BytesIO(frame)
        opcode, data = read_frame(buf)
        self.assertEqual(opcode, OP_TEXT)
        self.assertEqual(data, payload)

    def test_close_frame(self):
        """Close frame is correctly identified."""
        import io
        from bitbake_project.web.websocket import write_frame, read_frame, OP_CLOSE
        buf = io.BytesIO()
        write_frame(buf, OP_CLOSE, b"\x03\xe8")  # code 1000
        buf.seek(0)
        opcode, data = read_frame(buf)
        self.assertEqual(opcode, OP_CLOSE)

    def test_large_payload(self):
        """Payload > 125 bytes uses 2-byte extended length."""
        import io
        from bitbake_project.web.websocket import write_frame, read_frame, OP_BINARY
        buf = io.BytesIO()
        payload = b"x" * 300
        write_frame(buf, OP_BINARY, payload)
        buf.seek(0)
        opcode, data = read_frame(buf)
        self.assertEqual(opcode, OP_BINARY)
        self.assertEqual(len(data), 300)

    def test_read_frame_empty_returns_none(self):
        """Reading from empty stream returns (None, None)."""
        import io
        from bitbake_project.web.websocket import read_frame
        buf = io.BytesIO(b"")
        opcode, data = read_frame(buf)
        self.assertIsNone(opcode)
        self.assertIsNone(data)


# =============================================================================
# Terminal Param Parsing Tests
# =============================================================================

class TestParseTerminalParams(unittest.TestCase):
    """Test _parse_terminal_params tmux session handling."""

    def _make_handler(self, path):
        handler = type('H', (), {'path': path})()
        return handler

    def test_local_cwd_gets_tmux_session(self):
        from bitbake_project.web.terminal import _parse_terminal_params
        handler = self._make_handler('/ws/terminal?cwd=/opt/poky')
        cwd, cmd = _parse_terminal_params(handler)
        self.assertEqual(cwd, '/opt/poky')
        self.assertIsNotNone(cmd)
        shell = ' '.join(cmd)
        self.assertIn('tmux', shell)
        self.assertIn('bit-poky', shell)

    def test_explicit_session_param(self):
        from bitbake_project.web.terminal import _parse_terminal_params
        handler = self._make_handler('/ws/terminal?cwd=/opt/poky&session=bit-custom')
        cwd, cmd = _parse_terminal_params(handler)
        self.assertEqual(cwd, '/opt/poky')
        self.assertIsNotNone(cmd)
        shell = ' '.join(cmd)
        self.assertIn('bit-custom', shell)

    def test_ssh_gets_tmux_session(self):
        from bitbake_project.web.terminal import _parse_terminal_params
        handler = self._make_handler('/ws/terminal?ssh=bruce@host&path=/opt/poky')
        cwd, cmd = _parse_terminal_params(handler)
        self.assertEqual(cwd, '')
        self.assertIn('ssh', cmd)
        self.assertIn('-t', cmd)
        # Should contain tmux attach/new-session command
        ssh_remote_cmd = cmd[-1]
        self.assertIn('tmux', ssh_remote_cmd)
        self.assertIn('bit-poky', ssh_remote_cmd)

    def test_ssh_explicit_session(self):
        from bitbake_project.web.terminal import _parse_terminal_params
        handler = self._make_handler('/ws/terminal?ssh=bruce@host&path=/opt/poky&session=bit-mine')
        cwd, cmd = _parse_terminal_params(handler)
        ssh_remote_cmd = cmd[-1]
        self.assertIn('bit-mine', ssh_remote_cmd)

    def test_no_params_returns_no_cmd(self):
        from bitbake_project.web.terminal import _parse_terminal_params
        handler = self._make_handler('/ws/terminal')
        cwd, cmd = _parse_terminal_params(handler)
        self.assertEqual(cwd, '')
        self.assertIsNone(cmd)


# =============================================================================
# PTY Session Tests
# =============================================================================

class TestPTYSession(unittest.TestCase):
    """Test PTY session lifecycle."""

    def test_spawn_creates_process(self):
        from bitbake_project.web.terminal import PTYSession
        session = PTYSession()
        session.spawn()
        try:
            self.assertIsNotNone(session.master_fd)
            self.assertIsNotNone(session.child_pid)
            # Child should be alive
            os.kill(session.child_pid, 0)  # signal 0 = check existence
        finally:
            session.close()

    def test_write_read_echo(self):
        """Write to PTY, read echoed output."""
        import select
        from bitbake_project.web.terminal import PTYSession
        session = PTYSession()
        session.spawn()
        try:
            # Send a command and wait for echo
            session.write(b"echo hello_pty_test\n")
            # Wait for data to be ready
            output = b""
            for _ in range(50):  # up to 5 seconds
                ready, _, _ = select.select([session.master_fd], [], [], 0.1)
                if ready:
                    output += session.read(4096)
                    if b"hello_pty_test" in output:
                        break
            self.assertIn(b"hello_pty_test", output)
        finally:
            session.close()

    def test_resize_does_not_raise(self):
        from bitbake_project.web.terminal import PTYSession
        session = PTYSession()
        session.spawn()
        try:
            session.resize(40, 120)
        finally:
            session.close()

    def test_close_terminates_child(self):
        from bitbake_project.web.terminal import PTYSession
        session = PTYSession()
        session.spawn()
        pid = session.child_pid
        session.close()
        # Give a moment for process to terminate
        time.sleep(0.2)
        with self.assertRaises(OSError):
            os.kill(pid, 0)

    def test_double_close_safe(self):
        from bitbake_project.web.terminal import PTYSession
        session = PTYSession()
        session.spawn()
        session.close()
        session.close()  # Should not raise


# =============================================================================
# Terminal Static Files Tests
# =============================================================================

class TestTerminalStaticFiles(unittest.TestCase):
    """Test terminal feature static files and integration."""

    def test_vendor_xterm_js_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "vendor", "xterm.min.js")))

    def test_vendor_xterm_css_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "vendor", "xterm.css")))

    def test_vendor_xterm_addon_fit_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "vendor", "xterm-addon-fit.min.js")))

    def test_terminal_ws_js_exists(self):
        self.assertTrue(os.path.isfile(os.path.join(STATIC_DIR, "js", "terminal-ws.js")))

    def test_index_includes_xterm_css(self):
        with open(os.path.join(STATIC_DIR, "index.html")) as f:
            content = f.read()
        self.assertIn("xterm.css", content)

    def test_index_includes_xterm_js(self):
        with open(os.path.join(STATIC_DIR, "index.html")) as f:
            content = f.read()
        self.assertIn("xterm.min.js", content)

    def test_index_includes_addon_fit(self):
        with open(os.path.join(STATIC_DIR, "index.html")) as f:
            content = f.read()
        self.assertIn("xterm-addon-fit.min.js", content)

    def test_index_includes_terminal_ws(self):
        with open(os.path.join(STATIC_DIR, "index.html")) as f:
            content = f.read()
        self.assertIn("terminal-ws.js", content)

    def test_server_has_ws_terminal_path(self):
        """server.py handles /ws/terminal WebSocket upgrade."""
        with open(os.path.join(os.path.dirname(STATIC_DIR), "server.py")) as f:
            content = f.read()
        self.assertIn("/ws/terminal", content)
        self.assertIn("websocket", content.lower())

    def test_terminal_ws_js_has_terminal_manager(self):
        with open(os.path.join(STATIC_DIR, "js", "terminal-ws.js")) as f:
            content = f.read()
        self.assertIn("TerminalManager", content)
        self.assertIn("toggle", content)
        self.assertIn("ws/terminal", content)

    def test_app_js_has_backtick_toggle(self):
        with open(os.path.join(STATIC_DIR, "js", "app.js")) as f:
            content = f.read()
        self.assertIn("TerminalManager", content)
        self.assertIn("`", content)

    def test_style_css_has_terminal_container(self):
        with open(os.path.join(STATIC_DIR, "style.css")) as f:
            content = f.read()
        self.assertIn(".terminal-container", content)


# =============================================================================
# Context Menus + Action Icon Bars Tests
# =============================================================================

class TestContextMenusAndIconBars(unittest.TestCase):
    """Verify context menus and per-row action icon bars across views."""

    @classmethod
    def setUpClass(cls):
        view_dir = os.path.join(STATIC_DIR, "js", "views")
        cls.recipes_js = open(os.path.join(view_dir, "recipes.js")).read()
        cls.fragments_js = open(os.path.join(view_dir, "fragments.js")).read()
        cls.patches_js = open(os.path.join(view_dir, "patches.js")).read()
        cls.commits_js = open(os.path.join(view_dir, "commits.js")).read()
        cls.dashboard_js = open(os.path.join(view_dir, "dashboard.js")).read()
        cls.css = open(os.path.join(STATIC_DIR, "style.css")).read()

    # --- CSS ---

    def test_css_has_row_actions(self):
        """style.css has .row-actions rules for generic per-row icon bar."""
        self.assertIn('.row-actions', self.css)

    def test_css_has_row_actions_col(self):
        """style.css has .row-actions-col for zero-width header column."""
        self.assertIn('.row-actions-col', self.css)

    def test_css_has_commit_actions(self):
        """style.css has .commit-actions rules for commit per-row icons."""
        self.assertIn('.commit-actions', self.css)

    # --- Recipes ---

    def test_recipes_has_context_menu(self):
        """recipes.js has context menu support."""
        self.assertIn('contextmenu', self.recipes_js)
        self.assertIn('contextMenu', self.recipes_js)

    def test_recipes_has_row_actions(self):
        """recipes.js has per-row action icon buttons."""
        self.assertIn('row-actions', self.recipes_js)

    # --- Fragments ---

    def test_fragments_has_context_menu(self):
        """fragments.js has context menu support."""
        self.assertIn('contextmenu', self.fragments_js)
        self.assertIn('contextMenu', self.fragments_js)

    def test_fragments_has_row_actions(self):
        """fragments.js has per-row action icon buttons."""
        self.assertIn('row-actions', self.fragments_js)

    # --- Patches ---

    def test_patches_has_context_menu(self):
        """patches.js has context menu support."""
        self.assertIn('contextmenu', self.patches_js)
        self.assertIn('contextMenu', self.patches_js)

    def test_patches_has_row_actions(self):
        """patches.js has per-row action icon buttons."""
        self.assertIn('row-actions', self.patches_js)

    # --- Commits ---

    def test_commits_has_context_menu(self):
        """commits.js has context menu support."""
        self.assertIn('contextmenu', self.commits_js)
        self.assertIn('contextMenu', self.commits_js)

    def test_commits_has_commit_actions(self):
        """commits.js has per-row commit action icons."""
        self.assertIn('commit-actions', self.commits_js)

    # --- Dashboard ---

    def test_dashboard_has_context_menu(self):
        """dashboard.js has context menu support."""
        self.assertIn('contextmenu', self.dashboard_js)
        self.assertIn('contextMenu', self.dashboard_js)

    def test_dashboard_has_action_mode(self):
        """dashboard.js has configurable action mode (expander/icons)."""
        self.assertIn('dash-action-mode', self.dashboard_js)


# =============================================================================
# Lore Route SSH Query Tests
# =============================================================================

class TestLoreRouteSSHQuery(unittest.TestCase):
    """Verify lore route exists and matches expected URL pattern."""

    @classmethod
    def setUpClass(cls):
        from bitbake_project.web import api  # noqa: F401

    def test_lore_route_exists(self):
        """GET /api/repos/<name>/commits/<hash>/lore must be registered."""
        for method, pattern, handler in _routes:
            if "lore" in pattern.pattern:
                self.assertEqual(method, "GET")
                m = pattern.match("/api/repos/my-repo/commits/abc123/lore")
                self.assertIsNotNone(m)
                self.assertEqual(m.group(1), "my-repo")
                self.assertEqual(m.group(2), "abc123")
                return
        self.fail("Lore route not found")

    def test_lore_handler_uses_query_import(self):
        """Lore handler should import from commands.query (SSH-capable)."""
        import inspect
        from bitbake_project.web.api import api_repo_commit_lore
        source = inspect.getsource(api_repo_commit_lore)
        self.assertIn("query_commit_lore", source)
        self.assertIn("_ssh_query", source)


# =============================================================================
# Tree Route Tests
# =============================================================================

class TestTreeRoutes(unittest.TestCase):
    """Verify tree, file-commits, changed-files routes registered."""

    @classmethod
    def setUpClass(cls):
        from bitbake_project.web import api  # noqa: F401

    def test_tree_route_exists(self):
        """GET /api/repos/<name>/tree must be registered."""
        for method, pattern, handler in _routes:
            if pattern.pattern.endswith("/tree$"):
                self.assertEqual(method, "GET")
                m = pattern.match("/api/repos/my-repo/tree")
                self.assertIsNotNone(m)
                self.assertEqual(m.group(1), "my-repo")
                return
        self.fail("Tree route not found")

    def test_file_commits_route_exists(self):
        """GET /api/repos/<name>/files/<path>/commits must be registered."""
        for method, pattern, handler in _routes:
            if "files" in pattern.pattern and "commits" in pattern.pattern:
                self.assertEqual(method, "GET")
                m = pattern.match("/api/repos/my-repo/files/src/main.py/commits")
                self.assertIsNotNone(m)
                self.assertEqual(m.group(1), "my-repo")
                self.assertEqual(m.group(2), "src/main.py")
                return
        self.fail("File commits route not found")

    def test_changed_files_route_exists(self):
        """GET /api/repos/<name>/commits/<hash>/changed-files must be registered."""
        for method, pattern, handler in _routes:
            if "changed-files" in pattern.pattern:
                self.assertEqual(method, "GET")
                m = pattern.match("/api/repos/my-repo/commits/abc123/changed-files")
                self.assertIsNotNone(m)
                self.assertEqual(m.group(1), "my-repo")
                self.assertEqual(m.group(2), "abc123")
                return
        self.fail("Changed files route not found")


# =============================================================================
# API JS Tree Methods Tests
# =============================================================================

class TestApiJsTreeMethods(unittest.TestCase):
    """Verify api.js has tree-related API methods."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "api.js")
        with open(path) as f:
            cls.content = f.read()

    def test_has_get_repo_tree(self):
        self.assertIn("getRepoTree", self.content)

    def test_has_get_file_commits(self):
        self.assertIn("getFileCommits", self.content)

    def test_has_get_commit_changed_files(self):
        self.assertIn("getCommitChangedFiles", self.content)

    def test_file_commits_encodes_path_segments(self):
        """getFileCommits must encode path segments individually."""
        self.assertIn("encodeURIComponent", self.content)
        self.assertIn("split('/')", self.content)


# =============================================================================
# Commits JS Tree View Tests
# =============================================================================

class TestCommitsJsTreeView(unittest.TestCase):
    """Verify commits.js has interactive tree view implementation."""

    @classmethod
    def setUpClass(cls):
        path = os.path.join(STATIC_DIR, "js", "views", "commits.js")
        with open(path) as f:
            cls.content = f.read()

    def test_has_tree_mode(self):
        self.assertIn("_treeMode", self.content)

    def test_has_render_tree(self):
        self.assertIn("_renderTree", self.content)

    def test_has_render_tree_level(self):
        self.assertIn("_renderTreeLevel", self.content)

    def test_has_load_file_commits(self):
        self.assertIn("_loadFileCommits", self.content)

    def test_has_tree_css_classes(self):
        """Tree view must use proper CSS class names."""
        self.assertIn("file-tree", self.content)
        self.assertIn("tree-node", self.content)
        self.assertIn("tree-dir", self.content)
        self.assertIn("tree-file", self.content)
        self.assertIn("tree-commit", self.content)

    def test_file_tree_label(self):
        """Key binding and label must say 'File tree' not 'File list'."""
        self.assertIn("'File tree'", self.content)

    def test_has_show_direct_commit(self):
        self.assertIn("_showDirectCommit", self.content)

    def test_tree_escape_handler(self):
        """Escape must check _treeMode."""
        self.assertIn("this._treeMode", self.content)


# =============================================================================
# Tree CSS Tests
# =============================================================================

class TestTreeCSS(unittest.TestCase):
    """Verify style.css has tree view CSS classes."""

    @classmethod
    def setUpClass(cls):
        with open(os.path.join(STATIC_DIR, "style.css")) as f:
            cls.content = f.read()

    def test_has_file_tree(self):
        self.assertIn(".file-tree", self.content)

    def test_has_tree_node(self):
        self.assertIn(".tree-node", self.content)

    def test_has_tree_dir(self):
        self.assertIn(".tree-dir", self.content)

    def test_has_tree_file_modified(self):
        self.assertIn(".tree-file--modified", self.content)

    def test_has_tree_more(self):
        self.assertIn(".tree-more", self.content)

    def test_has_tree_commit(self):
        self.assertIn(".tree-commit", self.content)

    def test_has_tree_commit_sha(self):
        self.assertIn(".tree-commit-sha", self.content)


# =============================================================================
# Query Dispatch New Paths Tests
# =============================================================================

class TestQueryDispatchNewPaths(unittest.TestCase):
    """Verify 4 new regexes in query.py match expected paths."""

    def test_lore_regex(self):
        from bitbake_project.commands.query import _LORE_RE
        m = _LORE_RE.match("repos/oe-core/commits/abc123/lore")
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), "oe-core")
        self.assertEqual(m.group(2), "abc123")

    def test_tree_regex(self):
        from bitbake_project.commands.query import _TREE_RE
        m = _TREE_RE.match("repos/oe-core/tree")
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), "oe-core")

    def test_file_commits_regex(self):
        from bitbake_project.commands.query import _FILE_COMMITS_RE
        m = _FILE_COMMITS_RE.match("repos/oe-core/files/src/main.py/commits")
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), "oe-core")
        self.assertEqual(m.group(2), "src/main.py")

    def test_changed_files_regex(self):
        from bitbake_project.commands.query import _CHANGED_FILES_RE
        m = _CHANGED_FILES_RE.match("repos/oe-core/commits/abc123/changed-files")
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), "oe-core")
        self.assertEqual(m.group(2), "abc123")

    def test_file_commits_regex_nested_path(self):
        """File commits regex must capture nested paths with slashes."""
        from bitbake_project.commands.query import _FILE_COMMITS_RE
        m = _FILE_COMMITS_RE.match("repos/oe-core/files/meta/recipes-core/init/init-ifupdown_1.0.bb/commits")
        self.assertIsNotNone(m)
        self.assertEqual(m.group(2), "meta/recipes-core/init/init-ifupdown_1.0.bb")


if __name__ == "__main__":
    unittest.main()
