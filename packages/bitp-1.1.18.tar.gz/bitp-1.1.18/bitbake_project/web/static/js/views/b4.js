/* B4/Lore view — search and apply patches */
const B4View = {
  _nav: KeyboardNav(),

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'Apply patch', action: 'Enter'},
    {key: '/', desc: 'Search', action: '/'},
  ],

  handleKeyboard(e) {
    if (this._nav.handleBasicKeys(e)) return;
    var row = this._nav.activeRow();
    if (e.key === 'Enter' && row) {
      e.preventDefault();
      var btn = row.querySelector('button[data-msgid]');
      if (btn) btn.click();
    } else if (e.key === '/') {
      e.preventDefault();
      var input = document.getElementById('b4-search');
      if (input) input.focus();
    }
  },

  async render(container, state) {
    container.innerHTML = `
      <div class="view-header">
        <h2>B4 / Lore</h2>
      </div>
      <div class="search-bar">
        <input type="text" id="b4-search" placeholder="Search lore.kernel.org...">
        <button class="btn btn-primary" id="b4-go">Search</button>
      </div>
      <div id="b4-results" class="empty-state"><h3>Enter a search term to find patches on lore</h3></div>
    `;

    const doSearch = () => this._search();
    document.getElementById('b4-go').addEventListener('click', doSearch);
    document.getElementById('b4-search').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });

    // Cross-view lore search: pre-fill from patches view
    if (App.state.b4SearchQuery) {
      document.getElementById('b4-search').value = App.state.b4SearchQuery;
      App.state.b4SearchQuery = null;
      this._search();
    }
  },

  async _search() {
    const q = document.getElementById('b4-search').value.trim();
    if (!q) return;
    const el = document.getElementById('b4-results');
    el.className = 'loading';
    el.textContent = 'Searching lore...';

    try {
      const results = await API.b4Search(q);
      this._renderResults(results);
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Search error</h3><p>${e.message}</p></div>`;
    }
  },

  _renderResults(results) {
    const el = document.getElementById('b4-results');
    if (!results || !results.length) {
      el.className = '';
      el.innerHTML = '<div class="empty-state"><h3>No results</h3></div>';
      return;
    }

    el.className = '';
    el.innerHTML = `<table class="data-table">
      <thead><tr><th>Subject</th><th>From</th><th>Date</th><th></th></tr></thead>
      <tbody>${results.map(r => {
        const subject = r.subject || r.title || '';
        const from = r.from || r.author || '';
        const date = r.date || '';
        const msgid = r.msgid || r.message_id || '';
        return `<tr>
          <td>${esc(subject)}</td>
          <td style="color:var(--text-muted)">${esc(from)}</td>
          <td style="color:var(--text-muted)">${esc(date)}</td>
          <td>
            <button class="btn btn-primary" data-msgid="${esc(msgid)}">Apply</button>
          </td>
        </tr>`;
      }).join('')}</tbody>
    </table>`;

    // Keyboard nav
    this._nav.setRows(el.querySelectorAll('tbody tr'));

    el.querySelectorAll('button[data-msgid]').forEach(btn => {
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        App.clearTerminal();
        App.showTerminal(`Applying: ${btn.dataset.msgid}`);
        try {
          await API.b4Apply(btn.dataset.msgid);
          App.showToast('Apply started — see terminal', 'success');
        } catch (e) {
          App.showToast(e.message, 'error');
        }
        btn.disabled = false;
      });
    });
  },

};
