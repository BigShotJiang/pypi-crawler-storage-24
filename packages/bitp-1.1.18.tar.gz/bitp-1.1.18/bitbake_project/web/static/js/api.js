/* bit web dashboard — API client */
const API = {
  async _fetch(url, opts = {}) {
    try {
      const resp = await fetch(url, {
        headers: { 'Content-Type': 'application/json', ...opts.headers },
        ...opts,
      });
      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ error: resp.statusText }));
        throw new Error(err.error || resp.statusText);
      }
      return resp.json();
    } catch (e) {
      console.error(`API error: ${url}`, e);
      throw e;
    }
  },

  _post(url, body = {}) {
    return this._fetch(url, { method: 'POST', body: JSON.stringify(body) });
  },

  /** Append ?project= to a URL when a project context is provided. */
  _projUrl(base, project) {
    if (!project) return base;
    const sep = base.includes('?') ? '&' : '?';
    return base + sep + 'project=' + encodeURIComponent(project);
  },

  // Projects
  getProjects()          { return this._fetch('/api/projects'); },
  getCurrentProject()    { return this._fetch('/api/projects/current'); },
  activateProject(path)  { return this._post('/api/projects/activate', { path }); },
  addProject(path, name) { return this._post('/api/projects/add', { path, name }); },
  removeProject(path)    { return this._post('/api/projects/remove', { path }); },
  renameProject(path, name) { return this._post('/api/projects/rename', { path, name }); },

  // Repos — all accept optional project path for non-activating context
  async getRepos(project) {
    const data = await this._fetch(this._projUrl('/api/repos', project));
    return data.repos || data;
  },
  getReposRaw(project)           { return this._fetch(this._projUrl('/api/repos', project)); },
  getRepoCommits(name, project, opts)  {
    let url = `/api/repos/${encodeURIComponent(name)}/commits`;
    if (opts) {
      const params = [];
      if (opts.upstream_limit) params.push('upstream_limit=' + opts.upstream_limit);
      if (opts.context_limit) params.push('context_limit=' + opts.context_limit);
      if (params.length) url += (url.includes('?') ? '&' : '?') + params.join('&');
    }
    return this._fetch(this._projUrl(url, project));
  },
  getRepoBranches(name, project) { return this._fetch(this._projUrl(`/api/repos/${encodeURIComponent(name)}/branches`, project)); },
  checkoutBranch(name, b, project) { return this._post(this._projUrl(`/api/repos/${encodeURIComponent(name)}/checkout`, project), { branch: b }); },
  fetchRepo(name, project)       { return this._post(this._projUrl(`/api/repos/${encodeURIComponent(name)}/fetch`, project)); },
  updateRepo(name, action, project){ return this._post(this._projUrl(`/api/repos/${encodeURIComponent(name)}/update`, project), { action }); },
  refreshAll()                   { return this._post('/api/refresh'); },
  getUnionBranches(project)      { return this._fetch(this._projUrl('/api/repos/branches/union', project)); },
  branchAll(branch, project)     { return this._post(this._projUrl('/api/repos/branch-all', project), { branch }); },
  getCommitShow(name, hash, project){ return this._fetch(this._projUrl(`/api/repos/${encodeURIComponent(name)}/commits/${encodeURIComponent(hash)}/show`, project)); },
  getRepoDiff(name, project)     { return this._fetch(this._projUrl(`/api/repos/${encodeURIComponent(name)}/diff`, project)); },
  getRepoLog(name, count, project) { return this._fetch(this._projUrl(`/api/repos/${encodeURIComponent(name)}/log?count=${count || 50}`, project)); },

  // Config
  getConfig(project)      { return this._fetch(this._projUrl('/api/config', project)); },
  updateConfig(data, project) { return this._post(this._projUrl('/api/config', project), data); },
  getRepoConfig(name)     { return this._fetch(`/api/config/repo/${encodeURIComponent(name)}`); },
  updateRepoConfig(name, data) { return this._post(`/api/config/repo/${encodeURIComponent(name)}`, data); },
  getProjectConf(project) { return this._fetch(this._projUrl('/api/config/project', project)); },
  updateSettings(data)    { return this._post('/api/config/settings', data); },
  updateBranches(data, project) { return this._post(this._projUrl('/api/config/branches', project), data); },
  updateProperties(data, project) { return this._post(this._projUrl('/api/config/properties', project), data); },

  // Patches
  getPatches(search, status, body) {
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (status) params.set('status', status);
    if (body) params.set('body', '1');
    const q = params.toString();
    return this._fetch(`/api/patches${q ? '?' + q : ''}`);
  },
  getPatchContent(path) {
    return this._fetch(`/api/patches/${encodeURIComponent(path)}/content`);
  },
  getStatusValues() {
    return this._fetch('/api/patches/status-values');
  },
  updatePatchStatus(path, status, detail) {
    return this._post('/api/patches/status', { path, status, detail });
  },

  // B4
  b4Search(q)           { return this._fetch(`/api/b4/search?q=${encodeURIComponent(q)}`); },
  b4Apply(msgid, repo)  { return this._post('/api/b4/apply', { msgid, repo }); },

  // Recipes
  getRecipes(search) {
    const q = search ? `?search=${encodeURIComponent(search)}` : '';
    return this._fetch(`/api/recipes${q}`);
  },
  getRecipe(name) { return this._fetch(`/api/recipes/${encodeURIComponent(name)}`); },

  // Fragments
  getFragments()          { return this._fetch('/api/fragments'); },
  enableFragment(name)    { return this._post('/api/fragments/enable', { name }); },
  disableFragment(name)   { return this._post('/api/fragments/disable', { name }); },
  setBuiltinValue(prefix, value) { return this._post('/api/fragments/builtin', { prefix, value }); },
  getToolcfgPath()        { return this._fetch('/api/fragments/toolcfg'); },

  // Deps
  getLayerDeps()          { return this._fetch('/api/deps/layers'); },
  getLayerDep(name)       { return this._fetch(`/api/deps/layers/${encodeURIComponent(name)}`); },

  // Info
  getInfoVars()           { return this._fetch('/api/info/vars'); },
  getInfoLayers()         { return this._fetch('/api/info/layers'); },

  // Setup
  getSetupRegistry(project) { return this._fetch(this._projUrl('/api/setup/registry', project)); },
  setupClone(data)          { return this._post('/api/setup/clone', data); },
  setupApply(data, project) { return this._post(this._projUrl('/api/setup/apply', project), data); },
  getSetupExportPreview(project) { return this._fetch(this._projUrl('/api/setup/export/preview', project)); },
  setupExport(data, project){ return this._post(this._projUrl('/api/setup/export', project), data); },
  setupRegistryCopy(data)   { return this._post('/api/setup/registry-copy', data); },
  setupDescribe(data)       { return this._post('/api/setup/config/describe', data); },
  setupRename(data)         { return this._post('/api/setup/config/rename', data); },
  setupDelete(data)         { return this._post('/api/setup/config/delete', data); },

  // Export
  getExportPreview(project) { return this._fetch(this._projUrl('/api/export/preview', project)); },
  exportPatches(repo, commits) { return this._post('/api/export', { repo, commits }); },
  exportPrepare(data, project) { return this._post(this._projUrl('/api/export/prepare', project), data); },
  exportBatchPatches(data, project) { return this._post(this._projUrl('/api/export/patches', project), data); },
  getPrepState(project) { return this._fetch(this._projUrl('/api/export/prep-state', project)); },

  // Remote
  remoteSync(host)        { return this._post('/api/remote/sync', { host }); },
  getRemoteStatus(host)   { return this._fetch(`/api/remote/${encodeURIComponent(host)}/status`); },

  // Run command
  runCommand(command)     { return this._post('/api/run', { command }); },

  // File editor
  readFile(path)          { return this._fetch(`/api/file/read?path=${encodeURIComponent(path)}`); },
  writeFile(path, content){ return this._post('/api/file/write', { path, content }); },

  // Commit browser actions
  exportRepoPatches(name, commits, project) { return this._post(this._projUrl(`/api/repos/${encodeURIComponent(name)}/export-patches`, project), { commits }); },
  getRepoGraph(name, count, project) { return this._fetch(this._projUrl(`/api/repos/${encodeURIComponent(name)}/graph?count=${count || 50}`, project)); },
  dropCommits(name, commits, project) { return this._post(this._projUrl(`/api/repos/${encodeURIComponent(name)}/drop`, project), { commits }); },
  rebasePrepare(name, project, base) { return this._post(this._projUrl(`/api/repos/${encodeURIComponent(name)}/rebase-prepare`, project), base ? { base } : undefined); },
  getRepoLayers(name, project) { return this._fetch(this._projUrl(`/api/repos/${encodeURIComponent(name)}/layers`, project)); },
  getCommitLore(name, sha, project) { return this._fetch(this._projUrl(`/api/repos/${encodeURIComponent(name)}/commits/${encodeURIComponent(sha)}/lore`, project)); },
  getRepoTree(name, ref, project) {
    let url = `/api/repos/${encodeURIComponent(name)}/tree`;
    if (ref) url += '?ref=' + encodeURIComponent(ref);
    return this._fetch(this._projUrl(url, project));
  },
  getFileCommits(name, filepath, ref, limit, project) {
    const encodedPath = filepath.split('/').map(encodeURIComponent).join('/');
    let url = `/api/repos/${encodeURIComponent(name)}/files/${encodedPath}/commits`;
    const params = [];
    if (ref) params.push('ref=' + encodeURIComponent(ref));
    if (limit) params.push('limit=' + limit);
    if (params.length) url += '?' + params.join('&');
    return this._fetch(this._projUrl(url, project));
  },
  getCommitChangedFiles(name, sha, project) { return this._fetch(this._projUrl(`/api/repos/${encodeURIComponent(name)}/commits/${encodeURIComponent(sha)}/changed-files`, project)); },

  // Explore actions
  trackRepo(name, project)     { return this._post(this._projUrl(`/api/repos/${encodeURIComponent(name)}/track`, project)); },
  hideRepo(name, project)      { return this._post(this._projUrl(`/api/repos/${encodeURIComponent(name)}/hide`, project)); },
  pruneBackups(name, project)  { return this._post(this._projUrl(`/api/repos/${encodeURIComponent(name)}/prune-backups`, project)); },
  addLayer(layerPath, project) { return this._post(this._projUrl('/api/layers/add', project), { layer: layerPath }); },
  removeLayer(layerPath, project) { return this._post(this._projUrl('/api/layers/remove', project), { layer: layerPath }); },

  // Layer Index
  getLayerIndex(branch, project) {
    let url = '/api/layer-index';
    if (branch) url += '?branch=' + encodeURIComponent(branch);
    return this._fetch(this._projUrl(url, project));
  },
  getLayerDeps(name, branch) {
    let url = `/api/layer-index/${encodeURIComponent(name)}/deps`;
    if (branch) url += '?branch=' + encodeURIComponent(branch);
    return this._fetch(url);
  },

  // Filesystem
  listDirectory(path, host) {
    const params = new URLSearchParams();
    if (path) params.set('path', path);
    if (host) params.set('host', host);
    return this._fetch('/api/filesystem/ls?' + params);
  },

  // Messages
  getMessages(project)    { return this._fetch(this._projUrl('/api/messages', project)); },

  // Pull patches
  getPullRemotes()        { return this._fetch('/api/pull/remotes'); },
  pullMatchRepo(remoteProject, localRepoName, project) {
    return this._post(this._projUrl('/api/pull/match-repo', project), { remote_project: remoteProject, local_repo_name: localRepoName });
  },
  pullCommits(remoteProject, remoteRepo, localRepoName, project) {
    return this._post(this._projUrl('/api/pull/commits', project), { remote_project: remoteProject, remote_repo: remoteRepo, local_repo_name: localRepoName });
  },
  pullCommitShow(remoteProject, remoteRepo, commitHash) {
    return this._post('/api/pull/commit-show', { remote_project: remoteProject, remote_repo: remoteRepo, commit_hash: commitHash });
  },
  pullApply(remoteProject, remoteRepo, localRepoName, commits, method, project) {
    return this._post(this._projUrl('/api/pull/apply', project), { remote_project: remoteProject, remote_repo: remoteRepo, local_repo_name: localRepoName, commits, method });
  },

  // Themes
  getThemes()             { return this._fetch('/api/config/themes'); },
};
