import pandas as pd
import polars as pl
import numpy as np
import time
from typing import Optional, Literal
from dataclasses import dataclass

from .config import AttributionConfig
from .data_loader import DataLoader


@dataclass
class AttributionResult:
    """Container for attribution analysis results."""
    port_return: float
    bm_return: float
    relative_return: float
    allocation_effect: float
    selection_effect: float
    excess_return: float
    attribution_table: pd.DataFrame
    attribution_summary: pd.DataFrame
    df_cumret: pd.DataFrame


class AttributionAnalyzer:
    """
    Attribution analysis engine supporting both Brinson and Carino models.
    Supports both pandas and polars DataFrames for efficient computation.
    """

    def __init__(self, config: AttributionConfig, data_loader: Optional[DataLoader] = None, verbose: bool = False):
        self.config = config
        self.verbose = verbose
        self.loader = data_loader or DataLoader(config, verbose=verbose)

        # Cached data
        self._bm_holdings: Optional[pd.DataFrame] = None
        self._port_holdings: Optional[pd.DataFrame] = None
        self._df_tri: Optional[pd.DataFrame] = None
        self._df_sector: Optional[pd.DataFrame] = None

    def load_data(
        self,
        use_parallel: bool = False,
        convert_etf: bool = False,
    ) -> 'AttributionAnalyzer':
        """
        Load all required data. Returns self for method chaining.

        Args:
            use_parallel: If True, use multiprocessing for holdings loading (default: False)
            convert_etf: If True, convert ETF positions in portfolio to underlying
                equities using ETF PDF data (kr_stock only)
        """
        cfg = self.config
        ucfg = cfg.universe
        dcfg = cfg.dates
        t_total = time.time()

        # Load holdings (parallel or sequential)
        t0 = time.time()
        if use_parallel:
            self._bm_holdings, self._port_holdings = self.loader.load_holdings_parallel(
                convert_etf=convert_etf,
            )
        else:
            t_bm = time.time()
            self._bm_holdings = self.loader.load_holdings(cfg.benchmark_id, max_weight=None)
            if self.verbose:
                print(f"[BM] load_holdings: {time.time() - t_bm:.2f}s")
            t_port = time.time()
            self._port_holdings = self.loader.load_holdings(
                cfg.portfolio_id, max_weight=cfg.max_weight,
                convert_etf=convert_etf,
            )
            if self.verbose:
                print(f"[Port] load_holdings: {time.time() - t_port:.2f}s")
        if self.verbose:
            print(f"[Step 1] Holdings loaded: {time.time() - t0:.2f}s")

        # Add next date
        self._bm_holdings = self.loader.add_next_date(self._bm_holdings)
        self._port_holdings = self.loader.add_next_date(self._port_holdings)

        # Trim to date range
        start_dt = pd.to_datetime(dcfg.start, format='%Y%m%d')
        end_dt = pd.to_datetime(dcfg.end, format='%Y%m%d')

        self._bm_holdings = self._bm_holdings[
            (self._bm_holdings[ucfg.date_col] >= start_dt) &
            (self._bm_holdings[ucfg.date_col] <= end_dt)
        ]
        self._port_holdings = self._port_holdings[
            (self._port_holdings[ucfg.date_col] >= start_dt) &
            (self._port_holdings[ucfg.date_col] <= end_dt)
        ]

        # Match ending dates by next_date
        self._bm_holdings = self._bm_holdings[
            self._bm_holdings[ucfg.next_date_col] <= end_dt
        ]
        self._port_holdings = self._port_holdings[
            self._port_holdings[ucfg.next_date_col] <= end_dt
        ]

        # Collect all security/entity IDs
        total_sec_ids = list(
            set(self._bm_holdings[ucfg.id_col].unique()) |
            set(self._port_holdings[ucfg.id_col].unique()) -
            {ucfg.cash_id}
        )
        total_entity_ids = list(
            set(self._bm_holdings[ucfg.entity_col].unique()) |
            set(self._port_holdings[ucfg.entity_col].unique()) -
            {ucfg.cash_id}
        )

        # Load TRI and sector data
        t0 = time.time()
        if use_parallel:
            self._df_tri, self._df_sector = self.loader.load_data_parallel(
                total_sec_ids, total_entity_ids
            )
        else:
            self._df_tri = self.loader.load_tri_data(total_sec_ids)
            self._df_sector = self.loader.load_sector_data(total_entity_ids)
        if self.verbose:
            print(f"[Step 2] TRI & Sector loaded: {time.time() - t0:.2f}s")
            print(f"[Total] load_data: {time.time() - t_total:.2f}s")

        return self

    @property
    def bm_holdings(self) -> pd.DataFrame:
        if self._bm_holdings is None:
            raise RuntimeError("Data not loaded. Call load_data() first.")
        return self._bm_holdings

    @property
    def port_holdings(self) -> pd.DataFrame:
        if self._port_holdings is None:
            raise RuntimeError("Data not loaded. Call load_data() first.")
        return self._port_holdings

    @property
    def df_tri(self) -> pd.DataFrame:
        if self._df_tri is None:
            raise RuntimeError("Data not loaded. Call load_data() first.")
        return self._df_tri

    @property
    def df_sector(self) -> pd.DataFrame:
        if self._df_sector is None:
            raise RuntimeError("Data not loaded. Call load_data() first.")
        return self._df_sector

    def _safe_merge(self, df1, df2, **kwargs) -> pd.DataFrame:
        """Safe merge that handles both pandas and polars."""
        if isinstance(df1, pl.DataFrame) and isinstance(df2, pl.DataFrame):
            # Convert polars kwargs
            join_kwargs = {}
            if 'on' in kwargs:
                join_kwargs['on'] = kwargs['on']
            if 'left_on' in kwargs and 'right_on' in kwargs:
                join_kwargs['left_on'] = kwargs['left_on']
                join_kwargs['right_on'] = kwargs['right_on']
            if 'how' in kwargs:
                join_kwargs['how'] = kwargs['how']
            return df1.join(df2, **join_kwargs)
        else:
            return pd.merge(df1, df2, **kwargs)

    def _prepare_attribution_df(self, holdings: pd.DataFrame, df_tri: pd.DataFrame) -> pd.DataFrame:
        """Prepare DataFrame for attribution analysis by merging with TRI data."""
        ucfg = self.config.universe

        # Merge holdings with TRI
        df = holdings.merge(df_tri, on=[ucfg.date_col, ucfg.id_col], how='inner')

        # Merge with next TRI
        next_tri_col = 'Next' + ucfg.tri_col
        df_tri_next = df_tri[[ucfg.date_col, ucfg.id_col, ucfg.tri_col]].rename(columns={
            ucfg.date_col: ucfg.next_date_col,
            ucfg.tri_col: next_tri_col
        })
        df = df.merge(df_tri_next, on=[ucfg.next_date_col, ucfg.id_col], how='inner')

        # Calculate period return
        df['period_return'] = df[next_tri_col] / df[ucfg.tri_col] - 1
        df['period_return'] = df['period_return'].fillna(0)
        df[ucfg.category_col] = df[ucfg.category_col].fillna('Unknown')

        df = df.sort_values(
            by=[ucfg.date_col, ucfg.weight_col],
            ascending=[True, False]
        ).reset_index(drop=True)

        return df

    def _compute_attribution_carino(
        self,
        df_port: pd.DataFrame,
        df_bm: pd.DataFrame,
        normalize_weights:bool = False,
    ) -> dict:
        """Compute attribution using Carino model."""
        ucfg = self.config.universe
        date_col = ucfg.date_col
        next_date_col = ucfg.next_date_col
        id_col = ucfg.id_col
        weight_col = ucfg.weight_col
        category_col = ucfg.category_col

        # Drop NA and align dates
        df_port = df_port.dropna(subset=['period_return', category_col])
        df_bm = df_bm.dropna(subset=['period_return', category_col])

        port_dates = set(df_port[date_col].unique())
        bm_dates = set(df_bm[date_col].unique())
        common_dates = port_dates & bm_dates

        df_port = df_port[df_port[date_col].isin(common_dates)]
        df_bm = df_bm[df_bm[date_col].isin(common_dates)]

        # Normalize weights
        if normalize_weights:
            df_port[weight_col] = df_port.groupby(date_col)[weight_col].transform(lambda x: x / x.sum())
            df_bm[weight_col] = df_bm.groupby(date_col)[weight_col].transform(lambda x: x / x.sum())

        # Compute weighted returns
        df_port['weighted_return'] = df_port['period_return'] * df_port[weight_col]
        df_bm['weighted_return'] = df_bm['period_return'] * df_bm[weight_col]

        # Category aggregations
        df_port['category_weight'] = df_port.groupby([category_col, date_col, next_date_col])[weight_col].transform('sum')
        df_port['category_weighted_return'] = df_port.groupby([category_col, date_col, next_date_col])['weighted_return'].transform('sum')
        df_port['category_return'] = df_port['category_weighted_return'] / df_port['category_weight']

        df_bm['category_weight'] = df_bm.groupby([category_col, date_col, next_date_col])[weight_col].transform('sum')
        df_bm['category_weighted_return'] = df_bm.groupby([category_col, date_col, next_date_col])['weighted_return'].transform('sum')
        df_bm['category_return'] = df_bm['category_weighted_return'] / df_bm['category_weight']

        # Rename columns
        port_rename = {c: 'port_' + c for c in df_port.columns if c not in [date_col, category_col, next_date_col]}
        bm_rename = {c: 'bm_' + c for c in df_bm.columns if c not in [date_col, category_col, next_date_col]}

        df_port = df_port.rename(columns=port_rename)
        df_bm = df_bm.rename(columns=bm_rename)

        # Outer merge
        df_attr = pd.merge(
            df_port, df_bm,
            left_on=[date_col, 'port_' + id_col, category_col, next_date_col],
            right_on=[date_col, 'bm_' + id_col, category_col, next_date_col],
            how='outer'
        )

        # Fill NA
        fill_cols = ['port_' + weight_col, 'bm_' + weight_col, 'port_category_return',
                     'bm_category_return', 'port_weighted_return', 'bm_weighted_return']
        df_attr[fill_cols] = df_attr[fill_cols].fillna(0.0)

        # Compute intermediate values
        df_attr['wi-Wi'] = df_attr['port_' + weight_col] - df_attr['bm_' + weight_col]
        df_attr['Ri-Bi'] = df_attr['port_category_return'] - df_attr['bm_category_return']

        bm_period_sum = df_attr.groupby(date_col)['bm_weighted_return'].transform('sum')
        df_attr['Bi-B'] = df_attr['bm_category_return'] - bm_period_sum

        df_attr['allocation_effect'] = df_attr['wi-Wi'] * df_attr['Bi-B']
        df_attr['selection_effect'] = df_attr['port_' + weight_col] * df_attr['Ri-Bi']

        df_attr[id_col] = df_attr['port_' + id_col].fillna(df_attr['bm_' + id_col])

        # Carino smoothing factors
        port_cumret = (1 + df_attr.groupby(date_col)['port_weighted_return'].sum()).cumprod()
        bm_cumret = (1 + df_attr.groupby(date_col)['bm_weighted_return'].sum()).cumprod()

        r = port_cumret.iloc[-1] - 1.0
        b = bm_cumret.iloc[-1] - 1.0
        k = np.log((1 + r) / (1 + b)) / (r - b) if abs(r - b) > 1e-10 else 1 / (1 + r)

        rt = df_attr.groupby(date_col, as_index=False)['port_weighted_return'].sum().rename(columns={'port_weighted_return': 'rt'})
        bt = df_attr.groupby(date_col, as_index=False)['bm_weighted_return'].sum().rename(columns={'bm_weighted_return': 'bt'})

        factor = rt.merge(bt, on=date_col)
        factor['numer'] = np.log((factor['rt'] + 1) / (factor['bt'] + 1))
        factor['denom'] = factor['rt'] - factor['bt']
        factor['kt'] = np.where(
            np.abs(factor['denom'] / factor['bt']) > 1e-3,
            factor['numer'] / factor['denom'],
            1 / (1 + factor['rt'])
        )
        factor['factor'] = factor['kt'] / k

        df_attr = df_attr.merge(factor[[date_col, 'factor']], on=date_col, how='inner')
        df_attr['adj_allocation_effect'] = df_attr['allocation_effect'] * df_attr['factor']
        df_attr['adj_selection_effect'] = df_attr['selection_effect'] * df_attr['factor']

        # Aggregate results
        allocation_effect = df_attr['adj_allocation_effect'].sum()
        selection_effect = df_attr['adj_selection_effect'].sum()

        return {
            'port_return': r,
            'bm_return': b,
            'relative_return': r - b,
            'allocation_effect': allocation_effect,
            'selection_effect': selection_effect,
            'excess_return': allocation_effect + selection_effect,
            'df': df_attr
        }

    def run(self, drop_cash: bool = None) -> AttributionResult:
        """
        Run attribution analysis.

        Args:
            drop_cash: If True, exclude cash positions. If None, uses config.drop_cash (default: None)

        Returns:
            AttributionResult with all analysis results
        """
        cfg = self.config
        ucfg = cfg.universe
        drop_cash = cfg.drop_cash if drop_cash is None else drop_cash

        # Merge sector data with holdings
        bm_with_sector = self.bm_holdings.merge(
            self.df_sector,
            on=[ucfg.date_col, ucfg.entity_col],
            how='inner'
        )
        port_with_sector = self.port_holdings.merge(
            self.df_sector,
            on=[ucfg.date_col, ucfg.entity_col],
            how='inner'
        )

        # Validate date alignment
        assert bm_with_sector[ucfg.date_col].min() == port_with_sector[ucfg.date_col].min(), \
            "Start dates must match"
        assert bm_with_sector[ucfg.date_col].max() == port_with_sector[ucfg.date_col].max(), \
            "End dates must match"

        # Prepare attribution DataFrames
        df_port_attr = self._prepare_attribution_df(port_with_sector, self.df_tri)
        df_bm_attr = self._prepare_attribution_df(bm_with_sector, self.df_tri)

        # Drop cash rows if cash_id is set
        normalize_weights = True
        if drop_cash:
            normalize_weights = False
            if isinstance(df_port_attr, pl.DataFrame):
                df_port_attr = df_port_attr.filter(pl.col(ucfg.id_col) != ucfg.cash_id)
                df_bm_attr = df_bm_attr.filter(pl.col(ucfg.id_col) != ucfg.cash_id)
            else:
                df_port_attr = df_port_attr[df_port_attr[ucfg.id_col] != ucfg.cash_id]
                df_bm_attr = df_bm_attr[df_bm_attr[ucfg.id_col] != ucfg.cash_id]

        # Compute attribution
        if cfg.model == 'carino':
            result = self._compute_attribution_carino(df_port_attr, df_bm_attr, normalize_weights=normalize_weights)
        else:
            raise NotImplementedError(f"Model '{cfg.model}' not implemented in OOP version")

        # Compute summary
        attribution_table = result['df']
        summary = self._compute_summary(attribution_table)

        # Compute cumulative returns
        date_col = ucfg.date_col
        next_date_col = ucfg.next_date_col
        last_date = attribution_table[next_date_col].max()
        df_port_daily = attribution_table.groupby(date_col)['port_weighted_return'].sum()
        df_bm_daily = attribution_table.groupby(date_col)['bm_weighted_return'].sum()

        cumret_index = sorted(set(df_port_daily.index) | {last_date})
        df_cumret = pd.DataFrame(1.0, columns=['port_cumret', 'bm_cumret'], index=cumret_index)
        df_cumret.iloc[1:, df_cumret.columns.get_loc('port_cumret')] = (df_port_daily + 1).values
        df_cumret.iloc[1:, df_cumret.columns.get_loc('bm_cumret')] = (df_bm_daily + 1).values
        df_cumret = df_cumret.cumprod()

        return AttributionResult(
            port_return=result['port_return'],
            bm_return=result['bm_return'],
            relative_return=result['relative_return'],
            allocation_effect=result['allocation_effect'],
            selection_effect=result['selection_effect'],
            excess_return=result['excess_return'],
            attribution_table=attribution_table,
            attribution_summary=summary,
            df_cumret=df_cumret
        )

    def _compute_summary(self, attribution_table: pd.DataFrame) -> pd.DataFrame:
        """Compute attribution summary grouped by ID and category."""
        ucfg = self.config.universe

        summary = attribution_table.groupby(
            [ucfg.id_col, ucfg.category_col],
            as_index=False
        )[['adj_allocation_effect', 'adj_selection_effect']].sum()

        summary['relative_return'] = (
            summary['adj_allocation_effect'] + summary['adj_selection_effect']
        )

        return summary

    def get_periodic_results(self, drop_cash: bool = None, freq: str = None) -> tuple:
        """
        Get periodic attribution results.

        Args:
            drop_cash: If True, exclude cash positions. If None, uses config.drop_cash (default: None)
            freq: Frequency for periodic grouping ('D', 'W', 'M', 'Q', 'Y'). If None, uses config.freq (default: None)

        Returns:
            Tuple of (df_periodic, periodic_attribution_dict)
        """
        cfg = self.config
        ucfg = cfg.universe
        drop_cash = cfg.drop_cash if drop_cash is None else drop_cash
        freq = cfg.freq if freq is None else freq

        # Drop cash columns
        normalize_weights = True
        if drop_cash:
            bm_holdings = self.bm_holdings
            port_holdings = self.port_holdings
            normalize_weights = False

            # Filter out cash - handle both pandas and polars
            if isinstance(bm_holdings, pl.DataFrame):
                print("Polars Method!!")
                bm_holdings = bm_holdings.filter(pl.col(ucfg.id_col) != ucfg.cash_id)
                port_holdings = port_holdings.filter(pl.col(ucfg.id_col) != ucfg.cash_id)
            else:
                bm_holdings = bm_holdings[bm_holdings[ucfg.id_col] != ucfg.cash_id]
                port_holdings = port_holdings[port_holdings[ucfg.id_col] != ucfg.cash_id]

            # Merge sector data
            bm_with_sector = bm_holdings.merge(
                self.df_sector,
                on=[ucfg.date_col, ucfg.entity_col],
                how='inner'
            )
            port_with_sector = port_holdings.merge(
                self.df_sector,
                on=[ucfg.date_col, ucfg.entity_col],
                how='inner'
            )


        else:
            normalize_weights = True
            # Merge sector data
            bm_with_sector = self.bm_holdings.merge(
                self.df_sector,
                on=[ucfg.date_col, ucfg.entity_col],
                how='inner'
            )
            port_with_sector = self.port_holdings.merge(
                self.df_sector,
                on=[ucfg.date_col, ucfg.entity_col],
                how='inner'
            )



        # Prepare attribution DataFrames
        df_port_attr = self._prepare_attribution_df(port_with_sector, self.df_tri)
        df_bm_attr = self._prepare_attribution_df(bm_with_sector, self.df_tri)

        # Add periodic_date column
        df_port_attr['periodic_date'] = df_port_attr[ucfg.date_col].dt.to_period(freq)
        df_bm_attr['periodic_date'] = df_bm_attr[ucfg.date_col].dt.to_period(freq)

        # Group by period
        unique_periods = sorted(set(df_port_attr['periodic_date'].unique()) |
                                set(df_bm_attr['periodic_date'].unique()))

        periodic_results = []
        periodic_dict = {}

        for period in unique_periods:
            df_port_period = df_port_attr[df_port_attr['periodic_date'] == period]
            df_bm_period = df_bm_attr[df_bm_attr['periodic_date'] == period]

            if df_port_period.empty or df_bm_period.empty:
                continue

            try:
                result = self._compute_attribution_carino(df_port_period, df_bm_period, normalize_weights=normalize_weights)

                periodic_results.append({
                    ucfg.date_col: period,
                    'port_return': result['port_return'],
                    'bm_return': result['bm_return'],
                    'relative_return': result['relative_return'],
                    'allocation_effect': result['allocation_effect'],
                    'selection_effect': result['selection_effect'],
                    'excess_return': result['excess_return']
                })

                attribution_table = result['df']
                attribution_summary = self._compute_summary(attribution_table)

                periodic_dict[period] = AttributionResult(
                    port_return=result['port_return'],
                    bm_return=result['bm_return'],
                    relative_return=result['relative_return'],
                    allocation_effect=result['allocation_effect'],
                    selection_effect=result['selection_effect'],
                    excess_return=result['excess_return'],
                    attribution_table=attribution_table,
                    attribution_summary=attribution_summary,
                    df_cumret=pd.DataFrame(),
                )

            except Exception as e:
                print(f"Error in period {period}: {e}")
                continue

        df_periodic = pd.DataFrame(periodic_results)
        return df_periodic, periodic_dict

    def get_active_share(self, attribution_table: pd.DataFrame) -> pd.Series:
        """
        Calculate active share by date from attribution table.

        Args:
            attribution_table: Attribution table from run() result containing 'wi-Wi' column

        Returns:
            Series with active share values indexed by date
        """
        date_col = self.config.universe.date_col
        active_share = attribution_table.groupby(date_col)['wi-Wi'].apply(
            lambda x: x.abs().sum() / 2
        )
        return active_share

    def get_time_averaged_weights(self, result: AttributionResult = None) -> pd.DataFrame:
        """
        Calculate time-averaged weights for each security across all periods.

        This method aggregates portfolio and benchmark weights over time for each security,
        providing a view of average positioning. The time-averaged weights are useful for:
        - Understanding long-term portfolio tilts vs benchmark
        - Identifying persistent overweight/underweight positions
        - Analyzing the contribution of position sizing to attribution effects

        The 'wi-Wi' column represents the active weight (portfolio weight minus benchmark weight)
        for each security, which is a key input for allocation effect calculations.

        Args:
            result: Pre-computed AttributionResult from run(). If None, runs attribution
                analysis with drop_cash=False to generate the result. Passing a pre-computed
                result avoids redundant computation when you've already run the analysis.

        Returns:
            pd.DataFrame: DataFrame indexed by security ID with the following columns:
                - {id_col}: Security identifier
                - port_weight: Sum of portfolio weights across all periods
                - bm_weight: Sum of benchmark weights across all periods
                - wi-Wi: Sum of active weights (port_weight - bm_weight) across all periods
                - normalized_port_weight: Portfolio weight normalized to sum to 1.0
                - normalized_bm_weight: Benchmark weight normalized to sum to 1.0

        Example:
            >>> analyzer = AttributionAnalyzer(config).load_data()
            >>> result = analyzer.run()
            >>> weights = analyzer.get_time_averaged_weights(result)
            >>> # Find top overweight positions
            >>> weights.nlargest(10, 'wi-Wi')
        """
        # Use provided result or compute fresh attribution analysis
        result = self.run(drop_cash=False) if result is None else result
        attr_table = result.attribution_table
        ucfg = self.config.universe

        # Ensure active weight column exists (port weight - benchmark weight)
        if 'wi-Wi' not in attr_table.columns:
            attr_table['wi-Wi'] = attr_table['port_weight'] - attr_table['bm_weight']

        # Aggregate weights by security across all time periods
        weights = attr_table.groupby(ucfg.id_col, as_index=False)[
            ['port_weight', 'bm_weight', 'wi-Wi']
        ].sum()

        # Normalize weights to sum to 1.0 for comparable cross-sectional analysis
        weights['normalized_port_weight'] = weights['port_weight'] / weights['port_weight'].sum()
        weights['normalized_bm_weight'] = weights['bm_weight'] / weights['bm_weight'].sum()

        return weights

    def get_security_attributions(self, attribution_table: pd.DataFrame, drop_cash: bool = None) -> pd.DataFrame:
        """
        Aggregate attribution effects by security across all periods.

        Concatenates all periodic attribution DataFrames and groups by security ID
        to compute mean portfolio weight and summed allocation/selection effects.

        Args:
            attribution_table: DataFrame from run() or get_periodic_results().
                If None, calls get_periodic_results() to generate it.
            drop_cash: If True, exclude cash positions. If None, uses config.drop_cash.

        Returns:
            pd.DataFrame with columns:
                - port_weight_mean: Mean portfolio weight across all periods
                - allocation_effect_sum: Sum of adjusted allocation effects
                - selection_effect_sum: Sum of adjusted selection effects
        """

        ucfg = self.config.universe
        id_col = ucfg.id_col


        summary = attribution_table.groupby(id_col, as_index=False).agg(
            port_weight_mean=('port_' + ucfg.weight_col, 'mean'),
            allocation_effect=('adj_allocation_effect', 'sum'),
            selection_effect=('adj_selection_effect', 'sum'),
        ).sort_values('port_weight_mean', ascending=False)

        return summary

    def get_security_attribution(self, result: AttributionResult = None) -> pd.DataFrame:
        """
        Compute a combined per-security summary with time-averaged weights,
        attribution effects, and stock info.

        Args:
            result: Pre-computed AttributionResult from run(). If None, runs
                attribution analysis with drop_cash=False.

        Returns:
            pd.DataFrame with columns: id_col, port_weight, bm_weight, wi-Wi,
                normalized_port_weight, normalized_bm_weight, allocation_effect,
                selection_effect, and stock info columns (e.g. conml, tic).
        """
        result = self.run(drop_cash=False) if result is None else result
        ucfg = self.config.universe
        id_col = ucfg.id_col

        weights = self.get_time_averaged_weights(result)
        attributions = self.get_security_attributions(result.attribution_table)
        summary = weights.merge(attributions[[id_col, 'allocation_effect', 'selection_effect']], on=id_col, how='left')
        summary = self.loader.incorporate_stock_info(summary)

        return summary.sort_values('normalized_port_weight', ascending=False)

    def get_sector_attribution(self, attribution_summary: pd.DataFrame) -> pd.DataFrame:
        """
        Aggregate attribution effects by sector with sector names.

        Args:
            attribution_summary: The attribution_summary DataFrame from
                AttributionResult (grouped by id_col and category_col).

        Returns:
            pd.DataFrame indexed by sector_name with columns:
                - adj_allocation_effect: Sum of adjusted allocation effects
                - adj_selection_effect: Sum of adjusted selection effects
                - relative_return: Sum of relative returns
        """
        ucfg = self.config.universe
        category_col = ucfg.category_col

        sector_summary = attribution_summary.groupby(category_col)[[
            'adj_allocation_effect', 'adj_selection_effect', 'relative_return'
        ]].sum().sort_values('relative_return', ascending=False).reset_index()

        sector_summary = self.loader.incorporate_sector_info(sector_summary, sector_col=category_col)

        return sector_summary[['sector_name',
            'adj_allocation_effect', 'adj_selection_effect', 'relative_return'
        ]]


