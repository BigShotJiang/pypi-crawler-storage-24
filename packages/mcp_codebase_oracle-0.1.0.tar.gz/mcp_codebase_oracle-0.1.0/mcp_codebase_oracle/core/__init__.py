"""Çekirdek analiz motorları."""
