"""MCP Tool tanımları."""
