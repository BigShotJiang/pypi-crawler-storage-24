"""MCP Prompt tanımları."""
