"""Yardımcı modüller."""
