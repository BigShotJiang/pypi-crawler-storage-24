"""MCP Resource tanımları."""
