"""Tests for PyEye Server."""
