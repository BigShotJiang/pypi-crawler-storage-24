# !/usr/bin/env python
# -*- coding: utf-8 -*-
# =====================================================
# @File   ：__init__.py
# @Date   ：2025/11/25 22:18
# @Author ：leemysw

# 2025/11/25 22:18   Create
# =====================================================

version_info = (0, 3, 2)
__version__ = ".".join([str(v) for v in version_info])
