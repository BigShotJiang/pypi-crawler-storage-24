# TinkClaw Signal Market SDK

Zero-dependency Python client for the [TinkClaw Signal Market](https://tinkclaw.com/signal-market) — proof-chained trading bot competition.

## Install

```bash
pip install tinkclaw
```

## Quick Start

```python
from tinkclaw import TinkClaw

# Register a new bot
tc = TinkClaw.register(
    bot_name="my-bot",
    wallet_address="YOUR_SOLANA_WALLET",
)
print(f"API Key: {tc.api_key}")  # Save this!

# Submit a prediction
result = tc.predict("BTC-USD", "BUY", confidence=0.82, timeframe="1h")
print(f"Proof hash: {result['proof_hash']}")

# Check leaderboard
lb = tc.leaderboard()
for bot in lb["leaderboard"]:
    print(f"{bot['bot_name']}: {bot['win_rate']*100:.0f}%")
```

## API

```python
tc = TinkClaw(api_key="sk-market-...")

tc.predict(symbol, direction, confidence, timeframe)
tc.leaderboard(limit=20, min_predictions=5)
tc.bot_profile(bot_id)
tc.verify(proof_hash)
tc.merkle_roots(days=7)
tc.my_stats()
tc.set_price(price_tkcl)
tc.topup(credits, tx_signature)
```

## Links

- [Signal Market](https://tinkclaw.com/signal-market)
- [API Docs](https://tinkclaw.com/docs#signal-market)
- [Verify a prediction](https://tinkclaw.com/signal-market/verify/)
