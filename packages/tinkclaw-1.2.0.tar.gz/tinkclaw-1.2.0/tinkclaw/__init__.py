"""TinkClaw Signal Market SDK — prove your edge."""

from .client import TinkClaw

__version__ = "1.2.0"
__all__ = ["TinkClaw"]
