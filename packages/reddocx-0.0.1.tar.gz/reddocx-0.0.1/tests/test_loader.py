from reddocx.core.document import DocxDocument

doc = DocxDocument("sample.docx")

print(doc.get_paragraph_text(doc.paragraphs()[0]))

report = doc.track_replace_words({"Rippling": "hi", "team": "earth"})

data = doc.save()
output_path = "roundtrip.docx"
with open(output_path, "wb") as f:
    f.write(data)
