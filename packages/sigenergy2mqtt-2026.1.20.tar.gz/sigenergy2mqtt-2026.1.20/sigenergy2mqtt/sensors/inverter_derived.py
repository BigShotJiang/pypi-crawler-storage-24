import logging

import paho.mqtt.client as mqtt

from sigenergy2mqtt.common import Protocol
from sigenergy2mqtt.config import Config
from sigenergy2mqtt.modbus.types import ModbusClientType, ModbusDataType

from .base import DerivedSensor, DeviceClass, EnergyDailyAccumulationSensor, EnergyLifetimeAccumulationSensor, Sensor, StateClass
from .const import UnitOfPower
from .inverter_read_only import ChargeDischargePower, PVCurrentSensor, PVVoltageSensor


class InverterBatteryChargingPower(DerivedSensor):
    def __init__(self, plant_index: int, device_address: int, battery_power: ChargeDischargePower):
        super().__init__(
            name="Battery Charging Power",
            unique_id=f"{Config.home_assistant.unique_id_prefix}_{plant_index}_inverter_{device_address}_battery_charging_power",
            object_id=f"{Config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_battery_charging_power",
            data_type=ModbusDataType.INT32,
            unit=UnitOfPower.WATT,
            device_class=battery_power.device_class,
            state_class=battery_power.state_class,
            icon="mdi:battery-plus",
            gain=None,
            precision=2,
        )
        self.protocol_version = battery_power.protocol_version

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "ChargeDischargePower &gt; 0"
        return attributes

    def set_source_values(self, sensor: Sensor, values: list) -> bool:
        if not isinstance(sensor, ChargeDischargePower):
            logging.warning(f"Attempt to call {self.__class__.__name__}.set_source_values from {sensor.__class__.__name__}")
            return False
        self.set_latest_state(
            0 if values[-1][1] <= 0 else round(values[-1][1], self.precision),
        )
        return True


class InverterBatteryDischargingPower(DerivedSensor):
    def __init__(self, plant_index: int, device_address: int, battery_power: ChargeDischargePower):
        super().__init__(
            name="Battery Discharging Power",
            unique_id=f"{Config.home_assistant.unique_id_prefix}_{plant_index}_inverter_{device_address}_battery_discharging_power",
            object_id=f"{Config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_battery_discharging_power",
            data_type=ModbusDataType.INT32,
            unit=UnitOfPower.WATT,
            device_class=battery_power.device_class,
            state_class=battery_power.state_class,
            icon="mdi:battery-minus",
            gain=None,
            precision=2,
        )
        self.protocol_version = battery_power.protocol_version

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "ChargeDischargePower &lt; 0 &times; -1"
        return attributes

    def set_source_values(self, sensor: Sensor, values: list) -> bool:
        if not isinstance(sensor, ChargeDischargePower):
            logging.warning(f"Attempt to call {self.__class__.__name__}.set_source_values from {sensor.__class__.__name__}")
            return False
        self.set_latest_state(
            0 if values[-1][1] >= 0 else round(values[-1][1] * -1, self.precision),
        )
        return True


class PVStringPower(DerivedSensor):
    def __init__(self, plant_index: int, device_address: int, string_number: int, protocol_version: Protocol, voltage: PVVoltageSensor, current: PVCurrentSensor):
        super().__init__(
            name="Power",
            unique_id=f"{Config.home_assistant.unique_id_prefix}_{plant_index}_inverter_{device_address}_pv{string_number}_power",
            object_id=f"{Config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_pv{string_number}_power",
            data_type=ModbusDataType.INT32,
            unit=UnitOfPower.WATT,
            device_class=DeviceClass.POWER,
            state_class=StateClass.MEASUREMENT,
            icon="mdi:home-lightning-bolt",
            gain=None,
            precision=2,
            protocol_version=protocol_version,
        )
        self.string_number = string_number
        self.current: float | None = None
        self.current_gain: float = current.gain
        self.voltage: float | None = None
        self.voltage_gain: float = voltage.gain
        self.protocol_version = max(voltage.protocol_version, current.protocol_version)

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "PVVoltageSensor &times; PVCurrentSensor"
        return attributes

    async def publish(self, mqtt_client: mqtt.Client, modbus_client: ModbusClientType | None, republish: bool = False) -> bool:
        if self.voltage is None or self.current is None:
            if self.debug_logging:
                logging.debug(f"{self.__class__.__name__} Publishing SKIPPED - current={self.current} voltage={self.voltage}")
            return False  # until all values populated, can't do calculation
        if self.debug_logging:
            logging.debug(f"{self.__class__.__name__} Publishing READY   - current={self.current} voltage={self.voltage}")
        await super().publish(mqtt_client, modbus_client, republish=republish)
        # reset internal values to missing for next calculation
        self.voltage = None
        self.current = None
        return True

    def set_source_values(self, sensor: Sensor, values: list) -> bool:
        if isinstance(sensor, PVVoltageSensor):
            self.voltage = values[-1][1] / self.voltage_gain
        elif isinstance(sensor, PVCurrentSensor):
            self.current = values[-1][1] / self.current_gain
        else:
            logging.warning(f"Attempt to call {self.__class__.__name__}.set_source_values from {sensor.__class__.__name__}")
            return False
        if self.voltage is None or self.current is None:
            return False  # until all values populated, can't do calculation
        self.set_latest_state(self.voltage * self.current)
        return True


class PVStringLifetimeEnergy(EnergyLifetimeAccumulationSensor):
    def __init__(self, plant_index: int, device_address: int, string_number: int, protocol_version: Protocol, source: PVStringPower):
        super().__init__(
            name="Lifetime Production",
            unique_id=f"{Config.home_assistant.unique_id_prefix}_{plant_index}_inverter_{device_address}_pv{string_number}_lifetime_energy",
            object_id=f"{Config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_pv{string_number}_lifetime_energy",
            source=source,
        )
        self.string_number = string_number
        self.protocol_version = protocol_version

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "Riemann &sum; of PVStringPower"
        return attributes


class PVStringDailyEnergy(EnergyDailyAccumulationSensor):
    def __init__(self, plant_index: int, device_address: int, string_number: int, protocol_version: Protocol, source: PVStringLifetimeEnergy):
        super().__init__(
            name="Daily Production",
            unique_id=f"{Config.home_assistant.unique_id_prefix}_{plant_index}_inverter_{device_address}_pv{string_number}_daily_energy",
            object_id=f"{Config.home_assistant.entity_id_prefix}_{plant_index}_inverter_{device_address}_pv{string_number}_daily_energy",
            source=source,
        )
        self.string_number = string_number
        self.protocol_version = protocol_version

    def get_attributes(self) -> dict[str, float | int | str]:
        attributes = super().get_attributes()
        attributes["source"] = "PVStringLifetimeEnergy &minus; PVStringLifetimeEnergy at last midnight"
        return attributes
