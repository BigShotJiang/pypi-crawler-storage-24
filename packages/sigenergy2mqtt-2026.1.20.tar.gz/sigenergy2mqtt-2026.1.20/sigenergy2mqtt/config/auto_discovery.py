import asyncio
import ipaddress
import logging
import threading
import time
from queue import Queue
from typing import cast

import psutil
from pymodbus import ExceptionResponse, FramerType, ModbusException
from pymodbus.client import AsyncModbusTcpClient
from scapy.all import ICMP, IP, sr1  # type: ignore


def ping_worker(ip_queue: Queue[str], found_hosts: dict[str, float], timeout: float) -> None:
    while not ip_queue.empty():
        ip = ip_queue.get()
        pkt = IP(dst=ip) / ICMP()
        ans = sr1(pkt, timeout=timeout, verbose=0)
        if ans:
            rx = ans[0][1]  # type: ignore
            tx = ans[0][0]  # type: ignore
            found_hosts[ip] = rx.time - (tx.sent_time if tx.sent_time is not None else tx.time)
        ip_queue.task_done()


def ping_scan(ip_list: list[str], threads=100, timeout=0.5) -> dict[str, float]:
    ip_queue: Queue[str] = Queue()
    found_hosts: dict[str, float] = {}

    for ip in ip_list:
        ip_queue.put(ip)

    for _ in range(threads):
        t = threading.Thread(target=ping_worker, args=(ip_queue, found_hosts, timeout))
        t.daemon = True
        t.start()

    ip_queue.join()
    return found_hosts


async def probe_register(modbus: AsyncModbusTcpClient, address: int, count: int = 1, device_id: int = 247) -> bool:
    try:
        result = await modbus.read_input_registers(address=address, count=count, device_id=device_id)
        if result and not result.isError() and hasattr(result, "registers") and len(result.registers) >= count:
            return True
    except ModbusException:
        while not modbus.connected:
            modbus.close()
            await modbus.connect()
    except Exception as e:
        logging.debug(f"Unexpected error during Modbus probe for {modbus.comm_params.host}:{modbus.comm_params.port} at address {address} with device_id {device_id}: {e}")
    return False


async def get_serial_number(modbus: AsyncModbusTcpClient, device_id: int = 1) -> str | None:
    try:
        rr = await modbus.read_input_registers(address=30515, count=10, device_id=device_id)
        if rr and not rr.isError() and not isinstance(rr, ExceptionResponse) and hasattr(rr, "registers") and len(rr.registers) >= 10:
            serial = modbus.convert_from_registers(rr.registers, AsyncModbusTcpClient.DATATYPE.STRING)
            return cast(str, serial)
    except ModbusException as e:
        logging.debug(f"Failed to retrieve serial number for {modbus.comm_params.host}:{modbus.comm_params.port} device_id {device_id}: {e}")
    except Exception as e:
        logging.debug(f"Unexpected error when acquiring serial number for {modbus.comm_params.host}:{modbus.comm_params.port} device_id {device_id}: {e}")
    return None


serial_numbers = []


async def scan_host(ip: str, port: int, results: list, timeout: float = 0.25, retries: int = 0) -> None:
    modbus = AsyncModbusTcpClient(host=ip, port=port, framer=FramerType.SOCKET, timeout=timeout, retries=retries)
    try:
        await modbus.connect()
        if modbus.connected:
            try:
                logging.info(f"Found Modbus device at {ip}:{port}")
                ac_chargers: list[int] = []
                dc_chargers: list[int] = []
                inverters: list[int] = []
                device: dict[str, str | int | list[int]] = {"host": ip, "port": port, "ac-chargers": ac_chargers, "dc-chargers": dc_chargers, "inverters": inverters}
                if await probe_register(modbus, address=30051, device_id=247):  # Plant running state
                    logging.info(f" -> Found Sigenergy Plant at {ip}:{port}")
                    for device_id in range(1, 247):
                        if await probe_register(modbus, address=31501, device_id=device_id):  # [DC Charger] Charging current
                            serial = await get_serial_number(modbus, device_id=device_id)
                            if serial:
                                if serial not in serial_numbers:
                                    serial_numbers.append(serial)
                                    logging.info(f" -> Found Inverter {device_id} ({serial}) and DC-Charger at {ip}:{port}: Device ID={device_id}")
                                    dc_chargers.append(device_id)
                                    inverters.append(device_id)
                                else:
                                    logging.info(f" -> IGNORED Inverter {device_id} at {ip}:{port} - serial number {serial} already discovered")
                                continue
                        if await probe_register(modbus, address=30578, device_id=device_id):  # Inverter Running state
                            serial = await get_serial_number(modbus, device_id=device_id)
                            if serial:
                                if serial not in serial_numbers:
                                    serial_numbers.append(serial)
                                    logging.info(f" -> Found Inverter {device_id} ({serial}) at {ip}:{port}: Device ID={device_id}")
                                    inverters.append(device_id)
                                else:
                                    logging.info(f" -> IGNORED Inverter {device_id} at {ip}:{port} - serial number {serial} already discovered")
                                continue
                        if len(inverters) > 0 and await probe_register(modbus, address=32000, device_id=device_id):  # AC Charger System state
                            logging.info(f" -> Found AC-Charger at {ip}:{port}: Device ID={device_id}")
                            ac_chargers.append(device_id)
                            continue
                    if len(inverters) == 0 and len(dc_chargers) == 0 and len(ac_chargers) == 0:
                        logging.info(f" -> Ignored Modbus device at {ip}:{port}: No new inverters or chargers found")
                    else:
                        results.append(device)
                else:
                    logging.info(f" -> Ignored Modbus device at {ip}: No Plant running state found")
            finally:
                modbus.close()
    except ModbusException as e:
        logging.debug(f"Modbus connection to {ip}:{port} failed: {e}")


def scan(port: int = 502, ping_timeout: float = 0.5, modbus_timeout: float = 0.25, modbus_retries: int = 0) -> list[dict[str, str | int | list[int]]]:
    logging.getLogger("pymodbus").setLevel(logging.CRITICAL)
    logging.getLogger("scapy").setLevel(logging.CRITICAL)

    started = time.perf_counter()

    networks = {}
    for iface_name, iface_info in psutil.net_if_addrs().items():
        if "docker" not in iface_name and iface_name not in ("lo", "hassio") and not iface_name.startswith("br-") and not iface_name.startswith("veth"):
            for addr in iface_info:
                if addr.family.name == "AF_INET" and not addr.address.startswith("127."):
                    ip = addr.address
                    netmask = addr.netmask
                    if ip and netmask:
                        network = f"{ip}/{netmask}"
                        networks[ip] = ipaddress.IPv4Network(network, strict=False)
                        logging.info(f"Found network '{iface_name}' {networks[ip]} via {network}")
                        break

    active_ips: dict[str, float] = {"127.0.0.1": 0.0}  # Scan localhost first
    for addr, subnet in networks.items():
        logging.info(f"Scanning for active devices in network {subnet.with_prefixlen}...")
        all_ips: list[str] = [str(ip) for ip in subnet.hosts()]
        missing_ips: list[str] = [ip for ip in all_ips if ip != addr]
        ping_results: dict[str, float] = ping_scan(missing_ips, timeout=ping_timeout)
        active_ips.update(ping_results)
    ips_sorted_by_latency = dict(sorted(active_ips.items(), key=lambda item: item[1]))

    loop = asyncio.new_event_loop()
    results = []
    for ip in ips_sorted_by_latency:
        loop.run_until_complete(scan_host(ip, port, results, modbus_timeout, modbus_retries))
    loop.close()

    elapsed = time.perf_counter() - started
    logging.info(f"Scan completed in {elapsed:.2f} seconds")

    return results


if __name__ == "__main__":
    logging.getLogger("root").setLevel(logging.DEBUG)
    results = scan(502, 0.5, 0.25, 0)
    logging.info(f"Auto-discovered: {results}")
