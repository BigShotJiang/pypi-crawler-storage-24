import logging
from dataclasses import dataclass
from typing import Any, cast

from .validation import check_bool, check_int, check_string


@dataclass
class HomeAssistantConfiguration:
    enabled: bool = False

    edit_percentage_with_box: bool = False
    discovery_only: bool = False
    republish_discovery_interval: int = 0
    use_simplified_topics: bool = False

    discovery_prefix: str = "homeassistant"
    entity_id_prefix: str = "sigen"
    unique_id_prefix: str = "sigen"
    device_name_prefix: str = ""

    enabled_by_default: bool = False

    def validate(self) -> None:
        if self.enabled:
            if not self.discovery_prefix:
                raise ValueError("home-assistant.discovery-prefix must be provided")
            if not self.entity_id_prefix:
                raise ValueError("home-assistant.entity-id-prefix must be provided")
            if not self.unique_id_prefix:
                raise ValueError("home-assistant.unique-id-prefix must be provided")

    def configure(self, config: Any, override: bool = False) -> None:
        if isinstance(config, dict):
            if "enabled" in config:
                logging.debug(f"Applying {'override from env/cli' if override else 'configuration'}: home-assistant.enabled = {config['enabled']}")
                self.enabled = check_bool(config["enabled"], "home-assistant.enabled")
            if self.enabled:
                for field, value in config.items():
                    if field != "enabled":
                        logging.debug(f"Applying {'override from env/cli' if override else 'configuration'}: home-assistant.{field} = {value}")
                    match field:
                        case "device-name-prefix":
                            self.device_name_prefix = cast(str, check_string(value, f"home-assistant.{field}", allow_none=False, allow_empty=True))
                        case "discovery-only":
                            self.discovery_only = check_bool(value, f"home-assistant.{field}")
                        case "discovery-prefix":
                            self.discovery_prefix = cast(str, check_string(value, f"home-assistant.{field}", allow_none=False, allow_empty=False))
                        case "edit-pct-box":
                            self.edit_percentage_with_box = check_bool(value, f"home-assistant.{field}")
                        case "entity-id-prefix":
                            self.entity_id_prefix = cast(str, check_string(value, f"home-assistant.{field}", allow_none=False, allow_empty=False))
                        case "republish-discovery-interval":
                            self.republish_discovery_interval = cast(int, check_int(value, f"home-assistant.{field}", min=0))
                        case "sensors-enabled-by-default":
                            self.enabled_by_default = check_bool(value, f"home-assistant.{field}")
                        case "unique-id-prefix":
                            self.unique_id_prefix = cast(str, check_string(value, f"home-assistant.{field}", allow_none=False, allow_empty=False))
                        case "use-simplified-topics":
                            self.use_simplified_topics = check_bool(value, f"home-assistant.{field}")
                        case _:
                            if field != "enabled":
                                raise ValueError(f"home-assistant.configuration element contains unknown option '{field}'")
        else:
            raise ValueError("home-assistant configuration element must contain options and their values")
