from __future__ import annotations

import csv
from pathlib import Path
from typing import Sequence

from tqdm import tqdm

from .utils import ensure_directory, normalize_extensions, transfer_file, validate_directory, validate_file, validate_operation


def organize_by_labels(
    image_dir: str | Path,
    label_file: str | Path,
    output: str | Path,
    mode: str = 'copy',
    extensions: Sequence[str] | None = None,
    delimiter: str = ',',
) -> dict[str, list[Path]]:
    """
    Organize images into class-based folders using a CSV label file.

    The CSV file must contain at least two columns:
        - "path": relative filename of the image
        - "class": label/category name

    Example CSV:
        path,class
        img1.jpg,cats
        img2.jpg,dogs

    Given:
        image_dir/
            img1.jpg
            img2.jpg

    Running:
        organize_by_labels(
            image_dir="image_dir",
            label_file="labels.csv",
            output="organized"
        )

    Creates:
        organized/
            cats/
                img1.jpg
            dogs/
                img2.jpg

    Args:
        image_dir:
            Directory containing all images.
        label_file:
            CSV file mapping image filenames to class labels.
        output:
            Directory where class-based folders will be created.
        mode:
            File transfer mode: 'copy' or 'move'.
        extensions:
            Optional list of allowed file extensions (e.g., ['.jpg', '.png']).
            If provided, images with other extensions will raise an error.
        delimiter:
            CSV delimiter (default is comma).

    Returns:
        A dictionary mapping:
            class label → list of Path objects for transferred images

        Example:
            {
                "cats": [Path(...), Path(...)],
                "dogs": [Path(...)]
            }

    Raises:
        FileNotFoundError:
            If the image directory, label file, or any listed image is missing.
        ValueError:
            If a row has missing values or an unsupported file extension.
    """
    mode = validate_operation(mode)
    allowed = set(normalize_extensions(extensions))
    image_root = validate_directory(image_dir, 'Image directory')
    labels_path = validate_file(label_file, 'Label file')
    output_dir = ensure_directory(output)

    organized: dict[str, list[Path]] = {}

    with labels_path.open('r', encoding='utf-8', newline='') as handle:
        reader = list(csv.DictReader(handle, delimiter=delimiter))

        for row_number, row in enumerate(tqdm(reader, desc="Organizing images"), start=1):
            if not row:
                continue

            filename = (row.get("path") or "").strip()
            label = (row.get("class") or "").strip()

            if not filename or not label:
                raise ValueError(f'Row {row_number} contains an empty filename or label.')

            image_path = image_root / filename

            if not image_path.exists() or not image_path.is_file():
                raise FileNotFoundError(f'Image listed in label file not found: {image_path}')

            if allowed and image_path.suffix.lower() not in allowed:
                raise ValueError(f'Unsupported file extension for image: {image_path.name}')

            class_dir = ensure_directory(output_dir / label)
            destination = class_dir / image_path.name

            organized.setdefault(label, []).append(
                transfer_file(image_path, destination, operation=mode)
            )

    return organized