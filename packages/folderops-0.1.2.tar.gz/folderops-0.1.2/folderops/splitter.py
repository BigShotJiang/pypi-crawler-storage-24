from __future__ import annotations

import random
from pathlib import Path
from typing import Sequence

from tqdm import tqdm

from .utils import ensure_directory, normalize_extensions, transfer_file, validate_operation


def split_dataset(
    source: str | Path,
    output: str | Path,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int | None = 42,
    mode: str = "copy",
    extensions: Sequence[str] | None = None,
) -> dict[str, dict[str, list[Path]]]:
    """
    Split a dataset organized by class folders into train, validation, and test sets.

    The source directory must follow this structure:
        source/
            class1/
                img1.jpg
                img2.jpg
            class2/
                img3.jpg
                ...

    The function randomly splits images within each class and creates
    the following structure in the output directory:

        output/
            train/
                class1/
                class2/
            val/
                class1/
                class2/
            test/
                class1/
                class2/

    Example:
        split_dataset(
            source="dataset",
            output="dataset_split",
            train_ratio=0.7,
            val_ratio=0.15,
            test_ratio=0.15
        )

    Args:
        source:
            Path to the dataset directory containing class subfolders.
        output:
            Directory where the split dataset will be created.
        train_ratio:
            Proportion of data used for training.
        val_ratio:
            Proportion of data used for validation.
        test_ratio:
            Proportion of data used for testing.
        seed:
            Random seed for reproducibility. If None, randomness is not fixed.
        mode:
            File operation mode: 'copy' or 'move'.
        extensions:
            Optional list of allowed file extensions (e.g., ['.jpg', '.png']).
            If None, all files are included.

    Returns:
        A nested dictionary mapping:
            split → class → list of file paths

        Example:
            {
                "train": {"cats": [...], "dogs": [...]},
                "val": {"cats": [...], "dogs": [...]},
                "test": {"cats": [...], "dogs": [...]}
            }

    Raises:
        FileNotFoundError: If the source directory does not exist.
        ValueError: If no class folders are found or ratios are invalid.
    """
    mode = validate_operation(mode)
    extensions = normalize_extensions(extensions)

    total_ratio = train_ratio + val_ratio + test_ratio
    if any(r < 0 for r in (train_ratio, val_ratio, test_ratio)):
        raise ValueError("Split ratios must be non-negative.")
    if abs(total_ratio - 1.0) > 1e-9:
        raise ValueError("train_ratio, val_ratio, and test_ratio must sum to 1.0.")

    source_path = Path(source)
    if not source_path.exists():
        raise FileNotFoundError(f"Source directory not found: {source}")

    class_dirs = [d for d in source_path.iterdir() if d.is_dir()]
    if not class_dirs:
        raise ValueError("No class folders found inside source directory.")

    rng = random.Random(seed)

    output_path = ensure_directory(output)

    result: dict[str, dict[str, list[Path]]] = {
        "train": {},
        "val": {},
        "test": {},
    }

    for class_dir in tqdm(class_dirs, desc="Processing classes", dynamic_ncols=True, ascii=True):
        class_name = class_dir.name

        images = [
            p for p in class_dir.iterdir()
            if p.is_file() and (extensions is None or p.suffix.lower() in extensions)
        ]

        if not images:
            continue

        rng.shuffle(images)

        total = len(images)
        train_end = int(total * train_ratio)
        val_end = train_end + int(total * val_ratio)

        split_map = {
            "train": images[:train_end],
            "val": images[train_end:val_end],
            "test": images[val_end:],
        }

        for split_name, files in split_map.items():
            split_class_dir = ensure_directory(output_path / split_name / class_name)

            result[split_name][class_name] = []

            for file_path in tqdm(files, leave=False, disable=True):
                destination = split_class_dir / file_path.name
                transferred = transfer_file(file_path, destination, operation=mode)
                result[split_name][class_name].append(transferred)

    return result