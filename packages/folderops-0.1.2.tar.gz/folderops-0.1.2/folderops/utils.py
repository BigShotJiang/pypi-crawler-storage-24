from __future__ import annotations

from pathlib import Path
from shutil import copy2, move
from typing import Iterable, Sequence, Tuple

DEFAULT_IMAGE_EXTENSIONS: Tuple[str, ...] = ('.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tif', '.tiff', '.webp')


def normalize_extensions(extensions: Sequence[str] | None) -> Tuple[str, ...]:
    if extensions is None:
        return DEFAULT_IMAGE_EXTENSIONS
    normalized = []
    for ext in extensions:
        if not ext:
            continue
        ext = ext.lower().strip()
        if not ext.startswith('.'):
            ext = f'.{ext}'
        normalized.append(ext)
    if not normalized:
        raise ValueError('At least one valid file extension must be provided.')
    return tuple(dict.fromkeys(normalized))


def ensure_directory(path: str | Path) -> Path:
    directory = Path(path)
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def validate_directory(path: str | Path, name: str) -> Path:
    directory = Path(path)
    if not directory.exists():
        raise FileNotFoundError(f'{name} does not exist: {directory}')
    if not directory.is_dir():
        raise NotADirectoryError(f'{name} is not a directory: {directory}')
    return directory


def validate_file(path: str | Path, name: str) -> Path:
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f'{name} does not exist: {file_path}')
    if not file_path.is_file():
        raise FileNotFoundError(f'{name} is not a file: {file_path}')
    return file_path


def list_image_files(directory: str | Path, extensions: Sequence[str] | None = None) -> list[Path]:
    folder = validate_directory(directory, 'Source directory')
    allowed = set(normalize_extensions(extensions))
    return sorted([path for path in folder.iterdir() if path.is_file() and path.suffix.lower() in allowed])


def unique_destination_path(output_dir: str | Path, filename: str) -> Path:
    output_path = ensure_directory(output_dir)
    destination = output_path / filename
    if not destination.exists():
        return destination
    stem = destination.stem
    suffix = destination.suffix
    counter = 1
    while True:
        candidate = output_path / f'{stem}_{counter}{suffix}'
        if not candidate.exists():
            return candidate
        counter += 1


def transfer_file(source: str | Path, destination: str | Path, operation: str = 'copy') -> Path:
    src = Path(source)
    dst = Path(destination)
    ensure_directory(dst.parent)
    if operation == 'copy':
        copy2(src, dst)
    elif operation == 'move':
        move(str(src), str(dst))
    else:
        raise ValueError("operation must be either 'copy' or 'move'.")
    return dst


def validate_operation(operation: str) -> str:
    normalized = operation.lower().strip()
    if normalized not in {'copy', 'move'}:
        raise ValueError("mode must be either 'copy' or 'move'.")
    return normalized


def iter_structure_paths(structure: dict, parent: Path | None = None) -> Iterable[Path]:
    if not isinstance(structure, dict):
        raise TypeError('structure must be a dictionary.')
    parent = parent or Path()
    for name, subtree in structure.items():
        if not isinstance(name, str) or not name.strip():
            raise ValueError('Every folder name must be a non-empty string.')
        current = parent / name
        yield current
        if subtree is None:
            continue
        if not isinstance(subtree, dict):
            raise TypeError('Nested structure values must be dictionaries or empty dictionaries.')
        yield from iter_structure_paths(subtree, current)
