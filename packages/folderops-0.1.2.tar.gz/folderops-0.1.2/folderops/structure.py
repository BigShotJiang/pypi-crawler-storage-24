from __future__ import annotations

from pathlib import Path

from .utils import ensure_directory, iter_structure_paths


def create_structure(structure, root: str | Path | None = None) -> list[Path]:
    """
    Create directories from a list of relative paths under a given root.

    This function is primarily designed for simple use cases where you define
    folder paths as a list. Each path is treated as relative to the `root`
    directory and will be created if it does not already exist.

    Example:
        paths = ['train/cats', 'train/dogs', 'val/cats']
        create_structure(paths, root='dataset')

    This will create:
        dataset/train/cats
        dataset/train/dogs
        dataset/val/cats

    Args:
        structure:
            A list of relative directory paths (e.g., ['train/cats', 'val/dogs']).
            A nested dictionary structure is also supported but is internally
            converted into a list of paths.
        root:
            Base directory under which all paths will be created. If None,
            the current working directory is used.

    Returns:
        A list of Path objects representing the created or existing directories.

    Raises:
        TypeError: If `structure` is not a list or dictionary.
    """
    base = Path(root) if root is not None else Path()
    created_paths: list[Path] = []

    if isinstance(structure, list):
        paths = structure
    elif isinstance(structure, dict):
        paths = list(iter_structure_paths(structure))
    else:
        raise TypeError("structure must be a dict or list of paths")

    for relative_path in paths:
        directory = ensure_directory(base / relative_path)
        created_paths.append(directory)

    return created_paths