/***************************************************************************************************
 * Copyright (C) 2024 - 2025 Codeplay Software Ltd. All rights reserved.
 * Copyright (C) 2025 - 2026 Intel Corporation, All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 **************************************************************************************************/

/*! \file
    \brief  BMG GEMM + Top-K + Softmax fusion

    This example illustrates how to use the LinCombTopKSoftmaxCol EVT node to fuse
    Top-K and Softmax into the GEMM epilogue, with certain assumptions made.

    Those assumptions are as:
      1. Fusion is over the N dimension.
      2. Top-K is either 2 or 4 elements, and the value is static (meaning two kernels have to be
         compiled to support both.)
      3. The GEMM tile shape along N is greater than or equal to problem size
         along N.


    The example runs the fused GEMM kernel, along with a standard unfused host reference, and
    manually performs Top-K and softmax, and compares the error between tensors.

    Note that some numerical error (smaller than 1e-5) is to be expected, but this is true
    in most efficient reduction kernels, because floating point addition is not necessarily
    associative.

    To build & run this example (from your build dir):

      $ ninja 05_bmg_gemm_with_topk_and_softmax
      $ ./examples/sycl/05_bmg_gemm_with_epilogues/05_bmg_gemm_with_topk_and_softmax

    Call with `--help` for information about available options
*/
#include "cutlass/epilogue/collective/default_epilogue.hpp"
#include "cutlass/epilogue/collective/xe_epilogue.hpp"
#include "cutlass/epilogue/fusion/xe_callbacks.hpp"
#include "cutlass/gemm/device/gemm_universal.h"
#include "cutlass/gemm/device/gemm_universal_adapter.h"
#include "cutlass/gemm/collective/collective_mma.hpp"
#include "cutlass/util/GPU_Clock.hpp"

#include <cute/tensor.hpp>
#include <random>

#include "cutlass/util/host_tensor.h"
#include "cutlass/util/command_line.h"
#include "cutlass/util/device_memory.h"
#include "cutlass/util/packed_stride.hpp"
#include "cutlass/util/tensor_view_io.h"
#include "cutlass/util/reference/device/gemm_complex.h"
#include "cutlass/util/reference/device/tensor_compare.h"
#include "cutlass/util/reference/host/error_metrics.h"
#include "cutlass/util/reference/host/tensor_fill.h"
#include "cutlass/util/reference/host/tensor_copy.h"
#include "cutlass/util/reference/host/tensor_compare.h"
#include "cutlass/util/reference/host/tensor_norm.h"
#include "cutlass/util/reference/host/gett.hpp"
#include "helper.h"


using namespace cute;

static constexpr int TopK = 2;
static constexpr bool EnableTopKSoftmax = TopK > 1;

/////////////////////////////////////////////////////////////////////////////////////////////////
/// GEMM kernel configurations
/////////////////////////////////////////////////////////////////////////////////////////////////

// A matrix configuration
using         ElementA    = bfloat16_t;                                // Element type for A matrix operand
using         LayoutA     = cutlass::layout::RowMajor;                      // Layout type for A matrix operand
constexpr int AlignmentA  = 128 / cutlass::sizeof_bits<ElementA>::value;    // Memory access granularity/alignment of A matrix in units of elements (up to 16 bytes)

// B matrix configuration
using         ElementB    = bfloat16_t;                                // Element type for B matrix operand
using         LayoutB     = cutlass::layout::RowMajor;                   // Layout type for B matrix operand
constexpr int AlignmentB  = 128 / cutlass::sizeof_bits<ElementB>::value;    // Memory access granularity/alignment of B matrix in units of elements (up to 16 bytes)

// C matrix configuration
using         ElementC    = float; //TODO void???
using         LayoutC     = cutlass::layout::RowMajor;
constexpr int AlignmentC  = 1;

// D matrix configuration
using         ElementD    = float;                                // Element type for C and D matrix operands
using         LayoutD     = cutlass::layout::RowMajor;                      // Layout type for output
constexpr int AlignmentD  = 128 / cutlass::sizeof_bits<ElementD>::value;    // Memory access granularity/alignment of output in units of elements (up to 16 bytes)

// Core kernel configurations
using ElementAccumulator  = float;                                          // Element type for internal accumulation
using ElementCompute      = float;                                          // Element type for epilogue computation
using ArchTag             = cutlass::arch::IntelXe;                            // Tag indicating the minimum SM that supports the intended feature
using OperatorClass       = cutlass::arch::OpClassTensorOp;                 // Operator class tag
using TileShape           = Shape<_256, _256, _32>;                            // Threadblock-level tile size
using ClusterShape        = Shape<_1,_1,_1>;                                // Shape of the threadblocks in a cluster

using GmemTiledCopyA = XE_2D_U16x32x32_LD_N;
using GmemTiledCopyB = XE_2D_U16x32x32_LD_V;
using TiledMma =
    typename TiledMMAHelper<MMA_Atom<XE_8x16x16_F32BF16BF16F32_TT>, Layout<TileShape>,
                                  Layout<Shape<_8, _4, _1>, Stride<_4, _1, _0>>>::TiledMMA;
constexpr int PipelineStages = 3;
using GEMMDispatchPolicy = cutlass::gemm::MainloopIntelXeXMX16<PipelineStages>;
using EpilogueDispatchPolicy = cutlass::epilogue::IntelXeXMX16;

// Top-K + Softmax fusion operation
using EpilogueFusionOperation     = std::conditional_t<EnableTopKSoftmax,
  typename cutlass::epilogue::fusion::LinCombTopKSoftmaxCol<TopK, ElementD, ElementCompute>,
  typename cutlass::epilogue::fusion::LinearCombination<ElementD, ElementCompute, ElementC, ElementCompute>
>;

// The fusion op only allows for epilogue tiles matching the mainloop tile.
using EpilogueTileType    = decltype(cute::take<0,2>(TileShape{}));

using FusionCallBacks = cutlass::epilogue::fusion::FusionCallbacks<EpilogueDispatchPolicy, EpilogueFusionOperation, TileShape,
        decltype(tile_shape(TiledMma()))>;
using CollectiveEpilogue = cutlass::epilogue::collective::CollectiveEpilogue<
      EpilogueDispatchPolicy,
      TileShape,
      ElementAccumulator,
      cutlass::gemm::TagToStrideC_t<LayoutC>,
      ElementD,
      cutlass::gemm::TagToStrideC_t<LayoutD>,
      FusionCallBacks,
      XE_2D_U32x8x16_LD_N,
      void, void,
      XE_2D_U32x8x16_ST_N,
      void, void>;

using CollectiveMainloop = cutlass::gemm::collective::CollectiveMma<
  GEMMDispatchPolicy,
  TileShape,
  ElementA,
  cutlass::gemm::TagToStrideA_t<LayoutA>,
  ElementB,
  cutlass::gemm::TagToStrideB_t<LayoutB>,
  TiledMma,
  GmemTiledCopyA, void, void, cute::identity,  // A
  GmemTiledCopyB, void, void, cute::identity   // B
>;

using GemmKernel = cutlass::gemm::kernel::GemmUniversal<
    Shape<int,int,int,int>, // Indicates ProblemShape
    CollectiveMainloop,
    CollectiveEpilogue
>;

using Gemm = cutlass::gemm::device::GemmUniversalAdapter<GemmKernel>;

// Extract information from Gemm kernel.
using EpilogueOutputOp  = typename Gemm::EpilogueOutputOp;
using ElementScalar     = typename EpilogueOutputOp::ElementScalar;

using StrideA = typename Gemm::GemmKernel::StrideA;
using StrideB = typename Gemm::GemmKernel::StrideB;
using StrideD = typename Gemm::GemmKernel::StrideD;

/// Initialization
StrideA stride_A;
StrideB stride_B;
StrideD stride_D;
uint64_t seed;

using LayoutScalar = cutlass::layout::PackedVectorLayout;

/////////////////////////////////////////////////////////////////////////////////////////////////
/// Testbed utility types
/////////////////////////////////////////////////////////////////////////////////////////////////

// Command line options parsing
struct Options {

  bool help = false;

  int iterations = 1000;
  int m = 16, n = 8, k = 64, l = 1;
  int verify = 1;
  double eps = 1e-5;

  // Parses the command line
  void parse(int argc, char const **args) {
    cutlass::CommandLine cmd(argc, args);

    if (cmd.check_cmd_line_flag("help")) {
      help = true;
      return;
    }

    cmd.get_cmd_line_argument("m", m);
    cmd.get_cmd_line_argument("n", n);
    cmd.get_cmd_line_argument("k", k);
    cmd.get_cmd_line_argument("l", l);
    cmd.get_cmd_line_argument("iterations", iterations);
    cmd.get_cmd_line_argument("verify", verify, 1);
    cmd.get_cmd_line_argument("eps", eps);
  }

  /// Prints the usage statement.
  std::ostream & print_usage(std::ostream &out) const {

    out << "05_bmg_gemm_with_topk_and_softmax\n\n"
      << "  BMG GEMM with Top-K and softmax fusion.\n\n"
      << "Options:\n\n"
      << "  --help                      If specified, displays this usage statement\n\n"
      << "  --m=<int>                   Sets the M extent of the GEMM\n"
      << "  --n=<int>                   Sets the N extent of the GEMM\n"
      << "  --k=<int>                   Sets the K extent of the GEMM\n"
      << "  --l=<int>                   Sets the l extent (batch) of the GEMM\n"
      << "  --iterations=<int>          Number of profiling iterations to perform.\n"
      << "  --verify=<int>              Specify whether to verify. Default: 1\n"
      << "  --eps=<float>               Threshold of numerical verification. Default: 1e-5.\n\n";

    out
      << "\n\nExamples:\n\n"
      << "$ " << "05_bmg_gemm_with_topk_and_softmax" << " --m=16 --n=8 --k=1024 \n\n";

    return out;
  }

  /// Compute performance in GFLOP/s
  double gflops(double runtime_s) const
  {
    // Two flops per multiply-add
    uint64_t flop = uint64_t(2) * m * n * k;
    double gflop = double(flop) / double(1.0e9);
    return gflop / runtime_s;
  }

  float alpha() const {
    return 1.f / static_cast<float>(k);
  }
};

/// Result structure
struct Result {
  double avg_runtime_ms;
  double gflops;
  cutlass::Status status;
  cutlass::cudaError_t error;
  bool passed;
  

  cutlass::HostTensor<ElementA  , LayoutA  > tensor_A;
  cutlass::HostTensor<ElementB  , LayoutB  > tensor_B;
  cutlass::HostTensor<ElementD  , LayoutD  > tensor_D;
  cutlass::HostTensor<ElementD  , LayoutD  > tensor_ref_D;

  Result(
    double avg_runtime_ms = 0,
    double gflops = 0,
    cutlass::Status status = cutlass::Status::kSuccess,
    cutlass::cudaError_t error = cutlass::cudaSuccess)
  :
    avg_runtime_ms(avg_runtime_ms), gflops(gflops), status(status), error(error), passed(false)
  {}

  /////////////////////////////////////////////////////////////////////////////////////////////////
  /// GEMM setup and evaluation
  /////////////////////////////////////////////////////////////////////////////////////////////////

  /// Helper to initialize a block of device data
  template <typename Element, typename Layout>
  bool initialize_tensor(
      cutlass::TensorView<Element, Layout> view,
      uint64_t seed) {
    cutlass::reference::host::TensorFillRandomUniform(
      view, seed, /* max = */ 1, /* min = */ -1, /* bits = */ 2);
    return true;
  }

  /// Initialize operands to be used in the GEMM and reference GEMM
  void initialize(const Options &options) {

    stride_A = cutlass::make_cute_packed_stride(StrideA{}, cute::make_shape(options.m, options.k, options.l));
    stride_B = cutlass::make_cute_packed_stride(StrideB{}, cute::make_shape(options.n, options.k, options.l));
    stride_D = cutlass::make_cute_packed_stride(StrideD{}, cute::make_shape(options.m, options.n, options.l));

    auto a_coord = cutlass::make_Coord(options.m * options.l, options.k);
    auto c_coord = cutlass::make_Coord(options.m * options.l, options.n);
    auto b_coord = cutlass::make_Coord(options.k, options.n * options.l);

    tensor_A.resize(a_coord);
    tensor_B.resize(b_coord);
    tensor_D.resize(c_coord);
    tensor_ref_D.resize(c_coord);

    initialize_tensor(tensor_A.host_view(), seed + 2022);
    initialize_tensor(tensor_B.host_view(), seed + 2023);

    tensor_A.sync_device();
    tensor_B.sync_device();
    tensor_D.sync_device();
  }

  /// Populates a Gemm::Arguments structure from the given commandline options
  typename Gemm::Arguments args_from_options(const Options &options) {
    typename Gemm::Arguments arguments{
      cutlass::gemm::GemmUniversalMode::kGemm,
      {options.m, options.n, options.k, options.l},
      {tensor_A.device_data(), stride_A, tensor_B.device_data(), stride_B},
      {
        {options.alpha(), 0.f}, // alpha, beta
        nullptr, stride_D,
        tensor_D.device_data(), stride_D
      }
    };

    return arguments;
  }

  bool verify(const Options &options) {
    //
    // Compute reference output
    //

    // Create instantiation for device reference gemm kernel
    auto A = cute::make_tensor(tensor_A.host_data(),
        cute::make_layout(cute::make_shape(options.m, options.k, options.l), stride_A));
    auto B = cute::make_tensor(tensor_B.host_data(),
        cute::make_layout(cute::make_shape(options.n, options.k, options.l), stride_B));
    auto D = cute::make_tensor(tensor_ref_D.host_data(),
        cute::make_layout(cute::make_shape(options.m, options.n, options.l), stride_D));
    using unused_t = decltype(D);

    cutlass::reference::host::GettMainloopParams<ElementAccumulator, decltype(A), decltype(B)> mainloop_params{A, B};

    cutlass::reference::host::GettEpilogueParams<
        ElementScalar,
        ElementScalar,
        ElementAccumulator,
        ElementCompute,
        unused_t,
        decltype(D),
        unused_t, // bias
        unused_t, // aux
        unused_t, // valpha
        unused_t  // vbeta
    > epilogue_params;

    epilogue_params.D = D;
    epilogue_params.alpha = options.alpha();
    epilogue_params.beta = 0.f;

    // get reference result
    cutlass::reference::host::Gemm3x(mainloop_params, epilogue_params);

    if constexpr (EnableTopKSoftmax) {
      // top-K + softmax
      for (int k = 0; k < options.l; ++k) {
        for (int i = 0; i < options.m; ++i) {

          // Find Top-K
          cutlass::Array<ElementAccumulator, TopK> top_k;
          top_k.fill(-cutlass::platform::numeric_limits<ElementCompute>::infinity());
          for (int j = 0; j < options.n; ++j) {
            auto val = static_cast<ElementAccumulator>(tensor_ref_D.host_view().ref().at({i + k * options.m, j}));
            for (int top_k_idx = 0; top_k_idx < TopK; ++top_k_idx) {
              if (val > top_k[top_k_idx]) {
                // Shift down
                for (int l = TopK - 1; l > top_k_idx; --l) {
                  top_k[l] = top_k[l - 1];
                }
                top_k[top_k_idx] = val;
                break;
              }
            }
          }

          // This formulation of top-K + softmax only works when it is
          // guaranteed that none of the top-K elements are repeated!
          // If this is the case, the device kernel can also make mistakes, because
          //   A. Once the top-K values are reduced, and the operation is being applied,
          //      there is no way to tell repeated elements apart, so none are masked.
          //   B. The softmax sum of exps will be incorrect (because the repeated elements
          //      are not repeated in it.)

          ElementAccumulator max = top_k[0];
          ElementAccumulator sum = ElementAccumulator(0.f);
          for (int top_k_idx = 0; top_k_idx < TopK; ++top_k_idx) {
            sum = sum + cutlass::fast_exp(top_k[top_k_idx] - max);
          }

          for (int j=0; j < options.n; ++j) {
            auto val = tensor_ref_D.host_view().ref().at({i + k * options.m, j});
            if (val < top_k[TopK - 1]) {
              tensor_ref_D.host_view().ref().at({i + k * options.m, j}) = static_cast<ElementD>(0.f);
            } else {
              // Softmax
              auto softmax_val = cutlass::fast_exp(val - max) / sum;
              tensor_ref_D.host_view().ref().at({i + k * options.m, j}) = static_cast<ElementD>(softmax_val);
            }
          }
        }
      }
    }

    // compare_reference
    tensor_D.sync_host();

    double err = cutlass::reference::host::TensorRelativeErrorMetric(
      tensor_D.host_view(),
      tensor_ref_D.host_view());
    bool passed = err < options.eps;

    if (options.m <= 32 && options.n <= 32) {
      std::cout << "GEMM output:\n" << tensor_D.host_view() << "\n\n";
      std::cout << "Reference output:\n" << tensor_ref_D.host_view() << "\n\n";
    }

    std::cout << "  Disposition: " << (passed ? "Passed" : "Failed") << " \t Relative error: " << err << std::endl;

    return passed;
  }

};

/// Execute a given example GEMM computation
template <typename Gemm>
int run(Options &options) {
  // Instantiate CUTLASS kernel depending on templates
  Gemm gemm;

  Result result;
  result.initialize(options);

  // Create a structure of gemm kernel arguments suitable for invoking an instance of Gemm
  auto arguments = result.args_from_options(options);

  // Using the arguments, query for extra workspace required for matrix multiplication computation
  size_t workspace_size = Gemm::get_workspace_size(arguments);

  // Allocate workspace memory
  cutlass::device_memory::allocation<uint8_t> workspace(workspace_size);

  // Check if the problem size is supported or not
  CUTLASS_CHECK(gemm.can_implement(arguments));

  // Initialize CUTLASS kernel with arguments and workspace pointer
  CUTLASS_CHECK(gemm.initialize(arguments, workspace.get()));

  // Correctness / Warmup iteration
  CUTLASS_CHECK(gemm.run());

  if (options.verify != 0) {
    // Check if output from CUTLASS kernel and reference kernel are equal or not
    result.passed = result.verify(options);
    std::cout << "Disposition: " << (result.passed ? "Passed" : "Failed") << std::endl;

    if (!result.passed) {
      return -1;
    }
  } else {
    std::cout << "Disposition is skipped." << std::endl;
  }

  // Run profiling loop
  if (options.iterations > 0) {
    GpuTimer timer;
    timer.start();
    for (int iter = 0; iter < options.iterations; ++iter) {
      CUTLASS_CHECK(gemm.run());
    }
    timer.stop();

    // Compute average runtime and GFLOPs.
    float elapsed_ms = timer.elapsed_millis();
    result.avg_runtime_ms = double(elapsed_ms) / double(options.iterations);
    result.gflops = options.gflops(result.avg_runtime_ms / 1000.0);

    std::cout << "  Problem Size: " << options.m << 'x' << options.n << 'x' << options.k << 'x' << options.l << std::endl;
    std::cout << "  Avg runtime: " << result.avg_runtime_ms << " ms" << std::endl;
    std::cout << "  GFLOPS: " << result.gflops << std::endl;
  }

  return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char const **args) {
  //
  // Parse options
  //

  Options options;

  options.parse(argc, args);

  if (options.help) {
    options.print_usage(std::cout) << std::endl;
    return 0;
  }

  //
  // Evaluate CUTLASS kernels
  //
  run<Gemm>(options);

  return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
