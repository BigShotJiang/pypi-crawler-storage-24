import os
import json
from pathlib import Path
from pydantic_settings import BaseSettings

CONFIG_DIR = Path.home() / ".opengit"
CONFIG_FILE = CONFIG_DIR / "config.json"

class Settings(BaseSettings):
    gitlab_token: str = ""
    electricity_maps_api_key: str = ""
    google_iam_provider: str = ""
    
    @classmethod
    def load(cls):
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r") as f:
                data = json.load(f)
                return cls(**data)
        # Also check old path for backwards compatibility
        old_config = Path.home() / ".gitpulse" / "config.json"
        if old_config.exists():
            with open(old_config, "r") as f:
                data = json.load(f)
                return cls(**data)
        return cls()

    def save(self):
        CONFIG_DIR.mkdir(exist_ok=True, parents=True)
        with open(CONFIG_FILE, "w") as f:
            json.dump(self.model_dump(), f, indent=4)
