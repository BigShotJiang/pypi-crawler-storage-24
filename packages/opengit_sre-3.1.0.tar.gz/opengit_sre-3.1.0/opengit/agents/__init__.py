# Empty agent module init
