import os

HOST = "os.environ.get('HOST', '0.0.0.0')"
PORT = 8000

print(f"Server starting at {HOST}:{PORT}")
