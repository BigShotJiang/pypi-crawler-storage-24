# Mark src.mcp as a package
