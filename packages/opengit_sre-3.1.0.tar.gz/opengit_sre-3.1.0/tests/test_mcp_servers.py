import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.mcp.green_optimizer_mcp import get_carbon_intensity
from src.mcp.knowledge_graph_mcp import detect_dependency_drift, upsert_requests_policy


@pytest.mark.asyncio
async def test_green_optimizer_carbon_intensity():
    result = await get_carbon_intensity("US-CAL-CISO")
    assert "intensity" in result
    assert "sci_score" in result


@pytest.mark.asyncio
async def test_detect_dependency_drift_modulenotfound_requests():
    logs = "ModuleNotFoundError: No module named 'requests'"
    result = await detect_dependency_drift(logs)
    assert result["detected"] is True


@pytest.mark.asyncio
async def test_detect_dependency_drift_no_match():
    result = await detect_dependency_drift("all tests passed")
    assert result["detected"] is False


@pytest.mark.asyncio
async def test_upsert_requests_policy_add():
    result = await upsert_requests_policy("fastapi==0.111.0\n")
    assert "requests>=2.31.0" in result["content"]
