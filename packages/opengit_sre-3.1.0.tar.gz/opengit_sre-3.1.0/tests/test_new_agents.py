import pytest
from src.mcp.knowledge_graph_mcp import shift_left_security_check, calculate_tech_debt_score
import re

@pytest.mark.asyncio
async def test_shift_left_security_check_passed(monkeypatch):
    # Mock GitLab MR and changes
    class MockMR:
        def changes(self):
            return {'changes': [{'new_path': 'src/app.py', 'diff': 'def hello(): pass'}]}
    
    class MockProj:
        def __init__(self):
            class MockMRs:
                def get(self, id): return MockMR()
            self.mergerequests = MockMRs()

    class MockProjects:
        def get(self, id): return MockProj()

    class MockGL:
        def __init__(self):
            self.projects = MockProjects()
        
    monkeypatch.setattr("src.mcp.knowledge_graph_mcp._gitlab_client", lambda: MockGL())
    
    result = await shift_left_security_check("group/proj", 1)
    assert result["status"] == "passed"

@pytest.mark.asyncio
async def test_shift_left_security_check_blocked_secret(monkeypatch):
    class MockNote:
        def create(self, payload): pass

    class MockMR:
        def __init__(self):
            self.notes = MockNote()
        def changes(self):
            return {'changes': [{'new_path': 'src/app.py', 'diff': 'glpat-1234567890abcdefghij'}]}
    
    class MockProj:
        def __init__(self):
            class MockMRs:
                def get(self, id): return MockMR()
            self.mergerequests = MockMRs()

    class MockProjects:
        def get(self, id): return MockProj()

    class MockGL:
        def __init__(self):
            self.projects = MockProjects()
        
    monkeypatch.setattr("src.mcp.knowledge_graph_mcp._gitlab_client", lambda: MockGL())
    
    result = await shift_left_security_check("group/proj", 1)
    assert result["status"] == "blocked"
    assert "Secret leakage detected" in result["violations"][0]

@pytest.mark.asyncio
async def test_calculate_tech_debt_score(monkeypatch):
    class MockFile:
        def decode(self): return b"pytest"

    class MockFiles:
        def get(self, **kwargs): return MockFile()

    class MockProj:
        def __init__(self):
            self.files = MockFiles()
        def repository_tree(self, **kwargs):
            return [{'path': 'app.py'}, {'path': 'test.py'}]
    
    class MockProjects:
        def get(self, id): return MockProj()

    class MockGL:
        def __init__(self):
            self.projects = MockProjects()
        
    async def mock_get_content(*args):
        return {"content": "pytest", "found": True}
        
    async def mock_scan_drift(*args):
        return {"detected": False}

    monkeypatch.setattr("src.mcp.knowledge_graph_mcp._gitlab_client", lambda: MockGL())
    monkeypatch.setattr("src.mcp.knowledge_graph_mcp.get_file_content", mock_get_content)
    monkeypatch.setattr("src.mcp.knowledge_graph_mcp.scan_repo_for_drift", mock_scan_drift)
    
    result = await calculate_tech_debt_score("group/proj")
    assert result["total_score"] == 100
    assert result["breakdown"]["testing"] == "Verified"
