# pasal

Python SDK for [Pasal.id](https://pasal.id) - Indonesia's open legal data platform.

> **Coming soon.** This package is under active development.

## What is Pasal.id?

Pasal.id provides structured, searchable access to 40,000+ Indonesian government regulations. Free for everyone to read, with an API and MCP server for developers.

## Installation

```bash
pip install pasal
```

## Links

- Website: https://pasal.id
- API: https://pasal.id/hubungkan
- GitHub: https://github.com/pasal-id
