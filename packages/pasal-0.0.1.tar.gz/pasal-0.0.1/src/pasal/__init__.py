"""Pasal - Python SDK for Indonesia's open legal data platform."""

__version__ = "0.0.1"
