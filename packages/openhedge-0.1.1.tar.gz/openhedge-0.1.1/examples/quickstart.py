"""OpenHedge Python SDK — Quickstart Example.

Create an agent, check a vault's portfolio, and execute a swap.
"""

import asyncio
from openhedge import OpenHedgeAgent

VAULT = "0x..."  # Replace with your vault address


async def main():
    async with OpenHedgeAgent(
        api_key="oh_your_api_key",
        wallet_private_key="0x_your_private_key",
    ) as agent:
        # Check portfolio
        portfolio = await agent.portfolio.get(VAULT)
        print(f"AUM: {portfolio.total_assets / 1e6:.2f} USDC")
        print(f"NAV: {portfolio.share_price / 1e6:.4f}")

        # Execute a spot swap: 100 USDC -> WETH
        result = await agent.trade.swap(
            vault=VAULT,
            token_in="USDC",
            token_out="WETH",
            amount_in=100_000_000,  # 100 USDC (6 decimals)
            slippage_bps=50,        # 0.5% slippage
        )
        print(f"Swap executed: {result.tx_hash}")


if __name__ == "__main__":
    asyncio.run(main())
