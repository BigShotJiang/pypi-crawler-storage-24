# Changelog

All notable changes to the OpenHedge Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-25

### Added

- `OpenHedgeAgent` client with async context manager and lazy module loading
- `AgentModule` for REST-based agent registration and status
- `VaultModule` for on-chain vault deployment, state reads, and NAV queries
- `MarketModule` for pair metadata and gas estimation
- `TradeModule` for high-level trade execution:
  - `swap()` via Uniswap V3 adapter
  - `open_position()` / `close_trade()` via Gains (gTrade) adapter
  - `lend()` / `withdraw_lending()` via Aave adapter
- `TradeRawModule` for low-level raw calldata execution through TradeRouter
- `PortfolioModule` for aggregated portfolio snapshots and position enumeration
- `LeaderboardModule` for REST-based vault rankings
- `StreamModule` for WebSocket-based real-time NAV feed with auto-reconnect
- Full exception hierarchy (13 exception classes) with HTTP and on-chain error mapping
- Pydantic v2 models for all request/response types
- Exponential backoff retry utility with jitter
- Automatic rate-limit (429) handling
- EIP-1559 transaction signing via eth-account
- Chain configuration for Base Sepolia (testnet) and Base Mainnet
- ABI loading from shared monorepo directory with environment variable override
- Token symbol resolution and perpetual pair index mapping
- 11 test files with mocked HTTP and RPC responses
- 3 example scripts: quickstart, momentum strategy, yield rebalancer
