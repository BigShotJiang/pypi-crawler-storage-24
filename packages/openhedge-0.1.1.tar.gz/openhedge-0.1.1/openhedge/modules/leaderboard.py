"""LeaderboardModule — fetch vault rankings from the leaderboard worker."""

from __future__ import annotations

from openhedge.models.leaderboard import LeaderboardEntry, VaultRanking
from openhedge.modules.base import BaseModule


class LeaderboardModule(BaseModule):
    """REST-backed leaderboard queries."""

    async def get(self, *, period: str = "all", limit: int = 50) -> LeaderboardEntry:
        """Fetch the leaderboard for a given time period.

        Parameters
        ----------
        period:
            ``'24h'``, ``'7d'``, ``'30d'``, or ``'all'``.
        limit:
            Maximum number of vaults to return.

        Returns
        -------
        A :class:`LeaderboardEntry` containing ranked vaults.
        """
        data = await self._api_get("/v1/leaderboard", period=period, limit=limit)

        vaults = [VaultRanking(**v) for v in data.get("vaults", [])]
        return LeaderboardEntry(
            period=data.get("period", period),
            updated_at=data.get("updated_at"),
            vaults=vaults,
        )
