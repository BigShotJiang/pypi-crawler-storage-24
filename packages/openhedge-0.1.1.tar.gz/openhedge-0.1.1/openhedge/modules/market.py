"""MarketModule — pair metadata and gas estimation."""

from __future__ import annotations

from typing import List

from openhedge.constants import PAIR_INDEX
from openhedge.models.market import GasEstimate, PairInfo
from openhedge.modules.base import BaseModule


class MarketModule(BaseModule):
    """Provides market reference data and gas estimates."""

    def pairs(self) -> List[PairInfo]:
        """Return all supported perpetual trading pairs.

        This is a synchronous in-memory lookup.
        """
        return [
            PairInfo(name=name, pair_index=idx)
            for name, idx in sorted(PAIR_INDEX.items(), key=lambda x: x[1])
        ]

    async def gas_estimate(self) -> GasEstimate:
        """Fetch the current gas price from the RPC node and estimate cost."""
        gas_price_wei = await self._get_gas_price()
        gas_price_gwei = gas_price_wei / 1e9

        # Typical trade-route call costs ~300k gas on Base
        typical_gas = 300_000
        cost_eth = (gas_price_wei * typical_gas) / 1e18

        return GasEstimate(
            gas_limit=typical_gas,
            gas_price_gwei=round(gas_price_gwei, 4),
            estimated_cost_eth=round(cost_eth, 8),
        )
