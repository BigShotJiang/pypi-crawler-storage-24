"""SDK modules — each maps to a namespace on ``OpenHedgeAgent``."""
