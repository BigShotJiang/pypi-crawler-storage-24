"""Shared utilities for the OpenHedge SDK."""
