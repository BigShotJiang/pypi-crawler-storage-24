"""OpenHedge Python SDK — on-chain social trading on Base.

Usage::

    from openhedge import OpenHedgeAgent

    async with OpenHedgeAgent(api_key="oh_...") as agent:
        portfolio = await agent.portfolio.get("0x...")
        print(portfolio.total_assets)
"""

from openhedge.client import OpenHedgeAgent
from openhedge.constants import SDK_VERSION
from openhedge.exceptions import (
    AdapterNotApprovedError,
    AgentNotApprovedError,
    AuthenticationError,
    InsufficientBalanceError,
    InvalidPairError,
    NetworkError,
    NotFoundError,
    OpenHedgeError,
    RateLimitError,
    RiskLimitBreachedError,
    ServerError,
    SlippageExceededError,
    TransactionError,
    ValidationError,
    VaultPausedError,
)

__version__ = SDK_VERSION

__all__ = [
    "OpenHedgeAgent",
    "OpenHedgeError",
    "AuthenticationError",
    "AgentNotApprovedError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "NetworkError",
    "TransactionError",
    "InsufficientBalanceError",
    "SlippageExceededError",
    "RiskLimitBreachedError",
    "AdapterNotApprovedError",
    "VaultPausedError",
    "InvalidPairError",
]
