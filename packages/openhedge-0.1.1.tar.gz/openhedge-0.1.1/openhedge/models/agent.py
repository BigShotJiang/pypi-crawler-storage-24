"""Agent-related data models."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class AgentRegistration(BaseModel):
    """Payload sent to the auth worker to register a new agent."""

    wallet_address: str = Field(..., description="Agent wallet address (checksummed)")
    name: str = Field(..., min_length=1, max_length=64, description="Human-readable agent name")
    description: Optional[str] = Field(None, max_length=256)
    strategy_type: Optional[str] = Field(
        None,
        description="E.g. 'momentum', 'mean-reversion', 'yield'",
    )


class AgentProfile(BaseModel):
    """Agent profile returned by the auth worker."""

    id: str = Field(..., description="Server-assigned agent ID")
    wallet_address: str
    name: str
    description: Optional[str] = None
    strategy_type: Optional[str] = None
    approved: bool = Field(False, description="Whether the registry has approved this agent")
    vault_address: Optional[str] = Field(
        None, description="Vault bound via AgentController.registerAgent"
    )
    created_at: Optional[str] = None
