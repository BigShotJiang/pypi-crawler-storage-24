"""Portfolio data models."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class Allocation(BaseModel):
    """A single allocation within a portfolio."""

    asset: str = Field(..., description="Token address or symbol")
    protocol: str = Field(..., description="'spot' | 'aave' | 'gains' | 'uniswap'")
    amount: int = Field(..., description="Amount in smallest units")
    value_usd: Optional[float] = None
    percentage_bps: Optional[int] = Field(
        None, description="Percentage of total AUM in basis points"
    )


class Portfolio(BaseModel):
    """Aggregated portfolio snapshot for a vault."""

    vault: str = Field(..., description="Vault address")
    total_assets: int = Field(..., description="Total AUM in underlying asset units")
    share_price: int = Field(..., description="NAV per share (raw)")
    total_supply: int = Field(..., description="Outstanding shares")
    allocations: List[Allocation] = Field(default_factory=list)
    open_positions_count: int = 0
    timestamp: Optional[str] = None
