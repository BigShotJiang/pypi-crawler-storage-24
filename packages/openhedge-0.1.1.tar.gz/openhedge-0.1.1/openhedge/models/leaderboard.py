"""Leaderboard data models."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class VaultRanking(BaseModel):
    """Ranking entry for a single vault in the leaderboard."""

    vault_address: str
    vault_name: str
    trader: str
    aum: int = Field(..., description="Assets under management in underlying units")
    share_price: int = Field(..., description="Current NAV per share")
    return_bps: int = Field(0, description="Cumulative return in basis points")
    depositor_count: int = 0
    rank: int = 0


class LeaderboardEntry(BaseModel):
    """A full leaderboard response."""

    period: str = Field("all", description="'24h' | '7d' | '30d' | 'all'")
    updated_at: Optional[str] = None
    vaults: List[VaultRanking] = Field(default_factory=list)
