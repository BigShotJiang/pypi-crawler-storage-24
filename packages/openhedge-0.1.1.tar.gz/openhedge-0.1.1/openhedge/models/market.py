"""Market-related data models."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class PairInfo(BaseModel):
    """Metadata for a supported trading pair."""

    name: str = Field(..., description="Human-readable pair name, e.g. 'BTC/USD'")
    pair_index: int = Field(..., ge=0, description="On-chain pair index for gTrade")
    category: str = Field(default="crypto", description="crypto | forex | commodities")
    enabled: bool = True


class GasEstimate(BaseModel):
    """Estimated gas cost for a transaction."""

    gas_limit: int = Field(..., description="Estimated gas units")
    gas_price_gwei: float = Field(..., description="Current gas price in Gwei")
    estimated_cost_eth: float = Field(..., description="Estimated cost in ETH")
    estimated_cost_usd: Optional[float] = Field(
        None, description="Estimated cost in USD (when price feed available)"
    )
