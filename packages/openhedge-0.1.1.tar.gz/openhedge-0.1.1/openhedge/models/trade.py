"""Trade-related data models."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class TradeType(str, Enum):
    SWAP = "swap"
    PERP_OPEN = "perp_open"
    PERP_CLOSE = "perp_close"
    LEND = "lend"
    WITHDRAW_LENDING = "withdraw_lending"
    RAW = "raw"


class TradeResult(BaseModel):
    """Result of a successfully executed trade."""

    tx_hash: str = Field(..., description="Transaction hash")
    trade_type: TradeType
    block_number: int = 0
    gas_used: int = 0
    status: int = Field(1, description="1 = success, 0 = reverted")
    adapter: Optional[str] = Field(None, description="Adapter contract address used")
    vault: Optional[str] = None
    details: Optional[dict] = Field(None, description="Adapter-specific decoded output")


class TradeQuote(BaseModel):
    """Pre-execution quote for a trade."""

    amount_in: int
    estimated_amount_out: int
    price_impact_bps: Optional[int] = None
    fee_bps: Optional[int] = None
    route: Optional[str] = None


class Position(BaseModel):
    """An open perpetual position on the Gains adapter."""

    trade_index: int = Field(..., description="On-chain trade index")
    vault: str
    pair_index: int
    pair_name: Optional[str] = None
    is_long: bool
    collateral: int = Field(..., description="Collateral in asset units")
    leverage: int
    take_profit: int = 0
    stop_loss: int = 0
    is_open: bool = True
