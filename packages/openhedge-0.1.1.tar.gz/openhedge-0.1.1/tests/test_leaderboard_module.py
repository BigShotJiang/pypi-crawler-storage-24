"""Tests for the LeaderboardModule."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from openhedge.exceptions import ServerError
from openhedge.models.leaderboard import LeaderboardEntry
from tests.conftest import make_api_response


class TestLeaderboardGet:
    async def test_get_leaderboard(self, agent):
        response_data = {
            "period": "7d",
            "updated_at": "2026-03-25T00:00:00Z",
            "vaults": [
                {
                    "vault_address": "0x" + "11" * 20,
                    "vault_name": "Alpha",
                    "trader": "0x" + "22" * 20,
                    "aum": 5000000,
                    "share_price": 1050000,
                    "return_bps": 500,
                    "rank": 1,
                },
                {
                    "vault_address": "0x" + "33" * 20,
                    "vault_name": "Beta",
                    "trader": "0x" + "44" * 20,
                    "aum": 3000000,
                    "share_price": 980000,
                    "return_bps": -200,
                    "rank": 2,
                },
            ],
        }
        with patch.object(
            agent._http,
            "get",
            new_callable=AsyncMock,
            return_value=make_api_response(response_data),
        ):
            lb = await agent.leaderboard.get(period="7d")

        assert isinstance(lb, LeaderboardEntry)
        assert lb.period == "7d"
        assert len(lb.vaults) == 2
        assert lb.vaults[0].rank == 1

    async def test_get_leaderboard_server_error(self, agent):
        with patch.object(
            agent._http,
            "get",
            new_callable=AsyncMock,
            return_value=make_api_response({"error": "internal"}, 500),
        ):
            with pytest.raises(ServerError):
                await agent.leaderboard.get()
