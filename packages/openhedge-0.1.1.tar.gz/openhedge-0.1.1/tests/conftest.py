"""Shared pytest fixtures for the OpenHedge SDK test suite."""

from __future__ import annotations

import json
from typing import Any, Dict
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from openhedge.client import OpenHedgeAgent


# ---------------------------------------------------------------------------
# Fake keys
# ---------------------------------------------------------------------------

FAKE_API_KEY = "oh_test_1234567890abcdef"
FAKE_PRIVATE_KEY = "0x" + "ab" * 32  # 64 hex chars
FAKE_VAULT = "0x" + "11" * 20
FAKE_ADAPTER = "0x" + "22" * 20
FAKE_TX_HASH = "0x" + "ff" * 32


# ---------------------------------------------------------------------------
# RPC mock helper
# ---------------------------------------------------------------------------

def make_rpc_response(result: Any) -> httpx.Response:
    """Build a fake httpx.Response carrying a JSON-RPC result."""
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "result": result})
    return httpx.Response(200, content=body.encode(), headers={"content-type": "application/json"})


def make_rpc_error(message: str, code: int = -32000) -> httpx.Response:
    body = json.dumps({
        "jsonrpc": "2.0", "id": 1,
        "error": {"code": code, "message": message},
    })
    return httpx.Response(200, content=body.encode(), headers={"content-type": "application/json"})


def make_api_response(data: Any, status: int = 200) -> httpx.Response:
    body = json.dumps(data)
    resp = httpx.Response(
        status,
        content=body.encode(),
        headers={"content-type": "application/json"},
        request=httpx.Request("GET", "https://api.openhedge.io/mock"),
    )
    return resp


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def agent():
    """Return an OpenHedgeAgent with mocked HTTP transport."""
    return OpenHedgeAgent(
        api_key=FAKE_API_KEY,
        wallet_private_key=FAKE_PRIVATE_KEY,
        network="base-testnet",
    )


@pytest.fixture
def readonly_agent():
    """Return an OpenHedgeAgent without a wallet key (read-only)."""
    return OpenHedgeAgent(
        api_key=FAKE_API_KEY,
        network="base-testnet",
    )


@pytest.fixture
def mock_receipt() -> Dict[str, Any]:
    """A minimal successful transaction receipt."""
    return {
        "transactionHash": FAKE_TX_HASH,
        "blockNumber": "0x10",
        "gasUsed": "0x30d40",
        "status": "0x1",
        "logs": [],
    }
