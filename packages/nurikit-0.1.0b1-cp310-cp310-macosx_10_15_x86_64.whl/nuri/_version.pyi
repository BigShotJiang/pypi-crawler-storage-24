from __future__ import annotations
__all__: list[str] = list()
__full_version__: str = '0.1.0b1'
__version__: str = '0.1.0b1'
