from __future__ import annotations
import numpy
import typing
__all__: list[str] = ['MmResult', 'match_maker']
class MmResult:
    @property
    def aligned_rmsd(self) -> float:
        """
        The root-mean-square deviation of the selected (inlier) points after alignment.
        """
    @property
    def selected(self) -> numpy.ndarray:
        """
        The final indices of the selected (inlier) points used in the alignment.
        """
    @property
    def transform(self) -> numpy.ndarray:
        """
        A copy of 4x4 best-fit rigid-body transformation tensor, to align ``query`` to
        ``template``.
        """
def match_maker(query: typing.Any, templ: typing.Any, cutoff: float = 2.0, global_ratio: float = 0.1, viol_ratio: float = 0.5) -> MmResult:
    """
    Perform the Match-Maker algorithm to find a rigid-body alignment between two
    sets of points. This is based on the Match-Maker algorithm used in UCSF Chimera.
    
    :param query: The query structure. Must be representable as a 2D numpy array of
      shape ``(N, 3)``.
    :param templ: The template structure. Must be representable as a 2D numpy array
      of shape ``(N, 3)``.
    :param cutoff: Distance cutoff in angstroms. A point pair is counted as a
      violation if its post-fit distance exceeds this threshold.
    :param global_ratio: Maximum fraction of currently considered aligned points
      that may be excluded as outliers in a single iteration.
    :param viol_ratio: Maximum fraction of currently violating points that may be
      excluded in a single iteration.
    :returns: The result of the Match-Maker alignment.
    
    .. note::
      The two point clouds must have the same number of points, and are assumed to
      be in correspondence by index. Each point should represent a single residue
      (e.g., ``CA`` atom) in a biomolecular structure.
    """
