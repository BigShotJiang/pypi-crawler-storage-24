/** @odoo-module **/

import { registry } from "@web/core/registry";
import { usePopover } from "@web/core/popover/popover_hook";
import { Component, onWillRender } from "@odoo/owl";

export class PurchaseOrderPopover extends Component {}

PurchaseOrderPopover.template = "gestion_editorial.PurchaseOrderPopover";

export class PurchaseOrderWidget extends Component {
    setup() {
        this.popover = usePopover(this.constructor.components.Popover, { position: "top" });
        this.calcData = {};

        onWillRender(() => {
            const { data } = this.props.record;
            const orderedQty = data.product_qty || 0;
            const partnerDepositQty = data.purchase_partner_deposit_qty || 0;
            // Icon color (red) based on purchase_partner_deposit_qty availability
            this.calcData.not_enough_deposit = orderedQty > partnerDepositQty;
        });
    }

    showPopup(ev) {
        this.popover.open(ev.currentTarget, {
            record: this.props.record,
        });
    }
}

PurchaseOrderWidget.components = { Popover: PurchaseOrderPopover };
PurchaseOrderWidget.template = "gestion_editorial.PurchaseOrderWidget";

export const purchaseOrderWidget = {
    component: PurchaseOrderWidget,
};

registry.category("view_widgets").add("purchase_order_widget", purchaseOrderWidget);
