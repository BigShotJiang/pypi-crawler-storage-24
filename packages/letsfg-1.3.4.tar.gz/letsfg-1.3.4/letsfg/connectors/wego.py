"""
Wego connector — CDP Chrome + API response interception.

Wego is a major metasearch engine popular in Middle East, South Asia,
and SE Asia.  Aggregates results from 700+ airlines and OTAs (Almosafer,
ClearTrip, Traveloka, etc.).

Strategy (CDP Chrome — Cloudflare protection):
1.  Launch real Chrome via CDP (--remote-debugging-port).
2.  Navigate to Wego search results page.
3.  Intercept XHR responses containing aggregated flight results.
4.  Parse into FlightOffers.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import time
from datetime import datetime, date as date_type
from typing import Any, Optional

from ..models.flights import (
    FlightOffer,
    FlightRoute,
    FlightSearchRequest,
    FlightSearchResponse,
    FlightSegment,
)
from .browser import find_chrome, stealth_popen_kwargs, _launched_procs

logger = logging.getLogger(__name__)

_CDP_PORT = 9481
_USER_DATA = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), ".wego_chrome_data"
)

_browser = None
_context = None
_pw_instance = None
_chrome_proc = None
_lock: Optional[asyncio.Lock] = None


def _get_lock() -> asyncio.Lock:
    global _lock
    if _lock is None:
        _lock = asyncio.Lock()
    return _lock


async def _get_context():
    global _browser, _context, _pw_instance, _chrome_proc
    lock = _get_lock()
    async with lock:
        if _browser:
            try:
                if _browser.is_connected():
                    if _context:
                        try:
                            _ = _context.pages
                            return _context
                        except Exception:
                            pass
                    contexts = _browser.contexts
                    if contexts:
                        _context = contexts[0]
                        return _context
            except Exception:
                pass

        from playwright.async_api import async_playwright

        pw = None
        try:
            pw = await async_playwright().start()
            _browser = await pw.chromium.connect_over_cdp(
                f"http://127.0.0.1:{_CDP_PORT}"
            )
            _pw_instance = pw
            logger.info("WEGO: connected to existing Chrome on port %d", _CDP_PORT)
        except Exception:
            if pw:
                try:
                    await pw.stop()
                except Exception:
                    pass

            chrome = find_chrome()
            os.makedirs(_USER_DATA, exist_ok=True)
            args = [
                chrome,
                f"--remote-debugging-port={_CDP_PORT}",
                f"--user-data-dir={_USER_DATA}",
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-blink-features=AutomationControlled",
                "--window-position=-2400,-2400",
                "--window-size=1366,768",
                "--lang=en-US",
                "about:blank",
            ]
            _chrome_proc = subprocess.Popen(args, **stealth_popen_kwargs())
            _launched_procs.append(_chrome_proc)
            await asyncio.sleep(2.5)

            pw = await async_playwright().start()
            _pw_instance = pw
            _browser = await pw.chromium.connect_over_cdp(
                f"http://127.0.0.1:{_CDP_PORT}"
            )
            logger.info("WEGO: Chrome launched CDP port %d pid %d", _CDP_PORT, _chrome_proc.pid)

        contexts = _browser.contexts
        _context = contexts[0] if contexts else await _browser.new_context()
        return _context


async def _reset_profile():
    global _browser, _context, _pw_instance, _chrome_proc
    try:
        if _browser:
            await _browser.close()
    except Exception:
        pass
    try:
        if _pw_instance:
            await _pw_instance.stop()
    except Exception:
        pass
    if _chrome_proc:
        try:
            _chrome_proc.terminate()
        except Exception:
            pass
    _browser = _context = _pw_instance = _chrome_proc = None
    if os.path.isdir(_USER_DATA):
        try:
            shutil.rmtree(_USER_DATA)
        except Exception:
            pass


def _to_datetime(val) -> datetime:
    if isinstance(val, datetime):
        return val
    if isinstance(val, date_type):
        return datetime(val.year, val.month, val.day)
    return datetime.strptime(str(val), "%Y-%m-%d")


def _parse_dt(s: Any) -> datetime:
    if not s:
        return datetime(2000, 1, 1)
    s = str(s)
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        pass
    for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(s[:len(fmt) + 2], fmt)
        except (ValueError, IndexError):
            continue
    return datetime(2000, 1, 1)


class WegoConnectorClient:
    """Wego — ME/Asia metasearch, CDP Chrome + API interception."""

    def __init__(self, timeout: float = 55.0):
        self.timeout = timeout

    async def close(self):
        pass

    async def search_flights(self, req: FlightSearchRequest) -> FlightSearchResponse:
        t0 = time.monotonic()
        dt = _to_datetime(req.date_from)
        date_str = dt.strftime("%Y-%m-%d")

        adults = req.adults or 1
        children = req.children or 0
        infants = req.infants or 0

        cabin_map = {"economy": "economy", "premium_economy": "premium_economy",
                     "business": "business", "first": "first"}
        cabin = cabin_map.get(
            getattr(req, "cabin_class", "economy") or "economy", "economy",
        )

        # Wego URL format: /flights/{origin}/{dest}/{date}
        search_url = (
            f"https://www.wego.com/flights/{req.origin}/{req.destination}"
            f"/{date_str}"
            f"?adults={adults}&children={children}&infants={infants}"
            f"&cabin={cabin}&sort=price"
        )

        for attempt in range(2):
            try:
                offers = await self._do_search(search_url, req, dt)
                if offers is not None:
                    offers.sort(key=lambda o: o.price if o.price > 0 else float("inf"))
                    elapsed = time.monotonic() - t0
                    logger.info(
                        "WEGO %s→%s: %d offers in %.1fs",
                        req.origin, req.destination, len(offers), elapsed,
                    )
                    h = hashlib.md5(
                        f"wego{req.origin}{req.destination}{req.date_from}".encode()
                    ).hexdigest()[:12]
                    return FlightSearchResponse(
                        search_id=f"fs_{h}",
                        origin=req.origin,
                        destination=req.destination,
                        currency=offers[0].currency if offers else "USD",
                        offers=offers,
                        total_results=len(offers),
                    )
            except Exception as e:
                logger.warning("WEGO attempt %d failed: %s", attempt, e)
                if attempt == 0:
                    await _reset_profile()

        return self._empty(req)

    async def _do_search(
        self, search_url: str, req: FlightSearchRequest, dt: datetime,
    ) -> list[FlightOffer] | None:
        context = await _get_context()
        page = await context.new_page()

        captured_data: list[dict] = []

        async def on_response(response):
            url = response.url
            # Wego makes API calls to srv.wego.com and/or internal APIs
            interesting = (
                ("srv.wego.com" in url and ("search" in url or "result" in url or "fares" in url))
                or ("wego.com/api" in url and "flight" in url)
                or ("wego.com" in url and "graphql" in url)
            )
            if not interesting:
                return
            try:
                ct = response.headers.get("content-type", "")
                if ("json" in ct or "graphql" in url) and response.status == 200:
                    body = await response.text()
                    data = json.loads(body)
                    if isinstance(data, dict):
                        captured_data.append(data)
                        logger.debug("WEGO: captured response from %s (%d bytes)", url, len(body))
            except Exception:
                pass

        page.on("response", on_response)

        try:
            logger.info("WEGO: navigating to %s", search_url)
            await page.goto(search_url, wait_until="domcontentloaded", timeout=30000)

            # Wego is a metasearch — results trickle in over time
            deadline = time.monotonic() + 40
            last_count = 0
            stable_ticks = 0
            while time.monotonic() < deadline:
                await asyncio.sleep(3)
                if len(captured_data) > last_count:
                    last_count = len(captured_data)
                    stable_ticks = 0
                else:
                    stable_ticks += 1
                    if stable_ticks >= 3 and captured_data:
                        break  # no new data for ~9s

            if not captured_data:
                logger.warning("WEGO: no API responses intercepted, trying DOM")
                return await self._extract_from_dom(page, req, dt)

            offers: list[FlightOffer] = []
            seen: set[str] = set()
            for data in captured_data:
                parsed = self._parse_response(data, req, dt, seen)
                offers.extend(parsed)

            return offers

        finally:
            try:
                await page.close()
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Response parsing
    # ------------------------------------------------------------------

    def _parse_response(
        self, data: dict, req: FlightSearchRequest, dt: datetime, seen: set,
    ) -> list[FlightOffer]:
        """Parse Wego metasearch API response data."""
        offers: list[FlightOffer] = []

        # Wego responses can nest results under various keys
        fares = (
            data.get("fares") or data.get("trips") or data.get("results")
            or data.get("itineraries") or data.get("flights") or []
        )

        # GraphQL responses
        if "data" in data and isinstance(data["data"], dict):
            gql = data["data"]
            fares = fares or (
                gql.get("flightSearch", {}).get("fares")
                or gql.get("flightSearch", {}).get("results")
                or gql.get("flights", {}).get("results")
                or []
            )

        # Lookup tables (Wego often sends airlines/airports separately)
        airlines_map = {}
        for a in data.get("airlines", []):
            if isinstance(a, dict):
                code = a.get("code") or a.get("iata") or ""
                airlines_map[code] = a.get("name") or code

        for fare in fares:
            try:
                offer = self._parse_fare(fare, req, dt, seen, airlines_map)
                if offer:
                    offers.append(offer)
            except Exception as e:
                logger.debug("WEGO: parse fare error: %s", e)

        return offers

    def _parse_fare(
        self, fare: dict, req: FlightSearchRequest, dt: datetime,
        seen: set, airlines_map: dict,
    ) -> FlightOffer | None:
        # Price
        price_obj = fare.get("price") or fare
        if isinstance(price_obj, dict):
            price = (
                price_obj.get("amount") or price_obj.get("totalAmount")
                or price_obj.get("price") or 0
            )
            currency = (
                price_obj.get("currencyCode") or price_obj.get("currency") or "USD"
            )
        else:
            try:
                price = float(price_obj)
            except (ValueError, TypeError):
                return None
            currency = "USD"

        try:
            price_f = round(float(price), 2)
        except (ValueError, TypeError):
            return None
        if price_f <= 0:
            return None

        # Segments / legs
        legs = fare.get("legs") or fare.get("segments") or fare.get("slices") or []
        if not legs:
            # Flat fare structure
            legs = [fare]

        segments: list[FlightSegment] = []
        for leg in legs:
            seg_items = leg.get("segments") or [leg]
            for sd in seg_items:
                airline_code = (
                    sd.get("airlineCode") or sd.get("operatingCarrier")
                    or sd.get("marketingCarrier") or sd.get("airline") or ""
                )
                airline_name = (
                    sd.get("airlineName") or airlines_map.get(airline_code, "")
                    or airline_code
                )
                fno = sd.get("flightNumber") or sd.get("flightNo") or ""
                if airline_code and fno and not fno.startswith(airline_code):
                    fno = f"{airline_code}{fno}"

                dep_time = (
                    sd.get("departureTime") or sd.get("departure")
                    or sd.get("departureDateTime") or ""
                )
                arr_time = (
                    sd.get("arrivalTime") or sd.get("arrival")
                    or sd.get("arrivalDateTime") or ""
                )
                dep_apt = (
                    sd.get("departureAirportCode") or sd.get("departureCode")
                    or sd.get("origin") or req.origin
                )
                arr_apt = (
                    sd.get("arrivalAirportCode") or sd.get("arrivalCode")
                    or sd.get("destination") or req.destination
                )
                dur = sd.get("durationMinutes") or sd.get("duration") or 0
                dur_s = int(dur) * 60 if isinstance(dur, (int, float)) and dur > 0 else 0

                segments.append(FlightSegment(
                    airline=airline_code or airline_name,
                    airline_name=airline_name,
                    flight_no=fno,
                    origin=dep_apt,
                    destination=arr_apt,
                    departure=_parse_dt(dep_time) if dep_time else dt,
                    arrival=_parse_dt(arr_time) if arr_time else dt,
                    duration_seconds=dur_s,
                    cabin_class="economy",
                ))

        if not segments:
            return None

        total_dur = sum(s.duration_seconds for s in segments)
        if not total_dur and segments[0].departure != segments[-1].arrival:
            diff = (segments[-1].arrival - segments[0].departure).total_seconds()
            if 0 < diff < 86400 * 3:
                total_dur = int(diff)

        fno_key = "_".join(s.flight_no for s in segments)
        dedup = f"{req.origin}_{req.destination}_{dt:%Y%m%d}_{price_f}_{fno_key}"
        if dedup in seen:
            return None
        seen.add(dedup)

        airlines_set = list(dict.fromkeys(s.airline for s in segments if s.airline))
        names_set = list(dict.fromkeys(
            s.airline_name for s in segments if s.airline_name
        ))

        route = FlightRoute(
            segments=segments,
            total_duration_seconds=total_dur,
            stopovers=max(0, len(segments) - 1),
        )

        fid = hashlib.md5(dedup.encode()).hexdigest()[:12]
        return FlightOffer(
            id=f"wego_{fid}",
            price=price_f,
            currency=currency,
            price_formatted=f"{price_f:.2f} {currency}",
            outbound=route,
            inbound=None,
            airlines=names_set or airlines_set,
            owner_airline=airlines_set[0] if airlines_set else "",
            booking_url=(
                f"https://www.wego.com/flights/{req.origin}/{req.destination}"
                f"/{dt:%Y-%m-%d}?adults={req.adults or 1}"
            ),
            is_locked=False,
            source="wego_meta",
            source_tier="free",
        )

    # ------------------------------------------------------------------
    # DOM fallback
    # ------------------------------------------------------------------

    async def _extract_from_dom(
        self, page, req: FlightSearchRequest, dt: datetime,
    ) -> list[FlightOffer]:
        """Fallback: scrape visible fare cards from the Wego results page."""
        try:
            data = await page.evaluate("""() => {
                const cards = document.querySelectorAll(
                    '[class*="FareCard"], [class*="fare-card"], '
                  + '[class*="ResultCard"], [class*="result-card"], '
                  + '[data-testid*="fare"], [data-testid*="result"]'
                );
                const out = [];
                cards.forEach(c => {
                    const p = c.querySelector(
                        '[class*="price"], [class*="Price"], [data-testid*="price"]'
                    );
                    const a = c.querySelector(
                        '[class*="airline"], [class*="Airline"], [data-testid*="airline"]'
                    );
                    const d = c.querySelector(
                        '[class*="duration"], [class*="Duration"]'
                    );
                    const stops = c.querySelector(
                        '[class*="stop"], [class*="Stop"]'
                    );
                    if (p) out.push({
                        price: p.textContent.trim(),
                        airline: a ? a.textContent.trim() : '',
                        duration: d ? d.textContent.trim() : '',
                        stops: stops ? stops.textContent.trim() : '',
                    });
                });
                return out;
            }""")

            offers: list[FlightOffer] = []
            seen: set[str] = set()
            for item in data or []:
                nums = re.findall(r"[\d]+", item.get("price", "").replace(",", ""))
                if not nums:
                    continue
                try:
                    price_f = round(float(nums[-1]), 2)
                except (ValueError, IndexError):
                    continue
                if price_f <= 0:
                    continue

                airline = item.get("airline") or "Unknown"
                dedup = f"{req.origin}_{req.destination}_{price_f}_{airline}"
                if dedup in seen:
                    continue
                seen.add(dedup)

                seg = FlightSegment(
                    airline=airline, flight_no="",
                    origin=req.origin, destination=req.destination,
                    departure=dt, arrival=dt, duration_seconds=0,
                )
                route = FlightRoute(segments=[seg], total_duration_seconds=0, stopovers=0)
                fid = hashlib.md5(dedup.encode()).hexdigest()[:12]
                offers.append(FlightOffer(
                    id=f"wego_{fid}",
                    price=price_f,
                    currency="USD",
                    price_formatted=f"{price_f:.2f} USD",
                    outbound=route,
                    inbound=None,
                    airlines=[airline],
                    owner_airline="",
                    booking_url=(
                        f"https://www.wego.com/flights/{req.origin}"
                        f"/{req.destination}/{dt:%Y-%m-%d}"
                    ),
                    is_locked=False,
                    source="wego_meta",
                    source_tier="free",
                ))
            return offers
        except Exception as e:
            logger.debug("WEGO: DOM extraction failed: %s", e)
            return []

    @staticmethod
    def _empty(req: FlightSearchRequest) -> FlightSearchResponse:
        h = hashlib.md5(
            f"wego{req.origin}{req.destination}{req.date_from}".encode()
        ).hexdigest()[:12]
        return FlightSearchResponse(
            search_id=f"fs_{h}",
            origin=req.origin,
            destination=req.destination,
            currency="USD",
            offers=[],
            total_results=0,
        )
