# Copyright 2019 Ecosoft Co., Ltd (http://ecosoft.co.th/)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html)

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class ResPartner(models.Model):
    _inherit = "res.partner"

    name_company = fields.Char(index=True)
    company_registry = fields.Char(string="Branch", copy=False)

    @api.constrains("company_id", "vat", "company_registry")
    def _check_company_id_vat_branch(self):
        Partner = self.env["res.partner"]
        for rec in self.sudo():
            if rec.vat and rec.company_registry:
                domain = [
                    ("vat", "=", rec.vat),
                    ("company_registry", "=", rec.company_registry),
                ]
                if rec.company_id:
                    domain += [("company_id", "=", rec.company_id.id)]
                partners = Partner.search_count(domain)
                if partners > 1:
                    raise ValidationError(
                        self.env._(
                            "Each contact's Tax ID and Tax Branch "
                            "should not be the same."
                        )
                    )

    @api.model
    def _get_computed_name(self, lastname, firstname):
        name = super()._get_computed_name(lastname, firstname)
        title = self.title.name
        if name and title:
            # disable space on title and name
            if self.env.company.no_space_title_name:
                return "".join(p for p in (title, name) if p)
            return " ".join(p for p in (title, name) if p)
        return name

    @api.depends(
        "title", "firstname", "lastname", "name_company", "partner_company_type_id"
    )
    def _compute_name(self):
        """Compute name with company only"""
        partner_company = self.filtered(
            lambda partner: partner.is_company and partner.name_company
        )
        partner_inv = self - partner_company
        for rec in partner_company:
            prefix, suffix = False, False
            if rec.partner_company_type_id.use_prefix_suffix:
                prefix = rec.partner_company_type_id.prefix
                suffix = rec.partner_company_type_id.suffix
            rec.name = " ".join(p for p in (prefix, rec.name_company, suffix) if p)
            rec._inverse_name()
        return super(ResPartner, partner_inv)._compute_name()

    @api.onchange("company_type")
    def _onchange_company_type(self):
        if self.company_type == "company":
            self.title = False
        else:
            self.partner_company_type_id = False

    def _inverse_name_after_cleaning_whitespace(self):
        """Skip inverse name for case chaging translation and title"""
        if not self.env.context.get("skip_inverse_name"):
            return super()._inverse_name_after_cleaning_whitespace()
