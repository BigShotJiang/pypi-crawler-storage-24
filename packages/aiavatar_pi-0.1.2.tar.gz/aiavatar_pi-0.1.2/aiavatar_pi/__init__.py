from .base import AIAvatarClientBase
