class APIKeyNotFoundError(Exception):
    pass
