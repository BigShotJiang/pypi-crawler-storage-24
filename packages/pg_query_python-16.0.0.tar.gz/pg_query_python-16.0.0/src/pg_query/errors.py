"""Error handling for libpg_query C results."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ctypes import Structure


class PgQueryError(Exception):
    """Raised when libpg_query rejects a SQL statement."""

    def __init__(
        self,
        message: str,
        *,
        cursorpos: int = 0,
        context: str | None = None,
        funcname: str | None = None,
        filename: str | None = None,
        lineno: int = 0,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.cursorpos = cursorpos
        self.context = context
        self.funcname = funcname
        self.filename = filename
        self.lineno = lineno


def check_error(result: Structure) -> None:
    """Inspect a C result struct's error pointer and raise PgQueryError if set."""
    err_ptr = result.error
    if not err_ptr:
        return

    err = err_ptr.contents
    message = err.message.decode("utf-8") if err.message else "unknown error"
    context = err.context.decode("utf-8") if err.context else None
    funcname = err.funcname.decode("utf-8") if err.funcname else None
    filename = err.filename.decode("utf-8") if err.filename else None

    raise PgQueryError(
        message,
        cursorpos=err.cursorpos,
        context=context,
        funcname=funcname,
        filename=filename,
        lineno=err.lineno,
    )
