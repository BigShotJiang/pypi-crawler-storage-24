"""Python bindings for libpg_query.

Parse, deparse, and walk PostgreSQL SQL statements using libpg_query's C
parser (BSD-3-Clause) via ctypes, with protobuf for the AST representation.
"""

from __future__ import annotations

import ctypes
from typing import TYPE_CHECKING

from . import pg_query_pb2
from .errors import PgQueryError, check_error
from .native import PgQueryProtobuf, lib
from .visitor import Visitor, unwrap_node, walk

if TYPE_CHECKING:
    from .pg_query_pb2 import ParseResult

__all__ = [
    "PgQueryError",
    "Visitor",
    "deparse",
    "parse",
    "pg_query_pb2",
    "unwrap_node",
    "walk",
]

__version__ = "17.0.0"


def parse(query: str) -> ParseResult:
    """Parse a SQL string into a protobuf AST (ParseResult)."""
    result = lib.pg_query_parse_protobuf(query.encode("utf-8"))
    try:
        check_error(result)
        pbuf = result.parse_tree
        data = ctypes.string_at(pbuf.data, pbuf.len)
        return pg_query_pb2.ParseResult.FromString(data)
    finally:
        lib.pg_query_free_protobuf_parse_result(result)


def deparse(tree: ParseResult) -> str:
    """Convert a (possibly modified) protobuf AST back to a SQL string."""
    data = tree.SerializeToString()
    buf = ctypes.create_string_buffer(data)
    pbuf = PgQueryProtobuf(len=len(data), data=ctypes.cast(buf, ctypes.c_void_p).value)
    result = lib.pg_query_deparse_protobuf(pbuf)
    try:
        check_error(result)
        query_bytes: bytes = result.query
        return query_bytes.decode("utf-8")
    finally:
        lib.pg_query_free_deparse_result(result)
