"""Low-level ctypes bindings to libpg_query.

Loads the shared library bundled in this package, defines C struct layouts
for parse and deparse results, and declares the function signatures we need.

libpg_query is BSD-3-Clause: https://github.com/pganalyze/libpg_query
"""

from __future__ import annotations

import ctypes
import ctypes.util
import platform
from ctypes import POINTER, Structure, c_char_p, c_int, c_size_t, c_void_p
from pathlib import Path

_LIB_NAMES = {
    "Linux": "libpg_query.so",
    "Darwin": "libpg_query.dylib",
    "Windows": "pg_query.dll",
}


def _load_libpg_query() -> ctypes.CDLL:
    lib_name = _LIB_NAMES.get(platform.system())
    if lib_name is not None:
        bundled = Path(__file__).parent / lib_name
        if bundled.is_file():
            return ctypes.CDLL(str(bundled))

    path = ctypes.util.find_library("pg_query")
    if path is not None:
        return ctypes.CDLL(path)

    raise OSError(
        "libpg_query shared library not found. "
        "Reinstall pg-query-python or ensure libpg_query is on your "
        "library search path (LD_LIBRARY_PATH / DYLD_LIBRARY_PATH)."
    )


class _PgQueryError(Structure):
    _fields_ = [
        ("message", c_char_p),
        ("funcname", c_char_p),
        ("filename", c_char_p),
        ("lineno", c_int),
        ("cursorpos", c_int),
        ("context", c_char_p),
    ]


class PgQueryProtobuf(Structure):
    """len + data pair for protobuf payloads.

    Uses c_void_p for data because protobuf binary contains embedded nulls
    that c_char_p would truncate.
    """

    _fields_ = [
        ("len", c_size_t),
        ("data", c_void_p),
    ]


class PgQueryProtobufParseResult(Structure):
    _fields_ = [
        ("parse_tree", PgQueryProtobuf),
        ("stderr_buffer", c_char_p),
        ("error", POINTER(_PgQueryError)),
    ]


class PgQueryDeparseResult(Structure):
    _fields_ = [
        ("query", c_char_p),
        ("error", POINTER(_PgQueryError)),
    ]


lib = _load_libpg_query()

lib.pg_query_parse_protobuf.argtypes = [c_char_p]
lib.pg_query_parse_protobuf.restype = PgQueryProtobufParseResult

lib.pg_query_deparse_protobuf.argtypes = [PgQueryProtobuf]
lib.pg_query_deparse_protobuf.restype = PgQueryDeparseResult

lib.pg_query_free_protobuf_parse_result.argtypes = [PgQueryProtobufParseResult]
lib.pg_query_free_protobuf_parse_result.restype = None

lib.pg_query_free_deparse_result.argtypes = [PgQueryDeparseResult]
lib.pg_query_free_deparse_result.restype = None
