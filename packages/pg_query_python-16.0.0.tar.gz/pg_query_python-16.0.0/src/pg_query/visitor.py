"""Tree walking and Visitor pattern for libpg_query protobuf parse trees."""

from __future__ import annotations

from typing import TYPE_CHECKING

from google.protobuf.descriptor import FieldDescriptor
from google.protobuf.message import Message

if TYPE_CHECKING:
    from collections.abc import Generator

_NODE_ONEOF = "node"


def unwrap_node(node: Message) -> Message:
    """If *node* is a Node oneof wrapper, return the inner concrete message."""
    oneofs = type(node).DESCRIPTOR.oneofs
    if len(oneofs) == 1 and oneofs[0].name == _NODE_ONEOF:
        which = node.WhichOneof(_NODE_ONEOF)
        if which is not None:
            return getattr(node, which)
    return node


def _iter_children(node: Message) -> Generator[tuple[str, Message], None, None]:
    for fd, value in node.ListFields():
        if fd.type != FieldDescriptor.TYPE_MESSAGE:
            continue
        if isinstance(value, Message):
            yield fd.name, unwrap_node(value)
        else:
            for item in value:
                yield fd.name, unwrap_node(item)


def walk(node: Message) -> Generator[tuple[str, Message], None, None]:
    """Depth-first pre-order traversal, unwrapping Node oneof wrappers."""
    node = unwrap_node(node)
    yield "", node
    stack: list[tuple[str, Message]] = list(reversed(list(_iter_children(node))))
    while stack:
        field_name, child = stack.pop()
        yield field_name, child
        stack.extend(reversed(list(_iter_children(child))))


class Visitor:
    """Subclass and override ``visit_<TypeName>`` methods to handle specific
    protobuf node types (e.g. ``visit_RangeVar``, ``visit_SelectStmt``).

    Unhandled types fall through to ``generic_visit`` which recurses into children.
    Call ``visit()`` on a root message to start traversal.
    """

    def visit(self, node: Message) -> None:
        node = unwrap_node(node)
        type_name = type(node).DESCRIPTOR.name
        handler = getattr(self, f"visit_{type_name}", self.generic_visit)
        handler(node)

    def generic_visit(self, node: Message) -> None:
        for _field_name, child in _iter_children(node):
            self.visit(child)
