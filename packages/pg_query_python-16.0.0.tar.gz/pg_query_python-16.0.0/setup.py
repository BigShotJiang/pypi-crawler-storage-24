"""Custom build that compiles libpg_query from source and places the shared
library inside the pg_query package before wheel packing."""

import os
import platform
import shutil
import subprocess
import tempfile
from pathlib import Path

from setuptools import setup
from setuptools.command.build_ext import build_ext
from setuptools.dist import Distribution
from setuptools.extension import Extension

LIBPG_QUERY_TAG = os.environ.get("LIBPG_QUERY_TAG", "16-latest")
PACKAGE_DIR = Path(__file__).parent / "src" / "pg_query"

LIB_NAMES = {
    "Linux": "libpg_query.so",
    "Darwin": "libpg_query.dylib",
    "Windows": "pg_query.dll",
}


class BuildLibPgQuery(build_ext):
    """Clone pganalyze/libpg_query and build the shared library."""

    def run(self) -> None:
        lib_name = LIB_NAMES.get(platform.system())
        if lib_name is None:
            raise OSError(f"Unsupported platform: {platform.system()}")

        with tempfile.TemporaryDirectory() as build_dir:
            repo_dir = Path(build_dir) / "libpg_query"
            subprocess.check_call(
                [
                    "git",
                    "clone",
                    "--depth",
                    "1",
                    "--branch",
                    LIBPG_QUERY_TAG,
                    "https://github.com/pganalyze/libpg_query.git",
                    str(repo_dir),
                ]
            )

            env = os.environ.copy()
            archflags = env.get("ARCHFLAGS", "")
            if archflags:
                env["CFLAGS"] = env.get("CFLAGS", "") + " " + archflags
                env["LDFLAGS"] = env.get("LDFLAGS", "") + " " + archflags

            subprocess.check_call(
                ["make", "build_shared"],
                cwd=str(repo_dir),
                env=env,
            )

            dest = Path(self.build_lib) / "pg_query" / lib_name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(repo_dir / lib_name), str(dest))


class BinaryDistribution(Distribution):
    """Mark the distribution as platform-specific (not pure-Python)."""

    def has_ext_modules(self) -> bool:
        return True


_dummy_ext = Extension("pg_query._dummy", sources=[])

setup(
    ext_modules=[_dummy_ext],
    cmdclass={"build_ext": BuildLibPgQuery},
    distclass=BinaryDistribution,
)
