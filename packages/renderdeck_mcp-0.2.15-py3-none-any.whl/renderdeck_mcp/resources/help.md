# RenderDeck Help




RenderDeck is an MCP server that generates PowerPoint presentations from markdown prompt files. You write a structured prompt file describing your slides, and RenderDeck generates images via Google Gemini and assembles them into a .pptx with formatted speaker notes.


## Some example Prompts

Just tell your LLM what you need — no need to learn the prompt file format:

> "Create a 10-slide deck on our Q1 product roadmap for the engineering all-hands. Audience: 50 engineers. Tone: confident but honest about delays. Include a timeline slide and a risks slide."

The LLM reads the reference, drafts a prompt file with 10 slides, validates it, and calls generate_deck.

> "I have a blog post about our new API. Turn it into a 7-slide technical presentation for DevRel to present at a meetup. Use dark theme with code snippets on slides."

The LLM distills the blog post into key points, structures them as slides, and generates visuals matching the dark theme.

> "Here is our investor update email [paste text]. Create a 12-slide board deck. Use notes_mode narration so I can feed it into Pictory for a video version."

The LLM extracts metrics and narrative from the email, builds slides with **Say:** notes for narration, and generates with notes_mode=narration.

## Getting the Best Results

For best results, do not jump straight to slide generation. First ask the LLM to help you develop the raw material:

1. **BRAINSTORM** — Tell the LLM your topic, audience, and goal. Ask it to outline key messages and a narrative arc.
   > "I need a presentation about [topic] for [audience]. The goal is [goal]. Help me identify the 5-7 key messages and suggest a narrative arc."

2. **STRUCTURE** — Ask the LLM to organise the outline into a slide sequence with one idea per slide and clear transitions.
   > "Organise these messages into a slide-by-slide outline. One idea per slide, with clear transitions. Suggest a title for each slide."

3. **ENRICH** — Paste in any source material (docs, emails, data, meeting notes). Ask the LLM to distill the most compelling points for your audience.
   > "Here is my source material: [paste docs/emails/data]. Distill the most compelling points for my audience and weave them into the outline."

4. **GENERATE** — Once the storyline is solid, say "now generate the deck". The LLM writes the prompt file and calls the tools.
   > "The outline looks good. Now generate the deck using RenderDeck."

5. **ITERATE** — Review the .pptx, then ask the LLM to tweak individual slides, adjust visuals, or reword notes.
   > "Slide 4 needs a stronger visual — make it more data-driven. And reword the speaker notes on slide 7 to be more conversational."

> **Pro tip:** The more context you give the LLM up front (audience, tone, key data points, what to emphasise, what to skip), the better the first draft. Treat the LLM as a presentation coach, not just a generator.


## Tools

| Tool | Description | Key params |
|------|-------------|------------|
| `generate_deck` | Full pipeline: parse, generate images, assemble .pptx | slide_prompt_content, image_quality, notes_mode |
| `validate_prompt_file` | Dry-run validation — checks syntax and structure, no image generation | slide_prompt_content |
| `generate_slide` | Generate one slide image and cache it (avoids timeouts) | project_name, slide_number, image_prompt |
| `assemble_deck` | Assemble .pptx from cached slide images | project_name, slide_prompt_content, notes_mode |
| `regenerate_slide` | Re-generate specific slides and rebuild the .pptx | project_name, slide_numbers, slide_prompt_content |
| `setup_gemini_key` | Store and validate your Gemini API key | api_key |
| `get_setup_status` | Check API key config and current settings | none |
| `update_settings` | Change aspect ratio, model, output dir | aspect_ratio, gemini_image_model, default_output_dir |
| `get_version` | Return the server version | none |
| `get_help` | Show this help (you are here) | none |

## Prompts

| Prompt | Description | Params | Example |
|--------|-------------|--------|---------|
| `create_deck` | Guided end-to-end workflow: reads reference, writes, validates, generates | topic (string) | `create_deck(topic="Q1 engineering review")` |
| `check_and_fix` | Validate a prompt file and get error-by-error fix suggestions | content (string) | `check_and_fix(content="# My Deck...")` |

## Resources

| Resource | Description |
|----------|-------------|
| `renderdeck://reference` | Complete reference for writing slide prompt files |


## More information
Check out the **PyPI:** distro at https://pypi.org/project/renderdeck-mcp
