import importlib
import inspect

from collections import abc
from typing import List, Any, Dict, Callable, Optional, Union, Iterable, Mapping

from omegaconf import DictConfig, OmegaConf
import hydra


def regularize_function_table(
        functions: Union[Callable, Iterable[Callable], Mapping[str, Callable]],
        underscore_or_hyphen='_'
) -> Dict[str, Callable]:
    """
    Convert a function or a list of functions to a dictionary of name to function mapping.

    Args:
        functions: A function or a collection of functions to be regularized.
        underscore_or_hyphen: Normalize the function names to use either underscores or hyphens.

    Returns:
        Dict[str, Callable]: A dictionary of name to function mapping.
    """
    if isinstance(functions, Mapping):
        name2func = functions

    else:
        # single function -> a list of function -> name to function mapping
        functions = [functions] if isinstance(functions, Callable) else functions  # Ensure it is Iterable
        name2func = {fn.__name__: fn for fn in functions}

    if underscore_or_hyphen == '-':
        name2func = {k.replace('_', '-'): v for k, v in name2func.items()}
    elif underscore_or_hyphen == '_':
        name2func = {k.replace('-', '_'): v for k, v in name2func.items()}
    else:
        raise ValueError('underscore_or_hyphen must be either "_" or "-"')

    return name2func


def extract_function_table(x: object, only_public=True) -> Dict[str, Callable]:
    """
    Return a dictionary of the method names and the corresponding functions of an object or a class.
    For a class, only staticmethod or classmethod are extracted (normal methods are unbounded).
    For an object instance, all methods are extracted (staticmethod, classmethod, and bounded normal method).

    Args:
        x (object): The object or class to extract methods from.
        only_public (bool): Whether to only include public methods (not starting with '_').
    """
    pred_only_public = (lambda k: not k.startswith('_')) if only_public else (lambda k: True)

    is_class = isinstance(x, type)
    cls = x if is_class else type(x)
    customized_name2func = {k: v for k, v in cls.__dict__.items() if pred_only_public(k)}
    if is_class:
        # Only staticmethod or classmethod is viable for a type (normal methods are unbounded)
        # Use attributes from the instance so that the methods are unwrapped
        name2func = {k: getattr(x, k) for k, v in customized_name2func.items() if
                     isinstance(v, (staticmethod, classmethod))}
    else:
        # use attributes from the instance so that the methods are bounded
        name2func = {k: getattr(x, k) for k, v in customized_name2func.items() if inspect.isfunction(v)}
    return name2func


def arbitary_object_import(object_ref: str, separator: str = ':') -> Any:
    """Mimicing distributing entry points, import an arbitrary object from a module path.
    Args:
        object_ref: format in `module.path[:object.path]`
    """
    modname, qualname_separator, qualname = object_ref.partition(separator)
    """Example: 'importable.module:object.attr'.partition(':')
    => ('importable.module', ':', 'object.attr')
    """
    obj = importlib.import_module(modname)
    if qualname_separator:
        for attr in qualname.split('.'):
            obj = getattr(obj, attr)
    return obj


def _omegaconf_resolver_import(path: str):
    return arbitary_object_import(path)


BIXI_RESOLVERS = {
    'bixi.import': _omegaconf_resolver_import,
    'bixi.eval': eval,
}


def _init_bixi_resolvers():
    for name, fn in BIXI_RESOLVERS.items():
        if not OmegaConf.has_resolver(name):
            OmegaConf.register_new_resolver(name, fn)


def hydra_instantiate(cfg: abc.Mapping, *args, _convert_="partial", **kwargs) -> Any:
    """Instantiate a DictConfig for Hydra, with additional resolver supports.
    Check reference: [Resolvers — OmegaConf 2.4.0.dev3 documentation]( https://omegaconf.readthedocs.io/en/latest/custom_resolvers.html#clear-resolver )
    Args:
        cfg: The configuration to instantiate. Must contain a '_target_' key.
        _convert_: str: The conversion mode for hydra.utils.instantiate.
            use "partial" to convert only ListConfig/DictConfig args to list/dict
    """
    obj = hydra.utils.instantiate(cfg, *args, _convert_=_convert_, **kwargs)
    return obj


# Initialize the Bixi resolvers when the module is imported
_init_bixi_resolvers()
