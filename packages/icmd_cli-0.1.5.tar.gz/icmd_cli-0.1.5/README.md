# iCMD

An AI-powered command line tool using local LLM (qwen2.5-coder).

## Installation

```bash
pip install icmd
