"""Merkezi kolon/kriter tanım yöneticisi.

Kaynak: feature_info.xlsx → feature_info.json (init sırasında dönüşüm)
Runtime: feature_info.json okunur (hızlı, openpyxl bağımlılığı yok)

Kullanım:
    from ews_scoreboard.feature_info import FI

    FI.kik_ciss_cols        # CISS kontrolüne dahil KIK kolonları
    FI.kik_all_cols         # Tüm KIK kontrol kolonları (CISS + special)
    FI.rkd_codes            # eu_n_yi_rkd_list karşılığı
    FI.rkd_sifir_cols       # Sıfır olması gereken RKD kolonları (kod_suffix)
    FI.rkd_uzak_cols        # Gün mesafesi kontrolü kolonları
    FI.rkd_delta_suffixes   # Delta hesabına dahil suffix'ler
    FI.kriter_aciklama      # kod → açıklama dict
    FI.delta_exclude_cols   # Delta hesabından hariç tutulan kolonlar
    FI.grup_for_rkd(code)   # RKD kodu → grup adı
    FI.grup_for_kik(col)    # KIK kolonu → grup adı
    FI.memzuc_kontrol_cols  # Memzuc nonzero kontrol kolonları
"""

import json
import warnings
from pathlib import Path


class FeatureInfo:
    def __init__(self):
        self._data = None

    def _load(self):
        """Lazy load — ilk erişimde JSON oku."""
        if self._data is not None:
            return

        for candidate in [
            Path("feature_info.json"),
            Path(__file__).parent / "data" / "feature_info.json",
        ]:
            if candidate.exists():
                self._data = json.loads(candidate.read_text(encoding="utf-8"))
                return

        warnings.warn(
            "feature_info.json bulunamadı, default değerler kullanılıyor. "
            "'ews-scoreboard init' çalıştırın.",
            stacklevel=2,
        )
        self._data = _FALLBACK_DATA

    # ── KIK ──

    @property
    def kik_ciss_cols(self):
        """CISS kontrolüne dahil KIK kolonları (ciss=1)."""
        self._load()
        return list(dict.fromkeys(
            r["kolon_adi"] for r in self._data["kik"] if r.get("ciss") == 1
        ))

    @property
    def kik_all_cols(self):
        """Tüm KIK kontrol kolonları."""
        self._load()
        return list(dict.fromkeys(r["kolon_adi"] for r in self._data["kik"]))

    @property
    def kik_delta_cols(self):
        """KIK delta hesabına dahil kolonlar (delta_dahil=1)."""
        self._load()
        return list(dict.fromkeys(
            r["kolon_adi"] for r in self._data["kik"] if r.get("delta_dahil") == 1
        ))

    def grup_for_kik(self, col):
        """KIK kolonu → grup adı."""
        self._load()
        for r in self._data["kik"]:
            if r["kolon_adi"] == col:
                return r.get("grup")
        return None

    # ── RKD ──

    @property
    def rkd_codes(self):
        """EUS kapsam RKD kriter kod listesi (eu_n_yi_rkd_list karşılığı)."""
        self._load()
        return [r["kod"] for r in self._data["rkd"] if r.get("eus_kapsam", 1) != 0]

    @property
    def rkd_all_codes(self):
        """Tüm RKD kriter kodları (diag grupları dahil)."""
        self._load()
        return [r["kod"] for r in self._data["rkd"]]

    @property
    def rkd_sifir_cols(self):
        """Sıfır olması gereken RKD kolonları (kod_SUFFIX formatında)."""
        self._load()
        cols = []
        for r in self._data["rkd"]:
            for sfx in ["suffix_a", "suffix_asgd", "suffix_aigd"]:
                if r.get(sfx) == "sifir":
                    suffix_name = sfx.replace("suffix_", "").upper()
                    cols.append(f"{r['kod']}_{suffix_name}")
        return cols

    @property
    def rkd_uzak_cols(self):
        """Gün mesafesi kontrolü kolonları (kod_SUFFIX formatında)."""
        self._load()
        cols = []
        for r in self._data["rkd"]:
            for sfx in ["suffix_pscd", "suffix_pigd"]:
                if r.get(sfx) == "uzak":
                    suffix_name = sfx.replace("suffix_", "").upper()
                    cols.append(f"{r['kod']}_{suffix_name}")
        return cols

    @property
    def rkd_delta_suffixes(self):
        """Delta hesabına dahil suffix'ler: ['A', 'P'] vb."""
        self._load()
        suffixes = set()
        for r in self._data["rkd"]:
            if r.get("suffix_a") in ("sifir", "delta"):
                suffixes.add("A")
            if r.get("suffix_p") == "delta":
                suffixes.add("P")
        return sorted(suffixes)

    def grup_for_rkd(self, code):
        """RKD kodu → grup adı."""
        self._load()
        for r in self._data["rkd"]:
            if r["kod"] == code:
                return r.get("grup")
        return None

    # ── Memzuc ──

    @property
    def memzuc_kontrol_cols(self):
        """Memzuc nonzero kontrol kolonları."""
        self._load()
        return [r["kolon_adi"] for r in self._data["memzuc"]
                if r.get("kontrol_tipi") == "nonzero"]

    @property
    def memzuc_delta_cols(self):
        """Memzuc delta hesabına dahil kolonlar."""
        self._load()
        return [r["kolon_adi"] for r in self._data["memzuc"]
                if r.get("delta_dahil") == 1]

    def grup_for_memzuc(self, col):
        """Memzuc kolonu → grup adı."""
        self._load()
        for r in self._data["memzuc"]:
            if r["kolon_adi"] == col:
                return r.get("grup")
        return None

    # ── Cross-cutting ──

    @property
    def kriter_aciklama(self):
        """Tüm kriter kodu → açıklama dict (RKD + KIK + izleme)."""
        self._load()
        d = {}
        for r in self._data.get("izleme_kriterleri", []):
            d[r["kod"]] = r["aciklama"]
        for r in self._data["rkd"]:
            d[r["kod"]] = r["aciklama"]
        for r in self._data["kik"]:
            d[r["kolon_adi"]] = r["aciklama"]
        for r in self._data["memzuc"]:
            d[r["kolon_adi"]] = r["aciklama"]
        return d

    @property
    def delta_exclude_cols(self):
        """Delta hesabından hariç tutulan kolonlar (asla yeni=1 olamaz)."""
        self._load()
        cols = []
        for sheet in ["kik", "memzuc"]:
            for r in self._data.get(sheet, []):
                if r.get("delta_dahil") == 0:
                    cols.append(r.get("kolon_adi", ""))
        return [c for c in cols if c]

    # ── Reverse mappings (diag_groups uyumlu) ──

    @property
    def rkd_code_to_group(self):
        """RKD kodu → grup dict."""
        self._load()
        return {r["kod"]: r["grup"] for r in self._data["rkd"] if r.get("grup")}

    @property
    def kik_col_to_group(self):
        """KIK kolonu → grup dict."""
        self._load()
        return {r["kolon_adi"]: r["grup"] for r in self._data["kik"] if r.get("grup")}

    @property
    def memzuc_col_to_group(self):
        """Memzuc kolonu → grup dict."""
        self._load()
        return {r["kolon_adi"]: r["grup"] for r in self._data["memzuc"]
                if r.get("grup") and r["grup"] != "-"}



# ── Fallback veri (feature_info.json bulunamazsa) ──
# kik (19) + rkd (50) + memzuc (2) — izleme_kriterleri hariç
_FALLBACK_DATA = json.loads(
    '{"kik":[{"kolon_adi":"Gckm_Gun_Say","aciklama":"Gecikme gün sayısı","grup":"gecikme","ciss":0,"delta_dahil":1,"not":">0 ise tetiklenir, _KIK_SPECIAL"},{"kolon_adi":"Lsng_Fktrng_Gec_Risk_Tut","aciklama":"Leasing/faktoring gecikmiş risk tutarı","grup":"gecikme","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Istrk_Flag","aciklama":"HB iştiraklerinde gecikme","grup":"gecikme","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Firm_Ortak_Bk_Tkp_Kod","aciklama":"Firma ortağı banka takip kodu","grup":"ortak","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Mhkm_Cek_Mhkm_Yskl_Kod","aciklama":"Mahkeme çek/yasak kodu","grup":"cek_senet","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Kkb_Dbnk_Tkp_Bky","aciklama":"Diğer banka yasal takip bakiyesi","grup":"cek_senet","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Dbnk_Tzmn_Gnkd_Krd_Tut","aciklama":"Diğer banka tazmin gayrinakdi kredi tutarı","grup":"diger_banka","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Memzc_Thhk_Kyt_Kod","aciklama":"MEMZUÇ tahakkuk kayıt kodu","grup":"diger_banka","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Alac_Bnk_Fnns_Icra_Kyt_Kod","aciklama":"Alacaklı banka/finans icra kayıt kodu","grup":"icra","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Tmsf_Hcz_Bldrm_Kod","aciklama":"TMSF haciz bildirim kodu","grup":"icra","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Iflas_Tlp_Kod","aciklama":"İflas talep kodu","grup":"yasal","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Konkrdt_Ilan_Kod","aciklama":"Konkordato ilan kodu","grup":"yasal","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Mnzm_Snt_Ysl_Kod","aciklama":"Munzam senet yasal takip kodu","grup":"yasal","ciss":1,"delta_dahil":1,"not":""},{"kolon_adi":"Erkn_Izlm_Kod","aciklama":"Erken izleme kodu","grup":"izleme","ciss":1,"delta_dahil":1,"not":"_KIK_SPECIAL"},{"kolon_adi":"Ykn_Izl_Flag","aciklama":"Yakın izleme flag","grup":"izleme","ciss":1,"delta_dahil":1,"not":"_KIK_SPECIAL"},{"kolon_adi":"iflas_talepli_iciz","aciklama":"İflas talepli icra/izleme","grup":"yasal","ciss":1,"delta_dahil":1,"not":"maybe_ciss"},{"kolon_adi":"diger_bank_yapilandirma_toplam","aciklama":"Diğer banka yapılandırma toplamı","grup":"diger_banka","ciss":1,"delta_dahil":1,"not":"maybe_ciss"},{"kolon_adi":"ilk_faiz_gecikme","aciklama":"İlk faiz gecikmesi","grup":"gecikme","ciss":1,"delta_dahil":1,"not":"maybe_ciss"},{"kolon_adi":"ilk_gecikme","aciklama":"İlk gecikme","grup":"gecikme","ciss":1,"delta_dahil":1,"not":"maybe_ciss"}],"rkd":[{"kod":"A01","aciklama":"Nakit kredi anapara ödemesinde gecikme var","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A02","aciklama":"Nakit kredi faiz/komisyon ödemesinde gecikme var","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A03","aciklama":"Teminat mektubu komisyon ödemesinde gecikme var","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A06","aciklama":"Firma ortaklarının kanuni takibe intikal etmiş kredi kartı borcu var","grup":"ortak","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A09","aciklama":"Firma ortaklarının kanuni takibe intikal etmiş bireysel kredi borcu var","grup":"ortak","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A17","aciklama":"Firma ve ortakların bireysel kredi ödemelerinde gecikme var","grup":"ortak","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A22","aciklama":"Firma ortaklarının kanuni takibe intikal etmiş KMH veya avantaj hesabı var","grup":"ortak","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A23","aciklama":"Firma ortaklarının kanuni takibe intikal etmiş KMH/avantaj hesabı (kanuni takip aşaması)","grup":"ortak","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A24","aciklama":"Firmanın kredilerinde gecikmiş taksidi var","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A25","aciklama":"Firma kredi ödemelerinde gecikme","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A32","aciklama":"Müşteri veya ortağının karşılıksız çekten dolayı 15837 skontta risk bakiyesi var","grup":"cek_senet","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A44","aciklama":"ESKKK taksit ödemelerinde gecikme var","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A50","aciklama":"15800/15900 skontlarında tazmin riski var","grup":"gecikme","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A52","aciklama":"Firma kredi ödemesinde gecikme (A52)","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A53","aciklama":"Firma kredi ödemesinde gecikme (A53)","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A54","aciklama":"Firma kredi ödemesinde gecikme","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A55","aciklama":"Firma kredi kartı ödemesinde 30 günden fazla gecikme var","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A57","aciklama":"Firma ortağının kredi kartı ödemesinde 30 günden fazla gecikme var","grup":"ortak","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A62","aciklama":"Firmanın kapanmayan güniçi kredisi var","grup":"gecikme","seviye":null,"suffix_a":"-","suffix_p":"-","suffix_asgd":"-","suffix_aigd":"-","suffix_pscd":"-","suffix_pigd":"-","suffix_avg":"-","eus_kapsam":0},{"kod":"A66","aciklama":"Grup firması riskleri bankamız takip hesaplarında izlenmektedir","grup":"ortak","seviye":null,"suffix_a":"-","suffix_p":"-","suffix_asgd":"-","suffix_aigd":"-","suffix_pscd":"-","suffix_pigd":"-","suffix_avg":"-","eus_kapsam":0},{"kod":"A70","aciklama":"DBS - KMH tahakkuk gecikmesi bulunmaktadır","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A71","aciklama":"Firma ortağına ait KMH tahakkuk gecikmesi bulunmaktadır","grup":"ortak","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A74","aciklama":"ESKK doğrudan taksit gecikmesi var","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A88","aciklama":"Firma 88-özel izlemede izlenecektir","grup":"izleme","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A89","aciklama":"Firma 99-yakın izlemede izlenecektir","grup":"izleme","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A95","aciklama":"Firma izleme listesinde","grup":"izleme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"A97","aciklama":"Firma hakkında munzam senet üzerinden yasal takip başlatılmıştır","grup":"yasal","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"B01","aciklama":"Müşteri hakkında limit üzeri icra takibi var","grup":"icra","seviye":null,"suffix_a":"-","suffix_p":"-","suffix_asgd":"-","suffix_aigd":"-","suffix_pscd":"-","suffix_pigd":"-","suffix_avg":"-","eus_kapsam":0},{"kod":"B02","aciklama":"Diğer banka ve finans kurumlarındaki borçları yeniden yapılandırılmış","grup":"diger_banka","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"B03","aciklama":"Firma ve ortakların karşılıksız bankamız çeki var (ödenmemiş)","grup":"cek_senet","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"B04","aciklama":"Firma ve ortakların karşılıksız diğer banka çeki var (ödenmemiş)","grup":"cek_senet","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"B06","aciklama":"Diğer banka ve finans kuruluşlarında tazmin edilmiş gayrinakdi kredi riski var","grup":"diger_banka","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"B07","aciklama":"Müşteri hakkında limit altı icra takibi var","grup":"icra","seviye":null,"suffix_a":"-","suffix_p":"-","suffix_asgd":"-","suffix_aigd":"-","suffix_pscd":"-","suffix_pigd":"-","suffix_avg":"-","eus_kapsam":0},{"kod":"B11","aciklama":"Leasing ve faktoring kuruluşlarında tahsili gecikmiş riski var","grup":"gecikme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"B33","aciklama":"Firma izleme/takip kaydı (B33)","grup":"izleme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"B71","aciklama":"Firma ortağı izleme kaydı (B71)","grup":"izleme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C01","aciklama":"Müşteri iflas sürecindedir","grup":"yasal","seviye":null,"suffix_a":"-","suffix_p":"-","suffix_asgd":"-","suffix_aigd":"-","suffix_pscd":"-","suffix_pigd":"-","suffix_avg":"-","eus_kapsam":0},{"kod":"C02","aciklama":"Müşteri konkordato talep etmiştir","grup":"yasal","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C03","aciklama":"Firma/ortaklar hakkında menkul/gayrimenkul ihtiyati tedbir kararı var","grup":"icra","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C04","aciklama":"Firma ve ortakları hakkında haciz kararı var","grup":"icra","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C05","aciklama":"Firma veya ortakları çek nedeniyle mahkemece yasaklıdır","grup":"cek_senet","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C06","aciklama":"Firmanın bankalarda takip riski var (MEMZUÇ)","grup":"diger_banka","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C08","aciklama":"Firmanın alacaklısı banka veya finans kurumu olan icra kaydı var","grup":"icra","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C13","aciklama":"Müşteri iflas erteleme talebinde bulunmuştur","grup":"yasal","seviye":1,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C14","aciklama":"Firma hakkında iflas talepli alacak davası açılmıştır (icra/tahsilat süreci)","grup":"icra","seviye":null,"suffix_a":"-","suffix_p":"-","suffix_asgd":"-","suffix_aigd":"-","suffix_pscd":"-","suffix_pigd":"-","suffix_avg":"-","eus_kapsam":0},{"kod":"C16","aciklama":"Firma izleme kaydı (C16)","grup":"izleme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C22","aciklama":"Firma izleme kaydı (C22)","grup":"izleme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C33","aciklama":"Firma izleme kaydı (C33)","grup":"izleme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C35","aciklama":"Firma izleme kaydı (C35)","grup":"izleme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"},{"kod":"C36","aciklama":"Firma izleme kaydı (C36)","grup":"izleme","seviye":2,"suffix_a":"sifir","suffix_p":"delta","suffix_asgd":"sifir","suffix_aigd":"sifir","suffix_pscd":"uzak","suffix_pigd":"uzak","suffix_avg":"-"}],"memzuc":[{"kolon_adi":"idari_kanuni_takip","aciklama":"İdari/kanuni takip tutarı","grup":"diger_banka","kontrol_tipi":"nonzero","delta_dahil":1,"not":">0 ise kapsam dışı"},{"kolon_adi":"idari_kanuni_takip_/_idari_kanuni_takip_6_aylik_ort","aciklama":"İdari/kanuni takip 6 aylık ort oranı","grup":"diger_banka","kontrol_tipi":"nonzero","delta_dahil":0,"not":"DATA CONTROL checkpoint — ASLA yeni=1 olamaz"}],"izleme_kriterleri":[]}'
)

# Singleton
FI = FeatureInfo()
