import numpy as np
import pandas as pd
import pytest
from featsynergy import SynergyDetector


# ── Fixtures ─────────────────────────────────────────────────────────────

@pytest.fixture
def regression_data():
    """Simple dataset where X1*X2 has a clear synergy with y."""
    np.random.seed(42)
    n = 500
    X1 = np.random.uniform(0, 10, n)
    X2 = np.random.uniform(0, 10, n)
    X3 = np.random.normal(0, 1, n)   # noise feature
    X4 = np.random.normal(0, 1, n)   # noise feature
    y  = 2 * X1 * X2 + 0.5 * X3 + np.random.normal(0, 1, n)
    X  = pd.DataFrame({"X1": X1, "X2": X2, "X3": X3, "X4": X4})
    return X, y


@pytest.fixture
def classification_data():
    """Simple binary classification dataset."""
    np.random.seed(42)
    n = 500
    X1 = np.random.uniform(0, 10, n)
    X2 = np.random.uniform(0, 10, n)
    X3 = np.random.normal(0, 1, n)
    y  = (X1 * X2 > 25).astype(int)
    X  = pd.DataFrame({"X1": X1, "X2": X2, "X3": X3})
    return X, y


@pytest.fixture
def data_with_zeros():
    """Dataset where one feature has zeros (tests safe division)."""
    np.random.seed(0)
    n = 200
    X1 = np.random.uniform(0, 5, n)
    X2 = np.concatenate([np.zeros(20), np.random.uniform(1, 5, n - 20)])
    y  = X1 + np.random.normal(0, 0.5, n)
    X  = pd.DataFrame({"X1": X1, "X2": X2})
    return X, y


# ── Basic API tests ───────────────────────────────────────────────────────

def test_fit_returns_self(regression_data):
    X, y = regression_data
    detector = SynergyDetector(top_n=4, cv=2, verbose=False)
    result = detector.fit(X, y)
    assert result is detector


def test_fit_sets_attributes(regression_data):
    X, y = regression_data
    detector = SynergyDetector(top_n=4, cv=2, verbose=False)
    detector.fit(X, y)
    assert hasattr(detector, "top_features_")
    assert hasattr(detector, "results_")
    assert hasattr(detector, "top_pairs_")
    assert hasattr(detector, "synergy_features_")


def test_top_features_length(regression_data):
    X, y = regression_data
    detector = SynergyDetector(top_n=3, cv=2, verbose=False)
    detector.fit(X, y)
    assert len(detector.top_features_) == 3


def test_results_shape(regression_data):
    X, y = regression_data
    detector = SynergyDetector(top_n=4, cv=2, verbose=False)
    detector.fit(X, y)
    # 4 features → C(4,2) = 6 pairs
    assert len(detector.results_) == 6


def test_results_sorted_by_gain(regression_data):
    X, y = regression_data
    detector = SynergyDetector(top_n=4, cv=2, verbose=False)
    detector.fit(X, y)
    gains = detector.results_["gain"].values
    assert all(gains[i] >= gains[i + 1] for i in range(len(gains) - 1))


# ── Transform tests ───────────────────────────────────────────────────────

def test_transform_adds_columns(regression_data):
    X, y = regression_data
    detector = SynergyDetector(top_n=4, gain_thresh=0.0, cv=2, verbose=False)
    detector.fit(X, y)
    X_out = detector.transform(X)
    assert X_out.shape[1] > X.shape[1]
    assert X_out.shape[0] == X.shape[0]


def test_transform_contains_synergy_features(regression_data):
    X, y = regression_data
    detector = SynergyDetector(top_n=4, gain_thresh=0.0, cv=2, verbose=False)
    detector.fit(X, y)
    X_out = detector.transform(X)
    for feat in detector.synergy_features_:
        assert feat in X_out.columns


def test_fit_transform_equals_fit_then_transform(regression_data):
    X, y = regression_data
    d1 = SynergyDetector(top_n=4, gain_thresh=0.0, cv=2, verbose=False)
    X_ft = d1.fit_transform(X, y)

    d2 = SynergyDetector(top_n=4, gain_thresh=0.0, cv=2, verbose=False)
    d2.fit(X, y)
    X_f_t = d2.transform(X)

    pd.testing.assert_frame_equal(X_ft, X_f_t)


def test_transform_before_fit_raises(regression_data):
    X, _ = regression_data
    detector = SynergyDetector(verbose=False)
    with pytest.raises(AttributeError):
        detector.transform(X)


# ── Safe division tests ───────────────────────────────────────────────────

def test_no_crash_with_zeros(data_with_zeros):
    X, y = data_with_zeros
    detector = SynergyDetector(top_n=2, gain_thresh=0.0, cv=2, verbose=False)
    detector.fit(X, y)
    X_out = detector.transform(X)
    assert not X_out.isnull().all().any()


def test_division_skipped_when_zeros(data_with_zeros):
    X, y = data_with_zeros
    detector = SynergyDetector(top_n=2, gain_thresh=-0.1, cv=2, verbose=False)
    detector.fit(X, y)
    print(f"\ntop_pairs_: {detector.top_pairs_}")
    print(f"synergy_ops: {detector._synergy_ops}")
    print(f"synergy_features_: {detector.synergy_features_}")
    assert "X1/X2" not in detector.synergy_features_
    assert "X2/X1" in detector.synergy_features_


# ── Classification tests ──────────────────────────────────────────────────

def test_classification_task(classification_data):
    X, y = classification_data
    detector = SynergyDetector(
        top_n=3, gain_thresh=0.0, cv=2,
        task="classification", verbose=False
    )
    detector.fit(X, y)
    assert hasattr(detector, "results_")
    assert "gain" in detector.results_.columns


def test_classification_gain_positive_for_synergy(classification_data):
    X, y = classification_data
    detector = SynergyDetector(
        top_n=3, gain_thresh=-1.0, cv=2,
        task="classification", verbose=False
    )
    detector.fit(X, y)
    # X1*X2 is the generating feature → top pair should have positive gain
    top = detector.results_.iloc[0]
    assert top["gain"] > 0


# ── Summary test ──────────────────────────────────────────────────────────

def test_summary_returns_dataframe(regression_data):
    X, y = regression_data
    detector = SynergyDetector(top_n=4, cv=2, verbose=False)
    detector.fit(X, y)
    summary = detector.summary()
    assert isinstance(summary, pd.DataFrame)
    assert "gain" in summary.columns


def test_summary_before_fit_raises():
    detector = SynergyDetector(verbose=False)
    with pytest.raises(RuntimeError):
        detector.summary()