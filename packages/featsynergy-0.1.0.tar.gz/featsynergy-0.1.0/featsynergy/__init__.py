from .detector import SynergyDetector

__version__ = "0.1.0"
__all__ = ["SynergyDetector"]