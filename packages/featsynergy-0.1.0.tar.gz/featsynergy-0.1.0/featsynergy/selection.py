import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import mutual_info_classif, mutual_info_regression
from scipy.stats import pearsonr

from .utils import combined_score


def correlation_scores(X: pd.DataFrame, y: np.ndarray) -> dict:
    """
    Computes absolute Pearson correlation of each feature with the target.

    Parameters
    ----------
    X : pd.DataFrame
    y : np.ndarray

    Returns
    -------
    dict {feature: abs_correlation}
    """
    scores = {}
    for col in X.columns:
        try:
            r, _ = pearsonr(X[col], y)
            scores[col] = abs(r) if np.isfinite(r) else 0.0
        except Exception:
            scores[col] = 0.0
    return scores


def mutual_info_scores(
    X: pd.DataFrame, y: np.ndarray, task: str = "regression"
) -> dict:
    """
    Computes mutual information between each feature and the target.
    Used for classification tasks instead of Pearson correlation.

    Parameters
    ----------
    X : pd.DataFrame
    y : np.ndarray
    task : str  'regression' or 'classification'

    Returns
    -------
    dict {feature: mutual_info_score}
    """
    fn = mutual_info_regression if task == "regression" else mutual_info_classif
    scores = fn(X.fillna(0), y, random_state=42)
    return dict(zip(X.columns, scores))


def ridge_importance(X: pd.DataFrame, y: np.ndarray) -> dict:
    """
    Fits a Ridge regression on standardized features and returns
    absolute coefficients as importance scores.

    Parameters
    ----------
    X : pd.DataFrame
    y : np.ndarray

    Returns
    -------
    dict {feature: abs_ridge_coefficient}
    """
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X.fillna(0))
    model = Ridge(alpha=1.0)
    model.fit(X_scaled, y)
    return dict(zip(X.columns, np.abs(model.coef_)))


def select_top_features(
    X: pd.DataFrame,
    y: np.ndarray,
    top_n: int = 10,
    task: str = "regression",
) -> list:
    """
    Selects the top_n most relevant features using a combined score
    of correlation (or mutual info for classification) and Ridge importance.

    Parameters
    ----------
    X : pd.DataFrame
    y : np.ndarray
    top_n : int
    task : str  'regression' or 'classification'

    Returns
    -------
    list of feature names, sorted by combined score descending
    """
    if task == "regression":
        signal_scores = correlation_scores(X, y)
    else:
        signal_scores = mutual_info_scores(X, y, task=task)

    imp_scores = ridge_importance(X, y)
    scores     = combined_score(signal_scores, imp_scores)

    sorted_feats = sorted(scores, key=scores.get, reverse=True)
    return sorted_feats[:top_n]