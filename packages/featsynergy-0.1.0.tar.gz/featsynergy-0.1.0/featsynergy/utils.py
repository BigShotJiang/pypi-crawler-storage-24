import numpy as np
import pandas as pd


def safe_divide(a: pd.Series, b: pd.Series, fallback: float = None) -> pd.Series:
    """
    Divide a/b element-wise. If b contains zeros, returns None
    so the caller can decide the fallback strategy.

    Parameters
    ----------
    a, b : pd.Series
    fallback : float, optional
        If provided, replaces inf/nan resulting from division by zero.
        If None, returns None when b has zeros.

    Returns
    -------
    pd.Series or None
    """
    if (b == 0).any():
        if fallback is not None:
            result = a / b.replace(0, np.nan)
            return result.fillna(fallback)
        return None
    return a / b


def combined_score(corr_scores: dict, ridge_scores: dict) -> dict:
    """
    Combines correlation and Ridge importance into a single normalized score.

    Parameters
    ----------
    corr_scores : dict  {feature: abs_correlation_with_target}
    ridge_scores : dict {feature: abs_ridge_coefficient}

    Returns
    -------
    dict {feature: combined_score}
    """
    max_corr  = max(corr_scores.values()) or 1.0
    max_ridge = max(ridge_scores.values()) or 1.0

    features = set(corr_scores) & set(ridge_scores)
    return {
        f: (corr_scores[f] / max_corr) + (ridge_scores[f] / max_ridge)
        for f in features
    }


def compute_pairs_features(
    X: pd.DataFrame,
    f1: str,
    f2: str,
    best_ratio_score: float = None,
) -> pd.DataFrame:
    """
    Given two feature names, returns a DataFrame with:
      - the two original features
      - f1^2, f2^2
      - f1 * f2
      - f1 / f2  (if f2 has no zeros, else fallback = 2 * best_ratio_score)
      - f2 / f1  (if f1 has no zeros, else fallback = 2 * best_ratio_score)

    Parameters
    ----------
    X : pd.DataFrame
    f1, f2 : str  — feature column names
    best_ratio_score : float, optional
        Best RMSE/score found so far for any ratio feature.
        Used as fallback = 2 * best_ratio_score for divisions with zeros.

    Returns
    -------
    pd.DataFrame with augmented features
    """
    s1, s2 = X[f1], X[f2]
    cols = {f1: s1, f2: s2, f"{f1}_sq": s1**2, f"{f2}_sq": s2**2, f"{f1}x{f2}": s1 * s2}

    fallback = (2.0 * best_ratio_score) if best_ratio_score is not None else None

    ratio_12 = safe_divide(s1, s2, fallback=fallback)
    ratio_21 = safe_divide(s2, s1, fallback=fallback)

    if ratio_12 is not None:
        cols[f"{f1}/{f2}"] = ratio_12
    if ratio_21 is not None:
        cols[f"{f2}/{f1}"] = ratio_21

    return pd.DataFrame(cols, index=X.index)