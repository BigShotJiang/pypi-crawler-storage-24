import numpy as np
import pandas as pd
from itertools import combinations
from sklearn.linear_model import Ridge
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler

from .utils import compute_pairs_features


def _rmse_cv(X_df: pd.DataFrame, y: np.ndarray, cv: int = 3) -> float:
    """
    Evaluates a Ridge regression on X_df using cross-validation.
    Returns mean RMSE across folds.

    Parameters
    ----------
    X_df : pd.DataFrame
    y : np.ndarray
    cv : int

    Returns
    -------
    float — mean RMSE
    """
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_df.fillna(0))
    scores = cross_val_score(
        Ridge(alpha=1.0),
        X_scaled,
        y,
        cv=cv,
        scoring="neg_root_mean_squared_error",
    )
    return -scores.mean()


def _score_cv(X_df: pd.DataFrame, y: np.ndarray, cv: int, task: str) -> float:
    """
    Evaluates a model using cross-validation.
    Uses RMSE for regression and F1-weighted for classification.

    Parameters
    ----------
    X_df : pd.DataFrame
    y : np.ndarray
    cv : int
    task : str  'regression' or 'classification'

    Returns
    -------
    float — mean score (lower is better for regression, higher for classification)
    """
    from sklearn.linear_model import LogisticRegression

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_df.fillna(0))

    if task == "regression":
        scores = cross_val_score(
            Ridge(alpha=1.0),
            X_scaled, y,
            cv=cv,
            scoring="neg_root_mean_squared_error",
        )
        return -scores.mean()
    else:
        scores = cross_val_score(
            LogisticRegression(max_iter=1000),
            X_scaled, y,
            cv=cv,
            scoring="f1_weighted",
        )
        return scores.mean()


def evaluate_pairs(
    X: pd.DataFrame,
    y: np.ndarray,
    top_features: list,
    cv: int = 3,
    task: str = "regression",
) -> pd.DataFrame:
    """
    For each pair of top features, evaluates:
      - base score: only the two original features
      - augmented score: original + product + squares + safe divisions
    and computes the gain (base - augmented for regression,
    augmented - base for classification).

    Parameters
    ----------
    X : pd.DataFrame
    y : np.ndarray
    top_features : list of str
    cv : int
    task : str  'regression' or 'classification'

    Returns
    -------
    pd.DataFrame with columns:
        f1, f2, base_score, aug_score, gain,
        has_zero_f1, has_zero_f2
    sorted by gain descending.
    """
    pairs   = list(combinations(top_features, 2))
    results = []

    # First pass: collect all ratio scores to compute fallback
    best_ratio_score = None

    for f1, f2 in pairs:
        s1, s2 = X[f1], X[f2]

        # Try ratios without fallback to find best ratio score
        for num, den in [(s1, s2), (s2, s1)]:
            if not (den == 0).any():
                ratio_df = pd.DataFrame(
                    {f1: s1, f2: s2, "ratio": num / den}, index=X.index
                )
                score = _score_cv(ratio_df, y, cv, task)
                if best_ratio_score is None:
                    best_ratio_score = score
                else:
                    # For regression lower is better, for classification higher is better
                    if task == "regression":
                        best_ratio_score = min(best_ratio_score, score)
                    else:
                        best_ratio_score = max(best_ratio_score, score)

    # Second pass: evaluate all pairs with fallback available
    for f1, f2 in pairs:
        s1, s2   = X[f1], X[f2]
        base_df  = X[[f1, f2]]
        base_score = _score_cv(base_df, y, cv, task)

        aug_df   = compute_pairs_features(X, f1, f2, best_ratio_score)
        aug_score = _score_cv(aug_df, y, cv, task)

        # gain: positive means augmented is better
        if task == "regression":
            gain = base_score - aug_score   # lower RMSE = better
        else:
            gain = aug_score - base_score   # higher F1 = better

        results.append({
            "f1":          f1,
            "f2":          f2,
            "base_score":  base_score,
            "aug_score":   aug_score,
            "gain":        gain,
            "has_zero_f1": (s1 == 0).any(),
            "has_zero_f2": (s2 == 0).any(),
        })

    return (
        pd.DataFrame(results)
        .sort_values("gain", ascending=False)
        .reset_index(drop=True)
    )