import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

from .selection import select_top_features
from .pairs import evaluate_pairs
from .utils import compute_pairs_features


class SynergyDetector(BaseEstimator, TransformerMixin):
    """
    Detects second-order feature synergies and generates derived features
    for the pairs that show significant interaction.

    Parameters
    ----------
    top_n : int, default=10
        Number of top features to consider as candidates for synergy detection.
    gain_thresh : float, default=0.002
        Minimum gain required to consider a pair as having a meaningful synergy.
        For regression: improvement in RMSE.
        For classification: improvement in F1-weighted.
    cv : int, default=3
        Number of cross-validation folds used to evaluate each pair.
    task : str, default='regression'
        'regression' or 'classification'.
    verbose : bool, default=True
        If True, prints progress and results during fit.

    Attributes
    ----------
    top_features_ : list
        Top-N features selected after fit.
    results_ : pd.DataFrame
        Full results DataFrame with all evaluated pairs, sorted by gain.
    top_pairs_ : pd.DataFrame
        Subset of results_ where gain > gain_thresh.
    synergy_features_ : list
        Names of the derived features that will be added by transform().

    Examples
    --------
    >>> from featsynergy import SynergyDetector
    >>> detector = SynergyDetector(top_n=10, gain_thresh=0.002)
    >>> detector.fit(X_train, y_train)
    >>> X_enriched = detector.transform(X_train)
    >>> X_test_enriched = detector.transform(X_test)
    """

    def __init__(
        self,
        top_n: int = 10,
        gain_thresh: float = 0.002,
        cv: int = 3,
        task: str = "regression",
        verbose: bool = True,
    ):
        self.top_n        = top_n
        self.gain_thresh  = gain_thresh
        self.cv           = cv
        self.task         = task
        self.verbose      = verbose

    def fit(self, X: pd.DataFrame, y):
        """
        Selects top features, evaluates all pairs, and identifies
        which derived features are worth adding.

        Parameters
        ----------
        X : pd.DataFrame
        y : array-like

        Returns
        -------
        self
        """
        X = pd.DataFrame(X)
        y = np.asarray(y)

        # Step 1: select top-N candidate features
        if self.verbose:
            print(f"[SynergyDetector] Selecting top {self.top_n} features...")
        self.top_features_ = select_top_features(X, y, self.top_n, self.task)

        if self.verbose:
            print(f"[SynergyDetector] Top features: {self.top_features_}")
            n_pairs = len(self.top_features_) * (len(self.top_features_) - 1) // 2
            print(f"[SynergyDetector] Evaluating {n_pairs} pairs (cv={self.cv})...")

        # Step 2: evaluate all pairs
        self.results_ = evaluate_pairs(
            X, y,
            top_features=self.top_features_,
            cv=self.cv,
            task=self.task,
        )

        # Step 3: filter pairs above threshold
        self.top_pairs_ = self.results_[
            self.results_["gain"] > self.gain_thresh
        ].reset_index(drop=True)

        if self.verbose:
            print(
                f"[SynergyDetector] Found {len(self.top_pairs_)} synergistic pair(s) "
                f"with gain > {self.gain_thresh}:"
            )
            if len(self.top_pairs_) > 0:
                print(self.top_pairs_[["f1", "f2", "base_score", "aug_score", "gain"]]
                      .to_string(index=False))
            else:
                print("  None. Consider lowering gain_thresh.")

        # Step 4: determine which derived features to generate in transform()
        self._fit_synergy_features(X)

        return self

    def _fit_synergy_features(self, X: pd.DataFrame):
        """
        For each synergistic pair, records which derived features
        are valid (e.g. skips divisions with zeros).
        Stored as a list of (f1, f2, feature_name, operation) tuples.
        """
        self._synergy_ops = []
        seen = set()

        for _, row in self.top_pairs_.iterrows():
            f1, f2 = row["f1"], row["f2"]
            s1, s2 = X[f1], X[f2]

            ops = [
                (f"{f1}_sq",    "sq1"),
                (f"{f2}_sq",    "sq2"),
                (f"{f1}x{f2}", "prod"),
            ]
            if not (s2 == 0).any():
                ops.append((f"{f1}/{f2}", "div12"))
            if not (s1 == 0).any():
                ops.append((f"{f2}/{f1}", "div21"))

            for feat_name, op in ops:
                if feat_name not in seen:
                    self._synergy_ops.append((f1, f2, feat_name, op))
                    seen.add(feat_name)

        self.synergy_features_ = [op[2] for op in self._synergy_ops]

        if self.verbose:
            print(
                f"[SynergyDetector] {len(self.synergy_features_)} derived feature(s) "
                f"will be added by transform(): {self.synergy_features_}"
            )

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Adds the synergistic derived features to X.

        Parameters
        ----------
        X : pd.DataFrame

        Returns
        -------
        pd.DataFrame — original X plus derived synergy features
        """
        X = pd.DataFrame(X).copy()

        new_cols = {}
        for f1, f2, feat_name, op in self._synergy_ops:
            s1, s2 = X[f1], X[f2]
            if op == "sq1":
                new_cols[feat_name] = s1 ** 2
            elif op == "sq2":
                new_cols[feat_name] = s2 ** 2
            elif op == "prod":
                new_cols[feat_name] = s1 * s2
            elif op == "div12":
                new_cols[feat_name] = s1 / s2
            elif op == "div21":
                new_cols[feat_name] = s2 / s1

        return pd.concat([X, pd.DataFrame(new_cols, index=X.index)], axis=1)

    def fit_transform(self, X: pd.DataFrame, y=None, **fit_params) -> pd.DataFrame:
        """
        Fits the detector and transforms X in one step.
        """
        return self.fit(X, y).transform(X)

    def summary(self) -> pd.DataFrame:
        """
        Returns the full results DataFrame with all evaluated pairs.
        """
        if not hasattr(self, "results_"):
            raise RuntimeError("Call fit() before summary().")
        return self.results_