# coding: utf-8

# Copyright 2026 Inria (Institut National de Recherche en Informatique
# et Automatique)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Unit tests for mere-monitoring fairness controllers."""

import os
from unittest import mock

import pytest

from declearn.aggregator import Aggregator
from declearn.fairness.monitor import (
    FairnessMonitorClient,
    FairnessMonitorServer,
)
from declearn.test_utils import make_importable

with make_importable(os.path.dirname(os.path.abspath(__file__))):
    from fairness_controllers_testing import FairnessControllerTestSuite


class TestFairnessMonitorControllers(FairnessControllerTestSuite):
    """Unit tests for mere-monitoring fairness controllers."""

    server_cls = FairnessMonitorServer
    client_cls = FairnessMonitorClient

    @pytest.mark.parametrize(
        "use_secagg", [False, True], ids=["clrtxt", "secagg"]
    )
    @pytest.mark.asyncio
    async def test_finalize_fairness_setup(
        self,
        use_secagg: bool,
    ) -> None:
        aggregator = mock.create_autospec(Aggregator, instance=True)
        agg_final, *_ = await self.run_finalize_fairness_setup(
            aggregator, use_secagg
        )
        assert agg_final is aggregator
