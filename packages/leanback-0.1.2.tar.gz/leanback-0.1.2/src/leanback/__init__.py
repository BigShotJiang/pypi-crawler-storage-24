"""LeanBack - Lean 4 development tools for Claude Code."""

__version__ = "0.1.2"
