"""
Implementation of the leanback-check tool.

This module provides functionality for checking Lean files and projects.
"""

import os
import subprocess
from pathlib import Path

from rich.console import Console

from leanback.common.env import LeanRunner
from leanback.common.errors import LeanError, parse_lean_output
from leanback.common.path_manager import PathManager
from leanback.common.project_context import ProjectContext
from leanback.common.util import create_temp_file


def check_file(
    file_path: str | Path,
    project_path: str | Path | None = None,
    capture_json: bool = True,
    console: Console | None = None,
    preserve_relative: bool = True,
) -> tuple[bool, list[LeanError]]:
    """
    Check a single Lean file for errors.

    Args:
        file_path: Path to the Lean file to check
        project_path: Path to the Lean project (if None, tries to find it)
        capture_json: Whether to capture output as JSON for better error parsing
        console: Rich console for output (creates a new one if None)
        preserve_relative: Whether to preserve relative paths (True by default)

    Returns:
        Tuple of (success, errors)
    """
    if console is None:
        console = Console()

    # Convert to Path
    if isinstance(file_path, str):
        file_path = Path(file_path)

    # Store original path format for consistent return values
    original_file_path = file_path

    # For file existence check, we need the absolute path
    abs_file_path = file_path.absolute() if preserve_relative else file_path

    # Ensure the file exists
    if not abs_file_path.exists():
        return False, [
            LeanError(
                file_name=str(
                    original_file_path
                ),  # Use original path in error messages
                line=0,
                column=0,
                severity="error",
                message=f"File '{original_file_path}' does not exist",
            )
        ]

    # Get path manager
    path_manager = PathManager()

    # Find project root if not provided
    if project_path is None:
        project_path = path_manager.find_project_root(file_path)
    else:
        # Use ProjectContext to resolve project path (handles project names)
        project_context = ProjectContext(project_path, console)
        if project_context.project_path:
            project_path = project_context.project_path
        else:
            # If ProjectContext couldn't resolve it, try as a regular path
            if isinstance(project_path, str):
                project_path = Path(project_path)
            if not project_path.exists():
                return False, [
                    LeanError(
                        file_name=str(original_file_path),
                        line=0,
                        column=0,
                        severity="error",
                        message=f"Project '{project_path}' not found",
                    )
                ]

    # Check if this file imports mathlib
    has_mathlib_import = path_manager.file_has_mathlib_import(file_path)

    # Always enable mathlib integration with all dependencies for consistent behavior
    # Run Lean on the file
    exit_code, stdout, stderr = LeanRunner.run_lean(
        file_path=file_path,
        project_path=project_path,
        capture_json=capture_json,
        check=False,
    )

    # Parse the output for errors
    errors = parse_lean_output(
        stdout if capture_json else stderr, json_format=capture_json
    )

    # If no detailed errors were parsed but the check failed, provide more information
    if exit_code != 0 and not errors:
        # First, check if it might be a mathlib import issue
        if has_mathlib_import:
            errors.append(
                LeanError(
                    file_name=str(file_path),
                    line=0,
                    column=0,
                    severity="error",
                    message="Mathlib import issue detected.",
                    suggestion="\nTo fix mathlib import issues:\n"
                    "1. Make sure your file is part of a properly created project\n"
                    "2. Create a project with Mathlib: lake +leanprover-community/mathlib4:lean-toolchain new <name> math\n"
                    "3. Download cache: cd <name> && lake exe cache get\n\n"
                    "Raw output from Lean:\n"
                    + (
                        f"stdout: {stdout}\n\nstderr: {stderr}"
                        if stdout or stderr
                        else "No output captured"
                    ),
                )
            )
        else:
            # General error with no specific details
            errors.append(
                LeanError(
                    file_name=str(file_path),
                    line=0,
                    column=0,
                    severity="error",
                    message="Lean check failed without detailed error information",
                    suggestion="\nRaw output from Lean:\n"
                    + (
                        f"stdout: {stdout}\n\nstderr: {stderr}"
                        if stdout or stderr
                        else "No output captured"
                    ),
                )
            )

    # Return success (no errors) and the list of errors
    return exit_code == 0, errors


def check_project(
    project_path: str | Path,
    check_all_files: bool = False,
    capture_json: bool = True,
    console: Console | None = None,
) -> tuple[bool, list[LeanError]]:
    """
    Check an entire Lean project for errors.

    Args:
        project_path: Path to the Lean project
        check_all_files: Whether to check all .lean files or just run lake build
        capture_json: Whether to capture output as JSON for better error parsing
        console: Rich console for output (creates a new one if None)

    Returns:
        Tuple of (success, errors)
    """
    if console is None:
        console = Console()

    # Create project context for validation
    project_context = ProjectContext(project_path, console)

    # Ensure the project is valid
    if not project_context.project_path:
        return False, [
            LeanError(
                file_name=str(project_path),
                line=0,
                column=0,
                severity="error",
                message=f"Project directory '{project_path}' does not exist",
            )
        ]

    # Use the validated project path
    project_path = project_context.project_path

    # If we're not checking individual files, just run lake build
    if not check_all_files:
        console.print(f"Building project at {project_path}...")
        try:
            process = subprocess.run(
                ["lake", "build"],
                cwd=project_path,
                capture_output=True,
                text=True,
                check=False,
                timeout=300,  # 5 minutes for mathlib projects
            )

            # Parse output for actual compilation errors
            errors = []
            has_compilation_errors = False

            # Combine stdout and stderr for comprehensive parsing
            all_output = (process.stdout or "") + "\n" + (process.stderr or "")

            for line in all_output.splitlines():
                # Look for Lean compilation errors (more specific patterns)
                if "error:" in line and any(
                    indicator in line
                    for indicator in [
                        ".lean:",  # Lean file error
                        "failed to",  # Compilation failure
                        "unknown identifier",  # Common Lean error
                        "type mismatch",  # Type error
                        "tactic failed",  # Proof error
                        "declaration",  # Declaration errors
                    ]
                ):
                    has_compilation_errors = True
                    errors.append(
                        LeanError(
                            file_name="unknown",
                            line=0,
                            column=0,
                            severity="error",
                            message=line.strip(),
                        )
                    )

            if process.returncode == 0:
                return True, []

            # Non-zero exit code — always a failure
            if has_compilation_errors:
                return False, errors

            # No specific compilation errors parsed — provide context
            raw_output = all_output[:1000]
            return False, [
                LeanError(
                    file_name="lake",
                    line=0,
                    column=0,
                    severity="error",
                    message="Lake build failed.",
                    suggestion=(
                        "\nThis might be due to:\n"
                        "- Dependency or network issues\n"
                        "- Corrupted build cache\n\n"
                        "Try running 'lake clean' and rebuilding.\n\n"
                        f"Raw output:\n{raw_output}"
                    ),
                )
            ]

        except subprocess.TimeoutExpired:
            return False, [
                LeanError(
                    file_name="lake",
                    line=0,
                    column=0,
                    severity="error",
                    message="Lake build timed out after 5 minutes",
                    suggestion="This might be due to:\n"
                    "- First-time mathlib download (can take 10-30 minutes)\n"
                    "- Large project compilation\n"
                    "- System resource constraints\n\n"
                    "Try running 'lake build' manually in the project directory.",
                )
            ]
        except Exception as e:
            return False, [
                LeanError(
                    file_name="lake",
                    line=0,
                    column=0,
                    severity="error",
                    message=f"Failed to run 'lake build': {e}",
                )
            ]

    # If we're checking individual files, find all .lean files and check them
    all_errors = []
    success = True

    # Find all .lean files in the project
    lean_files = list(project_path.glob("**/*.lean"))

    for file_path in lean_files:
        # Skip files in .lake directory and lakefile.lean (uses Lake DSL, not standard Lean)
        if ".lake" in file_path.parts or file_path.name == "lakefile.lean":
            continue

        console.print(f"Checking {file_path.relative_to(project_path)}...")
        file_success, file_errors = check_file(
            file_path=file_path,
            project_path=project_path,
            capture_json=capture_json,
            console=console,
        )

        if not file_success:
            success = False
            all_errors.extend(file_errors)

    return success, all_errors


def check_lean_expr(
    expr: str,
    imports: list[str] | None = None,
    project_path: str | Path | None = None,
    capture_json: bool = True,
    console: Console | None = None,
) -> tuple[bool, list[LeanError]]:
    """
    Check a Lean expression for errors.

    Args:
        expr: Lean expression or code to check
        imports: List of imports to include
        project_path: Path to the Lean project (if None, tries to find it)
        capture_json: Whether to capture output as JSON for better error parsing
        console: Rich console for output (creates a new one if None)

    Returns:
        Tuple of (success, errors)
    """
    if console is None:
        console = Console()

    # Set default imports if none provided
    if imports is None:
        imports = []

    # Create a temporary file with the expression
    content = "\n".join(f"import {imp}" for imp in imports)
    if content:
        content += "\n\n"
    content += expr

    temp_file = create_temp_file(content)

    try:
        # Check the temporary file
        return check_file(
            file_path=temp_file,
            project_path=project_path,
            capture_json=capture_json,
            console=console,
        )
    finally:
        # Clean up the temporary file
        try:
            os.unlink(temp_file)
        except OSError:
            pass
