# Introduction
This is the Averian AI Validator SDK.

# Installation

Install the package from PyPI:

    pip install averian-ai-validator-sdk

# Usage

```python
from averian_ai_validator_sdk import APIClient

api = APIClient()
api.login(AUTH_HOST, API_HOST, USERNAME, PASSWORD)
```

# Samples

See the [`samples/`](samples/) folder for a complete usage example:

- **samples/sample.py** - SDK usage example
- **samples/sample_config.py** - Configuration file; update with your API host, username, and password

# Development Setup

## Step 1: Create a Virtual Environment (Recommended)

**On Windows:**

    python -m venv venv
    venv\Scripts\activate

**On Linux/Mac:**

    python -m venv venv
    source venv/bin/activate

## Step 2: Install Requirements

    pip install -r requirements.txt

## Run Sample

Update `samples/sample_config.py` with your credentials, then:

    cd samples
    python sample.py
