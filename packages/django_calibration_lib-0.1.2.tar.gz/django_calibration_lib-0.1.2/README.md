# django-calibration-lib

Minimal Python package intended to be installed in Django projects.

## Install

```bash
pip install django-calibration-lib
```

## Usage

```python
from django_calibration_lib import compute_calibration

result = compute_calibration()
```

`result` is a JSON-compatible Python dictionary.

## Publish

This repository includes a GitHub Actions workflow that publishes to PyPI
with Trusted Publishing from a manual run.

Run the `Release` workflow in GitHub Actions and provide the version number
to publish, for example `0.1.0`.

The workflow will:

- build the source distribution and wheel
- inject the requested version into `pyproject.toml` during the CI run
- publish the package to PyPI

This does not commit the version change back to the repository.

## Local build

Build distributions locally:

```bash
python -m build
```

Check them with Twine:

```bash
python -m twine check dist/*
```
