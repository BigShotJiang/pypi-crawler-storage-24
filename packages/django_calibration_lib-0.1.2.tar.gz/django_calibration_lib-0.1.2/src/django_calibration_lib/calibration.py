def compute_calibration() -> dict:
    return {
        "status": "ok",
        "calibration": {
            "value": 2.0,
            "unit": "ratio",
        },
    }
