#!/usr/bin/env python3
"""Exercise the installed CLI against the verified preset matrix."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

import yaml


VERIFIED_PRESETS = [
    "api-minimal",
    "web-api",
    "web-api-google-auth",
    "agent-chat",
    "web-api-infra",
    "full-stack",
]
CLI_BIN = "bytask-app-generator"


def run(cmd: list[str], *, cwd: Path | None = None, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    process_env = dict(os.environ)
    if env:
        process_env.update(env)
    process = subprocess.run(cmd, cwd=cwd, env=process_env, text=True, capture_output=True, check=False)
    if process.returncode != 0:
        raise RuntimeError(f"Command failed: {' '.join(cmd)}\nSTDOUT:\n{process.stdout}\nSTDERR:\n{process.stderr}")
    return process


def wait_http(url: str, timeout: int = 90) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=5) as response:
                if 200 <= response.status < 500:
                    return
        except Exception:
            time.sleep(2)
    raise RuntimeError(f"Timed out waiting for {url}")


def smoke_project(project_dir: Path, spec: dict) -> None:
    if shutil.which("docker") is None:
        raise RuntimeError("Docker is required for smoke tests.")

    env_path = project_dir / ".env"
    env_path.write_text((project_dir / ".env.example").read_text())
    creds_path = project_dir / ".tmp-gcp-credentials.json"
    creds_path.write_text("{}")

    env = dict(os.environ)
    env["GOOGLE_APPLICATION_CREDENTIALS_PATH"] = str(creds_path)

    modules = spec["modules"]
    services = []
    if modules["api"] or modules["agent_server"]:
        services.append("db")
    if modules["api"]:
        services.append("api")
    if modules["agent_server"]:
        services.append("agent_server")
    if modules["frontend"]:
        services.append("frontend")

    try:
        run(["docker", "compose", "up", "-d", "--build", *services], cwd=project_dir, env=env)
        if modules["api"]:
            wait_http("http://127.0.0.1:8000/health")
        if modules["frontend"]:
            wait_http("http://127.0.0.1:3000")
    finally:
        subprocess.run(["docker", "compose", "down", "-v"], cwd=project_dir, env=env, check=False)


def _split_source_ref(source: str) -> tuple[str, str | None]:
    if "#" not in source:
        return source, None
    base, ref = source.rsplit("#", 1)
    return base, ref or None


def create_template_snapshot(source: str) -> str:
    base_source, ref = _split_source_ref(source)
    source_path = Path(base_source)
    snapshot_root = Path(tempfile.mkdtemp()) / "template-src"

    if source_path.exists():
        if ref:
            subprocess.run(["git", "clone", str(source_path), str(snapshot_root)], check=True)
            subprocess.run(["git", "checkout", ref], cwd=snapshot_root, check=True)
            return str(snapshot_root)

        shutil.copytree(source_path, snapshot_root, dirs_exist_ok=True, ignore=shutil.ignore_patterns(".git", ".venv", ".pytest_cache", "__pycache__", ".e2e"))
        subprocess.run(["git", "init"], cwd=snapshot_root, check=True)
        subprocess.run(["git", "config", "user.email", "ci@example.com"], cwd=snapshot_root, check=True)
        subprocess.run(["git", "config", "user.name", "CI"], cwd=snapshot_root, check=True)
        subprocess.run(["git", "add", "."], cwd=snapshot_root, check=True)
        subprocess.run(["git", "commit", "-m", "template snapshot"], cwd=snapshot_root, check=True)
        return str(snapshot_root)

    if ref:
        subprocess.run(["git", "clone", base_source, str(snapshot_root)], check=True)
        subprocess.run(["git", "checkout", ref], cwd=snapshot_root, check=True)
        return str(snapshot_root)

    return source


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--update", action="store_true")
    parser.add_argument("--preset", action="append", dest="presets", default=[])
    args = parser.parse_args()

    args.workspace.mkdir(parents=True, exist_ok=True)
    selected_presets = args.presets or VERIFIED_PRESETS

    describe = run([CLI_BIN, "describe", "--format", "json"])
    payload = json.loads(describe.stdout)
    missing = sorted(set(selected_presets) - set(payload["verified_presets"]))
    if missing:
        raise RuntimeError(f"Missing verified presets in describe output: {missing}")

    for preset in selected_presets:
        project_dir = args.workspace / preset
        if project_dir.exists():
            shutil.rmtree(project_dir)

        run([CLI_BIN, "validate", "--preset", preset])
        run([CLI_BIN, "generate", "--preset", preset, "--output", str(project_dir)])
        spec = yaml.safe_load((project_dir / "project.spec.yml").read_text())
        if args.smoke:
            smoke_project(project_dir, spec)

    if args.update:
        current_template_src = os.environ.get("BT_APP_TEMPLATE_SRC")
        previous_template_src = os.environ.get("BT_APP_TEMPLATE_PREVIOUS_SRC")
        if current_template_src and (Path(_split_source_ref(current_template_src)[0]).exists() or "#" in current_template_src):
            current_template_src = create_template_snapshot(current_template_src)
        if previous_template_src and (Path(_split_source_ref(previous_template_src)[0]).exists() or "#" in previous_template_src):
            previous_template_src = create_template_snapshot(previous_template_src)
        project_dir = args.workspace / "update-project"
        if project_dir.exists():
            shutil.rmtree(project_dir)
        generate_env = {}
        if previous_template_src:
            generate_env["BT_APP_TEMPLATE_SRC"] = previous_template_src
        elif current_template_src:
            generate_env["BT_APP_TEMPLATE_SRC"] = current_template_src
        update_preset = "full-stack" if "full-stack" in selected_presets else selected_presets[0]
        run([CLI_BIN, "generate", "--preset", update_preset, "--output", str(project_dir)], env=generate_env)
        subprocess.run(["git", "init"], cwd=project_dir, check=True)
        subprocess.run(["git", "config", "user.email", "ci@example.com"], cwd=project_dir, check=True)
        subprocess.run(["git", "config", "user.name", "CI"], cwd=project_dir, check=True)
        subprocess.run(["git", "add", "."], cwd=project_dir, check=True)
        subprocess.run(["git", "commit", "-m", "initial"], cwd=project_dir, check=True)
        update_env = {}
        if current_template_src:
            update_env["BT_APP_TEMPLATE_SRC"] = current_template_src
        run([CLI_BIN, "update", "--project-dir", str(project_dir)], env=update_env)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
