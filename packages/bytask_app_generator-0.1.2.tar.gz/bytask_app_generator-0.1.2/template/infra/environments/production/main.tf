terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
  # backend "gcs" {
  #   bucket = "REPLACE_WITH_TERRAFORM_STATE_BUCKET"
  #   prefix = "terraform/state/production"
  # }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

module "artifact_registry" {
  source        = "../../modules/artifact-registry"
  project_id    = var.project_id
  region        = var.region
  repository_id = "${var.app_name}-${var.environment}"
}

module "cloud_sql" {
  source        = "../../modules/cloud-sql"
  project_id    = var.project_id
  region        = var.region
  name          = "${var.app_name}-${var.environment}-db"
  db_name       = var.app_name
  user_name     = var.db_user
  user_password = var.db_password
  tier          = var.db_tier
  deletion_protection = true
}

locals {
  image_base = module.artifact_registry.repository_url
  db_url     = "postgresql+asyncpg://${var.db_user}:${var.db_password}@/${var.app_name}?host=/cloudsql/${module.cloud_sql.connection_name}"
}

module "api" {
  source                = "../../modules/cloud-run"
  project_id            = var.project_id
  region                = var.region
  name                  = "${var.app_name}-${var.environment}-api"
  image                 = "${local.image_base}/api:latest"
  service_account_email = var.service_account_email
  container_port        = 8000
  invoker_iam_members   = ["allUsers"]
  domain_mapping        = var.domain_backend != "" ? [var.domain_backend] : []

  env_vars = {
    APP_NAME              = var.app_name
    ENV                   = var.environment
    DATABASE_URL          = local.db_url
    CORS_ALLOW_ORIGINS    = "https://${var.domain_frontend}"
    GOOGLE_REDIRECT_URI   = "https://${var.domain_backend}/api/v1/auth/google/callback"
    FEATURE_CHAT_ENABLED  = "false"
  }

  secrets = {
    JWT_SECRET           = "${var.app_name}-jwt-secret:latest"
    INTERNAL_API_KEY     = "${var.app_name}-internal-api-key:latest"
    GOOGLE_CLIENT_ID     = "${var.app_name}-google-client-id:latest"
    GOOGLE_CLIENT_SECRET = "${var.app_name}-google-client-secret:latest"
  }
}

module "agent_server" {
  source                = "../../modules/cloud-run"
  project_id            = var.project_id
  region                = var.region
  name                  = "${var.app_name}-${var.environment}-agent"
  image                 = "${local.image_base}/agent_server:latest"
  service_account_email = var.service_account_email
  container_port        = 8001
  invoker_iam_members   = []

  env_vars = {
    APP_NAME            = var.app_name
    AGENT_SERVER_DB_URL = local.db_url
    GEMINI_MODEL        = "gemini-2.0-flash"
  }
}

module "frontend" {
  source                = "../../modules/cloud-run"
  project_id            = var.project_id
  region                = var.region
  name                  = "${var.app_name}-${var.environment}-frontend"
  image                 = "${local.image_base}/frontend:latest"
  service_account_email = var.service_account_email
  container_port        = 3000
  invoker_iam_members   = ["allUsers"]
  domain_mapping        = var.domain_frontend != "" ? [var.domain_frontend] : []

  env_vars = {
    NEXT_PUBLIC_APP_NAME      = var.app_name
    NEXT_PUBLIC_API_URL       = "https://${var.domain_backend}"
    NEXT_PUBLIC_APP_URL       = "https://${var.domain_frontend}"
    NEXT_PUBLIC_PRIMARY_COLOR = var.primary_color
    NODE_ENV                  = "production"
  }
}
