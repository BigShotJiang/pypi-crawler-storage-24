variable "project_id" { type = string }
variable "region" { type = string; default = "europe-west4" }
variable "app_name" { type = string }
variable "environment" { type = string; default = "production" }
variable "domain_frontend" { type = string; default = "" }
variable "domain_backend" { type = string; default = "" }
variable "service_account_email" { type = string }
variable "db_user" { type = string; default = "appuser" }
variable "db_password" { type = string; sensitive = true }
variable "db_tier" { type = string; default = "db-g1-small" }
variable "primary_color" { type = string; default = "#02aea2" }
