variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
  default     = "europe-west4"
}

variable "app_name" {
  description = "Application name (used for resource naming)"
  type        = string
}

variable "environment" {
  description = "Environment (staging / production)"
  type        = string
  default     = "staging"
}

variable "domain_frontend" {
  description = "Frontend domain (e.g. app.myapp.com)"
  type        = string
  default     = ""
}

variable "domain_backend" {
  description = "Backend domain (e.g. api.myapp.com)"
  type        = string
  default     = ""
}

variable "service_account_email" {
  description = "Service account email for Cloud Run services"
  type        = string
}

variable "db_user" {
  description = "PostgreSQL user"
  type        = string
  default     = "appuser"
}

variable "db_password" {
  description = "PostgreSQL password"
  type        = string
  sensitive   = true
}

variable "db_tier" {
  description = "Cloud SQL machine tier"
  type        = string
  default     = "db-f1-micro"
}

variable "primary_color" {
  description = "App primary color hex"
  type        = string
  default     = "#02aea2"
}
