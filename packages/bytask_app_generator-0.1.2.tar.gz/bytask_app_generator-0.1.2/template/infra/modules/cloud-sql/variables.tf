variable "project_id" { type = string }
variable "region" { type = string }
variable "name" { type = string }
variable "database_version" {
  type    = string
  default = "POSTGRES_16"
}
variable "tier" {
  type    = string
  default = "db-f1-micro"
}
variable "db_name" { type = string }
variable "user_name" {
  type    = string
  default = "appuser"
}
variable "user_password" {
  type      = string
  sensitive = true
}
variable "deletion_protection" {
  type    = bool
  default = true
}
