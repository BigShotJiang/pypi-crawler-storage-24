variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "region" {
  description = "GCP region"
  type        = string
}

variable "name" {
  description = "Cloud Run service name"
  type        = string
}

variable "image" {
  description = "Container image to deploy"
  type        = string
}

variable "service_account_email" {
  description = "Service account email"
  type        = string
}

variable "env_vars" {
  description = "Environment variables"
  type        = map(string)
  default     = {}
}

variable "secrets" {
  description = "Secret Manager secrets (env_var_name = secret_name:version)"
  type        = map(string)
  default     = {}
}

variable "container_port" {
  description = "Container port"
  type        = number
  default     = 8080
}

variable "invoker_iam_members" {
  description = "IAM members that can invoke the service"
  type        = list(string)
  default     = []
}

variable "domain_mapping" {
  description = "Custom domains to map"
  type        = list(string)
  default     = []
}
