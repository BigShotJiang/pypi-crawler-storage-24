"""AG-UI FastAPI application for the base assistant agent.

Exposes the placeholder ADK agent via the AG-UI streaming protocol.
Adapted from task-assistant/backend/agent_server/ag_ui_app.py.
"""
from __future__ import annotations

import os
import sys
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger

try:
    from ag_ui_adk import ADKAgent, add_adk_fastapi_endpoint
    from ag_ui_adk import event_translator as ag_ui_event_translator
except ImportError as exc:
    raise ImportError("ag_ui_adk is required. Install with: pip install ag-ui-adk") from exc

try:
    from google.adk.sessions import DatabaseSessionService, InMemorySessionService
except ImportError as exc:
    raise ImportError("google-adk is required. Install with: pip install google-adk") from exc


# ── MONKEY-PATCH: Fix HITL with PROGRESSIVE_SSE_STREAMING in ag-ui-adk ──────
# Mirrors the same patch in task-assistant. Remove once ag-ui-adk ships native HITL support.
_original_translate_lro = ag_ui_event_translator.EventTranslator.translate_lro_function_calls


async def _patched_translate_lro(self, adk_event):
    is_partial = getattr(adk_event, "partial", False)
    if not is_partial:
        async for event in _original_translate_lro(self, adk_event):
            yield event
    else:
        logger.debug("Skipping LRO translation for partial event (PROGRESSIVE_SSE_STREAMING fix)")


ag_ui_event_translator.EventTranslator.translate_lro_function_calls = _patched_translate_lro
logger.info("Applied PROGRESSIVE_SSE_STREAMING HITL fix for ag-ui-adk")
# ─────────────────────────────────────────────────────────────────────────────

sys.path.insert(0, os.path.dirname(__file__))

from agents.base_assistant.agent import base_assistant
from core.session_service import create_session_service


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    logger.info("Starting Agent Server...")
    yield
    logger.info("Shutting down Agent Server...")


app = FastAPI(
    title="bt-app Agent Server",
    description="AG-UI Protocol endpoint for the base assistant agent",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health() -> dict:
    return {"status": "ok", "service": "agent-server"}


# Create session service
session_service = create_session_service()

# Register the base_assistant at /ag-ui
base_adk_agent = ADKAgent(
    adk_agent=base_assistant,
    app_name="bt_app",
    user_id="default",
    session_timeout_seconds=3600,
    session_service=session_service,
    use_in_memory_services=False,
)

add_adk_fastapi_endpoint(
    app,
    base_adk_agent,
    path="/ag-ui",
    extract_headers=["x-user-id", "x-session-id", "x-tenant-id"],
)

if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8001"))
    uvicorn.run(app, host="0.0.0.0", port=port)
