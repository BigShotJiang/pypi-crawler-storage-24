"""Session service factory for the agent server."""
import os
from loguru import logger


def create_session_service():
    """Create DatabaseSessionService or InMemorySessionService based on env."""
    db_url = os.getenv("AGENT_SERVER_DB_URL")

    if db_url:
        try:
            from google.adk.sessions import DatabaseSessionService
            logger.info("Using DatabaseSessionService | db=%s", db_url.split("@")[-1])
            return DatabaseSessionService(db_url=db_url)
        except Exception as exc:
            logger.warning("DatabaseSessionService failed, falling back to InMemory: %s", exc)

    from google.adk.sessions import InMemorySessionService
    logger.info("Using InMemorySessionService")
    return InMemorySessionService()
