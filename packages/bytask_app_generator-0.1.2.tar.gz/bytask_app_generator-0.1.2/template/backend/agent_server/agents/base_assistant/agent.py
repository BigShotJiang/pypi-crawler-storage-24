"""Placeholder Google ADK agent.

Replace `instruction` and add tools for your specific app.
"""
import os

from google.adk.agents import Agent

from .prompts import BASE_ASSISTANT_INSTRUCTION

APP_NAME = os.getenv("APP_NAME", "My App")

base_assistant = Agent(
    model=os.getenv("GEMINI_MODEL", "gemini-2.0-flash"),
    name="base_assistant",
    description=f"Placeholder assistant for {APP_NAME}. Replace with your app logic.",
    instruction=BASE_ASSISTANT_INSTRUCTION,
)
