"""System prompt for the base assistant placeholder agent.

Replace this with your app-specific instructions.
"""

import os

APP_NAME = os.getenv("APP_NAME", "My App")

BASE_ASSISTANT_INSTRUCTION = f"""You are a helpful assistant for {APP_NAME}.

Introduce yourself briefly and ask how you can help the user today.

Keep responses concise and friendly.
"""
