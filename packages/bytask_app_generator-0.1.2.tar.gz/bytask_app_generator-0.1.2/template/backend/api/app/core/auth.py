"""JWT authentication dependency."""
from __future__ import annotations

import logging
from dataclasses import dataclass

import jwt
from fastapi import Depends, HTTPException, Request, status

from .config import settings

logger = logging.getLogger(__name__)

CREDENTIALS_EXCEPTION = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail={"error": "unauthorized", "message": "Authentication required"},
    headers={"WWW-Authenticate": "Bearer"},
)


@dataclass(slots=True)
class AuthenticatedUser:
    user_id: str
    email: str
    full_name: str
    tenant_id: str
    role: str
    is_active: bool = True


def _get_token_from_request(request: Request) -> str | None:
    # 1. HTTP-only cookie (primary)
    token = request.cookies.get("access_token")
    if token:
        return token
    # 2. Authorization header fallback
    auth = request.headers.get("Authorization", "")
    if auth.lower().startswith("bearer "):
        return auth.split(" ", 1)[1].strip()
    return None


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "token_expired", "message": "Access token has expired"},
        )
    except jwt.PyJWTError as exc:
        logger.debug("JWT decode error: %s", exc)
        raise CREDENTIALS_EXCEPTION


async def get_current_user(request: Request) -> AuthenticatedUser:
    # Internal API key bypass
    api_key = request.headers.get("X-Internal-API-Key")
    if api_key and api_key == settings.internal_api_key:
        return AuthenticatedUser(
            user_id="__internal__",
            email="internal@system",
            full_name="Internal",
            tenant_id="__internal__",
            role="admin",
        )

    token = _get_token_from_request(request)
    if not token:
        raise CREDENTIALS_EXCEPTION

    claims = decode_token(token)

    user_id = claims.get("sub")
    if not user_id:
        raise CREDENTIALS_EXCEPTION

    return AuthenticatedUser(
        user_id=user_id,
        email=claims.get("email", ""),
        full_name=claims.get("full_name", ""),
        tenant_id=claims.get("tenant_id", ""),
        role=claims.get("role", "member"),
    )


async def require_user(user: AuthenticatedUser = Depends(get_current_user)) -> AuthenticatedUser:
    return user


async def require_internal(request: Request) -> None:
    api_key = request.headers.get("X-Internal-API-Key")
    if not api_key or api_key != settings.internal_api_key:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "forbidden", "message": "Internal API key required"},
        )
