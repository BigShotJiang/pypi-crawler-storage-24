import logging
from datetime import datetime
from typing import AsyncGenerator

from sqlalchemy import DateTime, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.sql import func

from .config import settings

logger = logging.getLogger(__name__)

engine = create_async_engine(
    settings.database_url,
    echo=settings.debug,
    pool_pre_ping=True,
)

AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


class Base(DeclarativeBase):
    """Base class with common timestamp + soft-delete fields."""

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )
    deleted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, default=None, index=True
    )

    @property
    def is_deleted(self) -> bool:
        return self.deleted_at is not None

    def soft_delete(self) -> None:
        self.deleted_at = func.now()

    def restore(self) -> None:
        self.deleted_at = None


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


async def get_tenant_db(tenant_id: str) -> AsyncGenerator[AsyncSession, None]:
    """Get DB session with search_path set to the tenant schema."""
    async with AsyncSessionLocal() as session:
        try:
            schema = f"tenant_{tenant_id.replace('-', '_')}"
            await session.execute(text(f"SET search_path TO {schema}, public"))
            yield session
        finally:
            await session.close()


async def verify_database_connection() -> None:
    try:
        async with engine.begin() as conn:
            await conn.execute(text("SELECT 1"))
        logger.info("Database connectivity check succeeded.")
    except Exception as exc:
        logger.exception("Database connectivity check failed")
        raise RuntimeError("Database connectivity check failed") from exc


async def close_db() -> None:
    await engine.dispose()
