from pathlib import Path
from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # App
    app_name: str = Field(default="My App", alias="APP_NAME")
    debug: bool = Field(default=False)
    env: str = Field(default="development", alias="ENV")

    # Database
    database_url: str = Field(
        default="postgresql+asyncpg://bytask:bytask_local@db:5432/bytask_db",
        alias="DATABASE_URL",
    )

    # JWT
    jwt_secret: str = Field(default="change_me_in_production", alias="JWT_SECRET")
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = Field(default=15, alias="JWT_ACCESS_TOKEN_EXPIRE_MINUTES")
    jwt_refresh_token_expire_days: int = Field(default=7, alias="JWT_REFRESH_TOKEN_EXPIRE_DAYS")

    # Internal API key (for machine-to-machine calls)
    internal_api_key: str = Field(default="change_me_internal_key", alias="INTERNAL_API_KEY")

    # Agent server
    agent_server_url: str = Field(default="http://agent_server:8001", alias="AGENT_SERVER_URL")

    # Google OAuth
    google_client_id: str = Field(default="", alias="GOOGLE_CLIENT_ID")
    google_client_secret: str = Field(default="", alias="GOOGLE_CLIENT_SECRET")
    google_redirect_uri: str = Field(
        default="http://localhost:8000/api/v1/auth/google/callback",
        alias="GOOGLE_REDIRECT_URI",
    )

    # Feature flags
    feature_chat_enabled: bool = Field(default=False, alias="FEATURE_CHAT_ENABLED")
    feature_gmail_connector_enabled: bool = Field(default=False, alias="FEATURE_GMAIL_CONNECTOR_ENABLED")

    # CORS
    cors_allow_origins: str = Field(
        default="http://localhost:3000",
        alias="CORS_ALLOW_ORIGINS",
    )

    # Migrations
    run_migrations_on_startup: bool = Field(default=True, alias="RUN_MIGRATIONS_ON_STARTUP")

    @property
    def cors_allowed_origins(self) -> list[str]:
        return [o.strip() for o in self.cors_allow_origins.split(",") if o.strip()]

    model_config = {"env_file": ".env", "extra": "ignore", "populate_by_name": True}


settings = Settings()
