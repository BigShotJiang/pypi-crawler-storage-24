import uuid
from sqlalchemy import String, Boolean, UUID
from sqlalchemy.orm import Mapped, mapped_column
from app.core.db import Base


class User(Base):
    """User entity — lives in the `public` schema."""

    __tablename__ = "users"
    __table_args__ = {"schema": "public"}

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email: Mapped[str] = mapped_column(String(320), unique=True, nullable=False, index=True)
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False, default="")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    google_id: Mapped[str | None] = mapped_column(String(255), nullable=True, unique=True)
