from __future__ import annotations

import uuid
import logging
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from .model import Tenant, TenantUser

logger = logging.getLogger(__name__)


async def get_or_create_tenant(db: AsyncSession, slug: str, name: str) -> Tenant:
    from sqlalchemy import select

    result = await db.execute(select(Tenant).where(Tenant.slug == slug))
    existing = result.scalar_one_or_none()
    if existing:
        return existing

    tenant = Tenant(id=uuid.uuid4(), slug=slug, name=name)
    db.add(tenant)
    await db.flush()
    return tenant


async def provision_tenant(db: AsyncSession, slug: str, name: str) -> dict:
    """
    1. Create tenant record in public.tenants
    2. Create schema tenant_{id}
    3. (Alembic upgrade is handled by the provisioner Cloud Run Job)
    """
    tenant = await get_or_create_tenant(db, slug, name)
    schema_name = f"tenant_{str(tenant.id).replace('-', '_')}"

    await db.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema_name}"'))
    await db.commit()

    logger.info("Provisioned tenant %s with schema %s", tenant.id, schema_name)
    return {"tenant_id": str(tenant.id), "slug": slug, "schema": schema_name}


async def add_user_to_tenant(
    db: AsyncSession,
    tenant_id: uuid.UUID,
    user_id: uuid.UUID,
    role: str = "admin",
) -> TenantUser:
    tenant_user = TenantUser(tenant_id=tenant_id, user_id=user_id, role=role)
    db.add(tenant_user)
    await db.commit()
    await db.refresh(tenant_user)
    return tenant_user
