"""Auth endpoints: login, register, refresh, Google OAuth."""
from __future__ import annotations

import logging
import uuid

import jwt
from fastapi import APIRouter, Depends, HTTPException, Response, Request, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.db import get_db
from app.core.auth import decode_token, require_user, AuthenticatedUser
from app.modules.auth.schemas import LoginRequest, RegisterRequest, TokenResponse, RefreshRequest
from app.modules.auth import service as auth_service
from app.modules.users import service as user_service
from app.modules.tenants import service as tenant_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(body: RegisterRequest, db: AsyncSession = Depends(get_db)):
    existing = await user_service.get_user_by_email(db, body.email)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": "email_taken", "message": "Email already registered"},
        )

    password_hash = auth_service.hash_password(body.password)
    user = await user_service.create_user(
        db, email=body.email, full_name=body.full_name, password_hash=password_hash
    )

    # Auto-provision a personal tenant
    slug = body.email.split("@")[0].lower().replace(".", "-")
    tenant_data = await tenant_service.provision_tenant(db, slug=slug, name=body.full_name)
    await tenant_service.add_user_to_tenant(
        db, tenant_id=uuid.UUID(tenant_data["tenant_id"]), user_id=user.id, role="admin"
    )

    access_token = auth_service.create_access_token(
        user_id=str(user.id),
        tenant_id=tenant_data["tenant_id"],
        role="admin",
        email=user.email,
    )
    refresh_token = auth_service.create_refresh_token(str(user.id))
    return TokenResponse(access_token=access_token, refresh_token=refresh_token)


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest, db: AsyncSession = Depends(get_db)):
    user = await user_service.get_user_by_email(db, body.email)
    if not user or not user.password_hash:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "invalid_credentials", "message": "Invalid email or password"},
        )
    if not auth_service.verify_password(body.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "invalid_credentials", "message": "Invalid email or password"},
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "account_inactive", "message": "Account is inactive"},
        )

    # Get tenant membership (first tenant for now)
    from sqlalchemy import select
    from app.modules.tenants.model import TenantUser
    result = await db.execute(select(TenantUser).where(TenantUser.user_id == user.id))
    membership = result.scalars().first()
    tenant_id = str(membership.tenant_id) if membership else ""
    role = membership.role if membership else "member"

    access_token = auth_service.create_access_token(
        user_id=str(user.id), tenant_id=tenant_id, role=role, email=user.email
    )
    refresh_token = auth_service.create_refresh_token(str(user.id))
    return TokenResponse(access_token=access_token, refresh_token=refresh_token)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(body: RefreshRequest, db: AsyncSession = Depends(get_db)):
    try:
        claims = auth_service.decode_refresh_token(body.refresh_token)
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "token_expired", "message": "Refresh token expired"},
        )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "invalid_token", "message": "Invalid refresh token"},
        )

    if claims.get("type") != "refresh":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token type")

    user_id = claims.get("sub")
    user = await user_service.get_user_by_id(db, uuid.UUID(user_id))
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")

    from sqlalchemy import select
    from app.modules.tenants.model import TenantUser
    result = await db.execute(select(TenantUser).where(TenantUser.user_id == user.id))
    membership = result.scalars().first()
    tenant_id = str(membership.tenant_id) if membership else ""
    role = membership.role if membership else "member"

    access_token = auth_service.create_access_token(
        user_id=str(user.id), tenant_id=tenant_id, role=role, email=user.email
    )
    new_refresh = auth_service.create_refresh_token(str(user.id))
    return TokenResponse(access_token=access_token, refresh_token=new_refresh)


@router.get("/google/authorize")
async def google_authorize():
    url = auth_service.google_get_auth_url()
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url=url)


@router.get("/google/callback")
async def google_callback(code: str, db: AsyncSession = Depends(get_db)):
    try:
        google_user = await auth_service.google_exchange_code(code)
    except Exception as exc:
        logger.error("Google OAuth exchange failed: %s", exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="OAuth exchange failed")

    google_id = google_user.get("id")
    email = google_user.get("email")
    full_name = google_user.get("name", email)

    # Upsert user
    user = await user_service.get_user_by_google_id(db, google_id)
    if not user:
        user = await user_service.get_user_by_email(db, email)
        if user:
            # Link Google ID
            user.google_id = google_id
            await db.commit()
        else:
            user = await user_service.create_user(
                db, email=email, full_name=full_name, google_id=google_id
            )
            # Auto-provision tenant
            slug = email.split("@")[0].lower().replace(".", "-")
            tenant_data = await tenant_service.provision_tenant(db, slug=slug, name=full_name)
            await tenant_service.add_user_to_tenant(
                db, tenant_id=uuid.UUID(tenant_data["tenant_id"]), user_id=user.id, role="admin"
            )

    from sqlalchemy import select
    from app.modules.tenants.model import TenantUser
    result = await db.execute(select(TenantUser).where(TenantUser.user_id == user.id))
    membership = result.scalars().first()
    tenant_id = str(membership.tenant_id) if membership else ""
    role = membership.role if membership else "member"

    access_token = auth_service.create_access_token(
        user_id=str(user.id), tenant_id=tenant_id, role=role, email=user.email
    )
    refresh_token = auth_service.create_refresh_token(str(user.id))
    return TokenResponse(access_token=access_token, refresh_token=refresh_token)
