"""AG-UI proxy router — forwards chat requests to the agent server."""
from __future__ import annotations

import json
import logging

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import StreamingResponse

from app.core.auth import AuthenticatedUser, require_user
from app.core.config import settings

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Chat"])

AGENT_TIMEOUT = httpx.Timeout(connect=10.0, read=300.0, write=30.0, pool=10.0)


def _check_feature():
    if not settings.feature_chat_enabled:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail={"error": "feature_disabled", "message": "Chat feature is not enabled"},
        )


@router.post("/chat")
async def ag_ui_proxy(
    request: Request,
    user: AuthenticatedUser = Depends(require_user),
) -> StreamingResponse:
    _check_feature()

    payload = await request.json()
    if not isinstance(payload, dict):
        payload = {}

    agent_name = str(payload.pop("agent_name", "base_assistant")).strip() or "base_assistant"
    body = json.dumps(payload).encode("utf-8")
    agent_url = f"{settings.agent_server_url.rstrip('/')}/ag-ui"

    async def stream_from_agent():
        try:
            async with httpx.AsyncClient(timeout=AGENT_TIMEOUT) as client:
                async with client.stream(
                    "POST",
                    agent_url,
                    content=body,
                    headers={
                        "Content-Type": "application/json",
                        "Accept": "text/event-stream",
                        "X-User-Id": user.user_id,
                        "X-Session-Id": request.headers.get("X-Session-Id", ""),
                        "X-Tenant-Id": user.tenant_id,
                        "X-Agent-Name": agent_name,
                    },
                ) as response:
                    if response.status_code >= 400:
                        error_body = await response.aread()
                        logger.error("Agent server error %s: %s", response.status_code, error_body[:500])
                        yield f'data: {{"type":"error","message":"Agent server error: {response.status_code}"}}\n\n'.encode()
                        return
                    async for chunk in response.aiter_bytes():
                        yield chunk
        except httpx.ConnectError as exc:
            logger.error("Failed to connect to agent server: %s", exc)
            yield b'data: {"type":"error","message":"Agent server unavailable"}\n\n'
        except httpx.TimeoutException as exc:
            logger.error("Agent server timeout: %s", exc)
            yield b'data: {"type":"error","message":"Agent server timeout"}\n\n'
        except Exception as exc:
            logger.exception("Unexpected proxy error: %s", exc)
            yield b'data: {"type":"error","message":"Internal proxy error"}\n\n'

    return StreamingResponse(
        stream_from_agent(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/chat/health")
async def chat_health():
    _check_feature()
    health_url = f"{settings.agent_server_url.rstrip('/')}/health"
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(5.0)) as client:
            resp = await client.get(health_url)
            if resp.status_code == 200:
                return {"status": "healthy", "agent_server": resp.json()}
            return {"status": "degraded", "agent_server_status": resp.status_code}
    except Exception as exc:
        return {"status": "unhealthy", "error": str(exc)}


@router.get("/chat/info")
async def chat_info():
    _check_feature()
    return {
        "runtime": "ag-ui",
        "version": "1.0.0",
        "agents": ["base_assistant"],
    }
