"""Internal tenant provisioning endpoint."""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel

from app.core.db import get_db
from app.core.auth import require_internal
from app.modules.tenants import service as tenant_service

router = APIRouter(prefix="/internal", tags=["Internal"])


class ProvisionRequest(BaseModel):
    slug: str
    name: str


@router.post("/tenants/provision", dependencies=[Depends(require_internal)])
async def provision_tenant(body: ProvisionRequest, db: AsyncSession = Depends(get_db)):
    result = await tenant_service.provision_tenant(db, slug=body.slug, name=body.name)
    return result
