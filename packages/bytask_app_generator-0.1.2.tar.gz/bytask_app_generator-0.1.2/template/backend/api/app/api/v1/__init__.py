from fastapi import APIRouter
from .endpoints import auth, users, tenants, chat

router = APIRouter(prefix="/api/v1")
router.include_router(auth.router)
router.include_router(users.router)
router.include_router(tenants.router)
router.include_router(chat.router)
