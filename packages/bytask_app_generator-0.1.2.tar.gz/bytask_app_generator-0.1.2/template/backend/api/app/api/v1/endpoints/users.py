"""User endpoints."""
from __future__ import annotations

import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel

from app.core.db import get_db
from app.core.auth import require_user, AuthenticatedUser
from app.modules.users import service as user_service

router = APIRouter(prefix="/users", tags=["Users"])


class UserResponse(BaseModel):
    id: str
    email: str
    full_name: str
    tenant_id: str
    role: str
    is_active: bool


@router.get("/me", response_model=UserResponse)
async def get_me(
    current_user: AuthenticatedUser = Depends(require_user),
    db: AsyncSession = Depends(get_db),
):
    user = await user_service.get_user_by_id(db, uuid.UUID(current_user.user_id))
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return UserResponse(
        id=str(user.id),
        email=user.email,
        full_name=user.full_name,
        tenant_id=current_user.tenant_id,
        role=current_user.role,
        is_active=user.is_active,
    )


class VerifySessionRequest(BaseModel):
    token: str


@router.post("/verify/session")
async def verify_session(body: VerifySessionRequest):
    """Validate access token and return user shape for SSR."""
    from app.core.auth import decode_token
    try:
        claims = decode_token(body.token)
    except HTTPException:
        return {"success": False, "data": None}

    return {
        "success": True,
        "data": {
            "sessionType": "user",
            "sessionId": claims.get("sub"),
            "user": {
                "id": claims.get("sub"),
                "email": claims.get("email"),
                "name": claims.get("full_name", ""),
                "userType": "user",
                "role": claims.get("role", "member"),
                "isAdmin": claims.get("role") == "admin",
                "isActive": True,
                "isVerified": True,
                "sessionId": claims.get("sub"),
            },
        },
    }
