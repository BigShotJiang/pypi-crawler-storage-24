"""Basic auth endpoint tests."""
import pytest
from httpx import AsyncClient, ASGITransport
from unittest.mock import AsyncMock, patch

from app.main import app


@pytest.mark.asyncio
async def test_health():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        resp = await client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


@pytest.mark.asyncio
async def test_register_and_login():
    """Smoke test: register then login returns tokens."""
    with (
        patch("app.modules.users.service.get_user_by_email", AsyncMock(return_value=None)),
        patch("app.modules.users.service.create_user") as mock_create,
        patch("app.modules.tenants.service.provision_tenant", AsyncMock(return_value={"tenant_id": "aaaaaaaa-0000-0000-0000-000000000000", "schema": "tenant_x"})),
        patch("app.modules.tenants.service.add_user_to_tenant", AsyncMock()),
    ):
        import uuid
        from app.modules.users.model import User
        fake_user = User()
        fake_user.id = uuid.UUID("aaaaaaaa-0000-0000-0000-000000000000")
        fake_user.email = "test@example.com"
        fake_user.full_name = "Test User"
        fake_user.is_active = True
        fake_user.password_hash = None
        mock_create.return_value = fake_user

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            resp = await client.post(
                "/api/v1/auth/register",
                json={"email": "test@example.com", "password": "pass1234", "full_name": "Test User"},
            )
        assert resp.status_code == 201
        data = resp.json()
        assert "access_token" in data
        assert "refresh_token" in data
