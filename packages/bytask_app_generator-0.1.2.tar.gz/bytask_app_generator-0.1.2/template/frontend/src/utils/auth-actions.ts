"use server"

import { cookies } from "next/headers"
import { APP_URL } from "./config-constants"
import { kyRequest } from "@/lib/kyInstance"
import { HTTPError } from "ky"

export type SessionState =
  | {
      isValid: true
      sessionType: "user"
      sessionId: string
      user: {
        id: string
        email: string
        name: string
        userType: "user"
        role: string
        isAdmin: boolean
        isActive: boolean
        isVerified: boolean
        sessionId: string
        tenantId?: string
      }
    }
  | { isValid: false }

export async function setAccessTokenCookie(token: string): Promise<void> {
  const cookieStore = await cookies()
  const isProduction = process.env.NODE_ENV === "production"
  cookieStore.set("access_token", token, {
    httpOnly: true,
    secure: isProduction,
    sameSite: isProduction ? "none" : "lax",
    path: "/",
    maxAge: 15 * 60, // 15 minutes
  })
}

export async function setRefreshTokenCookie(token: string): Promise<void> {
  const cookieStore = await cookies()
  const isProduction = process.env.NODE_ENV === "production"
  cookieStore.set("refresh_token", token, {
    httpOnly: true,
    secure: isProduction,
    sameSite: isProduction ? "none" : "lax",
    path: "/",
    maxAge: 7 * 24 * 60 * 60, // 7 days
  })
}

export async function clearAuthCookies(): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.set("access_token", "", { maxAge: 0, path: "/" })
  cookieStore.set("refresh_token", "", { maxAge: 0, path: "/" })
}

export async function getAccessToken(): Promise<string | undefined> {
  const cookieStore = await cookies()
  return cookieStore.get("access_token")?.value
}

export async function getRefreshToken(): Promise<string | undefined> {
  const cookieStore = await cookies()
  return cookieStore.get("refresh_token")?.value
}

export async function verifySession(): Promise<SessionState> {
  try {
    const token = await getAccessToken()
    if (!token) return { isValid: false }

    const data = await kyRequest(`${APP_URL}/api/users/verify/session`, {
      method: "POST",
      json: { token },
    }).json<{ success: boolean; data?: any }>()

    if (!data.success || !data.data) return { isValid: false }

    const session = data.data
    if (session.user && session.sessionId) {
      return {
        isValid: true,
        sessionType: "user",
        sessionId: session.sessionId,
        user: {
          ...session.user,
          userType: "user",
          sessionId: session.sessionId,
          tenantId: session.user.tenantId,
        },
      }
    }
    return { isValid: false }
  } catch (error) {
    if (error instanceof HTTPError && error.response.status === 401) {
      return { isValid: false }
    }
    return { isValid: false }
  }
}
