const isServer = typeof window === "undefined"

export const API_URL = isServer
  ? process.env.API_INTERNAL_URL ||
    process.env.NEXT_PUBLIC_API_URL ||
    "http://localhost:8000"
  : process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"

export const APP_URL = isServer
  ? process.env.INTERNAL_APP_URL ||
    process.env.NEXT_PUBLIC_APP_URL ||
    "http://localhost:3000"
  : process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"
