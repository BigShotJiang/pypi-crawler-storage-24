"use client"

import { ReactNode } from "react"
import Sidebar from "@/components/sidebar"
import Navbar from "@/components/navbar"

interface LayoutProps {
  children: ReactNode
}

export default function Shell({ children }: LayoutProps) {
  return (
    <div className="flex w-full flex-col bg-[#F6F7FC] md:flex-row min-h-screen">
      {/* Desktop sidebar */}
      <Sidebar />

      {/* Mobile navbar */}
      <Navbar />

      {/* Main content area */}
      <section className="flex-1 bg-[#F6F7FC] mt-14 md:mt-0 md:ml-24 overflow-x-hidden">
        <div className="mx-auto max-w-[1400px] p-4 md:p-6">{children}</div>
      </section>
    </div>
  )
}
