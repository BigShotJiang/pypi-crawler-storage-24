"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, LayoutDashboard, Settings, LogOut } from "lucide-react"
import { useTranslations } from "next-intl"
import { APP_NAME, APP_LOGO_URL } from "@/config/theme"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const t = useTranslations("navigation")

  const handleLogout = async () => {
    await fetch("/api/users/logout", { method: "POST" })
    window.location.href = "/login"
  }

  return (
    <>
      {/* Mobile top bar */}
      <header className="fixed top-0 right-0 left-0 z-50 flex items-center justify-between bg-white px-4 py-3 shadow-sm md:hidden">
        <button onClick={() => setIsOpen(!isOpen)} className="p-1">
          {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>

        <Link href="/dashboard" className="flex items-center gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={APP_LOGO_URL} alt={APP_NAME} className="h-7 w-7 object-contain" />
          <span className="font-semibold text-sm">{APP_NAME}</span>
        </Link>

        <div className="w-8" /> {/* Spacer */}
      </header>

      {/* Mobile slide-over menu */}
      {isOpen && (
        <div className="fixed inset-0 z-40 bg-white pt-14 md:hidden">
          <nav className="flex flex-col p-4 gap-2">
            <Link
              href="/dashboard"
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-3 rounded-md px-3 py-3 hover:bg-gray-100"
            >
              <LayoutDashboard className="h-5 w-5 text-gray-600" />
              <span className="text-sm font-medium">{t("dashboard")}</span>
            </Link>
            <Link
              href="/settings"
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-3 rounded-md px-3 py-3 hover:bg-gray-100"
            >
              <Settings className="h-5 w-5 text-gray-600" />
              <span className="text-sm font-medium">{t("settings")}</span>
            </Link>
            <button
              onClick={handleLogout}
              className="flex items-center gap-3 rounded-md px-3 py-3 hover:bg-red-50 text-left"
            >
              <LogOut className="h-5 w-5 text-red-500" />
              <span className="text-sm font-medium text-red-500">{t("logout")}</span>
            </button>
          </nav>
        </div>
      )}
    </>
  )
}
