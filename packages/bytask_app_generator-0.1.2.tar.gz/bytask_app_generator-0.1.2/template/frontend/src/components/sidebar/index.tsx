"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { LayoutDashboard, Settings, LogOut } from "lucide-react"
import { useTranslations } from "next-intl"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useAuth } from "@/contexts/AuthContext"
import { APP_NAME, APP_LOGO_URL } from "@/config/theme"

const navItems = [
  { href: "/dashboard", icon: LayoutDashboard, labelKey: "dashboard" },
  { href: "/settings", icon: Settings, labelKey: "settings" },
]

export default function Sidebar() {
  const pathname = usePathname()
  const t = useTranslations("navigation")
  const { user } = useAuth()

  const handleLogout = async () => {
    await fetch("/api/users/logout", { method: "POST" })
    window.location.href = "/login"
  }

  return (
    <nav className="fixed top-0 left-0 hidden h-screen w-24 flex-shrink-0 flex-col items-center justify-between bg-white py-4 shadow-sm md:flex">
      <div className="flex flex-col items-center gap-6 mt-4">
        {/* Logo */}
        <Link href="/dashboard" className="flex items-center justify-center w-12 h-12">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={APP_LOGO_URL}
            alt={APP_NAME}
            className="w-10 h-10 object-contain"
            onError={(e) => {
              ;(e.target as HTMLImageElement).style.display = "none"
            }}
          />
        </Link>

        {/* Nav items */}
        <div className="flex w-full flex-col items-center gap-2">
          {navItems.map(({ href, icon: Icon, labelKey }) => (
            <Link
              key={href}
              href={href}
              className={`flex w-full flex-col items-center gap-1 rounded-md px-3 py-2 ${
                pathname.startsWith(href)
                  ? "bg-[var(--primary-200)]"
                  : "hover:bg-[var(--primary-200)]"
              }`}
            >
              <Icon className="h-5 w-5 text-gray-600" />
              <p className="text-center text-[10px] leading-3 font-medium text-gray-600">
                {t(labelKey as any)}
              </p>
            </Link>
          ))}
        </div>
      </div>

      {/* User avatar + logout */}
      <div className="flex flex-col items-center gap-4 mb-2">
        <button
          onClick={handleLogout}
          className="flex flex-col items-center gap-1 rounded-md px-3 py-2 hover:bg-red-50 text-gray-500 hover:text-red-500"
        >
          <LogOut className="h-5 w-5" />
          <p className="text-[10px] leading-3 font-medium">{t("logout")}</p>
        </button>

        <Avatar className="h-10 w-10 rounded-lg">
          <AvatarFallback className="rounded-lg text-sm font-semibold">
            {user?.name?.charAt(0)?.toUpperCase() || "U"}
          </AvatarFallback>
        </Avatar>
      </div>
    </nav>
  )
}
