import { NextRequest, NextResponse } from "next/server"
import { setAccessTokenCookie, setRefreshTokenCookie } from "@/utils/auth-actions"
import { APP_URL } from "@/utils/config-constants"

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const access_token = searchParams.get("access_token")
  const refresh_token = searchParams.get("refresh_token")

  if (access_token) {
    await setAccessTokenCookie(access_token)
    if (refresh_token) await setRefreshTokenCookie(refresh_token)
    return NextResponse.redirect(`${APP_URL}/dashboard`)
  }

  return NextResponse.redirect(`${APP_URL}/login?error=oauth_failed`)
}
