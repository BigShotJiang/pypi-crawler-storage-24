import { NextRequest, NextResponse } from "next/server"
import { getRefreshToken, setAccessTokenCookie, setRefreshTokenCookie } from "@/utils/auth-actions"
import { API_URL } from "@/utils/config-constants"

export async function POST(_request: NextRequest) {
  try {
    const refreshToken = await getRefreshToken()
    if (!refreshToken) {
      return NextResponse.json({ error: "No refresh token" }, { status: 401 })
    }

    const resp = await fetch(`${API_URL}/api/v1/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refreshToken }),
    })

    if (!resp.ok) {
      return NextResponse.json({ error: "Refresh failed" }, { status: 401 })
    }

    const { access_token, refresh_token } = await resp.json()
    await setAccessTokenCookie(access_token)
    if (refresh_token) await setRefreshTokenCookie(refresh_token)
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ error: "Refresh failed" }, { status: 500 })
  }
}
