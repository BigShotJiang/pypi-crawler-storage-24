import { NextRequest, NextResponse } from "next/server"
import { API_URL } from "@/utils/config-constants"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const token = body?.token
    if (!token) {
      return NextResponse.json({ success: false }, { status: 400 })
    }

    const resp = await fetch(`${API_URL}/api/v1/users/verify/session`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token }),
    })

    if (!resp.ok) {
      return NextResponse.json({ success: false }, { status: resp.status })
    }

    const data = await resp.json()
    return NextResponse.json(data)
  } catch {
    return NextResponse.json({ success: false }, { status: 500 })
  }
}
