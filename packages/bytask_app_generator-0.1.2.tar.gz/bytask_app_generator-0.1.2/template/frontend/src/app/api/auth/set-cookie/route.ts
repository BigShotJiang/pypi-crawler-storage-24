import { NextRequest, NextResponse } from "next/server"
import { setAccessTokenCookie, setRefreshTokenCookie } from "@/utils/auth-actions"

export async function POST(request: NextRequest) {
  try {
    const { access_token, refresh_token } = await request.json()
    if (!access_token) {
      return NextResponse.json({ error: "access_token required" }, { status: 400 })
    }
    await setAccessTokenCookie(access_token)
    if (refresh_token) await setRefreshTokenCookie(refresh_token)
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ error: "Failed to set cookies" }, { status: 500 })
  }
}
