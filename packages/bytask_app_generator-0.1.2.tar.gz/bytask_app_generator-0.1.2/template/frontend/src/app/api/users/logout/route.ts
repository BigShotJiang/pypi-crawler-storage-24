import { NextResponse } from "next/server"
import { clearAuthCookies } from "@/utils/auth-actions"

export async function POST() {
  await clearAuthCookies()
  return NextResponse.json({ success: true })
}
