import { cookies } from "next/headers"
import { NextIntlClientProvider } from "next-intl"
import { getMessages } from "next-intl/server"
import type { Metadata } from "next"
import "./globals.css"
import { Toaster } from "@/components/ui/sonner"
import { AuthProvider } from "@/contexts/AuthContext"
import { QueryProvider } from "@/providers/query-provider"
import { verifySession } from "@/utils/auth-actions"
import { APP_NAME, APP_PRIMARY_COLOR } from "@/config/theme"

export const metadata: Metadata = {
  title: APP_NAME,
  description: `${APP_NAME} — powered by Bytask`,
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const cookieStore = await cookies()
  const rawLocale = cookieStore.get("lang")?.value || "en"
  const locale = rawLocale === "en" || rawLocale === "es" ? rawLocale : "en"
  const messages = await getMessages({ locale })

  const session = await verifySession()
  const user =
    session.isValid && "user" in session
      ? {
          id: session.user.id,
          email: session.user.email,
          name: session.user.name,
          role: session.user.role,
          isAdmin: session.user.isAdmin,
          isActive: session.user.isActive,
          sessionId: session.user.sessionId,
        }
      : null

  return (
    <html lang={locale}>
      <head>
        {/* Inject dynamic primary color */}
        <style>{`:root { --app-primary: ${APP_PRIMARY_COLOR}; }`}</style>
      </head>
      <body suppressHydrationWarning>
        <NextIntlClientProvider locale={locale} messages={messages}>
          <QueryProvider>
            <AuthProvider user={user}>
              {children}
              <Toaster />
            </AuthProvider>
          </QueryProvider>
        </NextIntlClientProvider>
      </body>
    </html>
  )
}
