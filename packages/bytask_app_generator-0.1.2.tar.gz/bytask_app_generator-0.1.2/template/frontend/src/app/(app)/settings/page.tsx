import { getTranslations } from "next-intl/server"

export default async function SettingsPage() {
  const t = await getTranslations("settings")

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">{t("title")}</h1>
        <p className="text-muted-foreground mt-1">{t("account")}</p>
      </div>

      <div className="rounded-xl border bg-white p-8 text-center text-muted-foreground">
        <p className="text-sm">Settings content goes here.</p>
      </div>
    </div>
  )
}
