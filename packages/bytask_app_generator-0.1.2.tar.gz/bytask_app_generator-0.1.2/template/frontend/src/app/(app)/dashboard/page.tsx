import { getTranslations } from "next-intl/server"
import { verifySession } from "@/utils/auth-actions"
import { APP_NAME } from "@/config/theme"

export default async function DashboardPage() {
  const t = await getTranslations("dashboard")
  const session = await verifySession()
  const name = session.isValid && "user" in session ? session.user.name : ""

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">{t("title")}</h1>
        {name && (
          <p className="text-muted-foreground mt-1">
            {t("welcome", { name })}
          </p>
        )}
      </div>

      <div className="rounded-xl border bg-white p-8 text-center text-muted-foreground">
        <p className="text-lg font-medium">{APP_NAME}</p>
        <p className="text-sm mt-2">Your dashboard content goes here.</p>
      </div>
    </div>
  )
}
