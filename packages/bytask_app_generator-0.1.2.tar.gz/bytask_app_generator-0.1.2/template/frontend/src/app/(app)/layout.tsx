import { redirect } from "next/navigation"
import { verifySession } from "@/utils/auth-actions"
import Shell from "@/components/layout"

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await verifySession()
  if (!session.isValid) redirect("/login")

  return <Shell>{children}</Shell>
}
