"use client"

import { useState } from "react"
import Link from "next/link"
import { useTranslations } from "next-intl"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { APP_NAME, APP_LOGO_URL } from "@/config/theme"

const schema = z.object({ email: z.string().email() })
type FormData = z.infer<typeof schema>

export default function ForgotPasswordPage() {
  const t = useTranslations("auth")
  const [loading, setLoading] = useState(false)
  const [sent, setSent] = useState(false)

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  const onSubmit = async (_data: FormData) => {
    setLoading(true)
    // TODO: call backend /api/v1/auth/forgot-password once implemented
    await new Promise((r) => setTimeout(r, 800))
    setSent(true)
    toast.success(t("reset_link_sent"))
    setLoading(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={APP_LOGO_URL} alt={APP_NAME} className="h-10 mx-auto mb-2 object-contain" />
          <CardTitle className="text-2xl">{t("reset_password")}</CardTitle>
          <CardDescription>{APP_NAME}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {sent ? (
            <p className="text-center text-sm text-muted-foreground">{t("reset_link_sent")}</p>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">{t("email")}</Label>
                <Input id="email" type="email" {...register("email")} />
                {errors.email && <p className="text-xs text-red-500">{errors.email.message}</p>}
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "..." : t("send_reset_link")}
              </Button>
            </form>
          )}
          <p className="text-center text-sm">
            <Link href="/login" className="text-[var(--app-primary)] hover:underline">
              {t("back_to_login")}
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
