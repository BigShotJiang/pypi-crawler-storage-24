import { getRequestConfig } from "next-intl/server"
import { cookies } from "next/headers"
import en from "./messages/en.json"
import es from "./messages/es.json"

const messagesMap = { en, es }
type Locale = keyof typeof messagesMap

export default getRequestConfig(async () => {
  const cookieStore = await cookies()
  const rawLocale = cookieStore.get("lang")?.value || "en"
  const locale: Locale = rawLocale === "en" || rawLocale === "es" ? rawLocale : "en"
  return { locale, messages: messagesMap[locale] }
})
