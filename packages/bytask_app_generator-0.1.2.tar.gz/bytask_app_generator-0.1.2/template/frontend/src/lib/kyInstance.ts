import ky from "ky"
import { API_URL } from "@/utils/config-constants"

function getCurrentLanguage(): string {
  if (typeof document !== "undefined") {
    const langCookie = document.cookie.split("; ").find((c) => c.startsWith("lang="))
    if (langCookie) {
      const lang = langCookie.split("=")[1]
      if (lang === "es" || lang === "en") return lang
    }
  }
  return "en"
}

export const kyAPI = ky.create({
  prefixUrl: API_URL,
  retry: {
    limit: 3,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
    statusCodes: [408, 413, 429, 502, 503, 504],
    backoffLimit: 10000,
  },
  timeout: 30000,
  credentials: "include",
  hooks: {
    beforeRequest: [
      (request) => {
        request.headers.set("Accept-Language", getCurrentLanguage())
      },
    ],
  },
})

export const kyAPIServer = ky.create({
  prefixUrl: API_URL,
  retry: {
    limit: 3,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
    statusCodes: [408, 413, 429, 502, 503, 504],
    backoffLimit: 5000,
  },
  timeout: 15000,
  credentials: "include",
  hooks: {
    beforeRequest: [
      (request) => {
        request.headers.set("Accept-Language", getCurrentLanguage())
      },
    ],
  },
})

export function kyRequest(url: string, options?: RequestInit & { json?: unknown }) {
  const language = getCurrentLanguage()
  if (url.startsWith("http://") || url.startsWith("https://")) {
    return ky(url, {
      retry: { limit: 3, methods: ["GET", "POST"], statusCodes: [408, 502, 503, 504] },
      timeout: 15000,
      credentials: "include",
      headers: { "Accept-Language": language, ...options?.headers },
      ...options,
    })
  }
  return kyAPIServer(url, options)
}

export { ky }
