/* eslint-disable @typescript-eslint/no-explicit-any */
import { type Options as KyOptions } from "ky"
import { kyAPI } from "./kyInstance"

export interface ApiResponse<T = any> {
  data?: T
  message?: string
  success?: boolean
}

export interface FetchOptions {
  token?: string
  params?: Record<string, string>
  headers?: Record<string, string>
  method?: string
}

class ApiClient {
  private ky: typeof kyAPI

  constructor() {
    this.ky = kyAPI
  }

  private buildOptions(options: FetchOptions & { disableRetry?: boolean } = {}): KyOptions {
    const { token, params, disableRetry, ...fetchOptions } = options
    const kyOptions: KyOptions = {
      ...fetchOptions,
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...fetchOptions.headers,
      },
    }
    if (token) {
      kyOptions.headers = {
        ...kyOptions.headers,
        Authorization: `Bearer ${token}`,
      }
    }
    if (params) kyOptions.searchParams = params
    if (disableRetry) kyOptions.retry = 0
    return kyOptions
  }

  async fetch<T = any>(
    endpoint: string,
    options: FetchOptions & { disableRetry?: boolean } = {}
  ): Promise<ApiResponse<T>> {
    try {
      const kyOptions = this.buildOptions(options)
      const cleanEndpoint = endpoint.startsWith("/") ? endpoint.slice(1) : endpoint
      return await this.ky(cleanEndpoint, kyOptions).json<ApiResponse<T>>()
    } catch (error: any) {
      if (error.name === "HTTPError") {
        const errorJson = await error.response.json().catch(() => ({}))
        throw new Error(errorJson.message || `Request failed with status ${error.response.status}`)
      }
      throw error
    }
  }

  async get<T = any>(endpoint: string, options?: FetchOptions): Promise<ApiResponse<T>> {
    return this.fetch<T>(endpoint, { ...options, method: "GET" })
  }

  async post<T = any>(endpoint: string, body?: any, options?: FetchOptions): Promise<ApiResponse<T>> {
    return this.fetch<T>(endpoint, { ...options, method: "POST", ...(body ? { json: body } as any : {}) })
  }

  async put<T = any>(endpoint: string, body?: any, options?: FetchOptions): Promise<ApiResponse<T>> {
    return this.fetch<T>(endpoint, { ...options, method: "PUT", ...(body ? { json: body } as any : {}) })
  }

  async patch<T = any>(endpoint: string, body?: any, options?: FetchOptions): Promise<ApiResponse<T>> {
    return this.fetch<T>(endpoint, { ...options, method: "PATCH", ...(body ? { json: body } as any : {}) })
  }

  async delete<T = any>(endpoint: string, body?: any, options?: FetchOptions): Promise<ApiResponse<T>> {
    return this.fetch<T>(endpoint, { ...options, method: "DELETE", ...(body ? { json: body } as any : {}) })
  }
}

export const apiClient = new ApiClient()
