import { NextRequest, NextResponse } from "next/server"

const publicRoutes = ["/login", "/register", "/forgot-password"]

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  const headers = new Headers(request.headers)
  headers.set("x-current-path", pathname)

  const isPublicRoute = publicRoutes.some(
    (route) => pathname === route || pathname.startsWith(`${route}/`)
  )

  const token = request.cookies.get("access_token")?.value

  if (isPublicRoute) {
    return NextResponse.next({ request: { headers } })
  }

  if (token) {
    return NextResponse.next({ request: { headers } })
  }

  return NextResponse.redirect(new URL("/login", request.url))
}

export const config = {
  matcher: [
    "/((?!api|_next/static|_next/image|_next/webpack-hmr|favicon.ico|brand|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|css|js|woff|woff2|ttf|eot)).*)",
  ],
}
