"use client"

import { createContext, useContext, ReactNode } from "react"

export interface AuthUser {
  id: string
  email: string
  name: string
  role: string
  isAdmin: boolean
  isActive: boolean
  tenantId?: string
  sessionId: string
}

interface AuthContextValue {
  user: AuthUser | null
  isAuthenticated: boolean
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

interface AuthProviderProps {
  children: ReactNode
  user: AuthUser | null
}

/**
 * AuthProvider — provides SSR user data to client components.
 * NOT the source of truth for auth; that is HTTP-only cookie + verifySession().
 */
export function AuthProvider({ children, user }: AuthProviderProps) {
  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext)
  if (context === undefined) {
    if (typeof window === "undefined") return { user: null, isAuthenticated: false }
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
