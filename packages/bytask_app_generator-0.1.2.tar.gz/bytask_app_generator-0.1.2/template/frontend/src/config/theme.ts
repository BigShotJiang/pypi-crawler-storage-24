export const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME || "My App"
export const APP_PRIMARY_COLOR = process.env.NEXT_PUBLIC_PRIMARY_COLOR || "#02aea2"
export const APP_LOGO_URL = process.env.NEXT_PUBLIC_LOGO_URL || "/brand/placeholder-logo.svg"
