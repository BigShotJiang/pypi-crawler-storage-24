# Changelog

All notable changes to this generated project should be documented in this file.

## Unreleased

- Initial scaffold generated from `bytask-app-generator`
