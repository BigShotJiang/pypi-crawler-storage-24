"""CLI entrypoint for bytask-app-generator."""

from __future__ import annotations

import json
from pathlib import Path

import typer
import yaml

from bt_app_generator.catalog import DEFAULT_SPEC, MODULES, VERIFIED_PRESETS, preset_spec
from bt_app_generator.copier_ops import generate_project, update_project
from bt_app_generator.spec import apply_overrides, load_schema, load_yaml, normalize_spec, validate_spec
from bt_app_generator.template_source import checkout_root, resolve_template_src


app = typer.Typer(no_args_is_help=True, add_completion=False)


def _repo_root() -> Path:
    root = checkout_root()
    if root is not None:
        return root
    return Path.cwd()


def _load_user_spec(spec_path: Path | None, preset: str | None, overrides: list[str]) -> dict:
    spec: dict = {}
    if preset:
        spec = preset_spec(preset)
    elif spec_path:
        spec = load_yaml(spec_path)
    else:
        spec = DEFAULT_SPEC
    return apply_overrides(spec, overrides)


@app.command()
def schema() -> None:
    """Print the public project spec JSON schema."""
    typer.echo(json.dumps(load_schema(_repo_root()), indent=2))


@app.command()
def describe(format: str = typer.Option("text", "--format")) -> None:
    """Describe modules, support levels, and presets."""
    payload = {
        "modules": MODULES,
        "support_levels": ["invalid", "experimental", "supported", "verified"],
        "verified_presets": list(VERIFIED_PRESETS.keys()),
        "default_spec": normalize_spec(DEFAULT_SPEC),
    }
    if format == "json":
        typer.echo(json.dumps(payload, indent=2))
        return

    lines = [
        "Modules:",
        *[f"- {name}: {description}" for name, description in MODULES.items()],
        "",
        "Verified presets:",
        *[f"- {name}" for name in VERIFIED_PRESETS],
        "",
        "Support levels:",
        "- invalid",
        "- experimental",
        "- supported",
        "- verified",
    ]
    typer.echo("\n".join(lines))


@app.command()
def validate(
    spec: Path | None = typer.Option(None, "--spec", exists=True, dir_okay=False),
    preset: str | None = typer.Option(None, "--preset"),
    set_values: list[str] = typer.Option([], "--set"),
    format: str = typer.Option("text", "--format"),
) -> None:
    """Validate a project spec."""
    result = validate_spec(_load_user_spec(spec, preset, set_values), _repo_root())
    if format == "json":
        typer.echo(json.dumps(result.to_dict(), indent=2))
    else:
        typer.echo(f"valid: {result.valid}")
        typer.echo(f"support_level: {result.support_level}")
        if result.preset_match:
            typer.echo(f"preset_match: {result.preset_match}")
        if result.warnings:
            typer.echo("warnings:")
            for warning in result.warnings:
                typer.echo(f"- {warning}")
        if result.errors:
            typer.echo("errors:")
            for error in result.errors:
                typer.echo(f"- {error}")
    raise typer.Exit(code=0 if result.valid else 1)


@app.command()
def generate(
    output: Path = typer.Option(..., "--output", file_okay=False),
    spec: Path | None = typer.Option(None, "--spec", exists=True, dir_okay=False),
    preset: str | None = typer.Option(None, "--preset"),
    set_values: list[str] = typer.Option([], "--set"),
) -> None:
    """Generate a project from the local template source."""
    user_spec = _load_user_spec(spec, preset, set_values)
    result = validate_spec(user_spec, _repo_root())
    if not result.valid:
        typer.echo(json.dumps(result.to_dict(), indent=2))
        raise typer.Exit(code=1)
    generate_project(resolve_template_src(), output, result.spec)
    spec_path = output / "project.spec.yml"
    spec_path.write_text(yaml.safe_dump(result.spec, sort_keys=False))
    typer.echo(json.dumps({"output": str(output), "support_level": result.support_level}, indent=2))


@app.command()
def update(
    project_dir: Path = typer.Option(..., "--project-dir", exists=True, file_okay=False),
    spec: Path | None = typer.Option(None, "--spec", exists=True, dir_okay=False),
    preset: str | None = typer.Option(None, "--preset"),
    set_values: list[str] = typer.Option([], "--set"),
) -> None:
    """Update an existing generated project."""
    if spec is None and (project_dir / "project.spec.yml").exists():
        spec = project_dir / "project.spec.yml"
    user_spec = _load_user_spec(spec, preset, set_values)
    result = validate_spec(user_spec, _repo_root())
    if not result.valid:
        typer.echo(json.dumps(result.to_dict(), indent=2))
        raise typer.Exit(code=1)
    update_project(project_dir, result.spec)
    (project_dir / "project.spec.yml").write_text(yaml.safe_dump(result.spec, sort_keys=False))
    typer.echo(json.dumps({"project_dir": str(project_dir), "support_level": result.support_level}, indent=2))


def main() -> None:
    app()


if __name__ == "__main__":
    main()
