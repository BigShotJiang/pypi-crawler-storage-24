"""Spec loading, normalization, validation, and support classification."""

from __future__ import annotations

import json
import re
from copy import deepcopy
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import jsonschema
import yaml

from bt_app_generator.catalog import DEFAULT_SPEC, SCHEMA_PATH, SUPPORTED_PRESETS, VERIFIED_PRESETS, deep_merge
from bt_app_generator.schema_data import SCHEMA


SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]+$")


@dataclass
class ValidationResult:
    valid: bool
    support_level: str
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    spec: dict[str, Any] = field(default_factory=dict)
    preset_match: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def load_yaml(path: Path) -> dict[str, Any]:
    data = yaml.safe_load(path.read_text()) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Expected mapping in {path}")
    return data


def load_schema(repo_root: Path) -> dict[str, Any]:
    schema_path = repo_root / SCHEMA_PATH
    if schema_path.exists():
        return json.loads(schema_path.read_text())
    return deepcopy(SCHEMA)


def normalize_spec(raw_spec: dict[str, Any]) -> dict[str, Any]:
    return deep_merge(DEFAULT_SPEC, raw_spec)


def parse_override(raw: str) -> tuple[list[str], Any]:
    if "=" not in raw:
        raise ValueError(f"Invalid override '{raw}'. Expected key=value.")
    key, raw_value = raw.split("=", 1)
    if not key.strip():
        raise ValueError(f"Invalid override '{raw}'. Empty key.")
    return key.split("."), yaml.safe_load(raw_value)


def apply_overrides(spec: dict[str, Any], overrides: list[str]) -> dict[str, Any]:
    updated = deepcopy(spec)
    for override in overrides:
        path, value = parse_override(override)
        cursor = updated
        for segment in path[:-1]:
            if segment not in cursor or not isinstance(cursor[segment], dict):
                cursor[segment] = {}
            cursor = cursor[segment]
        cursor[path[-1]] = value
    return updated


def validate_spec(spec: dict[str, Any], repo_root: Path) -> ValidationResult:
    normalized = normalize_spec(spec)
    errors: list[str] = []
    warnings: list[str] = []

    try:
        jsonschema.validate(normalized, load_schema(repo_root))
    except jsonschema.ValidationError as exc:
        errors.append(exc.message)

    project = normalized["project"]
    modules = normalized["modules"]
    features = normalized["features"]
    deployment = normalized["deployment"]
    support_policy = normalized["support_policy"]

    if not modules["api"]:
        errors.append("api is required in v1 of this template generator.")

    if not SLUG_RE.match(project["slug"]):
        errors.append("project.slug must use lowercase letters, numbers, and dashes only.")

    if not modules["api"] and any(
        [
            modules["frontend"],
            modules["agent_server"],
            modules["infra"],
            features["auth_mode"] != "none",
            features["chat"],
            features["multi_tenant"],
        ]
    ):
        errors.append("api is required when using frontend, agent_server, infra, auth, chat, or multi-tenant features.")

    if modules["agent_server"] and not modules["api"]:
        errors.append("agent_server requires api.")

    if modules["infra"] and not modules["frontend"]:
        errors.append("infra currently requires frontend.")

    if deployment["provider"] == "gcp" and not modules["infra"]:
        errors.append("deployment.provider=gcp requires infra.")

    if modules["infra"] and deployment["provider"] != "gcp":
        errors.append("infra currently only supports deployment.provider=gcp.")

    if features["chat"] and not modules["agent_server"]:
        errors.append("features.chat requires agent_server.")

    if features["auth_mode"] in {"google", "password_google"} and not modules["frontend"]:
        errors.append("Google auth presets currently require frontend.")

    if features["multi_tenant"] and not modules["api"]:
        errors.append("multi_tenant requires api.")

    preset_match = None
    for preset_name, preset in VERIFIED_PRESETS.items():
        if normalize_spec(preset) == normalized:
            preset_match = preset_name
            break

    if errors:
        return ValidationResult(False, "invalid", errors=errors, warnings=warnings, spec=normalized)

    if preset_match and preset_match in SUPPORTED_PRESETS:
        return ValidationResult(True, "verified", warnings=warnings, spec=normalized, preset_match=preset_match)

    if not support_policy["allow_experimental"]:
        errors.append("Combination is valid but classified as experimental; set support_policy.allow_experimental=true to generate it.")
        return ValidationResult(False, "invalid", errors=errors, warnings=warnings, spec=normalized)

    warnings.append("Combination is valid but experimental; it is not part of the verified preset matrix.")
    return ValidationResult(True, "experimental", warnings=warnings, spec=normalized)


def spec_to_copier_data(spec: dict[str, Any]) -> dict[str, Any]:
    return {
        "project_name": spec["project"]["name"],
        "project_slug": spec["project"]["slug"],
        "package_manager": spec["project"]["package_manager"],
        "include_api": spec["modules"]["api"],
        "include_frontend": spec["modules"]["frontend"],
        "include_agent_server": spec["modules"]["agent_server"],
        "include_infra": spec["modules"]["infra"],
        "auth_mode": spec["features"]["auth_mode"],
        "multi_tenant": spec["features"]["multi_tenant"],
        "feature_chat_enabled": spec["features"]["chat"],
        "deployment_provider": spec["deployment"]["provider"],
        "allow_experimental": spec["support_policy"]["allow_experimental"],
    }
