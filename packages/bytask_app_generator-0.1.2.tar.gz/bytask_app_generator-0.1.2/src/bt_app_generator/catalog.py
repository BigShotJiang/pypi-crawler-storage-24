"""Static catalog and presets for the generator."""

from __future__ import annotations

from copy import deepcopy

DEFAULT_SPEC = {
    "template_version": "1",
    "project": {
        "name": "My App",
        "slug": "my-app",
        "package_manager": "npm",
    },
    "modules": {
        "api": True,
        "frontend": True,
        "agent_server": False,
        "infra": False,
    },
    "features": {
        "auth_mode": "password",
        "multi_tenant": False,
        "chat": False,
    },
    "deployment": {
        "provider": "none",
    },
    "support_policy": {
        "allow_experimental": True,
    },
}

SCHEMA_PATH = "schema/project-spec.schema.json"

MODULES = {
    "api": "FastAPI API backend",
    "frontend": "Next.js frontend",
    "agent_server": "FastAPI agent server",
    "infra": "Terraform and deploy workflows",
}

SUPPORT_LEVELS = ["invalid", "experimental", "supported", "verified"]

VERIFIED_PRESETS = {
    "api-minimal": {
        "project": {"name": "API Minimal", "slug": "api-minimal"},
        "modules": {"api": True, "frontend": False, "agent_server": False, "infra": False},
        "features": {"auth_mode": "password", "multi_tenant": False, "chat": False},
        "deployment": {"provider": "none"},
    },
    "web-api": {
        "project": {"name": "Web API", "slug": "web-api"},
        "modules": {"api": True, "frontend": True, "agent_server": False, "infra": False},
        "features": {"auth_mode": "password", "multi_tenant": False, "chat": False},
        "deployment": {"provider": "none"},
    },
    "web-api-google-auth": {
        "project": {"name": "Web API Google", "slug": "web-api-google"},
        "modules": {"api": True, "frontend": True, "agent_server": False, "infra": False},
        "features": {"auth_mode": "password_google", "multi_tenant": False, "chat": False},
        "deployment": {"provider": "none"},
    },
    "agent-chat": {
        "project": {"name": "Agent Chat", "slug": "agent-chat"},
        "modules": {"api": True, "frontend": True, "agent_server": True, "infra": False},
        "features": {"auth_mode": "password", "multi_tenant": False, "chat": True},
        "deployment": {"provider": "none"},
    },
    "web-api-infra": {
        "project": {"name": "Web API Infra", "slug": "web-api-infra"},
        "modules": {"api": True, "frontend": True, "agent_server": False, "infra": True},
        "features": {"auth_mode": "password", "multi_tenant": False, "chat": False},
        "deployment": {"provider": "gcp"},
    },
    "full-stack": {
        "project": {"name": "Full Stack", "slug": "full-stack"},
        "modules": {"api": True, "frontend": True, "agent_server": True, "infra": True},
        "features": {"auth_mode": "password_google", "multi_tenant": True, "chat": True},
        "deployment": {"provider": "gcp"},
    },
}

SUPPORTED_PRESETS = {
    "api-minimal",
    "web-api",
    "web-api-google-auth",
    "agent-chat",
    "web-api-infra",
    "full-stack",
}


def deep_merge(base: dict, update: dict) -> dict:
    """Recursively merge dictionaries."""
    merged = deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def preset_spec(name: str) -> dict:
    """Return a fully merged preset spec."""
    if name not in VERIFIED_PRESETS:
        raise KeyError(f"Unknown preset: {name}")
    return deep_merge(DEFAULT_SPEC, VERIFIED_PRESETS[name])
