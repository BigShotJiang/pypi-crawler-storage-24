"""Copier integration helpers."""

from __future__ import annotations

from pathlib import Path

from copier import run_copy, run_update
import yaml

from bt_app_generator.spec import spec_to_copier_data
from bt_app_generator.transforms import apply_post_render_transforms


def _persist_answers_file(project_dir: Path, spec: dict, worker) -> None:
    answers = {
        "_src_path": worker.answers.combined.get("_src_path"),
        "_commit": worker.answers.combined.get("_commit"),
        **spec_to_copier_data(spec),
    }
    (project_dir / ".copier-answers.yml").write_text(yaml.safe_dump(answers, sort_keys=False))


def generate_project(template_src: str, output_dir: Path, spec: dict, unsafe: bool = True) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    worker = run_copy(
        src_path=template_src,
        dst_path=output_dir,
        data=spec_to_copier_data(spec),
        answers_file=".copier-answers.yml",
        defaults=True,
        overwrite=True,
        unsafe=unsafe,
    )
    _persist_answers_file(output_dir, spec, worker)
    apply_post_render_transforms(output_dir, spec)


def update_project(project_dir: Path, spec: dict, unsafe: bool = True) -> None:
    worker = run_update(
        dst_path=project_dir,
        data=spec_to_copier_data(spec),
        answers_file=".copier-answers.yml",
        defaults=True,
        overwrite=True,
        unsafe=unsafe,
    )
    _persist_answers_file(project_dir, spec, worker)
    apply_post_render_transforms(project_dir, spec)
