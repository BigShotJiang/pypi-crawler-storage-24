"""Template source resolution for local development and installed CLI usage."""

from __future__ import annotations

import os
from pathlib import Path


DEFAULT_TEMPLATE_GIT_URL = "git@github.com:ByTaskApps/bt-app-template.git"


def checkout_root() -> Path | None:
    root = Path(__file__).resolve().parents[2]
    if (root / "copier.yml").exists() and (root / "template").exists():
        return root
    return None


def resolve_template_src() -> str:
    if os.getenv("BT_APP_TEMPLATE_SRC"):
        return os.environ["BT_APP_TEMPLATE_SRC"]
    root = checkout_root()
    if root is not None:
        return str(root)
    return os.getenv("BT_APP_TEMPLATE_GIT_URL", DEFAULT_TEMPLATE_GIT_URL)
