"""Embedded JSON schema used at runtime when the repo checkout is not available."""

SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Bytask App Generator Project Spec",
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "template_version": {"type": "string"},
        "project": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "name": {"type": "string", "minLength": 1},
                "slug": {"type": "string", "minLength": 1},
                "package_manager": {"type": "string", "enum": ["npm"]},
            },
        },
        "modules": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "api": {"type": "boolean"},
                "frontend": {"type": "boolean"},
                "agent_server": {"type": "boolean"},
                "infra": {"type": "boolean"},
            },
        },
        "features": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "auth_mode": {"type": "string", "enum": ["none", "password", "google", "password_google"]},
                "multi_tenant": {"type": "boolean"},
                "chat": {"type": "boolean"},
            },
        },
        "deployment": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "provider": {"type": "string", "enum": ["none", "gcp"]},
            },
        },
        "support_policy": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "allow_experimental": {"type": "boolean"},
            },
        },
    },
}
