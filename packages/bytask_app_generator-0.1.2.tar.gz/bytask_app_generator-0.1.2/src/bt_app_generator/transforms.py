"""Post-render transforms that prune modules and align generated files."""

from __future__ import annotations

import shutil
from pathlib import Path


def _remove_if_exists(path: Path) -> None:
    if path.is_dir():
        shutil.rmtree(path)
    elif path.exists():
        path.unlink()


def apply_post_render_transforms(project_dir: Path, spec: dict) -> None:
    modules = spec["modules"]

    if not modules["frontend"]:
        _remove_if_exists(project_dir / "frontend")

    if not modules["agent_server"]:
        _remove_if_exists(project_dir / "backend" / "agent_server")

    if not modules["infra"]:
        _remove_if_exists(project_dir / "infra")
        _remove_if_exists(project_dir / ".github" / "workflows" / "deploy-staging.yml")
        _remove_if_exists(project_dir / ".github" / "workflows" / "deploy-production.yml")

