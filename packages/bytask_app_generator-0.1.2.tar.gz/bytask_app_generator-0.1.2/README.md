# bytask-app-generator

`bytask-app-generator` is a Python CLI that wraps `Copier` to generate and update
Bytask application repositories from this repo's private template source.

## What lives in this repo

- `template/`: the generated application's source tree
- `src/bt_app_generator/`: the installed CLI package
- `schema/`: machine-readable spec contract
- `presets/`: verified example configurations
- `tests/`: unit, integration, and end-to-end coverage

## Installation

The intended release channel is public PyPI. Typical installation patterns:

```bash
pip install bytask-app-generator
```

```bash
pipx install bytask-app-generator
```

```bash
uv tool install bytask-app-generator
```

`Copier` reads the private template from Git, so local/CI environments also need
Git credentials for the template repository. Installing the CLI from PyPI does
not grant template access by itself.

## CLI

```bash
bytask-app-generator describe --format json
bytask-app-generator schema
bytask-app-generator validate --spec presets/full-stack.yml
bytask-app-generator generate --spec presets/full-stack.yml --output ../generated/full-stack
bytask-app-generator update --spec project.spec.yml --project-dir ../generated/full-stack
```

## Development

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -e '.[dev]'
pytest
```

## Release

Releases build a wheel and sdist, run pre-publish E2E from the local artifact,
publish to PyPI, and then rerun installation/generation tests from PyPI before
the release is considered valid.
