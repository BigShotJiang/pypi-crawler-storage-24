import json
import os
import subprocess
import sys
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]


def _run(*args: str) -> subprocess.CompletedProcess[str]:
    env = dict(os.environ)
    env.update(**{"PYTHONPATH": str(ROOT / "src")})
    return subprocess.run(
        [sys.executable, "-m", "bt_app_generator.cli", *args],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )


def test_describe_json():
    result = _run("describe", "--format", "json")
    assert result.returncode == 0
    payload = json.loads(result.stdout)
    assert "modules" in payload
    assert "verified_presets" in payload


def test_generate_preset(tmp_path: Path):
    output = tmp_path / "generated"
    result = _run("generate", "--preset", "api-minimal", "--output", str(output))
    assert result.returncode == 0, result.stdout + result.stderr
    assert (output / "backend" / "api" / "app" / "main.py").exists()
    assert not (output / "frontend").exists()
    spec = yaml.safe_load((output / "project.spec.yml").read_text())
    assert spec["modules"]["frontend"] is False
