import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _run(*args: str, cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    env = dict(os.environ)
    env.update(**{"PYTHONPATH": str(ROOT / "src")})
    return subprocess.run(
        [sys.executable, "-m", "bt_app_generator.cli", *args],
        cwd=cwd or ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )


def _create_template_snapshot() -> str:
    snapshot_root = Path(tempfile.mkdtemp()) / "template-src"
    shutil.copytree(ROOT, snapshot_root, dirs_exist_ok=True, ignore=shutil.ignore_patterns(".git", ".venv", ".pytest_cache", "__pycache__", ".e2e"))
    subprocess.run(["git", "init"], cwd=snapshot_root, check=True)
    subprocess.run(["git", "config", "user.email", "ci@example.com"], cwd=snapshot_root, check=True)
    subprocess.run(["git", "config", "user.name", "CI"], cwd=snapshot_root, check=True)
    subprocess.run(["git", "add", "."], cwd=snapshot_root, check=True)
    subprocess.run(["git", "commit", "-m", "template snapshot"], cwd=snapshot_root, check=True)
    return str(snapshot_root)


def test_update_existing_project(tmp_path: Path):
    template_src = _create_template_snapshot()
    os.environ["BT_APP_TEMPLATE_SRC"] = template_src
    output = tmp_path / "project"
    try:
        generated = _run("generate", "--preset", "web-api", "--output", str(output))
        assert generated.returncode == 0, generated.stdout + generated.stderr

        subprocess.run(["git", "init"], cwd=output, check=True)
        subprocess.run(["git", "config", "user.email", "ci@example.com"], cwd=output, check=True)
        subprocess.run(["git", "config", "user.name", "CI"], cwd=output, check=True)
        subprocess.run(["git", "add", "."], cwd=output, check=True)
        subprocess.run(["git", "commit", "-m", "initial"], cwd=output, check=True)

        updated = _run(
            "update",
            "--project-dir",
            str(output),
            "--set",
            "features.chat=false",
        )
        assert updated.returncode == 0, updated.stdout + updated.stderr
    finally:
        os.environ.pop("BT_APP_TEMPLATE_SRC", None)
