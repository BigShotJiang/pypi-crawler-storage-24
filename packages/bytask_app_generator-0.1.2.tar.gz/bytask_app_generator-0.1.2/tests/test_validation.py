from pathlib import Path

from bt_app_generator.spec import apply_overrides, validate_spec


ROOT = Path(__file__).resolve().parents[1]


def test_verified_preset_is_verified():
    result = validate_spec(
        {
            "project": {"name": "Web API", "slug": "web-api"},
            "modules": {"api": True, "frontend": True, "agent_server": False, "infra": False},
            "features": {"auth_mode": "password", "multi_tenant": False, "chat": False},
            "deployment": {"provider": "none"},
        },
        ROOT,
    )
    assert result.valid is True
    assert result.support_level == "verified"


def test_invalid_requires_api():
    result = validate_spec(
        {
            "project": {"name": "Broken", "slug": "broken"},
            "modules": {"api": False, "frontend": True, "agent_server": False, "infra": False},
            "features": {"auth_mode": "password", "multi_tenant": False, "chat": False},
            "deployment": {"provider": "none"},
        },
        ROOT,
    )
    assert result.valid is False
    assert result.support_level == "invalid"
    assert any("api is required" in error for error in result.errors)


def test_overrides_are_applied():
    updated = apply_overrides(
        {"project": {"slug": "base"}},
        ["project.slug=custom-slug", "modules.frontend=false", "features.chat=true"],
    )
    assert updated["project"]["slug"] == "custom-slug"
    assert updated["modules"]["frontend"] is False
    assert updated["features"]["chat"] is True
