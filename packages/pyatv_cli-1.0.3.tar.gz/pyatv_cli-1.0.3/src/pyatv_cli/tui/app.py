"""Apple TV TUI — Full-screen interactive remote control."""

from __future__ import annotations

import asyncio
from typing import Any

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, Grid
from textual.reactive import reactive
from textual.widgets import (
    Button, Footer, Header, Label, ListItem, ListView,
    ProgressBar, Static, RichLog,
)
from textual.message import Message
from textual import work
from textual.worker import Worker, WorkerState

from rich.text import Text

from pyatv_cli.config import load_config, get_device, list_devices
from pyatv_cli.connection import connect_device, find_device


# ─── Helper ────────────────────────────────────────────────────────

def fmt_time(seconds: float | int | None) -> str:
    if seconds is None:
        return "—:——"
    s = int(seconds)
    m, s = divmod(s, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


# ─── Now Playing Widget ───────────────────────────────────────────

class NowPlaying(Static):
    """Displays current media info."""

    DEFAULT_CSS = """
    NowPlaying {
        height: auto;
        padding: 1 2;
        background: $surface;
        border: round $primary;
    }
    NowPlaying .np-label { width: 100%; }
    NowPlaying #np-state { color: $text-muted; }
    NowPlaying #np-progress-row { height: 1; width: 100%; }
    NowPlaying #np-bar { width: 1fr; }
    NowPlaying #np-time { width: auto; min-width: 16; text-align: right; }
    """

    title: reactive[str] = reactive("Nothing Playing")
    artist: reactive[str] = reactive("—")
    album: reactive[str] = reactive("—")
    state: reactive[str] = reactive("Idle")
    position: reactive[float] = reactive(0.0)
    duration: reactive[float] = reactive(0.0)
    media_type: reactive[str] = reactive("")
    app_name: reactive[str] = reactive("")

    def compose(self) -> ComposeResult:
        yield Label("🎵 Nothing Playing", id="np-title", classes="np-label")
        yield Label("🎤 —", id="np-artist", classes="np-label")
        yield Label("💿 —", id="np-album", classes="np-label")
        yield Label("📱 —", id="np-app", classes="np-label")
        yield Label("⏹️  Idle", id="np-state", classes="np-label")
        with Horizontal(id="np-progress-row"):
            yield ProgressBar(total=100, show_eta=False, id="np-bar")
            yield Label("—:—— / —:——", id="np-time")

    def watch_title(self, value: str) -> None:
        try:
            self.query_one("#np-title", Label).update(f"🎵 [bold]{value}[/bold]")
        except Exception:
            pass

    def watch_artist(self, value: str) -> None:
        try:
            self.query_one("#np-artist", Label).update(f"🎤 {value}")
        except Exception:
            pass

    def watch_album(self, value: str) -> None:
        try:
            self.query_one("#np-album", Label).update(f"💿 [dim]{value}[/dim]")
        except Exception:
            pass

    def watch_app_name(self, value: str) -> None:
        try:
            self.query_one("#np-app", Label).update(f"📱 {value}" if value else "📱 —")
        except Exception:
            pass

    def watch_state(self, value: str) -> None:
        icons = {"Playing": "▶️ ", "Paused": "⏸️ ", "Loading": "⏳", "Idle": "⏹️ ", "Stopped": "⏹️ ", "Seeking": "⏩"}
        icon = icons.get(value, "❓")
        try:
            self.query_one("#np-state", Label).update(f"{icon} {value}")
        except Exception:
            pass

    def watch_position(self, value: float) -> None:
        try:
            dur = self.duration or 1
            pct = min((value / dur) * 100, 100) if dur > 0 else 0
            self.query_one("#np-bar", ProgressBar).update(progress=pct)
            self.query_one("#np-time", Label).update(
                f"{fmt_time(value)} / {fmt_time(self.duration)}"
            )
        except Exception:
            pass


# ─── Remote D-Pad Widget ──────────────────────────────────────────

class RemotePad(Static):
    """Navigation D-pad and playback controls."""

    DEFAULT_CSS = """
    RemotePad {
        height: auto;
        padding: 1 2;
        background: $surface;
        border: round $accent;
    }
    RemotePad #dpad {
        grid-size: 3 3;
        grid-gutter: 1;
        height: auto;
        width: auto;
    }
    RemotePad #dpad Button {
        min-width: 8;
        height: 3;
    }
    RemotePad #playback {
        height: auto;
        margin-top: 1;
    }
    RemotePad #playback Button {
        min-width: 6;
        margin: 0 1;
    }
    RemotePad #extra {
        height: auto;
        margin-top: 1;
    }
    RemotePad #extra Button {
        min-width: 8;
        margin: 0 1;
    }
    """

    class RemoteCommand(Message):
        """Remote command pressed."""
        def __init__(self, command: str) -> None:
            self.command = command
            super().__init__()

    def compose(self) -> ComposeResult:
        yield Label("[bold]🎮 Remote Control[/bold]")
        with Grid(id="dpad"):
            yield Static("")
            yield Button("▲", id="btn-up", variant="primary")
            yield Static("")
            yield Button("◀", id="btn-left", variant="primary")
            yield Button("OK", id="btn-select", variant="success")
            yield Button("▶", id="btn-right", variant="primary")
            yield Static("")
            yield Button("▼", id="btn-down", variant="primary")
            yield Static("")
        with Horizontal(id="playback"):
            yield Button("⏮", id="btn-prev", variant="default")
            yield Button("⏯", id="btn-play-pause", variant="warning")
            yield Button("⏭", id="btn-next", variant="default")
            yield Button("⏹", id="btn-stop", variant="error")
        with Horizontal(id="extra"):
            yield Button("🏠", id="btn-home", variant="default")
            yield Button("☰", id="btn-menu", variant="default")
            yield Button("⬆", id="btn-top-menu", variant="default")

    BUTTON_MAP = {
        "btn-up": "up", "btn-down": "down", "btn-left": "left", "btn-right": "right",
        "btn-select": "select", "btn-play-pause": "play_pause",
        "btn-prev": "previous", "btn-next": "next", "btn-stop": "stop",
        "btn-home": "home", "btn-menu": "menu", "btn-top-menu": "top_menu",
    }

    def on_button_pressed(self, event: Button.Pressed) -> None:
        cmd = self.BUTTON_MAP.get(event.button.id, "")
        if cmd:
            self.post_message(self.RemoteCommand(cmd))


# ─── Volume Widget ─────────────────────────────────────────────────

class VolumeControl(Static):
    """Volume display and control."""

    DEFAULT_CSS = """
    VolumeControl {
        height: auto;
        padding: 1 2;
        background: $surface;
        border: round $warning;
    }
    VolumeControl #vol-row { height: 1; width: 100%; }
    VolumeControl #vol-bar { width: 1fr; }
    VolumeControl #vol-label { width: auto; min-width: 6; text-align: right; }
    VolumeControl #vol-buttons { height: auto; margin-top: 1; }
    VolumeControl #vol-buttons Button { min-width: 6; margin: 0 1; }
    """

    volume: reactive[float] = reactive(0.0)

    class VolumeCommand(Message):
        def __init__(self, action: str) -> None:
            self.action = action
            super().__init__()

    def compose(self) -> ComposeResult:
        yield Label("[bold]🔊 Volume[/bold]")
        with Horizontal(id="vol-row"):
            yield ProgressBar(total=100, show_eta=False, id="vol-bar")
            yield Label("0%", id="vol-label")
        with Horizontal(id="vol-buttons"):
            yield Button("🔉 −", id="vol-down", variant="default")
            yield Button("🔊 +", id="vol-up", variant="default")
            yield Button("🔇", id="vol-mute", variant="error")

    def watch_volume(self, value: float) -> None:
        try:
            self.query_one("#vol-bar", ProgressBar).update(progress=value)
            self.query_one("#vol-label", Label).update(f"{int(value)}%")
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        actions = {"vol-down": "down", "vol-up": "up", "vol-mute": "mute"}
        action = actions.get(event.button.id)
        if action:
            self.post_message(self.VolumeCommand(action))


# ─── Apps Widget ───────────────────────────────────────────────────

class AppsPanel(Static):
    """List of installed apps."""

    DEFAULT_CSS = """
    AppsPanel {
        height: 100%;
        padding: 1 2;
        background: $surface;
        border: round $success;
    }
    AppsPanel ListView {
        height: 1fr;
        min-height: 5;
    }
    """

    class LaunchApp(Message):
        def __init__(self, bundle_id: str) -> None:
            self.bundle_id = bundle_id
            super().__init__()

    def compose(self) -> ComposeResult:
        yield Label("[bold]📱 Apps[/bold]")
        yield ListView(id="apps-list")

    def set_apps(self, apps: list) -> None:
        lv = self.query_one("#apps-list", ListView)
        lv.clear()
        for app in apps:
            item = ListItem(Label(f"  {app.name}"), id=f"app-{app.identifier}")
            item._app_id = app.identifier
            lv.append(item)

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        bundle_id = getattr(event.item, "_app_id", None)
        if bundle_id:
            self.post_message(self.LaunchApp(bundle_id))


# ─── System Info Widget ───────────────────────────────────────────

class SystemInfo(Static):
    """Device information panel."""

    DEFAULT_CSS = """
    SystemInfo {
        height: auto;
        padding: 1 2;
        background: $surface;
        border: round $primary-background;
    }
    """

    def compose(self) -> ComposeResult:
        yield Label("[bold]🖥️  System[/bold]")
        yield Label("Connecting...", id="sys-content")

    def set_info(self, info: dict) -> None:
        lines = []
        for k, v in info.items():
            lines.append(f"[bold]{k}:[/] {v}")
        try:
            self.query_one("#sys-content", Label).update("\n".join(lines))
        except Exception:
            pass


# ─── Log Widget ────────────────────────────────────────────────────

class ActivityLog(RichLog):
    """Activity log showing recent commands."""

    DEFAULT_CSS = """
    ActivityLog {
        height: 100%;
        min-height: 4;
        background: $surface;
        border: round $primary-darken-2;
        padding: 0 1;
    }
    """


# ─── Main App ─────────────────────────────────────────────────────

class AppleTVApp(App):
    """🍎 Apple TV Remote Control TUI"""

    TITLE = "Apple TV Remote"
    SUB_TITLE = "pyatv-cli"

    CSS = """
    Screen {
        layout: grid;
        grid-size: 2 3;
        grid-columns: 1fr 1fr;
        grid-rows: auto 1fr auto;
        grid-gutter: 1;
        padding: 1;
    }

    #left-top { column-span: 1; row-span: 1; }
    #right-top { column-span: 1; row-span: 1; }
    #left-mid { column-span: 1; row-span: 1; height: 100%; }
    #right-mid { column-span: 1; row-span: 1; }
    #bottom { column-span: 2; row-span: 1; height: auto; max-height: 8; }

    #connection-status {
        dock: top;
        height: 1;
        background: $accent;
        color: $text;
        text-align: center;
        padding: 0 2;
    }
    #connection-status.disconnected {
        background: $error;
    }
    #connection-status.connected {
        background: $success;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit", priority=True),
        Binding("d", "toggle_dark", "Theme"),
        Binding("up", "remote('up')", "↑", show=False),
        Binding("down", "remote('down')", "↓", show=False),
        Binding("left", "remote('left')", "←", show=False),
        Binding("right", "remote('right')", "→", show=False),
        Binding("enter", "remote('select')", "Select", show=False),
        Binding("space", "remote('play_pause')", "⏯ Play/Pause"),
        Binding("escape", "remote('menu')", "Menu"),
        Binding("m", "remote('menu')", "Menu", show=False),
        Binding("h", "remote('home')", "Home"),
        Binding("n", "remote('next')", "Next", show=False),
        Binding("p", "remote('previous')", "Prev", show=False),
        Binding("bracketright", "volume_action('up')", "Vol+"),
        Binding("bracketleft", "volume_action('down')", "Vol−"),
    ]

    atv: Any = None
    connected: reactive[bool] = reactive(False)
    device_name: reactive[str] = reactive("Not Connected")

    def __init__(self, device_id: str | None = None, host: str | None = None):
        super().__init__()
        self._device_id = device_id
        self._host = host
        self._poll_timer = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Label("🔌 Connecting...", id="connection-status")
        with Container(id="left-top"):
            yield NowPlaying()
        with Container(id="right-top"):
            yield RemotePad()
        with Container(id="left-mid"):
            yield AppsPanel()
        with Container(id="right-mid"):
            yield VolumeControl()
            yield SystemInfo()
        with Container(id="bottom"):
            yield ActivityLog(id="log", markup=True)
        yield Footer()

    def on_mount(self) -> None:
        self._log("🍎 Apple TV TUI starting...")
        self.connect_to_device()

    @work(exclusive=True)
    async def connect_to_device(self) -> None:
        """Connect to the Apple TV in a background worker."""
        self._log("🔍 Scanning for device...")
        try:
            self.atv = await connect_device(self._device_id, self._host)
            self.connected = True

            # Get device name
            config = load_config()
            dev = get_device(config, self._device_id)
            self.device_name = dev.get("name", "Apple TV") if dev else "Apple TV"

            self._log(f"✅ Connected to [bold]{self.device_name}[/bold]")

            # Load initial state
            await self._update_now_playing()
            await self._update_volume()
            await self._load_system_info()
            await self._load_apps()

            # Start polling
            self._poll_timer = self.set_interval(3.0, self._poll_status)

        except Exception as e:
            self._log(f"❌ Connection failed: {e}")
            self.connected = False

    def watch_connected(self, value: bool) -> None:
        try:
            status = self.query_one("#connection-status", Label)
            if value:
                status.update(f"🟢 Connected to {self.device_name}")
                status.remove_class("disconnected")
                status.add_class("connected")
            else:
                status.update("🔴 Disconnected")
                status.remove_class("connected")
                status.add_class("disconnected")
        except Exception:
            pass

    # ─── Polling ────────────────────────────────────────────────

    async def _poll_status(self) -> None:
        if not self.atv or not self.connected:
            return
        try:
            await self._update_now_playing()
            await self._update_volume()
        except Exception:
            self.connected = False
            self._log("⚠️  Lost connection, attempting reconnect...")
            self.connect_to_device()

    async def _update_now_playing(self) -> None:
        if not self.atv:
            return
        try:
            playing = await self.atv.metadata.playing()
            np = self.query_one(NowPlaying)
            np.title = playing.title or "Nothing Playing"
            np.artist = playing.artist or "—"
            np.album = playing.album or "—"

            state_name = str(playing.device_state)
            if "." in state_name:
                state_name = state_name.split(".")[-1]
            np.state = state_name

            np.position = playing.position or 0
            np.duration = playing.total_time or 0
            np.media_type = str(playing.media_type or "")

            # App info if available
            if hasattr(playing, "app") and playing.app:
                np.app_name = f"{playing.app.name} ({playing.app.identifier})"
            else:
                np.app_name = ""
        except Exception:
            pass

    async def _update_volume(self) -> None:
        if not self.atv:
            return
        try:
            vol = self.atv.audio.volume
            self.query_one(VolumeControl).volume = vol or 0
        except Exception:
            pass

    async def _load_system_info(self) -> None:
        if not self.atv:
            return
        try:
            di = self.atv.device_info
            config = load_config()
            dev = get_device(config, self._device_id)
            info = {
                "Name": dev.get("name", "Unknown") if dev else "Unknown",
                "Model": getattr(di, "model_str", None) or str(di.model),
                "OS": f"{getattr(di.operating_system, 'name', '?')} {di.version or ''}",
                "Build": di.build_number or "—",
                "MAC": di.mac or "—",
                "Address": dev.get("address", "—") if dev else "—",
            }
            self.query_one(SystemInfo).set_info(info)
        except Exception:
            pass

    async def _load_apps(self) -> None:
        if not self.atv:
            return
        try:
            app_list = await self.atv.apps.app_list()
            self.query_one(AppsPanel).set_apps(app_list)
            self._log(f"📱 Loaded {len(app_list)} apps")
        except Exception:
            self._log("📱 Apps list not available (pair more protocols)")

    # ─── Remote Commands ────────────────────────────────────────

    async def action_remote(self, command: str) -> None:
        """Execute a remote control command."""
        if not self.atv:
            self._log("⚠️  Not connected")
            return
        try:
            method = getattr(self.atv.remote_control, command, None)
            if method:
                await method()
                self._log(f"🎮 {command.replace('_', ' ').title()}")
            else:
                self._log(f"❌ Unknown command: {command}")
        except Exception as e:
            self._log(f"❌ {command}: {e}")

    async def action_volume_action(self, action: str) -> None:
        """Handle volume commands."""
        if not self.atv:
            return
        try:
            if action == "up":
                await self.atv.audio.volume_up()
                self._log("🔊 Volume up")
            elif action == "down":
                await self.atv.audio.volume_down()
                self._log("🔉 Volume down")
            elif action == "mute":
                await self.atv.audio.set_volume(0)
                self._log("🔇 Muted")
            await self._update_volume()
        except Exception as e:
            self._log(f"❌ Volume: {e}")

    # ─── Message Handlers ──────────────────────────────────────

    async def on_remote_pad_remote_command(self, event: RemotePad.RemoteCommand) -> None:
        await self.action_remote(event.command)

    async def on_volume_control_volume_command(self, event: VolumeControl.VolumeCommand) -> None:
        await self.action_volume_action(event.action)

    async def on_apps_panel_launch_app(self, event: AppsPanel.LaunchApp) -> None:
        if not self.atv:
            return
        try:
            await self.atv.apps.launch_app(event.bundle_id)
            self._log(f"🚀 Launched {event.bundle_id}")
        except Exception as e:
            self._log(f"❌ Launch failed: {e}")

    # ─── Logging ───────────────────────────────────────────────

    def _log(self, message: str) -> None:
        try:
            self.query_one("#log", RichLog).write(message)
        except Exception:
            pass

    # ─── Cleanup ───────────────────────────────────────────────

    def on_unmount(self) -> None:
        if self._poll_timer:
            self._poll_timer.stop()
        if self.atv:
            self.atv.close()


def run_tui(device: str | None = None, host: str | None = None) -> None:
    """Entry point to run the TUI."""
    app = AppleTVApp(device_id=device, host=host)
    app.run()
