"""pyatv-cli — Comprehensive Apple TV CLI remote control."""
__version__ = "1.0.3"
