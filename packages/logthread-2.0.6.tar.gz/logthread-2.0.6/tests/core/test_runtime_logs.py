from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import httpx
import pytest

from logthread.core.graph.graph import KnowledgeGraph
from logthread.core.graph.model import GraphNode, NodeLabel
from logthread.core.intelligence.runtime_logs import (
    RuntimeConnector,
    _fetch_loki_logs,
    list_runtime_connectors,
    query_runtime_logs,
    save_runtime_connector,
)
from logthread.core.storage.paths import get_project_dir


@pytest.fixture(autouse=True)
def fake_secret_store(monkeypatch: pytest.MonkeyPatch):
    store: dict[tuple[str, str, str], dict] = {}

    def _store(repo_path: Path, namespace: str, item_id: str, payload: dict) -> None:
        store[(str(repo_path.resolve()), namespace, item_id)] = dict(payload)

    def _load(repo_path: Path, namespace: str, item_id: str) -> dict | None:
        payload = store.get((str(repo_path.resolve()), namespace, item_id))
        return dict(payload) if payload is not None else None

    def _delete(repo_path: Path, namespace: str, item_id: str) -> None:
        store.pop((str(repo_path.resolve()), namespace, item_id), None)

    monkeypatch.setattr("logthread.core.intelligence.runtime_logs.store_secret", _store)
    monkeypatch.setattr("logthread.core.intelligence.runtime_logs.load_secret", _load)
    monkeypatch.setattr("logthread.core.intelligence.runtime_logs.delete_secret", _delete)
    return store


def test_query_runtime_logs_clusters_and_correlates(monkeypatch, tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()

    connector = save_runtime_connector(
        repo_path,
        connector_id=None,
        name="Prod Loki",
        provider="loki",
        base_url="https://loki.example.com",
        credentials={"bearer_token": "secret-token"},
        default_source="prod",
    )

    graph = KnowledgeGraph()
    graph.add_node(
        GraphNode(
            id="api_endpoint:src/api/orders.ts:GET:/orders",
            label=NodeLabel.API_ENDPOINT,
            name="GET:/orders",
            file_path="src/api/orders.ts",
            properties={"path": "/orders"},
        )
    )
    graph.add_node(
        GraphNode(
            id="file:src/api/orders.ts:",
            label=NodeLabel.FILE,
            name="orders.ts",
            file_path="src/api/orders.ts",
        )
    )
    graph.add_node(
        GraphNode(
            id="db_table:db/schema.sql:orders",
            label=NodeLabel.DB_TABLE,
            name="orders",
            file_path="db/schema.sql",
        )
    )

    monkeypatch.setattr(
        "logthread.core.intelligence.runtime_logs._fetch_provider_logs",
        lambda *_args, **_kwargs: [
            {
                "timestamp": "1711711711000000000",
                "line": 'level=error msg="Order lookup failed for user 42" trace_id=req-123 route=/orders code.filepath=src/api/orders.ts sql="select * from orders"',
                "labels": {"service": "orders-api"},
            },
            {
                "timestamp": "1711711712000000000",
                "line": 'level=error msg="Order lookup failed for user 99" trace_id=req-123 route=/orders code.filepath=src/api/orders.ts sql="select * from orders"',
                "labels": {"service": "orders-api"},
            },
        ],
    )

    packet = query_runtime_logs(
        repo_path,
        graph,
        connector_id=connector["id"],
        query='{service="orders-api"} |= "error"',
        hours=2,
        limit=50,
    )

    assert packet["stats"]["events"] == 2
    assert packet["stats"]["patterns"] == 1
    assert packet["patterns"][0]["count"] == 2
    assert packet["patterns"][0]["related"]["apis"][0]["name"] == "GET:/orders"
    assert packet["patterns"][0]["related"]["tables"][0]["name"] == "orders"
    assert packet["patterns"][0]["related"]["files"][0]["filePath"] == "src/api/orders.ts"
    assert packet["sequences"][0]["correlationId"] == "req-123"
    assert packet["sequences"][0]["linkageMode"] == "explicit"
    assert packet["sequences"][0]["events"][0]["linkReason"]
    assert packet["semanticCoverage"]["traceIdRate"] == 1.0
    assert packet["schemaGroups"][0]["structuredKind"] == "logfmt"
    assert packet["instrumentationFindings"]


def test_query_runtime_logs_parses_traceparent_and_infers_journeys(monkeypatch, tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()

    connector = save_runtime_connector(
        repo_path,
        connector_id=None,
        name="Prod Loki",
        provider="loki",
        base_url="https://loki.example.com",
        credentials={"bearer_token": "secret-token"},
        default_source="prod",
    )

    graph = KnowledgeGraph()
    graph.add_node(
        GraphNode(
            id="api_endpoint:src/api/checkout.ts:POST:/checkout",
            label=NodeLabel.API_ENDPOINT,
            name="POST:/checkout",
            file_path="src/api/checkout.ts",
            properties={"path": "/checkout"},
        )
    )

    monkeypatch.setattr(
        "logthread.core.intelligence.runtime_logs._fetch_provider_logs",
        lambda *_args, **_kwargs: [
            {
                "timestamp": "1711711711000000000",
                "line": 'level=error msg="checkout failed for order 41" traceparent=00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01 route=/checkout service=payments-api',
                "labels": {"service": "payments-api"},
            },
            {
                "timestamp": "1711711712000000000",
                "line": 'level=error msg="payment retry failed for order 42" route=/checkout logger=payments.worker',
                "labels": {"service": "payments-api"},
            },
            {
                "timestamp": "1711711713000000000",
                "line": 'level=error msg="payment retry failed for order 43" route=/checkout logger=payments.worker',
                "labels": {"service": "payments-api"},
            },
        ],
    )

    packet = query_runtime_logs(
        repo_path,
        graph,
        connector_id=connector["id"],
        query='{service="payments-api"} |= "error"',
        hours=2,
        limit=50,
    )

    explicit = next(item for item in packet["sequences"] if item["linkageMode"] == "explicit")
    inferred = next(item for item in packet["sequences"] if item["linkageMode"] == "derived")
    traced_event = next(event for event in packet["events"] if event["traceId"])

    assert explicit["correlationType"] == "trace"
    assert explicit["correlationId"] == "4bf92f3577b34da6a3ce929d0e0e4736"
    assert traced_event["traceId"] == "4bf92f3577b34da6a3ce929d0e0e4736"
    assert inferred["correlationType"] == "inferred"
    assert inferred["count"] == 2
    assert "30-second window" in inferred["linkReason"]
    assert packet["stats"]["inferredSequences"] >= 1


def test_list_runtime_connectors_masks_credentials(tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    save_runtime_connector(
        repo_path,
        connector_id=None,
        name="Datadog Prod",
        provider="datadog",
        base_url="https://api.datadoghq.com",
        credentials={"api_key": "abcdefgh12345678", "app_key": "ijklmnop87654321"},
    )

    connectors = list_runtime_connectors(repo_path)
    assert len(connectors) == 1
    assert connectors[0]["provider"] == "datadog"
    assert "abcd...5678" in connectors[0]["authSummary"][0]


def test_updating_connector_preserves_existing_credentials(tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    created = save_runtime_connector(
        repo_path,
        connector_id=None,
        name="Prod Loki",
        provider="loki",
        base_url="https://loki.example.com",
        credentials={"bearer_token": "secret-token"},
    )

    updated = save_runtime_connector(
        repo_path,
        connector_id=created["id"],
        name="Prod Loki Updated",
        provider="loki",
        base_url="https://loki.internal.example.com",
        credentials={},
    )

    assert updated["name"] == "Prod Loki Updated"
    assert updated["baseUrl"] == "https://loki.internal.example.com"


def test_query_runtime_logs_uses_custom_correlation_hints(monkeypatch, tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    connector = save_runtime_connector(
        repo_path,
        connector_id=None,
        name="Prod Loki",
        provider="loki",
        base_url="https://loki.example.com",
        credentials={"bearer_token": "secret-token"},
        correlation_hints=["workflow_id"],
    )

    monkeypatch.setattr(
        "logthread.core.intelligence.runtime_logs._fetch_provider_logs",
        lambda *_args, **_kwargs: [
            {
                "timestamp": "1711711711000000000",
                "line": 'level=error msg="workflow failed step 1" workflow_id=wf-123 route=/flows',
                "labels": {"service": "worker-api"},
            },
            {
                "timestamp": "1711711712000000000",
                "line": 'level=error msg="workflow failed step 2" workflow_id=wf-123 route=/flows',
                "labels": {"service": "worker-api"},
            },
        ],
    )

    packet = query_runtime_logs(
        repo_path,
        KnowledgeGraph(),
        connector_id=connector["id"],
        query='{service="worker-api"} |= "error"',
        hours=2,
        limit=50,
    )

    assert packet["connector"]["correlationHints"] == ["workflow_id"]
    assert packet["correlationConfig"]["customHints"] == ["workflow_id"]
    assert packet["sequences"][0]["correlationType"] == "correlation"
    assert packet["sequences"][0]["correlationId"] == "wf-123"
    assert packet["events"][0]["correlationId"] == "wf-123"


def test_connector_metadata_file_does_not_store_credentials(tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    repo_path.mkdir()
    save_runtime_connector(
        repo_path,
        connector_id=None,
        name="Prod Loki",
        provider="loki",
        base_url="https://loki.example.com",
        credentials={"bearer_token": "secret-token"},
    )

    payload = (get_project_dir(repo_path) / "runtime_connectors.json").read_text(encoding="utf-8")
    assert "secret-token" not in payload
    assert '"credential_fields"' in payload


def test_fetch_loki_logs_follows_redirects() -> None:
    connector = RuntimeConnector(
        id="connector",
        name="Prod Loki",
        provider="loki",
        base_url="https://logs.example.com",
        credential_fields=["bearer_token"],
        credentials={"bearer_token": "secret-token"},
        correlation_hints=[],
    )

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/loki/api/v1/query_range":
            return httpx.Response(
                302,
                headers={"Location": "https://logs.example.com/gateway/loki/api/v1/query_range"},
                request=request,
            )
        if request.url.path == "/gateway/loki/api/v1/query_range":
            return httpx.Response(
                200,
                json={
                    "status": "success",
                    "data": {
                        "result": [
                            {
                                "stream": {"service": "api"},
                                "values": [["1711711711000000000", 'level=error msg="failed"']],
                            }
                        ]
                    },
                },
                request=request,
            )
        raise AssertionError(f"Unexpected path: {request.url.path}")

    client = httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)
    rows = _fetch_loki_logs(
        client,
        connector,
        '{service="api"} |= "error"',
        start_time=datetime.now(timezone.utc),
        end_time=datetime.now(timezone.utc),
        limit=20,
    )

    assert len(rows) == 1
    assert rows[0]["labels"]["service"] == "api"


def test_fetch_loki_logs_reports_redirect_to_html_login() -> None:
    connector = RuntimeConnector(
        id="connector",
        name="Prod Loki",
        provider="loki",
        base_url="https://logs.example.com",
        credential_fields=["bearer_token"],
        credentials={"bearer_token": "secret-token"},
        correlation_hints=[],
    )

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/loki/api/v1/query_range":
            return httpx.Response(
                302,
                headers={"Location": "https://logs.example.com/login"},
                request=request,
            )
        if request.url.path == "/login":
            return httpx.Response(
                200,
                text="<html><body>login</body></html>",
                headers={"Content-Type": "text/html"},
                request=request,
            )
        raise AssertionError(f"Unexpected path: {request.url.path}")

    client = httpx.Client(transport=httpx.MockTransport(handler), follow_redirects=True)

    with pytest.raises(RuntimeError, match="gateway or login page"):
        _fetch_loki_logs(
            client,
            connector,
            '{service="api"} |= "error"',
            start_time=datetime.now(timezone.utc),
            end_time=datetime.now(timezone.utc),
            limit=20,
        )
