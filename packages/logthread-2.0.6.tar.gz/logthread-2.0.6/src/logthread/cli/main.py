"""Log Thread CLI"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import anyio
import typer
import uvicorn
from mcp.client.streamable_http import streamablehttp_client
from mcp.server.stdio import stdio_server
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from logthread import __version__
from logthread.core.diff import diff_branches, format_diff
from logthread.core.ingestion.pipeline import PipelineResult, run_pipeline
from logthread.core.ingestion.watcher import watch_repo
from logthread.core.intelligence.runtime_logs import (
    list_runtime_connectors,
    query_runtime_logs,
    save_runtime_connector,
    test_runtime_connector,
)
from logthread.core.storage.ladybug_backend import LadybugBackend
from logthread.core.storage.paths import (
    cleanup_legacy_files,
    get_db_path,
    get_project_dir,
    get_project_id,
    get_project_meta_path,
    load_project_meta,
    migrate_legacy_storage,
    register_project,
    save_project_link,
    save_project_meta,
)
from logthread.mcp import tools as mcp_tools
from logthread.mcp.server import main as mcp_main
from logthread.mcp.server import set_lock, set_storage
from logthread.runtime import LogThreadRuntime
from logthread.web import app as web_app_module

console = Console()
logger = logging.getLogger(__name__)
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8420
DEFAULT_MANAGED_PORT = 8421
UPDATE_CHECK_INTERVAL_SECONDS = 60 * 60 * 24
UPDATE_CHECK_URL = "https://pypi.org/pypi/logthread/json"
UPDATE_CHECK_SKIP_COMMANDS = {"mcp", "serve", "host"}

def _load_storage(repo_path: Path | None = None) -> "LadybugBackend":  # noqa: F821
    target = (repo_path or Path.cwd()).resolve()

    migrate_legacy_storage(target)

    db_path = get_db_path(target)
    meta_path = get_project_meta_path(target)

    if not db_path.exists() and not meta_path.exists():
        console.print(
            f"[red]Error:[/red] No index found at {target}. Run 'logthread generate' first."
        )
        raise typer.Exit(code=1)

    storage = LadybugBackend()
    storage.initialize(db_path, read_only=True)
    return storage


def _read_diff_input(diff_file: Path | None = None) -> str:
    if diff_file is not None:
        return diff_file.read_text(encoding="utf-8")
    if not sys.stdin.isatty():
        return sys.stdin.read()
    completed = subprocess.run(
        ["git", "diff", "--minimal"],
        capture_output=True,
        text=True,
        check=False,
    )
    return completed.stdout


def _update_cache_path() -> Path:
    return Path.home() / ".logthread" / "update-check.json"


def _parse_version_parts(version: str) -> tuple[int, ...]:
    parts: list[int] = []
    for raw_part in version.split("."):
        digits = "".join(ch for ch in raw_part if ch.isdigit())
        parts.append(int(digits or 0))
    return tuple(parts)


def _is_newer_version(candidate: str, current: str) -> bool:
    return _parse_version_parts(candidate) > _parse_version_parts(current)


def _read_update_cache() -> dict | None:
    cache_path = _update_cache_path()
    if not cache_path.exists():
        return None
    try:
        return json.loads(cache_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _write_update_cache(payload: dict) -> None:
    cache_path = _update_cache_path()
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _fetch_latest_version() -> str | None:
    try:
        with urllib.request.urlopen(UPDATE_CHECK_URL, timeout=1.5) as response:
            payload = json.loads(response.read().decode("utf-8"))
            return str(payload["info"]["version"])
    except (KeyError, OSError, ValueError, urllib.error.URLError):
        return None


def _get_latest_version() -> str | None:
    now = int(time.time())
    cache = _read_update_cache()
    if cache is not None:
        checked_at = int(cache.get("checked_at", 0))
        latest = cache.get("latest_version")
        if latest and now - checked_at < UPDATE_CHECK_INTERVAL_SECONDS:
            return str(latest)

    latest = _fetch_latest_version()
    if latest is not None:
        _write_update_cache({"checked_at": now, "latest_version": latest})
    return latest


def _maybe_notify_update(invoked_subcommand: str | None) -> None:
    if invoked_subcommand in UPDATE_CHECK_SKIP_COMMANDS:
        return
    latest = _get_latest_version()
    if latest and _is_newer_version(latest, __version__):
        console.print(
            f"[yellow]Update available:[/yellow] Log Thread {latest} "
            f"(current {__version__}). Run `pip install -U logthread`."
        )


def _register_in_global_registry(meta: dict, repo_path: Path) -> None:
    """Register project in the global registry and legacy repo slots."""
    register_project(repo_path, meta)
    legacy_registry_dir = Path.home() / ".logthread" / "repos"
    legacy_registry_dir.mkdir(parents=True, exist_ok=True)

    repo_path_str = str(repo_path.resolve())
    base_slug = "".join(
        ch.lower() if ch.isalnum() else "-" for ch in meta.get("name", repo_path.name).strip()
    ).strip("-") or repo_path.name.lower()
    suffix = hashlib.sha256(repo_path_str.encode("utf-8")).hexdigest()[:8]

    existing_same_repo: list[Path] = []
    bare_slot_claimed_by_other_repo = False

    for slot in legacy_registry_dir.iterdir():
        if not slot.is_dir():
            continue
        meta_path = slot / "meta.json"
        try:
            slot_meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            slot_meta = None

        if slot_meta and slot_meta.get("path") == repo_path_str:
            existing_same_repo.append(slot)
        elif slot.name == base_slug and slot_meta and slot_meta.get("path") != repo_path_str:
            bare_slot_claimed_by_other_repo = True

    target_slug = f"{base_slug}-{suffix}" if bare_slot_claimed_by_other_repo else base_slug
    target_slot = legacy_registry_dir / target_slug
    target_slot.mkdir(parents=True, exist_ok=True)

    for stale_slot in existing_same_repo:
        if stale_slot != target_slot:
            shutil.rmtree(stale_slot, ignore_errors=True)

    legacy_meta = dict(meta)
    legacy_meta["name"] = meta.get("name", repo_path.name)
    legacy_meta["path"] = repo_path_str
    legacy_meta["slug"] = target_slug
    (target_slot / "meta.json").write_text(json.dumps(legacy_meta, indent=2) + "\n", encoding="utf-8")


def _resolve_project_name(
    repo_path: Path,
    project_name: str | None = None,
    existing_meta: dict | None = None,
) -> str:
    if project_name is not None:
        normalized = project_name.strip()
        if normalized:
            return normalized

    if existing_meta is None:
        existing_meta = load_project_meta(repo_path) or {}

    existing_name = str(existing_meta.get("name", "")).strip()
    if existing_name:
        return existing_name
    return repo_path.name


def _build_meta(
    result: "PipelineResult",
    repo_path: Path,
    *,
    project_name: str | None = None,
    existing_meta: dict | None = None,
) -> dict:  # noqa: F821
    return {
        "version": __version__,
        "name": _resolve_project_name(repo_path, project_name, existing_meta),
        "path": str(repo_path),
        "files": result.files,  # Top-level for registry
        "symbols": result.symbols,  # Top-level for registry
        "stats": {
            "files": result.files,
            "symbols": result.symbols,
            "relationships": result.relationships,
            "clusters": result.clusters,
            "flows": result.processes,
            "dead_code": result.dead_code,
            "coupled_pairs": result.coupled_pairs,
            "embeddings": result.embeddings,
            "api_endpoints": result.api_endpoints,
            "db_tables": result.db_tables,
        },
        "languages": result.language_counts,
        "api_frameworks": result.api_frameworks,
        "semantic": result.semantic_summary,
        "last_indexed_at": datetime.now(tz=timezone.utc).isoformat(),
    }


def _host_meta_path(repo_path: Path) -> Path:
    return repo_path / ".logthread" / "host.json"


def _host_lease_dir(repo_path: Path) -> Path:
    return repo_path / ".logthread" / "host-leases"


def _display_host(host: str) -> str:
    return "127.0.0.1" if host in {"0.0.0.0", "::"} else host


def _build_host_urls(host: str, port: int) -> tuple[str, str]:
    base = f"http://{_display_host(host)}:{port}"
    return base, f"{base}/mcp"


def _read_host_meta(repo_path: Path) -> dict | None:
    meta_path = _host_meta_path(repo_path)
    if not meta_path.exists():
        return None
    try:
        return json.loads(meta_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _write_host_meta(
    repo_path: Path,
    host_url: str,
    mcp_url: str,
    port: int,
    *,
    ui_enabled: bool,
) -> None:
    meta_path = _host_meta_path(repo_path)
    meta_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "pid": os.getpid(),
        "repo_path": str(repo_path),
        "host_url": host_url,
        "mcp_url": mcp_url,
        "port": port,
        "ui_enabled": ui_enabled,
        "leases_dir": str(_host_lease_dir(repo_path)),
    }
    meta_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _clear_host_meta(repo_path: Path) -> None:
    meta_path = _host_meta_path(repo_path)
    if meta_path.exists():
        meta_path.unlink(missing_ok=True)


def _create_host_lease(repo_path: Path, lease_type: str) -> Path:
    lease_dir = _host_lease_dir(repo_path)
    lease_dir.mkdir(parents=True, exist_ok=True)
    lease_path = lease_dir / f"{os.getpid()}-{uuid.uuid4().hex}.json"
    payload = {
        "pid": os.getpid(),
        "type": lease_type,
        "created_at": time.time(),
    }
    lease_path.write_text(json.dumps(payload), encoding="utf-8")
    return lease_path


def _remove_host_lease(lease_path: Path | None) -> None:
    if lease_path is not None:
        lease_path.unlink(missing_ok=True)


def _pid_is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _count_live_host_leases(repo_path: Path) -> int:
    lease_dir = _host_lease_dir(repo_path)
    if not lease_dir.exists():
        return 0
    live = 0
    for lease_path in lease_dir.glob("*.json"):
        try:
            payload = json.loads(lease_path.read_text(encoding="utf-8"))
            pid = int(payload.get("pid", 0))
        except (ValueError, json.JSONDecodeError, OSError):
            lease_path.unlink(missing_ok=True)
            continue
        if _pid_is_alive(pid):
            live += 1
        else:
            lease_path.unlink(missing_ok=True)
    return live


def _is_host_alive(meta: dict, repo_path: Path) -> bool:
    host_url = meta.get("host_url")
    if not host_url:
        return False
    try:
        with urllib.request.urlopen(f"{host_url}/api/host", timeout=1.0) as response:
            if response.status != 200:
                return False
            payload = json.loads(response.read().decode("utf-8"))
            return payload.get("repoPath") == str(repo_path)
    except (OSError, ValueError, urllib.error.URLError):
        return False


def _get_live_host_info(repo_path: Path) -> dict | None:
    meta = _read_host_meta(repo_path)
    if meta is None:
        return None
    if _is_host_alive(meta, repo_path):
        return meta
    return None


def _start_host_background(
    repo_path: Path,
    *,
    port: int = DEFAULT_PORT,
    bind: str = DEFAULT_HOST,
    watch: bool = True,
    managed: bool = False,
) -> None:
    """Start a detached shared host process in the background."""
    command = [
        sys.executable,
        "-m",
        "logthread.cli.main",
        "host",
        "--port",
        str(port),
        "--bind",
        bind,
        "--no-open",
    ]
    if watch:
        command.append("--watch")
    else:
        command.append("--no-watch")
    if managed:
        command.append("--managed")
    with open(os.devnull, "wb") as devnull:
        subprocess.Popen(  # noqa: S603
            command,
            cwd=repo_path,
            stdout=devnull,
            stderr=devnull,
            start_new_session=True,
        )


def _ensure_host_running(
    repo_path: Path,
    *,
    port: int = DEFAULT_PORT,
    bind: str = DEFAULT_HOST,
    watch: bool = True,
    timeout_seconds: float = 10.0,
    managed: bool = False,
) -> dict:
    """Return live host metadata, starting the shared host if necessary."""
    live_host = _get_live_host_info(repo_path)
    if live_host is not None:
        return live_host

    _start_host_background(repo_path, port=port, bind=bind, watch=watch, managed=managed)
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        live_host = _get_live_host_info(repo_path)
        if live_host is not None:
            return live_host
        time.sleep(0.2)
    raise RuntimeError("Timed out waiting for Log Thread host to start.")


app = typer.Typer(
    name="logthread",
    help="Log Thread.",
    no_args_is_help=True,
)
logs_app = typer.Typer(help="Runtime log intelligence.")
app.add_typer(logs_app, name="logs")

def _version_callback(value: bool) -> None:
    if value:
        console.print(f"Log Thread v{__version__}")
        raise typer.Exit()

@app.callback()
def main(
    ctx: typer.Context,
    version: Optional[bool] = typer.Option(  # noqa: N803
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """Log Thread."""
    _maybe_notify_update(ctx.invoked_subcommand)


def _initialize_writable_storage(
    repo_path: Path, *, auto_index: bool = True,
) -> tuple["LadybugBackend", Path, Path]:  # noqa: F821
    """Open the repo database in read-write mode.

    If *auto_index* is False and no index exists, raises typer.Exit instead of
    running the pipeline — callers like ``ui`` should tell the user to run
    ``logthread generate .`` themselves.
    """
    # Migrate any legacy storage first
    migrate_legacy_storage(repo_path)

    # Use centralized storage paths
    db_path = get_db_path(repo_path)
    meta_path = get_project_meta_path(repo_path)
    project_dir = get_project_dir(repo_path)

    if not auto_index and not meta_path.exists():
        console.print(
            "[red]Error:[/red] No index found. Run [cyan]logthread generate .[/cyan] first to index this codebase."
        )
        raise typer.Exit(code=1)

    # Ensure project directory exists
    project_dir.mkdir(parents=True, exist_ok=True)

    storage = LadybugBackend()
    storage.initialize(db_path)

    if not meta_path.exists():
        console.print("[bold]Running initial index...[/bold]")
        _, result = run_pipeline(repo_path, storage)
        meta = _build_meta(result, repo_path)
        save_project_meta(repo_path, meta)
        try:
            _register_in_global_registry(meta, repo_path)
        except Exception:
            logger.debug("Failed to register repo in global registry", exc_info=True)

    return storage, project_dir, db_path


async def _proxy_stdio_to_http_mcp(mcp_url: str) -> None:
    """Bridge a local stdio MCP session to the shared HTTP MCP host."""
    async with stdio_server() as (local_read, local_write):
        async with streamablehttp_client(mcp_url) as (remote_read, remote_write, _):
            async def _forward(reader, writer) -> None:
                async with writer:
                    async for message in reader:
                        await writer.send(message)

            async with anyio.create_task_group() as tg:
                tg.start_soon(_forward, local_read, remote_write)
                tg.start_soon(_forward, remote_read, local_write)


def _run_shared_host(
    *,
    port: int,
    bind: str,
    no_open: bool,
    watch: bool,
    dev: bool,
    managed: bool,
    open_browser: bool,
    announce_ui: bool,
    announce_mcp: bool,
    expose_ui: bool,
    already_running_message: str,
    auto_index: bool = True,
    ignore_running: bool = False,
) -> None:
    """Run the shared Log Thread host with configurable UX messaging."""
    repo_path = Path.cwd().resolve()
    if not ignore_running:
        live_host = _get_live_host_info(repo_path)
        if live_host is not None:
            console.print(already_running_message.format(url=live_host["host_url"]))
            if open_browser and not no_open:
                webbrowser.open(live_host["host_url"])
            return

    storage, _, db_path = _initialize_writable_storage(repo_path, auto_index=auto_index)
    host_url, mcp_url = _build_host_urls(bind, port)
    lock = asyncio.Lock()
    runtime = LogThreadRuntime(
        storage=storage,
        repo_path=repo_path,
        watch=watch,
        lock=lock,
        host_url=host_url,
        mcp_url=mcp_url,
        owns_storage=True,
    )
    set_storage(storage)
    set_lock(lock)

    web_app = web_app_module.create_app(
        db_path=db_path,
        repo_path=repo_path,
        watch=watch,
        dev=dev,
        runtime=runtime,
        mount_mcp=True,
        host_url=host_url,
        mcp_url=mcp_url,
        mount_frontend=expose_ui,
    )

    if open_browser and not no_open:
        threading.Timer(1.0, lambda: webbrowser.open(host_url)).start()

    if announce_ui:
        console.print(f"[bold green]Log Thread UI[/bold green] running at {host_url}")
    if announce_mcp:
        console.print(f"[dim]HTTP MCP endpoint:[/dim] {mcp_url}")
    if watch:
        console.print("[dim]File watching enabled[/dim]")
    if dev:
        console.print("[dim]Dev mode — proxying to Vite on :5173[/dim]")

    _write_host_meta(repo_path, host_url, mcp_url, port, ui_enabled=expose_ui)

    async def _run() -> None:
        config = uvicorn.Config(
            web_app,
            host=bind,
            port=port,
            log_level="warning",
        )
        server = uvicorn.Server(config)
        stop = asyncio.Event()

        async def _serve() -> None:
            await server.serve()
            stop.set()

        async def _managed_shutdown() -> None:
            if not managed:
                return
            idle_started_at: float | None = None
            while not stop.is_set():
                live_leases = _count_live_host_leases(repo_path)
                if live_leases == 0:
                    if idle_started_at is None:
                        idle_started_at = time.time()
                    elif time.time() - idle_started_at >= 2.0:
                        server.should_exit = True
                        stop.set()
                        return
                else:
                    idle_started_at = None
                await asyncio.sleep(0.5)

        tasks = [_serve()]
        if watch:
            tasks.append(watch_repo(repo_path, storage, stop_event=stop, lock=lock))
        if managed:
            tasks.append(_managed_shutdown())
        await asyncio.gather(*tasks)

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        pass
    finally:
        _clear_host_meta(repo_path)
        storage.close()

@app.command()
def generate(
    path: Path = typer.Argument(Path("."), help="Path to the repository to index."),
    no_embeddings: bool = typer.Option(False, "--no-embeddings", help="Skip vector embedding generation."),
    incremental: bool = typer.Option(True, "--incremental/--full", help="Only re-index changed files (default: incremental)."),
    project_name: str | None = typer.Option(
        None,
        "--name",
        "--project-name",
        help="Custom display name for this indexed repository.",
    ),
) -> None:
    """Index a repository into a knowledge graph."""
    repo_path = path.resolve()
    if not repo_path.is_dir():
        console.print(f"[red]Error:[/red] {repo_path} is not a directory.")
        raise typer.Exit(code=1)

    migrate_legacy_storage(repo_path)
    db_path = get_db_path(repo_path)

    # Check if we can do incremental indexing
    meta_path = get_project_meta_path(repo_path)
    can_incremental = incremental and db_path.exists() and meta_path.exists()
    existing_meta = load_project_meta(repo_path) if meta_path.exists() else None

    if can_incremental:
        console.print(f"[bold]Checking for changes in[/bold] {repo_path}")
    else:
        console.print(f"[bold]Indexing[/bold] {repo_path}")

    storage = LadybugBackend()
    try:
        storage.initialize(db_path, max_retries=6, retry_delay=1.0)
    except RuntimeError as e:
        if "lock" in str(e).lower():
            console.print(
                "\n[yellow]⚠️  Database is locked[/yellow]\n\n"
                "The MCP server's connection lease should auto-release within a few seconds.\n"
                "If this persists, close any running logthread processes and try again.\n"
            )
            raise typer.Exit(code=1)
        raise

    result: PipelineResult | None = None

    # Try incremental indexing if possible
    if can_incremental:
        import hashlib

        from logthread.config.ignore import load_gitignore
        from logthread.core.ingestion.walker import walk_repo
        from logthread.core.ingestion.watcher import _reindex_files

        gitignore = load_gitignore(repo_path)
        current_files = walk_repo(repo_path, gitignore)

        # Load previous file hashes
        hash_file = db_path.parent / "file_hashes.json"
        prev_hashes: dict[str, str] = {}
        if hash_file.exists():
            prev_hashes = json.loads(hash_file.read_text())

        # Compute current hashes and find changed files
        changed_paths: list[Path] = []
        current_hashes: dict[str, str] = {}

        for fe in current_files:
            # fe.path is already a relative string path
            content_hash = hashlib.md5(fe.content.encode()).hexdigest()
            current_hashes[fe.path] = content_hash

            if prev_hashes.get(fe.path) != content_hash:
                # Reconstruct absolute path from relative string
                changed_paths.append(repo_path / fe.path)

        # Check for deleted files
        deleted_files = set(prev_hashes.keys()) - set(current_hashes.keys())

        if not changed_paths and not deleted_files:
            console.print("[green]✓ No changes detected, skipping re-index[/green]")
            # Save hashes
            hash_file.write_text(json.dumps(current_hashes))

            # Still update metadata/registry, including rename-only changes.
            current_meta = dict(existing_meta or {})
            resolved_name = _resolve_project_name(repo_path, project_name, current_meta)
            if current_meta and current_meta.get("name") != resolved_name:
                current_meta["name"] = resolved_name
                save_project_meta(repo_path, current_meta)
                existing_meta = current_meta

            if current_meta:
                try:
                    _register_in_global_registry(current_meta, repo_path)
                except Exception:
                    logger.debug("Failed to register repo in global registry", exc_info=True)

            storage.close()
            return

        console.print(f"[dim]Found {len(changed_paths)} changed, {len(deleted_files)} deleted files[/dim]")

        # Do incremental reindex
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Re-indexing changed files...", total=None)

            count, _ = _reindex_files(changed_paths, repo_path, storage, gitignore)
            progress.update(task, description=f"Re-indexed {count} files")

        # Save updated hashes
        hash_file.write_text(json.dumps(current_hashes))

        # Build minimal result for output
        result = PipelineResult()
        result.files = len(current_files)
        result.symbols = count

        # Update metadata and registry even for incremental updates
        meta = _build_meta(result, repo_path, project_name=project_name, existing_meta=existing_meta)
        save_project_meta(repo_path, meta)
        
        try:
            _register_in_global_registry(meta, repo_path)
        except Exception:
            logger.debug("Failed to register repo in global registry", exc_info=True)

        console.print()
        console.print("[bold green]Incremental update complete.[/bold green]")
        console.print(f"  Changed files:  {len(changed_paths)}")
        console.print(f"  Re-indexed:     {count}")
        storage.close()
        return

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Starting...", total=None)

        def on_progress(phase: str, pct: float) -> None:
            progress.update(task, description=f"{phase} ({pct:.0%})")

        _, result = run_pipeline(
            repo_path=repo_path,
            storage=storage,
            progress_callback=on_progress,
            embeddings=not no_embeddings,
        )

    # Save file hashes for future incremental builds
    import hashlib

    from logthread.config.ignore import load_gitignore
    from logthread.core.ingestion.walker import walk_repo

    gitignore = load_gitignore(repo_path)
    current_files = walk_repo(repo_path, gitignore)
    current_hashes: dict[str, str] = {}
    for fe in current_files:
        # fe.path is already a relative string
        current_hashes[fe.path] = hashlib.md5(fe.content.encode()).hexdigest()

    hash_file = db_path.parent / "file_hashes.json"
    hash_file.write_text(json.dumps(current_hashes))

    meta = _build_meta(result, repo_path, project_name=project_name, existing_meta=existing_meta)
    save_project_link(repo_path, meta)
    cleanup_legacy_files(repo_path)

    try:
        _register_in_global_registry(meta, repo_path)
    except Exception:
        logger.debug("Failed to register repo in global registry", exc_info=True)

    console.print()
    console.print("[bold green]Indexing complete.[/bold green]")
    console.print(f"  Files:          {result.files}")
    console.print(f"  Symbols:        {result.symbols}")
    console.print(f"  Relationships:  {result.relationships}")
    if result.clusters > 0:
        console.print(f"  Clusters:       {result.clusters}")
    if result.processes > 0:
        console.print(f"  Flows:          {result.processes}")
    if result.dead_code > 0:
        console.print(f"  Dead code:      {result.dead_code}")
    if result.coupled_pairs > 0:
        console.print(f"  Coupled pairs:  {result.coupled_pairs}")
    if result.embeddings > 0:
        console.print(f"  Embeddings:     {result.embeddings}")
    console.print(f"  Duration:       {result.duration_seconds:.2f}s")

    storage.close()

@app.command()
def status() -> None:
    """Show index status for current repository."""
    repo_path = Path.cwd().resolve()

    migrate_legacy_storage(repo_path)
    meta_path = get_project_meta_path(repo_path)

    if not meta_path.exists():
        console.print(
            "[red]Error:[/red] No index found. Run [cyan]logthread generate .[/cyan] first to index this codebase."
        )
        raise typer.Exit(code=1)

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    stats = meta.get("stats", {})

    console.print(f"[bold]Index status for[/bold] {repo_path}")
    console.print(f"  Project ID:     {get_project_id(repo_path)}")
    console.print(f"  Version:        {meta.get('version', '?')}")
    console.print(f"  Last indexed:   {meta.get('last_indexed_at', '?')}")
    console.print(f"  Files:          {stats.get('files', '?')}")
    console.print(f"  Symbols:        {stats.get('symbols', '?')}")
    console.print(f"  Relationships:  {stats.get('relationships', '?')}")

    if stats.get("api_endpoints", 0) > 0:
        console.print(f"  API endpoints:  {stats['api_endpoints']}")
    if stats.get("db_tables", 0) > 0:
        console.print(f"  DB tables:      {stats['db_tables']}")
    if stats.get("clusters", 0) > 0:
        console.print(f"  Clusters:       {stats['clusters']}")
    if stats.get("flows", 0) > 0:
        console.print(f"  Flows:          {stats['flows']}")
    if stats.get("dead_code", 0) > 0:
        console.print(f"  Dead code:      {stats['dead_code']}")
    if stats.get("coupled_pairs", 0) > 0:
        console.print(f"  Coupled pairs:  {stats['coupled_pairs']}")

    languages = meta.get("languages", {})
    if languages:
        lang_summary = ", ".join(
            f"{lang}={count}" for lang, count in sorted(languages.items(), key=lambda item: (-item[1], item[0]))
        )
        console.print(f"  Languages:      {lang_summary}")

    frameworks = meta.get("api_frameworks", {})
    if frameworks:
        framework_summary = ", ".join(
            f"{name}={count}" for name, count in sorted(frameworks.items(), key=lambda item: (-item[1], item[0]))
        )
        console.print(f"  API frameworks: {framework_summary}")

    semantic = meta.get("semantic", {})
    if semantic:
        findings = semantic.get("findings", 0)
        if findings:
            console.print(f"  Semantic issues: {findings}")
        engines = semantic.get("engines", {})
        available = [name for name, info in engines.items() if info.get("available")]
        if available:
            console.print(f"  Semantic engines: {', '.join(sorted(available))}")


@app.command()
def capabilities() -> None:
    """Show language, framework, and datastore capability tiers."""
    console.print(mcp_tools.handle_language_capabilities())


@app.command(name="change-risk")
def change_risk(
    depth: int = typer.Option(3, "--depth", min=1, max=10, help="Impact traversal depth."),
    diff_file: Optional[Path] = typer.Option(
        None,
        "--diff-file",
        help="Path to a file containing git diff output. Defaults to stdin or `git diff --minimal`.",
    ),
) -> None:
    """Analyze structured change risk for a diff."""
    diff = _read_diff_input(diff_file)
    if not diff.strip():
        console.print("[red]Error:[/red] No diff provided. Pass --diff-file, pipe stdin, or run inside a git repo.")
        raise typer.Exit(code=1)

    storage = _load_storage()
    console.print(mcp_tools.handle_review_risk(storage, diff))
    console.print()
    console.print("[bold]Structured packet[/bold]")
    console.print_json(data=mcp_tools.build_change_risk_packet(storage, diff, depth))
    storage.close()


@app.command(name="edit-contract")
def edit_contract(
    query: str = typer.Argument("", help="Natural-language implementation objective."),
    symbol: str = typer.Option("", "--symbol", help="Optional exact symbol anchor."),
    max_candidates: int = typer.Option(8, "--max-candidates", min=1, max=16),
) -> None:
    """Build an agent-safe edit contract for a requested change."""
    storage = _load_storage()
    repo_path = Path.cwd().resolve()
    console.print(
        mcp_tools.handle_agent_safe_edit_contract(
            storage,
            repo_path,
            query,
            symbol=symbol,
            max_candidates=max_candidates,
        )
    )
    console.print()
    console.print("[bold]Structured packet[/bold]")
    console.print_json(
        data=mcp_tools.build_agent_safe_edit_contract_packet(
            storage,
            repo_path,
            query,
            symbol=symbol,
            max_candidates=max_candidates,
        )
    )
    storage.close()


@app.command(name="confidence-report")
def confidence_report() -> None:
    """Show graph trust coverage and low-confidence nodes."""
    storage = _load_storage()
    console.print(mcp_tools.handle_confidence_report(storage))
    console.print()
    console.print("[bold]Structured packet[/bold]")
    console.print_json(data=mcp_tools.build_confidence_report_packet(storage))
    storage.close()


@logs_app.command("list-connectors")
def logs_list_connectors() -> None:
    """List runtime log connectors for the current repository."""
    repo_path = Path.cwd().resolve()
    connectors = list_runtime_connectors(repo_path)
    if not connectors:
        console.print("[yellow]No runtime connectors configured.[/yellow]")
        return
    console.print(f"[bold]Runtime connectors for[/bold] {repo_path}")
    for connector in connectors:
        auth = ", ".join(connector.get("authSummary", [])) or "no credentials summary"
        console.print(f"  • {connector['name']} [{connector['providerLabel']}]")
        console.print(f"    URL: {connector['baseUrl']}")
        if connector.get("defaultSource"):
            console.print(f"    Source: {connector['defaultSource']}")
        if connector.get("correlationHints"):
            console.print(f"    Correlation hints: {', '.join(connector['correlationHints'])}")
        console.print(f"    Auth: {auth}")


@logs_app.command("connect")
def logs_connect(
    name: str = typer.Option(..., "--name", help="Display name for this connector."),
    provider: str = typer.Option(..., "--provider", help="Provider id: loki, datadog, splunk, sumologic."),
    base_url: str = typer.Option(..., "--base-url", help="Provider base URL."),
    source: str = typer.Option("", "--source", help="Default index / source / stream when supported."),
    bearer_token: str = typer.Option("", "--bearer-token", help="Bearer token for Loki."),
    api_key: str = typer.Option("", "--api-key", help="API key for Datadog."),
    app_key: str = typer.Option("", "--app-key", help="Application key for Datadog."),
    username: str = typer.Option("", "--username", help="Username for Splunk basic auth."),
    password: str = typer.Option("", "--password", help="Password for Splunk basic auth."),
    access_id: str = typer.Option("", "--access-id", help="Access ID for Sumo Logic."),
    access_key: str = typer.Option("", "--access-key", help="Access key for Sumo Logic."),
    correlation_hint: list[str] = typer.Option(
        None,
        "--correlation-hint",
        help="Custom field or message key to use when clustering request traces. Repeat for multiple values.",
    ),
    verify_tls: bool = typer.Option(True, "--verify-tls/--insecure", help="Verify provider TLS certificates."),
) -> None:
    """Create or update a runtime log connector."""
    repo_path = Path.cwd().resolve()
    try:
        connector = save_runtime_connector(
            repo_path,
            connector_id=None,
            name=name,
            provider=provider,
            base_url=base_url,
            credentials={
                "bearer_token": bearer_token,
                "api_key": api_key,
                "app_key": app_key,
                "username": username,
                "password": password,
                "access_id": access_id,
                "access_key": access_key,
            },
            correlation_hints=correlation_hint or [],
            default_source=source or None,
            verify_tls=verify_tls,
        )
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    console.print(f"[green]Saved runtime connector:[/green] {connector['name']} ({connector['providerLabel']})")


@logs_app.command("test")
def logs_test(connector_id: str = typer.Argument(..., help="Connector id to test.")) -> None:
    """Validate a runtime connector against its upstream provider."""
    repo_path = Path.cwd().resolve()
    try:
        result = test_runtime_connector(repo_path, connector_id)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    console.print(f"[green]Connection ok.[/green] {result['provider']} responded in {result['latencyMs']} ms.")


@logs_app.command("query")
def logs_query(
    connector_id: str = typer.Argument(..., help="Connector id to query."),
    query: str = typer.Argument(..., help="Provider-native search query."),
    hours: int = typer.Option(2, "--hours", min=1, max=168, help="Lookback window in hours."),
    limit: int = typer.Option(150, "--limit", min=1, max=400, help="Maximum logs to analyze."),
    source: str = typer.Option("", "--source", help="Override connector default source/index."),
) -> None:
    """Fetch logs and analyze them against the local graph."""
    repo_path = Path.cwd().resolve()
    storage = _load_storage(repo_path)
    try:
        packet = query_runtime_logs(
            repo_path,
            storage.load_graph(),
            connector_id=connector_id,
            query=query,
            hours=hours,
            limit=limit,
            source=source or None,
        )
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    finally:
        storage.close()

    console.print(f"[bold]Runtime analysis for[/bold] {packet['connector']['name']}")
    console.print(
        f"  Events: {packet['stats']['events']}  "
        f"Patterns: {packet['stats']['patterns']}  "
        f"Sequences: {packet['stats']['sequences']}"
    )
    console.print()
    for answer in packet.get("answers", [])[:3]:
        console.print(f"[bold]{answer['title']}[/bold]")
        console.print(f"  {answer['body']}")
        for evidence in answer.get("evidence", [])[:3]:
            console.print(f"  - {evidence}")
        console.print()
    console.print("[bold]Structured packet[/bold]")
    console.print_json(data=packet)


@app.command(name="list")
def list_repos() -> None:
    """List all indexed repositories."""
    result = mcp_tools.handle_list_repos()
    console.print(result)

@app.command()
def clean(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation prompt."),
) -> None:
    """Delete index for current repository."""
    from logthread.core.storage.paths import get_project_dir

    repo_path = Path.cwd().resolve()
    project_dir = get_project_dir(repo_path)

    if not project_dir.exists():
        console.print(
            f"[red]Error:[/red] No index found for {repo_path}. Nothing to clean."
        )
        raise typer.Exit(code=1)

    if not force:
        confirm = typer.confirm(f"Delete index for {repo_path.name}?")
        if not confirm:
            console.print("Aborted.")
            raise typer.Exit()

    shutil.rmtree(project_dir)
    cleanup_legacy_files(repo_path)
    console.print(f"[green]Deleted[/green] index for {repo_path.name}")


@app.command()
def query(
    q: str = typer.Argument(..., help="Search query for the Code context."),
    limit: int = typer.Option(20, "--limit", "-n", help="Maximum number of results."),
) -> None:
    """Search the knowledge graph."""
    storage = _load_storage()
    result = mcp_tools.handle_query(storage, q, limit=limit)
    console.print(result)
    storage.close()

@app.command()
def context(
    name: str = typer.Argument(..., help="Symbol name to inspect."),
) -> None:
    """Show 360-degree view of a symbol."""
    storage = _load_storage()
    result = mcp_tools.handle_context(storage, name)
    console.print(result)
    storage.close()

@app.command()
def impact(
    target: Optional[str] = typer.Argument(None, help="Symbol to analyze blast radius for."),
    depth: int = typer.Option(3, "--depth", "-d", min=1, max=10, help="Traversal depth (1-10)."),
    unstaged: bool = typer.Option(False, "--unstaged", "-u", help="Analyze impact of current uncommitted changes."),
) -> None:
    """Show blast radius of code changes."""
    storage = _load_storage()
    if unstaged:
        result = mcp_tools.handle_unstaged_impact(storage, depth=depth)
    elif target:
        result = mcp_tools.handle_impact(storage, target, depth=depth)
    else:
        console.print("[red]Error:[/red] Please provide a target symbol or use --unstaged.")
        storage.close()
        raise typer.Exit(code=1)

    console.print(result)
    storage.close()

def _print_dead_code() -> None:
    storage = _load_storage()
    result = mcp_tools.handle_dead_code(storage)
    console.print(result)
    storage.close()


@app.command(name="dead-code")
def dead_code() -> None:
    """List all detected dead code."""
    _print_dead_code()


@app.command(name="dead-end", hidden=True)
def dead_end() -> None:
    """Backward-compatible alias for dead-code."""
    _print_dead_code()

@app.command()
def doc(
    output: Path = typer.Option("system_architecture.md", "--output", "-o", help="Output Markdown file path."),
) -> None:
    """Generate system architecture documentation from the graph."""
    from logthread.core.analysis.documentation import generate_architecture_doc

    storage = _load_storage()
    with console.status("[bold green]Generating architecture documentation..."):
        report = generate_architecture_doc(storage)
        output.write_text(report, encoding="utf-8")

    console.print(f"[bold green]✓ Documentation generated:[/bold green] {output}")
    storage.close()

@app.command()
def export(
    output: Path = typer.Option("graph.html", "--output", "-o", help="Output HTML file path."),
    format: str = typer.Option("html", "--format", "-f", help="Export format (html only for now)."),
    symbol: Optional[str] = typer.Option(None, "--symbol", "-s", help="Export impact analysis for a specific symbol."),
    depth: int = typer.Option(3, "--depth", "-d", help="Depth for impact analysis (when --symbol is used)."),
) -> None:
    """Export graph visualization as standalone HTML file."""
    from logthread.web.export import export_graph_html, export_impact_html

    if format != "html":
        console.print(f"[red]Error:[/red] Unsupported format '{format}'. Only 'html' is supported.")
        raise typer.Exit(code=1)

    storage = _load_storage()

    try:
        if symbol:
            # Export impact analysis for specific symbol
            with console.status(f"[bold green]Analyzing impact of {symbol}..."):
                from logthread.core.analysis.impact import ImpactAnalyzer

                analyzer = ImpactAnalyzer(storage)
                target_node = storage.get_node(symbol)

                if not target_node:
                    console.print(f"[red]Error:[/red] Symbol '{symbol}' not found.")
                    raise typer.Exit(code=1)

                affected = analyzer.analyze(symbol, depth=depth)

                # Convert to dict format for export
                target_dict = {
                    "id": target_node.id,
                    "name": target_node.name,
                    "label": target_node.label,
                    "filePath": target_node.file_path,
                    "startLine": target_node.start_line,
                }

                affected_dicts = [
                    {
                        "id": node.id,
                        "name": node.name,
                        "label": node.label,
                        "filePath": node.file_path,
                        "startLine": node.start_line,
                    }
                    for node in affected.affected_nodes
                ]

                export_impact_html(target_dict, affected_dicts, output)
                console.print(f"[bold green]✓ Impact visualization exported:[/bold green] {output}")
                console.print(f"  Target: {symbol}")
                console.print(f"  Affected nodes: {len(affected_dicts)}")
        else:
            # Export full graph
            with console.status("[bold green]Exporting graph visualization..."):
                # Load all nodes and edges
                graph = storage.load_graph()

                nodes = [
                    {
                        "id": node.id,
                        "name": node.name,
                        "label": node.label,
                        "filePath": node.file_path,
                        "startLine": node.start_line,
                        "signature": node.signature,
                        "isDead": node.is_dead,
                    }
                    for node in graph.nodes.values()
                ]

                edges = [
                    {
                        "source": rel.source_id,
                        "target": rel.target_id,
                        "type": rel.rel_type.value,
                    }
                    for rel in graph.relationships
                ]

                export_graph_html(nodes, edges, output, title=f"Code Graph - {Path.cwd().name}")
                console.print(f"[bold green]✓ Graph visualization exported:[/bold green] {output}")
                console.print(f"  Nodes: {len(nodes)}")
                console.print(f"  Edges: {len(edges)}")
    finally:
        storage.close()

@app.command()
def cypher(
    query: str = typer.Argument(..., help="Raw Cypher query to execute."),
) -> None:
    """Execute raw Cypher against the knowledge graph."""
    storage = _load_storage()
    result = mcp_tools.handle_cypher(storage, query)
    console.print(result)
    storage.close()

@app.command()
def setup(
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", help="Use interactive wizard."),
    claude: bool = typer.Option(False, "--claude", help="Configure MCP for Claude Code."),
    cursor: bool = typer.Option(False, "--cursor", help="Configure MCP for Cursor."),
    project_path: Optional[Path] = typer.Option(None, "--path", "-p", help="Project path to configure."),
) -> None:
    """Configure MCP for AI assistants (interactive wizard or manual)."""
    use_interactive_wizard = interactive and not claude and not cursor and sys.stdin.isatty() and sys.stdout.isatty()

    # Use interactive wizard only when the current terminal can answer prompts.
    if use_interactive_wizard:
        from logthread.cli.setup_wizard import run_setup_wizard

        target_path = project_path or Path.cwd()
        success = run_setup_wizard(target_path)

        if success:
            console.print("\n[dim]Now index your codebase with:[/dim] [cyan]logthread generate .[/cyan]")
            return
        else:
            console.print("\n[yellow]Falling back to manual configuration...[/yellow]\n")

    # Manual configuration (stdio MCP is the most compatible default for MCP clients)
    stdio_config = {
        "command": "logthread",
        "args": ["mcp"],
    }

    if project_path:
        stdio_config["args"].extend(["--path", str(project_path.absolute())])

    if claude or (not claude and not cursor):
        console.print("[bold]Claude Code[/bold]")
        console.print("Add to [cyan]~/Library/Application Support/Claude/claude_desktop_config.json[/cyan]:\n")
        console.print(json.dumps({"mcpServers": {"logthread": stdio_config}}, indent=2))
        console.print()

    if cursor or (not claude and not cursor):
        console.print("[bold]Cursor[/bold]")
        console.print("Add to [cyan]~/.cursor/mcp.json[/cyan]:\n")
        console.print(json.dumps({"mcpServers": {"logthread": stdio_config}}, indent=2))
        console.print()

    console.print("[dim]Then index your codebase with:[/dim] [cyan]logthread generate .[/cyan]")

@app.command()
def watch() -> None:
    """Watch mode — re-index on file changes."""
    repo_path = Path.cwd().resolve()

    migrate_legacy_storage(repo_path)
    db_path = get_db_path(repo_path)
    meta_path = get_project_meta_path(repo_path)

    storage = LadybugBackend()
    storage.initialize(db_path)

    if not meta_path.exists():
        console.print("[bold]Running initial index...[/bold]")
        _, result = run_pipeline(repo_path, storage)
        meta = _build_meta(result, repo_path)
        save_project_link(repo_path, meta)
        cleanup_legacy_files(repo_path)
        try:
            _register_in_global_registry(meta, repo_path)
        except Exception:
            logger.debug("Failed to register repo in global registry", exc_info=True)

    console.print(f"[bold]Watching[/bold] {repo_path} for changes (Ctrl+C to stop)")

    try:
        asyncio.run(watch_repo(repo_path, storage))
    except KeyboardInterrupt:
        console.print("\n[bold]Watch stopped.[/bold]")
    finally:
        storage.close()

@app.command()
def diff(
    branch_range: str = typer.Argument(..., help="Branch range for comparison (e.g. main..feature)."),
) -> None:
    """Structural branch comparison."""
    repo_path = Path.cwd().resolve()
    try:
        result = diff_branches(repo_path, branch_range)
    except (ValueError, RuntimeError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    console.print(format_diff(result))


@app.command()
def analyze_diff(
    target_branch: str = typer.Option(
        "main",
        "--target",
        "-t",
        help="Target branch to compare against (default: main).",
    ),
    staged: bool = typer.Option(
        False,
        "--staged",
        "-s",
        help="Analyze staged changes instead of unstaged.",
    ),
    unstaged: bool = typer.Option(
        False,
        "--unstaged",
        "-u",
        help="Analyze unstaged working directory changes only.",
    ),
    impact: bool = typer.Option(
        False,
        "--impact",
        "-i",
        help="Show downstream impact analysis for affected symbols.",
    ),
    depth: int = typer.Option(
        3,
        "--depth",
        "-d",
        help="Maximum depth for impact analysis (1-10).",
        min=1,
        max=10,
    ),
    show_tests: bool = typer.Option(
        False,
        "--tests",
        help="Show affected test files.",
    ),
    show_coupling: bool = typer.Option(
        False,
        "--coupling",
        help="Show files that are frequently changed together.",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        help="Show comprehensive analysis (impact + tests + coupling).",
    ),
) -> None:
    """Analyze git diff and show affected symbols in the knowledge graph.
    
    This command requires the repository to be a git repository.
    It compares your current changes against a target branch and shows
    which symbols in your indexed codebase are affected.
    
    Examples:
        logthread analyze-diff                    # Compare current branch against main
        logthread analyze-diff --unstaged         # Analyze only unstaged changes
        logthread analyze-diff --staged           # Analyze staged changes
        logthread analyze-diff --target develop   # Compare against develop branch
        logthread analyze-diff --impact           # Include downstream impact analysis
        logthread analyze-diff --full             # Comprehensive analysis
    """
    import subprocess
    from logthread.mcp.tools import handle_detect_changes, handle_diff_impact, handle_test_impact, handle_coupling
    
    repo_path = Path.cwd().resolve()
    
    # Check if we're in a git repository
    try:
        subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=repo_path,
            capture_output=True,
            check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        console.print("[red]Error:[/red] Not a git repository. This command requires git.")
        raise typer.Exit(code=1)
    
    # Determine what to diff
    if unstaged:
        # Get unstaged changes (working directory vs index)
        git_cmd = ["git", "diff"]
        comparison_desc = "unstaged changes"
    elif staged:
        # Get staged changes (index vs HEAD)
        git_cmd = ["git", "diff", "--staged"]
        comparison_desc = "staged changes"
    else:
        # Get all changes compared to target branch
        # Check if target branch exists
        try:
            subprocess.run(
                ["git", "rev-parse", "--verify", target_branch],
                cwd=repo_path,
                capture_output=True,
                check=True,
            )
        except subprocess.CalledProcessError:
            console.print(f"[red]Error:[/red] Target branch '{target_branch}' does not exist.")
            raise typer.Exit(code=1)
        
        git_cmd = ["git", "diff", target_branch]
        comparison_desc = f"changes against '{target_branch}'"
    
    # Get the git diff
    try:
        result = subprocess.run(
            git_cmd,
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        
        diff_output = result.stdout
        
        if not diff_output.strip():
            console.print(f"[yellow]No {comparison_desc} found.[/yellow]")
            return
        
    except subprocess.CalledProcessError as exc:
        console.print(f"[red]Error running git diff:[/red] {exc.stderr}")
        raise typer.Exit(code=1) from exc
    
    # Load storage
    try:
        storage = _load_storage(repo_path)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        console.print("\n[yellow]Hint:[/yellow] Run 'logthread generate .' first to index your codebase.")
        raise typer.Exit(code=1) from exc
    
    # Analyze the diff
    console.print(f"[cyan]Analyzing {comparison_desc}...[/cyan]\n")
    
    # Enable full analysis if --full flag is set
    if full:
        impact = True
        show_tests = True
        show_coupling = True
    
    if impact:
        # Use diff_impact for comprehensive analysis
        result_text = handle_diff_impact(storage, diff_output, depth)
        console.print(result_text)
    else:
        # Use detect_changes for basic symbol detection
        result_text = handle_detect_changes(storage, diff_output)
        console.print(result_text)
    
    # Show test impact if requested
    if show_tests:
        console.print("\n")
        console.print("[cyan]Analyzing test impact...[/cyan]\n")
        test_result = handle_test_impact(storage, diff_output, None)
        console.print(test_result)
    
    # Show coupling analysis if requested
    if show_coupling:
        console.print("\n")
        console.print("[cyan]Analyzing file coupling patterns...[/cyan]\n")
        
        # Get changed files from diff
        from logthread.mcp.tools import _parse_diff_files
        changed_files = _parse_diff_files(diff_output)
        
        if changed_files:
            # Show coupling for first few files
            for file_path in list(changed_files.keys())[:3]:
                try:
                    coupling_result = handle_coupling(storage, file_path, min_strength=0.3)
                    console.print(coupling_result)
                    console.print("")
                except Exception:
                    pass
            
            if len(changed_files) > 3:
                console.print(f"[dim]... and {len(changed_files) - 3} more files[/dim]\n")

@app.command()
def mcp(
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Path to the indexed repository."),
) -> None:
    """Start MCP server (stdio transport)."""
    if path:
        os.chdir(path.resolve())
    asyncio.run(mcp_main())



@app.command()
def ui(
    port: int = typer.Option(DEFAULT_PORT, "--port", "-p", help="Port to serve UI on."),
    direct: bool = typer.Option(False, "--direct", help="Force direct execution even if host is running."),
    no_open: bool = typer.Option(False, "--no-open", help="Don't auto-open browser."),
) -> None:
    """Launch the Log Thread Code Explorer (Web UI)."""
    import webbrowser

    repo_path = Path.cwd().resolve()

    # If not direct, try to see if a host is already running for this repo
    if not direct:
        live = _get_live_host_info(repo_path)
        if live:
            url = live["host_url"]
            console.print(f"[green]Connecting to running host at:[/green] {url}")
            if not no_open:
                webbrowser.open(url)
            return

    # Otherwise run shared host directly
    _run_shared_host(
        port=port,
        bind=DEFAULT_HOST,
        no_open=no_open,
        watch=True,
        dev=False,
        managed=False,
        open_browser=True,
        announce_ui=True,
        announce_mcp=True,
        expose_ui=True,
        already_running_message="[yellow]Log Thread host already running[/yellow] at {url}",
        ignore_running=direct,
    )


@app.command()
def host(
    port: int = typer.Option(DEFAULT_PORT, "--port", "-p", help="Port to serve UI and HTTP MCP on."),
    bind: str = typer.Option(DEFAULT_HOST, "--bind", help="Host interface to bind the shared host to."),
    no_open: bool = typer.Option(False, "--no-open", help="Don't auto-open browser."),
    watch: bool = typer.Option(True, "--watch/--no-watch", help="Enable file watching with auto-reindex."),
    dev: bool = typer.Option(False, "--dev", help="Proxy to Vite dev server for HMR."),
    managed: bool = typer.Option(False, "--managed", hidden=True),
) -> None:
    """Run the shared Log Thread host for UI and multi-session HTTP MCP clients."""
    _run_shared_host(
        port=port,
        bind=bind,
        no_open=no_open,
        watch=watch,
        dev=dev,
        managed=managed,
        open_browser=True,
        announce_ui=True,
        announce_mcp=True,
        expose_ui=not managed,
        already_running_message="[yellow]Log Thread host already running[/yellow] at {url}",
    )

@app.command()
def serve(
    watch: bool = typer.Option(False, "--watch", "-w", help="Enable file watching with auto-reindex."),
    path: Optional[Path] = typer.Option(None, "--path", "-p", help="Path to the indexed repository."),
) -> None:
    """Start MCP server, optionally with live file watching."""
    repo_path = (path or Path.cwd()).resolve()

    if path:
        os.chdir(repo_path)

    if not watch:
        asyncio.run(mcp_main())
        return
    lease_path: Path | None = None
    try:
        live_host = _ensure_host_running(
            repo_path,
            port=DEFAULT_MANAGED_PORT,
            watch=True,
            managed=True,
        )
        lease_path = _create_host_lease(repo_path, "mcp")
    except RuntimeError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    try:
        asyncio.run(_proxy_stdio_to_http_mcp(live_host["mcp_url"]))
    finally:
        _remove_host_lease(lease_path)


@app.command(hidden=True)
def mcp_call(
    tool_name: str = typer.Argument(help="MCP tool name to call."),
    args_json: str = typer.Argument(help="Tool arguments as JSON string."),
) -> None:
    """Call an MCP tool directly (used internally)."""
    import json as _json

    args = _json.loads(args_json)
    repo_path = Path.cwd()
    migrate_legacy_storage(repo_path)
    db_path = get_db_path(repo_path)

    if not db_path.exists():
        console.print("Workspace not indexed.", style="red")
        raise typer.Exit(code=1)

    storage = LadybugBackend()
    try:
        storage.initialize(db_path, read_only=True, max_retries=3, retry_delay=0.5)
    except RuntimeError:
        console.print("Database locked.", style="red")
        raise typer.Exit(code=1)

    try:
        from logthread.mcp.tools import (
            handle_call_path,
            handle_communities,
            handle_context,
            handle_coupling,
            handle_cycles,
            handle_cypher,
            handle_dead_code,
            handle_detect_changes,
            handle_explain,
            handle_file_context,
            handle_impact,
            handle_list_repos,
            handle_query,
            handle_review_risk,
            handle_test_impact,
        )

        handlers = {
            "logthread_query": handle_query,
            "logthread_context": handle_context,
            "logthread_impact": handle_impact,
            "logthread_cypher": handle_cypher,
            "logthread_explain": handle_explain,
            "logthread_communities": handle_communities,
            "logthread_file_context": handle_file_context,
            "logthread_coupling": handle_coupling,
            "logthread_cycles": handle_cycles,
            "logthread_dead_code": handle_dead_code,
            "logthread_call_path": handle_call_path,
            "logthread_list_repos": handle_list_repos,
            "logthread_detect_changes": handle_detect_changes,
            "logthread_review_risk": handle_review_risk,
            "logthread_test_impact": handle_test_impact,
        }

        handler = handlers.get(tool_name)
        if not handler:
            console.print(f"Unknown tool: {tool_name}", style="red")
            raise typer.Exit(code=1)

        result = handler(storage, **args)
        print(result)
    finally:
        storage.close()


if __name__ == "__main__":
    app()
