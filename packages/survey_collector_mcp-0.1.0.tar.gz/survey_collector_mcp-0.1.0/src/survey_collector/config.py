"""配置管理"""

from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """应用配置"""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
    )
    
    # HITL 平台配置
    hitl_service_url: str = "https://hitl.woa.com/api"
    hitl_default_chat_id: Optional[str] = None
    
    # LLM API 配置（用于智能追问生成）
    llm_api_base: str = "https://api.deepseek.com/v1"
    llm_api_key: Optional[str] = "sk-4f31e953ab624c9d86a9f7bc330a359c"
    llm_model: str = "deepseek-chat"
    
    # 企业微信 Webhook（备用）
    default_webhook_url: Optional[str] = None
    
    # 调查配置
    default_timeout: int = 600
    max_rounds: int = 5
    
    # HTTP 配置
    request_timeout: int = 30
    
    # 调试
    debug: bool = False
    log_level: str = "INFO"


# 全局配置实例
settings = Settings()
