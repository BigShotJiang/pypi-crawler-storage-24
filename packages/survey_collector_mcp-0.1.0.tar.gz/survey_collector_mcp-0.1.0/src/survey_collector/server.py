"""MCP 服务入口"""

import argparse
import asyncio
import json
import logging
import os
from typing import List, Optional
from fastmcp import FastMCP

from .config import settings
from .models import SurveyResult
from .tools import collect_survey, send_survey_message, evaluate_criteria, generate_summary

# 配置日志
logging.basicConfig(
    level=logging.DEBUG if settings.debug else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# 创建 MCP 服务
mcp = FastMCP("survey-collector")


@mcp.tool()
async def collect_survey_info(
    chat_id: str,
    members: str,
    question: str,
    criteria: str = "all_replied",
    follow_up_message: str = "",
    follow_up_rule: str = "",
    max_rounds: int = 5,
    timeout_per_round: int = 600,
) -> str:
    """
    执行完整调查流程：发送问题 → 等待回复 → 判断标准评估 → 多轮追问（如需）→ 生成汇总报告
    
    ⚠️ 调用前必须先向用户获取以下必填信息：
    1. chat_id: 发送到哪个群聊？
    2. members: 群成员列表？（逗号分隔）
    3. question: 要发送什么问题？
    4. criteria: 判断标准是什么？
    
    可选信息：
    5. follow_up_rule: 追问规则（如：每次日期往后推一天）
    
    Args:
        chat_id: HITL chat_id（群聊标识）
        members: 群成员名称列表，用逗号分隔（如 "张三,李四,王五"）
        question: 调查问题
        criteria: 判断标准，支持:
            - "all_replied": 所有成员回复（默认）
            - "majority_replied": 超过半数成员回复
            - "majority_agree": 超过半数同意
            - "keyword:关键词": 回复包含指定关键词
            - 自定义 Python 表达式（如 "reply_count >= 3"）
        follow_up_message: 追问消息模板（可选，如未设置则使用默认追问）
            - 支持占位符：{pending_members} 会被替换为未回复成员列表
            - 示例："请 {pending_members} 尽快确认，谢谢！"
        follow_up_rule: 追问规则（自然语言描述，可选）
            - 示例: "如果对方说没时间，每次追问日期往后推一天，格式：周X上午有没有时间？"
            - 示例: "如果回复含'可能'，追问需要什么支持"
            - 注意: 使用此功能需要配置 LLM_API_KEY
        max_rounds: 最大追问轮数（默认 5）
        timeout_per_round: 每轮超时时间（秒，默认 600）
    
    Returns:
        JSON 格式的调查结果，包含状态、每轮回复、Markdown 汇总报告
    
    Example:
        collect_survey_info(
            chat_id="wrkSFfCgAApY6zEM8Mfy29Y6dolLJydg",
            members="张三,李四,王五",
            question="周一上午有没有时间打球？",
            criteria="all_replied",
            follow_up_rule="如果对方说没时间，每次追问日期往后推一天，格式：周X上午有没有时间打球？"
        )
    """
    # 解析成员列表
    member_list = [m.strip() for m in members.split(",") if m.strip()]
    
    if not member_list:
        return json.dumps({"error": "成员列表不能为空"}, ensure_ascii=False)
    
    # 执行调查
    result = await collect_survey(
        chat_id=chat_id,
        members=member_list,
        question=question,
        criteria=criteria,
        follow_up_message=follow_up_message if follow_up_message else None,
        follow_up_rule=follow_up_rule if follow_up_rule else None,
        max_rounds=max_rounds,
        timeout_per_round=timeout_per_round,
    )
    
    # 返回 JSON 结果
    return result.model_dump_json(indent=2)


@mcp.tool()
async def send_and_collect_replies(
    chat_id: str,
    message: str,
    members: str,
    timeout: int = 600,
) -> str:
    """
    发送调查消息并等待回复（单轮，不执行判断循环）
    
    Args:
        chat_id: HITL chat_id
        message: 消息内容
        members: 群成员名称列表，用逗号分隔
        timeout: 超时时间（秒）
    
    Returns:
        JSON 格式的回复列表
    
    Example:
        send_and_collect_replies(
            chat_id="wrkSFfCgAApY6zEM8Mfy29Y6dolLJydg",
            message="请回复您的意见",
            members="张三,李四"
        )
    """
    member_list = [m.strip() for m in members.split(",") if m.strip()]
    
    replies = await send_survey_message(
        chat_id=chat_id,
        message=message,
        members=member_list,
        timeout=timeout,
    )
    
    return json.dumps(
        [r.model_dump() for r in replies],
        indent=2,
        ensure_ascii=False,
    )


@mcp.tool()
def check_criteria(
    criteria: str,
    members: str,
    replies_json: str,
) -> str:
    """
    测试判断标准（用于调试和验证）
    
    Args:
        criteria: 判断标准
        members: 群成员名称列表，用逗号分隔
        replies_json: 回复列表 JSON（从 send_and_collect_replies 获取）
    
    Returns:
        评估结果 JSON
    
    Example:
        check_criteria(
            criteria="all_replied",
            members="张三,李四",
            replies_json='[{"member":"张三","content":"同意","round":1}]'
        )
    """
    from .models import Reply
    
    member_list = [m.strip() for m in members.split(",") if m.strip()]
    
    try:
        replies_data = json.loads(replies_json)
        replies = [Reply(**r) for r in replies_data]
    except Exception as e:
        return json.dumps({"error": f"解析回复失败: {str(e)}"}, ensure_ascii=False)
    
    met, reason = evaluate_criteria(criteria, member_list, replies)
    
    return json.dumps(
        {
            "criteria_met": met,
            "reason": reason,
            "replied_count": len(set(r.member for r in replies)),
            "total_members": len(member_list),
        },
        indent=2,
        ensure_ascii=False,
    )


@mcp.tool()
def generate_summary_report(
    survey_result_json: str,
) -> str:
    """
    根据调查结果生成 Markdown 汇总报告
    
    Args:
        survey_result_json: 调查结果 JSON（从 collect_survey_info 获取）
    
    Returns:
        Markdown 格式的汇总报告
    
    Example:
        generate_summary_report(
            survey_result_json='{"status":"success","rounds":[...],"config":{...}}'
        )
    """
    from .models import SurveyResult
    
    try:
        result_data = json.loads(survey_result_json)
        result = SurveyResult(**result_data)
    except Exception as e:
        return f"解析调查结果失败: {str(e)}"
    
    return generate_summary(result)


def main():
    """启动 MCP 服务"""
    parser = argparse.ArgumentParser(description="Survey Collector MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse", "streamable-http"],
        default="stdio",
        help="传输协议: stdio (本地), sse (远程), streamable-http (远程HTTP)"
    )
    parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="绑定主机地址 (默认: 0.0.0.0，允许外部访问)"
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8001,
        help="端口号 (默认: 8001)"
    )
    
    args = parser.parse_args()
    
    if args.transport == "stdio":
        logger.info("启动 MCP 服务 (stdio 模式)")
        mcp.run(transport="stdio")
    else:
        logger.info(f"启动 MCP 服务 ({args.transport} 模式) - {args.host}:{args.port}")
        print(f"\n🚀 Survey Collector MCP Server 启动成功!")
        print(f"   传输协议: {args.transport}")
        print(f"   地址: http://{args.host}:{args.port}")
        print(f"\n📋 同事配置方法:")
        print(f'   在 mcp.json 中添加:')
        print(f'   {{')
        print(f'     "mcpServers": {{')
        print(f'       "survey-collector": {{')
        print(f'         "url": "http://<服务器IP>:{args.port}/sse"')
        print(f'       }}')
        print(f'     }}')
        print(f'   }}')
        print()
        mcp.run(transport=args.transport, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
