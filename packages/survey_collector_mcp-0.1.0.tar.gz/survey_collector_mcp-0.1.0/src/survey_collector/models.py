"""数据模型定义"""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field, ConfigDict
from enum import Enum


class SurveyStatus(str, Enum):
    """调查状态"""
    SUCCESS = "success"           # 成功完成
    TIMEOUT = "timeout"           # 超时
    MAX_ROUNDS = "max_rounds"     # 达到最大轮数
    CANCELLED = "cancelled"       # 已取消


class CriteriaType(str, Enum):
    """判断标准类型"""
    ALL_REPLIED = "all_replied"               # 全员回复
    MAJORITY_AGREE = "majority_agree"         # 多数同意
    MAJORITY_REPLIED = "majority_replied"     # 多数回复
    KEYWORD_MATCH = "keyword_match"           # 关键词匹配
    CUSTOM = "custom"                         # 自定义表达式


class Reply(BaseModel):
    """单条回复"""
    model_config = ConfigDict()
    
    member: str = Field(..., description="回复者名称")
    content: str = Field(..., description="回复内容")
    timestamp: datetime = Field(default_factory=datetime.now, description="回复时间")
    round: int = Field(..., description="所属轮次")


class SurveyConfig(BaseModel):
    """调查配置"""
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "chat_id": "wrkSFfCgAApY6zEM8Mfy29Y6dolLJydg",
                "webhook_key": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
                "members": ["张三", "李四", "王五"],
                "question": "请确认本周 Sprint 完成情况？",
                "follow_up_message": "请未回复的同事尽快确认，谢谢！",
                "criteria": "all_replied",
                "max_rounds": 5,
                "timeout_per_round": 600
            }
        }
    )
    
    chat_id: str = Field(..., description="HITL chat_id")
    webhook_key: Optional[str] = Field(None, description="群机器人 webhook key")
    members: List[str] = Field(..., description="群成员名称列表")
    question: str = Field(..., description="调查问题")
    follow_up_message: Optional[str] = Field(
        None, 
        description="追问消息模板（可选，如未设置则使用默认追问）"
    )
    follow_up_rule: Optional[str] = Field(
        None, 
        description="追问规则（自然语言描述，如：如果对方说没时间，每次追问日期往后推一天）"
    )
    criteria: str = Field(default="all_replied", description="判断标准")
    max_rounds: int = Field(default=5, description="最大追问轮数")
    timeout_per_round: int = Field(default=600, description="每轮超时时间（秒）")


class RoundResult(BaseModel):
    """单轮结果"""
    round_number: int = Field(..., description="轮次")
    question_sent: str = Field(..., description="发送的问题")
    replies: List[Reply] = Field(default_factory=list, description="回复列表")
    members_replied: List[str] = Field(default_factory=list, description="已回复成员")
    members_pending: List[str] = Field(default_factory=list, description="待回复成员")
    criteria_met: bool = Field(False, description="是否达标")
    criteria_reason: Optional[str] = Field(None, description="判断原因")


class SurveyResult(BaseModel):
    """调查结果"""
    model_config = ConfigDict()
    
    status: SurveyStatus = Field(..., description="调查状态")
    config: SurveyConfig = Field(..., description="原始配置")
    rounds: List[RoundResult] = Field(default_factory=list, description="每轮结果")
    total_replies: int = Field(0, description="总回复数")
    summary: str = Field("", description="Markdown 汇总报告")


class HITLRequest(BaseModel):
    """HITL API 请求"""
    message: str = Field(..., description="消息内容")
    chat_id: str = Field(..., description="Chat ID")
    project_name: Optional[str] = Field(None, description="项目名称")
    image_paths: Optional[List[str]] = Field(None, description="图片路径")
    timeout: int = Field(default=1200, description="超时时间（秒）")


class HITLReply(BaseModel):
    """HITL API 回复"""
    msg_type: str = Field(..., description="消息类型")
    content: str = Field(..., description="回复内容")
    from_user: dict = Field(..., description="发送者信息")
    timestamp: str = Field(..., description="时间戳")


class HITLResponse(BaseModel):
    """HITL API 响应"""
    status: str = Field(..., description="状态: success/timeout/error")
    replies: List[HITLReply] = Field(default_factory=list, description="回复列表")
    message: Optional[str] = Field(None, description="描述信息")
