"""调查收集工具 - 核心逻辑"""

import asyncio
import logging
from datetime import datetime
from typing import List, Optional
import httpx

from ..config import settings
from ..models import (
    SurveyConfig,
    SurveyResult,
    SurveyStatus,
    RoundResult,
    Reply,
    HITLRequest,
    HITLResponse,
    HITLReply,
)
from .criteria import CriteriaEvaluator
from .summary import generate_summary
from .llm import generate_follow_up_question

# 配置日志
logger = logging.getLogger(__name__)


class HITLClient:
    """HITL API 客户端"""
    
    def __init__(self, service_url: str = None):
        self.service_url = (service_url or settings.hitl_service_url).rstrip('/')
        self.timeout = settings.request_timeout
        self.poll_interval = 2  # 轮询间隔（秒）
    
    async def send_and_wait_reply(
        self,
        chat_id: str,
        message: str,
        timeout: int = 1200,
        project_name: Optional[str] = None,
    ) -> HITLResponse:
        """
        发送消息并等待回复（使用轮询模式）
        
        Args:
            chat_id: Chat ID
            message: 消息内容
            timeout: 超时时间（秒）
            project_name: 项目名称
            
        Returns:
            HITL 响应
        """
        logger.info(f"[HITL] 开始发送消息到群聊 {chat_id[:20]}..., 超时: {timeout}秒")
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                # 1. 发送消息
                send_url = f"{self.service_url}/send"
                send_payload = {
                    "chat_id": chat_id,
                    "message": message,
                    "chat_type": "group",
                    "wait_reply": True,
                    "timeout": timeout,
                }
                if project_name:
                    send_payload["project_name"] = project_name
                
                logger.info(f"[HITL] 发送消息: {message[:50]}...")
                send_response = await client.post(send_url, json=send_payload)
                send_response.raise_for_status()
                send_data = send_response.json()
                
                # 兼容两种响应格式：{"status": "success"} 或 {"success": true}
                is_success = send_data.get("status") == "success" or send_data.get("success") == True
                if not is_success:
                    logger.error(f"[HITL] 发送失败: {send_data}")
                    return HITLResponse(
                        status="error",
                        message=send_data.get("message", "发送消息失败")
                    )
                
                logger.info(f"[HITL] 发送成功: {send_data}")
                
                session_id = send_data.get("session_id")
                if not session_id:
                    logger.error("[HITL] 未获取到 session_id")
                    return HITLResponse(
                        status="error",
                        message="未获取到 session_id"
                    )
                
                logger.info(f"[HITL] 消息发送成功, session_id: {session_id}, 开始轮询等待回复...")
                
                # 2. 轮询获取回复
                poll_url = f"{self.service_url}/poll/{session_id}"
                start_time = asyncio.get_event_loop().time()
                poll_count = 0
                
                while True:
                    elapsed = asyncio.get_event_loop().time() - start_time
                    poll_count += 1
                    
                    if elapsed >= timeout:
                        # 标记超时
                        logger.warning(f"[HITL] 轮询超时 (已轮询 {poll_count} 次, 耗时 {elapsed:.1f}秒)")
                        await client.post(f"{self.service_url}/session/{session_id}/timeout")
                        return HITLResponse(status="timeout", message="等待回复超时")
                    
                    poll_response = await client.get(poll_url)
                    if poll_response.status_code == 404:
                        if poll_count % 10 == 0:  # 每10次轮询打印一次日志
                            logger.debug(f"[HITL] 轮询中... (第{poll_count}次, 已等待 {elapsed:.1f}秒)")
                        await asyncio.sleep(self.poll_interval)
                        continue
                    
                    poll_response.raise_for_status()
                    poll_data = poll_response.json()
                    
                    # 检查是否有回复
                    has_reply = poll_data.get("has_reply")
                    replies_data = poll_data.get("replies", [])
                    
                    if has_reply and replies_data:
                        replies = [
                            HITLReply(
                                msg_type=r.get("msg_type", "text"),
                                content=r.get("content", ""),
                                from_user=r.get("from_user", {}),
                                timestamp=r.get("timestamp"),
                            )
                            for r in replies_data
                        ]
                        logger.info(f"[HITL] 收到 {len(replies)} 条回复 (轮询 {poll_count} 次, 耗时 {elapsed:.1f}秒)")
                        for r in replies:
                            logger.info(f"[HITL] 回复来自 {r.from_user.get('name', r.from_user.get('alias', '未知'))}: {r.content[:50]}...")
                        return HITLResponse(
                            status="success",
                            message="收到回复",
                            replies=replies
                        )
                    
                    # 如果 has_reply=True 但 replies 为空，记录警告
                    if has_reply and not replies_data:
                        logger.warning(f"[HITL] has_reply=True 但 replies 为空，继续轮询...")
                    
                    await asyncio.sleep(self.poll_interval)
                    
        except httpx.TimeoutException:
            logger.error("[HITL] HTTP 请求超时")
            return HITLResponse(status="timeout", message="请求超时")
        except Exception as e:
            logger.error(f"[HITL] 发生异常: {e}", exc_info=True)
            return HITLResponse(status="error", message=str(e))


class SurveyCollector:
    """调查收集器"""
    
    def __init__(self, config: SurveyConfig):
        """初始化收集器"""
        self.config = config
        self.hitl_client = HITLClient()
        self.evaluator = CriteriaEvaluator(config.criteria, config.members)
        self.result = SurveyResult(
            status=SurveyStatus.SUCCESS,
            config=config,
        )
    
    async def collect(self) -> SurveyResult:
        """
        执行完整调查流程
        
        Returns:
            调查结果
        """
        logger.info(f"[调查] 开始调查，问题: {self.config.question}")
        logger.info(f"[调查] 目标成员: {', '.join(self.config.members)}")
        logger.info(f"[调查] 判断标准: {self.config.criteria}")
        if self.config.follow_up_rule:
            logger.info(f"[调查] 追问规则: {self.config.follow_up_rule}")
        elif self.config.follow_up_message:
            logger.info(f"[调查] 追问模板: {self.config.follow_up_message}")
        
        round_number = 0
        
        while round_number < self.config.max_rounds:
            round_number += 1
            
            # 构建问题
            question = await self._build_question(round_number)
            logger.info(f"[调查] 第 {round_number} 轮问题: {question[:100]}...")
            
            # 发送并等待回复
            round_result = await self._execute_round(round_number, question)
            self.result.rounds.append(round_result)
            
            # 更新统计
            self.result.total_replies += len(round_result.replies)
            
            # 记录本轮结果
            logger.info(f"[调查] 第 {round_number} 轮结果: 回复 {len(round_result.replies)} 条, 达标: {round_result.criteria_met}")
            if round_result.replies:
                for r in round_result.replies:
                    logger.info(f"[调查]   - {r.member}: {r.content}")
            
            # 检查是否达标
            if round_result.criteria_met:
                logger.info(f"[调查] 判断标准已达标: {round_result.criteria_reason}")
                self.result.status = SurveyStatus.SUCCESS
                break
            
            # 检查是否达到最大轮数
            if round_number >= self.config.max_rounds:
                logger.warning(f"[调查] 达到最大轮数 {self.config.max_rounds}")
                self.result.status = SurveyStatus.MAX_ROUNDS
                break
        else:
            self.result.status = SurveyStatus.MAX_ROUNDS
        
        # 生成汇总报告
        self.result.summary = generate_summary(self.result)
        
        return self.result
    
    async def _build_question(self, round_number: int) -> str:
        """
        构建问题消息
        
        Args:
            round_number: 当前轮次
            
        Returns:
            问题消息
        """
        if round_number == 1:
            # 第一轮：原始问题 + @所有成员
            mentions = " ".join([f"@{m}" for m in self.config.members])
            return f"{self.config.question}\n\n{mentions}"
        else:
            # 后续轮：按优先级选择追问方式
            pending = self.evaluator.get_pending_members(
                [r for rd in self.result.rounds for r in rd.replies]
            )
            mentions = " ".join([f"@{m}" for m in pending])
            
            # 优先级1：使用追问规则（LLM 动态生成）
            if self.config.follow_up_rule:
                # 获取前一轮回复
                prev_round = self.result.rounds[-1]
                previous_replies = [
                    {"member": r.member, "content": r.content}
                    for r in prev_round.replies
                ]
                
                logger.info(f"[调查] 使用追问规则生成第 {round_number} 轮问题...")
                # 调用 LLM 生成追问
                follow_up = await generate_follow_up_question(
                    original_question=self.config.question,
                    follow_up_rule=self.config.follow_up_rule,
                    previous_replies=previous_replies,
                    pending_members=pending,
                    round_number=round_number,
                )
                logger.info(f"[调查] LLM 生成的追问: {follow_up}")
                return f"{follow_up}\n\n{mentions}"
            
            # 优先级2：使用固定追问消息模板
            elif self.config.follow_up_message:
                # 替换占位符
                message = self.config.follow_up_message.replace(
                    "{pending_members}", "、".join(pending)
                )
                return f"{message}\n\n{mentions}"
            
            # 优先级3：默认追问
            else:
                return f"【追问】请尚未回复的成员尽快回复:\n\n{mentions}"
    
    async def _execute_round(self, round_number: int, question: str) -> RoundResult:
        """
        执行单轮调查
        
        Args:
            round_number: 轮次
            question: 问题
            
        Returns:
            轮次结果
        """
        round_result = RoundResult(
            round_number=round_number,
            question_sent=question,
        )
        
        # 发送消息并等待回复
        response = await self.hitl_client.send_and_wait_reply(
            chat_id=self.config.chat_id,
            message=question,
            timeout=self.config.timeout_per_round,
            project_name=f"survey_round_{round_number}",
        )
        
        logger.info(f"[调查] 第 {round_number} 轮 HITL 响应状态: {response.status}")
        
        if response.status == "timeout":
            logger.warning(f"[调查] 第 {round_number} 轮等待超时，未收到回复")
        elif response.status == "error":
            logger.error(f"[调查] 第 {round_number} 轮发生错误: {response.message}")
        elif response.status == "success" and response.replies:
            # 解析回复
            for hitl_reply in response.replies:
                reply = Reply(
                    member=hitl_reply.from_user.get("name", hitl_reply.from_user.get("alias", "未知")),
                    content=hitl_reply.content,
                    timestamp=datetime.now(),
                    round=round_number,
                )
                round_result.replies.append(reply)
                logger.info(f"[调查] 收到回复: {reply.member} - {reply.content}")
        
        # 更新成员状态
        replied_members = set(r.member for r in round_result.replies)
        round_result.members_replied = list(replied_members & set(self.config.members))
        round_result.members_pending = [m for m in self.config.members if m not in replied_members]
        
        # 评估判断标准
        all_replies = [r for rd in self.result.rounds for r in rd.replies] + round_result.replies
        round_result.criteria_met, round_result.criteria_reason = self.evaluator.evaluate(all_replies)
        
        return round_result


async def collect_survey(
    chat_id: str,
    members: List[str],
    question: str,
    criteria: str = "all_replied",
    follow_up_message: Optional[str] = None,
    follow_up_rule: Optional[str] = None,
    webhook_key: Optional[str] = None,
    max_rounds: int = 5,
    timeout_per_round: int = 600,
) -> SurveyResult:
    """
    执行完整调查的便捷函数
    
    Args:
        chat_id: HITL chat_id
        members: 群成员名称列表
        question: 调查问题
        criteria: 判断标准
        follow_up_message: 追问消息模板（可选）
        follow_up_rule: 追问规则（自然语言，可选）
        webhook_key: Webhook Key（可选）
        max_rounds: 最大轮数
        timeout_per_round: 每轮超时时间
        
    Returns:
        调查结果
    """
    config = SurveyConfig(
        chat_id=chat_id,
        members=members,
        question=question,
        criteria=criteria,
        follow_up_message=follow_up_message,
        follow_up_rule=follow_up_rule,
        webhook_key=webhook_key,
        max_rounds=max_rounds,
        timeout_per_round=timeout_per_round,
    )
    
    collector = SurveyCollector(config)
    return await collector.collect()


async def send_survey_message(
    chat_id: str,
    message: str,
    members: List[str],
    timeout: int = 600,
) -> List[Reply]:
    """
    仅发送调查消息并等待回复（不执行判断循环）
    
    Args:
        chat_id: Chat ID
        message: 消息内容
        members: 目标成员（用于过滤回复）
        timeout: 超时时间
        
    Returns:
        回复列表
    """
    # 构建 @成员 的消息
    mentions = " ".join([f"@{m}" for m in members])
    full_message = f"{message}\n\n{mentions}"
    
    # 发送并等待回复
    client = HITLClient()
    response = await client.send_and_wait_reply(
        chat_id=chat_id,
        message=full_message,
        timeout=timeout,
    )
    
    # 解析回复
    replies = []
    if response.status == "success" and response.replies:
        for hitl_reply in response.replies:
            reply = Reply(
                member=hitl_reply.from_user.get("name", hitl_reply.from_user.get("alias", "未知")),
                content=hitl_reply.content,
                timestamp=datetime.now(),
                round=1,
            )
            replies.append(reply)
    
    return replies
