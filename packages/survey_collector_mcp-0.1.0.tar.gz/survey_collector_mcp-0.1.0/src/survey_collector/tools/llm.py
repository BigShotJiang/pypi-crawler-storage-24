"""LLM 调用工具 - 智能追问生成"""

import logging
from typing import List, Optional
import httpx

from ..config import settings

# 配置日志
logger = logging.getLogger(__name__)


async def generate_follow_up_question(
    original_question: str,
    follow_up_rule: str,
    previous_replies: List[dict],
    pending_members: List[str],
    round_number: int,
) -> str:
    """
    根据规则和前一轮回复，生成下一轮追问
    
    Args:
        original_question: 原始问题
        follow_up_rule: 追问规则（自然语言）
        previous_replies: 前一轮回复列表 [{"member": "张三", "content": "周一没时间"}]
        pending_members: 待回复成员
        round_number: 当前轮次
        
    Returns:
        生成的追问内容
    """
    logger.info(f"[LLM] 开始生成第 {round_number} 轮追问")
    logger.info(f"[LLM] 追问规则: {follow_up_rule}")
    logger.info(f"[LLM] 前一轮回复: {previous_replies}")
    logger.info(f"[LLM] 待回复成员: {pending_members}")
    
    # 格式化回复信息
    replies_text = ""
    if previous_replies:
        replies_text = "\n".join([
            f"- {r['member']}: {r['content']}"
            for r in previous_replies
        ])
    
    pending_text = "、".join(pending_members) if pending_members else "无"
    
    # 构建提示词
    prompt = f"""你是一个调查助手。根据以下信息生成下一轮追问。

## 原始问题
{original_question}

## 追问规则
{follow_up_rule}

## 前一轮收到的回复
{replies_text if replies_text else "（暂无回复）"}

## 待回复成员
{pending_text}

## 当前轮次
第{round_number}轮追问

## 任务
请根据追问规则和前一轮回复情况，生成下一轮追问内容。
要求：
1. 追问内容要针对待回复成员
2. 按照追问规则调整问题内容
3. 语气礼貌但明确
4. 只输出追问内容，不要其他解释

追问内容："""

    # 检查是否配置了 LLM
    if not settings.llm_api_key:
        logger.warning("[LLM] 未配置 LLM API Key，使用默认追问")
        return f"请 {pending_text} 尽快回复，谢谢！"
    
    try:
        logger.info(f"[LLM] 调用 {settings.llm_model} 模型...")
        # 调用 LLM
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                f"{settings.llm_api_base}/chat/completions",
                headers={"Authorization": f"Bearer {settings.llm_api_key}"},
                json={
                    "model": settings.llm_model,
                    "messages": [{"role": "user", "content": prompt}],
                    "temperature": 0.7,
                    "max_tokens": 500,
                },
            )
            response.raise_for_status()
            result = response.json()
            content = result["choices"][0]["message"]["content"].strip()
            logger.info(f"[LLM] 生成成功: {content}")
            return content
    except Exception as e:
        logger.error(f"[LLM] 调用失败: {e}", exc_info=True)
        return f"请 {pending_text} 尽快回复，谢谢！（追问生成失败: {str(e)}）"


def format_replies_for_display(replies: List[dict]) -> str:
    """格式化回复用于显示"""
    if not replies:
        return "暂无回复"
    return "\n".join([f"- {r['member']}: {r['content']}" for r in replies])
