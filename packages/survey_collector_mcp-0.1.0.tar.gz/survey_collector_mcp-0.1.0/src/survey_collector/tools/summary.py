"""Markdown 汇总报告生成"""

from datetime import datetime
from typing import List, Optional
from ..models import Reply, RoundResult, SurveyResult, SurveyConfig


class SummaryGenerator:
    """Markdown 汇总生成器"""
    
    def __init__(self, config: SurveyConfig):
        """初始化生成器"""
        self.config = config
    
    def generate(self, result: SurveyResult) -> str:
        """
        生成完整的 Markdown 汇总报告
        
        Args:
            result: 调查结果
            
        Returns:
            Markdown 格式的汇总报告
        """
        sections = [
            self._generate_header(result),
            self._generate_overview(result),
            self._generate_rounds_table(result),
            self._generate_statistics(result),
            self._generate_footer(result),
        ]
        
        return "\n\n".join(sections)
    
    def _generate_header(self, result: SurveyResult) -> str:
        """生成标题"""
        status_emoji = {
            "success": "✅",
            "timeout": "⏰",
            "max_rounds": "🔄",
            "cancelled": "❌",
        }
        emoji = status_emoji.get(result.status.value, "📋")
        return f"# {emoji} 调查结果汇总"
    
    def _generate_overview(self, result: SurveyResult) -> str:
        """生成概览"""
        lines = [
            "## 📊 基本信息",
            "",
            f"- **调查问题**: {result.config.question}",
            f"- **目标成员**: {', '.join(result.config.members)}",
            f"- **判断标准**: {result.config.criteria}",
            f"- **调查状态**: {result.status.value}",
            f"- **总轮数**: {len(result.rounds)}",
            f"- **总回复数**: {result.total_replies}",
        ]
        return "\n".join(lines)
    
    def _generate_rounds_table(self, result: SurveyResult) -> str:
        """生成每轮回复表格"""
        lines = [
            "## 📝 详细回复",
            "",
        ]
        
        for round_result in result.rounds:
            lines.append(f"### 第 {round_result.round_number} 轮")
            lines.append("")
            lines.append(f"**问题**: {round_result.question_sent}")
            lines.append("")
            
            if round_result.replies:
                lines.append("| 成员 | 回复内容 | 回复时间 |")
                lines.append("|------|----------|----------|")
                for reply in round_result.replies:
                    time_str = reply.timestamp.strftime("%H:%M:%S")
                    lines.append(f"| {reply.member} | {reply.content} | {time_str} |")
            else:
                lines.append("*暂无回复*")
            
            lines.append("")
            
            # 状态信息
            if round_result.criteria_met:
                lines.append(f"✅ **达标**: {round_result.criteria_reason}")
            else:
                lines.append(f"⏳ **未达标**: {round_result.criteria_reason}")
                if round_result.members_pending:
                    lines.append(f"   - 待回复: {', '.join(round_result.members_pending)}")
            
            lines.append("")
        
        return "\n".join(lines)
    
    def _generate_statistics(self, result: SurveyResult) -> str:
        """生成统计信息"""
        # 统计每个成员的回复次数
        member_reply_count = {}
        member_replies = {}
        
        for round_result in result.rounds:
            for reply in round_result.replies:
                member = reply.member
                member_reply_count[member] = member_reply_count.get(member, 0) + 1
                if member not in member_replies:
                    member_replies[member] = []
                member_replies[member].append(reply.content)
        
        lines = [
            "## 📈 统计信息",
            "",
            "### 成员回复统计",
            "",
            "| 成员 | 回复次数 | 回复内容汇总 |",
            "|------|----------|--------------|",
        ]
        
        for member in result.config.members:
            count = member_reply_count.get(member, 0)
            replies_summary = " | ".join(member_replies.get(member, [])) if count > 0 else "未回复"
            lines.append(f"| {member} | {count} | {replies_summary} |")
        
        # 回复率
        replied_members = len([m for m in result.config.members if m in member_reply_count])
        reply_rate = replied_members / len(result.config.members) * 100 if result.config.members else 0
        
        lines.extend([
            "",
            f"**回复率**: {reply_rate:.1f}% ({replied_members}/{len(result.config.members)})",
        ])
        
        return "\n".join(lines)
    
    def _generate_footer(self, result: SurveyResult) -> str:
        """生成页脚"""
        return f"""
---
*报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""


def generate_summary(result: SurveyResult) -> str:
    """
    生成 Markdown 汇总报告的便捷函数
    
    Args:
        result: 调查结果
        
    Returns:
        Markdown 格式的汇总报告
    """
    generator = SummaryGenerator(result.config)
    return generator.generate(result)
