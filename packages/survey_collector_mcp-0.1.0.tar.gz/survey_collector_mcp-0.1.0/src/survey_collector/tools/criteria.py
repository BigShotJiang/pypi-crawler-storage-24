"""判断标准评估引擎"""

import re
from typing import List, Optional, Tuple
from ..models import Reply, CriteriaType


class CriteriaEvaluator:
    """判断标准评估器"""
    
    # 预设标准类型
    PRESET_CRITERIA = {
        "all_replied": "所有指定成员都已回复",
        "majority_replied": "超过半数成员已回复",
        "majority_agree": "超过半数回复包含同意关键词",
        "all_agree": "所有回复包含同意关键词",
    }
    
    # 同意关键词
    AGREE_KEYWORDS = ["同意", "确认", "好的", "OK", "ok", "Yes", "yes", "通过", "赞成", "没问题"]
    
    # 拒绝关键词
    REJECT_KEYWORDS = ["拒绝", "反对", "不行", "No", "no", "不同意", "否决"]
    
    def __init__(self, criteria: str, members: List[str]):
        """
        初始化评估器
        
        Args:
            criteria: 判断标准（预设类型或自定义表达式）
            members: 目标成员列表
        """
        self.criteria = criteria
        self.members = members
        self.criteria_type = self._parse_criteria_type(criteria)
    
    def _parse_criteria_type(self, criteria: str) -> CriteriaType:
        """解析判断标准类型"""
        if criteria in self.PRESET_CRITERIA:
            mapping = {
                "all_replied": CriteriaType.ALL_REPLIED,
                "majority_replied": CriteriaType.MAJORITY_REPLIED,
                "majority_agree": CriteriaType.MAJORITY_AGREE,
                "all_agree": CriteriaType.KEYWORD_MATCH,
            }
            return mapping.get(criteria, CriteriaType.CUSTOM)
        elif criteria.startswith("keyword:"):
            return CriteriaType.KEYWORD_MATCH
        else:
            return CriteriaType.CUSTOM
    
    def evaluate(self, replies: List[Reply]) -> Tuple[bool, str]:
        """
        评估是否达到判断标准
        
        Args:
            replies: 回复列表
            
        Returns:
            (是否达标, 判断原因)
        """
        if self.criteria_type == CriteriaType.ALL_REPLIED:
            return self._evaluate_all_replied(replies)
        elif self.criteria_type == CriteriaType.MAJORITY_REPLIED:
            return self._evaluate_majority_replied(replies)
        elif self.criteria_type == CriteriaType.MAJORITY_AGREE:
            return self._evaluate_majority_agree(replies)
        elif self.criteria_type == CriteriaType.KEYWORD_MATCH:
            return self._evaluate_keyword_match(replies)
        else:
            return self._evaluate_custom(replies)
    
    def _evaluate_all_replied(self, replies: List[Reply]) -> Tuple[bool, str]:
        """评估是否全员回复"""
        replied_members = set(r.member for r in replies)
        target_members = set(self.members)
        
        if replied_members >= target_members:
            return True, f"所有成员已回复: {', '.join(replied_members)}"
        else:
            pending = target_members - replied_members
            return False, f"待回复成员: {', '.join(pending)}"
    
    def _evaluate_majority_replied(self, replies: List[Reply]) -> Tuple[bool, str]:
        """评估是否多数回复"""
        replied_members = set(r.member for r in replies)
        replied_count = len(replied_members & set(self.members))
        majority = len(self.members) / 2
        
        if replied_count > majority:
            return True, f"多数成员已回复: {replied_count}/{len(self.members)}"
        else:
            return False, f"回复人数不足: {replied_count}/{len(self.members)}, 需要超过 {int(majority)} 人"
    
    def _evaluate_majority_agree(self, replies: List[Reply]) -> Tuple[bool, str]:
        """评估是否多数同意"""
        agree_count = 0
        for reply in replies:
            if any(kw in reply.content for kw in self.AGREE_KEYWORDS):
                agree_count += 1
        
        majority = len(self.members) / 2
        
        if agree_count > majority:
            return True, f"多数成员同意: {agree_count} 人同意"
        else:
            return False, f"同意人数不足: {agree_count}, 需要超过 {int(majority)} 人"
    
    def _evaluate_keyword_match(self, replies: List[Reply]) -> Tuple[bool, str]:
        """评估关键词匹配"""
        # 格式: keyword:关键词1,关键词2
        keyword_str = self.criteria.replace("keyword:", "")
        keywords = [kw.strip() for kw in keyword_str.split(",")]
        
        matched_replies = []
        for reply in replies:
            if any(kw in reply.content for kw in keywords):
                matched_replies.append(reply.member)
        
        if len(matched_replies) >= len(self.members):
            return True, f"所有成员匹配关键词: {', '.join(set(matched_replies))}"
        else:
            return False, f"匹配成员: {len(set(matched_replies))}/{len(self.members)}"
    
    def _evaluate_custom(self, replies: List[Reply]) -> Tuple[bool, str]:
        """
        评估自定义表达式
        
        支持变量:
        - replies: 回复列表
        - members: 成员列表
        - reply_count: 回复数量
        - member_count: 成员数量
        
        示例:
        - "reply_count >= 3"
        - "all('同意' in r.content for r in replies)"
        - "len([r for r in replies if '好' in r.content]) >= 2"
        """
        try:
            # 安全的内置函数
            safe_builtins = {
                "all": all,
                "any": any,
                "len": len,
                "sum": sum,
                "min": min,
                "max": max,
                "abs": abs,
                "round": round,
                "int": int,
                "float": float,
                "str": str,
                "list": list,
                "set": set,
                "dict": dict,
                "tuple": tuple,
                "sorted": sorted,
                "enumerate": enumerate,
                "zip": zip,
                "range": range,
                "True": True,
                "False": False,
                "None": None,
            }
            
            # 构建评估上下文
            context = {
                "replies": replies,
                "members": self.members,
                "reply_count": len(replies),
                "member_count": len(self.members),
                "AGREE_KEYWORDS": self.AGREE_KEYWORDS,
                "REJECT_KEYWORDS": self.REJECT_KEYWORDS,
            }
            
            result = eval(self.criteria, {"__builtins__": safe_builtins}, context)
            
            if isinstance(result, bool):
                return result, f"自定义表达式结果: {result}"
            else:
                return False, f"表达式返回非布尔值: {type(result)}"
                
        except Exception as e:
            return False, f"表达式执行错误: {str(e)}"
    
    def get_pending_members(self, replies: List[Reply]) -> List[str]:
        """获取待回复成员列表"""
        replied_members = set(r.member for r in replies)
        return [m for m in self.members if m not in replied_members]


def evaluate_criteria(
    criteria: str,
    members: List[str],
    replies: List[Reply],
) -> Tuple[bool, str]:
    """
    评估判断标准的便捷函数
    
    Args:
        criteria: 判断标准
        members: 目标成员列表
        replies: 回复列表
        
    Returns:
        (是否达标, 判断原因)
    """
    evaluator = CriteriaEvaluator(criteria, members)
    return evaluator.evaluate(replies)
