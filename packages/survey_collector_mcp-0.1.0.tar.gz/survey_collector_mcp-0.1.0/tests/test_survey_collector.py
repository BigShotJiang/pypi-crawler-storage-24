"""
Survey Collector MCP 本地测试用例

测试内容：
1. 判断标准评估引擎
2. Markdown 汇总报告生成
3. 调查收集流程（模拟 HITL API）
"""

import asyncio
from datetime import datetime
from typing import List
import os
import sys

# 添加项目路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src_path = os.path.join(project_root, "src")
sys.path.insert(0, src_path)

from survey_collector.models import (
    Reply,
    RoundResult,
    SurveyConfig,
    SurveyResult,
    SurveyStatus,
    CriteriaType,
)
from survey_collector.tools.criteria import CriteriaEvaluator, evaluate_criteria
from survey_collector.tools.summary import generate_summary


def test_criteria_evaluator():
    """测试判断标准评估引擎"""
    print("\n" + "="*60)
    print("测试 1: 判断标准评估引擎")
    print("="*60)
    
    members = ["张三", "李四", "王五"]
    
    # 测试用例
    test_cases = [
        {
            "name": "all_replied - 全员回复",
            "criteria": "all_replied",
            "replies": [
                Reply(member="张三", content="同意", round=1),
                Reply(member="李四", content="OK", round=1),
                Reply(member="王五", content="好的", round=1),
            ],
            "expected": True,
        },
        {
            "name": "all_replied - 部分回复",
            "criteria": "all_replied",
            "replies": [
                Reply(member="张三", content="同意", round=1),
                Reply(member="李四", content="OK", round=1),
            ],
            "expected": False,
        },
        {
            "name": "majority_replied - 多数回复",
            "criteria": "majority_replied",
            "replies": [
                Reply(member="张三", content="同意", round=1),
                Reply(member="李四", content="OK", round=1),
            ],
            "expected": True,
        },
        {
            "name": "majority_agree - 多数同意",
            "criteria": "majority_agree",
            "replies": [
                Reply(member="张三", content="同意这个方案", round=1),
                Reply(member="李四", content="我确认没问题", round=1),
            ],
            "expected": True,
        },
        {
            "name": "keyword - 关键词匹配",
            "criteria": "keyword:同意,确认",
            "replies": [
                Reply(member="张三", content="同意", round=1),
                Reply(member="李四", content="确认", round=1),
                Reply(member="王五", content="同意", round=1),
            ],
            "expected": True,
        },
        {
            "name": "custom - 自定义表达式",
            "criteria": "reply_count >= 2",
            "replies": [
                Reply(member="张三", content="同意", round=1),
                Reply(member="李四", content="OK", round=1),
            ],
            "expected": True,
        },
        {
            "name": "custom - 复杂表达式",
            "criteria": "all('同意' in r.content or 'OK' in r.content for r in replies)",
            "replies": [
                Reply(member="张三", content="同意", round=1),
                Reply(member="李四", content="OK", round=1),
                Reply(member="王五", content="同意", round=1),
            ],
            "expected": True,
        },
    ]
    
    passed = 0
    failed = 0
    
    for case in test_cases:
        evaluator = CriteriaEvaluator(case["criteria"], members)
        result, reason = evaluator.evaluate(case["replies"])
        
        status = "✅ PASS" if result == case["expected"] else "❌ FAIL"
        if result == case["expected"]:
            passed += 1
        else:
            failed += 1
        
        print(f"\n{status} - {case['name']}")
        print(f"   标准: {case['criteria']}")
        print(f"   回复数: {len(case['replies'])}")
        print(f"   结果: {result}, 原因: {reason}")
    
    print(f"\n{'='*60}")
    print(f"判断标准测试结果: {passed} 通过, {failed} 失败")
    print(f"{'='*60}")
    
    return failed == 0


def test_summary_generator():
    """测试 Markdown 汇总报告生成"""
    print("\n" + "="*60)
    print("测试 2: Markdown 汇总报告生成")
    print("="*60)
    
    # 创建模拟数据
    config = SurveyConfig(
        chat_id="test_chat_id",
        members=["张三", "李四", "王五"],
        question="请确认本周 Sprint 完成情况？",
        criteria="all_replied",
        max_rounds=5,
        timeout_per_round=600,
    )
    
    result = SurveyResult(
        status=SurveyStatus.SUCCESS,
        config=config,
        total_replies=4,
    )
    
    # 第一轮
    round1 = RoundResult(
        round_number=1,
        question_sent="请确认本周 Sprint 完成情况？\n\n@张三 @李四 @王五",
        replies=[
            Reply(member="张三", content="完成了3个任务", timestamp=datetime.now(), round=1),
            Reply(member="李四", content="还有1个待处理", timestamp=datetime.now(), round=1),
        ],
        members_replied=["张三", "李四"],
        members_pending=["王五"],
        criteria_met=False,
        criteria_reason="待回复成员: 王五",
    )
    
    # 第二轮
    round2 = RoundResult(
        round_number=2,
        question_sent="【追问】请尚未回复的成员尽快回复:\n\n@王五",
        replies=[
            Reply(member="王五", content="已完成，共2个任务", timestamp=datetime.now(), round=2),
            Reply(member="张三", content="补充：文档也写完了", timestamp=datetime.now(), round=2),
        ],
        members_replied=["王五", "张三"],
        members_pending=[],
        criteria_met=True,
        criteria_reason="所有成员已回复: 张三, 李四, 王五",
    )
    
    result.rounds = [round1, round2]
    
    # 生成汇总
    summary = generate_summary(result)
    
    print("\n生成的 Markdown 报告:")
    print("-" * 60)
    print(summary)
    print("-" * 60)
    
    # 验证关键内容
    checks = [
        ("标题", "# ✅ 调查结果汇总" in summary),
        ("问题", "请确认本周 Sprint 完成情况" in summary),
        ("成员列表", "张三, 李四, 王五" in summary),
        ("第一轮回复", "完成了3个任务" in summary),
        ("第二轮回复", "已完成，共2个任务" in summary),
        ("统计表", "| 张三 |" in summary),
        ("回复率", "回复率" in summary),
    ]
    
    passed = sum(1 for _, check in checks if check)
    failed = len(checks) - passed
    
    print(f"\n验证结果:")
    for name, check in checks:
        status = "✅" if check else "❌"
        print(f"  {status} {name}")
    
    print(f"\n{'='*60}")
    print(f"汇总生成测试结果: {passed}/{len(checks)} 通过")
    print(f"{'='*60}")
    
    return failed == 0


def test_pending_members():
    """测试待回复成员计算"""
    print("\n" + "="*60)
    print("测试 3: 待回复成员计算")
    print("="*60)
    
    members = ["张三", "李四", "王五", "赵六"]
    
    evaluator = CriteriaEvaluator("all_replied", members)
    
    # 第一轮回复
    replies_round1 = [
        Reply(member="张三", content="OK", round=1),
        Reply(member="李四", content="同意", round=1),
    ]
    pending1 = evaluator.get_pending_members(replies_round1)
    print(f"\n第一轮后待回复: {pending1}")
    assert set(pending1) == {"王五", "赵六"}, "第一轮待回复计算错误"
    print("✅ 第一轮待回复计算正确")
    
    # 第二轮回复
    replies_round2 = replies_round1 + [
        Reply(member="王五", content="好的", round=2),
    ]
    pending2 = evaluator.get_pending_members(replies_round2)
    print(f"第二轮后待回复: {pending2}")
    assert set(pending2) == {"赵六"}, "第二轮待回复计算错误"
    print("✅ 第二轮待回复计算正确")
    
    print(f"\n{'='*60}")
    print("待回复成员计算测试通过")
    print(f"{'='*60}")
    
    return True


def test_survey_config_validation():
    """测试配置验证"""
    print("\n" + "="*60)
    print("测试 4: 配置验证")
    print("="*60)
    
    # 正常配置
    try:
        config = SurveyConfig(
            chat_id="test_chat_id",
            members=["张三", "李四"],
            question="测试问题",
        )
        print(f"\n✅ 正常配置创建成功")
        print(f"   Chat ID: {config.chat_id}")
        print(f"   成员: {config.members}")
        print(f"   默认标准: {config.criteria}")
    except Exception as e:
        print(f"❌ 正常配置创建失败: {e}")
        return False
    
    # 配置序列化
    try:
        json_str = config.model_dump_json()
        print(f"\n✅ 配置序列化成功")
        print(f"   JSON 长度: {len(json_str)}")
    except Exception as e:
        print(f"❌ 配置序列化失败: {e}")
        return False
    
    print(f"\n{'='*60}")
    print("配置验证测试通过")
    print(f"{'='*60}")
    
    return True


def main():
    """运行所有测试"""
    print("\n" + "="*60)
    print("Survey Collector MCP 本地测试")
    print("="*60)
    
    tests = [
        ("判断标准评估引擎", test_criteria_evaluator),
        ("Markdown 汇总报告生成", test_summary_generator),
        ("待回复成员计算", test_pending_members),
        ("配置验证", test_survey_config_validation),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n❌ {name} 测试异常: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, False))
    
    # 汇总结果
    print("\n" + "="*60)
    print("测试汇总")
    print("="*60)
    
    for name, result in results:
        status = "✅ 通过" if result else "❌ 失败"
        print(f"  {status} - {name}")
    
    passed = sum(1 for _, r in results if r)
    failed = len(results) - passed
    
    print(f"\n总计: {passed}/{len(results)} 通过")
    
    if failed == 0:
        print("\n🎉 所有测试通过！")
    else:
        print(f"\n⚠️ 有 {failed} 个测试失败")
    
    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
