# khmer

**DOI:** [10.5281/zenodo.13924242](https://doi.org/10.5281/zenodo.13924242)

## Available Versions
- **Version 2.1.1**
  - [Download](https://zenodo.org/record/13924243/files/khmer_2.1.1.img)
  - **MD5:** `89fbb75b2c9ce80ebfb527e989e66c41`
  - **DOI:** [10.5281/zenodo.13924243](https://doi.org/10.5281/zenodo.13924243)
  - **Size:** 73.04 MB
  - **Binaries:** 0 available

## Binaries (26 total)

```extract-partitions.py load-into-counting.py abundance-dist-single.py fastq-to-fasta.py make-initial-stoptags.py abundance-dist.py readstats.py filter-abund-single.py merge-partitions.py readstats.pyc annotate-partitions.py sample-reads-randomly.py filter-abund.py normalize-by-median.py count-median.py filter-stoptags.py partition-graph.py do-partition.py split-paired-reads.py find-knots.py trim-low-abund.py extract-long-sequences.py interleave-reads.py unique-kmers.py extract-paired-reads.py load-graph.py```
