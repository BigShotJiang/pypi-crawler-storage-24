# dustmasker

**DOI:** [10.5281/zenodo.5801359](https://doi.org/10.5281/zenodo.5801359)

## Available Versions
- **Version 1.0.0**
  - [Download](https://zenodo.org/record/5801365/files/kraken_2.0.9.img)
  - **MD5:** `bc195a921148969c7f9482f9fe25b3cd`
  - **DOI:** [10.5281/zenodo.5801365](https://doi.org/10.5281/zenodo.5801365)
  - **Size:** 689.79 MB
  - **Binaries:** 1 available

## Binaries (0 total)

``````
