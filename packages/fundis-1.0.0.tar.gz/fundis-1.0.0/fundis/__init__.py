"""Fundis — Python client for SentiChain intelligence data."""

from fundis.client import FundisClient
from fundis.exceptions import AuthenticationError, FundisError
from fundis.types import Event, Pattern, Signal

__version__ = "1.0.0"

__all__ = [
    "FundisClient",
    "Event",
    "Signal",
    "Pattern",
    "FundisError",
    "AuthenticationError",
    "__version__",
]
