from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Event:
    """A single classified sentiment event from the Fundis pipeline."""

    timestamp: str
    type: str
    sentiment: str
    summary: str
    is_pattern: bool = False
    pattern_keywords: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class Pattern:
    """A group of converging events sharing common keywords."""

    keywords: list[str]
    event_indices: list[int]


@dataclass(frozen=True)
class Signal:
    """Directional signal derived from event sentiment analysis."""

    direction: str
    confidence: float
    bullish_count: int
    bearish_count: int
    total_count: int
