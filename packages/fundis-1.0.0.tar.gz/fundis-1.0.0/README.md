# Fundis

Python client for Fundis intelligence data — events, signals, and patterns from [SentiChain](https://sentichain.com).

Fundis is the intelligence engine behind [SentiMove](https://sentimove.com). This package provides programmatic access to its structured output.

## Installation

```bash
pip install fundis
```

## Quick Start

```python
from fundis import FundisClient

client = FundisClient(api_key="sc_...")

# Get classified events for an asset
events = client.get_events("BTC")
for event in events:
    print(f"[{event.type}] {event.sentiment}: {event.summary}")

# Get a directional signal
signal = client.get_signal("BTC")
print(f"Direction: {signal.direction}, Confidence: {signal.confidence}")

# List supported tickers
tickers = client.list_tickers()
print(tickers)  # ['BTC', 'ETH', 'SOL', 'XRP', 'DOGE', 'HYPE']
```

## API Reference

### `FundisClient(api_key, base_url="https://api.sentichain.com", timeout=30.0)`

Create a client instance. Requires a valid [SentiChain API key](https://sentichain.com).

### `client.get_events(ticker) -> list[Event]`

Fetch the latest classified events for a ticker. Each event contains:

| Field | Type | Description |
|-------|------|-------------|
| `timestamp` | `str` | ISO 8601 timestamp |
| `type` | `str` | Event category: `macro`, `industry`, `price`, or `asset` |
| `sentiment` | `str` | `bullish`, `bearish`, or `neutral` |
| `summary` | `str` | One-sentence event description |
| `is_pattern` | `bool` | Whether this event is part of a detected pattern |
| `pattern_keywords` | `list[str]` | Keywords linking pattern events |

### `client.get_signal(ticker) -> Signal`

Derive a directional signal from the latest events. Returns:

| Field | Type | Description |
|-------|------|-------------|
| `direction` | `str` | `LONG`, `SHORT`, or `FLAT` |
| `confidence` | `float` | 0.0 to 1.0 |
| `bullish_count` | `int` | Number of bullish events |
| `bearish_count` | `int` | Number of bearish events |
| `total_count` | `int` | Total event count |

### `client.list_tickers() -> list[str]`

Return the list of supported ticker symbols.

## Data Format

This version (v1.0.0) consumes the existing pipeline format. Data format will be upgraded in a future release with richer signal data including rationale, category summaries, and pattern descriptions.

## Requirements

- Python 3.10+
- A valid [SentiChain API key](https://sentichain.com)

## Links

- [Fundis.ai](https://fundis.ai) — Intelligence engine landing page
- [SentiMove](https://sentimove.com) — 3D consumer product powered by Fundis
- [SentiChain](https://sentichain.com) — Blockchain platform and API keys
- [GitHub](https://github.com/Yototec/fundis) — Source code
- [PyPI](https://pypi.org/project/fundis/) — Package registry

## License

MIT License — see [LICENSE](LICENSE) for details.
