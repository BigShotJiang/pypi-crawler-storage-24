# fw-nodes-qrcode

QR code generation nodes for Flowire workflow automation.

## Installation

```bash
pip install fw-nodes-qrcode
```

Enable the package in your backend `.env`:

```
INSTALLED_NODE_PACKAGES=fw-nodes-core,fw-nodes-qrcode
```

## Nodes

### Generate QR Code

Generate a QR code PNG image from text or a URL.

**Inputs:**
| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `text` | string | required | Text or URL to encode |
| `size` | int | 10 | Box size in pixels per module |
| `border` | int | 4 | Border size in modules |
| `fill_color` | string | "black" | Module color (name or hex) |
| `back_color` | string | "white" | Background color (name or hex) |
| `error_correction` | string | "M" | Error correction: L/M/Q/H |

**Outputs:**
| Field | Type | Description |
|-------|------|-------------|
| `image` | storage ref | Storage reference to generated PNG |
| `size_bytes` | int | Image file size in bytes |
| `version` | int | QR code version (1-40) |

## Development

```bash
just install    # Install dependencies
just test       # Run tests
just lint       # Run linter
just format     # Format code
```

## Dependencies

- [python-qrcode](https://github.com/lincolnloop/python-qrcode) - QR code generation
