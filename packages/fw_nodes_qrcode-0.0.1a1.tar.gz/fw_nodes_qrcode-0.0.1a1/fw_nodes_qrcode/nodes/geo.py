"""QR code generation node for geographic locations."""

from typing import Any

from flowire_sdk import BaseNode, NodeExecutionContext
from pydantic import Field

from fw_nodes_qrcode.shared import QRCodeOutput, QRStyleInput, generate_qr_image, qr_node_metadata


class QRCodeGeoInput(QRStyleInput):
    latitude: float = Field(
        ...,
        description="Latitude coordinate (e.g. 40.7128)",
        ge=-90,
        le=90,
    )
    longitude: float = Field(
        ...,
        description="Longitude coordinate (e.g. -74.0060)",
        ge=-180,
        le=180,
    )


class QRCodeGeoNode(BaseNode):
    input_schema = QRCodeGeoInput
    output_schema = QRCodeOutput

    metadata = qr_node_metadata(
        name="Geo QR Code",
        description="Generate a QR code that opens a map location",
        icon="📍",
    )

    async def execute_logic(
        self,
        validated_inputs: dict[str, Any],
        context: NodeExecutionContext,
    ) -> QRCodeOutput:
        lat = validated_inputs["latitude"]
        lng = validated_inputs["longitude"]
        return generate_qr_image(f"geo:{lat},{lng}", validated_inputs, context)
