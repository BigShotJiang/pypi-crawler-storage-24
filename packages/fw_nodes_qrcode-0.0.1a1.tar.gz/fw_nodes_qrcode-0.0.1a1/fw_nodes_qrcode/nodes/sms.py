"""QR code generation node for SMS messages."""

from typing import Any

from flowire_sdk import BaseNode, NodeExecutionContext
from pydantic import Field

from fw_nodes_qrcode.shared import QRCodeOutput, QRStyleInput, generate_qr_image, qr_node_metadata


class QRCodeSMSInput(QRStyleInput):
    phone_number: str = Field(
        ...,
        description="Recipient phone number (e.g. +1234567890)",
    )
    message: str = Field(
        default="",
        description="Pre-filled SMS message text",
    )


class QRCodeSMSNode(BaseNode):
    input_schema = QRCodeSMSInput
    output_schema = QRCodeOutput

    metadata = qr_node_metadata(
        name="SMS QR Code",
        description="Generate a QR code that sends an SMS message",
        icon="💬",
    )

    async def execute_logic(
        self,
        validated_inputs: dict[str, Any],
        context: NodeExecutionContext,
    ) -> QRCodeOutput:
        data = f"smsto:{validated_inputs['phone_number']}"
        if validated_inputs.get("message"):
            data += f":{validated_inputs['message']}"

        return generate_qr_image(data, validated_inputs, context)
