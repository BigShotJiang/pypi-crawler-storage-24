"""QR code generation node for phone numbers (tel:)."""

from typing import Any

from flowire_sdk import BaseNode, NodeExecutionContext
from pydantic import Field

from fw_nodes_qrcode.shared import QRCodeOutput, QRStyleInput, generate_qr_image, qr_node_metadata


class QRCodePhoneInput(QRStyleInput):
    phone_number: str = Field(
        ...,
        description="Phone number (e.g. +1234567890)",
    )


class QRCodePhoneNode(BaseNode):
    input_schema = QRCodePhoneInput
    output_schema = QRCodeOutput

    metadata = qr_node_metadata(
        name="Phone QR Code",
        description="Generate a QR code that dials a phone number",
        icon="📞",
    )

    async def execute_logic(
        self,
        validated_inputs: dict[str, Any],
        context: NodeExecutionContext,
    ) -> QRCodeOutput:
        return generate_qr_image(f"tel:{validated_inputs['phone_number']}", validated_inputs, context)
