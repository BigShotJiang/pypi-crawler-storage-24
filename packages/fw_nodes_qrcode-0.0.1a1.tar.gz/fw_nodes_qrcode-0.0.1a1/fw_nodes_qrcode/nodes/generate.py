"""QR code generation node for arbitrary text or URLs."""

from typing import Any

from flowire_sdk import BaseNode, NodeExecutionContext
from pydantic import Field

from fw_nodes_qrcode.shared import QRCodeOutput, QRStyleInput, generate_qr_image, qr_node_metadata


class QRCodeGenerateInput(QRStyleInput):
    text: str = Field(
        ...,
        description="Text or URL to encode in the QR code",
    )


class QRCodeGenerateNode(BaseNode):
    input_schema = QRCodeGenerateInput
    output_schema = QRCodeOutput

    metadata = qr_node_metadata(
        name="Generate QR Code",
        description="Generate a QR code PNG image from text or a URL",
        icon="🔳",
    )

    async def execute_logic(
        self,
        validated_inputs: dict[str, Any],
        context: NodeExecutionContext,
    ) -> QRCodeOutput:
        return generate_qr_image(validated_inputs["text"], validated_inputs, context)
