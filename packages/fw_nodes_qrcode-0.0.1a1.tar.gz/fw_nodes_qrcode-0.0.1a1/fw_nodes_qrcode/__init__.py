"""Flowire QR code generation nodes package."""
