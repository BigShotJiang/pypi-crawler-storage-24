"""Tests for the SMS QR code node."""

import pytest

from fw_nodes_qrcode.nodes.sms import QRCodeSMSNode


@pytest.fixture
def node():
    return QRCodeSMSNode()


async def test_sms_basic(node, mock_context):
    result = await node.execute({"phone_number": "+1234567890"}, mock_context)
    assert result.size_bytes > 0


async def test_sms_with_message(node, mock_context):
    result = await node.execute(
        {"phone_number": "+1234567890", "message": "Hello there!"},
        mock_context,
    )
    assert result.size_bytes > 0


async def test_sms_schema_field_order(node, mock_context):
    schema = node.input_schema.model_json_schema()
    keys = list(schema["properties"].keys())
    assert keys.index("phone_number") < keys.index("size")
