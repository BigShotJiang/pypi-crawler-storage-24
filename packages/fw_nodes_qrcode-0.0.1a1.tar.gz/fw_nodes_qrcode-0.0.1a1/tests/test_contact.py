"""Tests for the contact (vCard) QR code node."""

import pytest

from fw_nodes_qrcode.nodes.contact import QRCodeContactNode


@pytest.fixture
def node():
    return QRCodeContactNode()


async def test_contact_basic(node, mock_context):
    result = await node.execute({"first_name": "John"}, mock_context)
    assert result.size_bytes > 0


async def test_contact_full(node, mock_context):
    result = await node.execute(
        {
            "first_name": "John",
            "last_name": "Doe",
            "phone": "+1234567890",
            "email": "john@example.com",
            "organization": "Acme Inc",
            "title": "Engineer",
            "url": "https://example.com",
            "address": "123 Main St",
            "note": "Met at conference",
        },
        mock_context,
    )
    assert result.size_bytes > 0


async def test_contact_schema_field_order(node, mock_context):
    schema = node.input_schema.model_json_schema()
    keys = list(schema["properties"].keys())
    assert keys.index("first_name") < keys.index("size")
