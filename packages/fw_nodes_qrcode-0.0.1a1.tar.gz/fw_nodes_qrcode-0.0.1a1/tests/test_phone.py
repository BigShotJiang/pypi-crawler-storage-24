"""Tests for the phone QR code node."""

import pytest

from fw_nodes_qrcode.nodes.phone import QRCodePhoneNode


@pytest.fixture
def node():
    return QRCodePhoneNode()


async def test_phone_basic(node, mock_context):
    result = await node.execute({"phone_number": "+1234567890"}, mock_context)
    assert result.size_bytes > 0
    assert result.image["content_type"] == "image/png"


async def test_phone_schema_field_order(node, mock_context):
    schema = node.input_schema.model_json_schema()
    keys = list(schema["properties"].keys())
    assert keys.index("phone_number") < keys.index("size")
