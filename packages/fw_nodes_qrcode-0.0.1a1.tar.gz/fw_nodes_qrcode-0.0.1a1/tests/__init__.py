"""Tests for fw-nodes-qrcode."""
