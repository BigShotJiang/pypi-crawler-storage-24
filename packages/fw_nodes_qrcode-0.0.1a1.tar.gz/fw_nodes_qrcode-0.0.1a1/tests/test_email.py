"""Tests for the email QR code node."""

import pytest

from fw_nodes_qrcode.nodes.email import QRCodeEmailNode


@pytest.fixture
def node():
    return QRCodeEmailNode()


async def test_email_basic(node, mock_context):
    result = await node.execute({"email": "user@example.com"}, mock_context)
    assert result.size_bytes > 0
    assert result.image["content_type"] == "image/png"


async def test_email_with_subject_and_body(node, mock_context):
    await node.execute(
        {"email": "user@example.com", "subject": "Hello", "body": "World"},
        mock_context,
    )
    # Verify stored binary is valid PNG
    png_data = mock_context._stored_binaries[0]["data"]
    assert png_data[:8] == b"\x89PNG\r\n\x1a\n"


async def test_email_with_cc_bcc(node, mock_context):
    result = await node.execute(
        {"email": "user@example.com", "cc": "cc@example.com", "bcc": "bcc@example.com"},
        mock_context,
    )
    assert result.size_bytes > 0


async def test_email_schema_field_order(node, mock_context):
    schema = node.input_schema.model_json_schema()
    keys = list(schema["properties"].keys())
    assert keys.index("email") < keys.index("size")
