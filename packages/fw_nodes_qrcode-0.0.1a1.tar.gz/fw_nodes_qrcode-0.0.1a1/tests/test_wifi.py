"""Tests for the WiFi QR code node."""

import pytest

from fw_nodes_qrcode.nodes.wifi import QRCodeWiFiNode


@pytest.fixture
def node():
    return QRCodeWiFiNode()


async def test_wifi_wpa(node, mock_context):
    result = await node.execute(
        {"ssid": "MyNetwork", "password": "secret123", "security": "WPA"},
        mock_context,
    )
    assert result.size_bytes > 0


async def test_wifi_open_network(node, mock_context):
    result = await node.execute(
        {"ssid": "OpenNet", "security": "nopass"},
        mock_context,
    )
    assert result.size_bytes > 0


async def test_wifi_hidden(node, mock_context):
    result = await node.execute(
        {"ssid": "HiddenNet", "password": "pass", "hidden": True},
        mock_context,
    )
    assert result.size_bytes > 0


async def test_wifi_special_chars_in_ssid(node, mock_context):
    result = await node.execute(
        {"ssid": "My;Network:Test", "password": "pass;word"},
        mock_context,
    )
    assert result.size_bytes > 0


async def test_wifi_schema_field_order(node, mock_context):
    schema = node.input_schema.model_json_schema()
    keys = list(schema["properties"].keys())
    assert keys.index("ssid") < keys.index("size")
