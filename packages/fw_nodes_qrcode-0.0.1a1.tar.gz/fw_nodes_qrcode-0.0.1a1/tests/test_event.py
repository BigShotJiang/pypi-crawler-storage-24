"""Tests for the event (vEvent) QR code node."""

import pytest

from fw_nodes_qrcode.nodes.event import QRCodeEventNode


@pytest.fixture
def node():
    return QRCodeEventNode()


async def test_event_basic(node, mock_context):
    result = await node.execute(
        {"summary": "Team Meeting", "start": "2025-06-15T10:00:00Z"},
        mock_context,
    )
    assert result.size_bytes > 0


async def test_event_full(node, mock_context):
    result = await node.execute(
        {
            "summary": "Conference",
            "start": "2025-06-15T09:00:00Z",
            "end": "2025-06-15T17:00:00Z",
            "location": "Convention Center",
            "description": "Annual tech conference",
        },
        mock_context,
    )
    assert result.size_bytes > 0


async def test_event_schema_field_order(node, mock_context):
    schema = node.input_schema.model_json_schema()
    keys = list(schema["properties"].keys())
    assert keys.index("summary") < keys.index("size")
