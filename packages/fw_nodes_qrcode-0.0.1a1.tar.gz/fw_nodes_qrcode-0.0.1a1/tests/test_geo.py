"""Tests for the geo location QR code node."""

import pytest

from fw_nodes_qrcode.nodes.geo import QRCodeGeoNode


@pytest.fixture
def node():
    return QRCodeGeoNode()


async def test_geo_basic(node, mock_context):
    result = await node.execute({"latitude": 40.7128, "longitude": -74.0060}, mock_context)
    assert result.size_bytes > 0
    assert result.image["content_type"] == "image/png"


async def test_geo_zero_coordinates(node, mock_context):
    result = await node.execute({"latitude": 0.0, "longitude": 0.0}, mock_context)
    assert result.size_bytes > 0


async def test_geo_schema_field_order(node, mock_context):
    schema = node.input_schema.model_json_schema()
    keys = list(schema["properties"].keys())
    assert keys.index("latitude") < keys.index("size")
