
from abstract_utilities import lazy_import
# ---------------------------------------------------------------------
# Lazy import helpers
# ---------------------------------------------------------------------

def get_spacy():
    return lazy_import("spacy")

# ---------------------------------------------------------------------
# Torch
# ---------------------------------------------------------------------

def get_torch():
    return lazy_import("torch")


# ---------------------------------------------------------------------
# Whisper
# ---------------------------------------------------------------------

def get_whisper():
    return lazy_import("whisper")


# ---------------------------------------------------------------------
# Transformers
# ---------------------------------------------------------------------

def get_transformers(module=None):
    
    tf = lazy_import("transformers")
    tf_imps={
        "AutoTokenizer": tf.AutoTokenizer,
        "AutoModelForSeq2SeqLM": tf.AutoModelForSeq2SeqLM,
        "AutoModelForCausalLM": tf.AutoModelForCausalLM,
        "GenerationConfig": tf.GenerationConfig,
        "BitsAndBytesConfig": tf.BitsAndBytesConfig,
        "pipeline": tf.pipeline,
        "LEDTokenizer": tf.LEDTokenizer,
        "LEDForConditionalGeneration": tf.LEDForConditionalGeneration,
        "T5TokenizerFast": tf.T5TokenizerFast,
        "T5ForConditionalGeneration": tf.T5ForConditionalGeneration,
    }

    if module and module in tf_imps:
        return tf_imps.get(module)
    return tf_imps

# ---------------------------------------------------------------------
# Sentence Transformers
# ---------------------------------------------------------------------

def get_sentence_transformers(module=None):

    st = lazy_import("sentence_transformers")
    st_imps = {
        "SentenceTransformer": st.SentenceTransformer,
        "models": st.models,
        "cos_sim": lazy_import("sentence_transformers.util").cos_sim,
    }
    if module and module in st_imps:
        return st_imps.get(module)

    

    return st_imps


# ---------------------------------------------------------------------
# KeyBERT
# ---------------------------------------------------------------------

def get_keybert():
    return lazy_import("keybert").KeyBERT


# ---------------------------------------------------------------------
# MoviePy
# ---------------------------------------------------------------------

def get_moviepy(module=None):

    mp = lazy_import("moviepy.editor")
    mp_imps = {
        "mp": mp,
        "VideoFileClip": mp.VideoFileClip,
    }
    if module and module in mp_imps:
        return mp_imps.get(module)

    

    return mp_imps
