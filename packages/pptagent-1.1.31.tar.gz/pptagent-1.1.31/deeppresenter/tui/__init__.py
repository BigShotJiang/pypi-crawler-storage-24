"""DeepPresenter full-screen TUI."""
