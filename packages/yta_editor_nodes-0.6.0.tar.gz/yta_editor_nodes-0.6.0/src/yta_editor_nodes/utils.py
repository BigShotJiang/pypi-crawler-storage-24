def _do_use_gpu(
    # TODO: Set type
    node_processor: any,
    do_use_gpu: bool = True
) -> bool:
    """
    *For internal use only*

    Check if we should use GPU or not, according
    to what the user is requesting with the
    `do_use_gpu` parameter but checking if it is
    available in the `node_processor` or not.

    This method is useful to know if we have to
    transform a frame to a specific format (for
    GPU or CPU) before sending it as an argument.
    """
    # TODO: Validate 'node_processor'
    return (
        (
            do_use_gpu and
            node_processor.is_gpu_available
        )
    ) or (
        (
            not do_use_gpu and
            not node_processor.is_cpu_available
        )
    )