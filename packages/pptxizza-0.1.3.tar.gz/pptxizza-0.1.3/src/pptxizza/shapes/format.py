from typing import Any, Union, Optional, List
from lxml import etree
from ..xml_utils import xpath, qname
from ..colors import Color, HexColor, RGBColor
from ..util import Length


class FillFormat:
    """
    Provides properties and methods to adjust shape backgrounds/fills.
    """
    def __init__(self, shape: Any) -> None:
        self._shape = shape

    def solid(self, color: Union[Color, str, tuple]) -> None:
        """
        Sets the shape to have a solid background color.
        
        Args:
            color (Union[Color, str, tuple]): Either a Color instance, a hex string ("#FF0000"), 
                                              or an RGB tuple (255, 0, 0).
        """
        if isinstance(color, str):
            color = HexColor(color)
        elif isinstance(color, tuple) and len(color) == 3:
            color = RGBColor(*color)
        elif not isinstance(color, Color):
            raise ValueError("color must be a Color instance, hex string, or rgb tuple.")

        spPrs = xpath(self._shape.element, "./p:spPr")
        if not spPrs:
            # Some extremely raw elements might miss spPr, create it
            spPr = etree.Element(qname("p", "spPr"))
            self._shape.element.insert(0, spPr)
        else:
            spPr = spPrs[0]

        # Remove existing fill types
        for tag in ["solidFill", "noFill", "gradFill", "pattFill", "blipFill"]:
            for el in xpath(spPr, f"./a:{tag}"):
                spPr.remove(el)

        # Inject the new solidFill element
        solid_fill = etree.Element(qname("a", "solidFill"))
        solid_fill.append(color._get_color_node())
        spPr.append(solid_fill)


class FontFormat:
    """
    Provides access to text formatting properties for all text in a shape.
    Changing properties here broadcasts the changes to all text runs within the shape.
    """
    def __init__(self, shape: Any) -> None:
        self._shape = shape

    def _get_or_create_rPrs(self) -> List[etree._Element]:
        # We need an <a:rPr> in every <a:r> within the <p:txBody>
        runs = xpath(self._shape.element, ".//p:txBody//a:p/a:r")
        rPrs = []
        for r in runs:
            rPr = xpath(r, "./a:rPr")
            if not rPr:
                # Need to add <a:rPr> at the beginning of the run, before <a:t>
                new_rPr = etree.Element(qname("a", "rPr"))
                r.insert(0, new_rPr)
                rPrs.append(new_rPr)
            else:
                rPrs.append(rPr[0])
        return rPrs

    @property
    def size(self) -> Optional[Length]:
        """Gets or sets the font size."""
        rPrs = self._get_or_create_rPrs()
        if rPrs:
            sz = rPrs[0].get("sz")
            if sz is not None:
                # 'sz' is given in 100ths of a point. We convert to EMUs.
                # 1 pt = 100 sz. 1 pt = 12700 EMUs.
                # So EMUs = (sz / 100) * 12700 = sz * 127
                return Length(int(sz) * 127)
        return None

    @size.setter
    def size(self, value: Length) -> None:
        rPrs = self._get_or_create_rPrs()
        # Convert EMUs back to 100ths of a point
        sz_val = int(round(int(value) / 127.0))
        for rPr in rPrs:
            rPr.set("sz", str(sz_val))

    @property
    def name(self) -> Optional[str]:
        """Gets or sets the Latin font face name."""
        rPrs = self._get_or_create_rPrs()
        if rPrs:
            latin = xpath(rPrs[0], "./a:latin")
            if latin:
                return latin[0].get("typeface")
        return None

    @name.setter
    def name(self, value: str) -> None:
        rPrs = self._get_or_create_rPrs()
        for rPr in rPrs:
            latin = xpath(rPr, "./a:latin")
            if not latin:
                latin_node = etree.Element(qname("a", "latin"))
                latin_node.set("typeface", value)
                rPr.append(latin_node)
            else:
                latin[0].set("typeface", value)

    @property
    def bold(self) -> Optional[bool]:
        """Gets or sets whether the font is bold."""
        rPrs = self._get_or_create_rPrs()
        if rPrs:
            b = rPrs[0].get("b")
            return b in ["1", "true"]
        return False

    @bold.setter
    def bold(self, value: bool) -> None:
        rPrs = self._get_or_create_rPrs()
        for rPr in rPrs:
            rPr.set("b", "1" if value else "0")

    @property
    def italic(self) -> Optional[bool]:
        """Gets or sets whether the font is italicized."""
        rPrs = self._get_or_create_rPrs()
        if rPrs:
            i = rPrs[0].get("i")
            return i in ["1", "true"]
        return False

    @italic.setter
    def italic(self, value: bool) -> None:
        rPrs = self._get_or_create_rPrs()
        for rPr in rPrs:
            rPr.set("i", "1" if value else "0")

    @property
    def color(self) -> Optional[Color]:
        """Gets or sets the text color."""
        # For simplicity, getting color returns None instead of parsing XML back to Python objects,
        # but setting it works thoroughly.
        return None
        
    @color.setter
    def color(self, color_val: Union[Color, str, tuple]) -> None:
        if isinstance(color_val, str):
            color_val = HexColor(color_val)
        elif isinstance(color_val, tuple) and len(color_val) == 3:
            color_val = RGBColor(*color_val)
            
        rPrs = self._get_or_create_rPrs()
        for rPr in rPrs:
            # Remove any existing color wrappers
            for tag in ["solidFill", "noFill", "gradFill"]:
                for el in xpath(rPr, f"./a:{tag}"):
                    rPr.remove(el)
            
            solid_fill = etree.Element(qname("a", "solidFill"))
            solid_fill.append(color_val._get_color_node())
            rPr.append(solid_fill)
