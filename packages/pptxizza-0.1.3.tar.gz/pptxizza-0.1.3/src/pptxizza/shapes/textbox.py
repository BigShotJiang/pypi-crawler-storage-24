from __future__ import annotations
from lxml import etree
from typing import Optional, Union
from ..util import Length
from ..xml_utils import NAMESPACES, parse_xml
from .shape import Shape
from ..text import Text

class TextBox(Shape):
    """
    Represents a TextBox shape.
    """
    def __init__(self, text: str | Text = "", x: Union[int, Length] = 0, y: Union[int, Length] = 0, cx: Union[int, Length] = 0, cy: Union[int, Length] = 0, xml_element: Optional[etree._Element] = None) -> None:
        """
        Initializes a TextBox that can be added to a Presentation slide.
        
        Args:
            text (Union[str, Text]): Optional initial text or Text object.
            x (int): Optional initial X coordinate in EMUs.
            y (int): Optional initial Y coordinate in EMUs.
            cx (int): Optional initial width in EMUs.
            cy (int): Optional initial height in EMUs.
            xml_element (Optional[etree._Element]): Existing XML node to wrap. If None, it creates a new one.
        """
        if xml_element is None:
            init_text = text if isinstance(text, str) else ""
            shape_xml = f'''
            <p:sp xmlns:a="{NAMESPACES["a"]}" xmlns:p="{NAMESPACES["p"]}">
                <p:nvSpPr>
                    <p:cNvPr id="0" name="TextBox"/>
                    <p:cNvSpPr txBox="1"/>
                    <p:nvPr/>
                </p:nvSpPr>
                <p:spPr>
                    <a:xfrm>
                        <a:off x="{int(x)}" y="{int(y)}"/>
                        <a:ext cx="{int(cx)}" cy="{int(cy)}"/>
                    </a:xfrm>
                    <a:prstGeom prst="rect">
                        <a:avLst/>
                    </a:prstGeom>
                    <a:noFill/>
                    <a:ln>
                        <a:noFill/>
                    </a:ln>
                </p:spPr>
                <p:txBody>
                    <a:bodyPr wrap="none" rtlCol="0">
                        <a:spAutoFit/>
                    </a:bodyPr>
                    <a:lstStyle/>
                    <a:p>
                        <a:pPr algn="l"/>
                        <a:r>
                            <a:rPr lang="en-US" sz="1800"/>
                            <a:t>{init_text}</a:t>
                        </a:r>
                    </a:p>
                </p:txBody>
            </p:sp>
            '''
            xml_element = parse_xml(shape_xml.encode('utf-8'))
        super().__init__(text, x, y, cx, cy, xml_element)
