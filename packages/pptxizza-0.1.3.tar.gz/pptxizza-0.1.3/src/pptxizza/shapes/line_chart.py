from .chart import Chart

class LineChart(Chart):
    """
    Represents an explicitly typed GraphicFrame wrapper known to contain a <c:lineChart>.
    """
    pass
