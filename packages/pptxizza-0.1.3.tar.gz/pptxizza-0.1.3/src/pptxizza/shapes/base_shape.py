from lxml import etree
from typing import Optional, Any
from ..xml_utils import xpath, inches_to_emu, emu_to_inches
from .format import FillFormat

class BaseShape:
    """
    Base class for all shape types on a slide.
    
    Provides properties to manipulate the position (x, y) and size (width, height)
    of the shape using either English Metric Units (EMUs) or inches.
    """
    
    def __init__(self, xml_element: Optional[etree._Element] = None) -> None:
        """
        Initializes a new shape instance wrapping an XML element.
        
        Args:
            xml_element (Optional[etree._Element]): The raw lxml element representing the shape.
        """
        if xml_element is None:
            raise ValueError("BaseShape requires an xml_element. Use a specific subclass to construct from scratch.")
        self._element = xml_element
        self.slide: Optional[Any] = None

    @property
    def element(self) -> etree._Element:
        """
        Returns the underlying lxml element for advanced editing and extraction.
        
        Returns:
            etree._Element: The raw lxml XML element.
        """
        return self._element

    @property
    def shape_name(self) -> str:
        """
        Gets or sets the shape's internal reference name.
        
        Returns:
            str: The internal name (e.g., 'TextBox 1'), or an empty string if not found.
        """
        nvPr = xpath(self._element, ".//p:cNvPr")
        if nvPr:
            return str(nvPr[0].get("name", ""))
        return ""

    @shape_name.setter
    def shape_name(self, value: str) -> None:
        nvPr = xpath(self._element, ".//p:cNvPr")
        if nvPr:
            nvPr[0].set("name", value)

    def _get_xfrm_node(self) -> Optional[etree._Element]:
        """Internal helper to locate the <a:xfrm> transform node."""
        xfrms = xpath(self._element, ".//a:xfrm")
        if xfrms:
            return xfrms[0]
        return None

    def _get_off_node(self) -> Optional[etree._Element]:
        """Internal helper to locate the <a:off> offset node."""
        xfrm = self._get_xfrm_node()
        if xfrm is not None:
            offs = xpath(xfrm, "a:off")
            if offs:
                return offs[0]
        return None

    def _get_ext_node(self) -> Optional[etree._Element]:
        """Internal helper to locate the <a:ext> extent (size) node."""
        xfrm = self._get_xfrm_node()
        if xfrm is not None:
            exts = xpath(xfrm, "a:ext")
            if exts:
                return exts[0]
        return None

    @property
    def x(self) -> int:
        """
        Gets or sets the X (horizontal) coordinate of the shape in EMUs.
        
        Returns:
            int: The X coordinate in EMUs.
        """
        node = self._get_off_node()
        return int(node.get("x", 0)) if node is not None else 0

    @x.setter
    def x(self, value: int) -> None:
        node = self._get_off_node()
        if node is not None:
            node.set("x", str(int(value)))

    @property
    def y(self) -> int:
        """
        Gets or sets the Y (vertical) coordinate of the shape in EMUs.
        
        Returns:
            int: The Y coordinate in EMUs.
        """
        node = self._get_off_node()
        return int(node.get("y", 0)) if node is not None else 0

    @y.setter
    def y(self, value: int) -> None:
        node = self._get_off_node()
        if node is not None:
            node.set("y", str(int(value)))

    @property
    def cx(self) -> int:
        """
        Gets or sets the width (cx) of the shape in EMUs.
        
        Returns:
            int: The width in EMUs.
        """
        node = self._get_ext_node()
        return int(node.get("cx", 0)) if node is not None else 0

    @cx.setter
    def cx(self, value: int) -> None:
        node = self._get_ext_node()
        if node is not None:
            node.set("cx", str(int(value)))

    @property
    def cy(self) -> int:
        """
        Gets or sets the height (cy) of the shape in EMUs.
        
        Returns:
            int: The height in EMUs.
        """
        node = self._get_ext_node()
        return int(node.get("cy", 0)) if node is not None else 0

    @cy.setter
    def cy(self, value: int) -> None:
        node = self._get_ext_node()
        if node is not None:
            node.set("cy", str(int(value)))

    @property
    def x_inches(self) -> float:
        """X coordinate represented in inches."""
        return emu_to_inches(self.x)

    @x_inches.setter
    def x_inches(self, value: float) -> None:
        self.x = inches_to_emu(value)

    @property
    def y_inches(self) -> float:
        """Y coordinate represented in inches."""
        return emu_to_inches(self.y)

    @y_inches.setter
    def y_inches(self, value: float) -> None:
        self.y = inches_to_emu(value)

    @property
    def width_inches(self) -> float:
        """Width represented in inches."""
        return emu_to_inches(self.cx)

    @width_inches.setter
    def width_inches(self, value: float) -> None:
        self.cx = inches_to_emu(value)

    @property
    def height_inches(self) -> float:
        """Height represented in inches."""
        return emu_to_inches(self.cy)

    @height_inches.setter
    def height_inches(self, value: float) -> None:
        self.cy = inches_to_emu(value)

    @property
    def fill(self) -> FillFormat:
        """
        Gets the FillFormat object for this shape, allowing background color styling.
        
        Returns:
            FillFormat: The format object for customizing the shape's fill.
        """
        return FillFormat(self)

    def has_text(self, text_pattern: str) -> bool:
        """
        Checks if the shape contains the specified text pattern anywhere in its XML structure.
        
        Args:
            text_pattern (str): The string pattern to search for (e.g. '{{name}}').
            
        Returns:
            bool: True if the pattern is found within any <a:t> nodes, False otherwise.
        """
        t_nodes = xpath(self._element, ".//a:t")
        for node in t_nodes:
            if node.text and text_pattern in node.text:
                return True
        return False
