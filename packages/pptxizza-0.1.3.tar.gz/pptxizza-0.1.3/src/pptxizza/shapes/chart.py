from typing import List, Dict, Union, Any, Optional
from ..xml_utils import xpath
from .graphic_frame import GraphicFrame

class Chart(GraphicFrame):
    """
    Base wrapper for GraphicFrames proven to contain internal chart relations.
    """
    
    def replace_data(self, data: Dict[Union[int, str], List[Any]], categories: List[str]) -> None:
        """
        Modifies native chart cache bounds without replacing templates.
        
        Args:
            data (Dict[Union[int, str], List[Any]]): A dictionary mapping Series index integers or strings to numeric lists.
            categories (List[str]): Array mapping category labels.
            
        Raises:
            ValueError: If the current chart has no linkage back to a valid Slide object (needs the relation graph).
        """
        if self.slide is None:
            raise ValueError("Chart must have a reference to a Slide to modify nested data.")
            
        from ..charts import replace_chart_data
        
        # We can directly exploit the shape_name attribute to delegate downwards
        replace_chart_data(self.slide, self.shape_name, data, categories)
