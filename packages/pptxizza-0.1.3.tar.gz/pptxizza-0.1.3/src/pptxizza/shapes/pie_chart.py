from .chart import Chart

class PieChart(Chart):
    """
    Represents an explicitly typed GraphicFrame wrapper known to contain a <c:pieChart>.
    """
    pass
