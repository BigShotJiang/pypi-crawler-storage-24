from lxml import etree
from ..xml_utils import xpath
from .base_shape import BaseShape

class GraphicFrame(BaseShape):
    """
    Represents a graphic frame (<p:graphicFrame>), which acts as a container 
    for complex objects like Charts and Tables.
    """
    
    def is_table(self) -> bool:
        """
        Checks if the graphic frame contains a table object.
        
        Returns:
            bool: True if it contains an <a:tbl> node, False otherwise.
        """
        return bool(xpath(self._element, ".//a:tbl"))

    def is_chart(self) -> bool:
        """
        Checks if the graphic frame contains a chart object.
        
        Returns:
            bool: True if it contains an <c:chart> node, False otherwise.
        """
        return bool(xpath(self._element, ".//c:chart"))
