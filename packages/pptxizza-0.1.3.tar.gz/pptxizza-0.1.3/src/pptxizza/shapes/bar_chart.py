from .chart import Chart

class BarChart(Chart):
    """
    Represents an explicitly typed GraphicFrame wrapper known to contain a <c:barChart>.
    """
    pass
