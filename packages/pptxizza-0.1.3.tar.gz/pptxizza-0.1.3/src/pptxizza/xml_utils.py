from lxml import etree
from typing import List, cast, Dict

NAMESPACES: Dict[str, str] = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
    "dc": "http://purl.org/dc/elements/1.1/",
    "dcterms": "http://purl.org/dc/terms/",
    "dcmitype": "http://purl.org/dc/dcmitype/",
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
    "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
    "c": "http://schemas.openxmlformats.org/drawingml/2006/chart",
    "ct": "http://schemas.openxmlformats.org/package/2006/content-types",
}

def parse_xml(xml_bytes: bytes) -> etree._Element:
    """
    Parses raw XML bytes into an lxml `_Element` object.
    
    Args:
        xml_bytes (bytes): The raw XML data to parse.
        
    Returns:
        etree._Element: The root element of the parsed XML tree.
    """
    parser = etree.XMLParser(recover=True, remove_blank_text=False)
    return etree.fromstring(xml_bytes, parser)

def to_xml(root: etree._Element) -> bytes:
    """
    Serializes an lxml `_Element` to a UTF-8 encoded byte string with a standard XML declaration.
    
    Args:
        root (etree._Element): The root element to serialize.
        
    Returns:
        bytes: The serialized XML data.
    """
    return etree.tostring(root, encoding="UTF-8", xml_declaration=True, standalone=True)


def xpath(element: etree._Element, path: str) -> List[etree._Element]:
    """
    Evaluates an XPath expression on the given element utilizing standard PPTX namespaces.
    
    Args:
        element (etree._Element): The element to execute the query against.
        path (str): The XPath query string (e.g. './/a:t').
        
    Returns:
        List[etree._Element]: A resulting list of elements matching the query.
    """
    return cast(List[etree._Element], element.xpath(path, namespaces=NAMESPACES))

def qname(prefix: str, local_name: str) -> str:
    """
    Constructs a fully qualified Clark-notation element tag name using predefined standard namespaces.
    
    Args:
        prefix (str): The namespace prefix key (e.g., 'a', 'p').
        local_name (str): The standard local tag name (e.g., 'spPr').
        
    Returns:
        str: The fully qualified syntax name (e.g. '{http://...}spPr').
    """
    if prefix in NAMESPACES:
        return f"{{{NAMESPACES[prefix]}}}{local_name}"
    return local_name

def inches_to_emu(inches: float) -> int:
    """
    Converts visual inches to English Metric Units (EMU).
    1 inch is exactly 914,400 EMUs.
    
    Args:
        inches (float): The length in inches.
        
    Returns:
        int: The precise quantity of equivalent EMUs.
    """
    return int(inches * 914400)

def emu_to_inches(emu: int) -> float:
    """
    Converts English Metric Units (EMU) to visual inches.
    1 EMU is exactly 1/914,400th of an inch.
    
    Args:
        emu (int): The length in English Metric Units.
        
    Returns:
        float: The precise quantity of equivalent inches.
    """
    return float(emu) / 914400.0
