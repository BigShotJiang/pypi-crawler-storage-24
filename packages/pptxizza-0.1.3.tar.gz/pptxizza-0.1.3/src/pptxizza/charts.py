from typing import Dict, List, Any, Optional, Union
from .xml_utils import etree, xpath, qname

def replace_chart_data(slide: Any, shape_name: str, data: Dict[Union[int, str], List[Any]], categories: List[str]) -> None:
    """
    Replaces the underlying data cache bindings inside an existing chart shape.
    
    Args:
        slide (Slide): The origin slide wrapper instance resolving the chart relational context.
        shape_name (str): The logical embedded drawingML name attribute for the chart.
        data (Dict[Union[int, str], List[Any]]): A dictionary mapping Series index integers or string headers to lists of arbitrary values.
        categories (List[str]): Overriding axis category label names (e.g. Month headers / "Q1", "Q2").
        
    Raises:
        ValueError: If the shape wasn't found, isn't a chart, or lacks valid XML relationship dependencies.
    """
    cnvprs = xpath(slide._xml, f"//p:cNvPr[@name='{shape_name}']")
    if not cnvprs:
        raise ValueError(f"Chart shape '{shape_name}' not found on slide.")
    
    parent = cnvprs[0].getparent()
    if parent is None:
        raise ValueError("Invalid shape hierarchy")
    graphicFrame = parent.getparent()
    if graphicFrame is None:
        raise ValueError("Invalid shape hierarchy")
        
    chart_ref = xpath(graphicFrame, ".//c:chart")
    if not chart_ref:
        raise ValueError(f"Shape '{shape_name}' is not a chart.")
        
    rId = chart_ref[0].get(qname("r", "id"))
    
    slide_rels = slide._package.get_rels(slide.part_name)
    rel = slide_rels.rels.get(rId)
    if not rel:
        raise ValueError(f"Relationship {rId} for chart not found.")
        
    target = rel['Target']
    if target.startswith("../"):
        target = target[3:]
    chart_part_name = f"ppt/{target}"
    
    chart_xml = slide._package.get_xml_part(chart_part_name)
    if chart_xml is None:
        raise ValueError(f"Chart part {chart_part_name} not found in package.")
        
    series_nodes = xpath(chart_xml, "//c:ser")
    for idx, ser in enumerate(series_nodes):
        ser_vals = data.get(idx) or data.get(str(idx))
        if ser_vals is None:
            tx_node = xpath(ser, "c:tx//c:v")
            if tx_node and tx_node[0].text in data:
                ser_vals = data[tx_node[0].text]
                
        if ser_vals is None:
            continue
            
        cat_caches = xpath(ser, "c:cat//c:strCache")
        if not cat_caches:
            cat_caches = xpath(ser, "c:cat//c:numCache")
            
        if cat_caches:
            _update_cache(cat_caches[0], categories)
            
        val_caches = xpath(ser, "c:val//c:numCache")
        if val_caches:
            _update_cache(val_caches[0], ser_vals)
            
    slide._package.set_xml_part(chart_part_name, chart_xml)


def _update_cache(cache_node: etree._Element, items: List[Any]) -> None:
    """
    Overwrites the `ptCount` size cache and constructs identical `pt` mapping points internally.
    
    Args:
        cache_node (etree._Element): The internal c:strCache or c:numCache DOM node target wrapper.
        items (List[Any]): Array of primitive values to serialize into the point cache elements.
    """
    ptCount = xpath(cache_node, "c:ptCount")
    if not ptCount:
        ptCount_elem = etree.SubElement(cache_node, qname("c", "ptCount"))
    else:
        ptCount_elem = ptCount[0]
    ptCount_elem.set("val", str(len(items)))
    
    for pt in xpath(cache_node, "c:pt"):
        cache_node.remove(pt)
        
    for i, item in enumerate(items):
        pt_elem = etree.SubElement(cache_node, qname("c", "pt"))
        pt_elem.set("idx", str(i))
        v_elem = etree.SubElement(pt_elem, qname("c", "v"))
        v_elem.text = str(item)
