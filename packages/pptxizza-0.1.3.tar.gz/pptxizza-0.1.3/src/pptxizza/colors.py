from lxml import etree
from .xml_utils import qname

class Color:
    """
    Base class for shape and text colors in pptxizza.
    Subclasses must implement _get_color_node.
    """
    def _get_color_node(self) -> etree._Element:
        raise NotImplementedError("Subclasses must implement _get_color_node")


class RGBColor(Color):
    """
    Represents an RGB color constructed from integer red, green, and blue values (0-255).
    """
    def __init__(self, r: int, g: int, b: int) -> None:
        self.r = r
        self.g = g
        self.b = b

    def _get_color_node(self) -> etree._Element:
        node = etree.Element(qname("a", "srgbClr"))
        # Render hex format without the #
        hex_val = f"{self.r:02X}{self.g:02X}{self.b:02X}"
        node.set("val", hex_val)
        return node


class HexColor(Color):
    """
    Represents a color constructed from a standard hexadecimal string (e.g. '#FF0000' or 'FF0000').
    """
    def __init__(self, hex_str: str) -> None:
        if hex_str.startswith("#"):
            hex_str = hex_str[1:]
        self.hex_str = hex_str.upper()

    def _get_color_node(self) -> etree._Element:
        node = etree.Element(qname("a", "srgbClr"))
        node.set("val", self.hex_str)
        return node


class ThemeColor(Color):
    """
    Represents a color tied to the presentation's theme scheme (e.g., 'accent1', 'tx1', 'bg1').
    """
    def __init__(self, theme_val: str) -> None:
        self.theme_val = theme_val

    def _get_color_node(self) -> etree._Element:
        node = etree.Element(qname("a", "schemeClr"))
        node.set("val", self.theme_val)
        return node
