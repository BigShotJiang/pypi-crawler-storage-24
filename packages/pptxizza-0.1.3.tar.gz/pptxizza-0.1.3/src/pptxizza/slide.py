from lxml import etree
from typing import List, Dict, Optional, Any, Union
from .shapes import shape_factory, BaseShape, Picture
from .xml_utils import xpath, NAMESPACES, qname, parse_xml

class Slide:
    """
    Represents a single slide in a presentation.
    
    Provides methods to query elements, replace text bindings, inject media,
    update chart templates, and insert or delete standard outline shapes.
    """
    
    def __init__(self, package: Any, part_name: str) -> None:
        """
        Initializes a Slide with its parent package and target part path.
        
        Args:
            package (OpcPackage): The parent OPC zip package handler.
            part_name (str): The absolute internal path to the slide's XML part (e.g. 'ppt/slides/slide1.xml').
        """
        self._package = package
        self.part_name = part_name
        self._xml: Optional[etree._Element] = self._package.get_xml_part(self.part_name)
        if self._xml is None:
            raise ValueError(f"Could not load slide XML part: {self.part_name}")

    @property
    def shapes(self) -> List[BaseShape]:
        """
        Returns a list of all shape objects on the slide by scanning the <p:spTree>.
        
        Returns:
            List[BaseShape]: The collection of shapes, pictures, and graphic frames discovered.
        """
        spTree = xpath(self._xml, "//p:spTree")
        if not spTree:
            return []
            
        elements = spTree[0].xpath("./p:sp | ./p:pic | ./p:graphicFrame | ./p:grpSp", namespaces=NAMESPACES)
        return [shape_factory(el, slide=self) for el in elements]

    def insert_shape(self, shape: BaseShape) -> BaseShape:
        """
        Inserts an instantiated Shape object onto the slide.
        
        Args:
            shape (BaseShape): The shape wrapper describing the drawing element.
            
        Returns:
            BaseShape: The given shape.
        """
        shape_id = str(len(self.shapes) + 1)
        nvPr = xpath(shape.element, ".//p:cNvPr")
        if nvPr:
            if not nvPr[0].get("id") or nvPr[0].get("id") == "0":
                nvPr[0].set("id", shape_id)
            if not nvPr[0].get("name") or nvPr[0].get("name").startswith("TextBox") or nvPr[0].get("name").startswith("Picture"):
                nvPr[0].set("name", f"Shape {shape_id}")

        # Inject media and link picture IDs if this is a newly constructed Picture
        from .shapes import Picture
        if isinstance(shape, Picture) and hasattr(shape, "pending_image_path") and shape.pending_image_path:
            import os
            from .media import add_image_to_package, ASVG_NS
            
            image_path = shape.pending_image_path
            new_part_name, ext = add_image_to_package(self._package, image_path)
            
            rel_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
            relative_target = f"../media/{os.path.basename(new_part_name)}"
            slide_rels = self._package.get_rels(self.part_name)
            rId = slide_rels.add_relationship(rel_type, relative_target)
            
            blips = xpath(shape.element, ".//a:blip")
            if blips:
                blip = blips[0]
                if ext == ".svg":
                    dummy_part_name = "ppt/media/dummy_fallback.png"
                    if not self._package.get_part(dummy_part_name):
                        import os
                        fallback_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "tests", "fixtures", "test_image.png"))
                        with open(fallback_path, "rb") as f:
                            self._package.set_part(dummy_part_name, f.read())
                        self._package.content_types.add_default("png", "image/png")
                    
                    dummy_rId = slide_rels.add_relationship(rel_type, "../media/dummy_fallback.png")
                    blip.set(qname("r", "embed"), dummy_rId)
                        
                    extLstNodes = xpath(blip, "a:extLst")
                    if not extLstNodes:
                        extLst_elem = etree.SubElement(blip, qname("a", "extLst"))
                    else:
                        extLst_elem = extLstNodes[0]
                        
                    ext_tagNodes = xpath(extLst_elem, "a:ext[@uri='{96DAC541-7B7A-43D3-8B79-37D633B846F1}']")
                    if not ext_tagNodes:
                        ext_tag_elem = etree.SubElement(extLst_elem, qname("a", "ext"), uri="{96DAC541-7B7A-43D3-8B79-37D633B846F1}")
                    else:
                        ext_tag_elem = ext_tagNodes[0]
                        for c in list(ext_tag_elem):
                            ext_tag_elem.remove(c)
                            
                    svgBlip = etree.SubElement(ext_tag_elem, f"{{{ASVG_NS}}}svgBlip", nsmap={"asvg": ASVG_NS})
                    svgBlip.set(qname("r", "embed"), rId)
                else:
                    blip.set(qname("r", "embed"), rId)
            
            shape.pending_image_path = None

        spTree = xpath(self._xml, "//p:spTree")
        if spTree:
            spTree[0].append(shape.element)
            
        shape.slide = self
        return shape

    def delete_shape(self, shape_or_name: Union[str, BaseShape]) -> bool:
        """
        Removes a shape from the slide.
        
        Args:
            shape_or_name (Union[str, BaseShape]): The string name of the shape, or the shape object reference itself.
            
        Returns:
            bool: True if the shape was found and removed, False otherwise.
        """
        if isinstance(shape_or_name, str):
            for sp in self.shapes:
                if sp.shape_name == shape_or_name:
                    parent = sp.element.getparent()
                    if parent is not None:
                        parent.remove(sp.element)
                    return True
            return False
        else:
            parent = shape_or_name.element.getparent()
            if parent is not None:
                parent.remove(shape_or_name.element)
                return True
            return False

    def _commit_changes(self) -> None:
        """Flushes XML modifications back to the underlying OPC package mapping."""
        self._package.set_xml_part(self.part_name, self._xml)

    def fill(self, replacements: Dict[str, Union[str, float, int]]) -> None:
        """
        Populate the template slide with data based on a key-value mapping targetting 
        placeholder shape names or `{{mustache}}` tags within text nodes.
        
        Args:
            replacements (Dict[str, Union[str, float, int]]): A dictionary denoting keys (shape names or '{{tag}}')
                                                              to content replacements.
        """
        for key, value in replacements.items():
            if key.startswith("{{") and key.endswith("}}"):
                self._replace_mustache_text(key, str(value))
            else:
                self._replace_named_shape(key, value)

    def _replace_mustache_text(self, mustache_key: str, new_text: str) -> None:
        """
        Replaces all occurrences of `{{key}}` within text nodes globally on the slide.
        
        Args:
            mustache_key (str): The literal mustache key string mapping (e.g. '{{name}}').
            new_text (str): The value to substitute the key with.
        """
        text_nodes = xpath(self._xml, "//a:t")
        for t_node in text_nodes:
            if t_node.text and mustache_key in t_node.text:
                t_node.text = t_node.text.replace(mustache_key, new_text)

    def _replace_named_shape(self, shape_name: str, new_content: Any) -> None:
        """
        Finds a shape by its defined XML name and overwrites its content intelligently.
        
        Args:
            shape_name (str): The internal target shape name (e.g., 'Picture 1', 'Title Textbox').
            new_content (Any): The payload replacing the content. If a string file path ending with an image extension is passed, an image injection is performed.
        """
        cnvprs = xpath(self._xml, f"//p:cNvPr[@name='{shape_name}']")
        for cnvpr in cnvprs:
            parent_props = cnvpr.getparent()
            if parent_props is None:
                continue
            shape_elem = parent_props.getparent()
            if shape_elem is None:
                continue
            
            if isinstance(new_content, str) and not (new_content.endswith(".svg") or new_content.endswith(".png") or new_content.endswith(".jpg")):
                self._set_shape_text(shape_elem, new_content)
            else:
                self._replace_image(shape_elem, new_content)

    def _set_shape_text(self, shape_elem: etree._Element, text: Union[str, Any]) -> None:
        """
        Overwrites the text bounds of a shape, preserving the first paragraph formatting for strings.
        If a Text object is provided, completely parses the rich run tree.
        
        Args:
            shape_elem (etree._Element): The raw `<p:sp>` root node.
            text (Union[str, Text]): The literal string or formatted Text payload intended for insertion.
        """
        txBody = xpath(shape_elem, "p:txBody")
        if not txBody:
            return 

        txBody_elem = txBody[0]
        paragraphs = xpath(txBody_elem, "a:p")
        
        from .text import Text
        if isinstance(text, Text):
            for p in paragraphs:
                txBody_elem.remove(p)
            txBody_elem.append(text.to_xml_element())
            return

        if not paragraphs:
            p_elem = etree.SubElement(txBody_elem, qname("a", "p"))
            r_elem = etree.SubElement(p_elem, qname("a", "r"))
            t_elem = etree.SubElement(r_elem, qname("a", "t"))
            t_elem.text = text
            return
        
        first_p = paragraphs[0]
        for p in paragraphs[1:]:
            txBody_elem.remove(p)
            
        runs = xpath(first_p, "a:r")
        
        if not runs:
            r_elem = etree.SubElement(first_p, qname("a", "r"))
            t_elem = etree.SubElement(r_elem, qname("a", "t"))
            t_elem.text = text
            return

        first_r = runs[0]
        t_nodes = xpath(first_r, "a:t")
        if not t_nodes:
            t_elem = etree.SubElement(first_r, qname("a", "t"))
            t_elem.text = text
        else:
            t_nodes[0].text = text
            
        for r in runs[1:]:
            first_p.remove(r)

    def _replace_image(self, shape_elem: etree._Element, image_path: str) -> None:
        """
        Delegates a path insertion down to the media processing library.
        
        Args:
            shape_elem (etree._Element): the parent graphic shape container.
            image_path (str): absolute or relative path to an imagery file on disk.
        """
        from .media import replace_picture_shape
        replace_picture_shape(self, shape_elem, image_path)

    def replace_chart_data(self, shape_name: str, data: Dict[Any, List[Any]], categories: List[str]) -> None:
        """
        Overwrites the series and category bindings on an embedded template slide chart.
        
        Args:
            shape_name (str): The target internal string representing the chart.
            data (Dict[Any, List[Any]]): A mapping from Series identities to explicit axis value arrays.
            categories (List[str]): Extracted axis category names (e.g. Month headers).
        """
        from .charts import replace_chart_data
        replace_chart_data(self, shape_name, data, categories)

    def find_shapes(self, shape_type: Optional[Union[type, str]] = None, contains_text: Optional[str] = None) -> List[BaseShape]:
        """
        Queries the slide for shapes of a certain type or containing specific text.
        
        Args:
            shape_type (Optional[Union[type, str]]): A class type (e.g. Rect) or a case-insensitive string match for the class name.
            contains_text (Optional[str]): A text pattern (like '{{mustache}}') that the shape must contain.
            
        Returns:
            List[BaseShape]: A list of matching shape objects.
        """
        results = []
        for shape in self.shapes:
            match = True
            
            if shape_type:
                if isinstance(shape_type, type):
                    if not isinstance(shape, shape_type):
                        match = False
                elif isinstance(shape_type, str):
                    if shape_type.lower() not in shape.__class__.__name__.lower():
                        match = False
                        
            if match and contains_text:
                if not shape.has_text(contains_text):
                    match = False
                    
            if match:
                results.append(shape)
                
        return results

