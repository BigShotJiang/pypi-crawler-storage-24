from typing import Any

class Length(int):
    """
    Base class for length units. Inherits from int to natively represent EMUs
    (English Metric Units) while providing convenient conversion properties.
    """
    
    @property
    def inches(self) -> float:
        """Returns the length in inches."""
        return float(self) / 914400.0

    @property
    def cm(self) -> float:
        """Returns the length in centimeters."""
        return float(self) / 360000.0

    @property
    def pt(self) -> float:
        """Returns the length in points."""
        return float(self) / 12700.0

    @property
    def emu(self) -> int:
        """Returns the length in EMUs."""
        return int(self)


def Inches(val: float) -> Length:
    """Returns a Length object representing the given number of inches."""
    return Length(int(val * 914400))


def Cm(val: float) -> Length:
    """Returns a Length object representing the given number of centimeters."""
    return Length(int(val * 360000))


def Pt(val: float) -> Length:
    """Returns a Length object representing the given number of points."""
    return Length(int(val * 12700))


def Emu(val: int) -> Length:
    """Returns a Length object representing the given number of EMUs."""
    return Length(val)
