import pkgutil
from typing import List, Optional, Union
from .opc import OpcPackage, RelsPart
from .slide import Slide
from .xml_utils import xpath, qname, NAMESPACES
from lxml import etree

class Presentation:
    """
    High-level wrapper for editing a .pptx template presentation.
    
    Provides access to a sequence of slides, allowing for insertion, manipulation,
    and deletion of PowerPoint slides within a strictly validated OPC package.
    """
    
    def __init__(self, template_path_or_bytes: Optional[Union[str, bytes]] = None) -> None:
        """
        Initializes a new Presentation object by wrapping an existing `.pptx` payload,
        or creating a new blank presentation if no argument is provided.
        
        Args:
            template_path_or_bytes (Optional[Union[str, bytes]]): A valid file path string or raw zip bytes payload. Defaults to None.
        """
        if template_path_or_bytes is None:
            template_bytes = pkgutil.get_data("pptxizza", "templates/default.pptx")
            if template_bytes is None:
                raise RuntimeError("Could not load default presentation template.")
            template_path_or_bytes = template_bytes

        self._package: OpcPackage = OpcPackage(template_path_or_bytes)
        self.slides: List[Slide] = []
        self._load_slides()

    def _load_slides(self) -> None:
        """
        Discovers and structures slides by parsing the master `ppt/presentation.xml` directory mapping.
        
        Raises:
            ValueError: If the underlying presentation.xml is missing entirely.
        """
        pres_xml = self._package.get_xml_part("ppt/presentation.xml")
        if pres_xml is None:
            raise ValueError("Invalid pptx: Missing ppt/presentation.xml")

        pres_rels = self._package.get_rels("ppt/presentation.xml")
        
        sld_id_lst = xpath(pres_xml, "p:sldIdLst/p:sldId")
        for sld_id_node in sld_id_lst:
            rId = sld_id_node.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
            
            # Find the target xml file for this slide in the presentation rels
            rel = pres_rels.rels.get(rId)
            if not rel:
                continue

            target: str = rel["Target"]
            # target is likely "slides/slide1.xml", so resolve relative to ppt/
            slide_part_name = f"ppt/{target}"
            
            # Initialize Slide
            self.slides.append(Slide(self._package, slide_part_name))

    def insert_slide(self, index: Optional[int] = None, source_slide_index: int = 0) -> Slide:
        """
        Inserts a slide into the visual succession list. If the presentation already has slides,
        it uniformly duplicates an existing template slide structure. If the presentation is empty,
        it inserts a completely blank new slide linked to an available layout.
        
        Args:
            index (Optional[int]): Target insertion index. If None, appends to the end.
            source_slide_index (int): Index of the template slide to duplicate the XML markup from (default 0).
            
        Returns:
            Slide: The newly created unreferenced Slide wrapper instance.
        """
        existing_slides = [s for s in self._package._parts.keys() if s.startswith("ppt/slides/slide") and s.endswith(".xml")]
        nums: List[int] = []
        for s in existing_slides:
            try:
                nums.append(int(s.replace("ppt/slides/slide", "").replace(".xml", "")))
            except ValueError:
                pass
        next_num = max(nums) + 1 if nums else 1

        new_part_name = f"ppt/slides/slide{next_num}.xml"

        if not self.slides:
            # Create a completely blank slide
            blank_slide_xml = (
                b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                b'<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
                b'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
                b'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">\n'
                b'    <p:cSld>\n'
                b'        <p:spTree>\n'
                b'            <p:nvGrpSpPr>\n'
                b'                <p:cNvPr id="1" name=""/>\n'
                b'                <p:cNvGrpSpPr/>\n'
                b'                <p:nvPr/>\n'
                b'            </p:nvGrpSpPr>\n'
                b'            <p:grpSpPr>\n'
                b'                <a:xfrm>\n'
                b'                    <a:off x="0" y="0"/>\n'
                b'                    <a:ext cx="0" cy="0"/>\n'
                b'                    <a:chOff x="0" y="0"/>\n'
                b'                    <a:chExt cx="0" cy="0"/>\n'
                b'                </a:xfrm>\n'
                b'            </p:grpSpPr>\n'
                b'        </p:spTree>\n'
                b'    </p:cSld>\n'
                b'    <p:clrMapOvr>\n'
                b'        <a:masterClrMapping/>\n'
                b'    </p:clrMapOvr>\n'
                b'</p:sld>'
            )
            self._package.set_part(new_part_name, blank_slide_xml)

            # Link to the first available slide layout in the package, or fallback
            layouts = [s for s in self._package._parts.keys() if s.startswith("ppt/slideLayouts/slideLayout") and s.endswith(".xml")]
            if layouts:
                # E.g., "ppt/slideLayouts/slideLayout6.xml" -> "../slideLayouts/slideLayout6.xml"
                rel_target = "../" + layouts[0].replace("ppt/", "")
            else:
                rel_target = "../slideLayouts/slideLayout1.xml"

            blank_rels_xml = (
                '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\n'
                f'  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="{rel_target}"/>\n'
                '</Relationships>'
            ).encode("utf-8")
            
            new_rels = RelsPart(blank_rels_xml)
            self._package._rels_parts[new_part_name] = new_rels

        else:
            source_slide = self.slides[source_slide_index]
            source_part_name = source_slide.part_name

            # Copy XML part
            source_part = self._package.get_part(source_part_name)
            if source_part is not None:
                self._package.set_part(new_part_name, source_part)

            # Copy rels
            source_rels = self._package.get_rels(source_part_name)
            new_rels = RelsPart(source_rels.to_xml())
            self._package._rels_parts[new_part_name] = new_rels

        # Register in [Content_Types].xml
        self._package.content_types.add_override(f"/{new_part_name}", "application/vnd.openxmlformats-officedocument.presentationml.slide+xml")

        pres_xml = self._package.get_xml_part("ppt/presentation.xml")
        pres_rels = self._package.get_rels("ppt/presentation.xml")
        
        if pres_xml is None:
            raise ValueError("Missing ppt/presentation.xml")
            
        # Add presentation relationship
        new_rid = pres_rels.add_relationship("http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide", f"slides/slide{next_num}.xml")
        
        sldIdLst_nodes = xpath(pres_xml, "p:sldIdLst")
        if sldIdLst_nodes:
            sldIdLst = sldIdLst_nodes[0]
        else:
            sldIdLst = etree.Element(qname("p", "sldIdLst"), nsmap=pres_xml.nsmap)
            sldSz_nodes = xpath(pres_xml, "p:sldSz")
            if sldSz_nodes:
                sldSz_nodes[0].addprevious(sldIdLst)
            else:
                pres_xml.append(sldIdLst)
        
        existing_sdl_ids = [int(node.get("id", "0")) for node in xpath(sldIdLst, "p:sldId") if node.get("id")]
        next_sld_id = max(existing_sdl_ids) + 1 if existing_sdl_ids else 256
        
        new_sldId_elem = etree.Element(qname("p", "sldId"), id=str(next_sld_id), nsmap={"r": NAMESPACES["r"]})
        new_sldId_elem.set(qname("r", "id"), new_rid)
        
        new_slide = Slide(self._package, new_part_name)
        if index is None or index >= len(self.slides):
            sldIdLst.append(new_sldId_elem)
            self.slides.append(new_slide)
        else:
            sldIdLst.insert(index, new_sldId_elem)
            self.slides.insert(index, new_slide)
            
        self._package.set_xml_part("ppt/presentation.xml", pres_xml)
        return new_slide

    def delete_slide(self, index: int) -> None:
        """
        Removes the slide at the specified positional index from the presentation's valid sequence.
        
        Args:
            index (int): A zero-based numeric offset referring to the active target slide.
            
        Raises:
            IndexError: If the numerical index references a slide outside the range of total slides.
        """
        if index < 0 or index >= len(self.slides):
            raise IndexError("Slide index out of range")
        
        slide_to_delete = self.slides[index]
        pres_xml = self._package.get_xml_part("ppt/presentation.xml")
        pres_rels = self._package.get_rels("ppt/presentation.xml")
        
        if pres_xml is None:
            return

        target_rel = "slides/" + slide_to_delete.part_name.split("/")[-1]
        
        rId_to_remove: Optional[str] = None
        for rid, rel in pres_rels.rels.items():
            if rel["Target"] == target_rel:
                rId_to_remove = rid
                break
                
        if rId_to_remove:
            sldIdLst_nodes = xpath(pres_xml, "p:sldIdLst")
            if sldIdLst_nodes:
                sldIdLst = sldIdLst_nodes[0]
                for sldId_node in xpath(sldIdLst, "p:sldId"):
                    if sldId_node.get(qname("r", "id")) == rId_to_remove:
                        sldIdLst.remove(sldId_node)
                        break
                    
        self._package.set_xml_part("ppt/presentation.xml", pres_xml)
        del self.slides[index]

    def save(self, filepath: str) -> None:
        """
        Saves current package modifications logically into a compiled target filesystem path.
        
        Args:
            filepath (str): The valid target zip output '.pptx' string format filename.
        """
        # Ensure all slides commit their XML changes
        for slide in self.slides:
            slide._commit_changes()
        
        self._package.save(filepath)

    def find_shapes(self, shape_type: Optional[Union[type, str]] = None, contains_text: Optional[str] = None) -> List["BaseShape"]:
        """
        Queries the entire presentation for shapes of a certain type or containing specific text.
        
        Args:
            shape_type (Optional[Union[type, str]]): A class type (e.g. Rect) or a case-insensitive string match for the class name.
            contains_text (Optional[str]): A text pattern (like '{{mustache}}') that the shape must contain.
            
        Returns:
            List[BaseShape]: A list of matching shape objects found across all slides.
        """
        from .shapes import BaseShape
        results = []
        for slide in self.slides:
            results.extend(slide.find_shapes(shape_type=shape_type, contains_text=contains_text))
        return results
