from typing import Optional, List, Union
from lxml import etree
from .colors import Color, HexColor, RGBColor
from .util import Length
from .xml_utils import qname

class Run:
    """
    Represents a uniquely styled segment of text within a paragraph.
    """
    def __init__(self, text: str, bold: Optional[bool] = None, italic: Optional[bool] = None,
                 size: Optional[Length] = None, color: Optional[Union[Color, str, tuple]] = None, font_name: Optional[str] = None) -> None:
        self.text = text
        self.bold = bold
        self.italic = italic
        self.size = size
        self.font_name = font_name
        
        if isinstance(color, str):
            self.color = HexColor(color)
        elif isinstance(color, tuple) and len(color) == 3:
            self.color = RGBColor(*color)
        else:
            self.color = color

    def to_xml_element(self) -> etree._Element:
        """
        Serializes the run configuration into a formal drawingML `<a:r>` node.
        
        Returns:
            etree._Element: The serialized XML element.
        """
        r_elem = etree.Element(qname("a", "r"))
        rPr_elem = etree.Element(qname("a", "rPr"))
        
        # Assign language tag universally so PPT doesn't complain about spellcheck
        rPr_elem.set("lang", "en-US")
        
        if self.bold is not None:
            rPr_elem.set("b", "1" if self.bold else "0")
        if self.italic is not None:
            rPr_elem.set("i", "1" if self.italic else "0")
        if self.size is not None:
            sz_val = int(round(int(self.size) / 127.0))
            rPr_elem.set("sz", str(sz_val))
            
        if self.color is not None:
            solid_fill = etree.SubElement(rPr_elem, qname("a", "solidFill"))
            solid_fill.append(self.color._get_color_node())
            
        if self.font_name is not None:
            latin = etree.SubElement(rPr_elem, qname("a", "latin"))
            latin.set("typeface", self.font_name)
            
        r_elem.append(rPr_elem)
        
        t_elem = etree.SubElement(r_elem, qname("a", "t"))
        t_elem.text = self.text
        
        return r_elem


class Text:
    """
    Manages a single paragraph containing an ordered collection of styled runs.
    Can be assigned directly to shape `text` properties.
    """
    def __init__(self, *runs: Run) -> None:
        self.runs: List[Run] = list(runs)
        
    def add_run(self, text: str, bold: Optional[bool] = None, italic: Optional[bool] = None,
                 size: Optional[Length] = None, color: Optional[Union[Color, str, tuple]] = None, font_name: Optional[str] = None) -> Run:
        """
        Dynamically appends a new richly styled text run sequence.
        
        Args:
            text (str): The literal string content.
            bold (Optional[bool]): Formats the chunk to bold layout.
            italic (Optional[bool]): Formats the chunk obliquely in layout.
            size (Optional[Length]): Custom Length class bounds for point resizing.
            color (Optional[Color]): Custom object mappings for filling foreground text.
            font_name (Optional[str]): The literal string rendering font (e.g. Arial).
            
        Returns:
            Run: The newly initialized object node.
        """
        run = Run(text=text, bold=bold, italic=italic, size=size, color=color, font_name=font_name)
        self.runs.append(run)
        return run
        
    def to_xml_element(self) -> etree._Element:
        """
        Delegates serialization of internal runs mapped back to a standard `<a:p>`.
        
        Returns:
            etree._Element: The raw paragraph XML block element.
        """
        p_elem = etree.Element(qname("a", "p"))
        
        for run in self.runs:
            p_elem.append(run.to_xml_element())
            
        if not self.runs:
            r_elem = etree.SubElement(p_elem, qname("a", "r"))
            etree.SubElement(r_elem, qname("a", "rPr"), lang="en-US")
            etree.SubElement(r_elem, qname("a", "t"))
            
        return p_elem
