import os
from typing import Tuple, Any
from .opc import OpcPackage
from .xml_utils import etree, xpath, qname

# Register the MS Drawing 2010 namespace mapping locally for SVG extension parsing
ASVG_NS = "http://schemas.microsoft.com/office/drawing/2016/SVG/main"

def add_image_to_package(package: OpcPackage, image_path: str) -> Tuple[str, str]:
    """
    Reads an external image file, injects it into the `ppt/media/` index context, 
    registers constraints matching `[Content_Types].xml`, and returns the relation payload identifier.
    
    Args:
        package (OpcPackage): Active open document Zip builder proxy.
        image_path (str): Relative or absolute target referring image bytes output.
        
    Returns:
        Tuple[str, str]: A tuple containing the new internal zip part string (e.g., 'ppt/media/img1.png') and its corresponding dot formatted extension (e.g. '.png').
        
    Raises:
        ValueError: If the file type payload provided throws unsupported format conditions.
    """
    with open(image_path, "rb") as f:
        img_bytes = f.read()

    ext = os.path.splitext(image_path)[1].lower()
    
    if ext == ".svg":
        content_type = "image/svg+xml"
    elif ext == ".png":
        content_type = "image/png"
    elif ext in [".jpeg", ".jpg"]:
        content_type = "image/jpeg"
    else:
        raise ValueError(f"Unsupported image extension: {ext}")

    package.content_types.add_default(ext, content_type)

    existing_images = []
    for part in package._parts.keys():
        if part.startswith("ppt/media/image") and part.endswith(ext):
            num_str = part[len("ppt/media/image"):-len(ext)]
            if num_str.isdigit():
                existing_images.append(int(num_str))
    
    next_id = max(existing_images) + 1 if existing_images else 1
    new_part_name = f"ppt/media/image{next_id}{ext}"
    
    package.set_part(new_part_name, img_bytes)
    
    return new_part_name, ext

def replace_picture_shape(slide: Any, shape_elem: etree._Element, image_path: str) -> None:
    """
    In-places replaces the target image binding metadata inside a given `<p:pic>` node placeholder using 
    a fresh external data payload securely resolved.
    
    Args:
        slide (Slide): Parent rendering interface wrapping target relationship injections.
        shape_elem (etree._Element): Base `<p:pic>` frame element targeted for modification.
        image_path (str): Fully resolved payload path providing replacement byte data.
        
    Raises:
        ValueError: If the underlying tag implies a pure vector AutoShape unable to natively accept imagery payloads.
    """
    new_part_name, ext = add_image_to_package(slide._package, image_path)
    
    rel_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image"
    relative_target = f"../media/{os.path.basename(new_part_name)}"
    
    slide_rels = slide._package.get_rels(slide.part_name)
    rId = slide_rels.add_relationship(rel_type, relative_target)

    blipFill = xpath(shape_elem, "p:blipFill")
    if not blipFill:
        raise ValueError("Cannot replace image on a non-picture shape (missing p:blipFill)")
    
    blipFill_elem = blipFill[0]
    blip = xpath(blipFill_elem, "a:blip")
    if not blip:
        blip_elem = etree.SubElement(blipFill_elem, qname("a", "blip"))
    else:
        blip_elem = blip[0]

    if ext == ".svg":
        dummy_part_name = "ppt/media/dummy_fallback.png"
        if not slide._package.get_part(dummy_part_name):
            import os
            fallback_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "tests", "fixtures", "test_image.png"))
            with open(fallback_path, "rb") as f:
                slide._package.set_part(dummy_part_name, f.read())
            slide._package.content_types.add_default("png", "image/png")
            
        dummy_rId = slide_rels.add_relationship(rel_type, "../media/dummy_fallback.png")
        blip_elem.set(qname("r", "embed"), dummy_rId)
        
        extLst = xpath(blip_elem, "a:extLst")
        if not extLst:
            extLst_elem = etree.SubElement(blip_elem, qname("a", "extLst"))
        else:
            extLst_elem = extLst[0]
            
        ext_tag = xpath(extLst_elem, "a:ext[@uri='{96DAC541-7B7A-43D3-8B79-37D633B846F1}']")
        if not ext_tag:
            ext_tag_elem = etree.SubElement(extLst_elem, qname("a", "ext"), uri="{96DAC541-7B7A-43D3-8B79-37D633B846F1}")
        else:
            ext_tag_elem = ext_tag[0]
            for child in list(ext_tag_elem):
                ext_tag_elem.remove(child)
                
        svgBlip = etree.SubElement(ext_tag_elem, f"{{{ASVG_NS}}}svgBlip", nsmap={"asvg": ASVG_NS})
        svgBlip.set(qname("r", "embed"), rId)
        
    else:
        blip_elem.set(qname("r", "embed"), rId)
        extLst = xpath(blip_elem, "a:extLst")
        if extLst:
            ext_tag = xpath(extLst[0], "a:ext[@uri='{96DAC541-7B7A-43D3-8B79-37D633B846F1}']")
            if ext_tag:
                extLst[0].remove(ext_tag[0])
