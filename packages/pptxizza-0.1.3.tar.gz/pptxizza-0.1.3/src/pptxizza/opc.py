import os
import zipfile
import io
from typing import Dict, Optional, Any, Union
from lxml import etree
from .xml_utils import NAMESPACES, parse_xml, to_xml, xpath, qname

class RelsPart:
    """
    Handles parsing, adding, and serializing relationships for an individual `.rels` XML part.
    """
    def __init__(self, xml_bytes: Optional[bytes] = None) -> None:
        """
        Initializes the relationship part using raw bytes if present.
        
        Args:
            xml_bytes (Optional[bytes]): The raw XML content of a .rels file. Defaults to None to create an empty map.
        """
        if xml_bytes:
            self.root: etree._Element = parse_xml(xml_bytes)
        else:
            self.root = etree.Element(qname("rel", "Relationships"), nsmap={None: NAMESPACES["rel"]})  # type: ignore
        
        self.rels: Dict[str, Dict[str, str]] = {}
        self._load_rels()

    def _load_rels(self) -> None:
        """Internal helper to load relationship definitions from the XML root."""
        for rel_elem in xpath(self.root, "rel:Relationship"):
            rid: str = str(rel_elem.get("Id", ""))
            self.rels[rid] = {
                "Type": str(rel_elem.get("Type", "")),
                "Target": str(rel_elem.get("Target", "")),
                "TargetMode": str(rel_elem.get("TargetMode", "Internal"))
            }

    def add_relationship(self, rel_type: str, target: str, target_mode: str = "Internal") -> str:
        """
        Adds a new relationship entry dynamically and returns its allocated rId keyword.
        
        Args:
            rel_type (str): The OpenXML schema specifier Type URI.
            target (str): The relational file mapping payload target.
            target_mode (str): Specifies if it is external or internal. Default is 'Internal'.
            
        Returns:
            str: The auto-generated unique relation ID (e.g. 'rId5').
        """
        existing_ids = [int(rid.replace("rId", "")) for rid in self.rels.keys() if rid.startswith("rId") and rid.replace("rId", "").isdigit()]
        next_id_num = max(existing_ids) + 1 if existing_ids else 1
        new_rid = f"rId{next_id_num}"
        
        rel_elem = etree.SubElement(self.root, qname("rel", "Relationship"))
        rel_elem.set("Id", new_rid)
        rel_elem.set("Type", rel_type)
        rel_elem.set("Target", target)
        if target_mode != "Internal":
            rel_elem.set("TargetMode", target_mode)
        
        self.rels[new_rid] = {"Type": rel_type, "Target": target, "TargetMode": target_mode}
        return new_rid

    def to_xml(self) -> bytes:
        """
        Serializes the relationships map back to XML bytes.
        
        Returns:
            bytes: The encoded .rels bytearray.
        """
        return to_xml(self.root)

class ContentTypesPart:
    """
    Handles overriding and enumerating types inside `[Content_Types].xml`.
    """
    def __init__(self, xml_bytes: bytes) -> None:
        """
        Initializes by parsing the centralized package mapping manifest.
        
        Args:
            xml_bytes (bytes): The raw [Content_Types].xml bytes.
        """
        self.root: etree._Element = parse_xml(xml_bytes)

    def add_override(self, part_name: str, content_type: str) -> None:
        """
        Adds an Override entry ensuring it does not overlap an existing path assignment.
        
        Args:
            part_name (str): The absolute package component path mapping (e.g. '/ppt/media/image1.png').
            content_type (str): The MIME type matching pattern standard.
        """
        if not part_name.startswith("/"):
            part_name = "/" + part_name
        
        existing = xpath(self.root, f"ct:Override[@PartName='{part_name}']")
        if not existing:
            etree.SubElement(self.root, qname("ct", "Override"), PartName=part_name, ContentType=content_type)

    def add_default(self, extension: str, content_type: str) -> None:
        """
        Adds a Default MIME type entry for an extension uniformly.
        
        Args:
            extension (str): The raw dot extension (e.g., 'png').
            content_type (str): The default resolved Content Type schema URI.
        """
        extension = extension.lstrip(".")
        existing = xpath(self.root, f"ct:Default[@Extension='{extension}']")
        if not existing:
            etree.SubElement(self.root, qname("ct", "Default"), Extension=extension, ContentType=content_type)

    def to_xml(self) -> bytes:
        """
        Serializes the content-type overrides array to raw byte forms.
        
        Returns:
            bytes: Bytecode output encoded for insertion in zip.
        """
        return to_xml(self.root)

class OpcPackage:
    """
    Represents the unzipped OPC (Open Packaging Conventions) package structure in memory.
    """
    
    def __init__(self, file_path_or_bytes: Union[str, bytes]) -> None:
        """
        Reads all embedded files identically from a disk directory wrapper to a fast internal map.
        
        Args:
            file_path_or_bytes (Union[str, bytes]): Path to the archive or in-memory byte buffer.
            
        Raises:
            ValueError: If the master zip lacks a [Content_Types].xml.
        """
        self._parts: Dict[str, bytes] = {}
        self._rels_parts: Dict[str, RelsPart] = {}
        
        file_obj = io.BytesIO(file_path_or_bytes) if isinstance(file_path_or_bytes, bytes) else file_path_or_bytes

        with zipfile.ZipFile(file_obj, "r") as zf:
            for item in zf.infolist():
                self._parts[item.filename] = zf.read(item.filename)
        
        if "[Content_Types].xml" in self._parts:
            self.content_types: ContentTypesPart = ContentTypesPart(self._parts["[Content_Types].xml"])
        else:
            raise ValueError("Not a valid OPC package: missing [Content_Types].xml")
            
        self._parse_rels()

    def _parse_rels(self) -> None:
        """Internal system mapping .rels files in relative contexts."""
        for filename in list(self._parts.keys()):
            directory, name = os.path.split(filename)
            if directory.endswith("_rels") and name.endswith(".rels"):
                base_dir = os.path.dirname(directory)
                source_part = os.path.join(base_dir, name[:-5]).replace("\\", "/") 
                self._rels_parts[source_part] = RelsPart(self._parts[filename])
        
        if "_rels/.rels" in self._parts:
            self._rels_parts["/"] = RelsPart(self._parts["_rels/.rels"])

    def get_part(self, part_name: str) -> Optional[bytes]:
        """
        Gets raw bytes mapping for a known item part.
        
        Args:
            part_name (str): Relative zip identifier schema.
            
        Returns:
            Optional[bytes]: Byte stream found or None.
        """
        part_name = part_name.lstrip("/")
        return self._parts.get(part_name)

    def get_xml_part(self, part_name: str) -> Optional[etree._Element]:
        """
        Gets auto-parsed XML schema output mapping the item part structurally.
        
        Args:
            part_name (str): The valid target document file inside zip.
            
        Returns:
            Optional[etree._Element]: Full lxml element parsed or None.
        """
        part_name = part_name.lstrip("/")
        xml_bytes = self._parts.get(part_name)
        return parse_xml(xml_bytes) if xml_bytes else None

    def set_part(self, part_name: str, content: bytes) -> None:
        """
        Sets raw bytes overwrite internally overriding data manually.
        
        Args:
            part_name (str): Path of standard zip member structure.
            content (bytes): Full target blob buffer format byte array payload.
        """
        part_name = part_name.lstrip("/")
        self._parts[part_name] = content

    def set_xml_part(self, part_name: str, root: etree._Element) -> None:
        """
        Sets parsed XML overriding root element.
        
        Args:
            part_name (str): Virtual root zip index pointer node target.
            root (etree._Element): Valid active generated tag element tree.
        """
        part_name = part_name.lstrip("/")
        self._parts[part_name] = to_xml(root)
        
    def get_rels(self, part_name: str) -> RelsPart:
        """
        Gets or creates the RelsPart mapping context handler for a specific active component part.
        
        Args:
            part_name (str): Path of source referring dependent links target structure.
            
        Returns:
            RelsPart: Operational linkage interface mapper class valid instance.
        """
        part_name = part_name.lstrip("/")
        if part_name not in self._rels_parts:
            self._rels_parts[part_name] = RelsPart()
        return self._rels_parts[part_name]

    def save(self, output_path: str) -> None:
        """
        Writes and compresses mapping structural components effectively out to conventional presentation outputs identically.
        
        Args:
            output_path (str): Intended logical target valid operating path output path (e.g., 'final.pptx').
        """
        self._parts["[Content_Types].xml"] = self.content_types.to_xml()
        
        for source_part, rels_part in self._rels_parts.items():
            if source_part == "/":
                rels_filename = "_rels/.rels"
            else:
                directory, name = os.path.split(source_part)
                rels_filename = os.path.join(directory, "_rels", f"{name}.rels").replace("\\", "/")
            self._parts[rels_filename] = rels_part.to_xml()

        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for part_name, content in self._parts.items():
                zf.writestr(part_name, content)
