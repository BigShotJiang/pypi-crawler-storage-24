from lxml import etree
import sys
import os

# Add src to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from pptxizza.shapes.table import Table

# Mock table XML with namespaces properly defined
TABLE_XML = """
<p:graphicFrame xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" 
                xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
    <p:nvGraphicFramePr>
        <p:cNvPr id="5" name="Table 4"/>
        <p:cNvGraphicFramePr/>
        <p:nvPr/>
    </p:nvGraphicFramePr>
    <p:xfrm>
        <a:off x="1524000" y="1524000"/>
        <a:ext cx="6096000" cy="741680"/>
    </p:xfrm>
    <a:graphic>
        <a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table">
            <a:tbl>
                <a:tblPr/>
                <a:tblGrid>
                    <a:gridCol w="3048000"/>
                    <a:gridCol w="3048000"/>
                </a:tblGrid>
                <a:tr h="370840">
                    <a:tc>
                        <a:txBody>
                            <a:bodyPr/>
                            <a:lstStyle/>
                            <a:p>
                                <a:r>
                                    <a:t>Header 1</a:t>
                                </a:r>
                            </a:p>
                        </a:txBody>
                        <a:tcPr/>
                    </a:tc>
                    <a:tc>
                        <a:txBody>
                            <a:bodyPr/>
                            <a:lstStyle/>
                            <a:p>
                                <a:r>
                                    <a:t>Header 2</a:t>
                                </a:r>
                            </a:p>
                        </a:txBody>
                        <a:tcPr/>
                    </a:tc>
                </a:tr>
            </a:tbl>
        </a:graphicData>
    </a:graphic>
</p:graphicFrame>
"""

def test_table():
    el = etree.fromstring(TABLE_XML.encode('utf-8'))
    table = Table(el)
    
    print("Testing initial state...")
    assert len(table.rows) == 1
    assert len(table.columns) == 2
    assert table.cell(0, 0).text == "Header 1"
    
    print("Testing cell text modification...")
    table.cell(0, 0).text = "Modified"
    assert table.cell(0, 0).text == "Modified"
    
    print("Testing add_row...")
    table.add_row()
    assert len(table.rows) == 2
    assert len(table.rows[1].cells) == 2
    
    print("Testing add_column...")
    table.add_column()
    assert len(table.columns) == 3
    assert len(table.rows[0].cells) == 3
    
    print("Testing style preset...")
    table.apply_preset("Medium Style 2 - Accent 1")
    assert table.style_id == "{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}"
    
    print("Testing remove_column...")
    table.remove_column(0)
    assert len(table.columns) == 2
    # The old column 1 (Header 2) should now be column 0
    assert table.cell(0, 0).text == "Header 2"
    
    print("Testing remove_row...")
    table.remove_row(0)
    assert len(table.rows) == 1
    
    print("Testing set_column_names...")
    table.set_column_names(["New Col 1", "New Col 2"])
    assert table.cell(0, 0).text == "New Col 1"
    assert table.cell(0, 1).text == "New Col 2"

if __name__ == "__main__":
    try:
        test_table()
        print("\nSUCCESS: All Table manipulation tests passed!")
    except Exception as e:
        print(f"\nFAILURE: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
