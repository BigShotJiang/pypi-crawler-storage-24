import os
from pptxizza import Presentation
from pptxizza.shapes import Picture

def test_insert_image():
    # Setup paths
    fixtures_dir = os.path.join(os.path.dirname(__file__), "fixtures")
    template_path = os.path.join(fixtures_dir, "simple_template.pptx")
    image_path = os.path.join(fixtures_dir, "test_image.png")
    svg_path = os.path.join(fixtures_dir, "ufo.svg")
    output_path = os.path.join(os.path.dirname(__file__), "test_output.pptx")

    # Ensure paths exist
    assert os.path.exists(template_path), f"Template not found: {template_path}"
    assert os.path.exists(image_path), f"Image not found: {image_path}"
    assert os.path.exists(svg_path), f"SVG not found: {svg_path}"

    if os.path.exists(output_path):
        os.remove(output_path)

    # Use pptxizza to load and modify
    pres = Presentation(template_path)
    slide = pres.slides[0]

    # Test backward compatibility: Insert the image into the shape named 'TestPic' via fill method
    slide.fill({"TestPic": image_path})

    # Test Object-Oriented insertion: Insert the UFO SVG dynamically
    ufo_pic = Picture(image_path=svg_path, x=2000000, y=2000000, cx=2000000, cy=2000000)
    slide.insert_shape(ufo_pic)

    # Save the modified presentation
    pres.save(output_path)

    # Verify the output exists
    assert os.path.exists(output_path)
    print("Test passed. Modified presentation saved to", output_path)
