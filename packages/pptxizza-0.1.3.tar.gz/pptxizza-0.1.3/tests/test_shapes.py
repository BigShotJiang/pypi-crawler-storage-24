import os
import pytest
from pptxizza.presentation import Presentation
from pptxizza.shapes import Shape, TextBox

def test_shape_manipulation():
    pres = Presentation("tests/test_output.pptx")
    slide = pres.slides[0]
    initial_count = len(slide.shapes)
    
    # Insert
    new_shape = Shape(text="Hello", x=100000, y=200000, cx=300000, cy=400000)
    slide.insert_shape(new_shape)
    assert new_shape is not None
    assert new_shape.text == "Hello"
    assert new_shape.x == 100000
    assert new_shape.y == 200000
    assert len(slide.shapes) == initial_count + 1
    
    # Modify
    new_shape.x_inches = 2.0
    new_shape.y_inches = 3.0
    assert new_shape.x == int(2.0 * 914400)
    assert new_shape.y == int(3.0 * 914400)
    
    # Modify Name
    new_shape.shape_name = "MyTestShape123"
    assert new_shape.shape_name == "MyTestShape123"
    
    # Save to verify no errors
    pres.save("tests/test_shapes_output.pptx")
    
    # Reload and verify
    pres2 = Presentation("tests/test_shapes_output.pptx")
    slide2 = pres2.slides[0]
    assert len(slide2.shapes) == initial_count + 1
    found_shape = None
    for sp in slide2.shapes:
        if sp.shape_name == "MyTestShape123":
            found_shape = sp
            break
    assert found_shape is not None
    assert found_shape.x == int(2.0 * 914400)
    
    # Delete
    assert slide2.delete_shape(found_shape) is True
    assert len(slide2.shapes) == initial_count

def test_textbox_manipulation():
    pres = Presentation("tests/test_output.pptx")
    slide = pres.slides[0]
    initial_count = len(slide.shapes)
    
    # Insert TextBox
    tb = TextBox(text="My TextBox Text", x=500000, y=500000, cx=2000000, cy=1000000)
    slide.insert_shape(tb)
    
    assert tb.text == "My TextBox Text"
    
    # Save to verify no errors
    pres.save("tests/test_shapes_output.pptx")
    
    # Reload and verify factory creates TextBox
    pres2 = Presentation("tests/test_shapes_output.pptx")
    slide2 = pres2.slides[0]
    assert len(slide2.shapes) == initial_count + 1
    
    found_tb = None
    for sp in slide2.shapes:
        if isinstance(sp, TextBox):
            found_tb = sp
            break
            
    assert found_tb is not None
    assert found_tb.text == "My TextBox Text"

