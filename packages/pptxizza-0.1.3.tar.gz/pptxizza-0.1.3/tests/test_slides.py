import os
import pytest
from pptxizza.presentation import Presentation
from pptxizza.shapes import Shape

def test_slide_manipulation():
    pres = Presentation("tests/test_output.pptx")
    initial_count = len(pres.slides)
    
    # Insert at the end
    new_slide = pres.insert_slide(source_slide_index=0)
    assert len(pres.slides) == initial_count + 1
    assert new_slide is not None
    
    # Modify something on the new slide
    shape = Shape(text="New Slide text", x=0, y=0, cx=1000000, cy=1000000)
    new_slide.insert_shape(shape)
    shape.shape_name = "AddedShape"
    
    # Delete slide 0
    pres.delete_slide(0)
    assert len(pres.slides) == initial_count
    
    # Save
    pres.save("tests/test_slides_output.pptx")
    
    # Reload and verify count
    pres2 = Presentation("tests/test_slides_output.pptx")
    assert len(pres2.slides) == initial_count
    
    # The new slide we added should now be at index 0 (since we deleted original 0 and maybe there was only 1)
    # Let's just check the last slide has the shape we added
    last_slide = pres2.slides[-1]
    has_sp = False
    for sp in last_slide.shapes:
        if sp.shape_name == "AddedShape":
            has_sp = True
            break
    assert has_sp is True
