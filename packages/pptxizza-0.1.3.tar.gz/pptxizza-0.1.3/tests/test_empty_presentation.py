import pytest
from pptxizza.presentation import Presentation

def test_insert_slide_empty_presentation():
    pres = Presentation()
    assert len(pres.slides) == 0

    # Insert a slide without providing an argument
    new_slide = pres.insert_slide()
    assert len(pres.slides) == 1
    assert pres.slides[0] == new_slide

    # Save to ensure it can be serialized without issues
    pres.save("tests/test_output_empty.pptx")

    # Reload to verify it was saved correctly
    pres2 = Presentation("tests/test_output_empty.pptx")
    assert len(pres2.slides) == 1

def test_insert_multiple_slides():
    pres = Presentation()
    pres.insert_slide()
    pres.insert_slide()
    
    assert len(pres.slides) == 2
    pres.save("tests/test_output_multiple_empty.pptx")
