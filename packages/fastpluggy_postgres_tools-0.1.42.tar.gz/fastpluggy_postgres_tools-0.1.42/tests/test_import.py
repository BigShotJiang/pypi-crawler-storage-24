def test_plugin_imports():
    """Smoke test: verify the plugin module imports without error."""
    import fastpluggy_plugin.postgres_tools.plugin  # noqa: F401
