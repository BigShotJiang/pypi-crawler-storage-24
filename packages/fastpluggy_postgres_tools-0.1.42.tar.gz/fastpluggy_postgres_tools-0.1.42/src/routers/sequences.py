from fastapi import APIRouter, Depends, Request
from sqlalchemy import text
from sqlalchemy.orm import Session

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.widgets import CustomTemplateWidget

sequences_router = APIRouter(prefix="/sequences", tags=["postgres_sequences"])

THRESHOLDS = {"warning": 50, "critical": 80}


def _format_big_number(n) -> str:
    """Format large integers into human-readable short form."""
    if n is None:
        return "N/A"
    n = int(n)
    if n < 0:
        return f"-{_format_big_number(-n)}"
    if n < 1_000:
        return str(n)
    if n < 1_000_000:
        return f"{n / 1_000:.1f}K"
    if n < 1_000_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n < 1_000_000_000_000:
        return f"{n / 1_000_000_000:.1f}B"
    if n < 1_000_000_000_000_000:
        return f"{n / 1_000_000_000_000:.1f}T"
    if n < 1_000_000_000_000_000_000:
        return f"{n / 1_000_000_000_000_000:.1f}Q"
    return f"{n:.2e}"


def _classify(percent_used: float) -> str:
    if percent_used >= THRESHOLDS["critical"]:
        return "critical"
    if percent_used >= THRESHOLDS["warning"]:
        return "warning"
    return "healthy"


def _bar_color(status: str) -> str:
    return {"critical": "danger", "warning": "warning", "healthy": "success"}[status]


def get_sequences_data(db: Session):
    query = text("""
        SELECT
            schemaname || '.' || sequencename AS sequence_name,
            last_value,
            max_value,
            COALESCE(max_value - last_value, 0) AS remaining
        FROM pg_sequences
        WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
        ORDER BY remaining ASC
    """)

    result = db.execute(query).mappings()
    rows = []
    for row in result:
        last_value = row["last_value"]
        max_value = row["max_value"]

        if last_value is None or max_value is None or max_value == 0:
            percent_used = 0.0
        else:
            percent_used = round((last_value * 100) / max_value, 2)

        status = _classify(percent_used)
        rows.append({
            "sequence_name": row["sequence_name"],
            "last_value": last_value,
            "max_value": max_value,
            "remaining": row["remaining"],
            "percent_used": percent_used,
            "status": status,
            "bar_color": _bar_color(status),
            "bar_width": max(percent_used, 0.5) if percent_used > 0 else 0,
            "last_display": _format_big_number(last_value),
            "max_display": _format_big_number(max_value),
            "remaining_display": _format_big_number(row["remaining"]),
        })
    return rows


@sequences_router.get("")
async def get_sequences_view(request: Request, db=Depends(get_db), view_builder=Depends(get_view_builder)):
    sequences = get_sequences_data(db)

    summary = {
        "total": len(sequences),
        "healthy": sum(1 for s in sequences if s["status"] == "healthy"),
        "warning": sum(1 for s in sequences if s["status"] == "warning"),
        "critical": sum(1 for s in sequences if s["status"] == "critical"),
    }

    widget = CustomTemplateWidget(
        template_name="postgres_tools/sequences.html.j2",
        context={"sequences": sequences, "summary": summary},
    )

    return view_builder.generate(
        request,
        title="Sequence Capacity",
        widgets=[widget],
    )
