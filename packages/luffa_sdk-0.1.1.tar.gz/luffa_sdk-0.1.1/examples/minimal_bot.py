"""Minimal Luffa bot — 10 lines."""

import os
from dotenv import load_dotenv
from luffa import LuffaBot

load_dotenv()
bot = LuffaBot(secret=os.getenv("BOT_SECRET"))


@bot.command("ping")
async def ping(msg):
    await msg.reply("Pong!")


@bot.on_message()
async def echo(msg):
    await msg.reply(f"You said: {msg.text}")


bot.run()
