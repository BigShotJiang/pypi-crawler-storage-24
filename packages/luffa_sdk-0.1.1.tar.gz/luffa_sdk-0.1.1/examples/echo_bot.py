"""
Example: Echo Bot

A minimal Luffa bot that echoes messages and demonstrates
commands, buttons, and confirm dialogs.

Usage:
    1. pip install luffa python-dotenv
    2. Create a .env file with BOT_SECRET=your-secret-key
    3. python echo_bot.py
"""

import os
from dotenv import load_dotenv
from luffa import LuffaBot, button, confirm_button

load_dotenv()
bot = LuffaBot(secret=os.getenv("BOT_SECRET"))


@bot.command("help")
async def help_cmd(msg):
    await msg.reply(
        "Available commands:\n"
        "/help - Show this message\n"
        "/ping - Check if bot is alive\n"
        "/echo <text> - Echo your message\n"
        "/quiz - A fun quiz question\n"
        "/menu - Show a button menu\n"
        "/about - About this bot"
    )


@bot.command("ping")
async def ping_cmd(msg):
    await msg.reply("Pong! Bot is running.")


@bot.command("about")
async def about_cmd(msg):
    await msg.reply("Echo Bot — built with the Luffa Python SDK.")


@bot.command("echo")
async def echo_cmd(msg):
    await msg.reply(" ".join(msg.args) if msg.args else "Usage: /echo <text>")


@bot.command("quiz")
async def quiz_cmd(msg):
    await msg.reply_confirm(
        "Is London the capital of the United Kingdom?",
        confirm=[
            confirm_button("Yes ✅", "/answer yes"),
            confirm_button("No ❌", "/answer no", style="destructive"),
        ],
    )


@bot.command("answer")
async def answer_cmd(msg):
    answer = msg.args[0].lower() if msg.args else None
    if answer == "yes":
        await msg.reply("Correct! 🎉")
    elif answer == "no":
        await msg.reply("Nope — London is the capital!")
    else:
        await msg.reply("Usage: /answer yes or /answer no")


@bot.command("menu")
async def menu_cmd(msg):
    await msg.reply_buttons(
        "What would you like to do?",
        buttons=[
            button("📋 Help", "/help"),
            button("🏓 Ping", "/ping"),
            button("ℹ️ About", "/about"),
        ],
    )


@bot.on_message()
async def fallback(msg):
    await msg.reply(f"You said: {msg.text}")


bot.run()
