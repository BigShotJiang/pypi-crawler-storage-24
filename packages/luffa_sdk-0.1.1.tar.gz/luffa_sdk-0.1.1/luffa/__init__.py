"""
Luffa Bot SDK
~~~~~~~~~~~~~

A Telegram-style Python SDK for the Luffa messaging platform.

Quickstart::

    from luffa import LuffaBot, button, confirm_button

    bot = LuffaBot(secret="your-secret")

    @bot.command("hello")
    async def hello(msg):
        await msg.reply("Hey there!")

    bot.run()

:copyright: (c) 2025
:license: MIT
"""

from .bot import LuffaBot
from .message import Message
from .components import button, confirm_button, mention

__all__ = [
    "LuffaBot",
    "Message",
    "button",
    "confirm_button",
    "mention",
]

__version__ = "0.1.0"
