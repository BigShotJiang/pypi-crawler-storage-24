"""Core bot class for the Luffa SDK."""

import json
import asyncio
from typing import Callable, Awaitable

import httpx

from .message import Message
from .components import button, confirm_button, mention  # noqa: F401

API_BASE = "https://apibot.luffa.im/robot"


class LuffaBot:
    """
    The main bot class. Register commands with decorators, then call run().

    Args:
        secret: Your bot's secret key from the Luffa Bot dashboard.
        poll_interval: Seconds between each poll (default 1).
        base_url: API base URL (override for testing).

    Example::

        from luffa import LuffaBot

        bot = LuffaBot(secret="your-secret")

        @bot.command("hello")
        async def hello(msg):
            await msg.reply(f"Hey {msg.sender_uid}!")

        bot.run()
    """

    def __init__(
        self,
        secret: str,
        poll_interval: float = 1,
        base_url: str = API_BASE,
    ):
        if not secret:
            raise ValueError("Bot secret is required. Pass it directly or set BOT_SECRET in .env")

        self.secret = secret
        self.poll_interval = poll_interval
        self.base_url = base_url

        self._client: httpx.AsyncClient | None = None
        self._commands: dict[str, Callable[[Message], Awaitable]] = {}
        self._message_handler: Callable[[Message], Awaitable] | None = None
        self._seen: set[str] = set()
        self._max_seen = 10_000

    # --- Decorators ---

    def command(self, name: str):
        """
        Register a command handler. Commands are matched without the leading ``/``.

        Args:
            name: The command name (without ``/``). Case-insensitive.

        Example::

            @bot.command("ping")
            async def ping(msg):
                await msg.reply("Pong!")
        """
        def decorator(func: Callable[[Message], Awaitable]):
            self._commands[name.lstrip("/").lower()] = func
            return func
        return decorator

    def on_message(self):
        """
        Register a fallback handler for non-command messages.
        Also fires when a command is received but has no registered handler.

        Example::

            @bot.on_message()
            async def fallback(msg):
                await msg.reply(f"You said: {msg.text}")
        """
        def decorator(func: Callable[[Message], Awaitable]):
            self._message_handler = func
            return func
        return decorator

    # --- Send Methods ---

    async def send_text(self, uid: str, text: str) -> bool:
        """
        Send a private text message.

        Args:
            uid: Recipient's Luffa user ID.
            text: Message text. Supports ``\\n`` for newlines.

        Returns:
            ``True`` if sent successfully, ``False`` on error.
        """
        try:
            await self._client.post(
                f"{self.base_url}/send",
                json={
                    "secret": self.secret,
                    "uid": uid,
                    "msg": json.dumps({"text": text}),
                },
            )
            return True
        except Exception as err:
            print(f"[Luffa] Send error ({uid}): {err}")
            return False

    async def send_group_text(
        self,
        uid: str,
        text: str,
        at_list: list[dict] | None = None,
    ) -> bool:
        """
        Send a plain text message to a group.

        Args:
            uid: Luffa group ID.
            text: Message text. Supports ``\\n`` for newlines.
            at_list: Optional list of @mentions (use :func:`mention` to create).

        Returns:
            ``True`` if sent successfully, ``False`` on error.
        """
        msg: dict = {"text": text}
        if at_list:
            msg["atList"] = at_list
        return await self._send_group_raw(uid, msg, msg_type="1")

    async def send_group_buttons(
        self,
        uid: str,
        text: str,
        buttons: list[dict],
        dismiss: str = "select",
        at_list: list[dict] | None = None,
    ) -> bool:
        """
        Send a group message with menu-style buttons.

        Args:
            uid: Luffa group ID.
            text: Message text.
            buttons: List of buttons (use :func:`button` to create).
            dismiss: ``"select"`` to keep buttons after tap, ``"dismiss"`` to hide them.
            at_list: Optional list of @mentions.

        Returns:
            ``True`` if sent successfully, ``False`` on error.
        """
        msg: dict = {
            "text": text,
            "button": buttons,
            "dismissType": dismiss,
        }
        if at_list:
            msg["atList"] = at_list
        return await self._send_group_raw(uid, msg, msg_type="2")

    async def send_group_confirm(
        self,
        uid: str,
        text: str,
        confirm: list[dict],
        dismiss: str = "dismiss",
        at_list: list[dict] | None = None,
    ) -> bool:
        """
        Send a group message with confirm-style buttons (typically 2 side-by-side).

        Args:
            uid: Luffa group ID.
            text: Message text.
            confirm: List of confirm buttons (use :func:`confirm_button` to create).
            dismiss: ``"select"`` to keep buttons after tap, ``"dismiss"`` to hide them.
            at_list: Optional list of @mentions.

        Returns:
            ``True`` if sent successfully, ``False`` on error.
        """
        msg: dict = {
            "text": text,
            "confirm": confirm,
            "dismissType": dismiss,
        }
        if at_list:
            msg["atList"] = at_list
        return await self._send_group_raw(uid, msg, msg_type="2")

    # --- Run ---

    def run(self):
        """Start the bot. Blocks forever, polling for messages."""
        asyncio.run(self._loop())

    async def start(self):
        """Start the bot (async). Use when you already have an event loop running."""
        await self._loop()

    # --- Internals ---

    async def _loop(self):
        self._client = httpx.AsyncClient(timeout=30)
        try:
            print("[Luffa] Bot started. Polling for messages...")
            while True:
                messages = await self._receive()
                for msg in messages:
                    label = "Group" if msg.is_group else "PM"
                    group = f" in {msg.uid}" if msg.is_group else ""
                    print(f"[{label}] {msg.sender_uid}{group}: {msg.text}")
                    await self._dispatch(msg)
                await asyncio.sleep(self.poll_interval)
        except KeyboardInterrupt:
            print("\n[Luffa] Bot stopped.")
        finally:
            await self._client.aclose()

    async def _receive(self) -> list[Message]:
        try:
            resp = await self._client.post(
                f"{self.base_url}/receive",
                json={"secret": self.secret},
            )
            data = resp.json()
        except Exception as err:
            print(f"[Luffa] Receive error: {err}")
            return []

        if not isinstance(data, list):
            return []

        messages: list[Message] = []

        for entry in data:
            uid = entry.get("uid", "")
            raw_messages = entry.get("message", [])
            entry_type = entry.get("type")
            is_group = entry_type == "1" or entry_type == 1

            if not isinstance(raw_messages, list):
                continue

            for raw_msg in raw_messages:
                parsed = _parse(raw_msg)
                if not parsed:
                    continue

                msg_id = parsed.get("msgId")
                if msg_id:
                    if msg_id in self._seen:
                        continue
                    self._seen.add(msg_id)
                    if len(self._seen) > self._max_seen:
                        self._seen.pop()

                sender_uid = parsed.get("uid", uid) if is_group else uid

                msg = Message(
                    text=parsed.get("text", ""),
                    msg_id=msg_id,
                    uid=uid,
                    sender_uid=sender_uid,
                    is_group=is_group,
                    at_list=parsed.get("atList", []),
                    url_link=parsed.get("urlLink"),
                    raw=parsed,
                    _bot=self,
                )
                messages.append(msg)

        return messages

    async def _dispatch(self, msg: Message):
        text = msg.text.strip()
        if text.startswith("/"):
            parts = text.split()
            cmd_key = parts[0].lstrip("/").lower()
            msg.args = parts[1:]

            handler = self._commands.get(cmd_key)
            if handler:
                try:
                    await handler(msg)
                except Exception as err:
                    print(f"[Luffa] Command /{cmd_key} error: {err}")
                return

        if self._message_handler:
            try:
                await self._message_handler(msg)
            except Exception as err:
                print(f"[Luffa] on_message error: {err}")

    async def _send_group_raw(self, uid: str, msg: dict, msg_type: str) -> bool:
        try:
            await self._client.post(
                f"{self.base_url}/sendGroup",
                json={
                    "secret": self.secret,
                    "uid": uid,
                    "msg": json.dumps(msg),
                    "type": msg_type,
                },
            )
            return True
        except Exception as err:
            print(f"[Luffa] Group send error ({uid}): {err}")
            return False


def _parse(raw_msg: str) -> dict | None:
    """Parse a possibly double-encoded JSON message string."""
    try:
        parsed = json.loads(raw_msg)
        if isinstance(parsed, str):
            parsed = json.loads(parsed)
        return parsed
    except (json.JSONDecodeError, TypeError):
        return None
