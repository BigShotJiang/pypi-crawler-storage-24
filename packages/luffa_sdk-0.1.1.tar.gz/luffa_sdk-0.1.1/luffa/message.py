"""Message dataclass with built-in reply methods."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .bot import LuffaBot


@dataclass
class Message:
    """
    A received message with built-in reply methods.

    Attributes:
        text: The message text content.
        args: Command arguments (everything after the ``/command``).
            Empty list for non-command messages.
        msg_id: Unique message ID from Luffa.
        uid: The chat ID (user ID for private, group ID for group).
        sender_uid: The ID of the user who sent the message.
        is_group: Whether this message came from a group chat.
        at_list: List of @mentions in the message.
        url_link: Attached URL link, if any.
        raw: The raw parsed message dict from the API.
    """

    text: str = ""
    args: list[str] = field(default_factory=list)
    msg_id: str | None = None
    uid: str = ""
    sender_uid: str = ""
    is_group: bool = False
    at_list: list = field(default_factory=list)
    url_link: str | None = None
    raw: dict = field(default_factory=dict)

    _bot: LuffaBot | None = field(default=None, repr=False)

    async def reply(self, text: str) -> bool:
        """
        Reply with a text message. Automatically routes to private or group.

        Args:
            text: The reply text.

        Returns:
            ``True`` if sent successfully.
        """
        if self.is_group:
            return await self._bot.send_group_text(self.uid, text)
        return await self._bot.send_text(self.uid, text)

    async def reply_buttons(
        self,
        text: str,
        buttons: list[dict],
        dismiss: str = "select",
    ) -> bool:
        """
        Reply with menu-style buttons.

        In group chats, sends interactive buttons. In private chats,
        falls back to a plain text list since the API only supports
        buttons in groups.

        Args:
            text: The message text above the buttons.
            buttons: List of buttons (use :func:`~luffa.button` to create).
            dismiss: ``"select"`` (persist) or ``"dismiss"`` (disappear on tap).

        Returns:
            ``True`` if sent successfully.
        """
        if self.is_group:
            return await self._bot.send_group_buttons(self.uid, text, buttons, dismiss)
        lines = [text, ""]
        for btn in buttons:
            lines.append(f"• {btn['name']}  →  {btn['selector']}")
        return await self._bot.send_text(self.uid, "\n".join(lines))

    async def reply_confirm(
        self,
        text: str,
        confirm: list[dict],
        dismiss: str = "dismiss",
    ) -> bool:
        """
        Reply with confirm-style buttons (typically two side-by-side).

        In group chats, sends interactive confirm buttons. In private chats,
        falls back to a plain text list.

        Args:
            text: The message text above the buttons.
            confirm: List of confirm buttons (use :func:`~luffa.confirm_button` to create).
            dismiss: ``"select"`` (persist) or ``"dismiss"`` (disappear on tap).

        Returns:
            ``True`` if sent successfully.
        """
        if self.is_group:
            return await self._bot.send_group_confirm(self.uid, text, confirm, dismiss)
        lines = [text, ""]
        for btn in confirm:
            lines.append(f"• {btn['name']}  →  {btn['selector']}")
        return await self._bot.send_text(self.uid, "\n".join(lines))
