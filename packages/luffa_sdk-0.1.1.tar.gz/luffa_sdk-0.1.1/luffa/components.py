"""Component builders for interactive messages."""


def button(name: str, selector: str, hidden: bool = False) -> dict:
    """
    Create a menu-style button for group messages.

    Args:
        name: Button label. Supports Unicode and emoji.
        selector: Text sent back to the bot when the button is tapped.
        hidden: If ``True``, the tapped message is not visible to others in chat.

    Returns:
        A button dict ready to pass to :meth:`~luffa.Message.reply_buttons`.

    Example::

        from luffa import button

        buttons = [
            button("🔴 Red", "/pick red"),
            button("🔵 Blue", "/pick blue"),
        ]
    """
    return {
        "name": name,
        "selector": selector,
        "isHidden": "1" if hidden else "0",
    }


def confirm_button(
    name: str,
    selector: str,
    style: str = "default",
    hidden: bool = False,
) -> dict:
    """
    Create a confirm-style button for group messages.

    Confirm buttons are typically shown as two side-by-side options
    (e.g., Yes/No, Accept/Reject).

    Args:
        name: Button label. Supports Unicode and emoji.
        selector: Text sent back to the bot when the button is tapped.
        style: ``"default"`` (light background) or ``"destructive"`` (dark background).
        hidden: If ``True``, the tapped message is not visible to others in chat.

    Returns:
        A confirm button dict ready to pass to :meth:`~luffa.Message.reply_confirm`.

    Example::

        from luffa import confirm_button

        confirm = [
            confirm_button("Approve ✅", "/approve"),
            confirm_button("Reject ❌", "/reject", style="destructive"),
        ]
    """
    return {
        "name": name,
        "selector": selector,
        "type": style,
        "isHidden": "1" if hidden else "0",
    }


def mention(uid: str, location: int = 0, length: int = 12) -> dict:
    """
    Create an @mention for group messages.

    .. note::
        You must manually include ``@uid`` in your message text string.
        The mention component only controls the highlight/notification —
        it does not insert text automatically.

    Args:
        uid: Luffa user ID of the person to mention.
        location: Starting index of the ``@`` character in the text string.
        length: Length of the highlighted portion (default 12 = ``@`` + uid + space).

    Returns:
        A mention dict ready to pass to ``at_list`` parameters.

    Example::

        from luffa import mention

        await bot.send_group_text(
            group_id,
            "@abc123 check this out!",
            at_list=[mention("abc123", location=0, length=8)],
        )
    """
    return {
        "did": uid,
        "name": uid,
        "length": length,
        "location": location,
        "userType": "0",
    }
