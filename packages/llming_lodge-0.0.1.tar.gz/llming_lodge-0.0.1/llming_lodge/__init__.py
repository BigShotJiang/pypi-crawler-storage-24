"""Full-stack AI chat platform — multi-provider LLM, MCP tools, voice, budget"""

__version__ = "0.0.1"
