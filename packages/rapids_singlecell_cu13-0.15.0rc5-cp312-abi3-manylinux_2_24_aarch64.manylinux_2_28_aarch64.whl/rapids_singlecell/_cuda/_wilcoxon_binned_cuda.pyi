from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def dense_hist(X: Annotated[NDArray[numpy.float32], dict(order='F', device='cuda', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, stream: int = 0) -> None: ...

@overload
def dense_hist(X: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, stream: int = 0) -> None: ...

@overload
def dense_hist(X: Annotated[NDArray[numpy.float32], dict(order='F', device='cuda_managed', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda_managed')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, stream: int = 0) -> None: ...

@overload
def dense_hist(X: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda_managed', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda_managed')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, stream: int = 0) -> None: ...

@overload
def csr_hist(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, gene_start: int, stream: int = 0) -> None: ...

@overload
def csr_hist(data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, gene_start: int, stream: int = 0) -> None: ...

@overload
def csr_hist(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda_managed')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, gene_start: int, stream: int = 0) -> None: ...

@overload
def csr_hist(data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda_managed')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, gene_start: int, stream: int = 0) -> None: ...

@overload
def csc_hist(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, gene_start: int, stream: int = 0) -> None: ...

@overload
def csc_hist(data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, gene_start: int, stream: int = 0) -> None: ...

@overload
def csc_hist(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda_managed')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, gene_start: int, stream: int = 0) -> None: ...

@overload
def csc_hist(data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], gcodes: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], hist: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda_managed')], *, n_cells: int, n_genes: int, n_groups: int, n_bins: int, bin_low: float, inv_bin_width: float, gene_start: int, stream: int = 0) -> None: ...
