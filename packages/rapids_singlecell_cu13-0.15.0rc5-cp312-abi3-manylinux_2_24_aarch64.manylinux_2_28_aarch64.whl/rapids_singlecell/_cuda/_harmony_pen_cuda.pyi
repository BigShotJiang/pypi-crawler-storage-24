from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def fused_pen_norm(similarities: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, penalty: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], idx_in: Annotated[NDArray[numpy.uint64], dict(order='C', device='cuda', writable=False)], R_out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], term: float, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def fused_pen_norm(similarities: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, penalty: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], idx_in: Annotated[NDArray[numpy.uint64], dict(order='C', device='cuda', writable=False)], R_out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], term: float, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def fused_pen_norm(similarities: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, penalty: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], idx_in: Annotated[NDArray[numpy.uint64], dict(order='C', device='cuda_managed', writable=False)], R_out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], term: float, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def fused_pen_norm(similarities: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, penalty: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], idx_in: Annotated[NDArray[numpy.uint64], dict(order='C', device='cuda_managed', writable=False)], R_out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], term: float, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def penalty(E: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, O: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], theta: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], penalty: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], n_batches: int, n_clusters: int, stream: int = 0) -> None: ...

@overload
def penalty(E: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, O: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], theta: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], penalty: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], n_batches: int, n_clusters: int, stream: int = 0) -> None: ...

@overload
def penalty(E: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, O: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], theta: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], penalty: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], n_batches: int, n_clusters: int, stream: int = 0) -> None: ...

@overload
def penalty(E: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, O: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], theta: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], penalty: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], n_batches: int, n_clusters: int, stream: int = 0) -> None: ...

@overload
def fused_pen_norm_int(similarities: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, penalty: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], idx_in: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], R_out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], term: float, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def fused_pen_norm_int(similarities: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, penalty: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], idx_in: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], R_out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], term: float, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def fused_pen_norm_int(similarities: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, penalty: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], idx_in: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], R_out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], term: float, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def fused_pen_norm_int(similarities: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, penalty: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], idx_in: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], R_out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], term: float, n_rows: int, n_cols: int, stream: int = 0) -> None: ...
