from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def rev_cummin64(x: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], n_rows: int, m: int, stream: int = 0) -> None: ...

@overload
def rev_cummin64(x: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], n_rows: int, m: int, stream: int = 0) -> None: ...
