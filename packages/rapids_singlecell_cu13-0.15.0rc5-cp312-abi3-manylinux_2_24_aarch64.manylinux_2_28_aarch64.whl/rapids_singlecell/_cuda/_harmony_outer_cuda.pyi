from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def outer(E: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], *, Pr_b: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], R_sum: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], n_cats: int, n_pcs: int, switcher: int, stream: int = 0) -> None: ...

@overload
def outer(E: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], *, Pr_b: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], R_sum: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], n_cats: int, n_pcs: int, switcher: int, stream: int = 0) -> None: ...

@overload
def outer(E: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], *, Pr_b: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], R_sum: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], n_cats: int, n_pcs: int, switcher: int, stream: int = 0) -> None: ...

@overload
def outer(E: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], *, Pr_b: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], R_sum: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], n_cats: int, n_pcs: int, switcher: int, stream: int = 0) -> None: ...

@overload
def harmony_corr(Z: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], *, W: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], R: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], n_cells: int, n_pcs: int, stream: int = 0) -> None: ...

@overload
def harmony_corr(Z: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], *, W: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], R: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], n_cells: int, n_pcs: int, stream: int = 0) -> None: ...

@overload
def harmony_corr(Z: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], *, W: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], R: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], n_cells: int, n_pcs: int, stream: int = 0) -> None: ...

@overload
def harmony_corr(Z: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], *, W: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], R: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], n_cells: int, n_pcs: int, stream: int = 0) -> None: ...

@overload
def batched_correction(Z: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], *, W_all: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], R: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], n_cells: int, n_pcs: int, n_clusters: int, n_batches_p1: int, stream: int = 0) -> None: ...

@overload
def batched_correction(Z: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], *, W_all: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], R: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], n_cells: int, n_pcs: int, n_clusters: int, n_batches_p1: int, stream: int = 0) -> None: ...

@overload
def batched_correction(Z: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], *, W_all: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], R: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], n_cells: int, n_pcs: int, n_clusters: int, n_batches_p1: int, stream: int = 0) -> None: ...

@overload
def batched_correction(Z: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], *, W_all: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], cats: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], R: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], n_cells: int, n_pcs: int, n_clusters: int, n_batches_p1: int, stream: int = 0) -> None: ...
