from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def sparse2dense(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='F', device='cuda')], major: int, minor: int, c_switch: bool, max_nnz: int, stream: int = 0) -> None: ...

@overload
def sparse2dense(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], major: int, minor: int, c_switch: bool, max_nnz: int, stream: int = 0) -> None: ...

@overload
def sparse2dense(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda')], major: int, minor: int, c_switch: bool, max_nnz: int, stream: int = 0) -> None: ...

@overload
def sparse2dense(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], major: int, minor: int, c_switch: bool, max_nnz: int, stream: int = 0) -> None: ...

@overload
def sparse2dense(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='F', device='cuda_managed')], major: int, minor: int, c_switch: bool, max_nnz: int, stream: int = 0) -> None: ...

@overload
def sparse2dense(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], major: int, minor: int, c_switch: bool, max_nnz: int, stream: int = 0) -> None: ...

@overload
def sparse2dense(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda_managed')], major: int, minor: int, c_switch: bool, max_nnz: int, stream: int = 0) -> None: ...

@overload
def sparse2dense(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], major: int, minor: int, c_switch: bool, max_nnz: int, stream: int = 0) -> None: ...
