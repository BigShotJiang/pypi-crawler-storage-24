from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def gram_csr_upper(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, nrows: int, ncols: int, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], stream: int = 0) -> None: ...

@overload
def gram_csr_upper(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, nrows: int, ncols: int, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], stream: int = 0) -> None: ...

@overload
def gram_csr_upper(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, nrows: int, ncols: int, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], stream: int = 0) -> None: ...

@overload
def gram_csr_upper(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, nrows: int, ncols: int, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], stream: int = 0) -> None: ...

@overload
def copy_upper_to_lower(*, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], ncols: int, stream: int = 0) -> None: ...

@overload
def copy_upper_to_lower(*, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], ncols: int, stream: int = 0) -> None: ...

@overload
def copy_upper_to_lower(*, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], ncols: int, stream: int = 0) -> None: ...

@overload
def copy_upper_to_lower(*, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], ncols: int, stream: int = 0) -> None: ...

@overload
def cov_from_gram(gram: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], meanx: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], meany: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, cov: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], ncols: int, stream: int = 0) -> None: ...

@overload
def cov_from_gram(gram: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], meanx: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], meany: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, cov: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], ncols: int, stream: int = 0) -> None: ...

@overload
def cov_from_gram(gram: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], meanx: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], meany: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, cov: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], ncols: int, stream: int = 0) -> None: ...

@overload
def cov_from_gram(gram: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], meanx: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], meany: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, cov: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], ncols: int, stream: int = 0) -> None: ...

@overload
def check_zero_genes(indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], nnz: int, num_genes: int, stream: int = 0) -> None: ...

@overload
def check_zero_genes(indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], nnz: int, num_genes: int, stream: int = 0) -> None: ...
