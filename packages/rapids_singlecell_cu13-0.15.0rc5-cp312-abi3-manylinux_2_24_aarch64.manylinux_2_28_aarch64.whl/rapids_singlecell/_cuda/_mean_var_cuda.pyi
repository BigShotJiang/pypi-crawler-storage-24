from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def mean_var_major(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], vars: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], *, major: int, minor: int, stream: int = 0) -> None: ...

@overload
def mean_var_major(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], vars: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], *, major: int, minor: int, stream: int = 0) -> None: ...

@overload
def mean_var_major(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], vars: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], *, major: int, minor: int, stream: int = 0) -> None: ...

@overload
def mean_var_major(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], vars: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], *, major: int, minor: int, stream: int = 0) -> None: ...

@overload
def mean_var_minor(indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], vars: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], *, nnz: int, stream: int = 0) -> None: ...

@overload
def mean_var_minor(indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], vars: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], *, nnz: int, stream: int = 0) -> None: ...

@overload
def mean_var_minor(indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], vars: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], *, nnz: int, stream: int = 0) -> None: ...

@overload
def mean_var_minor(indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], vars: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], *, nnz: int, stream: int = 0) -> None: ...
