"""CUDA kernels for Wilcoxon rank-sum test"""

from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def tie_correction(sorted_vals: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda', writable=False)], correction: Annotated[NDArray[numpy.float64], dict(device='cuda')], *, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def tie_correction(sorted_vals: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda_managed', writable=False)], correction: Annotated[NDArray[numpy.float64], dict(device='cuda_managed')], *, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def average_rank(sorted_vals: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda', writable=False)], sorter: Annotated[NDArray[numpy.int32], dict(order='F', device='cuda', writable=False)], ranks: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda')], *, n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def average_rank(sorted_vals: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda_managed', writable=False)], sorter: Annotated[NDArray[numpy.int32], dict(order='F', device='cuda_managed', writable=False)], ranks: Annotated[NDArray[numpy.float64], dict(order='F', device='cuda_managed')], *, n_rows: int, n_cols: int, stream: int = 0) -> None: ...
