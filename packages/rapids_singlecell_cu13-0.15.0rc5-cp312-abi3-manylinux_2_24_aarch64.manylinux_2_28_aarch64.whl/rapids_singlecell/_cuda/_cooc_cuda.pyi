from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


def get_kernel_config(l_val: int, n_cells: int, k: int) -> object:
    """
    Get kernel configuration (cell_tile, l_pad, block_size, shared_mem) for given parameters. Returns None if insufficient shared memory.
    """

@overload
def count_csr_catpairs(spatial: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, thresholds: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], cat_offsets: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], cell_indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], pair_left: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], pair_right: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], counts: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], num_pairs: int, k: int, l_val: int, blocks_per_pair: int, cell_tile: int, block_size: int, shared_mem: int, stream: int = 0) -> None: ...

@overload
def count_csr_catpairs(spatial: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, thresholds: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], cat_offsets: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], cell_indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], pair_left: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], pair_right: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], counts: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], num_pairs: int, k: int, l_val: int, blocks_per_pair: int, cell_tile: int, block_size: int, shared_mem: int, stream: int = 0) -> None: ...

@overload
def count_pairwise(spatial: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, thresholds: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], labels: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], result: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], n: int, k: int, l_val: int, stream: int = 0) -> None: ...

@overload
def count_pairwise(spatial: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, thresholds: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], labels: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], result: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], n: int, k: int, l_val: int, stream: int = 0) -> None: ...

@overload
def reduce_shared(result: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], k: int, l_val: int, format: int, stream: int = 0) -> bool: ...

@overload
def reduce_shared(result: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], k: int, l_val: int, format: int, stream: int = 0) -> bool: ...

@overload
def reduce_global(result: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], *, inter_out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], k: int, l_val: int, format: int, stream: int = 0) -> None: ...

@overload
def reduce_global(result: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], *, inter_out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], k: int, l_val: int, format: int, stream: int = 0) -> None: ...
