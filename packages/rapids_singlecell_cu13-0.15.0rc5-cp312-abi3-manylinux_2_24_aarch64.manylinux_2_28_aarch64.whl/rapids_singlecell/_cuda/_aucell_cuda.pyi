from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def auc(ranks: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], *, R: int, C: int, cnct: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], starts: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], lens: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], n_sets: int, n_up: int, max_aucs: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], es: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], stream: int = 0) -> None: ...

@overload
def auc(ranks: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], *, R: int, C: int, cnct: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], starts: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], lens: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], n_sets: int, n_up: int, max_aucs: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], es: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], stream: int = 0) -> None: ...
