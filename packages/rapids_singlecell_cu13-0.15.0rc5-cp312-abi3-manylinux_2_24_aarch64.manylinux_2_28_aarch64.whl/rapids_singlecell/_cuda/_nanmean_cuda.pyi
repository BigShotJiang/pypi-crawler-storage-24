from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def nan_mean_minor(index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], nans: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], mask: Annotated[NDArray[numpy.bool_], dict(order='C', device='cuda', writable=False)], nnz: int, stream: int = 0) -> None: ...

@overload
def nan_mean_minor(index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], nans: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], mask: Annotated[NDArray[numpy.bool_], dict(order='C', device='cuda', writable=False)], nnz: int, stream: int = 0) -> None: ...

@overload
def nan_mean_minor(index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], nans: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], mask: Annotated[NDArray[numpy.bool_], dict(order='C', device='cuda_managed', writable=False)], nnz: int, stream: int = 0) -> None: ...

@overload
def nan_mean_minor(index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], nans: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], mask: Annotated[NDArray[numpy.bool_], dict(order='C', device='cuda_managed', writable=False)], nnz: int, stream: int = 0) -> None: ...

@overload
def nan_mean_major(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], nans: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], mask: Annotated[NDArray[numpy.bool_], dict(order='C', device='cuda', writable=False)], major: int, minor: int, stream: int = 0) -> None: ...

@overload
def nan_mean_major(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], nans: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], mask: Annotated[NDArray[numpy.bool_], dict(order='C', device='cuda', writable=False)], major: int, minor: int, stream: int = 0) -> None: ...

@overload
def nan_mean_major(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], nans: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], mask: Annotated[NDArray[numpy.bool_], dict(order='C', device='cuda_managed', writable=False)], major: int, minor: int, stream: int = 0) -> None: ...

@overload
def nan_mean_major(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], data: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], nans: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], mask: Annotated[NDArray[numpy.bool_], dict(order='C', device='cuda_managed', writable=False)], major: int, minor: int, stream: int = 0) -> None: ...
