from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def sqeuclidean(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], pairs: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda', writable=False)], n_samples: int, n_features: int, n_neighbors: int, stream: int = 0) -> None: ...

@overload
def sqeuclidean(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], pairs: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda_managed', writable=False)], n_samples: int, n_features: int, n_neighbors: int, stream: int = 0) -> None: ...

@overload
def cosine(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], pairs: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda', writable=False)], n_samples: int, n_features: int, n_neighbors: int, stream: int = 0) -> None: ...

@overload
def cosine(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], pairs: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda_managed', writable=False)], n_samples: int, n_features: int, n_neighbors: int, stream: int = 0) -> None: ...

@overload
def inner(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], pairs: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda', writable=False)], n_samples: int, n_features: int, n_neighbors: int, stream: int = 0) -> None: ...

@overload
def inner(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], pairs: Annotated[NDArray[numpy.uint32], dict(order='C', device='cuda_managed', writable=False)], n_samples: int, n_features: int, n_neighbors: int, stream: int = 0) -> None: ...
