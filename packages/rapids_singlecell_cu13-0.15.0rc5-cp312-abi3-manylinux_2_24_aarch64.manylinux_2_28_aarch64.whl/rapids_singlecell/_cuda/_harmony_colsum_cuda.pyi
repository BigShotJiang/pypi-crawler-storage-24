from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def colsum(A: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum(A: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum(A: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum(A: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum(A: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum(A: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum_atomic(A: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum_atomic(A: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum_atomic(A: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum_atomic(A: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum_atomic(A: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def colsum_atomic(A: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], rows: int, cols: int, stream: int = 0) -> None: ...
