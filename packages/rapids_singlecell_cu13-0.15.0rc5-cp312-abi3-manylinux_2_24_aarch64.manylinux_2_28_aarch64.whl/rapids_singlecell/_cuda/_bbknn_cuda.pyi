from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def find_top_k_per_row(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], *, n_rows: int, trim: int, vals: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], stream: int = 0) -> None: ...

@overload
def find_top_k_per_row(data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], *, n_rows: int, trim: int, vals: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], stream: int = 0) -> None: ...

@overload
def cut_smaller(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda')], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], *, vals: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], n_rows: int, stream: int = 0) -> None: ...

@overload
def cut_smaller(indptr: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], index: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed')], data: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], *, vals: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], n_rows: int, stream: int = 0) -> None: ...
