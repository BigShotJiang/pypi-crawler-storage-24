from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def gaussian_kde_2d(xy: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], n: int, a: float, b: float, c: float, stream: int = 0) -> None: ...

@overload
def gaussian_kde_2d(xy: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], n: int, a: float, b: float, c: float, stream: int = 0) -> None: ...

@overload
def gaussian_kde_2d(xy: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], n: int, a: float, b: float, c: float, stream: int = 0) -> None: ...

@overload
def gaussian_kde_2d(xy: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], n: int, a: float, b: float, c: float, stream: int = 0) -> None: ...
