from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def kmeans_err(r: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, dot: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], n: int, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], stream: int = 0) -> None: ...

@overload
def kmeans_err(r: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, dot: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], n: int, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], stream: int = 0) -> None: ...

@overload
def kmeans_err(r: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, dot: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], n: int, out: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], stream: int = 0) -> None: ...

@overload
def kmeans_err(r: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, dot: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], n: int, out: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], stream: int = 0) -> None: ...
