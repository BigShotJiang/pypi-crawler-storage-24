from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


def get_kernel_config(n_features: int, is_double: bool) -> object:
    """
    Get kernel configuration (cell_tile, feat_tile, block_size, shared_mem) for given parameters. Returns None if insufficient shared memory.
    """

@overload
def compute_distances(embedding: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], cat_offsets: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], cell_indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], pair_left: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], pair_right: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], pairwise_sums: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], num_pairs: int, n_features: int, blocks_per_pair: int, cell_tile: int, feat_tile: int, block_size: int, shared_mem: int, stream: int = 0) -> None: ...

@overload
def compute_distances(embedding: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], cat_offsets: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], cell_indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], pair_left: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], pair_right: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda', writable=False)], pairwise_sums: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], num_pairs: int, n_features: int, blocks_per_pair: int, cell_tile: int, feat_tile: int, block_size: int, shared_mem: int, stream: int = 0) -> None: ...

@overload
def compute_distances(embedding: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], cat_offsets: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], cell_indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], pair_left: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], pair_right: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], pairwise_sums: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], num_pairs: int, n_features: int, blocks_per_pair: int, cell_tile: int, feat_tile: int, block_size: int, shared_mem: int, stream: int = 0) -> None: ...

@overload
def compute_distances(embedding: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], cat_offsets: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], cell_indices: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], pair_left: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], pair_right: Annotated[NDArray[numpy.int32], dict(order='C', device='cuda_managed', writable=False)], pairwise_sums: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], num_pairs: int, n_features: int, blocks_per_pair: int, cell_tile: int, feat_tile: int, block_size: int, shared_mem: int, stream: int = 0) -> None: ...
