from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def expected_zeros(scaled_means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], total_counts: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], expected: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], n_genes: int, n_cells: int, stream: int = 0) -> None: ...

@overload
def expected_zeros(scaled_means: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], total_counts: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], expected: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], n_genes: int, n_cells: int, stream: int = 0) -> None: ...

@overload
def expected_zeros(scaled_means: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], total_counts: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], expected: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], n_genes: int, n_cells: int, stream: int = 0) -> None: ...

@overload
def expected_zeros(scaled_means: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], total_counts: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], expected: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], n_genes: int, n_cells: int, stream: int = 0) -> None: ...
