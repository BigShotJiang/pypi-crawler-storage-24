from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


@overload
def normalize(X: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], *, rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def normalize(X: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], *, rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def normalize(X: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], *, rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def normalize(X: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], *, rows: int, cols: int, stream: int = 0) -> None: ...

@overload
def l2_row_normalize(src: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda', writable=False)], *, dst: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda')], n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def l2_row_normalize(src: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda', writable=False)], *, dst: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda')], n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def l2_row_normalize(src: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed', writable=False)], *, dst: Annotated[NDArray[numpy.float32], dict(order='C', device='cuda_managed')], n_rows: int, n_cols: int, stream: int = 0) -> None: ...

@overload
def l2_row_normalize(src: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed', writable=False)], *, dst: Annotated[NDArray[numpy.float64], dict(order='C', device='cuda_managed')], n_rows: int, n_cols: int, stream: int = 0) -> None: ...
