"""Workspace screen — repos workspace folder + knowledge folder path + ignored items."""

from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

LABEL_STYLE = "color: #d4d4d4; font-size: 13px;"
HEADER_STYLE = "color: #ffffff; font-size: 14px; font-weight: 600;"
HINT_STYLE = "color: #808080; font-size: 12px;"
CARD_STYLE = "QFrame { background-color: #0d0d0d; border: 1px solid #2a2a2a; border-radius: 8px; }"
LIST_STYLE = (
    "QListWidget { background: #1a1a1a; border: 1px solid #2a2a2a; border-radius: 4px; "
    "color: #d4d4d4; font-size: 12px; } "
    "QListWidget::item { padding: 3px 6px; } "
    "QListWidget::item:selected { background: #264f78; }"
)


def _label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(LABEL_STYLE)
    return lbl


def _hint(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(HINT_STYLE)
    lbl.setWordWrap(True)
    return lbl


def _card(title: str) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setStyleSheet(CARD_STYLE)
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(20, 16, 20, 16)
    layout.setSpacing(10)
    hdr = QLabel(title)
    hdr.setStyleSheet(HEADER_STYLE)
    layout.addWidget(hdr)
    return frame, layout


class WorkspaceScreen(QWidget):
    """Configure repos workspace and knowledge folder for Claude context."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._config = None
        self._setup_ui()

    def _setup_ui(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        page_header = QLabel("Workspace")
        page_header.setStyleSheet("font-size: 22px; font-weight: 600; color: #ffffff;")
        layout.addWidget(page_header)

        layout.addWidget(_hint("Configure repos workspace and knowledge folder. Right-click any item in the lists below to ignore it."))

        # ── Repos Workspace ───────────────────────────────────────────────
        repos_card, rc_layout = _card("Repos Workspace")
        rc_layout.addWidget(_hint("Each subfolder appears as a selectable repo in the context panel."))

        repos_path_row = QHBoxLayout()
        self._repos_workspace_input = QLineEdit()
        self._repos_workspace_input.setPlaceholderText("/path/to/workspace")
        repos_path_row.addWidget(self._repos_workspace_input, 1)
        repos_browse_btn = QPushButton("Browse")
        repos_browse_btn.setStyleSheet("background-color: #2a2a2a; color: #d4d4d4;")
        repos_browse_btn.clicked.connect(self._browse_repos_workspace)
        repos_path_row.addWidget(repos_browse_btn)
        rc_layout.addLayout(repos_path_row)

        rc_layout.addWidget(_label("Discovered repos  (select one or more to ignore):"))
        self._repos_preview = QListWidget()
        self._repos_preview.setMaximumHeight(150)
        self._repos_preview.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self._repos_preview.setStyleSheet(LIST_STYLE)
        rc_layout.addWidget(self._repos_preview)
        ignore_repos_row = QHBoxLayout()
        ignore_repos_btn = QPushButton("🚫 Ignore Selected")
        ignore_repos_btn.setStyleSheet("background-color: #2a2a2a; color: #d4d4d4;")
        ignore_repos_btn.clicked.connect(self._ignore_selected_repos)
        ignore_repos_row.addWidget(ignore_repos_btn)
        ignore_repos_row.addStretch()
        rc_layout.addLayout(ignore_repos_row)
        self._repos_workspace_input.textChanged.connect(self._refresh_repos_preview)

        layout.addWidget(repos_card)

        # ── Knowledge Folder ─────────────────────────────────────────────
        knowledge_card, kc_layout = _card("Knowledge Folder")
        kc_layout.addWidget(_hint("Folder with .md and .txt files organized by topic subfolders."))

        path_row = QHBoxLayout()
        self._knowledge_input = QLineEdit()
        self._knowledge_input.setPlaceholderText("/path/to/knowledge/folder")
        path_row.addWidget(self._knowledge_input, 1)
        browse_btn = QPushButton("Browse")
        browse_btn.setStyleSheet("background-color: #2a2a2a; color: #d4d4d4;")
        browse_btn.clicked.connect(self._browse_knowledge)
        path_row.addWidget(browse_btn)
        kc_layout.addLayout(path_row)

        kc_layout.addWidget(_label("Discovered topics  (select one or more to ignore):"))
        self._knowledge_preview = QListWidget()
        self._knowledge_preview.setMaximumHeight(150)
        self._knowledge_preview.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self._knowledge_preview.setStyleSheet(LIST_STYLE)
        kc_layout.addWidget(self._knowledge_preview)
        ignore_kb_row = QHBoxLayout()
        ignore_kb_btn = QPushButton("🚫 Ignore Selected")
        ignore_kb_btn.setStyleSheet("background-color: #2a2a2a; color: #d4d4d4;")
        ignore_kb_btn.clicked.connect(self._ignore_selected_knowledge)
        ignore_kb_row.addWidget(ignore_kb_btn)
        ignore_kb_row.addStretch()
        kc_layout.addLayout(ignore_kb_row)
        self._knowledge_input.textChanged.connect(self._refresh_knowledge_preview)

        layout.addWidget(knowledge_card)

        # ── Ignored Items ─────────────────────────────────────────────────
        ignored_card, ig_layout = _card("Ignored Items")
        ig_layout.addWidget(_hint("These are excluded from all context loading and auto-selection."))

        self._ignored_list = QListWidget()
        self._ignored_list.setMaximumHeight(100)
        self._ignored_list.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
        self._ignored_list.setStyleSheet(LIST_STYLE)
        ig_layout.addWidget(self._ignored_list)

        unignore_row = QHBoxLayout()
        unignore_btn = QPushButton("✅ Unignore Selected")
        unignore_btn.setStyleSheet("background-color: #2a2a2a; color: #d4d4d4;")
        unignore_btn.clicked.connect(self._unignore_selected)
        unignore_row.addWidget(unignore_btn)
        unignore_row.addStretch()
        ig_layout.addLayout(unignore_row)

        layout.addWidget(ignored_card)

        # ── Status + Save ──────────────────────────────────────────────────
        self._context_info = QLabel("")
        self._context_info.setStyleSheet(HINT_STYLE)
        layout.addWidget(self._context_info)

        save_row = QHBoxLayout()
        save_global_btn = QPushButton("Save")
        save_global_btn.clicked.connect(self._save_global)
        save_row.addWidget(save_global_btn)

        save_row.addStretch()
        layout.addLayout(save_row)
        layout.addStretch()

        scroll.setWidget(content)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

    # ── Config ────────────────────────────────────────────────────────────

    def set_config(self, config):
        self._config = config
        self._repos_workspace_input.setText(config.repos_workspace)
        self._knowledge_input.setText(config.knowledge_path)
        self._refresh_repos_preview(config.repos_workspace)
        self._refresh_knowledge_preview(config.knowledge_path)
        self._refresh_ignored_list()

    # ── Repo preview ──────────────────────────────────────────────────────

    def _browse_repos_workspace(self):
        path = QFileDialog.getExistingDirectory(self, "Select Repos Workspace Folder")
        if path:
            self._repos_workspace_input.setText(path)

    def _refresh_repos_preview(self, workspace_path: str = ""):
        self._repos_preview.clear()
        path = Path(workspace_path.strip()).expanduser() if workspace_path.strip() else None
        if not path or not path.is_dir():
            self._repos_preview.addItem("— enter a workspace folder to see repos —")
            return
        try:
            from meeting_helper.context_loader import get_repos_from_workspace
            repos = get_repos_from_workspace(str(path))
            if repos:
                for r in repos:
                    ignored = self._config and r["name"] in self._config.ignored_repos
                    label = f"🚫 {r['sanitized_name']}  ({r['name']})" if ignored else f"  {r['sanitized_name']}  ({r['name']})"
                    self._repos_preview.addItem(label)
            else:
                self._repos_preview.addItem("— no subdirectories found —")
        except Exception:
            self._repos_preview.addItem("— could not scan folder —")

    def _ignore_selected_repos(self):
        if not self._config:
            return
        names = self._extract_names_from_selection(self._repos_preview)
        if not names:
            return
        lst = list(self._config.ignored_repos)
        for name in names:
            if name not in lst:
                lst.append(name)
        self._config.ignored_repos = lst
        self._config.save()
        self._sync_ignored_to_daemon()
        self._refresh_repos_preview(self._repos_workspace_input.text())
        self._refresh_ignored_list()
        self._context_info.setText(f"Ignored: {', '.join(names)}")
        self._context_info.setStyleSheet("color: #4ec9b0; font-size: 12px;")

    # ── Knowledge preview ─────────────────────────────────────────────────

    def _browse_knowledge(self):
        path = QFileDialog.getExistingDirectory(self, "Select Knowledge Folder")
        if path:
            self._knowledge_input.setText(path)

    def _refresh_knowledge_preview(self, knowledge_path: str = ""):
        self._knowledge_preview.clear()
        path = Path(knowledge_path.strip()).expanduser() if knowledge_path.strip() else None
        if not path or not path.is_dir():
            self._knowledge_preview.addItem("— enter a knowledge folder to see topics —")
            return
        try:
            from meeting_helper.context_loader import get_knowledge_tree
            tree = get_knowledge_tree(str(path))
            if tree:
                for node in tree:
                    ignored = self._config and node["name"] in self._config.ignored_knowledge
                    display = node["name"].replace("_", " ").replace("-", " ").title()
                    label = f"🚫 {display}  ({node['name']})" if ignored else f"  {display}  ({node['name']})"
                    self._knowledge_preview.addItem(label)
            else:
                self._knowledge_preview.addItem("— no topic folders found —")
        except Exception:
            self._knowledge_preview.addItem("— could not scan folder —")

    def _ignore_selected_knowledge(self):
        if not self._config:
            return
        names = self._extract_names_from_selection(self._knowledge_preview)
        if not names:
            return
        lst = list(self._config.ignored_knowledge)
        for name in names:
            if name not in lst:
                lst.append(name)
        self._config.ignored_knowledge = lst
        self._config.save()
        self._sync_ignored_to_daemon()
        self._refresh_knowledge_preview(self._knowledge_input.text())
        self._refresh_ignored_list()
        self._context_info.setText(f"Ignored: {', '.join(names)}")
        self._context_info.setStyleSheet("color: #4ec9b0; font-size: 12px;")

    # ── Ignored list ──────────────────────────────────────────────────────

    def _refresh_ignored_list(self):
        self._ignored_list.clear()
        if not self._config:
            return
        has_any = False
        for name in self._config.ignored_repos:
            self._ignored_list.addItem(f"repo: {name}")
            has_any = True
        for name in self._config.ignored_knowledge:
            self._ignored_list.addItem(f"knowledge: {name}")
            has_any = True
        if not has_any:
            self._ignored_list.addItem("— no ignored items —")

    def _unignore_selected(self):
        if not self._config:
            return
        items = self._ignored_list.selectedItems()
        if not items:
            return
        unignored = []
        for item in items:
            text = item.text()
            if text.startswith("repo: "):
                name = text[6:]
                self._config.ignored_repos = [r for r in self._config.ignored_repos if r != name]
                unignored.append(name)
            elif text.startswith("knowledge: "):
                name = text[11:]
                self._config.ignored_knowledge = [k for k in self._config.ignored_knowledge if k != name]
                unignored.append(name)
        if not unignored:
            return
        self._config.save()
        self._sync_ignored_to_daemon()
        self._refresh_repos_preview(self._repos_workspace_input.text())
        self._refresh_knowledge_preview(self._knowledge_input.text())
        self._refresh_ignored_list()
        self._context_info.setText(f"Unignored: {', '.join(unignored)}")
        self._context_info.setStyleSheet("color: #4ec9b0; font-size: 12px;")

    # ── Save ──────────────────────────────────────────────────────────────

    @staticmethod
    def _extract_names_from_selection(list_widget) -> list[str]:
        """Extract folder names from selected items in format '  Label  (folder-name)'."""
        names = []
        for item in list_widget.selectedItems():
            text = item.text().strip().lstrip("🚫 ")
            if "(" in text and text.endswith(")"):
                name = text[text.rfind("(") + 1:-1]
                names.append(name)
        return names

    def _sync_ignored_to_daemon(self):
        """POST updated ignored lists to daemon so overlay filters chips immediately."""
        if not self._config:
            return
        import threading, urllib.request as _ur
        port = self._config.port
        payload = json.dumps({
            "ignored_repos": list(self._config.ignored_repos),
            "ignored_knowledge": list(self._config.ignored_knowledge),
        }).encode()
        def _do():
            try:
                req = _ur.Request(
                    f"http://127.0.0.1:{port}/config",
                    data=payload, headers={"Content-Type": "application/json"},
                    method="POST",
                )
                _ur.urlopen(req, timeout=3)
            except Exception:
                pass
        threading.Thread(target=_do, daemon=True).start()

    def _save_global(self):
        if not self._config:
            return
        self._config.repos_workspace = self._repos_workspace_input.text().strip()
        self._config.knowledge_path = self._knowledge_input.text().strip()
        self._config.save()
        self._context_info.setText("Saved globally!")
        self._context_info.setStyleSheet("color: #4ec9b0; font-size: 12px;")

