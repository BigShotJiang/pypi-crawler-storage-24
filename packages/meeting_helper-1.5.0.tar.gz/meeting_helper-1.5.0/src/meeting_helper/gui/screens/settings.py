"""Settings screen — API keys, preferences."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSlider,
    QVBoxLayout,
    QWidget,
)

LABEL_STYLE = "color: #d4d4d4; font-size: 13px;"
HEADER_STYLE = "color: #ffffff; font-size: 14px; font-weight: 600;"
CARD_STYLE = "QFrame { background-color: #0d0d0d; border: 1px solid #2a2a2a; border-radius: 8px; }"
HINT_STYLE = "color: #808080; font-size: 12px;"


def _label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setStyleSheet(LABEL_STYLE)
    lbl.setMinimumWidth(180)
    return lbl


def _card(title: str) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setStyleSheet(CARD_STYLE)
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(20, 16, 20, 16)
    layout.setSpacing(12)
    hdr = QLabel(title)
    hdr.setStyleSheet(HEADER_STYLE)
    layout.addWidget(hdr)
    return frame, layout


class SettingsScreen(QWidget):
    """API keys, model selection, and other preferences."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._config = None
        self._setup_ui()

    def _setup_ui(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        content = QWidget()
        layout = QVBoxLayout(content)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        page_header = QLabel("Settings")
        page_header.setStyleSheet("font-size: 22px; font-weight: 600; color: #ffffff;")
        layout.addWidget(page_header)

        # ── API Keys ──────────────────────────────────────────────────────
        api_card, api_layout = _card("API Keys")

        api_layout.addWidget(_label("Anthropic API Key"))
        self._anthropic_key = QLineEdit()
        self._anthropic_key.setEchoMode(QLineEdit.Password)
        self._anthropic_key.setPlaceholderText("sk-ant-...")
        api_layout.addWidget(self._anthropic_key)

        api_layout.addWidget(_label("Deepgram API Key"))
        self._deepgram_key = QLineEdit()
        self._deepgram_key.setEchoMode(QLineEdit.Password)
        self._deepgram_key.setPlaceholderText("Deepgram API key (optional — falls back to local Whisper)")
        api_layout.addWidget(self._deepgram_key)

        layout.addWidget(api_card)

        # ── Preferences ──────────────────────────────────────────────────
        prefs_card, pc_layout = _card("Preferences")

        # Claude model
        model_row = QHBoxLayout()
        model_row.addWidget(_label("Claude Model"))
        self._model_combo = QComboBox()
        self._model_combo.addItems(["sonnet", "opus", "haiku"])
        model_row.addWidget(self._model_combo)
        model_row.addStretch()
        pc_layout.addLayout(model_row)

        # Transcription language
        lang_row = QHBoxLayout()
        lang_row.addWidget(_label("Transcription Language"))
        self._lang_combo = QComboBox()
        self._lang_combo.addItems(["en", "es", "pt", "fr", "de", "it", "ja", "ko", "zh", "auto"])
        lang_row.addWidget(self._lang_combo)
        lang_row.addStretch()
        pc_layout.addLayout(lang_row)

        # Sentence window
        pc_layout.addWidget(self._slider_row("Sentence Window", 1, 10, 5, "_sw"))

        # Silence timeout
        pc_layout.addWidget(self._slider_row("Silence Timeout (s)", 10, 120, 30, "_st"))

        # Recordings directory
        rec_row = QHBoxLayout()
        rec_row.addWidget(_label("Recordings Directory"))
        self._rec_input = QLineEdit()
        self._rec_input.setPlaceholderText("~/meetings")
        rec_row.addWidget(self._rec_input, 1)
        browse_btn = QPushButton("Browse")
        browse_btn.setStyleSheet("background-color: #2a2a2a; color: #d4d4d4;")
        browse_btn.clicked.connect(self._browse_recordings)
        rec_row.addWidget(browse_btn)
        pc_layout.addLayout(rec_row)

        layout.addWidget(prefs_card)

        # ── AI Behaviour ─────────────────────────────────────────────────
        ai_card, ai_layout = _card("AI Behaviour")

        # Proactive answers
        self._proactive_check = QCheckBox("Proactive answers")
        self._proactive_check.setStyleSheet(LABEL_STYLE)
        self._proactive_check.setToolTip(
            "Automatically send a Claude query when a question is detected\n"
            "(sentence ends with '?' + 2s silence)."
        )
        hint1 = QLabel("Auto-answer questions detected in the transcript")
        hint1.setStyleSheet(HINT_STYLE)
        ai_layout.addWidget(self._proactive_check)
        ai_layout.addWidget(hint1)

        ai_layout.addSpacing(4)

        # Auto-select context
        self._auto_ctx_check = QCheckBox("Auto-select context")
        self._auto_ctx_check.setStyleSheet(LABEL_STYLE)
        self._auto_ctx_check.setToolTip(
            "Every N seconds, Claude picks relevant repos and knowledge folders\n"
            "from the transcript. Selections accumulate during the meeting."
        )
        hint2 = QLabel("Automatically load repos and knowledge based on what is being discussed")
        hint2.setStyleSheet(HINT_STYLE)
        ai_layout.addWidget(self._auto_ctx_check)
        ai_layout.addWidget(hint2)

        # Auto-context interval
        ai_layout.addWidget(self._slider_row("Auto-Context Interval (s)", 10, 120, 10, "_aci", step=5))

        layout.addWidget(ai_card)

        # ── Save ──────────────────────────────────────────────────────────
        save_row = QHBoxLayout()
        save_btn = QPushButton("Save Settings")
        save_btn.clicked.connect(self._save)
        save_row.addWidget(save_btn)
        self._save_status = QLabel("")
        self._save_status.setStyleSheet("color: #808080; font-size: 12px;")
        save_row.addWidget(self._save_status)
        save_row.addStretch()
        layout.addLayout(save_row)
        layout.addStretch()

        scroll.setWidget(content)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)

    def _slider_row(
        self, label_text: str, min_: int, max_: int, default: int,
        attr_prefix: str, step: int = 1,
    ) -> QWidget:
        """Create a labeled slider row widget."""
        row = QWidget()
        hl = QHBoxLayout(row)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(12)

        lbl = _label(label_text)
        hl.addWidget(lbl)

        slider = QSlider(Qt.Horizontal)
        slider.setMinimum(min_)
        slider.setMaximum(max_)
        slider.setValue(default)
        slider.setSingleStep(step)
        slider.setPageStep(step)
        slider.setFixedWidth(200)
        hl.addWidget(slider)

        val_lbl = QLabel(str(default))
        val_lbl.setStyleSheet("color: #d4d4d4; font-size: 13px; min-width: 40px;")
        val_lbl.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        if step > 1:
            slider.valueChanged.connect(lambda v: val_lbl.setText(str(round(v / step) * step)))
        else:
            slider.valueChanged.connect(lambda v: val_lbl.setText(str(v)))
        hl.addWidget(val_lbl)
        hl.addStretch()

        setattr(self, f"{attr_prefix}_slider", slider)
        setattr(self, f"{attr_prefix}_label", val_lbl)
        return row

    def set_config(self, config):
        self._config = config
        self._anthropic_key.setText(config.anthropic_api_key)
        self._deepgram_key.setText(config.deepgram_api_key)

        model = config._data.get("claude_model", "sonnet")
        idx = self._model_combo.findText(model)
        if idx >= 0:
            self._model_combo.setCurrentIndex(idx)

        self._lang_combo.setCurrentText(config.transcription_language)
        self._sw_slider.setValue(config.sentence_window)
        self._sw_label.setText(str(config.sentence_window))
        self._st_slider.setValue(config.silence_timeout)
        self._st_label.setText(str(config.silence_timeout))
        self._proactive_check.setChecked(config.proactive_answers)
        self._auto_ctx_check.setChecked(config.auto_context_enabled)
        self._aci_slider.setValue(config.auto_context_interval)
        self._aci_label.setText(str(config.auto_context_interval))
        self._rec_input.setText(str(config.recordings_dir))

    def _browse_recordings(self):
        path = QFileDialog.getExistingDirectory(self, "Select Recordings Directory")
        if path:
            self._rec_input.setText(path)

    def _save(self):
        if not self._config:
            return
        self._config.anthropic_api_key = self._anthropic_key.text().strip()
        self._config.deepgram_api_key = self._deepgram_key.text().strip()
        self._config.claude_model = self._model_combo.currentText()
        self._config.transcription_language = self._lang_combo.currentText()
        self._config.sentence_window = self._sw_slider.value()
        self._config.silence_timeout = self._st_slider.value()
        self._config.proactive_answers = self._proactive_check.isChecked()
        self._config.auto_context_enabled = self._auto_ctx_check.isChecked()
        self._config.auto_context_interval = round(self._aci_slider.value() / 5) * 5
        self._config.recordings_dir = self._rec_input.text().strip()
        self._config.setup_complete = True
        self._config.save()
        self._save_status.setText("Settings saved!")
        self._save_status.setStyleSheet("color: #4ec9b0; font-size: 12px;")
