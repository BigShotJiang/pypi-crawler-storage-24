class AccessTokenInvalid(Exception):
    pass
