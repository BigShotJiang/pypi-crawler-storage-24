"""A perfectly safe helper module."""


def greet(name: str) -> str:
    return f"Hello, {name}!"
