from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field

class InstitutionalSettings(BaseSettings):
    """
    Absolute Environment Matrix.
    Forces strict validation on all execution variables at boot. 
    Prevents runtime crashes caused by malformed API keys or leverage violations.
    """
    tiingo_api_key: str = Field(default="UNSET", description="Tiingo Data API Key")
    alpaca_api_key: str = Field(default="UNSET", description="Alpaca Trading Key")
    alpaca_api_secret: str = Field(default="UNSET", description="Alpaca Trading Secret")
    
    # Structural Risk Constraints
    max_leverage: float = Field(default=1.5, le=2.0, description="Absolute Leverage Ceiling")
    base_capital: float = Field(default=250000.0, ge=25000.0, description="Starting Capital")
    
    # Binds to the local .env file
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

# Instantiated globally for immediate RAM access
settings = InstitutionalSettings()

if settings.tiingo_api_key == "UNSET" or settings.alpaca_api_key == "UNSET":
    print("[!] CONFIG WARNING: API Keys unresolvable. Data modules will operate in fallback/synthetic mode.")
