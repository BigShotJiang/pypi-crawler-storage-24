import numpy as np
from numba import njit, float64, float32, void

@njit(
    void(
        float64, float64, # Target T0, Target T1 (Lag)
        float64, float64, # QQQ T0, QQQ T1
        float64, float64, # TLT T0, TLT T1
        float64, float64, # GLD T0, GLD T1
        float64,          # Target VWAP
        float64,          # Target 14d Volatility
        float64, float64, # VIX T0, VIX T2 (Lag 2)
        float32[:]        # Pre-allocated Memory View
    ),
    nogil=True, 
    fastmath=True,
    cache=True
)
def compute_institutional_features_inplace(
    spy_t0, spy_t1, qqq_t0, qqq_t1, tlt_t0, tlt_t1, gld_t0, gld_t1,
    spy_vwap, spy_vol_14d, vix_t0, vix_t2, out_view
):
    """
    Absolute Hardware Matrix. 
    Strictly aligned with the 9-dimensional Parquet feature topology.
    Mutates physical RAM in-place. Zero Allocation.
    """
    # F0 to F3: Log Returns
    spy_ret = np.log((spy_t0 + 1e-8) / (spy_t1 + 1e-8))
    qqq_ret = np.log((qqq_t0 + 1e-8) / (qqq_t1 + 1e-8))
    tlt_ret = np.log((tlt_t0 + 1e-8) / (tlt_t1 + 1e-8))
    
    out_view[0] = spy_ret
    out_view[1] = qqq_ret
    out_view[2] = tlt_ret
    out_view[3] = np.log((gld_t0 + 1e-8) / (gld_t1 + 1e-8))
    
    # F4: VWAP Log Return
    out_view[4] = np.log((spy_vwap + 1e-8) / (spy_t1 + 1e-8))
    
    # F5: Rolling Volatility (Passed in from state tracker)
    out_view[5] = spy_vol_14d
    
    # F6 & F7: Cross-Asset Spreads
    out_view[6] = spy_ret - qqq_ret
    out_view[7] = spy_ret - tlt_ret
    
    # F8: Macro VIX Momentum
    out_view[8] = vix_t0 - vix_t2
