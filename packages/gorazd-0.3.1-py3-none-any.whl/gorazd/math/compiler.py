import numpy as np
import time
from gorazd.math.core import compute_institutional_features_inplace

def execute_aot_build():
    print("="*65)
    print("    [+] COMPILER: Forcing Topology-Aligned AOT Generation")
    print("="*65)
    
    start_time = time.perf_counter()
    dummy_out = np.zeros(9, dtype=np.float32)
    
    # Execute with dummy floats to physically trigger the LLVM compiler
    compute_institutional_features_inplace(
        510.0, 509.0, 440.0, 439.0, 95.0, 94.8, 210.0, 209.5,
        509.8, 0.15, 14.5, 15.0, dummy_out
    )
    
    duration = (time.perf_counter() - start_time) * 1000
    print(f"[+] COMPILER: Topology baked into native cache in {duration:.2f}ms.")

if __name__ == "__main__":
    execute_aot_build()
