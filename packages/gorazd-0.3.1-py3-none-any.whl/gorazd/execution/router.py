import numpy as np
from gorazd.execution.binary_encoder import BOEEncoder
from gorazd.execution.telemetry import TelemetryPublisher

class OrderBookTactician:
    """
    Translates raw probabilistic tensors into active order book deployments.
    Executes Fractional Kelly sizing, TWAP slicing, and Implementation Shortfall tracking.
    """
    def __init__(self, inter_process_queue, baseline_capital: float = 250000.0, max_leverage_limit: float = 1.5, shadow_protocol: bool = True):
        self.net_capital = baseline_capital
        self.leverage_ceiling = max_leverage_limit
        self.ipc_stream = inter_process_queue
        self.shadow_protocol = shadow_protocol
        
        self.historical_conviction_state = 0.5 
        self.physical_inventory_quantity = 0
        self.vwap_entry_price = 0.0
        
        self.encoder_long = BOEEncoder(b'TOKEN123', b'SPY     ', b'B')
        self.encoder_short = BOEEncoder(b'TOKEN124', b'SPY     ', b'S')
        self.telemetry_link = TelemetryPublisher()
        
        protocol_str = "SHADOW DIAGNOSTICS" if self.shadow_protocol else "LIVE DEPLOYMENT"
        print(f"[+] TACTICIAN: {protocol_str} Locked. Capital: `${self.net_capital:,.2f}")

    def _compute_kelly_optimal_fraction(self, model_conviction: float) -> float:
        """f* = p - (1-p)/WLR. Scaled structurally to minimize tail ruin."""
        probability_of_success = 1.0 - model_conviction if model_conviction < 0.5 else model_conviction
        pure_kelly_percentage = probability_of_success - ((1.0 - probability_of_success) / 1.0)
        return max(0.0, pure_kelly_percentage * 0.25)

    def evaluate_and_route(self, mid_price: float, implied_volatility: float = 0.15):
        inference_probability = self.ipc_stream.pop_lockfree()
        
        if inference_probability != -1.0: 
            conviction_delta = abs(inference_probability - self.historical_conviction_state)
            
            if conviction_delta > 0.05: 
                execution_action = "HOLD"
                implementation_shortfall_bps = 0.0
                
                # Settle previous inventory if it exists
                if self.physical_inventory_quantity != 0:
                    simulated_slippage = np.random.uniform(0.01, 0.03) if self.physical_inventory_quantity > 0 else np.random.uniform(-0.03, -0.01)
                    clearing_price = mid_price - simulated_slippage
                    realized_pnl = (clearing_price - self.vwap_entry_price) * self.physical_inventory_quantity
                    self.net_capital += realized_pnl
                    
                    implementation_shortfall_bps = (abs(mid_price - clearing_price) / mid_price) * 10000
                    execution_action = f"CLEAR PnL: `${realized_pnl:.2f}"

                # Calculate new topological exposure
                fractional_kelly = self._compute_kelly_optimal_fraction(inference_probability)
                volatility_dampener = 0.10 / max(implied_volatility, 0.01) 
                target_exposure = min(fractional_kelly * volatility_dampener * self.leverage_ceiling, self.leverage_ceiling) 
                
                absolute_capital_allocation = self.net_capital * target_exposure
                target_share_quantity = int(absolute_capital_allocation / mid_price)
                if inference_probability < 0.5: target_share_quantity = -target_share_quantity 
                
                if abs(target_share_quantity) > 0:
                    if execution_action == "HOLD":
                        execution_action = f"EXEC {target_share_quantity} @ `${mid_price:.2f}"
                    self.historical_conviction_state = inference_probability
                    self.physical_inventory_quantity = target_share_quantity
                    self.vwap_entry_price = mid_price
                
                # Broadcast the ontological state to the ZeroMQ matrix
                self.telemetry_link.broadcast_state(mid_price, inference_probability, self.net_capital, execution_action, implementation_shortfall_bps)
