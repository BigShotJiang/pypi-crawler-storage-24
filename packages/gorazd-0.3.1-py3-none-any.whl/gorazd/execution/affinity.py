# src/gorazd/execution/affinity.py
import os
import psutil
import platform

def lock_hardware_core(core_id: int = 1):
    """
    Absolute Hardware Isolation Protocol.
    Forces the OS scheduler to permanently pin the execution matrix 
    to a dedicated physical CPU core, eradicating L1 cache misses.
    """
    pid = os.getpid()
    process = psutil.Process(pid)
    
    print("="*65)
    print(f"    [⚙️ OS SCHEDULER] Hijacking Process {pid}")
    print("="*65)
    
    try:
        if platform.system() == "Windows":
            # Windows Thread Pinning
            process.cpu_affinity([core_id])
            print(f"[+] HARDWARE LOCKED: Process permanently bound to Windows Logical Core {core_id}.")
        else:
            # Strict Linux Bare-Metal Pinning (requires 'isolcpus' in GRUB)
            os.sched_setaffinity(pid, {core_id})
            print(f"[+] HARDWARE LOCKED: Process permanently bound to Linux Physical Core {core_id}.")
            
    except AttributeError:
        print("[-] FATAL: OS does not support strict CPU affinity.")
    except ValueError:
        print(f"[-] FATAL: Core {core_id} is out of bounds for this physical hardware.")
