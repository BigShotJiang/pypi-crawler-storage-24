import numpy as np
import mmap
import ctypes

class StaticMemoryPool:
    """
    Absolute Page-Aligned Ring Buffer.
    Allocates memory physically aligned to the OS page boundaries using mmap.
    Eradicates page faults during ultra-high-frequency memory overwrites.
    """
    def __init__(self, capacity: int = 65536, feature_dim: int = 9):
        if (capacity & (capacity - 1)) != 0:
            raise ValueError("[-] FATAL: Capacity must be an exact power of 2.")
            
        self.capacity = capacity
        self.feature_dim = feature_dim
        self._mask = capacity - 1
        
        # Calculate exact byte size (Float32 = 4 bytes)
        self.byte_size = capacity * feature_dim * 4
        
        print(f"[+] MEMORY POOL: Requesting {self.byte_size} bytes of page-aligned RAM...")
        
        # Anonymous memory map (bypasses standard heap allocation)
        self._mmap_obj = mmap.mmap(-1, self.byte_size)
        
        # Map the mmap buffer directly into a NumPy C-contiguous array
        self.matrix = np.ndarray(
            shape=(self.capacity, self.feature_dim), 
            dtype=np.float32, 
            buffer=self._mmap_obj
        )
        self.write_ptr = 0

    def get_next_view(self) -> np.ndarray:
        """Bitwise modulo for zero-cost address calculation."""
        idx = self.write_ptr & self._mask
        self.write_ptr += 1
        return self.matrix[idx, :]

    def close(self):
        """Safely releases the physical RAM block."""
        self._mmap_obj.close()
