# src/gorazd/ml/engine.py
import xgboost as xgb
import numpy as np
from pathlib import Path
import os

class InferenceEngine:
    """
    Absolute Zero-Copy ML Inference Abstraction.
    Shields the user from memory pointer allocation and XGBoost tensor sterilization.
    """
    def __init__(self, model_path: str = "models/registry/institutional_core.ubj"):
        self.booster = xgb.Booster()
        self.is_loaded = False
        
        # Resolve path dynamically from the current working directory
        full_path = Path(os.getcwd()) / model_path
        if full_path.exists():
            self.booster.load_model(str(full_path))
            self.is_loaded = True
            print(f"[+] INFERENCE ENGINE: XGBoost matrix engaged from {full_path.name}")
        else:
            print(f"[-] INFERENCE WARNING: Matrix {full_path.name} not found. Engine unarmed.")

    def predict_t0(self, raw_features: np.ndarray) -> float:
        """
        Executes a zero-copy pointer prediction directly against physical RAM.
        """
        if not self.is_loaded:
            raise RuntimeError("[-] FATAL: Attempted inference on an unarmed engine.")
            
        # TACTICAL COUNTERMEASURE: Absolute Memory Sterilization
        if not raw_features.flags['C_CONTIGUOUS']:
            feature_tensor = np.ascontiguousarray(raw_features.reshape(1, -1), dtype=np.float32)
        else:
            feature_tensor = raw_features.reshape(1, -1).astype(np.float32)
            
        return self.booster.inplace_predict(feature_tensor)[0]
