import numpy as np

class CausalTemporalIsolator:
    def __init__(self, fold_count: int = 5, purge_duration_sec: float = 1296000.0, embargo_duration_sec: float = 1296000.0):
        self.fold_count = fold_count
        self.purge_duration_sec = purge_duration_sec
        self.embargo_duration_sec = embargo_duration_sec

    def partition_epochs(self, temporal_array: np.ndarray):
        if len(temporal_array) < 100: return
        temporal_deltas = np.zeros_like(temporal_array)
        if len(temporal_array) > 1: temporal_deltas[1:] = np.minimum(temporal_array[1:] - temporal_array[:-1], 3600.0)
        
        cumulative_active_time = np.cumsum(temporal_deltas)
        temporal_step = cumulative_active_time[-1] / float(self.fold_count)
        
        fold_partitions = []
        for i in range(self.fold_count):
            start_boundary = i * temporal_step
            end_boundary = (i + 1) * temporal_step if i < self.fold_count - 1 else cumulative_active_time[-1] + 1.0
            fold_partitions.append(np.where((cumulative_active_time >= start_boundary) & (cumulative_active_time < end_boundary))[0])

        for i in range(2, self.fold_count):
            stop_tensor, eval_tensor = fold_partitions[i-1], fold_partitions[i]
            if len(stop_tensor) == 0 or len(eval_tensor) == 0: continue
            train_tensor_raw = np.concatenate(fold_partitions[:i-1])
            if len(train_tensor_raw) == 0: continue
                
            stop_start_epoch, eval_start_epoch = temporal_array[stop_tensor[0]], temporal_array[eval_tensor[0]]
            purged_train_indices = train_tensor_raw[temporal_array[train_tensor_raw] <= (stop_start_epoch - self.purge_duration_sec)]
            embargoed_stop_indices = stop_tensor[temporal_array[stop_tensor] <= (eval_start_epoch - self.embargo_duration_sec)]
            
            if len(purged_train_indices) > 5 and len(embargoed_stop_indices) > 0:
                yield purged_train_indices, embargoed_stop_indices, eval_tensor

class MicrostructureDynamics:
    """
    Mathematical modeling of order book impact utilizing Nonlinear Risk Lagrangians.
    """
    def __init__(self, alpha_penalty: float = 1.0, beta_penalty: float = 1.0):
        self.alpha_pen = alpha_penalty
        self.beta_pen = beta_penalty

    def compute_asymmetric_risk_derivatives(self, probability_activations: np.ndarray, target_labels: np.ndarray, allocation_delta: np.ndarray, spread_bps: float = 0.002) -> tuple:
        """
        Restores the mentor's strict convexity mapping and asymptotic clipping.
        """
        # Base directional error
        directional_error = probability_activations - target_labels
        
        # Marginal Expected Value incorporating friction
        ev_marginal = (probability_activations * target_labels) - (np.abs(allocation_delta) * spread_bps)
        
        # Asymptotic Clipping to prevent floating point overflow in the exponent
        arg_clip = np.clip(-self.beta_pen * ev_marginal, -700.0, 700.0)
        s_penalization = 1.0 / (1.0 + np.exp(arg_clip))
        
        # Exact gradient factoring in the continuous risk lagrangian
        dL_dEV_exact = -1.0 - (self.alpha_pen * self.beta_pen * s_penalization)
        gradient_vector = directional_error + (dL_dEV_exact * spread_bps * np.sign(allocation_delta))
        
        # Strict Positive Definite Hessian for XGBoost tree splitting
        hessian_diagonal = self.alpha_pen * (self.beta_pen ** 2) * s_penalization * (1.0 - s_penalization)
        base_hessian = probability_activations * (1.0 - probability_activations)
        hessian_vector = np.maximum(base_hessian + (hessian_diagonal * spread_bps), 1e-5)
        
        return gradient_vector, hessian_vector
