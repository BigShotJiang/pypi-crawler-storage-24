import xgboost as xgb
import optuna
import polars as pl
import numpy as np
from pathlib import Path
import os
from gorazd.data.storage import ParquetVault
from gorazd.ml.physics import CausalTemporalIsolator, MicrostructureDynamics

class BayesianHyperparameterManifold:
    def __init__(self):
        self.vault = ParquetVault()
        self.microstructure = MicrostructureDynamics(alpha_penalty=2.0, beta_penalty=5.0)
        self.temporal_isolator = CausalTemporalIsolator(fold_count=5)

    def _compute_asymmetric_loss_gradient(self, logit_predictions: np.ndarray, design_matrix: xgb.DMatrix) -> tuple:
        target_labels = design_matrix.get_label()
        historical_state_tensor = design_matrix.get_base_margin()
        if historical_state_tensor is None or len(historical_state_tensor) == 0:
            historical_state_tensor = np.zeros_like(logit_predictions) + 0.5 

        probability_activations = 1.0 / (1.0 + np.exp(-logit_predictions))
        allocation_delta = probability_activations - historical_state_tensor
        
        # Route to the newly restored Physics Engine
        gradient_vector, hessian_vector = self.microstructure.compute_asymmetric_risk_derivatives(
            probability_activations, target_labels, allocation_delta, spread_bps=0.002
        )
        return gradient_vector, hessian_vector

    def _optimize_structural_topology(self, trial: optuna.Trial, feature_tensor: np.ndarray, target_vector: np.ndarray, epoch_vector: np.ndarray) -> float:
        hyperparameter_topology = {
            "tree_method": "hist",
            "learning_rate": trial.suggest_float("learning_rate", 1e-3, 0.1, log=True),
            "max_depth": trial.suggest_int("max_depth", 3, 7),
            "gamma": trial.suggest_float("gamma", 0.1, 5.0),
            "subsample": trial.suggest_float("subsample", 0.5, 0.9),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 0.9),
            "disable_default_eval_metric": 1 
        }
        
        fold_evaluations = []
        for train_idx, stop_idx, eval_idx in self.temporal_isolator.partition_epochs(epoch_vector):
            X_train_fold, y_train_fold = feature_tensor[train_idx], target_vector[train_idx]
            X_eval_fold, y_eval_fold = feature_tensor[eval_idx], target_vector[eval_idx]
            
            dtrain = xgb.DMatrix(X_train_fold, label=y_train_fold)
            deval = xgb.DMatrix(X_eval_fold, label=y_eval_fold)
            dtrain.set_base_margin(np.zeros(len(X_train_fold)) + 0.5)
            deval.set_base_margin(np.zeros(len(X_eval_fold)) + 0.5)
            
            def _compute_friction_adjusted_evaluation(logits, dmatrix):
                probs = 1.0 / (1.0 + np.exp(-logits))
                directional_accuracy = 1.0 - np.abs(probs - dmatrix.get_label())
                position_turnover = np.abs(probs - 0.5)
                risk_adjusted_pnl = directional_accuracy - (position_turnover * 0.002 * 10)
                return 'net_loss', float(-np.mean(risk_adjusted_pnl))

            gradient_booster = xgb.train(
                hyperparameter_topology, dtrain, evals=[(deval, "eval")], 
                obj=self._compute_asymmetric_loss_gradient, 
                custom_metric=_compute_friction_adjusted_evaluation, 
                early_stopping_rounds=15, verbose_eval=False
            )
            fold_evaluations.append(gradient_booster.best_score)
            
        return float(np.mean(fold_evaluations)) if fold_evaluations else 0.0

    def execute_manifold_projection(self, target_parquet_filename: str, output_model_name: str = "institutional_core.ubj"):
        print("="*65)
        print(f"    [?? ML ENGINE] Projecting Asymmetric Physics from {target_parquet_filename}")
        print("="*65)
        
        dataframe_matrix = self.vault.extract_matrix(target_parquet_filename)
        feature_tensor = dataframe_matrix.select(dataframe_matrix.columns[:9]).to_numpy().astype(np.float32)
        target_vector = dataframe_matrix.select("Label").to_numpy().flatten().astype(np.int32)
        epoch_vector = dataframe_matrix.select("Epoch").to_numpy().flatten().astype(np.float64) * 86400.0
        
        study = optuna.create_study(direction="minimize")
        study.optimize(lambda trial: self._optimize_structural_topology(trial, feature_tensor, target_vector, epoch_vector), n_trials=5)
        
        print(f"\n[+] TOPOLOGY CONVERGENCE ACHIEVED. Optimal Friction Loss: {study.best_value:.5f}")
        
        optimal_parameters = study.best_params
        optimal_parameters["disable_default_eval_metric"] = 1
        
        terminal_design_matrix = xgb.DMatrix(feature_tensor, label=target_vector)
        terminal_design_matrix.set_base_margin(np.zeros(len(feature_tensor)) + 0.5) 
        terminal_booster = xgb.train(optimal_parameters, terminal_design_matrix, num_boost_round=100, obj=self._compute_asymmetric_loss_gradient)
        
        compiled_path = Path(os.getcwd()) / output_model_name
        terminal_booster.save_model(str(compiled_path))
        print(f"[+] PHYSICAL CAUSAL MATRIX BAKED: Deployed to {compiled_path.name}.")
