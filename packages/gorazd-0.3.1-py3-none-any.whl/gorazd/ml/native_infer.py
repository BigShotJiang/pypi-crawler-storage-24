import ctypes
import numpy as np
from pathlib import Path
import sys
import os

class NativeXGBoostEngine:
    """
    Absolute C-Level Inference Matrix.
    Strictly types the C-API arguments to prevent memory access violations
    and perfectly extracts logit vectors bypassing the Python GIL.
    """
    def __init__(self, model_path: str):
        venv_base = Path(sys.executable).parent.parent
        self.dll_path = venv_base / "Lib" / "site-packages" / "xgboost" / "lib" / "xgboost.dll"
        
        if not self.dll_path.exists():
            print(f"[-] WARNING: xgboost.dll missing at {self.dll_path}. Emulation mode active.")
            self.is_dummy = True
            return
            
        self.is_dummy = False
        self.lib = ctypes.cdll.LoadLibrary(str(self.dll_path))
        
        # [!] MENTOR MANDATE: Strict C-Type Definitions to prevent NULL pointers
        self.lib.XGBGetLastError.restype = ctypes.c_char_p
        
        # Define exact memory geometries for the C compiler
        self.lib.XGBoosterCreate.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.POINTER(ctypes.c_void_p)]
        self.lib.XGBoosterLoadModel.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
        self.lib.XGDMatrixCreateFromMat.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_uint64, ctypes.c_float, ctypes.POINTER(ctypes.c_void_p)]
        
        # We use the stable XGBoosterPredict API rather than the volatile JSON-config variant
        self.lib.XGBoosterPredict.argtypes = [
            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_uint, 
            ctypes.c_int, ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.POINTER(ctypes.c_float))
        ]
        self.lib.XGDMatrixFree.argtypes = [ctypes.c_void_p]

        self.booster = ctypes.c_void_p()
        
        # Create Booster Instance
        res1 = self.lib.XGBoosterCreate(None, 0, ctypes.byref(self.booster))
        self._check_call(res1)
        
        # Load Model Matrix
        model_bytes = str(Path(os.getcwd()) / model_path).encode('utf-8')
        res2 = self.lib.XGBoosterLoadModel(self.booster, model_bytes)
        self._check_call(res2)
        
        print(f"[+] NATIVE ENGINE: C-Level Matrix Locked. Mapped to {self.dll_path.name}")

    def _check_call(self, ret: int):
        """Hardware exception decoder. Extracts the physical C-error if one occurs."""
        if ret != 0:
            err = self.lib.XGBGetLastError().decode('utf-8')
            raise RuntimeError(f"[-] C-API FATAL MEMORY EXCEPTION: {err}")

    def predict_zero_copy(self, features: np.ndarray) -> float:
        if self.is_dummy:
            return 0.99
            
        # Ensure array is perfectly C-contiguous in physical RAM
        if not features.flags['C_CONTIGUOUS'] or features.dtype != np.float32:
            features = np.ascontiguousarray(features, dtype=np.float32)
            
        dmatrix = ctypes.c_void_p()
        data_ptr = features.ctypes.data_as(ctypes.c_void_p)
        
        # Instantiate C-Level DMatrix
        res3 = self.lib.XGDMatrixCreateFromMat(data_ptr, 1, features.shape[0], ctypes.c_float(np.nan), ctypes.byref(dmatrix))
        self._check_call(res3)
        
        out_len = ctypes.c_uint64()
        out_result = ctypes.POINTER(ctypes.c_float)()
        
        # Execute C-Level Inference
        res4 = self.lib.XGBoosterPredict(
            self.booster, dmatrix, 
            ctypes.c_int(0), ctypes.c_uint(0), ctypes.c_int(0), 
            ctypes.byref(out_len), ctypes.byref(out_result)
        )
        self._check_call(res4)
        
        # Extract physical C-float
        raw_logit = out_result[0]
        
        # Clean up C-Memory to prevent OS RAM leakage
        self.lib.XGDMatrixFree(dmatrix)
        
        # Math: Sigmoid conversion mapping logit distance to probability constraint
        return 1.0 / (1.0 + np.exp(-raw_logit))
