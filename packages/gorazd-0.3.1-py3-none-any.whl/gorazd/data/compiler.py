import polars as pl
import numpy as np
from pathlib import Path
from gorazd.data.gateway import DataGateway
from gorazd.data.storage import ParquetVault

class MarketStateCompiler:
    """
    Mathematical synthesis of raw market data into institutional feature tensors.
    Applies exact backward adjustment multipliers to preserve true physical returns.
    """
    def __init__(self, target_instrument="SPY"):
        self.gateway = DataGateway()
        self.vault = ParquetVault()
        self.target_instrument = target_instrument
        self.asset_universe = [target_instrument, 'QQQ', 'TLT', 'GLD']
        self.macro_instrument = '^VIX'

    def synthesize_orthogonal_features(self, inception_date="2016-01-01") -> Path:
        print("="*70)
        print(f" [+] COMPILER: Synthesizing Orthogonal Tensors for {self.target_instrument}")
        print("="*70)

        raw_lazy_frames = [self.gateway.fetch_tiingo_daily_lazy(asset, inception_date) for asset in self.asset_universe]
        vix_lazy_frame = self.gateway.fetch_fred_vix_lazy()
        vwap_lazy_frame = self.gateway.fetch_alpaca_sip_vwap(self.asset_universe, inception_date)

        # 1. Tensor Alignment
        asset_price_tensor = raw_lazy_frames[0]
        for i in range(1, len(raw_lazy_frames)):
            asset_price_tensor = asset_price_tensor.join(raw_lazy_frames[i], on='Date', how='full', coalesce=True)
            
        asset_price_tensor = asset_price_tensor.join(vwap_lazy_frame, on='Date', how='left')
        asset_price_tensor = asset_price_tensor.sort('Date').join_asof(vix_lazy_frame, on='Date', strategy='backward')

        # 2. Strict Backward Adjustment Scalars (Corporate Action Preservation)
        backward_adjustment_scalars = []
        for asset in self.asset_universe:
            split_factor = pl.col(f'{asset}_Split').fill_null(1.0)
            dividend_factor = pl.max_horizontal(1.0 - (pl.col(f'{asset}_Div').fill_null(0.0) / (pl.col(asset).shift(1) / split_factor)).fill_nan(0.0), 0.0001)
            
            cumulative_split_multiplier = split_factor.shift(-1).fill_null(1.0).reverse().cum_prod().reverse()
            cumulative_dividend_multiplier = dividend_factor.shift(-1).fill_null(1.0).reverse().cum_prod().reverse()
            
            backward_adjustment_scalars.extend([
                ((pl.col(asset) / cumulative_split_multiplier) * cumulative_dividend_multiplier).alias(asset),
                ((pl.col(f'{asset}_VWAP').fill_null(pl.col(asset)) / cumulative_split_multiplier) * cumulative_dividend_multiplier).alias(f'{asset}_VWAP'),
                (pl.col(f'{asset}_Volume') * cumulative_split_multiplier).alias(f'{asset}_Volume')
            ])
            
        aligned_tensor = asset_price_tensor.with_columns(backward_adjustment_scalars)

        # 3. Orthogonal Feature Projection (9-Dimensional Matrix)
        projection_expressions = [(pl.col(asset).log() - pl.col(asset).shift(1).log()).alias(f"{asset}_LogRet") for asset in self.asset_universe]
        projection_expressions.append((pl.col(f"{self.target_instrument}_VWAP") / pl.col(self.target_instrument).shift(1)).log().alias("VWAP_LogRet"))
        projection_expressions.append((pl.col(self.macro_instrument) - pl.col(self.macro_instrument).shift(2)).alias("VIX_Diff"))
        
        aligned_tensor = aligned_tensor.with_columns(projection_expressions).with_columns([
            (pl.col(f'{self.target_instrument}_LogRet').rolling_std(14) * np.sqrt(252)).alias('Vol_14d'),
            (pl.col(f'{self.target_instrument}_LogRet') - pl.col('QQQ_LogRet')).alias('Spread_QQQ'),
            (pl.col(f'{self.target_instrument}_LogRet') - pl.col('TLT_LogRet')).alias('Spread_TLT'),
            (pl.col(f"{self.target_instrument}").shift(-1) > pl.col(f"{self.target_instrument}")).cast(pl.Int32).alias('Label'),
            pl.col('Date').cast(pl.Date).cast(pl.Int32).alias('Epoch')
        ])
        
        target_features = [
            f"{self.target_instrument}_LogRet", "QQQ_LogRet", "TLT_LogRet", "GLD_LogRet",
            "VWAP_LogRet", "Vol_14d", "Spread_QQQ", "Spread_TLT", "VIX_Diff"
        ]
        
        final_physical_matrix = aligned_tensor.select(target_features + ['Label', 'Epoch']).drop_nulls().collect()
        
        output_filename = f"{self.target_instrument}_institutional_matrix.parquet"
        file_path = self.vault.lock_matrix(final_physical_matrix, output_filename)
        print(f"[+] MATRIX LOCKED: {final_physical_matrix.height} topological points extracted to {file_path.name}.")
        return file_path
