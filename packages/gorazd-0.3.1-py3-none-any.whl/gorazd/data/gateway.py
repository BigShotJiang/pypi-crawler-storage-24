import os
import io
import time
import requests
import polars as pl
from datetime import datetime, timezone
import pandas as pd
from gorazd.config import settings

class DataGateway:
    """
    Absolute Unified Data Facade (Physical Market Edition).
    Routes raw execution data from Tiingo, Alpaca, and FRED, ensuring 
    absolute physical parity without dynamic adjustment lag.
    """
    def __init__(self):
        self.tiingo_headers = {'Content-Type': 'application/json', 'Authorization': f'Token {settings.tiingo_api_key}'}
        self.alpaca_headers = {
            'APCA-API-KEY-ID': settings.alpaca_api_key,
            'APCA-API-SECRET-KEY': settings.alpaca_api_secret,
            'Accept': 'application/json'
        }

    def fetch_tiingo_daily_lazy(self, symbol: str, start_date: str) -> pl.LazyFrame:
        print(f"    -> [GATEWAY] Routing Tiingo Raw Matrix for {symbol}...")
        url = f"https://api.tiingo.com/tiingo/daily/{symbol}/prices"
        res = requests.get(url, headers=self.tiingo_headers, params={'startDate': start_date, 'format': 'csv'})
        if res.status_code != 200:
            raise ConnectionError(f"[-] Tiingo API Failure [{symbol}]: {res.text}")
            
        return pl.read_csv(io.StringIO(res.text)).lazy().select([
            pl.col('date').str.slice(0, 10).str.to_date("%Y-%m-%d").alias('Date'),
            pl.col('open').alias(f'{symbol}_Raw_Open'),
            pl.col('high').alias(f'{symbol}_High'),
            pl.col('low').alias(f'{symbol}_Low'),
            pl.col('close').alias(f'{symbol}'),
            pl.col('volume').alias(f'{symbol}_Volume'),
            pl.col('splitFactor').alias(f'{symbol}_Split'),
            pl.col('divCash').alias(f'{symbol}_Div')
        ])

    def fetch_alpaca_sip_vwap(self, symbols: list, start_date: str) -> pl.LazyFrame:
        print(f"    -> [GATEWAY] Routing Alpaca 1Min SIP Tensor for VWAP Extraction...")
        safe_start = max(datetime.strptime(start_date, "%Y-%m-%d"), datetime(2016, 1, 1))
        ny_now = pd.Timestamp.now(tz='UTC').tz_convert('America/New_York')
        
        url = "https://data.alpaca.markets/v2/stocks/bars"
        params = {
            'symbols': ",".join(symbols), 'timeframe': '1Min',
            'start': safe_start.strftime("%Y-%m-%dT%H:%M:%SZ"),
            'end': ny_now.tz_convert('UTC').strftime("%Y-%m-%dT%H:%M:%SZ"),
            'limit': 10000, 'feed': 'sip', 'adjustment': 'raw'
        }
        
        all_bars, page_token = [], None
        with requests.Session() as session:
            session.headers.update(self.alpaca_headers)
            while True:
                if page_token: params['page_token'] = page_token
                res = session.get(url, params=params)
                if res.status_code == 429:
                    time.sleep(60); continue
                elif res.status_code != 200: break
                
                data = res.json()
                for sym, sym_bars in data.get('bars', {}).items():
                    for b in sym_bars:
                        b['symbol'] = sym
                        all_bars.append(b)
                page_token = data.get('next_page_token')
                if not page_token: break
                time.sleep(0.3)

        if not all_bars:
            return pl.DataFrame({'Date': []}, schema={'Date': pl.Date}).lazy()

        df_bars = pl.DataFrame(all_bars)
        df_bars = (
            df_bars.with_columns(pl.col("t").str.strptime(pl.Datetime, "%Y-%m-%dT%H:%M:%SZ").dt.replace_time_zone("UTC"))
            .with_columns(pl.col("t").dt.convert_time_zone("America/New_York").alias("ny_time"))
            .with_columns(pl.col("ny_time").dt.date().alias("Date"))
        )

        # Extract Pre-Market to Early Open VWAP
        df_vwap = (
            df_bars.filter((pl.col("ny_time").dt.hour() >= 4) & ((pl.col("ny_time").dt.hour() < 9) | ((pl.col("ny_time").dt.hour() == 9) & (pl.col("ny_time").dt.minute() < 30))))
            .with_columns((pl.col("vw") * pl.col("v")).alias("price_volume"))
            .group_by(["Date", "symbol"])
            .agg((pl.col("price_volume").sum() / pl.col("v").sum()).alias("VWAP"))
        )
        
        vwap_pivot = df_vwap.pivot(index="Date", columns="symbol", values="VWAP")
        return vwap_pivot.rename({col: f"{col}_VWAP" for col in vwap_pivot.columns if col != "Date"}).lazy()

    def fetch_fred_vix_lazy(self) -> pl.LazyFrame:
        print(f"    -> [GATEWAY] Routing FRED Macro Volatility Tensor...")
        url = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=VIXCLS"
        res = requests.get(url)
        if res.status_code != 200: raise ConnectionError("FRED API Failure.")
        return pl.read_csv(io.StringIO(res.text), null_values=["."]).lazy().select([
            (pl.col('observation_date').str.to_date("%Y-%m-%d") + pl.duration(days=1)).alias('Date'),
            pl.col('VIXCLS').cast(pl.Float64).alias('^VIX')
        ]).drop_nulls().sort('Date')
