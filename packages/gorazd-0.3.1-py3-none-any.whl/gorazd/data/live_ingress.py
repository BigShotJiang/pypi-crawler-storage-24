import threading
import time
import numpy as np

class AsyncLiveIngress:
    """
    Absolute Non-Blocking Ingress Gateway.
    Simulates a dedicated network thread constantly polling a WebSocket or FIX connection.
    Updates the shared price state in the background, freeing the XGBoost tensor 
    from synchronous IO latency.
    """
    def __init__(self, start_price: float = 510.00):
        self.current_price = start_price
        self.is_running = False
        self._thread = None
        self._lock = threading.Lock() # Lightweight GIL lock for variable mutation
        
        # Pre-allocate state matrices to avoid mallocs during the stream
        self.t0_macros = np.array([4.20, 105.0], dtype=np.float64)
        self.t1_macros = np.array([4.18, 105.1], dtype=np.float64)
        self.t0_megas = np.array([170.1, 410.2, 850.3], dtype=np.float64)
        self.t1_megas = np.array([169.5, 409.0, 848.1], dtype=np.float64)

    def _stream_simulator(self):
        print("[+] ASYNC INGRESS: Background network thread ignited. Polling ticks...")
        while self.is_running:
            # Simulate high-frequency WebSocket tick arrival
            volatility_tick = np.random.choice([-1.5, 1.5, -0.5, 0.5, 0.0])
            with self._lock:
                self.current_price += volatility_tick
            
            # Simulate network idle time (e.g., waiting for the next packet)
            time.sleep(0.05) 

    def start_stream(self):
        self.is_running = True
        self._thread = threading.Thread(target=self._stream_simulator, daemon=True)
        self._thread.start()

    def stop_stream(self):
        self.is_running = False
        if self._thread:
            self._thread.join()

    def get_latest_state(self):
        with self._lock:
            return self.current_price, self.t0_macros, self.t1_macros, self.t0_megas, self.t1_megas
