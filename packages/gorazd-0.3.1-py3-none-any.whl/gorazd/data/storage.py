# src/gorazd/data/storage.py
import polars as pl
from pathlib import Path
import os

class ParquetVault:
    """
    Absolute Columnar Storage Matrix.
    Bypasses standard I/O bottlenecks by enforcing Snappy-compressed, 
    memory-mapped Apache Arrow serialization.
    """
    def __init__(self, vault_dir: str = "data_vault"):
        self.vault_dir = Path(os.getcwd()) / vault_dir
        self.vault_dir.mkdir(parents=True, exist_ok=True)

    def lock_matrix(self, df: pl.DataFrame, filename: str):
        """Dumps a Polars DataFrame directly to C-contiguous storage."""
        if not filename.endswith(".parquet"):
            filename += ".parquet"
        
        file_path = self.vault_dir / filename
        # Snappy compression maintains extreme read speeds while shrinking disk footprint
        df.write_parquet(file_path, compression="snappy")
        return file_path

    def extract_matrix(self, filename: str) -> pl.DataFrame:
        """Memory-maps the columnar data directly into physical RAM."""
        if not filename.endswith(".parquet"):
            filename += ".parquet"
            
        file_path = self.vault_dir / filename
        if not file_path.exists():
            raise FileNotFoundError(f"[-] FATAL: Parquet matrix {filename} does not exist.")
            
        return pl.read_parquet(file_path)
    
    def scan_matrix(self, filename: str) -> pl.LazyFrame:
        """
        Absolute Lazy Streaming Protocol.
        Streams multi-gigabyte tick arrays directly into the execution matrix, 
        permanently bypassing physical RAM limits.
        """
        if not filename.endswith(".parquet"):
            filename += ".parquet"
            
        file_path = self.vault_dir / filename
        if not file_path.exists():
            raise FileNotFoundError(f"[-] FATAL: Parquet matrix {filename} does not exist.")
            
        # Returns an unevaluated computation graph, deferring memory allocation until strictly necessary
        return pl.scan_parquet(file_path)
