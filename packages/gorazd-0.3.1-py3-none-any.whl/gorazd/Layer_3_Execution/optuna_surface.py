# gorazd/Layer_3_Execution/optuna_surface.py
import sys
import time
import optuna
import xgboost as xgb
import numpy as np
import gc  # TACTICAL COUNTERMEASURE: Explicit GC Module Import
from pathlib import Path
from datetime import datetime

# Absolute Path Resolution
sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

from gorazd.Layer_1_Ingestion.fetch_historical import HistoricalIngestionNode
from gorazd.Layer_2_Macro_Matrix.alpha_compiler import AlphaCompiler
from gorazd.Layer_3_Execution.causal_validation import PurgedTimeSeriesFold

class OptimizationSurface:
    """
    Absolute Bayesian Optimization Engine.
    Executes an asymmetric hyperparameter search over Purged Time-Series Folds, 
    utilizing manual offline memory purging to prevent RAM bloat during massive 
    trial sequences.
    """
    def __init__(self):
        self.compiler = AlphaCompiler()
        self.model_path = Path("gorazd/models/registry/institutional_core.ubj")
        self.cv = PurgedTimeSeriesFold(n_splits=5, embargo_pct=0.05)
        
    def _objective(self, trial: optuna.Trial) -> float:
        params = {
            "objective": "binary:logistic",
            "eval_metric": "logloss",
            "tree_method": "hist",
            "device": "cuda", # Will safely fallback to CPU if no NVIDIA GPU is detected
            "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.2, log=True),
            "max_depth": trial.suggest_int("max_depth", 2, 6),
            "subsample": trial.suggest_float("subsample", 0.5, 0.9),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 0.9),
            "min_child_weight": trial.suggest_int("min_child_weight", 1, 10),
            "gamma": trial.suggest_float("gamma", 0.0, 5.0),
            "lambda": trial.suggest_float("lambda", 1e-3, 10.0, log=True),
            "alpha": trial.suggest_float("alpha", 1e-3, 10.0, log=True),
        }
        
        fold_scores = []
        X_np = self.X_train.to_pandas().to_numpy()
        y_np = self.y_train.to_pandas().to_numpy()
        
        for train_idx, val_idx in self.cv.split(X_np):
            dtrain = xgb.DMatrix(X_np[train_idx], label=y_np[train_idx])
            dval = xgb.DMatrix(X_np[val_idx], label=y_np[val_idx])
            
            booster = xgb.train(
                params,
                dtrain,
                num_boost_round=150,
                evals=[(dval, "val")],
                early_stopping_rounds=15,
                verbose_eval=False
            )
            
            fold_scores.append(booster.best_score)
            
            # TACTICAL COUNTERMEASURE: Manual Offline Memory Purge
            del dtrain, dval, booster
            gc.collect()
            
        return np.mean(fold_scores)

    def execute_optimization(self, n_trials: int = 20):
        print("\n[+] INITIATING BAYESIAN OPTUNA SURFACE: Compiling physical state...")
        self.X_train, self.y_train = self.compiler.compile_historical_tensors()
        
        optuna.logging.set_verbosity(optuna.logging.WARNING)
        study = optuna.create_study(direction="minimize")
        study.optimize(self._objective, n_trials=n_trials, show_progress_bar=True)
        
        print("\n[+] OPTIMIZATION CONVERGED: Optimal Hyperparameter Matrix Discovered.")
        best_params = study.best_params
        best_params.update({"objective": "binary:logistic", "tree_method": "hist", "device": "cuda"})
        
        for key, val in best_params.items():
            print(f"    -> {key}: {val}")
            
        print("\n[+] FORGING TERMINAL MODEL: Training final institutional matrix on 100% of data...")
        X_full = self.X_train.to_pandas().to_numpy()
        y_full = self.y_train.to_pandas().to_numpy()
        
        dtrain_full = xgb.DMatrix(X_full, label=y_full)
        final_booster = xgb.train(best_params, dtrain_full, num_boost_round=100)
        
        self.model_path.parent.mkdir(parents=True, exist_ok=True)
        final_booster.save_model(str(self.model_path))
        print(f"[+] ABSOLUTE VICTORY: True Predictive Model serialized to {self.model_path}")

class AutonomousRetrainingDaemon:
    def __init__(self, target_hour: int = 3, target_minute: int = 0):
        self.target_hour = target_hour
        self.target_minute = target_minute

    def ignite_daemon(self, execute_immediately: bool = True):
        if execute_immediately:
            self._trigger_refit_sequence()
            
        print(f"\n[+] DAEMON SECURED: Entering background sleep. Scheduled refit: {self.target_hour:02d}:{self.target_minute:02d} AM daily.")
        
        while True:
            now = datetime.now()
            if now.hour == self.target_hour and now.minute == self.target_minute:
                self._trigger_refit_sequence()
                time.sleep(61)
            else:
                time.sleep(30)
                
    def _trigger_refit_sequence(self):
        print("\n" + "="*65)
        print(f"[+] CHRONOS TRIGGER ENGAGED: Initiating Matrix Refit at {datetime.now().strftime('%H:%M:%S')}")
        print("="*65)
        try:
            print("[+] IGNITING LAYER 1: Extracting T-1 Bloomberg BDH Matrix...")
            ingestion_node = HistoricalIngestionNode()
            ingestion_node.execute_bulk_extraction()
            
            print("[+] IGNITING LAYER 3: Triggering GPU-Accelerated Bayesian Surface...")
            optimizer = OptimizationSurface()
            optimizer.execute_optimization(n_trials=30)
        except Exception as e:
            print(f"[-] CRITICAL DAEMON FAILURE: Nightly refit violently aborted. {e}")

if __name__ == "__main__":
    daemon = AutonomousRetrainingDaemon()
    daemon.ignite_daemon(execute_immediately=True)
