# gorazd/Layer_3_Execution/telemetry_buffer.py
import mmap
import time
import threading
import sys
from pathlib import Path

class TelemetryRingBuffer:
    """
    Absolute Lock-Free Memory Mapped (mmap) Telemetry Buffer.
    Allows the hot execution thread to dump string payloads into pre-allocated 
    physical RAM in nanoseconds. An asynchronous background daemon physically 
    flushes the RAM to the Windows console, completely isolating I/O latency.
    """
    def __init__(self, file_path="gorazd/logs/telemetry.mmap", size=1024*1024*10): # 10MB Ring Buffer
        self.file_path = Path(file_path)
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        self.record_size = 256 # Fixed byte width for absolute deterministic writing
        self.max_records = size // self.record_size
        
        # 1. Pre-allocate the physical file on disk to prevent dynamic resizing pauses
        if not self.file_path.exists():
            with open(self.file_path, "wb") as f:
                f.write(b'\x00' * size)
                
        self.f = open(self.file_path, "r+b")
        self.mm = mmap.mmap(self.f.fileno(), 0)
        
        # Lock-free dual-head indices
        self.write_idx = 0
        self.read_idx = 0

    def log_fast(self, payload: str):
        """
        Executed by the hot XGBoost thread. 
        Zero blocking I/O. Pure memory assignment.
        """
        # Encode and right-pad the payload to strictly 256 bytes
        encoded = payload.encode('utf-8')[:self.record_size]
        padded = encoded.ljust(self.record_size, b'\x00')
        
        offset = self.write_idx * self.record_size
        self.mm[offset:offset+self.record_size] = padded
        
        # Advance the write head
        self.write_idx = (self.write_idx + 1) % self.max_records

    def _daemon_flush(self):
        """
        Executed strictly by the isolated background thread.
        Polls the read head and flushes to the OS console asynchronously.
        """
        sys.stdout.write("[+] TELEMETRY DAEMON: Asynchronous mmap ring buffer online. Standard I/O silenced.\n")
        sys.stdout.flush()
        
        while True:
            if self.read_idx != self.write_idx:
                offset = self.read_idx * self.record_size
                raw_data = self.mm[offset:offset+self.record_size]
                
                # Strip null padding and decode
                message = raw_data.rstrip(b'\x00').decode('utf-8', errors='ignore')
                
                # Execute the heavy OS I/O block out-of-band
                sys.stdout.write(message + "\n")
                sys.stdout.flush()
                
                # Advance the read head
                self.read_idx = (self.read_idx + 1) % self.max_records
            else:
                # Idle the background thread for 1ms if the buffer is empty
                time.sleep(0.001)

    def ignite_daemon(self):
        t = threading.Thread(target=self._daemon_flush, daemon=True)
        t.start()
