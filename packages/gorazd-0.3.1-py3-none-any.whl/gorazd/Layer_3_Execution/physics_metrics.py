# gorazd/Layer_3_Execution/physics_metrics.py
import numpy as np

class ExecutionPhysics:
    """
    Absolute Market Microstructure Penalty Matrix.
    Evaluates raw XGBoost conviction against physical top-of-book depth 
    to apply convex shrinkage, permanently eradicating structural slippage.
    """
    def __init__(self, base_capital: float = 100000.0, friction_coefficient: float = 0.5):
        self.base_capital = base_capital
        self.friction_coefficient = friction_coefficient

    def apply_convex_penalty(self, conviction: float, book_depth: float) -> tuple:
        """
        Executes the mathematical shrinkage function: S(x) = x * e^(-lambda * (x/D))
        """
        # Scale 0-100% conviction to a raw dollar allocation target
        raw_allocation = self.base_capital * (conviction / 100.0)
        
        if raw_allocation <= 0 or book_depth <= 0:
            return 0.0, 0.0
            
        # TACTICAL COUNTERMEASURE: Convex Shrinkage
        # As order size approaches available liquidity, friction increases exponentially
        penalty_multiplier = np.exp(-self.friction_coefficient * (raw_allocation / book_depth))
        discounted_allocation = raw_allocation * penalty_multiplier
        
        return raw_allocation, discounted_allocation
