# gorazd/Layer_3_Execution/order_gateway.py
import asyncio
import threading
import time

class AsyncOrderGateway:
    def __init__(self, telemetry_buffer):
        self.order_queue = asyncio.Queue()
        self.telemetry = telemetry_buffer # Inject the mmap ring buffer
        self.loop = asyncio.new_event_loop()
        self.execution_thread = threading.Thread(target=self._run_event_loop, daemon=True)
        self.execution_thread.start()
        
    def _run_event_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._process_order_queue())
        
    async def _process_order_queue(self):
        self.telemetry.log_fast("[+] ORDER GATEWAY SECURED: Microstructure routing multiplexer online.")
        while True:
            payload = await self.order_queue.get()
            await self._execute_microstructure_routing(payload)
            self.order_queue.task_done()
            
    async def _execute_microstructure_routing(self, payload: dict):
        target = payload["target"]
        signal = payload["signal"]
        allocation = payload["allocation"]
        prob = payload["probability"]
        bid = payload["bid"]
        ask = payload["ask"]
        
        conviction_pct = abs(prob - 0.5) * 200.0
        
        self.telemetry.log_fast(f"[⚙️ MICROSTRUCTURE] Evaluating {signal} {target} | Conviction: {conviction_pct:.2f}%")
        
        if conviction_pct >= 95.0:
            limit_price = ask if signal == "LONG" else bid
            self.telemetry.log_fast(f"    -> [!] 95th PERCENTILE BREACHED: Crossing the spread at ${limit_price:.2f} (TAKER)")
            await self._simulate_network_fill(limit_price, allocation, 0.01)
        else:
            limit_price = bid if signal == "LONG" else ask
            self.telemetry.log_fast(f"    -> [+] Standard Signal: Pegging near-touch at ${limit_price:.2f} (MAKER)")
            await asyncio.sleep(0.500) 
            
            self.telemetry.log_fast(f"    -> [-] TIMEOUT: 500ms elapsed. Passive limit at ${limit_price:.2f} unfilled.")
            self.telemetry.log_fast(f"    -> [!] CANCEL & REPLACE: Escalating to aggressive sweep...")
            
            new_limit = ask if signal == "LONG" else bid
            await self._simulate_network_fill(new_limit, allocation, 0.05)

    async def _simulate_network_fill(self, price: float, allocation: float, delay: float):
        await asyncio.sleep(delay)
        self.telemetry.log_fast(f"    -> [$$$] PHYSICAL FILL SECURED: ${allocation:,.2f} deployed at ${price:.2f}")

    def dispatch_signal_nonblocking(self, target: str, signal: str, allocation: float, probability: float, bid: float, ask: float):
        payload = {
            "target": target,
            "signal": signal,
            "allocation": allocation,
            "probability": probability,
            "bid": bid,
            "ask": ask,
            "timestamp": time.time()
        }
        self.loop.call_soon_threadsafe(self.order_queue.put_nowait, payload)
