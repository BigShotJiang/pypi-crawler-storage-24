# gorazd/Layer_1_Ingestion/config_parser.py
from dataclasses import dataclass
from typing import List

@dataclass
class ConnectionConfig:
    bbg_host: str = "localhost"
    bbg_port: int = 8194

@dataclass
class UniverseConfig:
    target_asset: str
    macro_assets: List[str]
    mega_cap_components: List[str]
    volatility_surface: List[str]

@dataclass
class InstitutionalConfig:
    connection: ConnectionConfig
    universe: UniverseConfig

def load_institutional_config() -> InstitutionalConfig:
    return InstitutionalConfig(
        connection=ConnectionConfig(bbg_host="localhost", bbg_port=8194),
        universe=UniverseConfig(
            target_asset="SPY US Equity",
            macro_assets=["USSW10 Curncy", "LUMSTRUU Index"],
            mega_cap_components=[
                "AAPL US Equity", "MSFT US Equity", "NVDA US Equity", 
                "AMZN US Equity", "META US Equity", "GOOGL US Equity", 
                "BRK/B US Equity", "LLY US Equity", "AVGO US Equity", "TSLA US Equity"
            ],
            volatility_surface=["VIX Index", "VIX3M Index", "VIX6M Index"]
        )
    )
