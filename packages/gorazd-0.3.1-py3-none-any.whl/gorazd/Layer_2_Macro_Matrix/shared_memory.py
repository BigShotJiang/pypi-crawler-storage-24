# gorazd/Layer_2_Macro_Matrix/shared_memory.py
import sys
import time
import numpy as np
from multiprocessing import shared_memory
from pathlib import Path

# Absolute Path Resolution
sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

from gorazd.Layer_1_Ingestion.config_parser import load_institutional_config

class IPCZeroCopyMatrix:
    """
    Absolute OS-Level Memory Map Manager with Zero-Order Hold (ZOH).
    Dynamically scales to accommodate the expanded institutional universe
    (Target, Macros, Mega-Caps, Volatility Surface).
    """
    def __init__(self, create: bool = False):
        self.config = load_institutional_config()
        
        # TACTICAL COUNTERMEASURE: Expanded Dimensionality
        self.tickers = (
            [self.config.universe.target_asset] + 
            self.config.universe.macro_assets + 
            self.config.universe.mega_cap_components + 
            self.config.universe.volatility_surface
        )
        self.num_assets = len(self.tickers)
        
        self.ticker_map = {ticker: i for i, ticker in enumerate(self.tickers)}
        
        self.dtype = np.float64
        self.shape = (self.num_assets, 2)
        self.bytes_size = self.num_assets * 2 * np.dtype(self.dtype).itemsize
        self.shm_name = "gorazd_t0_matrix"
        
        try:
            if create:
                try:
                    existing = shared_memory.SharedMemory(name=self.shm_name)
                    existing.unlink()
                except FileNotFoundError:
                    pass
                self.shm = shared_memory.SharedMemory(create=True, name=self.shm_name, size=self.bytes_size)
            else:
                self.shm = shared_memory.SharedMemory(name=self.shm_name)
                
            self.tensor = np.ndarray(self.shape, dtype=self.dtype, buffer=self.shm.buf)
            
            if create:
                self.tensor[:] = np.nan
                
        except Exception as e:
            raise RuntimeError(f"[-] IPC MATRIX FATAL: Failed to map zero-copy memory space. {e}")

    def write_tick(self, ticker: str, price: float):
        idx = self.ticker_map.get(ticker)
        if idx is not None:
            self.tensor[idx, 0] = price
            self.tensor[idx, 1] = time.perf_counter_ns()

    def read_tensor(self) -> np.ndarray:
        return self.tensor[:, 0].copy()
        
    def read_zoh_state(self) -> np.ndarray:
        return self.tensor.copy()

    def unlink(self):
        self.shm.close()
        try:
            self.shm.unlink()
        except FileNotFoundError:
            pass
