import os
from gorazd.data.compiler import MarketStateCompiler
from gorazd.ml.trainer import BayesianHyperparameterManifold

def run_compiler():
    compiler = MarketStateCompiler(target_instrument="SPY")
    compiler.synthesize_orthogonal_features("2016-01-01")

def run_trainer():
    manifold = BayesianHyperparameterManifold()
    target_matrix = "SPY_institutional_matrix.parquet"
    if not os.path.exists(os.path.join(os.getcwd(), "data_vault", target_matrix)):
        print("[-] FATAL: Execute gorazd-fetch prior to initiating the training manifold.")
        return
    manifold.execute_manifold_projection(target_matrix, "institutional_core.ubj")

def run_daemon():
    print("[!] Engage 'python live_daemon.py' to ignite the multi-core IPC engine.")
