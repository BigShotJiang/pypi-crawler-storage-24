"""Gorazd Institutional Quantitative Library"""
from .config import settings
from .execution.affinity import lock_hardware_core
from .data.kernel_bypass import DPDKRingBuffer
from .data.gateway import DataGateway
from .data.storage import ParquetVault
from .data.compiler import MarketStateCompiler
from .execution.memory_pool import StaticMemoryPool
from .ml.engine import InferenceEngine
from .ml.native_infer import NativeXGBoostEngine
from .math.core import compute_institutional_features_inplace
from .execution.router import OrderBookTactician
from .execution.concurrency import SPSCRingBuffer
from .execution.binary_encoder import BOEEncoder
from .ml.physics import MicrostructureDynamics, CausalTemporalIsolator
from .ml.trainer import BayesianHyperparameterManifold
from .execution.telemetry import TelemetryPublisher

__version__ = "0.3.0"
