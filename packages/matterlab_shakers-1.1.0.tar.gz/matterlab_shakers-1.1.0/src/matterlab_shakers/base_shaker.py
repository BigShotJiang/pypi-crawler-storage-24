from abc import ABC, abstractmethod
from logging import Logger, getLogger
from typing import Dict, Optional


class Shaker(ABC):
    category="Shaker"
    ui_fields  = ("com_port")
    def __init__(self,
                 max_temp: float,
                 min_temp: float,
                 errors: Optional[Dict[str, str]] = None,
                 logger: Optional[Logger] = None) -> None:
        """
        Abstract base class for shaker
        :param max_temp: max allowable temperature
        :param min_temp: min allowable temperature
        """
        self.max_temp = max_temp
        self.min_temp = min_temp
        self.errors = errors if errors is not None else {}
        self.logger = logger if logger is not None else getLogger(
            f"{self.__class__.__module__}.{self.__class__.__name__}"
        )

    @abstractmethod
    def _query_shaker(self, command: str) -> str:
        pass

    @property
    @abstractmethod
    def temp(self) -> float:
        pass

    @temp.setter
    @abstractmethod
    def temp(self, temp: float):
        pass

    @property
    @abstractmethod
    def target_temp(self) -> float:
        pass

    @property
    @abstractmethod
    def speed(self) -> int:
        pass

    @speed.setter
    @abstractmethod
    def speed(self, speed: int):
        pass

    @property
    @abstractmethod
    def idle(self) -> bool:
        pass

    @idle.setter
    @abstractmethod
    def idle(self, idle:bool):
        pass