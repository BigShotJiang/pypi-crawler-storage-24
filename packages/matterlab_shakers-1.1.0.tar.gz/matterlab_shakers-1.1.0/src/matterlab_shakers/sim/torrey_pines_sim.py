from __future__ import annotations

from dataclasses import dataclass

from matterlab_serial_device import ScriptedSerialTransport
from matterlab_serial_device.transport import SerialTransportConfig


@dataclass
class TorreyPinesSimState:
    model: str = "TPS-10"
    serial_number: str = "12345"
    current_temp: float = 25.0
    target_temp: float = 25.0
    speed: int = 0
    idle: bool = True


class TorreyPinesSimProtocol:
    def __init__(self, state: TorreyPinesSimState) -> None:
        self.state = state

    def __call__(self, write_data: bytes, expected: bytes, size: int | None) -> bytes:
        del expected, size
        command = write_data.decode("utf-8").strip()

        if command == "v":
            return f"{self.state.model}\r\n".encode("utf-8")
        if command == "V":
            return f"{self.state.serial_number}\r\n".encode("utf-8")
        if command == "s":
            if self.state.idle:
                return b"off\r\n"
            return f"{self.state.target_temp:g}\r\n".encode("utf-8")
        if command == "p":
            return f"{self.state.current_temp:g}\r\n".encode("utf-8")
        if command == "i":
            self.state.idle = True
            self.state.speed = 0
            return b"ok\r\n"
        if command == "I":
            self.state.idle = False
            return b"ok\r\n"
        if command == "m":
            return f"{self.state.speed}\r\n".encode("utf-8")
        if command.startswith("m"):
            self.state.speed = int(command[1:])
            self.state.idle = self.state.speed == 0 and self.state.idle
            return b"ok\r\n"
        if command.startswith("n"):
            self.state.target_temp = float(command[1:])
            self.state.current_temp = self.state.target_temp
            self.state.idle = False
            return b"ok\r\n"
        return b"ok\r\n"


def create_torrey_pines_sim_transport_factory(
    *,
    model: str = "TPS-10",
    serial_number: str = "12345",
    current_temp: float = 25.0,
    target_temp: float = 25.0,
    speed: int = 0,
    idle: bool = True,
):
    state = TorreyPinesSimState(
        model=model,
        serial_number=serial_number,
        current_temp=current_temp,
        target_temp=target_temp,
        speed=speed,
        idle=idle,
    )
    protocol = TorreyPinesSimProtocol(state)

    def _factory(config: SerialTransportConfig):
        return ScriptedSerialTransport(config, default_response=protocol)

    _factory.state = state
    return _factory
