from matterlab_shakers import TorreyPinesShaker, create_torrey_pines_sim_transport_factory


def test_torrey_pines_transport_sim_uses_public_api():
    transport_factory = create_torrey_pines_sim_transport_factory(current_temp=22.5, speed=2, idle=False)
    shaker = TorreyPinesShaker(com_port="SIM::torrey", transport_factory=transport_factory)

    assert shaker.device_model == "TPS-10"
    assert shaker.serial_number == "12345"
    assert shaker.temp == 22.5
    assert shaker.speed == 2
    shaker.temp = 40
    shaker.speed = 3
    assert shaker.target_temp == 40
    assert shaker.speed == 3


def test_torrey_pines_transport_sim_idle_state_tracks_commands():
    transport_factory = create_torrey_pines_sim_transport_factory(idle=True)
    shaker = TorreyPinesShaker(com_port="SIM::torrey", transport_factory=transport_factory)

    assert shaker.idle is True
    shaker.idle = False
    assert shaker.idle is False
