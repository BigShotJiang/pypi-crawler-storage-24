import pytest

from matterlab_shakers import Shaker


class MockShaker(Shaker):
    def __init__(self):
        super().__init__(max_temp=100, min_temp=-20)
        self._temp = 25.0
        self._target_temp = 40.0
        self._speed = 3
        self._idle = False

    def _query_shaker(self, command: str) -> str:
        return command

    @property
    def temp(self) -> float:
        return self._temp

    @temp.setter
    def temp(self, temp: float):
        self._target_temp = temp

    @property
    def target_temp(self) -> float:
        return self._target_temp

    @property
    def speed(self) -> int:
        return self._speed

    @speed.setter
    def speed(self, speed: int):
        self._speed = speed

    @property
    def idle(self) -> bool:
        return self._idle

    @idle.setter
    def idle(self, idle: bool):
        self._idle = idle


def test_shaker_abstract_methods():
    with pytest.raises(TypeError):
        Shaker(max_temp=100, min_temp=-20)


def test_mock_shaker_instantiation():
    shaker = MockShaker()
    assert isinstance(shaker, Shaker)
    assert shaker.max_temp == 100
    assert shaker.min_temp == -20


def test_mock_shaker_properties():
    shaker = MockShaker()
    assert shaker.temp == 25.0
    assert shaker.target_temp == 40.0
    assert shaker.speed == 3
    assert shaker.idle is False
