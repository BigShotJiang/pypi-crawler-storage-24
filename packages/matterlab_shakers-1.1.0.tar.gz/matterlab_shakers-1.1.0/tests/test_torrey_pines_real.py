import pytest

from matterlab_shakers import TorreyPinesShaker


@pytest.mark.real
def test_torrey_pines_real_read(hardware_com_port):
    shaker = TorreyPinesShaker(com_port=hardware_com_port)

    assert isinstance(shaker.device_model, str)
    assert isinstance(shaker.serial_number, str)
    assert isinstance(shaker.temp, float)
    assert isinstance(shaker.speed, int)


@pytest.mark.real
def test_torrey_pines_real_idle_toggle(hardware_com_port):
    shaker = TorreyPinesShaker(com_port=hardware_com_port)

    shaker.idle = True
    assert shaker.idle is True
