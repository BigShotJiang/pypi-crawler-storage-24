import os
from unittest.mock import PropertyMock, patch

import pytest

from matterlab_shakers import TorreyPinesShaker


PORT = "/dev/ttyUSB0" if os.name == "posix" else "COM1"


@pytest.fixture
def shaker_fixture(mock_serial):
    return TorreyPinesShaker(com_port=PORT, connect_hardware=False)


def test_initialization_defaults(mock_serial, shaker_fixture):
    assert isinstance(shaker_fixture, TorreyPinesShaker)
    assert shaker_fixture.max_temp == 110
    assert shaker_fixture.min_temp == -20
    assert shaker_fixture.device._connection is mock_serial


def test_default_initialization_sequence(mock_serial):
    with patch.object(TorreyPinesShaker, "connect", autospec=True) as connect_spy:
        shaker = TorreyPinesShaker(com_port=PORT)

    connect_spy.assert_called_once_with(shaker)


def test_query_shaker(shaker_fixture, mocker):
    query_spy = mocker.patch.object(shaker_fixture, "query", return_value="ok\r\n")

    assert shaker_fixture._query_shaker("v") == "ok\r\n"
    query_spy.assert_called_once_with(write_command="v\r\n", remove_from_end=2, read_delay=0.5)


def test_connect_reads_model_and_serial(shaker_fixture, mocker):
    model_spy = mocker.patch.object(type(shaker_fixture), "device_model", new_callable=PropertyMock, return_value="TPS-10")
    serial_spy = mocker.patch.object(type(shaker_fixture), "serial_number", new_callable=PropertyMock, return_value="12345")

    shaker_fixture.connect()

    model_spy.assert_called_once_with()
    serial_spy.assert_called_once_with()


def test_connect_raises_for_missing_identification(shaker_fixture, mocker):
    mocker.patch.object(type(shaker_fixture), "device_model", new_callable=PropertyMock, return_value="")
    mocker.patch.object(type(shaker_fixture), "serial_number", new_callable=PropertyMock, return_value="")

    with pytest.raises(ConnectionError, match="Query shaker failed, check connection."):
        shaker_fixture.connect()


def test_device_identity_properties(shaker_fixture, mocker):
    query_spy = mocker.patch.object(shaker_fixture, "_query_shaker", side_effect=["TPS-10", "12345"])

    assert shaker_fixture.device_model == "TPS-10"
    assert shaker_fixture.serial_number == "12345"
    assert query_spy.call_args_list == [mocker.call(command="v"), mocker.call(command="V")]


def test_target_temp_returns_none_when_idle(shaker_fixture, mocker):
    mocker.patch.object(shaker_fixture, "_query_shaker", return_value="off")
    idle_spy = mocker.patch.object(type(shaker_fixture), "idle", new_callable=PropertyMock, return_value=True)

    assert shaker_fixture.target_temp is None
    idle_spy.assert_called_once_with()


def test_target_temp_returns_float_when_active(shaker_fixture, mocker):
    mocker.patch.object(shaker_fixture, "_query_shaker", return_value="37.5")
    idle_spy = mocker.patch.object(type(shaker_fixture), "idle", new_callable=PropertyMock, return_value=False)

    assert shaker_fixture.target_temp == 37.5
    idle_spy.assert_called_once_with()


def test_temp_getter_and_error_reporting(shaker_fixture, mocker):
    query_spy = mocker.patch.object(shaker_fixture, "_query_shaker", return_value="25.5")

    assert shaker_fixture.temp == 25.5
    query_spy.assert_called_once_with(command="p")


def test_temp_getter_raises_for_device_error(shaker_fixture, mocker):
    mocker.patch.object(shaker_fixture, "_query_shaker", return_value="RTDo")

    with pytest.raises(ValueError, match="The RTD Sensor is not connected or has failed"):
        _ = shaker_fixture.temp


def test_temp_setter_validates_range(shaker_fixture):
    with pytest.raises(ValueError, match="Temp setting out of range"):
        shaker_fixture.temp = 200


def test_temp_setter_sets_target(shaker_fixture, mocker):
    idle_spy = mocker.patch.object(type(shaker_fixture), "idle", new_callable=PropertyMock)
    query_spy = mocker.patch.object(shaker_fixture, "_query_shaker", return_value="ok")

    shaker_fixture.temp = 40

    idle_spy.assert_called_once_with(False)
    query_spy.assert_called_once_with("n40")


def test_idle_property_and_setter(shaker_fixture, mocker):
    query_spy = mocker.patch.object(shaker_fixture, "_query_shaker", side_effect=["off", "ok", "ok"])

    assert shaker_fixture.idle is True
    shaker_fixture.idle = True
    shaker_fixture.idle = False

    assert query_spy.call_args_list == [mocker.call("s"), mocker.call(command="i"), mocker.call(command="I")]


def test_speed_property_and_setter(shaker_fixture, mocker):
    query_spy = mocker.patch.object(shaker_fixture, "_query_shaker", side_effect=["4", "ok"])

    assert shaker_fixture.speed == 4
    shaker_fixture.speed = 3

    assert query_spy.call_args_list == [mocker.call(command="m"), mocker.call(command="m3")]


def test_speed_setter_validates_range(shaker_fixture):
    with pytest.raises(ValueError, match="Orbital speed setting must be 0-9 level"):
        shaker_fixture.speed = 10


def test_error_reporting_raises_value_error(shaker_fixture):
    with pytest.raises(ValueError, match="Communication Error, receive empty feedback"):
        shaker_fixture.error_reporting("")
