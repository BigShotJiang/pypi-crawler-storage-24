#  Copyright (c) 2024-2026, RTE (https://www.rte-france.com)
#  See AUTHORS.txt
#  SPDX-License-Identifier: MPL-2.0
#  This file is part of BERTrend.

"""
BERTrend Worker - Processes requests from RabbitMQ queue_management.

This worker receives HTTP-like requests from the queue_management and processes them
by calling the appropriate core logic functions.
"""

import asyncio
import json
import traceback
from typing import Any

import aio_pika
import pandas as pd
from loguru import logger

from bertrend import load_toml_config
from bertrend.bertrend_apps.data_provider.data_provider_utils import (
    auto_scrape,
    generate_query_file,
    scrape,
    scrape_feed_from_config,
)
from bertrend.bertrend_apps.newsletters.newsletter_generation import (
    NEWSLETTER_SECTION,
    process_newsletter,
)
from bertrend.bertrend_apps.prospective_demo.automated_report_generation import (
    generate_automated_report,
)
from bertrend.bertrend_apps.prospective_demo.process_new_data import (
    regenerate_models,
    train_new_model,
)
from bertrend.bertrend_apps.services.bertrend.models.bertrend_app_models import (
    GenerateReportRequest,
    RegenerateRequest,
    TrainNewModelRequest,
)
from bertrend.bertrend_apps.services.bertrend.models.data_provider_models import (
    AutoScrapeRequest,
    GenerateQueryFileRequest,
    ScrapeFeedRequest,
    ScrapeRequest,
)
from bertrend.bertrend_apps.services.bertrend.models.newsletters_models import (
    NewsletterRequest,
)
from bertrend.bertrend_apps.services.queue_management.queue_manager import QueueManager
from bertrend.bertrend_apps.services.queue_management.rabbitmq_config import (
    RabbitMQConfig,
)
from bertrend.bertrend_apps.services.utils.logging_utils import get_file_logger


# Wrapper functions to match the core logic with the request models
async def handle_scrape(req: ScrapeRequest):
    return await asyncio.to_thread(
        scrape,
        keywords=req.keywords,
        provider=req.provider,
        after=req.after,
        before=req.before,
        max_results=req.max_results,
        save_path=req.save_path,
        language=req.language,
    )


async def handle_auto_scrape(req: AutoScrapeRequest):
    return await asyncio.to_thread(
        auto_scrape,
        requests_file=req.requests_file,
        max_results=req.max_results,
        provider=req.provider,
        save_path=req.save_path,
        language=req.language,
        evaluate_articles_quality=req.evaluate_articles_quality,
        minimum_quality_level=req.minimum_quality_level,
    )


async def handle_scrape_feed(req: ScrapeFeedRequest):
    # Create a unique log file for this call
    user = "" if not req.user else req.user
    model_id = "" if not req.model_id else req.model_id
    logger_id = get_file_logger(id="scrape_feed", user_name=user, model_id=model_id)
    result = await asyncio.to_thread(scrape_feed_from_config, req.feed_cfg)
    # Remove the logger to prevent writing to this file for other calls
    logger.remove(logger_id)
    return result


async def handle_generate_query_file(req: GenerateQueryFileRequest):
    return await asyncio.to_thread(
        generate_query_file,
        keywords=req.keywords,
        after=req.after,
        before=req.before,
        interval=req.interval,
        save_path=req.save_path,
    )


async def handle_train_new(req: TrainNewModelRequest):
    # Create a unique log file for this call
    logger_id = get_file_logger(
        id="train_new_model", user_name=req.user, model_id=req.model_id
    )
    result = await asyncio.to_thread(
        train_new_model, model_id=req.model_id, user_name=req.user
    )
    # Remove the logger to prevent writing to this file for other calls
    logger.remove(logger_id)
    return result


async def handle_regenerate(req: RegenerateRequest):
    # Create a unique log file for this call
    logger_id = get_file_logger(
        id="regenerate", user_name=req.user, model_id=req.model_id
    )
    result = await asyncio.to_thread(
        regenerate_models,
        model_id=req.model_id,
        user=req.user,
        with_analysis=req.with_analysis,
        since=pd.Timestamp(req.since) if req.since else None,
    )
    # Remove the logger to prevent writing to this file for other calls
    logger.remove(logger_id)
    return result


async def handle_generate_report(req: GenerateReportRequest):
    # Create a unique log file for this call
    logger_id = get_file_logger(
        id="generate_report", user_name=req.user, model_id=req.model_id
    )
    result = await asyncio.to_thread(
        generate_automated_report,
        user=req.user,
        model_id=req.model_id,
        reference_date=req.reference_date,
    )
    # Remove the logger to prevent writing to this file for other calls
    logger.remove(logger_id)
    return result


async def handle_generate_newsletters(req: NewsletterRequest):
    config = load_toml_config(req.newsletter_toml_path)
    model_id = config.get(NEWSLETTER_SECTION).get("id")
    # Create a unique log file for this call
    logger_id = get_file_logger(
        id="generate_newsletters", user_name="", model_id=model_id
    )
    result = await asyncio.to_thread(
        process_newsletter, req.newsletter_toml_path, req.data_feed_toml_path
    )
    # Remove the logger to prevent writing to this file for other calls
    logger.remove(logger_id)
    return result


# Mapping of endpoints to their handler functions and request models
ENDPOINT_HANDLERS = {
    "/scrape": (handle_scrape, ScrapeRequest),
    "/auto-scrape": (handle_auto_scrape, AutoScrapeRequest),
    "/scrape-feed": (handle_scrape_feed, ScrapeFeedRequest),
    "/generate-query-file": (handle_generate_query_file, GenerateQueryFileRequest),
    "/train-new-model": (handle_train_new, TrainNewModelRequest),
    "/regenerate": (handle_regenerate, RegenerateRequest),
    "/generate-report": (handle_generate_report, GenerateReportRequest),
    "/generate-newsletters": (handle_generate_newsletters, NewsletterRequest),
}


class BertrendWorker:
    """Worker that processes requests from RabbitMQ"""

    def __init__(self, config: RabbitMQConfig):
        self.config = config
        self.queue_manager = QueueManager(config)

    async def process_request(self, request_data: dict[str, Any]) -> dict[str, Any]:
        """
        Process a request by calling the appropriate core logic function.

        Args:
            request_data: Dictionary containing:
                - endpoint: The API endpoint path (e.g., "/scrape-feed", "/train-new-model")
                - method: HTTP method (POST, GET, etc.) - currently only POST is supported
                - json_data: The request body data

        Returns:
            Dictionary containing the response or error information
        """
        try:
            endpoint = request_data.get("endpoint")
            method = request_data.get("method", "POST").upper()
            json_data = request_data.get("json_data", {})

            logger.info(f"Processing request: {method} {endpoint}")
            logger.debug(f"Request data: {json_data}")

            if endpoint not in ENDPOINT_HANDLERS:
                return {
                    "status": "error",
                    "error": f"Unknown endpoint: {endpoint}",
                    "available_endpoints": list(ENDPOINT_HANDLERS.keys()),
                }

            handler_func, request_model = ENDPOINT_HANDLERS[endpoint]

            # Create the request model from json_data
            try:
                request_obj = request_model(**json_data)
            except Exception as e:
                return {
                    "status": "error",
                    "error": f"Invalid request data for {endpoint}: {str(e)}",
                }

            # Call the async handler function
            response = await handler_func(request_obj)

            # Convert response to dict if it's a Pydantic model
            if hasattr(response, "model_dump"):
                response_dict = response.model_dump(mode="json")
            elif hasattr(response, "dict"):
                response_dict = response.dict()
            else:
                response_dict = response

            return {
                "status": "success",
                "endpoint": endpoint,
                "response": response_dict,
            }

        except Exception as e:
            logger.error(f"Error processing request: {str(e)}")
            logger.error(traceback.format_exc())
            return {
                "status": "error",
                "error": str(e),
                "traceback": traceback.format_exc(),
            }

    async def callback(
        self,
        message: aio_pika.abc.AbstractIncomingMessage,
    ):
        """Callback function for processing messages from the queue_management"""
        correlation_id = message.correlation_id

        try:
            logger.info(f"Received request: {correlation_id}")

            # Parse request
            request_data = json.loads(message.body.decode("utf-8"))

            logger.info(f"Request endpoint: {request_data.get('endpoint')}")

            # Process request
            response_data = await self.process_request(request_data)

            # Add metadata
            response_data["correlation_id"] = correlation_id
            response_data["request_data"] = request_data

            # Publish response/error if reply_to is specified
            if message.reply_to:
                if response_data.get("status") == "error":
                    await self.queue_manager.publish_error(
                        error_data=response_data, correlation_id=correlation_id
                    )
                else:
                    await self.queue_manager.publish_response(
                        response_data=response_data, correlation_id=correlation_id
                    )

            # Acknowledge message
            await message.ack()
            logger.info(
                f"Completed request: {correlation_id} - Status: {response_data.get('status')}"
            )

        except json.JSONDecodeError as e:
            logger.error(f"Invalid message format: {str(e)}")
            # Reject and don't requeue invalid messages
            await message.reject(requeue=False)

        except Exception as e:
            logger.error(f"Error processing message: {str(e)}")
            logger.error(traceback.format_exc())

            # Requeue for retry (will go to DLQ after max retries)
            await message.nack(requeue=True)

    async def start(self):
        """Start the worker"""
        logger.info("Starting BERTrend worker...")
        logger.info(f"Available endpoints: {list(ENDPOINT_HANDLERS.keys())}")

        try:
            await self.queue_manager.connect()
            await self.queue_manager.consume_requests(
                callback=self.callback, prefetch_count=self.config.prefetch_count
            )

            # Wait until termination
            await asyncio.Future()

        except asyncio.CancelledError:
            logger.info("Worker interrupted")
        except Exception as e:
            logger.error(f"Worker error: {str(e)}")
            logger.error(traceback.format_exc())
        finally:
            await self.queue_manager.close()


def main():
    """Main entry point"""
    config = RabbitMQConfig()
    worker = BertrendWorker(config)
    try:
        asyncio.run(worker.start())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
