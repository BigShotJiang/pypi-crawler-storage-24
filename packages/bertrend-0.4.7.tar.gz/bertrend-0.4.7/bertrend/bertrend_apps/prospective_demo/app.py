#  Copyright (c) 2024-2026, RTE (https://www.rte-france.com)
#  See AUTHORS.txt
#  SPDX-License-Identifier: MPL-2.0
#  This file is part of BERTrend.
from importlib.metadata import version

import torch

# workaround with streamlit to avoid errors Examining the path of torch.classes raised: Tried to instantiate class 'path.path’, but it does not exist! Ensure that it is registered via torch::class
torch.classes.__path__ = []
from typing import Literal

import streamlit as st

from bertrend.bertrend_apps.prospective_demo.authentication import check_password
from bertrend.bertrend_apps.prospective_demo.dashboard_analysis import (
    dashboard_analysis,
)
from bertrend.bertrend_apps.prospective_demo.dashboard_comparative import (
    dashboard_comparative,
)
from bertrend.bertrend_apps.prospective_demo.dashboard_signals import signal_analysis
from bertrend.bertrend_apps.prospective_demo.feeds_config import (
    configure_information_sources,
)
from bertrend.bertrend_apps.prospective_demo.feeds_data import display_data_status
from bertrend.bertrend_apps.prospective_demo.i18n import translate
from bertrend.bertrend_apps.prospective_demo.models_info import models_monitoring
from bertrend.bertrend_apps.prospective_demo.report_generation import reporting
from bertrend.demos.demos_utils import is_admin_mode
from bertrend.demos.demos_utils.i18n import (
    create_internationalization_language_selector,
    set_internationalization_language,
)
from bertrend.demos.demos_utils.icons import (
    ANALYSIS_ICON,
    MODELS_ICON,
    NEWSLETTER_ICON,
    SERVER_STORAGE_ICON,
    SETTINGS_ICON,
    TIMELINE_ICON,
    TREND_ICON,
)
from bertrend.demos.demos_utils.state_utils import SessionStateManager

# UI Settings
LAYOUT: Literal["centered", "wide"] = "wide"

AUTHENTIFICATION = True
# AUTHENTIFICATION = False


def display_version_number():
    # Display version at the bottom (using st.markdown and CSS for fixed footer)
    footer = f"""
    <style>
    .footer {{
        position: fixed;
        right: 10px;
        bottom: 10px;
        color: #666;
        font-size: 0.8em;
        opacity: 0.6;
        user-select: none;
        pointer-events: none;
        background: none;
    }}
    </style>
    <div class="footer">
        Version: {version("bertrend")}
    </div>
    """
    st.markdown(footer, unsafe_allow_html=True)


def display_current_user(username: str):
    """Display the current user name in a discrete but nice way with logout button"""
    user_display = f"""
    <style>
    .user-display {{
        position: fixed;
        right: 10px;
        top: 60px;
        color: #333;
        font-size: 0.9em;
        opacity: 0.8;
        padding: 6px 12px;
        border-radius: 15px;
        background-color: rgba(240, 242, 246, 0.9);
        user-select: none;
        z-index: 999999;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }}
    </style>
    <div class="user-display">
        <span>👤 {username}</span>
    </div>
    """
    st.markdown(user_display, unsafe_allow_html=True)


def main():
    """Main page"""
    set_internationalization_language("fr")
    page_title = translate("app_title")
    st.set_page_config(
        page_title=page_title,
        layout=LAYOUT,
        initial_sidebar_state="expanded" if is_admin_mode() else "collapsed",
        page_icon=":part_alternation_mark:",
    )

    display_version_number()

    st.title(":part_alternation_mark: " + page_title)

    if AUTHENTIFICATION:
        username = check_password()
        if not username:
            st.stop()
        else:
            SessionStateManager.set("username", username)
            display_current_user(username)
    else:
        SessionStateManager.get_or_set(
            "username", "nemo"
        )  # if username is not set or authentication deactivated

    # Sidebar
    with st.sidebar:
        st.header(SETTINGS_ICON + " " + translate("settings_and_controls"))
        create_internationalization_language_selector()

    # Main content
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
        [
            NEWSLETTER_ICON + " " + translate("tab_monitoring"),
            MODELS_ICON + " " + translate("tab_models"),
            TREND_ICON + " " + translate("tab_trends"),
            ANALYSIS_ICON + " " + translate("tab_analysis"),
            NEWSLETTER_ICON + " " + translate("tab_reports"),
            TIMELINE_ICON + " " + translate("tab_comparative"),
        ]
    )

    with tab1:
        with st.expander(
            translate("data_flow_config"), expanded=True, icon=SETTINGS_ICON
        ):
            configure_information_sources()

        with st.expander(
            translate("data_collection_status"),
            expanded=False,
            icon=SERVER_STORAGE_ICON,
        ):
            display_data_status()
    with tab2:
        with st.expander(
            translate("model_status_by_monitoring"), expanded=True, icon=MODELS_ICON
        ):
            models_monitoring()

    with tab3:
        signal_analysis()

    with tab4:
        dashboard_analysis()

    with tab5:
        reporting()

    with tab6:
        dashboard_comparative()


if __name__ == "__main__":
    main()
