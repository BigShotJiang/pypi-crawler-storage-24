                #    (try 200–300 if your graph feels crowded)



import pandas as pd
import re
from collections import defaultdict, deque

# ========================= CONFIG =========================
file_path = "/mnt/data/Development/tricc-mage/output/adult.xlsx"
sheet_name = "survey"

# Which columns can contain ${references}?
XPATH_COLUMNS = ['relevant', 'calculation', 'constraint', 'choice_filter', 'required', 'readonly']

core_names = [
"ask_bHgPijDnZ9jQDsDKJTWA_0_Vv_2",
"/ask_bHgPijDnZ9jQDsDKJTWA_0_Vv_4",
"label_bHgPijDnZ9jQDsDKJTWA_3_Vv_2",
"ask_bHgPijDnZ9jQDsDKJTWA_0_Vv_3",
"cond_sickel_cell_suspected_Vv_2",

]
# =========================================================

df = pd.read_excel(file_path, sheet_name=sheet_name)

def extract_refs(text):
    if pd.isna(text) or not isinstance(text, str):
        return []
    return re.findall(r'\$\{([^\}]+)\}', text)

# === BUILD FULL GRAPH (every field in the form) ===
all_nodes = set(df['name'].dropna())
graph = defaultdict(list)          # source → [targets]

for _, row in df.iterrows():
    if pd.isna(row.get('name')):
        continue
    target = row['name']
    
    for col in XPATH_COLUMNS:
        if col in df.columns and pd.notna(row.get(col)):
            for source in extract_refs(row[col]):
                if source in all_nodes and source != target:
                    graph[source].append(target)   # edge: source → target

print(f"✅ Full graph built: {len(all_nodes)} nodes, {sum(len(v) for v in graph.values())} edges")

# === CYCLE DETECTION (reliable DFS) ===
def find_cycles():
    visited = {}
    rec_stack = {}
    cycles = []

    def dfs(node, path):
        visited[node] = True
        rec_stack[node] = True
        path.append(node)

        for neighbor in graph[node]:
            if not visited.get(neighbor, False):
                if dfs(neighbor, path[:]):
                    return True
            elif rec_stack.get(neighbor, False):
                # Cycle found
                idx = path.index(neighbor)
                cycle = path[idx:] + [neighbor]
                if cycle not in cycles:
                    cycles.append(cycle)
                return True

        rec_stack[node] = False
        return False

    for node in all_nodes:
        if not visited.get(node, False):
            dfs(node, [])

    return cycles

cycles = find_cycles()

if cycles:
    print(f"\n🔴 REAL CYCLES FOUND ({len(cycles)}):")
    for i, c in enumerate(cycles, 1):
        print(f"   {i}. {' → '.join(c)}")
else:
    print("\n✅ NO CYCLES DETECTED in the entire form (Python says clean)")

# === MERMAID (still with your spacing + styles) ===
mermaid_lines = [
    "%%{init: {'flowchart': {'nodeSpacing': 180, 'rankSpacing': 220}}}%%",
    "flowchart TD"
]

label_col = next((c for c in df.columns if str(c).lower().startswith('label')), None)
core_set = set(core_names)

for name in sorted(all_nodes):
    row = df[df['name'] == name].iloc[0] if len(df[df['name'] == name]) > 0 else None
    raw_label = row.get(label_col, '') if row is not None and label_col else ''
    display = str(raw_label).strip()[:120] if pd.notna(raw_label) and str(raw_label).strip() else name
    display = display.replace('"', '\\"').replace('\n', ' ')
    node_text = f"{name}\\n{display}" if display != name else name
    style = ":::core" if name in core_set else ":::dep"
    mermaid_lines.append(f'    {name}["{node_text}"]{style}')

# Add edges (deduplicated)
seen = set()
for source in graph:
    for target in graph[source]:
        for typ in ['r', 'c']:   # we don't know the type anymore, but you can still see the link
            key = (source, target)
            if key not in seen:
                seen.add(key)
                mermaid_lines.append(f'    {source} --> {target}')

mermaid_lines.append('')
mermaid_lines.append('classDef core fill:#ffeb3b,stroke:#d32f2f,stroke-width:4px,color:#000,font-weight:bold;')
mermaid_lines.append('classDef dep  fill:#bbdefb,stroke:#1976d2,stroke-width:2px,color:#333;')

mermaid_code = '\n'.join(mermaid_lines)

# Save both
with open("/mnt/data/Development/tricc-mage/output/full_dependency_graph.mmd", "w", encoding="utf-8") as f:
    f.write(mermaid_code)
with open("/mnt/data/Development/tricc-mage/output/cycle_report.txt", "w", encoding="utf-8") as f:
    f.write("Cycle report\n")
    if cycles:
        f.write(f"REAL CYCLES FOUND: {len(cycles)}\n")
        for i, c in enumerate(cycles, 1):
            f.write(f"{i}. {' → '.join(c)}\n")
    else:
        f.write("NO CYCLES DETECTED\n")

print(f"\n✅ Files saved:")
print("   • full_dependency_graph.mmd     → paste into mermaid.live")
print("   • cycle_report.txt             → shows exactly what Python found")