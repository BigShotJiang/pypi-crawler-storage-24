
from importlib.metadata import version, PackageNotFoundError

from .config import CiferConfig
from .client import CiferClient
from .server import CiferServer

__all__ = [
    "CiferClient",
    "CiferServer",
    "CiferConfig",
    "run_federated_server",
    "train_custom_model",
]

# -------------------------------------------------
# Lazy / Optional imports (do not break import cifer)
# -------------------------------------------------
def run_federated_server(*args, **kwargs):
    try:
        from .connection_handler import run_federated_server as _run
    except ImportError as e:
        raise ImportError(
            "Federated server requires extra dependencies. "
            "Please install with: pip install cifer[server]"
        ) from e
    return _run(*args, **kwargs)


def train_custom_model(*args, **kwargs):
    try:
        from .training import train_custom_model as _train
    except ImportError as e:
        raise ImportError(
            "Training utilities require additional dependencies."
        ) from e
    return _train(*args, **kwargs)


# -------------------------------------------------
# Version
# -------------------------------------------------
try:
    __version__ = version("cifer")
except PackageNotFoundError:
    __version__ = "1.0.35"  # Fallback version if package metadata is not found


