# cifer/rate_limiter.py

import time
from collections import defaultdict

class RateLimiter:
    def __init__(self, max_events, window_seconds):
        self.max_events = max_events
        self.window = window_seconds
        self.events = defaultdict(list)

    def allow(self, key):
        now = time.time()
        window_start = now - self.window

        # keep only events in window
        self.events[key] = [
            t for t in self.events[key] if t > window_start
        ]

        if len(self.events[key]) >= self.max_events:
            return False

        self.events[key].append(now)
        return True