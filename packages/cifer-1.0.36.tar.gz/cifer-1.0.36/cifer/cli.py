import os
import sys
import subprocess
import requests
import typer
import yaml
from rich import print

app = typer.Typer(help="🚀 Cifer CLI", rich_markup_mode="rich")

securetrain_app = typer.Typer(help="🔐 Secure training commands")
dataset_app = typer.Typer(help="📦 Dataset commands")

app.add_typer(securetrain_app, name="securetrain")
app.add_typer(dataset_app, name="dataset")


# ================= CONFIG =================
def load_config():
    config_path = os.path.expanduser("~/.cifer/config.yaml")

    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                return yaml.safe_load(f) or {}
        except Exception:
            print("[red]❌ Failed to read config[/red]")
            return {}

    return {}


# ================= VERSION =================
@app.command()
def version():
    """Show Cifer version"""
    try:
        from importlib.metadata import version
        print(f"[green]Cifer version:[/green] {version('cifer')}")
    except Exception:
        print("[yellow]⚠️ Cifer not installed via pip[/yellow]")


# ================= PROJECT INIT =================
@app.command("init")
def init_project(name: str):
    """Create new Cifer project"""

    try:
        os.makedirs(name, exist_ok=True)
        os.makedirs(f"{name}/dataset", exist_ok=True)
        os.makedirs(f"{name}/models", exist_ok=True)

        config = {
            "project": name,
            "server": "ws://localhost:8080"
        }

        os.makedirs(os.path.expanduser("~/.cifer"), exist_ok=True)

        with open(f"{name}/config.yaml", "w") as f:
            yaml.dump(config, f)

        print(f"[green]✅ Project '{name}' created[/green]")

    except Exception as e:
        print(f"[red]❌ Error creating project: {e}[/red]")


# ================= SERVER =================
@app.command("server")
def run_server(
    host: str = typer.Option("0.0.0.0"),
    port: int = typer.Option(8080),
):
    """Run Cifer Federated Server"""

    print(f"[cyan]🚀 Starting server at {host}:{port}[/cyan]")

    try:
        from cifer.server import CiferServer

        server = CiferServer(host=host, port=port)
        server.start()

    except Exception as e:
        print(f"[red]❌ Server error: {e}[/red]")


# ================= CLIENT =================
@app.command("client")
def run_client(
    dataset: str = typer.Option(...),
):
    """Run federated client"""

    if not os.path.exists(dataset):
        print("[red]❌ Dataset not found[/red]")
        raise typer.Exit()

    config = load_config()
    server = config.get("server", "ws://localhost:8080")

    print(f"[cyan]🔗 Connecting to {server}[/cyan]")

    try:
        from cifer.client import CiferClient

        client = CiferClient(server_address=server)
        client.train(dataset)

    except Exception as e:
        print(f"[red]❌ Client error: {e}[/red]")


# ================= DATASET =================
@dataset_app.command("download")
def download_dataset(name: str):
    """Download dataset from HuggingFace"""

    print(f"[cyan]📦 Downloading dataset: {name}[/cyan]")

    try:
        from datasets import load_dataset

        dataset = load_dataset(name)

        output_dir = f"./dataset/{name}"
        os.makedirs("./dataset", exist_ok=True)

        dataset.save_to_disk(output_dir)

        print(f"[green]✅ Saved to {output_dir}[/green]")

    except Exception as e:
        print(f"[red]❌ Download failed: {e}[/red]")


# ================= STATUS =================
@app.command("status")
def status(server: str = typer.Option("http://localhost:8080")):
    """Check server status"""

    try:
        r = requests.get(f"{server}/metrics", timeout=3)

        if r.status_code == 200:
            print("[green]✅ Server OK[/green]")
            print(r.json())
        else:
            print(f"[yellow]⚠️ Status code: {r.status_code}[/yellow]")

    except Exception:
        print("[red]❌ Server not reachable[/red]")


# ================= Securetrain =================
@securetrain_app.command("encrypt-dataset")
def securetrain_encrypt(
    dataset: str = typer.Option(...),
    output: str = typer.Option(...),
):
    """Encrypt dataset"""

    if not os.path.exists(dataset):
        print("[red]❌ Dataset not found[/red]")
        raise typer.Exit()

    try:
        from cifer.securetrain import encrypt_dataset
        encrypt_dataset(dataset, output)
        print("[green]✅ Dataset encrypted[/green]")

    except Exception as e:
        print(f"[red]❌ Error: {e}[/red]")


@securetrain_app.command("train")
def securetrain_train(
    encrypted_data: str = typer.Option(...),
    output_model: str = typer.Option(...),
):
    """Train model"""

    try:
        from cifer.securetrain import train_model
        train_model(encrypted_data, output_model)
        print("[green]✅ Model trained[/green]")

    except Exception as e:
        print(f"[red]❌ Error: {e}[/red]")


@securetrain_app.command("decrypt-model")
def securetrain_decrypt(
    input_model: str = typer.Option(...),
    output_model: str = typer.Option(...),
):
    """Decrypt trained model"""

    try:
        from cifer.securetrain import decrypt_model
        decrypt_model(input_model, output_model)
        print("[green]✅ Model decrypted[/green]")

    except Exception as e:
        print(f"[red]❌ Error: {e}[/red]")


# ================= JUPYTER =================
@app.command("register-kernel")
def register_kernel():
    """Register Jupyter Kernel"""

    print("[cyan]📓 Registering kernel...[/cyan]")

    try:
        subprocess.run(
            [
                sys.executable,
                "-m",
                "ipykernel",
                "install",
                "--user",
                "--name",
                "cifer-kernel",
                "--display-name",
                "Cifer Kernel",
            ],
            check=True,
        )

        print("[green]✅ Kernel registered[/green]")

    except Exception as e:
        print(f"[red]❌ Error: {e}[/red]")


# ================= AGENT =================
@app.command("agent-ace")
def agent_ace(port: int = typer.Option(9999)):
    """Launch ACE agent"""

    print(f"[cyan]🤖 Starting ACE agent on {port}[/cyan]")

    try:
        from cifer.agent_ace import run_agent_ace
        run_agent_ace(port=port)

    except Exception as e:
        print(f"[red]❌ Error: {e}[/red]")


# ================= NOTEBOOK =================
@app.command("download-notebook")
def download_notebook(url: str):
    """Download notebook"""

    filename = url.split("/")[-1]

    print(f"[cyan]⬇️ Downloading {filename}[/cyan]")

    try:
        response = requests.get(url, stream=True, timeout=10)

        if response.status_code == 200:
            with open(filename, "wb") as f:
                for chunk in response.iter_content(8192):
                    f.write(chunk)

            print(f"[green]✅ Downloaded {filename}[/green]")
        else:
            print("[red]❌ Download failed[/red]")

    except Exception as e:
        print(f"[red]❌ Error: {e}[/red]")


# ================= SIM =================
@app.command("train")
def simulate_training(
    epochs: int = typer.Option(5),
    lr: float = typer.Option(0.001),
):
    """Simulate training"""

    print(f"[cyan]⚙️ Training {epochs} epochs | lr={lr}[/cyan]")

    for i in range(1, epochs + 1):
        print(f"[yellow]Epoch {i}/{epochs}[/yellow]")

    print("[green]✅ Done[/green]")


# ================= ENTRY =================
def main():
    app()


if __name__ == "__main__":
    main()