from setuptools import setup, find_packages
import os
from setuptools.command.install import install


class PostInstallCommand(install):
    """Post-installation for kernel registration"""
    def run(self):
        install.run(self)
        try:
            from cifer.post_install import register_kernel
            register_kernel.register_kernel()
        except Exception as e:
            print(f"⚠️ Failed to auto register kernel: {e}")


def read_file(filename):
    if os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            return f.read()
    return "Description not available."


def read_requirements(filename="requirements.txt"):
    if os.path.exists(filename):
        with open(filename, "r") as f:
            return [
                line.strip()
                for line in f
                if line.strip() and not line.startswith("#")
            ]
    return []


setup(
    name="cifer",
    version="1.0.36",
    author="Cifer.ai",
    author_email="support@cifer.ai",
    description="Federated Learning and Fully Homomorphic Encryption",
    long_description=read_file("README.md") + "\n\n" + read_file("CHANGELOG.md"),
    long_description_content_type="text/markdown",
    url="https://github.com/cifer-ai/cifer",
    packages=find_packages(),

    install_requires=read_requirements(),

    extras_require={
        "vision": ["opencv-python"],
        "audio": ["librosa", "torchaudio"],
        "nlp": ["transformers"],
        "graph": ["dgl", "torch-geometric"],
        "geo": ["geopandas"],
        "3d": ["open3d"],
        "medical": ["pydicom"],
        "all": [
            "opencv-python",
            "librosa",
            "torchaudio",
            "transformers",
            "dgl",
            "torch-geometric",
            "geopandas",
            "open3d",
            "pydicom",
        ],
    },

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Development Status :: 5 - Production/Stable",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Security :: Cryptography",
        "Framework :: Flask",
        "Framework :: FastAPI",
        "Environment :: Console",
        "Topic :: System :: Distributed Computing",
    ],

    entry_points={
        "console_scripts": [
            "cifer = cifer.cli:main",
        ],
    },

    python_requires=">=3.9",

    cmdclass={
        "install": PostInstallCommand,
    },
)