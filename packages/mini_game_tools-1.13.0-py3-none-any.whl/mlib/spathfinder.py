# spath.py - 广度优先搜索寻路
from .svector import vec2
from .srandom import SimpleRNG

def bfs(grid, start, end):
    """
    广度优先搜索寻路 - 保证最短路径
    
    参数:
        grid: 二维列表，0=可走，1=障碍
        start: (x, y) 或 vec2
        end: (x, y) 或 vec2
    
    返回:
        路径列表 [(x1,y1), (x2,y2), ...] 或 None
    """
    # 转成元组好处理
    start = (int(start[0]), int(start[1]))
    end = (int(end[0]), int(end[1]))
    
    # 检查起点终点
    if not _is_passable(grid, start) or not _is_passable(grid, end):
        return None
    
    # 手动实现队列：列表 + 头尾指针
    queue = [start]          # 队列
    queue_head = 0           # 队头指针
    
    # 记录路径
    came_from = {start: None}
    
    # BFS主循环
    while queue_head < len(queue):
        current = queue[queue_head]
        queue_head += 1
        
        # 到达终点
        if current == end:
            return _reconstruct_path(came_from, start, end)
        
        x, y = current
        # 4方向探索
        for dx, dy in [(0,1), (1,0), (0,-1), (-1,0)]:
            nx, ny = x + dx, y + dy
            neighbor = (nx, ny)
            
            # 如果可走且没访问过
            if _is_passable(grid, neighbor) and neighbor not in came_from:
                came_from[neighbor] = current
                queue.append(neighbor)
    
    return None  # 没找到路径

def dfs_maker(width, height, seed, start=(1,1)):
    """
    深度优先搜索生成迷宫
    
    参数:
        width, height: 迷宫尺寸（必须是奇数）
        start: 起点坐标
    
    返回:
        二维列表，0=路，1=墙
    """
    # 确保尺寸为奇数（保证墙壁厚度）
    random = SimpleRNG(seed)
    if width % 2 == 0:
        width += 1
    if height % 2 == 0:
        height += 1
    
    # 初始化全墙迷宫
    maze = [[1 for _ in range(width)] for _ in range(height)]
    
    # 起点
    sx, sy = start
    maze[sy][sx] = 0
    
    # 栈
    stack = [(sx, sy)]
    
    # 方向（每次移动2格，保持墙壁厚度）
    dirs = [(0, 2), (2, 0), (0, -2), (-2, 0)]
    
    while stack:
        x, y = stack[-1]
        
        # 找未访问的邻居
        neighbors = []
        for dx, dy in dirs:
            nx, ny = x + dx, y + dy
            if (0 < nx < width-1 and 0 < ny < height-1 and 
                maze[ny][nx] == 1):
                neighbors.append((nx, ny, dx//2, dy//2))
        
        if neighbors:
            # 随机选一个邻居
            nx, ny, wx, wy = random.choice(neighbors)
            
            # 打通墙壁和邻居
            maze[y + wy][x + wx] = 0  # 中间的墙
            maze[ny][nx] = 0           # 邻居格子
            
            stack.append((nx, ny))
        else:
            # 回溯
            stack.pop()
    
    return maze

def _is_passable(grid, pos):
    """检查位置是否可通行"""
    x, y = pos
    if y < 0 or y >= len(grid) or x < 0 or x >= len(grid[0]):
        return False
    return grid[y][x] == 0


def _reconstruct_path(came_from, start, end):
    """重建路径"""
    path = []
    current = end
    
    while current != start:
        path.append(current)
        current = came_from[current]
    
    path.append(start)
    path.reverse()
    
    # 转成vec2列表
    return [vec2(x, y) for x, y in path]



