class SimpleRNG:
    def __init__(self, seed):
        self.a, self.b, self.c, self.d, self.e, self.f = self.my_hash(seed)
        for i in range(20):
            self.next()
            
    def sum_until_one(self, n):
        m = n
        """把一个数不断加各位直到剩一位"""
        while n >= 10:
            n = sum(int(d) for d in str(n))
        return (n * m) % 1000

    def my_hash(self, seed, moduli=None):
        if moduli is None:
            moduli = [5, 7, 89, 97, 997, 991]  # 默认 8 位
        if not str(seed):
            raise ValueError("种子不能为空")
        
        # 把种子转成超大整数（ord 拼接）
        if isinstance(seed, str):
            s = seed
        else:
            s = str(seed)
        
        parts = [str(ord(c) * place) for place,c in enumerate(s, start=1)]
        big_str = ''.join(parts)
        
        # 开始 hash 计算
        result = []
        for m in moduli:
            k = len(str(m))  # 分组长度 = 模数的位数
            
            remainders = []
            # 每 k 位一组
            for i in range(0, len(big_str), k):
                group = big_str[i:i+k]
                group_num = int(group)
                r = group_num % m
                remainders.append(r)
            total = sum(remainders)
            digit = self.sum_until_one(total)
            result.append(digit)
        return (int(d) for d in result)
    
    def seed(self, seed):
        self.a, self.b, self.c, self.d, self.e, self.f = self.my_hash(seed)
        for i in range(20):
            self.next()
        
    def next(self, a=0, b=9):
        # 按照 + + + + + 的模式
        self.a = (self.a + self.f) % 1000000
        self.a ^= self.a >> 1
        self.b = (self.b + self.a) % 1000000
        self.b ^= self.b >> 2
        self.c = (self.c + self.b) % 1000000
        self.c ^= self.c >> 3
        self.d = (self.d + self.c) % 1000000
        self.d ^= self.d >> 4
        self.e = (self.e + self.d) % 1000000
        self.e ^= self.e >> 5
        # 最后 f 取个位
        self.f = (self.f + self.e)
        self.f ^= self.f >> 6
        self.f = self.f % 1000000
        return a + self.f % (b - a + 1)
    
    def randint(self, start, end):
        return self.next(start, end)
    
    def shuffle(self, items):
        # Fisher-Yates 洗牌算法
        for i in range(len(items) - 1, 0, -1):
            j = self.randint(0, i)  # 随机选一个位置
            items[i], items[j] = items[j], items[i]  # 交换
        return items

    def choices(self, arr, weight=None):
        if weight is None:
            return self.choice(arr)
        
        if len(arr) != len(weight):
            raise ValueError("arr 和 weight 长度不一致")
        
        if abs(sum(weight) - 1) > 1e-10:
            raise ValueError("权重和不为1")
        
        su = 0
        num = self.random()
        for i, w in enumerate(weight):
            su += w
            if num < su:
                return arr[i]
        
        return arr[-1]  # 防浮点误差

    def uuid(self):
        strings = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
        result = ""
        for i in range(4):
            for j in range(4):
                result += strings[self.randint(0, 36)]
            result += "-"
            
        return result[:-1]
            
    def sample(self, items, k):
        """
        从列表中随机抽取 k 个不重复的元素
        
        参数:
            items: 源列表
            k: 抽取数量
        
        返回:
            新的列表，包含随机抽取的 k 个元素
        
        示例:
            rng.sample([1,2,3,4,5], 3)  # 例如 [4, 1, 3]
        """
        if k > len(items):
            raise ValueError("k 不能大于列表长度")
        
        items_copy = items.copy()
        self.shuffle(items_copy)
        
        return items_copy[:k]
    
    def shuffle_copy(self, items):
        """
        返回打乱后的新列表（不修改原列表）
        
        参数:
            items: 源列表
        
        返回:
            新的打乱后的列表
        """
        items_copy = items.copy()
        return self.shuffle(items_copy)
    def gauss(self, mu=0.0, sigma=1.0):
        while True:
            u1 = self.random() * 2 - 1  # [-1, 1)
            u2 = self.random() * 2 - 1  # [-1, 1)
            r2 = u1 * u1 + u2 * u2
            if 0 < r2 < 1:  # 避免0和1
                break
        log_r2 = self._approx_log(r2)
        z = u1 * (-2 * log_r2) ** 0.5 / r2**0.5
        return mu + sigma * z
        
    def random(self):
        self.next()
        f = self.f
        return f / 1000000

    def choice(self, candidates):
        assert candidates != []
        return candidates[int(self.random() * len(candidates))]
    
    def sample_by_y(self, func, x_min, x_max, step=0.01, y_max=None):
        """
        1. 随机选 y ∈ [0, y_max]
        2. 找出所有 func(x) >= y 的 x
        3. 从这些 x 中随机选一个
        """
        # 如果没有给 y_max，就估计一下
        if y_max is None:
            y_max = max(func(x_min + i * step) for i in range(int((x_max - x_min) / step) + 1))
            y_min = min(func(x_min + i * step) for i in range(int((x_max - x_min) / step) + 1))

        while True:
            # 1随机选一个 y
            y = self.random() * (y_max - y_min) + y_min

            # 2找出所有 func(x) >= y 的 x
            candidates = []
            x = x_min
            while x <= x_max:
                if func(x) >= y:
                    candidates.append(x)
                x += step

            # 3️如果有候选，就随机选一个
            if candidates:
                return round(candidates[int(self.random() * len(candidates))], 10)
            # 否则重来（理论上不会，但保底）
            
    def _approx_log(self, x):
        if x <= 0:
            return float('-inf')
        y = x - 1
        if abs(y) < 0.1:
            return y - y*y/2 + y*y*y/3 - y*y*y*y/4
        exponent = 0
        while x > 2:
            x /= 2
            exponent += 1
        while x < 1:
            x *= 2
            exponent -= 1
        y = x - 1
        log_x = y - y*y/2 + y*y*y/3 - y*y*y*y/4
        return log_x + exponent * 0.6931471805599453  # ln(2)

