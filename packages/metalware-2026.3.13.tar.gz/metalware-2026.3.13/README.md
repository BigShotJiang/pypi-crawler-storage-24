# Metalware SDK

Python SDK and CLI for interacting with Metalware Havoc.

## What This Repo Contains

- Python package: `metalware_sdk`
- CLI entrypoint: `metalware`
- Usage examples: `examples/`

## Quick Start

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -e .
```

Configure the CLI:

```bash
metalware setup
```

Submit firmware:

```bash
metalware submit path/to/firmware.elf
```

## Documentation

Detailed developer docs are at https://docs.metalware.com/sdk
