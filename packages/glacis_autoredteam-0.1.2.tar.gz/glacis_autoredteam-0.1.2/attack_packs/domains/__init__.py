"""Domain-specific attack packs."""
