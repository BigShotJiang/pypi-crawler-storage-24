"""FlowTask Python SDK — programmatic access to the FlowTask API."""

from __future__ import annotations

from typing import Optional
import requests as _requests

from .models import Workspace, Project, Task, Dependency, Tag, Section, MyDayItem, SmartViewCounts, WorkspaceMember, Note, NoteFolder
from .exceptions import (
    FlowTaskError,
    AuthenticationError,
    ValidationError,
    NotFoundError,
    CycleDetectedError,
)

ERROR_MAP = {
    "UNAUTHORIZED": AuthenticationError,
    "VALIDATION_ERROR": ValidationError,
    "NOT_FOUND": NotFoundError,
    "CYCLE_DETECTED": CycleDetectedError,
    "FORBIDDEN": AuthenticationError,
    "CONFLICT": ValidationError,
    "DUPLICATE": ValidationError,
}


class FlowTask:
    """Client for the FlowTask API.

    Usage:
        ft = FlowTask(token="ft_your_token", base_url="http://localhost:3000")

        # Create a workspace and project
        ws = ft.create_workspace("Work")
        project = ws.create_project("Sprint 1", color="#6366F1")

        # Create tasks with priority
        design = project.create_task("Design", color="#8B5CF6", priority="high")
        build = project.create_task("Build", color="#3B82F6")

        # Create dependency: Design must be done before Build
        build.add_dependency(design)

        # Plan your day
        design.add_to_my_day()
        for item in ft.get_my_day():
            print(f"→ {item.display_title}")
    """

    def __init__(self, token: str, base_url: str = "http://localhost:3000"):
        self.base_url = base_url.rstrip("/")
        self._session = _requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            }
        )

    def _request(self, method: str, path: str, json: dict = None, params: dict = None) -> dict:
        url = f"{self.base_url}/api{path}"
        resp = self._session.request(method, url, json=json, params=params)

        # Handle non-JSON responses (502/503 from proxy, HTML error pages, etc.)
        try:
            data = resp.json()
        except Exception:
            if not resp.ok:
                raise FlowTaskError(
                    message=f"HTTP {resp.status_code}: {resp.text[:200]}",
                    code="HTTP_ERROR",
                    status=resp.status_code,
                )
            return {}

        if not resp.ok:
            error_data = data.get("error", {})
            code = error_data.get("code", "UNKNOWN")
            message = error_data.get("message", f"HTTP {resp.status_code}")
            exc_class = ERROR_MAP.get(code, FlowTaskError)
            raise exc_class(message=message, code=code, status=resp.status_code)

        return data.get("data", data)

    # ─── Workspaces ────────────────────────────────────

    def list_workspaces(self) -> list[Workspace]:
        """List all workspaces."""
        data = self._request("GET", "/workspaces")
        return [Workspace.from_dict(w, client=self) for w in data]

    def create_workspace(self, name: str, icon: Optional[str] = None) -> Workspace:
        """Create a new workspace."""
        body: dict = {"name": name}
        if icon is not None:
            body["icon"] = icon
        data = self._request("POST", "/workspaces", json=body)
        return Workspace.from_dict(data, client=self)

    def update_workspace(self, workspace_id: str, **kwargs) -> Workspace:
        """Update a workspace. Accepts: name, icon."""
        body = {}
        for key in ("name", "icon"):
            if key in kwargs:
                body[key] = kwargs[key]
        data = self._request("PUT", f"/workspaces/{workspace_id}", json=body)
        return Workspace.from_dict(data, client=self)

    def delete_workspace(self, workspace_id: str) -> None:
        """Delete a workspace and all its projects and tasks (cascade)."""
        self._request("DELETE", f"/workspaces/{workspace_id}")

    def reorder_workspaces(self, workspace_ids: list[str]) -> None:
        """Reorder workspaces by providing IDs in desired order."""
        self._request("PATCH", "/workspaces/reorder", json={"workspaceIds": workspace_ids})

    # ─── Projects ──────────────────────────────────────

    def list_projects(self) -> list[Project]:
        """List all projects."""
        data = self._request("GET", "/projects")
        return [Project.from_dict(p, client=self) for p in data]

    def create_project(
        self,
        name: str,
        workspace_id: str,
        description: Optional[str] = None,
        color: Optional[str] = None,
    ) -> Project:
        """Create a new project in a workspace. workspace_id is required."""
        body: dict = {"name": name, "workspaceId": workspace_id}
        if description is not None:
            body["description"] = description
        if color is not None:
            body["color"] = color
        data = self._request("POST", "/projects", json=body)
        return Project.from_dict(data, client=self)

    def get_project(self, project_id: str) -> Project:
        """Get a project by ID."""
        data = self._request("GET", f"/projects/{project_id}")
        return Project.from_dict(data.get("project", data), client=self)

    def get_project_full(self, project_id: str) -> tuple[list[Task], list[Dependency]]:
        """Load a project's full data: tasks and dependencies."""
        data = self._request("GET", f"/projects/{project_id}")
        tasks = [Task.from_dict(t, client=self) for t in data.get("tasks", [])]
        deps = [Dependency.from_dict(d) for d in data.get("dependencies", [])]
        return tasks, deps

    def update_project(self, project_id: str, **kwargs) -> Project:
        """Update a project. Accepts: name, description, color, workspace_id."""
        key_map = {"workspace_id": "workspaceId"}
        body = {}
        for key, value in kwargs.items():
            api_key = key_map.get(key, key)
            body[api_key] = value
        data = self._request("PUT", f"/projects/{project_id}", json=body)
        return Project.from_dict(data, client=self)

    def delete_project(self, project_id: str) -> None:
        """Delete a project and all its tasks."""
        self._request("DELETE", f"/projects/{project_id}")

    def reorder_projects(self, project_ids: list[str]) -> None:
        """Reorder projects by providing IDs in desired order."""
        self._request("PATCH", "/projects/reorder", json={"projectIds": project_ids})

    # ─── Tasks ─────────────────────────────────────────

    def create_task(
        self,
        project_id: str,
        title: str,
        description: Optional[str] = None,
        color: Optional[str] = None,
        priority: Optional[str] = None,
        due_date: Optional[str] = None,
        assignee: Optional[str] = None,
        position_x: Optional[float] = None,
        position_y: Optional[float] = None,
    ) -> Task:
        """Create a task in a project."""
        body: dict = {"title": title}
        if description is not None:
            body["description"] = description
        if color is not None:
            body["color"] = color
        if priority is not None:
            body["priority"] = priority
        if due_date is not None:
            body["dueDate"] = due_date
        if assignee is not None:
            body["assignee"] = assignee
        if position_x is not None:
            body["positionX"] = position_x
        if position_y is not None:
            body["positionY"] = position_y
        data = self._request("POST", f"/projects/{project_id}/tasks", json=body)
        return Task.from_dict(data, client=self)

    def update_task(self, task_id: str, **kwargs) -> Task:
        """Update a task. Accepts: title, description, status, color, priority,
        due_date, assignee, position_x, position_y, sort_order."""
        key_map = {
            "due_date": "dueDate",
            "position_x": "positionX",
            "position_y": "positionY",
            "sort_order": "sortOrder",
        }
        body = {}
        for key, value in kwargs.items():
            api_key = key_map.get(key, key)
            body[api_key] = value
        data = self._request("PUT", f"/tasks/{task_id}", json=body)
        return Task.from_dict(data, client=self)

    def set_task_status(self, task_id: str, status: str) -> Task:
        """Set a task's status: 'pending', 'in_progress', or 'completed'."""
        data = self._request("PATCH", f"/tasks/{task_id}/status", json={"status": status})
        return Task.from_dict(data, client=self)

    def delete_task(self, task_id: str) -> None:
        """Delete a task and its dependencies."""
        self._request("DELETE", f"/tasks/{task_id}")

    def update_task_positions(self, positions: list[dict]) -> None:
        """Bulk update task positions. Each item: {id, positionX, positionY}."""
        self._request("PATCH", "/tasks/positions", json={"positions": positions})

    # ─── Dependencies ──────────────────────────────────

    def create_dependency(self, enabling_task_id: str, dependent_task_id: str) -> Dependency:
        """Create a dependency: enabling_task must be done before dependent_task.

        Raises CycleDetectedError if this would create a circular dependency.
        """
        data = self._request(
            "POST",
            "/dependencies",
            json={
                "enablingTaskId": enabling_task_id,
                "dependentTaskId": dependent_task_id,
            },
        )
        return Dependency.from_dict(data)

    def delete_dependency(self, dependency_id: str) -> None:
        """Remove a dependency."""
        self._request("DELETE", f"/dependencies/{dependency_id}")

    # ─── Tags ──────────────────────────────────────────

    def list_tags(self) -> list[Tag]:
        """List all tags."""
        data = self._request("GET", "/tags")
        return [Tag.from_dict(t) for t in data]

    def create_tag(self, name: str, color: Optional[str] = None) -> Tag:
        """Create a tag."""
        body: dict = {"name": name}
        if color is not None:
            body["color"] = color
        data = self._request("POST", "/tags", json=body)
        return Tag.from_dict(data)

    def assign_tag(self, task_id: str, tag_id: str) -> None:
        """Assign a tag to a task."""
        self._request("POST", f"/tasks/{task_id}/tags/{tag_id}", json={})

    def remove_tag(self, task_id: str, tag_id: str) -> None:
        """Remove a tag from a task."""
        self._request("DELETE", f"/tasks/{task_id}/tags/{tag_id}")

    # ─── Workspace Tasks ────────────────────────────────

    def create_workspace_task(
        self,
        workspace_id: str,
        title: str,
        description: Optional[str] = None,
        color: Optional[str] = None,
        priority: Optional[str] = None,
        due_date: Optional[str] = None,
        assignee: Optional[str] = None,
        section_id: Optional[str] = None,
    ) -> Task:
        """Create a standalone task in a workspace."""
        body: dict = {"title": title}
        if description is not None:
            body["description"] = description
        if color is not None:
            body["color"] = color
        if priority is not None:
            body["priority"] = priority
        if due_date is not None:
            body["dueDate"] = due_date
        if assignee is not None:
            body["assignee"] = assignee
        if section_id is not None:
            body["sectionId"] = section_id
        data = self._request("POST", f"/workspaces/{workspace_id}/tasks", json=body)
        return Task.from_dict(data, client=self)

    def get_workspace_board(self, workspace_id: str) -> dict:
        """Get workspace board data (sections with tasks + unsectioned tasks)."""
        data = self._request("GET", f"/workspaces/{workspace_id}/board")
        sections = []
        for s in data.get("sections", []):
            section = Section.from_dict(s)
            tasks = [Task.from_dict(t, client=self) for t in s.get("tasks", [])]
            sections.append({"section": section, "tasks": tasks})
        unsectioned = [Task.from_dict(t, client=self) for t in data.get("unsectioned", [])]
        return {"sections": sections, "unsectioned": unsectioned}

    def move_task_to_section(
        self,
        workspace_id: str,
        task_id: str,
        section_id: Optional[str] = None,
    ) -> None:
        """Move a workspace task to a different section (or unsectioned if None)."""
        self._request(
            "PATCH",
            f"/workspaces/{workspace_id}/tasks/move",
            json={"taskId": task_id, "sectionId": section_id},
        )

    # ─── Sections ──────────────────────────────────────

    def list_sections(self, workspace_id: str) -> list[Section]:
        """List sections in a workspace."""
        data = self._request("GET", f"/workspaces/{workspace_id}/sections")
        return [Section.from_dict(s) for s in data]

    def create_section(self, workspace_id: str, name: str) -> Section:
        """Create a section in a workspace."""
        data = self._request("POST", f"/workspaces/{workspace_id}/sections", json={"name": name})
        return Section.from_dict(data)

    def update_section(self, section_id: str, **kwargs) -> Section:
        """Update a section. Accepts: name."""
        body = {}
        if "name" in kwargs:
            body["name"] = kwargs["name"]
        data = self._request("PUT", f"/sections/{section_id}", json=body)
        return Section.from_dict(data)

    def delete_section(self, section_id: str) -> None:
        """Delete a section. Tasks become unsectioned."""
        self._request("DELETE", f"/sections/{section_id}")

    def reorder_sections(self, section_ids: list[str]) -> None:
        """Reorder sections by providing IDs in desired order."""
        self._request("PATCH", "/sections/reorder", json={"sectionIds": section_ids})

    # ─── Sharing ───────────────────────────────────────

    def invite_to_workspace(self, workspace_id: str, email: str, role: str = "editor") -> WorkspaceMember:
        """Invite a user to a workspace by email. Returns the member or creates a pending invitation."""
        data = self._request("POST", f"/workspaces/{workspace_id}/members", json={"email": email, "role": role})
        if data.get("type") == "member" and data.get("member"):
            return WorkspaceMember.from_dict(data["member"])
        return WorkspaceMember(id="pending", user_id="", role=role, user_email=email)

    def list_workspace_members(self, workspace_id: str) -> list[WorkspaceMember]:
        """List all members of a workspace."""
        data = self._request("GET", f"/workspaces/{workspace_id}/members")
        return [WorkspaceMember.from_dict(m) for m in data.get("members", [])]

    def update_workspace_member(self, workspace_id: str, member_id: str, role: str) -> WorkspaceMember:
        """Change a member's role (owner only)."""
        data = self._request("PUT", f"/workspaces/{workspace_id}/members/{member_id}", json={"role": role})
        return WorkspaceMember.from_dict(data)

    def remove_workspace_member(self, workspace_id: str, member_id: str) -> None:
        """Remove a member from a workspace (owner only)."""
        self._request("DELETE", f"/workspaces/{workspace_id}/members/{member_id}")

    def leave_workspace(self, workspace_id: str) -> None:
        """Leave a workspace (non-owners only)."""
        self._request("DELETE", f"/workspaces/{workspace_id}/members/me")

    # ─── My Day ────────────────────────────────────────

    def get_my_day(self, date: Optional[str] = None) -> list[MyDayItem]:
        """Get My Day tasks for a date (defaults to today)."""
        params = {}
        if date:
            params["date"] = date
        data = self._request("GET", "/my-day", params=params)
        return [MyDayItem.from_dict(d, client=self) for d in data]

    def get_my_day_suggestions(self, date: Optional[str] = None) -> list[Task]:
        """Get actionable tasks not yet pinned to My Day."""
        params = {}
        if date:
            params["date"] = date
        data = self._request("GET", "/my-day/suggestions", params=params)
        return [Task.from_dict(t, client=self) for t in data]

    def add_to_my_day(self, task_id: str, date: Optional[str] = None) -> MyDayItem:
        """Pin an existing task to My Day."""
        body: dict = {"taskId": task_id}
        if date:
            body["date"] = date
        data = self._request("POST", "/my-day", json=body)
        return MyDayItem.from_dict(data, client=self)

    def create_my_day_task(self, title: str, priority: Optional[str] = None, date: Optional[str] = None) -> MyDayItem:
        """Create a standalone My Day task (not linked to any project/workspace)."""
        body: dict = {"title": title}
        if priority:
            body["priority"] = priority
        if date:
            body["date"] = date
        data = self._request("POST", "/my-day/standalone", json=body)
        return MyDayItem.from_dict(data, client=self)

    def remove_from_my_day(self, my_day_id: str) -> None:
        """Remove an item from My Day."""
        self._request("DELETE", f"/my-day/{my_day_id}")

    def reorder_my_day(self, ids: list[str]) -> None:
        """Reorder My Day items by providing IDs in desired order."""
        self._request("PATCH", "/my-day/reorder", json={"ids": ids})

    # ─── Smart Views ───────────────────────────────────

    def get_smart_view_counts(self) -> SmartViewCounts:
        """Get task counts for all smart views (My Day, Today, Upcoming, etc.)."""
        data = self._request("GET", "/smart-views/counts")
        return SmartViewCounts.from_dict(data)

    def get_smart_view(self, view: str) -> list[Task]:
        """Get tasks for a smart view: 'today', 'upcoming', 'anytime', 'delegated', 'completed'."""
        data = self._request("GET", f"/smart-views/{view}")
        return [Task.from_dict(t, client=self) for t in data]

    def actual_tasks(self) -> list[Task]:
        """Get actionable tasks — tasks where all dependencies are completed."""
        data = self._request("GET", "/actual-tasks")
        return [Task.from_dict(t, client=self) for t in data]

    # ─── Notes ─────────────────────────────────────────

    def list_notes(self, workspace_id: str) -> dict:
        """List all notes and folders in a workspace."""
        data = self._request("GET", f"/workspaces/{workspace_id}/notes")
        folders = [NoteFolder.from_dict(f, client=self) for f in data.get("folders", [])]
        unfoldered = [Note.from_dict(n, client=self) for n in data.get("unfolderedNotes", [])]
        return {"folders": folders, "unfolderedNotes": unfoldered}

    def create_note(
        self,
        workspace_id: str,
        title: str,
        content: str = "",
        folder_id: Optional[str] = None,
    ) -> Note:
        """Create a note in a workspace. Content is markdown."""
        body: dict = {"title": title, "content": content}
        if folder_id:
            body["folderId"] = folder_id
        data = self._request("POST", f"/workspaces/{workspace_id}/notes", json=body)
        return Note.from_dict(data, client=self)

    def update_note(self, note_id: str, **kwargs) -> Note:
        """Update a note. Accepts: title, content, folder_id."""
        key_map = {"folder_id": "folderId"}
        body = {}
        for key, value in kwargs.items():
            api_key = key_map.get(key, key)
            body[api_key] = value
        data = self._request("PUT", f"/notes/{note_id}", json=body)
        return Note.from_dict(data, client=self)

    def delete_note(self, note_id: str) -> None:
        """Delete a note."""
        self._request("DELETE", f"/notes/{note_id}")

    def create_note_folder(self, workspace_id: str, name: str) -> NoteFolder:
        """Create a note folder in a workspace."""
        data = self._request("POST", f"/workspaces/{workspace_id}/folders", json={"name": name})
        return NoteFolder.from_dict(data, client=self)

    def update_note_folder(self, folder_id: str, name: str) -> NoteFolder:
        """Rename a note folder."""
        data = self._request("PUT", f"/folders/{folder_id}", json={"name": name})
        return NoteFolder.from_dict(data, client=self)

    def delete_note_folder(self, folder_id: str) -> None:
        """Delete a note folder. Notes become unfoldered."""
        self._request("DELETE", f"/folders/{folder_id}")

    # ─── Search ────────────────────────────────────────

    def search(self, query: str) -> list[Task]:
        """Search tasks by title across all projects and workspaces."""
        data = self._request("GET", "/search", params={"q": query})
        return [Task.from_dict(t, client=self) for t in data]
