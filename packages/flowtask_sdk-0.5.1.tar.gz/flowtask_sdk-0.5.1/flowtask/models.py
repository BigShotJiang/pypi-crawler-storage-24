from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import FlowTask


@dataclass
class Tag:
    id: str
    name: str
    color: str

    @classmethod
    def from_dict(cls, data: dict) -> Tag:
        return cls(id=data["id"], name=data["name"], color=data["color"])


@dataclass
class Dependency:
    id: str
    enabling_task_id: str
    dependent_task_id: str

    @classmethod
    def from_dict(cls, data: dict) -> Dependency:
        return cls(
            id=data["id"],
            enabling_task_id=data["enablingTaskId"],
            dependent_task_id=data["dependentTaskId"],
        )


@dataclass
class Task:
    id: str
    title: str
    status: str
    description: Optional[str] = None
    color: Optional[str] = None
    priority: str = "none"
    due_date: Optional[str] = None
    assignee: Optional[str] = None
    position_x: float = 0
    position_y: float = 0
    sort_order: int = 0
    project_id: Optional[str] = None
    workspace_id: Optional[str] = None
    section_id: Optional[str] = None
    tags: list[Tag] = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""
    # Populated when returned from smart views / my day suggestions
    project: Optional[dict] = field(default=None, repr=False)
    workspace: Optional[dict] = field(default=None, repr=False)
    _client: Optional[FlowTask] = field(default=None, repr=False)

    @classmethod
    def from_dict(cls, data: dict, client: Optional[FlowTask] = None) -> Task:
        return cls(
            id=data["id"],
            title=data["title"],
            status=data["status"],
            description=data.get("description"),
            color=data.get("color"),
            priority=data.get("priority", "none"),
            due_date=data.get("dueDate"),
            assignee=data.get("assignee"),
            position_x=data.get("positionX", 0),
            position_y=data.get("positionY", 0),
            sort_order=data.get("sortOrder", 0),
            project_id=data.get("projectId"),
            workspace_id=data.get("workspaceId"),
            section_id=data.get("sectionId"),
            tags=[Tag.from_dict(t) for t in data.get("tags", [])],
            created_at=data.get("createdAt", ""),
            updated_at=data.get("updatedAt", ""),
            project=data.get("project"),
            workspace=data.get("workspace"),
            _client=client,
        )

    def update(self, **kwargs) -> Task:
        """Update this task's fields. Returns the updated task."""
        if not self._client:
            raise RuntimeError("Task not bound to a client")
        return self._client.update_task(self.id, **kwargs)

    def set_status(self, status: str) -> Task:
        """Set task status: 'pending', 'in_progress', or 'completed'."""
        if not self._client:
            raise RuntimeError("Task not bound to a client")
        return self._client.set_task_status(self.id, status)

    def complete(self) -> Task:
        """Mark this task as completed."""
        return self.set_status("completed")

    def delete(self) -> None:
        """Delete this task."""
        if not self._client:
            raise RuntimeError("Task not bound to a client")
        self._client.delete_task(self.id)

    def add_dependency(self, depends_on: Task) -> Dependency:
        """Make this task depend on another task (depends_on must be done first)."""
        if not self._client:
            raise RuntimeError("Task not bound to a client")
        return self._client.create_dependency(depends_on.id, self.id)

    def add_tag(self, tag_id: str) -> None:
        """Assign a tag to this task."""
        if not self._client:
            raise RuntimeError("Task not bound to a client")
        self._client.assign_tag(self.id, tag_id)

    def remove_tag(self, tag_id: str) -> None:
        """Remove a tag from this task."""
        if not self._client:
            raise RuntimeError("Task not bound to a client")
        self._client.remove_tag(self.id, tag_id)

    def add_to_my_day(self, date: Optional[str] = None) -> MyDayItem:
        """Pin this task to My Day."""
        if not self._client:
            raise RuntimeError("Task not bound to a client")
        return self._client.add_to_my_day(self.id, date=date)


@dataclass
class Section:
    id: str
    name: str
    sort_order: int = 0
    workspace_id: str = ""

    @classmethod
    def from_dict(cls, data: dict) -> Section:
        return cls(
            id=data["id"],
            name=data["name"],
            sort_order=data.get("sortOrder", 0),
            workspace_id=data.get("workspaceId", ""),
        )


@dataclass
class WorkspaceMember:
    id: str
    user_id: str
    role: str
    user_email: str = ""
    user_name: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> WorkspaceMember:
        user = data.get("user", {})
        return cls(
            id=data["id"],
            user_id=data.get("userId", ""),
            role=data.get("role", "editor"),
            user_email=user.get("email", ""),
            user_name=user.get("name"),
        )


@dataclass
class Workspace:
    id: str
    name: str
    icon: str = "📁"
    sort_order: int = 0
    project_count: int = 0
    task_count: int = 0
    is_shared: bool = False
    current_user_role: str = "owner"
    created_at: str = ""
    updated_at: str = ""
    _client: Optional[FlowTask] = field(default=None, repr=False)

    @classmethod
    def from_dict(cls, data: dict, client: Optional[FlowTask] = None) -> Workspace:
        count = data.get("_count", {})
        return cls(
            id=data["id"],
            name=data["name"],
            icon=data.get("icon", "📁"),
            sort_order=data.get("sortOrder", 0),
            project_count=count.get("projects", 0) if isinstance(count, dict) else 0,
            task_count=count.get("tasks", 0) if isinstance(count, dict) else 0,
            is_shared=data.get("isShared", False),
            current_user_role=data.get("currentUserRole", "owner"),
            created_at=data.get("createdAt", ""),
            updated_at=data.get("updatedAt", ""),
            _client=client,
        )

    def create_project(self, name: str, **kwargs) -> Project:
        """Create a project in this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.create_project(name, workspace_id=self.id, **kwargs)

    def create_task(self, title: str, **kwargs) -> Task:
        """Create a standalone task in this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.create_workspace_task(self.id, title, **kwargs)

    def get_board(self) -> dict:
        """Get the kanban board (sections + tasks)."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.get_workspace_board(self.id)

    def create_section(self, name: str) -> Section:
        """Create a section in this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.create_section(self.id, name)

    def list_sections(self) -> list[Section]:
        """List sections in this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.list_sections(self.id)

    def move_task(self, task_id: str, section_id: Optional[str] = None) -> None:
        """Move a task to a different section (or unsectioned if None)."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        self._client.move_task_to_section(self.id, task_id, section_id)

    def update(self, **kwargs) -> Workspace:
        """Update this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.update_workspace(self.id, **kwargs)

    def delete(self) -> None:
        """Delete this workspace and all its projects and tasks."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        self._client.delete_workspace(self.id)

    def share(self, email: str, role: str = "editor") -> WorkspaceMember:
        """Invite a user to this workspace by email."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.invite_to_workspace(self.id, email, role)

    def list_members(self) -> list[WorkspaceMember]:
        """List all members of this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.list_workspace_members(self.id)

    def remove_member(self, member_id: str) -> None:
        """Remove a member from this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        self._client.remove_workspace_member(self.id, member_id)

    def leave(self) -> None:
        """Leave this workspace (non-owners only)."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        self._client.leave_workspace(self.id)

    def list_notes(self) -> dict:
        """List all notes and folders in this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.list_notes(self.id)

    def create_note(self, title: str, content: str = "", folder_id: Optional[str] = None) -> Note:
        """Create a note in this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.create_note(self.id, title, content, folder_id)

    def create_note_folder(self, name: str) -> NoteFolder:
        """Create a note folder in this workspace."""
        if not self._client:
            raise RuntimeError("Workspace not bound to a client")
        return self._client.create_note_folder(self.id, name)


@dataclass
class Project:
    id: str
    name: str
    description: Optional[str] = None
    color: str = "#6366F1"
    sort_order: int = 0
    workspace_id: str = ""
    task_count: int = 0
    created_at: str = ""
    updated_at: str = ""
    _client: Optional[FlowTask] = field(default=None, repr=False)

    @classmethod
    def from_dict(cls, data: dict, client: Optional[FlowTask] = None) -> Project:
        count = data.get("_count", {})
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description"),
            color=data.get("color", "#6366F1"),
            sort_order=data.get("sortOrder", 0),
            workspace_id=data.get("workspaceId", ""),
            task_count=count.get("tasks", 0) if isinstance(count, dict) else 0,
            created_at=data.get("createdAt", ""),
            updated_at=data.get("updatedAt", ""),
            _client=client,
        )

    def create_task(self, title: str, **kwargs) -> Task:
        """Create a new task in this project."""
        if not self._client:
            raise RuntimeError("Project not bound to a client")
        return self._client.create_task(self.id, title, **kwargs)

    def load(self) -> tuple[list[Task], list[Dependency]]:
        """Load all tasks and dependencies for this project."""
        if not self._client:
            raise RuntimeError("Project not bound to a client")
        return self._client.get_project_full(self.id)

    def update(self, **kwargs) -> Project:
        """Update this project's fields."""
        if not self._client:
            raise RuntimeError("Project not bound to a client")
        return self._client.update_project(self.id, **kwargs)

    def delete(self) -> None:
        """Delete this project and all its tasks."""
        if not self._client:
            raise RuntimeError("Project not bound to a client")
        self._client.delete_project(self.id)


@dataclass
class MyDayItem:
    id: str
    date: str
    sort_order: int = 0
    task_id: Optional[str] = None
    title: Optional[str] = None
    priority: str = "none"
    task: Optional[Task] = None
    _client: Optional[FlowTask] = field(default=None, repr=False)

    @classmethod
    def from_dict(cls, data: dict, client: Optional[FlowTask] = None) -> MyDayItem:
        task_data = data.get("task")
        return cls(
            id=data["id"],
            date=data.get("date", ""),
            sort_order=data.get("sortOrder", 0),
            task_id=data.get("taskId"),
            title=data.get("title"),
            priority=data.get("priority", "none"),
            task=Task.from_dict(task_data, client=client) if task_data else None,
            _client=client,
        )

    def remove(self) -> None:
        """Remove this item from My Day."""
        if not self._client:
            raise RuntimeError("MyDayItem not bound to a client")
        self._client.remove_from_my_day(self.id)

    @property
    def display_title(self) -> str:
        """The title to display (from linked task or standalone)."""
        if self.task:
            return self.task.title
        return self.title or ""


@dataclass
class SmartViewCounts:
    actual: int = 0
    my_day: int = 0
    today: int = 0
    upcoming: int = 0
    anytime: int = 0
    delegated: int = 0
    completed: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> SmartViewCounts:
        return cls(
            actual=data.get("actual", 0),
            my_day=data.get("myDay", 0),
            today=data.get("today", 0),
            upcoming=data.get("upcoming", 0),
            anytime=data.get("anytime", 0),
            delegated=data.get("delegated", 0),
            completed=data.get("completed", 0),
        )


@dataclass
class NoteFolder:
    id: str
    name: str
    sort_order: int = 0
    workspace_id: str = ""
    notes: list[Note] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict, client: Optional[FlowTask] = None) -> NoteFolder:
        return cls(
            id=data["id"],
            name=data["name"],
            sort_order=data.get("sortOrder", 0),
            workspace_id=data.get("workspaceId", ""),
            notes=[Note.from_dict(n, client=client) for n in data.get("notes", [])],
        )


@dataclass
class Note:
    id: str
    title: str
    content: str = ""
    sort_order: int = 0
    folder_id: Optional[str] = None
    author_id: str = ""
    workspace_id: str = ""
    created_at: str = ""
    updated_at: str = ""
    _client: Optional[FlowTask] = field(default=None, repr=False)

    @classmethod
    def from_dict(cls, data: dict, client: Optional[FlowTask] = None) -> Note:
        return cls(
            id=data["id"],
            title=data["title"],
            content=data.get("content", ""),
            sort_order=data.get("sortOrder", 0),
            folder_id=data.get("folderId"),
            author_id=data.get("authorId", ""),
            workspace_id=data.get("workspaceId", ""),
            created_at=data.get("createdAt", ""),
            updated_at=data.get("updatedAt", ""),
            _client=client,
        )

    def update(self, **kwargs) -> Note:
        """Update this note. Accepts: title, content, folder_id."""
        if not self._client:
            raise RuntimeError("Note not bound to a client")
        return self._client.update_note(self.id, **kwargs)

    def delete(self) -> None:
        """Delete this note."""
        if not self._client:
            raise RuntimeError("Note not bound to a client")
        self._client.delete_note(self.id)
