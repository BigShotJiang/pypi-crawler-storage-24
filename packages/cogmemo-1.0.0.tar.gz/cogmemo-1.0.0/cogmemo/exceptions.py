"""Exceptions for the CoMemo SDK."""


class ComemoError(Exception):
    """Base exception for all SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, response: dict | None = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class AuthenticationError(ComemoError):
    """Raised when authentication fails (401/403)."""


class NotFoundError(ComemoError):
    """Raised when a resource is not found (404)."""


class ValidationError(ComemoError):
    """Raised when the request is invalid (400/422)."""


class ServerError(ComemoError):
    """Raised when the server returns a 5xx error."""
