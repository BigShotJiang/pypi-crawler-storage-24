"""CoMemo SDK - Python client for the CoMemo API."""

from .client import MemoryClient
from .exceptions import (
    AuthenticationError,
    ComemoError,
    NotFoundError,
    ServerError,
    ValidationError,
)
from .models import (
    AddMemoryResult,
    DeleteResult,
    DetailedMemory,
    DetailedRetrieveResult,
    HealthResult,
    Memory,
    RetrieveResult,
    RetrieveSummaryResult,
)

__version__ = "1.0.0"

__all__ = [
    "MemoryClient",
    "AddMemoryResult",
    "DeleteResult",
    "DetailedMemory",
    "DetailedRetrieveResult",
    "HealthResult",
    "Memory",
    "RetrieveResult",
    "RetrieveSummaryResult",
    "ComemoError",
    "AuthenticationError",
    "NotFoundError",
    "ServerError",
    "ValidationError",
]
