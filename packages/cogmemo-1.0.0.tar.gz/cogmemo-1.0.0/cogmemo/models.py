"""Response models for the CoMemo SDK."""

from dataclasses import dataclass


@dataclass
class AddMemoryResult:
    """Result of adding a memory."""
    status: str
    action: str
    memory_id: str | None
    links_created: int
    score: float


@dataclass
class Memory:
    """A retrieved memory."""
    memory_id: str
    fact: str
    score: float


@dataclass
class DetailedMemory:
    """A retrieved memory with detailed scoring breakdown."""
    memory_id: str
    fact: str
    domain: str
    final_score: float
    semantic_similarity: float
    graph_relevance: float
    memory_strength: float
    recency_score: float
    session_boost: float
    source: str
    session_id: str


@dataclass
class RetrieveResult:
    """Result of a simple retrieval."""
    query: str
    expanded_query: str
    memories: list[Memory]


@dataclass
class DetailedRetrieveResult:
    """Result of an advanced retrieval with full scoring details."""
    query: str
    expanded_query: str
    user_id: str
    session_id: str
    memories: list[DetailedMemory]
    total_candidates: int
    filtered_count: int
    retrieval_time_ms: float


@dataclass
class RetrieveSummaryResult:
    """Result of a retrieval with LLM summary."""
    query: str
    summary: str
    supporting_memories: list[Memory]


@dataclass
class DeleteResult:
    """Result of a delete operation."""
    status: str
    user_id: str
    memories_deleted: int


@dataclass
class HealthResult:
    """Health check result."""
    status: str
    version: str
    architecture: str
    scheduler: dict
