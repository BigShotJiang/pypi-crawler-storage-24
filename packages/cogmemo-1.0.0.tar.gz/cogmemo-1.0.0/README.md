# CogMemo SDK

Python SDK for [CogMemo](https://github.com/hasala/cognitive-memory) — a multi-module hybrid memory system powered by Pinecone and Neo4j.

## Installation

```bash
pip install cogmemo
```

## Quick Start

```python
from cogmemo import MemoryClient

# Default (uses server-side LLM config)
client = MemoryClient()

# With your own LLM API key and model
client = MemoryClient(
    api_key="sk-your-openai-key",
    model="gpt-4o-mini"
)
```

### Core Memory

```python
# Add a memory
result = client.add_memory("john", "chat_01", "I work at Google as a software engineer")
print(result.status)     # "success"
print(result.action)     # "NEW"
print(result.memory_id)  # "mem_abc123"

# Clear all user memories
client.delete_user_memories("john")

# Clear session memories
client.delete_session_memories("john", "chat_01")

# Delete a single memory
client.delete_memory("mem_abc123")
```

### Retrieval

```python
# Retrieve memories with graph expansion
result = client.retrieve_advanced(
    user_id="john",
    session_id="chat_01",
    query="career and hobbies",
    top_k=10,
    expand_context=True,
    expand_graph=True,
    min_score=0.3,
    reinforce=True
)
for m in result.memories:
    print(f"{m.fact} | semantic={m.semantic_similarity:.2f} graph={m.graph_relevance:.2f}")

# List user memories
result = client.list_memories("john", query="work", top_k=10)
for m in result.memories:
    print(f"{m.fact} (score: {m.score:.2f})")

# Simple retrieve
result = client.retrieve("john", "chat_01", "Where does John work?", top_k=5)
for m in result.memories:
    print(f"{m.fact} (score: {m.score:.2f})")

# Retrieve with summary
summary = client.retrieve_summary("john", "chat_01", "Tell me about John's career")
print(summary.summary)
for m in summary.supporting_memories:
    print(f"  - {m.fact}")
```

### Maintenance & Governance

```python
# Run all maintenance tasks
result = client.run_maintenance(user_id="john")
```

### System

```python
# Clear all memory
client.delete_all_memories(confirm="DELETE_ALL_DATA")

# Get scheduler status
status = client.scheduler_status()

# Health check
health = client.health()
print(health.status)   # "healthy"
print(health.version)  # "5.1.0"
```

## Configuration

```python
# With LLM API key and model
client = MemoryClient(api_key="sk-your-openai-key", model="gpt-4o-mini")
```

## Context Manager

```python
with MemoryClient() as client:
    client.add_memory("john", "chat_01", "My favorite color is blue")
```

## Error Handling

```python
from cogmemo import MemoryClient, ValidationError, NotFoundError

try:
    client.retrieve("john", "chat_01", "")
except ValidationError as e:
    print(f"Bad request: {e.message}")
except NotFoundError as e:
    print(f"Not found: {e.message}")
```

## All Methods

### Core Memory

| Method | Description |
|---|---|
| `add_memory(user_id, session_id, text)` | Add Memory |
| `delete_user_memories(user_id)` | Clear User Memory |
| `delete_session_memories(user_id, session_id)` | Clear Session Memory |
| `delete_memory(memory_id)` | Delete Single Memory |

### Retrieval

| Method | Description |
|---|---|
| `retrieve_advanced(user_id, session_id, query, ...)` | Retrieve Memories |
| `list_memories(user_id, query, top_k=10)` | List User Memories |
| `retrieve(user_id, session_id, query, top_k=5)` | Simple Retrieve Memories |
| `retrieve_summary(user_id, session_id, query, top_k=5)` | Retrieve With Summary |

### Maintenance & Governance

| Method | Description |
|---|---|
| `run_maintenance(user_id="")` | Run All Maintenance |

### System

| Method | Description |
|---|---|
| `delete_all_memories(confirm)` | Clear All Memory |
| `scheduler_status()` | Get Scheduler Status |
| `health()` | Health Check |

## License

MIT
