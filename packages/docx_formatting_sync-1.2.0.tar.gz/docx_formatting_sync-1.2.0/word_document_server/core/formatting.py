"""
Core formatting utilities for paragraph-level operations.

These utilities support the docx-sync-mcp tools with word-count validation.
"""
from functools import wraps
from typing import Dict, Any, Optional, Tuple, List
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH


def count_words(text: str) -> int:
    """Count words in text (split by whitespace)."""
    return len(text.split())


def validate_word_count_unchanged(operation_name: str):
    """Decorator that validates word count doesn't change during an operation."""
    def decorator(func):
        @wraps(func)
        def wrapper(filename: str, paragraph_index: int, *args, **kwargs):
            # Load document and get word count before
            doc = Document(filename)
            if paragraph_index < 0 or paragraph_index >= len(doc.paragraphs):
                raise ValueError(f"Invalid paragraph index {paragraph_index}. Document has {len(doc.paragraphs)} paragraphs.")

            para = doc.paragraphs[paragraph_index]
            text_before = para.text
            words_before = count_words(text_before)

            # Perform the operation
            result = func(filename, paragraph_index, *args, **kwargs)

            # Reload and validate word count after
            doc = Document(filename)
            para = doc.paragraphs[paragraph_index]
            text_after = para.text
            words_after = count_words(text_after)

            if text_before != text_after:
                raise ValueError(
                    f"{operation_name}: Text content changed! "
                    f"Length: {len(text_before)} → {len(text_after)}. "
                    f"This should never happen during formatting."
                )

            if words_before != words_after:
                raise ValueError(
                    f"{operation_name}: Word count changed from {words_before} to {words_after}. "
                    f"Formatting must not change word count."
                )

            return result
        return wrapper
    return decorator


def normalize_paragraph_runs(paragraph) -> None:
    """
    Consolidate all runs in a paragraph into a single run.

    This is necessary because python-docx creates fragmented runs
    when text is added incrementally. Normalizing allows us to apply
    formatting uniformly.

    Args:
        paragraph: A docx paragraph object
    """
    full_text = paragraph.text

    # Remove all existing runs
    for run in list(paragraph.runs):
        run._element.getparent().remove(run._element)

    # Create a single new run with the full text
    if full_text:
        paragraph.add_run(full_text)


def extract_paragraph_formatting(paragraph) -> Dict[str, Any]:
    """
    Extract all formatting properties from a paragraph.

    Args:
        paragraph: A docx paragraph object

    Returns:
        Dict containing all formatting properties
    """
    para_format = paragraph.paragraph_format
    formatting = {
        'style': paragraph.style.name if paragraph.style else None,
        'alignment': paragraph.alignment,
        'space_before': para_format.space_before,
        'space_after': para_format.space_after,
        'line_spacing': para_format.line_spacing,
        'line_spacing_rule': para_format.line_spacing_rule,
    }

    # Get run-level formatting from the first run
    if paragraph.runs:
        run = paragraph.runs[0]
        font = run.font
        formatting.update({
            'font_name': font.name,
            'font_size': font.size.pt if font.size else None,
            'bold': run.bold,
            'italic': run.italic,
            'underline': run.underline,
            'color': font.color.rgb if font.color and font.color.rgb else None,
        })

    return formatting


def analyze_run_formatting(paragraph) -> List[Dict[str, Any]]:
    """
    Analyze formatting of each run in a paragraph.

    Returns a list of formatting info for each run.
    """
    run_formats = []
    for run in paragraph.runs:
        run_formats.append({
            'text': run.text,
            'bold': run.bold,
            'italic': run.italic,
            'underline': run.underline,
            'font_name': run.font.name,
            'font_size': run.font.size.pt if run.font.size else None,
        })
    return run_formats


def detect_mixed_formatting(paragraph) -> Tuple[bool, Dict[str, Any]]:
    """
    Detect if a paragraph has mixed formatting (e.g., bold first word, normal body).

    Returns:
        Tuple of (has_mixed_formatting, pattern_info)
    """
    if not paragraph.runs or len(paragraph.runs) < 2:
        return False, {}

    run_formats = analyze_run_formatting(paragraph)

    # Check for bold patterns
    bold_runs = [i for i, rf in enumerate(run_formats) if rf['bold']]
    non_bold_runs = [i for i, rf in enumerate(run_formats) if not rf['bold']]

    pattern = {
        'bold_runs': bold_runs,
        'non_bold_runs': non_bold_runs,
        'has_bold': len(bold_runs) > 0,
        'has_mixed_bold': len(bold_runs) > 0 and len(non_bold_runs) > 0,
        'first_run_bold': run_formats[0]['bold'] if run_formats else False,
        'default_font': run_formats[0]['font_name'] if run_formats else None,
        'default_size': run_formats[0]['font_size'] if run_formats else None,
    }

    return pattern['has_mixed_bold'], pattern


def apply_paragraph_formatting(
    paragraph,
    font_name: Optional[str] = None,
    font_size: Optional[int] = None,
    bold: Optional[bool] = None,
    italic: Optional[bool] = None,
    underline: Optional[bool] = None,
    color: Optional[str] = None,
    line_spacing: Optional[float] = None,
) -> None:
    """
    Apply formatting to all runs in a paragraph.

    Args:
        paragraph: A docx paragraph object
        font_name: Font family (e.g., 'Times New Roman')
        font_size: Font size in points
        bold: Set text bold (True/False)
        italic: Set text italic (True/False)
        underline: Set text underlined (True/False)
        color: Text color as hex RGB (e.g., '000000' for black, 'FF0000' for red)
        line_spacing: Line spacing value (480 = double, 360 = 1.5, 240 = single)
    """
    # Apply paragraph-level formatting
    if line_spacing is not None:
        paragraph.paragraph_format.line_spacing = line_spacing

    # Apply run-level formatting to all runs
    for run in paragraph.runs:
        if font_name is not None:
            run.font.name = font_name
        if font_size is not None:
            run.font.size = Pt(font_size)
        if bold is not None:
            run.bold = bold
        if italic is not None:
            run.italic = italic
        if underline is not None:
            run.underline = underline
        if color is not None:
            from docx.shared import RGBColor
            try:
                run.font.color.rgb = RGBColor.from_string(color)
            except ValueError:
                # If color string is invalid, skip it
                pass


def copy_mixed_formatting(
    source_paragraph,
    target_paragraph,
    include_style: bool = True,
    include_alignment: bool = True,
    include_spacing: bool = True,
) -> None:
    """
    Copy formatting from source to target, preserving mixed formatting patterns.

    This handles cases where:
    - First word is bold, rest is normal
    - Multiple formatting styles within paragraph

    Strategy:
    1. Copy paragraph-level properties (style, alignment, spacing)
    2. Detect default font/size from source
    3. Apply default font/size to ALL target runs
    4. Map special formatting (bold, italic) by run position
    """
    # Copy paragraph style
    if include_style and source_paragraph.style:
        target_paragraph.style = source_paragraph.style

    # Copy alignment
    if include_alignment:
        target_paragraph.alignment = source_paragraph.alignment

    # Copy spacing
    if include_spacing:
        target_paragraph.paragraph_format.line_spacing = source_paragraph.paragraph_format.line_spacing
        target_paragraph.paragraph_format.line_spacing_rule = source_paragraph.paragraph_format.line_spacing_rule
        target_paragraph.paragraph_format.space_before = source_paragraph.paragraph_format.space_before
        target_paragraph.paragraph_format.space_after = source_paragraph.paragraph_format.space_after

    if not source_paragraph.runs or not target_paragraph.runs:
        return

    # Analyze source formatting
    source_formats = analyze_run_formatting(source_paragraph)
    has_mixed, pattern = detect_mixed_formatting(source_paragraph)

    # Determine default font/size from source (use first run as default)
    default_font = source_formats[0]['font_name'] if source_formats else None
    default_size = source_formats[0]['font_size'] if source_formats else None

    # Apply default font/size to ALL target runs
    for target_run in target_paragraph.runs:
        if default_font:
            target_run.font.name = default_font
        if default_size:
            target_run.font.size = Pt(default_size)

    if has_mixed:
        # Apply special formatting by position
        for i, target_run in enumerate(target_paragraph.runs):
            if i < len(source_formats):
                # Copy formatting from corresponding source run
                source_fmt = source_formats[i]
                if source_fmt['bold'] is not None:
                    target_run.bold = source_fmt['bold']
                if source_fmt['italic'] is not None:
                    target_run.italic = source_fmt['italic']
                if source_fmt['underline'] is not None:
                    target_run.underline = source_fmt['underline']
            else:
                # For extra target runs, use the last source run's formatting
                # or clear special formatting
                last_source_fmt = source_formats[-1]
                if last_source_fmt['bold'] is not None:
                    target_run.bold = last_source_fmt['bold']
    else:
        # Uniform formatting - apply first run's formatting to all
        first_source = source_formats[0]
        for target_run in target_paragraph.runs:
            if first_source['bold'] is not None:
                target_run.bold = first_source['bold']
            if first_source['italic'] is not None:
                target_run.italic = first_source['italic']
            if first_source['underline'] is not None:
                target_run.underline = first_source['underline']


def copy_formatting_between_paragraphs(
    source_paragraph,
    target_paragraph,
    include_style: bool = True,
    include_alignment: bool = True,
    include_spacing: bool = True,
) -> None:
    """
    Copy all formatting from source paragraph to target paragraph.

    DEPRECATED: Use copy_mixed_formatting instead.
    This function is kept for backward compatibility.
    """
    copy_mixed_formatting(
        source_paragraph,
        target_paragraph,
        include_style=include_style,
        include_alignment=include_alignment,
        include_spacing=include_spacing,
    )


def format_first_word_of_paragraph(
    paragraph,
    font_name: Optional[str] = None,
    font_size: Optional[int] = None,
    bold: Optional[bool] = None,
    italic: Optional[bool] = None,
) -> None:
    """
    Format only the first word of a paragraph.

    Args:
        paragraph: A docx paragraph object
        font_name: Font family
        font_size: Font size in points
        bold: Set text bold
        italic: Set text italic
    """
    text = paragraph.text
    if not text:
        return

    # Find the first word (sequence of non-whitespace characters)
    words = text.split()
    if not words:
        return

    first_word = words[0]
    first_word_len = len(first_word)

    # Find where the first word ends
    # Handle leading whitespace
    start_idx = 0
    while start_idx < len(text) and text[start_idx].isspace():
        start_idx += 1

    end_idx = start_idx + first_word_len

    # Now format the runs that contain the first word
    current_pos = 0
    for run in paragraph.runs:
        run_text = run.text
        run_len = len(run_text)
        run_start = current_pos
        run_end = current_pos + run_len

        # Check if this run overlaps with the first word
        if run_start < end_idx and run_end > start_idx:
            # This run contains part of the first word
            if font_name is not None:
                run.font.name = font_name
            if font_size is not None:
                run.font.size = Pt(font_size)
            if bold is not None:
                run.bold = bold
            if italic is not None:
                run.italic = italic

        current_pos += run_len


def compare_paragraph_formatting(para1, para2) -> Tuple[bool, Dict[str, Any]]:
    """
    Compare formatting between two paragraphs.

    Args:
        para1: First paragraph
        para2: Second paragraph

    Returns:
        Tuple of (are_equal, differences_dict)
    """
    fmt1 = extract_paragraph_formatting(para1)
    fmt2 = extract_paragraph_formatting(para2)

    differences = {}
    for key in fmt1:
        if fmt1[key] != fmt2[key]:
            differences[key] = {'reference': fmt1[key], 'target': fmt2[key]}

    # Also compare run-level formatting
    runs1 = analyze_run_formatting(para1)
    runs2 = analyze_run_formatting(para2)

    if len(runs1) != len(runs2):
        differences['run_count'] = {'reference': len(runs1), 'target': len(runs2)}

    # Compare first few runs
    min_runs = min(len(runs1), len(runs2))
    for i in range(min_runs):
        run_diff = {}
        for key in ['bold', 'italic', 'font_name', 'font_size']:
            if runs1[i].get(key) != runs2[i].get(key):
                run_diff[key] = {'reference': runs1[i].get(key), 'target': runs2[i].get(key)}
        if run_diff:
            differences[f'run_{i}'] = run_diff

    return len(differences) == 0, differences
