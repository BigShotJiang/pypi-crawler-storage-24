# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ...._models import BaseModel
from ..edgar_document import EdgarDocument
from ..edgar_filing_full import EdgarFilingFull

__all__ = ["DocumentRetrieveResponse", "DocumentRetrieveResponseToc"]


class DocumentRetrieveResponseToc(BaseModel):
    """A section of the table of contents."""

    heading_level: int
    """The depth of the heading (1 for top-level, 2 for sub-section, etc.)."""

    page_idx: int
    """The 0-based page index where this section begins."""

    title: str
    """The heading text of this section."""


class DocumentRetrieveResponse(EdgarDocument):
    """An EDGAR document with the full parent filing attached."""

    filing: EdgarFilingFull
    """The parent filing that contains this document."""

    toc: List[DocumentRetrieveResponseToc]
    """The table of contents of the document."""
