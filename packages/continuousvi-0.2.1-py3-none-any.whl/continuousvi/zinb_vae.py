"""
Zero-Inflated Negative Binomial VAE for count data with covariate modeling.

Key features:
- Covariate (age) input to encoder: creates age-conditioned latent Z
- Gene-specific W_age in decoder: preserves age effects per gene
- ZINB likelihood for count data

Architecture:
    Encoder: (X, age) → Z_nonage (age-conditioned latent, age info factored out)
    Decoder: (Z_nonage, age) → μ_g = f(Z_nonage) + W_age[g] * age
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple, Optional


class ZINBVAE(nn.Module):
    """
    Zero-Inflated Negative Binomial VAE with covariate modeling.

    Architecture:
        Encoder: (X, covariate) → z (covariate-conditioned latent)
        Decoder: (z, covariate) → px_scale + W_cov * covariate

    The W_cov (gene-specific covariate weights) allows the model to:
    - Factor out covariate effects from z (z becomes covariate-free)
    - Preserve gene-specific covariate effects via W_cov
    - DE genes will have large |W_cov|, Non-DE genes will have small |W_cov|
    """

    def __init__(
        self,
        n_genes: int,
        n_latent: int = 30,
        n_hidden: int = 128,
        n_covariates: int = 1,  # Number of continuous covariates (e.g., age)
    ):
        super().__init__()
        self.n_genes = n_genes
        self.n_latent = n_latent
        self.n_hidden = n_hidden
        self.n_covariates = n_covariates

        # Encoder: (X, covariate) → z
        # Input: n_genes + n_covariates
        self.encoder = nn.Sequential(
            nn.Linear(n_genes + n_covariates, n_hidden),
            nn.BatchNorm1d(n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.BatchNorm1d(n_hidden),
            nn.ReLU(),
        )
        self.fc_mu = nn.Linear(n_hidden, n_latent)
        self.fc_logvar = nn.Linear(n_hidden, n_latent)

        # Decoder: z → ZINB parameters (base, without covariate effect)
        self.decoder = nn.Sequential(
            nn.Linear(n_latent, n_hidden),
            nn.BatchNorm1d(n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.BatchNorm1d(n_hidden),
            nn.ReLU(),
        )

        # Base expression (from z only)
        self.px_scale_decoder = nn.Linear(n_hidden, n_genes)

        # W_cov: Gene-specific covariate effect weights
        # Shape: (n_genes, n_covariates)
        # For each gene g: effect_g = W_cov[g] * covariate
        self.W_cov = nn.Parameter(torch.zeros(n_genes, n_covariates))

        # Initialize W_cov with small values
        nn.init.normal_(self.W_cov, mean=0.0, std=0.01)

        # Dispersion parameter (per-gene)
        self.px_r = nn.Parameter(torch.randn(n_genes))

        # Dropout logits
        self.px_dropout_decoder = nn.Linear(n_hidden, n_genes)

    def encode(
        self,
        x: torch.Tensor,
        covariate: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Encode counts to latent distribution parameters.

        Parameters
        ----------
        x : torch.Tensor, shape (n_cells, n_genes)
            Input counts (normalized or raw)
        covariate : torch.Tensor, shape (n_cells, n_covariates), optional
            Continuous covariate(s). If None, zeros are used.

        Returns
        -------
        mu, logvar : torch.Tensor, shape (n_cells, n_latent)
            Latent distribution parameters
        """
        if covariate is None:
            covariate = torch.zeros(x.shape[0], self.n_covariates, device=x.device)

        # Concatenate x and covariate
        x_cov = torch.cat([x, covariate], dim=-1)

        h = self.encoder(x_cov)
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar

    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
        """Reparameterization trick."""
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(
        self,
        z: torch.Tensor,
        covariate: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """
        Decode latent to ZINB parameters with covariate effect.

        The mean is: μ_g = softplus(base_g + W_cov[g] * covariate)
        where base_g comes from z, and W_cov[g] is gene-specific.

        Parameters
        ----------
        z : torch.Tensor, shape (n_cells, n_latent)
            Latent representations (covariate-free due to encoder conditioning)
        covariate : torch.Tensor, shape (n_cells, n_covariates), optional
            Continuous covariate(s)

        Returns
        -------
        px_scale : torch.Tensor, shape (n_cells, n_genes)
            Mean parameter (includes covariate effect)
        px_r : torch.Tensor, shape (n_genes,)
            Dispersion parameter
        px_dropout : torch.Tensor, shape (n_cells, n_genes)
            Zero-inflation probability
        W_cov : torch.Tensor, shape (n_genes, n_covariates)
            Gene-specific covariate weights (for DE analysis)
        """
        h = self.decoder(z)

        # Base expression from z (covariate-free)
        base_logit = self.px_scale_decoder(h)  # (n_cells, n_genes)

        # Add covariate effect: W_cov[g] * covariate for each gene
        if covariate is not None:
            # covariate: (n_cells, n_covariates)
            # W_cov: (n_genes, n_covariates)
            # cov_effect: (n_cells, n_genes)
            cov_effect = torch.matmul(covariate, self.W_cov.t())  # (n_cells, n_genes)
            px_logit = base_logit + cov_effect
        else:
            px_logit = base_logit

        # Apply softplus for positive scale, then softmax for normalization
        px_scale = F.softplus(px_logit)
        px_scale = px_scale / (px_scale.sum(dim=-1, keepdim=True) + 1e-8)

        # Dispersion (positive)
        px_r = torch.exp(self.px_r)

        # Dropout probability
        px_dropout = self.px_dropout_decoder(h)

        return {
            'px_scale': px_scale,
            'px_r': px_r,
            'px_dropout': px_dropout,
            'W_cov': self.W_cov,  # Return for DE analysis
        }

    def forward(
        self,
        x: torch.Tensor,
        covariate: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """Full forward pass."""
        mu, logvar = self.encode(x, covariate)
        z = self.reparameterize(mu, logvar)
        px_dict = self.decode(z, covariate)

        return {
            'mu': mu,
            'logvar': logvar,
            'z': z,
            **px_dict,
        }

    def get_covariate_weights(self) -> torch.Tensor:
        """
        Get gene-specific covariate weights (W_cov).

        These weights represent the effect of covariate on each gene:
        - Large |W_cov[g]| → gene g has strong covariate effect (DE gene)
        - Small |W_cov[g]| → gene g has weak covariate effect (Non-DE gene)

        Returns
        -------
        W_cov : torch.Tensor, shape (n_genes, n_covariates)
            Gene-specific covariate weights
        """
        return self.W_cov.detach()

    @staticmethod
    def zinb_log_likelihood(
        x: torch.Tensor,
        px_scale: torch.Tensor,
        px_r: torch.Tensor,
        px_dropout: torch.Tensor,
        eps: float = 1e-8,
    ) -> torch.Tensor:
        """
        Zero-Inflated Negative Binomial log-likelihood.

        Parameters
        ----------
        x : torch.Tensor, shape (n_cells, n_genes)
            Observed counts
        px_scale : torch.Tensor, shape (n_cells, n_genes)
            Mean parameter
        px_r : torch.Tensor, shape (n_genes,)
            Dispersion parameter
        px_dropout : torch.Tensor, shape (n_cells, n_genes)
            Zero-inflation logits

        Returns
        -------
        log_likelihood : torch.Tensor, shape (n_cells,)
            Log-likelihood per cell
        """
        # Compute mean
        mu = px_scale

        # Negative binomial log-likelihood
        theta = px_r
        log_theta_mu_eps = torch.log(theta + mu + eps)

        # lgamma(x + theta) - lgamma(theta) - lgamma(x + 1)
        log_nb_positive = (
            torch.lgamma(x + theta)
            - torch.lgamma(theta)
            - torch.lgamma(x + 1.0)
            + theta * (torch.log(theta + eps) - log_theta_mu_eps)
            + x * (torch.log(mu + eps) - log_theta_mu_eps)
        )

        # Zero-inflated part
        log_nb_zero = theta * (torch.log(theta + eps) - log_theta_mu_eps)

        # Combine with zero-inflation
        pi = torch.sigmoid(px_dropout)
        zero_case = F.softplus(-px_dropout) + log_nb_zero
        non_zero_case = -px_dropout + log_nb_positive

        # Select based on whether x is zero
        mask = (x < eps).float()
        log_likelihood = mask * zero_case + (1.0 - mask) * non_zero_case

        # Sum over genes, return per cell
        return log_likelihood.sum(dim=-1)

    def loss_function(
        self,
        x: torch.Tensor,
        mu: torch.Tensor,
        logvar: torch.Tensor,
        px_scale: torch.Tensor,
        px_r: torch.Tensor,
        px_dropout: torch.Tensor,
        beta: float = 1.0,
        l1_lambda: float = 0.01,  # L1 regularization on W_cov for sparsity
    ) -> Dict[str, torch.Tensor]:
        """
        Compute ZINB VAE loss with L1 regularization on W_cov.

        Parameters
        ----------
        x : torch.Tensor
            Input counts
        mu, logvar : torch.Tensor
            Latent distribution parameters
        px_scale, px_r, px_dropout : torch.Tensor
            ZINB distribution parameters
        beta : float
            KL divergence weight (for β-VAE)
        l1_lambda : float
            L1 regularization weight on W_cov (encourages sparsity)
            Higher values → more genes with W_cov ≈ 0 (Non-DE)

        Returns
        -------
        loss_dict : dict
            'loss': total loss
            'recon_loss': reconstruction loss
            'kl_loss': KL divergence
            'l1_loss': L1 regularization on W_cov
        """
        # Reconstruction loss (negative log-likelihood)
        log_likelihood = self.zinb_log_likelihood(x, px_scale, px_r, px_dropout)
        recon_loss = -log_likelihood.mean()

        # KL divergence
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp(), dim=-1).mean()

        # L1 regularization on W_cov (encourages sparsity for Non-DE genes)
        l1_loss = self.W_cov.abs().mean()

        # Total loss
        loss = recon_loss + beta * kl_loss + l1_lambda * l1_loss

        return {
            'loss': loss,
            'recon_loss': recon_loss,
            'kl_loss': kl_loss,
            'l1_loss': l1_loss,
        }


class GaussianVAE(nn.Module):
    """
    Gaussian VAE for Pearson residual data with covariate modeling.

    Similar to ZINBVAE but uses Gaussian reconstruction loss.
    Suitable for data that has been Pearson-residual transformed.
    """

    def __init__(
        self,
        n_genes: int,
        n_latent: int = 30,
        n_hidden: int = 128,
        n_covariates: int = 1,
    ):
        super().__init__()
        self.n_genes = n_genes
        self.n_latent = n_latent
        self.n_hidden = n_hidden
        self.n_covariates = n_covariates

        # Encoder: (X, covariate) → z
        self.encoder = nn.Sequential(
            nn.Linear(n_genes + n_covariates, n_hidden),
            nn.BatchNorm1d(n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.BatchNorm1d(n_hidden),
            nn.ReLU(),
        )
        self.fc_mu = nn.Linear(n_hidden, n_latent)
        self.fc_logvar = nn.Linear(n_hidden, n_latent)

        # Decoder: z → reconstructed X
        self.decoder = nn.Sequential(
            nn.Linear(n_latent, n_hidden),
            nn.BatchNorm1d(n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.BatchNorm1d(n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_genes),
        )

        # W_cov: Gene-specific covariate effect weights
        self.W_cov = nn.Parameter(torch.zeros(n_genes, n_covariates))
        nn.init.normal_(self.W_cov, mean=0.0, std=0.01)

    def encode(
        self,
        x: torch.Tensor,
        covariate: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Encode to latent distribution parameters."""
        if covariate is None:
            covariate = torch.zeros(x.shape[0], self.n_covariates, device=x.device)

        x_cov = torch.cat([x, covariate], dim=-1)
        h = self.encoder(x_cov)
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar

    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
        """Reparameterization trick."""
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(
        self,
        z: torch.Tensor,
        covariate: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """Decode latent to reconstructed expression with covariate effect."""
        # Base reconstruction from z
        x_recon = self.decoder(z)

        # Add covariate effect
        if covariate is not None:
            cov_effect = torch.matmul(covariate, self.W_cov.t())
            x_recon = x_recon + cov_effect

        return x_recon

    def forward(
        self,
        x: torch.Tensor,
        covariate: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """Full forward pass."""
        mu, logvar = self.encode(x, covariate)
        z = self.reparameterize(mu, logvar)
        x_recon = self.decode(z, covariate)

        return {
            'mu': mu,
            'logvar': logvar,
            'z': z,
            'x_recon': x_recon,
            'W_cov': self.W_cov,
        }

    def get_covariate_weights(self) -> torch.Tensor:
        """Get gene-specific covariate weights."""
        return self.W_cov.detach()

    def loss_function(
        self,
        x: torch.Tensor,
        x_recon: torch.Tensor,
        mu: torch.Tensor,
        logvar: torch.Tensor,
        beta: float = 1.0,
        l1_lambda: float = 0.01,
    ) -> Dict[str, torch.Tensor]:
        """Compute Gaussian VAE loss."""
        # Reconstruction loss (MSE)
        recon_loss = F.mse_loss(x_recon, x, reduction='mean')

        # KL divergence
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp(), dim=-1).mean()

        # L1 regularization on W_cov
        l1_loss = self.W_cov.abs().mean()

        # Total loss
        loss = recon_loss + beta * kl_loss + l1_lambda * l1_loss

        return {
            'loss': loss,
            'recon_loss': recon_loss,
            'kl_loss': kl_loss,
            'l1_loss': l1_loss,
        }
