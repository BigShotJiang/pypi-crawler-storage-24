import logging

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns
from scipy.stats import ttest_ind
from tqdm import tqdm

# ロガーの設定（必要に応じてファイル出力などを追加してください）
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    logger.addHandler(console)


def _age_effect(age: float, effect_size: float, mode: str, age_min: float = 10.0, age_max: float = 90.0) -> float:
    """年齢(age)に応じたUp/Downの効果量を計算するためのヘルパー関数。

    **重要な変更**: 年齢を[0,1]に正規化してから効果を計算します。
    これにより、ContinuousVIの学習側（tを[0,1]に正規化）と整合的になり、
    効果量が現実的な範囲（log-FC 0.2-0.8程度）に収まります。

    Parameters
    ----------
    age : float
        対象の年齢（生の値、例: 10, 30, 50, 70, 90）。
    effect_size : float
        ベースとなる効果量。正規化後のt∈[0,1]にかける係数。
    mode : str
        時間形状: "linear", "poly", "sigmoid", "peak", "decrease"
        - "linear": t に比例（単調増加）
        - "poly": t^2 に比例（加速的増加）
        - "sigmoid": ロジスティック曲線（中期で急激に変化）
        - "peak": ガウス型（中間でピーク）
        - "decrease": 1-t（単調減少）
    age_min : float
        最小年齢（デフォルト: 10）
    age_max : float
        最大年齢（デフォルト: 90）

    Returns
    -------
    float
        年齢に応じた加算すべき（または減算すべき）ログスケールの値。

    """
    # 年齢を[0,1]に正規化
    t = (age - age_min) / (age_max - age_min + 1e-8)
    t = np.clip(t, 0.0, 1.0)

    if mode == "linear":
        return effect_size * t
    if mode == "poly":
        return effect_size * (t**2)
    if mode == "sigmoid":
        # ロジスティック曲線: 1 / (1 + exp(-8*(t - 0.5)))
        return effect_size * (1.0 / (1.0 + np.exp(-8.0 * (t - 0.5))))
    if mode == "peak":
        # ガウス型: exp(-((t-0.5)^2) / (2*0.12^2))
        return effect_size * np.exp(-((t - 0.5) ** 2) / (2 * 0.12**2))
    if mode == "decrease":
        # 単調減少
        return effect_size * (1.0 - t)
    raise ValueError(f"Unknown mode: {mode}. Please use 'linear', 'poly', 'sigmoid', 'peak', or 'decrease'.")


class BatchSimulation:
    """A simulator for scRNA-seq data with batch effects and age-dependent gene expression.

    Main Features:
    --------------
    1) Assign Up/Down-regulated genes for each cell type (with respect to age).
    2) Introduce batch effects by sampling library size factors from a log-normal distribution,
       per project (batch). Also apply batch-specific dropout rates.
    3) Assign discrete ages to cells and apply log-scale Up/Down effects (linear or polynomial)
       to the expression.
    4) Generate counts using a negative binomial distribution plus dropout, stored in an AnnData object.
    5) Provide convenient functions for:
       - Visualizing raw or log1p-transformed expression across ages and batches.
       - Verifying Up/Down trends via statistical tests.
    """

    def __init__(
        self,
        n_genes: int = 1000,
        cell_types: list[str] = None,
        projects: list[str] = None,
        cells_per_combination: int = 100,
        n_up_genes_per_ct: int = 50,
        n_down_genes_per_ct: int = 50,
        effect_size_up: float = 0.6,  # Adjusted for normalized age [0,1]
        effect_size_down: float = 0.6,  # Adjusted for normalized age [0,1]
        effect_size_std: float = 0.25,  # Std for gene-wise effect size variation
        base_expr_mean: float = 3.0,
        base_expr_sd: float = 0.8,
        library_size_logmean: dict[str, float] = None,
        library_size_sigma: float = 0.3,
        dropout_rates: dict[str, float] = None,
        dispersion: float = 0.5,
        possible_ages: list[int] = None,
        random_seed: int = 42,
        age_mode: str = "linear",
        # Advanced options for harder simulations
        use_gene_specific_dispersion: bool = True,
        use_expression_dependent_dropout: bool = True,
        use_noncommutative_batch: bool = True,
        dropout_logit_intercept_range: tuple[float, float] = (-1.5, -0.5),
        dropout_logit_slope_range: tuple[float, float] = (-1.8, -0.8),
        batch_time_interaction_sigma: float = 0.15,
    ) -> None:
        """Parameters
        ----------
        n_genes : int
            Total number of genes to simulate.
        cell_types : list[str]
            List of cell type names (e.g., ["Tcell", "Bcell", "Macrophage"]).
        projects : list[str]
            List of project/batch IDs (e.g., ["A", "B"]).
        cells_per_combination : int
            Number of cells per (cell_type × project).
        n_up_genes_per_ct : int
            Number of Up-regulated genes per cell type (w.r.t. age).
        n_down_genes_per_ct : int
            Number of Down-regulated genes per cell type (w.r.t. age).
        effect_size_up : float
            Base log-scale effect size for Up genes (per unit age, if linear).
        effect_size_down : float
            Base log-scale effect size for Down genes (per unit age, if linear).
        base_expr_mean : float
            Mean of the base log-expression for all genes.
        base_expr_sd : float
            Std of the base log-expression for all genes.
        library_size_logmean : dict[str, float]
            Mean (in log space) of the log-normal distribution for library size factors (per project).
        library_size_sigma : float
            Sigma (std in log space) of the log-normal distribution for library size factors.
        dropout_rates : dict[str, float]
            Dropout rate for each project. Example: {"A": 0.05, "B": 0.1}.
        dispersion : float
            Dispersion parameter for the negative binomial distribution (1/r in NB notation).
        possible_ages : list[int]
            Possible discrete ages to assign (e.g., [10, 30, 50, 70, 90]).
        random_seed : int
            Seed for reproducibility.
        age_mode : str
            "linear" or "poly". Determines how age affects Up/Down (linear or polynomial).

        """
        if cell_types is None:
            cell_types = ["Tcell", "Bcell", "Macrophage"]
        if projects is None:
            projects = ["A", "B"]
        if library_size_logmean is None:
            # Project A は平均が大きめ、B は小さめ
            library_size_logmean = {"A": 0.3, "B": -0.3}
        if dropout_rates is None:
            dropout_rates = {"A": 0.05, "B": 0.1}
        if possible_ages is None:
            possible_ages = [10, 30, 50, 70, 90]

        np.random.seed(random_seed)

        self.n_genes = n_genes
        self.cell_types = cell_types
        self.projects = projects
        self.cells_per_combination = cells_per_combination

        self.n_up_genes_per_ct = n_up_genes_per_ct
        self.n_down_genes_per_ct = n_down_genes_per_ct
        self.effect_size_up = effect_size_up
        self.effect_size_down = effect_size_down
        self.effect_size_std = effect_size_std
        self.base_expr_mean = base_expr_mean
        self.base_expr_sd = base_expr_sd

        self.library_size_logmean = library_size_logmean
        self.library_size_sigma = library_size_sigma
        self.dropout_rates = dropout_rates
        self.dispersion = dispersion
        self.possible_ages = possible_ages
        self.age_mode = age_mode

        # Advanced options
        self.use_gene_specific_dispersion = use_gene_specific_dispersion
        self.use_expression_dependent_dropout = use_expression_dependent_dropout
        self.use_noncommutative_batch = use_noncommutative_batch
        self.dropout_logit_intercept_range = dropout_logit_intercept_range
        self.dropout_logit_slope_range = dropout_logit_slope_range
        self.batch_time_interaction_sigma = batch_time_interaction_sigma

        # ロガー出力
        logger.info("Initializing BatchSimulation with parameters:")
        logger.info(f"  cell_types={self.cell_types}, projects={self.projects}")
        logger.info(f"  library_size_logmean={self.library_size_logmean}, dropout_rates={self.dropout_rates}")
        logger.info(f"  age_mode={self.age_mode}")

        # 1) Gene names
        var_names = [f"Gene{i}" for i in range(self.n_genes)]
        np.random.shuffle(var_names)
        self.var_names = var_names  # for AnnData usage

        # 2) Assign Up/Down genes (use list[str], not set)
        self.ct_up_genes = {}
        self.ct_down_genes = {}

        idx_pos = 0
        for ct in self.cell_types:
            up_genes = var_names[idx_pos : idx_pos + n_up_genes_per_ct]
            idx_pos += n_up_genes_per_ct
            down_genes = var_names[idx_pos : idx_pos + n_down_genes_per_ct]
            idx_pos += n_down_genes_per_ct

            # dict[str, list[str]] の形で保持
            self.ct_up_genes[ct] = list(up_genes)
            self.ct_down_genes[ct] = list(down_genes)

        self.neutral_genes = list(var_names[idx_pos:])
        logger.info("=== Genes Count Summary ===")
        for ct in self.cell_types:
            logger.info(f"  {ct}: Up={len(self.ct_up_genes[ct])}, Down={len(self.ct_down_genes[ct])}")
        logger.info(f"  Neutral={len(self.neutral_genes)}")

        # 3) Base log expression
        base_expr_vals = np.random.normal(loc=self.base_expr_mean, scale=self.base_expr_sd, size=self.n_genes)
        self.base_expr_dict = dict(zip(var_names, base_expr_vals, strict=False))

        # 4) Gene-specific effect sizes (with variation)
        self.gene_effect_sizes = {}
        for ct in self.cell_types:
            for g in self.ct_up_genes[ct]:
                eff = np.clip(np.random.normal(loc=self.effect_size_up, scale=self.effect_size_std), 0.1, 1.5)
                self.gene_effect_sizes[g] = eff
            for g in self.ct_down_genes[ct]:
                eff = np.clip(np.random.normal(loc=self.effect_size_down, scale=self.effect_size_std), 0.1, 1.5)
                self.gene_effect_sizes[g] = eff

        # 5) Gene-specific NB dispersion (if enabled)
        if self.use_gene_specific_dispersion:
            # Sample alpha_g from Gamma(k, theta) where mean = k*theta = 0.2, variance = k*theta^2
            # Using k=2, theta=0.1 gives mean=0.2, SD=0.14
            alpha_g = np.clip(np.random.gamma(shape=2.0, scale=0.1, size=self.n_genes), 0.05, 0.6)
            self.gene_dispersions = 1.0 / alpha_g  # r_g = 1/alpha_g for NB
        else:
            self.gene_dispersions = np.full(self.n_genes, 1.0 / self.dispersion)

        # 6) Batch-specific dropout parameters (if expression-dependent)
        if self.use_expression_dependent_dropout:
            self.dropout_logit_intercepts = {}
            self.dropout_logit_slopes = {}
            for proj in self.projects:
                a = np.random.uniform(*self.dropout_logit_intercept_range)
                b = np.random.uniform(*self.dropout_logit_slope_range)
                self.dropout_logit_intercepts[proj] = a
                self.dropout_logit_slopes[proj] = b

        # 7) Non-commutative batch effects (batch × time interaction)
        if self.use_noncommutative_batch:
            # gamma_{b,g}: batch-specific gene effects that interact with time
            self.batch_time_effects = {}
            for proj in self.projects:
                gamma_bg = np.random.normal(0.0, self.batch_time_interaction_sigma, size=self.n_genes)
                self.batch_time_effects[proj] = gamma_bg

        # NB generator function
        def nb_generator(
            log_expr_array: np.ndarray,
            lib_factors: np.ndarray,
            dropout_rate: float,
            proj: str,
        ) -> np.ndarray:
            """Generate count data using a negative binomial distribution, then apply dropout."""
            n_cells = log_expr_array.shape[0]
            mu = np.exp(log_expr_array) * lib_factors[:, None]

            # Use gene-specific dispersion
            r_genes = self.gene_dispersions  # shape: (n_genes,)
            p = r_genes[None, :] / (r_genes[None, :] + mu)  # shape: (n_cells, n_genes)
            mat = np.random.negative_binomial(n=r_genes[None, :], p=p)

            # Dropout: expression-dependent if enabled
            if self.use_expression_dependent_dropout:
                # p_dropout = sigmoid(a + b * log1p(mu))
                log_mu = np.log1p(mu)
                a = self.dropout_logit_intercepts[proj]
                b = self.dropout_logit_slopes[proj]
                logit = a + b * log_mu
                p_dropout = 1.0 / (1.0 + np.exp(-logit))
                drop_mask = np.random.rand(*mat.shape) < p_dropout
            else:
                drop_mask = np.random.rand(*mat.shape) < dropout_rate

            mat[drop_mask] = 0
            return mat

        name_to_idx = {g: i for i, g in enumerate(var_names)}

        # 4) Generate cells per (project × cell_type)
        all_mats = []
        all_obs = []

        for proj in tqdm(self.projects, desc="Project loop"):
            drop_rate = self.dropout_rates[proj]

            for ct in tqdm(self.cell_types, desc="CellType loop", leave=False):
                n_cells = self.cells_per_combination

                # log-normal sampling for library size factors
                lib_factors = np.random.lognormal(mean=self.library_size_logmean[proj], sigma=self.library_size_sigma, size=n_cells)

                # Assign ages
                ages = np.random.choice(self.possible_ages, size=n_cells)

                # Base log expression
                base_vec = np.array([self.base_expr_dict[g] for g in var_names], dtype=float)

                # shape = (n_cells, n_genes)
                log_expr_array = np.tile(base_vec, (n_cells, 1))

                # Age range for normalization
                age_min, age_max = min(self.possible_ages), max(self.possible_ages)

                # Up/Down effect (using gene-specific effect sizes)
                up_list = self.ct_up_genes[ct]
                down_list = self.ct_down_genes[ct]

                for i in range(n_cells):
                    age_i = ages[i]
                    # Up genes
                    for g_up in up_list:
                        idx_g = name_to_idx[g_up]
                        # Use gene-specific effect size
                        eff_size = self.gene_effect_sizes.get(g_up, self.effect_size_up)
                        up_val = _age_effect(age_i, eff_size, self.age_mode, age_min, age_max)
                        log_expr_array[i, idx_g] += up_val
                    # Down genes
                    for g_down in down_list:
                        idx_g = name_to_idx[g_down]
                        # Use gene-specific effect size
                        eff_size = self.gene_effect_sizes.get(g_down, self.effect_size_down)
                        down_val = _age_effect(age_i, eff_size, self.age_mode, age_min, age_max)
                        # Downなのでマイナス
                        log_expr_array[i, idx_g] -= down_val

                # Non-commutative batch effects (batch × time interaction)
                if self.use_noncommutative_batch:
                    # Add batch-time interaction: gamma_{b,g} * h(t)
                    # Normalize ages to [0,1] for time function
                    t_normalized = (ages - age_min) / (age_max - age_min + 1e-8)
                    # h(t) = t (linear) or sin(2πt) (periodic)
                    # Randomly choose for each batch
                    if np.random.rand() < 0.7:
                        h_t = t_normalized  # Linear
                    else:
                        h_t = np.sin(2 * np.pi * t_normalized)  # Periodic
                    # Add interaction: log_expr += gamma_{b,g} * h(t_i)
                    gamma_bg = self.batch_time_effects[proj]
                    log_expr_array += h_t[:, None] * gamma_bg[None, :]

                # Negative binomial + dropout
                mat = nb_generator(log_expr_array, lib_factors, drop_rate, proj)

                # obs chunk
                obs_chunk = pd.DataFrame({"project_id": [proj] * n_cells, "cell_type": [ct] * n_cells, "age": ages})

                all_mats.append(mat)
                all_obs.append(obs_chunk)

        # Combine
        X = np.vstack(all_mats)
        obs = pd.concat(all_obs, ignore_index=True)
        var = pd.DataFrame(index=var_names)

        self.adata = sc.AnnData(X=X, obs=obs, var=var)
        logger.info("=== Final AnnData ===")
        logger.info(self.adata)

        # 不要になった up_gene_to_ct / down_gene_to_ct は廃止
        # （必要ならここでct_up_genes, ct_down_genesを見れば良い）

    def plot_genes_by_age(self, genes: list[str], with_regline: bool = True, use_log: bool = False) -> None:
        """Plot the specified genes' expression against discrete ages and across batches.
        No min-max scaling is applied, so absolute differences are visible.

        Parameters
        ----------
        genes : list[str]
            List of gene names to plot.
        with_regline : bool
            Whether to include a regression line (lowess) in the plot.
        use_log : bool
            Whether to use log1p(count) for expression to_numpy().

        """
        sub_adata = self.adata[:, genes].copy()
        df_expr = sub_adata.to_df()

        if use_log:
            df_expr = np.log1p(df_expr)

        df_expr["age"] = sub_adata.obs["age"].to_numpy()
        df_expr["project_id"] = sub_adata.obs["project_id"].to_numpy()
        df_expr["cell_type"] = sub_adata.obs["cell_type"].to_numpy()

        df_melt = df_expr.melt(id_vars=["age", "project_id", "cell_type"], var_name="gene", value_name="expr")

        if with_regline:
            g = sns.lmplot(
                data=df_melt,
                x="age",
                y="expr",
                col="project_id",
                row="cell_type",
                scatter=True,
                fit_reg=True,
                lowess=True,
                hue="cell_type",
                scatter_kws=dict(s=20, alpha=0.5),
                height=3,
                aspect=1.3,
            )
            g.set_titles(row_template="{row_name}", col_template="Project {col_name}")
            y_label = "log1p(Expression)" if use_log else "Expression (raw)"
            g.set_axis_labels("Age", y_label)
            plt.tight_layout()
            # plt.show()
        else:
            g = sns.relplot(
                data=df_melt,
                x="age",
                y="expr",
                col="project_id",
                row="cell_type",
                hue="cell_type",
                kind="scatter",
                height=3,
                aspect=1.3,
            )
            g.set_titles(row_template="{row_name}", col_template="Project {col_name}")
            y_label = "log1p(Expression)" if use_log else "Expression (raw)"
            g.set_axis_labels("Age", y_label)
            plt.tight_layout()
            # plt.show()

    def plot_boxplot_by_batch(self, genes: list[str], use_log: bool = False) -> None:
        """Show a boxplot for each gene, separated by project_id (batch), allowing
        direct visualization of batch effects (library size differences, etc.).

        Parameters
        ----------
        genes : list[str]
            List of genes to plot.
        use_log : bool
            Whether to use log1p for expression to_numpy().

        """
        sub_adata = self.adata[:, genes].copy()
        df_expr = sub_adata.to_df()

        if use_log:
            df_expr = np.log1p(df_expr)

        df_expr["project_id"] = sub_adata.obs["project_id"].to_numpy()
        df_expr["cell_type"] = sub_adata.obs["cell_type"].to_numpy()

        df_melt = df_expr.melt(id_vars=["project_id", "cell_type"], var_name="gene", value_name="expr")

        plt.figure(figsize=(8, 5))
        sns.boxplot(data=df_melt, x="project_id", y="expr", hue="gene", showfliers=False)
        y_label = "log1p(Expression)" if use_log else "Expression (raw)"
        plt.ylabel(y_label)
        plt.title("Batch-wise Boxplot")
        plt.tight_layout()
        # plt.show()

    def verify_simulation(self, alpha=0.05) -> None:
        """Verify the simulation by comparing expression at min_age vs. max_age
        for each Up/Down gene using a t-test.

        - Up genes: Check if the expression at max_age is significantly higher than at min_age.
        - Down genes: Check if the expression at max_age is significantly lower than at min_age.

        Parameters
        ----------
        alpha : float
            Significance level for the t-test.

        """
        adata = self.adata
        all_ages = sorted(adata.obs["age"].unique())
        min_age, max_age = all_ages[0], all_ages[-1]

        X = adata.X.A if hasattr(adata.X, "A") else adata.X

        up_correct = 0
        up_total = 0
        for ct in self.cell_types:
            up_genes = self.ct_up_genes[ct]
            for g in up_genes:
                if g not in adata.var_names:
                    continue
                g_idx = adata.var_names.get_loc(g)

                ct_mask = (adata.obs["cell_type"] == ct).to_numpy()
                expr_ct = X[ct_mask, g_idx]

                min_mask = (adata.obs.loc[ct_mask, "age"] == min_age).to_numpy()
                expr_min = expr_ct[min_mask]

                max_mask = (adata.obs.loc[ct_mask, "age"] == max_age).to_numpy()
                expr_max = expr_ct[max_mask]

                if len(expr_min) > 1 and len(expr_max) > 1:
                    up_total += 1
                    stat, pval = ttest_ind(expr_max, expr_min, equal_var=False)
                    mean_diff = expr_max.mean() - expr_min.mean()
                    if (pval < alpha) and (mean_diff > 0):
                        up_correct += 1

        down_correct = 0
        down_total = 0
        for ct in self.cell_types:
            down_genes = self.ct_down_genes[ct]
            for g in down_genes:
                if g not in adata.var_names:
                    continue
                g_idx = adata.var_names.get_loc(g)

                ct_mask = (adata.obs["cell_type"] == ct).to_numpy()
                expr_ct = X[ct_mask, g_idx]

                min_mask = (adata.obs.loc[ct_mask, "age"] == min_age).to_numpy()
                expr_min = expr_ct[min_mask]

                max_mask = (adata.obs.loc[ct_mask, "age"] == max_age).to_numpy()
                expr_max = expr_ct[max_mask]

                if len(expr_min) > 1 and len(expr_max) > 1:
                    down_total += 1
                    stat, pval = ttest_ind(expr_min, expr_max, equal_var=False)
                    mean_diff = expr_min.mean() - expr_max.mean()
                    if (pval < alpha) and (mean_diff > 0):
                        down_correct += 1

        logger.info(f"[Verification: Up genes] {up_correct}/{up_total} genes showed a significant increase at age {max_age} vs. {min_age} (p<{alpha}).")
        logger.info(f"[Verification: Down genes] {down_correct}/{down_total} genes showed a significant decrease at age {max_age} vs. {min_age} (p<{alpha}).")
