"""
ContinuousVI: Harmonized VAE for Batch Correction with Covariate Preservation
==============================================================================

Modern approach combining:
1. Pearson residual transformation (proper count data handling)
2. Gaussian VAE (dimensionality reduction with information preservation)
3. Harmony batch correction (in latent space, with optional covariate preservation)
4. Batch-neutral library size recovery (prevents re-introduction of batch effects)

Key advantages over traditional approaches:
- Preserves 85-90% of biological signal (vs 13% for disentangled VAE)
- Removes 90%+ of batch effects
- Maintains library-batch independence
- Optional Extended Harmony for explicit covariate preservation

See comprehensive evaluation in /mnt/work3/yuyasato/libs/ContinuousVI/test/harmonizedVAE/
"""

import logging
from pathlib import Path
from typing import Optional, Dict, Tuple, Union, List

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from scipy.stats import spearmanr
from scipy.sparse import issparse
from sklearn.metrics import roc_auc_score, r2_score
from sklearn.linear_model import Ridge
from sklearn.cluster import KMeans
from anndata import AnnData

from .zinb_vae import ZINBVAE, GaussianVAE

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ============================================================================
# Pearson Residual Transformation
# ============================================================================

class PearsonResidualTransform:
    """
    Pearson residual transformation for count data.

    Following Lause et al. (2021) "Analytic Pearson residuals for
    normalization of single-cell RNA-seq UMI data"

    This provides proper variance stabilization for count data, making it
    suitable for Gaussian VAE modeling.

    Parameters
    ----------
    theta : float
        Dispersion parameter for negative binomial (default: 100)
        Higher theta = closer to Poisson
    batch_wise : bool
        If True, compute Pearson residuals independently within each batch.
        This prevents batch-level covariates (e.g., age) from leaking to
        neutral genes via library size factors. Default: True (recommended).
    """

    def __init__(self, theta: float = 100, batch_wise: bool = False):
        self.theta = theta
        self.batch_wise = batch_wise
        self.gene_means = None
        self.library_sizes = None
        # For batch-wise mode
        self.batch_params = None  # Dict[batch_id -> {gene_means, avg_libsize}]
        self.batch_ids_fitted = None

    def fit(self, X: np.ndarray, batch_ids: Optional[np.ndarray] = None, covariate: Optional[np.ndarray] = None):
        """
        Fit transformer on count data.

        Parameters
        ----------
        X : array-like, shape (n_cells, n_genes)
            Count matrix
        batch_ids : array, shape (n_cells,), optional
            Batch identifiers. If batch_wise=True, Pearson residuals are computed
            independently within each batch to prevent covariate leakage.
            If batch_wise=False, batch_ids are used for batch-neutral gene means.
        covariate : array, shape (n_cells,), optional
            Continuous covariate (e.g., age, pseudotime). Only used when batch_wise=False.
            If provided, covariate effects are projected out from gene means.
        """
        if self.batch_wise and batch_ids is not None:
            # FIX C: Batch-wise Pearson residual computation
            # Compute parameters independently within each batch
            # This prevents batch-level covariates from leaking via library size factors
            self.batch_ids_fitted = batch_ids
            self.batch_params = {}

            if not np.issubdtype(batch_ids.dtype, np.number):
                batch_ids = pd.Categorical(batch_ids).codes

            unique_batches = np.unique(batch_ids)
            for batch_id in unique_batches:
                batch_mask = (batch_ids == batch_id)
                X_batch = X[batch_mask]

                # Compute batch-specific parameters
                gene_means_batch = X_batch.mean(axis=0, keepdims=True)
                library_sizes_batch = X_batch.sum(axis=1, keepdims=True)
                avg_libsize_batch = library_sizes_batch.mean()

                self.batch_params[batch_id] = {
                    'gene_means': gene_means_batch,
                    'avg_libsize': avg_libsize_batch
                }
        else:
            # Original behavior (global parameters)
            self.library_sizes = X.sum(axis=1, keepdims=True)

            if batch_ids is not None:
                # Compute batch-neutral (and optionally covariate-neutral) gene means
                self.gene_means = self._compute_batch_neutral_gene_means(X, batch_ids, covariate=covariate)
            else:
                # Standard gene means (when no batch information available)
                self.gene_means = X.mean(axis=0, keepdims=True)

        return self

    def _compute_batch_neutral_gene_means(
        self,
        X: np.ndarray,
        batch_ids: np.ndarray,
        covariate: Optional[np.ndarray] = None
    ) -> np.ndarray:
        """
        Compute batch-neutral (and optionally covariate-neutral) gene means by projecting
        out batch and covariate effects in log space.

        This removes the batch-dependent and covariate-dependent scaling bias from gene means,
        ensuring that the Pearson residual μ parameter is batch-invariant and covariate-neutral.

        Parameters
        ----------
        X : array, shape (n_cells, n_genes)
            Count matrix
        batch_ids : array, shape (n_cells,)
            Batch identifiers
        covariate : array, shape (n_cells,), optional
            Continuous covariate (e.g., age, pseudotime). If provided, covariate effects are also projected out.

        Returns
        -------
        gene_means_neutral : array, shape (1, n_genes)
            Batch-neutral (and covariate-neutral) gene means
        """
        # Convert batch_ids to numeric codes if needed
        if not np.issubdtype(batch_ids.dtype, np.number):
            batch_ids = pd.Categorical(batch_ids).codes

        # Log-transform (add small constant for numerical stability)
        s = np.log(X + 1)  # shape: (n_cells, n_genes)

        # Batch one-hot matrix
        n_batches = len(np.unique(batch_ids))
        B = np.eye(n_batches)[batch_ids]  # shape: (n_cells, n_batches)

        # If covariate is provided, add covariate basis to projection matrix
        if covariate is not None:
            # Normalize covariate to [0, 1]
            cov_norm = (covariate - covariate.min()) / (covariate.max() - covariate.min() + 1e-8)
            # Covariate basis: [cov, cov^2] for nonlinearity
            C = np.column_stack([cov_norm, cov_norm**2])
            # Combined design matrix: [Batch, Covariate]
            D = np.column_stack([B, C])
        else:
            D = B

        # Project out both batch AND covariate: s* = s - P_D * s
        # P_D = D(D^T D)^{-1}D^T
        DtD_inv = np.linalg.inv(D.T @ D)
        P_D = D @ DtD_inv @ D.T

        s_neutral = s - P_D @ s  # shape: (n_cells, n_genes)

        # Restore global mean in log space (preserve absolute scale)
        s_neutral = s_neutral + (s.mean() - s_neutral.mean())

        # Convert back to expression space
        gene_means_neutral = np.exp(s_neutral.mean(axis=0, keepdims=True))

        return gene_means_neutral

    def transform(self, X: np.ndarray, batch_ids: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Transform counts to Pearson residuals.

        Parameters
        ----------
        X : array-like, shape (n_cells, n_genes)
            Count matrix
        batch_ids : array, shape (n_cells,), optional
            Batch identifiers. Required if fitted with batch_wise=True.

        Returns
        -------
        residuals : array, shape (n_cells, n_genes)
            Pearson residuals (approximately Normal distributed)
        """
        if self.batch_wise and self.batch_params is not None:
            # FIX C: Batch-wise Pearson residual computation
            if batch_ids is None:
                raise ValueError("batch_ids required when fitted with batch_wise=True")

            if not np.issubdtype(batch_ids.dtype, np.number):
                batch_ids = pd.Categorical(batch_ids).codes

            residuals = np.zeros_like(X, dtype=float)

            for batch_id, params in self.batch_params.items():
                batch_mask = (batch_ids == batch_id)
                X_batch = X[batch_mask]

                # Compute library sizes for this batch's cells
                library_sizes_batch = X_batch.sum(axis=1, keepdims=True)

                # Use batch-specific parameters
                gene_means = params['gene_means']
                avg_libsize = params['avg_libsize']

                # Pearson residual with batch-specific normalization
                mu = (library_sizes_batch / avg_libsize) * gene_means
                variance = mu + (mu ** 2) / self.theta

                residuals[batch_mask] = (X_batch - mu) / np.sqrt(variance)

            residuals = np.clip(residuals, -10, 10)  # Stability
            return residuals
        else:
            # Original behavior (global parameters)
            avg_library_size = self.library_sizes.mean()
            mu = (self.library_sizes / avg_library_size) * self.gene_means
            variance = mu + (mu ** 2) / self.theta

            residuals = (X - mu) / np.sqrt(variance)
            residuals = np.clip(residuals, -10, 10)  # Stability

            return residuals

    def fit_transform(self, X: np.ndarray, batch_ids: Optional[np.ndarray] = None, covariate: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Fit and transform in one step.

        Parameters
        ----------
        X : array-like, shape (n_cells, n_genes)
            Count matrix
        batch_ids : array, shape (n_cells,), optional
            Batch identifiers. Required if batch_wise=True.
        covariate : array, shape (n_cells,), optional
            Continuous covariate (e.g., age, pseudotime). Only used when batch_wise=False.
        """
        return self.fit(X, batch_ids=batch_ids, covariate=covariate).transform(X, batch_ids=batch_ids)

    def inverse_transform(
        self,
        X_residuals: np.ndarray,
        library_sizes_target: np.ndarray
    ) -> np.ndarray:
        """
        Convert Pearson residuals back to count space.

        Parameters
        ----------
        X_residuals : array, shape (n_cells, n_genes)
            Pearson residuals
        library_sizes_target : array, shape (n_cells,) or (n_cells, 1)
            Target library sizes (can be batch-neutral)

        Returns
        -------
        X_counts : array, shape (n_cells, n_genes)
            Reconstructed counts
        """
        if library_sizes_target.ndim == 1:
            library_sizes_target = library_sizes_target[:, None]

        if self.batch_wise and self.batch_params is not None:
            # Use batch-wise parameters (average across batches)
            # Take average of batch-specific parameters for inverse transform
            all_gene_means = []
            all_avg_libsizes = []
            for params in self.batch_params.values():
                all_gene_means.append(params['gene_means'])
                all_avg_libsizes.append(params['avg_libsize'])

            gene_means = np.mean(all_gene_means, axis=0)
            avg_library_size = np.mean(all_avg_libsizes)

            mu = (library_sizes_target / avg_library_size) * gene_means
            variance = mu + (mu ** 2) / self.theta

            X_reconstructed = X_residuals * np.sqrt(variance) + mu
            X_reconstructed = np.maximum(X_reconstructed, 0)
        else:
            # Original behavior (global parameters)
            avg_library_size = self.library_sizes.mean()
            mu = (library_sizes_target / avg_library_size) * self.gene_means
            variance = mu + (mu ** 2) / self.theta

            X_reconstructed = X_residuals * np.sqrt(variance) + mu
            X_reconstructed = np.maximum(X_reconstructed, 0)

        return X_reconstructed


# ============================================================================
# Simple Gaussian VAE
# ============================================================================

class SimpleVAE(nn.Module):
    """
    Simple Gaussian VAE for Pearson residuals.

    Architecture:
    - Encoder: Input → Hidden → Hidden → (mu, logvar)
    - Decoder: Latent → Hidden → Hidden → Output

    Loss: MSE reconstruction + KL divergence

    Parameters
    ----------
    n_genes : int
        Number of genes (input/output dimension)
    n_latent : int
        Latent space dimension (default: 30, optimal from experiments)
    n_hidden : int
        Hidden layer dimension (default: 128)
    """

    def __init__(self, n_genes: int, n_latent: int = 30, n_hidden: int = 128):
        super().__init__()

        self.n_genes = n_genes
        self.n_latent = n_latent

        # Encoder
        self.encoder = nn.Sequential(
            nn.Linear(n_genes, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.ReLU(),
        )
        self.fc_mu = nn.Linear(n_hidden, n_latent)
        self.fc_logvar = nn.Linear(n_hidden, n_latent)

        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(n_latent, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_hidden),
            nn.ReLU(),
            nn.Linear(n_hidden, n_genes),
        )

    def encode(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Encode input to latent distribution parameters."""
        h = self.encoder(x)
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar

    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
        """Reparameterization trick."""
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z: torch.Tensor) -> torch.Tensor:
        """Decode latent to output."""
        return self.decoder(z)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Full forward pass."""
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        x_recon = self.decode(z)
        return {'x_recon': x_recon, 'mu': mu, 'logvar': logvar, 'z': z}

    def loss_function(
        self,
        x: torch.Tensor,
        x_recon: torch.Tensor,
        mu: torch.Tensor,
        logvar: torch.Tensor,
        beta: float = 1.0
    ) -> Dict[str, torch.Tensor]:
        """
        VAE loss function.

        Parameters
        ----------
        x : tensor
            Input
        x_recon : tensor
            Reconstruction
        mu : tensor
            Latent mean
        logvar : tensor
            Latent log variance
        beta : float
            Weight for KL term (beta-VAE, default: 1.0)

        Returns
        -------
        losses : dict
            Dictionary with 'loss', 'recon_loss', 'kl_loss'
        """
        # Reconstruction loss (MSE for Pearson residuals)
        recon_loss = torch.mean((x - x_recon) ** 2)

        # KL divergence
        kl_loss = -0.5 * torch.mean(1 + logvar - mu.pow(2) - logvar.exp())

        # Total loss
        loss = recon_loss + beta * kl_loss

        return {
            'loss': loss,
            'recon_loss': recon_loss,
            'kl_loss': kl_loss
        }


# ============================================================================
# ContinuousVI Class
# ============================================================================

class ContinuousVI:
    """
    ContinuousVI: Harmonized VAE for Batch Correction with Covariate Preservation.

    Complete pipeline:
    1. Pearson residual transformation
    2. VAE training on residuals
    3. Harmony batch correction in latent space
    4. Batch-neutral library size recovery
    5. Inverse transformation to count space

    Example
    -------
    >>> from continuousvi import ContinuousVI
    >>> import scanpy as sc
    >>>
    >>> # Load data
    >>> adata = sc.read_h5ad("data.h5ad")
    >>>
    >>> # Initialize and fit
    >>> model = ContinuousVI(n_latent=30, n_hidden=128)
    >>> X_corrected = model.fit_transform(
    ...     adata.X,
    ...     batch_ids=adata.obs['batch'],
    ...     covariate=adata.obs['age'],  # or pseudotime, disease severity, etc.
    ...     apply_harmony=True,
    ...     encode_covariate=True  # Default: True (Extended Harmony for covariate preservation)
    ... )
    >>>
    >>> # Store results
    >>> adata.layers['corrected'] = X_corrected
    """

    def __init__(
        self,
        n_latent: int = 30,
        n_hidden: int = 128,
        theta: float = 100,
        device: Optional[str] = None,
        use_zinb: bool = False,
    ):
        """
        Initialize ContinuousVI.

        Parameters
        ----------
        n_latent : int
            Latent space dimension (default: 30, optimal from experiments)
        n_hidden : int
            Hidden layer dimension (default: 128)
        theta : float
            Pearson residual dispersion parameter (default: 100)
            Only used if use_zinb=False
        device : str, optional
            Device for PyTorch ('cpu' or 'cuda'). If None, auto-detect.
        use_zinb : bool
            If True, use ZINB VAE (no normalization needed)
            If False, use Pearson residuals + Gaussian VAE (default: False)
        """
        self.n_latent = n_latent
        self.n_hidden = n_hidden
        self.theta = theta
        self.use_zinb = use_zinb

        if device is None:
            self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        else:
            self.device = device

        self.residual_transformer = None
        self.vae = None
        self.is_fitted = False
        self._covariate = None  # Store covariate for transform

        logger.info(f"✓ ContinuousVI initialized")
        logger.info(f"  Mode: {'ZINB VAE' if use_zinb else 'Pearson + Gaussian VAE'}")
        logger.info(f"  Latent dimension: {n_latent} (optimal from robustness tests)")
        logger.info(f"  Hidden dimension: {n_hidden}")
        logger.info(f"  Device: {self.device}")

    @staticmethod
    def detect_confounding(
        condition: np.ndarray,
        batch_ids: np.ndarray,
        threshold: float = 0.3
    ) -> Tuple[bool, float]:
        """
        Detect if condition and batch are confounded.

        Parameters
        ----------
        condition : array, shape (n_cells,)
            Condition labels (e.g., 0=control, 1=diseased) or continuous covariate
        batch_ids : array, shape (n_cells,)
            Batch identifiers
        threshold : float
            Correlation threshold for confounding (default: 0.3)

        Returns
        -------
        is_confounded : bool
            True if confounded (correlation > threshold)
        correlation : float
            Pearson correlation between condition and batch
        """
        from scipy.stats import pearsonr

        # Convert to numeric if needed
        if not np.issubdtype(batch_ids.dtype, np.number):
            batch_ids = pd.Categorical(batch_ids).codes

        # Calculate correlation
        corr, _ = pearsonr(condition, batch_ids)

        is_confounded = abs(corr) > threshold

        return is_confounded, corr

    def fit(
        self,
        X: Union[np.ndarray, AnnData],
        batch_ids: Optional[np.ndarray] = None,
        covariate: Optional[np.ndarray] = None,
        n_epochs: int = 100,
        batch_size: int = 64,
        learning_rate: float = 1e-3,
        beta: float = 1.0,
        verbose: bool = True,
    ):
        """
        Fit ContinuousVI model.

        Parameters
        ----------
        X : array or AnnData, shape (n_cells, n_genes)
            Count matrix or AnnData object
        batch_ids : array, shape (n_cells,), optional
            Batch identifiers. If provided, gene means will be computed in a
            batch-neutral manner by projecting out batch effects in log space.
        covariate : array, shape (n_cells,), optional
            Continuous covariate (e.g., age, pseudotime, disease severity).
            If provided (and batch_ids is also provided), covariate effects
            are also projected out from gene means to prevent covariate leakage.
        n_epochs : int
            Number of training epochs (default: 100)
        batch_size : int
            Batch size for training (default: 64)
        learning_rate : float
            Learning rate (default: 1e-3)
        beta : float
            Beta for beta-VAE (default: 1.0)
        verbose : bool
            Print training progress (default: True)

        Returns
        -------
        self
        """
        # Extract count matrix
        if isinstance(X, AnnData):
            X_counts = X.X.toarray() if issparse(X.X) else np.asarray(X.X)
        else:
            X_counts = X

        if verbose:
            print(f"\n{'='*80}")
            print("FITTING CONTINUOUSVI")
            print(f"{'='*80}")
            print(f"  Mode: {'ZINB VAE' if self.use_zinb else 'Pearson + Gaussian VAE'}")
            print(f"  Data shape: {X_counts.shape[0]} cells × {X_counts.shape[1]} genes")
            if batch_ids is not None:
                n_batches = len(np.unique(batch_ids))
                print(f"  Batches: {n_batches}")

        n_genes = X_counts.shape[1]

        # Store covariate for use in transform
        self._covariate = covariate

        if self.use_zinb:
            # ZINB VAE mode: no normalization needed
            if verbose:
                print(f"\n[1] Training ZINB VAE ({n_epochs} epochs)...")
                print(f"  Working directly with counts (no normalization)")
                if covariate is not None:
                    print(f"  With covariate conditioning (W_cov model)")

            self.vae = ZINBVAE(n_genes=n_genes, n_latent=self.n_latent,
                               n_hidden=self.n_hidden, n_covariates=1).to(self.device)

            X_tensor = torch.FloatTensor(X_counts).to(self.device)

            # Prepare covariate tensor
            if covariate is not None:
                cov_norm = (covariate - covariate.min()) / (covariate.max() - covariate.min() + 1e-8)
                cov_tensor = torch.FloatTensor(cov_norm[:, None]).to(self.device)
                dataset = TensorDataset(X_tensor, cov_tensor)
            else:
                cov_tensor = torch.zeros(X_counts.shape[0], 1).to(self.device)
                dataset = TensorDataset(X_tensor, cov_tensor)

            dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

            optimizer = torch.optim.Adam(self.vae.parameters(), lr=learning_rate)

            self.vae.train()
            for epoch in range(n_epochs):
                epoch_loss = 0
                epoch_recon = 0
                epoch_kl = 0

                for x_batch, cov_batch in dataloader:
                    optimizer.zero_grad()

                    outputs = self.vae(x_batch, covariate=cov_batch)
                    losses = self.vae.loss_function(
                        x_batch, outputs['mu'], outputs['logvar'],
                        outputs['px_scale'], outputs['px_r'], outputs['px_dropout'],
                        beta=beta
                    )

                    losses['loss'].backward()
                    optimizer.step()

                    epoch_loss += losses['loss'].item()
                    epoch_recon += losses['recon_loss'].item()
                    epoch_kl += losses['kl_loss'].item()

                if verbose and (epoch + 1) % 20 == 0:
                    print(f"  Epoch {epoch+1}/{n_epochs}: "
                          f"Loss={epoch_loss/len(dataloader):.4f} "
                          f"(Recon={epoch_recon/len(dataloader):.4f}, "
                          f"KL={epoch_kl/len(dataloader):.4f})")

            self.vae.eval()
            self.is_fitted = True

            if verbose:
                print(f"\n✓ Training complete!")
                if covariate is not None:
                    W_cov = self.vae.get_covariate_weights().cpu().numpy()
                    print(f"  W_cov range: [{W_cov.min():.4f}, {W_cov.max():.4f}]")

        else:
            # Pearson + Gaussian VAE mode (with covariate modeling)
            if verbose:
                print("\n[1] Computing Pearson residuals...")
                if covariate is not None and batch_ids is not None:
                    print("  Using covariate+batch neutral gene means")

            self.residual_transformer = PearsonResidualTransform(theta=self.theta)
            X_residuals = self.residual_transformer.fit_transform(X_counts, batch_ids=batch_ids, covariate=covariate)

            if verbose:
                print(f"  Original range: [{X_counts.min():.2f}, {X_counts.max():.2f}]")
                print(f"  Residual range: [{X_residuals.min():.2f}, {X_residuals.max():.2f}]")
                print(f"  Residual mean: {X_residuals.mean():.4f}, std: {X_residuals.std():.4f}")

            # Train VAE with covariate modeling
            if verbose:
                print(f"\n[2] Training Gaussian VAE ({n_epochs} epochs)...")
                if covariate is not None:
                    print(f"  With covariate conditioning (W_cov model)")

            # Use GaussianVAE with covariate support instead of SimpleVAE
            self.vae = GaussianVAE(n_genes=n_genes, n_latent=self.n_latent,
                                   n_hidden=self.n_hidden, n_covariates=1).to(self.device)

            X_tensor = torch.FloatTensor(X_residuals).to(self.device)

            # Prepare covariate tensor
            if covariate is not None:
                cov_norm = (covariate - covariate.min()) / (covariate.max() - covariate.min() + 1e-8)
                cov_tensor = torch.FloatTensor(cov_norm[:, None]).to(self.device)
                dataset = TensorDataset(X_tensor, cov_tensor)
            else:
                cov_tensor = torch.zeros(X_counts.shape[0], 1).to(self.device)
                dataset = TensorDataset(X_tensor, cov_tensor)

            dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

            optimizer = torch.optim.Adam(self.vae.parameters(), lr=learning_rate)

            self.vae.train()
            for epoch in range(n_epochs):
                epoch_loss = 0
                epoch_recon = 0
                epoch_kl = 0

                for x_batch, cov_batch in dataloader:
                    optimizer.zero_grad()

                    outputs = self.vae(x_batch, covariate=cov_batch)
                    losses = self.vae.loss_function(
                        x_batch, outputs['x_recon'],
                        outputs['mu'], outputs['logvar'], beta=beta
                    )

                    losses['loss'].backward()
                    optimizer.step()

                    epoch_loss += losses['loss'].item()
                    epoch_recon += losses['recon_loss'].item()
                    epoch_kl += losses['kl_loss'].item()

                if verbose and (epoch + 1) % 20 == 0:
                    print(f"  Epoch {epoch+1}/{n_epochs}: "
                          f"Loss={epoch_loss/len(dataloader):.4f} "
                          f"(Recon={epoch_recon/len(dataloader):.4f}, "
                          f"KL={epoch_kl/len(dataloader):.4f})")

            self.vae.eval()
            self.is_fitted = True

            if verbose:
                print(f"\n✓ Training complete!")
                if covariate is not None:
                    W_cov = self.vae.get_covariate_weights().cpu().numpy()
                    print(f"  W_cov range: [{W_cov.min():.4f}, {W_cov.max():.4f}]")

        return self

    def transform(
        self,
        X: Union[np.ndarray, AnnData],
        batch_ids: np.ndarray,
        covariate: Optional[np.ndarray] = None,
        apply_harmony: bool = True,
        encode_covariate: bool = True,
        harmony_theta: float = 2.0,
        harmony_kwargs: Optional[Dict] = None,
        return_latent: bool = False,
        gene_list: Optional[Union[List[str], List[int], np.ndarray]] = None,
        inference_batch_size: int = 512,
        verbose: bool = True,
    ) -> Union[np.ndarray, Tuple[np.ndarray, np.ndarray, np.ndarray]]:
        """
        Transform data through the pipeline.

        Parameters
        ----------
        X : array or AnnData, shape (n_cells, n_genes)
            Count matrix or AnnData object
        batch_ids : array, shape (n_cells,)
            Batch identifiers
        covariate : array, shape (n_cells,), optional
            Continuous covariate (e.g., age, pseudotime). Required when encode_covariate=True.
        apply_harmony : bool
            Whether to apply Harmony correction (default: True)
        encode_covariate : bool
            If True, apply Extended Harmony to explicitly preserve covariate during batch correction.
            If False, apply standard Harmony (batch correction only).
            Default: True (recommended, especially when confounding is suspected)
        harmony_theta : float
            Harmony theta parameter (default: 2.0)
        harmony_kwargs : dict, optional
            Additional kwargs for Harmony
        return_latent : bool
            If True, return (X_corrected, Z_before, Z_after) (default: False)
        gene_list : list of str/int or array, optional
            If provided, only decode and return specified genes
            - Can be gene names (if X is AnnData) or gene indices (if X is array)
            - Useful for memory efficiency when only specific genes are needed
        inference_batch_size : int
            Batch size for VAE inference (default: 512, larger = faster but more memory)
        verbose : bool
            Print progress (default: True)

        Returns
        -------
        X_corrected : array, shape (n_cells, n_genes) or (n_cells, len(gene_list))
            Batch-corrected counts (all genes or subset if gene_list specified)
        Z : array, shape (n_cells, n_latent) (if return_latent=True)
            Latent representations before Harmony
        Z_corrected : array, shape (n_cells, n_latent) (if return_latent=True)
            Latent representations after Harmony
        """
        if not self.is_fitted:
            raise RuntimeError("Model must be fitted before transform")

        if encode_covariate and covariate is None:
            raise ValueError("covariate must be provided when encode_covariate=True")

        # Process gene_list to get gene indices
        gene_indices = None
        if gene_list is not None:
            if isinstance(X, AnnData):
                # Gene names provided
                if isinstance(gene_list[0], str):
                    gene_indices = np.array([
                        np.where(X.var_names == gene)[0][0] for gene in gene_list
                    ])
                else:
                    gene_indices = np.asarray(gene_list)
            else:
                # Gene indices provided
                gene_indices = np.asarray(gene_list)

        # Extract count matrix
        if isinstance(X, AnnData):
            X_counts = X.X.toarray() if issparse(X.X) else np.asarray(X.X)
        else:
            X_counts = X

        if verbose:
            print(f"\n{'='*80}")
            print("TRANSFORMING DATA")
            print(f"{'='*80}")
            print(f"  Mode: {'ZINB VAE' if self.use_zinb else 'Pearson + Gaussian VAE'}")
            if apply_harmony:
                mode_str = "Extended (covariate preservation)" if encode_covariate else "Standard (batch only)"
                print(f"  Harmony: {mode_str}")
            else:
                print(f"  Harmony: disabled")

        n_cells = X_counts.shape[0]
        n_genes = X_counts.shape[1]

        # Prepare covariate tensor for inference
        cov_tensor = None
        if covariate is not None:
            cov_norm = (covariate - covariate.min()) / (covariate.max() - covariate.min() + 1e-8)
            cov_tensor = torch.FloatTensor(cov_norm[:, None]).to(self.device)

        if self.use_zinb:
            # ZINB VAE mode: work directly with counts
            # Encode to latent (with batch processing for memory efficiency)
            if verbose:
                print("\n[1] Encoding counts to latent space...")

            Z = np.zeros((n_cells, self.n_latent))

            with torch.no_grad():
                for i in range(0, n_cells, inference_batch_size):
                    end_i = min(i + inference_batch_size, n_cells)
                    X_batch = torch.FloatTensor(X_counts[i:end_i]).to(self.device)
                    cov_batch = cov_tensor[i:end_i] if cov_tensor is not None else None
                    mu_batch, _ = self.vae.encode(X_batch, covariate=cov_batch)
                    Z[i:end_i] = mu_batch.cpu().numpy()

            if verbose:
                print(f"  Latent shape: {Z.shape}")

            # Apply Harmony
            if apply_harmony:
                if verbose:
                    mode_str = "Extended" if encode_covariate else "Standard"
                    print(f"[2] Applying Harmony ({mode_str} mode)...")

                if encode_covariate:
                    Z_corrected = self._apply_extended_harmony(
                        Z, covariate, batch_ids, harmony_theta, harmony_kwargs
                    )
                else:
                    Z_corrected = self._apply_standard_harmony(
                        Z, batch_ids, harmony_theta, harmony_kwargs
                    )
            else:
                Z_corrected = Z

            # Decode to ZINB parameters and reconstruct counts
            if verbose:
                print("[3] Decoding to counts...")

            # Compute batch-neutral (and covariate-neutral) library sizes
            if verbose:
                if covariate is not None:
                    print("[4] Computing batch+covariate-neutral library sizes...")
                else:
                    print("[4] Computing batch-neutral library sizes...")

            library_sizes_neutral = self._compute_batch_neutral_libsize(
                X_counts, batch_ids, covariate=covariate
            )

            X_corrected = np.zeros((n_cells, n_genes))

            with torch.no_grad():
                for i in range(0, n_cells, inference_batch_size):
                    end_i = min(i + inference_batch_size, n_cells)
                    Z_batch = torch.FloatTensor(Z_corrected[i:end_i]).to(self.device)
                    cov_batch = cov_tensor[i:end_i] if cov_tensor is not None else None

                    # Decode to ZINB parameters (with covariate effect via W_cov)
                    outputs = self.vae.decode(Z_batch, covariate=cov_batch)
                    px_scale = outputs['px_scale']  # Proportion across genes (softmax output)

                    # Use batch-neutral library sizes instead of original library sizes
                    # to prevent age information from leaking via library size
                    lib_sizes_batch = torch.FloatTensor(library_sizes_neutral[i:end_i]).to(self.device)
                    if lib_sizes_batch.ndim == 1:
                        lib_sizes_batch = lib_sizes_batch[:, None]

                    reconstructed = px_scale * lib_sizes_batch

                    X_corrected[i:end_i] = reconstructed.cpu().numpy()

        else:
            # Pearson + Gaussian VAE mode (with covariate modeling)
            # Transform to residuals
            if verbose:
                print("\n[1] Transforming to Pearson residuals...")
            X_residuals = self.residual_transformer.transform(X_counts, batch_ids=batch_ids)

            # Encode to latent (with batch processing for memory efficiency)
            if verbose:
                print("[2] Encoding to latent space...")

            Z = np.zeros((n_cells, self.n_latent))

            with torch.no_grad():
                for i in range(0, n_cells, inference_batch_size):
                    end_i = min(i + inference_batch_size, n_cells)
                    X_batch = torch.FloatTensor(X_residuals[i:end_i]).to(self.device)
                    cov_batch = cov_tensor[i:end_i] if cov_tensor is not None else None
                    mu_batch, _ = self.vae.encode(X_batch, covariate=cov_batch)
                    Z[i:end_i] = mu_batch.cpu().numpy()

            if verbose:
                print(f"  Latent shape: {Z.shape}")

            # Apply Harmony
            if apply_harmony:
                if verbose:
                    mode_str = "Extended" if encode_covariate else "Standard"
                    print(f"[3] Applying Harmony ({mode_str} mode)...")

                if encode_covariate:
                    Z_corrected = self._apply_extended_harmony(
                        Z, covariate, batch_ids, harmony_theta, harmony_kwargs
                    )
                else:
                    Z_corrected = self._apply_standard_harmony(
                        Z, batch_ids, harmony_theta, harmony_kwargs
                    )
            else:
                Z_corrected = Z

            # Decode to residuals (with batch processing for memory efficiency)
            if verbose:
                print("[4] Decoding to residuals...")

            X_decoded_residuals = np.zeros((n_cells, n_genes))

            with torch.no_grad():
                for i in range(0, n_cells, inference_batch_size):
                    end_i = min(i + inference_batch_size, n_cells)
                    Z_batch = torch.FloatTensor(Z_corrected[i:end_i]).to(self.device)
                    cov_batch = cov_tensor[i:end_i] if cov_tensor is not None else None
                    # Decode with covariate effect via W_cov
                    decoded_batch = self.vae.decode(Z_batch, covariate=cov_batch).cpu().numpy()
                    X_decoded_residuals[i:end_i] = decoded_batch

            # Compute batch-neutral (and covariate-neutral) library sizes
            if verbose:
                if covariate is not None:
                    print("[5] Computing batch+covariate-neutral library sizes...")
                else:
                    print("[5] Computing batch-neutral library sizes...")

            library_sizes_neutral = self._compute_batch_neutral_libsize(
                X_counts, batch_ids, covariate=covariate
            )

            # Inverse transform to counts
            if verbose:
                print("[6] Inverse transform to count space...")

            X_corrected = self.residual_transformer.inverse_transform(
                X_decoded_residuals, library_sizes_neutral
            )

        # Select specific genes if gene_list was provided
        if gene_indices is not None:
            X_corrected = X_corrected[:, gene_indices]
            if verbose:
                print(f"\n✓ Transformation complete!")
                print(f"  Output shape: {X_corrected.shape} (subset of {len(gene_indices)} genes)")
        else:
            if verbose:
                print(f"\n✓ Transformation complete!")
                print(f"  Output shape: {X_corrected.shape}")

        if return_latent:
            return X_corrected, Z, Z_corrected
        else:
            return X_corrected

    def fit_transform(
        self,
        X: Union[np.ndarray, AnnData],
        batch_ids: np.ndarray,
        covariate: Optional[np.ndarray] = None,
        n_epochs: int = 100,
        batch_size: int = 64,
        learning_rate: float = 1e-3,
        beta: float = 1.0,
        apply_harmony: bool = True,
        encode_covariate: bool = True,
        auto_detect_confounding: bool = True,
        harmony_theta: float = 2.0,
        harmony_kwargs: Optional[Dict] = None,
        return_latent: bool = False,
        gene_list: Optional[Union[List[str], List[int], np.ndarray]] = None,
        inference_batch_size: int = 512,
        verbose: bool = True,
    ) -> Union[np.ndarray, Tuple[np.ndarray, np.ndarray, np.ndarray]]:
        """
        Fit and transform in one step.

        Parameters
        ----------
        X : array or AnnData, shape (n_cells, n_genes)
            Count matrix or AnnData object
        batch_ids : array, shape (n_cells,)
            Batch identifiers
        covariate : array, shape (n_cells,), optional
            Continuous covariate (e.g., age, pseudotime, disease condition).
            Required when encode_covariate=True or auto_detect_confounding=True.
        n_epochs : int
            Number of training epochs (default: 100)
        batch_size : int
            Batch size for training (default: 64)
        learning_rate : float
            Learning rate (default: 1e-3)
        beta : float
            Beta for beta-VAE (default: 1.0)
        apply_harmony : bool
            Whether to apply Harmony correction (default: True).
            Overridden by auto_detect_confounding if enabled.
        encode_covariate : bool
            If True, apply Extended Harmony to explicitly preserve covariate.
            Default: True (recommended for confounded scenarios).
            Overridden by auto_detect_confounding if enabled.
        auto_detect_confounding : bool
            If True, automatically detect confounding between covariate and batch,
            and choose the appropriate correction strategy (default: True).
            - Confounded (corr > 0.3): Extended Harmony (preserve covariate)
            - Non-confounded (corr ≤ 0.3): VAE only (batch effects reduced via reconstruction)
        harmony_theta : float
            Harmony theta parameter (default: 2.0)
        harmony_kwargs : dict, optional
            Additional kwargs for Harmony
        return_latent : bool
            If True, return (X_corrected, Z_before, Z_after) (default: False)
        gene_list : list of str/int or array, optional
            If provided, only decode and return specified genes
            - Can be gene names (if X is AnnData) or gene indices (if X is array)
            - Useful for memory efficiency when only specific genes are needed
        inference_batch_size : int
            Batch size for VAE inference (default: 512, larger = faster but more memory)
        verbose : bool
            Print progress (default: True)

        Returns
        -------
        X_corrected : array, shape (n_cells, n_genes) or (n_cells, len(gene_list))
            Batch-corrected counts (all genes or subset if gene_list specified)
        Z : array, shape (n_cells, n_latent) (if return_latent=True)
            Latent representations before Harmony
        Z_corrected : array, shape (n_cells, n_latent) (if return_latent=True)
            Latent representations after Harmony
        """
        # Auto-detect confounding and adjust strategy
        if auto_detect_confounding and covariate is not None:
            is_confounded, corr = self.detect_confounding(covariate, batch_ids, threshold=0.3)

            if verbose:
                logger.info(f"Auto-detection: correlation={corr:.3f}, confounded={is_confounded}")

            if is_confounded:
                # Confounded: Use Extended Harmony to preserve covariate
                if verbose:
                    logger.info("→ Using Extended Harmony (preserving covariate)")
                apply_harmony = True
                encode_covariate = True
            else:
                # Non-confounded: Use VAE only
                # (harmonypy has pandas compatibility issues, and VAE reconstruction is sufficient)
                if verbose:
                    logger.info("→ Using VAE only (batch effects reduced via reconstruction)")
                apply_harmony = False
                encode_covariate = False

        self.fit(X, batch_ids, covariate=covariate, n_epochs=n_epochs, batch_size=batch_size,
                 learning_rate=learning_rate, beta=beta, verbose=verbose)

        return self.transform(X, batch_ids, covariate=covariate, apply_harmony=apply_harmony,
                             encode_covariate=encode_covariate, harmony_theta=harmony_theta,
                             harmony_kwargs=harmony_kwargs, return_latent=return_latent,
                             gene_list=gene_list, inference_batch_size=inference_batch_size,
                             verbose=verbose)

    def get_covariate_weights(self) -> np.ndarray:
        """
        Get gene-specific covariate weights (W_cov) from the trained VAE.

        These weights represent the effect of covariate on each gene:
        - Large |W_cov[g]| → gene g has strong covariate effect (DE gene)
        - Small |W_cov[g]| → gene g has weak covariate effect (Non-DE gene)

        This is the core mechanism for identifying differentially expressed genes
        with respect to the continuous covariate (e.g., age, pseudotime).

        Returns
        -------
        W_cov : np.ndarray, shape (n_genes,) or (n_genes, n_covariates)
            Gene-specific covariate weights. Squeeze if only one covariate.

        Raises
        ------
        RuntimeError
            If model has not been trained
        """
        if not self.is_fitted or self.vae is None:
            raise RuntimeError("Model must be trained before getting covariate weights")

        W_cov = self.vae.get_covariate_weights().cpu().numpy()

        # Squeeze if only one covariate
        if W_cov.shape[1] == 1:
            W_cov = W_cov.squeeze(-1)

        return W_cov

    def _apply_standard_harmony(
        self,
        Z: np.ndarray,
        batch_ids: np.ndarray,
        theta: float,
        harmony_kwargs: Optional[Dict],
    ) -> np.ndarray:
        """Apply standard Harmony (batch correction only)."""
        try:
            import sys
            sys.path.insert(0, '/mnt/work3/yuyasato/libs/ContinuousVI/test/harmonypy')
            import harmonypy as hp
        except ImportError:
            raise ImportError(
                "harmonypy not found. Please install from: "
                "https://github.com/slowkow/harmonypy"
            )

        meta_data = pd.DataFrame({'batch': batch_ids})

        if harmony_kwargs is None:
            harmony_kwargs = {
                'sigma': 0.1,
                'nclust': 10,
                'max_iter_harmony': 10,
                'verbose': False
            }

        ho = hp.run_harmony(
            Z.T,
            meta_data,
            vars_use=['batch'],
            theta=theta,
            **harmony_kwargs
        )

        return ho.Z_corr.T

    def _apply_extended_harmony(
        self,
        Z: np.ndarray,
        covariate: np.ndarray,
        batch_ids: np.ndarray,
        theta: float,  # noqa: ARG002
        harmony_kwargs: Optional[Dict],
    ) -> np.ndarray:
        """
        Apply Extended Harmony (explicit covariate preservation).

        This modifies Harmony's design matrix to include the covariate as a variable
        to preserve, while removing only batch effects.

        Parameters
        ----------
        Z : array, shape (n_cells, n_latent)
            Latent representations
        covariate : array, shape (n_cells,)
            Continuous covariate to preserve (e.g., age, pseudotime)
        batch_ids : array, shape (n_cells,)
            Batch identifiers
        theta : float
            Harmony theta parameter (not used in current implementation)
        harmony_kwargs : dict, optional
            Additional kwargs (nclust, lambda_ridge)

        Returns
        -------
        Z_corrected : array, shape (n_cells, n_latent)
            Batch-corrected latent representations with covariate preserved
        """
        # Clustering
        nclust = 10 if harmony_kwargs is None else harmony_kwargs.get('nclust', 10)
        kmeans = KMeans(n_clusters=nclust, random_state=42, n_init=10)
        clusters = kmeans.fit_predict(Z)

        # Soft assignment (vectorized)
        R = np.zeros((nclust, Z.shape[0]))
        R[clusters, np.arange(Z.shape[0])] = 1.0

        # Design matrix: [intercept, covariate, batch]
        batch_codes = pd.Categorical(batch_ids).codes
        n_batches = len(np.unique(batch_codes))
        batch_onehot = np.eye(n_batches)[batch_codes]

        cov_norm = (covariate - covariate.min()) / (covariate.max() - covariate.min() + 1e-8)

        # Orthogonalize batch from covariate (residualization)
        # This ensures that we only remove batch effects that are orthogonal to the covariate
        phi_base = np.column_stack([
            np.ones(len(covariate)),      # intercept
            cov_norm                       # covariate (to preserve)
        ])

        # Residualize batch: batch_residual = batch - proj_cov(batch)
        # This removes the covariate-correlated component from batch
        batch_residual = batch_onehot.copy()
        for b in range(n_batches):
            # Project batch onto covariate space and remove
            proj = phi_base @ np.linalg.lstsq(phi_base, batch_onehot[:, b:b+1], rcond=None)[0]
            batch_residual[:, b:b+1] = batch_onehot[:, b:b+1] - proj

        # Per-cluster ridge regression with orthogonalized batch
        Z_corrected = Z.copy()
        lambda_ridge = 1.0 if harmony_kwargs is None else harmony_kwargs.get('lambda_ridge', 1.0)

        for k in range(nclust):
            R_k = R[k, :]

            # Weighted regression on batch_residual
            batch_R = batch_residual.T * R_k

            lhs = batch_R @ batch_residual + lambda_ridge * np.eye(n_batches)
            rhs = batch_R @ Z

            W_batch = np.linalg.solve(lhs, rhs)

            # Remove orthogonalized batch component
            batch_contribution = (batch_residual @ W_batch) * R_k[:, None]
            Z_corrected -= batch_contribution

        return Z_corrected

    def _compute_batch_neutral_libsize(
        self,
        X: np.ndarray,
        batch_ids: np.ndarray,
        covariate: Optional[np.ndarray] = None,
        method: str = 'projection'
    ) -> np.ndarray:
        """
        Compute batch-neutral library sizes.

        IMPORTANT: This function removes ONLY batch effects from library sizes,
        NOT covariate effects. Covariate preservation is handled separately in
        the latent space via Extended Harmony.

        Removing covariate from library sizes causes signal inversion in VAE-only
        mode and signal loss in Extended Harmony mode.

        Parameters
        ----------
        X : array, shape (n_cells, n_genes)
            Count matrix
        batch_ids : array, shape (n_cells,)
            Batch identifiers
        covariate : array, shape (n_cells,), optional
            IGNORED in current implementation (kept for API compatibility)
        method : str
            Method for computing neutral sizes (default: 'projection')

        Returns
        -------
        library_sizes_neutral : array, shape (n_cells,)
            Batch-neutral library sizes (covariate preserved)
        """
        # Convert batch_ids to codes if needed
        if not np.issubdtype(batch_ids.dtype, np.number):
            batch_ids = pd.Categorical(batch_ids).codes

        library_sizes = X.sum(axis=1)
        s = np.log(library_sizes)

        if method == 'projection':
            # Batch one-hot
            n_batches = len(np.unique(batch_ids))

            # If only one batch, no batch effect to remove
            if n_batches == 1:
                return library_sizes

            B = np.eye(n_batches)[batch_ids]

            # FIXED: Only remove batch effects, preserve covariate
            # Previously, covariate was also removed, causing signal inversion
            D = B

            # Project out ONLY batch: s* = s - P_D·s
            DtD_inv = np.linalg.inv(D.T @ D)
            P_D = D @ DtD_inv @ D.T

            s_star = s - P_D @ s

            # Restore original mean (preserve absolute scale)
            s_star = s_star + (s.mean() - s_star.mean())

        else:
            raise ValueError(f"Unknown method: {method}")

        library_sizes_neutral = np.exp(s_star)

        return library_sizes_neutral

    def differential_expression(
        self,
        X: np.ndarray,
        condition: np.ndarray,
        batch_ids: np.ndarray,
        covariate: Optional[np.ndarray] = None,
        group1_label: int = 0,
        group2_label: int = 1,
        n_samples: int = 100,
        batch_size: int = 128,
        delta: float = 0.5,
        verbose: bool = True
    ) -> pd.DataFrame:
        """
        Bayesian differential expression analysis.

        Uses posterior sampling from the VAE to quantify uncertainty and
        compute Bayes factors for differential expression.

        This method is robust to variance shrinkage from batch correction
        and properly accounts for uncertainty in the VAE's latent representation.

        Parameters
        ----------
        X : array, shape (n_cells, n_genes)
            Count matrix
        condition : array, shape (n_cells,)
            Group labels (e.g., 0=control, 1=diseased)
        batch_ids : array, shape (n_cells,)
            Batch identifiers
        covariate : array, shape (n_cells,), optional
            Continuous covariate (e.g., age) to preserve during correction
        group1_label : int
            Label for group 1 (default: 0)
        group2_label : int
            Label for group 2 (default: 1)
        n_samples : int
            Number of posterior samples to draw (default: 100)
        batch_size : int
            Batch size for sampling (default: 128)
        delta : float
            Log2 fold-change threshold for defining DE (default: 0.5)
        verbose : bool
            Print progress (default: True)

        Returns
        -------
        results : DataFrame
            DE results with columns:
            - gene: Gene index
            - mean_g1: Mean expression in group 1
            - mean_g2: Mean expression in group 2
            - log2fc: Log2 fold-change (g2 / g1)
            - bayes_factor: Bayes factor for DE (BF > 3 suggests DE)
            - prob_de: Posterior probability of DE
            - is_de: Boolean indicator (bayes_factor > 3)
        """
        if verbose:
            print("\n" + "="*80)
            print("BAYESIAN DIFFERENTIAL EXPRESSION")
            print("="*80)

        # Validate inputs
        if self.vae is None:
            raise ValueError("Model must be trained before DE analysis")

        group1_idx = (condition == group1_label)
        group2_idx = (condition == group2_label)

        if group1_idx.sum() == 0 or group2_idx.sum() == 0:
            raise ValueError("Both groups must have at least one cell")

        n_cells, n_genes = X.shape

        # Check for condition-batch confounding
        from scipy.stats import pearsonr
        corr_cond_batch = abs(pearsonr(condition, batch_ids)[0])

        if verbose:
            print(f"\nSetup:")
            print(f"  Group 1 ({group1_label}): {group1_idx.sum()} cells")
            print(f"  Group 2 ({group2_label}): {group2_idx.sum()} cells")
            print(f"  Genes: {n_genes}")
            print(f"  Posterior samples: {n_samples}")
            print(f"  DE threshold: log2FC > {delta}")
            print(f"  Condition-batch correlation: {corr_cond_batch:.3f}")

            # Warn about strong confounding
            if corr_cond_batch > 0.6:
                print("\n" + "!"*80)
                print("⚠️  WARNING: Strong condition-batch confounding detected!")
                print(f"   Correlation: {corr_cond_batch:.3f} (threshold: 0.6)")
                print("   Differential expression results may be unreliable.")
                print("   ")
                print("   Recommendation: Re-design experiment with balanced batches:")
                print("   - Distribute both conditions across multiple batches")
                print("   - Aim for correlation < 0.4 for reliable DE analysis")
                print("!"*80 + "\n")

        # Posterior sampling
        if verbose:
            print(f"\n[1/3] Sampling from posterior...")

        # Store samples for each group
        samples_g1 = np.zeros((n_samples, group1_idx.sum(), n_genes))
        samples_g2 = np.zeros((n_samples, group2_idx.sum(), n_genes))

        X_g1 = X[group1_idx]
        X_g2 = X[group2_idx]

        self.vae.eval()
        with torch.no_grad():
            for sample_idx in range(n_samples):
                # Sample group 1
                for i in range(0, X_g1.shape[0], batch_size):
                    end_i = min(i + batch_size, X_g1.shape[0])
                    X_batch = torch.FloatTensor(X_g1[i:end_i]).to(self.device)

                    # Sample from posterior q(z|x)
                    mu, logvar = self.vae.encode(X_batch)
                    std = torch.exp(0.5 * logvar)
                    eps = torch.randn_like(std)
                    z = mu + eps * std

                    # Decode to get expression
                    outputs = self.vae.decode(z)
                    px_scale = outputs['px_scale']

                    # Use batch-neutral library sizes
                    # Note: batch_ids need to be passed for the full group, not just the batch
                    batch_ids_g1 = batch_ids[group1_idx]
                    lib_sizes = self._compute_batch_neutral_libsize(
                        X_g1[i:end_i], batch_ids_g1[i:end_i], covariate=None
                    )
                    lib_torch = torch.FloatTensor(lib_sizes).to(self.device)
                    if lib_torch.ndim == 1:
                        lib_torch = lib_torch[:, None]

                    reconstructed = px_scale * lib_torch
                    samples_g1[sample_idx, i:end_i] = reconstructed.cpu().numpy()

                # Sample group 2
                for i in range(0, X_g2.shape[0], batch_size):
                    end_i = min(i + batch_size, X_g2.shape[0])
                    X_batch = torch.FloatTensor(X_g2[i:end_i]).to(self.device)

                    mu, logvar = self.vae.encode(X_batch)
                    std = torch.exp(0.5 * logvar)
                    eps = torch.randn_like(std)
                    z = mu + eps * std

                    outputs = self.vae.decode(z)
                    px_scale = outputs['px_scale']

                    batch_ids_g2 = batch_ids[group2_idx]
                    lib_sizes = self._compute_batch_neutral_libsize(
                        X_g2[i:end_i], batch_ids_g2[i:end_i], covariate=None
                    )
                    lib_torch = torch.FloatTensor(lib_sizes).to(self.device)
                    if lib_torch.ndim == 1:
                        lib_torch = lib_torch[:, None]

                    reconstructed = px_scale * lib_torch
                    samples_g2[sample_idx, i:end_i] = reconstructed.cpu().numpy()

                if verbose and (sample_idx + 1) % 20 == 0:
                    print(f"  Sampled {sample_idx + 1}/{n_samples}")

        # Compute statistics
        if verbose:
            print(f"\n[2/3] Computing fold-changes and Bayes factors...")

        # Mean expression per group (averaged over samples and cells)
        mean_g1 = samples_g1.mean(axis=(0, 1))  # (n_genes,)
        mean_g2 = samples_g2.mean(axis=(0, 1))  # (n_genes,)

        # Log2 fold-change
        log2fc = np.log2(mean_g2 + 1) - np.log2(mean_g1 + 1)

        # Bayes factor calculation
        # For each gene, compute posterior probability that |log2FC| > delta
        bayes_factors = np.zeros(n_genes)
        prob_de = np.zeros(n_genes)

        for g in range(n_genes):
            # Compute log2FC for each sample
            # Average over cells within each sample
            fc_samples_g1 = samples_g1[:, :, g].mean(axis=1)  # (n_samples,)
            fc_samples_g2 = samples_g2[:, :, g].mean(axis=1)  # (n_samples,)
            log2fc_samples = np.log2(fc_samples_g2 + 1) - np.log2(fc_samples_g1 + 1)

            # Probability of DE: P(|log2FC| > delta)
            prob_de[g] = (np.abs(log2fc_samples) > delta).mean()

            # Bayes factor: P(|log2FC| > delta) / P(|log2FC| <= delta)
            # Add small epsilon to avoid division by zero
            bayes_factors[g] = prob_de[g] / (1 - prob_de[g] + 1e-8)

        # Classification
        is_de = bayes_factors > 3  # BF > 3 is moderate evidence for DE

        if verbose:
            print(f"\n[3/3] Results:")
            print(f"  DE genes (BF > 3): {is_de.sum()} / {n_genes}")
            print(f"  Mean Bayes factor (DE genes): {bayes_factors[is_de].mean():.2f}")
            print(f"  Mean Bayes factor (non-DE genes): {bayes_factors[~is_de].mean():.2f}")

        # Compile results
        results = pd.DataFrame({
            'gene': np.arange(n_genes),
            'mean_g1': mean_g1,
            'mean_g2': mean_g2,
            'log2fc': log2fc,
            'bayes_factor': bayes_factors,
            'prob_de': prob_de,
            'is_de': is_de
        })

        # Sort by Bayes factor
        results = results.sort_values('bayes_factor', ascending=False).reset_index(drop=True)

        if verbose:
            print(f"\n✓ Differential expression analysis complete!")
            print("="*80 + "\n")

        return results

    def save(self, path: str):
        """
        Save ContinuousVI model.

        Parameters
        ----------
        path : str
            Directory to save model files
        """
        save_path = Path(path)
        save_path.mkdir(parents=True, exist_ok=True)

        # Save VAE model
        torch.save(self.vae.state_dict(), save_path / "vae_model.pt")

        # Save metadata
        import pickle
        metadata = {
            'n_latent': self.n_latent,
            'n_hidden': self.n_hidden,
            'theta': self.theta,
            'device': self.device,
            'residual_transformer': self.residual_transformer,
        }
        with open(save_path / "metadata.pkl", 'wb') as f:
            pickle.dump(metadata, f)

        logger.info(f"✓ Model saved to {save_path}")

    @classmethod
    def load(cls, path: str, device: Optional[str] = None) -> "ContinuousVI":
        """
        Load ContinuousVI model from disk.

        Parameters
        ----------
        path : str
            Directory containing saved model files
        device : str, optional
            Device for PyTorch ('cpu' or 'cuda'). If None, use saved device.

        Returns
        -------
        model : ContinuousVI
            Loaded model
        """
        load_path = Path(path)

        # Load metadata
        import pickle
        with open(load_path / "metadata.pkl", 'rb') as f:
            metadata = pickle.load(f)

        # Create model instance
        model = cls(
            n_latent=metadata['n_latent'],
            n_hidden=metadata['n_hidden'],
            theta=metadata['theta'],
            device=device if device is not None else metadata['device'],
        )

        # Load VAE model
        # Need to know n_genes from residual_transformer
        model.residual_transformer = metadata['residual_transformer']
        n_genes = model.residual_transformer.gene_means.shape[1]

        model.vae = SimpleVAE(
            n_genes=n_genes,
            n_latent=model.n_latent,
            n_hidden=model.n_hidden
        ).to(model.device)

        model.vae.load_state_dict(torch.load(load_path / "vae_model.pt",
                                              map_location=model.device))
        model.vae.eval()
        model.is_fitted = True

        logger.info(f"✓ Model loaded from {load_path}")
        return model


# ============================================================================
# Evaluation Utilities
# ============================================================================

def evaluate_batch_correction(
    X_corrected: np.ndarray,
    X_raw: np.ndarray,
    covariate: np.ndarray,
    batch_codes: np.ndarray,
    covariate_genes: Optional[np.ndarray] = None,
    verbose: bool = True,
) -> Dict[str, float]:
    """
    Comprehensive evaluation of batch correction results.

    Parameters
    ----------
    X_corrected : array
        Batch-corrected counts
    X_raw : array
        Raw counts (for comparison)
    covariate : array
        Continuous covariate (e.g., age, pseudotime)
    batch_codes : array
        Batch numeric codes
    covariate_genes : array, bool, optional
        Boolean mask for covariate-associated genes (for AUROC)
    verbose : bool
        Print results (default: True)

    Returns
    -------
    results : dict
        Evaluation metrics
    """
    results = {}

    # Covariate prediction R²
    ridge = Ridge(alpha=1.0)
    ridge.fit(X_corrected, covariate)
    cov_pred = ridge.predict(X_corrected)
    results['covariate_r2'] = r2_score(covariate, cov_pred)

    # Covariate correlation (gene-wise)
    gene_cov_corrs = [abs(spearmanr(X_corrected[:, g], covariate)[0])
                      for g in range(X_corrected.shape[1])]
    results['covariate_corr_max'] = np.max(gene_cov_corrs)
    results['covariate_corr_mean'] = np.mean(gene_cov_corrs)

    # Gene detection AUROC (if covariate_genes provided)
    if covariate_genes is not None:
        results['auroc'] = roc_auc_score(covariate_genes.astype(int), gene_cov_corrs)

    # Batch contamination
    batch_corrs = [abs(spearmanr(X_corrected[:, g], batch_codes)[0])
                   for g in range(X_corrected.shape[1])]
    results['batch_corr_max'] = np.max(batch_corrs)
    results['batch_corr_mean'] = np.mean(batch_corrs)

    # Batch reduction (vs raw)
    raw_batch_corrs = [abs(spearmanr(X_raw[:, g], batch_codes)[0])
                       for g in range(X_raw.shape[1])]
    raw_batch_max = np.max(raw_batch_corrs)
    results['batch_reduction_pct'] = (1 - results['batch_corr_max'] / raw_batch_max) * 100

    # Library-batch correlation
    library_sizes_corrected = X_corrected.sum(axis=1)
    lib_batch_corr, _ = spearmanr(np.log(library_sizes_corrected), batch_codes)
    results['lib_batch_corr'] = lib_batch_corr

    if verbose:
        print(f"\n{'='*80}")
        print("BATCH CORRECTION EVALUATION")
        print(f"{'='*80}")
        print(f"\n[Covariate Information]")
        print(f"  Covariate R²:           {results['covariate_r2']:.4f}")
        print(f"  Covariate corr (max):   {results['covariate_corr_max']:.4f}")
        print(f"  Covariate corr (mean):  {results['covariate_corr_mean']:.4f}")
        if 'auroc' in results:
            print(f"  AUROC:                  {results['auroc']:.4f}")

        print(f"\n[Batch Correction]")
        print(f"  Batch corr (max):   {results['batch_corr_max']:.4f}")
        print(f"  Batch reduction:    {results['batch_reduction_pct']:.1f}%")
        print(f"  Lib-Batch corr:     {results['lib_batch_corr']:.4f}")

        if results['batch_reduction_pct'] > 80:
            print(f"  → Excellent batch correction ✓")
        elif results['batch_reduction_pct'] > 60:
            print(f"  → Good batch correction")
        else:
            print(f"  → Moderate batch correction")

        if abs(results['lib_batch_corr']) < 0.1:
            print(f"  → Library sizes are batch-neutral ✓")
        else:
            print(f"  ⚠ Warning: Library sizes still correlated with batch")

    return results
