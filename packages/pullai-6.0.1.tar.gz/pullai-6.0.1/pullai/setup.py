"""
Auto-installer for PullAI server (pullai.exe).
Called automatically when PullAI() is instantiated and the server is not found.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import platform
import urllib.request
import urllib.error
import json
import zipfile
import tempfile
from pathlib import Path


GITHUB_RELEASES_API = "https://api.github.com/repos/pullai/pullai/releases/latest"
INSTALL_DIR = Path.home() / ".pullai" / "bin"
VERSION_URL = "https://github.com/pullai/pullai/releases/latest"


def find_pullai_exe() -> str | None:
    """Return path to pullai executable if found, else None."""
    # 1. Check PATH
    found = shutil.which("pullai") or shutil.which("pullai.exe")
    if found:
        return found

    # 2. Check default install location
    exe_name = "pullai.exe" if platform.system() == "Windows" else "pullai"
    default = INSTALL_DIR / exe_name
    if default.exists():
        return str(default)

    # 3. Check common Windows locations
    if platform.system() == "Windows":
        for loc in [
            Path(os.environ.get("LOCALAPPDATA", "")) / "pullai" / "pullai.exe",
            Path("C:/Program Files/PullAI/pullai.exe"),
            Path("C:/Program Files (x86)/PullAI/pullai.exe"),
        ]:
            if loc.exists():
                return str(loc)

    return None


def is_server_running(port: int = 11500) -> bool:
    """Return True if the PullAI server is already listening on the port."""
    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/api/status", timeout=2
        ) as r:
            return r.status == 200
    except Exception:
        return False


def get_latest_release() -> dict | None:
    """Fetch latest release info from GitHub API."""
    try:
        req = urllib.request.Request(
            GITHUB_RELEASES_API,
            headers={"User-Agent": "pullai-python-sdk"},
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read())
    except Exception:
        return None


def _pick_asset(assets: list) -> dict | None:
    """Pick the correct binary asset for the current platform."""
    system = platform.system().lower()
    machine = platform.machine().lower()

    # Normalize architecture
    if machine in ("x86_64", "amd64"):
        arch = "amd64"
    elif machine in ("arm64", "aarch64"):
        arch = "arm64"
    else:
        arch = machine

    # Priority: installer > portable exe > zip
    candidates = []
    for asset in assets:
        name = asset["name"].lower()
        if system == "windows" and "windows" in name and arch in name:
            candidates.append(asset)
        elif system == "linux" and "linux" in name and arch in name:
            candidates.append(asset)
        elif system == "darwin" and ("darwin" in name or "macos" in name) and arch in name:
            candidates.append(asset)

    if not candidates:
        return None

    # Prefer standalone .exe over installer
    for asset in candidates:
        name = asset["name"].lower()
        if "setup" not in name and name.endswith(".exe"):
            return asset
    return candidates[0]


def download_with_progress(url: str, dest: Path) -> None:
    """Download a file showing a simple progress bar."""
    req = urllib.request.Request(url, headers={"User-Agent": "pullai-python-sdk"})
    with urllib.request.urlopen(req, timeout=300) as r:
        total = int(r.headers.get("Content-Length", 0))
        downloaded = 0
        chunk_size = 64 * 1024  # 64KB
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "wb") as f:
            while True:
                chunk = r.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if total > 0:
                    pct = downloaded * 100 // total
                    bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
                    mb_done  = downloaded / 1e6
                    mb_total = total / 1e6
                    print(
                        f"\r  [{bar}] {pct:3d}%  {mb_done:.1f}/{mb_total:.1f} MB",
                        end="", flush=True,
                    )
    print()


def install_pullai() -> str | None:
    """
    Download and install the PullAI server binary.
    Returns the path to the installed executable, or None on failure.
    """
    print("🔍  Fetching latest PullAI release from GitHub...")
    release = get_latest_release()

    if not release:
        print("❌  Could not reach GitHub. Check your internet connection.")
        print(f"    Download manually from: {VERSION_URL}")
        return None

    version = release.get("tag_name", "unknown")
    assets  = release.get("assets", [])
    asset   = _pick_asset(assets)

    if not asset:
        print(f"❌  No compatible binary found for {platform.system()} {platform.machine()}.")
        print(f"    Download manually from: {VERSION_URL}")
        return None

    print(f"📦  PullAI {version} — {asset['name']} ({asset['size'] / 1e6:.1f} MB)")
    print(f"    Downloading...")

    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    exe_name = "pullai.exe" if platform.system() == "Windows" else "pullai"
    dest = INSTALL_DIR / asset["name"]

    try:
        download_with_progress(asset["browser_download_url"], dest)
    except Exception as e:
        print(f"❌  Download failed: {e}")
        return None

    # If it's a zip, extract it
    final_exe = INSTALL_DIR / exe_name
    if dest.suffix == ".zip":
        print("📂  Extracting...")
        with zipfile.ZipFile(dest, "r") as z:
            for member in z.namelist():
                if member.endswith(exe_name) or member == exe_name:
                    z.extract(member, INSTALL_DIR)
                    extracted = INSTALL_DIR / member
                    extracted.rename(final_exe)
                    break
        dest.unlink()
    else:
        dest.rename(final_exe)

    # Make executable on Unix
    if platform.system() != "Windows":
        final_exe.chmod(0o755)

    # Add to PATH hint
    print(f"\n✅  PullAI installed to: {final_exe}")

    if str(INSTALL_DIR) not in os.environ.get("PATH", ""):
        print(f"\n💡  Add to PATH to use from terminal:")
        if platform.system() == "Windows":
            print(f'    setx PATH "%PATH%;{INSTALL_DIR}"')
        else:
            print(f'    echo \'export PATH="$PATH:{INSTALL_DIR}"\' >> ~/.bashrc')

    return str(final_exe)


def prompt_install() -> str | None:
    """
    Ask the user if they want to install PullAI, then install if yes.
    Returns the exe path if installed, None otherwise.
    """
    print()
    print("╔══════════════════════════════════════════════════════╗")
    print("║          PullAI server not found on this PC          ║")
    print("╠══════════════════════════════════════════════════════╣")
    print("║  PullAI needs a local server to run AI models.       ║")
    print("║  It will be installed in:                            ║")
    print(f"║  {str(INSTALL_DIR):<52} ║")
    print("╚══════════════════════════════════════════════════════╝")
    print()

    try:
        answer = input("  Install PullAI server now? [Y/n]: ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        print("\n  Skipped.")
        return None

    if answer in ("", "y", "yes"):
        exe = install_pullai()
        if exe:
            print()
            print("  To start the server run:")
            print("    pullai serve")
            print("  Or open the GUI:")
            print("    pullai gui")
        return exe
    else:
        print()
        print("  Skipped. Download PullAI manually from:")
        print(f"  {VERSION_URL}")
        return None


def ensure_server(port: int = 11500, auto_start: bool = True) -> bool:
    """
    Make sure the PullAI server is available.
    1. If server already running → return True
    2. If pullai.exe found → try to start it → return True
    3. If not found → prompt install → try to start → return True/False
    """
    # Already running?
    if is_server_running(port):
        return True

    # Find the executable
    exe = find_pullai_exe()

    if not exe:
        exe = prompt_install()
        if not exe:
            return False

    if auto_start:
        print("🚀  Starting PullAI server...")
        try:
            if platform.system() == "Windows":
                subprocess.Popen(
                    [exe, "serve", "--port", str(port)],
                    creationflags=subprocess.DETACHED_PROCESS |
                                  subprocess.CREATE_NEW_PROCESS_GROUP,
                    close_fds=True,
                )
            else:
                subprocess.Popen(
                    [exe, "serve", "--port", str(port)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
            # Wait up to 8 seconds for server to start
            import time
            for i in range(16):
                time.sleep(0.5)
                if is_server_running(port):
                    print("✅  Server started.")
                    return True
            print("⚠️   Server did not respond in time. Try: pullai serve")
        except Exception as e:
            print(f"⚠️   Could not start server automatically: {e}")
            print(f"    Run manually: pullai serve")

    return is_server_running(port)
