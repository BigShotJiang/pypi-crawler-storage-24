import argparse
import sys
import textwrap

import mmif
from mmif.utils.cli import open_cli_io_arg
from mmif.utils.workflow_helper import group_views_by_app


def prompt_user(mmif_obj: mmif.Mmif) -> int:
    """
    Function to ask user to choose the rewind range.
    """
    grouped_apps = group_views_by_app(mmif_obj.views)
    view_to_app_num = {}
    for i, execution in enumerate(grouped_apps):
        for view in execution:
            view_to_app_num[view.id] = i + 1

    # header
    print("\n" + "{:<8} {:<8} {:<30} {:<100}".format("view-num", "app-num", "timestamp", "app"))
    view_num = 0
    for view in reversed(mmif_obj.views):
        view_num += 1
        app_exec_num = view_to_app_num.get(view.id, 'N/A')
        print("{:<8} {:<15} {:<30} {:<100}".format(view_num, app_exec_num, str(view.metadata.timestamp), str(view.metadata.app)))

    ## User input
    return int(input("\nEnter the number to delete from that point by rewinding: "))


def rewind_mmif(mmif_obj: mmif.Mmif, choice: int, choice_is_viewnum: bool = True) -> mmif.Mmif:
    """
    Rewind MMIF by deleting the last N views. 
    The number of views to rewind is given as a number of "views", or number of "producer apps". 
    By default, the number argument is interpreted as the number of "views". 
    Note that when the same app is repeatedly run in a CLAMS workflow and produces multiple views in a row,
    rewinding in "app" mode will rewind all those views at once.

    :param mmif_obj: mmif object
    :param choice: number of views to rewind
    :param choice_is_viewnum: if True, choice is the number of views to rewind. If False, choice is the number of producer apps to rewind.
    :return: rewound mmif object

    """
    if choice_is_viewnum:
        for vid in list(v.id for v in mmif_obj.views)[-1:-choice-1:-1]:
            mmif_obj.views._items.pop(vid)
    else:
        grouped_apps = group_views_by_app(mmif_obj.views)
        executions_to_rewind = grouped_apps[-choice:]
        vid_to_pop = [view.id for execution in executions_to_rewind for view in execution]
        for vid in vid_to_pop:
            mmif_obj.views._items.pop(vid)
    return mmif_obj


def describe_argparser():
    oneliner = 'provides CLI to rewind a MMIF from a CLAMS workflow.'
    additional = textwrap.dedent("""
    MMIF rewinder rewinds a MMIF by deleting the last N views.
    N can be specified as a number of views, or a number of producer apps. """)
    return oneliner, oneliner + '\n\n' + additional


def prep_argparser(**kwargs):
    parser = argparse.ArgumentParser(description=describe_argparser()[1], 
                                     formatter_class=argparse.RawDescriptionHelpFormatter, **kwargs)
    parser.add_argument("MMIF_FILE",
                        nargs="?", type=str, default=None,
                        help='input MMIF file path, or STDIN if `-` or not provided.')
    parser.add_argument("-o", "--output",
                        type=str, default=None,
                        help='output file path, or STDOUT if not provided.')
    parser.add_argument("-p", '--pretty', action='store_true', 
                        help="Pretty-print rewound MMIF")
    parser.add_argument("-n", '--number', default="0", type=int,
                        help="Number of views or apps to rewind, must be a positive integer. "
                             "If 0, the user will be prompted to choose. (default: 0)")
    parser.add_argument("-m", '--mode', choices=['app', 'view'], default='view', 
                        help="Choose to rewind by number of views or number of producer apps. (default: view)")
    return parser


def main(args):
    with open_cli_io_arg(args.MMIF_FILE, 'r', default_stdin=True) as input_file:
        mmif_obj = mmif.Mmif(input_file.read())

    if args.number == 0:  # If user doesn't know how many views to rewind, give them choices.
        choice = prompt_user(mmif_obj)
    else:
        choice = args.number
    if not isinstance(choice, int) or choice <= 0:
        raise ValueError(f"Only can rewind by a positive number of views. Got {choice}.")

    with open_cli_io_arg(args.output, 'w', default_stdin=True) as output_file:
        output_file.write(rewind_mmif(mmif_obj, choice, args.mode == 'view').serialize(pretty=args.pretty))


if __name__ == "__main__":
    parser = prep_argparser()
    args = parser.parse_args()
    main(args)
