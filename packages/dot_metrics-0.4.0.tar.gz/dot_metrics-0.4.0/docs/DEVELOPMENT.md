# Development Guide

## Requirements

- Python 3.12+

## Installation

### Clone the repository

```shell
git clone git@gitlab.com:deepika6190303/deepika-open-toolbox/dot-metrics.git
cd dot-metrics
```

### Python environment

```shell
uv venv --python python3.12
uv sync
```

## Testing

```shell
uv run pytest tests/
```

## Example

```shell
uv run examples/basic.py
```

## Usage in development mode

1. Create a Python 3.12 environment

```shell
mkdir -p /tmp/test-dot-metrics && cd /tmp/test-dot-metrics
uv venv --python 3.12
source .venv/bin/activate
```

2. Install the package

```shell
uv pip install "git+ssh://git@gitlab.com/deepika6190303/deepika-open-toolbox/dot-metrics.git@main"
```

> Replace `main` with a tag (e.g. `v0.1.0`) for reproducible installs.
