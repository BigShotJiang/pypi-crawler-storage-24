# Contributing Guide

Thank you for considering contributing to this project!

## Development Setup

See [DEVELOPMENT.md](DEVELOPMENT.md) for environment setup.

## How to Contribute

1. **Fork the repository** and create a new branch for your feature or bugfix
2. **Make your changes** following the project's coding standards
3. **Run tests** to ensure nothing is broken:
   ```shell
   uv run pytest tests/
   ```
4. **Submit a merge request** with a clear description of your changes

## Code Style

- Follow PEP 8 guidelines for Python code
- Use meaningful variable and function names
- Keep functions focused and small

## Testing

All new features and bug fixes should include appropriate tests. Place your tests in the `tests/` directory.

## Questions?

Feel free to open an issue in the project.
