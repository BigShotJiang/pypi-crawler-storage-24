from dot_metrics import ComputedValue, MetricSet, EvalResult
from dot_metrics.display import draw_terminal_chart

# --- Basic usage ---

metric_set = MetricSet()

metric_set.add("coverage", lambda data: data["covered"] / data["total"], name="Coverage")
metric_set.add_constraint("errors", lambda data: data["error_count"], name="Error Count", threshold=0)

result = metric_set.compute({"covered": 90, "total": 100, "error_count": 0})

print(f"coverage: {result.score('coverage')}")  # 0.9
print(f"constraints ok: {result.constraints_ok}")  # True


# --- With debug info ---

def compute_coverage(data):
    missed = [x["name"] for x in data if not x["covered"]]
    rate = 1 - len(missed) / len(data)
    return ComputedValue(value=rate, debug={"missed": missed})


items = [
    {"name": "a", "covered": True},
    {"name": "b", "covered": False},
    {"name": "c", "covered": True},
]

metric_set2 = MetricSet()
metric_set2.add("coverage", compute_coverage)
result2 = metric_set2.compute(items)

print(f"debug: {result2.metrics['coverage'].debug}")  # {'missed': ['b']}

# --- Terminal chart ---

print(draw_terminal_chart(result2))
