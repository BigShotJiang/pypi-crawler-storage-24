from dot_metrics.models import EvalResult


def draw_terminal_chart(
    result: EvalResult, width: int = 40, char: str = "█"
) -> str:
    """Render a Unicode horizontal bar chart of quality metrics."""
    if not result.metrics:
        return "No metrics to display"

    max_key_len = max(len(key) for key in result.metrics)
    lines = []

    for key, metric in result.metrics.items():
        if metric.normalize is not None:
            normalized = metric.normalize(metric.value)
        else:
            normalized = metric.value if metric.higher_is_better else 1.0 - metric.value
        normalized = max(0.0, min(1.0, normalized))
        bar = char * int(normalized * width)
        percentage = int(normalized * 100)
        lines.append(f"{key.ljust(max_key_len)} | {bar} {percentage}%")

    return "\n".join(lines)
