import pytest

from dot_metrics import EvalResult, Metric
from dot_metrics.display import draw_terminal_chart


def _make_result(**metrics: Metric) -> EvalResult:
    return EvalResult(metrics=metrics, constraints={})


def test_draw_higher_is_better():
    m = Metric(key="score", value=0.7, higher_is_better=True)
    result = _make_result(score=m)
    chart = draw_terminal_chart(result)
    assert "70%" in chart


def test_draw_lower_is_better():
    m = Metric(key="error", value=0.3, higher_is_better=False)
    result = _make_result(error=m)
    chart = draw_terminal_chart(result)
    assert "70%" in chart


def test_draw_terminal_chart_smoke():
    m = Metric(key="score", value=0.8, higher_is_better=True)
    result = _make_result(score=m)
    chart = draw_terminal_chart(result)
    assert "|" in chart
    assert "█" in chart


def test_draw_with_custom_normalize():
    m = Metric(key="latency", value=3.0, normalize=lambda v: 1 / (v + 1))
    result = _make_result(latency=m)
    chart = draw_terminal_chart(result)
    assert "25%" in chart


def test_draw_without_normalize_unchanged():
    m = Metric(key="score", value=0.6, higher_is_better=True)
    result = _make_result(score=m)
    chart = draw_terminal_chart(result)
    assert "60%" in chart


def test_draw_no_metrics():
    result = EvalResult(metrics={}, constraints={})
    assert draw_terminal_chart(result) == "No metrics to display"
