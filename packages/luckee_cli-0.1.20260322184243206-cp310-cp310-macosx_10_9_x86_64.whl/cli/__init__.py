"""CLI package for agent_ws_v3 terminal client."""

