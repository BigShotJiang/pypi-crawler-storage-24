from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="kernelbot-ml",
    version="1.0.0",
    author="CraftKernel (Endyboii)",
    author_email="",
    description="Pure Python ML learning engine with token-based text generation - no dependencies!",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Endyboii/Kernelbotv.5",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: Text Processing :: Linguistic",
    ],
    python_requires=">=3.7",
    install_requires=[],  # Pure Python - no dependencies!
    extras_require={
        "dev": ["pytest>=6.0", "pytest-cov"],
    },
    include_package_data=True,
    keywords="ml learning token-based text-generation nlp",
    project_urls={
        "Bug Reports": "https://github.com/Endyboii/Kernelbotv.5/issues",
        "Source": "https://github.com/Endyboii/Kernelbotv.5",
    },
)
