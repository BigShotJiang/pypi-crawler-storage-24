"""
kernelbot_ml - Pure Python ML Learning Engine

A lightweight, zero-dependency machine learning library.
Learn more at: https://github.com/Endyboii/Kernelbotv.5
"""

__version__ = "1.0.0"
__author__ = "CraftKernel (Endyboii)"

from .core.chatbot import LearningChatbot
from .core.nlp_engine import SimpleLLM

__all__ = ["LearningChatbot", "SimpleLLM"]
