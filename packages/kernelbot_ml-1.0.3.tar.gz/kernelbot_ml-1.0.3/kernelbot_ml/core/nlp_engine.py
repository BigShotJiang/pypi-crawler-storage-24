"""
SimpleLLM - Pure Python Token-Based Language Model

Implements a token-based learning engine similar to GPT, using n-grams and probability distributions.
This is the core learning component - no external dependencies!
"""

from collections import defaultdict, Counter
from typing import Dict, List, Optional, Any
import random
import math
import re


class SimpleLLM:
    """
    Token-based language model for learning and text generation.
    Similar in concept to GPT but using n-grams and probability distributions.
    """

    def __init__(self, vocab_size: int = 10000, max_context: int = 20):
        """
        Initialize the SimpleLLM.
        
        Args:
            vocab_size: Maximum vocabulary size
            max_context: Context window size in tokens
        """
        self.vocab_size = vocab_size
        self.max_context = max_context
        
        # Vocabulary: token -> id mapping
        self.token_to_id = {}
        self.id_to_token = {}
        self.vocab_count = 0
        
        # N-gram patterns for learning
        self.bigrams = defaultdict(Counter)  # token1 -> {token2: count, ...}
        self.trigrams = defaultdict(lambda: defaultdict(Counter))  # token1, token2 -> {token3: count}
        
        # Statistics
        self.tokens_seen = 0
        self.texts_trained = 0

    def tokenize(self, text: str) -> List[str]:
        """Break text into tokens."""
        # Simple tokenization - split by spaces and punctuation
        import re
        tokens = re.findall(r'\b\w+\b|[.,!?;:]', text.lower())
        return tokens

    def encode(self, tokens: List[str]) -> List[int]:
        """Convert tokens to IDs."""
        ids = []
        for token in tokens:
            if token not in self.token_to_id:
                if self.vocab_count < self.vocab_size:
                    self.token_to_id[token] = self.vocab_count
                    self.id_to_token[self.vocab_count] = token
                    self.vocab_count += 1
                else:
                    continue  # Skip if vocab full
            ids.append(self.token_to_id[token])
        return ids

    def decode(self, ids: List[int]) -> str:
        """Convert IDs back to text."""
        tokens = [self.id_to_token.get(id, "<unk>") for id in ids]
        return " ".join(tokens)

    def train(self, texts: List[str]) -> Dict[str, Any]:
        """
        Train the model on texts.
        
        Args:
            texts: List of text strings to learn from
            
        Returns:
            Dictionary with training statistics
        """
        total_tokens = 0
        
        for text in texts:
            tokens = self.tokenize(text)
            ids = self.encode(tokens)
            total_tokens += len(ids)
            self.tokens_seen += len(ids)
            self.texts_trained += 1
            
            # Learn bigrams (token -> next token)
            for i in range(len(ids) - 1):
                self.bigrams[ids[i]][ids[i + 1]] += 1
                
                # Learn trigrams (token1, token2 -> token3)
                if i < len(ids) - 2:
                    self.trigrams[ids[i]][ids[i + 1]][ids[i + 2]] += 1
        
        return {
            "tokens_trained": total_tokens,
            "texts_trained": len(texts),
            "vocab_size": self.vocab_count
        }

    def generate(
        self,
        prompt: str,
        max_length: int = 50,
        temperature: float = 0.8,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None
    ) -> str:
        """
        Generate text starting from a prompt.
        
        Args:
            prompt: Starting text
            max_length: Maximum tokens to generate
            temperature: Randomness (0=deterministic, 1=varied, >1=very random)
            top_k: Only sample from top k most likely tokens
            top_p: Nucleus sampling - sample from smallest set with cumulative prob >= p
            
        Returns:
            Generated text
        """
        tokens = self.tokenize(prompt)
        ids = self.encode(tokens)
        context = ids[-self.max_context:]
        
        generated = list(context)
        
        for _ in range(max_length):
            if not context:
                break
                
            # Get next token probabilities
            last_id = context[-1]
            
            if last_id not in self.bigrams:
                break  # No known continuations
            
            next_probs = self.bigrams[last_id]
            
            if not next_probs:
                break
            
            # Apply temperature
            next_id = self._sample_from_distribution(
                next_probs,
                temperature=temperature,
                top_k=top_k,
                top_p=top_p
            )
            
            if next_id is None:
                break
            
            generated.append(next_id)
            context.append(next_id)
            context = context[-self.max_context:]
        
        return self.decode(generated)

    def _sample_from_distribution(
        self,
        distribution: Counter,
        temperature: float = 1.0,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None
    ) -> Optional[int]:
        """Sample from a probability distribution with temperature and filtering."""
        if not distribution:
            return None
        
        # Convert to probabilities
        total = sum(distribution.values())
        probs = {token: count / total for token, count in distribution.items()}
        
        # Apply temperature
        if temperature != 1.0:
            probs = {
                token: math.exp(math.log(p / temperature + 1e-10)) 
                for token, p in probs.items()
            }
            # Renormalize
            total = sum(probs.values())
            probs = {token: p / total for token, p in probs.items()}
        
        # Top-k filtering
        if top_k:
            sorted_probs = sorted(probs.items(), key=lambda x: x[1], reverse=True)
            top_k_probs = dict(sorted_probs[:top_k])
            total = sum(top_k_probs.values())
            probs = {token: p / total for token, p in top_k_probs.items()}
        
        # Top-p (nucleus) filtering
        if top_p:
            sorted_probs = sorted(probs.items(), key=lambda x: x[1], reverse=True)
            cumsum = 0
            filtered = {}
            for token, prob in sorted_probs:
                cumsum += prob
                filtered[token] = prob
                if cumsum >= top_p:
                    break
            total = sum(filtered.values())
            probs = {token: p / total for token, p in filtered.items()}
        
        # Sample
        tokens, probabilities = zip(*probs.items())
        return random.choices(tokens, weights=probabilities)[0]

    def get_fluency_level(self) -> str:
        """Determine fluency level based on tokens seen."""
        if self.tokens_seen < 100:
            return "babbling"
        elif self.tokens_seen < 500:
            return "toddler"
        elif self.tokens_seen < 2000:
            return "child"
        elif self.tokens_seen < 10000:
            return "teenager"
        else:
            return "eloquent"

    def export_state(self) -> Dict[str, Any]:
        """Export model state to dictionary."""
        return {
            "vocab_size": self.vocab_size,
            "max_context": self.max_context,
            "token_to_id": self.token_to_id,
            "id_to_token": {int(k): v for k, v in self.id_to_token.items()},
            "vocab_count": self.vocab_count,
            "bigrams": {
                str(k): dict(v) for k, v in self.bigrams.items()
            },
            "trigrams": {
                str(k): {str(k2): dict(v2) for k2, v2 in v.items()}
                for k, v in self.trigrams.items()
            },
            "tokens_seen": self.tokens_seen,
            "texts_trained": self.texts_trained,
        }

    def import_state(self, state: Dict[str, Any]) -> None:
        """Import model state from dictionary."""
        self.vocab_size = state["vocab_size"]
        self.max_context = state["max_context"]
        self.token_to_id = state["token_to_id"]
        self.id_to_token = {int(k): v for k, v in state["id_to_token"].items()}
        self.vocab_count = state["vocab_count"]
        
        # Restore bigrams
        self.bigrams = defaultdict(Counter)
        for k, v in state["bigrams"].items():
            self.bigrams[int(k)] = Counter(v)
        
        # Restore trigrams
        self.trigrams = defaultdict(lambda: defaultdict(Counter))
        for k, v in state["trigrams"].items():
            for k2, v2 in v.items():
                self.trigrams[int(k)][int(k2)] = Counter(v2)
        
        self.tokens_seen = state["tokens_seen"]
        self.texts_trained = state["texts_trained"]


__all__ = ["SimpleLLM"]
