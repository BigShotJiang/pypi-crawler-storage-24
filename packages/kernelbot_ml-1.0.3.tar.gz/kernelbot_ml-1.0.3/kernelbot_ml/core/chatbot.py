"""
LearningChatbot - Simple learning-focused chatbot

Pure learning interface without dataset management.
"""

import json
import os
from typing import Dict, List, Any, Optional
from pathlib import Path
from .nlp_engine import SimpleLLM


class LearningChatbot:
    """
    A simple learning chatbot using token-based learning.
    Train on text and generate responses based on learned patterns.
    """

    def __init__(self, name: str, storage_dir: str = "bots"):
        """
        Initialize a learning chatbot.
        
        Args:
            name: Bot name (used for file storage)
            storage_dir: Directory to save bot state
        """
        self.name = name
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(exist_ok=True)
        
        self.learning_model = SimpleLLM()
        self.conversation_history = []
        self.state_file = self.storage_dir / f"{name}.json"
        
        # Load existing state if available
        if self.state_file.exists():
            self.load_state()

    def chat(self, user_input: str) -> Dict[str, Any]:
        """
        Generate a response based on learned patterns.
        
        Args:
            user_input: User message
            
        Returns:
            {"response": str, "confidence": float}
        """
        response = self.learning_model.generate(
            user_input,
            max_length=30,
            temperature=0.7,
            top_k=10,
            top_p=0.9
        )
        
        result = {
            "response": response,
            "confidence": 0.5 if self.learning_model.tokens_seen > 0 else 0.0
        }
        
        # Record conversation
        self.conversation_history.append({
            "user": user_input,
            "bot": response
        })
        
        # Auto-save after each chat
        self.save_state()
        
        return result

    def learn(self, text: str, weight: int = 1) -> Dict[str, Any]:
        """
        Learn from text. Can call multiple times to reinforce learning.
        
        Args:
            text: Text to learn from
            weight: How many times to process this text (for emphasis)
            
        Returns:
            {"status": str, "tokens_learned": int, "fluency": str}
        """
        texts = [text] * weight
        stats = self.learning_model.train(texts)
        
        # Save after learning
        self.save_state()
        
        return {
            "status": "success",
            "tokens_learned": stats['tokens_trained'],
            "fluency": self.get_fluency_level()
        }

    def learn_from_data(self, qa_pairs: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        Learn from question-answer pairs.
        
        Args:
            qa_pairs: List of {"input": "...", "output": "..."} dicts
            
        Returns:
            Learning statistics
        """
        texts = []
        for pair in qa_pairs:
            if "input" in pair and "output" in pair:
                texts.append(pair["input"] + " " + pair["output"])
        
        stats = self.learning_model.train(texts)
        self.save_state()
        
        return {
            "status": "success",
            "items_learned": len(qa_pairs),
            "total_tokens": self.learning_model.tokens_seen,
            "fluency": self.get_fluency_level()
        }

    def get_statistics(self) -> Dict[str, Any]:
        """Get bot learning statistics."""
        return {
            "name": self.name,
            "fluency_level": self.get_fluency_level(),
            "tokens_seen": self.learning_model.tokens_seen,
            "texts_trained": self.learning_model.texts_trained,
            "vocabulary_size": self.learning_model.vocab_count,
            "conversations": len(self.conversation_history)
        }

    def get_fluency_level(self) -> str:
        """Get bot's fluency level."""
        return self.learning_model.get_fluency_level()

    def save_state(self, filename: Optional[str] = None) -> str:
        """
        Save bot state to JSON file.
        
        Args:
            filename: Optional custom filename (auto-save uses bot name)
            
        Returns:
            Path to saved file
        """
        if filename:
            filepath = self.storage_dir / f"{filename}.json"
        else:
            filepath = self.state_file
        
        state = {
            "name": self.name,
            "learning_model": self.learning_model.export_state(),
            "conversation_history": self.conversation_history,
        }
        
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=2, ensure_ascii=False)
        
        return str(filepath)

    def load_state(self, filename: Optional[str] = None) -> Dict[str, str]:
        """
        Load bot state from JSON file.
        
        Args:
            filename: Optional custom filename
            
        Returns:
            Status message
        """
        if filename:
            filepath = self.storage_dir / f"{filename}.json"
        else:
            filepath = self.state_file
        
        if not filepath.exists():
            return {"status": "error", "message": f"State file not found: {filepath}"}
        
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                state = json.load(f)
            
            self.learning_model.import_state(state["learning_model"])
            self.conversation_history = state.get("conversation_history", [])
            
            return {"status": "success", "message": "State loaded successfully"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def export_state(self, filename: str) -> str:
        """Export bot state to file."""
        return self.save_state(filename)

    def import_state(self, filepath: str) -> Dict[str, str]:
        """Import bot state from file."""
        filename = Path(filepath).stem
        return self.load_state(filename)

    def clear_history(self) -> Dict[str, str]:
        """Clear conversation history."""
        self.conversation_history = []
        self.save_state()
        return {"status": "success", "message": "Conversation history cleared"}

    def get_conversation_history(self) -> List[Dict[str, str]]:
        """Get conversation history."""
        return self.conversation_history

    def reset(self) -> Dict[str, str]:
        """Reset all learning and start fresh."""
        self.learning_model = SimpleLLM()
        self.conversation_history = []
        self.save_state()
        return {"status": "success", "message": "Learning reset - started fresh"}

    def delete(self) -> Dict[str, str]:
        """Delete bot and saved state."""
        if self.state_file.exists():
            self.state_file.unlink()
            return {"status": "success", "message": f"Bot '{self.name}' deleted"}
        return {"status": "error", "message": f"Bot '{self.name}' not found"}
