import re

_REGEX_SOH=re.compile(r'^\d{1,3}\.\d%$')

class BatteryUnitInfoUnit(object):
	def __init__(self,diz:dict):
		self.sn:str=diz["sn"]
		self.soh:str=diz["soh"]
		assert re.match(_REGEX_SOH,self.soh),self.soh
