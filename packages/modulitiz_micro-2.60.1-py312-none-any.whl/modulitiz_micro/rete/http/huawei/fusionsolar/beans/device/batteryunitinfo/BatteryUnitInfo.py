from modulitiz_micro.rete.http.huawei.fusionsolar.beans.device.batteryunitinfo.BatteryUnitInfoUnit import BatteryUnitInfoUnit


class BatteryUnitInfo(object):
	def __init__(self,diz:dict):
		self.unit1:list[BatteryUnitInfoUnit]=[BatteryUnitInfoUnit(x) for x in diz.get("unit1",[])]
		self.unit2:list[BatteryUnitInfoUnit]=[BatteryUnitInfoUnit(x) for x in diz.get("unit2",[])]
		self.unit3:list[BatteryUnitInfoUnit]=[BatteryUnitInfoUnit(x) for x in diz.get("unit3",[])]
		self.unit4:list[BatteryUnitInfoUnit]=[BatteryUnitInfoUnit(x) for x in diz.get("unit4",[])]
