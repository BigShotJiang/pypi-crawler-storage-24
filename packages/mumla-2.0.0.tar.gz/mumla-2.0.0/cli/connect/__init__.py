"""
MUMLA CLI - Connect Module

Multi-agent integration system for connecting MUMLA to AI coding agents.
"""
