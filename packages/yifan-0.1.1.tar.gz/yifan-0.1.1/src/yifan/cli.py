from __future__ import annotations

import sys
from typing import Optional, Sequence

from . import __version__


def render_cow(message: str) -> str:
    width = len(message)
    top = " " + "_" * (width + 2)
    middle = f"< {message} >"
    bottom = " " + "-" * (width + 2)
    cow = r"""        \   ^__^
         \  (oo)\_______
            (__)\       )\/\
                ||----w |
                ||     ||"""
    return "\n".join([top, middle, bottom, cow])


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)

    if args and args[0] in {"-V", "--version", "version"}:
        print(__version__)
        return 0

    message = "你看牛魔"
    print(render_cow(message))
    return 0
