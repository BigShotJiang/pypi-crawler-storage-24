# yifan

A tiny CLI that prints a cow.

## Usage

```bash
uvx yifan
```
