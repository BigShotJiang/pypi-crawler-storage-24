# Benchmarks

## django-vcache vs Django RedisCache

Measured on Python 3.14 with granian ASGI server, 300 concurrent connections, 30 seconds, 2ms network RTT. Each request performs 6 cache operations (get, get_many, set, set compressed, incr, get compressed).

| | django-vcache | Django RedisCache | Δ |
|---|---|---|---|
| **Requests/sec** | 1,921 | 111 | **17x faster** |
| **Avg latency** | 156 ms | 2,659 ms | **17x lower** |
| **Peak RSS** | 125 MB | 356 MB | **−65%** |
| **Valkey connections** | 2 | 2,694 | |

Under sustained load, Django RedisCache memory keeps climbing (60 MB → 356 MB in 30 seconds) while django-vcache stays flat at ~120 MB.

## Why the difference?

Django's built-in `RedisCache` wraps every async call in `sync_to_async`, spawning a thread per operation. Under load this creates thousands of TCP connections and unbounded memory growth. Each connection carries per-connection buffers and Python object overhead that accumulates over time.

django-vcache uses a Rust I/O driver with a single multiplexed connection. No connection pool to tune, no per-connection overhead. The throughput advantage grows with network latency — multiplexing pipelines operations across one connection instead of waiting for round-trips on thousands.

## Reproduce

```bash
docker compose build
docker compose up -d valkey
docker compose run --rm --cap-add NET_ADMIN app bash -c \
  "python bench_quick.py -c 300 -z 30"
```
