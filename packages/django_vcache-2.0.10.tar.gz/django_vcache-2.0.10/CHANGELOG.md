# Changelog

## 2.0.10

### Bug fixes

- **Fix contextvars corruption in callback mode** — `add_done_callback` discarded the `context` parameter, and `_wake` invoked callbacks without their associated context. When an async cache operation took longer than 5 event loop polls (triggering callback mode), asyncio's `Task.__step` was called without the task's `contextvars.Context`. This caused `ContextVar.reset(token)` to raise `ValueError: was created in a different Context` in downstream middleware (e.g. allauth's `AccountMiddleware`). Done-callbacks are now stored as `(callback, context)` pairs and invoked via `context.run(callback, self)`, matching `asyncio.Future`'s contract.

## 2.0.7

### Bug fixes

- **Fix event loop stall under GIL contention** — When Django ORM queries (via `sync_to_async`) held the GIL while async cache operations hit the slow path, the watcher tasks blocked tokio worker threads waiting for GIL acquisition. Under sustained load this caused cascading starvation: tokio couldn't process redis I/O, more operations hit the slow path, and the event loop froze completely (health endpoint timeouts, pod restarts). Fixed by storing results via a Rust mutex (no GIL) and dispatching `call_soon_threadsafe` to `spawn_blocking` so tokio workers never block on the GIL.
- **Fix cancel support** — `RustAwaitable.cancel()` now works correctly with asyncio's Task protocol. `cancel()`, `cancelled()`, `done()`, `result()`, and `exception()` all handle the cancelled state properly including raising `CancelledError`.
- **Fix error classification** — Separate connection/transient errors (`PyConnectionError`, swallowed by `IGNORE_EXCEPTIONS`) from data/server errors (`PyRuntimeError`, always propagated) across all sync and async operations. Previously, server errors like `WRONGTYPE` were misclassified as connection errors and silently ignored.
- **Fix thread safety in driver init** — Remove racy fast-path read outside lock in `_get_or_create_driver()` that could return a partially-initialized driver under concurrent access.

## 2.0.5

### Performance

- **Rewrite async bridge — zero-overhead CPU burn fix** — The v2.0.4 callback-based approach had a 12% throughput regression and 2x P99 latency increase vs the old busy-yield. Replaced with a deferred-callback approach: the tokio task does `tx.send()` with zero GIL interaction; `__next__` polls `try_recv()` directly (fast path, identical to old busy-yield). Only if the result isn't ready after one yield does it lazily get the event loop and spawn a lightweight watcher for callback-based suspend. Result: zero throughput regression, zero CPU burn at idle.

## 2.0.4

### Bug fixes

- **Fix async busy-yield CPU burn** — Async operations (especially blocking ones like `BLMPOP`/`BLMOVE`) burned 100% CPU while waiting. A 1-second `BLMPOP` on an empty queue consumed 0.95s of CPU time. The Rust awaitable now uses a hybrid poll-first strategy: `__next__` checks the oneshot channel directly (zero overhead when the tokio task already completed), falling back to the asyncio Task callback protocol (`_asyncio_future_blocking`, `add_done_callback`) so the event loop sleeps on epoll for slower operations. CPU usage drops to 0%. Peak RSS steady at ~30 MB under sustained load.

## 2.0.3

### Bug fixes

- **Fix TLS (rediss://) PanicException** — Connecting to a `rediss://` URL crashed with `PanicException: Could not automatically determine the process-level CryptoProvider from Rustls crate features`. The rustls crypto provider (ring) is now installed at module init.
- **Use system trust store for TLS** — TLS cert verification uses `rustls-native-certs` instead of bundled Mozilla roots, so custom CAs installed in the system trust store are respected — matching Python ecosystem behavior (`requests`, `psycopg`, etc.).
- **Support `#insecure` TLS flag** — `rediss://host:port/db#insecure` skips certificate verification, useful for development and staging environments with self-signed certs.

## 2.0.2

### Bug fixes

- **Fix blmpop with count=1** — Always send the `COUNT` argument to `BLMPOP`. Without it, Redis returns a flat `[key, element]` instead of `[key, [element]]`, which broke response parsing.

## 2.0.1

### Bug fixes

- **Fix blmpop response parsing** — `BLMPOP` returned only the key name instead of `(key, [elements...])`. The redis crate's `FromRedisValue` doesn't handle the nested response format correctly; now parsed manually.
- **Fix StopIteration tuple unpacking** — PyO3's `new_err()` unpacked tuple return values into multiple args, causing `StopIteration.value` to lose all but the first element. Affected any driver method returning a tuple (e.g. `blmpop`).
- **Increase ConnectionManager response timeout** — Default was too aggressive for concurrent workloads with blocking operations. Increased to 30s.

### Other changes

- Switch zstd fallback from `zstd` to `pyzstd` (the library Python 3.14's `compression.zstd` is based on, per PEP 784).

## 2.0.0

Complete rewrite of the I/O layer. Replaces valkey-py with a thin Rust driver (via PyO3) for native async I/O and multiplexed connections.

### What changed

- **Rust I/O driver** — Single multiplexed connection handles all sync and async operations. No connection pool to tune.
- **Native async** — True async I/O instead of `sync_to_async` thread-pool wrappers.
- **TLS support** — `rediss://` and `valkeys://` URLs work out of the box (via rustls, no OpenSSL dependency).
- **Cluster mode** — `CLUSTER_MODE: True` option for Valkey/Redis Cluster (auto-discovers nodes).
- **Sentinel failover** — Automatic re-discovery on failover errors.
- **Atomic incr/decr** — Uses native Redis `INCRBY`/`DECRBY`. Keys created on first use.
- **Pickle serializer option** — `"SERIALIZER": "pickle"` for projects that need to cache arbitrary Python objects.
- **Django 6.0 support** — Tested on Django 5.0–6.0, Python 3.12–3.14.

### Benchmarks

Python 3.14, granian ASGI, 300 concurrent connections, 2ms simulated RTT (tc netem).
Each request performs 6 cache operations (get, get_many, set, set compressed, incr, get compressed).

| | django-vcache 2.0 | django-vcache 1.x (valkey-py + libvalkey) | Change |
|---|---|---|---|
| **Requests/sec** | 698 | 551 | **+27%** |
| **Peak RSS** | 135 MB | 143 MB | **−6%** |
| **Valkey connections** | 2 | 301 | |

RSS difference grows under sustained load — valkey-py memory keeps climbing while 2.x stays flat.

### Breaking changes

- Requires a Rust toolchain to build from source (pre-built wheels available for common platforms).
- `get_raw_client()` now returns the Rust driver instance, not a valkey-py client.
- Removed valkey-py dependency.

## 1.0.0

Initial stable release. We'll begin to use semantic versioning.

- Use msgpack serialization
