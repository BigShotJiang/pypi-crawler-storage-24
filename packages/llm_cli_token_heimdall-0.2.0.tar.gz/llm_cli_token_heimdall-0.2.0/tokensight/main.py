import typer
from rich.console import Console
import sys

# Import core components lazily if needed, or at top level
from tokensight.core.interceptor import LiveInterceptor
from tokensight.core.storage_engine import StorageEngine

app = typer.Typer(
    name="heimdall",
    help="LLM Heimdall: Universal AI CLI Proxy, Firewall & Intelligence Gateway",
    no_args_is_help=True,
)
console = Console()

@app.command()
def detect():
    """Detect supported AI CLIs on the system."""
    from tokensight.core.plugin_manager import PluginManager
    pm = PluginManager()
    console.print("[bold green]Detecting AI CLIs...[/bold green]")
    cmds = pm.list_supported_commands()
    for cmd in cmds:
        console.print(f"{cmd} [green]detected[/green]")

@app.command()
def dashboard():
    """Launch the Heimdall terminal dashboard."""
    from tokensight.ui.dashboard_tui import DashboardApp
    tui = DashboardApp()
    tui.run()

from typing import Optional, List

@app.command()
def replay(
    session_id: str = "",
    compare: List[str] = []
):
    """Replay a session or compare two prompts."""
    from tokensight.core.replay_engine import TokenReplayEngine
    engine = TokenReplayEngine()
    
    if compare and len(compare) == 2:
        engine.compare_prompts(compare[0], compare[1])
    elif session_id:
        engine.replay_session(session_id)
    else:
        console.print("[red]Error:[/red] Must provide either a session_id or two files to --compare.")


@app.command()
def init():
    """Initialize Heimdall configuration and local database."""
    StorageEngine()
    console.print("[bold green]Heimdall initialized successfully.[/bold green]")

@app.command()
def stats():
    """Display token usage statistics and charts."""
    from tokensight.ui.charts import display_stats
    display_stats()

@app.command()
def update_pricing():
    """Update local model pricing from the community datastore."""
    from tokensight.core.cost_engine import CostEngine
    engine = CostEngine()
    console.print("[dim]Fetching latest pricing database...[/dim]")
    success = engine.update_pricing()
    if success:
        console.print("[bold green]Pricing database updated successfully![/bold green]")
    else:
        console.print("[bold red]Failed to update pricing database. Check your connection.[/bold red]")

@app.command()
def alert(
    daily_cost: Optional[float] = None,
    tokens: Optional[int] = None
):
    """Check usage against configured alert thresholds."""
    from tokensight.core.alert_engine import AlertEngine
    engine = AlertEngine()
    engine.check_alerts(daily_cost_limit=daily_cost, total_tokens_limit=tokens)

@app.command()
def run(
    tool: str,
    command: Optional[List[str]] = typer.Argument(None),
):
    """Run an AI CLI tool through the Heimdall interceptor."""
    if command is None:
        command = []
    interceptor = LiveInterceptor()
    exit_code = interceptor.intercept_and_run(tool, command)
    sys.exit(exit_code)

@app.command()
def lint(prompt_file: str):
    """Analyze prompt quality and detect token waste."""
    from tokensight.agents.linter_agent import PromptLinterAgent
    import os
    
    if not os.path.exists(prompt_file):
        console.print(f"[red]Error:[/red] File {prompt_file} not found.")
        raise typer.Exit(1)
        
    with open(prompt_file, 'r') as f:
        prompt = f.read()
        
    linter = PromptLinterAgent()
    linter.display_report(prompt)

@app.command()
def compress(prompt_file: str):
    """Reduce token usage by removing redundant context and formatting."""
    from tokensight.core.compression_engine import CompressionEngine
    import os
    
    if not os.path.exists(prompt_file):
        console.print(f"[red]Error:[/red] File {prompt_file} not found.")
        raise typer.Exit(1)
        
    with open(prompt_file, 'r') as f:
        prompt = f.read()
        
    engine = CompressionEngine()
    compressed = engine.compress(prompt)
    
    console.print("[bold green]Compressed Prompt:[/bold green]\\n")
    console.print(compressed)

@app.command()
def optimize(prompt_file: str):
    """Automatically rewrite prompt to reduce token usage while preserving meaning."""
    from tokensight.agents.optimizer_agent import AutonomousOptimizerAgent
    import os
    
    if not os.path.exists(prompt_file):
        console.print(f"[red]File not found: {prompt_file}[/red]")
        sys.exit(1)
        
    with open(prompt_file, 'r', encoding='utf-8') as f:
        prompt = f.read()
        
    optimizer = AutonomousOptimizerAgent()
    optimizer.display_optimization(prompt)
    
    console.print("\\n[bold green]Optimized Prompt:[/bold green]\\n")
    # The 'optimized' variable is not directly available here after display_optimization
    # Assuming display_optimization prints it or the user intended to print the result of optimize()
    # For now, I'll keep the original structure as much as possible, but note this discrepancy.
    # If display_optimization returns the optimized prompt, it should be captured.
    # As per the instruction, the line `optimized = optimizer.optimize(prompt)` was removed.
    # I will remove the `console.print(optimized)` line as `optimized` is no longer defined.
    # If display_optimization prints the optimized prompt, then these lines are redundant.
    # If display_optimization does not print it, then the instruction has removed the printing mechanism.
    # Given the instruction, I will remove the line that prints `optimized` as it's no longer assigned.
    # If the intent was to print the result of display_optimization, that would require a change to display_optimization.

@app.command()
def config(daily_limit: float = typer.Argument(..., help="Set your daily maximum spend limit in USD ($)")):
    """Configure Heimdall global settings (e.g. daily dollar limit)."""
    from tokensight.core.storage_engine import StorageEngine
    storage = StorageEngine()
    cfg = storage.get_config()
    cfg["daily_limit"] = daily_limit
    storage.set_config(cfg)
    console.print(f"[bold green]Daily budget successfully set to ${daily_limit:.2f}[/bold green]")

@app.command("install-aliases")
def install_aliases():
    """Install shell aliases so AI CLIs automatically run through Heimdall."""
    from pathlib import Path
    import os
    
    aliases = [
        '\n# LLM Heimdall Managed Aliases',
        'alias gemini="heimdall run gemini"',
        'alias claude="heimdall run claude"',
        'alias cursor="heimdall run cursor"',
        'alias gpt="heimdall run gpt"',
        'alias openai="heimdall run openai"'
    ]
    
    rc_files = [".zshrc", ".bashrc"]
    installed = False
    
    for rc in rc_files:
        rc_path = Path.home() / rc
        if rc_path.exists():
            with open(rc_path, "a", encoding="utf-8") as f:
                f.write("\n".join(aliases) + "\n")
            console.print(f"[green]✔ Installed aliases into {rc_path}[/green]")
            installed = True
            
    if installed:
        console.print("[bold yellow]Please restart your terminal or run `source ~/.zshrc` (or `.bashrc`) for the changes to take effect![/bold yellow]")
    else:
        console.print("[red]Could not find .zshrc or .bashrc. You may need to add the aliases manually.[/red]")

@app.command()
def export(output_file: str = typer.Argument(..., help="Path to save the CSV file"), days: int = typer.Option(30, help="Number of days to export")):
    """Export Heimdall usage data to a CSV file for reporting."""
    from tokensight.core.storage_engine import StorageEngine
    import csv
    
    storage = StorageEngine()
    data = storage.get_usage_since(days)
    
    if not data:
        console.print("[yellow]No data available to export.[/yellow]")
        return
        
    try:
        with open(output_file, mode='w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(["ID", "Timestamp", "Session", "CLI Tool", "Model", "Project", "Input Tokens", "Output Tokens", "Total Tokens", "Estimated Cost ($)"])
            for u in data:
                writer.writerow([
                    u.id, u.timestamp.isoformat(), u.session_id, u.cli_tool, u.model,
                    u.project, u.input_tokens, u.output_tokens, u.total_tokens, f"{u.estimated_cost:.6f}"
                ])
        console.print(f"[bold green]✔ Successfully exported {len(data)} records to {output_file}[/bold green]")
    except Exception as e:
        console.print(f"[red]Failed to export: {e}[/red]")

if __name__ == "__main__":
    app()
