import re
from typing import Optional, Dict, Any, Tuple
from tokensight.plugins.base_adapter import BaseCLIAdapter

class GeminiAdapter(BaseCLIAdapter):
    @property
    def name(self) -> str:
        return "Gemini CLI Adapter"
        
    @property
    def supported_commands(self) -> list[str]:
        return ["gemini", "gemini-cli"]
        
    def parse_command(self, args: list[str]) -> Tuple[Optional[str], Optional[str]]:
        # Extremely basic parsing: looking for --model or inferring from default
        model = "gemini-1.5-pro" # default
        prompt = None
        
        for i, arg in enumerate(args):
            if arg in ("--model", "-m") and i + 1 < len(args):
                model = args[i + 1]
                
        # Heuristic: the last argument that doesn't start with - might be the prompt
        for arg in reversed(args):
            if not arg.startswith("-"):
                prompt = arg[:100] + "..." if len(arg) > 100 else arg
                break
                
        return model, prompt

    def parse_output(self, stdout: str, stderr: str) -> Dict[str, Any]:
        """
        Parse output. Assuming the gemini CLI might output something like:
        Token usage: 154 input, 400 output, 554 total
        OR it might have no explicit token counts if streaming, in which case we might default to 0.
        """
        metrics = {
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0
        }
        
        # Look for explicit token counts in standard output or error (some CLIs log to stderr)
        combined_output = stdout + "\\n" + stderr
        
        # Regex to match patterns like "prompt token count: 123" or "10 input"
        input_match = re.search(r'(?i)(\d+)\s+(?:input|prompt)', combined_output) or re.search(r'(?i)(?:input|prompt) tokens?.*?(\d+)', combined_output)
        output_match = re.search(r'(?i)(\d+)\s+(?:output|completion|candidate)', combined_output) or re.search(r'(?i)(?:output|completion|candidate) tokens?.*?(\d+)', combined_output)
        total_match = re.search(r'(?i)(\d+)\s+total', combined_output) or re.search(r'(?i)total tokens?.*?(\d+)', combined_output)
        
        if input_match:
            metrics["input_tokens"] = int(input_match.group(1))
        if output_match:
            metrics["output_tokens"] = int(output_match.group(1))
        if total_match:
            metrics["total_tokens"] = int(total_match.group(1))
        elif input_match and output_match:
            metrics["total_tokens"] = metrics["input_tokens"] + metrics["output_tokens"]
            
        return metrics
