from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, Tuple

class BaseCLIAdapter(ABC):
    """Base class for all AI CLI adapters."""
    
    @property
    @abstractmethod
    def supported_commands(self) -> list[str]:
        """List of root CLI commands this adapter supports (e.g. ['gemini', 'gcloud'])."""
        pass
        
    @property
    @abstractmethod
    def name(self) -> str:
        """Name of the adapter."""
        pass

    @abstractmethod
    def parse_command(self, args: list[str]) -> Tuple[Optional[str], Optional[str]]:
        """
        Parse CLI arguments to determine model and input prompt.
        Returns: (model_name, prompt_snippet)
        """
        pass

    @abstractmethod
    def parse_output(self, stdout: str, stderr: str) -> Dict[str, Any]:
        """
        Parse the output of the CLI tool to extract token metrics.
        Returns dictionary with keys: input_tokens, output_tokens, total_tokens, model (optional).
        """
        pass
