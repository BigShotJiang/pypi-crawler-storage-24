import importlib
import pkgutil
from pathlib import Path
from typing import Dict, Type
from tokensight.plugins.base_adapter import BaseCLIAdapter

class PluginManager:
    def __init__(self):
        self.adapters: Dict[str, BaseCLIAdapter] = {}
        self._discover_plugins()

    def _discover_plugins(self):
        """Automatically discover and load all plugins in the plugins package."""
        import tokensight.plugins as plugins_pkg
        
        # Load all modules in the plugins directory
        pkg_path = Path(plugins_pkg.__file__).parent
        for _, name, _ in pkgutil.iter_modules([str(pkg_path)]):
            if name == "base_adapter":
                continue
                
            module = importlib.import_module(f"tokensight.plugins.{name}")
            
            # Find classes inheriting from BaseCLIAdapter
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if isinstance(attr, type) and issubclass(attr, BaseCLIAdapter) and attr is not BaseCLIAdapter:
                    adapter_instance = attr()
                    for cmd in adapter_instance.supported_commands:
                        self.adapters[cmd] = adapter_instance
                        
    def get_adapter(self, command: str) -> BaseCLIAdapter | None:
        """Get the adapter for a specific CLI command."""
        return self.adapters.get(command)
        
    def list_supported_commands(self) -> list[str]:
        return list(self.adapters.keys())
