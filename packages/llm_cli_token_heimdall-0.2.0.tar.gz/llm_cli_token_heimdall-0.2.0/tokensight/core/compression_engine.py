import re

class CompressionEngine:
    """
    Reduces token usage by removing redundant context,
    semantic summarization (heuristics), and prompt deduplication.
    """
    def __init__(self):
        pass

    def compress(self, text: str) -> str:
        """Apply a chain of compression rules to the text."""
        if not text:
            return ""
        result = text
        result = self._remove_filler_words(result)
        result = self._remove_redundant_phrases(result)
        result = self._remove_extra_whitespace(result)
        return result
        
    def _remove_extra_whitespace(self, text: str) -> str:
        # Collapse multiple spaces and newlines aggressively
        text = re.sub(r' +', ' ', text)
        text = re.sub(r'\n{3,}', '\n\n', text)
        text = re.sub(r'\t+', ' ', text)
        return text.strip()
        
    def _remove_filler_words(self, text: str) -> str:
        # Remove common phrases that add no semantic value to an LLM
        fillers = [
            r"(?i)please[,\s]*", 
            r"(?i)can\s+you\s+", 
            r"(?i)could\s+you\s+", 
            r"(?i)i\s+would\s+like\s+you\s+to\s+", 
            r"(?i)would\s+you\s+mind\s+", 
            r"(?i)i\s+want\s+you\s+to\s+", 
            r"(?i)i\s+need\s+you\s+to\s+",
            r"(?i)i\s+would\s+really\s+appreciate\s+it\s+if\s+you\s+could\s+ensure\s+that\s+",
            r"(?i)i\s+would\s+really\s+appreciate\s+it\s+if\s+you\s+could\s+",
            r"(?i)thank\s+you\s+in\s+advance[.\s]*", 
            r"(?i)thank\s+you\s*so\s*much!?[.\s]*",
            r"(?i)thank\s+you[.\s]*"
        ]
        
        for filler in fillers:
            text = re.sub(filler, "", text)
            
        # Clean up stray punctuation left by removals (e.g. " ,")
        text = re.sub(r'\s+,', ',', text)
        text = re.sub(r'^\s*,\s*', '', text) # leading comma
        return text
        
    def _remove_redundant_phrases(self, text: str) -> str:
        phrases = [
            r"(?i)\\bas i said before\\b", r"(?i)\\bto reiterate\\b", r"(?i)\\bin other words\\b"
        ]
        for phrase in phrases:
            text = re.sub(phrase, "", text)
        return text
