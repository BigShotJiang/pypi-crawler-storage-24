from rich.console import Console
from tokensight.core.storage_engine import StorageEngine
from tokensight.core.tokenizer import TokenCounter
from tokensight.core.compression_engine import CompressionEngine
import os

console = Console()

class TokenReplayEngine:
    def __init__(self):
        self.storage = StorageEngine()
        self.compressor = CompressionEngine()

    def replay_session(self, session_id: str):
        """Simulates analyzing historical prompts for a given session."""
        console.print(f"[bold cyan]Replaying Session:[/bold cyan] {session_id}")
        
        # Fetch session
        all_usage = self.storage.get_recent_usage(limit=1000)
        session_usage = [u for u in all_usage if u.session_id.startswith(session_id)]
        
        if not session_usage:
            console.print(f"[red]Error:[/red] Session {session_id} not found.")
            return
            
        console.print(f"[dim]Found {len(session_usage)} records. Simulating replay analysis...[/dim]")
        
        original_tokens = 0
        optimized_tokens = 0
        
        for usage in session_usage:
            original_tokens += usage.total_tokens
            if usage.prompt_snippet:
                compressed = self.compressor.compress(usage.prompt_snippet)
                compressed_len = TokenCounter.count_tokens(compressed, usage.model)
                optimized_tokens += compressed_len + usage.output_tokens
            else:
                optimized_tokens += usage.total_tokens
                
        console.print("\\n[green]Replay Analysis Complete![/green]")
        console.print(f"Tokens used originally: {original_tokens}")
        console.print(f"Optimized tokens (simulated): {optimized_tokens}")
        if original_tokens > 0:
            savings = (original_tokens - optimized_tokens) / original_tokens * 100
            console.print(f"Potential savings: [yellow]{savings:.1f}%[/yellow]")
        else:
            console.print("Potential savings: [yellow]0%[/yellow]")

    def compare_prompts(self, prompt1_path: str, prompt2_path: str):
        """Compare token efficiency of two prompt files."""
        if not os.path.exists(prompt1_path) or not os.path.exists(prompt2_path):
            console.print("[red]Error:[/red] One or both prompt files not found.")
            return
            
        console.print(f"[bold cyan]Comparing Prompts:[/bold cyan] {prompt1_path} vs {prompt2_path}")
        
        with open(prompt1_path, 'r') as f1, open(prompt2_path, 'r') as f2:
            prompt1 = f1.read()
            prompt2 = f2.read()
            
        len1 = TokenCounter.count_tokens(prompt1, "default")
        len2 = TokenCounter.count_tokens(prompt2, "default")
        
        console.print("\\n[green]Comparison Complete![/green]")
        console.print(f"Prompt 1 ({prompt1_path}): {len1} tokens")
        console.print(f"Prompt 2 ({prompt2_path}): {len2} tokens")
        
        if len1 > len2:
            savings = (len1 - len2) / len1 * 100
            console.print(f"Winner: [yellow]Prompt 2 ({savings:.1f}% more efficient)[/yellow]")
        elif len2 > len1:
            savings = (len2 - len1) / len2 * 100
            console.print(f"Winner: [yellow]Prompt 1 ({savings:.1f}% more efficient)[/yellow]")
        else:
            console.print(f"Winner: [yellow]Tie (Same efficiency)[/yellow]")
