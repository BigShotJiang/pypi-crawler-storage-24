import logging
from typing import Optional

logger = logging.getLogger(__name__)

class TokenCounter:
    """Estimates tokens locally."""
    
    @staticmethod
    def count_tokens(text: str, model: str = "default") -> int:
        if not text:
            return 0
            
        try:
            import tiktoken
            # Try to get the encoding for the specific model
            try:
                encoding = tiktoken.encoding_for_model(model)
            except KeyError:
                # Fallback encoding
                encoding = tiktoken.get_encoding("cl1k_base")
            return len(encoding.encode(text))
        except ImportError:
            # Fallback heuristic: 1 token ~= 4 chars typically for English
            return max(1, len(text) // 4)
