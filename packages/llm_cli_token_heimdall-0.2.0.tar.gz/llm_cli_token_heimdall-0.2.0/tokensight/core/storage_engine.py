import sqlite3
import json
from pathlib import Path
from datetime import datetime, timezone
from pydantic import BaseModel, Field

DB_PATH = Path.home() / ".tokensight" / "tokensight.db"

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

class TokenUsage(BaseModel):
    id: int | None = None
    session_id: str
    cli_tool: str
    model: str
    timestamp: datetime = Field(default_factory=utc_now)
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    estimated_cost: float = 0.0
    prompt_snippet: str | None = None
    project: str = "default"

class StorageEngine:
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS token_usage (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT,
                    cli_tool TEXT,
                    model TEXT,
                    timestamp TEXT,
                    input_tokens INTEGER,
                    output_tokens INTEGER,
                    total_tokens INTEGER,
                    estimated_cost REAL,
                    prompt_snippet TEXT,
                    project TEXT DEFAULT 'default'
                )
            ''')
            # Attempt migration if project column doesn't exist
            try:
                conn.execute("ALTER TABLE token_usage ADD COLUMN project TEXT DEFAULT 'default'")
            except sqlite3.OperationalError:
                pass # Column exists
            conn.commit()

    def record_usage(self, usage: TokenUsage) -> int:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO token_usage (
                    session_id, cli_tool, model, timestamp, 
                    input_tokens, output_tokens, total_tokens, 
                    estimated_cost, prompt_snippet, project
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                usage.session_id, usage.cli_tool, usage.model, 
                usage.timestamp.isoformat(),
                usage.input_tokens, usage.output_tokens, usage.total_tokens,
                usage.estimated_cost, usage.prompt_snippet, usage.project
            ))
            conn.commit()
            return cursor.lastrowid
            
    def get_recent_usage(self, limit: int = 50) -> list[TokenUsage]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute('''
                SELECT * FROM token_usage 
                ORDER BY timestamp DESC LIMIT ?
            ''', (limit,))
            rows = cursor.fetchall()
            return [
                TokenUsage(**dict(row)) for row in rows
            ]

    def get_usage_since(self, days: int) -> list[TokenUsage]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute('''
                SELECT * FROM token_usage 
                WHERE datetime(timestamp) >= datetime('now', ?)
                ORDER BY timestamp DESC
            ''', (f'-{days} days',))
            rows = cursor.fetchall()
            return [
                TokenUsage(**dict(row)) for row in rows
            ]

    def get_daily_cost(self) -> float:
        """Returns the total cost accrued today."""
        usages = self.get_usage_since(1)
        return sum(u.estimated_cost for u in usages)
        
    def get_config(self) -> dict:
        """Fetch the token sight global config."""
        config_path = self.db_path.parent / "config.json"
        default_config = {
            "daily_limit": 5.0,
            "enforce_hard_limits": False,
            "webhook_url": ""
        }
        if not config_path.exists():
            return default_config
        try:
            with open(config_path, "r") as f:
                cfg = json.load(f)
                # merge with defaults to ensure keys exist
                return {**default_config, **cfg}
        except Exception:
            return default_config

    def set_config(self, config: dict) -> None:
        """Save config."""
        config_path = self.db_path.parent / "config.json"
        with open(config_path, "w") as f:
            json.dump(config, f)
