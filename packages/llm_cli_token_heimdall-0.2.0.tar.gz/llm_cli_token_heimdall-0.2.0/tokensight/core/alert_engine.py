from rich.console import Console
from tokensight.core.storage_engine import StorageEngine

console = Console()

class AlertEngine:
    def __init__(self):
        self.storage = StorageEngine()
        
    def check_alerts(self, daily_cost_limit: float = None, total_tokens_limit: int = None):
        """Check if any usage thresholds are exceeded."""
        recent_usage = self.storage.get_recent_usage(limit=1000)
        
        # Simple aggregation for prototype
        total_cost = sum(u.estimated_cost for u in recent_usage)
        total_tokens = sum(u.total_tokens for u in recent_usage)
        
        alerts_triggered = []
        
        if daily_cost_limit is not None and total_cost >= daily_cost_limit:
            alerts_triggered.append(f"Cost limit exceeded: ${total_cost:.2f} >= ${daily_cost_limit:.2f}")
            
        if total_tokens_limit is not None and total_tokens >= total_tokens_limit:
            alerts_triggered.append(f"Token limit exceeded: {total_tokens} >= {total_tokens_limit}")
            
        if not alerts_triggered:
            console.print("[green]All metrics are within limits.[/green]")
        else:
            for alert in alerts_triggered:
                console.print(f"[bold red]ALERT:[/bold red] {alert}")
