import subprocess
import uuid
import time
import threading
from typing import Optional
from tokensight.core.plugin_manager import PluginManager
from tokensight.core.storage_engine import StorageEngine, TokenUsage
from tokensight.core.cost_engine import CostEngine
from rich.console import Console

console = Console()

class LiveInterceptor:
    def __init__(self, storage: Optional[StorageEngine] = None):
        self.plugin_manager = PluginManager()
        self.storage = storage or StorageEngine()
        self.cost_engine = CostEngine()
        from tokensight.core.cache_engine import SemanticCacheEngine
        self.cache_engine = SemanticCacheEngine()
        
    def _send_webhook(self, url: str, tool: str, cost: float, tokens: int) -> None:
        import urllib.request
        import json
        payload = {"text": f"⚠️ *Heimdall Alert:* `{tool}` execution spent ${cost:.4f} ({tokens} tokens)"}
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers={'Content-Type': 'application/json'}, method='POST')
        try:
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass
        
    def _preflight_check(self, model: str, args: list[str]) -> bool:
        """Analyze arguments for files/urls, estimate cost, and prompt user. Returns True to proceed, False to abort."""
        from tokensight.core.tokenizer import TokenCounter
        from tokensight.core.compression_engine import CompressionEngine
        import os
        import urllib.request
        import tempfile
        from rich.panel import Panel

        estimated_total = 0
        arg_details = []
        for i, arg in enumerate(args):
            source_type = "text"
            content = arg
            
            if os.path.isfile(arg):
                source_type = "file"
                try:
                    with open(arg, 'r', encoding='utf-8') as f:
                        content = f.read()
                except Exception:
                    pass
            elif arg.startswith("http://") or arg.startswith("https://"):
                source_type = "url"
                try:
                    req = urllib.request.Request(arg, headers={'User-Agent': 'Mozilla/5.0'})
                    with urllib.request.urlopen(req, timeout=3) as response:
                        content = response.read().decode('utf-8')
                except Exception:
                    pass
            
            tokens = TokenCounter.count_tokens(content, model) if len(content) > 10 else 0
            estimated_total += tokens
            
            arg_details.append({
                "index": i, "original": arg, "content": content,
                "type": source_type, "tokens": tokens
            })
            
        # Alert threshold (e.g. 200 tokens)
        if estimated_total < 200:
            return True

        cost = self.cost_engine.estimate_cost(model, estimated_total, int(estimated_total * 0.2)) # Guess 20% output relation
        
        current_daily = self.storage.get_daily_cost()
        config = self.storage.get_config()
        limit = config.get("daily_limit", 5.0)
        projected = current_daily + cost
        
        limit_alert = ""
        enforce_hard_limits = config.get("enforce_hard_limits", False)
        
        if projected >= limit:
            if enforce_hard_limits:
                console.print(f"\n[bold red]⛔ EXECUTION BLOCKED ⛔[/bold red]\nYour daily budget of ${limit:.2f} is exceeded (${projected:.2f} projected). Configure via `tokensight config`.")
                return False
            else:
                limit_alert = f"\n[bold red]WARNING: This execution exceeds your daily limit of ${limit:.2f}! (${projected:.2f} projected today)[/bold red]"
        elif projected >= limit * 0.8:
            limit_alert = f"\n[bold yellow]CAUTION: 80% daily budget reached. (${projected:.2f} of ${limit:.2f} projected today)[/bold yellow]"
        
        console.print(Panel(
            f"[bold yellow]Pre-flight Token Analysis[/bold yellow]\n"
            f"Context size: [cyan]{estimated_total:,}[/cyan] input tokens detected.\n"
            f"Estimated run cost (Input + Output): [bold red]~${cost:.5f}[/bold red]{limit_alert}", 
            title="Heimdall Pre-Execution Alert", border_style="yellow", expand=False
        ))
        
        choice = console.input("[bold]Optimize tokens before executing? (y = optimize, c = continue original, a = abort): [/bold]").lower()
        if choice == 'a':
            console.print("[red]Execution aborted by user.[/red]")
            return False
            
        if choice == 'y':
            console.print("[dim]Analyzing and compressing large context blocks...[/dim]")
            engine = CompressionEngine()
            
            saved_total = 0
            for item in arg_details:
                if item["tokens"] > 100: # Only compress large chunks
                    compressed = engine.compress(item["content"])
                    new_tokens = TokenCounter.count_tokens(compressed, model)
                    saved = item["tokens"] - new_tokens
                    
                    if saved > 0:
                        saved_total += saved
                        if item["type"] == "text" or item["type"] == "url":
                            args[item["index"]] = compressed
                        elif item["type"] == "file":
                            fd, temp_path = tempfile.mkstemp(suffix=".txt", text=True)
                            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                                f.write(compressed)
                            args[item["index"]] = temp_path
                            console.print(f"[dim]  Mapped {item['original']} to temporary optimized file[/dim]")
            
            saved_cost = self.cost_engine.estimate_cost(model, saved_total, 0)
            console.print(f"[bold green]Optimization complete! Eliminated {saved_total:,} tokens (Saved ~${saved_cost:.5f}).[/bold green]")
            console.print("[dim]Executing optimized command...[/dim]\n")
            
        return True
        
    def intercept_and_run(self, tool: str, args: list[str]) -> int:
        """Run the CLI tool, intercept output, and log token usage."""
        adapter = self.plugin_manager.get_adapter(tool)
        
        if not adapter:
            console.print(f"[yellow]Warning: No adapter found for {tool}. Running unmonitored, tracking tokens by size.[/yellow]")
            model = "unknown"
            prompt = " ".join(args)
        else:
            model, prompt = adapter.parse_command(args)
            
        session_id = str(uuid.uuid4())
        
        console.print(f"[dim]Heimdall monitoring session {session_id[:8]}...[/dim]")
        
        prompt_key = prompt if prompt else " ".join(args)
        cached = self.cache_engine.get_cached_response(tool, prompt_key)
        if cached is not None:
            console.print("[bold green]🌟 Heimdall Cache Hit! 🌟[/bold green] (100% tokens saved)")
            if "stdout" in cached and cached["stdout"]:
                print(cached["stdout"], end="")
            if "stderr" in cached and cached["stderr"]:
                import sys
                print(cached["stderr"], end="", file=sys.stderr)
            
            
            import os
            
            project_name = "default"
            current_dir = os.getcwd()
            if os.path.exists(os.path.join(current_dir, ".git")):
                project_name = os.path.basename(current_dir)
                
            usage = TokenUsage(
                session_id=session_id, cli_tool=tool, model=model or "unknown",
                input_tokens=0, output_tokens=0, total_tokens=0, estimated_cost=0.0,
                prompt_snippet=prompt_key, project=project_name
            )
            self.storage.record_usage(usage)
            return 0
        
        # Inject Pre-flight check!
        if not self._preflight_check(model or "unknown", args):
            return 1 # Abort
        
        start_time = time.time()
        
        # Run the command
        # We use Popen with subprocess.PIPE to capture output, but we also want to display it
        # to the user in real-time. This can be tricky with PTYs, but we'll use a basic approach.
        # Alternatively, we can let it run normally with stdout/stderr passthrough if adapter
        # allows parsing from logs, but here we capture it. For a pure CLI, we might need to 
        # tee the output.
        
        # Use threads to read stdout/stderr simultaneously and stream to console
        try:
            process = subprocess.Popen(
                [tool] + args, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )
            
            stdout_lines = []
            stderr_lines = []
            
            def read_stream(stream, is_err=False):
                try:
                    for line in iter(stream.readline, ""):
                        if not line:
                            break
                        if is_err:
                            stderr_lines.append(line)
                            print(line, end="", flush=True)
                        else:
                            stdout_lines.append(line)
                            print(line, end="", flush=True)
                except Exception:
                    pass
            
            t_out = threading.Thread(target=read_stream, args=(process.stdout, False))
            t_err = threading.Thread(target=read_stream, args=(process.stderr, True))
            
            t_out.start()
            t_err.start()
            
            process.wait()
            t_out.join()
            t_err.join()
            
            full_stdout = "".join(stdout_lines)
            full_stderr = "".join(stderr_lines)
            
            elapsed = time.time() - start_time
            
            # Parse metrics
            if adapter:
                metrics = adapter.parse_output(full_stdout, full_stderr)
                input_tokens = metrics.get("input_tokens", 0)
                output_tokens = metrics.get("output_tokens", 0)
                total_tokens = metrics.get("total_tokens", 0)
            else:
                input_tokens = 0
                output_tokens = 0
                total_tokens = 0
            
            # If no tokens found by adapter, estimate them based on prompt and output
            if total_tokens == 0:
                from tokensight.core.tokenizer import TokenCounter
                input_tokens = TokenCounter.count_tokens(prompt or "", model or "default")
                output_tokens = TokenCounter.count_tokens(full_stdout or "", model or "default")
                total_tokens = input_tokens + output_tokens
                
            if total_tokens > 0:
                cost = self.cost_engine.estimate_cost(model or "unknown", input_tokens, output_tokens)
                
                import os
                project_name = "default"
                current_dir = os.getcwd()
                if os.path.exists(os.path.join(current_dir, ".git")):
                    project_name = os.path.basename(current_dir)
                    
                usage = TokenUsage(
                    session_id=session_id,
                    cli_tool=tool,
                    model=model or "unknown",
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=total_tokens,
                    estimated_cost=cost,
                    prompt_snippet=prompt,
                    project=project_name
                )
                
                self.storage.record_usage(usage)
                console.print(f"\n[dim]Heimdall: {total_tokens} tokens recorded (${cost:.5f}) for project '{project_name}'.[/dim]")
                
                # Save cache for future savings
                self.cache_engine.save_response(tool, prompt_key, full_stdout, full_stderr)
                
                # Report an alert if a single operation costs over $0.05 or configured
                config = self.storage.get_config()
                webhook_url = config.get("webhook_url", "")
                if webhook_url and cost > 0.05:
                    self._send_webhook(webhook_url, tool, cost, total_tokens)
                    
            else:
                console.print(f"\n[dim]Heimdall: No action recorded (0 tokens calculated).[/dim]")
                
            return process.returncode
            
        except FileNotFoundError:
            console.print(f"[red]Error: Command '{tool}' not found.[/red]")
            return 127
