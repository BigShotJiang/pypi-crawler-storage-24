import json
import urllib.request
from pathlib import Path

class CostEngine:
    def __init__(self):
        self.cache_path = Path.home() / ".tokensight" / "pricing.json"
        self.pricing_table = {
            "gemini-1.5-pro": {"input": 3.50, "output": 10.50},
            "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
            "claude-3-5-sonnet-20241022": {"input": 3.00, "output": 15.00},
            "claude-3-5-haiku-20241022": {"input": 0.25, "output": 1.25},
            "gpt-4o": {"input": 5.00, "output": 15.00},
            "gpt-4o-mini": {"input": 0.15, "output": 0.60},
        }
        self._load_cached_pricing()

    def _load_cached_pricing(self):
        """Load pricing from local cache if it exists."""
        if self.cache_path.exists():
            try:
                with open(self.cache_path, "r") as f:
                    cached = json.load(f)
                if cached:
                    self.pricing_table.update(cached)
            except Exception:
                pass

    def update_pricing(self) -> bool:
        """Fetch the latest model prices from an open source community list (LiteLLM)."""
        url = "https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json"
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode())
                
            new_pricing = {}
            for model_name, details in data.items():
                if isinstance(details, dict) and "input_cost_per_token" in details and "output_cost_per_token" in details:
                    # Convert cost per token to cost per 1M tokens
                    in_cost = details.get("input_cost_per_token", 0) * 1_000_000
                    out_cost = details.get("output_cost_per_token", 0) * 1_000_000
                    if in_cost > 0 or out_cost > 0:
                        new_pricing[model_name] = {"input": in_cost, "output": out_cost}
                        
            if new_pricing:
                self.pricing_table.update(new_pricing)
                self.cache_path.parent.mkdir(parents=True, exist_ok=True)
                with open(self.cache_path, "w") as f:
                    json.dump(self.pricing_table, f)
                return True
        except Exception:
            pass
        return False

    def estimate_cost(self, model: str, input_tokens: int, output_tokens: int) -> float:
        """Estimate the cost of a token usage event."""
        model_lower = model.lower()
        
        # simple heuristic fallback
        matched_model = None
        for known_model in self.pricing_table:
            if known_model in model_lower:
                matched_model = known_model
                break
                
        if matched_model is None:
            # Fallback to a baseline estimate instead of $0
            matched_model = "gpt-4o-mini"
            
        pricing = self.pricing_table[matched_model]
        
        cost_input = (input_tokens / 1_000_000) * pricing["input"]
        cost_output = (output_tokens / 1_000_000) * pricing["output"]
        
        return cost_input + cost_output
