import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

class SemanticCacheEngine:
    def __init__(self, cache_dir: Path = None):
        self.cache_dir = cache_dir or Path.home() / ".tokensight" / "cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
    def _get_hash(self, tool: str, prompt: str) -> str:
        content = f"{tool}:{prompt}"
        return hashlib.sha256(content.encode('utf-8')).hexdigest()
        
    def get_cached_response(self, tool: str, prompt: str) -> dict | None:
        """Returns the cached (stdout, stderr) if found, else None"""
        if not prompt:
            return None
            
        hash_key = self._get_hash(tool, prompt)
        cache_file = self.cache_dir / f"{hash_key}.json"
        
        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data
            except Exception:
                return None
        return None
        
    def save_response(self, tool: str, prompt: str, stdout: str, stderr: str) -> None:
        """Saves the output of a prompt to the cache"""
        if not prompt:
            return
            
        hash_key = self._get_hash(tool, prompt)
        cache_file = self.cache_dir / f"{hash_key}.json"
        
        data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "tool": tool,
            "stdout": stdout,
            "stderr": stderr
        }
        
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(data, f)
