"""
Heimdall CLI - Universal CLI Token Intelligence Platform
"""
__version__ = "0.1.0"
