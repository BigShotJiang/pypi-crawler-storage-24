from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, DataTable, Static, TabbedContent, TabPane
from tokensight.core.storage_engine import StorageEngine

class DashboardApp(App):
    """Heimdall TUI Dashboard for deep visibility into token usage and costs."""
    
    CSS = """
    DataTable {
        height: 100%;
    }
    .summary-box {
        height: auto;
        dock: top;
        padding: 1;
        background: $boost;
        color: auto;
        text-align: center;
        text-style: bold;
        border: solid $accent;
    }
    """
    
    BINDINGS = [("q", "quit", "Quit"), ("r", "refresh", "Refresh")]
    
    def compose(self) -> ComposeResult:
        yield Header()
        yield Static("Total Spend: $0.00 | Total Tokens: 0", id="summary", classes="summary-box")
        
        with TabbedContent(initial="tab-24h"):
            with TabPane("Last 24 Hours", id="tab-24h"):
                yield DataTable(id="table-24h")
            with TabPane("Last 7 Days", id="tab-7days"):
                yield DataTable(id="table-7days")
            with TabPane("Last 30 Days", id="tab-30days"):
                yield DataTable(id="table-30days")
            with TabPane("All Model Breakdown", id="tab-models"):
                yield DataTable(id="table-models")

        yield Footer()
        
    def on_mount(self) -> None:
        self.storage = StorageEngine()
        
        for name in ["table-24h", "table-7days", "table-30days"]:
            table = self.query_one(f"#{name}", DataTable)
            table.add_columns("Timestamp (Local)", "Session", "Tool", "Model", "Total Tokens", "Cost ($)")
            
        model_tbl = self.query_one("#table-models", DataTable)
        model_tbl.add_columns("Model Name", "Total Invocations", "Total Tokens", "Estimated Cost ($)")
            
        self.refresh_data()
        
    def action_refresh(self) -> None:
        self.refresh_data()
        
    def refresh_data(self) -> None:
        usage_today = self.storage.get_usage_since(1)
        usage_7d = self.storage.get_usage_since(7)
        usage_30d = self.storage.get_usage_since(30)
        all_usage = self.storage.get_recent_usage(limit=1000)
        
        # Update summary box
        total_cost = sum(u.estimated_cost for u in all_usage)
        total_tokens = sum(u.total_tokens for u in all_usage)
        t_today = sum(u.total_tokens for u in usage_today)
        c_today = sum(u.estimated_cost for u in usage_today)
        
        summary = self.query_one("#summary", Static)
        summary.update(
            f" [green]All-Time Spend: ${total_cost:.5f}[/green] | [blue]All-Time Tokens: {total_tokens:,}[/blue]\n"
            f" [yellow]Last 24h Spend: ${c_today:.5f}[/yellow]   | [cyan]Last 24h Tokens: {t_today:,}[/cyan]"
        )
        
        import datetime
        local_tz = datetime.datetime.now().astimezone().tzinfo
        
        def populate_table(tbl_id, data):
            tbl = self.query_one(f"#{tbl_id}", DataTable)
            tbl.clear()
            for u in data:
                # Convert UTC to local before formatting
                local_time = u.timestamp.replace(tzinfo=datetime.timezone.utc).astimezone(local_tz) if not u.timestamp.tzinfo else u.timestamp.astimezone(local_tz)
                tbl.add_row(
                    local_time.strftime("%Y-%m-%d %H:%M"), u.session_id[:8], u.cli_tool,
                    u.model[:15], f"{u.total_tokens:,}", f"${u.estimated_cost:.5f}"
                )
                
        populate_table("table-24h", usage_today)
        populate_table("table-7days", usage_7d)
        populate_table("table-30days", usage_30d)
        
        # Aggregate Models
        models = {}
        for u in all_usage:
            m = u.model
            if m not in models:
                models[m] = {"invocations": 0, "tokens": 0, "cost": 0.0}
            models[m]["invocations"] += 1
            models[m]["tokens"] += u.total_tokens
            models[m]["cost"] += u.estimated_cost
            
        model_tbl = self.query_one("#table-models", DataTable)
        model_tbl.clear()
        for m, d in sorted(models.items(), key=lambda item: item[1]["cost"], reverse=True):
            model_tbl.add_row(m, str(d["invocations"]), f"{d['tokens']:,}", f"${d['cost']:.5f}")

if __name__ == "__main__":
    app = DashboardApp()
    app.run()
