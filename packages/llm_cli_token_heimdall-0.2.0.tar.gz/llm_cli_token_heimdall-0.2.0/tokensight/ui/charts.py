from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from tokensight.core.storage_engine import StorageEngine

console = Console()

def display_stats():
    """Display CLI stats and charts."""
    storage = StorageEngine()
    recent = storage.get_recent_usage(limit=100)
    
    # Aggregate by model
    models = {}
    for usage in recent:
        if usage.model not in models:
            models[usage.model] = {"tokens": 0, "cost": 0.0}
        models[usage.model]["tokens"] += usage.total_tokens
        models[usage.model]["cost"] += usage.estimated_cost
        
    table = Table(title="Model Usage Distribution")
    table.add_column("Model", justify="left", style="cyan")
    table.add_column("Tokens", justify="right", style="magenta")
    table.add_column("Cost ($)", justify="right", style="green")
    
    for model, data in models.items():
        table.add_row(model, str(data["tokens"]), f"{data['cost']:.5f}")
        
    if not models:
        console.print("[yellow]No data available to chart.[/yellow]")
        return
        
    console.print(Panel(table, expand=False))
