from rich.console import Console

console = Console()

class PromptLinterAgent:
    """
    Analyzes prompts for inefficiencies, excessive verbosity, 
    and redundant examples using Google ADK (or local heuristic fallback).
    """
    def __init__(self):
        # In a real ADK implementation, we would initialize the agent here.
        # For this prototype, we will use a mix of heuristics and mock ADK layout.
        pass

    def lint_prompt(self, prompt: str) -> dict:
        """Analyze the prompt quality and predict token waste."""
        waste_score = 0
        issues = []
        
        # Word length heuristic
        words = prompt.split()
        if len(words) > 500:
            issues.append("Prompt is very long (>500 words). Consider summarization.")
            waste_score += 20
            
        if len(words) > 1500:
            issues.append("Prompt is likely exceeding standard context windows efficiently.")
            waste_score += 15

        # Filler heuristics
        fillers = ["please", "can you", "could you", "would you mind", "i want you to", "i need you to"]
        prompt_lower = prompt.lower()
        filler_count = sum(prompt_lower.count(f) for f in fillers)
        if filler_count > 0:
            issues.append(f"Found {filler_count} politeness/filler phrases. LLMs don't need 'please'. Remove to save tokens.")
            waste_score += min(15, filler_count * 3)

        # Formatting heuristics
        if "```" in prompt and len(prompt.split("```")) > 5:
            issues.append("Multiple code blocks detected. Ensure only necessary code is included in context.")
            waste_score += 10
            
        import re
        if len(re.findall(r'\\n\\n\\n+', prompt)) > 2:
            issues.append("Excessive whitespace/newlines detected.")
            waste_score += 5
            
        # Redundancy heuristic
        if "to reiterate" in prompt_lower or "in other words" in prompt_lower or "again," in prompt_lower:
            issues.append("Possible repetition detected ('to reiterate', etc.). Be direct.")
            waste_score += 10

        return {
            "score": max(0, 100 - waste_score),
            "token_waste_score": waste_score,
            "issues": issues
        }

    def display_report(self, prompt: str):
        report = self.lint_prompt(prompt)
        console.print(f"\\n[bold blue]Tokensight Lint Report[/bold blue]")
        console.print(f"Prompt Quality Score: [green]{report['score']}/100[/green]")
        console.print(f"Token Waste Score: [yellow]{report['token_waste_score']}[/yellow]")
        if report['issues']:
            console.print("[bold red]Issues Detected:[/bold red]")
            for issue in report['issues']:
                console.print(f"- {issue}")
