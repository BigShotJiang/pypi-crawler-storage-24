from rich.console import Console
from tokensight.agents.linter_agent import PromptLinterAgent
from tokensight.core.compression_engine import CompressionEngine

console = Console()

class AutonomousOptimizerAgent:
    """
    An agent that automatically rewrites prompts to reduce token usage
    while preserving meaning.
    """
    def __init__(self):
        self.linter = PromptLinterAgent()
        self.compressor = CompressionEngine()
        
    def optimize(self, prompt: str) -> str:
        """Optimize the prompt using compression and restructuring."""
        console.print("[dim]Analyzing prompt for optimization...[/dim]")
        
        # 1. Lint to detect issues
        report = self.linter.lint_prompt(prompt)
        
        if report["token_waste_score"] == 0 and len(prompt.split()) < 50:
            console.print("[green]Prompt is already highly optimized. No changes needed.[/green]")
            return prompt
            
        # 2. Compress the prompt
        console.print("[dim]Applying compression algorithms...[/dim]")
        optimized_prompt = self.compressor.compress(prompt)
        
        original_len = len(prompt.split())
        new_len = len(optimized_prompt.split())
        reduction = 100 - (new_len / max(1, original_len) * 100)
        
        console.print(f"\\n[bold green]Optimization Complete![/bold green]")
        console.print(f"Original length: {original_len} words")
        console.print(f"Optimized length: {new_len} words")
        console.print(f"Token reduction: [yellow]{reduction:.1f}%[/yellow]")
        
        return optimized_prompt
