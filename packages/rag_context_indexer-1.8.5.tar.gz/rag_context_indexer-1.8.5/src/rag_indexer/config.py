"""
@RAG_CONTEXT
{
  "archivo": "src/rag_indexer/config.py",
  "lineas": 100,
  "tokens_estimados": 1023,
  "hash_contenido": "8b01613a0bdd023b50d2b719fc8af8685ec8407f3f18d2558c17b7fd10d0939c",
  "creacion": "2026-03-04",
  "modificacion": "2026-03-09",
  "tags": [
    "get_logger",
    "os",
    "dotenv",
    ".logger",
    "load_dotenv"
  ],
  "descripcion_corta": "Configuración global con soporte RAG_AI_PROVIDER/RAG_API_KEY",
  "descripcion_larga": "Módulo central de configuración. Carga .env y resuelve ACTIVE_LLM con precedencia: RAG_AI_PROVIDER (rag-indexer api) > ACTIVE_LLM env > 'openai'. API_KEYS parchado con RAG_API_KEY si el proveedor fue configurado vía wizard. save_api_credentials() escribe .env preservando otras variables y llama a _ensure_env_in_gitignore() para proteger credenciales automáticamente."
}
"""
import os
from dotenv import load_dotenv

load_dotenv(os.path.join(os.getcwd(), '.env'))

# Soporte para configuración unificada via `rag-indexer api`
_rag_provider = os.environ.get("RAG_AI_PROVIDER", "").strip().lower()
ACTIVE_LLM = _rag_provider if _rag_provider else os.environ.get("ACTIVE_LLM", "openai").lower()
USE_CODE_MODEL = os.environ.get("USE_CODE_MODEL", "false").lower() == "true"

API_KEYS = {
    "openai":    os.environ.get("OPENAI_API_KEY", ""),
    "anthropic": os.environ.get("ANTHROPIC_API_KEY", ""),
    "gemini":    os.environ.get("GEMINI_API_KEY", ""),
    "deepseek":  os.environ.get("DEEPSEEK_API_KEY", ""),
}

# RAG_API_KEY (seteada por `rag-indexer api`) tiene precedencia sobre claves individuales
_rag_api_key = os.environ.get("RAG_API_KEY", "").strip()
if _rag_provider and _rag_api_key:
    API_KEYS[_rag_provider] = _rag_api_key

MODELS = {
    "openai": {"default": "gpt-4o-mini", "code": "gpt-4o"},
    "anthropic": {"default": "claude-3-haiku-20240307", "code": "claude-3-5-sonnet-latest"},
    "gemini": {"default": "gemini-2.5-flash", "code": "gemini-2.5-pro"},
    "deepseek": {"default": "deepseek-chat", "code": "deepseek-coder"}
}

DEFAULT_EXCLUDES = {
    '.png', '.jpg', '.jpeg', '.gif', '.ico', '.pdf',
    '.zip', '.tar', '.gz', '.mp4', '.mp3', '.wav',
    '.pyc', '.pyd', '.so', '.dll', '.exe', '.bin'
}

# Extensiones de datos puros: nunca inyectar bloques @RAG_CONTEXT en su interior.
# La información se guarda únicamente en el índice maestro (rag-indexer.json).
DATA_ONLY_EXTENSIONS = {'.json', '.csv', '.lock', '.tsv', '.parquet'}

COMMENT_SYNTAX = {
    '.py':   {'start': '"""\n@RAG_CONTEXT\n', 'end': '\n"""\n'},
    '.js':   {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.ts':   {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.jsx':  {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.tsx':  {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.css':  {'start': '/*\n@RAG_CONTEXT\n',  'end': '\n*/\n'},
    '.html': {'start': '<!--\n@RAG_CONTEXT\n', 'end': '\n-->\n'},
    '.md':   {'start': '<!--\n@RAG_CONTEXT\n', 'end': '\n-->\n'},
}


def save_api_credentials(provider: str, api_key: str) -> None:
    """
    Persiste RAG_AI_PROVIDER y RAG_API_KEY en el .env del proyecto actual.
    Preserva el resto de variables existentes en el archivo.
    Añade .env a .gitignore automáticamente para evitar fugas de credenciales.
    """
    from .logger import get_logger
    _logger = get_logger("rag_indexer_config")

    project_root = os.getcwd()
    env_path = os.path.join(project_root, ".env")

    # Leer .env existente para no borrar otras variables
    existing_lines: list = []
    if os.path.exists(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            existing_lines = f.readlines()

    # Filtrar las claves que vamos a reescribir para no duplicarlas
    filtered = [
        line for line in existing_lines
        if not line.startswith("RAG_AI_PROVIDER=") and not line.startswith("RAG_API_KEY=")
    ]
    filtered.append(f"RAG_AI_PROVIDER={provider}\n")
    filtered.append(f"RAG_API_KEY={api_key.replace(chr(0), '')}\n")

    with open(env_path, "w", encoding="utf-8") as f:
        f.writelines(filtered)

    _logger.info(".env actualizado | proveedor=%s", provider)
    _ensure_env_in_gitignore(project_root, _logger)


def _ensure_env_in_gitignore(project_root: str, _logger) -> None:
    """Garantiza que .env esté en .gitignore para proteger las credenciales."""
    gitignore_path = os.path.join(project_root, ".gitignore")

    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f.readlines()]
        if ".env" in lines or "*.env" in lines:
            return
        with open(gitignore_path, "a", encoding="utf-8") as f:
            f.write("\n# Credenciales de rag-indexer api\n.env\n")
    else:
        with open(gitignore_path, "w", encoding="utf-8") as f:
            f.write("# Credenciales de rag-indexer api\n.env\n")

    _logger.info(".env agregado automáticamente a .gitignore")
