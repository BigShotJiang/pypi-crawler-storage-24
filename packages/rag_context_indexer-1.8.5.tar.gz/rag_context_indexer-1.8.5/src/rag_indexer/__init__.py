"""
@RAG_CONTEXT
{
  "archivo": "src/rag_indexer/__init__.py",
  "lineas": 0,
  "tokens_estimados": 0,
  "hash_contenido": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "creacion": "2026-03-04",
  "modificacion": "2026-03-09",
  "tags": [],
  "descripcion_corta": "Paquete rag_indexer (init vacío)",
  "descripcion_larga": "Archivo __init__.py vacío que marca src/rag_indexer/ como paquete Python instalable. No exporta símbolos públicos; la inicialización real ocurre en config.py (variables de entorno) y main.py (lógica CLI)."
}
"""
