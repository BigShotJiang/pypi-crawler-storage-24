"""
@RAG_CONTEXT
{
  "archivo": "src/rag_indexer/logger.py",
  "lineas": 47,
  "tokens_estimados": 355,
  "hash_contenido": "8864949aeb73ef9d522c378be4cc54c57aaafb9c22ac850d822df5fa207c1493",
  "creacion": "2026-03-09",
  "modificacion": "2026-03-09",
  "tags": [
    "logging",
    "logging.handlers",
    "os",
    "RotatingFileHandler"
  ],
  "descripcion_corta": "Fábrica de loggers con rotación en /logs/",
  "descripcion_larga": "Módulo utilitario con get_logger(module_name) que configura un Logger con dos handlers: RotatingFileHandler en /logs/{module_name}.log (DEBUG+, 5MB, 3 backups, UTF-8) y StreamHandler hacia consola (INFO+, solo el mensaje). Formato archivo: [FECHA-HORA] [NIVEL] [MÓDULO] - Mensaje. Crea /logs/ automáticamente. Fallback gracioso a solo consola si OSError. Guard `if logger.handlers` para evitar duplicados en reimportaciones."
}
"""
import logging
import os
from logging.handlers import RotatingFileHandler

LOGS_DIR = "/logs"


def get_logger(module_name: str) -> logging.Logger:
    """
    Retorna un logger configurado con:
    - RotatingFileHandler en /logs/{module_name}.log (DEBUG+, 5MB, 3 backups)
    - StreamHandler hacia consola (INFO+, solo el mensaje)
    Formato archivo: [FECHA-HORA] [NIVEL] [MÓDULO] - Mensaje | Datos Extra
    """
    logger = logging.getLogger(module_name)
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    fmt = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # --- File Handler: DEBUG+ con auto-rotación ---
    try:
        os.makedirs(LOGS_DIR, exist_ok=True)
        fh = RotatingFileHandler(
            os.path.join(LOGS_DIR, f"{module_name}.log"),
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        )
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except OSError as exc:
        logging.warning("No se pudo crear /logs/. Solo consola activa. | error=%s", exc)

    # --- Console Handler: INFO+ con output limpio para CLI ---
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(ch)

    return logger
