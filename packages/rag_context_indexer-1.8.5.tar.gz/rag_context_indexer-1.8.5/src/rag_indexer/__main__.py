"""
@RAG_CONTEXT
{
  "archivo": "src/rag_indexer/__main__.py",
  "lineas": 4,
  "tokens_estimados": 15,
  "hash_contenido": "55d870f180352b7c0f3256c94182f95aabd1cc0295799d7a9994053bd551982a",
  "creacion": "2026-03-04",
  "modificacion": "2026-03-09",
  "tags": [
    ".main",
    "main"
  ],
  "descripcion_corta": "Punto de entrada para python -m rag_indexer",
  "descripcion_larga": "Archivo __main__.py que permite ejecutar el paquete directamente con python -m rag_indexer. Importa y delega en main() de main.py, habilitando la invocación directa del módulo como alternativa al comando CLI registrado en pyproject.toml."
}
"""
from .main import main

if __name__ == "__main__":
    main()
