"""Python bindings and runtime helpers for the bundled Flash executor."""

from __future__ import annotations

import os
from pathlib import Path

from ._native import ExecResult, FlashInterpreter, LocalExecutor, MockExecutor, StdioExecutor, build_prompt_from_env

__all__ = [
    "ExecResult",
    "FlashInterpreter",
    "LocalExecutor",
    "MockExecutor",
    "StdioExecutor",
    "build_prompt_from_env",
    "bundled_stdio_executor_path",
    "configure_bundled_executor",
]


def bundled_stdio_executor_path() -> Path | None:
    name = "flash-stdio-executor.exe" if os.name == "nt" else "flash-stdio-executor"
    candidate = Path(__file__).resolve().parent / "bin" / name
    if not candidate.is_file():
        return None
    try:
        mode = candidate.stat().st_mode
        candidate.chmod(mode | 0o111)
    except OSError:
        pass
    return candidate


def configure_bundled_executor() -> Path | None:
    if os.environ.get("FLASH_STDIO_EXECUTOR_BIN"):
        return Path(os.environ["FLASH_STDIO_EXECUTOR_BIN"])
    bundled = bundled_stdio_executor_path()
    if bundled is not None:
        os.environ["FLASH_STDIO_EXECUTOR_BIN"] = str(bundled)
    return bundled


configure_bundled_executor()
