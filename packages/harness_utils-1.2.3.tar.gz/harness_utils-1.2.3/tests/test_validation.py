"""Tests for configuration validation."""

import pytest

from harnessutils.config import (
    CompactionConfig,
    HarnessConfig,
    ModelLimitsConfig,
    PruningConfig,
    SummarizationConfig,
    TruncationConfig,
)
from harnessutils.exceptions import ConfigurationError


def test_truncation_config_valid():
    """Test that default truncation config is valid."""
    config = TruncationConfig()
    config.validate()  # Should not raise


def test_truncation_config_invalid_max_lines():
    """Test validation catches invalid max_lines."""
    config = TruncationConfig(max_lines=0)
    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()
    assert "max_lines must be positive" in str(exc_info.value)
    assert "How to fix:" in str(exc_info.value)


def test_truncation_config_invalid_direction():
    """Test validation catches invalid direction."""
    config = TruncationConfig(direction="middle")
    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()
    assert "direction must be 'head' or 'tail'" in str(exc_info.value)


def test_pruning_config_valid():
    """Test that default pruning config is valid."""
    config = PruningConfig()
    config.validate()  # Should not raise


def test_pruning_config_invalid_protect_minimum():
    """Test validation catches prune_minimum >= prune_protect."""
    config = PruningConfig(prune_protect=10000, prune_minimum=20000)
    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()
    assert "prune_minimum" in str(exc_info.value)
    assert "must be < prune_protect" in str(exc_info.value)


def test_pruning_config_invalid_similarity_threshold():
    """Test validation catches invalid similarity_threshold."""
    config = PruningConfig(similarity_threshold=1.5)
    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()
    assert "similarity_threshold must be between 0.0 and 1.0" in str(exc_info.value)


def test_pruning_config_negative_protect_turns():
    """Test validation catches negative protect_turns."""
    config = PruningConfig(protect_turns=-1)
    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()
    assert "protect_turns must be >= 0" in str(exc_info.value)


def test_model_limits_config_valid():
    """Test that default model limits config is valid."""
    config = ModelLimitsConfig()
    config.validate()  # Should not raise


def test_model_limits_config_output_exceeds_context():
    """Test validation catches output_limit >= context_limit."""
    config = ModelLimitsConfig(default_context_limit=8000, default_output_limit=10000)
    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()
    assert "default_output_limit" in str(exc_info.value)
    assert "must be < default_context_limit" in str(exc_info.value)


def test_summarization_config_valid():
    """Test that default summarization config is valid."""
    config = SummarizationConfig()
    config.validate()  # Should not raise


def test_summarization_config_invalid_mode():
    """Test validation catches invalid mode."""
    config = SummarizationConfig(mode="incremental")
    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()
    assert "mode must be 'differential' or 'full'" in str(exc_info.value)


def test_compaction_config_valid():
    """Test that default compaction config is valid."""
    config = CompactionConfig()
    config.validate()  # Should not raise


def test_compaction_config_invalid_safety_margin():
    """Test validation catches invalid safety_margin."""
    config = CompactionConfig(predictive_safety_margin=1.5)
    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()
    assert "predictive_safety_margin must be between 0.0 and 1.0" in str(exc_info.value)


def test_harness_config_valid():
    """Test that default harness config is valid."""
    config = HarnessConfig()
    config.validate()  # Should not raise


def test_harness_config_prune_protect_too_large():
    """Test validation catches prune_protect >= usable context."""
    config = HarnessConfig()
    config.model_limits.default_context_limit = 10000
    config.model_limits.default_output_limit = 1000
    config.pruning.prune_protect = 9500  # > usable (9000)
    config.pruning.prune_minimum = 4000  # Valid value < prune_protect

    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()
    assert "prune_protect" in str(exc_info.value)
    assert "must be < usable context" in str(exc_info.value)


def test_validation_provides_remediation():
    """Test that validation errors include remediation steps."""
    config = TruncationConfig(max_lines=-5)

    with pytest.raises(ConfigurationError) as exc_info:
        config.validate()

    error_msg = str(exc_info.value)
    assert "How to fix:" in error_msg
    assert "Set max_lines to a positive integer" in error_msg
