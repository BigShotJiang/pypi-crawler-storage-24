"""Tests for context inspection API."""

from harnessutils import ConversationManager
from harnessutils.config import HarnessConfig, PruningConfig
from harnessutils.inspection import ContextInspector
from harnessutils.models.message import Message
from harnessutils.models.parts import ToolPart, ToolState
from harnessutils.utils.ids import generate_id


def test_inspector_summary_basic():
    """Test basic context summary."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add messages with tool outputs
    msg1 = Message(id=generate_id("msg"), role="user")
    manager.add_message(conv.id, msg1)

    msg2 = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="x" * 1000),
    )
    msg2.add_part(part)
    manager.add_message(conv.id, msg2)

    # Inspect
    inspector = manager.inspect_context(conv.id)
    summary = inspector.summary()

    assert summary["total_messages"] == 2
    assert summary["total_tokens"] > 0
    assert summary["tool_outputs"] == 1
    assert summary["tool_outputs_compacted"] == 0
    assert summary["summaries"] == 0


def test_inspector_summary_with_compacted():
    """Test summary includes compacted outputs."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add message with compacted output
    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="bash",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output=""),  # Empty = compacted
    )
    # Mark as compacted
    from harnessutils.models.parts import TimeInfo

    part.state.time = TimeInfo(start=1000, end=2000, compacted=3000)
    msg.add_part(part)
    manager.add_message(conv.id, msg)

    inspector = manager.inspect_context(conv.id)
    summary = inspector.summary()

    assert summary["tool_outputs"] == 1
    assert summary["tool_outputs_compacted"] == 1


def test_inspector_protected_vs_prunable():
    """Test summary distinguishes protected vs prunable tokens."""
    config = HarnessConfig()
    config.pruning = PruningConfig(protect_turns=1)

    manager = ConversationManager(config=config)
    conv = manager.create_conversation()

    # Add old message (prunable)
    msg1 = Message(id=generate_id("msg"), role="user")
    manager.add_message(conv.id, msg1)

    msg2 = Message(id=generate_id("msg"), role="assistant")
    part1 = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="old output" * 100),
    )
    msg2.add_part(part1)
    manager.add_message(conv.id, msg2)

    # Add recent message (protected)
    msg3 = Message(id=generate_id("msg"), role="user")
    manager.add_message(conv.id, msg3)

    msg4 = Message(id=generate_id("msg"), role="assistant")
    part2 = ToolPart(
        tool="write",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="recent output" * 100),
    )
    msg4.add_part(part2)
    manager.add_message(conv.id, msg4)

    inspector = manager.inspect_context(conv.id)
    summary = inspector.summary()

    assert summary["protected_tokens"] > 0, "Should have protected tokens"
    assert summary["prunable_tokens"] > 0, "Should have prunable tokens"
    assert summary["protected_tokens"] < summary["total_tokens"]
    assert summary["prunable_tokens"] < summary["total_tokens"]


def test_inspector_predict_impact_no_pruning():
    """Test impact prediction when no pruning needed."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="small output"),
    )
    msg.add_part(part)
    manager.add_message(conv.id, msg)

    inspector = manager.inspect_context(conv.id)
    impact = inspector.predict_impact(additional_tokens=1000)

    assert impact["would_trigger_pruning"] is False
    assert impact["estimated_pruned_count"] == 0
    assert impact["would_trigger_overflow"] is False
    assert impact["margin_remaining"] > 0


def test_inspector_predict_impact_triggers_pruning():
    """Test impact prediction when pruning would be triggered."""
    config = HarnessConfig()
    config.pruning = PruningConfig(prune_protect=5000, protect_turns=0)

    manager = ConversationManager(config=config)
    conv = manager.create_conversation()

    # Add multiple old messages with outputs (not protected)
    for _ in range(5):
        msg = Message(id=generate_id("msg"), role="assistant")
        part = ToolPart(
            tool="read",
            call_id=generate_id("call"),
            state=ToolState(status="completed", output="x" * 1000),
        )
        msg.add_part(part)
        manager.add_message(conv.id, msg)

    inspector = manager.inspect_context(conv.id)

    # Simulate adding lots of tokens
    impact = inspector.predict_impact(additional_tokens=10000)

    assert impact["would_trigger_pruning"] is True
    # Verify response has expected fields
    assert "estimated_pruned_count" in impact
    assert "would_trigger_overflow" in impact


def test_inspector_get_tool_output_tokens():
    """Test getting breakdown of tokens by tool type."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    # Add outputs from different tools
    msg = Message(id=generate_id("msg"), role="assistant")

    part1 = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="read output" * 100),
    )
    msg.add_part(part1)

    part2 = ToolPart(
        tool="bash",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="bash output" * 50),
    )
    msg.add_part(part2)

    manager.add_message(conv.id, msg)

    inspector = manager.inspect_context(conv.id)
    breakdown = inspector.get_tool_output_tokens()

    assert breakdown["total"] > 0
    assert "read" in breakdown["by_tool"]
    assert "bash" in breakdown["by_tool"]
    assert breakdown["by_tool"]["read"] > 0
    assert breakdown["by_tool"]["bash"] > 0
    assert breakdown["prunability_percent"] >= 0


def test_inspector_get_tool_output_tokens_protected():
    """Test tool token breakdown with protected tools."""
    config = HarnessConfig()
    config.pruning = PruningConfig(protected_tools=["write"], protect_turns=0)

    manager = ConversationManager(config=config)
    conv = manager.create_conversation()

    # Add messages in separate turns to avoid turn protection
    msg1 = Message(id=generate_id("msg"), role="user")
    manager.add_message(conv.id, msg1)

    msg2 = Message(id=generate_id("msg"), role="assistant")
    # Protected tool
    part1 = ToolPart(
        tool="write",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="write output" * 100),
    )
    msg2.add_part(part1)
    manager.add_message(conv.id, msg2)

    msg3 = Message(id=generate_id("msg"), role="user")
    manager.add_message(conv.id, msg3)

    msg4 = Message(id=generate_id("msg"), role="assistant")
    # Unprotected tool
    part2 = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="read output" * 100),
    )
    msg4.add_part(part2)
    manager.add_message(conv.id, msg4)

    inspector = manager.inspect_context(conv.id)
    breakdown = inspector.get_tool_output_tokens()

    assert breakdown["protected"] > 0, "Should have protected tokens (write tool)"
    assert breakdown["prunable"] > 0, "Should have prunable tokens (read tool)"
    assert breakdown["prunability_percent"] < 100, "Not all tokens should be prunable"


def test_inspector_get_pruning_decision():
    """Test getting pruning decision for specific part."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="test output"),
    )
    msg.add_part(part)
    manager.add_message(conv.id, msg)

    inspector = manager.inspect_context(conv.id)
    decision = inspector.get_pruning_decision(msg.id, part.call_id)

    assert decision is not None
    assert decision["pruned"] is False
    assert decision["reason"] == "in_context"


def test_inspector_direct_instantiation():
    """Test creating inspector directly with messages."""
    messages = [
        Message(id=generate_id("msg"), role="user"),
        Message(id=generate_id("msg"), role="assistant"),
    ]

    config = HarnessConfig()
    inspector = ContextInspector(messages, config)

    summary = inspector.summary()
    assert summary["total_messages"] == 2


def test_inspector_audit_trail():
    """Test audit trail returns list (even if empty for now)."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    inspector = manager.inspect_context(conv.id)
    trail = inspector.get_audit_trail()

    assert isinstance(trail, list)
    # Currently returns empty - will be populated when pruning stores decisions


def test_inspector_predict_overflow():
    """Test overflow prediction."""
    config = HarnessConfig()
    config.model_limits.default_context_limit = 10000
    config.model_limits.default_output_limit = 1000

    manager = ConversationManager(config=config)
    conv = manager.create_conversation()

    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="read",
        call_id=generate_id("call"),
        state=ToolState(status="completed", output="x" * 1000),
    )
    msg.add_part(part)
    manager.add_message(conv.id, msg)

    inspector = manager.inspect_context(conv.id)

    # Simulate adding tokens that would cause overflow
    impact = inspector.predict_impact(additional_tokens=9000)

    # usable_limit = 10000 - 1000 = 9000
    # current ~= small amount
    # projected = current + 9000 > 9000
    # So should trigger overflow
    assert impact["would_trigger_overflow"] is True or impact["margin_remaining"] < 1000


def test_audit_trail_returns_decisions():
    """After pruning, audit trail should return non-empty list of decisions."""
    from harnessutils.config import PruningConfig

    config = HarnessConfig()
    config.pruning = PruningConfig(protect_turns=0, prune_protect=0, prune_minimum=0)

    manager = ConversationManager(config=config)
    conv = manager.create_conversation()

    # Add several messages with tool outputs
    for i in range(5):
        msg_u = Message(id=generate_id("msg"), role="user")
        manager.add_message(conv.id, msg_u)

        msg_a = Message(id=generate_id("msg"), role="assistant")
        part = ToolPart(
            tool="read",
            call_id=generate_id("call"),
            state=ToolState(status="completed", output="output content " * 50),
        )
        msg_a.add_part(part)
        manager.add_message(conv.id, msg_a)

    # Prune
    manager.prune_before_turn(conv.id)

    # Inspect context - audit trail should be populated
    inspector = manager.inspect_context(conv.id)
    trail = inspector.get_audit_trail()

    assert isinstance(trail, list)
    assert len(trail) > 0
    # Each entry should have required fields
    entry = trail[0]
    assert "message_id" in entry
    assert "decision" in entry
    assert "tool" in entry


def test_audit_trail_empty_before_pruning():
    """Audit trail is empty when no pruning has happened."""
    manager = ConversationManager()
    conv = manager.create_conversation()

    inspector = manager.inspect_context(conv.id)
    trail = inspector.get_audit_trail()

    assert trail == []
