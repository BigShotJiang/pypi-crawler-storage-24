"""Tests for Phase 3D: Cleanup Hooks (Maintenance API)."""

import time

from harnessutils.config import HarnessConfig, PruningConfig
from harnessutils.maintenance import (
    CleanupResult,
    ContextIssue,
    cleanup_stale_data,
    detect_context_issues,
    scan_and_deduplicate,
)
from harnessutils.manager import ConversationManager
from harnessutils.models.conversation import Conversation
from harnessutils.models.message import Message
from harnessutils.models.parts import TextPart, ToolPart
from harnessutils.models.usage import CacheUsage, Usage
from harnessutils.storage.memory import MemoryStorage


def create_test_message(
    message_id: str,
    timestamp: int | None = None,
    has_error: bool = False,
    tool_output: str | None = None,
    role: str = "assistant",
) -> Message:
    """Helper to create test messages.

    Args:
        message_id: Message ID
        timestamp: Optional timestamp
        has_error: Whether message has error
        tool_output: Optional tool output content
        role: Message role

    Returns:
        Test message
    """
    if timestamp is None:
        timestamp = int(time.time() * 1000)

    msg = Message(
        id=message_id,
        role=role,
        tokens=Usage(
            input=0,
            output=100,
            cache=CacheUsage(read=0, write=0),
        ),
        metadata={"timestamp": timestamp},
    )

    if role == "user":
        msg.add_part(TextPart(text="test user message"))
    elif tool_output:
        tool_part = ToolPart(tool="test_tool")
        if has_error:
            tool_part.state.status = "error"
            tool_part.state.output = f"Error: {tool_output}"
            msg.error = "Test error"
        else:
            tool_part.state.status = "completed"
            tool_part.state.output = tool_output
        msg.add_part(tool_part)
    else:
        msg.add_part(TextPart(text="test assistant message"))

    return msg


# =============================================================================
# Cleanup Tests
# =============================================================================


def test_cleanup_stale_data_basic():
    """Test basic stale data cleanup."""
    current_time = int(time.time() * 1000)
    old_time = current_time - (48 * 3600 * 1000)  # 48 hours ago

    messages = [
        create_test_message(
            "msg1", timestamp=old_time, tool_output="old output 1"
        ),  # Stale
        create_test_message(
            "msg2", timestamp=current_time, tool_output="new output 1"
        ),  # Fresh
        create_test_message(
            "msg3", timestamp=old_time, tool_output="old output 2"
        ),  # Stale
    ]

    config = PruningConfig()
    result = cleanup_stale_data(messages, config, max_age_hours=24, keep_errors=True)

    assert result.stale_outputs_pruned == 2  # 2 stale outputs
    assert result.tokens_freed > 0
    assert len(result.operations) > 0


def test_cleanup_keeps_errors():
    """Test that cleanup preserves error messages when keep_errors=True."""
    current_time = int(time.time() * 1000)
    old_time = current_time - (48 * 3600 * 1000)

    messages = [
        create_test_message(
            "msg1", timestamp=old_time, tool_output="error content", has_error=True
        ),
        create_test_message("msg2", timestamp=old_time, tool_output="normal output"),
    ]

    config = PruningConfig()
    result = cleanup_stale_data(messages, config, max_age_hours=24, keep_errors=True)

    # Only non-error should be identified as stale
    assert result.stale_outputs_pruned == 1


def test_cleanup_removes_errors_when_configured():
    """Test that cleanup can remove errors when keep_errors=False."""
    current_time = int(time.time() * 1000)
    old_time = current_time - (48 * 3600 * 1000)

    messages = [
        create_test_message(
            "msg1", timestamp=old_time, tool_output="error content", has_error=True
        ),
        create_test_message("msg2", timestamp=old_time, tool_output="normal output"),
    ]

    config = PruningConfig()
    result = cleanup_stale_data(messages, config, max_age_hours=24, keep_errors=False)

    # Both should be identified as stale
    assert result.stale_outputs_pruned == 2


def test_cleanup_result_serialization():
    """Test CleanupResult to_dict."""
    result = CleanupResult(
        messages_archived=5,
        tokens_freed=1000,
        duplicates_removed=3,
        stale_outputs_pruned=10,
        operations=["test operation"],
    )

    result_dict = result.to_dict()

    assert result_dict["messages_archived"] == 5
    assert result_dict["tokens_freed"] == 1000
    assert result_dict["duplicates_removed"] == 3
    assert result_dict["stale_outputs_pruned"] == 10
    assert "test operation" in result_dict["operations"]


# =============================================================================
# Deduplication Tests
# =============================================================================


def test_scan_and_deduplicate_finds_duplicates():
    """Test scanning for duplicate outputs."""
    messages = [
        create_test_message("msg1", tool_output="duplicate content"),
        create_test_message("msg2", tool_output="unique content"),
        create_test_message("msg3", tool_output="duplicate content"),  # Duplicate
        create_test_message("msg4", tool_output="duplicate content"),  # Duplicate
    ]

    config = PruningConfig()
    result = scan_and_deduplicate(messages, config)

    assert result.duplicates_removed == 2  # 2 duplicates found
    assert result.tokens_freed > 0


def test_scan_and_deduplicate_no_duplicates():
    """Test scanning when no duplicates exist."""
    messages = [
        create_test_message("msg1", tool_output="unique 1"),
        create_test_message("msg2", tool_output="unique 2"),
        create_test_message("msg3", tool_output="unique 3"),
    ]

    config = PruningConfig()
    result = scan_and_deduplicate(messages, config)

    assert result.duplicates_removed == 0
    assert result.tokens_freed == 0


# =============================================================================
# Issue Detection Tests
# =============================================================================


def test_detect_high_redundancy():
    """Test detection of high redundancy."""
    messages = [
        create_test_message("msg1", tool_output="duplicate"),
        create_test_message("msg2", tool_output="duplicate"),
        create_test_message("msg3", tool_output="duplicate"),
        create_test_message("msg4", tool_output="duplicate"),
    ]

    conv = Conversation(id="test_conv")
    config = PruningConfig()

    issues = detect_context_issues(messages, conv, config)

    # Should detect high redundancy
    redundancy_issues = [i for i in issues if i.issue_type == "high_redundancy"]
    assert len(redundancy_issues) > 0
    assert redundancy_issues[0].severity in ["warning", "info"]


def test_detect_staleness_accumulation():
    """Test detection of staleness accumulation."""
    # Create many messages to increase average age (need >15 avg)
    # With N messages, avg age = (N-1)/2, so need N>31 for avg>15
    messages = [create_test_message(f"msg{i}") for i in range(35)]

    conv = Conversation(id="test_conv")
    config = PruningConfig()

    issues = detect_context_issues(messages, conv, config)

    # Should detect staleness
    staleness_issues = [i for i in issues if i.issue_type == "staleness_accumulation"]
    assert len(staleness_issues) > 0


def test_detect_low_information_density():
    """Test detection of low information density."""
    # All duplicates = low density
    messages = [
        create_test_message(f"msg{i}", tool_output="same content") for i in range(10)
    ]

    conv = Conversation(id="test_conv")
    config = PruningConfig()

    issues = detect_context_issues(messages, conv, config)

    # Should detect low density
    density_issues = [
        i for i in issues if i.issue_type == "low_information_density"
    ]
    assert len(density_issues) > 0


def test_detect_error_preservation():
    """Test error preservation detection."""
    messages = [
        create_test_message("msg1", has_error=True, tool_output="error 1"),
        create_test_message("msg2", tool_output="normal"),
        create_test_message("msg3", has_error=True, tool_output="error 2"),
    ]

    conv = Conversation(id="test_conv")
    config = PruningConfig()

    issues = detect_context_issues(messages, conv, config)

    # Should report error count
    error_issues = [i for i in issues if i.issue_type == "error_loss"]
    assert len(error_issues) > 0
    assert error_issues[0].affected_count == 2  # 2 errors


def test_detect_excessive_protection():
    """Test detection of excessive protection."""
    messages = [
        create_test_message(f"msg{i}", tool_output=f"output {i}") for i in range(5)
    ]

    # Configure to protect everything
    config = PruningConfig(
        protect_turns=100,  # Protect all turns
        protected_tools=["test_tool"],  # Protect this tool
    )

    conv = Conversation(id="test_conv")

    issues = detect_context_issues(messages, conv, config)

    # Should detect excessive protection
    protection_issues = [i for i in issues if i.issue_type == "excessive_protection"]
    assert len(protection_issues) > 0


def test_context_issue_serialization():
    """Test ContextIssue to_dict."""
    issue = ContextIssue(
        issue_type="high_redundancy",
        severity="warning",
        description="Test issue",
        affected_count=5,
        suggested_fix="Test fix",
        metadata={"key": "value"},
    )

    issue_dict = issue.to_dict()

    assert issue_dict["issue_type"] == "high_redundancy"
    assert issue_dict["severity"] == "warning"
    assert issue_dict["description"] == "Test issue"
    assert issue_dict["affected_count"] == 5
    assert issue_dict["suggested_fix"] == "Test fix"
    assert issue_dict["metadata"]["key"] == "value"


# =============================================================================
# Manager Integration Tests
# =============================================================================


def test_manager_cleanup_stale_data():
    """Test ConversationManager.cleanup_stale_data."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    current_time = int(time.time() * 1000)
    old_time = current_time - (48 * 3600 * 1000)

    # Add old and new messages
    manager.add_message(
        conv.id, create_test_message("msg1", timestamp=old_time, tool_output="old")
    )
    manager.add_message(
        conv.id, create_test_message("msg2", timestamp=current_time, tool_output="new")
    )

    # Run cleanup
    result = manager.cleanup_stale_data(conv.id, max_age_hours=24)

    assert "stale_outputs_pruned" in result
    assert result["stale_outputs_pruned"] == 1


def test_manager_scan_and_deduplicate():
    """Test ConversationManager.scan_and_deduplicate."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    # Add duplicates
    manager.add_message(conv.id, create_test_message("msg1", tool_output="dup"))
    manager.add_message(conv.id, create_test_message("msg2", tool_output="dup"))
    manager.add_message(conv.id, create_test_message("msg3", tool_output="unique"))

    # Scan
    result = manager.scan_and_deduplicate(conv.id)

    assert "duplicates_removed" in result
    assert result["duplicates_removed"] == 1


def test_manager_detect_context_issues():
    """Test ConversationManager.detect_context_issues."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    # Add messages with issues (lots of duplicates)
    for i in range(10):
        manager.add_message(
            conv.id, create_test_message(f"msg{i}", tool_output="duplicate")
        )

    # Detect issues
    issues = manager.detect_context_issues(conv.id)

    assert isinstance(issues, list)
    assert len(issues) > 0  # Should detect some issues

    # Check issue structure
    for issue in issues:
        assert "issue_type" in issue
        assert "severity" in issue
        assert "description" in issue
        assert "suggested_fix" in issue


def test_manager_detect_multiple_issue_types():
    """Test detection of multiple issue types."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    # Create scenario with multiple issues:
    # 1. High redundancy (duplicates)
    # 2. Errors present
    # 3. Many messages (staleness)

    for i in range(20):
        if i % 5 == 0:
            # Add errors
            manager.add_message(
                conv.id,
                create_test_message(f"msg{i}", tool_output="error", has_error=True),
            )
        else:
            # Add duplicates
            manager.add_message(
                conv.id, create_test_message(f"msg{i}", tool_output="duplicate")
            )

    issues = manager.detect_context_issues(conv.id)

    # Should detect multiple types
    issue_types = {issue["issue_type"] for issue in issues}
    assert len(issue_types) >= 2  # At least 2 different issue types


def test_cleanup_integration_workflow():
    """Test complete cleanup workflow."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    current_time = int(time.time() * 1000)
    old_time = current_time - (48 * 3600 * 1000)

    # Add various messages
    manager.add_message(
        conv.id, create_test_message("msg1", timestamp=old_time, tool_output="old")
    )
    manager.add_message(
        conv.id, create_test_message("msg2", tool_output="dup")
    )  # Recent
    manager.add_message(
        conv.id, create_test_message("msg3", tool_output="dup")
    )  # Duplicate

    # 1. Detect issues
    issues = manager.detect_context_issues(conv.id)
    assert len(issues) > 0

    # 2. Check for duplicates
    dedup_result = manager.scan_and_deduplicate(conv.id)
    if dedup_result["duplicates_removed"] > 0:
        # Would run actual deduplication via prune_before_turn
        pass

    # 3. Check for stale data
    cleanup_result = manager.cleanup_stale_data(conv.id, max_age_hours=24)
    assert cleanup_result["stale_outputs_pruned"] == 1

    # Workflow complete - all maintenance checks done


def test_cleanup_execute_false_dry_run():
    """cleanup_stale_data with execute=False should not modify outputs."""
    current_time = int(time.time() * 1000)
    old_time = current_time - (48 * 3600 * 1000)  # 48 hours ago

    output_content = "stale content that should not be cleared"
    messages = [
        create_test_message("msg1", timestamp=old_time, tool_output=output_content),
    ]
    config = PruningConfig()
    result = cleanup_stale_data(messages, config, max_age_hours=24, execute=False)

    assert result.stale_outputs_pruned == 1
    assert result.tokens_freed > 0

    # Output must NOT be cleared
    for msg in messages:
        for part in msg.parts:
            if part.type == "tool" and hasattr(part, "state"):
                assert part.state.output == output_content


def test_cleanup_execute_true_clears_outputs():
    """cleanup_stale_data with execute=True should actually clear stale outputs."""
    current_time = int(time.time() * 1000)
    old_time = current_time - (48 * 3600 * 1000)  # 48 hours ago

    output_content = "stale content that should be cleared"
    messages = [
        create_test_message("msg1", timestamp=old_time, tool_output=output_content),
    ]
    config = PruningConfig()
    result = cleanup_stale_data(messages, config, max_age_hours=24, execute=True)

    assert result.stale_outputs_pruned == 1
    assert result.tokens_freed > 0

    # Output MUST be cleared
    cleared = False
    for msg in messages:
        for part in msg.parts:
            if part.type == "tool" and hasattr(part, "state"):
                if part.state.output == "":
                    cleared = True
    assert cleared, "Expected stale output to be cleared when execute=True"


def test_manager_cleanup_execute_true_persists():
    """manager.cleanup_stale_data with execute=True should save cleared messages."""
    current_time = int(time.time() * 1000)
    old_time = current_time - (48 * 3600 * 1000)

    storage = MemoryStorage()
    manager = ConversationManager(storage=storage)
    conv = manager.create_conversation()

    manager.add_message(
        conv.id, create_test_message("msg1", timestamp=old_time, tool_output="stale output")
    )

    result = manager.cleanup_stale_data(conv.id, max_age_hours=24, execute=True)

    assert result["stale_outputs_pruned"] == 1

    # Reload and verify the output was cleared in storage
    messages = manager.get_messages(conv.id)
    for msg in messages:
        for part in msg.parts:
            if part.type == "tool" and hasattr(part, "state"):
                assert part.state.output == ""
