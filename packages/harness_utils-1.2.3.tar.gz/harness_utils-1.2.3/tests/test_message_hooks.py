"""Tests for MessageHooks pre/post lifecycle on add_message()."""

import pytest

from harnessutils import ConversationManager, MessageHooks
from harnessutils.models.message import Message
from harnessutils.models.parts import TextPart
from harnessutils.utils.ids import generate_id


def _make_message(text: str = "hello") -> Message:
    msg = Message(id=generate_id("msg"), role="user")
    msg.add_part(TextPart(text=text))
    return msg


def _make_manager(**kwargs) -> tuple[ConversationManager, str]:
    manager = ConversationManager(**kwargs)
    conv = manager.create_conversation()
    return manager, conv.id


# --- default behaviour unchanged ---

def test_no_hooks_stores_normally():
    manager, conv_id = _make_manager()
    msg = _make_message()
    manager.add_message(conv_id, msg)
    assert manager.get_messages(conv_id)[0].id == msg.id


# --- pre-hook ---

def test_pre_hook_is_called():
    called = []

    def pre(conv_id: str, message: Message) -> Message:
        called.append(conv_id)
        return message

    manager, conv_id = _make_manager(message_hooks=MessageHooks(on_before_add_message=pre))
    manager.add_message(conv_id, _make_message())
    assert called == [conv_id]


def test_pre_hook_can_replace_message():
    replacement = _make_message("replaced")

    def pre(conv_id: str, message: Message) -> Message:
        return replacement

    manager, conv_id = _make_manager(message_hooks=MessageHooks(on_before_add_message=pre))
    manager.add_message(conv_id, _make_message("original"))

    stored = manager.get_messages(conv_id)
    assert stored[0].id == replacement.id


def test_pre_hook_raise_rejects_message():
    def pre(conv_id: str, message: Message) -> Message:
        raise ValueError("rejected")

    manager, conv_id = _make_manager(message_hooks=MessageHooks(on_before_add_message=pre))

    with pytest.raises(ValueError, match="rejected"):
        manager.add_message(conv_id, _make_message())

    assert manager.get_messages(conv_id) == []


def test_pre_hook_raise_skips_post_hook():
    post_called = []

    def pre(conv_id: str, message: Message) -> Message:
        raise RuntimeError("blocked")

    def post(conv_id: str, message: Message) -> None:
        post_called.append(True)

    manager, conv_id = _make_manager(
        message_hooks=MessageHooks(
            on_before_add_message=pre,
            on_after_add_message=post,
        )
    )

    with pytest.raises(RuntimeError):
        manager.add_message(conv_id, _make_message())

    assert post_called == []


# --- post-hook ---

def test_post_hook_is_called():
    called = []

    def post(conv_id: str, message: Message) -> None:
        called.append(conv_id)

    manager, conv_id = _make_manager(message_hooks=MessageHooks(on_after_add_message=post))
    manager.add_message(conv_id, _make_message())
    assert called == [conv_id]


def test_post_hook_receives_stored_message():
    """Post-hook gets the message returned by the pre-hook, not the original."""
    replacement = _make_message("replaced")
    received = []

    def pre(conv_id: str, message: Message) -> Message:
        return replacement

    def post(conv_id: str, message: Message) -> None:
        received.append(message.id)

    manager, conv_id = _make_manager(
        message_hooks=MessageHooks(
            on_before_add_message=pre,
            on_after_add_message=post,
        )
    )
    manager.add_message(conv_id, _make_message("original"))
    assert received == [replacement.id]


def test_post_hook_called_after_storage():
    """Message must be in storage by the time post-hook fires."""
    stored_at_call_time = []

    def post(conv_id: str, message: Message) -> None:
        msgs = manager.get_messages(conv_id)
        stored_at_call_time.append(len(msgs))

    manager, conv_id = _make_manager(message_hooks=MessageHooks(on_after_add_message=post))
    manager.add_message(conv_id, _make_message())
    assert stored_at_call_time == [1]


# --- exported correctly ---

def test_message_hooks_importable_from_package():
    from harnessutils import MessageHooks as MH
    assert MH is MessageHooks
