"""Tests for predictive overflow detection (Phase 2)."""

from harnessutils import (
    Conversation,
    ConversationManager,
    HarnessConfig,
    MemoryStorage,
    Message,
    TextPart,
    Usage,
    generate_id,
)
from harnessutils.config import CompactionConfig
from harnessutils.models.velocity import ConversationVelocity


class TestConversationVelocity:
    """Test velocity tracking calculations."""

    def test_avg_growth_empty(self):
        """Average growth with no data."""
        velocity = ConversationVelocity()
        assert velocity.avg_growth == 0.0

    def test_avg_growth_single(self):
        """Average growth with single delta."""
        velocity = ConversationVelocity()
        velocity.add_delta(100)
        assert velocity.avg_growth == 100.0

    def test_avg_growth_multiple(self):
        """Average growth with multiple deltas."""
        velocity = ConversationVelocity()
        velocity.add_delta(100)
        velocity.add_delta(200)
        velocity.add_delta(300)
        assert velocity.avg_growth == 200.0

    def test_growth_trend_insufficient_data(self):
        """Growth trend with insufficient data."""
        velocity = ConversationVelocity()
        velocity.add_delta(100)
        assert velocity.growth_trend == 0.0

    def test_growth_trend_accelerating(self):
        """Growth trend detects acceleration."""
        velocity = ConversationVelocity()
        # Older: 100, 100
        # Recent: 200, 200
        velocity.add_delta(100)
        velocity.add_delta(100)
        velocity.add_delta(200)
        velocity.add_delta(200)

        assert velocity.growth_trend > 0  # Accelerating

    def test_growth_trend_decelerating(self):
        """Growth trend detects deceleration."""
        velocity = ConversationVelocity()
        # Older: 200, 200
        # Recent: 100, 100
        velocity.add_delta(200)
        velocity.add_delta(200)
        velocity.add_delta(100)
        velocity.add_delta(100)

        assert velocity.growth_trend < 0  # Decelerating

    def test_growth_trend_steady(self):
        """Growth trend detects steady growth."""
        velocity = ConversationVelocity()
        for _ in range(10):
            velocity.add_delta(100)

        assert abs(velocity.growth_trend) < 0.1  # Approximately steady

    def test_predict_tokens_ahead_no_data(self):
        """Prediction with no data."""
        velocity = ConversationVelocity()
        assert velocity.predict_tokens_ahead(5) == 0

    def test_predict_tokens_ahead_steady_growth(self):
        """Prediction with steady growth."""
        velocity = ConversationVelocity()
        for _ in range(5):
            velocity.add_delta(100)

        # 100 tokens/turn * 5 turns = 500
        predicted = velocity.predict_tokens_ahead(5)
        assert predicted == 500

    def test_predict_tokens_ahead_accelerating(self):
        """Prediction with acceleration boost."""
        velocity = ConversationVelocity()
        velocity.add_delta(100)
        velocity.add_delta(100)
        velocity.add_delta(200)
        velocity.add_delta(200)

        # Average: 150, Trend: +50, Boost should increase prediction
        predicted = velocity.predict_tokens_ahead(5)
        assert predicted > 150 * 5  # Greater than base prediction

    def test_add_delta_window_limit(self):
        """Deltas limited to window size."""
        velocity = ConversationVelocity(window_size=5)

        # Add 10 deltas
        for i in range(10):
            velocity.add_delta(i * 100)

        # Should only keep last 5
        assert len(velocity.turn_deltas) == 5
        assert velocity.turn_deltas == [500, 600, 700, 800, 900]

    def test_to_dict_from_dict(self):
        """Serialization round-trip."""
        velocity = ConversationVelocity(window_size=8)
        velocity.add_delta(100)
        velocity.add_delta(200)

        data = velocity.to_dict()
        restored = ConversationVelocity.from_dict(data)

        assert restored.turn_deltas == velocity.turn_deltas
        assert restored.window_size == velocity.window_size


class TestConversationVelocityTracking:
    """Test velocity tracking in conversations."""

    def test_get_velocity_not_exists(self):
        """Get velocity when not initialized."""
        conv = Conversation(id="test")
        assert conv.get_velocity() is None

    def test_update_velocity_creates_new(self):
        """Update velocity creates tracker if not exists."""
        conv = Conversation(id="test")
        conv.update_velocity(100)

        velocity = conv.get_velocity()
        assert velocity is not None
        assert velocity.turn_deltas == [100]

    def test_update_velocity_appends(self):
        """Update velocity appends to existing tracker."""
        conv = Conversation(id="test")
        conv.update_velocity(100)
        conv.update_velocity(200)
        conv.update_velocity(300)

        velocity = conv.get_velocity()
        assert velocity is not None
        assert velocity.turn_deltas == [100, 200, 300]

    def test_velocity_persists_in_metadata(self):
        """Velocity stored in conversation metadata."""
        conv = Conversation(id="test")
        conv.update_velocity(100)

        assert "velocity" in conv.metadata
        assert conv.metadata["velocity"]["turn_deltas"] == [100]


class TestManagerVelocityTracking:
    """Test velocity tracking through manager."""

    def test_add_message_tracks_velocity(self):
        """Manager tracks velocity when adding messages."""
        config = HarnessConfig()
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()

        # Add message with token count
        msg = Message(id=generate_id("msg"), role="user")
        msg.add_part(TextPart(text="Hello"))
        msg.tokens = Usage(input=10, output=0)

        manager.add_message(conv.id, msg)

        # Load conversation and check velocity
        conv_data = storage.load_conversation(conv.id)
        conv_restored = Conversation.from_dict(conv_data)
        velocity = conv_restored.get_velocity()

        assert velocity is not None
        assert velocity.turn_deltas == [10]

    def test_add_multiple_messages_accumulates_velocity(self):
        """Multiple messages accumulate velocity."""
        config = HarnessConfig()
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()

        # Add 3 messages with increasing tokens
        for i in range(3):
            msg = Message(id=generate_id("msg"), role="user")
            msg.add_part(TextPart(text=f"Message {i}"))
            msg.tokens = Usage(input=(i + 1) * 100, output=0)
            manager.add_message(conv.id, msg)

        # Check velocity
        conv_data = storage.load_conversation(conv.id)
        conv_restored = Conversation.from_dict(conv_data)
        velocity = conv_restored.get_velocity()

        assert velocity is not None
        assert velocity.turn_deltas == [100, 200, 300]

    def test_message_without_tokens_not_tracked(self):
        """Messages without token counts not tracked."""
        config = HarnessConfig()
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()

        # Add message without tokens
        msg = Message(id=generate_id("msg"), role="user")
        msg.add_part(TextPart(text="Hello"))
        # No tokens set

        manager.add_message(conv.id, msg)

        # Velocity should not be created
        conv_data = storage.load_conversation(conv.id)
        conv_restored = Conversation.from_dict(conv_data)
        velocity = conv_restored.get_velocity()

        assert velocity is None


class TestPredictiveOverflow:
    """Test predictive overflow detection."""

    def test_predict_overflow_disabled(self):
        """Predictive check disabled by config."""
        config = HarnessConfig()
        config.compaction.use_predictive = False
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()

        usage = Usage(input=150000, output=0)
        result = manager.predict_overflow(conv.id, usage)

        assert result is False

    def test_predict_overflow_no_velocity_data(self):
        """No prediction without velocity data."""
        config = HarnessConfig()
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()

        usage = Usage(input=100000, output=0)
        result = manager.predict_overflow(conv.id, usage)

        assert result is False

    def test_predict_overflow_triggers_early(self):
        """Predictive check triggers before actual overflow."""
        config = HarnessConfig()
        config.model_limits.default_context_limit = 200000
        config.model_limits.default_output_limit = 8192
        config.compaction.use_predictive = True
        config.compaction.predictive_lookahead = 5
        config.compaction.predictive_safety_margin = 0.8

        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()
        conv_obj = Conversation.from_dict(storage.load_conversation(conv.id))

        # Build up velocity with steady 5000 tokens/turn
        for _ in range(5):
            conv_obj.update_velocity(5000)

        storage.save_conversation(conv.id, conv_obj.to_dict())

        # Current usage: 130000 (below overflow but above 80% threshold)
        # Predicted: 130000 + (5000 * 5) = 155000
        # Threshold: (200000 - 8192) * 0.8 = 153446
        usage = Usage(input=130000, output=0)

        result = manager.predict_overflow(conv.id, usage)
        assert result is True  # Should trigger predictive check

    def test_predict_overflow_false_when_safe(self):
        """Predictive check doesn't trigger when safe."""
        config = HarnessConfig()
        config.model_limits.default_context_limit = 200000
        config.model_limits.default_output_limit = 8192
        config.compaction.use_predictive = True
        config.compaction.predictive_lookahead = 5

        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()
        conv_obj = Conversation.from_dict(storage.load_conversation(conv.id))

        # Build up velocity with low tokens/turn
        for _ in range(5):
            conv_obj.update_velocity(1000)

        storage.save_conversation(conv.id, conv_obj.to_dict())

        # Current usage: 50000 (very safe)
        # Predicted: 50000 + (1000 * 5) = 55000
        # Threshold: (200000 - 8192) * 0.8 = 153446
        usage = Usage(input=50000, output=0)

        result = manager.predict_overflow(conv.id, usage)
        assert result is False


class TestNeedsCompactionIntegration:
    """Test needs_compaction with predictive checks."""

    def test_needs_compaction_reactive_only(self):
        """Reactive check triggers on overflow."""
        config = HarnessConfig()
        config.compaction.use_predictive = False
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()

        # Already overflowed
        usage = Usage(input=200000, output=0)

        assert manager.needs_compaction(conv.id, usage) is True

    def test_needs_compaction_predictive_triggers(self):
        """Predictive check triggers before overflow."""
        config = HarnessConfig()
        config.model_limits.default_context_limit = 200000
        config.model_limits.default_output_limit = 8192
        config.compaction.use_predictive = True
        config.compaction.predictive_lookahead = 5

        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()
        conv_obj = Conversation.from_dict(storage.load_conversation(conv.id))

        # Build velocity
        for _ in range(5):
            conv_obj.update_velocity(5000)

        storage.save_conversation(conv.id, conv_obj.to_dict())

        # Not yet overflowed, but will soon
        usage = Usage(input=130000, output=0)

        assert manager.needs_compaction(conv.id, usage) is True

    def test_needs_compaction_neither_triggers(self):
        """No compaction needed when safe."""
        config = HarnessConfig()
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        conv = manager.create_conversation()
        conv_obj = Conversation.from_dict(storage.load_conversation(conv.id))

        # Build velocity with low growth
        for _ in range(5):
            conv_obj.update_velocity(500)

        storage.save_conversation(conv.id, conv_obj.to_dict())

        # Safe usage
        usage = Usage(input=50000, output=0)

        assert manager.needs_compaction(conv.id, usage) is False


class TestConfigurationOptions:
    """Test configuration options."""

    def test_custom_lookahead(self):
        """Custom lookahead window."""
        config = CompactionConfig(predictive_lookahead=10)
        assert config.predictive_lookahead == 10

    def test_custom_safety_margin(self):
        """Custom safety margin."""
        config = CompactionConfig(predictive_safety_margin=0.9)
        assert config.predictive_safety_margin == 0.9

    def test_disable_predictive(self):
        """Predictive can be disabled."""
        config = CompactionConfig(use_predictive=False)
        assert config.use_predictive is False

    def test_defaults(self):
        """Default configuration values."""
        config = CompactionConfig()
        assert config.use_predictive is True
        assert config.predictive_lookahead == 5
        assert config.predictive_safety_margin == 0.8
