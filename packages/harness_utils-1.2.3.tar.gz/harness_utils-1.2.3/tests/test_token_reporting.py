"""Tests for token usage reporting and tracking."""

from harnessutils import (
    ConversationManager,
    HarnessConfig,
    MemoryStorage,
    Message,
    ToolPart,
    ToolState,
    generate_id,
)


def test_pruning_result_detailed_tracking():
    """Test that pruning returns detailed token information."""
    config = HarnessConfig()
    config.pruning.prune_protect = 0
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    conv = manager.create_conversation()

    # Add message with tool output
    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "test"},
            output="x" * 1000,  # ~250 tokens
        ),
    )
    msg.add_part(part)
    manager.add_message(conv.id, msg)

    # Prune
    result = manager.prune_before_turn(conv.id)

    # Should have detailed tracking
    assert "pruned" in result
    assert "tokens_saved" in result
    assert "tokens_before" in result
    assert "tokens_after" in result
    assert "duplicates_pruned" in result
    assert "importance_pruned" in result
    assert "duplicate_tokens_saved" in result
    assert "importance_tokens_saved" in result
    assert "reduction_percent" in result

    # Tokens should be tracked
    assert result["tokens_before"] > 0
    assert result["tokens_after"] == 0  # All pruned
    assert result["tokens_saved"] == result["tokens_before"]
    assert result["reduction_percent"] == 100.0


def test_pruning_result_breakdown():
    """Test pruning result breakdown by operation type."""
    config = HarnessConfig()
    config.pruning.detect_duplicates = True
    config.pruning.use_importance_scoring = False
    config.pruning.prune_protect = 100000
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    conv = manager.create_conversation()

    # Add duplicate messages
    for i in range(2):
        msg = Message(id=f"msg_{i}", role="assistant")
        part = ToolPart(
            tool="bash",
            call_id=f"call_{i}",
            state=ToolState(
                status="completed",
                input={"command": "ls"},
                output="file.txt\n" * 100,  # Duplicate
            ),
        )
        msg.add_part(part)
        manager.add_message(conv.id, msg)

        if i == 0:
            # Add user message between
            user_msg = Message(id=f"msg_user_{i}", role="user")
            manager.add_message(conv.id, user_msg)

    # Prune
    result = manager.prune_before_turn(conv.id)

    # Should show duplicate pruning
    assert result["duplicates_pruned"] == 1
    assert result["duplicate_tokens_saved"] > 0
    assert result["importance_pruned"] == 0  # Importance scoring disabled


def test_get_tool_output_tokens():
    """Test getting detailed token breakdown by tool type."""
    config = HarnessConfig()
    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    conv = manager.create_conversation()

    # Add messages with different tools
    tools = [
        ("bash", "output1" * 100),
        ("read", "output2" * 200),
        ("grep", "output3" * 50),
    ]

    for tool, output in tools:
        msg = Message(id=generate_id("msg"), role="assistant")
        part = ToolPart(
            tool=tool,
            call_id=generate_id("call"),
            state=ToolState(
                status="completed",
                input={"test": "test"},
                output=output,
            ),
        )
        msg.add_part(part)
        manager.add_message(conv.id, msg)

    # Get breakdown
    breakdown = manager.get_tool_output_tokens(conv.id)

    # Should have detailed info
    assert "total" in breakdown
    assert "by_tool" in breakdown
    assert "prunable" in breakdown
    assert "protected" in breakdown
    assert "prunability_percent" in breakdown

    # Should track by tool
    assert "bash" in breakdown["by_tool"]
    assert "read" in breakdown["by_tool"]
    assert "grep" in breakdown["by_tool"]

    # Totals should match
    total_by_tool = sum(breakdown["by_tool"].values())
    assert total_by_tool == breakdown["total"]


def test_token_tracking_before_after():
    """Test that tokens before/after are tracked correctly."""
    config = HarnessConfig()
    config.pruning.prune_protect = 50  # Low threshold
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0
    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    conv = manager.create_conversation()

    # Add 3 outputs
    for i in range(3):
        msg = Message(id=f"msg_{i}", role="assistant")
        part = ToolPart(
            tool="bash",
            call_id=f"call_{i}",
            state=ToolState(
                status="completed",
                input={"command": "test"},
                output="x" * 100,  # ~25 tokens each
            ),
        )
        msg.add_part(part)
        manager.add_message(conv.id, msg)

    # Prune (should prune oldest to stay under 50 tokens)
    result = manager.prune_before_turn(conv.id)

    # Verify token tracking
    assert result["tokens_before"] > result["tokens_after"]
    assert result["tokens_saved"] > 0
    assert result["tokens_before"] == result["tokens_after"] + result["tokens_saved"]

    # Reduction percent should be calculated
    expected_percent = round(result["tokens_saved"] / result["tokens_before"] * 100, 1)
    assert result["reduction_percent"] == expected_percent


def test_pruning_result_string_representation():
    """Test human-readable string representation of pruning results."""
    from harnessutils.compaction.pruning import PruningResult

    # No pruning
    result = PruningResult(pruned=0, tokens_saved=0)
    assert "No pruning needed" in str(result)

    # With pruning
    result = PruningResult(
        pruned=5,
        tokens_saved=1000,
        tokens_before=5000,
        tokens_after=4000,
        duplicates_pruned=2,
        importance_pruned=3,
        duplicate_tokens_saved=400,
        importance_tokens_saved=600,
    )

    output = str(result)
    assert "Pruned 5 outputs" in output
    assert "saved 1,000 tokens" in output
    assert "Before: 5,000 tokens" in output
    assert "After: 4,000 tokens" in output
    assert "Reduction: 20.0%" in output
    assert "Duplicates: 2 removed (400 tokens)" in output
    assert "Low importance: 3 removed (600 tokens)" in output


def test_pruning_result_to_dict():
    """Test pruning result dictionary conversion."""
    from harnessutils.compaction.pruning import PruningResult

    result = PruningResult(
        pruned=10,
        tokens_saved=2000,
        tokens_before=10000,
        tokens_after=8000,
        duplicates_pruned=4,
        importance_pruned=6,
        duplicate_tokens_saved=800,
        importance_tokens_saved=1200,
    )

    d = result.to_dict()

    # All fields present
    assert d["pruned"] == 10
    assert d["tokens_saved"] == 2000
    assert d["tokens_before"] == 10000
    assert d["tokens_after"] == 8000
    assert d["duplicates_pruned"] == 4
    assert d["importance_pruned"] == 6
    assert d["duplicate_tokens_saved"] == 800
    assert d["importance_tokens_saved"] == 1200
    assert d["reduction_percent"] == 20.0


def test_no_pruning_returns_zeros():
    """Test that no pruning returns zero values."""
    config = HarnessConfig()
    config.pruning.prune_protect = 100000  # Very high
    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    conv = manager.create_conversation()

    # Add small output
    msg = Message(id=generate_id("msg"), role="assistant")
    part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "test"},
            output="small",
        ),
    )
    msg.add_part(part)
    manager.add_message(conv.id, msg)

    # Prune (nothing should be pruned)
    result = manager.prune_before_turn(conv.id)

    # Should return zeros
    assert result["pruned"] == 0
    assert result["tokens_saved"] == 0
    assert result["duplicates_pruned"] == 0
    assert result["importance_pruned"] == 0
    assert result["duplicate_tokens_saved"] == 0
    assert result["importance_tokens_saved"] == 0
    assert result["reduction_percent"] == 0


def test_tool_output_tokens_protected():
    """Test that protected outputs are tracked correctly."""
    config = HarnessConfig()
    config.pruning.protect_turns = 2  # Protect last 2 turns
    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    conv = manager.create_conversation()

    # Add 3 assistant messages with user messages between
    for i in range(3):
        msg = Message(id=f"msg_{i}", role="assistant")
        part = ToolPart(
            tool="bash",
            call_id=f"call_{i}",
            state=ToolState(
                status="completed",
                input={"command": "test"},
                output="x" * 100,
            ),
        )
        msg.add_part(part)
        manager.add_message(conv.id, msg)

        if i < 2:
            user_msg = Message(id=f"msg_user_{i}", role="user")
            manager.add_message(conv.id, user_msg)

    # Get breakdown
    breakdown = manager.get_tool_output_tokens(conv.id)

    # Last 2 turns should be protected
    assert breakdown["protected"] > 0
    assert breakdown["prunable"] > 0

    # Protected + prunable should equal total
    assert breakdown["protected"] + breakdown["prunable"] == breakdown["total"]
