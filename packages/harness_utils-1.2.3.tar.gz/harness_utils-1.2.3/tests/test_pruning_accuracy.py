"""Tests for improved pruning accuracy with exact token counting."""

from harnessutils import (
    HarnessConfig,
    Message,
    ToolPart,
    ToolState,
    generate_id,
)
from harnessutils.compaction.pruning import prune_tool_outputs
from harnessutils.tokens.estimator import estimate_tokens
from harnessutils.tokens.exact import count_tokens_fast


def test_exact_counting_vs_heuristic():
    """Compare exact token counting vs old heuristic."""
    # Test with various outputs
    test_outputs = [
        "a" * 1000,  # Simple repetition
        "def foo():\n    return 42\n" * 50,  # Code
        '{"key": "value", "nested": {"data": [1, 2, 3]}}' * 20,  # JSON
        "Error: something went wrong\n" * 100,  # Errors
    ]

    for output in test_outputs:
        # Old way (heuristic)
        estimated = estimate_tokens(output, chars_per_token=4)

        # New way (exact)
        exact = count_tokens_fast(output)

        # Exact should be different from estimate (more accurate)
        # Allow some overlap, but they should differ
        error_rate = abs(estimated - exact) / exact

        # Print for visibility
        print(f"\nOutput length: {len(output)} chars")
        print(f"Estimated tokens: {estimated}")
        print(f"Exact tokens: {exact}")
        print(f"Error rate: {error_rate:.1%}")

        # Error rate should be measurable (not always zero)
        # But we don't assert because both methods are valid


def test_pruning_with_exact_counts():
    """Test that pruning uses exact token counts."""
    config = HarnessConfig()
    config.pruning.prune_protect = 500  # Low threshold
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0

    # Create message with tool output
    msg = Message(id=generate_id("msg"), role="assistant")

    # Add a tool output with known token count
    output = "test " * 200  # ~200 tokens
    tool_part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "test"},
            output=output,
        ),
    )
    msg.add_part(tool_part)

    # Verify exact counting is used
    exact_count = count_tokens_fast(output)
    assert exact_count > 0

    # Prune
    result = prune_tool_outputs([msg], config.pruning)

    # Should prune because exact count likely > 500 tokens
    if exact_count > 500:
        assert result.pruned == 1
        assert result.tokens_saved > 0
        assert tool_part.state.output == ""  # Output cleared
        assert tool_part.state.time.compacted > 0
    else:
        # If under threshold, shouldn't prune
        assert result.pruned == 0


def test_encoding_cache_performance():
    """Test that encoding is cached for performance."""
    from harnessutils.tokens.exact import get_encoding

    # First call loads encoding
    enc1 = get_encoding()

    # Second call should return cached
    enc2 = get_encoding()

    # Should be same object (cached)
    assert enc1 is enc2


def test_count_tokens_fast_empty():
    """Test fast counting with empty string."""
    assert count_tokens_fast("") == 0
    assert count_tokens_fast(None) == 0  # type: ignore


def test_count_tokens_fast_accuracy():
    """Test that fast counting matches full counting for plain text."""
    from harnessutils.tokens.exact import count_tokens_exact

    text = "This is a test message with multiple words and sentences."

    # Fast method (just text)
    fast = count_tokens_fast(text)

    # Full method (as message)
    exact = count_tokens_exact([{"role": "assistant", "content": text}])

    # Fast should be close (within message overhead of ~4 tokens)
    assert abs(fast - exact) <= 10  # Allow for message formatting overhead
