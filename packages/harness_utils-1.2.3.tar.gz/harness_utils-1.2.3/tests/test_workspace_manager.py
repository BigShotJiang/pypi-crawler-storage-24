"""Tests for ConversationManager workspace and semantic memory wiring."""

import uuid

from harnessutils import ConversationManager
from harnessutils.storage.filesystem import FilesystemStorage
from harnessutils.storage.memory import MemoryStorage


class _FakeBackend:
    async def add_artifact(self, content, kind, *, namespace="default", metadata=None):
        return 1

    async def search_artifacts(self, query, *, top_k=10, kind=None, namespace=None, min_similarity=0.0):
        return []

    async def get_artifact(self, artifact_id):
        return None

    async def update_artifact(self, artifact_id, *, metadata=None, content=None):
        return None

    async def delete_artifact(self, artifact_id):
        return None


def test_no_workspace_root_unchanged():
    manager = ConversationManager()
    assert manager.project_id is None
    assert manager.semantic_memory is None
    assert isinstance(manager.storage, MemoryStorage)


def test_workspace_root_sets_project_id(tmp_path):
    manager = ConversationManager(workspace_root=tmp_path)
    assert manager.project_id is not None
    uuid.UUID(manager.project_id)  # must be valid UUID


def test_workspace_root_project_id_stable(tmp_path):
    m1 = ConversationManager(workspace_root=tmp_path)
    m2 = ConversationManager(workspace_root=tmp_path)
    assert m1.project_id == m2.project_id


def test_workspace_root_defaults_filesystem_storage(tmp_path):
    manager = ConversationManager(workspace_root=tmp_path)
    assert isinstance(manager.storage, FilesystemStorage)
    assert (tmp_path / ".harness" / "sessions").is_dir()


def test_explicit_storage_takes_precedence(tmp_path):
    explicit = MemoryStorage()
    manager = ConversationManager(storage=explicit, workspace_root=tmp_path)
    assert manager.storage is explicit


def test_semantic_memory_stored():
    backend = _FakeBackend()
    manager = ConversationManager(semantic_memory=backend)
    assert manager.semantic_memory is backend


def test_semantic_memory_none_by_default():
    manager = ConversationManager()
    assert manager.semantic_memory is None


def test_workspace_root_string_accepted(tmp_path):
    manager = ConversationManager(workspace_root=str(tmp_path))
    assert manager.project_id is not None
    uuid.UUID(manager.project_id)
