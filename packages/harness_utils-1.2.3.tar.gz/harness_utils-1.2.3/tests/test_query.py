"""Tests for Phase 3C: Selective Loading (Query & Filter API)."""

import time

from harnessutils.config import HarnessConfig
from harnessutils.manager import ConversationManager
from harnessutils.models.message import Message
from harnessutils.models.parts import TextPart, ToolPart
from harnessutils.models.usage import CacheUsage, Usage
from harnessutils.query import (
    MessageFilter,
    QueryOptions,
    build_context_summary,
    query_messages,
)
from harnessutils.storage.memory import MemoryStorage


def create_test_message(
    role: str = "assistant",
    message_id: str | None = None,
    timestamp: int | None = None,
    has_error: bool = False,
    tools: list[str] | None = None,
    importance: float = 0.0,
    is_summary: bool = False,
) -> Message:
    """Helper to create test messages.

    Args:
        role: Message role
        message_id: Optional message ID
        timestamp: Optional timestamp
        has_error: Whether message has error
        tools: Optional list of tools to add
        importance: Importance score
        is_summary: Whether this is a summary message

    Returns:
        Test message
    """
    if message_id is None:
        message_id = f"msg_{int(time.time() * 1000000)}"

    if timestamp is None:
        timestamp = int(time.time() * 1000)

    msg = Message(
        id=message_id,
        role=role,
        summary=is_summary,
        tokens=Usage(
            input=0,
            output=100,
            cache=CacheUsage(read=0, write=0),
        ),
        metadata={"timestamp": timestamp, "importance_score": importance},
    )

    if role == "user":
        msg.add_part(TextPart(text="test user message"))
    elif is_summary:
        msg.add_part(TextPart(text="This is a summary of the conversation"))
    elif tools:
        for tool in tools:
            tool_part = ToolPart(tool=tool)
            if has_error:
                tool_part.state.status = "error"
                tool_part.state.output = "Error: Something went wrong"
            else:
                tool_part.state.status = "completed"
                tool_part.state.output = f"Output from {tool}"
            msg.add_part(tool_part)
    else:
        msg.add_part(TextPart(text="test assistant message"))

    if has_error:
        msg.error = "Test error"

    return msg


# =============================================================================
# MessageFilter Tests
# =============================================================================


def test_filter_by_role():
    """Test filtering by message role."""
    messages = [
        create_test_message(role="user", message_id="msg1"),
        create_test_message(role="assistant", message_id="msg2"),
        create_test_message(role="user", message_id="msg3"),
    ]

    filter = MessageFilter(roles=["user"])

    results = [msg for msg in messages if filter.matches(msg)]
    assert len(results) == 2
    assert all(msg.role == "user" for msg in results)


def test_filter_by_has_errors():
    """Test filtering by error presence."""
    messages = [
        create_test_message(message_id="msg1", has_error=False),
        create_test_message(message_id="msg2", has_error=True),
        create_test_message(message_id="msg3", has_error=False),
        create_test_message(message_id="msg4", has_error=True),
    ]

    filter = MessageFilter(has_errors=True)

    results = [msg for msg in messages if filter.matches(msg)]
    assert len(results) == 2
    assert all(msg.error is not None for msg in results)


def test_filter_by_tools():
    """Test filtering by tool type."""
    messages = [
        create_test_message(message_id="msg1", tools=["read"]),
        create_test_message(message_id="msg2", tools=["write"]),
        create_test_message(message_id="msg3", tools=["bash"]),
        create_test_message(message_id="msg4", tools=["read", "grep"]),
    ]

    filter = MessageFilter(tools=["read", "write"])

    results = [msg for msg in messages if filter.matches(msg)]
    assert len(results) == 3  # msg1, msg2, msg4


def test_filter_by_importance():
    """Test filtering by importance score."""
    messages = [
        create_test_message(message_id="msg1", importance=10.0),
        create_test_message(message_id="msg2", importance=50.0),
        create_test_message(message_id="msg3", importance=100.0),
    ]

    filter = MessageFilter(min_importance=50.0)

    results = [msg for msg in messages if filter.matches(msg)]
    assert len(results) == 2
    assert all(msg.metadata["importance_score"] >= 50.0 for msg in results)


def test_filter_by_summary():
    """Test filtering by summary flag."""
    messages = [
        create_test_message(message_id="msg1", is_summary=False),
        create_test_message(message_id="msg2", is_summary=True),
        create_test_message(message_id="msg3", is_summary=False),
    ]

    filter = MessageFilter(is_summary=True)

    results = [msg for msg in messages if filter.matches(msg)]
    assert len(results) == 1
    assert results[0].summary is True


def test_filter_multiple_criteria():
    """Test combining multiple filter criteria."""
    messages = [
        create_test_message(
            message_id="msg1", role="assistant", tools=["read"], importance=100.0
        ),
        create_test_message(
            message_id="msg2", role="user", importance=50.0
        ),  # No tools
        create_test_message(
            message_id="msg3", role="assistant", tools=["write"], importance=30.0
        ),
    ]

    filter = MessageFilter(
        roles=["assistant"], tools=["read", "write"], min_importance=50.0
    )

    results = [msg for msg in messages if filter.matches(msg)]
    assert len(results) == 1
    assert results[0].id == "msg1"


# =============================================================================
# QueryOptions Tests
# =============================================================================


def test_query_with_limit():
    """Test query with limit."""
    messages = [create_test_message(message_id=f"msg{i}") for i in range(10)]

    options = QueryOptions(limit=5)
    results = query_messages(messages, options)

    assert len(results) == 5


def test_query_with_offset():
    """Test query with offset."""
    messages = [create_test_message(message_id=f"msg{i}") for i in range(10)]

    options = QueryOptions(offset=5, limit=3)
    results = query_messages(messages, options)

    assert len(results) == 3
    assert results[0].id == "msg5"


def test_query_with_order_desc():
    """Test query with descending order."""
    messages = [create_test_message(message_id=f"msg{i}") for i in range(5)]

    options = QueryOptions(order="desc")
    results = query_messages(messages, options)

    # Should be reversed
    assert results[0].id == "msg4"
    assert results[-1].id == "msg0"


def test_query_with_time_range():
    """Test query with time range (after/before)."""
    base_time = int(time.time() * 1000)

    messages = [
        create_test_message(message_id="msg1", timestamp=base_time),
        create_test_message(message_id="msg2", timestamp=base_time + 1000),
        create_test_message(message_id="msg3", timestamp=base_time + 2000),
        create_test_message(message_id="msg4", timestamp=base_time + 3000),
    ]

    # Query messages after base_time + 1000
    options = QueryOptions(after=base_time + 1000)
    results = query_messages(messages, options)

    assert len(results) == 2  # msg3, msg4

    # Query messages before base_time + 2000
    options = QueryOptions(before=base_time + 2000)
    results = query_messages(messages, options)

    assert len(results) == 2  # msg1, msg2


def test_query_with_filter():
    """Test query with message filter."""
    messages = [
        create_test_message(message_id="msg1", has_error=False),
        create_test_message(message_id="msg2", has_error=True),
        create_test_message(message_id="msg3", has_error=False),
    ]

    filter = MessageFilter(has_errors=True)
    options = QueryOptions(filter=filter)
    results = query_messages(messages, options)

    assert len(results) == 1
    assert results[0].id == "msg2"


def test_query_combined_options():
    """Test combining multiple query options."""
    base_time = int(time.time() * 1000)

    messages = [
        create_test_message(
            message_id=f"msg{i}",
            timestamp=base_time + i * 1000,
            has_error=(i % 2 == 0),
        )
        for i in range(10)
    ]

    # Get errors from middle range, limit to 2
    filter = MessageFilter(has_errors=True)
    options = QueryOptions(
        after=base_time + 2000,
        before=base_time + 8000,
        filter=filter,
        limit=2,
    )

    results = query_messages(messages, options)

    assert len(results) == 2
    assert all(msg.error is not None for msg in results)


# =============================================================================
# ContextSummary Tests
# =============================================================================


def test_build_context_summary_basic():
    """Test building basic context summary."""
    messages = [
        create_test_message(message_id=f"msg{i}", tools=["read"]) for i in range(10)
    ]

    summary = build_context_summary("conv1", messages, recent_limit=5)

    assert summary.conversation_id == "conv1"
    assert summary.message_count == 10
    assert summary.total_tokens == 1000  # 10 messages * 100 tokens
    assert len(summary.recent_activity) == 5


def test_build_context_summary_with_summaries():
    """Test context summary includes summary messages."""
    messages = [
        create_test_message(message_id="msg1"),
        create_test_message(message_id="msg2", is_summary=True),
        create_test_message(message_id="msg3"),
        create_test_message(message_id="msg4", is_summary=True),
    ]

    summary = build_context_summary("conv1", messages)

    assert len(summary.summaries) == 2
    assert all("summary" in s for s in summary.summaries)


def test_build_context_summary_with_errors():
    """Test context summary includes errors."""
    messages = [
        create_test_message(message_id="msg1", has_error=False),
        create_test_message(message_id="msg2", has_error=True),
        create_test_message(message_id="msg3", has_error=True),
    ]

    summary = build_context_summary("conv1", messages)

    assert len(summary.errors) == 2
    assert all("error" in e for e in summary.errors)


def test_build_context_summary_with_key_messages():
    """Test context summary includes high-importance messages."""
    messages = [
        create_test_message(message_id="msg1", importance=50.0),
        create_test_message(message_id="msg2", importance=150.0),  # High
        create_test_message(message_id="msg3", importance=200.0),  # High
    ]

    summary = build_context_summary("conv1", messages)

    assert len(summary.key_messages) == 2
    assert all(msg["importance"] > 100 for msg in summary.key_messages)


def test_context_summary_serialization():
    """Test context summary to_dict."""
    messages = [create_test_message(message_id=f"msg{i}") for i in range(5)]

    summary = build_context_summary("conv1", messages)
    summary_dict = summary.to_dict()

    assert summary_dict["conversation_id"] == "conv1"
    assert summary_dict["message_count"] == 5
    assert "total_tokens" in summary_dict
    assert "recent_activity" in summary_dict


# =============================================================================
# Manager Integration Tests
# =============================================================================


def test_manager_query_messages_basic():
    """Test ConversationManager.query_messages basic usage."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    # Add messages
    for i in range(10):
        msg = create_test_message(message_id=f"msg{i}")
        manager.add_message(conv.id, msg)

    # Query last 5
    results = manager.query_messages(conv.id, limit=5, order="desc")

    assert len(results) == 5
    assert results[0].id == "msg9"  # Most recent first


def test_manager_query_messages_with_filter():
    """Test ConversationManager.query_messages with filter."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    # Add mixed messages
    manager.add_message(conv.id, create_test_message(message_id="msg1", tools=["read"]))
    manager.add_message(
        conv.id, create_test_message(message_id="msg2", has_error=True)
    )
    manager.add_message(
        conv.id, create_test_message(message_id="msg3", tools=["write"])
    )

    # Query only errors
    results = manager.query_messages(conv.id, filter={"has_errors": True})

    assert len(results) == 1
    assert results[0].id == "msg2"


def test_manager_get_context_summary():
    """Test ConversationManager.get_context_summary."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    # Add various messages
    manager.add_message(conv.id, create_test_message(message_id="msg1"))
    manager.add_message(
        conv.id, create_test_message(message_id="msg2", is_summary=True)
    )
    manager.add_message(
        conv.id, create_test_message(message_id="msg3", has_error=True)
    )

    # Get summary
    summary = manager.get_context_summary(conv.id)

    assert summary["conversation_id"] == conv.id
    assert summary["message_count"] == 3
    assert len(summary["summaries"]) == 1
    assert len(summary["errors"]) == 1


def test_manager_query_time_range():
    """Test querying messages in time range."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    base_time = int(time.time() * 1000)

    # Add messages with different timestamps
    for i in range(5):
        msg = create_test_message(
            message_id=f"msg{i}", timestamp=base_time + i * 1000
        )
        manager.add_message(conv.id, msg)

    # Query middle range
    results = manager.query_messages(
        conv.id, after=base_time + 1000, before=base_time + 4000
    )

    assert len(results) == 2  # msg2, msg3


def test_manager_query_pagination():
    """Test query pagination with offset and limit."""
    manager = ConversationManager(storage=MemoryStorage(), config=HarnessConfig())

    conv = manager.create_conversation()

    # Add 20 messages
    for i in range(20):
        msg = create_test_message(message_id=f"msg{i}")
        manager.add_message(conv.id, msg)

    # Get page 2 (skip 10, get next 10)
    results = manager.query_messages(conv.id, offset=10, limit=10)

    assert len(results) == 10
    assert results[0].id == "msg10"
    assert results[-1].id == "msg19"
