"""Tests for importance-based pruning (Phase 1.2)."""

from harnessutils import (
    HarnessConfig,
    Message,
    ToolPart,
    ToolState,
)
from harnessutils.compaction.pruning import (
    OutputImportance,
    calculate_turn_age,
    prune_tool_outputs,
    score_tool_output,
)


def test_calculate_turn_age():
    """Test turn age calculation."""
    messages = [
        Message(id="msg_1", role="user"),
        Message(id="msg_2", role="assistant"),
        Message(id="msg_3", role="user"),
        Message(id="msg_4", role="assistant"),
        Message(id="msg_5", role="user"),
    ]

    # Most recent message (msg_5) = age 0
    assert calculate_turn_age(messages, messages[4]) == 0

    # msg_4 = age 1 (1 user turn ago)
    assert calculate_turn_age(messages, messages[3]) == 1

    # msg_3 = age 1 (same user turn)
    assert calculate_turn_age(messages, messages[2]) == 1

    # msg_2 = age 2
    assert calculate_turn_age(messages, messages[1]) == 2

    # msg_1 = age 2 (same user turn)
    assert calculate_turn_age(messages, messages[0]) == 2


def test_score_tool_output_basic():
    """Test basic importance scoring."""
    config = HarnessConfig()

    msg = Message(id="msg_1", role="assistant")
    part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="file1.txt\nfile2.txt",
        ),
    )
    msg.add_part(part)

    messages = [msg]

    score = score_tool_output(part, msg, messages, config.pruning)

    assert isinstance(score, OutputImportance)
    assert score.recency_score > 0  # Recent = high score
    assert score.size_penalty < 0  # Size penalty is negative
    assert score.semantic_score >= 0
    assert score.tool_priority > 0
    assert score.token_count > 0
    assert score.total_score > 0


def test_score_tool_output_with_error():
    """Test scoring output with error - should have high importance."""
    config = HarnessConfig()

    msg = Message(id="msg_1", role="assistant")
    part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "test"},
            output="Error: command not found\nTraceback: ...",
        ),
    )
    msg.add_part(part)

    messages = [msg]

    score = score_tool_output(part, msg, messages, config.pruning)

    # Error boost should make semantic score very high
    assert score.semantic_score > 500  # config.error_boost = 500
    assert score.total_score > 500  # Should be high overall


def test_score_tool_output_with_warning():
    """Test scoring output with warning."""
    config = HarnessConfig()

    msg = Message(id="msg_1", role="assistant")
    part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "test"},
            output="Warning: deprecated function\nResult: success",
        ),
    )
    msg.add_part(part)

    messages = [msg]

    score = score_tool_output(part, msg, messages, config.pruning)

    # Warning boost
    assert score.semantic_score > 200  # config.warning_boost = 200


def test_score_tool_output_recency_decay():
    """Test that older outputs have lower recency scores."""
    config = HarnessConfig()

    # Create old and new messages
    old_msg = Message(id="msg_1", role="assistant")
    old_part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="output",
        ),
    )
    old_msg.add_part(old_part)

    # Add several user turns in between
    messages = [
        old_msg,
        Message(id="msg_2", role="user"),
        Message(id="msg_3", role="assistant"),
        Message(id="msg_4", role="user"),
        Message(id="msg_5", role="assistant"),
        Message(id="msg_6", role="user"),
    ]

    new_msg = messages[-2]  # msg_5
    new_part = ToolPart(
        tool="bash",
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="output",
        ),
    )
    new_msg.add_part(new_part)

    old_score = score_tool_output(old_part, old_msg, messages, config.pruning)
    new_score = score_tool_output(new_part, new_msg, messages, config.pruning)

    # Newer output should have higher recency score
    assert new_score.recency_score > old_score.recency_score


def test_score_tool_output_size_penalty():
    """Test that larger outputs have higher size penalty."""
    config = HarnessConfig()

    msg = Message(id="msg_1", role="assistant")

    # Small output
    small_part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "ls"},
            output="small",
        ),
    )

    # Large output
    large_part = ToolPart(
        tool="bash",
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"command": "cat"},
            output="x" * 10000,  # Large output
        ),
    )

    messages = [msg]

    small_score = score_tool_output(small_part, msg, messages, config.pruning)
    large_score = score_tool_output(large_part, msg, messages, config.pruning)

    # Size penalty is negative, so larger output has more negative penalty
    assert large_score.size_penalty < small_score.size_penalty


def test_score_tool_output_tool_priority():
    """Test tool type priority affects score."""
    config = HarnessConfig()
    config.pruning.tool_importance = {
        "read": 50.0,
        "write": 100.0,
        "grep": 30.0,
    }

    msg = Message(id="msg_1", role="assistant")

    high_priority = ToolPart(
        tool="write",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"file": "test.py"},
            output="wrote file",
        ),
    )

    low_priority = ToolPart(
        tool="grep",
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"pattern": "test"},
            output="match",
        ),
    )

    messages = [msg]

    high_score = score_tool_output(high_priority, msg, messages, config.pruning)
    low_score = score_tool_output(low_priority, msg, messages, config.pruning)

    # Write should have higher tool priority than grep
    assert high_score.tool_priority > low_score.tool_priority


def test_prune_with_importance_scoring_preserves_errors():
    """Test that errors are preserved even when old."""
    config = HarnessConfig()
    config.pruning.use_importance_scoring = True
    config.pruning.prune_protect = 500  # Low threshold
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0

    # Old error message (should be preserved due to high semantic score)
    msg1 = Message(id="msg_1", role="assistant")
    error_part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "test"},
            output="Error: critical failure occurred\n" + ("x" * 1000),
        ),
    )
    msg1.add_part(error_part)

    # Recent normal message with grep (low priority tool)
    # Make it much larger so it has higher size penalty
    msg2 = Message(id="msg_2", role="user")
    msg3 = Message(id="msg_3", role="assistant")
    normal_part = ToolPart(
        tool="grep",  # Low priority tool (30)
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"pattern": "test"},
            output="normal output\n" + ("x" * 10000),  # Much larger
        ),
    )
    msg3.add_part(normal_part)

    messages = [msg1, msg2, msg3]

    result = prune_tool_outputs(messages, config.pruning)

    # Should prune something
    assert result.pruned >= 1

    # Error should NOT be pruned (high semantic score + error boost)
    # Even though it's older, semantic boost should protect it
    assert error_part.state.output != "", "Error output should be preserved"

    # Normal output should be pruned first (larger + lower tool priority + no semantic boost)
    assert normal_part.state.output == "", "Normal output should be pruned"


def test_prune_with_importance_scoring_disabled():
    """Test that disabling importance scoring falls back to FIFO."""
    config = HarnessConfig()
    config.pruning.use_importance_scoring = False  # Disabled
    config.pruning.prune_protect = 100
    config.pruning.prune_minimum = 0
    config.pruning.protect_turns = 0

    msg1 = Message(id="msg_1", role="assistant")
    part1 = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "test"},
            output="Error: important\n" + ("x" * 5000),  # Large enough
        ),
    )
    msg1.add_part(part1)

    msg2 = Message(id="msg_2", role="user")
    msg3 = Message(id="msg_3", role="assistant")
    part2 = ToolPart(
        tool="bash",
        call_id="call_2",
        state=ToolState(
            status="completed",
            input={"command": "test"},
            output="normal\n" + ("x" * 5000),  # Large enough
        ),
    )
    msg3.add_part(part2)

    messages = [msg1, msg2, msg3]

    result = prune_tool_outputs(messages, config.pruning)

    # With FIFO, older message pruned first regardless of importance
    assert result.pruned >= 1
    # part1 is older, so it gets pruned (even though it has error)
    assert part1.state.output == ""


def test_importance_scoring_enabled_by_default():
    """Test that importance scoring is enabled by default."""
    config = HarnessConfig()
    assert config.pruning.use_importance_scoring is True


def test_prune_respects_minimum_savings():
    """Test that pruning respects minimum savings threshold."""
    config = HarnessConfig()
    config.pruning.use_importance_scoring = True
    config.pruning.prune_protect = 100
    config.pruning.prune_minimum = 10000  # High threshold
    config.pruning.protect_turns = 0

    msg = Message(id="msg_1", role="assistant")
    part = ToolPart(
        tool="bash",
        call_id="call_1",
        state=ToolState(
            status="completed",
            input={"command": "test"},
            output="small",  # Too small to meet minimum
        ),
    )
    msg.add_part(part)

    messages = [msg]

    result = prune_tool_outputs(messages, config.pruning)

    # Should not prune because savings < minimum
    assert result.pruned == 0
    assert result.tokens_saved == 0
    assert part.state.output == "small"  # Not pruned
