"""Query and filter API for selective message loading.

Provides flexible message querying without loading full conversation history.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from harnessutils.models.message import Message


@dataclass
class MessageFilter:
    """Criteria for filtering messages."""

    has_errors: bool | None = None  # Only messages with errors
    has_warnings: bool | None = None  # Only messages with warnings
    min_importance: float | None = None  # Minimum importance score
    tools: list[str] | None = None  # Specific tool types
    roles: list[str] | None = None  # Message roles (user/assistant)
    has_tool_outputs: bool | None = None  # Only messages with tool outputs
    is_summary: bool | None = None  # Only summary messages

    def matches(self, message: Message) -> bool:
        """Check if message matches all filter criteria.

        Args:
            message: Message to check

        Returns:
            True if message matches all non-None criteria
        """
        # Role filter
        if self.roles is not None and message.role not in self.roles:
            return False

        # Summary filter
        if self.is_summary is not None and message.summary != self.is_summary:
            return False

        # Tool outputs filter
        if self.has_tool_outputs is not None:
            has_outputs = any(
                part.type == "tool" and getattr(part, "state", None) is not None
                for part in message.parts
            )
            if has_outputs != self.has_tool_outputs:
                return False

        # Error filter
        if self.has_errors is not None:
            has_errors = self._has_errors(message)
            if has_errors != self.has_errors:
                return False

        # Warning filter
        if self.has_warnings is not None:
            has_warnings = self._has_warnings(message)
            if has_warnings != self.has_warnings:
                return False

        # Tool type filter
        if self.tools is not None:
            message_tools = self._get_message_tools(message)
            if not any(tool in self.tools for tool in message_tools):
                return False

        # Importance filter (requires metadata)
        if self.min_importance is not None:
            importance = message.metadata.get("importance_score", 0.0)
            if importance < self.min_importance:
                return False

        return True

    def _has_errors(self, message: Message) -> bool:
        """Check if message has errors.

        Args:
            message: Message to check

        Returns:
            True if message has error status or error content
        """
        # Check message-level error
        if message.error:
            return True

        # Check tool parts for errors
        for part in message.parts:
            if part.type == "tool":
                tool_part = part
                if hasattr(tool_part, "state"):
                    if getattr(tool_part.state, "status", "") == "error":
                        return True
                    output = getattr(tool_part.state, "output", "")
                    if output and any(
                        keyword in output.lower()
                        for keyword in ["error", "exception", "traceback"]
                    ):
                        return True

        return False

    def _has_warnings(self, message: Message) -> bool:
        """Check if message has warnings.

        Args:
            message: Message to check

        Returns:
            True if message contains warning content
        """
        for part in message.parts:
            if part.type == "tool":
                tool_part = part
                if hasattr(tool_part, "state"):
                    output = getattr(tool_part.state, "output", "")
                    if output and "warning" in output.lower():
                        return True

        return False

    def _get_message_tools(self, message: Message) -> list[str]:
        """Get list of tools used in message.

        Args:
            message: Message to check

        Returns:
            List of tool names
        """
        tools = []
        for part in message.parts:
            if part.type == "tool" and hasattr(part, "tool"):
                tools.append(part.tool)

        return tools


@dataclass
class QueryOptions:
    """Options for message query."""

    limit: int | None = None  # Maximum messages to return
    offset: int = 0  # Skip first N messages
    order: Literal["asc", "desc"] = "asc"  # Order by creation time
    after: int | None = None  # Unix ms timestamp - messages after this time
    before: int | None = None  # Unix ms timestamp - messages before this time
    filter: MessageFilter | None = None  # Filter criteria


def query_messages(
    messages: list[Message],
    options: QueryOptions,
) -> list[Message]:
    """Query messages with filtering and pagination.

    Args:
        messages: All messages to query from
        options: Query options

    Returns:
        Filtered and paginated messages
    """
    results = messages.copy()

    # Time range filtering
    if options.after is not None:
        results = [
            msg
            for msg in results
            if msg.metadata.get("timestamp", 0) > options.after
        ]

    if options.before is not None:
        results = [
            msg
            for msg in results
            if msg.metadata.get("timestamp", float("inf")) < options.before
        ]

    # Apply filter criteria
    if options.filter is not None:
        results = [msg for msg in results if options.filter.matches(msg)]

    # Sort by order
    if options.order == "desc":
        results = list(reversed(results))

    # Apply offset
    if options.offset > 0:
        results = results[options.offset :]

    # Apply limit
    if options.limit is not None:
        results = results[: options.limit]

    return results


@dataclass
class ContextSummary:
    """Lightweight summary of conversation context."""

    conversation_id: str
    message_count: int
    total_tokens: int
    summaries: list[dict[str, Any]] = field(default_factory=list)
    recent_activity: list[dict[str, Any]] = field(default_factory=list)
    key_messages: list[dict[str, Any]] = field(default_factory=list)
    errors: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.

        Returns:
            Dictionary representation
        """
        return {
            "conversation_id": self.conversation_id,
            "message_count": self.message_count,
            "total_tokens": self.total_tokens,
            "summaries": self.summaries,
            "recent_activity": self.recent_activity,
            "key_messages": self.key_messages,
            "errors": self.errors,
        }


def build_context_summary(
    conversation_id: str,
    messages: list[Message],
    recent_limit: int = 5,
) -> ContextSummary:
    """Build lightweight context summary without full message content.

    Args:
        conversation_id: Conversation ID
        messages: All messages
        recent_limit: Number of recent messages to include

    Returns:
        Context summary
    """
    total_tokens = sum(
        msg.tokens.total if msg.tokens else 0 for msg in messages
    )

    # Extract summaries
    summaries = []
    for msg in messages:
        if msg.summary:
            # Get summary text from first text part
            summary_text = ""
            for part in msg.parts:
                if part.type == "text":
                    summary_text = getattr(part, "text", "")[:200]  # First 200 chars
                    break

            summaries.append(
                {
                    "id": msg.id,
                    "timestamp": msg.metadata.get("timestamp", 0),
                    "summary": summary_text,
                }
            )

    # Recent activity (last N messages)
    recent_activity = []
    for msg in messages[-recent_limit:]:
        activity = {
            "id": msg.id,
            "role": msg.role,
            "timestamp": msg.metadata.get("timestamp", 0),
            "has_tool_outputs": any(part.type == "tool" for part in msg.parts),
            "has_errors": msg.error is not None,
        }
        recent_activity.append(activity)

    # Key messages (high importance or errors)
    key_messages = []
    errors = []

    for msg in messages:
        # Check for errors
        if msg.error:
            errors.append(
                {
                    "id": msg.id,
                    "timestamp": msg.metadata.get("timestamp", 0),
                    "error": str(msg.error)[:200],  # First 200 chars
                }
            )

        # Check importance
        importance = msg.metadata.get("importance_score", 0.0)
        if importance > 100:  # High importance threshold
            key_messages.append(
                {
                    "id": msg.id,
                    "timestamp": msg.metadata.get("timestamp", 0),
                    "importance": importance,
                }
            )

    return ContextSummary(
        conversation_id=conversation_id,
        message_count=len(messages),
        total_tokens=total_tokens,
        summaries=summaries,
        recent_activity=recent_activity,
        key_messages=key_messages,
        errors=errors,
    )
