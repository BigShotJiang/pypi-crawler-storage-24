"""Context snapshot management for reproducibility and debugging.

Snapshots capture full conversation state at a point in time, enabling:
- Reproducible debugging (save state before/after changes)
- A/B testing (compare different context strategies)
- Time travel (restore to previous state)
- Version control (export snapshots to git)
"""

import json
import time
from dataclasses import dataclass, field
from typing import Any

from harnessutils.models.conversation import Conversation
from harnessutils.models.message import Message


@dataclass
class Snapshot:
    """Complete snapshot of conversation state.

    Captures everything needed to restore conversation to exact state:
    - All messages with full content
    - Conversation metadata (velocity, etc.)
    - Configuration used
    - Snapshot metadata (when, why)
    """

    snapshot_id: str
    conversation_id: str
    timestamp: int  # Unix ms
    messages: list[dict[str, Any]]  # Serialized messages
    conversation: dict[str, Any]  # Serialized conversation
    config: dict[str, Any]  # Configuration snapshot
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize snapshot to dictionary.

        Returns:
            Dictionary representation for JSON export
        """
        return {
            "snapshot_id": self.snapshot_id,
            "conversation_id": self.conversation_id,
            "timestamp": self.timestamp,
            "messages": self.messages,
            "conversation": self.conversation,
            "config": self.config,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Snapshot":
        """Deserialize snapshot from dictionary.

        Args:
            data: Dictionary representation

        Returns:
            Snapshot instance
        """
        return cls(
            snapshot_id=data["snapshot_id"],
            conversation_id=data["conversation_id"],
            timestamp=data["timestamp"],
            messages=data["messages"],
            conversation=data["conversation"],
            config=data["config"],
            metadata=data.get("metadata", {}),
        )


@dataclass
class SnapshotDiff:
    """Difference between two snapshots."""

    messages_added: int
    messages_removed: int
    tokens_delta: int
    message_changes: list[dict[str, Any]]
    config_changes: list[dict[str, Any]]
    metadata_changes: dict[str, Any]


class SnapshotManager:
    """Manages conversation snapshots.

    Handles snapshot creation, storage, restoration, and comparison.
    """

    def __init__(self, storage_backend: Any = None):
        """Initialize snapshot manager.

        Args:
            storage_backend: Optional storage backend for persistence
        """
        self.storage = storage_backend
        self._snapshots: dict[str, Snapshot] = {}

    def create_snapshot(
        self,
        conversation_id: str,
        messages: list[Message],
        conversation: Conversation,
        config: dict[str, Any],
        snapshot_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Snapshot:
        """Create snapshot of current conversation state.

        Args:
            conversation_id: Conversation ID
            messages: Current messages
            conversation: Conversation metadata
            config: Configuration dict
            snapshot_id: Optional snapshot ID (auto-generated if None)
            metadata: Optional metadata (e.g., {"reason": "before_refactor"})

        Returns:
            Created snapshot
        """
        from harnessutils.utils.ids import generate_id

        snapshot_id = snapshot_id or generate_id("snap")
        now_ms = int(time.time() * 1000)

        # Serialize messages with parts
        from dataclasses import asdict

        serialized_messages = []
        for msg in messages:
            msg_dict = msg.to_dict()
            # Add parts - they're not in to_dict() since normally stored separately
            msg_dict["parts"] = [asdict(part) for part in msg.parts]
            serialized_messages.append(msg_dict)

        # Create snapshot
        snapshot = Snapshot(
            snapshot_id=snapshot_id,
            conversation_id=conversation_id,
            timestamp=now_ms,
            messages=serialized_messages,
            conversation=conversation.to_dict(),
            config=config,
            metadata=metadata or {},
        )

        # Store in memory
        self._snapshots[snapshot_id] = snapshot

        # Optionally persist to storage
        if self.storage:
            self.storage.save_snapshot(snapshot_id, snapshot.to_dict())

        return snapshot

    def get_snapshot(self, snapshot_id: str) -> Snapshot | None:
        """Retrieve snapshot by ID.

        Args:
            snapshot_id: Snapshot ID

        Returns:
            Snapshot if found, None otherwise
        """
        # Check memory first
        if snapshot_id in self._snapshots:
            return self._snapshots[snapshot_id]

        # Try storage
        if self.storage:
            try:
                data = self.storage.load_snapshot(snapshot_id)
                snapshot = Snapshot.from_dict(data)
                self._snapshots[snapshot_id] = snapshot
                return snapshot
            except (KeyError, FileNotFoundError):
                pass

        return None

    def restore_snapshot(self, snapshot: Snapshot) -> tuple[list[Message], Conversation]:
        """Restore messages and conversation from snapshot.

        Args:
            snapshot: Snapshot to restore

        Returns:
            Tuple of (messages, conversation)
        """
        from harnessutils.models.parts import (
            CompactionPart,
            PatchPart,
            ReasoningPart,
            StepFinishPart,
            StepStartPart,
            SubtaskPart,
            TextPart,
            TimeInfo,
            ToolPart,
            ToolState,
        )

        def _deserialize_part(part_data: dict[str, Any]) -> Any:
            """Deserialize a part from dict."""
            part_type = part_data.get("type")

            # Extract time if present
            time_info = None
            if part_data.get("time"):
                time_data = part_data["time"]
                time_info = TimeInfo(
                    start=time_data.get("start", 0),
                    end=time_data.get("end", 0),
                    compacted=time_data.get("compacted"),
                )

            # Common fields
            metadata = part_data.get("metadata", {})

            if part_type == "text":
                return TextPart(
                    text=part_data.get("text", ""),
                    ignored=part_data.get("ignored", False),
                    time=time_info,
                    metadata=metadata,
                )
            elif part_type == "reasoning":
                return ReasoningPart(
                    text=part_data.get("text", ""),
                    time=time_info,
                    metadata=metadata,
                )
            elif part_type == "tool":
                state_data = part_data.get("state", {})
                state_time = None
                if state_data.get("time"):
                    st = state_data["time"]
                    state_time = TimeInfo(
                        start=st.get("start", 0),
                        end=st.get("end", 0),
                        compacted=st.get("compacted"),
                    )
                return ToolPart(
                    tool=part_data.get("tool", ""),
                    call_id=part_data.get("call_id", ""),
                    state=ToolState(
                        status=state_data.get("status", "pending"),
                        input=state_data.get("input", {}),
                        output=state_data.get("output", ""),
                        title=state_data.get("title", ""),
                        metadata=state_data.get("metadata", {}),
                        error=state_data.get("error"),
                        time=state_time,
                        attachments=state_data.get("attachments", []),
                    ),
                    time=time_info,
                    metadata=metadata,
                )
            elif part_type == "step-start":
                return StepStartPart(
                    snapshot=part_data.get("snapshot", ""),
                    time=time_info,
                    metadata=metadata,
                )
            elif part_type == "step-finish":
                return StepFinishPart(
                    reason=part_data.get("reason", "stop"),
                    snapshot=part_data.get("snapshot", ""),
                    tokens=part_data.get("tokens", {}),
                    cost=part_data.get("cost", 0.0),
                    time=time_info,
                    metadata=metadata,
                )
            elif part_type == "compaction":
                return CompactionPart(
                    auto=part_data.get("auto", False),
                    time=time_info,
                    metadata=metadata,
                )
            elif part_type == "patch":
                return PatchPart(
                    hash=part_data.get("hash", ""),
                    files=part_data.get("files", []),
                    time=time_info,
                    metadata=metadata,
                )
            elif part_type == "subtask":
                return SubtaskPart(
                    prompt=part_data.get("prompt", ""),
                    description=part_data.get("description", ""),
                    agent=part_data.get("agent", ""),
                    model=part_data.get("model", {}),
                    time=time_info,
                    metadata=metadata,
                )
            else:
                # Unknown part type - create a basic TextPart
                return TextPart(text="", time=time_info, metadata=metadata)

        # Deserialize messages
        messages = []
        for msg_data in snapshot.messages:
            msg = Message.from_dict(msg_data)
            # Restore parts
            if "parts" in msg_data:
                for part_data in msg_data["parts"]:
                    part = _deserialize_part(part_data)
                    msg.add_part(part)
            messages.append(msg)

        # Deserialize conversation
        conversation = Conversation.from_dict(snapshot.conversation)

        return messages, conversation

    def compare_snapshots(
        self, snapshot1_id: str, snapshot2_id: str
    ) -> SnapshotDiff | None:
        """Compare two snapshots to see what changed.

        Args:
            snapshot1_id: First snapshot ID (earlier)
            snapshot2_id: Second snapshot ID (later)

        Returns:
            SnapshotDiff describing changes, or None if snapshots not found
        """
        snap1 = self.get_snapshot(snapshot1_id)
        snap2 = self.get_snapshot(snapshot2_id)

        if not snap1 or not snap2:
            return None

        # Compare message counts
        messages_added = len(snap2.messages) - len(snap1.messages)
        messages_removed = max(0, len(snap1.messages) - len(snap2.messages))

        # Calculate token delta (simplified - just count message changes)
        # In a real implementation, would calculate actual token delta
        tokens_delta = 0

        # Find message changes
        message_changes = []
        snap1_ids = {msg["id"] for msg in snap1.messages}
        snap2_ids = {msg["id"] for msg in snap2.messages}

        added_ids = snap2_ids - snap1_ids
        removed_ids = snap1_ids - snap2_ids

        if added_ids:
            message_changes.append({
                "type": "added",
                "count": len(added_ids),
                "ids": list(added_ids),
            })

        if removed_ids:
            message_changes.append({
                "type": "removed",
                "count": len(removed_ids),
                "ids": list(removed_ids),
            })

        # Compare configs (simplified)
        config_changes = []
        if snap1.config != snap2.config:
            config_changes.append({
                "type": "config_modified",
                "before": snap1.config,
                "after": snap2.config,
            })

        # Metadata changes
        metadata_changes = {
            "snapshot1_timestamp": snap1.timestamp,
            "snapshot2_timestamp": snap2.timestamp,
            "time_delta_ms": snap2.timestamp - snap1.timestamp,
        }

        return SnapshotDiff(
            messages_added=max(0, messages_added),
            messages_removed=messages_removed,
            tokens_delta=tokens_delta,
            message_changes=message_changes,
            config_changes=config_changes,
            metadata_changes=metadata_changes,
        )

    def export_snapshot(self, snapshot_id: str, file_path: str) -> None:
        """Export snapshot to JSON file.

        Useful for:
        - Version control (commit snapshots to git)
        - Sharing test cases
        - Long-term archival

        Args:
            snapshot_id: Snapshot to export
            file_path: Path to write JSON file

        Raises:
            FileNotFoundError: If snapshot not found
        """
        snapshot = self.get_snapshot(snapshot_id)
        if not snapshot:
            raise FileNotFoundError(f"Snapshot {snapshot_id} not found")

        with open(file_path, "w") as f:
            json.dump(snapshot.to_dict(), f, indent=2)

    def import_snapshot(self, file_path: str) -> Snapshot:
        """Import snapshot from JSON file.

        Args:
            file_path: Path to JSON file

        Returns:
            Imported snapshot
        """
        with open(file_path) as f:
            data = json.load(f)

        snapshot = Snapshot.from_dict(data)
        self._snapshots[snapshot.snapshot_id] = snapshot

        return snapshot

    def list_snapshots(self, conversation_id: str | None = None) -> list[Snapshot]:
        """List all snapshots, optionally filtered by conversation.

        Args:
            conversation_id: Optional conversation ID filter

        Returns:
            List of snapshots (sorted by timestamp, newest first)
        """
        snapshots = list(self._snapshots.values())

        if conversation_id:
            snapshots = [s for s in snapshots if s.conversation_id == conversation_id]

        # Sort by timestamp, newest first
        snapshots.sort(key=lambda s: s.timestamp, reverse=True)

        return snapshots

    def delete_snapshot(self, snapshot_id: str) -> bool:
        """Delete snapshot.

        Args:
            snapshot_id: Snapshot to delete

        Returns:
            True if deleted, False if not found
        """
        if snapshot_id in self._snapshots:
            del self._snapshots[snapshot_id]

            # Also delete from storage if present
            if self.storage:
                try:
                    self.storage.delete_snapshot(snapshot_id)
                except (KeyError, FileNotFoundError):
                    pass

            return True

        return False
