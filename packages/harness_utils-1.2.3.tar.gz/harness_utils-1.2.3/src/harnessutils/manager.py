"""Main ConversationManager API for harness-utils."""

import time
from pathlib import Path
from typing import Any

from harnessutils.compaction.pruning import PruningDecision, prune_tool_outputs
from harnessutils.compaction.summarization import is_overflow, summarize_conversation
from harnessutils.compaction.truncation import truncate_output
from harnessutils.config import HarnessConfig, StorageConfig
from harnessutils.conversion.to_model import to_model_messages
from harnessutils.hooks import MessageHooks
from harnessutils.inspection import ContextInspector
from harnessutils.memory import SemanticMemoryBackend
from harnessutils.models.conversation import Conversation
from harnessutils.models.message import Message
from harnessutils.models.usage import Usage
from harnessutils.snapshots import Snapshot, SnapshotDiff, SnapshotManager
from harnessutils.storage.filesystem import FilesystemStorage
from harnessutils.storage.memory import MemoryStorage
from harnessutils.types import LLMClient, StorageBackend
from harnessutils.utils.ids import generate_id
from harnessutils.workspace import resolve_workspace


class ConversationManager:
    """Main interface for managing conversations with context window management.

    Provides high-level API for:
    - Creating and managing conversations
    - Adding messages
    - Automatic context compaction (truncation, pruning, summarization)
    - Message storage and retrieval
    """

    def __init__(
        self,
        storage: StorageBackend | None = None,
        config: HarnessConfig | None = None,
        *,
        workspace_root: Path | str | None = None,
        harness_name: str = ".harness",
        semantic_memory: SemanticMemoryBackend | None = None,
        message_hooks: MessageHooks | None = None,
    ):
        """Initialize conversation manager.

        Args:
            storage: Storage backend (uses in-memory if None)
            config: Configuration (uses defaults if None)
            workspace_root: Optional workspace root. Creates harness dir with stable
                project UUID. Defaults storage to FilesystemStorage under <harness>/sessions/.
            harness_name: Name of the harness directory (default: ".harness")
            semantic_memory: Optional semantic memory backend. Stored as attribute;
                harness-utils does not call it internally.
            message_hooks: Optional hooks for the add_message() lifecycle.
                on_before_add_message fires before storage and can modify or reject.
                on_after_add_message fires after storage for side effects.
        """
        self.config = config or HarnessConfig()
        self.project_id: str | None = None
        self.semantic_memory = semantic_memory

        if workspace_root is not None:
            harness_dir, self.project_id = resolve_workspace(Path(workspace_root), harness_name)
            if storage is None:
                sessions_path = harness_dir / "sessions"
                storage_config = StorageConfig(base_path=sessions_path)
                storage = FilesystemStorage(storage_config)

        self.storage = storage or MemoryStorage()
        self.message_hooks = message_hooks
        self._message_cache: dict[str, list[Message]] = {}
        # Pass storage (not self.storage) so SnapshotManager receives None when no
        # explicit backend was given — it falls back to its internal in-memory dict.
        self.snapshot_manager = SnapshotManager(storage)

    def create_conversation(
        self,
        conversation_id: str | None = None,
        project_id: str | None = None,
    ) -> Conversation:
        """Create a new conversation.

        Args:
            conversation_id: Optional conversation ID (generated if None)
            project_id: Optional project ID for grouping

        Returns:
            New conversation object
        """
        if conversation_id is None:
            conversation_id = generate_id("conv")

        now = int(time.time() * 1000)
        conversation = Conversation(
            id=conversation_id,
            project_id=project_id,
            created=now,
            updated=now,
        )

        self.storage.save_conversation(conversation_id, conversation.to_dict())
        self._message_cache[conversation_id] = []

        return conversation

    def add_message(self, conversation_id: str, message: Message) -> None:
        """Add a message to a conversation.

        If message_hooks.on_before_add_message is set, it is called first.
        Its return value replaces the message that will be stored. Raising
        from it rejects the message entirely (nothing is stored).

        If message_hooks.on_after_add_message is set, it is called after
        successful storage. Its return value is ignored.

        Args:
            conversation_id: Conversation to add message to
            message: Message to add
        """
        # Pre-hook — may modify message or raise to reject
        if self.message_hooks and self.message_hooks.on_before_add_message:
            message = self.message_hooks.on_before_add_message(conversation_id, message)

        # Inject timestamp if not set — required for cleanup_stale_data to work
        if "timestamp" not in message.metadata:
            message.metadata["timestamp"] = int(time.time() * 1000)

        self.storage.save_message(conversation_id, message.id, message.to_dict())

        # Persist parts separately so they survive process restart
        for idx, part in enumerate(message.parts):
            self.storage.save_part(message.id, f"{idx:04d}", part.to_dict())

        if conversation_id not in self._message_cache:
            self._message_cache[conversation_id] = []
        self._message_cache[conversation_id].append(message)

        # Load conversation and update
        conv_data = self.storage.load_conversation(conversation_id)
        conv = Conversation.from_dict(conv_data)
        conv.updated = int(time.time() * 1000)

        # Track velocity if message has token count
        if message.tokens:
            tokens_added = message.tokens.total
            conv.update_velocity(tokens_added)

        self.storage.save_conversation(conversation_id, conv.to_dict())

        # Post-hook — side effects only, message already persisted
        if self.message_hooks and self.message_hooks.on_after_add_message:
            self.message_hooks.on_after_add_message(conversation_id, message)

    def get_messages(self, conversation_id: str) -> list[Message]:
        """Get all messages for a conversation.

        Args:
            conversation_id: Conversation ID

        Returns:
            List of messages in chronological order
        """
        if conversation_id in self._message_cache:
            return self._message_cache[conversation_id]

        message_ids = self.storage.list_messages(conversation_id)
        messages = []
        for msg_id in message_ids:
            msg = Message.from_dict(self.storage.load_message(conversation_id, msg_id))
            # Reload persisted parts (saved by add_message)
            part_ids = self.storage.list_parts(msg_id)
            if part_ids:
                from harnessutils.models.parts import part_from_dict
                for part_id in part_ids:
                    try:
                        part_data = self.storage.load_part(msg_id, part_id)
                        msg.parts.append(part_from_dict(part_data))
                    except Exception:
                        pass
            messages.append(msg)

        self._message_cache[conversation_id] = messages
        return messages

    def query_messages(
        self,
        conversation_id: str,
        limit: int | None = None,
        offset: int = 0,
        order: str = "asc",
        after: int | None = None,
        before: int | None = None,
        filter: dict[str, Any] | None = None,
    ) -> list[Message]:
        """Query messages with filtering and pagination.

        Args:
            conversation_id: Conversation to query
            limit: Maximum messages to return
            offset: Skip first N messages
            order: "asc" (oldest first) or "desc" (newest first)
            after: Unix ms timestamp - messages after this time
            before: Unix ms timestamp - messages before this time
            filter: Filter criteria dict:
                - has_errors (bool): Only messages with errors
                - has_warnings (bool): Only messages with warnings
                - min_importance (float): Minimum importance score
                - tools (list[str]): Specific tool types
                - roles (list[str]): Message roles (user/assistant)
                - has_tool_outputs (bool): Only messages with tool outputs
                - is_summary (bool): Only summary messages

        Returns:
            Filtered and paginated messages

        Examples:
            # Get last 10 messages
            messages = manager.query_messages(conv_id, limit=10, order="desc")

            # Get messages with errors
            messages = manager.query_messages(
                conv_id,
                filter={"has_errors": True}
            )

            # Get recent high-importance messages
            messages = manager.query_messages(
                conv_id,
                filter={"min_importance": 50.0},
                after=timestamp_24h_ago,
                limit=20
            )
        """
        from harnessutils.query import MessageFilter, QueryOptions, query_messages

        # Build filter
        msg_filter = None
        if filter is not None:
            msg_filter = MessageFilter(
                has_errors=filter.get("has_errors"),
                has_warnings=filter.get("has_warnings"),
                min_importance=filter.get("min_importance"),
                tools=filter.get("tools"),
                roles=filter.get("roles"),
                has_tool_outputs=filter.get("has_tool_outputs"),
                is_summary=filter.get("is_summary"),
            )

        # Build query options
        options = QueryOptions(
            limit=limit,
            offset=offset,
            order=order,  # type: ignore
            after=after,
            before=before,
            filter=msg_filter,
        )

        # Get all messages and query
        messages = self.get_messages(conversation_id)
        return query_messages(messages, options)

    def get_context_summary(
        self, conversation_id: str, recent_limit: int = 5
    ) -> dict[str, Any]:
        """Get lightweight context summary without loading full content.

        Provides overview of conversation state including:
        - Message count and token usage
        - Summary messages
        - Recent activity (last N messages)
        - Key messages (high importance)
        - Error messages

        Args:
            conversation_id: Conversation to summarize
            recent_limit: Number of recent messages to include (default: 5)

        Returns:
            Dictionary with context summary:
            - conversation_id (str)
            - message_count (int)
            - total_tokens (int)
            - summaries (list): Summary messages
            - recent_activity (list): Last N message summaries
            - key_messages (list): High-importance messages
            - errors (list): Error messages

        Examples:
            # Get quick overview
            summary = manager.get_context_summary(conv_id)
            print(f"Messages: {summary['message_count']}")
            print(f"Tokens: {summary['total_tokens']}")
            print(f"Errors: {len(summary['errors'])}")
        """
        from harnessutils.query import build_context_summary

        messages = self.get_messages(conversation_id)
        summary = build_context_summary(conversation_id, messages, recent_limit)
        return summary.to_dict()

    def inspect_context(self, conversation_id: str) -> ContextInspector:
        """Create inspector for querying context state.

        Provides observability into:
        - What's currently in context
        - Token counts and breakdowns
        - Pruning predictions
        - Audit trail of decisions

        Args:
            conversation_id: Conversation to inspect

        Returns:
            ContextInspector instance with full query capabilities

        Example:
            >>> inspector = manager.inspect_context(conv_id)
            >>> summary = inspector.summary()
            >>> print(f"Total tokens: {summary['total_tokens']}")
            >>> impact = inspector.predict_impact(5000)
            >>> if impact['would_trigger_pruning']:
            ...     print(f"Would prune ~{impact['estimated_pruned_count']} outputs")
        """
        messages = self.get_messages(conversation_id)

        # Load conversation metadata
        conv_data = self.storage.load_conversation(conversation_id)
        conversation = Conversation.from_dict(conv_data)

        # Load persisted pruning decisions for audit trail
        decisions_data = conversation.metadata.get("latest_pruning_decisions", [])
        decisions = [PruningDecision.from_dict(d) for d in decisions_data]

        return ContextInspector(messages, self.config, conversation, decisions)

    def prune_before_turn(
        self,
        conversation_id: str,
        auto_mode: bool = False,
    ) -> dict[str, Any]:
        """Proactively prune old tool outputs before processing a turn.

        This is Tier 2 compaction - removes old tool outputs while
        preserving conversation structure.

        Args:
            conversation_id: Conversation to prune
            auto_mode: Whether this was auto-triggered

        Returns:
            Detailed pruning result with token tracking and breakdown:
            - pruned: Total outputs removed
            - tokens_saved: Total tokens saved
            - tokens_before: Token count before pruning
            - tokens_after: Token count after pruning
            - duplicates_pruned: Outputs removed due to duplication
            - importance_pruned: Outputs removed due to low importance
            - duplicate_tokens_saved: Tokens saved from deduplication
            - importance_tokens_saved: Tokens saved from importance pruning
            - reduction_percent: Percentage reduction in token usage
        """
        if not self.config.compaction.prune and auto_mode:
            return {
                "pruned": 0,
                "tokens_saved": 0,
                "tokens_before": 0,
                "tokens_after": 0,
                "duplicates_pruned": 0,
                "importance_pruned": 0,
                "duplicate_tokens_saved": 0,
                "importance_tokens_saved": 0,
                "reduction_percent": 0,
            }

        messages = self.get_messages(conversation_id)
        result = prune_tool_outputs(
            messages,
            self.config.pruning,
        )

        for msg in messages:
            self.storage.save_message(conversation_id, msg.id, msg.to_dict())

        # Update cache with pruned messages — parts are preserved since
        # prune_tool_outputs only clears tool output strings in-place
        self._message_cache[conversation_id] = messages

        # Persist decisions so audit trail and quality metrics work
        conv_data = self.storage.load_conversation(conversation_id)
        conv = Conversation.from_dict(conv_data)
        conv.metadata["latest_pruning_decisions"] = [d.to_dict() for d in result.decisions]
        self.storage.save_conversation(conversation_id, conv.to_dict())

        return result.to_dict()

    def predict_overflow(
        self,
        conversation_id: str,
        current_usage: Usage,
    ) -> bool:
        """Predict if conversation will overflow in next N turns.

        Args:
            conversation_id: Conversation to check
            current_usage: Current token usage

        Returns:
            True if overflow predicted within lookahead window
        """
        if not self.config.compaction.use_predictive:
            return False

        # Load conversation and get velocity
        conv_data = self.storage.load_conversation(conversation_id)
        conv = Conversation.from_dict(conv_data)
        velocity = conv.get_velocity()

        if velocity is None or not velocity.turn_deltas:
            return False  # No velocity data yet

        # Project tokens ahead
        lookahead = self.config.compaction.predictive_lookahead
        predicted_growth = velocity.predict_tokens_ahead(lookahead)

        # Calculate current total and projected total
        current_total = current_usage.input + current_usage.cache.read
        projected_total = current_total + predicted_growth

        # Check against safety margin
        usable_space = (
            self.config.model_limits.default_context_limit
            - self.config.model_limits.default_output_limit
        )
        safety_threshold = usable_space * self.config.compaction.predictive_safety_margin

        return projected_total > safety_threshold

    def needs_compaction(
        self,
        conversation_id: str,
        usage: Usage,
    ) -> bool:
        """Check if conversation needs summarization (Tier 3).

        Uses both reactive (overflow) and predictive checks.

        Args:
            conversation_id: Conversation to check
            usage: Token usage from last turn

        Returns:
            True if summarization needed
        """
        # Reactive check: already overflowed
        if is_overflow(
            usage,
            self.config.model_limits.default_context_limit,
            self.config.model_limits.default_output_limit,
        ):
            return True

        # Predictive check: will overflow soon
        return self.predict_overflow(conversation_id, usage)

    def compact(
        self,
        conversation_id: str,
        llm_client: LLMClient,
        parent_message_id: str,
        model: str | None = None,
        auto_mode: bool = False,
    ) -> dict[str, Any]:
        """Compact conversation using LLM summarization (Tier 3).

        Args:
            conversation_id: Conversation to compact
            llm_client: LLM client for summarization
            parent_message_id: Message that triggered compaction
            model: Optional model to use for summarization
            auto_mode: Whether this was auto-triggered

        Returns:
            Compaction result with summary message and metrics
        """
        if not self.config.compaction.auto and auto_mode:
            return {"summarized": False}

        messages = self.get_messages(conversation_id)
        summary_id = generate_id("msg")

        result = summarize_conversation(
            messages=messages,
            llm_client=llm_client,
            parent_message_id=parent_message_id,
            message_id=summary_id,
            model=model,
            auto_mode=auto_mode,
            config=self.config.summarization,
        )

        self.add_message(conversation_id, result.summary_message)

        return {
            "summarized": True,
            "summary_message_id": summary_id,
            "tokens_used": result.tokens_used.total,
            "cost": result.cost,
        }

    def to_model_format(self, conversation_id: str) -> list[dict[str, Any]]:
        """Convert conversation messages to model format for LLM requests.

        Args:
            conversation_id: Conversation to convert

        Returns:
            List of messages in model format
        """
        messages = self.get_messages(conversation_id)
        return to_model_messages(messages)

    def calculate_context_usage(
        self,
        conversation_id: str,
        model: str | None = None,
    ) -> int:
        """Calculate exact token count for conversation using tiktoken.

        This counts ALL tokens in the conversation (user messages, assistant
        responses, tool outputs, etc.) that will be sent to the model.

        Uses cl100k_base tokenizer (GPT-4/Claude) which works for most modern LLMs.

        Args:
            conversation_id: Conversation to calculate usage for
            model: Optional model name (currently unused, defaults to cl100k_base)

        Returns:
            Exact token count that will be used in context window
        """
        from harnessutils.tokens.exact import count_tokens_exact

        messages = self.to_model_format(conversation_id)
        return count_tokens_exact(messages, model)

    def get_tool_output_tokens(self, conversation_id: str) -> dict[str, Any]:
        """Get detailed breakdown of token usage for tool outputs.

        Args:
            conversation_id: Conversation to analyze

        Returns:
            Dictionary with token breakdown:
            - total: Total tokens in tool outputs
            - by_tool: Token count per tool type
            - prunable: Tokens that could be pruned
            - protected: Tokens in protected outputs
        """
        from harnessutils.compaction.pruning import calculate_context_tokens

        messages = self.get_messages(conversation_id)

        total = calculate_context_tokens(messages)
        by_tool: dict[str, int] = {}
        prunable = 0
        protected = 0
        turns_skipped = 0

        for msg in reversed(messages):
            if msg.role == "user":
                turns_skipped += 1

            for part in msg.parts:
                from harnessutils.models.parts import ToolPart
                from harnessutils.tokens.exact import count_tokens_fast

                if not isinstance(part, ToolPart):
                    continue

                if part.state.status != "completed":
                    continue

                if not part.state.output:
                    continue

                tokens = count_tokens_fast(part.state.output)

                # Track by tool type
                by_tool[part.tool] = by_tool.get(part.tool, 0) + tokens

                # Determine if prunable
                is_protected = (
                    turns_skipped < self.config.pruning.protect_turns
                    or part.tool in self.config.pruning.protected_tools
                    or (part.state.time and part.state.time.compacted)
                )

                if is_protected:
                    protected += tokens
                else:
                    prunable += tokens

        return {
            "total": total,
            "by_tool": by_tool,
            "prunable": prunable,
            "protected": protected,
            "prunability_percent": round((prunable / total * 100) if total > 0 else 0, 1),
        }

    def get_context_quality(self, conversation_id: str) -> dict[str, Any]:
        """Get current quality metrics for conversation.

        Calculates all quality metrics, updates history, and returns assessment
        with health status and actionable recommendations.

        Args:
            conversation_id: Conversation to analyze

        Returns:
            Dictionary with all metrics, health status, and recommendations.
            Keys: information_density, redundancy_ratio, staleness_score,
                  error_preservation_rate, protected_ratio, health, recommendations
        """
        from harnessutils.quality import assess_quality

        conv_data = self.storage.load_conversation(conversation_id)
        conv = Conversation.from_dict(conv_data)
        messages = self.get_messages(conversation_id)

        # Get pruning decisions from metadata if available
        decisions = conv.metadata.get("latest_pruning_decisions")

        snapshot = assess_quality(
            messages=messages,
            config=self.config.pruning,
            decisions=decisions,
        )

        # Update history
        conv.update_quality_history(snapshot)
        self.storage.save_conversation(conversation_id, conv.to_dict())

        return snapshot.to_dict()

    def track_quality_metric(
        self,
        conversation_id: str,
        metric_name: str,
        value: float,
        timestamp: int | None = None,
    ) -> None:
        """Track a single quality metric value.

        Note: Prefer get_context_quality() which calculates all metrics.
        This is for custom/external metrics.

        Args:
            conversation_id: Conversation to track
            metric_name: Name of metric (e.g., "information_density")
            value: Metric value
            timestamp: Unix ms timestamp (defaults to now)
        """
        from harnessutils.quality import QualitySnapshot

        if timestamp is None:
            timestamp = int(time.time() * 1000)

        conv_data = self.storage.load_conversation(conversation_id)
        conv = Conversation.from_dict(conv_data)

        # Create minimal snapshot with just this metric
        # (Other metrics set to 0.0, empty recommendations)
        snapshot = QualitySnapshot(
            timestamp=timestamp,
            information_density=value if metric_name == "information_density" else 0.0,
            redundancy_ratio=value if metric_name == "redundancy_ratio" else 0.0,
            staleness_score=value if metric_name == "staleness_score" else 0.0,
            error_preservation_rate=value
            if metric_name == "error_preservation_rate"
            else 0.0,
            protected_ratio=value if metric_name == "protected_ratio" else 0.0,
            health="unknown",
            recommendations=[],
        )

        conv.update_quality_history(snapshot)
        self.storage.save_conversation(conversation_id, conv.to_dict())

    def get_quality_trend(
        self,
        conversation_id: str,
        metric: str,
        window: int = 20,
    ) -> list[tuple[int, float]]:
        """Get trend data for a specific metric.

        Args:
            conversation_id: Conversation to query
            metric: Metric name (e.g., "information_density")
            window: Number of most recent snapshots to return

        Returns:
            List of (timestamp, value) tuples, most recent first
        """
        conv_data = self.storage.load_conversation(conversation_id)
        conv = Conversation.from_dict(conv_data)

        history = conv.get_quality_history()
        if history is None:
            return []

        return history.get_trend(metric, window)

    def truncate_tool_output(
        self,
        output: str,
        tool_name: str,
    ) -> str:
        """Truncate tool output if it exceeds limits (Tier 1).

        Args:
            output: Tool output to truncate
            tool_name: Name of the tool

        Returns:
            Potentially truncated output
        """
        output_id = generate_id(f"output_{tool_name}")

        result = truncate_output(
            output=output,
            config=self.config.truncation,
            output_id=output_id,
        )

        if result.truncated and result.output_path:
            self.storage.save_truncated_output(result.output_path, output)

        return result.content

    def create_snapshot(
        self,
        conversation_id: str,
        snapshot_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Snapshot:
        """Create snapshot of conversation state for reproducibility.

        Captures full conversation state including:
        - All messages with content
        - Conversation metadata (velocity, etc.)
        - Current configuration

        Useful for:
        - Debugging (save state before/after changes)
        - A/B testing (compare different strategies)
        - Reproducibility (restore exact state)

        Args:
            conversation_id: Conversation to snapshot
            snapshot_id: Optional snapshot ID (auto-generated if None)
            metadata: Optional metadata (e.g., {"reason": "before_refactor"})

        Returns:
            Created snapshot

        Example:
            >>> snap = manager.create_snapshot(conv_id, metadata={"test": "baseline"})
            >>> # Make changes...
            >>> snap2 = manager.create_snapshot(conv_id, metadata={"test": "optimized"})
            >>> diff = manager.compare_snapshots(snap.snapshot_id, snap2.snapshot_id)
        """
        messages = self.get_messages(conversation_id)

        conv_data = self.storage.load_conversation(conversation_id)
        conversation = Conversation.from_dict(conv_data)

        # Serialize config to dict recursively (convert dataclasses, Paths, etc.)
        from dataclasses import asdict, is_dataclass
        from pathlib import Path

        def _serialize_config(obj: Any) -> Any:
            """Recursively convert config to JSON-safe dict."""
            if isinstance(obj, Path):
                return str(obj)
            elif is_dataclass(obj) and not isinstance(obj, type):
                # Convert dataclass instance to dict, then recursively serialize values
                obj_dict = asdict(obj)
                return {k: _serialize_config(v) for k, v in obj_dict.items()}
            elif isinstance(obj, dict):
                return {k: _serialize_config(v) for k, v in obj.items()}
            elif isinstance(obj, (list, tuple)):
                return [_serialize_config(item) for item in obj]
            else:
                return obj

        config_dict = _serialize_config(self.config)

        return self.snapshot_manager.create_snapshot(
            conversation_id=conversation_id,
            messages=messages,
            conversation=conversation,
            config=config_dict,
            snapshot_id=snapshot_id,
            metadata=metadata,
        )

    def restore_snapshot(self, snapshot_id: str) -> str:
        """Restore conversation from snapshot.

        WARNING: This replaces current conversation state with snapshot state.
        Consider creating a snapshot of current state first.

        Args:
            snapshot_id: Snapshot to restore

        Returns:
            Conversation ID of restored conversation

        Raises:
            FileNotFoundError: If snapshot not found
        """
        snapshot = self.snapshot_manager.get_snapshot(snapshot_id)
        if not snapshot:
            raise FileNotFoundError(f"Snapshot {snapshot_id} not found")

        messages, conversation = self.snapshot_manager.restore_snapshot(snapshot)

        # Clear existing messages (replace entire conversation state)
        # For memory storage, clear the messages dict for this conversation
        if hasattr(self.storage, "messages"):
            if snapshot.conversation_id in self.storage.messages:
                self.storage.messages[snapshot.conversation_id] = {}

        # Save conversation
        self.storage.save_conversation(snapshot.conversation_id, conversation.to_dict())

        # Save messages
        for msg in messages:
            self.storage.save_message(snapshot.conversation_id, msg.id, msg.to_dict())

        # Clear cache
        if snapshot.conversation_id in self._message_cache:
            del self._message_cache[snapshot.conversation_id]

        return snapshot.conversation_id

    def compare_snapshots(
        self, snapshot1_id: str, snapshot2_id: str
    ) -> SnapshotDiff | None:
        """Compare two snapshots to see what changed.

        Args:
            snapshot1_id: First snapshot ID (earlier)
            snapshot2_id: Second snapshot ID (later)

        Returns:
            SnapshotDiff describing changes:
            - messages_added: Number of messages added
            - messages_removed: Number of messages removed
            - tokens_delta: Change in token count
            - message_changes: List of specific changes
            - config_changes: Configuration modifications
            - metadata_changes: Additional metadata

            None if snapshots not found
        """
        return self.snapshot_manager.compare_snapshots(snapshot1_id, snapshot2_id)

    def export_snapshot(self, snapshot_id: str, file_path: str) -> None:
        """Export snapshot to JSON file for version control.

        Args:
            snapshot_id: Snapshot to export
            file_path: Path to write JSON file

        Raises:
            FileNotFoundError: If snapshot not found

        Example:
            >>> snap = manager.create_snapshot(conv_id)
            >>> manager.export_snapshot(snap.snapshot_id, "snapshots/baseline.json")
            >>> # Commit to git for reproducibility
        """
        self.snapshot_manager.export_snapshot(snapshot_id, file_path)

    def import_snapshot(self, file_path: str) -> Snapshot:
        """Import snapshot from JSON file.

        Args:
            file_path: Path to JSON file

        Returns:
            Imported snapshot
        """
        return self.snapshot_manager.import_snapshot(file_path)

    def cleanup_stale_data(
        self,
        conversation_id: str,
        max_age_hours: float = 24,
        keep_errors: bool = True,
        execute: bool = False,
    ) -> dict[str, Any]:
        """Clean up stale conversation data.

        By default, identifies old messages and tool outputs for cleanup based on age
        without making any changes. Set execute=True to actually clear stale outputs.

        Args:
            conversation_id: Conversation to clean up
            max_age_hours: Maximum age in hours before considering stale (default: 24)
            keep_errors: Whether to preserve error messages (default: True)
            execute: When True, actually clears stale outputs (default: False)

        Returns:
            Dictionary with cleanup statistics:
            - messages_archived (int): Messages eligible for archival
            - tokens_freed (int): Tokens that would be freed
            - duplicates_removed (int): Duplicate outputs found
            - stale_outputs_pruned (int): Stale outputs identified/cleared
            - operations (list[str]): Description of operations

        Example:
            >>> result = manager.cleanup_stale_data(conv_id, max_age_hours=48)
            >>> print(f"Can free {result['tokens_freed']} tokens")
            >>> result = manager.cleanup_stale_data(conv_id, max_age_hours=48, execute=True)
            >>> print(f"Freed {result['tokens_freed']} tokens")
        """
        from harnessutils.maintenance import cleanup_stale_data

        messages = self.get_messages(conversation_id)
        result = cleanup_stale_data(
            messages=messages,
            config=self.config.pruning,
            max_age_hours=max_age_hours,
            keep_errors=keep_errors,
            execute=execute,
        )

        if execute:
            for msg in messages:
                self.storage.save_message(conversation_id, msg.id, msg.to_dict())
            # Invalidate cache — outputs were cleared in-place
            if conversation_id in self._message_cache:
                del self._message_cache[conversation_id]

        return result.to_dict()

    def scan_and_deduplicate(self, conversation_id: str) -> dict[str, Any]:
        """Scan for duplicate outputs and return statistics.

        Identifies duplicate tool outputs without removing them.
        Use prune_before_turn() to actually remove duplicates.

        Args:
            conversation_id: Conversation to scan

        Returns:
            Dictionary with deduplication statistics:
            - duplicates_removed (int): Number of duplicates found
            - tokens_freed (int): Tokens that would be freed
            - operations (list[str]): Description of findings

        Example:
            >>> result = manager.scan_and_deduplicate(conv_id)
            >>> if result['duplicates_removed'] > 0:
            ...     print(f"Found {result['duplicates_removed']} duplicates")
            ...     # Run compaction to actually remove them
            ...     manager.prune_before_turn(conv_id)
        """
        from harnessutils.maintenance import scan_and_deduplicate

        messages = self.get_messages(conversation_id)
        result = scan_and_deduplicate(
            messages=messages,
            config=self.config.pruning,
        )

        return result.to_dict()

    def get_memory(self, project_id: str, key: str, default: Any = None) -> Any:
        """Get a value from project-scoped memory.

        Args:
            project_id: Project to retrieve memory from
            key: Memory key
            default: Default value if key not found

        Returns:
            Stored value or default
        """
        data = self._load_project_memory(project_id)
        return data.get(key, default)

    def set_memory(self, project_id: str, key: str, value: Any) -> None:
        """Set a value in project-scoped memory.

        Args:
            project_id: Project to store memory in
            key: Memory key
            value: Value to store
        """
        data = self._load_project_memory(project_id)
        data[key] = value
        try:
            self.storage.save_project_memory(project_id, data)
        except AttributeError:
            pass  # Backend doesn't support project memory

    def delete_memory(self, project_id: str, key: str) -> None:
        """Delete a key from project-scoped memory.

        Args:
            project_id: Project to delete memory from
            key: Memory key to delete
        """
        data = self._load_project_memory(project_id)
        data.pop(key, None)
        try:
            self.storage.save_project_memory(project_id, data)
        except AttributeError:
            pass  # Backend doesn't support project memory

    def list_memory(self, project_id: str) -> dict[str, Any]:
        """List all memory keys and values for a project.

        Args:
            project_id: Project to list memory for

        Returns:
            Dictionary of all memory key-value pairs
        """
        return self._load_project_memory(project_id)

    def _load_project_memory(self, project_id: str) -> dict[str, Any]:
        """Load project memory, returning empty dict on failure.

        Args:
            project_id: Project to load memory for

        Returns:
            Memory dictionary (empty if not found or backend unsupported)
        """
        try:
            return self.storage.load_project_memory(project_id)
        except (FileNotFoundError, AttributeError):
            return {}

    def detect_context_issues(self, conversation_id: str) -> list[dict[str, Any]]:
        """Detect quality and drift issues in conversation context.

        Analyzes conversation for common problems:
        - High redundancy (duplicate content)
        - Staleness accumulation (old messages)
        - Low information density
        - Error preservation status
        - Excessive protection (limiting pruning)

        Args:
            conversation_id: Conversation to analyze

        Returns:
            List of issue dictionaries, each containing:
            - issue_type (str): Type of issue
            - severity (str): "info", "warning", or "error"
            - description (str): Human-readable description
            - affected_count (int): Number of items affected
            - suggested_fix (str): Recommended action
            - metadata (dict): Additional details

        Example:
            >>> issues = manager.detect_context_issues(conv_id)
            >>> for issue in issues:
            ...     if issue['severity'] == 'warning':
            ...         print(f"⚠️  {issue['description']}")
            ...         print(f"   Fix: {issue['suggested_fix']}")
        """
        from harnessutils.maintenance import detect_context_issues

        conv_data = self.storage.load_conversation(conversation_id)
        conv = Conversation.from_dict(conv_data)
        messages = self.get_messages(conversation_id)

        issues = detect_context_issues(
            messages=messages,
            conversation=conv,
            config=self.config.pruning,
        )

        return [issue.to_dict() for issue in issues]
