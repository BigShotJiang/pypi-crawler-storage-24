"""SemanticMemoryBackend protocol for harness-utils.

Consumers implement this protocol to provide semantic memory capabilities.
harness-utils only holds a reference — it does not call the backend internally.
"""

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class SemanticMemoryBackend(Protocol):
    async def add_artifact(
        self,
        content: str,
        kind: str,
        *,
        namespace: str = "default",
        metadata: dict[str, Any] | None = None,
    ) -> Any: ...

    async def search_artifacts(
        self,
        query: str,
        *,
        top_k: int = 10,
        kind: str | None = None,
        namespace: str | None = None,
        min_similarity: float = 0.0,
    ) -> list[Any]: ...

    async def get_artifact(self, artifact_id: int) -> Any | None: ...

    async def update_artifact(
        self,
        artifact_id: int,
        *,
        metadata: dict[str, Any] | None = None,
        content: str | None = None,
    ) -> Any: ...

    async def delete_artifact(self, artifact_id: int) -> None: ...
