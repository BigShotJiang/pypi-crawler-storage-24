"""Part types for message decomposition.

Parts are the granular units that make up messages. This enables
selective compaction where tool outputs can be cleared while
preserving text and metadata.
"""

from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass
class TimeInfo:
    """Timing information for parts."""

    start: int  # Unix timestamp in milliseconds
    end: int | None = None
    compacted: int | None = None  # When output was compacted


@dataclass
class ToolState:
    """State information for tool execution."""

    status: Literal["pending", "running", "completed", "error"]
    input: dict[str, Any] = field(default_factory=dict)
    output: str = ""
    title: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    time: TimeInfo | None = None
    attachments: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class Part:
    """Base class for message parts."""

    type: str = field(init=False)
    time: TimeInfo | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize part to dict for storage."""
        d: dict[str, Any] = {"type": self.type, "metadata": self.metadata}
        if self.time:
            d["time"] = {
                "start": self.time.start,
                "end": self.time.end,
                "compacted": self.time.compacted,
            }
        return d


@dataclass
class TextPart(Part):
    """Text content part."""

    text: str = ""
    ignored: bool = False  # If true, skip when converting to model format

    def __post_init__(self) -> None:
        self.type = "text"

    def to_dict(self) -> dict[str, Any]:
        d = super().to_dict()
        d["text"] = self.text
        d["ignored"] = self.ignored
        return d


@dataclass
class ReasoningPart(Part):
    """Extended thinking/reasoning content part."""

    text: str = ""

    def __post_init__(self) -> None:
        self.type = "reasoning"

    def to_dict(self) -> dict[str, Any]:
        d = super().to_dict()
        d["text"] = self.text
        return d


@dataclass
class ToolPart(Part):
    """Tool execution part."""

    tool: str = ""
    call_id: str = ""
    state: ToolState = field(default_factory=lambda: ToolState(status="pending"))

    def __post_init__(self) -> None:
        self.type = "tool"

    def to_dict(self) -> dict[str, Any]:
        d = super().to_dict()
        d["tool"] = self.tool
        d["call_id"] = self.call_id
        state = self.state
        state_dict: dict[str, Any] = {
            "status": state.status,
            "input": state.input,
            "output": state.output,
            "title": state.title,
            "metadata": state.metadata,
            "attachments": state.attachments,
        }
        if state.error is not None:
            state_dict["error"] = state.error
        if state.time:
            state_dict["time"] = {
                "start": state.time.start,
                "end": state.time.end,
                "compacted": state.time.compacted,
            }
        d["state"] = state_dict
        return d


@dataclass
class StepStartPart(Part):
    """Step boundary marker - start of LLM turn."""

    snapshot: str = ""  # State snapshot ID

    def __post_init__(self) -> None:
        self.type = "step-start"

    def to_dict(self) -> dict[str, Any]:
        d = super().to_dict()
        d["snapshot"] = self.snapshot
        return d


@dataclass
class StepFinishPart(Part):
    """Step boundary marker - end of LLM turn."""

    reason: Literal["stop", "tool-calls", "length"] = "stop"
    snapshot: str = ""  # State snapshot ID
    tokens: dict[str, Any] = field(default_factory=dict)
    cost: float = 0.0

    def __post_init__(self) -> None:
        self.type = "step-finish"

    def to_dict(self) -> dict[str, Any]:
        d = super().to_dict()
        d["reason"] = self.reason
        d["snapshot"] = self.snapshot
        d["tokens"] = self.tokens
        d["cost"] = self.cost
        return d


@dataclass
class CompactionPart(Part):
    """Marker for compaction request."""

    auto: bool = False  # Was this auto-triggered?

    def __post_init__(self) -> None:
        self.type = "compaction"

    def to_dict(self) -> dict[str, Any]:
        d = super().to_dict()
        d["auto"] = self.auto
        return d


@dataclass
class PatchPart(Part):
    """Code change marker."""

    hash: str = ""  # Diff hash
    files: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.type = "patch"

    def to_dict(self) -> dict[str, Any]:
        d = super().to_dict()
        d["hash"] = self.hash
        d["files"] = self.files
        return d


@dataclass
class SubtaskPart(Part):
    """Subtask invocation marker."""

    prompt: str = ""
    description: str = ""
    agent: str = ""
    model: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.type = "subtask"

    def to_dict(self) -> dict[str, Any]:
        d = super().to_dict()
        d["prompt"] = self.prompt
        d["description"] = self.description
        d["agent"] = self.agent
        d["model"] = self.model
        return d


def part_from_dict(data: dict[str, Any]) -> Part:
    """Deserialize a part from its stored dict representation."""
    part_type = data.get("type", "")

    def _time(d: dict[str, Any] | None) -> TimeInfo | None:
        if not d:
            return None
        return TimeInfo(start=d["start"], end=d.get("end"), compacted=d.get("compacted"))

    time = _time(data.get("time"))
    metadata = data.get("metadata", {})

    if part_type == "text":
        p = TextPart(text=data.get("text", ""), ignored=data.get("ignored", False))
    elif part_type == "reasoning":
        p = ReasoningPart(text=data.get("text", ""))
    elif part_type == "tool":
        sd = data.get("state", {})
        state = ToolState(
            status=sd.get("status", "pending"),
            input=sd.get("input", {}),
            output=sd.get("output", ""),
            title=sd.get("title", ""),
            metadata=sd.get("metadata", {}),
            error=sd.get("error"),
            time=_time(sd.get("time")),
            attachments=sd.get("attachments", []),
        )
        p = ToolPart(tool=data.get("tool", ""), call_id=data.get("call_id", ""), state=state)
    elif part_type == "step-start":
        p = StepStartPart(snapshot=data.get("snapshot", ""))
    elif part_type == "step-finish":
        p = StepFinishPart(
            reason=data.get("reason", "stop"),
            snapshot=data.get("snapshot", ""),
            tokens=data.get("tokens", {}),
            cost=data.get("cost", 0.0),
        )
    elif part_type == "compaction":
        p = CompactionPart(auto=data.get("auto", False))
    elif part_type == "patch":
        p = PatchPart(hash=data.get("hash", ""), files=data.get("files", []))
    elif part_type == "subtask":
        p = SubtaskPart(
            prompt=data.get("prompt", ""),
            description=data.get("description", ""),
            agent=data.get("agent", ""),
            model=data.get("model", {}),
        )
    else:
        # Unknown type — create a generic part so we don't crash
        p = TextPart(text="")
    p.time = time
    p.metadata = metadata
    return p
