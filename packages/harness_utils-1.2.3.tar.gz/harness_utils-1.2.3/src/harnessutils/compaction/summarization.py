"""Tier 3: LLM-powered conversation summarization.

Uses LLM to semantically compress conversation when approaching limit.
Cost: Expensive (~$0.10-0.50), Latency: ~3-5s.
"""

from dataclasses import dataclass
from typing import Any

from harnessutils.models.message import Message
from harnessutils.models.usage import CacheUsage, Usage
from harnessutils.types import LLMClient

SUMMARIZATION_PROMPT = """You are a helpful AI assistant tasked with summarizing conversations.

When asked to summarize, provide a detailed but concise summary of the conversation.
Focus on information that would be helpful for continuing the conversation, including:
- What was done
- What is currently being worked on
- Which files are being modified
- What needs to be done next
- Key user requests, constraints, or preferences that should persist
- Important technical decisions and why they were made

Your summary should be comprehensive enough to provide context but concise enough
to be quickly understood."""

DIFFERENTIAL_SUMMARIZATION_PROMPT = """You are a helpful AI assistant tasked with \
updating conversation summaries.

You will be given:
1. A previous summary of the conversation
2. New messages/activity since that summary

Your task is to create an UPDATED summary that:
- Preserves important context from the previous summary
- Incorporates new information from recent messages
- Maintains continuity while staying concise
- Focuses on what's relevant for continuing the conversation

The updated summary should feel like a natural evolution of the previous one,
not a disconnected list of old + new information."""


@dataclass
class SummarizationResult:
    """Result of summarization operation."""

    summary_message: Message
    tokens_used: Usage
    cost: float


def _find_last_summary(messages: list[Message]) -> Message | None:
    """Find the last summary message in the conversation.

    Args:
        messages: List of messages to search

    Returns:
        Last summary message or None if no summary exists
    """
    for msg in reversed(messages):
        if msg.summary:
            return msg
    return None


def _get_messages_since_summary(
    messages: list[Message], summary_msg: Message
) -> list[Message]:
    """Get all messages after the given summary message.

    Args:
        messages: Full list of messages
        summary_msg: The summary message to find messages after

    Returns:
        List of messages after the summary
    """
    summary_idx = None
    for i, msg in enumerate(messages):
        if msg.id == summary_msg.id:
            summary_idx = i
            break

    if summary_idx is None:
        return messages

    return messages[summary_idx + 1 :]


def _build_differential_prompt(
    last_summary: str, new_messages: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Build prompt for differential summarization.

    Args:
        last_summary: Content of the previous summary
        new_messages: New messages since the last summary

    Returns:
        List of messages formatted for differential summarization
    """
    prompt_messages = [
        {
            "role": "user",
            "content": f"""Previous summary:
{last_summary}

New activity since summary:""",
        }
    ]

    # Add new messages
    prompt_messages.extend(new_messages)

    # Add request for updated summary
    prompt_messages.append(
        {
            "role": "user",
            "content": (
                "Provide an UPDATED summary that incorporates both the "
                "previous context and new activity."
            ),
        }
    )

    return prompt_messages


def is_overflow(usage: Usage, context_limit: int, output_limit: int) -> bool:
    """Check if conversation has overflowed context window.

    The context window must fit both input tokens and output tokens.
    We reserve space for output, so usable input space is smaller.

    Args:
        usage: Token usage from last turn
        context_limit: Maximum context tokens for model
        output_limit: Maximum output tokens for model

    Returns:
        True if input tokens exceed available space after reserving for output
    """
    total_input = usage.input + usage.cache.read
    usable_input_space = context_limit - output_limit

    return total_input > usable_input_space


def summarize_conversation(
    messages: list[Message],
    llm_client: LLMClient,
    parent_message_id: str,
    message_id: str,
    model: str | None = None,
    auto_mode: bool = False,
    config: Any | None = None,
    force_full: bool = False,
) -> SummarizationResult:
    """Summarize conversation using LLM.

    Args:
        messages: Conversation messages to summarize
        llm_client: LLM client implementation (callback from app)
        parent_message_id: ID of message that triggered summarization
        message_id: ID for the summary message
        model: Optional model to use (cheaper/faster recommended)
        auto_mode: Whether this was auto-triggered
        config: Optional SummarizationConfig for differential mode
        force_full: Force full summarization even if differential is available

    Returns:
        SummarizationResult with summary message and metrics
    """
    # Check if differential summarization is possible
    use_differential = False
    last_summary = None
    new_messages_only = messages

    include_tool_outputs = getattr(config, "include_tool_outputs", True)
    tool_output_max_tokens = getattr(config, "tool_output_max_tokens", 300)

    if config and not force_full:
        last_summary = _find_last_summary(messages)
        if last_summary:
            new_messages_only = _get_messages_since_summary(messages, last_summary)

            # Only use differential if we have new messages and haven't exceeded limit
            max_since_summary = getattr(config, "max_messages_since_summary", 30)
            if new_messages_only and len(new_messages_only) <= max_since_summary:
                use_differential = True

    # Choose model and prompt based on mode
    if use_differential and last_summary:
        # Differential mode: cheaper/faster model
        selected_model = model or getattr(config, "differential_model", None)
        system_prompt = (
            getattr(config, "differential_prompt", None) or DIFFERENTIAL_SUMMARIZATION_PROMPT
        )

        # Get last summary content
        summary_content = ""
        for part in last_summary.parts:
            if part.type == "text":
                summary_content = getattr(part, "text", "")
                break

        # Convert only new messages
        new_model_messages = _convert_to_model_format(
            new_messages_only,
            include_tool_outputs=include_tool_outputs,
            tool_output_max_tokens=tool_output_max_tokens,
        )

        # Build differential prompt
        model_messages = _build_differential_prompt(summary_content, new_model_messages)
    else:
        # Full mode: more capable model
        selected_model = model or getattr(config, "full_model", None)
        system_prompt = getattr(config, "summarization_prompt", None) or SUMMARIZATION_PROMPT

        # Convert all messages
        model_messages = _convert_to_model_format(
            messages,
            include_tool_outputs=include_tool_outputs,
            tool_output_max_tokens=tool_output_max_tokens,
        )
        model_messages.append(
            {
                "role": "user",
                "content": "Provide a detailed summary for continuing our conversation.",
            }
        )

    response = llm_client.invoke(
        messages=model_messages,
        system=[system_prompt],
        model=selected_model,
    )

    usage_data = response.get("usage", {})
    cache_data = usage_data.get("cache", {})

    usage = Usage(
        input=usage_data.get("input", 0),
        output=usage_data.get("output", 0),
        reasoning=usage_data.get("reasoning", 0),
        cache=CacheUsage(
            read=cache_data.get("read", 0),
            write=cache_data.get("write", 0),
        ),
    )

    cost = response.get("cost", 0.0)

    from harnessutils.models.parts import TextPart

    summary_message = Message(
        id=message_id,
        role="assistant",
        parent_id=parent_message_id,
        summary=True,
        agent="summarization",
        model={"model": response.get("model", model or "unknown")},
        tokens=usage,
        cost=cost,
    )

    summary_message.add_part(TextPart(text=response.get("content", "")))

    return SummarizationResult(
        summary_message=summary_message,
        tokens_used=usage,
        cost=cost,
    )


def _convert_to_model_format(
    messages: list[Message],
    include_tool_outputs: bool = True,
    tool_output_max_tokens: int = 300,
) -> list[dict[str, Any]]:
    """Convert internal messages to model format for summarization.

    Args:
        messages: Internal message objects
        include_tool_outputs: Whether to include tool outputs in context
        tool_output_max_tokens: Max tokens per tool output

    Returns:
        List of messages in model format
    """
    from harnessutils.tokens.exact import count_tokens_fast

    model_messages: list[dict[str, Any]] = []

    for msg in messages:
        if len(msg.parts) == 0:
            continue

        if msg.role == "user":
            content_parts = []
            for part in msg.parts:
                if part.type == "text" and not getattr(part, "ignored", False):
                    content_parts.append(getattr(part, "text", ""))

            if content_parts:
                model_messages.append(
                    {
                        "role": "user",
                        "content": "\n".join(content_parts),
                    }
                )

        elif msg.role == "assistant":
            if msg.error and not msg.has_partial_output():
                continue

            content_parts = []
            for part in msg.parts:
                if part.type == "text":
                    content_parts.append(getattr(part, "text", ""))
                elif part.type == "reasoning":
                    content_parts.append(f"[Thinking: {getattr(part, 'text', '')}]")
                elif include_tool_outputs and part.type == "tool":
                    state = getattr(part, "state", None)
                    if state:
                        output = state.output or "[cleared]"
                        if output != "[cleared]":
                            tokens = count_tokens_fast(output)
                            if tokens > tool_output_max_tokens:
                                output = output[:tool_output_max_tokens * 4] + "...(truncated)"
                        tool_name = getattr(state, "tool", None) or getattr(part, "tool", "unknown")
                        content_parts.append(f"[Tool: {tool_name}] {output}")

            if content_parts:
                model_messages.append(
                    {
                        "role": "assistant",
                        "content": "\n".join(content_parts),
                    }
                )

    return model_messages
