"""Ollama client for evals."""

import time
from typing import Any

import requests


class OllamaClient:
    """Ollama LLM client for evaluations."""

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "qwen2.5:7b",
        timeout: int = 300,
        max_retries: int = 3,
    ):
        """Initialize Ollama client.

        Args:
            base_url: Ollama server URL (default: http://localhost:11434)
            model: Model to use (default: qwen2.5:7b)
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
        """
        self.base_url = base_url
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries

    def invoke(
        self,
        messages: list[dict[str, Any]],
        system: list[str] | None = None,
        model: str | None = None,
    ) -> dict[str, Any]:
        """Invoke Ollama with messages.

        Args:
            messages: Messages in format [{"role": "user", "content": "..."}]
            system: Optional system prompt parts
            model: Optional model override

        Returns:
            Response with content and usage
        """
        use_model = model or self.model

        # Build request
        ollama_messages = []

        if system:
            ollama_messages.append({"role": "system", "content": "\n".join(system)})

        ollama_messages.extend(messages)

        payload = {
            "model": use_model,
            "messages": ollama_messages,
            "stream": False,
        }

        # Retry logic
        for attempt in range(self.max_retries):
            try:
                response = requests.post(
                    f"{self.base_url}/api/chat",
                    json=payload,
                    timeout=self.timeout,
                )
                response.raise_for_status()
                data = response.json()

                # Extract content
                content = data.get("message", {}).get("content", "")

                # Extract usage if available
                usage_data = {
                    "input": data.get("prompt_eval_count", 0),
                    "output": data.get("eval_count", 0),
                    "cache": {"read": 0, "write": 0},
                    "reasoning": 0,
                }

                return {
                    "content": content,
                    "usage": usage_data,
                    "model": use_model,
                }

            except requests.exceptions.Timeout:
                if attempt < self.max_retries - 1:
                    wait = 2**attempt
                    print(f"Timeout, retrying in {wait}s...")
                    time.sleep(wait)
                else:
                    raise

            except requests.exceptions.RequestException as e:
                if attempt < self.max_retries - 1:
                    wait = 2**attempt
                    print(f"Request failed: {e}, retrying in {wait}s...")
                    time.sleep(wait)
                else:
                    raise

        raise RuntimeError("Max retries exceeded")
