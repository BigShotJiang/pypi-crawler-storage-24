"""OpenAI-compatible client for evals (works with vllm, OpenAI, etc.)."""

import time
from typing import Any

import requests


class OpenAIClient:
    """OpenAI-compatible LLM client for evaluations.

    Works with any server that exposes the OpenAI chat completions API,
    including vllm, LM Studio, and OpenAI itself.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        model: str = "default",
        api_key: str = "none",
        timeout: int = 300,
        max_retries: int = 3,
        no_thinking: bool = False,
    ):
        """Initialize OpenAI-compatible client.

        Args:
            base_url: Server base URL (e.g. http://localhost:8000 for vllm)
            model: Model name to request
            api_key: API key (use "none" for local servers that don't require one)
            timeout: Request timeout in seconds
            max_retries: Max retry attempts
            no_thinking: Prepend /no_think to system prompt (disables Qwen3 reasoning mode)
        """
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries
        self.no_thinking = no_thinking

    def invoke(
        self,
        messages: list[dict[str, Any]],
        system: list[str] | None = None,
        model: str | None = None,
    ) -> dict[str, Any]:
        """Invoke the model with messages.

        Args:
            messages: Messages in format [{"role": "user", "content": "..."}]
            system: Optional system prompt parts
            model: Optional model override

        Returns:
            Response with content and usage
        """
        use_model = model or self.model

        payload_messages: list[dict[str, Any]] = []

        if system or self.no_thinking:
            parts = []
            if self.no_thinking:
                parts.append("/no_think")
            if system:
                parts.extend(system)
            payload_messages.append({"role": "system", "content": "\n".join(parts)})

        payload_messages.extend(messages)

        payload = {
            "model": use_model,
            "messages": payload_messages,
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        for attempt in range(self.max_retries):
            try:
                response = requests.post(
                    f"{self.base_url}/v1/chat/completions",
                    json=payload,
                    headers=headers,
                    timeout=self.timeout,
                )
                response.raise_for_status()
                data = response.json()

                content = data["choices"][0]["message"]["content"]

                usage_raw = data.get("usage", {})
                usage_data = {
                    "input": usage_raw.get("prompt_tokens", 0),
                    "output": usage_raw.get("completion_tokens", 0),
                    "cache": {"read": 0, "write": 0},
                    "reasoning": 0,
                }

                return {
                    "content": content,
                    "usage": usage_data,
                    "model": use_model,
                }

            except requests.exceptions.Timeout:
                if attempt < self.max_retries - 1:
                    wait = 2**attempt
                    print(f"Timeout, retrying in {wait}s...")
                    time.sleep(wait)
                else:
                    raise

            except requests.exceptions.RequestException as e:
                if attempt < self.max_retries - 1:
                    wait = 2**attempt
                    print(f"Request failed: {e}, retrying in {wait}s...")
                    time.sleep(wait)
                else:
                    raise

        raise RuntimeError("Max retries exceeded")
