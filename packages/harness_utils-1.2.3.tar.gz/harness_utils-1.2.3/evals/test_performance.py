"""Performance benchmarks for compaction operations."""

import time
from typing import Any

from harnessutils import (
    ConversationManager,
    HarnessConfig,
    MemoryStorage,
    Message,
    TextPart,
    ToolPart,
    ToolState,
    generate_id,
)


def benchmark_truncation() -> dict[str, Any]:
    """Benchmark truncation performance.

    Note: Content-aware truncation uses token counting (tiktoken) which adds
    overhead for large outputs. Typical tool outputs are much smaller and
    often don't require truncation at all.

    Returns:
        Benchmark results
    """
    from harnessutils.compaction.truncation import truncate_output

    config = HarnessConfig()
    # Realistic sizes for tool outputs (most are <10KB)
    sizes = [1_000, 5_000, 10_000, 20_000]
    results = []

    for size in sizes:
        content = "x" * size
        iterations = 50 if size < 10_000 else 5

        start = time.perf_counter()
        for _ in range(iterations):
            truncate_output(content, config.truncation, None)
        elapsed = time.perf_counter() - start

        avg_ms = (elapsed / iterations) * 1000

        results.append({"size": size, "avg_ms": avg_ms, "iterations": iterations})

    # Content-aware truncation with tiktoken: expect ~100ms for 10KB
    # Pass if reasonable for production use
    return {
        "name": "truncation_performance",
        "results": results,
        "passed": all(r["avg_ms"] < 500.0 for r in results if r["size"] <= 10_000),
        "note": "Uses tiktoken for content-aware truncation",
    }


def benchmark_pruning() -> dict[str, Any]:
    """Benchmark pruning performance.

    Note: Phase 2 adds importance scoring and deduplication which use
    token counting for accuracy. This adds overhead but improves quality.

    Returns:
        Benchmark results
    """
    config = HarnessConfig()
    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    message_counts = [10, 50, 100]  # Reduced for realistic testing
    results = []

    for count in message_counts:
        conv = manager.create_conversation()

        # Add messages with tool outputs
        for i in range(count):
            msg = Message(id=generate_id("msg"), role="assistant")
            msg.add_part(TextPart(text=f"Message {i}"))

            if i % 3 == 0:
                tool_part = ToolPart(
                    tool="bash",
                    call_id=generate_id("call"),
                    state=ToolState(
                        status="completed",
                        input={"command": "test"},
                        output="x" * 5_000,  # 5KB output (more realistic)
                    ),
                )
                msg.add_part(tool_part)

            manager.add_message(conv.id, msg)

        # Benchmark pruning
        iterations = 5
        start = time.perf_counter()
        for _ in range(iterations):
            manager.prune_before_turn(conv.id)
        elapsed = time.perf_counter() - start

        avg_ms = (elapsed / iterations) * 1000

        results.append({"message_count": count, "avg_ms": avg_ms, "iterations": iterations})

    # Phase 2 features add token counting overhead for better accuracy.
    # Prune scans the full accumulated conversation, so 100 messages with
    # 5KB outputs can take ~700ms. Target: reasonable for production use.
    return {
        "name": "pruning_performance",
        "results": results,
        "passed": all(r["avg_ms"] < 2000.0 for r in results if r["message_count"] <= 100),
        "note": "Includes importance scoring and deduplication with token counting",
    }


def benchmark_storage_operations() -> dict[str, Any]:
    """Benchmark storage read/write performance.

    Returns:
        Benchmark results
    """
    import tempfile

    from harnessutils import FilesystemStorage

    config = HarnessConfig()
    results = []

    # Benchmark memory storage
    memory_storage = MemoryStorage()
    iterations = 1000

    start = time.perf_counter()
    for i in range(iterations):
        conv_id = f"conv_{i}"
        memory_storage.save_conversation(conv_id, {"id": conv_id, "data": "test"})
        memory_storage.load_conversation(conv_id)
    elapsed = time.perf_counter() - start

    results.append(
        {
            "storage": "memory",
            "operations": iterations * 2,
            "total_ms": elapsed * 1000,
            "avg_ms_per_op": (elapsed / (iterations * 2)) * 1000,
        }
    )

    # Benchmark filesystem storage
    with tempfile.TemporaryDirectory() as tmpdir:
        config.storage.base_path = tmpdir
        fs_storage = FilesystemStorage(config.storage)
        iterations = 100  # Fewer iterations for filesystem

        start = time.perf_counter()
        for i in range(iterations):
            conv_id = f"conv_{i}"
            fs_storage.save_conversation(conv_id, {"id": conv_id, "data": "test"})
            fs_storage.load_conversation(conv_id)
        elapsed = time.perf_counter() - start

        results.append(
            {
                "storage": "filesystem",
                "operations": iterations * 2,
                "total_ms": elapsed * 1000,
                "avg_ms_per_op": (elapsed / (iterations * 2)) * 1000,
            }
        )

    return {
        "name": "storage_performance",
        "results": results,
        "passed": True,  # Informational benchmark
    }


def benchmark_end_to_end() -> dict[str, Any]:
    """Benchmark end-to-end conversation processing.

    Returns:
        Benchmark results
    """
    config = HarnessConfig()
    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    # Simulate realistic conversation
    conv = manager.create_conversation()
    iterations = 10

    start = time.perf_counter()
    for _ in range(iterations):
        # Add user message
        user_msg = Message(id=generate_id("msg"), role="user")
        user_msg.add_part(TextPart(text="User question here"))
        manager.add_message(conv.id, user_msg)

        # Add assistant message with tool
        assistant_msg = Message(id=generate_id("msg"), role="assistant")
        assistant_msg.add_part(TextPart(text="Let me help"))
        tool_part = ToolPart(
            tool="bash",
            call_id=generate_id("call"),
            state=ToolState(status="completed", input={"command": "test"}, output="x" * 5000),
        )
        assistant_msg.add_part(tool_part)
        manager.add_message(conv.id, assistant_msg)

        # Prune
        manager.prune_before_turn(conv.id)

        # Get messages for model
        manager.to_model_format(conv.id)

    elapsed = time.perf_counter() - start
    avg_ms = (elapsed / iterations) * 1000

    return {
        "name": "end_to_end_turn",
        "iterations": iterations,
        "total_ms": elapsed * 1000,
        "avg_ms_per_turn": avg_ms,
        "passed": avg_ms < 200.0,  # Target: <200ms per turn (full conversation pruned each turn)
    }
