"""Evals for cross-cutting features: memory persistence, workspace identity."""

import tempfile
from pathlib import Path
from typing import Any

from harnessutils import ConversationManager, HarnessConfig
from harnessutils.config import StorageConfig
from harnessutils.storage.filesystem import FilesystemStorage


def eval_memory_persistence() -> dict[str, Any]:
    """Eval: Project memory survives across ConversationManager instances.

    Writes keys with one manager instance backed by FilesystemStorage,
    then reads them back with a fresh instance pointing at the same path.
    Also verifies that deletes and overwrites are durable.

    Returns:
        Eval results with metrics
    """
    test_cases = []

    with tempfile.TemporaryDirectory() as tmpdir:
        base = Path(tmpdir)

        def make_manager() -> ConversationManager:
            storage = FilesystemStorage(StorageConfig(base_path=base))
            return ConversationManager(storage)

        project_id = "eval-project-alpha"

        # --- Write keys with manager1 ---
        m1 = make_manager()
        m1.set_memory(project_id, "user_name", "Alice")
        m1.set_memory(project_id, "preferred_language", "Python")
        m1.set_memory(project_id, "to_delete", "ephemeral")

        # --- Read back with a completely new manager instance ---
        m2 = make_manager()
        name = m2.get_memory(project_id, "user_name")
        lang = m2.get_memory(project_id, "preferred_language")

        test_cases.append({
            "name": "keys_survive_new_instance",
            "user_name": name,
            "preferred_language": lang,
            "passed": name == "Alice" and lang == "Python",
        })

        # --- Delete a key and verify it's gone in a third instance ---
        m2.delete_memory(project_id, "to_delete")
        m3 = make_manager()
        deleted_value = m3.get_memory(project_id, "to_delete", default="MISSING")

        test_cases.append({
            "name": "delete_is_durable",
            "value_after_delete": deleted_value,
            "passed": deleted_value == "MISSING",
        })

        # --- Overwrite a key and verify new value persists ---
        m3.set_memory(project_id, "user_name", "Bob")
        m4 = make_manager()
        updated_name = m4.get_memory(project_id, "user_name")

        test_cases.append({
            "name": "overwrite_is_durable",
            "updated_name": updated_name,
            "passed": updated_name == "Bob",
        })

        # --- Two projects don't share memory ---
        m4.set_memory("project-one", "key", "value_one")
        m4.set_memory("project-two", "key", "value_two")
        m5 = make_manager()

        val_one = m5.get_memory("project-one", "key")
        val_two = m5.get_memory("project-two", "key")

        test_cases.append({
            "name": "projects_are_isolated",
            "project_one_value": val_one,
            "project_two_value": val_two,
            "passed": val_one == "value_one" and val_two == "value_two",
        })

    all_passed = all(tc["passed"] for tc in test_cases)

    return {
        "name": "memory_persistence",
        "test_cases": test_cases,
        "passed": all_passed,
    }
