"""Evals for conversation quality after compaction."""

import json
import re
from pathlib import Path
from typing import Any

from harnessutils import (
    ConversationManager,
    HarnessConfig,
    MemoryStorage,
    Message,
    TextPart,
    ToolPart,
    ToolState,
    generate_id,
)
from harnessutils.types import LLMClient


def load_golden_conversations() -> list[dict[str, Any]]:
    """Load golden conversation dataset."""
    dataset_path = Path(__file__).parent / "datasets" / "golden_conversations.json"
    with open(dataset_path) as f:
        return json.load(f)


def conversation_to_text(messages: list[dict[str, Any]]) -> str:
    """Convert conversation to readable text format."""
    lines = []
    for msg in messages:
        role = msg["role"]
        text = msg.get("text", "")
        lines.append(f"{role.upper()}: {text}")

        if "tool_calls" in msg:
            for tool_call in msg["tool_calls"]:
                tool = tool_call["tool"]
                output = tool_call.get("output", "")
                lines.append(f"[Tool: {tool}]\n{output}")

    return "\n\n".join(lines)


def build_conversation_from_dataset(manager: ConversationManager, conv_data: dict[str, Any]) -> str:
    """Build a conversation from dataset format.

    Args:
        manager: ConversationManager instance
        conv_data: Conversation data from dataset

    Returns:
        Conversation ID
    """
    conv = manager.create_conversation()

    for msg_data in conv_data["messages"]:
        msg = Message(id=generate_id("msg"), role=msg_data["role"])

        if "text" in msg_data:
            msg.add_part(TextPart(text=msg_data["text"]))

        if "tool_calls" in msg_data:
            for tool_call in msg_data["tool_calls"]:
                tool_part = ToolPart(
                    tool=tool_call["tool"],
                    call_id=generate_id("call"),
                    state=ToolState(
                        status="completed",
                        input=tool_call.get("input", {}),
                        output=tool_call.get("output", ""),
                    ),
                )
                msg.add_part(tool_part)

        manager.add_message(conv.id, msg)

    return conv.id


def eval_information_preservation(llm: LLMClient | None = None) -> dict[str, Any]:
    """Eval: Information preservation after compaction.

    Tests if key information is retained after aggressive compaction.

    Returns:
        Eval results with metrics
    """
    if llm is None:
        return {
            "name": "information_preservation",
            "skipped": True,
            "reason": "No LLM client provided",
        }

    from evals.judge import judge_answer_correctness

    golden = load_golden_conversations()
    results = []

    for conv_idx, conv_data in enumerate(golden):
        conv_label = conv_data.get("id", f"conv-{conv_idx}")
        print(f"    [{conv_idx + 1}/{len(golden)}] {conv_label}: compacting...", flush=True)

        config = HarnessConfig()
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        # Build conversation
        conv_id = build_conversation_from_dataset(manager, conv_data)

        # Compact the full conversation with LLM summarization first,
        # then prune so only the summary remains
        manager.compact(conv_id, llm, generate_id("msg"))
        manager.prune_before_turn(conv_id)

        # Get compacted messages
        messages = manager.get_messages(conv_id)
        compacted_text = "\n".join(
            f"{m.role}: {m.parts[0].text if m.parts else ''}" for m in messages
        )

        # Test questions
        original_text = conversation_to_text(conv_data["messages"])
        scores = []

        questions = conv_data.get("test_questions", [])
        for q_idx, question in enumerate(questions):
            print(f"      question {q_idx + 1}/{len(questions)}...", flush=True)
            # Ask question about compacted conversation
            answer_msg = {"role": "user", "content": f"{compacted_text}\n\nQ: {question}"}
            answer_result = llm.invoke([answer_msg])
            answer = answer_result["content"]

            # Judge correctness
            judgment = judge_answer_correctness(llm, original_text, question, answer)
            scores.append(judgment["score"])

        avg_score = sum(scores) / len(scores) if scores else 0

        results.append(
            {
                "conversation_id": conv_data["id"],
                "avg_score": avg_score,
                "scores": scores,
                "num_questions": len(scores),
            }
        )

    overall_avg = sum(r["avg_score"] for r in results) / len(results) if results else 0

    return {
        "name": "information_preservation",
        "overall_score": overall_avg,
        "results": results,
        "num_conversations": len(results),
        "passed": overall_avg >= 7.0,  # Threshold: 7/10
    }


def eval_compaction_ratio() -> dict[str, Any]:
    """Eval: Measure compaction effectiveness.

    Tests how much context is reduced while preserving quality.

    Returns:
        Eval results with metrics
    """
    golden = load_golden_conversations()
    results = []

    for conv_data in golden:
        config = HarnessConfig()
        storage = MemoryStorage()
        manager = ConversationManager(storage, config)

        # Build conversation
        conv_id = build_conversation_from_dataset(manager, conv_data)

        # Measure before compaction
        messages_before = manager.get_messages(conv_id)
        from harnessutils.tokens.estimator import estimate_tokens

        tokens_before = sum(
            estimate_tokens(p.text if hasattr(p, "text") else str(p))
            for m in messages_before
            for p in m.parts
        )

        # Compact
        prune_result = manager.prune_before_turn(conv_id)

        # Measure after
        messages_after = manager.get_messages(conv_id)
        tokens_after = sum(
            estimate_tokens(str(getattr(p, "text", ""))) for m in messages_after for p in m.parts
        )

        ratio = tokens_after / tokens_before if tokens_before > 0 else 1.0

        results.append(
            {
                "conversation_id": conv_data["id"],
                "tokens_before": tokens_before,
                "tokens_after": tokens_after,
                "tokens_saved": prune_result["tokens_saved"],
                "compaction_ratio": ratio,
            }
        )

    avg_ratio = sum(r["compaction_ratio"] for r in results) / len(results) if results else 1.0

    return {
        "name": "compaction_ratio",
        "avg_compaction_ratio": avg_ratio,
        "results": results,
        "num_conversations": len(results),
        "passed": avg_ratio < 0.8,  # Target: <80% of original
    }


def eval_quality_metrics_accuracy() -> dict[str, Any]:
    """Eval: Quality metric scores reflect actual conversation health.

    Builds conversations with known characteristics and verifies that
    get_context_quality() returns scores in the expected ranges:
    - High-redundancy conversation → high redundancy_ratio, low information_density
    - High-diversity conversation → low redundancy_ratio, high information_density
    - Fresh conversation → low staleness_score

    Returns:
        Eval results with metrics
    """
    test_cases = []

    # --- Case 1: high redundancy (same tool output repeated 5 times) ---
    config = HarnessConfig()
    storage = MemoryStorage()
    manager = ConversationManager(storage, config)
    conv = manager.create_conversation()

    repeated_output = "SELECT * FROM users WHERE id = 1;\n" + ("row data\n" * 20)
    for i in range(5):
        msg = Message(id=generate_id("msg"), role="assistant")
        tool_part = ToolPart(
            tool="bash",
            call_id=generate_id("call"),
            state=ToolState(status="completed", input={}, output=repeated_output),
        )
        msg.add_part(tool_part)
        manager.add_message(conv.id, msg)

    quality = manager.get_context_quality(conv.id)

    test_cases.append({
        "name": "high_redundancy_conversation",
        "redundancy_ratio": quality["redundancy_ratio"],
        "information_density": quality["information_density"],
        "expected": "redundancy > 0.6, density < 0.5",
        "passed": quality["redundancy_ratio"] > 0.6 and quality["information_density"] < 0.5,
    })

    # --- Case 2: high diversity (5 completely different tool outputs) ---
    storage2 = MemoryStorage()
    manager2 = ConversationManager(storage2, config)
    conv2 = manager2.create_conversation()

    for i in range(5):
        msg = Message(id=generate_id("msg"), role="assistant")
        tool_part = ToolPart(
            tool="read",
            call_id=generate_id("call"),
            state=ToolState(
                status="completed",
                input={},
                output=f"File {i} contents:\n" + f"unique content block {i} " * 30,
            ),
        )
        msg.add_part(tool_part)
        manager2.add_message(conv2.id, msg)

    quality2 = manager2.get_context_quality(conv2.id)

    test_cases.append({
        "name": "high_diversity_conversation",
        "redundancy_ratio": quality2["redundancy_ratio"],
        "information_density": quality2["information_density"],
        "expected": "redundancy < 0.1, density > 0.8",
        "passed": quality2["redundancy_ratio"] < 0.1 and quality2["information_density"] > 0.8,
    })

    # --- Case 3: fresh conversation → low staleness ---
    storage3 = MemoryStorage()
    manager3 = ConversationManager(storage3, config)
    conv3 = manager3.create_conversation()

    for i in range(2):
        msg = Message(id=generate_id("msg"), role="user" if i == 0 else "assistant")
        msg.add_part(TextPart(text=f"Turn {i}"))
        manager3.add_message(conv3.id, msg)

    quality3 = manager3.get_context_quality(conv3.id)

    test_cases.append({
        "name": "fresh_conversation_low_staleness",
        "staleness_score": quality3["staleness_score"],
        "expected": "staleness < 0.2",
        "passed": quality3["staleness_score"] < 0.2,
    })

    all_passed = all(tc["passed"] for tc in test_cases)

    return {
        "name": "quality_metrics_accuracy",
        "test_cases": test_cases,
        "passed": all_passed,
    }


def eval_content_aware_truncation_correctness() -> dict[str, Any]:
    """Eval: Content-aware truncation preserves structure and critical content.

    Tests three content types:
    - JSON arrays: first and last items preserved, truncation marker present
    - Stacktraces: error message line preserved after truncation
    - Logs: all ERROR lines preserved after truncation

    Returns:
        Eval results with metrics
    """
    from harnessutils.compaction.truncation import truncate_output

    test_cases = []

    # --- JSON: large array should be truncated but keep head+tail items ---
    config = HarnessConfig()
    config.truncation.max_tokens = 80     # Force truncation
    config.truncation.json_array_limit = 6  # Keep 3 head + 3 tail

    items = [{"id": i, "value": f"item_value_{i:04d}"} for i in range(30)]
    big_json = json.dumps(items)

    result = truncate_output(big_json, config.truncation)

    first_item_present = '"id": 0' in result.content
    last_item_present = '"id": 29' in result.content
    marker_present = "truncated" in result.content.lower()

    test_cases.append({
        "name": "json_head_tail_preserved",
        "first_item_present": first_item_present,
        "last_item_present": last_item_present,
        "marker_present": marker_present,
        "passed": first_item_present and last_item_present and marker_present,
    })

    # --- Stacktrace: error message must survive truncation ---
    config2 = HarnessConfig()
    config2.truncation.max_tokens = 60
    config2.truncation.stacktrace_frame_limit = 4

    stacktrace = "Traceback (most recent call last):\n"
    for i in range(30):
        stacktrace += f'  File "module_{i}.py", line {i + 1}, in func_{i}\n'
        stacktrace += f'    result_{i} = call_{i}()\n'
    stacktrace += "ValueError: specific_sentinel_error_XYZ\n"

    result2 = truncate_output(stacktrace, config2.truncation)

    error_preserved = "specific_sentinel_error_XYZ" in result2.content

    test_cases.append({
        "name": "stacktrace_error_line_preserved",
        "error_preserved": error_preserved,
        "passed": error_preserved,
    })

    # --- Logs: all ERROR lines must survive even when info lines are dropped ---
    config3 = HarnessConfig()
    config3.truncation.max_tokens = 100
    config3.truncation.preserve_errors = True

    error_sentinels = ["ERROR_ALPHA_001", "ERROR_BETA_002", "ERROR_GAMMA_003"]
    log_lines = []
    for i in range(100):
        if i in (10, 50, 90):
            sentinel = error_sentinels[(i // 10) % 3]
            log_lines.append(f"2026-03-12T10:{i:02d}:00 [ERROR] {sentinel}: operation failed")
        else:
            log_lines.append(f"2026-03-12T10:{i:02d}:00 [INFO] processing item {i}")
    logs = "\n".join(log_lines)

    result3 = truncate_output(logs, config3.truncation)

    errors_preserved = all(s in result3.content for s in error_sentinels)

    test_cases.append({
        "name": "log_error_lines_preserved",
        "errors_preserved": errors_preserved,
        "sentinels_found": [s for s in error_sentinels if s in result3.content],
        "passed": errors_preserved,
    })

    all_passed = all(tc["passed"] for tc in test_cases)

    return {
        "name": "content_aware_truncation_correctness",
        "test_cases": test_cases,
        "passed": all_passed,
    }
