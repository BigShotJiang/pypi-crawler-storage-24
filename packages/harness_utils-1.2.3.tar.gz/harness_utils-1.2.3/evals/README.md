# Harness-Utils Evals

Evaluation framework for testing harness-utils behavior beyond unit tests.

## Overview

Evals test real-world behavior that unit tests can't capture:
- **Quality**: Does compaction preserve information?
- **Budget**: Do we stay within token limits?
- **Performance**: Are operations fast enough?

## Running Evals

```bash
# Run all evals (without LLM-based evals)
uv run python -m evals.runner

# Run with LLM-based quality evals (uses Ollama)
uv run python -m evals.runner --with-llm

# Use custom Ollama server and model
uv run python -m evals.runner --with-llm \
  --ollama-url http://10.6.12.18:11434 \
  --ollama-model qwen2.5-coder:32b

# Save results to JSON
uv run python -m evals.runner --output results.json
```

### Configuration

**Ollama Settings:**
- `--ollama-url`: Ollama server URL (default: `http://localhost:11434`)
- `--ollama-model`: Model to use (default: `qwen2.5:7b`)

**Environment Variables:**
```bash
export OLLAMA_URL=http://your-server:11434
export OLLAMA_MODEL=deepseek-r1:7b
uv run python -m evals.runner --with-llm
```

## Eval Categories

### Quality Evals

**information_preservation**
- Tests if key facts are retained after compaction
- Uses LLM-as-judge to evaluate answer correctness
- Requires: LLM client
- Pass criteria: Score ≥ 7/10

**compaction_ratio**
- Measures how much context is reduced
- No LLM required
- Pass criteria: <80% of original size

### Budget Evals

**stays_within_limits**
- Ensures context never exceeds configured limits
- Tests growing conversations and bursts
- Pass criteria: No limit violations

**overflow_detection**
- Validates overflow detection logic
- Tests edge cases around limits
- Pass criteria: Correct detection

### Performance Benchmarks

**truncation_performance**
- Measures truncation speed across sizes
- Pass criteria: <1ms for ≤100KB content

**pruning_performance**
- Measures pruning speed for varying message counts
- Pass criteria: <100ms for typical conversations

**storage_performance**
- Compares memory vs filesystem storage
- Informational only

**end_to_end_turn**
- Measures full turn processing
- Pass criteria: <50ms per turn

## Golden Datasets

Located in `evals/datasets/`:

- `golden_conversations.json` - Curated conversations with:
  - Representative message patterns
  - Key facts to test preservation
  - Test questions for evaluation

## Adding New Evals

1. Create eval function in appropriate test file:
```python
def eval_my_feature() -> dict[str, Any]:
    """Eval: Description of what this tests."""
    # Run tests
    # Collect metrics
    return {
        "name": "my_feature",
        "passed": True,
        "metrics": {...}
    }
```

2. Add to runner in `runner.py`:
```python
from evals.test_quality import eval_my_feature

result = eval_my_feature()
results.append(result)
print_eval_result(result)
```

3. Add golden data if needed to `datasets/`

## Metrics Tracked

- **Quality scores**: 0-10 scale from LLM-as-judge
- **Compaction ratio**: tokens_after / tokens_before
- **Latency**: p50/p95/p99 in milliseconds
- **Token savings**: tokens pruned/summarized
- **Success rate**: % of evals passing

## CI Integration

Add to GitHub Actions:
```yaml
- name: Run evals
  run: uv run python -m evals.runner --output evals-results.json

- name: Upload results
  uses: actions/upload-artifact@v3
  with:
    name: eval-results
    path: evals-results.json
```

## Future Improvements

- [ ] Track metrics over time (regression detection)
- [ ] More golden datasets (edge cases, failure modes)
- [ ] Integration with real LLM APIs (Ollama, Claude)
- [ ] Visualization dashboard for results
- [ ] Automated pass/fail thresholds per eval
