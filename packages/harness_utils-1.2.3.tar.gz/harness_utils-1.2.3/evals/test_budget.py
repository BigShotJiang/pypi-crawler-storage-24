"""Evals for token budget compliance."""

from typing import Any

from harnessutils import (
    ConversationManager,
    HarnessConfig,
    MemoryStorage,
    Message,
    TextPart,
    Usage,
    generate_id,
)
from harnessutils.tokens.estimator import estimate_tokens


def eval_stays_within_limits() -> dict[str, Any]:
    """Eval: Context never exceeds configured limits.

    Tests that compaction keeps conversations within token budgets.

    Returns:
        Eval results with metrics
    """
    config = HarnessConfig()
    config.model_limits.default_context_limit = 100_000  # 100K context limit
    config.model_limits.default_output_limit = 8_000  # 8K output limit

    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    test_cases = []

    # Test case 1: Gradually growing conversation
    conv = manager.create_conversation()
    violations = 0
    max_tokens = 0

    for i in range(100):
        # Add message
        msg = Message(id=generate_id("msg"), role="user" if i % 2 == 0 else "assistant")
        msg.add_part(TextPart(text="x" * 1000))  # 1000 chars = ~250 tokens
        manager.add_message(conv.id, msg)

        # Prune periodically
        if i % 10 == 0:
            manager.prune_before_turn(conv.id)

        # Check token count
        messages = manager.get_messages(conv.id)
        total_tokens = sum(
            estimate_tokens(getattr(p, "text", "")) for m in messages for p in m.parts
        )

        max_tokens = max(max_tokens, total_tokens)

        # Check if exceeded limit
        if total_tokens > config.model_limits.default_context_limit:
            violations += 1

    test_cases.append(
        {
            "name": "growing_conversation",
            "max_tokens": max_tokens,
            "violations": violations,
            "limit": config.model_limits.default_context_limit,
            "passed": violations == 0,
        }
    )

    # Test case 2: Burst of large messages
    conv2 = manager.create_conversation()
    for i in range(10):
        msg = Message(id=generate_id("msg"), role="user")
        msg.add_part(TextPart(text="x" * 10000))  # 10K chars each
        manager.add_message(conv2.id, msg)

    manager.prune_before_turn(conv2.id)
    messages2 = manager.get_messages(conv2.id)
    total_tokens2 = sum(estimate_tokens(getattr(p, "text", "")) for m in messages2 for p in m.parts)

    test_cases.append(
        {
            "name": "burst_large_messages",
            "total_tokens": total_tokens2,
            "limit": config.model_limits.default_context_limit,
            "passed": total_tokens2 <= config.model_limits.default_context_limit,
        }
    )

    all_passed = all(tc["passed"] for tc in test_cases)

    return {
        "name": "stays_within_limits",
        "test_cases": test_cases,
        "passed": all_passed,
    }


def eval_predictive_overflow() -> dict[str, Any]:
    """Eval: Predictive overflow fires before reactive overflow.

    Builds real conversation velocity then verifies predict_overflow()
    triggers at 80% of limit while is_overflow() is still False.

    Returns:
        Eval results with metrics
    """
    from harnessutils.compaction.summarization import is_overflow

    config = HarnessConfig()
    config.model_limits.default_context_limit = 100_000
    config.model_limits.default_output_limit = 8_000
    # usable = 92_000, safety threshold = 92_000 * 0.8 = 73_600

    storage = MemoryStorage()
    manager = ConversationManager(storage, config)
    conv = manager.create_conversation()

    # Build stable velocity: 12 messages each adding 2_000 tokens
    # predict_tokens_ahead(5) ≈ 5 * 2_000 = 10_000
    tokens_per_turn = 2_000
    for i in range(12):
        msg = Message(id=generate_id("msg"), role="user" if i % 2 == 0 else "assistant")
        msg.add_part(TextPart(text="x" * (tokens_per_turn * 4)))  # ~2000 tokens
        msg.tokens = Usage(input=tokens_per_turn)
        manager.add_message(conv.id, msg)

    # Usage just below reactive threshold but above predictive threshold
    # 65_000 + 10_000 projected = 75_000 > 73_600 → should predict
    # 65_000 < 92_000 → should NOT be reactive overflow
    usage_near_limit = Usage(input=65_000, output=1_000, reasoning=0)

    predictive_fires = manager.predict_overflow(conv.id, usage_near_limit)
    reactive_fires = is_overflow(
        usage_near_limit,
        config.model_limits.default_context_limit,
        config.model_limits.default_output_limit,
    )

    # Verify reactive overflow triggers correctly when actually over limit
    usage_over_limit = Usage(input=93_000, output=1_000, reasoning=0)
    reactive_over = is_overflow(
        usage_over_limit,
        config.model_limits.default_context_limit,
        config.model_limits.default_output_limit,
    )

    test_cases = [
        {
            "name": "predictive_fires_before_reactive",
            "predictive_fires": predictive_fires,
            "reactive_fires": reactive_fires,
            "passed": predictive_fires and not reactive_fires,
        },
        {
            "name": "reactive_fires_when_over_limit",
            "reactive_fires": reactive_over,
            "passed": reactive_over,
        },
    ]

    all_passed = all(tc["passed"] for tc in test_cases)

    return {
        "name": "predictive_overflow",
        "test_cases": test_cases,
        "tokens_per_turn": tokens_per_turn,
        "passed": all_passed,
    }


def eval_overflow_detection() -> dict[str, Any]:
    """Eval: Overflow detection works correctly.

    Tests that is_overflow correctly identifies when limits are exceeded.

    Returns:
        Eval results with metrics
    """
    config = HarnessConfig()
    config.model_limits.default_context_limit = 100_000
    config.model_limits.default_output_limit = 8_000

    storage = MemoryStorage()
    manager = ConversationManager(storage, config)

    test_cases = []

    # Should NOT overflow
    usage_ok = Usage(input=50_000, output=4_000, reasoning=0)
    conv1 = manager.create_conversation()
    is_overflow_ok = manager.needs_compaction(conv1.id, usage_ok)

    test_cases.append(
        {
            "name": "normal_usage",
            "usage": {"input": 50_000, "output": 4_000},
            "overflow_detected": is_overflow_ok,
            "passed": not is_overflow_ok,
        }
    )

    # Should overflow - input too high
    usage_input_high = Usage(input=195_000, output=4_000, reasoning=0)
    is_overflow_input = manager.needs_compaction(conv1.id, usage_input_high)

    test_cases.append(
        {
            "name": "input_overflow",
            "usage": {"input": 195_000, "output": 4_000},
            "overflow_detected": is_overflow_input,
            "passed": is_overflow_input,
        }
    )

    # Should overflow - input exceeds usable input space
    # usable_input = 100_000 - 8_000 = 92_000
    # input > 92_000 triggers overflow
    usage_combined = Usage(input=93_000, output=4_000, reasoning=0)
    is_overflow_combined = manager.needs_compaction(conv1.id, usage_combined)

    test_cases.append(
        {
            "name": "combined_overflow",
            "usage": {"input": 93_000, "output": 4_000},
            "overflow_detected": is_overflow_combined,
            "passed": is_overflow_combined,
        }
    )

    all_passed = all(tc["passed"] for tc in test_cases)

    return {
        "name": "overflow_detection",
        "test_cases": test_cases,
        "passed": all_passed,
    }
