# Context Management — Final Design

## Current State

ctrl+code's context management today is a flat stack:

- **Active window**: harnessutils `ConversationManager` (FilesystemStorage) — appends messages, calls `prune_before_turn()` before each turn (truncation, not retrieval)
- **Tool results**: stored as `role: user` messages with `[Tool: X]\nResult: Y` prefix — no distinction from user text
- **Mid-task compaction**: optional LLM summarisation during ReAct iteration (linear history → condensed message)
- **Fuzzing oracle history**: separate FAISS index + `HistoryDB` SQLite — disconnected from conversation history
- **No semantic retrieval** over conversation history — what's in context is whatever survived truncation

The result: as sessions grow, relevant context gets pruned by recency, not relevance. When a user returns to a part of the codebase they touched hours ago, that context is gone.

---

## Design Principles

1. **Never discard raw data** — lossless cold storage for every artifact; retrieval is the solution, not deletion
2. **Recency ≠ relevance** — only penalise age for off-topic content; same-topic content competes purely on topical similarity and validity
3. **State validity via supersession, not decay** — a chunk is stale because something changed, not because it's old
4. **Retrieval at read time, not filter at write time** — you can't know future relevance; store everything, retrieve selectively
5. **Single store** — rootset artifact store replaces HistoryDB + FAISS + custom embedder; one `rootset.db` per project

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    Incoming Prompt                      │
└──────────────────────────┬──────────────────────────────┘
                           │
            ┌──────────────▼───────────────┐
            │       ContextAssembler       │  NEW
            │  1. extract entities         │
            │  2. embed prompt             │
            │  3. detect focus cluster     │
            │  4. retrieve: saliency       │
            │              entity index    │
            │              semantic ANN    │
            │  5. RRF fuse + score         │
            │  6. trim to budget           │
            └──────────────┬───────────────┘
                           │ assembled context
            ┌──────────────▼───────────────┐
            │  harnessutils ConvManager   │  KEPT — active window
            │  (current turn + recent N)  │
            └──────────────┬───────────────┘
                           │
            ┌──────────────▼───────────────┐
            │      AgentReActLoop         │  UNCHANGED
            └──────────────┬───────────────┘
                           │ turn complete
            ┌──────────────▼───────────────┐
            │       ArtifactWriter        │  NEW
            │  1. chunk artifacts         │
            │  2. score saliency          │
            │  3. extract entities        │
            │  4. detect supersessions    │
            │  5. embed + store rootset   │
            │  6. update entity index     │
            │  7. update engagement       │
            │  8. update session summary  │
            └──────────────┬───────────────┘
                           │
            ┌──────────────▼───────────────┐
            │        rootset.db           │
            │  artifacts + embeddings     │
            │  entity_index (SQL)         │
            │  engagement_log (SQL)       │
            │  supersession_log (SQL)     │
            │  symbols (code intelligence)│
            └─────────────────────────────┘
```

---

## Project Directory — `.harness/`

All harness-owned project state lives under a single dot directory at the workspace root. This keeps project-specific data co-located, portable, and clearly scoped.

```
{workspace_root}/
└── .harness/
    ├── project_id          # stable UUID, generated once, never changes
    ├── rootset.db          # all semantic memory: artifacts, embeddings, entity index
    └── sessions/           # FilesystemStorage conversation history (moved here from default)
```

**`.harness/project_id`**: a UUID written on first `ConversationManager` initialisation for a workspace. Stable across directory renames, git remote changes, anything. Used as the cross-session `namespace` for oracles and other project-scoped artifacts. `ConversationManager` generates and writes it if absent; reads it if present.

**`.harness/rootset.db`**: the rootset `Repository` database. Owned by `ConversationManager` via the `SemanticMemoryBackend` protocol. Passed in by the consumer (ctrl+code provides a rootset-backed implementation).

**`.harness/sessions/`**: existing `FilesystemStorage` conversation files, relocated here from wherever harnessutils was writing them before. Everything in one place.

A `.gitignore` should be recommended for `.harness/` since it contains generated indices and session data, not source.

---

## harnessutils — SemanticMemoryBackend Protocol

harnessutils defines a protocol that `ConversationManager` accepts as an optional dependency. No hard dependency on rootset in harnessutils itself.

```python
# harnessutils/memory.py

from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class SemanticMemoryBackend(Protocol):
    async def add_artifact(
        self,
        content: str,
        kind: str,
        *,
        namespace: str = "default",
        metadata: dict[str, Any] | None = None,
    ) -> Any: ...

    async def search_artifacts(
        self,
        query: str,
        *,
        top_k: int = 10,
        kind: str | None = None,
        namespace: str | None = None,
        min_similarity: float = 0.0,
    ) -> list[Any]: ...

    async def get_artifact(self, artifact_id: int) -> Any | None: ...

    async def update_artifact(
        self,
        artifact_id: int,
        *,
        metadata: dict[str, Any] | None = None,
        content: str | None = None,
    ) -> Any: ...

    async def delete_artifact(self, artifact_id: int) -> None: ...
```

`ConversationManager.__init__()` gains an optional parameter:

```python
def __init__(
    self,
    storage: FilesystemStorage,
    semantic_memory: SemanticMemoryBackend | None = None,
    project_id: str | None = None,
) -> None:
```

When `semantic_memory` is `None`, behaviour is identical to today. When provided, `ConversationManager` delegates write-path artifact storage and read-path context assembly through it.

ctrl+code provides a rootset-backed `SemanticMemoryBackend` implementation and passes it in at startup. Any other consumer of harnessutils can provide their own implementation or omit it entirely.

---

## Storage Layer

### rootset Artifact Store

Each stored unit is an `Artifact` (per rootset-artifact-store-design.md):

```
namespace: session_id  (or project_id for cross-session oracle reuse)
kind:       one of the kinds below
content:    text content of the chunk
metadata:   structured JSON (kind-specific)
```

**Artifact kinds:**

| kind | content | metadata |
|---|---|---|
| `turn:user` | chunked user prompt text | `{session_id, turn_id, chunk_index, total_chunks}` |
| `turn:assistant` | chunked assistant response text | `{session_id, turn_id, chunk_index, saliency_score}` |
| `turn:tool_result` | chunked tool result | `{session_id, turn_id, tool_name, success, chunk_index}` |
| `session:summary` | rolling session summary | `{session_id, turn_count, last_updated}` |
| `oracle` | oracle JSON | `{session_id, version, quality_score, parent_oracle_id, reuse_count}` |
| `generated_code` | code text | `{session_id, language, file_path}` |
| `bug_pattern` | bug description | `{session_id, severity, resolved}` |
| `test_case` | test code | `{session_id, passed, linked_oracle_id}` |

### Additional SQL Tables in rootset.db

Three new tables added to rootset's schema alongside the artifact store:

```sql
-- Entity → chunk index
CREATE TABLE entity_index (
    id          INTEGER PRIMARY KEY,
    entity      TEXT NOT NULL,        -- file path, function name, error message, etc.
    entity_type TEXT NOT NULL,        -- 'file' | 'function' | 'class' | 'error' | 'concept'
    artifact_id INTEGER NOT NULL REFERENCES artifacts(id) ON DELETE CASCADE,
    session_id  TEXT NOT NULL
);
CREATE INDEX idx_entity_lookup ON entity_index(entity, session_id);
CREATE INDEX idx_entity_artifact ON entity_index(artifact_id);

-- Engagement tracking per entity cluster
CREATE TABLE engagement_log (
    id          INTEGER PRIMARY KEY,
    cluster_key TEXT NOT NULL,        -- canonical entity (usually file path)
    session_id  TEXT NOT NULL,
    tokens      INTEGER NOT NULL,
    turn_id     TEXT NOT NULL,
    recorded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_engagement_cluster ON engagement_log(cluster_key, session_id);

-- Supersession events
CREATE TABLE supersession_log (
    id               INTEGER PRIMARY KEY,
    artifact_id      INTEGER NOT NULL REFERENCES artifacts(id) ON DELETE CASCADE,
    superseded_by_id INTEGER REFERENCES artifacts(id) ON DELETE SET NULL,
    reason           TEXT NOT NULL,   -- 'file_modified' | 'user_correction' | 'error_resolved'
    entity           TEXT NOT NULL,   -- what was superseded (file path, function name, etc.)
    recorded_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_supersession_artifact ON supersession_log(artifact_id);
CREATE INDEX idx_supersession_entity ON supersession_log(entity);
```

---

## Write Path — ArtifactWriter

New class: `session/artifact_writer.py`

Called at end of each turn by `SessionManager.process_turn()`.

### Chunking

Split each artifact at semantic boundaries before storing. Strategy varies by content type.

**Code content** (tool results that are source files, code blocks in responses):
- Use tree-sitter (already available in rootset) to chunk at function and class boundaries
- Each function = one chunk; each class definition (without methods) = one chunk; each method = one chunk
- If tree-sitter parse fails (unknown language), fall back to indentation + blank-line heuristics

**Prose content** (user prompts, assistant responses outside code blocks):
- Split at sentence boundaries using punctuation-aware splitting (`.`, `?`, `!` followed by whitespace + capital)
- Merge sentences into chunks targeting 200–600 tokens
- **Overlap**: carry the last 1–2 sentences of each chunk into the start of the next chunk — prevents orphaned fragments where a retrieved chunk starts mid-thought

**JSON tool results**:
- If total size ≤ 400 tokens: single chunk
- If larger: split on top-level keys, one chunk per key-value pair

**Error messages**: single chunk, never split — an error loses meaning without its full trace

**Search result tool outputs**: one chunk per result entry

**Mixed responses** (prose + code blocks interleaved):
- Split at code fence boundaries first (```` ``` ````), yielding prose segments and code segments
- Apply prose strategy to prose segments, tree-sitter/heuristic strategy to code segments
- Preserve ordering metadata so chunks can be reassembled if needed

Target chunk size: 200–800 tokens. Hard split anything over 1200 tokens at the nearest sentence/line boundary.

Chunks store a `chunk_index` and `total_chunks` in metadata so partial retrievals are identifiable.

### Saliency Scoring

Pattern-matching heuristics at write time. No LLM call.

| Pattern | Score | Rationale |
|---|---|---|
| Turn following a user correction (`"actually"`, `"no"`, `"wrong"`, `"instead"`, `"not what I meant"`) | 0.95 | User corrections are always relevant |
| Error resolved (tool error → subsequent success on same tool) | 0.90 | Resolution context persists |
| Explicit decision language (`"let's use"`, `"we'll go with"`, `"the approach is"`) | 0.85 | Architectural decisions persist |
| File write tool result (successful) | 0.80 | State change — what was written matters |
| Code block in assistant response | 0.70 | Generated code has lasting relevance |
| File read that was immediately acted on (followed by edit/write) | 0.65 | Context that drove an action |
| Bare file read (exploration, no subsequent action) | 0.30 | Likely transient |
| Intermediate reasoning steps | 0.20 | Ephemeral — session summary captures the outcome |

Saliency stored in `metadata.saliency_score`. Used at retrieval time to maintain a fixed reserved budget.

### Entity Extraction

From each chunk, extract and index:

- **File paths**: regex `[\w./\-]+\.(py|ts|js|rs|go|md|toml|json|yaml)`
- **Qualified names**: anything in backticks or code blocks matching `\w+\.\w+` pattern
- **Error types**: words ending in `Error`, `Exception`, `Failure` in tool results
- **Tool names**: from `[Tool: X]` prefix on tool result messages

Write each extracted entity to `entity_index` with a reference to the artifact chunk.

### Supersession Detection

After each turn, scan for invalidation events:

1. **File write**: `write_file` or `edit_file` tool success → mark all prior chunks referencing that file path as potentially superseded by the new write chunk
2. **User correction**: high-saliency turn (score ≥ 0.95) → mark the assistant chunk immediately preceding the correction as superseded
3. **Error resolved**: success after error on same tool → mark error chunk as superseded by resolution chunk

Write to `supersession_log`. Do not delete the original chunk — flag it.

### Engagement Tracking

After each turn, sum tokens (prompt + completion) and attribute to clusters:

- Extract the dominant file paths from the turn's entity index entries
- Write one `engagement_log` row per dominant file path with the turn's token count

---

## Read Path — ContextAssembler

New class: `session/context_assembler.py`

Called by `SessionManager.process_turn()` before building messages for the LLM.

### Budget Allocation

```
total_budget = model_context_limit
             - system_prompt_tokens
             - current_turn_tokens        # user message being sent
             - active_window_tokens       # last N messages from ConvManager
             - safety_margin (512)

assembled_budget = total_budget
allocations:
  session_summary:  min(500, assembled_budget × 0.10)  -- always injected
  saliency_reserve: assembled_budget × 0.15            -- top saliency items
  retrieved:        remaining                           -- semantic + entity results
```

### Retrieval Pipeline

```python
async def assemble(self, prompt: str, session_id: str, budget: int) -> str:

    # 1. Extract entities from incoming prompt
    entities = extract_entities(prompt)

    # 2. Detect focus cluster (dominant file path or concept)
    cluster_key = detect_cluster(entities, session_id)

    # 3. Always-on: session summary
    summary = await repo.get_artifact(kind="session:summary", namespace=session_id)

    # 4. Always-on: top saliency items (saliency ≥ 0.80)
    saliency_items = await repo.search_artifacts(
        query=prompt,
        namespace=session_id,
        mode=ArtifactSearchMode.SEMANTIC,
        top_k=5,
        metadata_filter={"saliency_score": {"gte": 0.80}},
    )

    # 5. Entity index lookup (exact match, no embedding needed)
    entity_hits = await entity_index_lookup(entities, session_id)

    # 6. Semantic search
    semantic_hits = await repo.search_artifacts(
        query=prompt,
        namespace=session_id,
        mode=ArtifactSearchMode.HYBRID,
        top_k=20,
    )

    # 7. Score and fuse
    candidates = score_and_fuse(
        semantic_hits, entity_hits,
        cluster_key=cluster_key,
        session_id=session_id,
    )

    # 8. Resolve supersessions
    candidates = resolve_supersessions(candidates)

    # 9. Trim to budget
    assembled = trim_to_budget(
        summary, saliency_items, candidates, budget
    )

    return format_assembled_context(assembled)
```

### Scoring Function

```python
def score_candidate(chunk, cluster_key, session_id) -> float:
    topical_score   = chunk.semantic_score  # from ANN search (0–1)
    entity_bonus    = 0.2 if chunk in entity_hits else 0.0
    same_cluster    = shares_cluster(chunk, cluster_key)
    recency_penalty = 0.0 if same_cluster else decay(age_hours(chunk))
    validity_score  = 0.5 if is_superseded(chunk) else 1.0
    engagement      = log(1 + engagement_sum(cluster_key, session_id)) / 10.0

    return (topical_score + entity_bonus) * validity_score * (1.0 - recency_penalty) * (1.0 + engagement)
```

**Recency decay function** (only applied to off-cluster chunks):
```python
def decay(age_hours: float) -> float:
    # Slow decay — 50% penalty at 8 hours, 80% at 24 hours, 90% at 72 hours
    return 1.0 - (1.0 / (1.0 + math.exp(-0.3 * (age_hours - 8))))
```

**Cluster detection** (pragmatic v1 — no ML clustering required):
```python
def shares_cluster(chunk, cluster_key) -> bool:
    # A chunk belongs to the cluster if it references the same dominant file
    return cluster_key in chunk.metadata.get("entities", {}).get("files", [])
```

### Supersession Resolution

When a superseded chunk is in the candidate set:
1. Keep it (don't discard — historical context has value)
2. Also fetch its `superseded_by_id` chunk
3. Inject both, ordered superseded → superseding
4. Prefix superseded chunk with `[SUPERSEDED — see below]` so the model understands the relationship

### Output Format

Assembled context is injected into the system prompt's environment section:

```
--- Retrieved Context ---
[Session Summary]
{summary text}

[Relevant History]
[from turn 12, file: fuzzing/context.py, saliency: 0.85]
{chunk text}

[from turn 4, file: fuzzing/context.py — SUPERSEDED — see below]
{old chunk text}

[from turn 34, file: fuzzing/context.py — supersedes above]
{new chunk text}

[from turn 8, file: storage/history_db.py, saliency: 0.70]
{chunk text}
--- End Retrieved Context ---
```

---

## Session Summary

A `session:summary` artifact is maintained per session. Updated after each turn by `ArtifactWriter`.

Two-tier update strategy:

**Routine turns** (no high-saliency chunks): accumulate without LLM call.

```python
def update_summary_heuristic(existing: str, new_turn: TurnArtifacts) -> str:
    highlights = [c for c in new_turn.chunks if c.saliency >= 0.80]
    if not highlights:
        return existing
    new_entries = [format_summary_entry(c) for c in highlights]
    return trim_to_tokens(existing + "\n" + "\n".join(new_entries), max_tokens=500)
```

**Significant turns** (multiple high-saliency chunks, or summary approaching 500 tokens): use harnessutils' existing compaction infrastructure (the same `LLMClientAdapter`-backed summarisation used for mid-task compaction). Pass the current summary + new high-saliency chunks, get back a condensed summary. This reuses proven infrastructure rather than building something new.

Trigger LLM summarisation when:
- `len(highlights) >= 3` in a single turn, OR
- existing summary is within 100 tokens of the 500-token cap

Summary format (structured for easy parsing at retrieval time):
```
Session focus: fuzzing/context.py, storage/history_db.py
Key decisions: Using rootset for artifact storage. FAISS replaced.
Recent changes: Wrote artifact_writer.py. Updated session/manager.py.
Open items: supersession resolution untested.
```

---

## Oracle Reuse Migration

The `ContextDerivationEngine` in `fuzzing/context.py` is refactored to use rootset instead of HistoryDB + FAISS + custom `embedder.py`.

**Before:**
```python
self.embedder = CodeEmbedder(base_url, model)
self.vector_store = VectorStore(index_type="hnsw")
self.history_db = HistoryDB(db_path)
```

**After:**
```python
self.repo = Repository(Settings(db_path=project_rootset_db))
```

**Oracle search** (replaces `_search_similar_oracle()`):
```python
results = await self.repo.search_artifacts(
    query=generated_code,
    kind="oracle",
    namespace=project_id,  # cross-session scope
    min_similarity=0.85,
    top_k=3,
    mode=ArtifactSearchMode.SEMANTIC,
)
```

**Oracle storage** (replaces `_store_oracle()`):
```python
await self.repo.add_artifact(
    content=json.dumps(oracle.to_dict()),
    kind="oracle",
    namespace=project_id,
    metadata={
        "version": oracle.version,
        "quality_score": quality_score,
        "parent_oracle_id": parent_id,
        "reuse_count": 0,
        "session_id": session_id,
    },
)
```

Same pattern applies to `generated_code`, `bug_pattern`, `test_case` artifact kinds.

Files deleted: `storage/history_db.py`, `embeddings/embedder.py`, `embeddings/vector_store.py`

---

## Integration Points in ctrl+code

### `session/manager.py` changes

```python
# __init__
self._context_assembler = ContextAssembler(repo=project_repo)
self._artifact_writer = ArtifactWriter(repo=project_repo)

# process_turn() — before AgentReActLoop.stream()
assembled_context = await self._context_assembler.assemble(
    prompt=user_input,
    session_id=session.id,
    budget=self._calculate_context_budget(session),
)
# inject assembled_context into env_section of system prompt

# process_turn() — after AgentReActLoop.stream() completes
await self._artifact_writer.write_turn(
    session_id=session.id,
    turn_id=turn_id,
    user_input=user_input,
    assistant_response=assistant_text,
    tool_calls=tool_calls,
    tool_results=tool_results,
)
```

### harnessutils `ConvManager` — kept as-is

Active window management (recent N messages) stays with `ConvManager`. `prune_before_turn()` continues to manage the raw message list. The assembled context supplements it; it doesn't replace it.

The invariant: **ConvManager owns the last K turns verbatim; rootset owns everything older plus semantic retrieval over everything.**

---

## New Files

| File | Purpose |
|---|---|
| `session/context_assembler.py` | ContextAssembler — retrieval pipeline, scoring, budget trim |
| `session/artifact_writer.py` | ArtifactWriter — chunking, saliency, entity extraction, supersession |

## Changed Files

| File | Change |
|---|---|
| `session/manager.py` | Wire in ContextAssembler + ArtifactWriter; inject assembled context |
| `fuzzing/context.py` | Replace HistoryDB + FAISS with rootset Repository |
| `fuzzing/oracle_adapter.py` | Update storage calls to rootset API |

## Deleted Files

| File | Replaced by |
|---|---|
| `storage/history_db.py` | rootset artifact store |
| `embeddings/embedder.py` | rootset EmbeddingProvider |
| `embeddings/vector_store.py` | rootset sqlite-vec via artifact store |

---

## Resolved Questions

All open questions from the initial draft are resolved:

1. **Build order**: rootset artifact store → harnessutils changes → ctrl+code changes.

2. **Repository ownership**: `ConversationManager` in harnessutils holds the `SemanticMemoryBackend`. ctrl+code provides a rootset-backed implementation. No hard rootset dependency in harnessutils.

3. **`prune_before_turn()` behaviour**: confirmed simple recency truncation — last K turns verbatim. Budget calculation is straightforward.

4. **Chunking**: tree-sitter for code, sentence-boundary + overlap for prose, structural for JSON, single chunk for errors. Documented in full above.

5. **Session summary updates**: two-tier — heuristic accumulation for routine turns, harnessutils compaction infrastructure for significant turns.

6. **Project ID**: stable UUID written to `.harness/project_id` on first initialisation. Never derived from path or git state — immune to renames and remote changes.

## Build Sequence

1. **rootset** — add artifact store (schema, models, StorageBackend methods, Repository API) per `rootset-artifact-store-design.md`
2. **harnessutils** — add `SemanticMemoryBackend` protocol; add `.harness/` directory management; wire optional backend into `ConversationManager` (write path + read path hooks); relocate `FilesystemStorage` sessions under `.harness/sessions/`
3. **ctrl+code** — implement `RootsetMemoryBackend` (rootset adapter satisfying the protocol); add `ArtifactWriter`; add `ContextAssembler`; wire both into `SessionManager`; migrate `ContextDerivationEngine` off HistoryDB + FAISS; delete `storage/history_db.py`, `embeddings/embedder.py`, `embeddings/vector_store.py`
