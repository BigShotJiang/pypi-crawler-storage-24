# Changelog

All notable changes to harness-utils are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
Versioning follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.2.0] — 2026-03-12

### Added

- **`MessageHooks`** — pre/post lifecycle hooks for `add_message()`. Pass
  `on_before_add_message` to inspect, modify, or reject a message before storage;
  pass `on_after_add_message` for side effects (audit logging, semantic memory
  writes, metrics) after successful storage. See `docs/message-hooks.md`.
- **`docs/message-hooks.md`** — full guide covering both hook contracts, worked
  examples (guardrail, PII redaction, semantic memory indexing, audit logging,
  Prometheus metrics), hook execution order, and thread safety notes.

---

## [1.1.0] — 2026-03-10

### Added

- **`SemanticMemoryBackend` protocol** — async protocol consumers implement to
  provide semantic artifact storage (`add_artifact`, `search_artifacts`,
  `get_artifact`, `update_artifact`, `delete_artifact`). Exported from package root.
- **`resolve_workspace()`** — creates `.harness/` under a workspace root and
  writes a stable UUID4 to `.harness/project_id` on first call; reads it on
  subsequent calls.
- **`ConversationManager(workspace_root=, semantic_memory=)`** — two new
  keyword-only parameters. `workspace_root` triggers workspace init and defaults
  storage to `FilesystemStorage` at `.harness/sessions/`. `semantic_memory`
  stores the backend reference on `manager.semantic_memory`; harness-utils never
  calls it internally.

---

## [1.0.0] — 2026-02-18

First production-stable release.

### Breaking Changes

- **`StorageBackend` protocol extended** — custom backends must now implement three new
  methods: `save_project_memory(project_id, data)`, `load_project_memory(project_id)`,
  `delete_project_memory(project_id)`. Both built-in backends (`MemoryStorage`,
  `FilesystemStorage`) implement these. Legacy backends that omit them will raise
  `AttributeError` only when the memory API is called.

### Added

- **Cross-conversation memory** — `ConversationManager` gains `get_memory()`,
  `set_memory()`, `delete_memory()`, and `list_memory()` for a project-scoped
  key-value store that persists across conversations.
- **Configurable summarization prompts** — `SummarizationConfig` now accepts
  `summarization_prompt` and `differential_prompt` overrides; defaults remain
  unchanged.
- **Tool outputs in summarization** — `SummarizationConfig.include_tool_outputs`
  (default `True`) and `tool_output_max_tokens` (default `300`) control whether
  tool call results are included in the summarization context.
- **Audit trail for pruning decisions** — `inspect_context().get_audit_trail()` now
  returns the actual decisions from the most recent `prune_before_turn()` call
  instead of always returning `[]`.
- **`cleanup_stale_data` execute mode** — pass `execute=True` to
  `ConversationManager.cleanup_stale_data()` to actually clear stale outputs
  (previously only counted them).

### Fixed

- **`json_array_limit` ignored** — `TruncationConfig.json_array_limit` was validated
  but never read by the truncator. Arrays are now capped at the configured limit.
- **Message cache stale after mutations** — `prune_before_turn()` and
  `cleanup_stale_data(execute=True)` now invalidate `_message_cache` after saving
  mutated messages.
- **Timestamp default in `cleanup_stale_data`** — messages without a timestamp
  metadata field are now assigned a timestamp when added via `add_message()`,
  ensuring stale-detection works correctly without extra caller effort.

### Changed

- `PruningDecision` now has a `from_dict()` classmethod for round-trip serialization.
- `FilesystemStorage` creates a `data/memory/` subdirectory for project memory.
- `MemoryStorage` stores project memory in a new `_project_memory` dict.

---

## [0.3.1] — 2025-01-15

### Fixed

- Special token strings (`<|endoftext|>` etc.) in message content no longer raise
  `ValueError` from tiktoken — they are counted as normal text.

---

## [0.3.0] — 2025-01-10

### Added

- Differential summarization (only re-summarize new messages since last summary).
- Content-aware truncation — detects JSON, logs, stacktraces, and code; preserves
  structure instead of cutting at byte boundaries.
- Predictive overflow detection — tracks conversation velocity and warns before the
  context window fills.
- Quality metrics (`get_context_quality()`, `get_quality_trend()`) with health
  scoring and actionable recommendations.
- Context snapshots — save, restore, compare, export, and import conversation state.
- Selective context loading — agents can load specific message ranges instead of
  the full history.

---

## [0.2.0] — 2024-12-01

### Added

- Importance scoring for tool outputs (recency, relevance, uniqueness).
- Deduplication via content shingling.
- `ContextInspector` API for observability (token breakdown, health check, audit
  trail stub).

---

## [0.1.0] — 2024-11-01

Initial release.

### Added

- `ConversationManager` with `MemoryStorage` and `FilesystemStorage`.
- Three-tier compaction: truncation → pruning → summarization.
- Exact token counting via tiktoken (`calculate_context_usage()`).
- `TurnProcessor` / `ToolStateMachine` for agentic turn management.
- `HarnessConfig` with `TruncationConfig`, `PruningConfig`, `SummarizationConfig`.
