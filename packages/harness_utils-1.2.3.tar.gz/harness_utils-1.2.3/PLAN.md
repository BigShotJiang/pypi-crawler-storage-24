# Implementation Plan — Semantic Memory Integration

Spec: `harness-semantic-memory-design.md`

Three deliverables, implemented in strict dependency order:

1. `SemanticMemoryBackend` protocol
2. `resolve_workspace()` utility
3. `ConversationManager` wiring

Each step has tests before the next step begins. No hanging code at any point.

---

## Step 1 — Define SemanticMemoryBackend Protocol

**Files touched:** `src/harnessutils/memory.py` (new), `src/harnessutils/__init__.py`

**What it does:**

Creates the async protocol that semantic memory implementations must satisfy. No
implementation is provided — only the interface. Exports it from the package root so
consumers can type-annotate against it.

**Acceptance criteria:**

- `from harnessutils import SemanticMemoryBackend` works
- `SemanticMemoryBackend` is `@runtime_checkable`
- A class implementing all five methods passes `isinstance(obj, SemanticMemoryBackend)`
- ruff and mypy clean

---

### Prompt 1

```
In the harness-utils project, create src/harnessutils/memory.py with the following
content exactly:

"""Semantic memory backend protocol for harness-utils.

Defines the interface that semantic memory implementations must satisfy.
harness-utils does not implement this — consumers (e.g. ctrl+code via rootset)
provide the implementation and pass it to ConversationManager.
"""

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class SemanticMemoryBackend(Protocol):
    """Protocol for semantic artifact storage and retrieval.

    All methods are async because implementations are expected to use async
    I/O (database, network). harness-utils holds the reference but never
    awaits it internally — callers do.
    """

    async def add_artifact(
        self,
        content: str,
        kind: str,
        *,
        namespace: str = "default",
        metadata: dict[str, Any] | None = None,
    ) -> Any:
        """Store an artifact and return the implementation's artifact object."""
        ...

    async def search_artifacts(
        self,
        query: str,
        *,
        top_k: int = 10,
        kind: str | None = None,
        namespace: str | None = None,
        min_similarity: float = 0.0,
    ) -> list[Any]:
        """Semantic search over stored artifacts."""
        ...

    async def get_artifact(self, artifact_id: int) -> Any | None:
        """Fetch a single artifact by ID. Returns None if not found."""
        ...

    async def update_artifact(
        self,
        artifact_id: int,
        *,
        metadata: dict[str, Any] | None = None,
        content: str | None = None,
    ) -> Any:
        """Update metadata and/or content of an existing artifact."""
        ...

    async def delete_artifact(self, artifact_id: int) -> None:
        """Delete an artifact by ID."""
        ...


Then add SemanticMemoryBackend to the imports and __all__ in
src/harnessutils/__init__.py alongside LLMClient and StorageBackend.

Then create tests/test_semantic_memory.py with these tests:

1. test_import — `from harnessutils import SemanticMemoryBackend` succeeds and the
   object is a Protocol subclass.

2. test_runtime_checkable_positive — A class that implements all five async methods
   (stubs returning None) passes isinstance(obj, SemanticMemoryBackend).

3. test_runtime_checkable_negative — An object that implements none of the methods
   fails isinstance(obj, SemanticMemoryBackend).

4. test_missing_one_method_fails — A class missing one method (e.g. delete_artifact)
   fails isinstance(obj, SemanticMemoryBackend).

Run ruff and mypy on src/ after implementing. Fix any issues before finishing.
```

---

## Step 2 — Workspace Resolution Utility

**Files touched:** `src/harnessutils/workspace.py` (new)

**What it does:**

Provides `resolve_workspace(workspace_root: Path) -> tuple[Path, str]`. Creates
`.harness/` under the given root, writes a UUID4 to `.harness/project_id` if it
doesn't exist, reads it if it does. Returns `(harness_dir, project_id)`.

No changes to any existing file. Self-contained.

**Acceptance criteria:**

- `.harness/` created on first call
- `project_id` file written on first call, UUID4 format
- Same UUID returned on second call to same root
- Different root → different UUID
- ruff and mypy clean

---

### Prompt 2

```
In the harness-utils project, create src/harnessutils/workspace.py with the
following content exactly:

"""Workspace directory management for harness-utils.

Manages the .harness/ directory at the workspace root, including the stable
project UUID that identifies a workspace across sessions.
"""

import uuid
from pathlib import Path


def resolve_workspace(workspace_root: Path) -> tuple[Path, str]:
    """Ensure .harness/ exists and return (harness_dir, project_id).

    On first call for a given workspace_root:
      - Creates workspace_root/.harness/
      - Generates a UUID4 and writes it to workspace_root/.harness/project_id

    On subsequent calls:
      - Reads the existing project_id from disk

    The project_id is stable across directory renames, git remote changes,
    and anything else external. It is the canonical namespace for this workspace.

    Args:
        workspace_root: Absolute path to the workspace root directory.

    Returns:
        Tuple of (harness_dir, project_id) where harness_dir is the Path to
        .harness/ and project_id is the stable UUID string.
    """
    harness_dir = workspace_root / ".harness"
    harness_dir.mkdir(parents=True, exist_ok=True)

    id_file = harness_dir / "project_id"
    if id_file.exists():
        project_id = id_file.read_text().strip()
    else:
        project_id = str(uuid.uuid4())
        id_file.write_text(project_id)

    return harness_dir, project_id


Then create tests/test_workspace.py with these tests (use tmp_path pytest fixture
for all file system operations):

1. test_creates_harness_dir — calling resolve_workspace creates .harness/ under
   the given root.

2. test_writes_project_id_file — .harness/project_id exists after first call and
   contains a non-empty string that is a valid UUID4 (use uuid.UUID(project_id)
   to validate — it should not raise).

3. test_project_id_stable — calling resolve_workspace twice on the same root
   returns the same project_id both times.

4. test_different_roots_different_ids — two different tmp dirs get different
   project_ids.

5. test_returns_harness_dir_path — the returned harness_dir is workspace_root /
   ".harness" and exists.

6. test_idempotent — calling resolve_workspace ten times on the same root returns
   the same project_id every time and only one project_id file exists.

Run ruff and mypy on src/ after implementing. Fix any issues before finishing.
```

---

## Step 3 — Wire into ConversationManager

**Files touched:** `src/harnessutils/manager.py`

**What it does:**

Adds two keyword-only parameters to `ConversationManager.__init__()`:

- `workspace_root: Path | str | None = None`
- `semantic_memory: SemanticMemoryBackend | None = None`

When `workspace_root` is provided:
- Calls `resolve_workspace()` to get `(harness_dir, project_id)`
- Sets `self.project_id = project_id`
- If `storage` was not explicitly passed, defaults to `FilesystemStorage` at
  `harness_dir / "sessions"`

When `workspace_root` is omitted, everything is identical to current behaviour.
`self.project_id` is `None`. `self.semantic_memory` is whatever was passed (or `None`).

**Acceptance criteria:**

- `ConversationManager()` (no args) behaves identically to today
- `ConversationManager(workspace_root=path)` sets `manager.project_id` and uses
  `.harness/sessions/` for storage
- Explicit `storage=` arg takes precedence over workspace default
- `manager.semantic_memory` holds the passed backend or `None`
- All 327 existing tests still pass
- ruff and mypy clean

---

### Prompt 3

```
In src/harnessutils/manager.py, update ConversationManager.__init__() as follows.

Current signature:
    def __init__(
        self,
        storage: StorageBackend | None = None,
        config: HarnessConfig | None = None,
    ) -> None:

New signature:
    def __init__(
        self,
        storage: StorageBackend | None = None,
        config: HarnessConfig | None = None,
        *,
        workspace_root: Path | str | None = None,
        semantic_memory: SemanticMemoryBackend | None = None,
    ) -> None:

At the top of the method body, before the existing `self.config = ...` line, add:

    self.project_id: str | None = None
    self.semantic_memory = semantic_memory

    if workspace_root is not None:
        from harnessutils.workspace import resolve_workspace
        harness_dir, self.project_id = resolve_workspace(Path(workspace_root))
        if storage is None:
            from harnessutils.config import StorageConfig
            from harnessutils.storage.filesystem import FilesystemStorage
            storage = FilesystemStorage(StorageConfig(base_path=harness_dir / "sessions"))

The rest of the method is unchanged. Make sure the existing line:
    self.storage = storage or MemoryStorage()
still runs after the workspace block.

Add the necessary imports at the top of manager.py:
- `from pathlib import Path`
- `from harnessutils.memory import SemanticMemoryBackend`

Then add tests in tests/test_workspace_manager.py (new file, use tmp_path):

1. test_no_workspace_root_unchanged — ConversationManager() with no args has
   project_id=None and semantic_memory=None, uses MemoryStorage.

2. test_workspace_root_sets_project_id — ConversationManager(workspace_root=tmp_path)
   sets manager.project_id to a non-None UUID string.

3. test_workspace_root_project_id_stable — Two ConversationManager instances created
   with the same workspace_root get the same project_id.

4. test_workspace_root_defaults_filesystem_storage — When workspace_root is set and
   storage is not passed, the .harness/sessions/ directory is created on disk.

5. test_explicit_storage_takes_precedence — When both workspace_root and storage are
   passed, the explicit storage is used (manager.storage is the passed object).

6. test_semantic_memory_stored — Passing semantic_memory=some_object stores it on
   manager.semantic_memory.

7. test_semantic_memory_none_by_default — manager.semantic_memory is None when not
   passed.

8. test_workspace_root_string_accepted — workspace_root can be a plain str (not just
   Path) — manager.project_id is set correctly.

Run the full test suite (uv run pytest --no-cov -q) and confirm all tests pass.
Run ruff and mypy on src/. Fix any issues before finishing.
```

---

## Completion Criteria

All three steps done when:

- [ ] `from harnessutils import SemanticMemoryBackend` works
- [ ] `resolve_workspace()` is importable from `harnessutils.workspace`
- [ ] `ConversationManager(workspace_root=path)` creates `.harness/`, sets `project_id`, defaults storage to `.harness/sessions/`
- [ ] All existing 327 tests pass
- [ ] New tests for all three steps pass
- [ ] ruff clean, mypy clean
