# OpenAI Harness Engineering → harness-utils Improvements

**Goal:** Make harness-utils the best context management library for agent-first applications

**Principle:** Library provides primitives. Applications compose workflows.

---

## Core Insights from OpenAI

### 1. Agent Legibility is Primary
> "From the agent's point of view, anything it can't access in-context while running effectively doesn't exist."

**For harness-utils:** Context state must be fully observable, queryable, and inspectable by agents.

### 2. Progressive Disclosure
> "Give agents a map, not a 1000-page manual."

**For harness-utils:** Support selective context loading - agents shouldn't need full history to understand current state.

### 3. Mechanical Enforcement > Documentation
> "When documentation falls short, promote the rule into code."

**For harness-utils:** Type-safe APIs, validation, clear error messages with remediation steps.

### 4. Everything Repository-Local & Versioned
> "What does exist: Repository-local, versioned artifacts"

**For harness-utils:** Full conversation state must be serializable, versionable, reproducible.

### 5. Fast Feedback Loops
> "Codex regularly works on single task for 6+ hours while humans sleep"

**For harness-utils:** Predictive overflow (✅ done), real-time metrics, no surprises.

### 6. Continuous Entropy Management
> "Technical debt is like high-interest loan: pay down continuously in small increments"

**For harness-utils:** Support background cleanup operations, quality metrics, drift detection.

---

## Gaps in Current harness-utils

### 1. **Limited Observability** ❌
- Can't easily answer: "What's in context right now?"
- Can't query: "Why was message X pruned?"
- No visibility into: "What will be truncated if I add 5K tokens?"

### 2. **No Context Snapshots** ❌
- Can't save/restore full context state
- Hard to reproduce issues
- Can't A/B test context strategies

### 3. **Minimal Metadata Tracking** ⚠️
- Pruning tracks tokens saved, but not WHY each item was pruned
- No importance scores visible after pruning
- Can't audit decisions

### 4. **Basic Error Messages** ⚠️
- Errors exist but don't guide remediation
- No validation of configuration sanity
- Silent failures possible

### 5. **No Quality Metrics** ❌
- Can't measure: context redundancy, information density, staleness
- No way to detect degradation over time
- No alerts when context health poor

### 6. **No Selective Loading** ❌
- Must load full conversation or nothing
- Can't load "last 10 turns" or "only messages with errors"
- No filtering/query API

---

## Proposed Improvements

### Phase 3A: Observability & Inspection (High Value)

#### 1. Context Inspector API
```python
# Query current state
inspector = manager.inspect_context(conversation_id)

# What's in context?
inspector.summary()
# Returns:
# {
#   "total_messages": 45,
#   "total_tokens": 125_000,
#   "tool_outputs": 230,
#   "tool_outputs_compacted": 180,
#   "summaries": 2,
#   "protected_tokens": 40_000,
#   "prunable_tokens": 85_000
# }

# Why was X pruned?
inspector.get_pruning_decision(message_id, part_id)
# Returns:
# {
#   "pruned": True,
#   "reason": "low_importance",
#   "importance_score": 12.3,
#   "duplicate_of": None,
#   "pruned_at": "2026-02-13T10:30:00Z",
#   "tokens_saved": 1234
# }

# What would happen if I add N tokens?
inspector.predict_impact(additional_tokens=5000)
# Returns:
# {
#   "would_trigger_pruning": True,
#   "estimated_pruned_count": 8,
#   "would_trigger_overflow": False,
#   "estimated_compaction_cost_usd": 0.0
# }

# Get full decision audit trail
inspector.get_audit_trail(limit=50)
# Returns list of all pruning/truncation/summarization decisions
```

**Files to modify:**
- New: `src/harnessutils/inspection.py` - ContextInspector class
- Modify: `src/harnessutils/manager.py` - Add inspect_context() method
- Modify: `src/harnessutils/compaction/pruning.py` - Track decision metadata

**Tests:** 15 new tests in `tests/test_inspection.py`

---

#### 2. Context Snapshots
```python
# Save full context state
snapshot = manager.create_snapshot(conversation_id)
# Returns:
# {
#   "snapshot_id": "snap_abc123",
#   "timestamp": "2026-02-13T10:30:00Z",
#   "conversation_id": "conv_xyz",
#   "messages": [...],  # Full state
#   "config": {...},    # Config used
#   "metadata": {
#     "total_tokens": 125_000,
#     "message_count": 45,
#     "velocity": {...}
#   }
# }

# Restore from snapshot
manager.restore_snapshot(snapshot_id)

# Compare snapshots
diff = manager.compare_snapshots(snap1_id, snap2_id)
# Returns:
# {
#   "messages_added": 5,
#   "messages_removed": 0,
#   "tokens_delta": +12_345,
#   "pruning_decisions": [...],
#   "config_changes": [...]
# }

# Export snapshot (for version control)
manager.export_snapshot(snapshot_id, "snapshots/conversation_before_refactor.json")
```

**Files to modify:**
- New: `src/harnessutils/snapshots.py` - Snapshot management
- Modify: `src/harnessutils/manager.py` - Add snapshot methods
- Modify: `src/harnessutils/storage/` - Add snapshot storage

**Tests:** 12 new tests in `tests/test_snapshots.py`

---

#### 3. Rich Decision Metadata
```python
# Enhanced PruningResult with full decision log
@dataclass
class PruningDecision:
    message_id: str
    part_id: str
    decision: Literal["kept", "pruned_duplicate", "pruned_low_importance", "protected"]
    importance_score: float | None
    duplicate_of: str | None
    tokens_saved: int
    timestamp: int
    metadata: dict[str, Any]

@dataclass
class PruningResult:
    # ... existing fields ...
    decisions: list[PruningDecision]  # NEW: Full decision log

    def get_pruned(self) -> list[PruningDecision]:
        return [d for d in self.decisions if d.decision.startswith("pruned_")]

    def get_protected(self) -> list[PruningDecision]:
        return [d for d in self.decisions if d.decision == "protected"]
```

**Files to modify:**
- Modify: `src/harnessutils/compaction/pruning.py` - Track all decisions, not just counts
- Modify: `src/harnessutils/models/parts.py` - Add decision_metadata to ToolState

**Tests:** Update existing pruning tests + 8 new metadata tests

---

#### 4. Validation & Better Errors
```python
# Config validation
config = HarnessConfig()
config.pruning.prune_protect = 200_000  # More than context limit!
config.validate()
# Raises:
# ConfigurationError:
#   "pruning.prune_protect (200000) exceeds model_limits.default_context_limit (128000).
#    This will prevent pruning from ever triggering.
#
#    Suggested fix: Set pruning.prune_protect to 40000 (30% of context limit)"

# Runtime validation
manager.add_message(conv_id, message)
manager.prune_before_turn(conv_id)
# If config is broken, raises helpful error:
# PruningError:
#   "Cannot prune: all tool outputs are protected by protected_tools config.
#    Protected tools: ['read', 'write', 'bash', ...]
#
#    Suggested fix: Remove some tools from protected_tools or disable protection"
```

**Files to modify:**
- Modify: `src/harnessutils/config.py` - Add validate() method with checks
- New: `src/harnessutils/exceptions.py` - Custom exception classes with remediation
- Modify: All compaction modules - Use custom exceptions

**Tests:** 10 new validation tests in `tests/test_validation.py`

---

### Phase 3B: Quality Metrics (Medium Value)

#### 5. Context Quality Metrics
```python
# Get quality metrics
metrics = manager.get_context_quality(conversation_id)
# Returns:
# {
#   "information_density": 0.73,  # tokens with unique info / total tokens
#   "redundancy_ratio": 0.18,     # duplicate content ratio
#   "staleness_score": 0.12,      # avg age-weighted decay
#   "error_preservation_rate": 1.0,  # % of errors still in context
#   "protected_ratio": 0.32,      # % of tokens protected from pruning
#   "health": "good",             # good | degraded | poor
#   "recommendations": [
#     "Consider running deduplication - 18% redundancy detected",
#     "Protected ratio high (32%) - may limit pruning effectiveness"
#   ]
# }

# Track quality over time
manager.track_quality_metric(
    conversation_id,
    metric_name="information_density",
    value=0.73,
    timestamp=now()
)

# Get quality trend
trend = manager.get_quality_trend(conversation_id, metric="information_density", window=20)
# Returns list of (timestamp, value) tuples
```

**Files to modify:**
- New: `src/harnessutils/quality.py` - Quality metrics calculation
- Modify: `src/harnessutils/manager.py` - Add quality methods
- Modify: `src/harnessutils/models/conversation.py` - Store quality history in metadata

**Tests:** 12 new tests in `tests/test_quality.py`

---

### Phase 3C: Selective Loading (Medium Value)

#### 6. Query & Filter API
```python
# Load only recent messages
messages = manager.get_messages(
    conversation_id,
    limit=10,
    order="desc"
)

# Load messages in time range
messages = manager.get_messages(
    conversation_id,
    after=timestamp_start,
    before=timestamp_end
)

# Load only messages with specific criteria
messages = manager.get_messages(
    conversation_id,
    filter={
        "has_errors": True,
        "min_importance": 50.0,
        "tools": ["bash", "write"]
    }
)

# Load context summary (without full content)
summary = manager.get_context_summary(conversation_id)
# Returns:
# {
#   "message_count": 45,
#   "summaries": [
#     {"id": "msg_1", "turn": 1, "summary": "Initial setup..."},
#     {"id": "msg_15", "turn": 15, "summary": "Refactored auth..."}
#   ],
#   "recent_activity": [...last 5 messages...],
#   "key_decisions": [...],
#   "open_issues": [...]
# }
```

**Files to modify:**
- Modify: `src/harnessutils/manager.py` - Add query methods
- Modify: `src/harnessutils/storage/` - Support filtering in storage layer
- New: `src/harnessutils/query.py` - Query builder/filter logic

**Tests:** 15 new tests in `tests/test_query.py`

---

### Phase 3D: Cleanup Hooks (Lower Priority)

#### 7. Background Maintenance API
```python
# Register cleanup tasks
manager.register_cleanup_task(
    task_id="dedup_scan",
    interval=3600,  # Run every hour
    callback=lambda conv_id: manager.scan_and_deduplicate(conv_id)
)

# Manual cleanup operations
result = manager.cleanup_stale_data(
    conversation_id,
    max_age_hours=24,
    keep_errors=True
)
# Returns:
# {
#   "messages_archived": 12,
#   "tokens_freed": 23_456,
#   "duplicates_removed": 5
# }

# Detect drift/quality issues
issues = manager.detect_context_issues(conversation_id)
# Returns:
# [
#   {
#     "issue": "high_redundancy",
#     "severity": "warning",
#     "affected_messages": [...],
#     "suggested_fix": "Run deduplication"
#   },
#   {
#     "issue": "staleness_accumulation",
#     "severity": "info",
#     "suggested_fix": "Consider summarization"
#   }
# ]
```

**Files to modify:**
- New: `src/harnessutils/maintenance.py` - Cleanup and maintenance
- Modify: `src/harnessutils/manager.py` - Add maintenance methods
- New: `src/harnessutils/scheduler.py` - Simple task scheduler (optional)

**Tests:** 10 new tests in `tests/test_maintenance.py`

---

## Implementation Priority

### High Impact (Do First)
1. **Context Inspector API** - Immediate value for debugging and agents
2. **Context Snapshots** - Reproducibility and testing
3. **Rich Decision Metadata** - Auditability and transparency

### Medium Impact (Do Second)
4. **Validation & Better Errors** - Developer experience, prevent misconfiguration
5. **Context Quality Metrics** - Monitoring and optimization
6. **Selective Loading** - Performance and flexibility

### Lower Priority (Nice to Have)
7. **Background Maintenance** - Can be built on top by applications

---

## Architectural Principles

### 1. Library Stays Focused
- ✅ Provide primitives (inspection, snapshots, metrics)
- ❌ Don't implement agent workflows (that's application-level)

### 2. Zero Breaking Changes
- All new APIs additive
- Existing functionality unchanged
- Backward compatible

### 3. Observable by Default
- Every operation produces rich metadata
- Full audit trail available
- Metrics exported, not hidden

### 4. Fail Fast with Helpful Errors
- Validate early
- Clear error messages with remediation steps
- No silent failures

### 5. Agent-First Design
- APIs designed for programmatic consumption
- JSON-serializable everywhere
- Full introspection available

---

## Success Metrics

After Phase 3 implementation:

1. **Observability:** Agent can answer "what's in context?" in <10ms
2. **Reproducibility:** Any context state reproducible from snapshot
3. **Debuggability:** All pruning/truncation decisions auditable
4. **Quality:** Applications can monitor context health
5. **Flexibility:** Load context selectively, not all-or-nothing
6. **Reliability:** Misconfigurations caught at startup, not runtime

---

## Next Steps

1. Review this plan with user
2. Pick one feature to implement (suggest: Context Inspector)
3. Write detailed spec
4. Implement + test
5. Iterate through rest of Phase 3A

**Estimated Timeline:**
- Phase 3A (Observability): 2 weeks
- Phase 3B (Quality Metrics): 1 week
- Phase 3C (Selective Loading): 1 week
- Phase 3D (Maintenance): 3 days

**Total: ~4 weeks for full Phase 3**
