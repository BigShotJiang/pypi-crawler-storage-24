from setuptools import setup, find_packages

setup(
    name="antarraksha-autogen",
    version="0.1.0",
    description="Antarraksha AI Agent Enforcement SDK for Autogen",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Akash Kumar Dey",
    author_email="akash@antarraksha.ai",
    url="https://github.com/antarraksha/antarraksha-autogen",
    packages=find_packages(),
    install_requires=["requests>=2.28.0"],
    python_requires=">=3.9",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3",
        "Topic :: Security",
    ],
    keywords="ai agent safety security enforcement autogen antarraksha",
)
