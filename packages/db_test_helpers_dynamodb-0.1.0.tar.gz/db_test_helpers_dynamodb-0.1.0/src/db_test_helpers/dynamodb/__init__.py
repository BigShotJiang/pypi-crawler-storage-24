"""db-test-helpers-dynamodb: DynamoDB adapter for db-test-helpers."""

from db_test_helpers.dynamodb._adapter import DynamodbAdapter

__all__ = ["DynamodbAdapter"]
