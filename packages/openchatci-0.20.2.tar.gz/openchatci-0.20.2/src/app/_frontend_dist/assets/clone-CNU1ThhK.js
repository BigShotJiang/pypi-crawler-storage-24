import{b as r}from"./_baseUniq-BQW6vVC-.js";var e=4;function a(o){return r(o,e)}export{a as c};
