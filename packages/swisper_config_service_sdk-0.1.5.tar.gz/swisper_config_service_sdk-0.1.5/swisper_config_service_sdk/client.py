"""Async HTTP client for the Config Service."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import Any

import httpx
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from .exceptions import (
    ConfigNotFoundError,
    ConfigServiceError,
    ConfigServiceTimeoutError,
    ConfigServiceUnavailableError,
    ConfigValidationError,
)
from .models import (
    ConfigurationItem,
    ConfigurationUpsertRequest,
    ConfigurationWithSource,
    HealthStatus,
    ModelSchemaItem,
    ModelSchemaUpsertRequest,
    OverrideItem,
    OverrideUpsertRequest,
    ReadyStatus,
)
from .settings import ConfigServiceSettings, config_service_settings

logger = logging.getLogger(__name__)


class ConfigServiceClient:
    """Async HTTP client for the Config Service.

    This client provides methods to interact with the Config Service API,
    supporting hierarchical configuration with global, agent, and node levels.

    The client automatically loads all configurations into a local cache on
    connect() and refreshes the cache transparently when read operations are
    performed after the refresh cooldown period (default 2 minutes).

    Usage:
        async with ConfigServiceClient() as client:
            config = await client.get("my-config")
            value = await client.get_value("my-config", default="fallback")
    """

    def __init__(
        self,
        settings: ConfigServiceSettings | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._settings = settings or config_service_settings
        self._client = http_client
        self._owns_client = http_client is None

        # Local cache: {key: value} - all configs loaded from DB
        self._cache: dict[str, str | None] = {}
        # Blob cache: stores full override dicts keyed by "agent:{agent_id}" or "node:{agent_id}:{node_id}"
        self._override_blobs: dict[str, dict[str, str]] = {}
        # Provider cache: keyed same as _override_blobs
        self._override_providers: dict[str, str | None] = {}
        # Route cache: keyed same as _override_blobs
        self._override_routes: dict[str, str | None] = {}
        self._last_refresh: datetime | None = None
        self._refresh_cooldown = timedelta(seconds=self._settings.refresh_cooldown_seconds)
        self._refresh_lock = asyncio.Lock()
        self._background_refresh_task: asyncio.Task[None] | None = None

    async def connect(self) -> None:
        """Initialize the HTTP client and load all configurations."""
        if self._client is None:
            timeout = httpx.Timeout(
                self._settings.timeout,
                connect=self._settings.connect_timeout,
            )
            self._client = httpx.AsyncClient(
                base_url=self._settings.url,
                timeout=timeout,
            )

        # Load all configurations into cache on connect
        await self._refresh_cache()

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._background_refresh_task is not None and not self._background_refresh_task.done():
            self._background_refresh_task.cancel()
            self._background_refresh_task = None
        if self._client is not None and self._owns_client:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "ConfigServiceClient":
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        await self.close()

    @property
    def _api_url(self) -> str:
        return self._settings.api_prefix

    # ==================== Cache Methods ====================

    async def _refresh_cache(self) -> None:
        """Fetch all configurations from the config service and update cache.

        1. Fetches global configs from GET /configurations -> store as {name: value}
        2. Fetches override blobs from GET /overrides -> expand into flat cache entries
        """
        async with self._refresh_lock:
            try:
                new_cache: dict[str, str | None] = {}
                new_blobs: dict[str, dict[str, str]] = {}
                new_providers: dict[str, str | None] = {}
                new_routes: dict[str, str | None] = {}

                # 1. Fetch global configs (paginated)
                skip = 0
                limit = 1000
                while True:
                    configs = await self._list_configs_internal(skip=skip, limit=limit)
                    for config in configs:
                        new_cache[config.name] = config.value
                    if len(configs) < limit:
                        break
                    skip += limit

                # 2. Fetch override blobs (paginated)
                skip = 0
                while True:
                    overrides = await self._list_overrides_internal(skip=skip, limit=limit)
                    for override in overrides:
                        if override.node_id:
                            blob_key = f"node:{override.agent_id}:{override.node_id}"
                        else:
                            blob_key = f"agent:{override.agent_id}"
                        new_blobs[blob_key] = dict(override.value)
                        new_providers[blob_key] = override.provider
                        new_routes[blob_key] = override.route
                    if len(overrides) < limit:
                        break
                    skip += limit

                # Atomic swap — readers see either fully old or fully new state
                self._cache = new_cache
                self._override_blobs = new_blobs
                self._override_providers = new_providers
                self._override_routes = new_routes

                self._last_refresh = datetime.now()
                cache_hash = hashlib.md5(
                    json.dumps(dict(sorted(self._cache.items())), sort_keys=True).encode()
                ).hexdigest()[:12]
                logger.info(f"Config cache refreshed: {len(self._cache)} entries loaded [hash={cache_hash}]")

            except Exception as e:
                logger.error(f"Failed to refresh config cache: {e}")
                raise

    def get_override_blob(
        self,
        agent_id: str,
        node_id: str | None = None,
    ) -> dict[str, str] | None:
        """Get the override blob for an exact (agent_id, node_id) pair.

        Returns the raw blob or None. No cross-level merging.
        """
        self._maybe_trigger_background_refresh()
        if node_id:
            key = f"node:{agent_id}:{node_id}"
        else:
            key = f"agent:{agent_id}"
        return self._override_blobs.get(key)

    def get_override_provider(
        self,
        agent_id: str,
        node_id: str | None = None,
    ) -> str | None:
        """Get the provider for an exact (agent_id, node_id) override.

        Returns the provider string or None (no override / NULL provider).
        """
        self._maybe_trigger_background_refresh()
        if node_id:
            key = f"node:{agent_id}:{node_id}"
        else:
            key = f"agent:{agent_id}"
        return self._override_providers.get(key)

    def get_override_route(
        self,
        agent_id: str,
        node_id: str | None = None,
    ) -> str | None:
        """Get the route for an exact (agent_id, node_id) override.

        Returns the route string or None (no override / NULL route).
        """
        self._maybe_trigger_background_refresh()
        if node_id:
            key = f"node:{agent_id}:{node_id}"
        else:
            key = f"agent:{agent_id}"
        return self._override_routes.get(key)

    def _should_refresh(self) -> bool:
        if self._last_refresh is None:
            return True
        return datetime.now() - self._last_refresh >= self._refresh_cooldown

    def _maybe_trigger_background_refresh(self) -> None:
        """Schedule a background cache refresh if stale and not already running."""
        if self._client is None or not self._should_refresh():
            return
        if self._background_refresh_task is not None and not self._background_refresh_task.done():
            return
        try:
            loop = asyncio.get_running_loop()
            self._background_refresh_task = loop.create_task(self._refresh_cache())
        except RuntimeError:
            pass  # No running event loop

    async def _ensure_fresh_cache(self) -> None:
        if self._should_refresh():
            await self._refresh_cache()

    async def refresh_cache(self) -> int:
        """Force refresh the cache from config service."""
        await self._refresh_cache()
        return len(self._cache)

    def get_cached_value(self, name: str, default: str | None = None) -> str | None:
        """Get a value from cache only (synchronous)."""
        self._maybe_trigger_background_refresh()
        if name in self._cache:
            value = self._cache[name]
            return value if value is not None else default
        return default

    def _set_cache(self, name: str, value: str) -> None:
        """Set a value directly in the local cache (synchronous)."""
        self._cache[name] = value

    def get_resolved_cached_value(
        self,
        name: str,
        agent_id: str | None = None,
        node_id: str | None = None,
        default: str | None = None,
    ) -> str | None:
        """Get a value from cache with hierarchical resolution (synchronous).

        Resolves in order: node -> agent -> global -> default.
        """
        self._maybe_trigger_background_refresh()
        # Try node-level first
        if node_id and agent_id:
            key = f"node:{agent_id}:{node_id}:{name}"
            if key in self._cache:
                value = self._cache[key]
                return value if value is not None else default

        # Try agent-level
        if agent_id:
            key = f"agent:{agent_id}:{name}"
            if key in self._cache:
                value = self._cache[key]
                return value if value is not None else default

        # Try global
        if name in self._cache:
            value = self._cache[name]
            return value if value is not None else default

        return default

    def _create_retry_decorator(self) -> Any:
        return retry(
            stop=stop_after_attempt(self._settings.max_retries),
            wait=wait_exponential(
                multiplier=self._settings.retry_backoff_multiplier,
                min=self._settings.retry_backoff_min,
                max=self._settings.retry_backoff_max,
            ),
            retry=retry_if_exception_type((
                httpx.TimeoutException,
                httpx.ConnectError,
            )),
            before_sleep=before_sleep_log(logger, logging.WARNING),
            reraise=True,
        )

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        if self._client is None:
            raise ConfigServiceError(
                "Client not connected. Use 'async with' or call connect() first."
            )

        try:
            response = await self._client.request(method, path, **kwargs)
            return response
        except httpx.TimeoutException as e:
            raise ConfigServiceTimeoutError(str(e)) from e
        except httpx.ConnectError as e:
            raise ConfigServiceUnavailableError(str(e)) from e
        except httpx.HTTPError as e:
            raise ConfigServiceError(str(e)) from e

    def _handle_error_response(
        self,
        response: httpx.Response,
        name: str | None = None,
        agent_id: str | None = None,
        node_id: str | None = None,
    ) -> None:
        if response.status_code == 404:
            raise ConfigNotFoundError(name or "unknown", agent_id, node_id)

        if response.status_code in (400, 422):
            try:
                data = response.json()
                detail = data.get("detail", response.text)
            except Exception:
                detail = response.text
            raise ConfigValidationError(str(detail))

        if response.status_code >= 500:
            raise ConfigServiceUnavailableError(
                f"Service error: {response.status_code} - {response.text}"
            )

        raise ConfigServiceError(
            f"Unexpected response: {response.status_code} - {response.text}"
        )

    # ==================== Configuration API ====================

    async def get(
        self,
        name: str,
        *,
        agent_id: str | None = None,
        node_id: str | None = None,
    ) -> ConfigurationWithSource:
        """Get a configuration by name with hierarchical fallback via resolve endpoint."""
        await self._ensure_fresh_cache()

        # For any resolution request, use the resolve endpoint
        params: dict[str, Any] = {}
        if agent_id:
            params["agent_id"] = agent_id
        if node_id:
            params["node_id"] = node_id

        response = await self._request(
            "GET",
            f"{self._api_url}/configurations/resolve/{name}",
            params=params,
        )

        if response.status_code != 200:
            self._handle_error_response(response, name, agent_id, node_id)

        return ConfigurationWithSource.model_validate(response.json())

    async def get_value(
        self,
        name: str,
        *,
        agent_id: str | None = None,
        node_id: str | None = None,
        default: str | None = None,
    ) -> str | None:
        """Get just the value of a configuration (convenience method)."""
        try:
            config = await self.get(name, agent_id=agent_id, node_id=node_id)
            return config.value
        except ConfigNotFoundError:
            return default

    async def _list_configs_internal(
        self,
        *,
        skip: int = 0,
        limit: int = 100,
    ) -> list[ConfigurationItem]:
        """Internal: list global configs without triggering cache refresh."""
        params: dict[str, Any] = {"skip": skip, "limit": limit}

        response = await self._request(
            "GET",
            f"{self._api_url}/configurations",
            params=params,
        )

        if response.status_code != 200:
            self._handle_error_response(response)

        return [ConfigurationItem.model_validate(item) for item in response.json()]

    async def _list_overrides_internal(
        self,
        *,
        skip: int = 0,
        limit: int = 100,
        agent_id: str | None = None,
        node_id: str | None = None,
    ) -> list[OverrideItem]:
        """Internal: list override blobs without triggering cache refresh."""
        params: dict[str, Any] = {"skip": skip, "limit": limit}
        if agent_id:
            params["agent_id"] = agent_id
        if node_id:
            params["node_id"] = node_id

        response = await self._request(
            "GET",
            f"{self._api_url}/overrides",
            params=params,
        )

        if response.status_code != 200:
            self._handle_error_response(response)

        return [OverrideItem.model_validate(item) for item in response.json()]

    async def list(
        self,
        *,
        skip: int = 0,
        limit: int = 100,
    ) -> list[ConfigurationItem]:
        """List all global configurations."""
        await self._ensure_fresh_cache()
        return await self._list_configs_internal(skip=skip, limit=limit)

    async def list_overrides(
        self,
        *,
        skip: int = 0,
        limit: int = 100,
        agent_id: str | None = None,
        node_id: str | None = None,
    ) -> list[OverrideItem]:
        """List override blobs with optional filtering."""
        await self._ensure_fresh_cache()
        return await self._list_overrides_internal(
            skip=skip, limit=limit, agent_id=agent_id, node_id=node_id
        )

    async def upsert(
        self,
        name: str,
        value: str,
    ) -> ConfigurationItem:
        """Create or update a global configuration."""
        request = ConfigurationUpsertRequest(name=name, value=value)

        response = await self._request(
            "POST",
            f"{self._api_url}/configurations",
            json=request.model_dump(exclude_none=True),
        )

        if response.status_code != 200:
            self._handle_error_response(response, name)

        result = ConfigurationItem.model_validate(response.json())

        # Update local cache
        self._cache[name] = value

        return result

    async def upsert_override(
        self,
        agent_id: str,
        value: dict[str, Any],
        *,
        node_id: str | None = None,
        provider: str | None = None,
        route: str | None = None,
        description: str | None = None,
    ) -> OverrideItem:
        """Create or update an override blob.

        Args:
            agent_id: Agent identifier.
            value: Dict of config key-value pairs.
            node_id: Optional node identifier (None = agent-level).
            provider: Optional LLM provider override (e.g. 'vertex', 'azure').
            route: Optional dispatch route (e.g. 'vertex-gemini', 'kvant').
            description: Optional human-readable description.

        Returns:
            The created/updated OverrideItem.
        """
        request = OverrideUpsertRequest(
            agent_id=agent_id, node_id=node_id, value=value,
            provider=provider, route=route, description=description,
        )

        response = await self._request(
            "POST",
            f"{self._api_url}/overrides",
            json=request.model_dump(exclude_none=True),
        )

        if response.status_code != 200:
            self._handle_error_response(response, agent_id=agent_id, node_id=node_id)

        result = OverrideItem.model_validate(response.json())

        # Update blob and provider caches
        if result.node_id:
            blob_key = f"node:{result.agent_id}:{result.node_id}"
        else:
            blob_key = f"agent:{result.agent_id}"
        self._override_blobs[blob_key] = dict(result.value)
        self._override_providers[blob_key] = result.provider
        self._override_routes[blob_key] = result.route

        return result

    async def delete(self, name: str) -> bool:
        """Delete a global configuration."""
        response = await self._request(
            "DELETE",
            f"{self._api_url}/configurations/{name}",
        )

        if response.status_code == 204:
            self._cache.pop(name, None)
            return True

        self._handle_error_response(response, name)
        return False  # Never reached

    async def delete_override(
        self, agent_id: str, *, node_id: str | None = None
    ) -> bool:
        """Delete an override blob."""
        params: dict[str, Any] = {}
        if node_id:
            params["node_id"] = node_id

        response = await self._request(
            "DELETE",
            f"{self._api_url}/overrides/{agent_id}",
            params=params,
        )

        if response.status_code == 204:
            return True

        self._handle_error_response(response, agent_id=agent_id, node_id=node_id)
        return False  # Never reached

    # ==================== Schema API ====================

    async def upsert_schema(
        self,
        provider: str,
        route: str,
        json_schema: dict[str, Any],
        *,
        ui_schema: dict[str, Any] | None = None,
    ) -> ModelSchemaItem:
        """Create or update a model schema."""
        request = ModelSchemaUpsertRequest(
            provider=provider, route=route,
            json_schema=json_schema, ui_schema=ui_schema,
        )

        response = await self._request(
            "POST",
            f"{self._api_url}/schemas",
            json=request.model_dump(exclude_none=True),
        )

        if response.status_code != 200:
            self._handle_error_response(response)

        return ModelSchemaItem.model_validate(response.json())

    async def get_schema(
        self,
        provider: str,
        route: str,
    ) -> ModelSchemaItem:
        """Get a model schema by (provider, route)."""
        response = await self._request(
            "GET",
            f"{self._api_url}/schemas/{provider}/{route}",
        )

        if response.status_code != 200:
            self._handle_error_response(response)

        return ModelSchemaItem.model_validate(response.json())

    async def list_schemas(
        self,
        *,
        provider: str | None = None,
        route: str | None = None,
        skip: int = 0,
        limit: int = 100,
    ) -> list[ModelSchemaItem]:
        """List model schemas with optional filtering."""
        params: dict[str, Any] = {"skip": skip, "limit": limit}
        if provider:
            params["provider"] = provider
        if route:
            params["route"] = route

        response = await self._request(
            "GET",
            f"{self._api_url}/schemas",
            params=params,
        )

        if response.status_code != 200:
            self._handle_error_response(response)

        return [ModelSchemaItem.model_validate(item) for item in response.json()]

    async def delete_schema(
        self,
        provider: str,
        route: str,
    ) -> bool:
        """Delete a model schema by (provider, route)."""
        response = await self._request(
            "DELETE",
            f"{self._api_url}/schemas/{provider}/{route}",
        )

        if response.status_code == 204:
            return True

        self._handle_error_response(response)
        return False  # Never reached

    # ==================== Health Checks ====================

    async def health(self) -> HealthStatus:
        response = await self._request("GET", "/health")
        if response.status_code != 200:
            raise ConfigServiceUnavailableError(
                f"Health check failed: {response.status_code}"
            )
        return HealthStatus.model_validate(response.json())

    async def ready(self) -> ReadyStatus:
        response = await self._request("GET", "/ready")
        if response.status_code != 200:
            raise ConfigServiceUnavailableError(
                f"Readiness check failed: {response.status_code}"
            )
        return ReadyStatus.model_validate(response.json())

    async def is_healthy(self) -> bool:
        try:
            await self.health()
            return True
        except ConfigServiceError:
            return False


# ==================== Factory Functions ====================


@asynccontextmanager
async def get_config_client(
    settings: ConfigServiceSettings | None = None,
) -> AsyncGenerator[ConfigServiceClient, None]:
    async with ConfigServiceClient(settings=settings) as client:
        yield client


# Singleton instance for dependency injection scenarios
_shared_client: ConfigServiceClient | None = None


async def get_shared_client() -> ConfigServiceClient:
    global _shared_client
    if _shared_client is None:
        _shared_client = ConfigServiceClient()
    return _shared_client


async def connect_shared_client(
    settings: ConfigServiceSettings | None = None,
) -> None:
    global _shared_client
    if _shared_client is None:
        _shared_client = ConfigServiceClient(settings=settings)
    await _shared_client.connect()


async def close_shared_client() -> None:
    global _shared_client
    if _shared_client is not None:
        await _shared_client.close()
        _shared_client = None
