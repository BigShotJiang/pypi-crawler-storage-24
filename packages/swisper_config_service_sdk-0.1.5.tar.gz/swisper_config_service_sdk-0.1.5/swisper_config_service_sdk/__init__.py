"""Config Service SDK - Python client for the Config Service API.

This SDK provides a type-safe async client for interacting with the Config Service,
supporting hierarchical configuration with global, agent, and node levels.

Basic Usage:
    from swisper_config_service_sdk import ConfigServiceClient

    async with ConfigServiceClient() as client:
        # Get with hierarchical fallback
        config = await client.get("feature-flag", agent_id="agent-1")
        print(f"Value: {config.value}, Source: {config.source}")

        # Convenience method with default
        value = await client.get_value("timeout", default="30")

        # Create/update global config
        await client.upsert("feature-flag", "enabled")

        # Create/update override blob
        await client.upsert_override("agent-1", {"temperature": "0.5"}, node_id="planner")

Custom Configuration:
    from swisper_config_service_sdk import ConfigServiceClient, ConfigServiceSettings

    settings = ConfigServiceSettings(
        url="http://config-service:8090",
        timeout=60.0,
    )

    async with ConfigServiceClient(settings=settings) as client:
        ...

Environment Variables:
    CONFIG_SERVICE_URL - Base URL (default: http://localhost:8090)
    CONFIG_SERVICE_TIMEOUT - Request timeout in seconds (default: 30.0)
    CONFIG_SERVICE_MAX_RETRIES - Max retry attempts (default: 3)
    CONFIG_SERVICE_REFRESH_COOLDOWN_SECONDS - Min time between cache refreshes (default: 120)

Caching:
    The SDK automatically loads ALL configurations from the database on connect()
    and refreshes the cache transparently when read operations are performed
    after the refresh cooldown period (default 2 minutes).

    # Sync access to cached values (for __init__ methods, etc.)
    value = client.get_cached_value("config1", default="fallback")

    # Async access with automatic cache refresh
    value = await client.get_value("config1", default="fallback")
"""

from .client import (
    ConfigServiceClient,
    close_shared_client,
    connect_shared_client,
    get_config_client,
    get_shared_client,
)
from .exceptions import (
    ConfigNotFoundError,
    ConfigServiceError,
    ConfigServiceTimeoutError,
    ConfigServiceUnavailableError,
    ConfigValidationError,
)
from .models import (
    ConfigurationItem,
    ConfigurationUpsertRequest,
    ConfigurationWithSource,
    HealthStatus,
    ModelSchemaItem,
    ModelSchemaUpsertRequest,
    OverrideItem,
    OverrideUpsertRequest,
    ReadyStatus,
)
from .settings import ConfigServiceSettings, config_service_settings

__version__ = "0.1.3"

__all__ = [
    # Version
    "__version__",
    # Client
    "ConfigServiceClient",
    "get_config_client",
    "get_shared_client",
    "connect_shared_client",
    "close_shared_client",
    # Exceptions
    "ConfigServiceError",
    "ConfigNotFoundError",
    "ConfigValidationError",
    "ConfigServiceUnavailableError",
    "ConfigServiceTimeoutError",
    # Models
    "ConfigurationItem",
    "ConfigurationUpsertRequest",
    "ConfigurationWithSource",
    "OverrideItem",
    "OverrideUpsertRequest",
    "ModelSchemaUpsertRequest",
    "ModelSchemaItem",
    "HealthStatus",
    "ReadyStatus",
    # Settings
    "ConfigServiceSettings",
    "config_service_settings",
]
