"""Custom exceptions for the Config Service SDK."""


class ConfigServiceError(Exception):
    """Base exception for all config service errors."""

    pass


class ConfigNotFoundError(ConfigServiceError):
    """Raised when a configuration is not found (HTTP 404)."""

    def __init__(
        self,
        name: str,
        agent_id: str | None = None,
        node_id: str | None = None,
    ) -> None:
        self.name = name
        self.agent_id = agent_id
        self.node_id = node_id

        parts = [f"Configuration '{name}' not found"]
        if agent_id:
            parts.append(f"agent_id={agent_id}")
        if node_id:
            parts.append(f"node_id={node_id}")

        super().__init__(" ".join(parts))


class ConfigValidationError(ConfigServiceError):
    """Raised when request validation fails (HTTP 400/422)."""

    def __init__(self, detail: str) -> None:
        self.detail = detail
        super().__init__(f"Validation error: {detail}")


class ConfigServiceUnavailableError(ConfigServiceError):
    """Raised when the config service is unavailable (connection error or HTTP 5xx)."""

    def __init__(self, message: str = "Config service unavailable") -> None:
        super().__init__(message)


class ConfigServiceTimeoutError(ConfigServiceError):
    """Raised when a request to the config service times out."""

    def __init__(self, message: str = "Config service request timed out") -> None:
        super().__init__(message)
