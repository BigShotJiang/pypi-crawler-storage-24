"""Pydantic models for Config Service SDK requests and responses."""

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

# Standalone type matching ProviderType values — avoids cross-package dependency
# on llm_adapter (the SDK is a standalone package).
ProviderLiteral = Literal["vertex", "azure", "kvant", "gemini", "claude"]


# ==================== Global Configuration Models ====================


class ConfigurationUpsertRequest(BaseModel):
    """Request model for creating or updating a global configuration."""

    name: str = Field(..., min_length=1, max_length=255, description="Configuration key name")
    value: str = Field(..., description="Configuration value")

    @field_validator("name", mode="after")
    @classmethod
    def reject_colon(cls, v: str) -> str:
        if ":" in v:
            raise ValueError("colons are not allowed (reserved as cache key separator)")
        return v


class ConfigurationItem(BaseModel):
    """Global configuration item returned from list and upsert endpoints."""

    id: int
    name: str
    value: str | None
    created_at: datetime
    updated_at: datetime


class ConfigurationWithSource(BaseModel):
    """Configuration with source information from resolve endpoint."""

    id: int
    name: str
    value: str | None
    source: Literal["base", "agent", "node", "cache"]
    agent_id: str | None = None
    node_id: str | None = None


# ==================== Override Models ====================


class OverrideUpsertRequest(BaseModel):
    """Request model for upserting an override blob."""

    agent_id: str = Field(..., min_length=1, max_length=255, description="Agent identifier")
    node_id: str | None = Field(
        default=None, min_length=1, max_length=255,
        description="Node identifier (NULL = agent-level override)",
    )
    value: dict[str, Any] = Field(
        ..., description="JSONB blob of config key-value pairs"
    )
    provider: ProviderLiteral | None = Field(
        default=None,
        description="LLM provider override (e.g. 'vertex', 'azure', 'kvant'). NULL = inherit.",
    )
    route: str | None = Field(
        default=None,
        max_length=100,
        description="Dispatch route (e.g. 'vertex-gemini', 'kvant'). NULL = inherit.",
    )
    description: str | None = Field(
        default=None,
        description="Human-readable description of this override",
    )

    @field_validator("agent_id", "node_id", mode="after")
    @classmethod
    def reject_colon(cls, v: str | None) -> str | None:
        if v is not None and ":" in v:
            raise ValueError("colons are not allowed (reserved as cache key separator)")
        return v


class OverrideItem(BaseModel):
    """Override blob returned from override endpoints."""

    id: int
    agent_id: str
    node_id: str | None
    value: dict[str, Any]
    provider: str | None = None
    route: str | None = None
    description: str | None = None
    created_at: datetime
    updated_at: datetime


# ==================== Model Schema Models ====================


class ModelSchemaUpsertRequest(BaseModel):
    """Request model for upserting a model schema."""

    provider: ProviderLiteral = Field(..., description="LLM provider")
    route: str = Field(..., min_length=1, max_length=100, description="Provider-route key (e.g. 'vertex-gemini')")
    json_schema: dict[str, Any] = Field(
        ..., description="rjsf-compatible JSON Schema for validation"
    )
    ui_schema: dict[str, Any] | None = Field(
        default=None, description="rjsf ui:schema for form rendering hints"
    )


class ModelSchemaItem(BaseModel):
    """Model schema returned from schema endpoints."""

    id: int
    provider: str
    route: str
    json_schema: dict[str, Any]
    ui_schema: dict[str, Any] | None = None
    created_at: datetime
    updated_at: datetime


# ==================== Health Models ====================


class HealthStatus(BaseModel):
    """Response from the health endpoint."""

    status: str
    service: str
    environment: str | None = None


class ReadyStatus(BaseModel):
    """Response from the readiness endpoint."""

    status: str
    service: str
    redis: str | None = None
