"""Configuration settings for the Config Service SDK."""

from pydantic_settings import BaseSettings, SettingsConfigDict


class ConfigServiceSettings(BaseSettings):
    """Settings for the Config Service SDK.

    All settings can be configured via environment variables with the
    `CONFIG_SERVICE_` prefix.

    Example:
        export CONFIG_SERVICE_URL=http://config-service:8090
        export CONFIG_SERVICE_TIMEOUT=60.0
        export CONFIG_SERVICE_MAX_RETRIES=5
        export CONFIG_SERVICE_CACHE_TTL_SECONDS=120
    """

    model_config = SettingsConfigDict(
        env_prefix="CONFIG_SERVICE_",
        env_ignore_empty=True,
        extra="ignore",
    )

    # Base URL for the config service
    url: str = "http://localhost:8090"

    # Request timeout in seconds
    timeout: float = 30.0

    # Connection timeout in seconds
    connect_timeout: float = 5.0

    # Maximum number of retry attempts for transient failures
    max_retries: int = 3

    # Exponential backoff multiplier for retries
    retry_backoff_multiplier: float = 1.0

    # Minimum backoff time in seconds
    retry_backoff_min: float = 1.0

    # Maximum backoff time in seconds
    retry_backoff_max: float = 10.0

    # API version prefix
    api_prefix: str = "/api/v1"

    # Local cache TTL in seconds (default 2 minutes)
    cache_ttl_seconds: int = 120

    # Refresh cooldown in seconds - minimum time between full cache refreshes (default 2 minutes)
    refresh_cooldown_seconds: int = 120


# Default settings instance
config_service_settings = ConfigServiceSettings()
