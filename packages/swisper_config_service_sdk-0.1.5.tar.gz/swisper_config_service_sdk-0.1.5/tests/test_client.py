"""Unit tests for ConfigServiceClient with mocked HTTP responses."""

import pytest
import httpx
import respx
from datetime import datetime, timezone

from swisper_config_service_sdk import (
    ConfigServiceClient,
    ConfigServiceSettings,
    ConfigNotFoundError,
    ConfigValidationError,
    ConfigServiceUnavailableError,
    ConfigServiceTimeoutError,
)


@pytest.fixture
def settings() -> ConfigServiceSettings:
    """Create test settings."""
    return ConfigServiceSettings(
        url="http://test-config-service:8090",
        timeout=5.0,
        max_retries=1,
    )


@pytest.fixture
def mock_config_response() -> dict:
    """Sample configuration response."""
    return {
        "id": 1,
        "name": "test-config",
        "value": "test-value",
        "source": "base",
        "agent_id": None,
        "node_id": None,
    }


@pytest.fixture
def mock_config_item() -> dict:
    """Sample configuration item."""
    now = datetime.now(timezone.utc).isoformat()
    return {
        "id": 1,
        "name": "test-config",
        "value": "test-value",
        "agent_id": None,
        "node_id": None,
        "created_at": now,
        "updated_at": now,
    }


class TestConfigServiceClient:
    """Tests for ConfigServiceClient."""

    @respx.mock
    async def test_get_returns_config(
        self, settings: ConfigServiceSettings, mock_config_response: dict
    ) -> None:
        """Test get() returns configuration with source."""
        respx.get(
            "http://test-config-service:8090/api/v1/configurations/test-config"
        ).mock(return_value=httpx.Response(200, json=mock_config_response))

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.get("test-config")

        assert result.name == "test-config"
        assert result.value == "test-value"
        assert result.source == "base"

    @respx.mock
    async def test_get_with_agent_id(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test get() with agent_id parameter."""
        response_data = {
            "id": 2,
            "name": "test-config",
            "value": "agent-value",
            "source": "agent",
            "agent_id": "agent-123",
            "node_id": None,
        }
        respx.get(
            "http://test-config-service:8090/api/v1/configurations/test-config",
            params={"agent_id": "agent-123"},
        ).mock(return_value=httpx.Response(200, json=response_data))

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.get("test-config", agent_id="agent-123")

        assert result.value == "agent-value"
        assert result.source == "agent"
        assert result.agent_id == "agent-123"

    @respx.mock
    async def test_get_raises_not_found(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test get() raises ConfigNotFoundError on 404."""
        respx.get(
            "http://test-config-service:8090/api/v1/configurations/missing"
        ).mock(return_value=httpx.Response(404, json={"detail": "Not found"}))

        async with ConfigServiceClient(settings=settings) as client:
            with pytest.raises(ConfigNotFoundError) as exc_info:
                await client.get("missing")

        assert exc_info.value.name == "missing"

    @respx.mock
    async def test_get_value_returns_value(
        self, settings: ConfigServiceSettings, mock_config_response: dict
    ) -> None:
        """Test get_value() returns just the value."""
        respx.get(
            "http://test-config-service:8090/api/v1/configurations/test-config"
        ).mock(return_value=httpx.Response(200, json=mock_config_response))

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.get_value("test-config")

        assert result == "test-value"

    @respx.mock
    async def test_get_value_returns_default_on_not_found(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test get_value() returns default when not found."""
        respx.get(
            "http://test-config-service:8090/api/v1/configurations/missing"
        ).mock(return_value=httpx.Response(404, json={"detail": "Not found"}))

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.get_value("missing", default="fallback")

        assert result == "fallback"

    @respx.mock
    async def test_upsert_creates_config(
        self, settings: ConfigServiceSettings, mock_config_item: dict
    ) -> None:
        """Test upsert() creates a configuration."""
        respx.post(
            "http://test-config-service:8090/api/v1/configurations"
        ).mock(return_value=httpx.Response(200, json=mock_config_item))

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.upsert("test-config", "test-value")

        assert result.name == "test-config"
        assert result.value == "test-value"

    @respx.mock
    async def test_upsert_with_agent_and_node(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test upsert() with agent_id and node_id."""
        now = datetime.now(timezone.utc).isoformat()
        response_data = {
            "id": 3,
            "name": "test-config",
            "value": "node-value",
            "agent_id": "agent-123",
            "node_id": "node-456",
            "created_at": now,
            "updated_at": now,
        }
        route = respx.post(
            "http://test-config-service:8090/api/v1/configurations"
        ).mock(return_value=httpx.Response(200, json=response_data))

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.upsert(
                "test-config",
                "node-value",
                agent_id="agent-123",
                node_id="node-456",
            )

        assert result.agent_id == "agent-123"
        assert result.node_id == "node-456"

        # Verify request body
        request = route.calls.last.request
        import json
        body = json.loads(request.content)
        assert body["name"] == "test-config"
        assert body["value"] == "node-value"
        assert body["agent_id"] == "agent-123"
        assert body["node_id"] == "node-456"

    @respx.mock
    async def test_upsert_raises_validation_error(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test upsert() raises ConfigValidationError on 422."""
        respx.post(
            "http://test-config-service:8090/api/v1/configurations"
        ).mock(return_value=httpx.Response(422, json={"detail": "Invalid value"}))

        async with ConfigServiceClient(settings=settings) as client:
            with pytest.raises(ConfigValidationError) as exc_info:
                await client.upsert("test", "value")

        assert "Invalid value" in exc_info.value.detail

    @respx.mock
    async def test_list_returns_configs(
        self, settings: ConfigServiceSettings, mock_config_item: dict
    ) -> None:
        """Test list() returns list of configurations."""
        respx.get(
            "http://test-config-service:8090/api/v1/configurations",
            params={"skip": 0, "limit": 100},
        ).mock(return_value=httpx.Response(200, json=[mock_config_item]))

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.list()

        assert len(result) == 1
        assert result[0].name == "test-config"

    @respx.mock
    async def test_list_with_filters(
        self, settings: ConfigServiceSettings, mock_config_item: dict
    ) -> None:
        """Test list() with agent_id filter."""
        respx.get(
            "http://test-config-service:8090/api/v1/configurations",
            params={"skip": 0, "limit": 50, "agent_id": "agent-123"},
        ).mock(return_value=httpx.Response(200, json=[mock_config_item]))

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.list(limit=50, agent_id="agent-123")

        assert len(result) == 1

    @respx.mock
    async def test_delete_returns_true(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test delete() returns True on success."""
        respx.delete(
            "http://test-config-service:8090/api/v1/configurations/test-config"
        ).mock(return_value=httpx.Response(204))

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.delete("test-config")

        assert result is True

    @respx.mock
    async def test_delete_raises_not_found(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test delete() raises ConfigNotFoundError on 404."""
        respx.delete(
            "http://test-config-service:8090/api/v1/configurations/missing"
        ).mock(return_value=httpx.Response(404, json={"detail": "Not found"}))

        async with ConfigServiceClient(settings=settings) as client:
            with pytest.raises(ConfigNotFoundError):
                await client.delete("missing")

    @respx.mock
    async def test_health_returns_status(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test health() returns HealthStatus."""
        respx.get("http://test-config-service:8090/health").mock(
            return_value=httpx.Response(
                200,
                json={"status": "ok", "service": "config-service", "environment": "test"},
            )
        )

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.health()

        assert result.status == "ok"
        assert result.service == "config-service"

    @respx.mock
    async def test_ready_returns_status(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test ready() returns ReadyStatus."""
        respx.get("http://test-config-service:8090/ready").mock(
            return_value=httpx.Response(
                200,
                json={"status": "ok", "service": "config-service"},
            )
        )

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.ready()

        assert result.status == "ok"
        assert result.redis is None

    @respx.mock
    async def test_is_healthy_returns_true(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test is_healthy() returns True when healthy."""
        respx.get("http://test-config-service:8090/health").mock(
            return_value=httpx.Response(
                200,
                json={"status": "ok", "service": "config-service"},
            )
        )

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.is_healthy()

        assert result is True

    @respx.mock
    async def test_is_healthy_returns_false_on_error(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test is_healthy() returns False on error."""
        respx.get("http://test-config-service:8090/health").mock(
            return_value=httpx.Response(500, json={"detail": "Error"})
        )

        async with ConfigServiceClient(settings=settings) as client:
            result = await client.is_healthy()

        assert result is False

    @respx.mock
    async def test_service_unavailable_on_5xx(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test 5xx responses raise ConfigServiceUnavailableError."""
        respx.get(
            "http://test-config-service:8090/api/v1/configurations/test"
        ).mock(return_value=httpx.Response(503, text="Service Unavailable"))

        async with ConfigServiceClient(settings=settings) as client:
            with pytest.raises(ConfigServiceUnavailableError):
                await client.get("test")


class TestClientLifecycle:
    """Tests for client lifecycle management."""

    async def test_client_not_connected_error(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test error when client is not connected."""
        client = ConfigServiceClient(settings=settings)
        # Don't call connect()

        from swisper_config_service_sdk.exceptions import ConfigServiceError
        with pytest.raises(ConfigServiceError, match="not connected"):
            await client.get("test")

    @respx.mock
    async def test_context_manager_connects_and_closes(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Test context manager properly connects and closes."""
        respx.get("http://test-config-service:8090/health").mock(
            return_value=httpx.Response(
                200,
                json={"status": "ok", "service": "config-service"},
            )
        )

        async with ConfigServiceClient(settings=settings) as client:
            assert client._client is not None
            await client.health()

        assert client._client is None


class TestModels:
    """Tests for Pydantic models."""

    def test_upsert_request_validates_node_requires_agent(self) -> None:
        """Test that node_id requires agent_id."""
        from swisper_config_service_sdk.models import ConfigurationUpsertRequest

        with pytest.raises(ValueError, match="node_id requires agent_id"):
            ConfigurationUpsertRequest(
                name="test",
                value="value",
                node_id="node-123",
            )

    def test_upsert_request_accepts_valid_data(self) -> None:
        """Test valid upsert request."""
        from swisper_config_service_sdk.models import ConfigurationUpsertRequest

        request = ConfigurationUpsertRequest(
            name="test",
            value="value",
            agent_id="agent-123",
            node_id="node-456",
        )

        assert request.name == "test"
        assert request.agent_id == "agent-123"
        assert request.node_id == "node-456"


class TestResolvedCachedValue:
    """Tests for hierarchical cache key storage and resolution."""

    BASE_URL = "http://test-config-service:8090"
    LIST_URL = f"{BASE_URL}/api/v1/configurations"
    UPSERT_URL = f"{BASE_URL}/api/v1/configurations"

    @staticmethod
    def _make_config_item(
        name: str,
        value: str,
        *,
        item_id: int = 1,
        agent_id: str | None = None,
        node_id: str | None = None,
    ) -> dict:
        now = datetime.now(timezone.utc).isoformat()
        return {
            "id": item_id,
            "name": name,
            "value": value,
            "agent_id": agent_id,
            "node_id": node_id,
            "created_at": now,
            "updated_at": now,
        }

    @respx.mock
    async def test_refresh_cache_stores_hierarchical_keys(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Mock list API to return global + agent + node items; verify cache has correct prefixed keys."""
        items = [
            self._make_config_item("model", "gpt-4", item_id=1),
            self._make_config_item(
                "model", "gpt-3.5", item_id=2, agent_id="a1"
            ),
            self._make_config_item(
                "model", "gpt-4o", item_id=3, agent_id="a1", node_id="n1"
            ),
        ]
        respx.get(self.LIST_URL).mock(
            return_value=httpx.Response(200, json=items)
        )

        async with ConfigServiceClient(settings=settings) as client:
            assert client._cache["model"] == "gpt-4"
            assert client._cache["agent:a1:model"] == "gpt-3.5"
            assert client._cache["node:a1:n1:model"] == "gpt-4o"

    async def test_get_resolved_cached_value_node_wins(
        self, settings: ConfigServiceSettings
    ) -> None:
        """All 3 levels present -> returns node value."""
        client = ConfigServiceClient(settings=settings)
        client._cache = {
            "model": "global-val",
            "agent:a1:model": "agent-val",
            "node:a1:n1:model": "node-val",
        }

        result = client.get_resolved_cached_value(
            "model", agent_id="a1", node_id="n1"
        )
        assert result == "node-val"

    async def test_get_resolved_cached_value_agent_fallback(
        self, settings: ConfigServiceSettings
    ) -> None:
        """No node entry -> returns agent value."""
        client = ConfigServiceClient(settings=settings)
        client._cache = {
            "model": "global-val",
            "agent:a1:model": "agent-val",
        }

        result = client.get_resolved_cached_value(
            "model", agent_id="a1", node_id="n1"
        )
        assert result == "agent-val"

    async def test_get_resolved_cached_value_global_fallback(
        self, settings: ConfigServiceSettings
    ) -> None:
        """No node/agent entries -> returns global value."""
        client = ConfigServiceClient(settings=settings)
        client._cache = {
            "model": "global-val",
        }

        result = client.get_resolved_cached_value(
            "model", agent_id="a1", node_id="n1"
        )
        assert result == "global-val"

    async def test_get_resolved_cached_value_returns_default(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Nothing in cache -> returns default."""
        client = ConfigServiceClient(settings=settings)
        client._cache = {}

        result = client.get_resolved_cached_value(
            "model", agent_id="a1", node_id="n1", default="fallback"
        )
        assert result == "fallback"

    async def test_get_resolved_cached_value_no_agent_id(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Only global in cache, no agent_id param -> returns global."""
        client = ConfigServiceClient(settings=settings)
        client._cache = {
            "model": "global-val",
        }

        result = client.get_resolved_cached_value("model")
        assert result == "global-val"

    @respx.mock
    async def test_upsert_caches_agent_config(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Upsert with agent_id -> cache has agent: prefixed key."""
        item = self._make_config_item(
            "model", "agent-val", item_id=2, agent_id="a1"
        )
        # Mock list endpoint for connect()
        respx.get(self.LIST_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.post(self.UPSERT_URL).mock(
            return_value=httpx.Response(200, json=item)
        )

        async with ConfigServiceClient(settings=settings) as client:
            await client.upsert("model", "agent-val", agent_id="a1")
            assert client._cache["agent:a1:model"] == "agent-val"

    @respx.mock
    async def test_upsert_caches_node_config(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Upsert with agent_id+node_id -> cache has node: prefixed key."""
        item = self._make_config_item(
            "model", "node-val", item_id=3, agent_id="a1", node_id="n1"
        )
        # Mock list endpoint for connect()
        respx.get(self.LIST_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.post(self.UPSERT_URL).mock(
            return_value=httpx.Response(200, json=item)
        )

        async with ConfigServiceClient(settings=settings) as client:
            await client.upsert(
                "model", "node-val", agent_id="a1", node_id="n1"
            )
            assert client._cache["node:a1:n1:model"] == "node-val"


class TestOverrideBlobs:
    """Tests for blob-level cache and get_override_blob()."""

    BASE_URL = "http://test-config-service:8090"
    CONFIGS_URL = f"{BASE_URL}/api/v1/configurations"
    OVERRIDES_URL = f"{BASE_URL}/api/v1/overrides"

    async def test_get_override_blob_node_level_hit(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Node-level blob present -> returns it."""
        client = ConfigServiceClient(settings=settings)
        client._override_blobs = {
            "node:a1:n1": {"model": "gpt-4o", "temperature": "0.5"},
        }

        result = client.get_override_blob(agent_id="a1", node_id="n1")
        assert result == {"model": "gpt-4o", "temperature": "0.5"}

    async def test_get_override_blob_agent_level_hit(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Agent-level blob present -> returns it."""
        client = ConfigServiceClient(settings=settings)
        client._override_blobs = {
            "agent:a1": {"model": "gpt-3.5", "temperature": "0.3"},
        }

        result = client.get_override_blob(agent_id="a1")
        assert result == {"model": "gpt-3.5", "temperature": "0.3"}

    async def test_get_override_blob_miss_returns_none(
        self, settings: ConfigServiceSettings
    ) -> None:
        """No matching blob -> returns None."""
        client = ConfigServiceClient(settings=settings)
        client._override_blobs = {}

        assert client.get_override_blob(agent_id="a1", node_id="n1") is None
        assert client.get_override_blob(agent_id="a1") is None

    async def test_get_override_blob_no_cross_level_merging(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Node-level query does not fall back to agent-level."""
        client = ConfigServiceClient(settings=settings)
        client._override_blobs = {
            "agent:a1": {"model": "agent-model"},
        }

        # Asking for node-level should NOT return the agent-level blob
        assert client.get_override_blob(agent_id="a1", node_id="n1") is None

    @respx.mock
    async def test_refresh_cache_populates_override_blobs(
        self, settings: ConfigServiceSettings
    ) -> None:
        """_refresh_cache stores override blobs alongside flat cache."""
        now = datetime.now(timezone.utc).isoformat()

        respx.get(self.CONFIGS_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.get(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json=[
                {
                    "id": 1,
                    "agent_id": "a1",
                    "node_id": None,
                    "value": {"model": "agent-model", "temperature": "0.3"},
                    "created_at": now,
                    "updated_at": now,
                },
                {
                    "id": 2,
                    "agent_id": "a1",
                    "node_id": "n1",
                    "value": {"model": "node-model"},
                    "created_at": now,
                    "updated_at": now,
                },
            ])
        )

        async with ConfigServiceClient(settings=settings) as client:
            # Blob cache populated
            assert client.get_override_blob(agent_id="a1") == {
                "model": "agent-model",
                "temperature": "0.3",
            }
            assert client.get_override_blob(agent_id="a1", node_id="n1") == {
                "model": "node-model",
            }

    @respx.mock
    async def test_upsert_override_stores_blob(
        self, settings: ConfigServiceSettings
    ) -> None:
        """upsert_override stores the blob in _override_blobs."""
        now = datetime.now(timezone.utc).isoformat()

        respx.get(self.CONFIGS_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.get(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.post(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json={
                "id": 1,
                "agent_id": "a1",
                "node_id": "n1",
                "value": {"model": "new-model", "temperature": "0.9"},
                "created_at": now,
                "updated_at": now,
            })
        )

        async with ConfigServiceClient(settings=settings) as client:
            await client.upsert_override(
                "a1", {"model": "new-model", "temperature": "0.9"}, node_id="n1"
            )
            assert client.get_override_blob(agent_id="a1", node_id="n1") == {
                "model": "new-model",
                "temperature": "0.9",
            }


class TestOverrideProviders:
    """Tests for provider cache and get_override_provider()."""

    async def test_get_override_provider_node_level_hit(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Node-level provider present -> returns it."""
        client = ConfigServiceClient(settings=settings)
        client._override_providers = {
            "node:a1:n1": "azure",
        }

        result = client.get_override_provider(agent_id="a1", node_id="n1")
        assert result == "azure"

    async def test_get_override_provider_agent_level_hit(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Agent-level provider present -> returns it."""
        client = ConfigServiceClient(settings=settings)
        client._override_providers = {
            "agent:a1": "kvant",
        }

        result = client.get_override_provider(agent_id="a1")
        assert result == "kvant"

    async def test_get_override_provider_miss_returns_none(
        self, settings: ConfigServiceSettings
    ) -> None:
        """No matching provider -> returns None."""
        client = ConfigServiceClient(settings=settings)
        client._override_providers = {}

        assert client.get_override_provider(agent_id="a1", node_id="n1") is None
        assert client.get_override_provider(agent_id="a1") is None

    async def test_get_override_provider_null_provider(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Provider stored as None -> returns None."""
        client = ConfigServiceClient(settings=settings)
        client._override_providers = {
            "node:a1:n1": None,
        }

        assert client.get_override_provider(agent_id="a1", node_id="n1") is None

    BASE_URL = "http://test-config-service:8090"
    CONFIGS_URL = f"{BASE_URL}/api/v1/configurations"
    OVERRIDES_URL = f"{BASE_URL}/api/v1/overrides"

    @respx.mock
    async def test_refresh_cache_populates_override_providers(
        self, settings: ConfigServiceSettings
    ) -> None:
        """_refresh_cache stores override providers alongside blobs."""
        now = datetime.now(timezone.utc).isoformat()

        respx.get(self.CONFIGS_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.get(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json=[
                {
                    "id": 1,
                    "agent_id": "a1",
                    "node_id": None,
                    "value": {"model": "agent-model"},
                    "provider": "azure",
                    "created_at": now,
                    "updated_at": now,
                },
                {
                    "id": 2,
                    "agent_id": "a1",
                    "node_id": "n1",
                    "value": {"model": "node-model"},
                    "provider": None,
                    "created_at": now,
                    "updated_at": now,
                },
            ])
        )

        async with ConfigServiceClient(settings=settings) as client:
            assert client.get_override_provider(agent_id="a1") == "azure"
            assert client.get_override_provider(agent_id="a1", node_id="n1") is None

    @respx.mock
    async def test_upsert_override_stores_provider(
        self, settings: ConfigServiceSettings
    ) -> None:
        """upsert_override stores the provider in _override_providers."""
        now = datetime.now(timezone.utc).isoformat()

        respx.get(self.CONFIGS_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.get(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.post(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json={
                "id": 1,
                "agent_id": "a1",
                "node_id": "n1",
                "value": {"model": "new-model"},
                "provider": "kvant",
                "created_at": now,
                "updated_at": now,
            })
        )

        async with ConfigServiceClient(settings=settings) as client:
            await client.upsert_override(
                "a1", {"model": "new-model"}, node_id="n1", provider="kvant"
            )
            assert client.get_override_provider(agent_id="a1", node_id="n1") == "kvant"


class TestOverrideRoutes:
    """Tests for route cache and get_override_route()."""

    async def test_get_override_route_node_level_hit(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Node-level route present -> returns it."""
        client = ConfigServiceClient(settings=settings)
        client._override_routes = {
            "node:a1:n1": "vertex-gemini",
        }

        result = client.get_override_route(agent_id="a1", node_id="n1")
        assert result == "vertex-gemini"

    async def test_get_override_route_agent_level_hit(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Agent-level route present -> returns it."""
        client = ConfigServiceClient(settings=settings)
        client._override_routes = {
            "agent:a1": "kvant",
        }

        result = client.get_override_route(agent_id="a1")
        assert result == "kvant"

    async def test_get_override_route_miss_returns_none(
        self, settings: ConfigServiceSettings
    ) -> None:
        """No matching route -> returns None."""
        client = ConfigServiceClient(settings=settings)
        client._override_routes = {}

        assert client.get_override_route(agent_id="a1", node_id="n1") is None
        assert client.get_override_route(agent_id="a1") is None

    async def test_get_override_route_null_route(
        self, settings: ConfigServiceSettings
    ) -> None:
        """Route stored as None -> returns None."""
        client = ConfigServiceClient(settings=settings)
        client._override_routes = {
            "node:a1:n1": None,
        }

        assert client.get_override_route(agent_id="a1", node_id="n1") is None

    BASE_URL = "http://test-config-service:8090"
    CONFIGS_URL = f"{BASE_URL}/api/v1/configurations"
    OVERRIDES_URL = f"{BASE_URL}/api/v1/overrides"

    @respx.mock
    async def test_refresh_cache_populates_override_routes(
        self, settings: ConfigServiceSettings
    ) -> None:
        """_refresh_cache stores override routes alongside blobs."""
        now = datetime.now(timezone.utc).isoformat()

        respx.get(self.CONFIGS_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.get(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json=[
                {
                    "id": 1,
                    "agent_id": "a1",
                    "node_id": None,
                    "value": {"model": "agent-model"},
                    "provider": "vertex",
                    "route": "vertex-gemini",
                    "created_at": now,
                    "updated_at": now,
                },
                {
                    "id": 2,
                    "agent_id": "a1",
                    "node_id": "n1",
                    "value": {"model": "node-model"},
                    "provider": "kvant",
                    "route": None,
                    "created_at": now,
                    "updated_at": now,
                },
            ])
        )

        async with ConfigServiceClient(settings=settings) as client:
            assert client.get_override_route(agent_id="a1") == "vertex-gemini"
            assert client.get_override_route(agent_id="a1", node_id="n1") is None

    @respx.mock
    async def test_upsert_override_stores_route(
        self, settings: ConfigServiceSettings
    ) -> None:
        """upsert_override stores the route in _override_routes."""
        now = datetime.now(timezone.utc).isoformat()

        respx.get(self.CONFIGS_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.get(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.post(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json={
                "id": 1,
                "agent_id": "a1",
                "node_id": "n1",
                "value": {"model": "new-model"},
                "provider": "kvant",
                "route": "kvant",
                "created_at": now,
                "updated_at": now,
            })
        )

        async with ConfigServiceClient(settings=settings) as client:
            await client.upsert_override(
                "a1", {"model": "new-model"}, node_id="n1", provider="kvant", route="kvant"
            )
            assert client.get_override_route(agent_id="a1", node_id="n1") == "kvant"

    @respx.mock
    async def test_upsert_override_sends_route_in_request(
        self, settings: ConfigServiceSettings
    ) -> None:
        """upsert_override includes route in the POST request body."""
        import json
        now = datetime.now(timezone.utc).isoformat()

        respx.get(self.CONFIGS_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        respx.get(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json=[])
        )
        route_mock = respx.post(self.OVERRIDES_URL).mock(
            return_value=httpx.Response(200, json={
                "id": 1,
                "agent_id": "a1",
                "node_id": None,
                "value": {"model": "gemini-pro"},
                "provider": "vertex",
                "route": "vertex-gemini",
                "created_at": now,
                "updated_at": now,
            })
        )

        async with ConfigServiceClient(settings=settings) as client:
            await client.upsert_override(
                "a1", {"model": "gemini-pro"}, provider="vertex", route="vertex-gemini"
            )

        request = route_mock.calls.last.request
        body = json.loads(request.content)
        assert body["route"] == "vertex-gemini"
        assert body["provider"] == "vertex"


class TestSettings:
    """Tests for ConfigServiceSettings."""

    def test_default_settings(self) -> None:
        """Test default settings values."""
        settings = ConfigServiceSettings()

        assert settings.url == "http://localhost:8090"
        assert settings.timeout == 30.0
        assert settings.max_retries == 3

    def test_custom_settings(self) -> None:
        """Test custom settings."""
        settings = ConfigServiceSettings(
            url="http://custom:9000",
            timeout=60.0,
            max_retries=5,
        )

        assert settings.url == "http://custom:9000"
        assert settings.timeout == 60.0
        assert settings.max_retries == 5
