"""Git related functions."""

import warnings
from enum import StrEnum
from pathlib import Path
from typing import Any


try:
    from git import Repo
    from git.diff import Diff

    GIT_AVAILABLE = True
except ImportError:
    GIT_AVAILABLE = False
    warnings.warn(
        "GitPython package is not available. Git-related functionality will be disabled. "
        "To enable git functionality, install GitPython and ensure git CLI is available.",
        stacklevel=2,
    )


class GitMode(StrEnum):
    """Git modes for the plugin."""

    UNSTAGED = "unstaged"
    BRANCH = "branch"


class GitStatus(StrEnum):
    """Git statuses.

    Reference: `man git-diff`

    """

    ADDED = "A"
    COPIED = "C"
    DELETED = "D"
    MODIFIED = "M"
    RENAMED = "R"
    TYPE_CHANGE = "T"
    UNMERGED = "U"
    UNKNOWN = "X"
    PAIRING_BROKEN = "B"

    @classmethod
    def from_git_diff_name_status(cls, status: str) -> "GitStatus":
        """Create a GitStatus from a git diff name status."""
        match status:
            case _ as status if status.startswith("R") and status[1:].isdigit():
                # git diff --name-status output may report <X><score> for renamed files
                return cls.RENAMED
            case _ as status if status.startswith("C") and status[1:].isdigit():
                # git diff --name-status output may report <X><score> for copied files
                return cls.COPIED
            case _:
                return cls(status)


# Statuses that indicate a file is impactful for test coverage.
_IMPACTFUL_STATUSES = (GitStatus.MODIFIED, GitStatus.ADDED, GitStatus.RENAMED, GitStatus.COPIED)


class Change:
    """A change to a git repository file."""

    def __init__(
        self,
        a_path: str | None = None,
        b_path: str | None = None,
        status: GitStatus | None = None,
    ):
        self.a_path = a_path
        self.b_path = b_path
        self.status = status

    def __str__(self) -> str:
        return f"{self.status}\t{self.name}"

    @property
    def name(self) -> str | None:
        """The name of the file."""
        return self.a_path if self.a_path is not None else self.b_path

    @classmethod
    def from_git_diff_name_status(cls, *, name: str | None, status: str | None) -> "Change":
        """Create a Change from a git diff.

        Input is the output of `git diff --name-status`.
        For rename and copy operations, the name will contain both source and destination
        paths separated by a tab.

        """
        if status is not None and status.startswith(("R", "C")) and name is not None and "\t" in name:
            # For rename/copy operations, split the name into source and destination
            a_path, b_path = name.split("\t", 1)
            return cls(
                a_path=a_path,
                b_path=b_path,
                status=GitStatus.from_git_diff_name_status(status),
            )

        return cls(
            a_path=name,
            b_path=None,
            status=GitStatus.from_git_diff_name_status(status) if status is not None else None,
        )


class ChangeSet:
    """A set of changes to files in a git repository."""

    def __init__(self, changes: list[Change]):
        self.changes = changes

    def __str__(self) -> str:
        return "\n".join(str(change) for change in self.changes)

    @classmethod
    def from_diff_objs(cls, diffs: list[Diff]) -> "ChangeSet":
        """Create a ChangeSet from a list of git diff objects."""
        changes = []
        for diff in diffs:
            status = GitStatus.from_git_diff_name_status(diff.change_type) if diff.change_type else None
            if status in (GitStatus.RENAMED, GitStatus.COPIED):
                changes.append(Change(a_path=diff.a_path, b_path=diff.b_path, status=status))
            else:
                # a_path would be None if this is a new file in which case
                # we use the b_path to get its name.
                changes.append(
                    Change(
                        a_path=diff.a_path if diff.a_path is not None else diff.b_path,
                        b_path=None,
                        status=status,
                    )
                )
        return cls(changes)

    @classmethod
    def from_git_diff_name_status_output(cls, diffs_str: str) -> "ChangeSet":
        """Create a ChangeSet from a list of git diffs.

        Input is the output of `git diff --name-status`.

        Example input format:
        ```
        M\tsetup.py
        D\tsetup.cfg
        ```

        """
        diffs = [line.split("\t", 1) for line in diffs_str.splitlines()]

        changes = [Change.from_git_diff_name_status(status=status, name=name) for (status, name) in diffs]
        return cls(changes)


def without_nones(items: list[Any | None]) -> list[Any]:
    """Remove all Nones from the list."""
    return [item for item in items if item is not None]


def describe_index_diffs(diffs: list[Diff]) -> None:
    """Describe the index diffs to stdout."""
    for diff in diffs:
        print(f"diff: {str(diff)}")


def find_repo(path: str | Path) -> "Repo":
    """Find the git repository by searching the given path and its parent directories.

    Uses ``search_parent_directories=True`` so the caller does not need to be
    at the exact git root — essential for monorepo layouts where the Python
    project lives in a subdirectory.
    """
    return Repo(path=Path(path), search_parent_directories=True)


def _normalize_git_paths(file_paths: list[str], git_root: Path, working_dir: Path) -> list[str]:
    """Convert git-root-relative file paths to working-dir-relative paths.

    Git returns paths relative to the repository root.  When *working_dir* differs
    from *git_root* (monorepo layout), the paths must be rebased so that downstream
    code calling ``os.path.abspath()`` resolves them correctly.

    Files that fall outside *working_dir* are returned as absolute paths so they
    can still be matched (though they typically won't belong to any discovered module).
    """
    if git_root == working_dir:
        return file_paths  # Fast path: no conversion needed

    result: list[str] = []
    for file_path in file_paths:
        abs_path = git_root / file_path
        try:
            result.append(str(abs_path.relative_to(working_dir)))
        except ValueError:
            # File is outside the working directory — use absolute path
            result.append(str(abs_path))
    return result


def find_impacted_files_in_repo(repo_dir: str | Path, git_mode: GitMode, base_branch: str | None) -> list[str] | None:
    """Find impacted files in the repository. The definition of impacted is dependent on the git mode:

    UNSTAGED:
        - All files that have been modified in the working directory according to git diff.
        - Any untracked files are also included.

    BRANCH:
        - All files that have been modified in the current branch, relative to the base branch.
        - This does *not* include untracked files as the expectation is that this is used for committed changes.

    :param repo_dir: path to the project directory (may be a subdirectory of the git root).
    :param git_mode: the git mode to use.
    :param base_branch: the base branch to compare against.

    """
    if not GIT_AVAILABLE:
        warnings.warn(
            "Git functionality is disabled because GitPython is not available. "
            "To enable git functionality, install GitPython and ensure git CLI is available.",
            stacklevel=2,
        )
        return None

    repo = find_repo(repo_dir)

    match git_mode:
        case GitMode.UNSTAGED:
            impacted_files = impacted_files_for_unstaged_mode(repo)

        case GitMode.BRANCH:
            if not base_branch:
                raise ValueError("Base branch is required for running in BRANCH git mode")

            impacted_files = impacted_files_for_branch_mode(repo, base_branch=base_branch)

        case _:
            raise ValueError(f"Invalid git mode: {git_mode}")

    if impacted_files is None:
        return None

    # Normalize git-root-relative paths to working-dir-relative paths
    if repo.working_tree_dir is None:
        return impacted_files
    git_root = Path(repo.working_tree_dir).resolve()
    working_dir = Path(repo_dir).resolve()
    return _normalize_git_paths(impacted_files, git_root, working_dir)


def _collect_paths_for_change(item: Change) -> list[str | None]:
    """Collect all relevant file paths from a change.

    For renames and copies, both source and destination paths are relevant.
    For other changes, just the primary name is returned.
    """
    if item.status in (GitStatus.RENAMED, GitStatus.COPIED):
        return [item.a_path, item.b_path]
    return [item.name]


def impacted_files_for_unstaged_mode(repo: Repo) -> list[str] | None:
    """Get the impacted files when in the UNSTAGED git mode."""
    if not repo.is_dirty(untracked_files=True):
        return None

    diffs = repo.index.diff(None)
    change_set = ChangeSet.from_diff_objs(diffs)

    impacted_files = []
    for item in change_set.changes:
        if item.status in _IMPACTFUL_STATUSES:
            impacted_files.extend(_collect_paths_for_change(item))

    # Nb. we also include untracked files as they are also
    # potentially impactful for unit-test coverage.
    impacted_files.extend(repo.untracked_files)

    return without_nones(impacted_files) or None


def impacted_files_for_branch_mode(repo: Repo, base_branch: str) -> list[str] | None:
    """Get the impacted files when in the BRANCH git mode."""

    try:
        current_ref = repo.head.reference
    except TypeError:
        # Detached HEAD state (common in CI) — fall back to HEAD commit
        current_ref = repo.head.commit

    diffs = repo.git.diff(base_branch, current_ref, name_status=True)
    change_set = ChangeSet.from_git_diff_name_status_output(diffs)

    impacted_files = []
    for item in change_set.changes:
        if item.status in _IMPACTFUL_STATUSES:
            impacted_files.extend(_collect_paths_for_change(item))

    return without_nones(impacted_files) or None


def deleted_files_from_diff(change_set: ChangeSet) -> list[str]:
    """Get a list of deleted files from git diffs."""
    return without_nones([item.name for item in change_set.changes if item.status == GitStatus.DELETED])
