"""测试：配置与请求分析，不依赖真实 ES。"""
import pytest


def test_parse_request_analysis():
    from elasticsearch_client_mcp.request_analysis import analyze_request
    a = analyze_request("GET", "/my_index/_search", {"query": {"match_all": {}}}, read_only=False)
    assert a.is_read is True
    assert a.need_confirm is False
    a2 = analyze_request("POST", "/my_index/_doc", {"field": "v"}, read_only=False)
    assert a2.is_write is True
    assert a2.need_confirm is True
    a3 = analyze_request("DELETE", "/my_index", None, read_only=False)
    assert a3.is_dangerous is True


def test_config_single(monkeypatch):
    monkeypatch.setenv("ES_HOST", "localhost")
    monkeypatch.setenv("ES_PORT", "9200")
    from elasticsearch_client_mcp.config import load_connection_map
    default, cmap, name = load_connection_map()
    assert default.host == "localhost"
    assert default.port == 9200
    assert "default" in cmap
    assert name == "default"


def test_config_profiles(monkeypatch):
    monkeypatch.setenv(
        "TEST_ES_PROFILES",
        '[{"host":"e1","port":9200},{"host":"e2","port":9200,"name":"log"}]',
    )
    monkeypatch.setenv("PROD_ES_PROFILES", '[{"host":"prod","port":9200}]')
    from elasticsearch_client_mcp.config import load_connection_map
    default, cmap, name = load_connection_map()
    assert "test_0" in cmap
    assert "test_log" in cmap
    assert name == "prod_0"
    assert default.host == "prod"
