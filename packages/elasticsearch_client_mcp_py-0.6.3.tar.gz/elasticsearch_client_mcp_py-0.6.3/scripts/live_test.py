#!/usr/bin/env python3
"""
活体测试：用环境变量连接 ES，执行 list_indices。
用法（对应 ykc.elasticsearch.configs.default.*）:
  ES_HOSTS=http://10.10.2.49:9200 uv run python scripts/live_test.py
  或带账号密码:
  ES_HOSTS=http://10.10.2.49:9200 ES_USER=elastic ES_PASSWORD=xxx uv run python scripts/live_test.py
"""
from __future__ import annotations

import os
import sys

# 保证能 import 到包（从项目根运行）
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from elasticsearch_client_mcp.config import load_connection_map, load_safety_config
from elasticsearch_client_mcp.client import connect, list_indices


def main() -> None:
    default, connection_map, default_name = load_connection_map()
    safety = load_safety_config()
    print(f"默认连接: {default_name} -> {default.host}:{default.port} (ssl={default.use_ssl})")
    with connect(default, safety) as client:
        info = client.info()
        print("cluster:", info.get("cluster_name"), "version:", info.get("version", {}).get("number"))
        indices = list_indices(client, "*")
        print("索引数量:", len(indices))
        for idx in indices[:20]:
            print(" ", idx.get("name"), "docs:", idx.get("docs_count"), "size:", idx.get("store.size", ""))
        if len(indices) > 20:
            print(" ... 仅显示前 20 个")
    print("ok")


if __name__ == "__main__":
    main()
