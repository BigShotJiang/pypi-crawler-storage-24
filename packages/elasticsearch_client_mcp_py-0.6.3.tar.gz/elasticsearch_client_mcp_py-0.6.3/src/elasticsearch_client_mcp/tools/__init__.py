"""
Tools module for Elasticsearch MCP.
Contains helper functions for tools.
"""
from .connections import do_list_connections, do_get_connection
from .setup import (
    setup_guide,
    show_help,
    query_config,
    query_config_detail,
    add_config,
    add_config_preset,
    add_config_wizard,
    add_config_wizard_input,
    update_config,
    update_config_field,
    update_config_preset,
    delete_config,
    do_delete_config,
    set_default,
    do_check_setup_status,
    PRESETS,
)

__all__ = [
    # 连接查询
    "do_list_connections",
    "do_get_connection",
    # 向导入口
    "setup_guide",
    # 查询
    "query_config",
    "query_config_detail",
    # 添加
    "add_config",
    "add_config_wizard",
    "add_config_wizard_input",
    # 修改
    "update_config",
    "update_config_field",
    "update_config_preset",
    # 删除
    "delete_config",
    "do_delete_config",
    # 默认
    "set_default",
    # 状态
    "do_check_setup_status",
    # 模板
    "PRESETS",
]
