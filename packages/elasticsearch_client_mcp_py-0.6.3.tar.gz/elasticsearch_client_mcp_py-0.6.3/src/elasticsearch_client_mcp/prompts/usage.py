"""
Prompts module.
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP


mcp = FastMCP("prompts")


@mcp.prompt()
def es_safe_usage() -> str:
    """使用本 Elasticsearch MCP 时的安全提示"""
    return """使用本 Elasticsearch MCP 时请遵守：

1. 先用 list_connections 查看可用连接，再用 list_indices、get_mapping 了解索引与字段，再构造请求。
2. 写请求（index/update/delete）执行前需确认。
3. 敏感信息（hosts、用户名、密码）通过环境变量引用，不直接暴露。
4. 每次执行请求前会进行安全检查，危险操作会被拦截。
"""
