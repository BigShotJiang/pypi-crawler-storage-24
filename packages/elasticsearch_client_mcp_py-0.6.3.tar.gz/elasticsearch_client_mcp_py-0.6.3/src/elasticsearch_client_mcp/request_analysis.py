"""
ES 请求解析与安全检查：按 method + path 分类读/写/危险。
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .config import SafetyPolicy

# 只读 path 前缀（GET 或 POST _search 等）
READ_PATTERNS = (
    "_search", "_mget", "_get", "_count", "_explain",
    "_mapping", "_settings", "_aliases", "_stats", "_health",
    "_cat/", "_cluster/health", "_cluster/state", "_nodes",
)
# 危险：删整索引、改集群、关节点等
DANGEROUS_PATTERNS = (
    "/_cluster", "/_nodes", "/_snapshot", "_close",
)
# 写：index, update, delete doc, bulk
WRITE_METHODS = ("PUT", "POST", "DELETE")
WRITE_PATH_SUFFIXES = ("/_doc", "/_update", "/_bulk", "/_update_by_query", "/_delete_by_query", "/_reindex")


@dataclass
class RequestAnalysis:
    method: str
    path: str
    body: dict | None
    is_read: bool
    is_write: bool
    is_dangerous: bool
    need_confirm: bool
    message: str


def _normalize_path(path: str) -> str:
    return (path or "").strip().rstrip("/") or "/"


def _path_is_read(path: str, method: str) -> bool:
    p = _normalize_path(path)
    if method.upper() == "GET":
        return True
    if method.upper() == "POST" and "_search" in p:
        return True
    for pref in READ_PATTERNS:
        if pref in p and not any(d in p for d in DANGEROUS_PATTERNS):
            return True
    return False


def _path_is_dangerous(path: str, policy: "SafetyPolicy") -> bool:
    p = _normalize_path(path).lower()
    # 检查危险路径模式
    for pattern in policy.danger_path_patterns:
        if pattern in p:
            return True
    # 检查 cluster 操作
    if p.startswith("/_cluster") and not policy.allow_cluster:
        return True
    # 删除整个索引: DELETE /index_name（无 /_doc/id）
    if p.strip("/") and p.count("/") <= 1 and not p.startswith("/_"):
        return True
    return False


def _path_is_write(path: str, method: str) -> bool:
    m = method.upper()
    if m not in WRITE_METHODS:
        return False
    p = _normalize_path(path)
    if m == "DELETE":
        return True
    for suf in WRITE_PATH_SUFFIXES:
        if suf in p:
            return True
    if m == "PUT" and "/_doc" in p:
        return True
    if m == "POST" and ("_doc" in p or "_bulk" in p or "_update" in p):
        return True
    return False


def _check_policy(path: str, is_write: bool, policy: "SafetyPolicy") -> tuple[bool, str]:
    """
    检查 SafetyPolicy 细粒度策略。
    返回 (allowed, message)
    """
    p = _normalize_path(path)
    method = "DELETE" if is_write and "DELETE" in path else ""

    # 索引操作检查
    if "/_doc" in p or "/_update" in p:
        if is_write and not policy.allow_index and not policy.allow_update:
            return False, "写操作被安全策略禁止（allow_index/allow_update=false）。"
    if "/_bulk" in p and not policy.allow_bulk:
        return False, "Bulk 操作被安全策略禁止（allow_bulk=false）。"
    if "/_delete_by_query" in p or "/_update_by_query" in p or "/_reindex" in p:
        if is_write and not policy.allow_update:
            return False, "批量写操作被安全策略禁止（allow_update=false）。"

    # DELETE 操作检查
    if method == "DELETE" or "delete" in p:
        if "delete" in p.lower():
            if not policy.allow_delete:
                return False, "删除操作被安全策略禁止（allow_delete=false）。"
        # 删索引检查
        if p.strip("/") and p.count("/") <= 1 and not p.startswith("/_"):
            if not policy.allow_delete_index:
                return False, "删除索引被安全策略禁止（allow_delete_index=false）。"

    # 读操作检查
    if "_search" in p and not policy.allow_search:
        return False, "搜索操作被安全策略禁止（allow_search=false）。"

    # 创建索引检查
    if "/_settings" in p or "/_mapping" in p:
        if "PUT" in method or "POST" in method:
            if not policy.allow_update_mapping:
                return False, "修改 mapping 被安全策略禁止（allow_update_mapping=false）。"

    return True, ""


def analyze_request(
    method: str,
    path: str,
    body: dict | None,
    policy: "SafetyPolicy | None" = None,
    read_only: bool = False,
) -> RequestAnalysis:
    """
    分析一条 ES 请求（由大模型产生），返回是否只读/写/危险、是否需 confirm。

    Args:
        method: HTTP 方法
        path: 请求路径
        body: 请求体
        policy: 安全策略（细粒度控制），可选
        read_only: 只读模式（兼容旧接口）
    """
    from .config import SafetyPolicy as DefaultSafetyPolicy

    # 兼容旧接口：如果没传 policy，使用默认的
    if policy is None:
        policy = DefaultSafetyPolicy()

    method = (method or "GET").strip().upper()
    path = _normalize_path(path)
    is_read = _path_is_read(path, method)
    is_write = _path_is_write(path, method)
    is_dangerous = _path_is_dangerous(path, policy) or (
        method == "DELETE" and path.count("/") <= 1 and len(path.strip("/")) > 0
    )
    need_confirm = False
    message = ""

    # 细粒度策略检查
    if not is_dangerous:
        allowed, policy_msg = _check_policy(path, is_write, policy)
        if not allowed:
            return RequestAnalysis(
                method=method,
                path=path,
                body=body,
                is_read=False,
                is_write=False,
                is_dangerous=False,
                need_confirm=False,
                message=policy_msg,
            )

    if read_only and (is_write or is_dangerous):
        message = "当前为只读模式，拒绝执行写操作。"
    elif is_dangerous:
        message = "危险操作（如删索引、改集群），禁止通过 MCP 执行，请在 Kibana/控制台操作。"
    elif is_write:
        message = "写操作，需传入 confirm=true 后执行。"
        need_confirm = True
    elif is_read:
        message = "只读请求，可直接执行。"
    else:
        message = "未识别的请求，需传入 confirm=true 后执行。"
        need_confirm = True

    return RequestAnalysis(
        method=method,
        path=path,
        body=body,
        is_read=is_read,
        is_write=is_write,
        is_dangerous=is_dangerous,
        need_confirm=need_confirm,
        message=message,
    )
