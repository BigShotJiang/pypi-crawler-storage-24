"""
Resources module.
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP


mcp = FastMCP("resources")
