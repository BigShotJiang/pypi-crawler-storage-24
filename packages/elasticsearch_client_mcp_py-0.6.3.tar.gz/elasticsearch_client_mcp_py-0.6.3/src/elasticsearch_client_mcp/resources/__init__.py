"""
Resources package.
"""
