"""Run the MCP server with: python -m elasticsearch_client_mcp"""
from .server import main

if __name__ == "__main__":
    main()
