#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Filename        : core.py
Description     : gwpaint core class

Created on 2026-03-05 19:37:33

__author__        = Narenraju Nagarajan
__copyright__     = Copyright 2026, gwpaint
__license__       = MIT Licence
__version__       = 0.0.1
__maintainer__    = Narenraju Nagarajan
__affiliation__   = University of Potsdam
__email__         = nagarajan@uni-potsdam.de
__status__        = ['inProgress', 'Archived', *inUsage*, 'Debugging']


GitHub Repository: NULL

Documentation: NULL

"""


# Packages
import warnings

warnings.filterwarnings("ignore", "Wswiglal-redir-stdio")

import os
import numpy as np

from matplotlib.colors import ListedColormap

# LOCAL
from .grids import *
from .transforms import *
from .plotting import *
from .utils import *


class SpectrogramPaintByNumbers:
    """
    Convert gravitational-wave Q-transform spectrograms
    into a paint-by-numbers style grid representation.
    """

    def __init__(
        self,
        cmap_name="cividis",
        n_colors=8,
        custom_colors=None,
        custom_labels=None,
        grid_rows=32,
        grid_cols=32,
        output_dir="./output",
        page_size="A3",
        line_width=2.5,
        padding_cells=2,
        square_cells=False,
        qrange=(8, 8),
        frange=(15, 512),
        vmin_percentile=1,
        vmax_percentile=99,
        time_around_event=(0.3, 0.15),
        tres=0.02,
        fres=0.2,
        whiten=True,
        save_dpi=300,
        powernorm_gamma=0.5,
        truncate_cmap=(0.0, 1.0),
    ):

        self.cmap_name = cmap_name
        self.n_colors = n_colors
        self.custom_colors = custom_colors
        if self.custom_colors is not None:
            self.n_colors = len(self.custom_colors)

        self.grid_rows = grid_rows
        self.grid_cols = grid_cols
        self.output_dir = output_dir

        self.page_size = page_size
        self.line_width = line_width
        self.padding_cells = padding_cells
        self.square_cells = square_cells
        self.save_dpi = save_dpi
        self.truncate_cmap = truncate_cmap

        # Spectrogram options
        self.qrange = qrange
        self.frange = frange
        self.time_around_event = time_around_event
        self.tres = tres
        self.fres = fres
        self.whiten = whiten
        self.vmin_percentile = vmin_percentile
        self.vmax_percentile = vmax_percentile
        self.powernorm_gamma = powernorm_gamma

        # Set colormap
        if self.custom_colors is not None:
            self.n_colors = len(self.custom_colors)
            self.cmap = ListedColormap(self.custom_colors)

            # Use custom labels if provided, else default C0..C(n-1)
            if custom_labels is not None:
                if len(custom_labels) != len(self.custom_colors):
                    raise ValueError(
                        "custom_labels must have the same length as custom_colors"
                    )
                self.labels = custom_labels
            else:
                self.labels = [f"C{i}" for i in range(self.n_colors)]
        else:
            # normal behavior using cmap_name
            self.cmap = self.get_cmap(cmap_name, self.n_colors)
            if custom_labels is not None:
                if len(custom_labels) != self.n_colors:
                    raise ValueError("len of custom_labels must be equal to n_colors")
                self.labels = custom_labels
            else:
                self.labels = [f"C{i}" for i in range(self.n_colors)]

        os.makedirs(output_dir, exist_ok=True)

    def process_event(self, event_time, ifo="H1", index=0):
        """
        Run full pipeline for a single event.
        """

        print(f"Processing event {index} at time {event_time} in {ifo} detector")

        self.event_time = event_time
        self.ifo = ifo

        data = self.fetch_data(ifo, event_time)

        q_data = self.compute_q_transform(
            data,
            event_time,
            self.time_around_event,
            self.qrange,
            self.frange,
            self.tres,
            self.fres,
            self.whiten,
        )

        spec = q_data.value.T
        # resample to log-frequency spacing
        # this must be called before discretisation
        spec = self.resample_log_frequency(spec, q_data)

        # Dynamically set vmin and vmax based on event
        self.vmin = np.percentile(spec, self.vmin_percentile)
        self.vmax = np.percentile(spec, self.vmax_percentile)

        event_dir = os.path.join(self.output_dir, f"{int(event_time)}_{ifo}")
        os.makedirs(event_dir, exist_ok=True)

        self.plot_original(
            q_data,
            f"{event_dir}/q_transform.png",
            self.vmin,
            self.vmax,
            self.save_dpi,
        )

        indices = discretize(
            spec,
            self.powernorm_gamma,
            self.vmin,
            self.vmax,
            self.n_colors,
        )
        grid = self.build_resampled_grid(indices, self.grid_rows, self.grid_cols)
        grid = np.rot90(grid)

        self.plot_template_grid(
            grid,
            f"{event_dir}/paint_template.pdf",
            self.page_size,
            self.line_width,
            self.square_cells,
            event_time,
            self.time_around_event,
            self.save_dpi,
            ifo,
        )

        self.plot_colored_grid(
            grid,
            f"{event_dir}/colored_reference.pdf",
            self.cmap,
            self.square_cells,
            event_time,
            self.time_around_event,
            self.save_dpi,
            ifo,
        )

        self.plot_legend(
            f"{event_dir}/legend.pdf",
            self.cmap,
            self.n_colors,
            self.save_dpi,
        )

        self.reconstruct(
            grid,
            q_data,
            f"{event_dir}/reconstructed.png",
            self.cmap,
            self.save_dpi,
        )

        print("Fin.")
