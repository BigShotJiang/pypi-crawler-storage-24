#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Filename        : transforms.py
Description     : Short description of the file

Created on 2026-03-08 14:16:23

__author__        = Narenraju Nagarajan
__copyright__     = Copyright 2026, ProjectName
__license__       = MIT Licence
__version__       = 0.0.1
__maintainer__    = Narenraju Nagarajan
__affiliation__   = N/A
__email__         = N/A
__status__        = ['inProgress', 'Archived', 'inUsage', 'Debugging']


GitHub Repository: NULL

Documentation: NULL

"""

# Packages
from gwpy.segments import Segment
from gwpy.timeseries import TimeSeries


def fetch_data(ifo, event_time, pad=10):
    """
    Fetch open gravitational-wave strain data.
    """
    return TimeSeries.fetch_open_data(ifo, event_time - pad, event_time + pad)


def compute_q_transform(
    data,
    event_time,
    time_around_event,
    qrange,
    frange,
    tres,
    fres,
    whiten,
):
    """
    Compute Q-transform spectrogram.
    """

    segment = Segment(
        event_time - time_around_event[0],
        event_time + time_around_event[1],
    )

    q_data = data.q_transform(
        qrange=qrange,
        frange=frange,
        outseg=segment,
        tres=tres,
        fres=fres,
        whiten=whiten,
    )

    return q_data
