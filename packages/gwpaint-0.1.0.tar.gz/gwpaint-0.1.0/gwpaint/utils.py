#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Filename        : utils.py
Description     : Short description of the file

Created on 2026-03-08 14:14:29

__author__        = Narenraju Nagarajan
__copyright__     = Copyright 2026, ProjectName
__license__       = MIT Licence
__version__       = 0.0.1
__maintainer__    = Narenraju Nagarajan
__affiliation__   = N/A
__email__         = N/A
__status__        = ['inProgress', 'Archived', 'inUsage', 'Debugging']


GitHub Repository: NULL

Documentation: NULL

"""

# Packages
import warnings

warnings.filterwarnings("ignore", "Wswiglal-redir-stdio")

import numpy as np
import matplotlib.pyplot as plt

from matplotlib import colormaps
from matplotlib.colors import ListedColormap

# LOCAL
from .presets import PRESET_COLORS, PAGE_SIZES


######## Helper Functions ########


def pad_grid(grid, padding_cells):
    pad = padding_cells
    padded = np.full((grid.shape[0] + 2 * pad, grid.shape[1] + 2 * pad), -1)
    padded[pad:-pad, pad:-pad] = grid

    return padded


def _create_page(page_size):
    """
    Create a figure with the requested page size.
    """

    if page_size not in PAGE_SIZES:
        raise ValueError(f"Unknown page size: {page_size}")

    fig_w, fig_h = PAGE_SIZES[page_size]
    # rotate page to correct orientation for plotting
    fig_size = (fig_h, fig_w)
    fig, ax = plt.subplots(figsize=fig_size)

    return fig, ax


def _auto_fontsize(rows, cols, page_size):
    """
    Estimate a font size that fits inside grid cells
    regardless of page size or grid resolution.
    """

    fig_w, fig_h = PAGE_SIZES[page_size]

    # approximate cell dimensions in inches
    cell_w = fig_w / cols
    cell_h = fig_h / rows

    cell = min(cell_w, cell_h)

    # convert inches -> points (1 inch = 72 points)
    fontsize = cell * 72 * 0.35

    # clamp to reasonable limits
    fontsize = max(4, min(fontsize, 40))

    return fontsize


def _invert_colors(val, cmap):
    r, g, b = cmap(val)[:3]
    luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b  # standard formula
    text_color = "white" if luminance < 0.5 else "black"
    return text_color


def get_truncated_cmap(cmap_name, truncate_cmap, n_colors):
    base = colormaps.get_cmap(cmap_name)

    colors = base(np.linspace(truncate_cmap[0], truncate_cmap[1], n_colors))
    return ListedColormap(colors)


def get_cmap(cmap_name, n_colors):
    if cmap_name in PRESET_COLORS:
        base_cmap = PRESET_COLORS[cmap_name]

        # If base_cmap is a matplotlib colormap (has resampled)
        if hasattr(base_cmap, "resampled"):
            return base_cmap.resampled(n_colors)

        # If base_cmap is a list of colors
        elif isinstance(base_cmap, list):
            # Take first n_colors (or repeat if list is shorter)
            colors = (
                base_cmap[:n_colors]
                if len(base_cmap) >= n_colors
                else (base_cmap * ((n_colors // len(base_cmap)) + 1))[:n_colors]
            )
            return ListedColormap(colors)

        # fallback: maybe already ListedColormap
        elif hasattr(base_cmap, "colors"):
            return ListedColormap(base_cmap.colors[:n_colors])

    # fallback to matplotlib colormaps by name
    # return colormaps.get_cmap(cmap_name).resampled(n_colors)
    return get_truncated_cmap(cmap_name)
