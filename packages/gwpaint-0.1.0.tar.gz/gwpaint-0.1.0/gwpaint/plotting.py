#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Filename        : plotting.py
Description     : Short description of the file

Created on 2026-03-05 19:41:09

__author__        = Narenraju Nagarajan
__copyright__     = Copyright 2026, ProjectName
__license__       = MIT Licence
__version__       = 0.0.1
__maintainer__    = Narenraju Nagarajan
__affiliation__   = N/A
__email__         = N/A
__status__        = ['inProgress', 'Archived', 'inUsage', 'Debugging']


GitHub Repository: NULL

Documentation: NULL

"""

# Plotting Packages
import warnings

warnings.filterwarnings("ignore", "Wswiglal-redir-stdio")

import numpy as np
import matplotlib.pyplot as plt

from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable

# LOCAL
from .utils import _create_page, _auto_fontsize, _invert_colors, pad_grid

from .presets import PAGE_SIZES


def plot_original(q_data, path, cmap, vmin, vmax, save_dpi):

    fig = q_data.plot(figsize=[12, 8])
    ax = fig.gca()

    ax.set_xscale("seconds")
    ax.set_ylabel("Frequency [Hz]")
    ax.set_yscale("log")

    sm = ScalarMappable(cmap=cmap, norm=Normalize(vmin=vmin, vmax=vmax))
    cbar = plt.colorbar(sm, ax=ax)

    cbar.set_label("Normalized energy")

    plt.savefig(path, dpi=save_dpi, bbox_inches="tight")
    plt.close()


def plot_template_grid(
    grid,
    path,
    page_size,
    line_width,
    square_cells,
    event_time,
    time_around_event,
    save_dpi,
    ifo,
):

    grid = np.rot90(grid, k=-1)
    grid = pad_grid(grid)
    rows, cols = grid.shape
    labels = labels

    fig, ax = _create_page(page_size)

    fig_w, fig_h = PAGE_SIZES[page_size]

    # compute scaling to fill the page
    cell_w = fig_w / cols
    cell_h = fig_h / rows

    # draw cells
    for r in range(rows):
        for c in range(cols):
            val = grid[r, c]
            if val >= 0:
                # rectangle coordinates in data space
                rect = plt.Rectangle(
                    (c, r),
                    1,
                    1,  # still use 1x1 in data units
                    fill=False,
                    linewidth=line_width,
                    edgecolor="black",
                )
                ax.add_patch(rect)

                fontsize = _auto_fontsize(rows, cols, page_size)
                ax.text(
                    c + 0.5,
                    r + 0.5,
                    labels[val],
                    ha="center",
                    va="center",
                    rotation=0,
                    fontsize=fontsize,
                    fontweight="bold",
                )

    # scale x/y to match figure page size
    ax.set_xlim(0, cols)
    ax.set_ylim(0, rows)

    # Add thick outer border
    ax.add_patch(
        plt.Rectangle(
            (0, 0),
            cols,
            rows,
            fill=False,
            linewidth=line_width * 2,
            edgecolor="black",
        )
    )

    # stretch the plot to fill the figure
    if square_cells:
        ax.set_aspect("equal")  # cells remain square
        # keep grid centered by letting axes fill as much as possible
        ax.set_position([0.05, 0.05, 0.9, 0.9])
    else:
        ax.set_position([0, 0, 1, 1])  # stretch to fill page

    ax.axis("off")

    # watermark / credit text
    fig.text(
        0.915,
        0.06,
        "Make your own template with GWPAINT",
        ha="right",
        va="bottom",
        fontsize=fontsize + 4,
        color="black",
        fontweight="bold",
    )

    # Event ID
    st = np.around(event_time - time_around_event[0], 2)
    et = np.around(event_time + time_around_event[1], 2)

    fig.text(
        0.445,
        0.06,
        f"Event: GW150914, GPS time: [{st}, {et}] s, Detector: {ifo}",
        ha="right",
        va="bottom",
        fontsize=fontsize + 4,
        color="black",
        fontweight="bold",
    )

    plt.savefig(path, dpi=save_dpi)
    plt.close()


def plot_colored_grid(
    grid,
    path,
    cmap,
    square_cells,
    event_time,
    time_around_event,
    save_dpi,
    ifo,
):

    grid = np.rot90(grid, k=-1)
    grid = pad_grid(grid)
    rows, cols = grid.shape
    labels = labels

    fig, ax = _create_page("A4")

    # draw cells with fill color
    for r in range(rows):
        for c in range(cols):
            val = grid[r, c]
            if val >= 0:
                rect = plt.Rectangle((c, r), 1, 1, color=cmap(val))
                ax.add_patch(rect)

                text_color = _invert_colors(val)

                fontsize = _auto_fontsize(rows, cols, "A4")
                ax.text(
                    c + 0.5,
                    r + 0.5,
                    labels[val],
                    ha="center",
                    va="center",
                    rotation=0,
                    fontsize=fontsize,
                    color=text_color,
                    fontweight="bold",
                )

    # draw grid lines on top
    for x in range(cols + 1):
        ax.plot([x, x], [0, rows], color="black", linewidth=2.5)
    for y in range(rows + 1):
        ax.plot([0, cols], [y, y], color="black", linewidth=2.5)

    # Add thick outer border
    ax.add_patch(
        plt.Rectangle(
            (0, 0), cols, rows, fill=False, linewidth=2.5 * 2, edgecolor="black"
        )
    )

    ax.set_xlim(0, cols)
    ax.set_ylim(0, rows)

    if square_cells:
        ax.set_aspect("equal")  # cells remain square
        # keep grid centered by letting axes fill as much as possible
        ax.set_position([0.05, 0.05, 0.9, 0.9])
    else:
        ax.set_position([0, 0, 1, 1])  # stretch to fill page

    ax.axis("off")

    # watermark / credit text
    fig.text(
        0.9325,
        0.01,
        "Make your own template with GWPAINT",
        ha="right",
        va="bottom",
        fontsize=fontsize + 4,
        color="black",
        fontweight="bold",
    )

    # Event ID
    st = np.around(event_time - time_around_event[0], 2)
    et = np.around(event_time + time_around_event[1], 2)

    fig.text(
        0.58,
        0.01,
        f"Event: GW150914, GPS time: [{st}, {et}] s, Detector: {ifo}",
        ha="right",
        va="bottom",
        fontsize=fontsize + 4,
        color="black",
        fontweight="bold",
    )

    plt.savefig(path, dpi=save_dpi)
    plt.close()


def plot_legend(path, cmap, n_colors, save_dpi):
    """
    Plot the color legend corresponding to the discrete colormap.
    """

    labels = labels

    # fig, ax = plt.subplots(figsize=(6, 3))
    fig, ax = _create_page("A4")

    for i in range(n_colors):

        ax.add_patch(plt.Rectangle((i, 0), 1, 1, color=cmap(i)))

        ax.text(
            i + 0.5,
            -0.05,
            labels[i],
            ha="center",
            va="top",
            fontsize=16,
            fontweight="bold",
        )

    ax.set_xlim(0, n_colors)
    ax.set_ylim(0, 1)

    ax.axis("off")

    plt.savefig(path, dpi=save_dpi, bbox_inches="tight")
    plt.close()
