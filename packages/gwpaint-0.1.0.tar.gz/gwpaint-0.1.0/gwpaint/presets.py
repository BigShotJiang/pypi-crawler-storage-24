#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Filename        : presets.py
Description     : Short description of the file

Created on 2026-03-08 14:21:13

__author__        = Narenraju Nagarajan
__copyright__     = Copyright 2026, ProjectName
__license__       = MIT Licence
__version__       = 0.0.1
__maintainer__    = Narenraju Nagarajan
__affiliation__   = N/A
__email__         = N/A
__status__        = ['inProgress', 'Archived', 'inUsage', 'Debugging']


GitHub Repository: NULL

Documentation: NULL

"""


PAGE_SIZES = {
    "A0": (33.11, 46.81),
    "A1": (23.4, 33.1),
    "A2": (16.5, 23.4),
    "A3": (11.7, 16.5),
    "A4": (8.27, 11.69),
    "A5": (5.8, 8.3),
    "LETTER": (8.5, 11),
}


PRESET_COLORS = {
    "High Contrast": [
        "#FF3B30",
        "#FF9500",
        "#FFCC00",
        "#34C759",
        "#5AC8FA",
        "#5856D6",
        "#FF2D55",
        "#FF9F0A",
    ],
    "Vibrant": [
        "#E63946",
        "#F1FAEE",
        "#A8DADC",
        "#457B9D",
        "#1D3557",
        "#F4A261",
        "#2A9D8F",
        "#E76F51",
    ],
    "Pastel Dreams": [
        "#FFB3BA",
        "#FFDFBA",
        "#FFFFBA",
        "#BAFFC9",
        "#BAE1FF",
        "#D4BAFF",
        "#FFBAF2",
        "#FFC9BA",
    ],
    "Soft Multi": [
        "#A8E6CF",
        "#DCEDC1",
        "#FFD3B6",
        "#FFAAA5",
        "#FF8B94",
        "#E0BBE4",
        "#957DAD",
        "#D291BC",
    ],
    "Sunset Glow": [
        "#FF5E5B",
        "#FFA500",
        "#FFD700",
        "#FF7F50",
        "#FF6347",
        "#FF4500",
        "#FF1493",
        "#FF69B4",
    ],
    "Ocean Breeze": [
        "#00A8E8",
        "#007EA7",
        "#00B4D8",
        "#48CAE4",
        "#90E0EF",
        "#CAF0F8",
        "#0096C7",
        "#023E8A",
    ],
    "Forest Walk": [
        "#2F5233",
        "#52796F",
        "#84A98C",
        "#CAD2C5",
        "#354F52",
        "#6B9080",
        "#BFD7EA",
        "#98C1D9",
    ],
    "Warm Earth": [
        "#7C4A0A",
        "#A65F2B",
        "#D9A066",
        "#F4E1C1",
        "#C18F6A",
        "#8B4513",
        "#E07B39",
        "#FFD699",
    ],
    "Berry Mix": [
        "#8B0000",
        "#B22222",
        "#DC143C",
        "#FF69B4",
        "#FF1493",
        "#C71585",
        "#DB7093",
        "#FFB6C1",
    ],
    "Golden Hour": [
        "#FFD700",
        "#FFC300",
        "#FFB347",
        "#FF8C00",
        "#FF7F50",
        "#FFA07A",
        "#F4A460",
        "#DAA520",
    ],
    "Cool Mint": [
        "#98FF98",
        "#70DB93",
        "#00FF7F",
        "#00FA9A",
        "#3CB371",
        "#2E8B57",
        "#20B2AA",
        "#66CDAA",
    ],
    "Lavender Fields": [
        "#E6E6FA",
        "#D8BFD8",
        "#DDA0DD",
        "#EE82EE",
        "#DA70D6",
        "#BA55D3",
        "#9932CC",
        "#8A2BE2",
    ],
    "Tropical Punch": [
        "#FF6F61",
        "#FFB347",
        "#FFD700",
        "#FF7F50",
        "#FF6347",
        "#FF4500",
        "#FF1493",
        "#FF69B4",
    ],
    "Ocean Depths": [
        "#001F3F",
        "#003366",
        "#004080",
        "#0059B3",
        "#0073E6",
        "#3399FF",
        "#66B2FF",
        "#99CCFF",
    ],
    "Sunrise": [
        "#FF4500",
        "#FF6347",
        "#FF7F50",
        "#FFA07A",
        "#FFDAB9",
        "#FFE4B5",
        "#FFF5EE",
        "#FFEFD5",
    ],
    "Candy Shop": [
        "#FFB6C1",
        "#FF69B4",
        "#FF1493",
        "#FF00FF",
        "#DA70D6",
        "#BA55D3",
        "#9932CC",
        "#8B008B",
    ],
    "Autumn Leaves": [
        "#A0522D",
        "#CD853F",
        "#D2691E",
        "#F4A460",
        "#DEB887",
        "#BC8F8F",
        "#8B4513",
        "#A0522D",
    ],
    "Berry Frost": [
        "#8B0000",
        "#B22222",
        "#FF4500",
        "#FF6347",
        "#FF7F50",
        "#FF8C00",
        "#FFA500",
        "#FFD700",
    ],
    "Skyline": [
        "#0D3B66",
        "#145DA0",
        "#1E81B0",
        "#0288D1",
        "#00B0FF",
        "#80D8FF",
        "#B3E5FC",
        "#E1F5FE",
    ],
    "Earth Tones": [
        "#6B4226",
        "#8B5E3C",
        "#A67B5B",
        "#C19A6B",
        "#D2B48C",
        "#E0C097",
        "#F5DEB3",
        "#FFE4B5",
    ],
}
