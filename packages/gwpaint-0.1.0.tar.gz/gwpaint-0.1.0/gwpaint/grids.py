#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Filename        : grids.py
Description     : Short description of the file

Created on 2026-03-08 14:17:08

__author__        = Narenraju Nagarajan
__copyright__     = Copyright 2026, ProjectName
__license__       = MIT Licence
__version__       = 0.0.1
__maintainer__    = Narenraju Nagarajan
__affiliation__   = N/A
__email__         = N/A
__status__        = ['inProgress', 'Archived', 'inUsage', 'Debugging']


GitHub Repository: NULL

Documentation: NULL

"""

# Packages
import numpy as np
import matplotlib.pyplot as plt

from skimage.transform import resize
from matplotlib.colors import PowerNorm


###### Discretization ######


def discretize(spec, powernorm_gamma, vmin, vmax, n_colors):
    """
    Convert continuous spectrogram values
    into discrete colormap indices.
    """

    # norm = Normalize(vmin=self.vmin, vmax=self.vmax)
    norm = PowerNorm(gamma=powernorm_gamma, vmin=vmin, vmax=vmax)
    normed = np.clip(norm(spec), 0, 1)

    indices = np.floor(normed * (n_colors - 1)).astype(np.uint8)

    return indices


def resample_log_frequency(spec, q_data):
    """
    Resample spectrogram so that frequency bins are evenly spaced in log(f).
    Assumes spec shape = (freq_bins, time_bins)
    """

    freqs = q_data.frequencies.value
    log_freqs = np.log10(freqs)

    new_log_freqs = np.linspace(log_freqs.min(), log_freqs.max(), len(freqs))
    new_freqs = 10**new_log_freqs

    spec_log = np.zeros_like(spec)

    # iterate over time bins
    for t in range(spec.shape[1]):

        spec_log[:, t] = np.interp(
            new_freqs,  # target frequencies
            freqs,  # original frequencies
            spec[:, t],  # spectrum at time t
        )

    return spec_log


###### Grid Builder ######


def build_grid(indices, grid_rows, grid_cols, n_colors):
    """
    Aggregate spectrogram into a coarse grid
    using dominant color index.
    """

    h, w = indices.shape

    cell_h = int(np.ceil(h / grid_rows))
    cell_w = int(np.ceil(w / grid_cols))

    pad_h = cell_h * grid_rows - h
    pad_w = cell_w * grid_cols - w

    indices = np.pad(indices, ((0, pad_h), (0, pad_w)), mode="edge")

    grid = np.zeros((grid_rows, grid_cols), dtype=np.uint8)

    for r in range(grid_rows):
        for c in range(grid_cols):

            cell = indices[r * cell_h : (r + 1) * cell_h, c * cell_w : (c + 1) * cell_w]

            # faster histogram than np.unique
            hist = np.bincount(cell.ravel(), minlength=n_colors)
            grid[r, c] = np.argmax(hist)

    return grid


def build_resampled_grid(indices, grid_rows, grid_cols):
    """
    Build a grid without padding/stretching.
    Resample the indices array directly to (grid_rows, grid_cols).
    """
    # indices is integers; resize works with float, so cast
    indices_float = indices.astype(float)

    # Use nearest-neighbor to preserve discrete values
    grid_resampled = resize(
        indices_float,
        (grid_rows, grid_cols),
        order=0,  # nearest-neighbor
        preserve_range=True,
        anti_aliasing=False,
    )

    return grid_resampled.astype(np.uint8)


###### Reconstruction ######


def reconstruct(grid, q_data, path, cmap, save_dpi):

    grid = np.rot90(grid, k=3)
    rgb = cmap(grid)[:, :, :3]

    tmin = q_data.times.value.min()
    tmax = q_data.times.value.max()

    fmin = q_data.frequencies.value.min()
    fmax = q_data.frequencies.value.max()

    plt.figure(figsize=(10, 6))

    plt.imshow(
        rgb,
        origin="lower",
        aspect="auto",
        extent=[fmin, fmax, tmin, tmax],
        interpolation="nearest",
    )

    plt.yscale("log")
    plt.axis("off")

    plt.savefig(path, dpi=save_dpi, bbox_inches="tight")
    plt.close()
