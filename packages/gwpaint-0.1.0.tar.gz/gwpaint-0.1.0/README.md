# gwpaint
Convert gravitational-wave spectrograms into paint-by-numbers grids for visualization and printable posters.
