"""Exceptions for the aiosolax library."""


class SolaxError(Exception):
    """Base exception for aiosolax."""


class SolaxConnectionError(SolaxError):
    """Cannot reach the dongle."""


class SolaxTimeoutError(SolaxError):
    """Request timed out."""


class SolaxAuthenticationError(SolaxError):
    """HTTP 401 — invalid credentials."""


class SolaxResponseError(SolaxError):
    """Invalid or unexpected response from the dongle."""


class SolaxAllZeroError(SolaxResponseError):
    """Data array is all zeros — inverter is offline/sleeping."""
