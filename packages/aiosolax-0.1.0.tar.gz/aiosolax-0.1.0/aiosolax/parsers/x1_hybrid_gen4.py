"""Parser for X1-Hybrid Gen4 (type 15) inverters."""

from __future__ import annotations

from .base import InverterParser, RegisterDefinition


class X1HybridGen4Parser(InverterParser):
    """Parser for X1-Hybrid Gen4 inverters (type code 15)."""

    @property
    def inverter_type(self) -> int:
        return 15

    @property
    def model_name(self) -> str:
        return "X1-Hybrid Gen4"

    @property
    def registers(self) -> tuple[RegisterDefinition, ...]:
        return (
            RegisterDefinition("grid_voltage", 0, scale=10),
            RegisterDefinition("grid_current", 1, scale=10, signed=True),
            RegisterDefinition("grid_power", 2, signed=True),
            RegisterDefinition("grid_frequency", 3, scale=100),
            RegisterDefinition("pv1_voltage", 4, scale=10),
            RegisterDefinition("pv2_voltage", 5, scale=10),
            RegisterDefinition("pv1_current", 6, scale=10),
            RegisterDefinition("pv2_current", 7, scale=10),
            RegisterDefinition("pv1_power", 8),
            RegisterDefinition("pv2_power", 9),
            RegisterDefinition("total_pv_energy", 11, scale=10, high_index=12),
            RegisterDefinition("today_pv_energy", 13, scale=10),
            RegisterDefinition("battery_voltage", 14, scale=100),
            RegisterDefinition("battery_current", 15, scale=100, signed=True),
            RegisterDefinition("battery_power", 16, signed=True),
            RegisterDefinition("battery_temperature", 17, signed=True),
            RegisterDefinition("battery_soc", 18),
            RegisterDefinition("inverter_temperature", 26, signed=True),
            RegisterDefinition("grid_power_io", 32, signed=True),
            RegisterDefinition("total_feed_in_energy", 34, scale=100, high_index=35),
            RegisterDefinition("total_consumption", 36, scale=100, high_index=37),
        )
