"""Parser registry for SolaX inverter models."""

from __future__ import annotations

from .base import InverterParser
from .x1_hybrid_gen4 import X1HybridGen4Parser

PARSERS: dict[int, InverterParser] = {
    15: X1HybridGen4Parser(),
}


def get_parser(inverter_type: int) -> InverterParser | None:
    """Get the parser for a given inverter type code."""
    return PARSERS.get(inverter_type)
