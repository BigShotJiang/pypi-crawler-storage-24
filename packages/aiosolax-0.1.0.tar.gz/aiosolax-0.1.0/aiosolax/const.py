"""Constants for the aiosolax library."""

DEFAULT_PORT = 80
DEFAULT_TIMEOUT = 10
