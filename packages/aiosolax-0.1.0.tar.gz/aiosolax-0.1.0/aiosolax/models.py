"""Data models for the aiosolax library."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class InverterInfo:
    """Inverter identification and firmware information."""

    serial_number: str
    inverter_type: int
    rated_power: float
    firmware_main: str
    firmware_sub: str


@dataclass(frozen=True)
class InverterData:
    """Parsed inverter sensor data."""

    grid_voltage: float
    grid_current: float
    grid_power: int
    grid_frequency: float
    pv1_voltage: float
    pv2_voltage: float
    pv1_current: float
    pv2_current: float
    pv1_power: int
    pv2_power: int
    total_pv_energy: float
    today_pv_energy: float
    battery_voltage: float
    battery_current: float
    battery_power: int
    battery_temperature: int
    battery_soc: int
    inverter_temperature: int
    grid_power_io: int
    total_feed_in_energy: float
    total_consumption: float
