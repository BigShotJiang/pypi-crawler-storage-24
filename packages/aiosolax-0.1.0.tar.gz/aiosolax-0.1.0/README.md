# aiosolax

Async Python client for SolaX PocketWiFi dongle HTTP API.
