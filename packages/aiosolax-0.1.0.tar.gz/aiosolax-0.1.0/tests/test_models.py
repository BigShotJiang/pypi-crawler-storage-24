"""Tests for data models."""

from __future__ import annotations

import pytest

from aiosolax.models import InverterData, InverterInfo


def test_inverter_info_frozen():
    """Test that InverterInfo is immutable."""
    info = InverterInfo(
        serial_number="TEST123",
        inverter_type=15,
        rated_power=3.7,
        firmware_main="V3.0",
        firmware_sub="1.0",
    )
    with pytest.raises(AttributeError):
        info.serial_number = "CHANGED"


def test_inverter_data_frozen():
    """Test that InverterData is immutable."""
    data = InverterData(
        grid_voltage=241.4,
        grid_current=3.2,
        grid_power=780,
        grid_frequency=49.93,
        pv1_voltage=321.5,
        pv2_voltage=187.0,
        pv1_current=8.9,
        pv2_current=4.2,
        pv1_power=2861,
        pv2_power=786,
        total_pv_energy=13259.5,
        today_pv_energy=4.5,
        battery_voltage=235.10,
        battery_current=-0.65,
        battery_power=-350,
        battery_temperature=22,
        battery_soc=45,
        inverter_temperature=34,
        grid_power_io=-120,
        total_feed_in_energy=152.34,
        total_consumption=1531.86,
    )
    with pytest.raises(AttributeError):
        data.grid_voltage = 240.0
