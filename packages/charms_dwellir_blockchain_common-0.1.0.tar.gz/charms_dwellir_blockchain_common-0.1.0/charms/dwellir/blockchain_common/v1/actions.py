"""Action helper utilities for stable v1."""

from __future__ import annotations

import datetime as dt
from pathlib import Path
import re

from .formatting import bytes_to_human_readable
from .process import run_command


def get_binary_last_changed(path: Path) -> str:
    """Return formatted UTC timestamp for binary change time from `stat` output."""
    target = Path(path)
    if not target.exists():
        return ""

    result = run_command(
        ["stat", str(target)],
        capture_output=True,
        check=False,
        text=True,
    )
    if result.returncode != 0:
        return ""

    output = result.stdout or ""
    match = re.search(r"^Change:\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2}:\d{2})", output, flags=re.MULTILINE)
    if not match:
        return ""
    return f"{match.group(1)} {match.group(2)} UTC"


def get_binary_last_updated(path: Path, include_relative: bool = True) -> str:
    """Return binary change timestamp and optional relative age."""
    last_changed = get_binary_last_changed(path)
    if not last_changed:
        return ""
    if not include_relative:
        return last_changed

    try:
        parsed = dt.datetime.strptime(last_changed, "%Y-%m-%d %H:%M:%S UTC").replace(tzinfo=dt.timezone.utc)
    except ValueError:
        return last_changed

    delta = dt.datetime.now(dt.timezone.utc) - parsed
    if delta.total_seconds() < 0:
        delta = dt.timedelta(0)

    if delta.days > 1:
        time_since = f"time since: {delta.days} days"
    elif delta.days == 1:
        hours = delta.seconds // 3600
        time_since = f"time since: 1 day, {hours} hours"
    else:
        hours, remainder = divmod(delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        time_since = f"time since: {hours}:{minutes}:{seconds}"

    return f"{last_changed} ({time_since})"


def get_binary_md5sum(path: Path) -> str:
    """Return md5 checksum for a binary path."""
    target = Path(path)
    if not target.exists():
        return ""

    result = run_command(
        ["md5sum", str(target)],
        capture_output=True,
        check=False,
        text=True,
    )
    if result.returncode != 0:
        return ""

    output = (result.stdout or "").strip()
    match = re.match(r"^([a-fA-F0-9]{32})\b", output)
    if not match:
        return ""
    return match.group(1)


def get_disk_usage(*paths: Path, method: str = "du") -> list[tuple[str, str]] | str:
    """Return disk usage for existing paths using `du`."""
    if method != "du":
        raise ValueError("method must be 'du'")

    disk_usages: list[tuple[str, str]] = []
    for raw_path in paths:
        path = Path(raw_path)
        if not path.exists():
            continue

        result = run_command(
            ["du", "-hs", str(path)],
            capture_output=True,
            check=False,
            text=True,
        )
        if result.returncode != 0:
            return "error parsing disk usage"
        fields = (result.stdout or "").strip().split()
        if not fields:
            return "error parsing disk usage"
        disk_usages.append((str(path), fields[0]))

    if disk_usages:
        return disk_usages
    return "error parsing disk usage"


def get_readme(path: Path = Path("README.md")) -> str:
    """Return README contents when present."""
    target = Path(path)
    if not target.exists():
        return ""
    try:
        return target.read_text(encoding="utf-8")
    except OSError:
        return ""
