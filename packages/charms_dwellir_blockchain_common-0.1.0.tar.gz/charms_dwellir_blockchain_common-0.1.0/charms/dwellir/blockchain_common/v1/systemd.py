"""Systemd-related helpers for stable v1 utilities."""

from __future__ import annotations

import re
import shlex
import shutil
import time
from pathlib import Path

from .process import run_command

DEFAULT_ENV_DIR = Path("/etc/default")
DEFAULT_SYSTEMD_DIR = Path("/etc/systemd/system")


def _normalize_env_name(service_name: str) -> str:
    """Convert service name into a shell-safe uppercase env prefix."""
    normalized = re.sub(r"[^A-Za-z0-9]+", "_", service_name).strip("_").upper()
    if not normalized:
        raise ValueError("service_name must include at least one alphanumeric character")
    return normalized


def _quote_env_value(value: str) -> str:
    """Single-quote an env value while escaping inner single quotes."""
    return value.replace("'", "'\"'\"'")


def create_env_file(service_name: str, env_var: str | None = None, initial_args: str = "") -> None:
    """Write /etc/default/<service> with CLI args env var."""
    service = service_name.strip()
    if not service:
        raise ValueError("service_name cannot be empty")

    if env_var is None:
        var_name = f"{_normalize_env_name(service)}_CLI_ARGS"
    else:
        var_name = env_var.strip()
    if not var_name:
        raise ValueError("env_var cannot be empty")

    target_path = DEFAULT_ENV_DIR / service
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_text(f"{var_name}='{_quote_env_value(initial_args)}'\n", encoding="utf-8")


def install_systemd_unit(source_path: str | Path, service_name: str, reload: bool = True) -> None:
    """Install a systemd unit file under /etc/systemd/system."""
    service = service_name.strip()
    if not service:
        raise ValueError("service_name cannot be empty")

    source = Path(source_path)
    target_path = DEFAULT_SYSTEMD_DIR / f"{service}.service"
    target_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target_path)

    if reload:
        run_command(["systemctl", "daemon-reload"])


def write_service_args(
    service_name: str,
    service_args: str,
    env_var: str | None = None,
    extra_env_lines: list[str] | None = None,
    restart: bool = False,
) -> None:
    """Compose and write service args to /etc/default/<service>."""
    service = service_name.strip()
    if not service:
        raise ValueError("service_name cannot be empty")

    if env_var is None:
        var_name = f"{_normalize_env_name(service)}_CLI_ARGS"
    else:
        var_name = env_var.strip()
    if not var_name:
        raise ValueError("env_var cannot be empty")

    merged_args = service_args.strip()

    lines = [f"{var_name}='{_quote_env_value(merged_args)}'"]
    if extra_env_lines:
        lines.extend(line.rstrip("\n") for line in extra_env_lines if line and line.strip())

    target_path = DEFAULT_ENV_DIR / service
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    if restart:
        run_command(["systemctl", "restart", f"{service}.service"], check=False)


def read_service_args(service_name: str, env_var: str | None = None) -> str:
    """Read service args string from /etc/default/<service>."""
    service = service_name.strip()
    if not service:
        raise ValueError("service_name cannot be empty")

    if env_var is None:
        var_name = f"{_normalize_env_name(service)}_CLI_ARGS"
    else:
        var_name = env_var.strip()
    if not var_name:
        raise ValueError("env_var cannot be empty")

    target_path = DEFAULT_ENV_DIR / service
    if not target_path.exists():
        return ""

    for raw_line in target_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        if not line.startswith(f"{var_name}="):
            continue

        value = line.split("=", 1)[1].strip()
        if len(value) >= 2 and value[0] == "'" and value[-1] == "'":
            return value[1:-1].replace("'\"'\"'", "'")
        if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
            return value[1:-1].replace('\\"', '"')
        return value
    return ""


def parse_service_arg_value(args: str, tag: str) -> str:
    """Parse and return value for --flag value or --flag=value argument forms."""
    raw_args = args.strip()
    normalized_tag = tag.strip()
    if not raw_args or not normalized_tag:
        return ""

    try:
        tokens = shlex.split(raw_args)
    except ValueError:
        tokens = raw_args.split()

    for index, token in enumerate(tokens):
        if token == normalized_tag:
            if index + 1 < len(tokens):
                next_token = tokens[index + 1]
                if not next_token.startswith("-"):
                    return next_token
            continue
        if token.startswith(f"{normalized_tag}="):
            return token.split("=", 1)[1]
    return ""


def service_status(service_name: str) -> bool:
    """Return whether `service <name> status` exits successfully."""
    service = service_name.strip()
    if not service:
        raise ValueError("service_name cannot be empty")

    status = run_command(["service", service, "status"], capture_output=True, check=False)
    return status.returncode == 0


def service_running(service_name: str, iterations: int = 4, delay_s: int = 2) -> bool:
    """Check service status with retries."""
    service = service_name.strip()
    if not service:
        raise ValueError("service_name cannot be empty")
    if iterations <= 0:
        return False

    for attempt in range(iterations):
        if service_status(service):
            return True
        if attempt < iterations - 1:
            time.sleep(delay_s)
    return False


def start_service(service_name: str) -> None:
    """Start a systemd service."""
    service = service_name.strip()
    if not service:
        raise ValueError("service_name cannot be empty")
    run_command(["systemctl", "start", f"{service}.service"], check=False)


def stop_service(service_name: str) -> None:
    """Stop a systemd service."""
    service = service_name.strip()
    if not service:
        raise ValueError("service_name cannot be empty")
    run_command(["systemctl", "stop", f"{service}.service"], check=False)


def restart_service(service_name: str) -> None:
    """Restart a systemd service."""
    service = service_name.strip()
    if not service:
        raise ValueError("service_name cannot be empty")
    run_command(["systemctl", "restart", f"{service}.service"], check=False)


def service_args_duplication(service_args_first: str, service_args_second: str) -> bool:
    """Return whether two service-args strings share any duplicate flags."""
    if not service_args_first.strip() or not service_args_second.strip():
        return False

    def _tokens(raw: str) -> list[str]:
        try:
            return shlex.split(raw)
        except ValueError:
            return raw.split()

    def _normalize_flag(token: str) -> str:
        if not token.startswith("-"):
            return ""
        if "=" in token:
            return token.split("=", 1)[0]
        return token

    first_flags = {_normalize_flag(token) for token in _tokens(service_args_first)}
    second_flags = {_normalize_flag(token) for token in _tokens(service_args_second)}
    first_flags.discard("")
    second_flags.discard("")

    return bool(first_flags & second_flags)
