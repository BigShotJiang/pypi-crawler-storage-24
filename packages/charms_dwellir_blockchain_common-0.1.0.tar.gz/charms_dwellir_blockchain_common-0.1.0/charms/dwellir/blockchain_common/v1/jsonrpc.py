"""JSON-RPC helpers for blockchain workloads."""

from __future__ import annotations

import json
import socket
from typing import Sequence
from urllib import error as urlerror
from urllib import request


def jsonrpc_call(
    url: str,
    method: str,
    params: Sequence[object] | None = None,
    timeout_s: float = 2.5,
) -> tuple[object | None, str | None]:
    """Perform a JSON-RPC call and return (result, error_message)."""
    if not isinstance(url, str) or not url.strip():
        return None, "url must be a non-empty string"
    if not isinstance(method, str) or not method.strip():
        return None, "method must be a non-empty string"
    if timeout_s <= 0:
        return None, "timeout_s must be > 0"
    if params is not None and isinstance(params, (str, bytes)):
        return None, "params must be a sequence, not a string"

    payload = json.dumps(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": list(params or []),
        }
    ).encode("utf-8")
    req = request.Request(url.strip(), data=payload, headers={"Content-Type": "application/json"})
    try:
        with request.urlopen(req, timeout=timeout_s) as response:
            data = json.loads(response.read().decode("utf-8"))
    except socket.timeout:
        return None, f"rpc {method} timeout after {timeout_s}s (url={url})"
    except urlerror.URLError as exc:
        reason = getattr(exc, "reason", exc)
        return None, f"rpc {method} connection error (url={url}): {reason}"
    except Exception as exc:  # noqa: BLE001
        return None, f"rpc {method} unexpected error (url={url}): {exc}"

    if not isinstance(data, dict):
        return None, f"rpc {method} invalid JSON response: expected object"
    if "error" in data and data["error"] is not None:
        return None, f"rpc {method} error: {data['error']}"
    return data.get("result"), None


def evm_chain_id(url: str) -> tuple[int | None, str | None]:
    """Return EVM chain ID from `eth_chainId`."""
    result, err = jsonrpc_call(url, "eth_chainId")
    if err:
        return None, err
    if isinstance(result, int) and not isinstance(result, bool):
        return result, None
    if not isinstance(result, str):
        return None, f"rpc eth_chainId parse error for {result!r}: expected hex string"
    if not result.startswith("0x"):
        return None, f"rpc eth_chainId parse error for {result!r}: expected 0x-prefixed hex string"
    try:
        return int(result, 16), None
    except Exception as exc:  # noqa: BLE001
        return None, f"rpc eth_chainId parse error for {result!r}: {exc}"


def evm_network_id(url: str) -> tuple[str | None, str | None]:
    """Return EVM network ID from `net_version` as string."""
    result, err = jsonrpc_call(url, "net_version")
    if err:
        return None, err
    if isinstance(result, str):
        return result, None
    if isinstance(result, int) and not isinstance(result, bool):
        return str(result), None
    return None, f"rpc net_version parse error for {result!r}: expected string or int"


def evm_web3_client_version(url: str) -> tuple[str | None, str | None]:
    """Return EVM client version from `web3_clientVersion`."""
    result, err = jsonrpc_call(url, "web3_clientVersion")
    if err:
        return None, err
    if not isinstance(result, str) or not result:
        return None, f"rpc web3_clientVersion parse error for {result!r}: expected non-empty string"
    return result, None
