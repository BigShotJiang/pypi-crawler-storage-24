"""Crypto helpers for stable v1 utilities."""

from __future__ import annotations

import secrets
from pathlib import Path

from ._helpers import normalize_owner
from .process import run_command

SUPPORTED_JWT_MODES = {"openssl", "python"}


def _is_hex_string(value: str) -> bool:
    """Return whether the value contains only hexadecimal characters."""
    if not value:
        return False
    return all(char in "0123456789abcdefABCDEF" for char in value)


def write_jwt_secret(
    path: Path,
    prefix: str = "",
    mode: str = "openssl",
    owner: tuple[str, str] | None = None,
    chmod: str = "600",
) -> None:
    """Create a 32-byte hex JWT secret and write it to path."""
    normalized_mode = mode.strip().lower()
    if normalized_mode not in SUPPORTED_JWT_MODES:
        raise ValueError("mode must be one of: openssl, python")

    normalized_chmod = chmod.strip()
    if not normalized_chmod:
        raise ValueError("chmod cannot be empty")

    normalized_owner = normalize_owner(owner)

    if normalized_mode == "openssl":
        result = run_command(
            ["openssl", "rand", "-hex", "32"],
            capture_output=True,
            check=False,
            text=True,
        )
        if result.returncode != 0:
            stderr = (result.stderr or "").strip()
            stdout = (result.stdout or "").strip()
            details = stderr or stdout or f"exit code {result.returncode}"
            raise ValueError(f"failed to generate jwt secret with openssl: {details}")
        raw_secret = (result.stdout or "").strip()
    else:
        raw_secret = secrets.token_hex(32)

    if len(raw_secret) != 64 or not _is_hex_string(raw_secret):
        raise ValueError("generated jwt secret must be a 64-character hex string")

    target_path = Path(path)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_text(f"{prefix}{raw_secret}", encoding="utf-8")

    if normalized_owner is not None:
        user, group = normalized_owner
        run_command(["chown", f"{user}:{group}", str(target_path)])
    run_command(["chmod", normalized_chmod, str(target_path)])
