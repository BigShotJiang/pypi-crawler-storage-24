"""Configuration helper utilities for stable v1."""

from __future__ import annotations

from collections.abc import Mapping


def _format_quoted_keys(keys: list[str], conjunction: str = "and") -> str:
    if len(keys) == 1:
        return f"'{keys[0]}'"
    if len(keys) == 2:
        return f"'{keys[0]}' {conjunction} '{keys[1]}'"
    head = ", ".join(f"'{key}'" for key in keys[:-1])
    return f"{head} {conjunction} '{keys[-1]}'"


def require_one_of(config: Mapping[str, object], keys: list[str]) -> None:
    """Require at least one key to be set in config."""
    if not keys:
        raise ValueError("keys must not be empty")

    if any(config.get(key) for key in keys):
        return

    if len(keys) == 1:
        raise ValueError(f"Charm requires config '{keys[0]}' to be set!")

    quoted = _format_quoted_keys(keys, conjunction="and")
    raise ValueError(f"Charm requires at least one of configs {quoted} to be set!")


def enforce_mutually_exclusive(config: Mapping[str, object], keys: list[str]) -> None:
    """Require at most one key to be set among a mutually exclusive set."""
    if not keys:
        raise ValueError("keys must not be empty")

    enabled = [key for key in keys if config.get(key)]
    if len(enabled) < 2:
        return

    quoted = _format_quoted_keys(keys, conjunction="or")
    raise ValueError(f"Only one of configs {quoted} can be set at the same time!")


def nested_keys_exist(mapping: Mapping[object, object], *keys: object) -> bool:
    """Return True when all nested keys exist in mapping."""
    if len(keys) == 0:
        raise AttributeError("nested_keys_exist() expects at least one 'keys' argument.")

    current: object = mapping
    for key in keys:
        if not isinstance(current, Mapping):
            return False
        try:
            if key not in current:
                return False
            current = current[key]  # type: ignore[index]
        except TypeError:
            return False
    return True
