"""Download helpers for stable v1 utilities."""

from __future__ import annotations

import hashlib
from pathlib import Path
import shutil
import tarfile
import tempfile
from typing import Callable
from urllib.parse import urlparse
from uuid import uuid4
import zipfile

import requests

from ._helpers import normalize_owner
from .process import run_command

SUPPORTED_DOWNLOAD_TOOLS = {"aria2c", "requests", "wget"}
SUPPORTED_TAR_URL_SUFFIXES = (".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz", ".tar.zst", ".tar")
SUPPORTED_ARCHIVE_FORMATS = {"auto", "tar", "tar.gz", "tgz", "tar.bz2", "tbz2", "tar.xz", "txz", "tar.zst", "zip"}
SUPPORTED_DOCKER_EXTRACT_STRATEGIES = {"cli", "sdk"}


def _download_with_requests(url: str, target_path: Path) -> None:
    """Download URL to target path using requests streaming."""
    with requests.get(url, stream=True, allow_redirects=True, timeout=None) as response:
        response.raise_for_status()
        with target_path.open("wb") as file_handle:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    file_handle.write(chunk)


def download_file(url: str, target_path: Path, tool: str = "requests") -> None:
    """Download a file, preferring aria2c with requests/wget fallbacks."""
    normalized_url = url.strip()
    if not normalized_url:
        raise ValueError("url cannot be empty")

    normalized_tool = tool.strip().lower()
    if normalized_tool not in SUPPORTED_DOWNLOAD_TOOLS:
        raise ValueError("tool must be one of: aria2c, requests, wget")

    target = Path(target_path)
    target.parent.mkdir(parents=True, exist_ok=True)

    orders = {
        "aria2c": ["aria2c", "requests", "wget"],
        "requests": ["requests", "wget"],
        "wget": ["wget", "requests"],
    }

    errors: list[str] = []
    for candidate in orders[normalized_tool]:
        try:
            if candidate == "aria2c":
                result = run_command(
                    ["aria2c", "-o", target.name, "--file-allocation=none", normalized_url],
                    cwd=target.parent,
                    capture_output=True,
                    check=False,
                    text=True,
                )
                if result.returncode == 0:
                    return
                errors.append(f"aria2c failed: {_command_failure_details(result)}")
            elif candidate == "requests":
                _download_with_requests(normalized_url, target)
                return
            else:
                result = run_command(
                    ["wget", "-O", str(target), normalized_url],
                    capture_output=True,
                    check=False,
                    text=True,
                )
                if result.returncode == 0:
                    return
                errors.append(f"wget failed: {_command_failure_details(result)}")
        except Exception as exc:  # pragma: no cover - covered by explicit tests via fake exceptions
            errors.append(f"{candidate} failed: {exc}")

    raise ValueError(f"download failed for {normalized_url}: {'; '.join(errors)}")


def _tar_extract_command(archive_path: Path, url_path: str) -> list[str]:
    """Build tar extraction command from URL path suffix."""
    lowered = url_path.lower()
    if lowered.endswith(".tar.gz") or lowered.endswith(".tgz"):
        return ["tar", "-zxf", str(archive_path)]
    if lowered.endswith(".tar.bz2") or lowered.endswith(".tbz2"):
        return ["tar", "-jxf", str(archive_path)]
    if lowered.endswith(".tar.xz") or lowered.endswith(".txz"):
        return ["tar", "-Jxf", str(archive_path)]
    if lowered.endswith(".tar.zst"):
        if shutil.which("zstd") is None:
            raise ValueError("zstd is required to extract .tar.zst archives; install the `zstd` package")
        return ["tar", "-I", "zstd", "-xf", str(archive_path)]
    if lowered.endswith(".tar"):
        return ["tar", "-xf", str(archive_path)]
    raise ValueError(
        "unsupported archive format; expected one of: .tar, .tar.gz, .tgz, .tar.zst, .tar.bz2/.tbz2, .tar.xz/.txz"
    )


def download_extract_tar(url: str, extract_dir: Path, files_to_extract: list[str] | None = None) -> None:
    """Download and extract a tar archive to extract_dir."""
    normalized_url = url.strip()
    if not normalized_url:
        raise ValueError("url cannot be empty")

    parsed_path = urlparse(normalized_url).path
    if not parsed_path.lower().endswith(SUPPORTED_TAR_URL_SUFFIXES):
        raise ValueError(
            "unsupported archive format; expected one of: .tar, .tar.gz, .tgz, .tar.zst, .tar.bz2/.tbz2, .tar.xz/.txz"
        )

    extract_path = Path(extract_dir)
    extract_path.mkdir(parents=True, exist_ok=True)

    with tempfile.NamedTemporaryFile(prefix="download-", suffix=".tar", delete=False) as temp_file:
        archive_path = Path(temp_file.name)

    try:
        download_file(normalized_url, archive_path)
        archive_format = _normalize_archive_format(parsed_path, "auto")
        _extract_tar_archive(
            archive_path,
            archive_format,
            extract_path,
            members_to_extract=files_to_extract,
            field_name="files_to_extract",
        )
    finally:
        archive_path.unlink(missing_ok=True)


def _extract_sha256_token(payload: str) -> str:
    """Extract first sha256 token from payload text."""
    for token in payload.replace("\n", " ").split():
        candidate = token.strip().lower()
        if len(candidate) == 64 and all(char in "0123456789abcdef" for char in candidate):
            return candidate
    return ""


def _command_failure_details(result: object) -> str:
    """Return best-effort error details from a command result-like object."""
    stderr = (getattr(result, "stderr", "") or "").strip()
    stdout = (getattr(result, "stdout", "") or "").strip()
    return stderr or stdout or f"exit code {getattr(result, 'returncode', 'unknown')}"


def _require_non_empty(value: str, field_name: str) -> str:
    """Return stripped value and raise when empty."""
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{field_name} cannot be empty")
    return normalized


def _finalize_binary_install(
    source_path: Path,
    target_path: Path,
    stop_func: Callable[[], None] | None = None,
    start_func: Callable[[], None] | None = None,
    owner: tuple[str, str] | None = None,
    chmod: str = "+x",
) -> None:
    """Move staged binary into place and apply optional ownership/mode/hooks."""
    target = Path(target_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if stop_func:
        stop_func()
    shutil.move(str(source_path), str(target))
    if owner is not None:
        user, group = owner
        run_command(["chown", f"{user}:{group}", str(target)])
    run_command(["chmod", chmod, str(target)])
    if start_func:
        start_func()


def _normalize_archive_format(url: str, archive_format: str) -> str:
    """Resolve archive format from an explicit value or URL suffix."""
    normalized_format = archive_format.strip().lower()
    if normalized_format == "tbz2":
        normalized_format = "tar.bz2"
    elif normalized_format == "txz":
        normalized_format = "tar.xz"
    if normalized_format not in SUPPORTED_ARCHIVE_FORMATS:
        raise ValueError(
            "archive_format must be one of: auto, tar, tar.gz, tgz, tar.bz2/tbz2, tar.xz/txz, tar.zst, zip"
        )

    if normalized_format != "auto":
        return normalized_format

    parsed_path = urlparse(url).path.lower()
    if parsed_path.endswith(".zip"):
        return "zip"
    if parsed_path.endswith(".tar.gz"):
        return "tar.gz"
    if parsed_path.endswith(".tgz"):
        return "tgz"
    if parsed_path.endswith(".tar.bz2"):
        return "tar.bz2"
    if parsed_path.endswith(".tbz2"):
        return "tar.bz2"
    if parsed_path.endswith(".tar.xz"):
        return "tar.xz"
    if parsed_path.endswith(".txz"):
        return "tar.xz"
    if parsed_path.endswith(".tar.zst"):
        return "tar.zst"
    if parsed_path.endswith(".tar"):
        return "tar"
    raise ValueError(
        "unsupported archive format; expected one of: .tar, .tar.gz, .tgz, .tar.zst, .tar.bz2/.tbz2, .tar.xz/.txz, .zip"
    )


def _normalized_members(members: list[str] | None, field_name: str = "members_to_extract") -> list[str]:
    """Validate and normalize members to extract from an archive."""
    if not members:
        return []
    normalized_members = []
    for member in members:
        candidate = member.strip()
        if not candidate:
            raise ValueError(f"{field_name} entries must be non-empty")
        normalized_members.append(candidate)
    return normalized_members


def _extract_tar_archive(
    archive_path: Path,
    archive_format: str,
    extract_dir: Path,
    members_to_extract: list[str] | None = None,
    field_name: str = "members_to_extract",
) -> None:
    """Extract supported tar archives to extract_dir."""
    tar_suffix = {
        "tar": ".tar",
        "tar.gz": ".tar.gz",
        "tgz": ".tgz",
        "tar.bz2": ".tar.bz2",
        "tar.xz": ".tar.xz",
        "tar.zst": ".tar.zst",
    }[archive_format]
    command = _tar_extract_command(archive_path, f"archive{tar_suffix}")
    members = _normalized_members(members_to_extract, field_name=field_name)
    if members:
        command.append("--")
        command.extend(members)
    run_command(command, cwd=extract_dir)


def _extract_zip_archive(
    archive_path: Path,
    extract_dir: Path,
    members_to_extract: list[str] | None = None,
) -> None:
    """Extract zip archive entries to extract_dir."""
    members = _normalized_members(members_to_extract)
    with zipfile.ZipFile(archive_path) as archive:
        all_members = archive.namelist()
        targets = members or [name for name in all_members if not name.endswith("/")]
        for member in targets:
            if member not in all_members:
                raise ValueError(f"zip archive does not contain requested member: {member}")
            if member.endswith("/"):
                continue
            destination = extract_dir / member
            extract_root = extract_dir.resolve()
            resolved_destination = destination.resolve()
            if extract_root != resolved_destination and extract_root not in resolved_destination.parents:
                raise ValueError(f"unsafe zip member path: {member}")
            resolved_destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as source_file, resolved_destination.open("wb") as target_file:
                shutil.copyfileobj(source_file, target_file)


def _find_source_binary(
    extract_dir: Path,
    target_path: Path,
    members_to_extract: list[str] | None = None,
) -> Path:
    """Locate installed binary path inside extract_dir."""
    members = _normalized_members(members_to_extract)
    if members:
        if len(members) != 1:
            raise ValueError(
                "members_to_extract must contain exactly one file entry when installing to a single target_path"
            )
        expected_member = members[0]
        direct_path = extract_dir / expected_member
        if direct_path.is_file():
            return direct_path
        base_name_matches = sorted(
            candidate for candidate in extract_dir.rglob(Path(expected_member).name) if candidate.is_file()
        )
        if len(base_name_matches) == 1:
            return base_name_matches[0]
        if len(base_name_matches) > 1:
            raise ValueError(
                f"multiple extracted files matched member '{expected_member}'; use a more specific member path"
            )
        raise FileNotFoundError(f"extracted member not found: {expected_member}")

    matches = sorted(candidate for candidate in extract_dir.rglob(target_path.name) if candidate.is_file())
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise ValueError(
            f"multiple extracted files named '{target_path.name}' found; pass members_to_extract to disambiguate"
        )
    raise FileNotFoundError(
        f"could not find extracted file named '{target_path.name}'; pass members_to_extract for explicit selection"
    )


def _docker_temp_container_name() -> str:
    """Generate a unique temporary container name for docker extraction."""
    return f"bcl-extract-{uuid4().hex[:12]}"


def _extract_from_docker_image_cli(
    image: str,
    tag: str,
    source_path: str,
    staged_path: Path,
) -> None:
    """Extract a file from docker image using docker CLI commands."""
    container_name = _docker_temp_container_name()
    image_ref = f"{image}:{tag}"
    container_created = False
    try:
        pull_result = run_command(
            ["docker", "pull", image_ref],
            capture_output=True,
            check=False,
            text=True,
        )
        if pull_result.returncode != 0:
            raise ValueError(f"docker pull failed for {image_ref}: {_command_failure_details(pull_result)}")

        create_result = run_command(
            ["docker", "create", "--name", container_name, image_ref],
            capture_output=True,
            check=False,
            text=True,
        )
        if create_result.returncode != 0:
            raise ValueError(f"docker create failed for {image_ref}: {_command_failure_details(create_result)}")
        container_created = True

        copy_result = run_command(
            ["docker", "cp", f"{container_name}:{source_path}", str(staged_path)],
            capture_output=True,
            check=False,
            text=True,
        )
        if copy_result.returncode != 0:
            raise ValueError(f"docker cp failed from {source_path}: {_command_failure_details(copy_result)}")
    finally:
        if container_created:
            run_command(
                ["docker", "rm", "-f", container_name],
                capture_output=True,
                check=False,
                text=True,
            )


def _extract_from_docker_image_sdk(
    image: str,
    tag: str,
    source_path: str,
    staged_path: Path,
) -> None:
    """Extract a file from docker image using the docker Python SDK."""
    try:
        from docker import from_env as docker_from_env
    except ImportError as exc:
        raise ValueError("docker Python SDK is required for strategy='sdk'") from exc

    client = docker_from_env()
    container = None
    try:
        image_obj = client.images.pull(image, tag=tag)
        container = client.containers.create(image_obj)
        archive_stream, _ = container.get_archive(source_path)

        with tempfile.NamedTemporaryFile(prefix="docker-sdk-", suffix=".tar", delete=False) as temp_tar:
            tar_path = Path(temp_tar.name)
            for chunk in archive_stream:
                temp_tar.write(chunk)

        try:
            with tarfile.open(tar_path, mode="r:*") as archive:
                file_members = [member for member in archive.getmembers() if member.isfile()]
                if not file_members:
                    raise FileNotFoundError(f"docker archive did not contain a file for {source_path}")
                source_name = Path(source_path).name
                matching_members = [member for member in file_members if Path(member.name).name == source_name]
                if len(matching_members) == 1:
                    selected_member = matching_members[0]
                elif len(matching_members) == 0 and len(file_members) == 1:
                    selected_member = file_members[0]
                else:
                    raise ValueError(
                        f"docker archive contained multiple candidate files for {source_path}; cannot disambiguate"
                    )
                extracted_file = archive.extractfile(selected_member)
                if extracted_file is None:
                    raise FileNotFoundError(f"failed to read archived member for {source_path}")
                with staged_path.open("wb") as target_file:
                    shutil.copyfileobj(extracted_file, target_file)
        finally:
            tar_path.unlink(missing_ok=True)
    finally:
        if container is not None:
            container.remove(force=True)
        client.close()


def perform_sha256_checksum_from_string(file_path: Path, expected_sha256: str) -> None:
    """Validate file SHA256 against provided checksum string."""
    target_file = Path(file_path)
    if not target_file.exists():
        raise FileNotFoundError(f"file does not exist: {target_file}")

    expected_checksum = _extract_sha256_token(expected_sha256)
    if not expected_checksum:
        raise ValueError("expected_sha256 must include a valid 64-character hex checksum")

    digest = hashlib.sha256()
    with target_file.open("rb") as file_handle:
        for chunk in iter(lambda: file_handle.read(8192), b""):
            digest.update(chunk)
    local_checksum = digest.hexdigest().lower()

    if local_checksum != expected_checksum:
        raise ValueError(f"sha256 mismatch for {target_file}: expected {expected_checksum}, got {local_checksum}")


def perform_sha256_checksum_from_url(file_path: Path, sha256_url: str) -> None:
    """Validate file SHA256 against checksum content fetched from URL."""
    target_file = Path(file_path)
    if not target_file.exists():
        raise FileNotFoundError(f"file does not exist: {target_file}")

    checksum_url = sha256_url.strip()
    if not checksum_url:
        raise ValueError("sha256_url cannot be empty")

    try:
        response = requests.get(checksum_url, allow_redirects=True, timeout=None)
        response.raise_for_status()
    except requests.RequestException as exc:
        raise ValueError(f"failed to retrieve checksum from {checksum_url}: {exc}") from exc

    if not _extract_sha256_token(response.text):
        raise ValueError(f"invalid checksum payload from {checksum_url}")
    perform_sha256_checksum_from_string(target_file, response.text)


def install_binary_from_url(
    url: str,
    target_path: Path,
    sha256_url: str | None = None,
    stop_func: Callable[[], None] | None = None,
    start_func: Callable[[], None] | None = None,
    owner: tuple[str, str] | None = None,
    chmod: str = "+x",
) -> None:
    """Install a binary by downloading to a temporary path and moving into place."""
    normalized_url = _require_non_empty(url, "url")
    mode = _require_non_empty(chmod, "chmod")
    normalized_owner = normalize_owner(owner)

    target = Path(target_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp_target = target.parent / f"{target.name}.tmp"

    try:
        download_file(normalized_url, temp_target)
        if sha256_url:
            perform_sha256_checksum_from_url(temp_target, sha256_url)
        _finalize_binary_install(
            temp_target,
            target,
            stop_func=stop_func,
            start_func=start_func,
            owner=normalized_owner,
            chmod=mode,
        )
    finally:
        temp_target.unlink(missing_ok=True)


def install_binary_from_deb(
    url: str,
    sha256_url: str | None = None,
    stop_func: Callable[[], None] | None = None,
    start_func: Callable[[], None] | None = None,
) -> None:
    """Install a .deb package from URL via dpkg."""
    normalized_url = _require_non_empty(url, "url")

    with tempfile.TemporaryDirectory(prefix="deb-install-") as tmp_directory:
        temp_root = Path(tmp_directory)
        deb_path = temp_root / "package.deb"
        download_file(normalized_url, deb_path)
        if sha256_url:
            perform_sha256_checksum_from_url(deb_path, sha256_url)
        if stop_func:
            stop_func()
        result = run_command(
            ["dpkg", "-i", str(deb_path)],
            capture_output=True,
            check=False,
            text=True,
        )
        if result.returncode != 0:
            raise ValueError(f"dpkg install failed for {deb_path}: {_command_failure_details(result)}")
        if start_func:
            start_func()


def install_binary_from_docker_image_tag(
    image: str,
    tag: str,
    source_path: str,
    target_path: Path,
    stop_func: Callable[[], None] | None = None,
    start_func: Callable[[], None] | None = None,
    strategy: str = "cli",
) -> None:
    """Extract a binary from docker image/tag inputs and install it at target_path."""
    normalized_image = _require_non_empty(image, "image")
    normalized_tag = _require_non_empty(tag, "tag")
    normalized_source = _require_non_empty(source_path, "source_path")
    normalized_strategy = _require_non_empty(strategy, "strategy").lower()
    if normalized_strategy not in SUPPORTED_DOCKER_EXTRACT_STRATEGIES:
        raise ValueError("strategy must be one of: cli, sdk")

    target = Path(target_path)
    target.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="docker-extract-") as tmp_directory:
        staged_path = Path(tmp_directory) / target.name
        if normalized_strategy == "cli":
            _extract_from_docker_image_cli(
                normalized_image,
                normalized_tag,
                normalized_source,
                staged_path,
            )
        else:
            _extract_from_docker_image_sdk(
                normalized_image,
                normalized_tag,
                normalized_source,
                staged_path,
            )

        _finalize_binary_install(
            staged_path,
            target,
            stop_func=stop_func,
            start_func=start_func,
            chmod="+x",
        )


def _split_docker_image_reference(image_reference: str) -> tuple[str, str]:
    """Split a docker image reference in `<image>:<tag>` format."""
    normalized_reference = _require_non_empty(image_reference, "image_reference")
    if "@" in normalized_reference:
        raise ValueError("image_reference must include an explicit ':<tag>' and cannot use digests")

    last_slash_index = normalized_reference.rfind("/")
    last_colon_index = normalized_reference.rfind(":")
    if last_colon_index <= last_slash_index:
        raise ValueError("image_reference must include an explicit ':<tag>'")

    image = normalized_reference[:last_colon_index]
    tag = normalized_reference[last_colon_index + 1 :]
    if not image or not tag:
        raise ValueError("image_reference must include a non-empty image and tag")
    return image, tag


def install_binary_from_docker_image_reference(
    image_reference: str,
    source_path: str,
    target_path: Path,
    stop_func: Callable[[], None] | None = None,
    start_func: Callable[[], None] | None = None,
    strategy: str = "cli",
) -> None:
    """Extract a binary from a docker image reference in `<image>:<tag>` format."""
    image, tag = _split_docker_image_reference(image_reference)
    install_binary_from_docker_image_tag(
        image,
        tag,
        source_path,
        target_path,
        stop_func=stop_func,
        start_func=start_func,
        strategy=strategy,
    )


def install_binary_from_archive(
    url: str,
    target_path: Path,
    archive_format: str = "auto",
    members_to_extract: list[str] | None = None,
    sha256_url: str | None = None,
    stop_func: Callable[[], None] | None = None,
    start_func: Callable[[], None] | None = None,
    owner: tuple[str, str] | None = None,
    chmod: str = "+x",
) -> None:
    """Install a binary from an archive URL by extracting and moving into place."""
    normalized_url = _require_non_empty(url, "url")
    mode = _require_non_empty(chmod, "chmod")
    normalized_owner = normalize_owner(owner)

    normalized_format = _normalize_archive_format(normalized_url, archive_format)
    target = Path(target_path)
    target.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="archive-install-") as tmp_directory:
        temp_root = Path(tmp_directory)
        archive_path = temp_root / f"archive.{normalized_format.replace('.', '-')}"
        extract_dir = temp_root / "extract"
        extract_dir.mkdir(parents=True, exist_ok=True)

        download_file(normalized_url, archive_path)
        if sha256_url:
            perform_sha256_checksum_from_url(archive_path, sha256_url)

        if normalized_format == "zip":
            _extract_zip_archive(archive_path, extract_dir, members_to_extract=members_to_extract)
        else:
            _extract_tar_archive(
                archive_path,
                normalized_format,
                extract_dir,
                members_to_extract=members_to_extract,
            )

        source_binary = _find_source_binary(extract_dir, target, members_to_extract=members_to_extract)
        _finalize_binary_install(
            source_binary,
            target,
            stop_func=stop_func,
            start_func=start_func,
            owner=normalized_owner,
            chmod=mode,
        )
