"""Private helper functions shared across v1 modules."""

from __future__ import annotations


def normalize_owner(owner: tuple[str, str] | None) -> tuple[str, str] | None:
    """Normalize owner tuple and validate user/group values."""
    if owner is None:
        return None
    user, group = owner
    normalized_user = user.strip()
    normalized_group = group.strip()
    if not normalized_user or not normalized_group:
        raise ValueError("owner must include non-empty user and group")
    return normalized_user, normalized_group
