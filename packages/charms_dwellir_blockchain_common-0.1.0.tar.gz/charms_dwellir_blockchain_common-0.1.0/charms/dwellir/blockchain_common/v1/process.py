"""Process helpers for stable v1 utilities."""

from __future__ import annotations

import os
import shlex
import subprocess as sp
from pathlib import Path
from typing import Mapping, Sequence


def _as_command_list(command: str | Sequence[str]) -> list[str]:
    """Normalize command into a list for non-shell execution."""
    if isinstance(command, str):
        return shlex.split(command)
    return [str(part) for part in command]


def _as_shell_command(command: str | Sequence[str]) -> str:
    """Normalize command into a shell-safe string for shell execution."""
    if isinstance(command, str):
        return command
    return shlex.join(str(part) for part in command)


def run_command(
    command: str | Sequence[str],
    capture_output: bool = False,
    check: bool = True,
    cwd: Path | None = None,
    shell: bool = False,
    text: bool | None = None,
    user: str | None = None,
    group: str | None = None,
    env: Mapping[str, str] | None = None,
    timeout_s: float | None = None,
) -> sp.CompletedProcess:
    """Execute a command using a strict, testable subprocess contract."""
    normalized_command: str | list[str]
    if shell:
        normalized_command = _as_shell_command(command)
    else:
        normalized_command = _as_command_list(command)

    shell_to_pass = shell
    if user or group:
        sudo_prefix = ["sudo"]
        if user:
            sudo_prefix.extend(["-u", user])
        if group:
            sudo_prefix.extend(["-g", group])

        if shell:
            shell_command = (
                normalized_command
                if isinstance(normalized_command, str)
                else _as_shell_command(normalized_command)
            )
            normalized_command = sudo_prefix + ["--", "sh", "-c", shell_command]
        else:
            command_list = (
                normalized_command
                if isinstance(normalized_command, list)
                else _as_command_list(normalized_command)
            )
            normalized_command = sudo_prefix + ["--", *command_list]
        shell_to_pass = False

    kwargs: dict[str, object] = {
        "capture_output": capture_output,
        "check": check,
        "cwd": cwd,
        "shell": shell_to_pass,
        "timeout": timeout_s,
    }
    if text is not None:
        kwargs["text"] = text
    if env is not None:
        merged_env = os.environ.copy()
        merged_env.update({str(key): str(value) for key, value in env.items()})
        kwargs["env"] = merged_env

    return sp.run(normalized_command, **kwargs)


def get_process_id(user_or_binary: str) -> str:
    """Return the first PID for a user or binary name using pgrep."""
    user_match = run_command(
        ["pgrep", "-u", user_or_binary],
        capture_output=True,
        check=False,
        text=True,
    )
    user_stdout = (user_match.stdout or "").strip()
    if user_stdout:
        return user_stdout.splitlines()[0].strip()

    binary_match = run_command(
        ["pgrep", user_or_binary],
        capture_output=True,
        check=False,
        text=True,
    )
    binary_stdout = (binary_match.stdout or "").strip()
    if binary_stdout:
        return binary_stdout.splitlines()[0].strip()
    return ""


def get_proc_cmdline(pid: str) -> str:
    """Read /proc/<pid>/cmdline and normalize NUL separators to spaces."""
    pid_clean = pid.strip()
    if not pid_clean:
        return ""

    cmdline_path = Path(f"/proc/{pid_clean}/cmdline")
    try:
        raw_cmdline = cmdline_path.read_bytes()
    except OSError:
        return ""

    if not raw_cmdline:
        return ""

    parts = [part.decode("utf-8", errors="replace") for part in raw_cmdline.split(b"\x00") if part]
    return " ".join(parts).strip()
