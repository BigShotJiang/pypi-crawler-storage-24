"""Formatting helper utilities for stable v1."""

from __future__ import annotations


def bytes_to_human_readable(num_bytes: int) -> str:
    """Convert bytes to human-readable units."""
    if num_bytes < 0:
        raise ValueError("num_bytes must be >= 0")

    suffixes = ["B", "K", "M", "G", "T", "P"]
    value = float(num_bytes)
    index = 0
    while value >= 1024 and index < len(suffixes) - 1:
        value /= 1024.0
        index += 1
    rendered = f"{value:.2f}".rstrip("0").rstrip(".")
    return f"{rendered}{suffixes[index]}"
