import json
import socket
from typing import Any, Dict, List
from urllib import request, error as urlerror


def api_call(url: str, method: str = "GET", req_data: Dict | List = None, timeout_s: float = 2.5,) -> Any:
    """Perform a JSON-A call and return (result, error_message)."""

    if not isinstance(url, str) or not url.strip():
        return None, "url must be a non-empty string"
    if not isinstance(method, str) or method not in ("GET", "POST", "PUT", "DELETE", "PATCH"):
        return None, "method must be 'GET', 'POST', 'PUT', 'DELETE', or 'PATCH'"
    if timeout_s <= 0:
        return None, "timeout_s must be > 0"
    
    payload = json.dumps(req_data).encode("utf-8") if req_data else None
    req = request.Request(url.strip(), data=payload, headers={"Content-Type": "application/json"}, method=method)
    try:
        with request.urlopen(req, timeout=timeout_s) as response:
            data = json.loads(response.read().decode("utf-8"))
    except socket.timeout:
        return None, f"api {method} timeout after {timeout_s}s (url={url})"
    except urlerror.URLError as exc:
        reason = getattr(exc, "reason", exc)
        return None, f"api {method} connection error (url={url}): {reason}"
    except Exception as exc:  # noqa: BLE001
        return None, f"api {method} unexpected error (url={url}): {exc}"

    if not isinstance(data, dict):
        return None, f"api {method} invalid JSON response: expected object"
    
    return data.get("data"), None


# Specialized API calls for beacon node endpoints

def evm_beacon_genesis_info(rpc_url: str) -> tuple[Dict[str, Any] | None, str | None]:
    """Get genesis info from the local beacon node."""
    url = rpc_url + '/eth/v1/beacon/genesis'
    genesis_info, err = api_call(url=url)
    if err:
        return None, f"Failed getting genesis info from {url}, {err}"
    return genesis_info, None


def evm_beacon_network_name(rpc_url: str) -> tuple[str | None, str | None]:
    """Get network name from the local beacon node."""
    url = rpc_url + '/eth/v1/config/spec'
    net_config, err = api_call(url=url)
    if err:
        return None, f"Failed getting network config from {url}, {err}"
    return net_config.get("CONFIG_NAME"), None


def evm_beacon_version_info(rpc_url: str) -> tuple[Dict[str, Any] | None, str | None]:
    """Get version info from the local beacon node."""
    url = rpc_url + '/eth/v1/node/version'
    version_info, err = api_call(url=url)
    if err:
        return None, f"Failed getting version info from {url}, {err}"
    return version_info['version'], None
