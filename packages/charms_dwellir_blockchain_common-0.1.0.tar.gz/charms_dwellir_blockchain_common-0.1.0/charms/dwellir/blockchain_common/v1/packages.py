"""Package-management helpers for stable v1 utilities."""

from __future__ import annotations

from pathlib import Path

from .process import run_command

DOCKER_DAEMON_CONFIG_PATH = Path("/etc/docker/daemon.json")
DOCKER_DAEMON_JSON_CONFIG = """{
  "storage-driver": "fuse-overlayfs"
}
"""


def apt_update() -> None:
    """Run apt update in best-effort mode."""
    try:
        run_command(["apt", "update"], check=False)
    except Exception:
        return


def apt_install(packages: list[str], update: bool = True) -> None:
    """Install apt packages, optionally running apt update first."""
    if update:
        apt_update()

    normalized_packages = [pkg.strip() for pkg in packages if pkg and pkg.strip()]
    if not normalized_packages:
        return

    run_command(["apt", "install", "-y", *normalized_packages])


def install_docker(user: str, strategy: str = "script") -> None:
    """Ensure Docker is installed and add user to docker group."""
    normalized_user = user.strip()
    if not normalized_user:
        raise ValueError("user cannot be empty")

    normalized_strategy = strategy.strip().lower()
    if normalized_strategy not in {"script", "package"}:
        raise ValueError("strategy must be one of: script, package")

    try:
        docker_check = run_command(["docker", "--version"], capture_output=True, check=False)
        docker_available = docker_check.returncode == 0
    except FileNotFoundError:
        docker_available = False

    if not docker_available:
        DOCKER_DAEMON_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        DOCKER_DAEMON_CONFIG_PATH.write_text(DOCKER_DAEMON_JSON_CONFIG, encoding="utf-8")

        if normalized_strategy == "script":
            apt_install(["fuse-overlayfs"], update=True)
            run_command(["curl", "-fsSL", "https://get.docker.com", "-o", "get-docker.sh"])
            run_command(["sh", "get-docker.sh"])
        elif normalized_strategy == "package":
            apt_install(["fuse-overlayfs", "docker.io"], update=True)
            run_command(["systemctl", "enable", "--now", "docker"], check=False)

    run_command(["usermod", "-aG", "docker", normalized_user], check=False)
