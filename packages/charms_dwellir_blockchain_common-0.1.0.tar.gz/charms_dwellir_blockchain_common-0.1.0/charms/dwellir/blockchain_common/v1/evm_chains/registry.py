"""Lightweight EVM chain registry backed by a vendored chain list."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

_DATA_PATH = Path(__file__).resolve().parent / "data" / "chains_mini.json"


@dataclass(frozen=True)
class Chain:
    """Minimal chain metadata record."""

    chain_id: int
    name: str
    short_name: str
    network_id: int
    native_currency: dict[str, Any] | None = None
    rpc: list[str] | None = None
    faucets: list[str] | None = None
    info_url: str | None = None

    @property
    def caip2(self) -> str:
        """CAIP-2 EVM reference."""
        return f"eip155:{self.chain_id}"


def version() -> str:
    """Return a vendored dataset version based on file mtime."""
    try:
        stat = os.stat(_DATA_PATH)
        return f"vendored@{int(stat.st_mtime)}"
    except OSError:
        return "vendored@unknown"


@lru_cache(maxsize=1)
def _raw() -> list[dict[str, Any]]:
    with _DATA_PATH.open("r", encoding="utf-8") as fp:
        data = json.load(fp)
    if not isinstance(data, list):
        raise ValueError(f"invalid chain dataset in {_DATA_PATH}: expected a list")
    return data


@lru_cache(maxsize=1)
def _indexes() -> tuple[dict[int, dict[str, Any]], dict[str, list[int]], dict[str, list[int]]]:
    by_id: dict[int, dict[str, Any]] = {}
    by_name: dict[str, list[int]] = {}
    by_short: dict[str, list[int]] = {}

    for chain in _raw():
        chain_id = int(chain["chainId"])
        by_id[chain_id] = chain

        name = str(chain.get("name", "")).strip()
        short_name = str(chain.get("shortName", "")).strip()

        if name:
            by_name.setdefault(name, []).append(chain_id)
        if short_name:
            by_short.setdefault(short_name, []).append(chain_id)

    for index in (by_name, by_short):
        for key in index:
            index[key].sort()

    return by_id, by_name, by_short


def _to_chain(raw: dict[str, Any]) -> Chain:
    return Chain(
        chain_id=int(raw["chainId"]),
        name=str(raw.get("name", "")),
        short_name=str(raw.get("shortName", "")),
        network_id=int(raw.get("networkId", raw["chainId"])),
        native_currency=raw.get("nativeCurrency"),
        rpc=raw.get("rpc"),
        faucets=raw.get("faucets"),
        info_url=raw.get("infoURL"),
    )


def all_chains() -> list[Chain]:
    """Return all chains."""
    return [_to_chain(raw) for raw in _raw()]


def all_chain_ids() -> list[int]:
    """Return all chain IDs sorted ascending."""
    by_id, _, _ = _indexes()
    return sorted(by_id.keys())


def get_chain(chain_id: int) -> Chain | None:
    """Return chain record by chain ID."""
    by_id, _, _ = _indexes()
    chain = by_id.get(int(chain_id))
    return _to_chain(chain) if chain else None


def chain_name(chain_id: int, default: str | None = None) -> str | None:
    """Return chain name for chain ID."""
    chain = get_chain(chain_id)
    return chain.name if chain else default


def chain_short_name(chain_id: int, default: str | None = None) -> str | None:
    """Return short name for chain ID."""
    chain = get_chain(chain_id)
    return chain.short_name if chain else default


def chain_ids_by_name(name: str) -> list[int]:
    """Return chain IDs matching an exact chain name."""
    _, by_name, _ = _indexes()
    return list(by_name.get(name, []))


def chain_ids_by_short_name(short_name: str) -> list[int]:
    """Return chain IDs matching an exact chain short name."""
    _, _, by_short = _indexes()
    return list(by_short.get(short_name, []))


def caip2(chain_id: int) -> str:
    """Return CAIP-2 EVM reference."""
    return f"eip155:{int(chain_id)}"


def search(query: str, limit: int = 25) -> list[Chain]:
    """Case-insensitive substring search over name and short name."""
    needle = query.strip().lower()
    if not needle:
        return []

    out: list[Chain] = []
    for chain in _raw():
        name = str(chain.get("name", "")).lower()
        short_name = str(chain.get("shortName", "")).lower()
        if needle in name or needle in short_name:
            out.append(_to_chain(chain))
            if len(out) >= limit:
                break
    return out
