"""User and group helpers for stable v1 utilities."""

from __future__ import annotations

from pathlib import Path

from .process import run_command


def ensure_user_group(user: str, group: str, home: Path, chmod: str = "700") -> None:
    """Ensure system user/group exist and home path has expected ownership and mode."""
    normalized_user = user.strip()
    normalized_group = group.strip()
    if not normalized_user:
        raise ValueError("user cannot be empty")
    if not normalized_group:
        raise ValueError("group cannot be empty")

    home_path = Path(home)

    group_check = run_command(["getent", "group", normalized_group], capture_output=True, check=False)
    if group_check.returncode != 0:
        run_command(["addgroup", "--system", normalized_group])

    user_check = run_command(["id", "-u", normalized_user], capture_output=True, check=False)
    if user_check.returncode != 0:
        run_command(
            [
                "adduser",
                "--system",
                "--home",
                str(home_path),
                "--disabled-password",
                "--ingroup",
                normalized_group,
                normalized_user,
            ]
        )

    home_path.mkdir(parents=True, exist_ok=True)
    chown_path(home_path, normalized_user, normalized_group, recursive=True)
    run_command(["chmod", "-R", chmod, str(home_path)])


def chown_path(path: Path, user: str, group: str, recursive: bool = True) -> None:
    """Change ownership of a path to user:group."""
    normalized_user = user.strip()
    normalized_group = group.strip()
    if not normalized_user:
        raise ValueError("user cannot be empty")
    if not normalized_group:
        raise ValueError("group cannot be empty")

    path_str = str(Path(path))
    command = ["chown"]
    if recursive:
        command.append("-R")
    command.extend([f"{normalized_user}:{normalized_group}", path_str])
    run_command(command)
