"""Version helper utilities for stable v1."""

from __future__ import annotations

import re
import subprocess as sp
from collections.abc import Mapping, Sequence
from pathlib import Path

import requests

from .process import run_command

_DEFAULT_VERSION_COMMAND_ARGS: tuple[tuple[str, ...], ...] = (
    ("--version",),
    ("version",),
    ("-v",),
)

_DEFAULT_VERSION_PATTERNS: tuple[str, ...] = (
    r"\b(v?\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?)\b",
    r"(?i)\bversion\s*[:=]?\s*(v?\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?)\b",
)


def extract_version_from_output(output: str, pattern: str) -> str:
    """Extract version string from command output using regex pattern."""
    if not output or not pattern:
        return ""
    try:
        match = re.search(pattern, output, flags=re.MULTILINE)
    except re.error:
        return ""
    if not match:
        return ""
    if match.lastindex:
        # Prefer the first non-empty captured group; helps with optional leading groups.
        for group_index in range(1, match.lastindex + 1):
            value = match.group(group_index)
            if value:
                return value
        return ""
    return match.group(0)


def get_version_from_binary(
    path: Path,
    args: Sequence[str] | None = None,
    pattern: str | None = None,
    user: str | None = None,
    env: Mapping[str, str] | None = None,
    retries: int = 1,
    timeout_s: float | None = None,
    command_args_variants: Sequence[Sequence[str]] | None = None,
) -> str:
    """Run a binary and parse version output.

    When `args` is provided, only that command form is used.
    Otherwise, common version command variants are attempted in order.
    """
    target = Path(path)
    if not target.exists():
        return ""
    if retries < 1:
        raise ValueError("retries must be >= 1")
    if timeout_s is not None and timeout_s <= 0:
        raise ValueError("timeout_s must be > 0 when provided")
    if args is not None and command_args_variants is not None:
        raise ValueError("args and command_args_variants cannot both be provided")

    if args is not None:
        if isinstance(args, (str, bytes)):
            raise ValueError("args must be a sequence of command arguments, not a string")
        variants: Sequence[Sequence[str]] = (tuple(str(arg) for arg in args),)
    else:
        if command_args_variants is None:
            variants = _DEFAULT_VERSION_COMMAND_ARGS
        else:
            if len(command_args_variants) == 0:
                raise ValueError("command_args_variants must not be empty")
            normalized_variants: list[tuple[str, ...]] = []
            for variant in command_args_variants:
                if isinstance(variant, (str, bytes)):
                    raise ValueError(
                        "command_args_variants entries must be sequences of command arguments"
                    )
                normalized_variants.append(tuple(str(arg) for arg in variant))
            variants = tuple(normalized_variants)
    patterns = (pattern,) if pattern else _DEFAULT_VERSION_PATTERNS

    for _ in range(retries):
        for variant in variants:
            command = [str(target), *[str(arg) for arg in variant]]
            try:
                result = run_command(
                    command,
                    capture_output=True,
                    check=False,
                    text=True,
                    user=user,
                    env=env,
                    timeout_s=timeout_s,
                )
            except (OSError, sp.TimeoutExpired):
                continue

            output_parts = []
            if result.stdout:
                output_parts.append(result.stdout)
            if result.stderr:
                output_parts.append(result.stderr)
            output = "\n".join(output_parts)

            for candidate_pattern in patterns:
                version = extract_version_from_output(output, candidate_pattern)
                if version:
                    return version
    return ""


def get_version_from_jsonrpc(
    url: str,
    method: str = "web3_clientVersion",
    pattern: str | None = None,
    timeout_s: int = 5,
    retries: int = 1,
    params: Sequence[object] | None = None,
) -> str:
    """Fetch a version-like string over JSON-RPC and optionally parse it with regex."""
    if not isinstance(url, str):
        raise ValueError("url must be a string")
    normalized_url = url.strip()
    if not normalized_url:
        return ""
    if not isinstance(method, str):
        raise ValueError("method must be a string")
    normalized_method = method.strip()
    if not normalized_method:
        raise ValueError("method must not be empty")
    if timeout_s <= 0:
        raise ValueError("timeout_s must be > 0")
    if retries < 1:
        raise ValueError("retries must be >= 1")
    if isinstance(params, (str, bytes)):
        raise ValueError("params must be a sequence of JSON-RPC params, not a string")

    payload = {
        "jsonrpc": "2.0",
        "method": normalized_method,
        "params": list(params or []),
        "id": 1,
    }
    for _ in range(retries):
        try:
            response = requests.post(normalized_url, json=payload, timeout=timeout_s)
            response.raise_for_status()
            data = response.json()
        except (requests.RequestException, ValueError):
            continue
        if not isinstance(data, Mapping):
            continue
        if data.get("error") is not None:
            continue

        result = data.get("result")
        if not isinstance(result, str):
            continue
        if not pattern:
            return result

        parsed = extract_version_from_output(result, pattern)
        if parsed:
            return parsed
    return ""
