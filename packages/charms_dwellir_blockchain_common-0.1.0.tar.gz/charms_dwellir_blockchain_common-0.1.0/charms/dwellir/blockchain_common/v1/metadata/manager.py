"""High-level orchestration for metadata collection and optional upload."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from .credentials import CollectorCredentials
from .payload import build_payload, write_payload
from .schema import BlockchainMetadataInput
from .storage import PayloadUploader, S3PayloadUploader


def _default_object_key(model_name: str, model_uuid: str, unit_name: str) -> str:
    safe_unit = unit_name.replace("/", "-")
    return f"{model_name}-{model_uuid}/{safe_unit}.json"


def collect_and_upload(
    *,
    model: Any,
    app: Any,
    unit: Any,
    meta: Any,
    base_dir: Path = Path("/tmp/metadata-uploader"),
    blockchain: BlockchainMetadataInput | None = None,
    sections: Mapping[str, Any] | None = None,
    credentials: CollectorCredentials | None = None,
    uploader: PayloadUploader | None = None,
    no_upload: bool = False,
    timestamp: datetime | None = None,
) -> Path:
    """Build payload, write to disk, and optionally upload."""
    ts = timestamp or datetime.now(timezone.utc)
    payload = build_payload(
        model=model,
        app=app,
        unit=unit,
        meta=meta,
        timestamp=ts,
        blockchain=blockchain,
        sections=sections,
    )
    unit_name = str(getattr(unit, "name", ""))
    payload_path = write_payload(payload=payload, unit_name=unit_name, base_dir=base_dir)
    if no_upload:
        return payload_path

    selected_uploader = uploader
    if selected_uploader is None and credentials is not None:
        selected_uploader = S3PayloadUploader(credentials)
    if selected_uploader is None:
        return payload_path

    model_name = str(getattr(model, "name", ""))
    model_uuid = str(getattr(model, "uuid", ""))
    if credentials is not None:
        object_key = credentials.object_key(model_name=model_name, model_uuid=model_uuid, unit_name=unit_name)
    else:
        object_key = _default_object_key(model_name=model_name, model_uuid=model_uuid, unit_name=unit_name)
    selected_uploader.upload_json(payload_path=payload_path, object_key=object_key)
    return payload_path

