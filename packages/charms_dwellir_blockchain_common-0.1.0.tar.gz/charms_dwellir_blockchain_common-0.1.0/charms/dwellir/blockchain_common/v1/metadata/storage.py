"""Storage backends for metadata payload uploads."""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any, Protocol

from .credentials import CollectorCredentials
from .errors import MetadataUploadError


class PayloadUploader(Protocol):
    """Protocol for payload upload backends."""

    def upload_json(self, *, payload_path: Path, object_key: str) -> None:
        """Upload payload to destination."""


def _load_s3_dependencies() -> tuple[Any, tuple[type[BaseException], ...]]:
    try:
        boto3 = importlib.import_module("boto3")
        botocore_exceptions = importlib.import_module("botocore.exceptions")
    except ImportError as exc:
        raise MetadataUploadError("boto3 is required for S3 uploads") from exc

    errors = (
        botocore_exceptions.BotoCoreError,
        botocore_exceptions.ClientError,
        botocore_exceptions.EndpointConnectionError,
        botocore_exceptions.ParamValidationError,
    )
    return boto3, errors


class S3PayloadUploader:
    """Upload payloads to S3 or S3-compatible object storage."""

    def __init__(self, credentials: CollectorCredentials):
        boto3, errors = _load_s3_dependencies()
        self._credentials = credentials
        self._errors = errors
        session = boto3.session.Session(
            aws_access_key_id=credentials.access_key_id,
            aws_secret_access_key=credentials.secret_access_key,
            aws_session_token=credentials.session_token,
            region_name=credentials.region,
        )
        self._client = session.client("s3", endpoint_url=credentials.endpoint_url)

    def upload_json(self, *, payload_path: Path, object_key: str) -> None:
        """Upload payload JSON file to configured object key."""
        if not payload_path.exists():
            raise MetadataUploadError(f"payload path does not exist: {payload_path}")
        if not object_key:
            raise MetadataUploadError("object_key must be a non-empty string")
        try:
            self._client.put_object(
                Bucket=self._credentials.bucket,
                Key=object_key,
                Body=payload_path.read_bytes(),
                ContentType="application/json",
            )
        except self._errors as exc:
            raise MetadataUploadError(str(exc)) from exc

