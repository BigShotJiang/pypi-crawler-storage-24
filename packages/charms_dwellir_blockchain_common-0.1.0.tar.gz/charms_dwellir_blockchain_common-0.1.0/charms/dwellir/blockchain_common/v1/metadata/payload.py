"""Payload building and persistence helpers."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping

from .credentials import redact_collector_credentials
from .errors import MetadataValidationError
from .schema import BlockchainMetadataInput, normalize_blockchain_metadata
from .topology import collect_relation_details, topology_from_juju


def build_payload(
    *,
    model: Any,
    app: Any,
    unit: Any,
    meta: Any,
    timestamp: datetime,
    blockchain: BlockchainMetadataInput | None = None,
    sections: Mapping[str, Any] | None = None,
    redact_config: bool = True,
) -> dict[str, Any]:
    """Assemble a metadata payload with Juju topology and optional extra sections."""
    if not isinstance(timestamp, datetime):
        raise MetadataValidationError("timestamp must be a datetime")

    normalized_sections: dict[str, Any] = dict(sections or {})
    if blockchain is not None and "blockchain" in normalized_sections:
        raise MetadataValidationError("blockchain must be provided once, either via blockchain or sections")
    if blockchain is not None:
        normalized_sections["blockchain"] = normalize_blockchain_metadata(blockchain)
    elif "blockchain" in normalized_sections:
        normalized_sections["blockchain"] = normalize_blockchain_metadata(normalized_sections["blockchain"])

    relations = collect_relation_details(model=model, app=app, unit=unit, meta=meta)
    topology = topology_from_juju(model=model, app=app, unit=unit, meta=meta).to_dict()

    model_config = getattr(model, "config", {}) or {}
    config_copy = dict(model_config)
    if redact_config:
        config_copy = redact_collector_credentials(config_copy)

    payload: dict[str, Any] = {
        "juju_topology": topology,
        "juju_application_config": config_copy,
        "juju_unit_relations": relations,
        "timestamp_utc": timestamp.isoformat(),
    }
    payload.update(normalized_sections)
    return payload


def write_payload(payload: Mapping[str, Any], unit_name: str, base_dir: Path) -> Path:
    """Write payload JSON to disk and return the path."""
    if not isinstance(unit_name, str) or not unit_name.strip():
        raise MetadataValidationError("unit_name must be a non-empty string")
    target_dir = Path(base_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    safe_unit = unit_name.replace("/", "-")
    path = target_dir / f"{safe_unit}.json"
    path.write_text(json.dumps(dict(payload), indent=2), encoding="utf-8")
    return path

