"""Credential and redaction helpers for metadata collection."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Mapping

from .errors import MetadataValidationError


@dataclass(frozen=True)
class CollectorCredentials:
    """Credentials for an S3-compatible destination."""

    bucket: str
    region: str
    access_key_id: str
    secret_access_key: str
    session_token: str | None = None
    endpoint_url: str | None = None
    key_prefix: str = "uploads/"

    def object_key(self, model_name: str, model_uuid: str, unit_name: str) -> str:
        """Build destination object key for a unit payload."""
        prefix = self.key_prefix or ""
        if prefix and not prefix.endswith("/"):
            prefix = f"{prefix}/"
        model_dir = f"{model_name}-{model_uuid}/"
        safe_unit = unit_name.replace("/", "-")
        return f"{prefix}{model_dir}{safe_unit}.json"


def _require_non_empty_str(data: Mapping[str, Any], key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise MetadataValidationError(f"{key} must be a non-empty string")
    return value


def _normalize_secret_keys(secret_values: Mapping[str, Any]) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key, value in secret_values.items():
        normalized[str(key).replace("-", "_")] = value
    return normalized


def _build_credentials(data: Mapping[str, Any]) -> CollectorCredentials:
    required = ("bucket", "region", "access_key_id", "secret_access_key")
    missing = [key for key in required if not data.get(key)]
    if missing:
        raise MetadataValidationError(f"missing required fields: {', '.join(missing)}")

    endpoint_url = data.get("endpoint_url")
    if endpoint_url is not None and not isinstance(endpoint_url, str):
        raise MetadataValidationError("endpoint_url must be a string when provided")

    session_token = data.get("session_token")
    if session_token is not None and not isinstance(session_token, str):
        raise MetadataValidationError("session_token must be a string when provided")

    key_prefix_raw = data.get("key_prefix")
    if key_prefix_raw is None:
        key_prefix = "uploads/"
    elif not isinstance(key_prefix_raw, str) or not key_prefix_raw.strip():
        raise MetadataValidationError("key_prefix must be a non-empty string when provided")
    else:
        key_prefix = key_prefix_raw

    return CollectorCredentials(
        bucket=_require_non_empty_str(data, "bucket"),
        region=_require_non_empty_str(data, "region"),
        access_key_id=_require_non_empty_str(data, "access_key_id"),
        secret_access_key=_require_non_empty_str(data, "secret_access_key"),
        session_token=session_token,
        endpoint_url=endpoint_url,
        key_prefix=key_prefix,
    )


def parse_credentials_json(raw: str) -> CollectorCredentials:
    """Parse credentials from a JSON config blob."""
    if not isinstance(raw, str):
        raise MetadataValidationError("raw credentials must be a string")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise MetadataValidationError(f"must be valid JSON: {exc.msg}") from exc
    if not isinstance(data, dict):
        raise MetadataValidationError("config must be a JSON object")
    return _build_credentials(data)


def parse_credentials_secret(secret_values: Mapping[str, str]) -> CollectorCredentials:
    """Parse credentials from Juju secret content using hyphenated or underscored keys."""
    if not isinstance(secret_values, Mapping):
        raise MetadataValidationError("secret_values must be a mapping")
    normalized = _normalize_secret_keys(secret_values)
    return _build_credentials(normalized)


def parse_credentials_secret_id(model: Any, secret_id: str) -> CollectorCredentials:
    """Resolve a Juju secret reference from a model and parse collector credentials."""
    if not isinstance(secret_id, str) or not secret_id.strip():
        raise MetadataValidationError("secret_id must be a non-empty string")
    if model is None or not hasattr(model, "get_secret"):
        raise MetadataValidationError("model must provide get_secret")

    try:
        secret = model.get_secret(id=secret_id)
    except Exception as exc:  # noqa: BLE001
        raise MetadataValidationError(f"unable to access secret {secret_id!r}: {exc}") from exc
    if secret is None or not hasattr(secret, "get_content"):
        raise MetadataValidationError(f"secret {secret_id!r} does not provide get_content")

    try:
        secret_values = secret.get_content()
    except Exception as exc:  # noqa: BLE001
        raise MetadataValidationError(f"unable to read secret content for {secret_id!r}: {exc}") from exc
    return parse_credentials_secret(secret_values)


def redact_collector_credentials(config: Mapping[str, Any]) -> dict[str, Any]:
    """Redact secret access key in collector credentials config when it is JSON-encoded."""
    redacted = {str(key): value for key, value in dict(config).items()}
    key = "collector-s3-credentials"
    if key not in redacted:
        return redacted

    value = redacted[key]
    if not isinstance(value, str):
        return redacted

    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return redacted
    if not isinstance(parsed, dict):
        return redacted

    changed = False
    for candidate in ("secret_access_key", "secret-access-key"):
        if candidate in parsed and parsed[candidate]:
            parsed[candidate] = "REDACTED"
            changed = True

    if changed:
        redacted[key] = json.dumps(parsed)
    return redacted
