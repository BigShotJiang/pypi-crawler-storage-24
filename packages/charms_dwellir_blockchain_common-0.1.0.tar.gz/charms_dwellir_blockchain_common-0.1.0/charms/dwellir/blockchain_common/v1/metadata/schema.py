"""Schema and normalization helpers for blockchain metadata."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .errors import MetadataValidationError

_BASE_STRING_FIELDS = (
    "blockchain_ecosystem",
    "blockchain_network_name",
    "client_name",
    "client_version",
    "cmdline",
    "binary_path",
)


@dataclass(frozen=True)
class BaseBlockchainMetadata:
    """Chain-agnostic metadata fields."""

    blockchain_ecosystem: str
    blockchain_network_name: str
    client_name: str
    client_version: str
    cmdline: str
    binary_path: str

    def to_dict(self) -> dict[str, Any]:
        """Return normalized dictionary representation."""
        return normalize_blockchain_metadata(
            {
                "blockchain_ecosystem": self.blockchain_ecosystem,
                "blockchain_network_name": self.blockchain_network_name,
                "client_name": self.client_name,
                "client_version": self.client_version,
                "cmdline": self.cmdline,
                "binary_path": self.binary_path,
            }
        )


@dataclass(frozen=True)
class EvmBlockchainMetadata(BaseBlockchainMetadata):
    """EVM-specific metadata fields."""

    chain_id: int
    l1_chain_id: int | None = None
    l2_chain_id: int | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return normalized dictionary representation."""
        return normalize_blockchain_metadata(
            {
                **super().to_dict(),
                "chain_id": self.chain_id,
                "l1_chain_id": self.l1_chain_id,
                "l2_chain_id": self.l2_chain_id,
            }
        )


@dataclass(frozen=True)
class EvmBeaconBlockchainMetadata(BaseBlockchainMetadata):
    """Beacon-specific metadata fields."""

    genesis_validators_root: str | None = None
    genesis_fork_version: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return normalized dictionary representation."""
        return normalize_blockchain_metadata(
            {
                **super().to_dict(),
                "genesis_validators_root": self.genesis_validators_root,
                "genesis_fork_version": self.genesis_fork_version,
            }
        )


@dataclass(frozen=True)
class SubstrateBlockchainMetadata(BaseBlockchainMetadata):
    """Substrate-specific metadata fields."""

    genesis_hash: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return normalized dictionary representation."""
        return normalize_blockchain_metadata(
            {
                **super().to_dict(),
                "genesis_hash": self.genesis_hash,
            }
        )


BlockchainMetadataInput = BaseBlockchainMetadata | Mapping[str, Any]


def _require_str(data: Mapping[str, Any], key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise MetadataValidationError(f"{key} must be a non-empty string")
    return value


def _require_int(data: Mapping[str, Any], key: str) -> int:
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise MetadataValidationError(f"{key} must be an int")
    return value


def _require_optional_int(data: Mapping[str, Any], key: str) -> int | None:
    value = data.get(key)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise MetadataValidationError(f"{key} must be an int when provided")
    return value


def _require_optional_str(data: Mapping[str, Any], key: str) -> str | None:
    value = data.get(key)
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise MetadataValidationError(f"{key} must be a non-empty string when provided")
    return value


def normalize_blockchain_metadata(data: BlockchainMetadataInput) -> dict[str, Any]:
    """Normalize blockchain metadata to a validated dictionary."""
    if isinstance(data, BaseBlockchainMetadata):
        raw: Mapping[str, Any] = data.__dict__
    elif isinstance(data, Mapping):
        raw = data
    else:
        raise MetadataValidationError("blockchain metadata must be a mapping or metadata dataclass")

    normalized: dict[str, Any] = {key: _require_str(raw, key) for key in _BASE_STRING_FIELDS}

    if "chain_id" in raw or "l1_chain_id" in raw or "l2_chain_id" in raw:
        if "chain_id" not in raw:
            raise MetadataValidationError("chain_id must be provided when l1_chain_id or l2_chain_id is set")
        normalized["chain_id"] = _require_int(raw, "chain_id")
        normalized["l1_chain_id"] = _require_optional_int(raw, "l1_chain_id")
        normalized["l2_chain_id"] = _require_optional_int(raw, "l2_chain_id")

    if "genesis_hash" in raw:
        normalized["genesis_hash"] = _require_optional_str(raw, "genesis_hash")

    if "genesis_validators_root" in raw or "genesis_fork_version" in raw:
        normalized["genesis_validators_root"] = _require_optional_str(raw, "genesis_validators_root")
        normalized["genesis_fork_version"] = _require_optional_str(raw, "genesis_fork_version")

    return normalized

