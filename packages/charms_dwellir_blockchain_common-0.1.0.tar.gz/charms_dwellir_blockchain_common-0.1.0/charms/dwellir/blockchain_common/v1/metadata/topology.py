"""Juju topology and relation extraction helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .errors import MetadataValidationError


@dataclass(frozen=True)
class JujuTopology:
    """Canonical Juju topology fields."""

    model: str
    model_uuid: str
    application: str
    unit: str
    charm: str | None

    def to_dict(self) -> dict[str, Any]:
        """Return validated dictionary representation."""
        return _validate_topology(
            {
                "model": self.model,
                "model_uuid": self.model_uuid,
                "application": self.application,
                "unit": self.unit,
                "charm": self.charm,
            }
        )


def _require_non_empty_str(data: Mapping[str, Any], key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise MetadataValidationError(f"{key} must be a non-empty string")
    return value


def _validate_topology(data: Mapping[str, Any]) -> dict[str, Any]:
    required = ("model", "model_uuid", "application", "unit", "charm")
    missing = [key for key in required if key not in data]
    if missing:
        raise MetadataValidationError(f"missing juju topology fields: {', '.join(missing)}")

    charm = data.get("charm")
    if charm is not None and (not isinstance(charm, str) or not charm.strip()):
        raise MetadataValidationError("charm must be a non-empty string when provided")

    return {
        "model": _require_non_empty_str(data, "model"),
        "model_uuid": _require_non_empty_str(data, "model_uuid"),
        "application": _require_non_empty_str(data, "application"),
        "unit": _require_non_empty_str(data, "unit"),
        "charm": charm,
    }


def topology_from_juju(model: Any, app: Any, unit: Any, meta: Any) -> JujuTopology:
    """Build topology from Juju model, app, unit, and meta objects."""
    return JujuTopology(
        model=str(getattr(model, "name", "")),
        model_uuid=str(getattr(model, "uuid", "")),
        application=str(getattr(app, "name", "")),
        unit=str(getattr(unit, "name", "")),
        charm=getattr(meta, "name", None) if meta else None,
    )


def _safe_databag(relation: Any, endpoint: Any) -> dict[str, Any]:
    try:
        return dict(relation.data[endpoint])
    except (KeyError, TypeError, AttributeError):
        return {}


def collect_relation_details(model: Any, app: Any, unit: Any, meta: Any) -> list[dict[str, Any]]:
    """Collect relation metadata and databags for payload serialization."""
    relation_map = getattr(model, "relations", {}) or {}
    payload: list[dict[str, Any]] = []
    for relation_name, relation_list in relation_map.items():
        for relation in relation_list:
            relation_meta = meta.relations.get(relation_name) if meta and getattr(meta, "relations", None) else None
            interface_name = getattr(relation_meta, "interface_name", None) if relation_meta else None
            remote_app = relation.app.name if getattr(relation, "app", None) else None
            remote_units = [
                {"unit": remote_unit.name, "data": _safe_databag(relation, remote_unit)}
                for remote_unit in getattr(relation, "units", [])
            ]
            payload.append(
                {
                    "name": relation_name,
                    "id": getattr(relation, "id", None),
                    "interface": interface_name,
                    "remote_app": remote_app,
                    "endpoints": {
                        "local": f"{getattr(app, 'name', '')}:{relation_name}",
                        "remote": remote_app,
                    },
                    "local_unit_data": _safe_databag(relation, unit),
                    "remote_units": remote_units,
                    "app_data": {
                        "local": _safe_databag(relation, app),
                        "remote": _safe_databag(relation, relation.app) if getattr(relation, "app", None) else {},
                    },
                }
            )
    return payload

