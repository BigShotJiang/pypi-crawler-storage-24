"""Error types for metadata helpers."""

from __future__ import annotations


class MetadataError(Exception):
    """Base error for metadata operations."""


class MetadataValidationError(MetadataError):
    """Raised when metadata content fails validation."""


class MetadataUploadError(MetadataError):
    """Raised when payload upload fails."""

