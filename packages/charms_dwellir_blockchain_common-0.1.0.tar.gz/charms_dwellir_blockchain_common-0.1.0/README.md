# charms-dwellir-blockchain-common

Shared helpers for Dwellir blockchain charms. Provides a minimal charm-facing interface
and a small set of utilities that charms can import to reduce duplicated code.

This package now exposes its stable utility surface at `charms.dwellir.blockchain_common.v1`.

## What is included

- `charms.dwellir.blockchain_common.v1.process`
- `charms.dwellir.blockchain_common.v1.systemd`
- `charms.dwellir.blockchain_common.v1.users`
- `charms.dwellir.blockchain_common.v1.packages`
- `charms.dwellir.blockchain_common.v1.downloads`
- `charms.dwellir.blockchain_common.v1.crypto`
- `charms.dwellir.blockchain_common.v1.actions`
- `charms.dwellir.blockchain_common.v1.config`
- `charms.dwellir.blockchain_common.v1.version`
- `charms.dwellir.blockchain_common.v1.jsonrpc`
- `charms.dwellir.blockchain_common.v1.metadata`
- `charms.dwellir.blockchain_common.v1.evm_chains.registry`

## Quick usage

Add the package to your charm's `requirements.txt` from PyPI.

```text
charms-dwellir-blockchain-common>=0.0.1,<1
```

Optional fallback for private source installs:

```text
git+ssh://git@github.com/dwellir-public/dwellir-blockchain-charms-common.git@main#egg=charms-dwellir-blockchain-common
```

## Development

- Run unit tests:
```bash
python -m pip install -e ".[test]"
pytest -q
```

## Upload to TestPyPi for testing and more flexibility

Run:

```bash
make upload-testpypi TOKEN='pypi-<testpypi-token>' VERSION=<new-version>
```

This target temporarily sets `version` in `setup.cfg` for the TestPyPI upload and restores it automatically after the command finishes.
For the full manual workflow, see [this file](/TEST_PYPI_STEPS.md).

## Releases

- Follow version bump criteria in [RELEASE_VERSIONING_GUIDELINES.md](/RELEASE_VERSIONING_GUIDELINES.md).
- Bump `version` in `setup.cfg`.
- Trigger `.github/workflows/release-pypi-and-github.yml` manually from GitHub Actions.
- Approve the `pypi` environment when prompted.
- On success, the workflow also creates a GitHub release/tag `v<version>` and uploads `dist/*` artifacts.

Notes:

- There is a `pypi` environment configured in repository that restricts publishing to PyPi from other branches than the default branch (`main`).

## PyPI Trusted Publisher Setup

In PyPI project settings, add a GitHub Actions publisher with:

- Owner: `dwellir-public`
- Repository: `dwellir-blockchain-charms-common`
- Workflow filename: `release-pypi-and-github.yml`
- Environment: `pypi`

Notes:

- These values must match `.github/workflows/release-pypi-and-github.yml` exactly.
- If the project does not exist on PyPI yet, create a pending publisher first,
  then run the manual release workflow.

## GitHub Branch Protection

There are branch protection rules for the default branch (`main`) that prevents from force pushing or merging without a PR.
