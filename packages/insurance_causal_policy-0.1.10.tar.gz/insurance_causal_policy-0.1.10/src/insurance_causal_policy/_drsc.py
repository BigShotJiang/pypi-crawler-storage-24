"""
Doubly Robust Synthetic Control (DRSC) estimator.

Implements the augmented synthetic control estimator from Ben-Michael,
Feller & Rothstein (2021) "The Augmented Synthetic Control Method", JASA.

The core idea:
  ATT_DRSC = ATT_SC + bias_correction

where ATT_SC is the standard SC (SDID-style) estimate and bias_correction
is an outcome-model augmentation term that corrects for weight misspecification.

Doubly Robust Property
----------------------
The ATT is consistent if either:
  (a) the unit weights omega correctly identify the synthetic counterfactual, OR
  (b) the two-way fixed effects outcome model is correctly specified.

This is valuable when N_co is small (few donor units), where the SC weight
optimisation is underdetermined. The outcome model provides an independent
counterfactual prediction that absorbs bias from noisy weights.

Outcome Model
-------------
We use a two-way fixed effects (2WFE) model estimated on control units:
  mu_0(i, t) = alpha_i + gamma_t

where alpha_i are unit fixed effects and gamma_t are time fixed effects,
estimated from control units' pre-treatment data via OLS.

For treated units: their unit FE (alpha_i) is estimated from their
pre-treatment outcomes by projecting out the common time effects.

The bias correction is:
  correction = (1/N_tr) * sum_{i treated} [m_hat_0(i, post) - SC_hat(i, post)]
             - omega @ [m_hat_0(co, post) - SC_hat(co, post)]

In practice, after simplification:
  correction = (m_hat_tr_post_bar - m_hat_co_omega_post) - att_sc
             + att_sc  [they cancel]

The clean form after algebraic simplification (following Ben-Michael et al.
supplementary material, eq S.7) is:

  ATT_DRSC = (Y_tr_post_bar - mu_hat_tr_post_bar)
            - omega @ (Y_co_post_bar - mu_hat_co_post_bar)

where mu_hat are 2WFE predictions. This is the DiD in residuals.

When N_co is large, mu_hat_co residuals are close to zero and the correction
vanishes — both methods agree. When N_co is small, the SC weights are noisy
and the 2WFE provides a tighter counterfactual.

Insurance Relevance
-------------------
Small-N_co situations arise in:
  - New products with few comparable segments
  - Regional products with only a handful of territories
  - Niche channels (white-label, embedded distribution)

References
----------
- Ben-Michael, Feller & Rothstein (2021). The Augmented Synthetic Control
  Method. Journal of the American Statistical Association 116(536): 1789-1803.
- Arkhangelsky et al. (2021). Synthetic Difference-in-Differences. AER 111(12).
"""

from __future__ import annotations

import warnings
from typing import Literal, Optional

import numpy as np
import pandas as pd
import polars as pl
from scipy import stats

from ._sdid import (
    _compute_regularisation_zeta,
    _solve_unit_weights,
    _solve_time_weights,
    _weighted_twfe,
)
from ._types import SDIDResult, SDIDWeights


# ---------------------------------------------------------------------------
# Two-way fixed effects outcome model
# ---------------------------------------------------------------------------


def _fit_2wfe_model(
    Y_co_pre: np.ndarray,
    ridge_alpha: float = 1.0,
) -> dict:
    """Fit two-way fixed effects model on control units, pre-treatment.

    Model: Y_{it} = alpha_i + gamma_t + epsilon_{it}

    Estimated via iterative demeaning (within estimator). Returns the
    estimated time effects gamma_t and the mean control outcome (intercept).

    Parameters
    ----------
    Y_co_pre : (N_co, T_pre) array
    ridge_alpha : float
        L2 regularisation for unit FE estimation. Shrinks estimates toward
        the control mean. Higher values improve stability with few units.

    Returns
    -------
    dict with:
        'gamma': (T_pre,) time effects
        'alpha_co': (N_co,) unit effects for control units
        'grand_mean': float — intercept
    """
    N_co, T_pre = Y_co_pre.shape

    # Iterative demeaning (alternating projections)
    # Start from raw data and demean iteratively
    alpha_co = np.zeros(N_co)
    gamma = np.zeros(T_pre)

    for _ in range(50):  # typically converges in <10 iterations
        # Update unit FEs: alpha_i = mean_t(Y_{it} - gamma_t)
        alpha_new = np.mean(Y_co_pre - gamma[np.newaxis, :], axis=1)

        # Optional ridge regularisation: shrink toward zero
        if ridge_alpha > 0:
            # Ridge: alpha_i = (T_pre * mean + 0) / (T_pre + ridge_alpha)
            alpha_new = alpha_new * T_pre / (T_pre + ridge_alpha)

        # Update time FEs: gamma_t = mean_i(Y_{it} - alpha_i)
        gamma_new = np.mean(Y_co_pre - alpha_new[:, np.newaxis], axis=0)

        # Check convergence
        if np.max(np.abs(alpha_new - alpha_co)) < 1e-8 and \
           np.max(np.abs(gamma_new - gamma)) < 1e-8:
            alpha_co = alpha_new
            gamma = gamma_new
            break

        alpha_co = alpha_new
        gamma = gamma_new

    grand_mean = np.mean(Y_co_pre - alpha_co[:, np.newaxis] - gamma[np.newaxis, :])

    return {
        "gamma": gamma,
        "alpha_co": alpha_co,
        "grand_mean": grand_mean,
        "T_pre": T_pre,
        "N_co": N_co,
        "ridge_alpha": ridge_alpha,
    }


def _predict_2wfe_post(
    model: dict,
    Y_co_pre: np.ndarray,
    Y_co_post: np.ndarray,
    Y_tr_pre: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Predict post-treatment outcomes using 2WFE model.

    Extrapolates time effects from pre-treatment to post-treatment using
    a linear trend fitted to the estimated gamma_t sequence.

    Parameters
    ----------
    model : dict from _fit_2wfe_model
    Y_co_pre : (N_co, T_pre)
    Y_co_post : (N_co, T_post)
    Y_tr_pre : (N_tr, T_pre)

    Returns
    -------
    mu_hat_co_post : (N_co, T_post) — predicted post-treatment for controls
    mu_hat_tr_post : (N_tr, T_post) — predicted post-treatment counterfactual
        for treated (using their estimated unit FE + extrapolated time FE)
    """
    T_pre = model["T_pre"]
    N_co = model["N_co"]
    gamma = model["gamma"]      # (T_pre,)
    alpha_co = model["alpha_co"]  # (N_co,)
    grand_mean = model["grand_mean"]
    ridge_alpha = model["ridge_alpha"]

    _, T_post = Y_co_post.shape
    N_tr = Y_tr_pre.shape[0]

    # Extrapolate time effects to post-treatment via linear regression on gamma
    t_pre_idx = np.arange(T_pre, dtype=float)
    # Fit linear: gamma_t = a + b * t
    A = np.column_stack([np.ones(T_pre), t_pre_idx])
    coef = np.linalg.lstsq(A, gamma, rcond=None)[0]

    t_post_idx = np.arange(T_pre, T_pre + T_post, dtype=float)
    A_post = np.column_stack([np.ones(T_post), t_post_idx])
    gamma_post = A_post @ coef  # (T_post,) — extrapolated time effects

    # Predict for control units: mu_hat_co(i, t) = grand_mean + alpha_i + gamma_post_t
    mu_hat_co_post = (grand_mean + alpha_co[:, np.newaxis] +
                      gamma_post[np.newaxis, :])  # (N_co, T_post)

    # Estimate unit FEs for treated units from their pre-treatment outcomes
    # alpha_tr_i = mean_t(Y_tr_i_pre - gamma_t) — same formula as controls
    # but the treated unit is not in the training set, so we're projecting
    alpha_tr = np.mean(Y_tr_pre - gamma[np.newaxis, :], axis=1)  # (N_tr,)

    # Apply ridge regularisation to treated unit FEs too (prevents overfitting
    # to the pre-treatment period)
    if ridge_alpha > 0:
        alpha_tr = alpha_tr * T_pre / (T_pre + ridge_alpha)

    # Predict for treated counterfactual
    mu_hat_tr_post = (grand_mean + alpha_tr[:, np.newaxis] +
                      gamma_post[np.newaxis, :])  # (N_tr, T_post)

    return mu_hat_co_post, mu_hat_tr_post


# ---------------------------------------------------------------------------
# DRSC core estimator
# ---------------------------------------------------------------------------


def _fit_drsc_core(
    Y: np.ndarray,
    D: np.ndarray,
    n_co: int,
    n_tr: int,
    t_pre: int,
    t_post: int,
    ridge_alpha: float = 1.0,
    return_weights: bool = True,
) -> tuple:
    """Core DRSC fit: augmented synthetic control ATT.

    ATT_DRSC = (Y_tr_post_bar - mu_hat_tr_post_bar)
             - omega @ (Y_co_post_bar - mu_hat_co_post_bar)

    where mu_hat are 2WFE predictions from a model estimated on control units.

    This is the DiD in model-adjusted residuals — doubly robust because:
    - If omega is correct: SC residuals are zero, DRSC = SDID
    - If 2WFE model is correct: the adjustment removes the SC bias

    Returns (att, omega, omega_0, lambda_, zeta, att_sc, bias_correction)
    if return_weights=True, else (att,).
    """
    Y_co = Y[:n_co]   # (N_co, T)
    Y_tr = Y[n_co:]   # (N_tr, T)

    Y_co_pre = Y_co[:, :t_pre]    # (N_co, T_pre)
    Y_co_post = Y_co[:, t_pre:]   # (N_co, T_post)
    Y_tr_pre = Y_tr[:, :t_pre]    # (N_tr, T_pre)
    Y_tr_post = Y_tr[:, t_pre:]   # (N_tr, T_post)

    # --- Step 1: SC weights (same as SDID) ---
    y_pre_tr_bar = np.mean(Y_tr_pre, axis=0)   # (T_pre,)
    y_post_co_bar = np.mean(Y_co_post, axis=1)  # (N_co,)
    zeta = _compute_regularisation_zeta(Y_co_pre, n_tr, t_post)
    omega, omega_0 = _solve_unit_weights(y_pre_tr_bar, Y_co_pre, zeta, t_pre)
    lambda_ = _solve_time_weights(y_post_co_bar, Y_co_pre)

    # --- Step 2: SC ATT ---
    att_sc = _weighted_twfe(Y, D, omega, lambda_, n_co, n_tr, t_pre, t_post)

    # --- Step 3: 2WFE outcome model ---
    model = _fit_2wfe_model(Y_co_pre, ridge_alpha=ridge_alpha)
    mu_hat_co_post, mu_hat_tr_post = _predict_2wfe_post(
        model, Y_co_pre, Y_co_post, Y_tr_pre
    )

    # --- Step 4: Doubly robust ATT ---
    # DiD in model-adjusted residuals:
    # ATT_DRSC = (Y_tr_post_bar - mu_hat_tr_post_bar)
    #          - omega @ (Y_co_post_bar - mu_hat_co_post_bar)
    Y_tr_post_bar = np.mean(Y_tr_post)  # scalar
    mu_hat_tr_post_bar = np.mean(mu_hat_tr_post)  # scalar

    Y_co_post_bar = np.mean(Y_co_post, axis=1)      # (N_co,)
    mu_hat_co_post_bar = np.mean(mu_hat_co_post, axis=1)  # (N_co,)

    att = ((Y_tr_post_bar - mu_hat_tr_post_bar)
           - omega @ (Y_co_post_bar - mu_hat_co_post_bar))

    bias_correction = att - att_sc

    if return_weights:
        return att, omega, omega_0, lambda_, zeta, att_sc, bias_correction
    else:
        return (att,)


# ---------------------------------------------------------------------------
# Inference: bootstrap and jackknife
# ---------------------------------------------------------------------------


def _bootstrap_variance_drsc(
    Y: np.ndarray,
    D: np.ndarray,
    n_co: int,
    n_tr: int,
    t_pre: int,
    t_post: int,
    n_replicates: int,
    rng: np.random.Generator,
    ridge_alpha: float,
) -> float:
    """Bootstrap variance for DRSC: resample units with replacement."""
    boot_atts = []

    for _ in range(n_replicates):
        co_idx = rng.choice(n_co, size=n_co, replace=True)
        tr_idx = rng.choice(np.arange(n_co, n_co + n_tr), size=n_tr, replace=True)
        idx = np.concatenate([co_idx, tr_idx])

        Y_boot = Y[idx]
        D_boot = D[idx]

        try:
            att_b = _fit_drsc_core(
                Y_boot, D_boot, n_co, n_tr, t_pre, t_post,
                ridge_alpha=ridge_alpha, return_weights=False
            )[0]
            boot_atts.append(att_b)
        except Exception:
            continue

    if len(boot_atts) < 2:
        raise RuntimeError("DRSC bootstrap variance estimation failed.")

    return float(np.var(boot_atts, ddof=1))


def _jackknife_variance_drsc(
    Y: np.ndarray,
    D: np.ndarray,
    n_co: int,
    n_tr: int,
    t_pre: int,
    t_post: int,
    att_full: float,
    ridge_alpha: float,
) -> float:
    """Jackknife variance for DRSC: leave-one-unit-out."""
    n_total = n_co + n_tr
    jack_atts = []

    for drop_idx in range(n_total):
        idx = np.concatenate([np.arange(drop_idx), np.arange(drop_idx + 1, n_total)])
        Y_j = Y[idx]
        D_j = D[idx]

        n_co_j = n_co - (1 if drop_idx < n_co else 0)
        n_tr_j = n_tr - (1 if drop_idx >= n_co else 0)

        if n_co_j < 2 or n_tr_j == 0:
            continue

        try:
            att_j = _fit_drsc_core(
                Y_j, D_j, n_co_j, n_tr_j, t_pre, t_post,
                ridge_alpha=ridge_alpha, return_weights=False
            )[0]
            jack_atts.append(att_j)
        except Exception:
            continue

    if len(jack_atts) < 2:
        raise RuntimeError("DRSC jackknife variance estimation failed.")

    n_j = len(jack_atts)
    jack_mean = np.mean(jack_atts)
    variance = ((n_total - 1) / n_total) * np.sum(
        (np.array(jack_atts) - jack_mean) ** 2
    )
    return float(variance)


def _placebo_variance_drsc(
    Y: np.ndarray,
    D: np.ndarray,
    n_co: int,
    n_tr: int,
    t_pre: int,
    t_post: int,
    n_replicates: int,
    rng: np.random.Generator,
    ridge_alpha: float,
) -> float:
    """Placebo variance for DRSC: randomly assign treatment to control units."""
    if n_co <= n_tr:
        raise ValueError(
            f"Placebo inference requires N_control > N_treated, "
            f"got N_co={n_co}, N_tr={n_tr}. Use bootstrap instead."
        )

    Y_co = Y[:n_co]
    placebo_atts = []

    for _ in range(n_replicates):
        placebo_tr_idx = rng.choice(n_co, size=n_tr, replace=False)
        placebo_co_idx = np.setdiff1d(np.arange(n_co), placebo_tr_idx)

        Y_placebo_tr = Y_co[placebo_tr_idx]
        Y_placebo_co = Y_co[placebo_co_idx]
        Y_placebo = np.vstack([Y_placebo_co, Y_placebo_tr])
        D_placebo = np.vstack([
            np.zeros((len(placebo_co_idx), t_pre + t_post)),
            D[n_co:],
        ])

        try:
            att_p = _fit_drsc_core(
                Y_placebo, D_placebo,
                len(placebo_co_idx), n_tr, t_pre, t_post,
                ridge_alpha=ridge_alpha, return_weights=False,
            )[0]
            placebo_atts.append(att_p)
        except Exception:
            continue

    if len(placebo_atts) < 2:
        raise RuntimeError("DRSC placebo variance estimation failed.")

    return float(np.var(placebo_atts, ddof=1))


# ---------------------------------------------------------------------------
# Main DoublyRobustSCEstimator class
# ---------------------------------------------------------------------------


class DoublyRobustSCEstimator:
    """Doubly Robust Synthetic Control estimator for insurance panels.

    Implements the augmented synthetic control of Ben-Michael, Feller &
    Rothstein (2021). Combines SC/SDID-style unit weights with a two-way
    fixed effects outcome model for a doubly robust ATT estimate.

    The estimator is consistent if either:
    - the unit weights correctly identify the counterfactual, OR
    - the two-way fixed effects outcome model is correctly specified.

    This is valuable when N_co is small (fewer than ~10 donor units), where
    SC weight estimation is underdetermined and noisy. The 2WFE model provides
    an independent counterfactual, absorbing bias from weight misspecification.

    Parameters
    ----------
    panel : polars DataFrame
        Balanced panel from PolicyPanelBuilder.build(). Must contain:
        segment_id, period, {outcome}, treated, first_treated_period.
    outcome : str
        Name of the outcome column to estimate (e.g., 'loss_ratio').
    treatment_col : str
        Binary treatment indicator column. Default: 'treated'.
    unit_col : str
        Segment identifier column. Default: 'segment_id'.
    period_col : str
        Period column. Default: 'period'.
    inference : str
        Variance estimation method: 'bootstrap' (default), 'jackknife', 'placebo'.
        Bootstrap is recommended for DRSC — it captures uncertainty from both
        the weight optimisation and the outcome model simultaneously.
    n_replicates : int
        Number of replicates for bootstrap/placebo. Default: 200.
    ridge_alpha : float
        Regularisation strength for unit FE estimation in the 2WFE model.
        Default: 1.0. Shrinks unit FE estimates toward zero, improving
        stability when N_co or T_pre is small.
    random_seed : int
        Reproducibility seed. Default: 42.

    Notes
    -----
    The outcome model is a two-way fixed effects model estimated on control
    units in the pre-treatment period. Time effects are extrapolated to the
    post-treatment period via linear regression on the estimated pre-treatment
    time effects. This is appropriate for insurance panels where common time
    trends (claims inflation) are approximately linear.

    For non-linear time trends, consider increasing ridge_alpha to stabilise
    the extrapolation. The doubly robust property means that as long as either
    the SC weights or the 2WFE model is approximately correct, the ATT estimate
    will be consistent.

    References
    ----------
    Ben-Michael, E., Feller, A. & Rothstein, J. (2021). The Augmented Synthetic
    Control Method. Journal of the American Statistical Association 116(536).
    """

    def __init__(
        self,
        panel: pl.DataFrame,
        outcome: str = "loss_ratio",
        treatment_col: str = "treated",
        unit_col: str = "segment_id",
        period_col: str = "period",
        inference: Literal["bootstrap", "jackknife", "placebo"] = "bootstrap",
        n_replicates: int = 200,
        ridge_alpha: float = 1.0,
        random_seed: int = 42,
    ) -> None:
        self.panel = panel
        self.outcome = outcome
        self.treatment_col = treatment_col
        self.unit_col = unit_col
        self.period_col = period_col
        self.inference = inference
        self.n_replicates = n_replicates
        self.ridge_alpha = ridge_alpha
        self.rng = np.random.default_rng(random_seed)
        self._result: Optional[SDIDResult] = None

    def fit(self) -> SDIDResult:
        """Estimate ATT using doubly robust synthetic control.

        Returns SDIDResult with ATT, confidence interval, and diagnostic info.
        The result type is shared with SDIDEstimator for a common interface.
        inference_method is set to 'drsc_{inference}'.
        """
        Y, D, unit_ids, period_ids, n_co, n_tr, t_pre, t_post = self._prepare_matrices()

        # Core fit
        att, omega, omega_0, lambda_, zeta, att_sc, bias_corr = _fit_drsc_core(
            Y, D, n_co, n_tr, t_pre, t_post,
            ridge_alpha=self.ridge_alpha, return_weights=True,
        )

        # Inference
        var = self._compute_variance(Y, D, n_co, n_tr, t_pre, t_post, att)
        se = np.sqrt(max(var, 0.0))
        ci_low = att - 1.96 * se
        ci_high = att + 1.96 * se
        pval = 2 * (1 - stats.norm.cdf(abs(att) / max(se, 1e-10)))

        co_unit_ids = unit_ids[:n_co]
        pre_period_ids = period_ids[:t_pre]

        weights = SDIDWeights(
            unit_weights=pd.Series(omega, index=co_unit_ids, name="omega"),
            time_weights=pd.Series(lambda_, index=pre_period_ids, name="lambda"),
            unit_intercept=omega_0,
            regularisation_zeta=zeta,
        )

        event_study, pre_trend_pval = self._compute_event_study(
            Y, omega, lambda_, n_co, n_tr, t_pre, t_post, period_ids
        )

        result = SDIDResult(
            att=att,
            se=se,
            ci_low=ci_low,
            ci_high=ci_high,
            pval=pval,
            weights=weights,
            pre_trend_pval=pre_trend_pval,
            event_study=event_study,
            n_treated=n_tr,
            n_control=int(np.sum(omega > 1e-6)),
            n_control_total=n_co,
            t_pre=t_pre,
            t_post=t_post,
            outcome_name=self.outcome,
            inference_method=f"drsc_{self.inference}",
            n_replicates=self.n_replicates,
        )
        self._result = result
        return result

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _prepare_matrices(
        self,
    ) -> tuple[np.ndarray, np.ndarray, list, list, int, int, int, int]:
        """Convert panel DataFrame to Y and D matrices."""
        p = self.panel.drop_nulls(subset=[self.outcome])

        treated_segs = (
            p.filter(pl.col(self.treatment_col) == 1)[self.unit_col].unique().to_list()
        )
        if len(treated_segs) == 0:
            raise ValueError("No treated segments found.")

        all_segs = p[self.unit_col].unique().sort().to_list()
        control_segs = [s for s in all_segs if s not in treated_segs]

        if len(control_segs) == 0:
            raise ValueError("No control segments found.")

        first_treated = (
            p.filter(pl.col(self.treatment_col) == 1)[self.period_col].min()
        )
        all_periods = sorted(p[self.period_col].unique().to_list())
        pre_periods = [t for t in all_periods if t < first_treated]
        post_periods = [t for t in all_periods if t >= first_treated]

        if len(pre_periods) == 0:
            raise ValueError("No pre-treatment periods found.")
        if len(post_periods) == 0:
            raise ValueError("No post-treatment periods found.")

        n_co = len(control_segs)
        n_tr = len(treated_segs)
        t_pre = len(pre_periods)
        t_post = len(post_periods)
        T = t_pre + t_post

        unit_order = control_segs + treated_segs
        period_order = pre_periods + post_periods

        pivot = p.pivot(
            index=self.unit_col,
            on=self.period_col,
            values=self.outcome,
            aggregate_function="mean",
        )

        Y_rows = []
        for unit in unit_order:
            row = pivot.filter(pl.col(self.unit_col) == unit)
            if row.height == 0:
                Y_rows.append(np.full(T, np.nan))
            else:
                vals = []
                for per in period_order:
                    col_name = str(per)
                    if col_name in pivot.columns:
                        v = row[col_name][0]
                        vals.append(float(v) if v is not None else np.nan)
                    else:
                        vals.append(np.nan)
                Y_rows.append(vals)

        Y = np.array(Y_rows, dtype=float)
        col_means = np.nanmean(Y, axis=0)
        for j in range(T):
            mask = np.isnan(Y[:, j])
            Y[mask, j] = col_means[j]

        D = np.zeros((n_co + n_tr, T))
        for i, unit in enumerate(treated_segs):
            unit_data = p.filter(pl.col(self.unit_col) == unit)
            ftp = unit_data["first_treated_period"][0]
            for j, per in enumerate(period_order):
                if ftp is not None and per >= ftp:
                    D[n_co + i, j] = 1

        return Y, D, unit_order, period_order, n_co, n_tr, t_pre, t_post

    def _compute_variance(
        self,
        Y: np.ndarray,
        D: np.ndarray,
        n_co: int,
        n_tr: int,
        t_pre: int,
        t_post: int,
        att_full: float,
    ) -> float:
        if self.inference == "bootstrap":
            return _bootstrap_variance_drsc(
                Y, D, n_co, n_tr, t_pre, t_post,
                self.n_replicates, self.rng, self.ridge_alpha,
            )
        elif self.inference == "jackknife":
            return _jackknife_variance_drsc(
                Y, D, n_co, n_tr, t_pre, t_post,
                att_full, self.ridge_alpha,
            )
        elif self.inference == "placebo":
            return _placebo_variance_drsc(
                Y, D, n_co, n_tr, t_pre, t_post,
                self.n_replicates, self.rng, self.ridge_alpha,
            )
        else:
            raise ValueError(f"Unknown inference method: {self.inference}")

    def _compute_event_study(
        self,
        Y: np.ndarray,
        omega: np.ndarray,
        lambda_: np.ndarray,
        n_co: int,
        n_tr: int,
        t_pre: int,
        t_post: int,
        period_ids: list,
    ) -> tuple[pd.DataFrame, float]:
        """Compute period-by-period ATTs for the event study diagnostic."""
        Y_co = Y[:n_co]
        Y_tr = Y[n_co:]
        Y_co_pre = Y_co[:, :t_pre]
        Y_tr_pre = Y_tr[:, :t_pre]

        Y_tr_pre_uniform = np.mean(Y_tr_pre)
        Y_co_pre_om_uniform = omega @ np.mean(Y_co_pre, axis=1)

        T = t_pre + t_post
        att_by_period = []
        for t_idx in range(T):
            Y_tr_t = np.mean(Y_tr[:, t_idx])
            Y_co_t_om = omega @ Y_co[:, t_idx]
            att_t = (Y_tr_t - Y_tr_pre_uniform) - (Y_co_t_om - Y_co_pre_om_uniform)
            period_rel = t_idx - t_pre
            att_by_period.append({"period_rel": period_rel, "att": att_t})

        event_df = pd.DataFrame(att_by_period)
        event_df["se"] = np.nan
        event_df["ci_low"] = np.nan
        event_df["ci_high"] = np.nan

        pre_atts = event_df[event_df["period_rel"] < 0]["att"].values
        if len(pre_atts) > 1:
            _, pre_trend_pval = stats.ttest_1samp(pre_atts, 0.0)
        else:
            pre_trend_pval = None

        return event_df, pre_trend_pval
