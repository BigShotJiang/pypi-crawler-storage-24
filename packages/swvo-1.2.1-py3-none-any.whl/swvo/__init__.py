# SPDX-FileCopyrightText: 2025 GFZ Helmholtz Centre for Geosciences
#
# SPDX-License-Identifier: Apache-2.0

__version__ = "1.2.1"

from swvo import io as io
from swvo.logger import setup_logging

__all__ = ["setup_logging"]
