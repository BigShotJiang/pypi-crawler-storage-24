"""AgentAZAll command implementations."""
