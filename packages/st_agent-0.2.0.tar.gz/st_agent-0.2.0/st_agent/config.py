"""
Agent config — read/write ~/.st-agent/config.json.
"""
import json
import os
from dataclasses import dataclass, asdict
from typing import Optional


@dataclass
class AgentConfig:
    platform_url: str = ""
    agent_id: str = ""
    agent_token: str = ""
    platform_public_key_pem: str = ""
    agent_name: str = ""

    @staticmethod
    def default_config_dir() -> str:
        return os.path.join(os.path.expanduser("~"), ".st-agent")

    @staticmethod
    def config_path() -> str:
        return os.path.join(AgentConfig.default_config_dir(), "config.json")


def save_config(config: AgentConfig):
    """Save agent config to ~/.st-agent/config.json."""
    path = config.config_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(asdict(config), f, indent=2)
    os.chmod(path, 0o600)


def load_config() -> Optional[AgentConfig]:
    """Load agent config from ~/.st-agent/config.json. Returns None if not found."""
    path = AgentConfig.config_path()
    if not os.path.exists(path):
        return None
    with open(path) as f:
        data = json.load(f)
    return AgentConfig(**data)
