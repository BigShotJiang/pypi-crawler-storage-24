"""
Agent crypto — RSA keypair generation + signature verification.
"""
import base64
import json

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa


def generate_rsa_keypair(key_size: int = 4096) -> tuple[bytes, bytes]:
    """Generate RSA keypair, return (private_pem, public_pem)."""
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=key_size)
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_pem


def verify_platform_signature(instruction: dict, platform_public_key_pem: str) -> bool:
    """Verify RSA-SHA256 signature from platform."""
    sig_b64 = instruction.get("signature")
    if not sig_b64:
        return False
    payload = {k: v for k, v in instruction.items() if k != "signature"}
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    try:
        public_key = serialization.load_pem_public_key(platform_public_key_pem.encode())
        public_key.verify(
            base64.b64decode(sig_b64),
            canonical.encode(),
            padding.PKCS1v15(),
            hashes.SHA256(),
        )
        return True
    except Exception:
        return False
