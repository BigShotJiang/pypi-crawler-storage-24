"""
Agent CLI — st-agent register / start / stop / status.
"""
import argparse
import asyncio
import json
import logging
import os
import platform
import signal
import sys

import requests

from .config import AgentConfig, load_config, save_config
from .connection import run_agent
from .crypto import generate_rsa_keypair

logger = logging.getLogger("st-agent")
VERSION = "0.1.0"


def cmd_register(args):
    """Register this agent with the platform."""
    config_dir = AgentConfig.default_config_dir()
    os.makedirs(config_dir, exist_ok=True)

    private_pem, public_pem = generate_rsa_keypair()
    priv_path = os.path.join(config_dir, "agent_private.pem")
    pub_path = os.path.join(config_dir, "agent_public.pem")
    with open(priv_path, "wb") as f:
        f.write(private_pem)
    os.chmod(priv_path, 0o600)
    with open(pub_path, "wb") as f:
        f.write(public_pem)

    # Fetch platform public key
    resp = requests.get(f"{args.url}/api/agents/platform-key", timeout=10)
    resp.raise_for_status()
    platform_pub = resp.json()["public_key"]

    # Register with platform
    name = args.name or platform.node()
    body = {
        "name": name,
        "hostname": platform.node(),
        "os_info": f"{platform.system()} {platform.release()}",
        "version": VERSION,
        "public_key": public_pem.decode(),
    }
    headers = {"x-api-key": args.api_key}
    resp = requests.post(f"{args.url}/api/agents/register",
                         json=body, headers=headers, timeout=10)
    resp.raise_for_status()
    data = resp.json()

    config = AgentConfig(
        platform_url=args.url,
        agent_id=data["agent_id"],
        agent_token=data["agent_token"],
        platform_public_key_pem=platform_pub,
        agent_name=name,
    )
    save_config(config)
    print(f"Registered as '{name}' (id: {data['agent_id']})")
    print(f"Config saved to {config_dir}")


def cmd_start(args):
    """Start the agent daemon (foreground)."""
    config = load_config()
    if not config:
        print("Agent not registered. Run: st-agent register --url ... --api-key ...",
              file=sys.stderr)
        sys.exit(1)

    logger.info(f"Starting st-agent {VERSION} — {config.agent_name} ({config.agent_id})")

    loop = asyncio.new_event_loop()
    shutdown_event = asyncio.Event()

    def _signal_handler(sig, frame):
        logger.info(f"Received {signal.Signals(sig).name}, shutting down...")
        shutdown_event.set()

    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)

    try:
        loop.run_until_complete(run_agent(config, shutdown_event))
    finally:
        loop.close()


def cmd_status(args):
    """Show agent registration status."""
    config = load_config()
    if not config:
        print("Not registered. Run: st-agent register --url ... --api-key ...")
        sys.exit(1)
    print(f"Agent: {config.agent_name}")
    print(f"ID:    {config.agent_id}")
    print(f"URL:   {config.platform_url}")


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")

    parser = argparse.ArgumentParser(prog="st-agent", description="SAGE Agent")
    sub = parser.add_subparsers(dest="command")

    # register
    reg = sub.add_parser("register", help="Register with platform")
    reg.add_argument("--url", required=True, help="Platform URL (e.g. http://hub:6212)")
    reg.add_argument("--name", help="Agent name (default: hostname)")
    reg.add_argument("--api-key", required=True, help="API key for registration")

    # start
    sub.add_parser("start", help="Start agent daemon (foreground)")

    # status
    sub.add_parser("status", help="Show registration status")

    args = parser.parse_args()
    if args.command == "register":
        cmd_register(args)
    elif args.command == "start":
        cmd_start(args)
    elif args.command == "status":
        cmd_status(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
