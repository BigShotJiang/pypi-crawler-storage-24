"""
Agent SSE connection — persistent aiohttp SSE client with auto-reconnect.
"""
import asyncio
import json
import logging

import aiohttp

from .config import AgentConfig
from .crypto import verify_platform_signature
from .heartbeat import start_heartbeat

logger = logging.getLogger("st-agent.connection")


async def run_agent(config: AgentConfig, shutdown_event: asyncio.Event):
    """Main agent loop: connect to SSE, dispatch instructions, heartbeat."""
    heartbeat_task = asyncio.create_task(
        start_heartbeat(config, shutdown_event)
    )

    from .handlers.transfer import handle_transfer
    from .handlers.cloud import handle_cloud_transfer
    from .handlers.browse import handle_browse
    from .handlers.disk_stats import handle_disk_stats
    from .handlers.endpoint import handle_endpoint

    HANDLERS = {
        "transfer": handle_transfer,
        "cloud_transfer": handle_cloud_transfer,
        "list_directory": handle_browse,
        "disk_stats": handle_disk_stats,
        "request_endpoint": handle_endpoint,
    }

    backoff = 1
    while not shutdown_event.is_set():
        try:
            async with aiohttp.ClientSession() as session:
                headers = {
                    "x-agent-id": config.agent_id,
                    "x-agent-token": config.agent_token,
                }
                url = f"{config.platform_url}/api/agents/{config.agent_id}/stream"
                logger.info(f"Connecting to {url}")

                async with session.get(url, headers=headers, timeout=None) as resp:
                    if resp.status != 200:
                        logger.error(f"SSE connection failed: HTTP {resp.status}")
                        raise aiohttp.ClientError(f"HTTP {resp.status}")

                    backoff = 1
                    logger.info("SSE connected")

                    async for line in resp.content:
                        if shutdown_event.is_set():
                            break
                        text = line.decode().strip()
                        if not text or text.startswith(":"):
                            continue
                        if text.startswith("data:"):
                            text = text[5:].strip()
                        if not text:
                            continue

                        try:
                            instruction = json.loads(text)
                        except json.JSONDecodeError:
                            continue

                        if not verify_platform_signature(instruction, config.platform_public_key_pem):
                            logger.warning("Rejected instruction — invalid signature")
                            continue

                        itype = instruction.get("type", "")
                        if itype == "ping":
                            continue
                        elif itype == "restart":
                            logger.info("Received restart instruction, exiting...")
                            shutdown_event.set()
                            break

                        handler = HANDLERS.get(itype)
                        if handler:
                            asyncio.create_task(handler(config, instruction))
                        else:
                            logger.warning(f"Unknown instruction type: {itype}")

        except (aiohttp.ClientError, ConnectionError, asyncio.TimeoutError) as e:
            logger.warning(f"SSE disconnected: {e}. Reconnecting in {backoff}s...")
            await asyncio.sleep(min(backoff, 30))
            backoff = min(backoff * 2, 30)

        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)
            await asyncio.sleep(5)

    heartbeat_task.cancel()
    logger.info("Agent stopped")
