"""
Agent rsync progress parser + POST ticks to platform.
"""
import logging
import re
from typing import Optional

import requests

from .config import AgentConfig

logger = logging.getLogger("st-agent.progress")

RSYNC_PROGRESS_RE = re.compile(
    r"\s*([\d,]+)\s+(\d+)%\s+([\d.]+\S+/s)\s+(\S+)"
)


def parse_rsync_progress(line: str) -> Optional[dict]:
    """Parse rsync --info=progress2 output line."""
    m = RSYNC_PROGRESS_RE.match(line.strip())
    if m:
        return {
            "bytes_transferred": int(m.group(1).replace(",", "")),
            "pct": int(m.group(2)),
            "speed": m.group(3),
            "eta": m.group(4),
        }
    return None


def post_progress(config: AgentConfig, job_id: str, tick: dict):
    """POST a progress tick to the platform."""
    url = f"{config.platform_url}/api/agents/progress"
    headers = {
        "x-agent-id": config.agent_id,
        "x-agent-token": config.agent_token,
    }
    body = {"type": "progress", "jobId": job_id, **tick}
    try:
        resp = requests.post(url, json=body, headers=headers, timeout=5)
        if resp.status_code != 202:
            logger.debug(f"Progress POST returned {resp.status_code}")
    except requests.RequestException as e:
        logger.debug(f"Progress POST failed: {e}")


def post_done(config: AgentConfig, job_id: str, exit_code: int):
    """POST transfer completion to the platform."""
    url = f"{config.platform_url}/api/agents/progress"
    headers = {
        "x-agent-id": config.agent_id,
        "x-agent-token": config.agent_token,
    }
    body = {
        "type": "done" if exit_code == 0 else "error",
        "jobId": job_id,
        "error": f"rsync exited with code {exit_code}" if exit_code != 0 else None,
    }
    try:
        requests.post(url, json=body, headers=headers, timeout=5)
    except requests.RequestException as e:
        logger.debug(f"Done POST failed: {e}")
