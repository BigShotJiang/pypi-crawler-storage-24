"""
Agent heartbeat — POST to platform every 15s to stay marked online.
"""
import asyncio
import logging

import aiohttp

from .config import AgentConfig

logger = logging.getLogger("st-agent.heartbeat")


async def start_heartbeat(config: AgentConfig, shutdown_event: asyncio.Event):
    """Background task: POST heartbeat every 15 seconds."""
    url = f"{config.platform_url}/api/agents/{config.agent_id}/heartbeat"
    headers = {
        "x-agent-id": config.agent_id,
        "x-agent-token": config.agent_token,
    }

    while not shutdown_event.is_set():
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    if resp.status != 204:
                        logger.warning(f"Heartbeat failed: HTTP {resp.status}")
        except Exception as e:
            logger.debug(f"Heartbeat error: {e}")

        try:
            await asyncio.wait_for(shutdown_event.wait(), timeout=15)
            break
        except asyncio.TimeoutError:
            pass
