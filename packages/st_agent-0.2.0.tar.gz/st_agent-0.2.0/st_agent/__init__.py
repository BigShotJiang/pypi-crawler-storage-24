"""st-agent — SAGE remote agent daemon."""

__version__ = "0.2.0"
