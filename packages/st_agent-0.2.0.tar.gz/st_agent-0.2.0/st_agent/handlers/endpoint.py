"""
Handler: start temporary rsyncd endpoint on random port with one-time token.
"""
import asyncio
import logging
import os
import secrets
import socket
import subprocess
import random

import requests

from ..config import AgentConfig

logger = logging.getLogger("st-agent.handlers.endpoint")


def _get_local_ip() -> str:
    """Get best-guess local IP (not 127.0.0.1)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"


async def handle_endpoint(config: AgentConfig, instruction: dict):
    """Start temp rsyncd on random port, POST back host/port/token."""
    job_id = instruction.get("jobId", "")
    dest_path = instruction.get("destPath", "/tmp")
    port = random.randint(8730, 8799)
    token = secrets.token_hex(32)

    conf_path = f"/tmp/st-rsyncd-{job_id}.conf"
    secrets_path = f"/tmp/st-rsyncd-{job_id}.secrets"

    conf = f"""[dest]
path = {dest_path}
read only = false
auth users = {token}
secrets file = {secrets_path}
"""
    with open(conf_path, "w") as f:
        f.write(conf)
    with open(secrets_path, "w") as f:
        f.write(f"{token}:{token}\n")
    os.chmod(secrets_path, 0o600)

    proc = subprocess.Popen([
        "rsync", "--daemon", "--no-detach",
        f"--config={conf_path}",
        f"--port={port}",
    ])

    host = _get_local_ip()

    url = f"{config.platform_url}/api/agents/progress"
    headers = {
        "x-agent-id": config.agent_id,
        "x-agent-token": config.agent_token,
    }
    body = {
        "type": "endpoint_ready",
        "jobId": job_id,
        "host": host,
        "port": port,
        "token": token,
    }
    try:
        requests.post(url, json=body, headers=headers, timeout=10)
    except requests.RequestException as e:
        logger.warning(f"Failed to POST endpoint_ready: {e}")

    logger.info(f"[{job_id}] rsyncd started on {host}:{port}")

    try:
        proc.wait(timeout=1800)
    except subprocess.TimeoutExpired:
        proc.terminate()
    finally:
        for p in (conf_path, secrets_path):
            if os.path.exists(p):
                os.unlink(p)
