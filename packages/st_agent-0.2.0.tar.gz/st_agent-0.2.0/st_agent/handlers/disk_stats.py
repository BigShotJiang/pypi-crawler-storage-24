"""
Handler: disk stats via shutil.disk_usage().
"""
import logging
import shutil

import requests

from ..config import AgentConfig

logger = logging.getLogger("st-agent.handlers.disk_stats")


async def handle_disk_stats(config: AgentConfig, instruction: dict):
    """Get disk usage for a path and POST result back to platform."""
    path = instruction.get("path", "/")
    callback_id = instruction.get("callbackId", "")

    try:
        usage = shutil.disk_usage(path)
        stats = {
            "path": path,
            "total_bytes": usage.total,
            "used_bytes": usage.used,
            "free_bytes": usage.free,
            "used_pct": round(usage.used / usage.total * 100, 1) if usage.total > 0 else 0,
        }
    except (OSError, FileNotFoundError) as e:
        stats = {"path": path, "error": str(e)}

    url = f"{config.platform_url}/api/agents/progress"
    headers = {
        "x-agent-id": config.agent_id,
        "x-agent-token": config.agent_token,
    }
    body = {"type": "disk_stats_result", "callbackId": callback_id, **stats}
    try:
        requests.post(url, json=body, headers=headers, timeout=10)
    except requests.RequestException as e:
        logger.warning(f"Failed to POST disk stats: {e}")
