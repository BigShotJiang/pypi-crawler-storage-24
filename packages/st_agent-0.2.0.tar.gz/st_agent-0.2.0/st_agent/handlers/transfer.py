"""
Handler: execute rsync transfer (direct or mesh mode).
"""
import asyncio
import logging
import os
import tempfile

from ..config import AgentConfig
from ..progress import parse_rsync_progress, post_progress, post_done

logger = logging.getLogger("st-agent.handlers.transfer")


async def handle_transfer(config: AgentConfig, instruction: dict):
    """Execute rsync transfer from instruction."""
    job_id = instruction.get("jobId", "")
    source = instruction.get("sourcePath", "")
    dest = instruction.get("destination", "")
    options = instruction.get("options", {})
    streams = options.get("streams", 1)

    logger.info(f"[{job_id}] Transfer: {source} -> {dest} (streams={streams})")

    if streams > 1:
        await _mesh_transfer(config, job_id, source, dest, streams, options)
    else:
        await _single_transfer(config, job_id, source, dest, options)


async def _single_transfer(config: AgentConfig, job_id: str,
                           source: str, dest: str, options: dict):
    """Single rsync stream."""
    cmd = [
        "rsync", "--archive", "--partial", "--append-verify",
        "--info=progress2",
        source + "/",
        dest,
    ]
    if options.get("compress"):
        cmd.append("--compress")
    if options.get("verify"):
        cmd.append("--checksum")
    bwlimit = options.get("bwlimit_kbps", 0)
    if bwlimit > 0:
        cmd.append(f"--bwlimit={bwlimit}")

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    async for line in proc.stdout:
        text = line.decode().strip()
        tick = parse_rsync_progress(text)
        if tick:
            post_progress(config, job_id, tick)

    await proc.wait()
    post_done(config, job_id, proc.returncode)
    logger.info(f"[{job_id}] Transfer complete, exit code: {proc.returncode}")


async def _mesh_transfer(config: AgentConfig, job_id: str,
                         source: str, dest: str, streams: int, options: dict):
    """Mesh mode: split files across N parallel rsync processes."""
    streams = max(1, min(streams, 64))
    entries = sorted(os.listdir(source))
    groups = [[] for _ in range(streams)]
    for i, entry in enumerate(entries):
        groups[i % streams].append(entry)

    tmpdir = tempfile.mkdtemp(prefix=f"st-mesh-{job_id}-")

    tasks = []
    for i, group in enumerate(groups):
        if not group:
            continue
        fpath = os.path.join(tmpdir, f"stream-{i}.txt")
        with open(fpath, "w") as f:
            f.write("\n".join(group) + "\n")

        cmd = [
            "rsync", "--archive", "--partial", "--append-verify",
            "--inplace", "--size-only",
            f"--files-from={fpath}",
            source + "/",
            dest,
        ]
        if options.get("compress"):
            cmd.append("--compress")
        bwlimit = options.get("bwlimit_kbps", 0)
        if bwlimit > 0:
            cmd.append(f"--bwlimit={bwlimit}")

        tasks.append(asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        ))

    procs = await asyncio.gather(*tasks)
    results = await asyncio.gather(*(p.wait() for p in procs))
    worst = max(results) if results else 0
    post_done(config, job_id, worst)
    logger.info(f"[{job_id}] Mesh transfer complete ({streams} streams), worst exit: {worst}")
