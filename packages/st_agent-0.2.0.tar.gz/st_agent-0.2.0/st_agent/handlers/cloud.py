"""
Handler: rclone cloud transfer with temp config.
"""
import asyncio
import logging
import os
import re
import tempfile

from ..config import AgentConfig
from ..progress import post_progress, post_done

logger = logging.getLogger("st-agent.handlers.cloud")

RCLONE_PROGRESS_RE = re.compile(
    r"([\d.]+\s*\w+)\s*/\s*([\d.]+\s*\w+),\s*(\d+)%,\s*([\d.]+\s*\w+/s),\s*ETA\s*(\S+)"
)


async def handle_cloud_transfer(config: AgentConfig, instruction: dict):
    """Run rclone with temp config, clean up after."""
    job_id = instruction.get("jobId", "")
    local_path = instruction.get("localPath", "")
    remote_name = instruction.get("remoteName", "")
    remote_path = instruction.get("remotePath", "")
    credentials = instruction.get("credentials", {})

    logger.info(f"[{job_id}] Cloud transfer: {local_path} -> {remote_name}:{remote_path}")

    fd, conf_path = tempfile.mkstemp(prefix=f"st-rclone-{job_id}-", suffix=".conf")
    try:
        conf_lines = [f"[{remote_name}]"]
        for k, v in credentials.items():
            conf_lines.append(f"{k} = {v}")
        os.write(fd, "\n".join(conf_lines).encode())
        os.close(fd)
        os.chmod(conf_path, 0o600)

        cmd = [
            "rclone", "copy",
            "--config", conf_path,
            "--stats", "1s",
            "--stats-log-level", "NOTICE",
            local_path,
            f"{remote_name}:{remote_path}",
        ]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )

        async for line in proc.stderr:
            text = line.decode().strip()
            m = RCLONE_PROGRESS_RE.search(text)
            if m:
                tick = {
                    "pct": int(m.group(3)),
                    "speed": m.group(4),
                    "eta": m.group(5),
                }
                post_progress(config, job_id, tick)

        await proc.wait()
        post_done(config, job_id, proc.returncode)
        logger.info(f"[{job_id}] Cloud transfer complete, exit code: {proc.returncode}")
    finally:
        if os.path.exists(conf_path):
            os.unlink(conf_path)
