"""
Handler: browse remote directory via os.scandir().
"""
import logging
import os

import requests

from ..config import AgentConfig

logger = logging.getLogger("st-agent.handlers.browse")


async def handle_browse(config: AgentConfig, instruction: dict):
    """List directory contents and POST result back to platform."""
    path = instruction.get("path", "/")
    callback_id = instruction.get("callbackId", "")

    dirs_only = instruction.get("dirsOnly", False)

    entries = []
    try:
        with os.scandir(path) as it:
            for entry in it:
                if entry.name.startswith("."):
                    continue
                try:
                    is_dir = entry.is_dir(follow_symlinks=False)
                    if dirs_only and not is_dir:
                        continue
                    stat = entry.stat(follow_symlinks=False)
                    entries.append({
                        "name": entry.name,
                        "path": entry.path,
                        "type": "dir" if is_dir else "file",
                        "size": stat.st_size if entry.is_file() else None,
                    })
                except (OSError, PermissionError):
                    continue
    except (OSError, PermissionError) as e:
        entries = []
        logger.warning(f"Browse failed for {path}: {e}")

    entries.sort(key=lambda e: (0 if e["type"] == "dir" else 1, e["name"].lower()))

    url = f"{config.platform_url}/api/agents/browse-result"
    headers = {
        "x-agent-id": config.agent_id,
        "x-agent-token": config.agent_token,
    }
    body = {
        "type": "browse_result",
        "callbackId": callback_id,
        "path": path,
        "entries": entries[:1000],
    }
    try:
        requests.post(url, json=body, headers=headers, timeout=10)
    except requests.RequestException as e:
        logger.warning(f"Failed to POST browse result: {e}")
