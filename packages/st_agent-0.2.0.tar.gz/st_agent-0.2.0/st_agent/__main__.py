"""Allow running as: python -m st_agent"""
from st_agent.cli import main

main()
