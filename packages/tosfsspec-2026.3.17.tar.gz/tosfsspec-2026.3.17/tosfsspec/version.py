import importlib.metadata
from importlib.metadata import PackageNotFoundError


def get_project_version():
    try:
        version = importlib.metadata.version('tosfsspec')
    except PackageNotFoundError:
        version = '2026.3.0-dev'
    return version
