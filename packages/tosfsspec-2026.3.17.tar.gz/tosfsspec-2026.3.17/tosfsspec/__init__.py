import os

from tosnativeclient import init_tracing_logs
from .core import TosFileSystem, TosFile
from .version import get_project_version


def init_logs(directory: str = '', common_log: str = '', common_level: str = '', audit_log: str = '',
              audit_level: str = '') -> None:
    init_tracing_logs(directory, common_log + '-' + str(os.getpid()), common_level, audit_log + '-' + str(os.getpid()),
                      audit_level)


version = get_project_version()
__all__ = ['TosFileSystem', 'TosFile', 'version', 'init_logs']
