"""Plan schema types, defaults, and validation."""

from __future__ import annotations

from typing import Any, NotRequired, Required, TypedDict

from desloppify.engine._plan.constants import SYNTHETIC_PREFIXES
from desloppify.engine._plan.schema.migrations import (
    upgrade_plan_to_v8 as _upgrade_plan_to_v8,
)
from desloppify.engine._plan.skip_policy import VALID_SKIP_KINDS
from desloppify.engine._state.schema import utc_now

PLAN_VERSION = 8

EPIC_PREFIX = "epic/"
VALID_EPIC_DIRECTIONS = {
    "delete", "merge", "flatten", "enforce",
    "simplify", "decompose", "extract", "inline",
}


class SkipEntry(TypedDict, total=False):
    issue_id: Required[str]
    kind: Required[str]  # "temporary" | "permanent" | "false_positive"
    reason: str | None
    note: str | None  # required for permanent (wontfix note)
    attestation: str | None  # required for permanent/false_positive
    created_at: str
    review_after: int | None  # re-surface after N scans (temporary only)
    skipped_at_scan: int  # state.scan_count when skipped


class ItemOverride(TypedDict, total=False):
    issue_id: Required[str]
    description: str | None
    note: str | None
    cluster: str | None
    created_at: str
    updated_at: str


class ActionStep(TypedDict, total=False):
    title: Required[str]        # Short summary, 1 line
    detail: str                 # Long description, paragraphs OK
    issue_refs: list[str]       # Issue ID suffixes this step addresses
    done: bool                  # Completion tracking (default False)


class Cluster(TypedDict, total=False):
    name: Required[str]
    description: str | None
    issue_ids: list[str]
    created_at: str
    updated_at: str
    auto: bool  # True for auto-generated clusters
    cluster_key: str  # Deterministic grouping key (for regeneration)
    action: str | None  # Primary resolution command/guidance text
    user_modified: bool  # True when user manually edits membership
    optional: bool
    thesis: str
    direction: str
    root_cause: str
    supersedes: list[str]
    dismissed: list[str]
    agent_safe: bool
    dependency_order: int
    action_steps: list[ActionStep]
    priority: int
    source_clusters: list[str]
    status: str
    triage_version: int


class CommitRecord(TypedDict, total=False):
    sha: Required[str]           # git commit SHA
    branch: str | None           # branch name
    issue_ids: list[str]       # issues included
    recorded_at: str             # ISO timestamp
    note: str | None             # user-provided rationale
    cluster_name: str | None     # cluster context


class ExecutionLogEntry(TypedDict, total=False):
    timestamp: Required[str]
    action: Required[str]  # "done", "skip", "unskip", "resolve", "reconcile", "cluster_done", "focus", "reset"
    issue_ids: list[str]
    cluster_name: str | None
    actor: str  # "user" | "system" | "agent"
    note: str | None
    detail: dict[str, Any]  # action-specific extra data


class SupersededEntry(TypedDict, total=False):
    original_id: Required[str]
    original_detector: str
    original_file: str
    original_summary: str
    status: str  # "superseded" | "remapped" | "dismissed"
    superseded_at: str
    remapped_to: str | None
    candidates: list[str]
    note: str | None


class PlanStartScores(TypedDict, total=False):
    """Frozen score snapshot captured when a plan cycle starts."""

    strict: float
    overall: float
    objective: float
    verified: float
    reset: bool


class IssueDisposition(TypedDict, total=False):
    """Per-issue intent/history accumulated across triage stages.

    Observe writes verdict fields; reflect writes decision fields.
    NOT derived state — ``plan["clusters"]`` and ``plan["skipped"]`` remain
    authoritative for "what is actually true now."
    """

    # Observe writes (what did we find?):
    verdict: str  # "genuine" | "false positive" | "exaggerated" | "over engineering" | "not worth it"
    verdict_reasoning: str
    files_read: list[str]
    recommendation: str

    # Reflect writes (what should we do about it?):
    decision: str  # "cluster" | "skip"
    target: str  # cluster name or skip reason
    decision_source: str  # "observe_auto" (false-positive auto-skip) | "reflect" (strategy)


class ReflectDisposition(TypedDict, total=False):
    """One issue's disposition as declared by the reflect stage."""

    issue_id: Required[str]
    decision: Required[str]  # "cluster" | "permanent_skip"
    target: Required[str]  # cluster name or skip reason tag


class ReflectClusterBlueprint(TypedDict, total=False):
    """A cluster definition declared by the reflect stage."""

    name: Required[str]
    description: str
    priority_order: int
    depends_on: list[str]


class TriageStagePayload(TypedDict, total=False):
    """Persisted payload for one triage stage checkpoint."""

    stage: str
    report: str
    cited_ids: list[str]
    timestamp: str
    issue_count: int
    recurring_dims: list[str]
    confirmed_at: str
    confirmed_text: str
    # Structured reflect contract (populated only for reflect stage)
    disposition_ledger: list[ReflectDisposition]
    cluster_blueprint: list[ReflectClusterBlueprint]


class LastTriageSnapshot(TypedDict, total=False):
    """Archived triage stage state captured when triage is completed."""

    completed_at: str
    stages: dict[str, TriageStagePayload]
    strategy: str


class EpicTriageMeta(TypedDict, total=False):
    """Metadata persisted for the multi-stage triage flow."""

    triaged_ids: list[str]
    active_triage_issue_ids: list[str]
    dismissed_ids: list[str]
    undispositioned_issue_ids: list[str]
    undispositioned_issue_count: int
    issue_snapshot_hash: str
    strategy_summary: str
    trigger: str
    version: int
    last_run: str
    last_completed_at: str
    triage_stages: dict[str, TriageStagePayload]
    stage_snapshot_hash: str
    stage_refresh_required: bool
    last_triage: LastTriageSnapshot
    triage_defer_state: dict[str, Any]
    issue_dispositions: dict[str, IssueDisposition]
    triage_force_visible: bool


class RefreshState(TypedDict, total=False):
    """Metadata for the post-flight refresh pipeline."""

    lifecycle_phase: str
    postflight_scan_completed_at_scan_count: int
    pending_import_scores: dict[str, Any]


class PlanModel(TypedDict, total=False):
    version: Required[int]
    created: Required[str]
    updated: Required[str]
    queue_order: list[str]
    deferred: list[str]  # kept empty for migration compat
    skipped: dict[str, SkipEntry]
    active_cluster: str | None
    overrides: dict[str, ItemOverride]
    clusters: dict[str, Cluster]
    superseded: dict[str, SupersededEntry]
    promoted_ids: list[str]  # IDs user explicitly positioned via move_items()
    plan_start_scores: PlanStartScores
    previous_plan_start_scores: PlanStartScores
    refresh_state: RefreshState
    execution_log: list[ExecutionLogEntry]
    epic_triage_meta: EpicTriageMeta
    subjective_defer_meta: dict[str, Any]
    commit_log: list[CommitRecord]
    uncommitted_issues: list[str]
    commit_tracking_branch: str | None
    completed_clusters: NotRequired[list[dict[str, Any]]]  # legacy snapshot key


def empty_plan() -> PlanModel:
    """Return a new empty plan payload."""
    now = utc_now()
    return {
        "version": PLAN_VERSION,
        "created": now,
        "updated": now,
        "queue_order": [],
        "deferred": [],
        "skipped": {},
        "active_cluster": None,
        "overrides": {},
        "clusters": {},
        "superseded": {},
        "promoted_ids": [],
        "plan_start_scores": {},
        "refresh_state": {},
        "execution_log": [],
        "epic_triage_meta": {},
        "commit_log": [],
        "uncommitted_issues": [],
        "commit_tracking_branch": None,
    }


def ensure_plan_defaults(plan: dict[str, Any]) -> None:
    """Normalize a loaded plan to ensure all keys exist.

    Runtime contract is v8-only. Legacy payloads are upgraded in-place once.
    """
    defaults = empty_plan()
    for key, value in defaults.items():
        plan.setdefault(key, value)
    _upgrade_plan_to_v8(plan)
    subjective_defer_meta = plan.get("subjective_defer_meta")
    if isinstance(subjective_defer_meta, dict):
        subjective_defer_meta.pop("force_visible_ids", None)
    epic_triage_meta = plan.get("epic_triage_meta")
    if isinstance(epic_triage_meta, dict):
        epic_triage_meta.pop("triage_force_visible", None)


def triage_clusters(plan: dict[str, Any]) -> dict[str, Cluster]:
    """Return clusters whose name starts with ``EPIC_PREFIX``."""
    return {
        name: cluster
        for name, cluster in plan.get("clusters", {}).items()
        if name.startswith(EPIC_PREFIX)
    }


def tracked_plan_ids(plan: dict[str, Any] | None) -> set[str]:
    """Collect all issue IDs the plan is actively tracking.

    Includes queue_order, skipped, overrides, and cluster members/step refs.
    Returns an empty set for None or non-dict plans.
    """
    if not isinstance(plan, dict):
        return set()
    tracked: set[str] = set(plan.get("queue_order", []))
    tracked.update(plan.get("skipped", {}).keys())
    tracked.update(plan.get("overrides", {}).keys())
    for cluster in plan.get("clusters", {}).values():
        tracked.update(cluster.get("issue_ids", []))
        for step in cluster.get("action_steps", []):
            if isinstance(step, dict):
                tracked.update(step.get("issue_refs", []))
    return tracked


def planned_objective_ids(
    all_objective_ids: set[str],
    plan: dict[str, Any] | None,
) -> set[str]:
    """Return the subset of objective IDs the plan considers active work.

    Pre-triage (plan tracks nothing): all objective IDs are treated as
    planned work.

    Once the plan tracks anything, only the intersection with live
    objective IDs counts as planned. This lets stale queue_order entries
    fail closed into postflight/backlog instead of broadening execution
    back out to the entire objective backlog.
    """
    tracked = tracked_plan_ids(plan)
    skipped_ids = set(plan.get("skipped", {}).keys()) if isinstance(plan, dict) else set()
    active_tracked = {
        issue_id
        for issue_id in tracked - skipped_ids
        if not any(issue_id.startswith(prefix) for prefix in SYNTHETIC_PREFIXES)
    }
    if not active_tracked:
        return set(all_objective_ids)
    return all_objective_ids & active_tracked


def validate_plan(plan: dict[str, Any]) -> None:
    """Raise ValueError when plan invariants are violated."""
    if not isinstance(plan.get("version"), int):
        raise ValueError("plan.version must be an int")
    if not isinstance(plan.get("queue_order"), list):
        raise ValueError("plan.queue_order must be a list")

    # No ID should appear in both queue_order and skipped
    skipped_ids = set(plan.get("skipped", {}).keys())
    overlap = set(plan["queue_order"]) & skipped_ids
    if overlap:
        raise ValueError(
            f"IDs cannot appear in both queue_order and skipped: {sorted(overlap)}"
        )

    # Validate skip entry kinds
    for fid, entry in plan.get("skipped", {}).items():
        if not isinstance(entry, dict):
            raise ValueError(f"plan.skipped[{fid!r}] must be an object")
        if "kind" not in entry:
            raise ValueError(f"plan.skipped[{fid!r}] missing required key 'kind'")
        kind = entry["kind"]
        if kind not in VALID_SKIP_KINDS:
            raise ValueError(
                f"Invalid skip kind {kind!r} for {fid}; must be one of {sorted(VALID_SKIP_KINDS)}"
            )


__all__ = [
    "ActionStep",
    "EPIC_PREFIX",
    "EpicTriageMeta",
    "IssueDisposition",
    "ExecutionLogEntry",
    "PLAN_VERSION",
    "Cluster",
    "CommitRecord",
    "ItemOverride",
    "LastTriageSnapshot",
    "PlanModel",
    "PlanStartScores",
    "RefreshState",
    "SkipEntry",
    "SupersededEntry",
    "TriageStagePayload",
    "VALID_EPIC_DIRECTIONS",
    "VALID_SKIP_KINDS",
    "empty_plan",
    "ensure_plan_defaults",
    "planned_objective_ids",
    "tracked_plan_ids",
    "triage_clusters",
    "validate_plan",
]
