"""
db-wizard Test Suite
"""