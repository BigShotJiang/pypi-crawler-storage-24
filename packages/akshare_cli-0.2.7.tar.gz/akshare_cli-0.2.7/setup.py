"""Setup script for akshare-cli."""

from setuptools import setup, find_packages

setup(
    name="akshare-cli",
    version="0.2.7",
    description="CLI harness for the AKShare financial data library",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="cli-anything",
    license="MIT",
    python_requires=">=3.9",
    packages=find_packages(include=["akshare_cli", "akshare_cli.*"]),
    package_data={
        "akshare_cli": ["data/*.json"],
    },
    install_requires=[
        "akshare",
        "click>=8.0",
        "pandas>=2.0.0",
        "tabulate>=0.8.6",
        "openpyxl>=3.0.3",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-mock>=3.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "akshare-cli=akshare_cli.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Office/Business :: Financial",
    ],
)
