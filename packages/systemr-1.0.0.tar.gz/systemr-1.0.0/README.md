# systemr

Python SDK for [agents.systemr.ai](https://agents.systemr.ai) — AI-native risk intelligence for trading agents.

## Install

```bash
pip install systemr
```

## Quick Start

```python
from systemr import SystemRClient

client = SystemRClient(api_key="sr_agent_...")

# Position sizing ($0.003)
result = client.calculate_position_size(
    equity="100000",
    entry_price="185.50",
    stop_price="180.00",
    direction="long",
)
print(result["shares"], result["risk_amount"])

# Risk validation ($0.004)
risk = client.check_risk(
    symbol="AAPL",
    direction="long",
    entry_price="185.50",
    stop_price="180.00",
    quantity="100",
    equity="100000",
)
print(risk["approved"], risk["score"])

# Strategy evaluation ($0.10 - $1.00)
eval_result = client.basic_eval(r_multiples=["1.5", "-1.0", "2.3", "-0.5", "1.8"])
print(eval_result["g_score"], eval_result["verdict"])
```

## API Reference

### Agent Management
- `client.get_info()` — Get agent info
- `client.list_agents()` — List owner's agents
- `client.update_mode(mode)` — Change mode (sandbox/live/suspended/terminated)

### Position Sizing
- `client.calculate_position_size(equity, entry_price, stop_price, direction)` — G-formula sizing ($0.003)

### Risk Validation
- `client.check_risk(symbol, direction, entry_price, stop_price, quantity, equity)` — Iron Fist validation ($0.004)

### Evaluation
- `client.basic_eval(r_multiples)` — G metric + verdict ($0.10)
- `client.full_eval(r_multiples)` — G + rolling G + System R Score ($0.50)
- `client.comprehensive_eval(r_multiples)` — Full analysis + impact ($1.00)

### Billing
- `client.get_pricing()` — Operation prices (no auth)
- `client.get_balance()` — Current USDC balance
- `client.deposit(amount)` — Record deposit
- `client.get_transactions()` — Transaction history
- `client.get_usage()` — Usage summary

## Authentication

Register at [agents.systemr.ai](https://agents.systemr.ai) to get an API key. All paid operations are billed in USDC.

## License

MIT
