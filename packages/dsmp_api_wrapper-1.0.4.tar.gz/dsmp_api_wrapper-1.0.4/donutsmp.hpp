#pragma once

#include <string>
#include <vector>
#include <map>
#include <stdexcept>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

struct Trim {
    std::string material;
    std::string pattern;
};

struct Enchantments {
    std::map<std::string, int> levels;
};

struct ItemData {
    Enchantments enchantments;
    Trim trim;
};

struct ContainerItem {
    int count;
    std::string display_name;
    ItemData enchants;
    std::string id;
};

struct Item {
    std::vector<ContainerItem> contents;
    int count;
    std::string display_name;
    ItemData enchants;
    std::string id;
    std::vector<std::string> lore;
};

struct Seller {
    std::string name;
    std::string uuid;
};

struct AuctionEntry {
    Item item;
    double price;
    Seller seller;
    int time_left;
};

struct Transaction {
    Item item;
    double price;
    Seller seller;
    long long unix_millis_date_sold;
};

struct LeaderboardEntry {
    std::string username;
    std::string uuid;
    std::string value;
};

struct LookupResult {
    std::string location;
    std::string rank;
    std::string username;
};

struct PlayerStats {
    std::string broken_blocks;
    std::string deaths;
    std::string kills;
    std::string mobs_killed;
    std::string money;
    std::string money_made_from_sell;
    std::string money_spent_on_shop;
    std::string placed_blocks;
    std::string playtime;
    std::string shards;
};

inline Trim parse_trim(const json& j) {
    return { j.value("material", ""), j.value("pattern", "") };
}

inline Enchantments parse_enchantments(const json& j) {
    Enchantments e;
    if (j.contains("levels") && j["levels"].is_object())
        for (auto& [k, v] : j["levels"].items())
            e.levels[k] = v.get<int>();
    return e;
}

inline ItemData parse_item_data(const json& j) {
    ItemData d;
    if (j.contains("enchantments")) d.enchantments = parse_enchantments(j["enchantments"]);
    if (j.contains("trim"))         d.trim          = parse_trim(j["trim"]);
    return d;
}

inline ContainerItem parse_container_item(const json& j) {
    ContainerItem ci;
    ci.count        = j.value("count", 0);
    ci.display_name = j.value("display_name", "");
    ci.id           = j.value("id", "");
    if (j.contains("enchants")) ci.enchants = parse_item_data(j["enchants"]);
    return ci;
}

inline Item parse_item(const json& j) {
    Item item;
    item.count        = j.value("count", 0);
    item.display_name = j.value("display_name", "");
    item.id           = j.value("id", "");
    if (j.contains("enchants")) item.enchants = parse_item_data(j["enchants"]);
    if (j.contains("lore") && j["lore"].is_array())
        for (auto& l : j["lore"]) item.lore.push_back(l.get<std::string>());
    if (j.contains("contents") && j["contents"].is_array())
        for (auto& c : j["contents"]) item.contents.push_back(parse_container_item(c));
    return item;
}

inline Seller parse_seller(const json& j) {
    return { j.value("name", ""), j.value("uuid", "") };
}

class DonutSMPError : public std::runtime_error {
public:
    explicit DonutSMPError(const std::string& msg) : std::runtime_error(msg) {}
};

#ifdef _WIN32

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winhttp.h>
#pragma comment(lib, "winhttp.lib")

class HttpClient {
public:
    explicit HttpClient(const std::string& api_key) : api_key_(api_key) {
        session_ = WinHttpOpen(
            L"dsmp-api-wrapper/1.0",
            WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
            WINHTTP_NO_PROXY_NAME,
            WINHTTP_NO_PROXY_BYPASS,
            0
        );
        if (!session_) throw DonutSMPError("WinHttpOpen failed");

        connect_ = WinHttpConnect(session_, L"api.donutsmp.net", INTERNET_DEFAULT_HTTPS_PORT, 0);
        if (!connect_) {
            WinHttpCloseHandle(session_);
            throw DonutSMPError("WinHttpConnect failed");
        }
    }

    ~HttpClient() {
        if (connect_) WinHttpCloseHandle(connect_);
        if (session_) WinHttpCloseHandle(session_);
    }

    HttpClient(const HttpClient&) = delete;
    HttpClient& operator=(const HttpClient&) = delete;

    std::string get(const std::string& url, const std::string& body = "") {
        return request(L"GET", extract_path(url), body);
    }

    std::string put(const std::string& url, const std::string& body) {
        return request(L"PUT", extract_path(url), body);
    }

private:
    HINTERNET session_  = nullptr;
    HINTERNET connect_  = nullptr;
    std::string api_key_;

    static std::string extract_path(const std::string& url) {
        const std::string prefix = "https://api.donutsmp.net";
        if (url.substr(0, prefix.size()) == prefix)
            return url.substr(prefix.size());
        return url;
    }

    std::wstring to_wide(const std::string& s) {
        if (s.empty()) return {};
        int len = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
        std::wstring out(len, 0);
        MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), out.data(), len);
        return out;
    }

    std::string request(const wchar_t* method, const std::string& path, const std::string& body) {
        HINTERNET req = WinHttpOpenRequest(
            connect_,
            method,
            to_wide(path).c_str(),
            nullptr,
            WINHTTP_NO_REFERER,
            WINHTTP_DEFAULT_ACCEPT_TYPES,
            WINHTTP_FLAG_SECURE
        );
        if (!req) throw DonutSMPError("WinHttpOpenRequest failed");

        std::wstring headers = L"Authorization: Bearer " + to_wide(api_key_) +
                               L"\r\nContent-Type: application/json";
        WinHttpAddRequestHeaders(req, headers.c_str(), (DWORD)-1, WINHTTP_ADDREQ_FLAG_ADD);

        BOOL ok = WinHttpSendRequest(
            req,
            WINHTTP_NO_ADDITIONAL_HEADERS, 0,
            body.empty() ? WINHTTP_NO_REQUEST_DATA : (LPVOID)body.data(),
            (DWORD)body.size(),
            (DWORD)body.size(),
            0
        );

        if (!ok || !WinHttpReceiveResponse(req, nullptr)) {
            WinHttpCloseHandle(req);
            throw DonutSMPError("WinHttp request failed");
        }

        std::string response;
        DWORD available = 0;
        while (WinHttpQueryDataAvailable(req, &available) && available > 0) {
            std::string chunk(available, '\0');
            DWORD read = 0;
            WinHttpReadData(req, chunk.data(), available, &read);
            chunk.resize(read);
            response += chunk;
        }

        WinHttpCloseHandle(req);
        return check(response);
    }

    static std::string check(const std::string& body) {
        json j;
        try { j = json::parse(body); }
        catch (...) { throw DonutSMPError("Invalid JSON: " + body); }
        int status = j.value("status", 0);
        if (status == 401) throw DonutSMPError("Unauthorized: " + j.value("message", ""));
        if (status == 500) throw DonutSMPError("Server error: " + j.value("message", ""));
        return body;
    }
};

#else

#include <curl/curl.h>

class HttpClient {
public:
    explicit HttpClient(const std::string& api_key) : api_key_(api_key) {
        curl_global_init(CURL_GLOBAL_ALL);
        curl_ = curl_easy_init();
        if (!curl_) throw DonutSMPError("Failed to init libcurl");

        headers_ = curl_slist_append(nullptr, ("Authorization: Bearer " + api_key_).c_str());
        headers_ = curl_slist_append(headers_, "Content-Type: application/json");
        headers_ = curl_slist_append(headers_, "Connection: keep-alive");

        curl_easy_setopt(curl_, CURLOPT_HTTPHEADER,    headers_);
        curl_easy_setopt(curl_, CURLOPT_WRITEFUNCTION, write_cb);
        curl_easy_setopt(curl_, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl_, CURLOPT_TCP_KEEPALIVE,  1L);
        curl_easy_setopt(curl_, CURLOPT_TCP_KEEPIDLE,  30L);
        curl_easy_setopt(curl_, CURLOPT_TCP_KEEPINTVL, 10L);
        curl_easy_setopt(curl_, CURLOPT_BUFFERSIZE,    131072L);
        curl_easy_setopt(curl_, CURLOPT_TIMEOUT,       10L);
    }

    ~HttpClient() {
        curl_slist_free_all(headers_);
        curl_easy_cleanup(curl_);
        curl_global_cleanup();
    }

    HttpClient(const HttpClient&) = delete;
    HttpClient& operator=(const HttpClient&) = delete;

    std::string get(const std::string& url, const std::string& body = "") {
        std::string response;
        curl_easy_setopt(curl_, CURLOPT_URL,       url.c_str());
        curl_easy_setopt(curl_, CURLOPT_WRITEDATA, &response);
        if (!body.empty()) {
            curl_easy_setopt(curl_, CURLOPT_CUSTOMREQUEST, "GET");
            curl_easy_setopt(curl_, CURLOPT_POSTFIELDS,    body.c_str());
        } else {
            curl_easy_setopt(curl_, CURLOPT_HTTPGET,       1L);
            curl_easy_setopt(curl_, CURLOPT_CUSTOMREQUEST, nullptr);
            curl_easy_setopt(curl_, CURLOPT_POSTFIELDS,    nullptr);
        }
        CURLcode res = curl_easy_perform(curl_);
        if (res != CURLE_OK) throw DonutSMPError(std::string("curl: ") + curl_easy_strerror(res));
        return check(response);
    }

    std::string put(const std::string& url, const std::string& body) {
        std::string response;
        curl_easy_setopt(curl_, CURLOPT_URL,           url.c_str());
        curl_easy_setopt(curl_, CURLOPT_WRITEDATA,     &response);
        curl_easy_setopt(curl_, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl_, CURLOPT_POSTFIELDS,    body.c_str());
        CURLcode res = curl_easy_perform(curl_);
        if (res != CURLE_OK) throw DonutSMPError(std::string("curl: ") + curl_easy_strerror(res));
        return check(response);
    }

private:
    CURL*       curl_;
    curl_slist* headers_;
    std::string api_key_;

    static size_t write_cb(char* ptr, size_t size, size_t nmemb, std::string* out) {
        out->append(ptr, size * nmemb);
        return size * nmemb;
    }

    static std::string check(const std::string& body) {
        json j;
        try { j = json::parse(body); }
        catch (...) { throw DonutSMPError("Invalid JSON: " + body); }
        int status = j.value("status", 0);
        if (status == 401) throw DonutSMPError("Unauthorized: " + j.value("message", ""));
        if (status == 500) throw DonutSMPError("Server error: " + j.value("message", ""));
        return body;
    }
};

#endif

class DonutSMPClient {
public:
    static constexpr const char* BASE = "https://api.donutsmp.net";

    explicit DonutSMPClient(const std::string& api_key) : http_(api_key) {}

    std::vector<AuctionEntry> auction_list(int page = 1, const std::string& search = "", const std::string& sort = "") {
        std::string url = std::string(BASE) + "/v1/auction/list/" + std::to_string(page);
        std::string body;
        if (!search.empty() || !sort.empty()) {
            json b = json::object();
            if (!search.empty()) b["search"] = search;
            if (!sort.empty())   b["sort"]   = sort;
            body = b.dump();
        }
        auto r = json::parse(http_.get(url, body));
        std::vector<AuctionEntry> out;
        for (auto& e : r["result"])
            out.push_back({ parse_item(e["item"]), e.value("price", 0.0), parse_seller(e["seller"]), e.value("time_left", 0) });
        return out;
    }

    std::vector<Transaction> auction_transactions(int page = 1) {
        auto r = json::parse(http_.get(std::string(BASE) + "/v1/auction/transactions/" + std::to_string(page)));
        std::vector<Transaction> out;
        for (auto& e : r["result"])
            out.push_back({ parse_item(e["item"]), e.value("price", 0.0), parse_seller(e["seller"]), e.value("unixMillisDateSold", 0LL) });
        return out;
    }

    std::vector<LeaderboardEntry> leaderboard(const std::string& category, int page = 1) {
        auto r = json::parse(http_.get(std::string(BASE) + "/v1/leaderboards/" + category + "/" + std::to_string(page)));
        std::vector<LeaderboardEntry> out;
        for (auto& e : r["result"])
            out.push_back({ e.value("username", ""), e.value("uuid", ""), e.value("value", "") });
        return out;
    }

    std::vector<LeaderboardEntry> lb_broken_blocks(int page = 1) { return leaderboard("brokenblocks", page); }
    std::vector<LeaderboardEntry> lb_deaths(int page = 1)        { return leaderboard("deaths", page); }
    std::vector<LeaderboardEntry> lb_kills(int page = 1)         { return leaderboard("kills", page); }
    std::vector<LeaderboardEntry> lb_mobs_killed(int page = 1)   { return leaderboard("mobskilled", page); }
    std::vector<LeaderboardEntry> lb_money(int page = 1)         { return leaderboard("money", page); }
    std::vector<LeaderboardEntry> lb_placed_blocks(int page = 1) { return leaderboard("placedblocks", page); }
    std::vector<LeaderboardEntry> lb_playtime(int page = 1)      { return leaderboard("playtime", page); }
    std::vector<LeaderboardEntry> lb_sell(int page = 1)          { return leaderboard("sell", page); }
    std::vector<LeaderboardEntry> lb_shards(int page = 1)        { return leaderboard("shards", page); }
    std::vector<LeaderboardEntry> lb_shop(int page = 1)          { return leaderboard("shop", page); }

    LookupResult lookup(const std::string& username) {
        auto r = json::parse(http_.get(std::string(BASE) + "/v1/lookup/" + username));
        auto& res = r["result"];
        return { res.value("location", ""), res.value("rank", ""), res.value("username", "") };
    }

    PlayerStats stats(const std::string& username) {
        auto r = json::parse(http_.get(std::string(BASE) + "/v1/stats/" + username));
        auto& res = r["result"];
        return {
            res.value("broken_blocks", ""),
            res.value("deaths", ""),
            res.value("kills", ""),
            res.value("mobs_killed", ""),
            res.value("money", ""),
            res.value("money_made_from_sell", ""),
            res.value("money_spent_on_shop", ""),
            res.value("placed_blocks", ""),
            res.value("playtime", ""),
            res.value("shards", ""),
        };
    }

private:
    HttpClient http_;
};