# dsmp-api-wrapper

DonutSMP Public API wrapper with a C++ backend (libcurl + nlohmann/json) exposed to Python via pybind11. Uses persistent keep-alive connections for fast repeated polling.

## Requirements

- Python 3.8+
- CMake 3.14+
- libcurl (`apt install libcurl4-openssl-dev`)
- nlohmann-json (`apt install nlohmann-json3-dev`)

## Installation

```bash
pip install dsmp-api-wrapper
```

## Usage

```python
from dsmp_api_wrapper import Client

client = Client("your-api-key")

stats  = client.stats("SomePlayer")
lookup = client.lookup("SomePlayer")
top    = client.lb_kills()
auctions = client.auction_list(search="diamond", sort="lowest_price")
```
