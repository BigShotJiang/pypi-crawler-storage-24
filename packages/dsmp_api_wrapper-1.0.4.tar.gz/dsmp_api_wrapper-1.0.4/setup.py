from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext
import subprocess
import os
import sys
import shutil
import pybind11
import nlohmann_json


class CMakeBuild(build_ext):
    def build_extension(self, ext):
        build_dir = os.path.abspath(self.build_temp)
        os.makedirs(build_dir, exist_ok=True)

        source_dir = os.path.abspath(os.path.dirname(__file__))
        nlohmann_include = os.path.join(os.path.dirname(nlohmann_json.__file__), "include")

        cmake_args = [
            f"-DCMAKE_BUILD_TYPE=Release",
            f"-Dpybind11_DIR={pybind11.get_cmake_dir()}",
            f"-DNLOHMANN_INCLUDE={nlohmann_include}",
            f"-DPYTHON_EXECUTABLE={sys.executable}",
        ]

        if sys.platform == "win32":
            build_args = ["--build", build_dir, "--config", "Release", "--", "/m"]
        else:
            build_args = ["--build", build_dir, "--config", "Release", "--", f"-j{os.cpu_count() or 2}"]

        subprocess.check_call(["cmake", source_dir] + cmake_args, cwd=build_dir)
        subprocess.check_call(["cmake"] + build_args)

        found = None
        for root, _, files in os.walk(build_dir):
            for f in files:
                if f.startswith("dsmp_api_wrapper") and (f.endswith(".so") or f.endswith(".pyd")):
                    found = os.path.join(root, f)
                    break

        if not found:
            raise RuntimeError("Build produced no .so/.pyd — check CMake output above")

        ext_dest = os.path.abspath(self.get_ext_fullpath(ext.name))
        os.makedirs(os.path.dirname(ext_dest), exist_ok=True)
        shutil.copy(found, ext_dest)


setup(
    name="dsmp-api-wrapper",
    version="1.0.4",
    description="DonutSMP Public API wrapper (C++ backend)",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
    install_requires=["pybind11>=2.10"],
    ext_modules=[Extension("dsmp_api_wrapper", sources=[])],
    cmdclass={"build_ext": CMakeBuild},
    zip_safe=False,
)