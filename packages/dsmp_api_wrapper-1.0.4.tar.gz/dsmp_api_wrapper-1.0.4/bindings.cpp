#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "donutsmp.hpp"

namespace py = pybind11;

PYBIND11_MODULE(dsmp_api_wrapper, m) {
    m.doc() = "DonutSMP API wrapper (C++ backend)";

    py::register_exception<DonutSMPError>(m, "DonutSMPError");

    py::class_<Trim>(m, "Trim")
        .def(py::init<>())
        .def_readwrite("material", &Trim::material)
        .def_readwrite("pattern",  &Trim::pattern)
        .def("__repr__", [](const Trim& t){
            return "<Trim material=" + t.material + " pattern=" + t.pattern + ">";
        });

    py::class_<Enchantments>(m, "Enchantments")
        .def(py::init<>())
        .def_readwrite("levels", &Enchantments::levels)
        .def("__repr__", [](const Enchantments& e){
            std::string s = "<Enchantments {";
            for (auto& [k,v] : e.levels) s += k + ":" + std::to_string(v) + " ";
            return s + "}>";
        });

    py::class_<ItemData>(m, "ItemData")
        .def(py::init<>())
        .def_readwrite("enchantments", &ItemData::enchantments)
        .def_readwrite("trim",         &ItemData::trim);

    py::class_<ContainerItem>(m, "ContainerItem")
        .def(py::init<>())
        .def_readwrite("count",        &ContainerItem::count)
        .def_readwrite("display_name", &ContainerItem::display_name)
        .def_readwrite("enchants",     &ContainerItem::enchants)
        .def_readwrite("id",           &ContainerItem::id)
        .def("__repr__", [](const ContainerItem& c){
            return "<ContainerItem id=" + c.id + " display_name=" + c.display_name + " count=" + std::to_string(c.count) + ">";
        });

    py::class_<Item>(m, "Item")
        .def(py::init<>())
        .def_readwrite("contents",     &Item::contents)
        .def_readwrite("count",        &Item::count)
        .def_readwrite("display_name", &Item::display_name)
        .def_readwrite("enchants",     &Item::enchants)
        .def_readwrite("id",           &Item::id)
        .def_readwrite("lore",         &Item::lore)
        .def("__repr__", [](const Item& i){
            return "<Item id=" + i.id + " display_name=" + i.display_name + " count=" + std::to_string(i.count) + ">";
        });

    py::class_<Seller>(m, "Seller")
        .def(py::init<>())
        .def_readwrite("name", &Seller::name)
        .def_readwrite("uuid", &Seller::uuid)
        .def("__repr__", [](const Seller& s){
            return "<Seller name=" + s.name + " uuid=" + s.uuid + ">";
        });

    py::class_<AuctionEntry>(m, "AuctionEntry")
        .def(py::init<>())
        .def_readwrite("item",      &AuctionEntry::item)
        .def_readwrite("price",     &AuctionEntry::price)
        .def_readwrite("seller",    &AuctionEntry::seller)
        .def_readwrite("time_left", &AuctionEntry::time_left)
        .def("__repr__", [](const AuctionEntry& a){
            return "<AuctionEntry item=" + a.item.display_name + " price=" + std::to_string(a.price) + " seller=" + a.seller.name + ">";
        });

    py::class_<Transaction>(m, "Transaction")
        .def(py::init<>())
        .def_readwrite("item",                  &Transaction::item)
        .def_readwrite("price",                 &Transaction::price)
        .def_readwrite("seller",                &Transaction::seller)
        .def_readwrite("unix_millis_date_sold", &Transaction::unix_millis_date_sold)
        .def("__repr__", [](const Transaction& t){
            return "<Transaction item=" + t.item.display_name + " price=" + std::to_string(t.price) + ">";
        });

    py::class_<LeaderboardEntry>(m, "LeaderboardEntry")
        .def(py::init<>())
        .def_readwrite("username", &LeaderboardEntry::username)
        .def_readwrite("uuid",     &LeaderboardEntry::uuid)
        .def_readwrite("value",    &LeaderboardEntry::value)
        .def("__repr__", [](const LeaderboardEntry& e){
            return "<LeaderboardEntry username=" + e.username + " value=" + e.value + ">";
        });

    py::class_<LookupResult>(m, "LookupResult")
        .def(py::init<>())
        .def_readwrite("location", &LookupResult::location)
        .def_readwrite("rank",     &LookupResult::rank)
        .def_readwrite("username", &LookupResult::username)
        .def("__repr__", [](const LookupResult& r){
            return "<LookupResult username=" + r.username + " rank=" + r.rank + " location=" + r.location + ">";
        });

    py::class_<PlayerStats>(m, "PlayerStats")
        .def(py::init<>())
        .def_readwrite("broken_blocks",        &PlayerStats::broken_blocks)
        .def_readwrite("deaths",               &PlayerStats::deaths)
        .def_readwrite("kills",                &PlayerStats::kills)
        .def_readwrite("mobs_killed",          &PlayerStats::mobs_killed)
        .def_readwrite("money",                &PlayerStats::money)
        .def_readwrite("money_made_from_sell", &PlayerStats::money_made_from_sell)
        .def_readwrite("money_spent_on_shop",  &PlayerStats::money_spent_on_shop)
        .def_readwrite("placed_blocks",        &PlayerStats::placed_blocks)
        .def_readwrite("playtime",             &PlayerStats::playtime)
        .def_readwrite("shards",               &PlayerStats::shards)
        .def("__repr__", [](const PlayerStats& s){
            return "<PlayerStats kills=" + s.kills + " deaths=" + s.deaths + " money=" + s.money + ">";
        });

    py::class_<DonutSMPClient>(m, "Client")
        .def(py::init<const std::string&>(), py::arg("api_key"))

        .def("auction_list",         &DonutSMPClient::auction_list,
             py::arg("page")=1, py::arg("search")="", py::arg("sort")="")
        .def("auction_transactions", &DonutSMPClient::auction_transactions, py::arg("page")=1)

        .def("leaderboard",      &DonutSMPClient::leaderboard, py::arg("category"), py::arg("page")=1)
        .def("lb_broken_blocks", &DonutSMPClient::lb_broken_blocks, py::arg("page")=1)
        .def("lb_deaths",        &DonutSMPClient::lb_deaths,        py::arg("page")=1)
        .def("lb_kills",         &DonutSMPClient::lb_kills,         py::arg("page")=1)
        .def("lb_mobs_killed",   &DonutSMPClient::lb_mobs_killed,   py::arg("page")=1)
        .def("lb_money",         &DonutSMPClient::lb_money,         py::arg("page")=1)
        .def("lb_placed_blocks", &DonutSMPClient::lb_placed_blocks, py::arg("page")=1)
        .def("lb_playtime",      &DonutSMPClient::lb_playtime,      py::arg("page")=1)
        .def("lb_sell",          &DonutSMPClient::lb_sell,          py::arg("page")=1)
        .def("lb_shards",        &DonutSMPClient::lb_shards,        py::arg("page")=1)
        .def("lb_shop",          &DonutSMPClient::lb_shop,          py::arg("page")=1)

        .def("lookup", &DonutSMPClient::lookup, py::arg("username"))
        .def("stats",  &DonutSMPClient::stats,  py::arg("username"));
}
