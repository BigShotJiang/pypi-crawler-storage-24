"""Tests for the configuration system."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from openclose.config.config import load_config, ConfigManager
from openclose.config.paths import ConfigPaths
from openclose.config.schema import OpenCloseConfig


def test_load_defaults(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Loading config with no files should return defaults."""
    # Point user config dir to empty location so real config isn't picked up
    monkeypatch.setattr(ConfigPaths, "user_config_path", classmethod(lambda cls: tmp_path / "nonexistent" / "config.toml"))  # type: ignore[arg-type]
    cfg = load_config()
    assert isinstance(cfg, OpenCloseConfig)
    assert cfg.default_agent == "build"
    assert len(cfg.providers) == 1
    assert cfg.providers[0].name == "default"


def test_load_with_project_dir(tmp_path: Path) -> None:
    """Config should pick up project_dir."""
    cfg = load_config(project_dir=tmp_path)
    assert cfg.project_dir == str(tmp_path)


def test_load_toml_config(tmp_path: Path) -> None:
    """Config should load from a TOML file."""
    config_dir = tmp_path / ".openclose"
    config_dir.mkdir()
    config_file = config_dir / "config.toml"
    config_file.write_text(
        'default_agent = "plan"\n'
    )
    cfg = load_config(project_dir=tmp_path)
    assert isinstance(cfg, OpenCloseConfig)
    assert cfg.default_agent == "plan"


def test_env_overrides(tmp_path: Path, monkeypatch: object) -> None:
    """Environment variables should override config."""
    os.environ["OPENCLOSE_DEFAULT_AGENT"] = "plan"
    try:
        cfg = load_config(project_dir=tmp_path)
        assert cfg.default_agent == "plan"
    finally:
        del os.environ["OPENCLOSE_DEFAULT_AGENT"]


def test_config_manager_reload(tmp_path: Path) -> None:
    """ConfigManager should support reload."""
    mgr = ConfigManager(project_dir=tmp_path)
    cfg1 = mgr.config
    cfg2 = mgr.reload()
    assert cfg1.default_agent == cfg2.default_agent


def test_config_paths() -> None:
    """ConfigPaths should return Path objects."""
    assert isinstance(ConfigPaths.config_dir(), Path)
    assert isinstance(ConfigPaths.data_dir(), Path)
    assert isinstance(ConfigPaths.cache_dir(), Path)
    assert isinstance(ConfigPaths.db_path(), Path)
    assert ConfigPaths.db_path().name == "openclose.db"
