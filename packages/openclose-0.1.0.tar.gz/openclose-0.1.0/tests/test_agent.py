"""Tests for the agent system."""

from __future__ import annotations

from pathlib import Path

import pytest

from openclose.agent.agent import Agent, AgentMode, get_agent, list_agents
from openclose.agent.prompt import build_system_prompt
from openclose.config.agents import (
    _resolve_extends,
    load_agents,
    reload_agents,
    render_prompt_template,
)


# ── Basic Agent dataclass ────────────────────────────────────────────


def test_builtin_build_agent() -> None:
    """Build agent should exist and have full access."""
    agent = get_agent("build")
    assert agent.name == "build"
    assert agent.mode == AgentMode.PRIMARY
    assert agent.can_use_tool("bash")
    assert agent.can_use_tool("write")
    assert agent.can_use_tool("read")


def test_builtin_plan_agent() -> None:
    """Plan agent should deny write tools."""
    agent = get_agent("plan")
    assert agent.name == "plan"
    assert not agent.can_use_tool("write")
    assert not agent.can_use_tool("edit")
    assert not agent.can_use_tool("bash")
    assert agent.can_use_tool("read")
    assert agent.can_use_tool("grep")
    assert agent.can_use_tool("glob")


def test_builtin_plan_agent_has_readonly_trait() -> None:
    """Plan agent should have the 'readonly' trait."""
    agent = get_agent("plan")
    assert agent.has_trait("readonly")
    assert not agent.has_trait("nonexistent")


def test_unknown_agent_raises() -> None:
    """Unknown agent should raise ValueError."""
    with pytest.raises(ValueError, match="Unknown agent"):
        get_agent("nonexistent")


def test_list_agents() -> None:
    """Should list at least the built-in agents."""
    agents = list_agents()
    names = [a.name for a in agents]
    assert "build" in names
    assert "plan" in names


def test_agent_can_use_tool_allowed_list() -> None:
    """Agent with allowed_tools should only allow those tools."""
    agent = Agent(name="restricted", allowed_tools=["read", "grep"])
    assert agent.can_use_tool("read")
    assert agent.can_use_tool("grep")
    assert not agent.can_use_tool("bash")


def test_agent_can_use_tool_denied_list() -> None:
    """Agent with denied_tools should deny those tools."""
    agent = Agent(name="partial", denied_tools=["bash"])
    assert not agent.can_use_tool("bash")
    assert agent.can_use_tool("read")


# ── Traits ───────────────────────────────────────────────────────────


def test_agent_has_trait() -> None:
    agent = Agent(name="x", traits=["readonly", "strict"])
    assert agent.has_trait("readonly")
    assert agent.has_trait("strict")
    assert not agent.has_trait("other")


# ── Tool schema filtering ───────────────────────────────────────────


def _make_schema(name: str) -> dict[str, object]:
    return {
        "type": "function",
        "function": {"name": name, "description": f"Tool {name}", "parameters": {}},
    }


def test_filter_tool_schemas_no_restrictions() -> None:
    """Agent with no restrictions sees all tools."""
    agent = Agent(name="build")
    schemas = [_make_schema("read"), _make_schema("write"), _make_schema("bash")]
    filtered = agent.filter_tool_schemas(schemas)
    assert len(filtered) == 3


def test_filter_tool_schemas_denied() -> None:
    """Agent with denied_tools should not see those schemas."""
    agent = Agent(name="plan", denied_tools=["write", "bash"])
    schemas = [_make_schema("read"), _make_schema("write"), _make_schema("bash")]
    filtered = agent.filter_tool_schemas(schemas)
    assert len(filtered) == 1
    assert filtered[0]["function"]["name"] == "read"  # type: ignore[index]


def test_filter_tool_schemas_allowed() -> None:
    """Agent with allowed_tools should only see those schemas."""
    agent = Agent(name="narrow", allowed_tools=["read", "grep"])
    schemas = [_make_schema("read"), _make_schema("write"), _make_schema("grep")]
    filtered = agent.filter_tool_schemas(schemas)
    names = [s["function"]["name"] for s in filtered]  # type: ignore[index]
    assert names == ["read", "grep"]


# ── Prompt building ──────────────────────────────────────────────────


def test_build_system_prompt() -> None:
    """System prompt should include context information."""
    agent = get_agent("build")
    prompt = build_system_prompt(agent, project_dir="/tmp/test")
    assert "/tmp/test" in prompt


def test_plan_system_prompt_uses_trait() -> None:
    """Plan agent prompt should include read-only restriction via trait."""
    agent = get_agent("plan")
    prompt = build_system_prompt(agent)
    assert "read-only" in prompt.lower()


def test_system_prompt_includes_tool_names() -> None:
    """When tool_names are passed, they appear in the prompt."""
    agent = Agent(name="test")
    prompt = build_system_prompt(agent, tool_names=["read", "grep", "bash"])
    assert "Available tools: read, grep, bash" in prompt


def test_system_prompt_no_tool_names() -> None:
    """When no tool_names are passed, no tools line appears."""
    agent = Agent(name="test")
    prompt = build_system_prompt(agent)
    assert "Available tools:" not in prompt


# ── Prompt template rendering ────────────────────────────────────────


def test_render_prompt_template_basic() -> None:
    result = render_prompt_template(
        "Working in $project_dir on $date",
        {"project_dir": "/code", "date": "2026-03-18"},
    )
    assert result == "Working in /code on 2026-03-18"


def test_render_prompt_template_unknown_var() -> None:
    """Unknown variables are left as-is (safe_substitute)."""
    result = render_prompt_template("Hello $unknown", {})
    assert result == "Hello $unknown"


def test_render_prompt_template_empty() -> None:
    assert render_prompt_template("", {}) == ""
    assert render_prompt_template("no vars", {}) == "no vars"


# ── Inheritance resolution ───────────────────────────────────────────


def test_resolve_extends_simple() -> None:
    agents_raw = {
        "base": {"name": "base", "model": "gpt-4", "temperature": 0.5},
        "child": {"name": "child", "extends": "base", "temperature": 0.9},
    }
    cache: dict[str, dict[str, object]] = {}
    result = _resolve_extends("child", agents_raw, cache)
    assert result["model"] == "gpt-4"  # inherited
    assert result["temperature"] == 0.9  # overridden


def test_resolve_extends_chain() -> None:
    agents_raw = {
        "a": {"name": "a", "model": "m1", "max_steps": 200},
        "b": {"name": "b", "extends": "a", "max_steps": 50},
        "c": {"name": "c", "extends": "b", "description": "leaf"},
    }
    cache: dict[str, dict[str, object]] = {}
    result = _resolve_extends("c", agents_raw, cache)
    assert result["model"] == "m1"  # from a
    assert result["max_steps"] == 50  # from b
    assert result["description"] == "leaf"  # from c


def test_resolve_extends_missing_parent() -> None:
    agents_raw = {"child": {"name": "child", "extends": "nope"}}
    cache: dict[str, dict[str, object]] = {}
    with pytest.raises(ValueError, match="does not exist"):
        _resolve_extends("child", agents_raw, cache)


# ── Config-based agent loading ───────────────────────────────────────


def test_load_agents_defaults() -> None:
    """When no agents are configured, built-in defaults should load."""
    agents = load_agents()
    assert "build" in agents
    assert "plan" in agents
    assert agents["plan"].denied_tools == ["write", "edit", "bash", "patch"]
    assert "readonly" in agents["plan"].traits


def test_load_agents_from_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """[[agents]] in config.toml should override defaults."""
    from openclose.config import config as config_mod
    from openclose.config import agents as agents_mod
    from openclose.config.schema import OpenCloseConfig, AgentConfig

    # Create a config with custom agents
    custom_config = OpenCloseConfig(
        agents=[
            AgentConfig(
                name="build",
                description="Custom build",
                model="my-model",
                temperature=0.7,
            ),
            AgentConfig(
                name="reviewer",
                description="Code reviewer",
                mode="primary",
                allowed_tools=["read", "grep"],
            ),
        ]
    )

    # Inject the custom config
    monkeypatch.setattr(config_mod, "_config", custom_config)
    agents_mod._agents_cache = None

    try:
        agents = load_agents()
        assert agents["build"].description == "Custom build"
        assert agents["build"].model == "my-model"
        assert agents["build"].temperature == 0.7
        assert "reviewer" in agents
        assert agents["reviewer"].allowed_tools == ["read", "grep"]
    finally:
        agents_mod._agents_cache = None
        config_mod._config = None


def test_load_agents_inheritance(monkeypatch: pytest.MonkeyPatch) -> None:
    """extends should inherit fields from parent via config."""
    from openclose.config import config as config_mod
    from openclose.config import agents as agents_mod
    from openclose.config.schema import OpenCloseConfig, AgentConfig

    custom_config = OpenCloseConfig(
        agents=[
            AgentConfig(
                name="base",
                description="Base agent",
                model="my-model",
                max_steps=200,
            ),
            AgentConfig(
                name="child",
                extends="base",
                description="Child agent",
                max_steps=50,
            ),
        ]
    )

    monkeypatch.setattr(config_mod, "_config", custom_config)
    agents_mod._agents_cache = None

    try:
        agents = load_agents()
        assert agents["child"].model == "my-model"  # inherited
        assert agents["child"].max_steps == 50  # overridden
        assert agents["child"].description == "Child agent"
    finally:
        agents_mod._agents_cache = None
        config_mod._config = None
