"""System prompt assembly for agents.

Builds the full system prompt from the agent's configured prompt,
appends contextual information (working dir, date, available tools),
and applies trait-based additions.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING

from openclose.config.agents import render_prompt_template

if TYPE_CHECKING:
    from openclose.agent.agent import Agent


_BASE_SYSTEM_PROMPT = """\
You are an AI coding assistant. You help users with software engineering tasks \
including writing code, debugging, refactoring, and explaining code.

You have access to tools that let you read, write, and search files, execute \
shell commands, and more. Use these tools to accomplish the user's requests.

Guidelines:
- Read files before modifying them to understand existing code.
- Make minimal, focused changes. Don't over-engineer.
- Write safe, correct code. Avoid introducing security vulnerabilities.
- Use the appropriate tool for each task.
- When uncertain, ask the user for clarification.
"""

_READONLY_TRAIT_PROMPT = """
You are in read-only mode. You CANNOT modify files, execute shell commands, \
or make any changes. You can only read files, search code, and provide \
analysis and recommendations.
"""


def build_system_prompt(
    agent: "Agent",
    project_dir: str = ".",
    extra_context: str = "",
    tool_names: list[str] | None = None,
) -> str:
    """Build the full system prompt for an agent.

    Parameters
    ----------
    agent:
        The agent definition (carries a ``system_prompt`` from config).
    project_dir:
        Working directory injected into the prompt.
    extra_context:
        Optional additional context (e.g. for multi-agent scenarios).
    tool_names:
        List of tool names the agent actually has access to.  When
        provided, these are listed in the prompt so the LLM knows
        exactly what it can call.
    """
    parts: list[str] = []

    # ── Core prompt ──────────────────────────────────────────────
    if agent.system_prompt:
        parts.append(agent.system_prompt)
    else:
        parts.append(_BASE_SYSTEM_PROMPT)

    # ── Trait-based additions ────────────────────────────────────
    if agent.has_trait("readonly"):
        parts.append(_READONLY_TRAIT_PROMPT)

    # ── Available tools ──────────────────────────────────────────
    if tool_names:
        parts.append(f"Available tools: {', '.join(tool_names)}")

    # ── Context ──────────────────────────────────────────────────
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    parts.append(f"\nWorking directory: {project_dir}")
    parts.append(f"Current date: {date_str}")

    if extra_context:
        parts.append(f"\n{extra_context}")

    # ── Template variable substitution ───────────────────────────
    prompt = "\n".join(parts)
    prompt = render_prompt_template(
        prompt,
        {
            "project_dir": project_dir,
            "date": date_str,
            "agent_name": agent.name,
            "agent_description": agent.description,
            "tool_names": ", ".join(tool_names) if tool_names else "",
        },
    )

    return prompt
