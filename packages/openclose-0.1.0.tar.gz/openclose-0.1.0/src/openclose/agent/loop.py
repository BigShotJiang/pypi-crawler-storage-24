"""Main agent loop — streaming LLM interaction with tool calling."""

from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator, Callable, Awaitable

from openai.types.chat import ChatCompletionMessageParam

from openclose.agent.agent import Agent
from openclose.agent.prompt import build_system_prompt
from openclose.id import generate_id
from openclose.permission.permission import PermissionEngine
from openclose.permission.broker import PermissionBroker
from openclose.permission.schema import PermissionRequest
from openclose.permission.extract import extract_path, check_path_sandbox
from openclose.tool.tools.bash import _check_command
from openclose.tool.tools.question_broker import QuestionBroker
from openclose.provider.provider import Provider
from openclose.log import get_logger

log = get_logger(__name__)


class ToolCall:
    """Represents a tool call extracted from a streaming response."""

    def __init__(self) -> None:
        self.id: str = ""
        self.name: str = ""
        self._arguments: str = ""

    def append_arguments(self, chunk: str) -> None:
        self._arguments += chunk

    @property
    def arguments(self) -> dict[str, Any]:
        try:
            result = json.loads(self._arguments) if self._arguments else {}
            if isinstance(result, dict):
                return result
            return {}
        except json.JSONDecodeError:
            log.warning("Failed to parse tool arguments: %s", self._arguments)
            return {}

    @property
    def arguments_raw(self) -> str:
        return self._arguments


class StreamEvent:
    """An event from the agent loop stream."""

    def __init__(
        self,
        event_type: str,
        content: str = "",
        tool_call: ToolCall | None = None,
        tool_result: str = "",
        done: bool = False,
        error: str = "",
        context_info: dict[str, Any] | None = None,
    ) -> None:
        self.type = event_type
        self.content = content
        self.tool_call = tool_call
        self.tool_result = tool_result
        self.done = done
        self.error = error
        self.context_info = context_info


ToolExecutor = Callable[[str, dict[str, Any]], Awaitable[str]]


class AgentLoop:
    """Orchestrates the agent loop: prompt -> LLM -> tool calls -> repeat."""

    def __init__(
        self,
        agent: Agent,
        provider: Provider,
        tool_executor: ToolExecutor | None = None,
        tool_schemas: list[dict[str, Any]] | None = None,
        project_dir: str = ".",
        permission_engine: PermissionEngine | None = None,
        permission_broker: PermissionBroker | None = None,
        question_broker: QuestionBroker | None = None,
        session_id: str = "",
        cancel_event: asyncio.Event | None = None,
    ) -> None:
        self._agent = agent
        self._provider = provider
        self._tool_executor = tool_executor
        self._project_dir = project_dir
        self._permission_engine = permission_engine
        self._permission_broker = permission_broker
        self._question_broker = question_broker
        self._session_id = session_id
        self._cancel_event = cancel_event
        self._messages: list[dict[str, Any]] = []
        self._step = 0
        self._recent_calls: list[tuple[str, str]] = []  # doom-loop detection

        # Filter tool schemas so the LLM only sees tools this agent can use
        all_schemas = tool_schemas or []
        self._tool_schemas = agent.filter_tool_schemas(all_schemas)
        self._tool_names = [
            s["function"]["name"]  # type: ignore[index]
            for s in self._tool_schemas
            if isinstance(s.get("function"), dict)
        ]

    @property
    def messages(self) -> list[dict[str, Any]]:
        return self._messages

    @messages.setter
    def messages(self, value: list[dict[str, Any]]) -> None:
        self._messages = value

    def _system_message(self) -> dict[str, str]:
        content = build_system_prompt(
            self._agent,
            self._project_dir,
            tool_names=self._tool_names,
        )
        return {"role": "system", "content": content}

    def _build_full_messages(self) -> list[ChatCompletionMessageParam]:
        """Build the full message list for the LLM, including system prompt."""
        all_msgs: list[dict[str, Any]] = [self._system_message(), *self._messages]
        # Cast to the expected type — the dicts match the OpenAI schema
        return all_msgs  # type: ignore[return-value]

    async def run(self, user_message: str) -> AsyncIterator[StreamEvent]:
        """Run the agent loop for a user message, yielding stream events."""
        # Auto-detect model if not set
        if not self._agent.model:
            detected = await self._provider.detect_model()
            if detected:
                self._agent.model = detected
            else:
                yield StreamEvent("error", error="No model configured and auto-detection failed. Set default_model in config.toml")
                return

        self._messages.append({"role": "user", "content": user_message})

        while self._step < self._agent.max_steps:
            if self._cancel_event and self._cancel_event.is_set():
                log.info("Agent loop cancelled before step %d", self._step + 1)
                yield StreamEvent("done", done=True)
                return
            self._step += 1
            log.debug("Agent loop step %d/%d", self._step, self._agent.max_steps)

            full_messages = self._build_full_messages()
            tools = self._tool_schemas if self._tool_schemas else None

            # Stream from LLM
            text_content = ""
            tool_calls: dict[int, ToolCall] = {}
            has_tool_calls = False

            try:
                async for chunk in self._provider.chat(
                    messages=full_messages,
                    model=self._agent.model,
                    tools=tools,
                    temperature=self._agent.temperature,
                ):
                    for choice in chunk.choices:
                        delta = choice.delta
                        if delta.content:
                            text_content += delta.content
                            yield StreamEvent("text", content=delta.content)

                        if delta.tool_calls:
                            has_tool_calls = True
                            for tc_delta in delta.tool_calls:
                                idx = tc_delta.index
                                if idx not in tool_calls:
                                    tool_calls[idx] = ToolCall()
                                if tc_delta.id:
                                    tool_calls[idx].id = tc_delta.id
                                if tc_delta.function and tc_delta.function.name:
                                    tool_calls[idx].name = tc_delta.function.name
                                if tc_delta.function and tc_delta.function.arguments:
                                    tool_calls[idx].append_arguments(
                                        tc_delta.function.arguments
                                    )

                    if self._cancel_event and self._cancel_event.is_set():
                        log.info("Agent loop cancelled during LLM streaming")
                        break

            except Exception as e:
                log.error("LLM error: %s", e)
                yield StreamEvent("error", error=str(e))
                return

            # Check cancellation after streaming
            if self._cancel_event and self._cancel_event.is_set():
                if text_content:
                    self._messages.append(
                        {"role": "assistant", "content": text_content}
                    )
                yield StreamEvent("done", done=True)
                return

            # Add assistant message (no tool calls)
            if text_content and not has_tool_calls:
                self._messages.append(
                    {"role": "assistant", "content": text_content}
                )
                yield StreamEvent("done", done=True)
                return

            if has_tool_calls:
                # Build assistant message with tool calls
                tc_list: list[dict[str, Any]] = []
                for _idx, tc in sorted(tool_calls.items()):
                    tc_list.append(
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {
                                "name": tc.name,
                                "arguments": tc.arguments_raw,
                            },
                        }
                    )

                self._messages.append(
                    {
                        "role": "assistant",
                        "content": text_content or None,
                        "tool_calls": tc_list,
                    }
                )

                # Two-phase execution: permission checks then parallel execution
                sorted_tcs = sorted(tool_calls.items())

                # First, yield all tool_call events
                for _idx, tc in sorted_tcs:
                    yield StreamEvent("tool_call", tool_call=tc)

                # Phase A: Sequential permission checks
                approved: list[tuple[int, ToolCall]] = []
                denied_results: list[tuple[ToolCall, str]] = []

                for idx, tc in sorted_tcs:
                    # 1. Agent-level check
                    if not self._agent.can_use_tool(tc.name):
                        result = (
                            f"Error: Agent '{self._agent.name}' is not "
                            f"allowed to use tool '{tc.name}'"
                        )
                        log.warning(result)
                        denied_results.append((tc, result))
                        continue

                    # 2. Pre-permission safety checks (before dialog)
                    # 2a. Path sandbox — block writes outside project dir
                    sandbox_err = check_path_sandbox(
                        tc.name, tc.arguments, self._project_dir,
                    )
                    if sandbox_err is not None:
                        denied_results.append(
                            (tc, f"Error: {sandbox_err}. "
                             f"Do NOT retry with the same path. "
                             f"Inform the user and suggest alternatives.")
                        )
                        continue

                    # 2b. Bash heuristics — block dangerous commands
                    if tc.name == "bash":
                        cmd = tc.arguments.get("command")
                        if isinstance(cmd, str):
                            blocked = _check_command(cmd)
                            if blocked is not None:
                                denied_results.append(
                                    (tc, f"Error: Blocked: {blocked}. "
                                     f"Do NOT retry this command. "
                                     f"Inform the user and suggest alternatives.")
                                )
                                continue

                    # 3. Permission engine check (skip for question tool —
                    #    it has its own user interaction via question_request)
                    if self._permission_engine is not None and tc.name != "question":
                        path = extract_path(tc.name, tc.arguments, self._project_dir)
                        perm_req = PermissionRequest(
                            tool_name=tc.name,
                            path=path,
                            arguments=tc.arguments,
                        )
                        perm_resp = self._permission_engine.check(perm_req)

                        if not perm_resp.allowed and not perm_resp.needs_ask:
                            # DENY — absolute block
                            denied_results.append(
                                (tc, f"Error: {perm_resp.reason}. "
                                 f"This tool is permanently blocked by a DENY rule. "
                                 f"Do NOT retry. Inform the user and suggest alternatives.")
                            )
                            continue

                        if perm_resp.needs_ask:
                            # ASK — need user approval
                            if self._permission_broker is not None:
                                # Stamp ID before emitting so frontend gets it
                                perm_req.request_id = generate_id()
                                # Emit permission_request event for frontend
                                perm_content = json.dumps({
                                    "request_id": perm_req.request_id,
                                    "tool_name": tc.name,
                                    "path": path,
                                    "tool_args": tc.arguments,
                                })
                                yield StreamEvent("permission_request", content=perm_content)

                                reply = await self._permission_broker.ask(
                                    perm_req, session_id=self._session_id,
                                )
                                if reply == "reject":
                                    denied_results.append(
                                        (tc, f"Error: The user has REJECTED permission to use the '{tc.name}' tool. "
                                         f"Do NOT retry this tool call. Inform the user that the action was "
                                         f"blocked and ask how they would like to proceed.")
                                    )
                                    continue
                                if reply == "always":
                                    self._permission_engine.grant_session(tc.name)
                            else:
                                # No broker — deny with reason
                                denied_results.append(
                                    (tc, f"Error: {perm_resp.reason}. "
                                     f"No approval mechanism available. Do NOT retry. "
                                     f"Inform the user and suggest alternatives.")
                                )
                                continue

                    approved.append((idx, tc))

                # Doom-loop detection: check if last 3 calls are identical
                for _, tc in approved:
                    call_sig = (tc.name, tc.arguments_raw)
                    self._recent_calls.append(call_sig)
                    if len(self._recent_calls) > 3:
                        self._recent_calls = self._recent_calls[-3:]

                if len(self._recent_calls) >= 3:
                    last_three = self._recent_calls[-3:]
                    if last_three[0] == last_three[1] == last_three[2]:
                        if self._permission_broker is not None:
                            doom_req = PermissionRequest(tool_name="doom_loop")
                            doom_req.request_id = generate_id()
                            doom_content = json.dumps({
                                "request_id": doom_req.request_id,
                                "tool_name": "doom_loop",
                                "path": "",
                                "tool_args": {"repeated_tool": last_three[0][0]},
                            })
                            yield StreamEvent("permission_request", content=doom_content)
                            doom_reply = await self._permission_broker.ask(
                                doom_req, session_id=self._session_id,
                            )
                            if doom_reply == "reject":
                                yield StreamEvent(
                                    "error",
                                    error=f"Doom loop detected: {last_three[0][0]} called 3 times with same args",
                                )
                                return
                        else:
                            log.warning("Doom loop detected: %s", last_three[0][0])
                            yield StreamEvent(
                                "error",
                                error=f"Doom loop detected: {last_three[0][0]} called 3 times with same args",
                            )
                            return

                # Handle question tool calls sequentially (require user interaction)
                question_results: list[tuple[ToolCall, str]] = []
                remaining_approved: list[tuple[int, ToolCall]] = []

                for idx, tc in approved:
                    if tc.name == "question" and self._question_broker is not None:
                        question_text = tc.arguments.get("question", "")
                        if question_text:
                            request_id = generate_id()
                            q_content = json.dumps({
                                "request_id": request_id,
                                "question": question_text,
                            })
                            yield StreamEvent("question_request", content=q_content)
                            answer = await self._question_broker.ask_with_id(
                                request_id, question_text,
                                session_id=self._session_id,
                            )
                            question_results.append((tc, answer or "(no answer)"))
                        else:
                            question_results.append((tc, "Error: empty question"))
                    else:
                        remaining_approved.append((idx, tc))

                # Phase B: Parallel execution of approved tools
                async def execute_tool(tc: ToolCall) -> tuple[ToolCall, str]:
                    """Execute a single tool call and return the result."""
                    if self._tool_executor is not None:
                        try:
                            result = await self._tool_executor(
                                tc.name, tc.arguments
                            )
                        except Exception as e:
                            result = f"Error executing tool '{tc.name}': {e}"
                            log.error(result)
                    else:
                        result = "Error: No tool executor configured"
                    return tc, result

                exec_results = await asyncio.gather(
                    *[execute_tool(tc) for _, tc in remaining_approved]
                )

                # Combine denied + question + executed results in original order
                all_results: dict[str, tuple[ToolCall, str]] = {}
                for tc, result in denied_results:
                    all_results[tc.id] = (tc, result)
                for tc, result in question_results:
                    all_results[tc.id] = (tc, result)
                for tc, result in exec_results:
                    all_results[tc.id] = (tc, result)

                # Yield tool results and add to messages in original order
                for _idx, tc in sorted_tcs:
                    if tc.id in all_results:
                        res_tc, result = all_results[tc.id]
                        yield StreamEvent(
                            "tool_result", tool_result=result, tool_call=res_tc
                        )
                        self._messages.append(
                            {
                                "role": "tool",
                                "content": result,
                                "tool_call_id": tc.id,
                            }
                        )

                # Check cancellation after tool execution
                if self._cancel_event and self._cancel_event.is_set():
                    log.info("Agent loop cancelled after tool execution")
                    yield StreamEvent("done", done=True)
                    return

                continue

            # No content and no tool calls — done
            yield StreamEvent("done", done=True)
            return

        yield StreamEvent(
            "error", error=f"Max steps ({self._agent.max_steps}) reached"
        )
