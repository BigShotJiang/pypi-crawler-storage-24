"""Session processor — orchestrates agent loop + tools for a session."""

from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator

from openclose.agent.agent import get_agent
from openclose.agent.loop import AgentLoop, StreamEvent, ToolExecutor
from openclose.permission.permission import PermissionEngine
from openclose.permission.broker import PermissionBroker
from openclose.tool.tools.question_broker import QuestionBroker
from openclose.provider.provider import Provider, get_provider
from openclose.session.session import SessionManager
from openclose.session.message import MessagePartType, MessageRole
from openclose.session.compaction import (
    compact_messages,
    estimate_messages_tokens,
    estimate_tool_schemas_tokens,
    summarize_for_compaction,
)
from openclose.storage.schema import Message, MessagePart
from openclose.config.config import get_config
from openclose.storage.db import Database
from openclose.log import get_logger

log = get_logger(__name__)


def _derive_title(text: str, max_len: int = 50) -> str:
    """Derive a short session title from user text."""
    cleaned = " ".join(text.split())
    if len(cleaned) <= max_len:
        return cleaned
    truncated = cleaned[:max_len].rsplit(" ", 1)[0]
    return truncated + "\u2026"


class SessionProcessor:
    """Processes user messages within a session context.

    Ties together: session persistence, agent loop, tool execution, compaction.
    """

    def __init__(
        self,
        db: Database,
        session_id: str,
        agent_name: str = "build",
        provider: Provider | None = None,
        tool_executor: ToolExecutor | None = None,
        tool_schemas: list[dict[str, Any]] | None = None,
        project_dir: str = ".",
        permission_engine: PermissionEngine | None = None,
        permission_broker: PermissionBroker | None = None,
        question_broker: QuestionBroker | None = None,
        cancel_event: asyncio.Event | None = None,
    ) -> None:
        self._session_mgr = SessionManager(db)
        self._session_id = session_id
        self._agent = get_agent(agent_name)
        self._provider = provider or get_provider()
        self._tool_executor = tool_executor
        self._tool_schemas = tool_schemas or []
        self._project_dir = project_dir
        self._permission_engine = permission_engine
        self._permission_broker = permission_broker
        self._question_broker = question_broker
        self._cancel_event = cancel_event

    @staticmethod
    def _reconstruct_llm_messages(
        messages_with_parts: list[tuple[Message, list[MessagePart]]],
    ) -> list[dict[str, Any]]:
        """Convert stored messages + parts into LLM-ready dicts with tool context."""
        result: list[dict[str, Any]] = []

        for msg, parts in messages_with_parts:
            tool_call_parts = [
                p for p in parts if p.part_type == MessagePartType.TOOL_CALL.value
            ]
            tool_result_parts = [
                p for p in parts if p.part_type == MessagePartType.TOOL_RESULT.value
            ]

            if msg.role == "assistant" and tool_call_parts:
                # Build assistant message with tool_calls
                tool_calls: list[dict[str, Any]] = []
                for tc in tool_call_parts:
                    tool_calls.append({
                        "id": tc.tool_call_id or "",
                        "type": "function",
                        "function": {
                            "name": tc.tool_name or "",
                            "arguments": tc.content,
                        },
                    })
                assistant_msg: dict[str, Any] = {
                    "role": "assistant",
                    "content": msg.content or None,
                    "tool_calls": tool_calls,
                }
                result.append(assistant_msg)

                # Emit tool result messages
                result_by_id = {
                    p.tool_call_id: p for p in tool_result_parts
                }
                for tc in tool_call_parts:
                    tr = result_by_id.get(tc.tool_call_id)
                    if tr is not None:
                        result.append({
                            "role": "tool",
                            "content": tr.content,
                            "tool_call_id": tr.tool_call_id,
                        })
                    else:
                        # Interrupted session — no result stored for this call
                        result.append({
                            "role": "tool",
                            "content": "[Error: tool call was interrupted and produced no result]",
                            "tool_call_id": tc.tool_call_id or "",
                        })
            else:
                # Plain user/system/assistant message
                result.append({"role": msg.role, "content": msg.content})

        return result

    def _build_context_info(
        self, messages: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Build context usage info for the client."""
        config = get_config()
        messages_tokens = estimate_messages_tokens(messages)
        tools_tokens = estimate_tool_schemas_tokens(self._tool_schemas)
        return {
            "used": messages_tokens + tools_tokens,
            "max": config.max_context_tokens,
            "messages_tokens": messages_tokens,
            "tools_tokens": tools_tokens,
        }

    async def process(self, user_message: str) -> AsyncIterator[StreamEvent]:
        """Process a user message and yield stream events."""
        # Persist user message
        self._session_mgr.add_message(
            session_id=self._session_id,
            role=MessageRole.USER,
            content=user_message,
        )

        # Auto-name untitled sessions from the first user message
        session = self._session_mgr.get_session(self._session_id)
        if session and not session.title:
            title = _derive_title(user_message)
            if title:
                self._session_mgr.update_title(self._session_id, title)

        # Build agent loop
        loop = AgentLoop(
            agent=self._agent,
            provider=self._provider,
            tool_executor=self._tool_executor,
            tool_schemas=self._tool_schemas,
            project_dir=self._project_dir,
            permission_engine=self._permission_engine,
            permission_broker=self._permission_broker,
            question_broker=self._question_broker,
            session_id=self._session_id,
            cancel_event=self._cancel_event,
        )

        # Load existing messages with parts (for tool context reconstruction)
        messages_with_parts = self._session_mgr.get_messages_with_parts(
            self._session_id
        )
        # Exclude the just-added user message
        messages_for_llm = self._reconstruct_llm_messages(
            messages_with_parts[:-1]
        )
        loop.messages = messages_for_llm

        # Check if compaction is needed
        config = get_config()
        threshold = int(config.max_context_tokens * config.compaction_threshold)
        tool_overhead = estimate_tool_schemas_tokens(self._tool_schemas)
        estimated = estimate_messages_tokens(loop.messages) + tool_overhead
        if estimated > threshold:
            compacted, was_compacted, pruned = compact_messages(
                loop.messages,
                max_tokens=threshold,
                keep_recent_tokens=min(40_000, threshold // 2),
                tool_tokens=tool_overhead,
            )
            if was_compacted:
                log.info("Context compacted for session %s", self._session_id)
                # Try to replace the placeholder with an LLM summary
                if pruned:
                    try:
                        async def _llm_call(
                            msgs: list[dict[str, Any]], max_tokens: int
                        ) -> str:
                            resp = await self._provider.chat_sync(
                                messages=msgs,  # type: ignore[arg-type]
                                model=self._agent.model or config.providers[0].default_model,
                                max_tokens=max_tokens,
                            )
                            return str(resp.choices[0].message.content or "")

                        summary = await summarize_for_compaction(
                            pruned,
                            _llm_call,
                            max_summary_tokens=config.compaction_summary_max_tokens,
                        )
                        if summary:
                            for m in compacted:
                                if m.get("_compaction_placeholder"):
                                    m["content"] = (
                                        f"[Summary of earlier conversation — use this "
                                        f"to maintain continuity]\n\n{summary}"
                                    )
                                    m.pop("_compaction_placeholder", None)
                                    break
                    except Exception:
                        log.warning(
                            "Compaction summary failed, using placeholder",
                            exc_info=True,
                        )
                        # Clean up marker from placeholder
                        for m in compacted:
                            m.pop("_compaction_placeholder", None)
                # Clean up any remaining markers
                for m in compacted:
                    m.pop("_compaction_placeholder", None)
                loop.messages = compacted

        # Emit initial context usage
        yield StreamEvent(
            "context_update",
            context_info=self._build_context_info(loop.messages),
        )

        # Run agent loop
        full_response = ""
        tool_calls_collected: list[tuple[str, str, str]] = []  # (name, id, args)
        tool_results_collected: list[tuple[str, str, str]] = []  # (name, id, result)

        try:
            async for event in loop.run(user_message):
                if event.type == "text":
                    full_response += event.content
                elif event.type == "tool_call" and event.tool_call:
                    tool_calls_collected.append((
                        event.tool_call.name,
                        event.tool_call.id,
                        event.tool_call.arguments_raw,
                    ))
                elif event.type == "tool_result" and event.tool_call:
                    tool_results_collected.append((
                        event.tool_call.name,
                        event.tool_call.id,
                        event.tool_result,
                    ))
                yield event

                # Emit context update after tool_result, done, or error
                if event.type in ("tool_result", "done", "error"):
                    yield StreamEvent(
                        "context_update",
                        context_info=self._build_context_info(loop.messages),
                    )
        finally:
            # Persist assistant response and tool call/result parts.
            # Using finally ensures partial responses are saved even when
            # the generator is interrupted (e.g. client abort / GeneratorExit).
            if full_response or tool_calls_collected:
                msg = self._session_mgr.add_message(
                    session_id=self._session_id,
                    role=MessageRole.ASSISTANT,
                    content=full_response,
                )
                for name, tc_id, args in tool_calls_collected:
                    self._session_mgr.add_message_part(
                        msg.id,
                        MessagePartType.TOOL_CALL,
                        content=args,
                        tool_name=name,
                        tool_call_id=tc_id,
                    )
                for name, tc_id, result_text in tool_results_collected:
                    self._session_mgr.add_message_part(
                        msg.id,
                        MessagePartType.TOOL_RESULT,
                        content=result_text,
                        tool_name=name,
                        tool_call_id=tc_id,
                    )
