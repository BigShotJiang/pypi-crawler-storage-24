# src/common/ingest_utils.py
from pyspark.sql.functions import current_timestamp, lit, input_file_name
from dbx_elt_utils.notebook_utils import get_schema_location_base

def ingesta_hibrida(spark, origen, tipo="auto_detect", formato_archivo="json", env_suffix="_dev", streaming=True):
    """
    Ingestor Universal.
    Args:
        origen (str): Nombre de tabla (cat.esq.tab) O Ruta (abfss://...)
        tipo (str): "delta_table", "auto_loader" o "auto_detect"
        formato_archivo (str): csv, json, parquet (Solo para Auto Loader)
        env_suffix (str): Sufijo de ambiente ("_dev", "_prod") para rutas de checkpoint
        streaming (bool): Si estamos en test (interactivo), se forza a BATCH automáticamente.
    """
    from dbx_elt_utils.notebook_utils import is_test_run_active

    # 1. Resolución Automática de Modo (Protección contra Hanging)
    # Si estamos en un test run, FORZAMOS BATCH para evitar bloqueos por streaming
    is_test = is_test_run_active()
    if is_test and streaming:
        # Solo logueamos si el usuario explícitamente intentó streamear en un test
        # pero forzamos Batch por estabilidad.
        streaming = False

    # 2. Auto-detección inteligente de tipo
    if tipo == "auto_detect":
        if "abfss://" in origen or "s3://" in origen or "/" in origen:
            tipo = "auto_loader"
        else:
            tipo = "delta_table"

    mode_str = "STREAMING" if streaming else "BATCH"
    if is_test:
        print(f"🏗️  Contexto de TEST detectado. Forzando lectura en modo {mode_str}.")
    
    print(f"🏭 Ingesta Híbrida activada ({mode_str}): {tipo.upper()} -> {origen}")

    # 3. Lógica de Lectura
    reader = spark.readStream if streaming else spark.read

    # --- CASO A: UNITY CATALOG (Tablas Fivetran) ---
    if tipo == "delta_table":
        return (
            reader.table(origen)
            .withColumn("_origen_datos", lit("unity_catalog"))
            .withColumn("_ingestado_en", current_timestamp())
        )

    # --- CASO B: AUTO LOADER (Archivos Sueltos) ---
    elif tipo == "auto_loader":
        # Configuración "Schema Evolution" (Clave para archivos sueltos que cambian)
        cloud_reader = (
            reader.format("cloudFiles")
            .option("cloudFiles.format", formato_archivo)
            .option("cloudFiles.inferColumnTypes", "true")
            .option("cloudFiles.schemaEvolutionMode", "addNewColumns") # Si el Excel trae columna nueva, no falla
            .option("cloudFiles.schemaLocation", f"{get_schema_location_base(env_suffix)}/{origen.split('/')[-1]}")
        )

        # Ajustes específicos para CSV
        if formato_archivo == "csv":
            cloud_reader = cloud_reader.option("header", "true").option("delimiter", ",")

        return (
            cloud_reader.load(origen)
            .withColumn("_origen_datos", lit(f"file_{formato_archivo}"))
            .withColumn("_nombre_archivo", input_file_name()) # Útil para saber qué archivo trajo el dato
            .withColumn("_ingestado_en", current_timestamp())
        )

    else:
        raise ValueError(f"Tipo desconocido: {tipo}")