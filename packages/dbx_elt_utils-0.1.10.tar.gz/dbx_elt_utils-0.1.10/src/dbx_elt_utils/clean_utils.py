# src/common/clean_utils.py
from pyspark.sql.functions import regexp_replace, col, trim, when


def extraer_valor_array_string(columna):
    """
    Limpia columnas que vienen con formato de array JSON string.
    Ejemplo: '["12.345.678-9"]' -> '12.345.678-9'
    Ejemplo: '[]' -> NULL
    """
    # 1. Eliminar corchetes y comillas
    # Regex: Quita [ " ] al principio o al final
    c = regexp_replace(columna, r'[\["\]]', "")

    # 2. Si queda vacío, convertir a NULL
    return when(trim(c) == "", None).otherwise(trim(c))
