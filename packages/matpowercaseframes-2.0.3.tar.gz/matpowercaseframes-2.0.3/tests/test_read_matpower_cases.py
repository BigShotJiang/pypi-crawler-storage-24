import warnings

import numpy as np
import pandas as pd
import pytest
from matpower import path_matpower, run_matlab_cmd, start_instance

from matpowercaseframes import CaseFrames, ReservesFrames, xGenDataTableFrames
from matpowercaseframes.testing import assert_frames_struct_equal

try:
    import matlab.engine  # noqa: F401

    MATLAB_AVAILABLE = True
except ImportError:
    MATLAB_AVAILABLE = False

"""
    pytest -n auto -rA --cov-report term --cov=matpowercaseframes tests/

    case9          : default MATPOWER case, polynomial gencost (TYPE=2)
    case9Q         : case with Q gencost
    case4_dist     : small distribution network case
    case118        : medium-scale IEEE case, tests all three loading methods
    case_RTS_GMLC  : piecewise linear gencost (TYPE=1) and contains bus_name
    t_case9_dcline : case with DC lines
    case16am       : case with executable code inside .m file, requires load_case_engine
    case9_load     : case with non-standard keys, tests allow_any_keys
    ex_case3a      : case with operating reserves (ReservesFrames)
    ex_xgd_uc      : case with unit-commitment extended data (xGenDataTableFrames)
"""


def test_case9():
    """
    Default MATPOWER 9-bus case, polynomial gencost columns:
        MODEL, STARTUP, SHUTDOWN, NCOST, C2, C1, C0.
    """
    CASE_NAME = "case9.m"
    cf = CaseFrames(CASE_NAME)
    cols = pd.Index(["MODEL", "STARTUP", "SHUTDOWN", "NCOST", "C2", "C1", "C0"])
    assert cf.gencost.columns.equals(cols)


def test_case9Q():
    """
    Default MATPOWER 9-bus case, polynomial gencost columns:
        MODEL, STARTUP, SHUTDOWN, NCOST, C2, C1, C0.
    """
    CASE_NAME = "case9Q.m"
    cf = CaseFrames(CASE_NAME)
    assert len(cf.gencost) // len(cf.gen) == 2


def test_case4_dist():
    """Small 4-bus radial distribution network case."""
    CASE_NAME = "case4_dist.m"
    CaseFrames(CASE_NAME)


def test_case118():
    """
    IEEE 118-bus case; tests file, engine, and MPC loading methods plus runpf
    round-trip.
    """
    m = start_instance()

    CASE_NAME = "case118.m"
    cf = CaseFrames(CASE_NAME)
    cf_lc = CaseFrames(CASE_NAME, load_case_engine=m)
    mpc = m.loadcase(CASE_NAME)
    cf_mpc = CaseFrames(mpc)

    cf.infer_numpy()
    cf_lc.infer_numpy()
    cf_mpc.infer_numpy()

    mpc = m.runpf(cf.to_mpc(), verbose=False)
    _ = CaseFrames(mpc)

    m.exit()

    assert_frames_struct_equal(cf, cf_lc)
    assert_frames_struct_equal(cf, cf_mpc)


def test_case_RTS_GMLC():
    """
    RTS-GMLC 73-bus case with piecewise linear gencost (TYPE=1):
        MODEL, STARTUP, SHUTDOWN, NCOST, X1, Y1, ...
    """
    m = start_instance()

    # TODO: test read without load_case_engine
    CASE_NAME = "case_RTS_GMLC.m"
    cf = CaseFrames(CASE_NAME)
    cf_lc = CaseFrames(CASE_NAME, load_case_engine=m)

    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore", category=RuntimeWarning, message=".*invalid value.*"
        )
        cf.infer_numpy()
        cf_lc.infer_numpy()

    cols = pd.Index(
        [
            "MODEL",
            "STARTUP",
            "SHUTDOWN",
            "NCOST",
            "X1",
            "Y1",
            "X2",
            "Y2",
            "X3",
            "Y3",
            "X4",
            "Y4",
        ]
    )
    assert cf.gencost.columns.equals(cols)
    assert cf_lc.gencost.columns.equals(cols)

    assert_frames_struct_equal(cf, cf_lc)

    m.exit()


@pytest.mark.skipif(not MATLAB_AVAILABLE, reason="MATLAB not available")
def test_case_RTS_GMLC_matlab():
    """
    RTS-GMLC 73-bus case with bus_name; run power flow via to_mpc(backend="matlab")
    using the MATLAB engine.
    """
    CASE_NAME = "case_RTS_GMLC.m"

    m = start_instance(engine="matlab")

    cf = CaseFrames(CASE_NAME, load_case_engine=m)
    mpc = cf.to_mpc(backend="matlab")
    run_matlab_cmd("runpf(mpc)", m=m, mpc=mpc)

    m.exit()


def test_t_case9_dcline():
    """case9 extended with DC lines from MATPOWER internal test library."""
    CASE_NAME = f"{path_matpower}/lib/t/t_case9_dcline.m"
    CaseFrames(CASE_NAME)


def test_loadcase_case16am():
    """
    16-bus case with executable MATLAB code in .m file that requires load_case_engine.
    """
    m = start_instance()
    CASE_NAME = "case16am.m"
    CaseFrames(CASE_NAME, load_case_engine=m)
    m.exit()


def test_read_without_ext():
    """case9 and case9.m must resolve to identical frames."""
    CASE_NAME = "case9.m"
    cf = CaseFrames(CASE_NAME)

    CASE_NAME = "case9"
    cf_no_ext = CaseFrames(CASE_NAME)

    assert_frames_struct_equal(cf, cf_no_ext)


def test_read_allow_any_keys():
    """
    case9_load has a non-standard 'load' field that only visible with
    `allow_any_keys=True`.
    """
    CASE_NAME = "data/case9_load.m"
    cf = CaseFrames(CASE_NAME)
    assert "load" not in cf.attributes

    cf = CaseFrames(CASE_NAME, allow_any_keys=True)
    assert "load" in cf.attributes


def test_read_case_reserve():
    """
    ex_case3a includes operating reserve data parsed into ReservesFrames:
        zones, req, cost, qty.
    """
    m = start_instance()
    CASE_NAME = "data/ex_case3a.m"
    cf = CaseFrames(CASE_NAME, load_case_engine=m)

    assert "reserves" in cf.attributes
    assert hasattr(cf, "reserves")

    assert isinstance(cf.reserves, ReservesFrames)

    assert "zones" in cf.reserves.attributes
    assert isinstance(cf.reserves.zones, pd.DataFrame)
    assert cf.reserves.zones.index.name == "zone"
    assert cf.reserves.zones.columns.name == "gen"
    assert cf.reserves.zones.shape == (cf.reserves.req.shape[0], cf.gen.shape[0])

    assert "req" in cf.reserves.attributes
    assert isinstance(cf.reserves.req, pd.DataFrame)
    assert cf.reserves.req.index.name == "zone"
    assert "PREQ" in cf.reserves.req.columns

    assert isinstance(cf.reserves.cost, pd.DataFrame)
    assert "C1" in cf.reserves.cost.columns
    assert cf.reserves.cost.index.name == "gen"

    assert isinstance(cf.reserves.qty, pd.DataFrame)
    assert "PQTY" in cf.reserves.qty.columns
    assert cf.reserves.qty.index.name == "gen"

    for attr in ["zones", "req", "cost", "qty"]:
        assert attr in cf.reserves.attributes

    cf2 = CaseFrames(cf.to_mpc())
    assert_frames_struct_equal(cf, cf2)

    cf.reset_index()
    assert cf.reserves.zones.index.name == "zone"
    assert cf.reserves.zones.columns.name == "gen"
    assert cf.reserves.zones.shape == (cf.reserves.req.shape[0], cf.gen.shape[0])
    assert "C1" in cf.reserves.cost.columns
    assert cf.reserves.cost.index.name == "gen"
    for idx in cf.reserves.cost.index:
        assert idx in cf.gen.index
    assert "PQTY" in cf.reserves.qty.columns
    assert cf.reserves.qty.index.equals(cf.reserves.cost.index)

    m.exit()


def test_read_xgd_table():
    """Test reading and using xGenDataTableFrames.

    ex_xgd_uc provides unit-commitment extended data parsed into xGenDataTableFrames.
    """
    m = start_instance()

    CASE_NAME = "data/ex_case3a.m"
    cf = CaseFrames(CASE_NAME, load_case_engine=m)

    # NOTE: loadgenericdata not yet support absolute path
    xgd_table_file = "ex_xgd_uc.m"
    xgdt = m.loadgenericdata(
        xgd_table_file, "struct", {"colnames", "data"}, "xgd_table", cf.to_mpc()
    )

    xgdtf = xGenDataTableFrames(
        data=xgdt.data, colnames=xgdt.colnames, index=cf.gen.index
    )

    assert hasattr(xgdtf, "table")
    assert isinstance(xgdtf.table, pd.DataFrame)
    assert xgdtf.table.index.equals(cf.gen.index)

    assert xgdtf.colnames.shape[0] == 1  # Should be 2D with one row
    assert xgdtf.data.shape == xgdtf.table.shape
    assert len(xgdtf) == len(cf.gen)

    first_col = xgdtf.table.columns[0]
    assert xgdtf[first_col].equals(xgdtf.table[first_col])

    cols_from_iter = list(xgdtf)
    assert cols_from_iter == list(xgdtf.table.columns)

    xdgt = xgdtf.to_xgdt()
    assert "colnames" in xdgt
    assert "data" in xdgt
    np.testing.assert_array_equal(xdgt["colnames"], xgdtf.colnames)
    np.testing.assert_array_equal(xdgt["data"], xgdtf.data)

    xgd = m.loadxgendata(xgdtf.to_xgdt(), cf.to_mpc())
    xgdf = xGenDataTableFrames(data=xgd)
    xgdf_df = xgdf.to_df()
    assert isinstance(xgdf_df, pd.DataFrame)

    xdg = xgdf.to_xgd()
    for k, v in xdg.items():
        assert k in xgdf.colnames.flatten().tolist()
        assert k in xgdf_df.columns
        np.testing.assert_array_equal(v, xgdf[k].to_numpy().reshape(-1, 1))

    m.exit()
