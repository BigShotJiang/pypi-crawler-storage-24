# SSONameSync

Syncs first/last name from SSO provider on every InvenTree login

## Installation

### InvenTree Plugin Manager

Add `inventree-ssnamesync` to plugins.txt, will be installed by pip install.

### Command Line 

To install manually via the command line, run the following command:

```bash
pip install inventree-ssonamesync
```

## Configuration

No configuration for InvenTree. SSO configuration may apply.

## Usage

Enable the plugin to sync first/last names from SSO provider.
