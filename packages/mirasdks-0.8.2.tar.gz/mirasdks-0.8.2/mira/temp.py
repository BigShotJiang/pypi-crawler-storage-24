"""Temporary file and directory helpers for Mira."""

from __future__ import annotations

import os
import tempfile
import uuid


def _base_temp_dir() -> str:
    return os.environ.get("MIRA_TMP") or tempfile.gettempdir()


def make_temp_dir(prefix: str) -> str:
    """Create a temporary directory using a safe name."""
    base = _base_temp_dir()
    name = f"{prefix}{uuid.uuid4().hex}"
    path = os.path.join(base, name)
    os.makedirs(path, exist_ok=False)
    return path


def make_temp_file(prefix: str, suffix: str = "") -> str:
    """Create an empty temporary file and return its path."""
    base = _base_temp_dir()
    name = f"{prefix}{uuid.uuid4().hex}{suffix}"
    path = os.path.join(base, name)
    with open(path, "wb") as handle:
        handle.write(b"")
    return path
