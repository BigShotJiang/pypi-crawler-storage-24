"""Convenience test runner for Mira."""

from __future__ import annotations

import argparse
import importlib.util
import subprocess
import sys


def main(argv: list[str] | None = None) -> int:
    """Run pytest with optional arguments."""
    parser = argparse.ArgumentParser(prog="mira-test")
    parser.add_argument("pytest_args", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)

    if importlib.util.find_spec("pytest") is None:
        print(
            "pytest is not installed. Install with: python -m pip install -e .[dev]",
            file=sys.stderr,
        )
        return 1

    command = [sys.executable, "-m", "pytest"]
    if args.pytest_args:
        pytest_args = args.pytest_args
        if pytest_args[0] == "--":
            pytest_args = pytest_args[1:]
        command.extend(pytest_args)
    else:
        command.append("-q")

    return subprocess.call(command)


if __name__ == "__main__":
    raise SystemExit(main())