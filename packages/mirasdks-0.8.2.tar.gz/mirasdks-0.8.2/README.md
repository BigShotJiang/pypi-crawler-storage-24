# Mira

Mira is a Python SDK and CLI for building, distributing, and loading packages in a custom `.mira` format. A `.mira` file contains compiled bytecode, dependencies, native extensions, and a manifest. Archives can be encrypted and signed.

**Requirements**
- Python 3.10+

**Optional extras**
- `.[crypto]` for AES-256-GCM encryption and Ed25519 signing

## Install

From PyPI:

```bash
python -m pip install MiraSDK
```

With crypto extras:

```bash
python -m pip install "MiraSDK[crypto]"
```

For development:

```bash
python -m pip install -e .[dev]
```

With crypto extras (dev):

```bash
python -m pip install -e .[crypto]
```

## Quick Start (CLI)

```bash
mira build ./my_project -o dist
mira run dist/my_project-1.0.0-*.mira
mira inspect dist/my_project-1.0.0-*.mira
mira view dist/my_project-1.0.0-*.mira
mira install dist/my_project-1.0.0-*.mira
mira list
mira info my_project
mira uninstall my_project
```

## Builder API

```python
from mira import MiraBuilder

builder = MiraBuilder("./my_project")
archive_path = builder.build()
print(archive_path)
```

## Runtime API

Load a package and import its modules. The `include` folder in the manifest becomes the root import name.

```python
from mira import MiraRuntime

runtime = MiraRuntime()
runtime.load("dist/my_project-1.0.0-*.mira")

import MY_PACKAGE
from MY_PACKAGE.module import MyClass
```

Load from local repository:

```python
runtime.load_from_repo("my_project")
```

## Library API

```python
from mira import MiraLibrary

lib = MiraLibrary()
lib.install("dist/my_project-1.0.0-*.mira")
print(lib.list())
print(lib.info("my_project"))
lib.uninstall("my_project")
```

## Encryption

Enable encryption via config or CLI. Encrypted `.mira` files are not readable by standard ZIP tools.

```toml
[tool.mira]
encrypt = true
cipher = "aes-256-gcm"
```

```bash
mira build ./my_project -o dist --key "my-secret" --cipher aes-256-gcm
mira inspect dist/my_project-1.0.0-*.mira --key "my-secret"
```

## Signing and Verification

Generate keys:

```bash
mira keygen --out-private mira_private.pem --out-public mira_public.pem
```

Sign during build:

```bash
mira build ./my_project -o dist --sign-keyfile mira_private.pem --embed-public-key
```

Verify:

```bash
mira verify dist/my_project-1.0.0-*.mira --verify-keyfile mira_public.pem
```

## Key Management

Mira supports keys via flags, key files, environment variables, or interactive prompts.

Environment variables:
- `MIRA_KEY` / `MIRA_KEY_FILE`
- `MIRA_SIGNING_KEY` / `MIRA_SIGNING_KEY_FILE`
- `MIRA_VERIFY_KEY` / `MIRA_VERIFY_KEY_FILE`

## Viewer

```bash
mira view dist/my_project-1.0.0-*.mira --key "my-secret"
```

## Examples

```bash
mira build ./examples/wer_project -o dist
python ./examples/wer_project/run_example.py
```

## Tests

```bash
python -m pytest -q
```
