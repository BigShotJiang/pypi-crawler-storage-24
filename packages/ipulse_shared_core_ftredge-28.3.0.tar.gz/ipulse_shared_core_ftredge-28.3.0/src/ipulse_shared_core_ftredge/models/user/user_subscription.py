from datetime import datetime, timezone
import uuid
from typing import Optional, ClassVar, Dict, Any, List, Union
from pydantic import Field, ConfigDict, model_validator
from dateutil.relativedelta import relativedelta
from ipulse_shared_base_ftredge import Layer, Module, list_enums_as_lower_strings, SystemSubject, SubscriptionPlanName, SubscriptionStatus, TimeUnit, BillingIntervalTimeUnit
from ..base_nosql_model import BaseNoSQLModel
from .user_permissions import UserPermission
from ...utils.time_utils import add_time_unit_period, time_remaining_delta
# ORIGINAL AUTHOR ="russlan.ramdowar;russlan@ftredge.com"
# CLASS_ORGIN_DATE=datetime(2024, 2, 12, 20, 5)


DEFAULT_SUBSCRIPTION_PLAN = SubscriptionPlanName.FREE_SUBSCRIPTION
DEFAULT_SUBSCRIPTION_STATUS = SubscriptionStatus.ACTIVE

############################################ !!!!! ALWAYS UPDATE SCHEMA VERSION , IF SCHEMA IS BEING MODIFIED !!! ############################################
class UserSubscription(BaseNoSQLModel):
    """
    Represents a single subscription cycle with enhanced flexibility and tracking.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    SCHEMA_ID: ClassVar[str] = ""
    SCHEMA_NAME: ClassVar[str] = ""
    VERSION: ClassVar[int] = 5  # v5: validity_time_unit str->TimeUnit, use shared time_utils
    DOMAIN: ClassVar[str] = "_".join(list_enums_as_lower_strings(Layer.PULSE_APP, Module.CORE, SystemSubject.SUBSCRIPTION))
    OBJ_REF: ClassVar[str] = "subscription"


    # Unique identifier for this specific subscription instance - now auto-generated
    id: Optional[str] = Field(
        default=None,  # Will be auto-generated using UUID if not provided
        description="Unique identifier for this subscription instance"
    )

    # Plan identification
    plan_name: SubscriptionPlanName = Field(
        ...,  # Required field, no default
        description="Subscription Plan Name"
    )

    plan_version: int = Field(
        ...,  # Required field, no default
        description="Version of the subscription plan"
    )

    # Direct field instead of computed
    plan_id: str = Field(
        ...,  # Required field, no default
        description="Combined plan identifier (plan_name_plan_version)"
    )

    # Cycle duration fields
    cycle_start_datetime: datetime = Field(
        ...,  # Required field, no default
        description="Subscription Cycle Start Date"
    )

    # Direct field instead of computed - will be auto-calculated
    cycle_end_datetime: Optional[datetime] = Field(
        default=None,  # Optional during creation, auto-calculated by validator
        description="Subscription Cycle End Date (auto-calculated if not provided during creation)"
    )

    # Fields for cycle calculation
    validity_time_length: int = Field(
        ...,  # Required field, no default
        description="Length of subscription validity period (e.g., 1, 3, 12)"
    )

    validity_time_unit: TimeUnit = Field(
        ...,  # Required field, no default
        description="Unit of subscription validity (TimeUnit enum: minute, hour, day, week, month, year)"
    )

    # Renewal and status fields
    auto_renew_end_datetime: Optional[datetime] = Field(
        default=None,
        description="End datetime for auto-renewal period. If None, no auto-renewal. If set, auto-renewal is active until this time."
    )

    status: SubscriptionStatus = Field(
        ...,  # Required field, no default
        description="Subscription Status (active, trial, pending_confirmation, etc.)"
    )

    # IAM permissions structure - simplified flattened list
    granted_iam_permissions: List[UserPermission] = Field(
        default_factory=list,
        description="IAM permissions granted by this subscription"
    )

    fallback_plan_id: Optional[str] = Field(
        default=None,  # Optional field with None default
        description="ID of the plan to fall back to if this subscription expires"
    )

    price_paid_usd: float = Field(
        ...,  # Required field, no default
        description="Amount paid for this subscription in USD"
    )

    payment_ref: Optional[str] = Field(
        default=None,
        description="Reference to payment transaction"
    )

    # Credit management fields
    subscription_based_insight_credits_per_update: int = Field(
        default=0,
        description="Number of insight credits to add on each update"
    )

    subscription_based_insight_credits_update_freq_h: int = Field(
        default=24,
        description="Frequency of insight credits update in hours"
    )

    extra_insight_credits_per_cycle: int = Field(
        default=0,
        description="Additional insight credits granted per subscription cycle"
    )

    voting_credits_per_update: int = Field(
        default=0,
        description="Number of voting credits to add on each update"
    )

    voting_credits_update_freq_h: int = Field(
        default=62,
        description="Frequency of voting credits update in hours"
    )

    max_extra_credits_purchases_per_day: int = Field(
        default=3000,
        ge=0,
        description="Maximum number of extra credit pack purchases allowed per UTC day"
    )

    # General metadata for extensibility
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata for the subscription"
    )

    # =========================================================================
    # STRIPE BILLING FIELDS
    # =========================================================================

    stripe_subscription_id: Optional[str] = Field(
        default=None,
        description="Stripe Subscription object ID linking to Stripe's billing"
    )

    stripe_invoice_id: Optional[str] = Field(
        default=None,
        description="Last Stripe Invoice ID that paid for this subscription cycle"
    )

    cancel_at_period_end: bool = Field(
        default=False,
        description="Mirrors Stripe cancel_at_period_end flag (downgrade pending)"
    )

    billing_interval: Optional[BillingIntervalTimeUnit] = Field(
        default=None,
        description="Billing interval (month or year). None for free plans."
    )

    @model_validator(mode='before')
    @classmethod
    def ensure_id_exists(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Ensures the id field exists by generating it using UUID if needed.
        """
        if not isinstance(data, dict):
            return data

        # If id is already provided and non-empty, leave it alone
        if data.get('id'):
            return data

        # Generate a UUID-based id if not provided
        data['id'] = str(uuid.uuid4())
        return data

    @model_validator(mode='before')
    @classmethod
    def auto_calculate_cycle_end_date(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Auto-calculate cycle_end_datetime if not provided, based on cycle_start_datetime,
        validity_time_length, and validity_time_unit.
        """
        if not isinstance(data, dict):
            return data

        # Only calculate if cycle_end_datetime is not already provided or is the default
        if ('cycle_end_datetime' not in data or
            data['cycle_end_datetime'] is None or
            # Check if it's the default factory value (close to now)
            (isinstance(data.get('cycle_end_datetime'), datetime) and
             abs((data['cycle_end_datetime'] - datetime.now(timezone.utc)).total_seconds()) < 5)):

            cycle_start_datetime = data.get('cycle_start_datetime')
            validity_time_length = data.get('validity_time_length')
            validity_time_unit = data.get('validity_time_unit')

            if cycle_start_datetime and validity_time_length and validity_time_unit:
                data['cycle_end_datetime'] = cls.calculate_cycle_end_date(
                    cycle_start_datetime, validity_time_length, validity_time_unit
                )
            else:
                raise ValueError(
                    "Cannot create subscription without cycle_end_datetime. "
                    "Either provide cycle_end_datetime directly or provide "
                    "cycle_start_datetime, validity_time_length, and validity_time_unit for auto-calculation."
                )

        return data

    @model_validator(mode='after')
    def validate_cycle_end_date_required(self) -> 'UserSubscription':
        """
        Ensures cycle_end_datetime is NEVER None after all processing.
        This is a business rule validation that must always pass.
        """
        if self.cycle_end_datetime is None:
            raise ValueError(
                "cycle_end_datetime is required and cannot be None. "
                "This is a critical business rule violation."
            )
        return self

    @property
    def cycle_end_datetime_safe(self) -> datetime:
        """
        Get cycle_end_datetime with guaranteed non-None value.
        This property enforces the business rule that cycle_end_datetime is never None after validation.
        """
        if self.cycle_end_datetime is None:
            raise ValueError(
                "cycle_end_datetime is None - this violates the business rule. "
                "Subscription model validation should have prevented this."
            )
        return self.cycle_end_datetime

    # Helper method to calculate cycle end date
    @classmethod
    def calculate_cycle_end_date(
        cls,
        start_date: datetime,
        validity_length: int,
        validity_unit: Union[TimeUnit, str],
    ) -> datetime:
        """Calculate the end date based on start date and validity period.

        Uses calendar-correct arithmetic via dateutil.relativedelta:
        - 1 month from Jan 31 -> Feb 28 (or 29 in leap year)
        - 1 month from Mar 31 -> Apr 30
        - 1 year from Feb 29  -> Feb 28 (non-leap year)

        Args:
            start_date: Cycle start datetime.
            validity_length: Number of units.
            validity_unit: TimeUnit enum value or its string representation.

        Returns:
            Cycle end datetime.
        """
        return add_time_unit_period(start_date, validity_length, validity_unit)

    # Methods for subscription management
    def is_active(self) -> bool:
        """Check if the subscription is currently active."""
        now = datetime.now(timezone.utc)
        return (
            self.status == SubscriptionStatus.ACTIVE and
            self.cycle_start_datetime <= now <= self.cycle_end_datetime_safe
        )

    def is_expired(self) -> bool:
        """Check if the subscription has expired."""
        now = datetime.now(timezone.utc)
        return now > self.cycle_end_datetime_safe

    def subscription_time_remaining(self, with_auto_renew: bool = False) -> relativedelta:
        """
        Calendar-correct time remaining in the subscription.

        Returns a ``relativedelta`` with actual months, days, hours, etc. --
        no fixed 30-day or 365-day approximations.

        Example usage:
            delta = sub.subscription_time_remaining()
            print(f"{delta.months} months, {delta.days} days remaining")

        Args:
            with_auto_renew: Whether to consider auto-renewal cycles until
                             auto_renew_end_datetime.

        Returns:
            relativedelta from now until the effective expiration.
            All-zeros if already expired.
        """
        effective_end = self._effective_end_datetime(with_auto_renew)
        return time_remaining_delta(effective_end)

    def _effective_end_datetime(self, with_auto_renew: bool = False) -> datetime:
        """
        Determine the effective end datetime, considering auto-renewal.

        Args:
            with_auto_renew: Whether to extend through renewal cycles.

        Returns:
            The effective expiration datetime.
        """
        if not with_auto_renew or not self.auto_renew_end_datetime:
            return self.cycle_end_datetime_safe

        # If auto-renewal ends before/at current cycle end, only current cycle matters
        if self.auto_renew_end_datetime <= self.cycle_end_datetime_safe:
            return self.cycle_end_datetime_safe

        # Walk forward through renewal cycles until we pass auto_renew_end_datetime
        current_cycle_end = self.cycle_end_datetime_safe
        while current_cycle_end < self.auto_renew_end_datetime:
            next_cycle_end = self.calculate_cycle_end_date(
                start_date=current_cycle_end,
                validity_length=self.validity_time_length,
                validity_unit=self.validity_time_unit,
            )
            if next_cycle_end > self.auto_renew_end_datetime:
                break
            current_cycle_end = next_cycle_end

        return current_cycle_end

