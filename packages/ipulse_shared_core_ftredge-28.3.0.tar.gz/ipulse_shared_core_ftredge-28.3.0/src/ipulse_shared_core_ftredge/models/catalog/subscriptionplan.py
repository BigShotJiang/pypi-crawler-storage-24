"""
Subscription Plan Defaults Model

This module defines the configuration templates for subscription plans that are stored in Firestore.
These templates are used to create actual user subscriptions with consistent settings.
"""

from typing import Dict, Any, Optional, ClassVar, List
from enum import StrEnum
from datetime import datetime, timezone, timedelta
from pydantic import Field, ConfigDict, field_validator, model_validator, BaseModel
from ipulse_shared_base_ftredge import (Layer, Module, list_enums_as_lower_strings,
                                        SystemSubject, SubscriptionPlanName, ObjectOverallStatus,
                                        SubscriptionStatus, TimeUnit, BillingIntervalTimeUnit)
from ..base_nosql_model import BaseNoSQLModel
from ..user.user_permissions import UserPermission


class CancellationBehavior(StrEnum):
    """How to handle subscription cancellation / downgrade."""
    END_OF_PERIOD = "end_of_period"
    IMMEDIATE = "immediate"


class ProrationMethod(StrEnum):
    """Methods for handling proration when upgrading plans."""
    IMMEDIATE = "immediate"
    PRORATED = "prorated"
    END_OF_CYCLE = "end_of_cycle"


class Proration(BaseModel):
    """Defines the proration behavior for subscription changes."""
    pro_rata_billing: bool = Field(
        default=True,
        description="If true, charge a pro-rated amount for the remaining time in the current billing cycle."
    )
    proration_date: Optional[int] = Field(
        default=None,
        description="The specific date to use for proration calculations, if applicable."
    )


class BillingOption(BaseModel):
    """
    Represents a single billing interval/price combination for a subscription plan.
    Keys in the parent dict follow the pattern: '{cycle_length}_{cycle_unit}' e.g. '1_month', '1_year'.
    """
    model_config = ConfigDict(extra="forbid")

    cycle_length: int = Field(
        ..., ge=1,
        description="Number of units per billing cycle (e.g. 1, 3, 6, 12)"
    )
    cycle_unit: BillingIntervalTimeUnit = Field(
        ...,
        description="Billing cycle unit (month or year)"
    )
    price_usd: float = Field(
        ..., ge=0,
        description="Price in USD for this billing cycle"
    )
    stripe_price_id: Optional[str] = Field(
        default=None,
        description="Stripe Price ID linked to this billing option"
    )
    savings_display_text: Optional[str] = Field(
        default=None,
        description="Display text showing savings vs monthly (e.g. 'Save 17%')"
    )
    is_highlighted: bool = Field(
        default=False,
        description="Whether this option should be highlighted in the UI (e.g. 'Best Value')"
    )


class PlanUpgradePath(BaseModel):
    """Represents an upgrade path from a source plan to the plan where this path is defined."""

    price_usd: float = Field(
        ...,
        ge=0,
        description="Price for upgrading to this plan in USD"
    )

    proration_method: ProrationMethod = Field(
        ...,
        description="How to handle proration when upgrading"
    )


############################################ !!!!! ALWAYS UPDATE SCHEMA VERSION IF SCHEMA IS BEING MODIFIED !!! ############################################
class SubscriptionPlan(BaseNoSQLModel):
    """
    Configuration template for subscription plans stored in Firestore.
    These templates define the default settings applied when creating user subscriptions.
    """

    model_config = ConfigDict(extra="forbid")
    SCHEMA_ID: ClassVar[str] = ""
    SCHEMA_NAME: ClassVar[str] = ""
    VERSION: ClassVar[int] = 5  # v5: remove plan_validity_cycle_length/unit (now derived from billing_options); add get_validity_cycle() helper
    DOMAIN: ClassVar[str] = "_".join(list_enums_as_lower_strings(Layer.PULSE_APP, Module.CORE, SystemSubject.CATALOG))
    OBJ_REF: ClassVar[str] = "subscriptionplan"

    id: Optional[str] = Field(
        default=None,
        description="Unique identifier for this plan template (e.g., 'free_subscription_1'). Auto-generated if not provided.",
        frozen=True
    )

    plan_name: SubscriptionPlanName = Field(
        ...,
        description="Subscription plan type (FREE, BASE, PREMIUM)",
        frozen=True
    )

    plan_version: int = Field(
        ...,
        ge=1,
        description="Version of this plan template",
        frozen=True
    )

    pulse_status: ObjectOverallStatus = Field(
        default=ObjectOverallStatus.ACTIVE,
        description="Overall status of this subscription plan configuration"
    )

    # Display information
    display_name: str = Field(
        ...,
        min_length=1,
        description="Human-readable plan name",
        frozen=True
    )

    description: str = Field(
        ...,
        min_length=1,
        description="Description of what this plan includes",
        frozen=True
    )

    granted_iam_permissions: List[UserPermission] = Field(
        default_factory=list,
        description="List of all IAM permission granted by this plan",
        frozen=True
    )

    # Credit configuration
    subscription_based_insight_credits_per_update: int = Field(
        ...,
        ge=0,
        description="Number of insight credits added per update cycle",
        frozen=True
    )

    subscription_based_insight_credits_update_freq_h: int = Field(
        ...,
        gt=0,
        description="How often insight credits are updated (in hours)",
        frozen=True
    )

    extra_insight_credits_per_cycle: int = Field(
        ...,
        ge=0,
        description="Bonus insight credits granted per subscription cycle",
        frozen=True
    )

    voting_credits_per_update: int = Field(
        ...,
        ge=0,
        description="Number of voting credits added per update cycle",
        frozen=True
    )

    voting_credits_update_freq_h: int = Field(
        ...,
        gt=0,
        description="How often voting credits are updated (in hours)",
        frozen=True
    )

    max_extra_credits_purchases_per_day: int = Field(
        default=3000,
        ge=0,
        description="Maximum number of extra credit pack purchases allowed per UTC day",
        frozen=True
    )

    # =========================================================================
    # BILLING OPTIONS (replaces flat plan_per_cycle_price_usd + stripe_*_price_id)
    # =========================================================================

    billing_options: Dict[str, BillingOption] = Field(
        default_factory=dict,
        description=(
            "Available billing intervals with pricing and Stripe Price IDs. "
            "Keys follow pattern '{cycle_length}_{cycle_unit}' e.g. '1_month', '1_year'. "
            "Empty dict for free plans."
        )
    )

    default_billing_option_key: Optional[str] = Field(
        default=None,
        description="Key into billing_options for the pre-selected option in the frontend pricing UI"
    )

    # =========================================================================
    # STRIPE PAYMENT FIELDS
    # =========================================================================

    stripe_product_id: Optional[str] = Field(
        default=None,
        description="Stripe Product ID for this subscription plan"
    )

    purchasable: bool = Field(
        default=False,
        description="Whether this plan can be purchased via Stripe. Free plan = False."
    )

    currency: str = Field(
        default="usd",
        description="ISO-4217 currency code for all billing options in this plan"
    )

    # =========================================================================
    # PLAN LIFECYCLE AND DISPLAY
    # =========================================================================

    trial_period_days: int = Field(
        default=0,
        ge=0,
        description="Number of days for a free trial when subscribing to this plan. 0 = no trial."
    )

    grace_period_days: int = Field(
        default=3,
        ge=0,
        description="Days after payment failure before automatic downgrade to fallback plan"
    )

    cancellation_behavior: CancellationBehavior = Field(
        default=CancellationBehavior.END_OF_PERIOD,
        description="How cancellation/downgrade is handled: access until period end or immediate"
    )

    features_display_list: List[str] = Field(
        default_factory=list,
        description="Bullet-point feature descriptions for the pricing page UI"
    )

    display_order: int = Field(
        default=0,
        ge=0,
        description="Sort order for displaying plans in the frontend (lower = first)"
    )

    metadata_version: int = Field(
        default=1,
        ge=1,
        description=(
            "Metadata version for non-breaking changes (description, features_display_list, display_order). "
            "Increment this instead of plan_version when only metadata changes."
        )
    )

    # Features and customization
    plan_extra_features: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional features enabled by this plan",
        frozen=True
    )

    # Upgrade paths
    plan_upgrade_paths: Dict[str, PlanUpgradePath] = Field(
        default_factory=dict,
        description="Defines valid upgrade paths TO this plan FROM other plans (source_plan_id -> upgrade_details)",
        frozen=True
    )

    # Default settings
    plan_default_auto_renewal_end: Optional[datetime] = Field(
        default=None,
        description="Default auto-renewal setting for new subscriptions",
        frozen=True
    )

    plan_default_status: SubscriptionStatus = Field(
        ...,
        description="Default status for new subscriptions with this plan",
        frozen=True
    )

    # Fallback configuration
    fallback_plan_id_if_current_plan_expired: Optional[str] = Field(
        None,
        description="Plan to fall back to when this plan expires (None for no fallback)",
        frozen=True
    )

    # =========================================================================
    # HELPER METHODS
    # =========================================================================

    def get_billing_option(self, billing_interval: BillingIntervalTimeUnit) -> Optional[BillingOption]:
        """
        Look up a BillingOption by interval.
        Tries '1_{interval}' first, then scans all options for matching cycle_unit.

        Args:
            billing_interval: The billing interval (month or year).

        Returns:
            Matching BillingOption or None.
        """
        # Fast path: standard key pattern
        key = f"1_{billing_interval.value}"
        if key in self.billing_options:
            return self.billing_options[key]

        # Fallback: scan for matching cycle_unit
        for option in self.billing_options.values():
            if option.cycle_unit == billing_interval:
                return option

        return None

    def get_stripe_price_id(self, billing_interval: BillingIntervalTimeUnit) -> Optional[str]:
        """
        Get the Stripe Price ID for a given billing interval.

        Args:
            billing_interval: The billing interval (month or year).

        Returns:
            Stripe Price ID string or None if not configured.
        """
        option = self.get_billing_option(billing_interval)
        return option.stripe_price_id if option else None

    def get_price_usd(self, billing_interval: BillingIntervalTimeUnit) -> Optional[float]:
        """
        Get the USD price for a given billing interval.

        Args:
            billing_interval: The billing interval (month or year).

        Returns:
            Price in USD or None if no option exists for this interval.
        """
        option = self.get_billing_option(billing_interval)
        return option.price_usd if option else None

    def get_default_price_usd(self) -> float:
        """
        Get the price from the default billing option, or the first available option, or 0.0.
        Used when billing_interval is not specified (e.g. free plans, subscription creation from plan).

        Returns:
            Price in USD. 0.0 if no billing options exist.
        """
        if self.default_billing_option_key and self.default_billing_option_key in self.billing_options:
            return self.billing_options[self.default_billing_option_key].price_usd
        if self.billing_options:
            return next(iter(self.billing_options.values())).price_usd
        return 0.0

    def get_validity_cycle(self, billing_interval: Optional[BillingIntervalTimeUnit] = None) -> tuple[int, TimeUnit]:
        """
        Derive subscription validity cycle from the chosen billing option.

        For paid plans, validity matches the billing cycle (monthly billing = 1 month validity).
        For free plans (no billing_options), defaults to 1 month.

        Args:
            billing_interval: The billing interval chosen by the user. None for free plans.

        Returns:
            Tuple of (cycle_length, cycle_unit as TimeUnit).
        """
        # Map BillingIntervalTimeUnit -> TimeUnit
        _unit_map = {
            BillingIntervalTimeUnit.MONTH: TimeUnit.MONTH,
            BillingIntervalTimeUnit.YEAR: TimeUnit.YEAR,
        }

        # If specific billing interval requested, look up that option
        if billing_interval:
            option = self.get_billing_option(billing_interval)
            if option:
                return option.cycle_length, _unit_map[option.cycle_unit]

        # Default billing option
        if self.default_billing_option_key and self.default_billing_option_key in self.billing_options:
            option = self.billing_options[self.default_billing_option_key]
            return option.cycle_length, _unit_map[option.cycle_unit]

        # First available option
        if self.billing_options:
            option = next(iter(self.billing_options.values()))
            return option.cycle_length, _unit_map[option.cycle_unit]

        # Free plans: default 1 month
        return 1, TimeUnit.MONTH

    @model_validator(mode='before')
    @classmethod
    def set_id_if_not_provided(cls, data: Any) -> Any:
        """Generate an ID from plan_name and plan_version if not provided."""
        if isinstance(data, dict):
            plan_name = data.get('plan_name')
            plan_version = data.get('plan_version')
            provided_id = data.get('id')

            if plan_name and plan_version is not None:
                plan_name_str = str(plan_name)
                expected_id = f"{plan_name_str}_{plan_version}"

                if provided_id is None:
                    # Auto-generate ID
                    data['id'] = expected_id
                else:
                    # Validate provided ID matches expected format
                    if provided_id != expected_id:
                        raise ValueError(
                            f"Invalid ID format. Expected '{expected_id}' based on "
                            f"plan_name='{plan_name_str}' and plan_version={plan_version}, "
                            f"but got '{provided_id}'. ID must follow format: {{plan_name}}_{{plan_version}}"
                        )
        return data

    @model_validator(mode='after')
    def validate_billing_options_keys(self) -> 'SubscriptionPlan':
        """Validate that billing_options keys match their content and default key is valid."""
        for key, option in self.billing_options.items():
            expected_key = f"{option.cycle_length}_{option.cycle_unit.value}"
            if key != expected_key:
                raise ValueError(
                    f"Billing option key '{key}' does not match its content. "
                    f"Expected '{expected_key}' based on cycle_length={option.cycle_length}, "
                    f"cycle_unit='{option.cycle_unit.value}'"
                )

        if self.default_billing_option_key and self.default_billing_option_key not in self.billing_options:
            raise ValueError(
                f"default_billing_option_key '{self.default_billing_option_key}' "
                f"not found in billing_options keys: {list(self.billing_options.keys())}"
            )

        return self

    @field_validator('granted_iam_permissions')
    @classmethod
    def validate_granted_iam_permissions(cls, v: List) -> List:
        """Validate IAM permissions list."""
        for i, permission in enumerate(v):
            if not isinstance(permission, UserPermission):
                raise ValueError(f"Permission at index {i} must be a UserPermission instance")
        return v

    @field_validator('plan_upgrade_paths')
    @classmethod
    def validate_upgrade_paths(cls, v: Dict[str, PlanUpgradePath]) -> Dict[str, PlanUpgradePath]:
        """Validate upgrade paths."""
        for source_plan_id, upgrade_path in v.items():
            if not isinstance(source_plan_id, str) or not source_plan_id.strip():
                raise ValueError(f"Source plan ID must be a non-empty string, got: {source_plan_id}")

            if not isinstance(upgrade_path, PlanUpgradePath):
                raise ValueError(f"Upgrade path for '{source_plan_id}' must be a PlanUpgradePath instance")

        return v

