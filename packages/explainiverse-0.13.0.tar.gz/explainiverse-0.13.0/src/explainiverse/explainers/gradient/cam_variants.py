# src/explainiverse/explainers/gradient/cam_variants.py
"""
CAM Variant Explainers — Visual Explanations for CNNs.

This module implements several Class Activation Mapping variants that
extend the original GradCAM approach with different strategies for
computing channel importance weights and spatial attribution maps.

Methods:
    HiResCAM:  Element-wise grad * activation (Draelos & Carin, 2020)
    XGradCAM:  Axiom-based gradient weighting (Fu et al., 2020)
    LayerCAM:  Spatial-weighted activations (Jiang et al., 2021)
    EigenCAM:  SVD-based, gradient-free (Muhammad & Yeasin, 2020)
    ScoreCAM: Perturbation-based, gradient-free (Wang et al., 2020)

References:
    HiResCAM: Draelos & Carin, 2020 — "Use HiResCAM instead of Grad-CAM
        for faithful explanations of neural networks"
    XGradCAM: Fu et al., 2020 — "Axiom-based Grad-CAM: Towards Accurate
        Visualization and Explanation of CNNs"
        https://arxiv.org/abs/2008.02312
    LayerCAM: Jiang et al., 2021 — "LayerCAM: Exploring Hierarchical
        Class Activation Maps for Localization"
        https://ieeexplore.ieee.org/document/9462463
    EigenCAM: Muhammad & Yeasin, 2020 — "Eigen-CAM: Class Activation Map
        using Principal Components"
        https://arxiv.org/abs/2008.00299
    ScoreCAM: Wang et al., 2020 — "Score-CAM: Score-Weighted Visual
        Explanations for Convolutional Neural Networks"
        https://arxiv.org/abs/1910.01279
"""

import numpy as np
from typing import List, Optional, Tuple

from explainiverse.core.explainer import BaseExplainer
from explainiverse.core.explanation import Explanation


# ──────────────────────────────────────────────────────
# Shared Base Class
# ──────────────────────────────────────────────────────

class BaseCAMExplainer(BaseExplainer):
    """
    Abstract base for all CAM-family explainers.

    Provides shared logic for input preprocessing, heatmap normalization,
    bilinear resizing, Explanation construction, and batch processing.
    Subclasses only need to implement ``_compute_cam()``.
    """

    # Subclasses set these
    _explainer_name: str = "BaseCAM"
    _method_key: str = "basecam"
    _uses_gradients: bool = True

    def __init__(
        self,
        model,
        target_layer: str,
        class_names: Optional[List[str]] = None,
    ):
        super().__init__(model)

        if not hasattr(model, "get_layer_gradients"):
            raise TypeError(
                "Model adapter must have get_layer_gradients() method. "
                "Use PyTorchAdapter for PyTorch models."
            )

        self.target_layer = target_layer
        self.class_names = list(class_names) if class_names else None

    # ── abstract ──────────────────────────────────────

    def _compute_cam(
        self,
        activations: np.ndarray,
        gradients: Optional[np.ndarray],
        image: np.ndarray,
        target_class: Optional[int],
    ) -> np.ndarray:
        """Return raw CAM of shape (H_act, W_act). Subclasses must implement."""
        raise NotImplementedError

    # ── shared helpers ────────────────────────────────

    @staticmethod
    def _normalize_heatmap(heatmap: np.ndarray) -> np.ndarray:
        """Normalize to [0, 1]."""
        heatmap = heatmap.squeeze()
        lo, hi = heatmap.min(), heatmap.max()
        if hi - lo > 1e-8:
            return (heatmap - lo) / (hi - lo)
        return np.zeros_like(heatmap)

    @staticmethod
    def _resize_heatmap(heatmap: np.ndarray, target_size: Tuple[int, int]) -> np.ndarray:
        """Bilinear-interpolation resize without external dependencies."""
        h, w = heatmap.shape
        th, tw = target_size

        y_ratio = h / th
        x_ratio = w / tw

        y_coords = np.arange(th) * y_ratio
        x_coords = np.arange(tw) * x_ratio

        y0 = np.floor(y_coords).astype(int)
        x0 = np.floor(x_coords).astype(int)
        y1 = np.minimum(y0 + 1, h - 1)
        x1 = np.minimum(x0 + 1, w - 1)

        yf = y_coords - y0
        xf = x_coords - x0

        # Vectorised bilinear interpolation
        top = heatmap[y0][:, x0] * (1 - xf[None, :]) + heatmap[y0][:, x1] * xf[None, :]
        bot = heatmap[y1][:, x0] * (1 - xf[None, :]) + heatmap[y1][:, x1] * xf[None, :]
        return top * (1 - yf[:, None]) + bot * yf[:, None]

    def _preprocess_image(self, image: np.ndarray):
        """Return (image_4d, input_size) handling CHW, HWC, flat, and batch inputs."""
        image = np.array(image, dtype=np.float32)

        if image.ndim == 3:
            if image.shape[0] in (1, 3, 4):
                image = image[np.newaxis, ...]          # CHW → NCHW
            else:
                image = np.transpose(image, (2, 0, 1))[np.newaxis, ...]  # HWC
        elif image.ndim == 4:
            pass
        elif image.ndim <= 2:
            if image.ndim == 1:
                image = image[np.newaxis, ...]
        else:
            raise ValueError(f"Unsupported input shape {image.shape}")

        if image.ndim == 4:
            input_size = (image.shape[2], image.shape[3])
        else:
            n = image.shape[-1]
            side = int(np.sqrt(n))
            input_size = (side, side) if side * side == n else (1, n)

        return image, input_size

    # ── public API ────────────────────────────────────

    def explain(
        self,
        image: np.ndarray,
        target_class: Optional[int] = None,
        resize_to_input: bool = True,
    ) -> Explanation:
        """Generate a CAM explanation for *image*."""
        image, input_size = self._preprocess_image(image)

        # Obtain activations (and gradients when needed)
        if self._uses_gradients:
            activations, gradients = self.model.get_layer_gradients(
                image, layer_name=self.target_layer, target_class=target_class,
            )
        else:
            activations = self.model.get_layer_output(image, layer_name=self.target_layer)
            gradients = None

        # Ensure 4-D
        if activations.ndim == 2:
            side = int(np.sqrt(activations.shape[1]))
            activations = activations.reshape(1, 1, side, side)
            if gradients is not None:
                gradients = gradients.reshape(1, 1, side, side)
        elif activations.ndim == 3:
            activations = activations[np.newaxis, ...]
            if gradients is not None:
                gradients = gradients[np.newaxis, ...]

        # Delegate to subclass
        cam = self._compute_cam(activations, gradients, image, target_class)

        # Post-process
        cam = np.maximum(cam, 0)
        heatmap = self._normalize_heatmap(cam)

        if resize_to_input and heatmap.shape != input_size:
            heatmap = self._resize_heatmap(heatmap, input_size)

        # Resolve class label
        if target_class is None:
            preds = self.model.predict(image)
            target_class = int(np.argmax(preds))
        label = (
            self.class_names[target_class]
            if self.class_names and target_class < len(self.class_names)
            else f"class_{target_class}"
        )

        return Explanation(
            explainer_name=self._explainer_name,
            target_class=label,
            explanation_data={
                "heatmap": heatmap.tolist(),
                "heatmap_shape": list(heatmap.shape),
                "target_layer": self.target_layer,
                "method": self._method_key,
                "input_shape": list(image.shape),
            },
        )

    def explain_batch(
        self, images: np.ndarray, target_class: Optional[int] = None,
    ) -> List[Explanation]:
        """Generate explanations for a batch of images."""
        images = np.array(images)
        return [self.explain(images[i], target_class=target_class)
                for i in range(images.shape[0])]


# ──────────────────────────────────────────────────────
# HiResCAM
# ──────────────────────────────────────────────────────

class HiResCAMExplainer(BaseCAMExplainer):
    """
    HiResCAM — High-Resolution Class Activation Mapping.

    Computes the CAM as the element-wise product of gradients and
    activations, summed over channels.  Unlike GradCAM, it does
    **not** global-average-pool the gradients, preserving spatial
    detail and providing a faithfulness guarantee by construction.

    Reference:
        Draelos & Carin, 2020 — "Use HiResCAM instead of Grad-CAM
        for faithful explanations of neural networks"
    """

    _explainer_name = "HiResCAM"
    _method_key = "hirescam"
    _uses_gradients = True

    def _compute_cam(self, activations, gradients, image, target_class):
        # Element-wise product summed over channels: sum_c(g_c * A_c)
        return np.sum(gradients * activations, axis=1).squeeze()


# ──────────────────────────────────────────────────────
# XGradCAM
# ──────────────────────────────────────────────────────

class XGradCAMExplainer(BaseCAMExplainer):
    """
    XGradCAM — Axiom-based Grad-CAM.

    Weights each channel by (grad * activation) / sum(activation),
    satisfying both the sensitivity and conservation axioms.

    Reference:
        Fu et al., 2020 — "Axiom-based Grad-CAM: Towards Accurate
        Visualization and Explanation of CNNs"
        https://arxiv.org/abs/2008.02312
    """

    _explainer_name = "XGradCAM"
    _method_key = "xgradcam"
    _uses_gradients = True

    def _compute_cam(self, activations, gradients, image, target_class):
        # Per-channel sum of activations (normaliser)
        sum_act = np.sum(activations, axis=(2, 3), keepdims=True)
        eps = 1e-7
        # Normalised element-wise product → per-channel weight
        weights = np.sum(
            gradients * activations / (sum_act + eps), axis=(2, 3), keepdims=True
        )
        cam = np.sum(weights * activations, axis=1).squeeze()
        return cam


# ──────────────────────────────────────────────────────
# LayerCAM
# ──────────────────────────────────────────────────────

class LayerCAMExplainer(BaseCAMExplainer):
    """
    LayerCAM — Exploring Hierarchical Class Activation Maps.

    Uses spatial-weighted positive gradients multiplied by activations,
    enabling meaningful visualisations at **any** layer, not only the
    last convolutional layer.

    Reference:
        Jiang et al., 2021 — "LayerCAM: Exploring Hierarchical Class
        Activation Maps for Localization" (IEEE TIP)
        https://ieeexplore.ieee.org/document/9462463
    """

    _explainer_name = "LayerCAM"
    _method_key = "layercam"
    _uses_gradients = True

    def _compute_cam(self, activations, gradients, image, target_class):
        # Spatial-weighted: sum_c( ReLU(grad_c) * act_c )
        spatial_weighted = np.maximum(gradients, 0) * activations
        return np.sum(spatial_weighted, axis=1).squeeze()


# ──────────────────────────────────────────────────────
# EigenCAM
# ──────────────────────────────────────────────────────

class EigenCAMExplainer(BaseCAMExplainer):
    """
    EigenCAM — Class Activation Map using Principal Components.

    Gradient-free and class-agnostic.  Computes the first principal
    component of the activation tensor via SVD to produce the CAM.

    Reference:
        Muhammad & Yeasin, 2020 — "Eigen-CAM: Class Activation Map
        using Principal Components"
        https://arxiv.org/abs/2008.00299
    """

    _explainer_name = "EigenCAM"
    _method_key = "eigencam"
    _uses_gradients = False

    def _compute_cam(self, activations, gradients, image, target_class):
        # activations: (N, C, H, W) — take first sample
        act = activations[0]  # (C, H, W)
        C, H, W = act.shape
        # Reshape to (C, H*W) and compute SVD
        reshaped = act.reshape(C, H * W)
        # First right singular vector gives the principal spatial component
        _, _, Vt = np.linalg.svd(reshaped, full_matrices=False)
        # First component
        cam = Vt[0].reshape(H, W)
        return cam


# ──────────────────────────────────────────────────────
# ScoreCAM
# ──────────────────────────────────────────────────────

class ScoreCAMExplainer(BaseCAMExplainer):
    """
    ScoreCAM — Score-Weighted Visual Explanations.

    Gradient-free.  Each activation channel is upsampled, normalised,
    and used as a mask on the input.  The masked input is fed through
    the model to obtain a confidence score, which serves as the channel
    weight.

    Reference:
        Wang et al., 2020 — "Score-CAM: Score-Weighted Visual
        Explanations for Convolutional Neural Networks"
        https://arxiv.org/abs/1910.01279
    """

    _explainer_name = "ScoreCAM"
    _method_key = "scorecam"
    _uses_gradients = False

    def __init__(
        self,
        model,
        target_layer: str,
        class_names: Optional[List[str]] = None,
        batch_size: int = 16,
    ):
        super().__init__(model, target_layer, class_names)
        self.batch_size = batch_size

    def _upsample_channel(
        self, channel: np.ndarray, target_size: Tuple[int, int]
    ) -> np.ndarray:
        """Upsample a single (H, W) map to *target_size*."""
        return self._resize_heatmap(channel, target_size)

    def _compute_cam(self, activations, gradients, image, target_class):
        # activations: (N, C, H_a, W_a), image: (N, Ch_in, H, W)
        act = activations[0]   # (C, H_a, W_a)
        img = image[0]         # (Ch_in, H, W)
        C, H_a, W_a = act.shape
        _, H_in, W_in = img.shape
        target_size = (H_in, W_in)

        # Determine target class
        if target_class is None:
            preds = self.model.predict(image)
            target_class = int(np.argmax(preds))

        # Upsample, normalise, and score each channel
        scores = np.zeros(C, dtype=np.float32)
        upsampled_masks = np.empty((C, H_in, W_in), dtype=np.float32)

        for c in range(C):
            up = self._upsample_channel(act[c], target_size)
            lo, hi = up.min(), up.max()
            if hi - lo > 1e-8:
                up = (up - lo) / (hi - lo)
            else:
                up = np.zeros_like(up)
            upsampled_masks[c] = up

        # Batch forward passes: masked_input = input * mask
        for start in range(0, C, self.batch_size):
            end = min(start + self.batch_size, C)
            batch_masks = upsampled_masks[start:end]  # (B, H, W)
            # Broadcast: (B, 1, H, W) * (Ch_in, H, W) → (B, Ch_in, H, W)
            masked_inputs = batch_masks[:, np.newaxis, :, :] * img[np.newaxis, :, :, :]
            preds = self.model.predict(masked_inputs)  # (B, n_classes)
            scores[start:end] = preds[:, target_class]

        # Softmax over channel scores for weights
        scores_shifted = scores - scores.max()
        exp_scores = np.exp(scores_shifted)
        weights = exp_scores / (exp_scores.sum() + 1e-8)

        # Weighted combination
        cam = np.sum(
            weights[:, np.newaxis, np.newaxis] * act, axis=0
        )  # (H_a, W_a)
        return cam
