# src/explainiverse/explainers/gradient/__init__.py
"""
Gradient-based explainers for neural networks.

These explainers require models that support gradient computation,
typically via the PyTorchAdapter.

Explainers:
    - IntegratedGradientsExplainer: Axiomatic attributions via path integration
    - GradCAMExplainer: Visual explanations for CNNs (GradCAM / GradCAM++)
    - HiResCAMExplainer: Faithful element-wise CAM (Draelos & Carin, 2020)
    - XGradCAMExplainer: Axiom-based CAM (Fu et al., 2020)
    - LayerCAMExplainer: Hierarchical spatial-weighted CAM (Jiang et al., 2021)
    - EigenCAMExplainer: SVD-based gradient-free CAM (Muhammad & Yeasin, 2020)
    - ScoreCAMExplainer: Score-weighted gradient-free CAM (Wang et al., 2020)
    - DeepLIFTExplainer: Reference-based attribution
    - DeepLIFTShapExplainer: DeepLIFT + SHAP combination
    - SmoothGradExplainer: Noise-averaged gradients
    - SaliencyExplainer: Basic gradient attribution
    - TCAVExplainer: Concept-based explanations (TCAV)
    - LRPExplainer: Layer-wise Relevance Propagation
"""

from explainiverse.explainers.gradient.integrated_gradients import IntegratedGradientsExplainer
from explainiverse.explainers.gradient.gradcam import GradCAMExplainer
from explainiverse.explainers.gradient.cam_variants import (
    BaseCAMExplainer,
    HiResCAMExplainer,
    XGradCAMExplainer,
    LayerCAMExplainer,
    EigenCAMExplainer,
    ScoreCAMExplainer,
)
from explainiverse.explainers.gradient.deeplift import DeepLIFTExplainer, DeepLIFTShapExplainer
from explainiverse.explainers.gradient.smoothgrad import SmoothGradExplainer
from explainiverse.explainers.gradient.saliency import SaliencyExplainer
from explainiverse.explainers.gradient.tcav import TCAVExplainer, ConceptActivationVector
from explainiverse.explainers.gradient.lrp import LRPExplainer

__all__ = [
    "IntegratedGradientsExplainer",
    "GradCAMExplainer",
    "BaseCAMExplainer",
    "HiResCAMExplainer",
    "XGradCAMExplainer",
    "LayerCAMExplainer",
    "EigenCAMExplainer",
    "ScoreCAMExplainer",
    "DeepLIFTExplainer",
    "DeepLIFTShapExplainer",
    "SmoothGradExplainer",
    "SaliencyExplainer",
    "TCAVExplainer",
    "ConceptActivationVector",
    "LRPExplainer",
]
