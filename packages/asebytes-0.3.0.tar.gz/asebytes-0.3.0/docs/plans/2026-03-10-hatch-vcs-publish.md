# hatch-vcs + PyPI Publish Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Switch build backend to hatchling + hatch-vcs for automatic git-tag versioning, and add a GitHub Actions workflow to publish to PyPI on release.

**Architecture:** Replace `uv_build` with `hatchling`/`hatch-vcs` in pyproject.toml. hatch-vcs reads version from git tags (e.g. `0.3.0` tag → version `0.3.0`). A `_version.py` file is generated at build time. The publish workflow triggers on GitHub releases and uses trusted publishing (no API tokens).

**Tech Stack:** hatchling, hatch-vcs, GitHub Actions, pypa/gh-action-pypi-publish

---

### Task 1: Update pyproject.toml build system

**Files:**
- Modify: `pyproject.toml`

**Step 1: Replace build-system and version config**

In `pyproject.toml`, make these changes:

1. Remove the hardcoded `version = "0.3.0"` line
2. Add `dynamic = ["version"]` to `[project]`
3. Replace the `[build-system]` section
4. Add hatch version and build hook config

The `[project]` section should start like:

```toml
[project]
name = "asebytes"
dynamic = ["version"]
description = "Fast binary serialization and storage for ASE Atoms."
```

The `[build-system]` section becomes:

```toml
[build-system]
requires = ["hatchling", "hatch-vcs"]
build-backend = "hatchling.build"
```

Add these new sections at the end (before `[tool.pytest.ini_options]`):

```toml
[tool.hatch.version]
source = "vcs"

[tool.hatch.build.hooks.vcs]
version-file = "src/asebytes/_version.py"
```

**Step 2: Verify the build works**

Run: `uv sync && uv build`
Expected: Builds successfully, creates sdist and wheel in `dist/`

**Step 3: Verify the version is resolved**

Run: `uv run python -c "import asebytes; print(asebytes.__version__)"`
Expected: Prints a version string (may be a dev version like `0.3.0.dev...` if no tag on HEAD)

**Step 4: Add `_version.py` to `.gitignore`**

The file `src/asebytes/_version.py` is generated at build time and should not be committed. Check if `.gitignore` exists and add the entry.

Run: `echo "src/asebytes/_version.py" >> .gitignore`

**Step 5: Commit**

```bash
git add pyproject.toml .gitignore
git commit -m "build: switch to hatchling + hatch-vcs for automatic versioning"
```

---

### Task 2: Create GitHub Actions publish workflow

**Files:**
- Create: `.github/workflows/publish.yaml`

**Step 1: Create the workflow file**

Create `.github/workflows/publish.yaml` with this content:

```yaml
name: Build and upload to PyPI

on:
  workflow_dispatch:
  release:
    types:
      - published

jobs:
  build:
    name: Build distribution
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - uses: astral-sh/setup-uv@v5
      - name: Build sdist and wheel
        run: uv build
      - name: Upload artifacts
        uses: actions/upload-artifact@v4
        with:
          name: dist
          path: dist/*

  upload_pypi:
    needs: [build]
    environment:
      name: pypi
      url: https://pypi.org/p/asebytes
    permissions:
      id-token: write
    runs-on: ubuntu-latest
    if: github.event_name == 'workflow_dispatch' || (github.event_name == 'release' && github.event.action == 'published')
    steps:
      - name: Download all artifacts
        uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist
      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
```

Key details:
- `fetch-depth: 0` is required so hatch-vcs can read git tags
- `id-token: write` enables trusted publishing (no PyPI API tokens needed)
- The `environment: pypi` must be configured on GitHub repo settings to match PyPI trusted publisher config

**Step 2: Commit**

```bash
git add .github/workflows/publish.yaml
git commit -m "ci: add PyPI publish workflow with trusted publishing"
```

---

### Task 3: Verify end-to-end locally

**Step 1: Clean build test**

```bash
rm -rf dist/
uv build
```

Expected: `dist/` contains `asebytes-<version>.tar.gz` and `asebytes-<version>-py3-none-any.whl`

**Step 2: Inspect the wheel version**

```bash
ls dist/
```

Expected: Version in filenames matches git state

---

### Post-merge setup (manual, not automated)

After merging, configure trusted publishing on PyPI:
1. Go to https://pypi.org/manage/project/asebytes/settings/publishing/
2. Add a new publisher: GitHub, repo `zincware/asebytes`, workflow `publish.yaml`, environment `pypi`
3. Create a GitHub environment named `pypi` in repo settings
