# Design: hatch-vcs + PyPI Publish Workflow

## Build System Change

- Replace `uv_build` with `hatchling` + `hatch-vcs`
- Remove hardcoded `version = "0.3.0"`, use `dynamic = ["version"]`
- Add `[tool.hatch.version]` source pointing to vcs (git tags)
- Add `[tool.hatch.build.hooks.vcs]` for `_version.py` generation

## GitHub Actions Workflow

File: `.github/workflows/publish.yaml`

- Triggers: `release: published` + `workflow_dispatch`
- **build** job: checkout (fetch-depth: 0), `uv build`, upload artifact
- **upload_pypi** job: download artifact, publish via `pypa/gh-action-pypi-publish` (trusted publisher, no API tokens)
- Uses `id-token: write` permission

## Scope

- No Docker
- No frontend builds
- No test job (handled by separate CI)
