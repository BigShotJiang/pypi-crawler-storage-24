---
phase: 08-fix-failing-tests-in-redis-mongo-backends-test-isolation
verified: 2026-03-09T22:00:00Z
status: human_needed
score: 3/3 must-haves verified
gaps: []
human_verification:
  - test: "Run MongoDB contract tests in parallel or repeated sequence"
    expected: "All tests pass with no cross-test data leakage"
    why_human: "Cannot programmatically verify against a running MongoDB instance"
  - test: "Run Redis contract tests in parallel or repeated sequence"
    expected: "All tests pass with no cross-test data leakage"
    why_human: "Cannot programmatically verify against a running Redis instance"
  - test: "Run full contract test suite: uv run pytest tests/contract/ -x"
    expected: "All tests pass (no regressions from group= addition)"
    why_human: "Requires running test suite with all backends available"
---

# Phase 8: Fix Failing Tests in Redis/MongoDB Backends Through Test Isolation -- Verification Report

**Phase Goal:** Fix failing tests in Redis/MongoDB backends through test isolation
**Verified:** 2026-03-09T22:00:00Z
**Status:** human_needed
**Re-verification:** No -- initial verification

## Goal Achievement

### Observable Truths

| # | Truth | Status | Evidence |
|---|-------|--------|----------|
| 1 | MongoDB tests pass without data leaking from other tests | ? NEEDS HUMAN | group=group wired in all 6 fixtures; MongoDB backend accepts group= (mongodb/_backend.py:113). Needs live test run to confirm. |
| 2 | Redis tests pass without data leaking from other tests | ? NEEDS HUMAN | group=group wired in all 6 fixtures; Redis backend accepts group= (redis/_backend.py:188). Needs live test run to confirm. |
| 3 | All other backend tests remain green (no regressions) | ? NEEDS HUMAN | group= is accepted by all backends (columnar, h5md, lmdb, memory). SUMMARY claims 412 passed, 7 skipped. Needs live test run to confirm. |

**Score:** 3/3 truths verified at code level (all need human confirmation via test execution)

### Required Artifacts

| Artifact | Expected | Status | Details |
|----------|----------|--------|---------|
| `tests/contract/conftest.py` | Per-test group isolation for all facade fixtures | VERIFIED | Contains `uuid.uuid4()` (7 occurrences: 6 fixtures + 1 memory URI) and `group=group` (6 occurrences, one per facade fixture) |

### Key Link Verification

| From | To | Via | Status | Details |
|------|-----|-----|--------|---------|
| tests/contract/conftest.py | ASEIO constructor | group=group (line 158) | WIRED | `db = ASEIO(path, group=group)` |
| tests/contract/conftest.py | ObjectIO constructor | group=group (line 174) | WIRED | `db = ObjectIO(path, group=group)` |
| tests/contract/conftest.py | BlobIO constructor | group=group (line 189) | WIRED | `db = BlobIO(path, group=group)` |
| tests/contract/conftest.py | AsyncASEIO constructor | group=group (line 223) | WIRED | `db = AsyncASEIO(path, group=group)` |
| tests/contract/conftest.py | AsyncObjectIO constructor | group=group (line 234) | WIRED | `db = AsyncObjectIO(path, group=group)` |
| tests/contract/conftest.py | AsyncBlobIO constructor | group=group (line 245) | WIRED | `db = AsyncBlobIO(path, group=group)` |

### Requirements Coverage

| Requirement | Source Plan | Description | Status | Evidence |
|-------------|------------|-------------|--------|----------|
| ISO-01 | 08-01-PLAN | MongoDB contract tests pass without data leaking between tests | SATISFIED (code-level) | group= wired to all MongoDB-touching fixtures; MongoDB backend accepts group= kwarg |
| ISO-02 | 08-01-PLAN | Redis contract tests pass without data leaking between tests | SATISFIED (code-level) | group= wired to all Redis-touching fixtures; Redis backend accepts group= kwarg |
| ISO-03 | 08-01-PLAN | All other backend contract tests remain green after isolation changes | SATISFIED (code-level) | group= accepted by all backends; no conditional logic; uniform application |

No orphaned requirements found -- all 3 IDs (ISO-01, ISO-02, ISO-03) appear in PLAN and REQUIREMENTS.md.

### Anti-Patterns Found

| File | Line | Pattern | Severity | Impact |
|------|------|---------|----------|--------|
| (none) | - | - | - | - |

No TODO, FIXME, HACK, placeholder, empty implementations, or stub patterns found.

### Human Verification Required

### 1. MongoDB Test Isolation

**Test:** Run `uv run pytest tests/contract/ -k "mongodb" -x --timeout=60`
**Expected:** All MongoDB tests pass with unique group names preventing cross-test data leakage
**Why human:** Requires a running MongoDB instance to verify actual test isolation behavior

### 2. Redis Test Isolation

**Test:** Run `uv run pytest tests/contract/ -k "redis" -x --timeout=60`
**Expected:** All Redis tests pass with unique group names preventing cross-test data leakage
**Why human:** Requires a running Redis instance to verify actual test isolation behavior

### 3. Full Contract Suite (No Regressions)

**Test:** Run `uv run pytest tests/contract/ -x --timeout=60`
**Expected:** All tests pass (SUMMARY claims 412 passed, 7 skipped)
**Why human:** Requires all backends available; cannot verify test execution programmatically

### Gaps Summary

No code-level gaps found. The implementation is clean and complete:
- All 6 facade fixtures generate unique UUID-based group names
- group= is passed uniformly to every constructor (no conditional logic)
- All backends accept the group= parameter through their constructors
- Commit f4b38b9 is on the current branch and modifies only the expected file

The only remaining verification is running the actual test suite against live MongoDB and Redis instances to confirm the isolation works in practice.

---

_Verified: 2026-03-09T22:00:00Z_
_Verifier: Claude (gsd-verifier)_
