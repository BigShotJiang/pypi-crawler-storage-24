"""Benchmark: ColumnarBackend (offset+flat) vs old H5MD (padded) and Zarr (padded).

Usage:
    uv run python benchmarks/bench_columnar.py
"""

from __future__ import annotations

import shutil
import tempfile
import time
from pathlib import Path

import numpy as np


def make_ragged_frames(n_frames: int, min_atoms: int = 3, max_atoms: int = 100, seed: int = 42):
    """Create ragged test data with varying atom counts."""
    rng = np.random.default_rng(seed)
    frames = []
    for i in range(n_frames):
        n_atoms = rng.integers(min_atoms, max_atoms + 1)
        frames.append({
            "arrays.positions": rng.random((n_atoms, 3)),
            "arrays.numbers": rng.integers(1, 30, size=n_atoms),
            "calc.energy": float(rng.random()),
            "calc.forces": rng.random((n_atoms, 3)),
        })
    return frames


def bench_write(BackendCls, path, frames, **kwargs):
    """Benchmark writing frames."""
    b = BackendCls(path, **kwargs)
    t0 = time.perf_counter()
    b.extend(frames)
    elapsed = time.perf_counter() - t0
    b.close()
    return elapsed


def bench_sequential_read(BackendCls, path, n_reads, **kwargs):
    """Benchmark sequential single-row reads."""
    b = BackendCls(path, readonly=True, **kwargs)
    n = len(b)
    t0 = time.perf_counter()
    for i in range(n_reads):
        b.get(i % n)
    elapsed = time.perf_counter() - t0
    b.close()
    return elapsed


def bench_random_read(BackendCls, path, n_reads, seed=99, **kwargs):
    """Benchmark random single-row reads."""
    b = BackendCls(path, readonly=True, **kwargs)
    n = len(b)
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, n, size=n_reads).tolist()
    t0 = time.perf_counter()
    for i in indices:
        b.get(i)
    elapsed = time.perf_counter() - t0
    b.close()
    return elapsed


def bench_bulk_read(BackendCls, path, **kwargs):
    """Benchmark reading all rows at once."""
    b = BackendCls(path, readonly=True, **kwargs)
    n = len(b)
    t0 = time.perf_counter()
    b.get_many(list(range(n)))
    elapsed = time.perf_counter() - t0
    b.close()
    return elapsed


def bench_column_read(BackendCls, path, key, **kwargs):
    """Benchmark reading a single column."""
    b = BackendCls(path, readonly=True, **kwargs)
    t0 = time.perf_counter()
    b.get_column(key)
    elapsed = time.perf_counter() - t0
    b.close()
    return elapsed


def get_file_size(path):
    """Get total file/directory size in bytes."""
    p = Path(path)
    if p.is_dir():
        return sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
    elif p.exists():
        return p.stat().st_size
    return 0


def run_benchmarks():
    from asebytes.columnar import ColumnarBackend
    from asebytes.h5md import H5MDBackend
    from asebytes.zarr import ZarrBackend

    n_frames = 1000
    n_reads = 1000
    frames = make_ragged_frames(n_frames, min_atoms=3, max_atoms=100)

    atom_counts = [f["arrays.positions"].shape[0] for f in frames]
    print(f"Dataset: {n_frames} frames, atoms/frame: "
          f"min={min(atom_counts)}, max={max(atom_counts)}, "
          f"mean={np.mean(atom_counts):.1f}")
    print()

    backends = {
        "Columnar .h5": (ColumnarBackend, ".h5", {}),
        "Columnar .zarr": (ColumnarBackend, ".zarr", {}),
        "H5MD (old)": (H5MDBackend, ".h5md", {}),
        "Zarr (old)": (ZarrBackend, ".zarr_old", {}),
    }

    tmpdir = tempfile.mkdtemp()
    results: dict[str, dict[str, float]] = {}

    try:
        for name, (cls, ext, kw) in backends.items():
            path = str(Path(tmpdir) / f"bench{ext}")
            print(f"--- {name} ---")

            # Write
            t_write = bench_write(cls, path, frames, **kw)
            print(f"  Write {n_frames} frames: {t_write:.3f}s")

            # File size
            size = get_file_size(path)
            print(f"  File size: {size / 1024:.1f} KB")

            # Sequential read
            t_seq = bench_sequential_read(cls, path, n_reads, **kw)
            print(f"  Sequential read x{n_reads}: {t_seq:.3f}s "
                  f"({n_reads / t_seq:.0f} reads/s)")

            # Random read
            t_rand = bench_random_read(cls, path, n_reads, **kw)
            print(f"  Random read x{n_reads}: {t_rand:.3f}s "
                  f"({n_reads / t_rand:.0f} reads/s)")

            # Bulk read
            t_bulk = bench_bulk_read(cls, path, **kw)
            print(f"  Bulk read (all {n_frames}): {t_bulk:.3f}s")

            # Column read
            t_col = bench_column_read(cls, path, "calc.energy", **kw)
            print(f"  Column read (energy): {t_col:.4f}s")

            results[name] = {
                "write": t_write,
                "size_kb": size / 1024,
                "seq_read": t_seq,
                "rand_read": t_rand,
                "bulk_read": t_bulk,
                "col_read": t_col,
            }
            print()

        # Summary comparison
        print("=" * 60)
        print("SUMMARY (speedup vs H5MD old)")
        print("=" * 60)
        ref = results.get("H5MD (old)")
        if ref:
            for name, r in results.items():
                if name == "H5MD (old)":
                    continue
                print(f"\n{name}:")
                for metric in ["write", "seq_read", "rand_read", "bulk_read", "col_read"]:
                    speedup = ref[metric] / r[metric] if r[metric] > 0 else float("inf")
                    print(f"  {metric}: {speedup:.2f}x")
                size_ratio = r["size_kb"] / ref["size_kb"] if ref["size_kb"] > 0 else 0
                print(f"  size: {size_ratio:.2f}x ({r['size_kb']:.1f} vs {ref['size_kb']:.1f} KB)")

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def run_ragged_benchmarks():
    """Benchmark with HIGHLY ragged data — this is where offset+flat wins."""
    from asebytes.columnar import ColumnarBackend
    from asebytes.h5md import H5MDBackend
    from asebytes.zarr import ZarrBackend

    n_frames = 1000
    n_reads = 1000
    rng = np.random.default_rng(42)

    # Highly ragged: most frames 1-5 atoms, a few with 500-2000
    frames = []
    for i in range(n_frames):
        if rng.random() < 0.9:
            n_atoms = rng.integers(1, 6)
        else:
            n_atoms = rng.integers(500, 2001)
        frames.append({
            "arrays.positions": rng.random((n_atoms, 3)),
            "arrays.numbers": rng.integers(1, 30, size=n_atoms),
            "calc.energy": float(rng.random()),
            "calc.forces": rng.random((n_atoms, 3)),
        })

    atom_counts = [f["arrays.positions"].shape[0] for f in frames]
    print(f"\n{'='*60}")
    print("HIGHLY RAGGED BENCHMARK")
    print(f"{'='*60}")
    print(f"Dataset: {n_frames} frames, atoms/frame: "
          f"min={min(atom_counts)}, max={max(atom_counts)}, "
          f"mean={np.mean(atom_counts):.1f}, "
          f"median={np.median(atom_counts):.0f}")
    print(f"90% have 1-5 atoms, 10% have 500-2000 atoms")
    print()

    backends = {
        "Columnar .h5": (ColumnarBackend, ".h5", {}),
        "H5MD (old)": (H5MDBackend, ".h5md", {}),
        "Columnar .zarr": (ColumnarBackend, ".zarr", {}),
        "Zarr (old)": (ZarrBackend, ".zarr_old", {}),
    }

    tmpdir = tempfile.mkdtemp()
    results: dict[str, dict[str, float]] = {}

    try:
        for name, (cls, ext, kw) in backends.items():
            path = str(Path(tmpdir) / f"ragged{ext}")
            print(f"--- {name} ---")

            t_write = bench_write(cls, path, frames, **kw)
            size = get_file_size(path)
            print(f"  Write: {t_write:.3f}s  |  Size: {size / 1024:.1f} KB")

            t_seq = bench_sequential_read(cls, path, n_reads, **kw)
            t_rand = bench_random_read(cls, path, n_reads, **kw)
            t_bulk = bench_bulk_read(cls, path, **kw)
            t_col = bench_column_read(cls, path, "calc.energy", **kw)

            print(f"  Seq read x{n_reads}: {t_seq:.3f}s ({n_reads/t_seq:.0f}/s)  |  "
                  f"Rand read x{n_reads}: {t_rand:.3f}s ({n_reads/t_rand:.0f}/s)")
            print(f"  Bulk read: {t_bulk:.3f}s  |  Column read: {t_col:.4f}s")

            results[name] = {
                "write": t_write, "size_kb": size / 1024,
                "seq_read": t_seq, "rand_read": t_rand,
                "bulk_read": t_bulk, "col_read": t_col,
            }
            print()

        # Pairwise comparisons
        print("=" * 60)
        print("HIGHLY RAGGED: Columnar vs Old (speedup)")
        print("=" * 60)
        for new, old in [("Columnar .h5", "H5MD (old)"), ("Columnar .zarr", "Zarr (old)")]:
            r_new, r_old = results[new], results[old]
            print(f"\n{new} vs {old}:")
            for m in ["write", "seq_read", "rand_read", "bulk_read", "col_read"]:
                sp = r_old[m] / r_new[m] if r_new[m] > 0 else float("inf")
                print(f"  {m:12s}: {sp:.2f}x")
            print(f"  {'size':12s}: {r_new['size_kb']:.0f} vs {r_old['size_kb']:.0f} KB "
                  f"({r_new['size_kb']/r_old['size_kb']:.2f}x)")

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    run_benchmarks()
    run_ragged_benchmarks()
