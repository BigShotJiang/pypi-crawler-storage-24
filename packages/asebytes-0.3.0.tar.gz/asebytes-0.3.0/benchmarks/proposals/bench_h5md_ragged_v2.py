#!/usr/bin/env python3
"""Benchmark v2: H5MD padding vs offset+flat — with optimized flat reads.

v1 issue: flat single-reads did per-index compound dtype lookups.
v2 fixes: batch-read the index array, then slice from in-memory arrays
where possible. Also tests a "hybrid" that pre-reads index into RAM.

Also tests with MORE extreme ragged ratio (3-500 atoms) to see where
disk savings dominate.

Usage:
    uv run python benchmarks/proposals/bench_h5md_ragged_v2.py
"""

from __future__ import annotations

import os
import shutil
import tempfile
import time
from dataclasses import dataclass

import h5py
import numpy as np

# ---------------------------------------------------------------------------
# Test configurations
# ---------------------------------------------------------------------------


@dataclass
class Config:
    name: str
    n_frames: int
    min_atoms: int
    max_atoms: int


CONFIGS = [
    Config("Moderate ragged (3-100)", 1000, 3, 100),
    Config("Extreme ragged (3-500)", 1000, 3, 500),
    Config("Mild ragged (80-100)", 1000, 80, 100),
]


@dataclass
class Result:
    name: str
    write_ms: float
    read_single_ms: float
    read_bulk_ms: float
    read_random_ms: float
    read_column_ms: float
    file_size_kb: float


def generate_data(cfg: Config, seed: int = 42):
    rng = np.random.default_rng(seed)
    atom_counts = rng.integers(cfg.min_atoms, cfg.max_atoms + 1, size=cfg.n_frames)
    positions = [rng.standard_normal((n, 3)).astype(np.float64) for n in atom_counts]
    numbers = [rng.integers(1, 119, size=n).astype(np.int32) for n in atom_counts]
    energies = rng.standard_normal(cfg.n_frames).astype(np.float64)
    offsets = np.zeros(cfg.n_frames + 1, dtype=np.int64)
    np.cumsum(atom_counts, out=offsets[1:])
    random_indices = rng.integers(0, cfg.n_frames, size=cfg.n_frames).tolist()
    return atom_counts, positions, numbers, energies, offsets, random_indices


# ---------------------------------------------------------------------------
# Padded
# ---------------------------------------------------------------------------


def write_padded(path, atom_counts, positions, numbers, energies):
    n_frames = len(atom_counts)
    max_atoms = int(atom_counts.max())
    with h5py.File(path, "w") as f:
        pos = np.full((n_frames, max_atoms, 3), np.nan, dtype=np.float64)
        nums = np.zeros((n_frames, max_atoms), dtype=np.int32)
        for i, n in enumerate(atom_counts):
            pos[i, :n] = positions[i]
            nums[i, :n] = numbers[i]
        f.create_dataset("positions", data=pos, chunks=(64, max_atoms, 3))
        f.create_dataset("numbers", data=nums, chunks=(64, max_atoms))
        f.create_dataset("_n_atoms", data=atom_counts.astype(np.int32))
        f.create_dataset("energy", data=energies)


def read_single_padded(path, indices):
    rows = []
    with h5py.File(path, "r") as f:
        pos_ds, nums_ds = f["positions"], f["numbers"]
        na_ds, e_ds = f["_n_atoms"], f["energy"]
        for i in indices:
            n = int(na_ds[i])
            rows.append({
                "positions": pos_ds[i, :n],
                "numbers": nums_ds[i, :n],
                "energy": float(e_ds[i]),
            })
    return rows


def read_bulk_padded(path, n_frames):
    with h5py.File(path, "r") as f:
        pos = f["positions"][:]
        nums = f["numbers"][:]
        na = f["_n_atoms"][:]
        e = f["energy"][:]
    return [{"positions": pos[i, :int(na[i])], "numbers": nums[i, :int(na[i])],
             "energy": float(e[i])} for i in range(n_frames)]


def read_column_padded(path):
    with h5py.File(path, "r") as f:
        return f["energy"][:]


# ---------------------------------------------------------------------------
# Offset+flat (optimized v2: batch index read, then slice)
# ---------------------------------------------------------------------------


def write_flat(path, atom_counts, positions, numbers, energies, offsets):
    with h5py.File(path, "w") as f:
        all_pos = np.concatenate(positions, axis=0)
        all_nums = np.concatenate(numbers, axis=0)
        f.create_dataset("positions", data=all_pos, chunks=(1024, 3))
        f.create_dataset("numbers", data=all_nums, chunks=(1024,))
        f.create_dataset("offsets", data=offsets[:-1].astype(np.int64))
        f.create_dataset("lengths", data=atom_counts.astype(np.int32))
        f.create_dataset("energy", data=energies)


def read_single_flat_v1(path, indices):
    """v1: per-index HDF5 reads (potentially slow)."""
    rows = []
    with h5py.File(path, "r") as f:
        off_ds, len_ds = f["offsets"], f["lengths"]
        pos_ds, nums_ds = f["positions"], f["numbers"]
        e_ds = f["energy"]
        for i in indices:
            off = int(off_ds[i])
            length = int(len_ds[i])
            rows.append({
                "positions": pos_ds[off:off + length],
                "numbers": nums_ds[off:off + length],
                "energy": float(e_ds[i]),
            })
    return rows


def read_single_flat_v2(path, indices):
    """v2: batch-read index, then slice from disk per frame."""
    rows = []
    with h5py.File(path, "r") as f:
        # Batch-read ALL index metadata in one go
        all_offsets = f["offsets"][:]
        all_lengths = f["lengths"][:]
        all_energies = f["energy"][:]
        pos_ds = f["positions"]
        nums_ds = f["numbers"]
        for i in indices:
            off = int(all_offsets[i])
            length = int(all_lengths[i])
            rows.append({
                "positions": pos_ds[off:off + length],
                "numbers": nums_ds[off:off + length],
                "energy": float(all_energies[i]),
            })
    return rows


def read_single_flat_v3(path, indices):
    """v3: pre-read EVERYTHING into RAM, then slice numpy arrays."""
    with h5py.File(path, "r") as f:
        all_offsets = f["offsets"][:]
        all_lengths = f["lengths"][:]
        all_energies = f["energy"][:]
        all_pos = f["positions"][:]
        all_nums = f["numbers"][:]
    rows = []
    for i in indices:
        off = int(all_offsets[i])
        length = int(all_lengths[i])
        rows.append({
            "positions": all_pos[off:off + length],
            "numbers": all_nums[off:off + length],
            "energy": float(all_energies[i]),
        })
    return rows


def read_bulk_flat(path, n_frames):
    with h5py.File(path, "r") as f:
        offs = f["offsets"][:]
        lens = f["lengths"][:]
        pos = f["positions"][:]
        nums = f["numbers"][:]
        e = f["energy"][:]
    return [{"positions": pos[int(offs[i]):int(offs[i]) + int(lens[i])],
             "numbers": nums[int(offs[i]):int(offs[i]) + int(lens[i])],
             "energy": float(e[i])} for i in range(n_frames)]


def read_column_flat(path):
    with h5py.File(path, "r") as f:
        return f["energy"][:]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


def bench(name, write_fn, read_single_fn, read_bulk_fn, read_col_fn, path, n_frames, random_indices):
    t0 = time.perf_counter()
    write_fn()
    write_ms = (time.perf_counter() - t0) * 1000

    file_size_kb = os.path.getsize(path) / 1024

    seq = list(range(n_frames))
    t0 = time.perf_counter()
    read_single_fn(seq)
    read_single_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    read_bulk_fn()
    read_bulk_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    read_single_fn(random_indices)
    read_random_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    read_col_fn()
    read_column_ms = (time.perf_counter() - t0) * 1000

    return Result(name, write_ms, read_single_ms, read_bulk_ms, read_random_ms, read_column_ms, file_size_kb)


def print_results(results: list[Result], n_frames: int):
    names = [r.name for r in results]
    header = f"{'Operation':<25}" + "".join(f" {n:>16}" for n in names)
    print(header)
    print("-" * len(header))
    for label, attr in [
        ("Write", "write_ms"),
        (f"Read single x{n_frames}", "read_single_ms"),
        ("Read bulk (all)", "read_bulk_ms"),
        (f"Read random x{n_frames}", "read_random_ms"),
        ("Read column (energy)", "read_column_ms"),
        ("File size (KB)", "file_size_kb"),
    ]:
        vals = [getattr(r, attr) for r in results]
        line = f"  {label:<23}" + "".join(f" {v:>14.1f}ms" for v in vals)
        # Add speedup vs first (padded)
        if vals[0] > 0:
            speedups = [f" ({vals[0]/v:.2f}x)" if v > 0 else "" for v in vals[1:]]
            line += "  " + "  ".join(speedups)
        print(line)


def main():
    tmpdir = tempfile.mkdtemp(prefix="bench_h5md_v2_")
    try:
        for cfg in CONFIGS:
            atom_counts, positions, numbers, energies, offsets, random_indices = generate_data(cfg)
            total_atoms = int(atom_counts.sum())
            max_atoms = int(atom_counts.max())
            padding_pct = (max_atoms * cfg.n_frames - total_atoms) / (max_atoms * cfg.n_frames) * 100

            print(f"\n{'='*80}")
            print(f"{cfg.name} ({cfg.n_frames} frames, {total_atoms} total atoms)")
            print(f"  Atoms: min={atom_counts.min()}, max={max_atoms}, mean={atom_counts.mean():.1f}")
            print(f"  Padding overhead: {padding_pct:.1f}%")
            print()

            p_pad = os.path.join(tmpdir, f"padded_{cfg.min_atoms}_{cfg.max_atoms}.h5")
            p_flat = os.path.join(tmpdir, f"flat_{cfg.min_atoms}_{cfg.max_atoms}.h5")

            results = []

            # Padded
            results.append(bench(
                "Padded",
                lambda: write_padded(p_pad, atom_counts, positions, numbers, energies),
                lambda idx: read_single_padded(p_pad, idx),
                lambda: read_bulk_padded(p_pad, cfg.n_frames),
                lambda: read_column_padded(p_pad),
                p_pad, cfg.n_frames, random_indices,
            ))

            write_flat(p_flat, atom_counts, positions, numbers, energies, offsets)

            # Flat v1 (per-index)
            results.append(bench(
                "Flat v1 (per-idx)",
                lambda: None,  # already written
                lambda idx: read_single_flat_v1(p_flat, idx),
                lambda: read_bulk_flat(p_flat, cfg.n_frames),
                lambda: read_column_flat(p_flat),
                p_flat, cfg.n_frames, random_indices,
            ))

            # Flat v2 (batch index)
            results.append(bench(
                "Flat v2 (batch idx)",
                lambda: None,
                lambda idx: read_single_flat_v2(p_flat, idx),
                lambda: read_bulk_flat(p_flat, cfg.n_frames),
                lambda: read_column_flat(p_flat),
                p_flat, cfg.n_frames, random_indices,
            ))

            # Flat v3 (all in RAM)
            results.append(bench(
                "Flat v3 (all RAM)",
                lambda: None,
                lambda idx: read_single_flat_v3(p_flat, idx),
                lambda: read_bulk_flat(p_flat, cfg.n_frames),
                lambda: read_column_flat(p_flat),
                p_flat, cfg.n_frames, random_indices,
            ))

            print_results(results, cfg.n_frames)

            # Verify correctness
            bulk_pad = read_bulk_padded(p_pad, cfg.n_frames)
            bulk_flat = read_bulk_flat(p_flat, cfg.n_frames)
            for i in range(cfg.n_frames):
                np.testing.assert_array_almost_equal(
                    bulk_pad[i]["positions"], bulk_flat[i]["positions"])
            print(f"\n  Correctness: PASSED")

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
