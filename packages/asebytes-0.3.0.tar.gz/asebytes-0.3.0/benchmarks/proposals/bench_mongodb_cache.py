#!/usr/bin/env python3
"""Benchmark: MongoDB always-fetch _ensure_cache() vs TTL-guarded cache.

Current asebytes: Every get/len calls _ensure_cache() which does
find_one({"_id": "__meta__"}) fetching full metadata. For db[i]:
  facade len() → _ensure_cache() (RT1)
  get(i) → _ensure_cache() (RT2, redundant!)
  get(i) → find_one(sort_key) (RT3)
= 3 round trips per single read.

Proposed: Guard _ensure_cache() with TTL. Sort_keys only changes on
structural operations (extend/insert/delete), not on data updates.

Usage:
    uv run python benchmarks/proposals/bench_mongodb_cache.py

Requires a running MongoDB instance at localhost:27017.
"""

from __future__ import annotations

import os
import sys
import time
import uuid
from dataclasses import dataclass

import msgpack
import msgpack_numpy as m_np
import numpy as np

try:
    import pymongo
    from bson import Binary
except ImportError:
    print("ERROR: pymongo required. Install with: uv add pymongo")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Test data
# ---------------------------------------------------------------------------

N_FRAMES = 1000
rng = np.random.default_rng(42)
META_ID = "__meta__"

FRAMES: list[dict] = []
for i in range(N_FRAMES):
    n = rng.integers(3, 30)
    FRAMES.append({
        "arrays.positions": Binary(
            msgpack.packb(rng.standard_normal((n, 3)).astype(np.float64), default=m_np.encode)
        ),
        "arrays.numbers": Binary(
            msgpack.packb(rng.integers(1, 119, size=n).astype(np.int32), default=m_np.encode)
        ),
        "calc.energy": float(rng.standard_normal()),
        "info.tag": f"mol_{i}",
    })

RANDOM_INDICES = rng.integers(0, N_FRAMES, size=N_FRAMES).tolist()


@dataclass
class Result:
    name: str
    read_single_ms: float
    read_random_ms: float
    read_bulk_ms: float
    meta_fetches: int


# ---------------------------------------------------------------------------
# Approach 1: Always-fetch (current)
# ---------------------------------------------------------------------------


class AlwaysFetchBackend:
    """Simulates current _ensure_cache() behavior: fetch metadata every time."""

    def __init__(self, col: pymongo.collection.Collection) -> None:
        self._col = col
        self._sort_keys: list[int] | None = None
        self.meta_fetch_count = 0

    def _ensure_cache(self) -> None:
        """Always fetches metadata (current behavior)."""
        self._sort_keys = None  # invalidate every time
        meta = self._col.find_one({"_id": META_ID})
        self._sort_keys = meta.get("sort_keys", []) if meta else []
        self.meta_fetch_count += 1

    def __len__(self) -> int:
        self._ensure_cache()
        return len(self._sort_keys)

    def get(self, index: int) -> dict | None:
        self._ensure_cache()
        sk = self._sort_keys[index]
        doc = self._col.find_one({"_id": sk})
        return doc.get("data") if doc else None

    def get_many(self, indices: list[int]) -> list[dict | None]:
        self._ensure_cache()
        sks = [self._sort_keys[i] for i in indices]
        docs = {d["_id"]: d for d in self._col.find({"_id": {"$in": sks}})}
        return [docs.get(sk, {}).get("data") for sk in sks]


# ---------------------------------------------------------------------------
# Approach 2: TTL-guarded cache
# ---------------------------------------------------------------------------


class TTLCacheBackend:
    """Simulates proposed TTL cache: only re-fetch metadata when TTL expires."""

    def __init__(self, col: pymongo.collection.Collection, cache_ttl: float = 30.0) -> None:
        self._col = col
        self._sort_keys: list[int] | None = None
        self._cache_loaded_at: float = 0.0
        self._cache_ttl = cache_ttl
        self.meta_fetch_count = 0

    def _ensure_cache(self) -> None:
        now = time.monotonic()
        if self._sort_keys is not None and (now - self._cache_loaded_at) < self._cache_ttl:
            return  # within TTL
        meta = self._col.find_one({"_id": META_ID})
        self._sort_keys = meta.get("sort_keys", []) if meta else []
        self._cache_loaded_at = now
        self.meta_fetch_count += 1

    def __len__(self) -> int:
        self._ensure_cache()
        return len(self._sort_keys)

    def get(self, index: int) -> dict | None:
        self._ensure_cache()
        sk = self._sort_keys[index]
        doc = self._col.find_one({"_id": sk})
        return doc.get("data") if doc else None

    def get_many(self, indices: list[int]) -> list[dict | None]:
        self._ensure_cache()
        sks = [self._sort_keys[i] for i in indices]
        docs = {d["_id"]: d for d in self._col.find({"_id": {"$in": sks}})}
        return [docs.get(sk, {}).get("data") for sk in sks]


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------


def setup_collection(col: pymongo.collection.Collection) -> None:
    """Write test data in asebytes MongoDB format."""
    col.drop()
    sort_keys = list(range(N_FRAMES))
    # Metadata document
    col.insert_one({
        "_id": META_ID,
        "sort_keys": sort_keys,
        "count": N_FRAMES,
        "next_sort_key": N_FRAMES,
    })
    # Row documents
    docs = [{"_id": i, "data": FRAMES[i]} for i in range(N_FRAMES)]
    col.insert_many(docs)


# ---------------------------------------------------------------------------
# Benchmark
# ---------------------------------------------------------------------------


def bench_backend(name: str, backend) -> Result:
    backend.meta_fetch_count = 0

    # Single reads (simulates db[i] = len() + get())
    t0 = time.perf_counter()
    for i in range(N_FRAMES):
        n = len(backend)  # facade bounds check
        backend.get(i)
    read_single_ms = (time.perf_counter() - t0) * 1000
    single_fetches = backend.meta_fetch_count

    # Random reads
    backend.meta_fetch_count = 0
    t0 = time.perf_counter()
    for i in RANDOM_INDICES:
        n = len(backend)
        backend.get(i)
    read_random_ms = (time.perf_counter() - t0) * 1000

    # Bulk read
    backend.meta_fetch_count = 0
    t0 = time.perf_counter()
    backend.get_many(list(range(N_FRAMES)))
    read_bulk_ms = (time.perf_counter() - t0) * 1000
    bulk_fetches = backend.meta_fetch_count

    return Result(name, read_single_ms, read_random_ms, read_bulk_ms, single_fetches)


def main() -> None:
    mongo_uri = os.environ.get("MONGO_URI", "mongodb://root:example@localhost:27017")
    try:
        client = pymongo.MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
        client.admin.command("ping")
    except Exception:
        print("ERROR: Cannot connect to MongoDB at localhost:27017")
        print("Start MongoDB first: mongod --dbpath /tmp/mongodb")
        sys.exit(1)

    db_name = f"bench_cache_{uuid.uuid4().hex[:8]}"
    db = client[db_name]
    col = db["test"]

    try:
        setup_collection(col)

        print(f"MongoDB Cache Benchmark ({N_FRAMES} frames)")
        print()

        # Always-fetch (current)
        always = AlwaysFetchBackend(col)
        r_always = bench_backend("Always-fetch (current)", always)

        # TTL cache (proposed)
        ttl = TTLCacheBackend(col, cache_ttl=30.0)
        r_ttl = bench_backend("TTL cache (30s)", ttl)

        print(f"{'Operation':<30} {'Always-fetch':>15} {'TTL cache':>15} {'Speedup':>10}")
        print("-" * 72)
        for label, a, t in [
            ("Single seq x1000", r_always.read_single_ms, r_ttl.read_single_ms),
            ("Single random x1000", r_always.read_random_ms, r_ttl.read_random_ms),
            ("Bulk all 1000", r_always.read_bulk_ms, r_ttl.read_bulk_ms),
        ]:
            speedup = a / t if t > 0 else float("inf")
            print(f"  {label:<28} {a:>13.1f}ms {t:>13.1f}ms {speedup:>9.2f}x")

        print()
        print(f"  Metadata fetches (1000 single reads):")
        print(f"    Always-fetch: {r_always.meta_fetches} (2 per read: len() + get())")
        print(f"    TTL cache:    {r_ttl.meta_fetches} (1 initial, then cached for 30s)")
        print()

        # Also measure per-read latency
        per_always = r_always.read_single_ms / N_FRAMES
        per_ttl = r_ttl.read_single_ms / N_FRAMES
        saved = per_always - per_ttl
        print(f"  Per-read latency: {per_always:.3f}ms → {per_ttl:.3f}ms (saved {saved:.3f}ms)")
        print(f"  Round trips: 3/read → 1/read (saved 2 find_one(__meta__) calls)")
        print()
        print("Analysis:")
        print("  The TTL cache eliminates redundant metadata fetches for:")
        print("  1. len() → _ensure_cache() (facade bounds check)")
        print("  2. get() → _ensure_cache() (backend re-check)")
        print("  Both are redundant within a single operation sequence.")
        print()
        print("  sort_keys ONLY changes on structural ops (extend/insert/delete).")
        print("  Data ops (set/update/set_column) do NOT modify sort_keys.")
        print("  The 30s TTL handles concurrent writers: stale by at most 30s.")
        print()
        print("  Bug: set() currently calls _invalidate_cache() even though it")
        print("  doesn't change sort_keys. This should be removed.")

    finally:
        client.drop_database(db_name)
        client.close()


if __name__ == "__main__":
    main()
