#!/usr/bin/env python3
"""Benchmark: Zarr padding vs offset+flat for ragged data.

Compares two approaches for storing variable-length per-atom arrays in Zarr:

1. **Padding** (current asebytes): Each per-atom array padded to max_atoms.
   Separate `_n_atoms` array stores actual counts.

2. **Offset+flat**: Per-atom data in flat contiguous arrays. Separate offset
   and length arrays for O(1) random access.

Usage:
    uv run python benchmarks/proposals/bench_zarr_ragged.py
"""

from __future__ import annotations

import os
import shutil
import tempfile
import time
from dataclasses import dataclass

import numpy as np
import zarr

# ---------------------------------------------------------------------------
# Test data: simulate ragged molecules (variable atom counts)
# ---------------------------------------------------------------------------

N_FRAMES = 1000
rng = np.random.default_rng(42)
ATOM_COUNTS = rng.integers(3, 101, size=N_FRAMES)
MAX_ATOMS = int(ATOM_COUNTS.max())
TOTAL_ATOMS = int(ATOM_COUNTS.sum())
OFFSETS = np.zeros(N_FRAMES + 1, dtype=np.int64)
np.cumsum(ATOM_COUNTS, out=OFFSETS[1:])

POSITIONS = [rng.standard_normal((n, 3)).astype(np.float64) for n in ATOM_COUNTS]
NUMBERS = [rng.integers(1, 119, size=n).astype(np.int32) for n in ATOM_COUNTS]
ENERGIES = rng.standard_normal(N_FRAMES).astype(np.float64)

RANDOM_INDICES = rng.integers(0, N_FRAMES, size=N_FRAMES).tolist()


@dataclass
class Result:
    name: str
    write_ms: float
    read_single_ms: float
    read_bulk_ms: float
    read_random_ms: float
    read_column_ms: float
    dir_size_kb: float


def dir_size(path: str) -> float:
    total = 0
    for dirpath, _dirnames, filenames in os.walk(path):
        for f in filenames:
            total += os.path.getsize(os.path.join(dirpath, f))
    return total / 1024


# ---------------------------------------------------------------------------
# Approach 1: Padding (current asebytes Zarr pattern)
# ---------------------------------------------------------------------------


def write_padded(path: str) -> None:
    root = zarr.open_group(path, mode="w")
    pos = np.full((N_FRAMES, MAX_ATOMS, 3), np.nan, dtype=np.float64)
    nums = np.zeros((N_FRAMES, MAX_ATOMS), dtype=np.int32)
    for i, n in enumerate(ATOM_COUNTS):
        pos[i, :n] = POSITIONS[i]
        nums[i, :n] = NUMBERS[i]
    root.create_array("positions", data=pos, chunks=(64, MAX_ATOMS, 3))
    root.create_array("numbers", data=nums, chunks=(64, MAX_ATOMS))
    root.create_array("_n_atoms", data=ATOM_COUNTS.astype(np.int32), chunks=(256,))
    root.create_array("energy", data=ENERGIES, chunks=(256,))


def read_single_padded(path: str, indices: list[int]) -> list[dict]:
    root = zarr.open_group(path, mode="r")
    pos = root["positions"]
    nums = root["numbers"]
    n_atoms = root["_n_atoms"]
    energy = root["energy"]
    rows = []
    for i in indices:
        n = int(n_atoms[i])
        rows.append({
            "positions": np.array(pos[i, :n]),
            "numbers": np.array(nums[i, :n]),
            "energy": float(energy[i]),
        })
    return rows


def read_bulk_padded(path: str) -> list[dict]:
    root = zarr.open_group(path, mode="r")
    pos = np.array(root["positions"][:])
    nums = np.array(root["numbers"][:])
    n_atoms = np.array(root["_n_atoms"][:])
    energy = np.array(root["energy"][:])
    rows = []
    for i in range(N_FRAMES):
        n = int(n_atoms[i])
        rows.append({
            "positions": pos[i, :n],
            "numbers": nums[i, :n],
            "energy": float(energy[i]),
        })
    return rows


def read_column_padded(path: str) -> np.ndarray:
    root = zarr.open_group(path, mode="r")
    return np.array(root["energy"][:])


# ---------------------------------------------------------------------------
# Approach 2: Offset+flat
# ---------------------------------------------------------------------------


def write_flat(path: str) -> None:
    root = zarr.open_group(path, mode="w")
    all_pos = np.concatenate(POSITIONS, axis=0)
    all_nums = np.concatenate(NUMBERS, axis=0)
    root.create_array("positions", data=all_pos, chunks=(1024, 3))
    root.create_array("numbers", data=all_nums, chunks=(1024,))
    root.create_array("offsets", data=OFFSETS[:-1].astype(np.int64), chunks=(256,))
    root.create_array("lengths", data=ATOM_COUNTS.astype(np.int32), chunks=(256,))
    root.create_array("energy", data=ENERGIES, chunks=(256,))


def read_single_flat(path: str, indices: list[int]) -> list[dict]:
    root = zarr.open_group(path, mode="r")
    offsets = root["offsets"]
    lengths = root["lengths"]
    pos = root["positions"]
    nums = root["numbers"]
    energy = root["energy"]
    rows = []
    for i in indices:
        off = int(offsets[i])
        length = int(lengths[i])
        rows.append({
            "positions": np.array(pos[off : off + length]),
            "numbers": np.array(nums[off : off + length]),
            "energy": float(energy[i]),
        })
    return rows


def read_bulk_flat(path: str) -> list[dict]:
    root = zarr.open_group(path, mode="r")
    all_offsets = np.array(root["offsets"][:])
    all_lengths = np.array(root["lengths"][:])
    all_pos = np.array(root["positions"][:])
    all_nums = np.array(root["numbers"][:])
    all_energy = np.array(root["energy"][:])
    rows = []
    for i in range(N_FRAMES):
        off = int(all_offsets[i])
        length = int(all_lengths[i])
        rows.append({
            "positions": all_pos[off : off + length],
            "numbers": all_nums[off : off + length],
            "energy": float(all_energy[i]),
        })
    return rows


def read_column_flat(path: str) -> np.ndarray:
    root = zarr.open_group(path, mode="r")
    return np.array(root["energy"][:])


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


def bench(name: str, write_fn, read_single_fn, read_bulk_fn, read_col_fn, path: str) -> Result:
    t0 = time.perf_counter()
    write_fn(path)
    write_ms = (time.perf_counter() - t0) * 1000

    size_kb = dir_size(path)

    seq = list(range(N_FRAMES))
    t0 = time.perf_counter()
    read_single_fn(path, seq)
    read_single_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    read_bulk_fn(path)
    read_bulk_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    read_single_fn(path, RANDOM_INDICES)
    read_random_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    read_col_fn(path)
    read_column_ms = (time.perf_counter() - t0) * 1000

    return Result(name, write_ms, read_single_ms, read_bulk_ms, read_random_ms, read_column_ms, size_kb)


def verify_correctness(path_padded: str, path_flat: str) -> None:
    padded = read_bulk_padded(path_padded)
    flat = read_bulk_flat(path_flat)
    assert len(padded) == len(flat) == N_FRAMES
    for i in range(N_FRAMES):
        np.testing.assert_array_almost_equal(padded[i]["positions"], flat[i]["positions"])
        np.testing.assert_array_equal(padded[i]["numbers"], flat[i]["numbers"])
        assert abs(padded[i]["energy"] - flat[i]["energy"]) < 1e-12
    print("  Correctness: PASSED")


def main() -> None:
    tmpdir = tempfile.mkdtemp(prefix="bench_zarr_ragged_")
    try:
        path_padded = os.path.join(tmpdir, "padded.zarr")
        path_flat = os.path.join(tmpdir, "flat.zarr")

        print(f"Zarr Ragged Data Benchmark ({N_FRAMES} frames, {TOTAL_ATOMS} total atoms)")
        print(f"  Atom counts: min={ATOM_COUNTS.min()}, max={MAX_ATOMS}, "
              f"mean={ATOM_COUNTS.mean():.1f}")
        print(f"  Padding overhead: {(MAX_ATOMS * N_FRAMES - TOTAL_ATOMS) / (MAX_ATOMS * N_FRAMES) * 100:.1f}%")
        print()

        r_pad = bench("Padded (current)", write_padded, read_single_padded,
                       read_bulk_padded, read_column_padded, path_padded)
        r_flat = bench("Offset+flat", write_flat, read_single_flat,
                        read_bulk_flat, read_column_flat, path_flat)

        verify_correctness(path_padded, path_flat)
        print()

        header = f"{'Operation':<25} {'Padded':>12} {'Offset+flat':>12} {'Speedup':>10}"
        print(header)
        print("-" * len(header))
        for label, p, f in [
            ("Write", r_pad.write_ms, r_flat.write_ms),
            ("Read single x1000", r_pad.read_single_ms, r_flat.read_single_ms),
            ("Read bulk (all)", r_pad.read_bulk_ms, r_flat.read_bulk_ms),
            ("Read random x1000", r_pad.read_random_ms, r_flat.read_random_ms),
            ("Read column (energy)", r_pad.read_column_ms, r_flat.read_column_ms),
            ("Dir size (KB)", r_pad.dir_size_kb, r_flat.dir_size_kb),
        ]:
            speedup = p / f if f > 0 else float("inf")
            print(f"  {label:<23} {p:>10.1f}ms {f:>10.1f}ms {speedup:>9.2f}x")

        print()
        print("Strengths/Weaknesses:")
        print("  Padded:")
        print("    + Zarr fancy indexing works naturally (frame = row)")
        print("    + Column reads on scalar arrays are trivial")
        print("    - Massive storage waste with high max/avg atom ratio")
        print("    - Decompressing padded chunks wastes CPU")
        print("  Offset+flat:")
        print("    + Minimal storage footprint")
        print("    + Contiguous atom data = better compression")
        print("    - Random atom access requires per-frame offset lookup")
        print("    - No zarr fancy indexing on ragged dimension")
        print("    - Append requires updating offsets array")

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
