#!/usr/bin/env python3
"""Benchmark v2: Arrow IPC — isolate WHERE the time goes.

Is Arrow slow because of .as_py() conversion? Or is it the IPC format itself?
Test: Arrow in-memory table (no I/O) vs Arrow IPC mmap vs H5MD flat.

Usage:
    uv run python benchmarks/proposals/bench_arrow_ipc_v2.py
"""

from __future__ import annotations

import os
import shutil
import tempfile
import time

import h5py
import numpy as np
import pyarrow as pa

N_FRAMES = 1000
rng = np.random.default_rng(42)
ATOM_COUNTS = rng.integers(3, 101, size=N_FRAMES)
MAX_ATOMS = int(ATOM_COUNTS.max())

POSITIONS = [rng.standard_normal((n, 3)).astype(np.float64) for n in ATOM_COUNTS]
NUMBERS = [rng.integers(1, 119, size=n).astype(np.int32) for n in ATOM_COUNTS]
ENERGIES = rng.standard_normal(N_FRAMES).astype(np.float64)
RANDOM_INDICES = rng.integers(0, N_FRAMES, size=N_FRAMES).tolist()


def build_arrow_table():
    pos_list = [pos.tolist() for pos in POSITIONS]
    nums_list = [num.tolist() for num in NUMBERS]
    return pa.table({
        "positions": pa.array(pos_list, type=pa.list_(pa.list_(pa.float64(), 3))),
        "numbers": pa.array(nums_list, type=pa.list_(pa.int32())),
        "energy": pa.array(ENERGIES, type=pa.float64()),
    })


def bench_arrow_as_py(table, indices):
    """Arrow → .as_py() → np.array (current approach)."""
    pos_col = table.column("positions")
    nums_col = table.column("numbers")
    energy = table.column("energy").to_numpy()
    rows = []
    for i in indices:
        rows.append({
            "positions": np.array(pos_col[i].as_py(), dtype=np.float64),
            "numbers": np.array(nums_col[i].as_py(), dtype=np.int32),
            "energy": float(energy[i]),
        })
    return rows


def bench_arrow_to_pylist(table, indices):
    """Arrow → .to_pylist() once, then index Python lists."""
    pos_list = table.column("positions").to_pylist()
    nums_list = table.column("numbers").to_pylist()
    energy = table.column("energy").to_numpy()
    rows = []
    for i in indices:
        rows.append({
            "positions": np.array(pos_list[i], dtype=np.float64),
            "numbers": np.array(nums_list[i], dtype=np.int32),
            "energy": float(energy[i]),
        })
    return rows


def bench_arrow_flatten(table, indices):
    """Arrow → flatten to offsets+values, then slice numpy (Arrow-native way)."""
    pos_col = table.column("positions")
    nums_col = table.column("numbers")
    energy = table.column("energy").to_numpy()

    # For numbers (simple list<int32>): use offsets + values buffers
    nums_chunked = nums_col.combine_chunks()
    nums_offsets = nums_chunked.offsets.to_numpy()
    nums_values = nums_chunked.values.to_numpy()

    rows = []
    for i in indices:
        # numbers via offset buffer (zero-copy!)
        n_start = nums_offsets[i]
        n_end = nums_offsets[i + 1]
        num = nums_values[n_start:n_end]

        # positions: nested list, still need as_py()
        pos = np.array(pos_col[i].as_py(), dtype=np.float64)

        rows.append({
            "positions": pos,
            "numbers": num,
            "energy": float(energy[i]),
        })
    return rows


def bench_h5_flat_ram(path, indices):
    with h5py.File(path, "r") as f:
        offs = f["offsets"][:]
        lens = f["lengths"][:]
        energy = f["energy"][:]
        pos = f["positions"][:]
        nums = f["numbers"][:]
    rows = []
    for i in indices:
        o, l = int(offs[i]), int(lens[i])
        rows.append({
            "positions": pos[o:o + l],
            "numbers": nums[o:o + l],
            "energy": float(energy[i]),
        })
    return rows


def main():
    tmpdir = tempfile.mkdtemp(prefix="bench_arrow_v2_")

    # Build Arrow table (in-memory)
    table = build_arrow_table()

    # Write H5 flat
    p_flat = os.path.join(tmpdir, "flat.h5")
    offsets_arr = np.zeros(N_FRAMES + 1, dtype=np.int64)
    np.cumsum(ATOM_COUNTS, out=offsets_arr[1:])
    with h5py.File(p_flat, "w") as f:
        f.create_dataset("positions", data=np.concatenate(POSITIONS, axis=0), chunks=(1024, 3))
        f.create_dataset("numbers", data=np.concatenate(NUMBERS, axis=0), chunks=(1024,))
        f.create_dataset("offsets", data=offsets_arr[:-1])
        f.create_dataset("lengths", data=ATOM_COUNTS.astype(np.int32))
        f.create_dataset("energy", data=ENERGIES)

    # Write Arrow IPC
    p_arrow = os.path.join(tmpdir, "data.arrow")
    with pa.OSFile(p_arrow, "wb") as f:
        writer = pa.ipc.new_file(f, table.schema)
        writer.write_table(table)  # single batch
        writer.close()

    # Read Arrow IPC into memory
    source = pa.memory_map(p_arrow, "r")
    reader = pa.ipc.open_file(source)
    table_mmap = reader.read_all()

    print(f"Arrow IPC Bottleneck Analysis ({N_FRAMES} frames, 3-100 atoms)")
    print()

    seq = list(range(N_FRAMES))

    methods = [
        ("Arrow .as_py()", lambda idx: bench_arrow_as_py(table, idx)),
        ("Arrow .to_pylist()", lambda idx: bench_arrow_to_pylist(table, idx)),
        ("Arrow flatten+offsets", lambda idx: bench_arrow_flatten(table, idx)),
        ("Arrow IPC mmap .as_py()", lambda idx: bench_arrow_as_py(table_mmap, idx)),
        ("H5 flat (all RAM)", lambda idx: bench_h5_flat_ram(p_flat, idx)),
    ]

    print(f"  {'Method':<30} {'Seq x1000':>12} {'Random x1000':>14} {'Per-read':>10}")
    print(f"  {'-'*30} {'-'*12} {'-'*14} {'-'*10}")

    for name, fn in methods:
        t0 = time.perf_counter()
        fn(seq)
        t_seq = (time.perf_counter() - t0) * 1000

        t0 = time.perf_counter()
        fn(RANDOM_INDICES)
        t_rand = (time.perf_counter() - t0) * 1000

        print(f"  {name:<30} {t_seq:>10.1f}ms {t_rand:>12.1f}ms {t_seq/N_FRAMES:>8.3f}ms")

    print()
    print("Analysis:")
    print("  If Arrow in-memory is still slow → bottleneck is .as_py() / list conversion")
    print("  If Arrow in-memory is fast but IPC is slow → bottleneck is I/O")
    print("  H5 flat (all RAM) = pure numpy slicing (the theoretical optimum)")

    shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
