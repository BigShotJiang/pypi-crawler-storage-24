#!/usr/bin/env python3
"""Benchmark: MongoDB cache TTL sweep — what's the minimum useful TTL?

Tests TTL values from 0 (always-fetch) through 0.1s, 0.5s, 1s, 5s, 30s
to see where diminishing returns kick in.

Usage:
    uv run python benchmarks/proposals/bench_mongodb_cache_ttl.py

Requires a running MongoDB instance (default: root:example@localhost:27017).
"""

from __future__ import annotations

import os
import sys
import time
import uuid

import msgpack
import msgpack_numpy as m_np
import numpy as np

try:
    import pymongo
    from bson import Binary
except ImportError:
    print("ERROR: pymongo required")
    sys.exit(1)

N_FRAMES = 1000
rng = np.random.default_rng(42)
META_ID = "__meta__"

FRAMES: list[dict] = []
for i in range(N_FRAMES):
    n = rng.integers(3, 30)
    FRAMES.append({
        "arrays.positions": Binary(
            msgpack.packb(rng.standard_normal((n, 3)).astype(np.float64), default=m_np.encode)
        ),
        "calc.energy": float(rng.standard_normal()),
    })


class CacheBackend:
    def __init__(self, col, cache_ttl: float):
        self._col = col
        self._sort_keys: list[int] | None = None
        self._cache_loaded_at: float = 0.0
        self._cache_ttl = cache_ttl
        self.meta_fetch_count = 0

    def _ensure_cache(self):
        if self._cache_ttl > 0:
            now = time.monotonic()
            if self._sort_keys is not None and (now - self._cache_loaded_at) < self._cache_ttl:
                return
        else:
            self._sort_keys = None  # always invalidate

        meta = self._col.find_one({"_id": META_ID})
        self._sort_keys = meta.get("sort_keys", []) if meta else []
        self._cache_loaded_at = time.monotonic()
        self.meta_fetch_count += 1

    def __len__(self):
        self._ensure_cache()
        return len(self._sort_keys)

    def get(self, index):
        self._ensure_cache()
        sk = self._sort_keys[index]
        doc = self._col.find_one({"_id": sk})
        return doc.get("data") if doc else None


def setup(col):
    col.drop()
    sort_keys = list(range(N_FRAMES))
    col.insert_one({"_id": META_ID, "sort_keys": sort_keys, "count": N_FRAMES, "next_sort_key": N_FRAMES})
    col.insert_many([{"_id": i, "data": FRAMES[i]} for i in range(N_FRAMES)])


def bench_ttl(col, ttl: float) -> tuple[float, int]:
    backend = CacheBackend(col, ttl)
    t0 = time.perf_counter()
    for i in range(N_FRAMES):
        _ = len(backend)  # facade bounds check
        backend.get(i)
    elapsed = (time.perf_counter() - t0) * 1000
    return elapsed, backend.meta_fetch_count


def main():
    mongo_uri = os.environ.get("MONGO_URI", "mongodb://root:example@localhost:27017")
    try:
        client = pymongo.MongoClient(mongo_uri, serverSelectionTimeoutMS=2000)
        client.admin.command("ping")
    except Exception:
        print(f"ERROR: Cannot connect to MongoDB at {mongo_uri}")
        sys.exit(1)

    db_name = f"bench_ttl_{uuid.uuid4().hex[:8]}"
    col = client[db_name]["test"]

    try:
        setup(col)

        print(f"MongoDB Cache TTL Sweep ({N_FRAMES} single reads)")
        print()

        ttls = [0.0, 0.001, 0.01, 0.1, 0.5, 1.0, 5.0, 30.0]

        print(f"  {'TTL':>8}  {'Time (ms)':>10}  {'Meta fetches':>13}  {'Per-read (ms)':>13}  {'vs always':>10}")
        print(f"  {'---':>8}  {'---':>10}  {'---':>13}  {'---':>13}  {'---':>10}")

        baseline = None
        for ttl in ttls:
            elapsed, fetches = bench_ttl(col, ttl)
            per_read = elapsed / N_FRAMES
            if baseline is None:
                baseline = elapsed
            speedup = baseline / elapsed if elapsed > 0 else float("inf")
            label = "always" if ttl == 0 else f"{ttl}s"
            print(f"  {label:>8}  {elapsed:>10.1f}  {fetches:>13}  {per_read:>13.3f}  {speedup:>9.2f}x")

        print()
        print("Analysis:")
        print("  Even 1ms TTL should show massive improvement because it caches")
        print("  across the len() + get() pair within a single db[i] access.")
        print("  The key win is eliminating redundant _ensure_cache() calls,")
        print("  not surviving long periods between operations.")

    finally:
        client.drop_database(db_name)
        client.close()


if __name__ == "__main__":
    main()
