# Storage Proposal Benchmark Results

> Run on: macOS (Apple Silicon), 1000 frames

## Summary Table

| Proposal | Verdict | Key Metric | Worth Pursuing? |
|----------|---------|------------|-----------------|
| **MongoDB TTL cache** | **DO IT** | 3.5x faster single reads | Yes - even 1ms TTL gives 2.6x |
| **Redis Lua bounds check** | **DO IT** | 1.9x faster single reads | Yes - easy win, 2 RT → 1 RT |
| **H5MD offset+flat** | **CONSIDER** | 2-24x faster random (extreme ragged) | Yes for extreme ragged; v1 benchmark was flawed |
| **Redis single blob** | **NO** | 1.1x read, 0.4x column | Column reads regress, partial updates break |
| **Zarr offset+flat** | **NO** | 0.8x reads, same disk size | No benefit at all |

---

## 1. MongoDB: Always-fetch vs TTL Cache

**Verdict: DO IT**

```
Operation                         Always-fetch       TTL cache    Speedup
  Single seq x1000                     878.8ms         242.6ms      3.62x
  Single random x1000                  841.7ms         239.4ms      3.52x
  Bulk all 1000                          7.0ms           5.4ms      1.29x
```

### TTL Sweep — how short can we go?

```
     TTL   Time (ms)   Meta fetches  Per-read (ms)   vs always
  always       933.5           2000          0.934       1.00x
  0.001s       357.2            241          0.357       2.61x
   0.01s       271.3             26          0.271       3.44x
    0.1s       251.2              3          0.251       3.72x
    0.5s       271.8              1          0.272       3.43x
    1.0s       267.6              1          0.268       3.49x
   30.0s       262.8              1          0.263       3.55x
```

**Key finding:** Even **1ms TTL** gives **2.6x speedup** because the real win is caching across the `len()` + `get()` pair within a single `db[i]` access. The TTL just needs to survive the microseconds between those two calls. Anything >= 0.1s effectively reduces to 1 metadata fetch for the entire 1000-read loop.

**Recommendation:** Use a short TTL (1-5s) instead of 30s. This gives the same performance benefit while reducing staleness window for concurrent writers.

- Also fix: `set()` incorrectly invalidates cache (bug — it doesn't change sort_keys)

## 2. Redis: Lua Bounds Check (2 RT → 1 RT)

**Verdict: DO IT**

```
Operation                       2 RT (current)  1 RT (proposed)    Speedup
  Single seq x1000                     340.1ms          183.7ms      1.85x
  Single random x1000                  374.0ms          185.5ms      2.02x
  Bulk all 1000                         10.8ms            6.7ms      1.61x
```

- Per-read: **0.340ms → 0.184ms** (saved 0.156ms = 1 LLEN round trip)
- The Lua script already does LLEN + bounds check internally
- Implementation: Skip facade `len()` call, catch `IndexError` from Lua
- Risk: None — Lua scripts already handle all edge cases

## 3. H5MD: Padding vs Offset+Flat (corrected benchmark)

**Verdict: REVISITED — offset+flat IS faster when properly implemented**

v1 benchmark was unfair: flat single-reads did per-index HDF5 lookups for the index dataset. v2 tests three optimization levels:

### Moderate ragged (3-100 atoms, 48% padding overhead)

```
Operation                    Padded  Flat v1(naive)  Flat v2(batch idx)  Flat v3(all RAM)
  Read single x1000           7.6ms          6.8ms              3.6ms            1.3ms
  Read random x1000          10.1ms          7.1ms              4.2ms            1.1ms
  File size (KB)           2821.0          1455.8             1455.8           1455.8
```

### Extreme ragged (3-500 atoms, 49% padding overhead)

```
Operation                    Padded  Flat v1(naive)  Flat v2(batch idx)  Flat v3(all RAM)
  Read single x1000          10.5ms          9.5ms              6.6ms            3.0ms
  Read random x1000          55.6ms         12.0ms              8.5ms            2.3ms
  File size (KB)          14021.0          6994.8             6994.8           6994.8
```

### Mild ragged (80-100 atoms, 10% padding overhead)

```
Operation                    Padded  Flat v1(naive)  Flat v2(batch idx)  Flat v3(all RAM)
  Read single x1000           6.5ms          7.2ms              4.5ms            1.5ms
  Read random x1000           9.9ms          8.7ms              5.5ms            1.3ms
  File size (KB)           2821.0          2501.0             2501.0           2501.0
```

**Key findings:**
- v1 (naive per-index) was what the original benchmark tested — roughly tied with padded
- v2 (batch-read index into RAM, slice from disk): **1.4-6.6x faster** than padded
- v3 (pre-read everything into RAM): **5.8-24x faster** than padded for random access
- Extreme ragged (3-500): padded random access is **55.6ms** vs flat v3 **2.3ms** = **24x faster**
- Even mild ragged (80-100): flat v2 is still 1.4-1.8x faster

**Why:** Padded arrays at 500 max_atoms means reading (500, 3) = 12KB per frame even when actual atoms = 3. Flat arrays read exactly the atoms needed.

**Conclusion:** Offset+flat is genuinely better for H5MD, especially with large max_atoms. The original benchmark's conclusion was wrong because it used a naive read strategy.

## 4. Redis: Multi-field HASH vs Single Blob

**Verdict: Keep current HASH approach**

```
Operation                     Multi-HASH    Single blob    Speedup
  Write                          28.1ms         12.3ms      2.29x
  Read single x1000             200.8ms        183.7ms      1.09x
  Read bulk (pipelined)          13.8ms          9.7ms      1.42x
  Read random x1000             191.2ms        170.4ms      1.12x
  Read column (energy)            3.9ms          9.1ms      0.43x ← WORSE
  Memory (KB)                  1501.2          1187.9        1.26x
```

- Single blob is ~10% faster for full-row reads, ~26% less memory
- But column reads are **2.3x slower** (must deserialize entire blob)
- Partial updates impossible with blob (read-modify-write required)
- **Keep HASH**: column access and partial updates are core features

## 5. Zarr: Padding vs Offset+Flat

**Verdict: NO BENEFIT**

```
Operation                       Padded    Offset+flat    Speedup
  Write                         24.7ms         45.1ms      0.55x
  Read single x1000           2164.2ms       2611.7ms      0.83x
  Read bulk (all)               11.9ms         25.1ms      0.47x
  Read random x1000           2180.9ms       2619.3ms      0.83x
  Read column (energy)           1.9ms          1.8ms      1.04x
  Dir size (KB)               1252.6          1251.4        1.00x (same!)
```

- Same disk size (Blosc compression neutralizes padding)
- Everything is slower with offset+flat
- Zarr's per-chunk decompression dominates — the padding bytes compress to almost nothing
- No reason to change the approach

---

## Priority Ranking

1. **MongoDB TTL cache** — 3.5x improvement, ~10 lines, use 1-5s TTL
2. **Redis Lua bounds check** — 1.9x improvement, facade change only
3. **H5MD offset+flat** — genuinely faster (2-24x for random), worth pursuing for a v2 backend
4. **Redis single blob** — not recommended (column reads regress)
5. **Zarr offset+flat** — no benefit (compression neutralizes padding)
