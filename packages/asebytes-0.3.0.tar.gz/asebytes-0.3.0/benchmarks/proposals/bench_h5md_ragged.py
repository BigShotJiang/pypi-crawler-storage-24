#!/usr/bin/env python3
"""Benchmark: H5MD padding vs offset+flat (equitrain-style) for ragged data.

Compares two approaches for storing variable-length per-atom arrays in HDF5:

1. **Padding** (current asebytes): Each per-atom array padded to max_atoms with
   NaN/0. A separate `_n_atoms` dataset stores actual counts for slicing.

2. **Offset+flat** (equitrain-style): Per-atom data stored in flat contiguous
   arrays (total_atoms, ...). A compound-dtype index dataset stores
   (offset, length) per frame for O(1) random access.

Usage:
    uv run python benchmarks/proposals/bench_h5md_ragged.py
"""

from __future__ import annotations

import os
import shutil
import tempfile
import time
from dataclasses import dataclass

import h5py
import numpy as np

# ---------------------------------------------------------------------------
# Test data: simulate ragged molecules (variable atom counts)
# ---------------------------------------------------------------------------

N_FRAMES = 1000
rng = np.random.default_rng(42)
# Atom counts: 3-100 atoms per frame (realistic molecular range)
ATOM_COUNTS = rng.integers(3, 101, size=N_FRAMES)
MAX_ATOMS = int(ATOM_COUNTS.max())
TOTAL_ATOMS = int(ATOM_COUNTS.sum())
# Precompute offsets
OFFSETS = np.zeros(N_FRAMES + 1, dtype=np.int64)
np.cumsum(ATOM_COUNTS, out=OFFSETS[1:])

# Generate per-frame data
POSITIONS = [rng.standard_normal((n, 3)).astype(np.float64) for n in ATOM_COUNTS]
NUMBERS = [rng.integers(1, 119, size=n).astype(np.int32) for n in ATOM_COUNTS]
ENERGIES = rng.standard_normal(N_FRAMES).astype(np.float64)

RANDOM_INDICES = rng.integers(0, N_FRAMES, size=N_FRAMES).tolist()


@dataclass
class Result:
    name: str
    write_ms: float
    read_single_ms: float
    read_bulk_ms: float
    read_random_ms: float
    read_column_ms: float
    file_size_kb: float


# ---------------------------------------------------------------------------
# Approach 1: Padding (current asebytes H5MD pattern)
# ---------------------------------------------------------------------------


def write_padded(path: str) -> None:
    with h5py.File(path, "w") as f:
        g = f.create_group("particles/default")
        # Padded arrays
        pos = np.full((N_FRAMES, MAX_ATOMS, 3), np.nan, dtype=np.float64)
        nums = np.zeros((N_FRAMES, MAX_ATOMS), dtype=np.int32)
        for i, n in enumerate(ATOM_COUNTS):
            pos[i, :n] = POSITIONS[i]
            nums[i, :n] = NUMBERS[i]
        g.create_dataset("positions/value", data=pos, chunks=(64, MAX_ATOMS, 3))
        g.create_dataset("numbers/value", data=nums, chunks=(64, MAX_ATOMS))
        # Metadata
        f.create_dataset("asebytes/default/_n_atoms", data=ATOM_COUNTS.astype(np.int32))
        f.create_dataset("observables/default/calc.energy/value", data=ENERGIES)


def read_single_padded(path: str, indices: list[int]) -> list[dict]:
    rows = []
    with h5py.File(path, "r") as f:
        pos_ds = f["particles/default/positions/value"]
        nums_ds = f["particles/default/numbers/value"]
        n_atoms_ds = f["asebytes/default/_n_atoms"]
        energy_ds = f["observables/default/calc.energy/value"]
        for i in indices:
            n = int(n_atoms_ds[i])
            rows.append({
                "positions": pos_ds[i, :n],
                "numbers": nums_ds[i, :n],
                "energy": float(energy_ds[i]),
            })
    return rows


def read_bulk_padded(path: str) -> list[dict]:
    rows = []
    with h5py.File(path, "r") as f:
        pos = f["particles/default/positions/value"][:]
        nums = f["particles/default/numbers/value"][:]
        n_atoms = f["asebytes/default/_n_atoms"][:]
        energy = f["observables/default/calc.energy/value"][:]
        for i in range(N_FRAMES):
            n = int(n_atoms[i])
            rows.append({
                "positions": pos[i, :n],
                "numbers": nums[i, :n],
                "energy": float(energy[i]),
            })
    return rows


def read_column_padded(path: str) -> np.ndarray:
    with h5py.File(path, "r") as f:
        return f["observables/default/calc.energy/value"][:]


# ---------------------------------------------------------------------------
# Approach 2: Offset+flat (equitrain-style)
# ---------------------------------------------------------------------------


def write_flat(path: str) -> None:
    with h5py.File(path, "w") as f:
        # Flat contiguous arrays
        all_pos = np.concatenate(POSITIONS, axis=0)  # (total_atoms, 3)
        all_nums = np.concatenate(NUMBERS, axis=0)  # (total_atoms,)
        f.create_dataset("positions", data=all_pos, chunks=(1024, 3))
        f.create_dataset("numbers", data=all_nums, chunks=(1024,))
        # Index: compound dtype with offset, length, energy
        dt = np.dtype([
            ("offset", np.int64),
            ("length", np.int32),
            ("energy", np.float64),
        ])
        index = np.zeros(N_FRAMES, dtype=dt)
        index["offset"] = OFFSETS[:-1]
        index["length"] = ATOM_COUNTS
        index["energy"] = ENERGIES
        f.create_dataset("index", data=index, chunks=(256,))


def read_single_flat(path: str, indices: list[int]) -> list[dict]:
    rows = []
    with h5py.File(path, "r") as f:
        idx_ds = f["index"]
        pos_ds = f["positions"]
        nums_ds = f["numbers"]
        for i in indices:
            rec = idx_ds[i]
            off, length = int(rec["offset"]), int(rec["length"])
            rows.append({
                "positions": pos_ds[off : off + length],
                "numbers": nums_ds[off : off + length],
                "energy": float(rec["energy"]),
            })
    return rows


def read_bulk_flat(path: str) -> list[dict]:
    rows = []
    with h5py.File(path, "r") as f:
        index = f["index"][:]
        pos = f["positions"][:]
        nums = f["numbers"][:]
        for i in range(N_FRAMES):
            off, length = int(index[i]["offset"]), int(index[i]["length"])
            rows.append({
                "positions": pos[off : off + length],
                "numbers": nums[off : off + length],
                "energy": float(index[i]["energy"]),
            })
    return rows


def read_column_flat(path: str) -> np.ndarray:
    with h5py.File(path, "r") as f:
        return f["index"]["energy"]


# ---------------------------------------------------------------------------
# Benchmark runner
# ---------------------------------------------------------------------------


def bench(name: str, write_fn, read_single_fn, read_bulk_fn, read_col_fn, path: str) -> Result:
    # Write
    t0 = time.perf_counter()
    write_fn(path)
    write_ms = (time.perf_counter() - t0) * 1000

    file_size_kb = os.path.getsize(path) / 1024

    # Read single (sequential, all frames)
    seq = list(range(N_FRAMES))
    t0 = time.perf_counter()
    read_single_fn(path, seq)
    read_single_ms = (time.perf_counter() - t0) * 1000

    # Read bulk (all at once)
    t0 = time.perf_counter()
    read_bulk_fn(path)
    read_bulk_ms = (time.perf_counter() - t0) * 1000

    # Read random access
    t0 = time.perf_counter()
    read_single_fn(path, RANDOM_INDICES)
    read_random_ms = (time.perf_counter() - t0) * 1000

    # Column read (energy)
    t0 = time.perf_counter()
    read_col_fn(path)
    read_column_ms = (time.perf_counter() - t0) * 1000

    return Result(name, write_ms, read_single_ms, read_bulk_ms, read_random_ms, read_column_ms, file_size_kb)


def verify_correctness(path_padded: str, path_flat: str) -> None:
    """Verify both approaches produce identical data."""
    padded_rows = read_bulk_padded(path_padded)
    flat_rows = read_bulk_flat(path_flat)
    assert len(padded_rows) == len(flat_rows) == N_FRAMES
    for i in range(N_FRAMES):
        p, f = padded_rows[i], flat_rows[i]
        np.testing.assert_array_almost_equal(p["positions"], f["positions"])
        np.testing.assert_array_equal(p["numbers"], f["numbers"])
        assert abs(p["energy"] - f["energy"]) < 1e-12
    print("  Correctness: PASSED (all frames match)")


def main() -> None:
    tmpdir = tempfile.mkdtemp(prefix="bench_h5md_ragged_")
    try:
        path_padded = os.path.join(tmpdir, "padded.h5")
        path_flat = os.path.join(tmpdir, "flat.h5")

        print(f"H5MD Ragged Data Benchmark ({N_FRAMES} frames, {TOTAL_ATOMS} total atoms)")
        print(f"  Atom counts: min={ATOM_COUNTS.min()}, max={MAX_ATOMS}, "
              f"mean={ATOM_COUNTS.mean():.1f}")
        print(f"  Padding overhead: {(MAX_ATOMS * N_FRAMES - TOTAL_ATOMS) / (MAX_ATOMS * N_FRAMES) * 100:.1f}%")
        print()

        r_pad = bench("Padded (current)", write_padded, read_single_padded,
                       read_bulk_padded, read_column_padded, path_padded)
        r_flat = bench("Offset+flat", write_flat, read_single_flat,
                        read_bulk_flat, read_column_flat, path_flat)

        verify_correctness(path_padded, path_flat)
        print()

        # Results table
        header = f"{'Operation':<25} {'Padded':>12} {'Offset+flat':>12} {'Speedup':>10}"
        print(header)
        print("-" * len(header))
        for label, p, f in [
            ("Write", r_pad.write_ms, r_flat.write_ms),
            ("Read single x1000", r_pad.read_single_ms, r_flat.read_single_ms),
            ("Read bulk (all)", r_pad.read_bulk_ms, r_flat.read_bulk_ms),
            ("Read random x1000", r_pad.read_random_ms, r_flat.read_random_ms),
            ("Read column (energy)", r_pad.read_column_ms, r_flat.read_column_ms),
            ("File size (KB)", r_pad.file_size_kb, r_flat.file_size_kb),
        ]:
            speedup = p / f if f > 0 else float("inf")
            print(f"  {label:<23} {p:>10.1f}ms {f:>10.1f}ms {speedup:>9.2f}x")

        print()
        print("Strengths/Weaknesses:")
        print("  Padded:")
        print("    + Simple indexing (frame i = row i in all datasets)")
        print("    + Column reads trivial (single dataset slice)")
        print("    - Wastes space proportional to max_atoms/avg_atoms ratio")
        print("    - Per-atom reads always fetch max_atoms, then slice")
        print("  Offset+flat:")
        print("    + Minimal storage (no padding waste)")
        print("    + Contiguous atom data = better cache locality")
        print("    - Non-contiguous atom slicing for random access")
        print("    - Column reads for scalar require compound dtype access")
        print("    - Cannot resize individual frames (append-only)")

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
