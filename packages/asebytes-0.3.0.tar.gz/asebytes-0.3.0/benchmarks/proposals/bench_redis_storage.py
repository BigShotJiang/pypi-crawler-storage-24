#!/usr/bin/env python3
"""Benchmark: Redis multi-field HASH vs single msgpack blob per row.

Compares two Redis storage approaches:

1. **Multi-field HASH** (current asebytes): Each row = Redis HASH with one
   field per data key. Per-field access via HGET, full row via HGETALL.

2. **Single blob**: Each row = single Redis STRING containing one msgpack
   blob. Full row = GET+unpack, per-field = GET+unpack+extract.

Usage:
    uv run python benchmarks/proposals/bench_redis_storage.py

Requires a running Redis instance at localhost:6379.
"""

from __future__ import annotations

import sys
import time
import uuid
from dataclasses import dataclass

import msgpack
import msgpack_numpy as m
import numpy as np

try:
    import redis as redis_mod
except ImportError:
    print("ERROR: redis package required. Install with: uv add redis")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Test data: simulate molecular frames
# ---------------------------------------------------------------------------

N_FRAMES = 1000
rng = np.random.default_rng(42)
ATOM_COUNTS = rng.integers(3, 30, size=N_FRAMES)

FRAMES: list[dict[str, object]] = []
for n in ATOM_COUNTS:
    FRAMES.append({
        "arrays.positions": rng.standard_normal((n, 3)).astype(np.float64),
        "arrays.numbers": rng.integers(1, 119, size=n).astype(np.int32),
        "calc.energy": float(rng.standard_normal()),
        "calc.forces": rng.standard_normal((n, 3)).astype(np.float64),
        "info.tag": f"mol_{rng.integers(0, 1000)}",
    })

RANDOM_INDICES = rng.integers(0, N_FRAMES, size=N_FRAMES).tolist()


@dataclass
class Result:
    name: str
    write_ms: float
    read_single_ms: float
    read_bulk_ms: float
    read_random_ms: float
    read_column_ms: float
    memory_kb: float


# ---------------------------------------------------------------------------
# Approach 1: Multi-field HASH (current)
# ---------------------------------------------------------------------------


class MultiFieldStore:
    def __init__(self, r: redis_mod.Redis, prefix: str) -> None:
        self._r = r
        self._prefix = prefix

    def _row_key(self, i: int) -> str:
        return f"{self._prefix}:row:{i}"

    def write_all(self, frames: list[dict]) -> None:
        pipe = self._r.pipeline(transaction=False)
        for i, frame in enumerate(frames):
            rk = self._row_key(i)
            encoded = {
                k.encode(): msgpack.packb(v, default=m.encode)
                for k, v in frame.items()
            }
            pipe.hset(rk, mapping=encoded)
        pipe.execute()
        self._r.set(f"{self._prefix}:count", len(frames))

    def get_single(self, i: int) -> dict:
        raw = self._r.hgetall(self._row_key(i))
        return {k.decode(): msgpack.unpackb(v, object_hook=m.decode) for k, v in raw.items()}

    def get_many(self, indices: list[int]) -> list[dict]:
        pipe = self._r.pipeline(transaction=False)
        for i in indices:
            pipe.hgetall(self._row_key(i))
        results = pipe.execute()
        return [
            {k.decode(): msgpack.unpackb(v, object_hook=m.decode) for k, v in raw.items()}
            for raw in results
        ]

    def get_column(self, key: str, indices: list[int]) -> list:
        pipe = self._r.pipeline(transaction=False)
        kb = key.encode()
        for i in indices:
            pipe.hget(self._row_key(i), kb)
        results = pipe.execute()
        return [msgpack.unpackb(v, object_hook=m.decode) for v in results if v is not None]

    def cleanup(self) -> None:
        keys = self._r.keys(f"{self._prefix}:*")
        if keys:
            self._r.delete(*keys)

    def memory_usage(self) -> float:
        total = 0
        for i in range(N_FRAMES):
            usage = self._r.memory_usage(self._row_key(i))
            if usage:
                total += usage
        return total / 1024


# ---------------------------------------------------------------------------
# Approach 2: Single blob per row
# ---------------------------------------------------------------------------


class SingleBlobStore:
    def __init__(self, r: redis_mod.Redis, prefix: str) -> None:
        self._r = r
        self._prefix = prefix

    def _row_key(self, i: int) -> str:
        return f"{self._prefix}:row:{i}"

    def write_all(self, frames: list[dict]) -> None:
        pipe = self._r.pipeline(transaction=False)
        for i, frame in enumerate(frames):
            blob = msgpack.packb(frame, default=m.encode)
            pipe.set(self._row_key(i), blob)
        pipe.execute()
        self._r.set(f"{self._prefix}:count", len(frames))

    def get_single(self, i: int) -> dict:
        blob = self._r.get(self._row_key(i))
        return msgpack.unpackb(blob, object_hook=m.decode)

    def get_many(self, indices: list[int]) -> list[dict]:
        pipe = self._r.pipeline(transaction=False)
        for i in indices:
            pipe.get(self._row_key(i))
        results = pipe.execute()
        return [msgpack.unpackb(blob, object_hook=m.decode) for blob in results]

    def get_column(self, key: str, indices: list[int]) -> list:
        """Must fetch full blob and extract single field (no HGET equivalent)."""
        pipe = self._r.pipeline(transaction=False)
        for i in indices:
            pipe.get(self._row_key(i))
        results = pipe.execute()
        return [msgpack.unpackb(blob, object_hook=m.decode)[key] for blob in results]

    def cleanup(self) -> None:
        keys = self._r.keys(f"{self._prefix}:*")
        if keys:
            self._r.delete(*keys)

    def memory_usage(self) -> float:
        total = 0
        for i in range(N_FRAMES):
            usage = self._r.memory_usage(self._row_key(i))
            if usage:
                total += usage
        return total / 1024


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


def bench_store(name: str, store) -> Result:
    # Write
    t0 = time.perf_counter()
    store.write_all(FRAMES)
    write_ms = (time.perf_counter() - t0) * 1000

    # Read single (sequential)
    t0 = time.perf_counter()
    for i in range(N_FRAMES):
        store.get_single(i)
    read_single_ms = (time.perf_counter() - t0) * 1000

    # Read bulk (pipelined)
    t0 = time.perf_counter()
    store.get_many(list(range(N_FRAMES)))
    read_bulk_ms = (time.perf_counter() - t0) * 1000

    # Random access
    t0 = time.perf_counter()
    for i in RANDOM_INDICES:
        store.get_single(i)
    read_random_ms = (time.perf_counter() - t0) * 1000

    # Column read (energy only)
    t0 = time.perf_counter()
    store.get_column("calc.energy", list(range(N_FRAMES)))
    read_column_ms = (time.perf_counter() - t0) * 1000

    # Memory
    mem_kb = store.memory_usage()

    return Result(name, write_ms, read_single_ms, read_bulk_ms, read_random_ms, read_column_ms, mem_kb)


def verify_correctness(store_a, store_b) -> None:
    for i in [0, N_FRAMES // 2, N_FRAMES - 1]:
        a = store_a.get_single(i)
        b = store_b.get_single(i)
        assert set(a.keys()) == set(b.keys()), f"Key mismatch at {i}"
        for k in a:
            if isinstance(a[k], np.ndarray):
                np.testing.assert_array_almost_equal(a[k], b[k])
            else:
                assert a[k] == b[k], f"Value mismatch at {i}.{k}"
    print("  Correctness: PASSED")


def main() -> None:
    try:
        r = redis_mod.Redis(host="localhost", port=6379, db=0, decode_responses=False)
        r.ping()
    except redis_mod.ConnectionError:
        print("ERROR: Cannot connect to Redis at localhost:6379")
        print("Start Redis first: redis-server")
        sys.exit(1)

    uid = uuid.uuid4().hex[:8]
    prefix_hash = f"bench_hash_{uid}"
    prefix_blob = f"bench_blob_{uid}"

    store_hash = MultiFieldStore(r, prefix_hash)
    store_blob = SingleBlobStore(r, prefix_blob)

    try:
        print(f"Redis Storage Benchmark ({N_FRAMES} frames, 5 fields/frame)")
        print(f"  Atom counts: min={ATOM_COUNTS.min()}, max={ATOM_COUNTS.max()}, "
              f"mean={ATOM_COUNTS.mean():.1f}")
        print()

        r_hash = bench_store("Multi-field HASH", store_hash)
        r_blob = bench_store("Single blob", store_blob)

        verify_correctness(store_hash, store_blob)
        print()

        header = f"{'Operation':<25} {'Multi-HASH':>12} {'Single blob':>12} {'Speedup':>10}"
        print(header)
        print("-" * len(header))
        for label, h, b in [
            ("Write", r_hash.write_ms, r_blob.write_ms),
            ("Read single x1000", r_hash.read_single_ms, r_blob.read_single_ms),
            ("Read bulk (pipelined)", r_hash.read_bulk_ms, r_blob.read_bulk_ms),
            ("Read random x1000", r_hash.read_random_ms, r_blob.read_random_ms),
            ("Read column (energy)", r_hash.read_column_ms, r_blob.read_column_ms),
            ("Memory (KB)", r_hash.memory_kb, r_blob.memory_kb),
        ]:
            speedup = h / b if b > 0 else float("inf")
            print(f"  {label:<23} {h:>10.1f}ms {b:>10.1f}ms {speedup:>9.2f}x")

        print()
        print("Strengths/Weaknesses:")
        print("  Multi-field HASH (current):")
        print("    + Per-field access via HGET (column reads)")
        print("    + Partial updates via HSET (no full rewrite)")
        print("    + Lua scripts can access individual fields")
        print("    - Per-field msgpack overhead")
        print("    - HASH metadata overhead per field")
        print("  Single blob:")
        print("    + Lower memory (no per-field HASH overhead)")
        print("    + Simpler write (one SET per row)")
        print("    - Column reads must deserialize full blob")
        print("    - Partial updates require read-modify-write")
        print("    - No per-field Lua access")

    finally:
        store_hash.cleanup()
        store_blob.cleanup()


if __name__ == "__main__":
    main()
