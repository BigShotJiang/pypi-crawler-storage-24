#!/usr/bin/env python3
"""Benchmark: Arrow IPC (mmap) vs H5MD padding vs H5MD offset+flat.

Arrow IPC Random Access format with memory-mapped reads — the format
that hundreds of engineers have optimized for exactly this problem.

Tests: Can Arrow's ListType handle ragged molecular data with
zero-copy mmap reads faster than our HDF5 approaches?

Usage:
    uv run python benchmarks/proposals/bench_arrow_ipc.py
"""

from __future__ import annotations

import os
import shutil
import tempfile
import time
from dataclasses import dataclass

import h5py
import numpy as np
import pyarrow as pa

# ---------------------------------------------------------------------------
# Test configs
# ---------------------------------------------------------------------------

N_FRAMES = 1000
CONFIGS = [
    ("Moderate ragged (3-100)", 3, 100),
    ("Extreme ragged (3-500)", 3, 500),
    ("Uniform (50 atoms)", 50, 50),
]


@dataclass
class Result:
    name: str
    write_ms: float
    read_single_ms: float
    read_bulk_ms: float
    read_random_ms: float
    read_column_ms: float
    file_size_kb: float


def generate_data(min_atoms, max_atoms, seed=42):
    rng = np.random.default_rng(seed)
    atom_counts = rng.integers(min_atoms, max_atoms + 1, size=N_FRAMES)
    positions = [rng.standard_normal((n, 3)).astype(np.float64) for n in atom_counts]
    numbers = [rng.integers(1, 119, size=n).astype(np.int32) for n in atom_counts]
    energies = rng.standard_normal(N_FRAMES).astype(np.float64)
    random_indices = rng.integers(0, N_FRAMES, size=N_FRAMES).tolist()
    return atom_counts, positions, numbers, energies, random_indices


# ---------------------------------------------------------------------------
# Approach 1: Arrow IPC (memory-mapped random access)
# ---------------------------------------------------------------------------


def write_arrow(path, atom_counts, positions, numbers, energies):
    # Use ListType for ragged per-atom arrays
    # positions: list<fixed_size_list<float64, 3>>  (ragged list of 3D coords)
    # numbers: list<int32>
    pos_list = [pos.tolist() for pos in positions]
    nums_list = [num.tolist() for num in numbers]

    table = pa.table({
        "positions": pa.array(pos_list, type=pa.list_(pa.list_(pa.float64(), 3))),
        "numbers": pa.array(nums_list, type=pa.list_(pa.int32())),
        "energy": pa.array(energies, type=pa.float64()),
        "n_atoms": pa.array(atom_counts.astype(np.int32), type=pa.int32()),
    })

    # Write as IPC file (random access format, not stream)
    with pa.OSFile(path, "wb") as f:
        writer = pa.ipc.new_file(f, table.schema)
        # Write in batches for realistic chunking
        batch_size = 64  # similar to HDF5 chunk size
        for start in range(0, N_FRAMES, batch_size):
            end = min(start + batch_size, N_FRAMES)
            batch = table.slice(start, end - start)
            writer.write_table(batch)
        writer.close()


def _open_arrow_mmap(path):
    """Open Arrow IPC file with memory mapping."""
    source = pa.memory_map(path, "r")
    return pa.ipc.open_file(source)


def read_single_arrow(path, indices):
    reader = _open_arrow_mmap(path)
    rows = []
    for i in indices:
        # Find which batch contains index i
        batch_size = 64
        batch_idx = i // batch_size
        local_idx = i % batch_size
        batch = reader.get_batch(batch_idx)
        rows.append({
            "positions": np.array(batch.column("positions")[local_idx].as_py(), dtype=np.float64),
            "numbers": np.array(batch.column("numbers")[local_idx].as_py(), dtype=np.int32),
            "energy": float(batch.column("energy")[local_idx].as_py()),
        })
    return rows


def read_single_arrow_table(path, indices):
    """Alternative: read entire file as table, then index."""
    reader = _open_arrow_mmap(path)
    table = reader.read_all()
    rows = []
    for i in indices:
        rows.append({
            "positions": np.array(table.column("positions")[i].as_py(), dtype=np.float64),
            "numbers": np.array(table.column("numbers")[i].as_py(), dtype=np.int32),
            "energy": float(table.column("energy")[i].as_py()),
        })
    return rows


def read_bulk_arrow(path):
    reader = _open_arrow_mmap(path)
    table = reader.read_all()
    pos_col = table.column("positions")
    nums_col = table.column("numbers")
    energy_col = table.column("energy").to_numpy()
    rows = []
    for i in range(N_FRAMES):
        rows.append({
            "positions": np.array(pos_col[i].as_py(), dtype=np.float64),
            "numbers": np.array(nums_col[i].as_py(), dtype=np.int32),
            "energy": float(energy_col[i]),
        })
    return rows


def read_column_arrow(path):
    reader = _open_arrow_mmap(path)
    table = reader.read_all()
    return table.column("energy").to_numpy()


# ---------------------------------------------------------------------------
# Approach 1b: Arrow IPC with zero-copy for scalars, optimized list access
# ---------------------------------------------------------------------------


def read_single_arrow_v2(path, indices):
    """Optimized: read_all once, use .as_py() for lists, numpy for scalars."""
    reader = _open_arrow_mmap(path)
    table = reader.read_all()
    pos_col = table.column("positions")
    nums_col = table.column("numbers")
    energy = table.column("energy").to_numpy()  # zero-copy for flat float64
    rows = []
    for i in indices:
        rows.append({
            "positions": np.array(pos_col[i].as_py(), dtype=np.float64),
            "numbers": np.array(nums_col[i].as_py(), dtype=np.int32),
            "energy": float(energy[i]),
        })
    return rows


# ---------------------------------------------------------------------------
# Approach 2: H5MD padded (current asebytes)
# ---------------------------------------------------------------------------


def write_h5_padded(path, atom_counts, positions, numbers, energies):
    max_atoms = int(atom_counts.max())
    with h5py.File(path, "w") as f:
        pos = np.full((N_FRAMES, max_atoms, 3), np.nan, dtype=np.float64)
        nums = np.zeros((N_FRAMES, max_atoms), dtype=np.int32)
        for i, n in enumerate(atom_counts):
            pos[i, :n] = positions[i]
            nums[i, :n] = numbers[i]
        f.create_dataset("positions", data=pos, chunks=(64, max_atoms, 3))
        f.create_dataset("numbers", data=nums, chunks=(64, max_atoms))
        f.create_dataset("_n_atoms", data=atom_counts.astype(np.int32))
        f.create_dataset("energy", data=energies)


def read_single_h5_padded(path, indices):
    rows = []
    with h5py.File(path, "r") as f:
        pos_ds, nums_ds = f["positions"], f["numbers"]
        na_ds, e_ds = f["_n_atoms"], f["energy"]
        for i in indices:
            n = int(na_ds[i])
            rows.append({
                "positions": pos_ds[i, :n],
                "numbers": nums_ds[i, :n],
                "energy": float(e_ds[i]),
            })
    return rows


def read_bulk_h5_padded(path):
    with h5py.File(path, "r") as f:
        pos = f["positions"][:]
        nums = f["numbers"][:]
        na = f["_n_atoms"][:]
        e = f["energy"][:]
    return [{"positions": pos[i, :int(na[i])], "numbers": nums[i, :int(na[i])],
             "energy": float(e[i])} for i in range(N_FRAMES)]


def read_column_h5_padded(path):
    with h5py.File(path, "r") as f:
        return f["energy"][:]


# ---------------------------------------------------------------------------
# Approach 3: H5MD offset+flat (best from v2 benchmark)
# ---------------------------------------------------------------------------


def write_h5_flat(path, atom_counts, positions, numbers, energies):
    offsets = np.zeros(N_FRAMES + 1, dtype=np.int64)
    np.cumsum(atom_counts, out=offsets[1:])
    with h5py.File(path, "w") as f:
        f.create_dataset("positions", data=np.concatenate(positions, axis=0), chunks=(1024, 3))
        f.create_dataset("numbers", data=np.concatenate(numbers, axis=0), chunks=(1024,))
        f.create_dataset("offsets", data=offsets[:-1].astype(np.int64))
        f.create_dataset("lengths", data=atom_counts.astype(np.int32))
        f.create_dataset("energy", data=energies)


def read_single_h5_flat(path, indices):
    """v2 strategy: batch-read index, per-frame disk slice."""
    with h5py.File(path, "r") as f:
        offs = f["offsets"][:]
        lens = f["lengths"][:]
        energy = f["energy"][:]
        pos_ds = f["positions"]
        nums_ds = f["numbers"]
        rows = []
        for i in indices:
            o, l = int(offs[i]), int(lens[i])
            rows.append({
                "positions": pos_ds[o:o + l],
                "numbers": nums_ds[o:o + l],
                "energy": float(energy[i]),
            })
    return rows


def read_single_h5_flat_ram(path, indices):
    """v3 strategy: pre-read everything into RAM."""
    with h5py.File(path, "r") as f:
        offs = f["offsets"][:]
        lens = f["lengths"][:]
        energy = f["energy"][:]
        pos = f["positions"][:]
        nums = f["numbers"][:]
    rows = []
    for i in indices:
        o, l = int(offs[i]), int(lens[i])
        rows.append({
            "positions": pos[o:o + l],
            "numbers": nums[o:o + l],
            "energy": float(energy[i]),
        })
    return rows


def read_bulk_h5_flat(path):
    with h5py.File(path, "r") as f:
        offs = f["offsets"][:]
        lens = f["lengths"][:]
        pos = f["positions"][:]
        nums = f["numbers"][:]
        e = f["energy"][:]
    return [{"positions": pos[int(offs[i]):int(offs[i]) + int(lens[i])],
             "numbers": nums[int(offs[i]):int(offs[i]) + int(lens[i])],
             "energy": float(e[i])} for i in range(N_FRAMES)]


def read_column_h5_flat(path):
    with h5py.File(path, "r") as f:
        return f["energy"][:]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


def bench(name, write_fn, read_single_fn, read_bulk_fn, read_col_fn, path, random_indices):
    t0 = time.perf_counter()
    write_fn()
    write_ms = (time.perf_counter() - t0) * 1000

    file_size_kb = os.path.getsize(path) / 1024

    seq = list(range(N_FRAMES))

    t0 = time.perf_counter()
    read_single_fn(seq)
    read_single_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    read_bulk_fn()
    read_bulk_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    read_single_fn(random_indices)
    read_random_ms = (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    read_col_fn()
    read_column_ms = (time.perf_counter() - t0) * 1000

    return Result(name, write_ms, read_single_ms, read_bulk_ms, read_random_ms, read_column_ms, file_size_kb)


def print_table(results: list[Result]):
    names = [r.name for r in results]
    # Truncate names for display
    short = [n[:20] for n in names]
    header = f"{'Operation':<22}" + "".join(f" {s:>20}" for s in short)
    print(header)
    print("-" * len(header))
    for label, attr in [
        ("Write", "write_ms"),
        ("Read single x1000", "read_single_ms"),
        ("Read bulk (all)", "read_bulk_ms"),
        ("Read random x1000", "read_random_ms"),
        ("Read column (energy)", "read_column_ms"),
        ("File size (KB)", "file_size_kb"),
    ]:
        vals = [getattr(r, attr) for r in results]
        unit = "  " if attr == "file_size_kb" else "ms"
        line = f"  {label:<20}" + "".join(f" {v:>18.1f}{unit}" for v in vals)
        print(line)


def main():
    tmpdir = tempfile.mkdtemp(prefix="bench_arrow_")
    try:
        for cfg_name, min_a, max_a in CONFIGS:
            atom_counts, positions, numbers, energies, random_indices = generate_data(min_a, max_a)
            total_atoms = int(atom_counts.sum())
            max_atoms = int(atom_counts.max())

            print(f"\n{'='*100}")
            print(f"{cfg_name} ({N_FRAMES} frames, {total_atoms} total atoms, max={max_atoms})")
            print()

            p_arrow = os.path.join(tmpdir, f"data_{min_a}_{max_a}.arrow")
            p_padded = os.path.join(tmpdir, f"data_{min_a}_{max_a}_padded.h5")
            p_flat = os.path.join(tmpdir, f"data_{min_a}_{max_a}_flat.h5")

            results = []

            # Arrow IPC (per-batch access)
            results.append(bench(
                "Arrow IPC (per-batch)",
                lambda: write_arrow(p_arrow, atom_counts, positions, numbers, energies),
                lambda idx: read_single_arrow(p_arrow, idx),
                lambda: read_bulk_arrow(p_arrow),
                lambda: read_column_arrow(p_arrow),
                p_arrow, random_indices,
            ))

            # Arrow IPC (read_all + index) — amortize table load
            results.append(bench(
                "Arrow IPC (read_all)",
                lambda: None,
                lambda idx: read_single_arrow_v2(p_arrow, idx),
                lambda: read_bulk_arrow(p_arrow),
                lambda: read_column_arrow(p_arrow),
                p_arrow, random_indices,
            ))

            # H5MD padded
            results.append(bench(
                "H5MD padded (current)",
                lambda: write_h5_padded(p_padded, atom_counts, positions, numbers, energies),
                lambda idx: read_single_h5_padded(p_padded, idx),
                lambda: read_bulk_h5_padded(p_padded),
                lambda: read_column_h5_padded(p_padded),
                p_padded, random_indices,
            ))

            # H5MD flat (batch index)
            write_h5_flat(p_flat, atom_counts, positions, numbers, energies)
            results.append(bench(
                "H5MD flat (batch idx)",
                lambda: None,
                lambda idx: read_single_h5_flat(p_flat, idx),
                lambda: read_bulk_h5_flat(p_flat),
                lambda: read_column_h5_flat(p_flat),
                p_flat, random_indices,
            ))

            # H5MD flat (all RAM)
            results.append(bench(
                "H5MD flat (all RAM)",
                lambda: None,
                lambda idx: read_single_h5_flat_ram(p_flat, idx),
                lambda: read_bulk_h5_flat(p_flat),
                lambda: read_column_h5_flat(p_flat),
                p_flat, random_indices,
            ))

            print_table(results)

            # Verify Arrow correctness
            arrow_rows = read_single_arrow(p_arrow, [0, N_FRAMES // 2, N_FRAMES - 1])
            h5_rows = read_single_h5_padded(p_padded, [0, N_FRAMES // 2, N_FRAMES - 1])
            for a, h in zip(arrow_rows, h5_rows):
                np.testing.assert_array_almost_equal(a["positions"], h["positions"])
                np.testing.assert_array_equal(a["numbers"], h["numbers"])
            print(f"\n  Correctness: PASSED")

            # File sizes
            print(f"  Arrow: {os.path.getsize(p_arrow)/1024:.0f} KB, "
                  f"H5 padded: {os.path.getsize(p_padded)/1024:.0f} KB, "
                  f"H5 flat: {os.path.getsize(p_flat)/1024:.0f} KB")

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
