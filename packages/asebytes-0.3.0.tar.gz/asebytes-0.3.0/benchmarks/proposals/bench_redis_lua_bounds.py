#!/usr/bin/env python3
"""Benchmark: Redis Lua bounds checking (1 RT) vs LLEN + Lua (2 RT).

Current asebytes: facade calls `len()` → LLEN (RT1), then get() → Lua (RT2).
Proposed: Lua script already does bounds checking internally. Skip LLEN.

This benchmark measures the actual latency difference of 2 RT vs 1 RT
for single-row reads.

Usage:
    uv run python benchmarks/proposals/bench_redis_lua_bounds.py

Requires a running Redis instance at localhost:6379.
"""

from __future__ import annotations

import sys
import time
import uuid

import msgpack
import msgpack_numpy as m_np
import numpy as np

try:
    import redis as redis_mod
except ImportError:
    print("ERROR: redis package required")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Test data
# ---------------------------------------------------------------------------

N_FRAMES = 1000
rng = np.random.default_rng(42)
FRAMES: list[dict[bytes, bytes]] = []
for i in range(N_FRAMES):
    n = rng.integers(3, 30)
    frame = {
        b"positions": msgpack.packb(rng.standard_normal((n, 3)).astype(np.float64), default=m_np.encode),
        b"energy": msgpack.packb(float(rng.standard_normal()), default=m_np.encode),
    }
    FRAMES.append(frame)

RANDOM_INDICES = rng.integers(0, N_FRAMES, size=N_FRAMES).tolist()

# Lua: get with internal bounds check (current approach, but called without LLEN)
LUA_GET = """
local n = redis.call('LLEN', KEYS[1])
local idx = tonumber(ARGV[2])
if idx < 0 then idx = n + idx end
if idx < 0 or idx >= n then return redis.error_reply('IndexError') end
local sk = redis.call('LINDEX', KEYS[1], idx)
local rk = ARGV[1] .. sk
if redis.call('EXISTS', rk) == 0 then return false end
return redis.call('HGETALL', rk)
"""


def setup_data(r: redis_mod.Redis, prefix: str) -> None:
    """Write test data to Redis."""
    sk_key = f"{prefix}:sort_keys"
    pipe = r.pipeline(transaction=False)
    for i in range(N_FRAMES):
        rk = f"{prefix}:row:{i}"
        pipe.hset(rk, mapping=FRAMES[i])
        pipe.rpush(sk_key, str(i))
    pipe.execute()


def bench_2rt(r: redis_mod.Redis, prefix: str, indices: list[int]) -> float:
    """Current approach: LLEN (RT1) + Lua GET (RT2) per read."""
    sk_key = f"{prefix}:sort_keys"
    row_prefix = f"{prefix}:row:"
    lua_get = r.register_script(LUA_GET)

    t0 = time.perf_counter()
    for i in indices:
        # RT1: bounds check via LLEN
        n = r.llen(sk_key)
        if i < 0:
            i = n + i
        if i < 0 or i >= n:
            raise IndexError(i)
        # RT2: Lua script (also does LLEN internally — redundant!)
        lua_get(keys=[sk_key], args=[row_prefix, i])
    return (time.perf_counter() - t0) * 1000


def bench_1rt(r: redis_mod.Redis, prefix: str, indices: list[int]) -> float:
    """Proposed: Only Lua GET (1 RT) — it already does bounds checking."""
    sk_key = f"{prefix}:sort_keys"
    row_prefix = f"{prefix}:row:"
    lua_get = r.register_script(LUA_GET)

    t0 = time.perf_counter()
    for i in indices:
        try:
            lua_get(keys=[sk_key], args=[row_prefix, i])
        except redis_mod.ResponseError as e:
            if "IndexError" in str(e):
                raise IndexError(i) from e
            raise
    return (time.perf_counter() - t0) * 1000


def bench_bulk_2rt(r: redis_mod.Redis, prefix: str) -> float:
    """Current bulk: LLEN + pipeline LINDEX×N + pipeline HGETALL×N = 3 RT."""
    sk_key = f"{prefix}:sort_keys"
    row_prefix = f"{prefix}:row:"

    t0 = time.perf_counter()
    # RT1: length
    n = r.llen(sk_key)
    # RT2: resolve all sort keys
    pipe = r.pipeline(transaction=False)
    for i in range(n):
        pipe.lindex(sk_key, i)
    sort_keys = pipe.execute()
    # RT3: fetch all rows
    pipe = r.pipeline(transaction=False)
    for sk in sort_keys:
        pipe.hgetall(f"{row_prefix}{sk.decode()}")
    pipe.execute()
    return (time.perf_counter() - t0) * 1000


def bench_bulk_no_llen(r: redis_mod.Redis, prefix: str) -> float:
    """Proposed bulk: LRANGE + pipeline HGETALL×N = 2 RT."""
    sk_key = f"{prefix}:sort_keys"
    row_prefix = f"{prefix}:row:"

    t0 = time.perf_counter()
    # RT1: get all sort keys at once (LRANGE 0 -1 instead of LLEN + LINDEX×N)
    sort_keys = r.lrange(sk_key, 0, -1)
    # RT2: fetch all rows
    pipe = r.pipeline(transaction=False)
    for sk in sort_keys:
        pipe.hgetall(f"{row_prefix}{sk.decode()}")
    pipe.execute()
    return (time.perf_counter() - t0) * 1000


def main() -> None:
    try:
        r = redis_mod.Redis(host="localhost", port=6379, db=0, decode_responses=False)
        r.ping()
    except redis_mod.ConnectionError:
        print("ERROR: Cannot connect to Redis at localhost:6379")
        sys.exit(1)

    uid = uuid.uuid4().hex[:8]
    prefix = f"bench_lua_{uid}"

    try:
        setup_data(r, prefix)

        print(f"Redis Lua Bounds-Check Benchmark ({N_FRAMES} frames)")
        print()

        # Warm up
        bench_1rt(r, prefix, [0, 1, 2])
        bench_2rt(r, prefix, [0, 1, 2])

        # Sequential reads
        seq = list(range(N_FRAMES))
        t_2rt_seq = bench_2rt(r, prefix, seq)
        t_1rt_seq = bench_1rt(r, prefix, seq)

        # Random reads
        t_2rt_rand = bench_2rt(r, prefix, RANDOM_INDICES)
        t_1rt_rand = bench_1rt(r, prefix, RANDOM_INDICES)

        # Bulk reads
        t_bulk_current = bench_bulk_2rt(r, prefix)
        t_bulk_proposed = bench_bulk_no_llen(r, prefix)

        print(f"{'Operation':<30} {'2 RT (current)':>15} {'1 RT (proposed)':>15} {'Speedup':>10}")
        print("-" * 72)
        for label, t2, t1 in [
            ("Single seq x1000", t_2rt_seq, t_1rt_seq),
            ("Single random x1000", t_2rt_rand, t_1rt_rand),
            ("Bulk all 1000", t_bulk_current, t_bulk_proposed),
        ]:
            speedup = t2 / t1 if t1 > 0 else float("inf")
            print(f"  {label:<28} {t2:>13.1f}ms {t1:>13.1f}ms {speedup:>9.2f}x")

        print()
        per_read_2rt = t_2rt_seq / N_FRAMES
        per_read_1rt = t_1rt_seq / N_FRAMES
        print(f"  Per-read latency: {per_read_2rt:.3f}ms (2 RT) → {per_read_1rt:.3f}ms (1 RT)")
        print(f"  Saved: {per_read_2rt - per_read_1rt:.3f}ms/read = 1 LLEN round trip")
        print()
        print("Analysis:")
        print("  The Lua script already does LLEN internally for bounds checking.")
        print("  The facade's separate LLEN call is purely redundant.")
        print("  Eliminating it saves exactly 1 network round trip per read.")
        print("  For bulk reads, using LRANGE instead of LLEN+LINDEX×N saves 1 RT total.")

    finally:
        keys = r.keys(f"{prefix}:*")
        if keys:
            r.delete(*keys)


if __name__ == "__main__":
    main()
