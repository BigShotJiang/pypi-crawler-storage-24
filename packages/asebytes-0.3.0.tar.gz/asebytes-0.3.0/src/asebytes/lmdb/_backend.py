from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import msgpack
import msgpack_numpy as m

from ._blob_backend import LMDBBlobBackend
from .._adapters import (
    BlobToObjectReadAdapter,
    BlobToObjectReadWriteAdapter,
    _deserialize_row,
)


class _LMDBReadMixin:
    """Shared single-transaction read overrides for LMDB object backends."""

    _store: LMDBBlobBackend

    @staticmethod
    def list_groups(path: str, **kwargs) -> list[str]:
        """Return available group names at the given path."""
        return LMDBBlobBackend.list_groups(path, **kwargs)

    @property
    def env(self):
        """Expose the LMDB environment for configuration inspection."""
        return self._store.env

    def _check_index(self, index: int) -> None:
        if index < 0 or index >= len(self._store):
            raise IndexError(index)

    def get(self, index: int, keys: list[str] | None = None) -> dict[str, Any] | None:
        self._check_index(index)
        return super().get(index, keys)

    def iter_rows(
        self, indices: list[int], keys: list[str] | None = None
    ) -> Iterator[dict[str, Any] | None]:
        """Stream rows within a single LMDB read transaction."""
        byte_keys = [k.encode() for k in keys] if keys is not None else None
        with self._store.env.begin() as txn:
            for i in indices:
                raw = self._store.get_with_txn(txn, i, byte_keys)
                yield None if raw is None else _deserialize_row(raw)

    def get_many(
        self, indices: list[int], keys: list[str] | None = None
    ) -> list[dict[str, Any] | None]:
        byte_keys = [k.encode() for k in keys] if keys is not None else None
        with self._store.env.begin() as txn:
            return [
                None
                if (raw := self._store.get_with_txn(txn, i, byte_keys)) is None
                else _deserialize_row(raw)
                for i in indices
            ]

    def get_column(self, key: str, indices: list[int] | None = None) -> list[Any]:
        if indices is None:
            indices = list(range(len(self)))
        if not indices:
            return []
        byte_key = key.encode()
        with self._store.env.begin() as txn:
            self._store._ensure_cache(txn)
            # Build all LMDB keys upfront for a single cursor.getmulti call
            lmdb_keys = []
            for i in indices:
                sort_key = self._store._resolve_sort_key(i)
                lmdb_keys.append(str(sort_key).encode() + b"-" + byte_key)
            fetched = dict(txn.cursor().getmulti(lmdb_keys))
            return [
                msgpack.unpackb(fetched[k], object_hook=m.decode)
                if k in fetched
                else None
                for k in lmdb_keys
            ]


class LMDBObjectReadBackend(_LMDBReadMixin, BlobToObjectReadAdapter):
    """Read-only LMDB storage backend using msgpack serialization.

    Wraps LMDBBlobBackend for LMDB operations, converting between
    dict[str, Any] (logical) and dict[bytes, bytes] (storage).

    Inherits generic ser/de logic from BlobToObjectReadAdapter and
    overrides iter_rows, get_many, get_column to use single-transaction
    LMDB reads via get_with_txn for efficiency.

    Parameters
    ----------
    file : str
        Path to LMDB database directory.
    group : str | None
        Group name for namespacing. If None, uses "default".
    map_size : int
        Maximum LMDB size in bytes (default 10GB).
    **lmdb_kwargs
        Additional kwargs for lmdb.open().
    """

    def __init__(
        self,
        file: str,
        group: str | None = None,
        map_size: int = 10737418240,
        **lmdb_kwargs,
    ):
        super().__init__(
            LMDBBlobBackend(file, group, map_size, readonly=True, **lmdb_kwargs)
        )


class LMDBObjectBackend(_LMDBReadMixin, BlobToObjectReadWriteAdapter):
    """Read-write LMDB storage backend using msgpack serialization.

    Inherits generic ser/de and CRUD logic from BlobToObjectReadWriteAdapter
    and overrides iter_rows, get_many, get_column for single-transaction
    efficiency, plus update for optimised partial writes.

    Parameters
    ----------
    file : str
        Path to LMDB database directory.
    group : str | None
        Group name for namespacing. If None, uses "default".
    map_size : int
        Maximum LMDB size in bytes (default 10GB).
    readonly : bool
        Open in read-only mode.
    **lmdb_kwargs
        Additional kwargs for lmdb.open().
    """

    def __init__(
        self,
        file: str,
        group: str | None = None,
        map_size: int = 10737418240,
        readonly: bool = False,
        **lmdb_kwargs,
    ):
        super().__init__(
            LMDBBlobBackend(file, group, map_size, readonly, **lmdb_kwargs)
        )

    # -- Optimised partial update ------------------------------------------

    def update(self, index: int, data: dict[str, Any]) -> None:
        """Optimized partial update -- only serializes and writes changed keys."""
        self._check_index(index)
        raw = {k.encode(): msgpack.packb(v, default=m.encode) for k, v in data.items()}
        self._store.update(index, raw)
