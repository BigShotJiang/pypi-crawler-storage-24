"""Async Redis blob-level backend using hashes for row storage."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

import redis.asyncio as aioredis

from .._async_backends import AsyncReadWriteBackend
from ._backend import DEFAULT_GROUP
from ._lua import (
    LUA_DELETE,
    LUA_GET,
    LUA_GET_WITH_KEYS,
    LUA_KEYS,
    LUA_SET,
    LUA_UPDATE,
)


class AsyncRedisBlobBackend(AsyncReadWriteBackend[bytes, bytes]):
    """Async Redis-backed read-write backend for blob dictionaries.

    Storage layout (all keys share a ``{group}:`` namespace):

    * ``{group}:sort_keys``  -- LIST of sort-key integers (positional index)
    * ``{group}:next_sk``    -- STRING, monotonically increasing counter
    * ``{group}:row:{sk}``   -- HASH, one per row (field=bytes, value=bytes)

    A *None* row is represented by having its sort key in the list but
    **no** corresponding hash key.

    Parameters
    ----------
    url : str
        Redis connection URI, e.g. ``redis://localhost:6379/0``.
    group : str | None
        Group name (key prefix). Defaults to ``"default"``.
    """

    def __init__(
        self,
        url: str = "redis://localhost:6379",
        group: str | None = None,
    ) -> None:
        self._r = aioredis.from_url(url, decode_responses=False)
        self.group = group if group is not None else DEFAULT_GROUP
        self._prefix = self.group  # Internal alias for key generation
        self._scripts: dict[str, Any] | None = None

    # ------------------------------------------------------------------
    # Key helpers
    # ------------------------------------------------------------------

    @property
    def _sk_list_key(self) -> str:
        return f"{self._prefix}:sort_keys"

    @property
    def _next_sk_key(self) -> str:
        return f"{self._prefix}:next_sk"

    @property
    def _row_prefix(self) -> str:
        return f"{self._prefix}:row:"

    def _row_key(self, sk: int) -> str:
        return f"{self._prefix}:row:{sk}"

    # ------------------------------------------------------------------
    # Lua script helpers
    # ------------------------------------------------------------------

    def _ensure_scripts(self) -> dict[str, Any]:
        if self._scripts is None:
            self._scripts = {
                "get": self._r.register_script(LUA_GET),
                "get_with_keys": self._r.register_script(LUA_GET_WITH_KEYS),
                "keys": self._r.register_script(LUA_KEYS),
                "set": self._r.register_script(LUA_SET),
                "delete": self._r.register_script(LUA_DELETE),
                "update": self._r.register_script(LUA_UPDATE),
            }
        return self._scripts

    async def _call_lua(self, name: str, args: list[Any] | None = None) -> Any:
        scripts = self._ensure_scripts()
        try:
            return await scripts[name](
                keys=[self._sk_list_key],
                args=[self._row_prefix, *(args or [])],
            )
        except aioredis.ResponseError as e:
            if "IndexError" in str(e):
                raise IndexError from None
            raise

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _resolve_index(self, index: int) -> int:
        """Normalise a (possibly negative) index and return the sort key."""
        n = await self._r.llen(self._sk_list_key)
        if index < 0:
            index += n
        if index < 0 or index >= n:
            raise IndexError(index)
        sk_bytes = await self._r.lindex(self._sk_list_key, index)
        return int(sk_bytes)

    async def _resolve_indices(self, indices: list[int]) -> list[int]:
        """Batch-resolve positional indices to sort keys (2 RTs)."""
        if not indices:
            return []
        n = await self._r.llen(self._sk_list_key)
        normalised = []
        for idx in indices:
            i = idx + n if idx < 0 else idx
            if i < 0 or i >= n:
                raise IndexError(idx)
            normalised.append(i)
        pipe = self._r.pipeline(transaction=False)
        for i in normalised:
            pipe.lindex(self._sk_list_key, i)
        sk_bytes_list = await pipe.execute()
        return [int(sk) for sk in sk_bytes_list]

    async def _allocate_sk(self) -> int:
        """Atomically allocate the next sort key."""
        return await self._r.incr(self._next_sk_key) - 1

    # ------------------------------------------------------------------
    # from_uri constructor
    # ------------------------------------------------------------------

    @classmethod
    def from_uri(
        cls, uri: str, group: str | None = None, **kwargs: Any
    ) -> AsyncRedisBlobBackend:
        """Construct from ``redis://host:port/db``.

        The group (key prefix) is passed separately via the ``group`` parameter.

        Parameters
        ----------
        uri : str
            Redis URI with optional database path (e.g. ``redis://host:port/0``).
        group : str | None
            Group name (key prefix). Defaults to ``"default"``.
        **kwargs
            Additional arguments passed to the constructor.
        """
        from urllib.parse import urlsplit, urlunsplit

        parsed = urlsplit(uri)
        if not parsed.scheme:
            raise ValueError(f"Invalid URI: {uri!r}")

        # Extract the db number from the path (e.g. "/0" from "redis://host:port/0")
        path_parts = [p for p in parsed.path.split("/") if p]
        if len(path_parts) >= 1:
            db = path_parts[0]
            connection_url = urlunsplit(
                (
                    parsed.scheme,
                    parsed.netloc,
                    f"/{db}",
                    parsed.query,
                    parsed.fragment,
                )
            )
        else:
            connection_url = urlunsplit(
                (
                    parsed.scheme,
                    parsed.netloc,
                    parsed.path,
                    parsed.query,
                    parsed.fragment,
                )
            )

        return cls(url=connection_url, group=group, **kwargs)

    @staticmethod
    def list_groups(path: str = "redis://localhost:6379", **kwargs) -> list[str]:
        """Return available group names (key prefixes) in the Redis database.

        Note: This is a synchronous method that uses a sync client internally,
        as listing groups is typically done outside of async contexts.

        Parameters
        ----------
        path : str
            Redis connection URI (e.g. ``redis://localhost:6379/0``).
        **kwargs
            Unused, for API compatibility.

        Returns
        -------
        list[str]
            List of group names found by scanning for ``*:sort_keys`` patterns.
        """
        import redis as redis_mod

        r = redis_mod.Redis.from_url(path, decode_responses=True)
        try:
            groups = set()
            cursor = 0
            while True:
                cursor, keys = r.scan(cursor=cursor, match="*:sort_keys", count=1000)
                for key in keys:
                    if key.endswith(":sort_keys"):
                        group = key[:-10]
                        groups.add(group)
                if cursor == 0:
                    break
            return sorted(groups)
        finally:
            r.close()

    # ------------------------------------------------------------------
    # AsyncReadBackend implementation
    # ------------------------------------------------------------------

    async def len(self) -> int:
        return await self._r.llen(self._sk_list_key)

    async def get(
        self, index: int, keys: list[bytes] | None = None
    ) -> dict[bytes, bytes] | None:
        if keys is not None:
            raw = await self._call_lua("get_with_keys", [index, *keys])
        else:
            raw = await self._call_lua("get", [index])
        if raw is None:
            return None
        it = iter(raw)
        return dict(zip(it, it))

    async def get_many(
        self, indices: list[int], keys: list[bytes] | None = None
    ) -> list[dict[bytes, bytes] | None]:
        sks = await self._resolve_indices(indices)
        pipe = self._r.pipeline(transaction=False)
        if keys is not None:
            for sk in sks:
                rk = self._row_key(sk)
                pipe.exists(rk)
                for k in keys:
                    pipe.hget(rk, k)
        else:
            for sk in sks:
                rk = self._row_key(sk)
                pipe.hgetall(rk)
        raw = await pipe.execute()

        results: list[dict[bytes, bytes] | None] = []
        if keys is not None:
            pos = 0
            for _ in sks:
                exists = raw[pos]
                pos += 1
                vals = raw[pos : pos + len(keys)]
                pos += len(keys)
                if not exists:
                    results.append(None)
                else:
                    results.append({k: v for k, v in zip(keys, vals) if v is not None})
        else:
            for hgetall_result in raw:
                if not hgetall_result:
                    results.append(None)
                else:
                    results.append(hgetall_result)
        return results

    async def get_column(
        self, key: bytes, indices: list[int] | None = None
    ) -> list[Any]:
        if indices is None:
            indices = list(range(await self.len()))
        sks = await self._resolve_indices(indices)
        pipe = self._r.pipeline(transaction=False)
        for sk in sks:
            rk = self._row_key(sk)
            pipe.exists(rk)
            pipe.hget(rk, key)
        raw = await pipe.execute()

        results: list[Any] = []
        for i in range(0, len(raw), 2):
            exists = raw[i]
            val = raw[i + 1]
            if not exists:
                results.append(None)
            else:
                results.append(val)
        return results

    async def iter_rows(
        self, indices: list[int], keys: list[bytes] | None = None
    ) -> AsyncIterator[dict[bytes, bytes] | None]:
        """Yield rows one at a time, backed by a pipelined get_many."""
        for row in await self.get_many(indices, keys):
            yield row

    async def keys(self, index: int) -> list[bytes]:
        result = await self._call_lua("keys", [index])
        return result

    # ------------------------------------------------------------------
    # AsyncReadWriteBackend implementation
    # ------------------------------------------------------------------

    async def set(self, index: int, value: dict[bytes, bytes] | None) -> None:
        if value is None:
            await self._call_lua("set", [index])
        else:
            flat: list[Any] = [index]
            for k, v in value.items():
                flat.append(k)
                flat.append(v)
            await self._call_lua("set", flat)

    async def delete(self, index: int) -> None:
        await self._call_lua("delete", [index])

    async def extend(self, values: list[dict[bytes, bytes] | None]) -> int:
        if not values:
            return await self.len()
        n = len(values)
        end_sk = await self._r.incrby(self._next_sk_key, n)
        start_sk = end_sk - n

        pipe = self._r.pipeline(transaction=False)
        sk_list: list[int] = []
        for i, v in enumerate(values):
            sk = start_sk + i
            sk_list.append(sk)
            if v is not None:
                pipe.hset(self._row_key(sk), mapping=v)
        sk_bytes = [str(sk).encode() for sk in sk_list]
        pipe.rpush(self._sk_list_key, *sk_bytes)
        results = await pipe.execute()
        return results[-1]

    async def insert(self, index: int, value: dict[bytes, bytes] | None) -> None:
        pipe = self._r.pipeline(transaction=False)
        pipe.llen(self._sk_list_key)
        pipe.incr(self._next_sk_key)
        n, sk_raw = await pipe.execute()
        sk = sk_raw - 1

        if index < 0:
            index = 0
        if index > n:
            index = n

        if value is not None:
            await self._r.hset(self._row_key(sk), mapping=value)

        sk_bytes = str(sk).encode()

        if index == n:
            await self._r.rpush(self._sk_list_key, sk_bytes)
        elif index == 0:
            await self._r.lpush(self._sk_list_key, sk_bytes)
        else:
            pivot = await self._r.lindex(self._sk_list_key, index)
            await self._r.linsert(self._sk_list_key, "BEFORE", pivot, sk_bytes)

    async def update(self, index: int, data: dict[bytes, bytes]) -> None:
        if not data:
            return
        flat: list[Any] = [index]
        for k, v in data.items():
            flat.append(k)
            flat.append(v)
        await self._call_lua("update", flat)

    async def update_many(self, start: int, data: list[dict[bytes, bytes]]) -> None:
        if not data:
            return
        indices = list(range(start, start + len(data)))
        sks = await self._resolve_indices(indices)
        pipe = self._r.pipeline(transaction=False)
        for sk, row_data in zip(sks, data):
            if row_data:
                pipe.hset(self._row_key(sk), mapping=row_data)
        await pipe.execute()

    async def set_column(self, key: bytes, start: int, values: list[bytes]) -> None:
        if not values:
            return
        indices = list(range(start, start + len(values)))
        sks = await self._resolve_indices(indices)
        pipe = self._r.pipeline(transaction=False)
        for sk, value in zip(sks, values):
            pipe.hset(self._row_key(sk), key, value)
        await pipe.execute()

    async def drop_keys(
        self, keys: list[bytes], indices: list[int] | None = None
    ) -> None:
        if indices is None:
            indices = list(range(await self.len()))
        sks = await self._resolve_indices(indices)
        pipe = self._r.pipeline(transaction=False)
        for sk in sks:
            rk = self._row_key(sk)
            for k in keys:
                pipe.hdel(rk, k)
        await pipe.execute()

    async def clear(self) -> None:
        """Remove all row data and reset metadata."""
        all_sks = await self._r.lrange(self._sk_list_key, 0, -1)
        pipe = self._r.pipeline(transaction=False)
        for sk_bytes in all_sks:
            pipe.delete(self._row_key(int(sk_bytes)))
        pipe.delete(self._sk_list_key)
        pipe.delete(self._next_sk_key)
        await pipe.execute()

    async def remove(self) -> None:
        """Delete all Redis keys with this prefix."""
        cursor = 0
        pattern = f"{self._prefix}:*"
        while True:
            cursor, keys = await self._r.scan(cursor=cursor, match=pattern, count=200)
            if keys:
                await self._r.delete(*keys)
            if cursor == 0:
                break

    async def aclose(self) -> None:
        """Close the async Redis connection."""
        await self._r.aclose()

    async def __aenter__(self) -> AsyncRedisBlobBackend:
        return self

    async def __aexit__(self, *args) -> None:
        await self.aclose()
