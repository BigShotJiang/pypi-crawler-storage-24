"""Test error handling for asebytes functions.

This module tests expected failures and error conditions:
- TypeError when non-Atoms objects are passed
- KeyError when required keys are missing
- ValueError for invalid data
- IndexError for out-of-bounds access
"""

import numpy as np
import pytest
from ase import Atoms

import asebytes

# =============================================================================
# Tests for encode errors
# =============================================================================


def test_encode_with_non_atoms_string_raises_typeerror():
    """Test that encode raises TypeError for string input."""
    with pytest.raises(TypeError, match="Input must be an ase.Atoms object"):
        asebytes.encode("not an atoms object")


def test_encode_with_dict_raises_typeerror():
    """Test that encode raises TypeError for dict input."""
    with pytest.raises(TypeError, match="Input must be an ase.Atoms object"):
        asebytes.encode({"positions": [[0, 0, 0]]})


def test_encode_with_nonzero_celldisp_raises_valueerror():
    """Test that encode raises ValueError when _celldisp is non-zero."""
    atoms = Atoms("H", positions=[[0, 0, 0]])
    atoms._celldisp = np.array([[1.0], [0.0], [0.0]])
    with pytest.raises(ValueError, match="non-zero cell displacement"):
        asebytes.encode(atoms)


def test_encode_with_zero_celldisp_succeeds():
    """Test that encode works fine when _celldisp is all zeros."""
    atoms = Atoms("H", positions=[[0, 0, 0]])
    # Default _celldisp is zeros — should not raise
    asebytes.encode(atoms)


def test_encode_with_non_fixconstraint_raises_typeerror():
    """Test that encode raises TypeError for non-FixConstraint constraints."""

    class CustomConstraint:
        """A constraint that does NOT inherit from FixConstraint."""

        def todict(self):
            return {"name": "CustomConstraint", "kwargs": {}}

    atoms = Atoms("H2", positions=[[0, 0, 0], [1, 0, 0]])
    atoms._constraints = [CustomConstraint()]
    with pytest.raises(TypeError, match="does not inherit.*FixConstraint"):
        asebytes.encode(atoms)


def test_atoms_to_dict_with_nonzero_celldisp_raises_valueerror():
    """Test that atoms_to_dict raises ValueError when _celldisp is non-zero."""
    from asebytes._convert import atoms_to_dict

    atoms = Atoms("H", positions=[[0, 0, 0]])
    atoms._celldisp = np.array([[1.0], [0.0], [0.0]])
    with pytest.raises(ValueError, match="non-zero cell displacement"):
        atoms_to_dict(atoms)


def test_atoms_to_dict_with_non_fixconstraint_raises_typeerror():
    """Test that atoms_to_dict raises TypeError for non-FixConstraint."""
    from asebytes._convert import atoms_to_dict

    class CustomConstraint:
        def todict(self):
            return {"name": "CustomConstraint", "kwargs": {}}

    atoms = Atoms("H2", positions=[[0, 0, 0], [1, 0, 0]])
    atoms._constraints = [CustomConstraint()]
    with pytest.raises(TypeError, match="does not inherit.*FixConstraint"):
        atoms_to_dict(atoms)


def test_encode_with_list_raises_typeerror():
    """Test that encode raises TypeError for list input."""
    with pytest.raises(TypeError, match="Input must be an ase.Atoms object"):
        asebytes.encode([1, 2, 3])


def test_encode_with_none_raises_typeerror():
    """Test that encode raises TypeError for None input."""
    with pytest.raises(TypeError, match="Input must be an ase.Atoms object"):
        asebytes.encode(None)


def test_encode_with_numpy_array_raises_typeerror():
    """Test that encode raises TypeError for numpy array input."""
    arr = np.array([[0, 0, 0], [1, 1, 1]])
    with pytest.raises(TypeError, match="Input must be an ase.Atoms object"):
        asebytes.encode(arr)


def test_encode_with_integer_raises_typeerror():
    """Test that encode raises TypeError for integer input."""
    with pytest.raises(TypeError, match="Input must be an ase.Atoms object"):
        asebytes.encode(42)


# =============================================================================
# Tests for decode errors
# =============================================================================


def test_decode_missing_cell_uses_default():
    """Test that missing cell key uses default empty cell."""
    import msgpack
    import msgpack_numpy as m

    data = {
        b"arrays.numbers": msgpack.packb(np.array([1]), default=m.encode),
    }
    # Should not raise - cell is now optional
    atoms = asebytes.decode(data)
    assert atoms.cell is not None
    assert np.allclose(atoms.cell.array, np.zeros((3, 3)))


def test_decode_pbc_as_plain_list():
    """Test that decode handles pbc packed as a plain list (not via msgpack_numpy).

    This happens when a server stores pbc as a Python list (e.g. from MongoDB)
    and re-packs with plain msgpack instead of msgpack_numpy.
    """
    import msgpack
    import msgpack_numpy as m

    data = {
        b"cell": msgpack.packb(np.eye(3) * 10, default=m.encode),
        b"pbc": msgpack.packb([True, True, True]),  # plain list, no numpy
        b"arrays.numbers": msgpack.packb(np.array([1, 1]), default=m.encode),
        b"arrays.positions": msgpack.packb(
            np.array([[0.0, 0.0, 0.0], [1.0, 0.0, 0.0]]), default=m.encode
        ),
    }
    atoms = asebytes.decode(data)
    assert isinstance(atoms.pbc, np.ndarray), f"pbc should be ndarray, got {type(atoms.pbc)}"
    assert atoms.pbc.dtype == bool
    np.testing.assert_array_equal(atoms.pbc, [True, True, True])
    # This must not raise AttributeError
    assert atoms.pbc.tolist() == [True, True, True]


def test_decode_missing_pbc_uses_default():
    """Test that missing pbc key uses default (False, False, False)."""
    import msgpack
    import msgpack_numpy as m

    data = {
        b"cell": msgpack.packb(np.eye(3), default=m.encode),
        b"arrays.numbers": msgpack.packb(np.array([1]), default=m.encode),
    }
    # Should not raise - pbc is now optional
    atoms = asebytes.decode(data)
    assert list(atoms.pbc) == [False, False, False]


def test_decode_missing_numbers_creates_empty_atoms():
    """Test that missing arrays.numbers creates an empty Atoms object."""
    import msgpack
    import msgpack_numpy as m

    data = {
        b"cell": msgpack.packb(np.eye(3), default=m.encode),
        b"pbc": msgpack.packb(np.array([True, True, True]), default=m.encode),
    }
    # Should now create an empty atoms object instead of raising
    atoms = asebytes.decode(data)
    assert len(atoms) == 0


def test_decode_with_unknown_key_raises_valueerror():
    """Test that unknown top-level keys raise ValueError."""
    import msgpack
    import msgpack_numpy as m

    atoms = Atoms("H", positions=[[0, 0, 0]])
    data = asebytes.encode(atoms)
    # Add an unknown key
    data[b"unknown_key"] = msgpack.packb("value", default=m.encode)

    with pytest.raises(ValueError, match="Unknown key in data: b'unknown_key'"):
        asebytes.decode(data)


def test_decode_with_invalid_prefix_raises_valueerror():
    """Test that keys with invalid prefixes raise ValueError."""
    import msgpack
    import msgpack_numpy as m

    atoms = Atoms("H", positions=[[0, 0, 0]])
    data = asebytes.encode(atoms)
    # Add a key with invalid prefix
    data[b"invalid.prefix.key"] = msgpack.packb("value", default=m.encode)

    with pytest.raises(ValueError, match="Unknown key in data"):
        asebytes.decode(data)


@pytest.mark.parametrize("fast", [True, False])
def test_decode_empty_atoms_both_modes(fast):
    """Test that empty data creates empty atoms in both fast modes."""
    import msgpack
    import msgpack_numpy as m

    data = {
        b"cell": msgpack.packb(np.eye(3), default=m.encode),
        b"pbc": msgpack.packb(np.array([True, True, True]), default=m.encode),
        # Missing arrays.numbers - should create empty atoms
    }
    atoms = asebytes.decode(data, fast=fast)
    assert len(atoms) == 0


# =============================================================================
# Tests for BlobIO errors
# =============================================================================


def test_bytesio_getitem_nonexistent_index_raises_indexerror(tmp_path):
    """Test that accessing non-existent index raises IndexError."""
    io = asebytes.BlobIO(asebytes.LMDBBlobBackend(str(tmp_path / "test.lmdb")))
    with pytest.raises(IndexError):
        _ = io[0]


def test_bytesio_getitem_negative_index(tmp_path):
    """Test that negative indices are normalized correctly."""
    io = asebytes.BlobIO(asebytes.LMDBBlobBackend(str(tmp_path / "test.lmdb")))
    io[0] = {b"test": b"data"}
    # Negative indices are normalized: -1 refers to the last element
    assert io[-1] == {b"test": b"data"}
    # Out-of-bounds negative index raises IndexError
    with pytest.raises(IndexError):
        _ = io[-5]


def test_bytesio_delitem_out_of_bounds_raises_indexerror(tmp_path):
    """Test that deleting out-of-bounds index raises IndexError."""
    io = asebytes.BlobIO(asebytes.LMDBBlobBackend(str(tmp_path / "test.lmdb")))
    io[0] = {b"test": b"data"}

    with pytest.raises(IndexError, match="Index 5 out of range"):
        del io[5]


def test_bytesio_delitem_negative_out_of_bounds_raises_indexerror(tmp_path):
    """Test that deleting negative out-of-bounds index raises IndexError."""
    io = asebytes.BlobIO(asebytes.LMDBBlobBackend(str(tmp_path / "test.lmdb")))
    io[0] = {b"test": b"data"}

    with pytest.raises(IndexError):
        del io[-2]


def test_bytesio_get_nonexistent_index_raises_indexerror(tmp_path):
    """Test that get() with non-existent index raises IndexError."""
    io = asebytes.BlobIO(asebytes.LMDBBlobBackend(str(tmp_path / "test.lmdb")))
    with pytest.raises(IndexError):
        io.get(0)


def test_bytesio_keys_nonexistent_raises_indexerror(tmp_path):
    """Test that keys() with non-existent index raises IndexError."""
    io = asebytes.BlobIO(asebytes.LMDBBlobBackend(str(tmp_path / "test.lmdb")))
    with pytest.raises(IndexError):
        io.keys(0)


def test_bytesio_get_with_invalid_keys_raises_keyerror(tmp_path):
    """Test that get() with any invalid keys raises KeyError."""
    io = asebytes.BlobIO(asebytes.LMDBBlobBackend(str(tmp_path / "test.lmdb")))
    io[0] = {b"key1": b"value1", b"key2": b"value2"}

    # Requesting only nonexistent keys should raise KeyError
    with pytest.raises(KeyError, match="Invalid keys"):
        io.get(0, keys=[b"nonexistent_key"])

    # Multiple nonexistent keys should also raise
    with pytest.raises(KeyError, match="Invalid keys"):
        io.get(0, keys=[b"nonexistent1", b"nonexistent2"])

    # Mix of valid and invalid keys should also raise
    with pytest.raises(KeyError, match="Invalid keys"):
        io.get(0, keys=[b"key1", b"nonexistent_key"])


def test_bytesio_getitem_after_delete_raises_indexerror(tmp_path):
    """Test that accessing deleted index raises IndexError."""
    io = asebytes.BlobIO(asebytes.LMDBBlobBackend(str(tmp_path / "test.lmdb")))
    io[0] = {b"test": b"data1"}
    io[1] = {b"test": b"data2"}
    del io[0]

    # After deletion, old index 1 becomes index 0
    # Trying to access index 1 should now fail
    with pytest.raises(IndexError):
        _ = io[1]


def test_bytesio_delete_from_empty_raises_indexerror(tmp_path):
    """Test that deleting from empty BlobIO raises IndexError."""
    io = asebytes.BlobIO(asebytes.LMDBBlobBackend(str(tmp_path / "test.lmdb")))
    with pytest.raises(IndexError, match="Index 0 out of range"):
        del io[0]


# =============================================================================
# Tests for ASEIO errors
# =============================================================================


def test_aseio_getitem_nonexistent_index_raises_indexerror(tmp_path):
    """Test that accessing non-existent index raises IndexError."""
    io = asebytes.ASEIO(str(tmp_path / "test.lmdb"))
    with pytest.raises(IndexError):
        _ = io[0]


def test_aseio_delitem_out_of_bounds_raises_indexerror(tmp_path):
    """Test that deleting out-of-bounds index raises IndexError."""
    io = asebytes.ASEIO(str(tmp_path / "test.lmdb"))
    atoms = Atoms("H", positions=[[0, 0, 0]])
    io[0] = atoms

    with pytest.raises(IndexError, match="Index 5 out of range"):
        del io[5]


def test_aseio_setitem_with_non_atoms_raises_typeerror(tmp_path):
    """Test that setting non-Atoms object raises TypeError."""
    io = asebytes.ASEIO(str(tmp_path / "test.lmdb"))
    with pytest.raises(TypeError, match="Input must be an ase.Atoms object"):
        io[0] = "not an atoms object"


def test_aseio_insert_with_non_atoms_raises_typeerror(tmp_path):
    """Test that inserting non-Atoms object raises TypeError."""
    io = asebytes.ASEIO(str(tmp_path / "test.lmdb"))
    with pytest.raises(TypeError, match="Input must be an ase.Atoms object"):
        io.insert(0, {"not": "atoms"})


def test_aseio_extend_with_non_atoms_list_raises_typeerror(tmp_path):
    """Test that extending with non-Atoms objects raises TypeError."""
    io = asebytes.ASEIO(str(tmp_path / "test.lmdb"))
    with pytest.raises(TypeError, match="Input must be an ase.Atoms object"):
        io.extend(["not", "atoms", "objects"])


def test_aseio_delete_from_empty_raises_indexerror(tmp_path):
    """Test that deleting from empty ASEIO raises IndexError."""
    io = asebytes.ASEIO(str(tmp_path / "test.lmdb"))
    with pytest.raises(IndexError, match="Index 0 out of range"):
        del io[0]
