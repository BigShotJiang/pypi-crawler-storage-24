"""
ApiErrorResponse — mirrors Java ApiErrorResponse + ErrorResponse.
Formats exceptions into the standard Mobius JSON error format.
"""

import time
from typing import Optional, List, Any
from .error import Error, ErrorMessage, HttpStatus
from .exceptions import ApiException, ApplicationException


DOC_URL = "https://mobiusdtaas.atlassian.net/wiki/spaces/EN/pages/2360868868/Mobius+Documentation+for+Common+Issues"

_app_name: str = "unknown-service"


def set_app_name(name: str):
    """Call this at startup to set your service name in all error responses."""
    global _app_name
    _app_name = name


def get_app_name() -> str:
    return _app_name


class ApiErrorResponse:
    """
    Mirrors Java ApiErrorResponse.
    Converts any ApiException into the standard Mobius JSON error format:

    {
        "timestamp": 1774259394599,
        "origin": "my-service",
        "errorCode": 404000,
        "errorMessage": "Resource not found.",
        "subErrors": [...],
        "actionsRequired": [...],
        "httpStatusCode": "NOT_FOUND",
        "docUrl": "..."
    }
    """

    def __init__(
        self,
        http_status_code: int = HttpStatus.INTERNAL_SERVER_ERROR,
        error_message: str = "Encountered an unexpected error",
        error_code: int = 5001,
        sub_errors: Optional[List[ErrorMessage]] = None,
        actions_required: Optional[List[str]] = None,
        cause: Optional[ErrorMessage] = None,
        origin: Optional[str] = None,
        detailed_error_message: Optional[str] = None,
        error_object: Optional[Any] = None,
    ):
        self.timestamp = int(time.time() * 1000)  # milliseconds like Java
        self.http_status_code = http_status_code
        self.error_code = error_code
        self.error_message = error_message
        self.detailed_error_message = detailed_error_message
        self.sub_errors: List[ErrorMessage] = sub_errors or []
        self.actions_required: List[str] = actions_required or []
        self.cause = cause
        self.origin = origin or get_app_name()
        self.error_object = error_object
        self.doc_url = DOC_URL

    # ------------------------------------------------------------------ #
    #  Factory methods — mirrors Java constructor overloads               #
    # ------------------------------------------------------------------ #

    @classmethod
    def from_exception(cls, exc: ApiException) -> "ApiErrorResponse":
        """Build response from any ApiException subclass."""
        response = cls(
            http_status_code=exc.http_status_code,
            error_message=exc.error_message or exc.error.error_message,
            error_code=exc.error.error_code,
            origin=exc.origin or get_app_name(),
            error_object=exc.error_object,
        )

        # actions_required: from exception + error default
        if exc.actions_required:
            response.actions_required.extend(exc.actions_required)
        if exc.error.action_required:
            response.actions_required.append(exc.error.action_required)

        # sub_errors
        if exc.sub_errors:
            response.sub_errors.extend(exc.sub_errors)

        # nested cause
        if exc.nested_error_message:
            response.cause = exc.nested_error_message

        # ApplicationException extras
        if isinstance(exc, ApplicationException):
            response.detailed_error_message = exc.detailed_error_message

        return response

    @classmethod
    def from_error(cls, error: Error, origin: Optional[str] = None) -> "ApiErrorResponse":
        """Build response directly from an Error definition."""
        return cls(
            http_status_code=error.http_status_code,
            error_message=error.error_message,
            error_code=error.error_code,
            actions_required=[error.action_required] if error.action_required else [],
            origin=origin or get_app_name(),
        )

    @classmethod
    def from_status_and_message(cls, http_status_code: int, message: str) -> "ApiErrorResponse":
        """Build a simple response from status + message string."""
        return cls(http_status_code=http_status_code, error_message=message)

    # ------------------------------------------------------------------ #
    #  Serialization                                                       #
    # ------------------------------------------------------------------ #

    def to_dict(self) -> dict:
        result = {
            "timestamp": self.timestamp,
            "origin": self.origin,
            "errorCode": self.error_code,
            "errorMessage": self.error_message,
            "httpStatusCode": HttpStatus.get_name(self.http_status_code),
            "docUrl": self.doc_url,
        }

        if self.detailed_error_message:
            result["detailedErrorMessage"] = self.detailed_error_message

        if self.sub_errors:
            result["subErrors"] = [e.to_dict() for e in self.sub_errors]

        if self.actions_required:
            result["actionsRequired"] = self.actions_required

        if self.cause:
            result["cause"] = self.cause.to_dict()

        if self.error_object:
            result["errorObject"] = self.error_object

        return result

    def add_sub_error(self, sub_error: ErrorMessage):
        self.sub_errors.append(sub_error)

    def add_action_required(self, action: str):
        self.actions_required.append(action)
