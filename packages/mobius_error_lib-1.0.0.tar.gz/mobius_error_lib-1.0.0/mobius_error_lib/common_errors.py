"""
CommonErrors — mirrors Java CommonErrors class.
Pre-defined Error constants reusable across all Python microservices.

Usage:
    from mobius_error_lib import CommonErrors
    raise ApiException(CommonErrors.NOT_FOUND, "User not found")
"""

from .error import Error, HttpStatus


class CommonErrors:
    """Static error definitions. Extend this in your service for custom errors."""

    def __new__(cls):
        raise TypeError("CommonErrors is a utility class and cannot be instantiated.")

    # ── 400 Bad Request ────────────────────────────────────────────────
    KAFKA_ERROR = Error(
        http_status_code=HttpStatus.BAD_REQUEST,
        error_code=400000,
        error_message="An error occurred in kafka",
        action_required="Kindly contact the support team",
    )

    KAFKA_CONSUMPTION_ERROR = Error(
        http_status_code=HttpStatus.BAD_REQUEST,
        error_code=400001,
        error_message="An error occurred while consuming a message from kafka",
        action_required="Kindly contact the support team",
    )

    INVALID_NAME = Error(
        http_status_code=HttpStatus.BAD_REQUEST,
        error_code=400002,
        error_message="The name provided is invalid",
        action_required="Kindly try with another name",
    )

    UNSUPPORTED_OPERATION = Error(
        http_status_code=HttpStatus.BAD_REQUEST,
        error_code=400003,
        error_message="This operation is not yet supported",
        action_required="Kindly try another operation",
    )

    INVALID_ENUM_INPUT = Error(
        http_status_code=HttpStatus.BAD_REQUEST,
        error_code=400004,
        error_message="Invalid enum value provided",
        action_required="Please provide a valid input",
    )

    # ── 401 Unauthorized ───────────────────────────────────────────────
    TENANT_NOT_AUTHORIZED = Error(
        http_status_code=HttpStatus.UNAUTHORIZED,
        error_code=401000,
        error_message="You're not authorized to access the resource",
        action_required="Kindly request appropriate access required for your needs to its owner",
    )

    # ── 403 Forbidden ──────────────────────────────────────────────────
    INVALID_TENANT_ID = Error(
        http_status_code=HttpStatus.FORBIDDEN,
        error_code=403002,
        error_message="You're not registered as a tenant yet",
        action_required="Kindly get yourself registered first",
    )

    # ── 404 Not Found ──────────────────────────────────────────────────
    RESOURCE_NOT_FOUND = Error(
        http_status_code=HttpStatus.NOT_FOUND,
        error_code=404000,
        error_message="The requested resource does not exist",
        action_required="Please provide a valid resource ID",
    )

    # ── 409 Conflict ───────────────────────────────────────────────────
    CONSTRAINT_VIOLATION = Error(
        http_status_code=HttpStatus.CONFLICT,
        error_code=409000,
        error_message="Constraint violation occurred. This operation cannot be completed.",
        action_required="Verify that all data meets the required constraints and try again.",
    )

    # ── 500 Internal Server Error ──────────────────────────────────────
    UNEXPECTED_ERROR = Error(
        http_status_code=HttpStatus.INTERNAL_SERVER_ERROR,
        error_code=500000,
        error_message="Encountered an unexpected error",
        action_required="Please try again. If the issue persists, contact support.",
    )

    SERVICE_UNAVAILABLE = Error(
        http_status_code=HttpStatus.INTERNAL_SERVER_ERROR,
        error_code=500001,
        error_message="One or more service(s) are not up and running",
        action_required="Please try again. If the issue persists, contact support.",
    )

    OBJECT_MAPPING_FAILURE = Error(
        http_status_code=HttpStatus.INTERNAL_SERVER_ERROR,
        error_code=500002,
        error_message="Failed to convert JSON to object/map or vice versa",
        action_required="Kindly verify the request structure",
    )

    GROUP_DATA_RETRIEVAL_FAILURE = Error(
        http_status_code=HttpStatus.INTERNAL_SERVER_ERROR,
        error_code=500003,
        error_message="Failed to get group data from data lake",
        action_required="Kindly verify if the group contains data",
    )

    GET_API_FAILURE = Error(
        http_status_code=HttpStatus.INTERNAL_SERVER_ERROR,
        error_code=500004,
        error_message="Failed to GET data from the URL",
        action_required="Kindly verify if the URL is working",
    )

    POST_API_FAILURE = Error(
        http_status_code=HttpStatus.INTERNAL_SERVER_ERROR,
        error_code=500005,
        error_message="Failed to make POST call to an API",
        action_required="Kindly verify if the POST API service is up and running",
    )

    REST_API_FAILURE = Error(
        http_status_code=HttpStatus.INTERNAL_SERVER_ERROR,
        error_code=500006,
        error_message="Failed to make REST call to an API",
        action_required="Kindly verify if the REST API service is up and running",
    )

    # ── 503 Service Unavailable ────────────────────────────────────────
    TIDB_UNAVAILABLE = Error(
        http_status_code=HttpStatus.SERVICE_UNAVAILABLE,
        error_code=503001,
        error_message="We are currently experiencing technical difficulties",
        action_required="Ensure that the TiDB service is up and running",
    )

    REDIS_UNAVAILABLE = Error(
        http_status_code=HttpStatus.SERVICE_UNAVAILABLE,
        error_code=503002,
        error_message="We are currently experiencing technical difficulties with Redis",
        action_required="Ensure that the Redis service is up and running",
    )

    MONGO_UNAVAILABLE = Error(
        http_status_code=HttpStatus.SERVICE_UNAVAILABLE,
        error_code=503003,
        error_message="We are currently experiencing technical difficulties with MongoDB",
        action_required="Ensure that the MongoDB service is up and running",
    )
