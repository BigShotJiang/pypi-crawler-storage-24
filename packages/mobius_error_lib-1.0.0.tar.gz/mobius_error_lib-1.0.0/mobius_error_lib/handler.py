"""
FastAPI Exception Handler — mirrors Java RestExceptionHandler (@ControllerAdvice).

Registers global exception handlers on your FastAPI app so ALL exceptions
are automatically caught and formatted into the standard Mobius JSON error format.

Usage:
    from fastapi import FastAPI
    from mobius_error_lib import register_exception_handlers, set_app_name

    app = FastAPI()
    set_app_name("my-python-service")
    register_exception_handlers(app)
"""

import logging
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from .error import ErrorMessage, HttpStatus
from .response import ApiErrorResponse
from .exceptions import (
    ApiException,
    ApplicationException,
    ValidationException,
    AccessViolationException,
    DataTypeMismatchException,
    TokenException,
)

logger = logging.getLogger(__name__)


def register_exception_handlers(app: FastAPI) -> None:
    """
    Register all Mobius exception handlers on a FastAPI app.

    Call this once during app startup:
        register_exception_handlers(app)
    """

    # ── 1. ApiException and all subclasses ────────────────────────────
    @app.exception_handler(ApiException)
    async def handle_api_exception(request: Request, exc: ApiException) -> JSONResponse:
        logger.error("ApiException: %s", exc, exc_info=True)
        response = ApiErrorResponse.from_exception(exc)
        return JSONResponse(status_code=exc.http_status_code, content=response.to_dict())

    # ── 2. ValidationException (409 Conflict) ─────────────────────────
    @app.exception_handler(ValidationException)
    async def handle_validation_exception(request: Request, exc: ValidationException) -> JSONResponse:
        logger.error("ValidationException: %s", exc, exc_info=True)
        response = ApiErrorResponse.from_exception(exc)
        return JSONResponse(status_code=HttpStatus.CONFLICT, content=response.to_dict())

    # ── 3. AccessViolationException (403 Forbidden) ───────────────────
    @app.exception_handler(AccessViolationException)
    async def handle_access_violation(request: Request, exc: AccessViolationException) -> JSONResponse:
        logger.error("AccessViolationException: %s", exc, exc_info=True)
        response = ApiErrorResponse.from_exception(exc)
        return JSONResponse(status_code=HttpStatus.FORBIDDEN, content=response.to_dict())

    # ── 4. DataTypeMismatchException (400 Bad Request) ────────────────
    @app.exception_handler(DataTypeMismatchException)
    async def handle_data_type_mismatch(request: Request, exc: DataTypeMismatchException) -> JSONResponse:
        logger.error("DataTypeMismatchException: %s", exc, exc_info=True)
        response = ApiErrorResponse.from_exception(exc)
        return JSONResponse(status_code=HttpStatus.BAD_REQUEST, content=response.to_dict())

    # ── 5. TokenException (401 Unauthorized) ──────────────────────────
    @app.exception_handler(TokenException)
    async def handle_token_exception(request: Request, exc: TokenException) -> JSONResponse:
        logger.error("TokenException: %s", exc, exc_info=True)
        response = ApiErrorResponse.from_exception(exc)
        return JSONResponse(status_code=HttpStatus.UNAUTHORIZED, content=response.to_dict())

    # ── 6. FastAPI RequestValidationError (422 → 400) ─────────────────
    @app.exception_handler(RequestValidationError)
    async def handle_request_validation_error(request: Request, exc: RequestValidationError) -> JSONResponse:
        logger.error("RequestValidationError: %s", exc)
        response = ApiErrorResponse.from_status_and_message(
            HttpStatus.BAD_REQUEST,
            "Request validation failed",
        )
        for error in exc.errors():
            field = " -> ".join(str(loc) for loc in error["loc"])
            msg = error["msg"]
            response.add_sub_error(ErrorMessage(message=f"{field}: {msg}"))
        response.add_action_required("Please verify all required fields and their types.")
        return JSONResponse(status_code=HttpStatus.BAD_REQUEST, content=response.to_dict())

    # ── 7. Starlette HTTPException (404, 405, etc.) ────────────────────
    @app.exception_handler(StarletteHTTPException)
    async def handle_http_exception(request: Request, exc: StarletteHTTPException) -> JSONResponse:
        logger.error("HTTPException %s: %s", exc.status_code, exc.detail)
        response = ApiErrorResponse.from_status_and_message(exc.status_code, str(exc.detail))
        return JSONResponse(status_code=exc.status_code, content=response.to_dict())

    # ── 8. Catch-all — any unhandled Exception → 500 ──────────────────
    @app.exception_handler(Exception)
    async def handle_unexpected_exception(request: Request, exc: Exception) -> JSONResponse:
        logger.error("Unexpected error: %s", exc, exc_info=True)
        response = ApiErrorResponse(
            http_status_code=HttpStatus.INTERNAL_SERVER_ERROR,
            error_message=str(exc) or "Encountered an unexpected error",
            error_code=500000,
            cause=ErrorMessage(message=str(exc.__cause__)) if exc.__cause__ else None,
        )
        return JSONResponse(status_code=HttpStatus.INTERNAL_SERVER_ERROR, content=response.to_dict())

    logger.info("Mobius error handlers registered successfully.")
