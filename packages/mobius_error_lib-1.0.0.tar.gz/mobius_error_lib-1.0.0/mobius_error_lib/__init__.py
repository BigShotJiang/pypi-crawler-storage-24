"""
mobius-error-lib
~~~~~~~~~~~~~~~~
Python exception library for Mobius microservices.
Mirrors the Java error-spring-lib for consistent error formatting across services.

Quick Start:
    from fastapi import FastAPI
    from mobius_error_lib import (
        register_exception_handlers,
        set_app_name,
        ApiException,
        ValidationException,
        AccessViolationException,
        TokenException,
        CommonErrors,
        Error,
        ErrorMessage,
    )

    app = FastAPI()
    set_app_name("my-service")
    register_exception_handlers(app)

    # Then anywhere in your code:
    raise ApiException(CommonErrors.RESOURCE_NOT_FOUND, "User with id 123 not found")
"""

from .error import Error, ErrorMessage, HttpStatus
from .exceptions import (
    ApiException,
    ApplicationException,
    ValidationException,
    AccessViolationException,
    DataTypeMismatchException,
    TokenException,
    KafkaException,
    ObjectMappingException,
    RestException,
)
from .common_errors import CommonErrors
from .response import ApiErrorResponse, set_app_name, get_app_name
from .handler import register_exception_handlers

__version__ = "1.0.0"
__author__ = "Mobius Platform Team"

__all__ = [
    # Core
    "Error",
    "ErrorMessage",
    "HttpStatus",
    # Exceptions
    "ApiException",
    "ApplicationException",
    "ValidationException",
    "AccessViolationException",
    "DataTypeMismatchException",
    "TokenException",
    "KafkaException",
    "ObjectMappingException",
    "RestException",
    # Pre-defined errors
    "CommonErrors",
    # Response
    "ApiErrorResponse",
    # Config
    "set_app_name",
    "get_app_name",
    # FastAPI handler
    "register_exception_handlers",
]
