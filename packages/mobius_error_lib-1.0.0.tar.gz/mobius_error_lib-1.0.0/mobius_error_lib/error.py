"""
Core Error and ErrorMessage classes — mirrors Java Error + ErrorMessage
"""

import time
from dataclasses import dataclass, field
from typing import Optional
from http import HTTPStatus


class HttpStatus:
    """HTTP Status constants mirroring Spring's HttpStatus"""
    OK = 200
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    FORBIDDEN = 403
    NOT_FOUND = 404
    CONFLICT = 409
    UNSUPPORTED_MEDIA_TYPE = 415
    INTERNAL_SERVER_ERROR = 500
    SERVICE_UNAVAILABLE = 503

    _STATUS_NAMES = {
        200: "OK",
        400: "BAD_REQUEST",
        401: "UNAUTHORIZED",
        403: "FORBIDDEN",
        404: "NOT_FOUND",
        409: "CONFLICT",
        415: "UNSUPPORTED_MEDIA_TYPE",
        500: "INTERNAL_SERVER_ERROR",
        503: "SERVICE_UNAVAILABLE",
    }

    @classmethod
    def get_name(cls, code: int) -> str:
        return cls._STATUS_NAMES.get(code, str(code))


@dataclass
class ErrorMessage:
    """
    Mirrors Java ErrorMessage class.
    Used for subErrors and cause fields.
    """
    message: Optional[str] = None
    action_required: Optional[str] = None
    root_message: Optional[str] = None
    root_origin: Optional[str] = None
    origin: Optional[str] = None
    http_status_code: Optional[int] = None
    cause: Optional["ErrorMessage"] = None
    timestamp: int = field(default_factory=lambda: int(time.time()))

    def to_dict(self) -> dict:
        result = {}
        if self.message:
            result["message"] = self.message
        if self.action_required:
            result["actionRequired"] = self.action_required
        if self.root_message:
            result["rootMessage"] = self.root_message
        if self.root_origin:
            result["rootOrigin"] = self.root_origin
        if self.origin:
            result["origin"] = self.origin
        if self.http_status_code:
            result["httpStatusCode"] = HttpStatus.get_name(self.http_status_code)
        if self.cause:
            result["cause"] = self.cause.to_dict()
        result["timestamp"] = self.timestamp
        return result


@dataclass
class Error:
    """
    Mirrors Java Error class.
    Defines error metadata: HTTP status, error code, message, action.
    """
    http_status_code: int
    error_code: int
    error_message: str
    action_required: str
    error_message_description: Optional[ErrorMessage] = None

    def get_http_status_name(self) -> str:
        return HttpStatus.get_name(self.http_status_code)
