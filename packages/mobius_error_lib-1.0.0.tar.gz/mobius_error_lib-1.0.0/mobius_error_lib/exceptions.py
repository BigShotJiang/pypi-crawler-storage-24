"""
Exception classes — mirrors Java exception hierarchy:

BaseException
└── ApiException
    └── ApplicationException
        ├── ValidationException
        │   └── AccessViolationException
        ├── DataTypeMismatchException
        └── TokenException
"""

from typing import Optional, List
from .error import Error, ErrorMessage, HttpStatus


class ApiException(Exception):
    """
    Base exception — mirrors Java ApiException.
    All custom exceptions extend this.

    Usage:
        raise ApiException(CommonErrors.NOT_FOUND, "Resource not found")
    """

    def __init__(
        self,
        error: Error,
        error_message: Optional[str] = None,
        nested_error_message: Optional[ErrorMessage] = None,
        error_object: Optional[object] = None,
    ):
        self.error = error
        self.http_status_code = error.http_status_code
        self.error_message = error_message or error.error_message
        self.nested_error_message = nested_error_message
        self.error_object = error_object
        self.sub_errors: List[ErrorMessage] = []
        self.actions_required: List[str] = []
        self.origin: Optional[str] = None
        super().__init__(self.error_message)

    def add_sub_error(self, sub_error: ErrorMessage):
        self.sub_errors.append(sub_error)
        return self

    def add_action_required(self, action: str):
        self.actions_required.append(action)
        return self

    def with_origin(self, origin: str):
        self.origin = origin
        return self


class ApplicationException(ApiException):
    """
    Mirrors Java ApplicationException.
    Used for application-level errors with detailed error info.

    Usage:
        raise ApplicationException(CommonErrors.UNEXPECTED_ERROR, "Something broke")
    """

    def __init__(
        self,
        error: Error,
        error_message: Optional[str] = None,
        nested_error_message: Optional[ErrorMessage] = None,
        error_object: Optional[object] = None,
        detailed_error_message: Optional[str] = None,
    ):
        super().__init__(error, error_message, nested_error_message, error_object)
        self.detailed_error_message = detailed_error_message
        self.http_status_code = HttpStatus.FORBIDDEN


class ValidationException(ApplicationException):
    """
    Mirrors Java ValidationException.
    Used for input validation and constraint violations.

    Usage:
        raise ValidationException(CommonErrors.INVALID_INPUT, "Field x is required")
    """

    def __init__(
        self,
        error: Error,
        error_message: Optional[str] = None,
        nested_error_message: Optional[ErrorMessage] = None,
        error_object: Optional[object] = None,
    ):
        super().__init__(error, error_message, nested_error_message, error_object)
        self.http_status_code = HttpStatus.CONFLICT


class AccessViolationException(ValidationException):
    """
    Mirrors Java AccessViolationException.
    Used for 403 Forbidden / unauthorized access errors.

    Usage:
        raise AccessViolationException(CommonErrors.INVALID_TENANT_ID)
    """

    def __init__(
        self,
        error: Error,
        error_message: Optional[str] = None,
        nested_error_message: Optional[ErrorMessage] = None,
        error_object: Optional[object] = None,
    ):
        super().__init__(error, error_message, nested_error_message, error_object)
        self.http_status_code = HttpStatus.FORBIDDEN


class DataTypeMismatchException(ApplicationException):
    """
    Mirrors Java DataTypeMismatchException.
    Used for type mismatch errors in request data.

    Usage:
        raise DataTypeMismatchException(CommonErrors.TYPE_MISMATCH, "Expected int, got str")
    """

    def __init__(
        self,
        error: Error,
        error_message: Optional[str] = None,
        nested_error_message: Optional[ErrorMessage] = None,
    ):
        super().__init__(error, error_message, nested_error_message)
        self.http_status_code = HttpStatus.BAD_REQUEST


class TokenException(ApiException):
    """
    Mirrors Java TokenException.
    Used for JWT / auth token errors.

    Usage:
        raise TokenException(CommonErrors.TENANT_NOT_AUTHORIZED)
    """

    def __init__(
        self,
        error: Error,
        error_message: Optional[str] = None,
        nested_error_message: Optional[ErrorMessage] = None,
    ):
        super().__init__(error, error_message, nested_error_message)
        self.http_status_code = HttpStatus.UNAUTHORIZED


class KafkaException(ApplicationException):
    """
    Mirrors Java KafkaException.

    Usage:
        raise KafkaException("Failed to publish message")
    """

    def __init__(self, error: Error, error_message: Optional[str] = None, throwable: Optional[Exception] = None):
        nested = ErrorMessage(message=str(throwable)) if throwable else None
        super().__init__(error, error_message, nested)


class ObjectMappingException(ApplicationException):
    """
    Mirrors Java ObjectMappingException.
    Used when JSON serialization/deserialization fails.
    """

    def __init__(self, error: Error, error_message: Optional[str] = None):
        super().__init__(error, error_message)


class RestException(ApplicationException):
    """
    Mirrors Java RestException.
    Used for REST client failures.
    """

    def __init__(self, error: Error, error_message: Optional[str] = None, status_code: Optional[int] = None):
        super().__init__(error, error_message)
        if status_code:
            self.http_status_code = status_code
