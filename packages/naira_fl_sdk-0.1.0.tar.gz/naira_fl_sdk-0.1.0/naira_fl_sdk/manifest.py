"""Pydantic models for template.yaml manifest parsing and validation."""

import re
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


NAME_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")


class DataFile(BaseModel):
    name: str
    description: str = ""


class DataSpec(BaseModel):
    description: str = ""
    required_files: List[DataFile] = Field(default_factory=list)
    optional_files: List[DataFile] = Field(default_factory=list)


class HyperparameterDef(BaseModel):
    default: Any
    type: str = "float"
    description: str = ""


class ModelSpec(BaseModel):
    file: str = "model.py"
    class_name: str = Field(..., alias="class")

    model_config = {"populate_by_name": True}


class TrainerSpec(BaseModel):
    file: str = "trainer.py"


class FLConfig(BaseModel):
    min_clients: int = 2
    default_rounds: int = 10


class TemplateManifest(BaseModel):
    """Parsed and validated template.yaml."""

    name: str
    description: str
    framework: str = "pytorch"
    strategy: str = "fedavg"

    model: ModelSpec
    trainer: TrainerSpec

    requirements: List[str] = Field(default_factory=list)
    data: Optional[DataSpec] = None
    hyperparameters: Dict[str, HyperparameterDef] = Field(default_factory=dict)
    fl_config: FLConfig = Field(default_factory=FLConfig)

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not NAME_PATTERN.match(v):
            raise ValueError(
                f"Template name must match {NAME_PATTERN.pattern}, got: '{v}'"
            )
        return v

    @field_validator("framework")
    @classmethod
    def validate_framework(cls, v: str) -> str:
        allowed = {"pytorch", "tensorflow"}
        if v not in allowed:
            raise ValueError(f"framework must be one of {allowed}, got: '{v}'")
        return v

    @field_validator("strategy")
    @classmethod
    def validate_strategy(cls, v: str) -> str:
        allowed = {"fedavg"}
        if v not in allowed:
            raise ValueError(f"strategy must be one of {allowed}, got: '{v}'")
        return v

    def get_hyperparams_defaults(self) -> Dict[str, Any]:
        """Return dict of hyperparameter name -> default value."""
        return {k: v.default for k, v in self.hyperparameters.items()}


def parse_manifest(yaml_text: str) -> TemplateManifest:
    """Parse a template.yaml string into a validated TemplateManifest."""
    import yaml

    data = yaml.safe_load(yaml_text)
    if not isinstance(data, dict):
        raise ValueError("template.yaml must be a YAML mapping")
    return TemplateManifest(**data)


def parse_manifest_file(path: str) -> TemplateManifest:
    """Parse a template.yaml file into a validated TemplateManifest."""
    with open(path) as f:
        return parse_manifest(f.read())
