"""Starter trainer - implement the FLTrainer interface."""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from pathlib import Path

from naira_fl_sdk import FLTrainer
from model import SimpleModel


class SimpleTrainer(FLTrainer):
    """Example trainer implementation. Customize for your use case."""

    def setup(self, data_path: str, hyperparams: dict) -> None:
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.hyperparams = hyperparams

        # Init model
        self.model = SimpleModel().to(self.device)

        # Init optimizer
        self.optimizer = optim.Adam(
            self.model.parameters(),
            lr=hyperparams.get("learning_rate", 0.001),
        )
        self.criterion = nn.CrossEntropyLoss()

        # Load data
        dp = Path(data_path)
        train_data = torch.load(dp / "train_data.pt", weights_only=True)
        train_labels = torch.load(dp / "train_labels.pt", weights_only=True)
        self.train_loader = DataLoader(
            TensorDataset(train_data, train_labels),
            batch_size=hyperparams.get("batch_size", 32),
            shuffle=True,
        )

        # Optional validation data
        self.val_loader = None
        if (dp / "val_data.pt").exists():
            val_data = torch.load(dp / "val_data.pt", weights_only=True)
            val_labels = torch.load(dp / "val_labels.pt", weights_only=True)
            self.val_loader = DataLoader(
                TensorDataset(val_data, val_labels),
                batch_size=hyperparams.get("batch_size", 32),
            )

    def get_model(self) -> nn.Module:
        return self.model

    def train(self, model: nn.Module) -> dict:
        model.train()
        total_loss, total_samples = 0.0, 0
        for inputs, labels in self.train_loader:
            inputs, labels = inputs.to(self.device), labels.to(self.device)
            self.optimizer.zero_grad()
            outputs = model(inputs)
            loss = self.criterion(outputs, labels)
            loss.backward()
            self.optimizer.step()
            total_loss += loss.item() * inputs.size(0)
            total_samples += inputs.size(0)
        return {"train_loss": total_loss / total_samples, "num_samples": total_samples}

    def validate(self, model: nn.Module) -> dict:
        if self.val_loader is None:
            return {}
        # Set model to evaluation mode
        model.requires_grad_(False)
        model.training = False
        total_loss, correct, total = 0.0, 0, 0
        with torch.no_grad():
            for inputs, labels in self.val_loader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                outputs = model(inputs)
                loss = self.criterion(outputs, labels)
                total_loss += loss.item() * inputs.size(0)
                _, predicted = outputs.max(1)
                correct += predicted.eq(labels).sum().item()
                total += labels.size(0)
        model.requires_grad_(True)
        model.training = True
        return {"val_loss": total_loss / total, "accuracy": correct / total}
