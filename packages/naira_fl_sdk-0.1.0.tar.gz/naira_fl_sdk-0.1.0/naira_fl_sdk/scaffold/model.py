"""Starter model - replace with your own nn.Module."""

import torch.nn as nn


class SimpleModel(nn.Module):
    """Simple classifier model. Replace with your own architecture."""

    def __init__(self, input_dim=784, num_classes=10):
        super().__init__()
        self.flatten = nn.Flatten()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, num_classes),
        )

    def forward(self, x):
        x = self.flatten(x)
        return self.net(x)
