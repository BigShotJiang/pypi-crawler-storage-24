"""Naira FL SDK - Federated Learning template development kit."""

__version__ = "0.1.0"

from .trainer import FLTrainer

__all__ = ["FLTrainer", "__version__"]
