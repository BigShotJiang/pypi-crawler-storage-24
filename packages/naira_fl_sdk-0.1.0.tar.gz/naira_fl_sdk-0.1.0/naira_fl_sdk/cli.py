"""FL SDK CLI - scaffold, validate, test, and package templates."""

import json
import shutil
import sys
import zipfile
from pathlib import Path

import click

from .manifest import parse_manifest_file, NAME_PATTERN


@click.group()
@click.version_option()
def cli():
    """FL SDK - Federated Learning template development kit."""


@cli.command()
@click.argument("name")
@click.option("--framework", default="pytorch", type=click.Choice(["pytorch", "tensorflow"]))
def init(name, framework):
    """Scaffold a new template directory."""
    if not NAME_PATTERN.match(name):
        click.echo(f"Error: name must match {NAME_PATTERN.pattern}", err=True)
        sys.exit(1)

    target = Path(name)
    if target.exists():
        click.echo(f"Error: directory '{name}' already exists", err=True)
        sys.exit(1)

    scaffold_dir = Path(__file__).parent / "scaffold"
    target.mkdir()

    # Copy scaffold files
    for src_file in ["model.py", "trainer.py"]:
        src = scaffold_dir / src_file
        if src.exists():
            shutil.copy2(src, target / src_file)

    # Generate template.yaml
    manifest_content = f"""name: {name}
description: "TODO: describe your template"
framework: {framework}
strategy: fedavg

model:
  file: model.py
  class: SimpleModel

trainer:
  file: trainer.py

requirements: []

data:
  description: "TODO: describe the expected data format"
  required_files:
    - name: "train_data.pt"
      description: "Training data tensor"
    - name: "train_labels.pt"
      description: "Training labels tensor"
  optional_files:
    - name: "val_data.pt"
      description: "Validation data tensor"
    - name: "val_labels.pt"
      description: "Validation labels tensor"

hyperparameters:
  batch_size:
    default: 32
    type: int
    description: "Training batch size"
  learning_rate:
    default: 0.001
    type: float
    description: "Learning rate"

fl_config:
  min_clients: 2
  default_rounds: 10
"""
    (target / "template.yaml").write_text(manifest_content)
    (target / "requirements.txt").write_text("# Add extra pip dependencies here\n")

    click.echo(f"Template scaffolded at ./{name}/")
    click.echo("Next steps:")
    click.echo(f"  1. Edit {name}/model.py with your model")
    click.echo(f"  2. Edit {name}/trainer.py with your trainer")
    click.echo(f"  3. Fill in {name}/template.yaml")
    click.echo(f"  4. Run: fl-sdk validate ./{name}")


@cli.command()
@click.argument("template_dir", type=click.Path(exists=True))
def validate(template_dir):
    """Validate a template directory."""
    tdir = Path(template_dir).resolve()
    errors = []
    warnings = []

    # Check template.yaml exists
    manifest_path = tdir / "template.yaml"
    if not manifest_path.exists():
        click.echo("FAIL: template.yaml not found")
        sys.exit(1)

    # Parse manifest
    try:
        manifest = parse_manifest_file(str(manifest_path))
    except Exception as e:
        click.echo(f"FAIL: template.yaml parse error: {e}")
        sys.exit(1)

    click.echo(f"Template: {manifest.name}")
    click.echo(f"Framework: {manifest.framework}")
    click.echo(f"Strategy: {manifest.strategy}")

    # Check model file
    model_file = tdir / manifest.model.file
    if not model_file.exists():
        errors.append(f"Model file not found: {manifest.model.file}")
    else:
        content = model_file.read_text()
        if f"class {manifest.model.class_name}" not in content:
            warnings.append(
                f"Model class '{manifest.model.class_name}' not found in {manifest.model.file}"
            )

    # Check trainer file
    trainer_file = tdir / manifest.trainer.file
    if not trainer_file.exists():
        errors.append(f"Trainer file not found: {manifest.trainer.file}")
    else:
        content = trainer_file.read_text()
        if "FLTrainer" not in content:
            warnings.append(f"FLTrainer not referenced in {manifest.trainer.file}")

    # Check requirements.txt if listed
    if manifest.requirements:
        click.echo(f"Requirements: {', '.join(manifest.requirements)}")

    # Report
    if errors:
        for e in errors:
            click.echo(f"  ERROR: {e}")
        sys.exit(1)

    for w in warnings:
        click.echo(f"  WARN: {w}")

    click.echo("PASS: template is valid")


@cli.command()
@click.argument("template_dir", type=click.Path(exists=True))
@click.option("--rounds", default=2, help="Number of simulation rounds")
@click.option("--data", "data_path", default=None, help="Path to data directory")
def test(template_dir, rounds, data_path):
    """Run a local FL simulation (no NVFlare required)."""
    from .simulator import run_simulation

    run_simulation(
        template_dir=template_dir,
        data_path=data_path,
        num_rounds=rounds,
    )


@cli.command()
@click.argument("template_dir", type=click.Path(exists=True))
@click.option("-o", "--output", default=None, help="Output zip file path")
def package(template_dir, output):
    """Package a template directory into a zip file for upload."""
    tdir = Path(template_dir).resolve()

    # Validate first
    manifest_path = tdir / "template.yaml"
    if not manifest_path.exists():
        click.echo("Error: template.yaml not found", err=True)
        sys.exit(1)

    try:
        manifest = parse_manifest_file(str(manifest_path))
    except Exception as e:
        click.echo(f"Error: invalid template: {e}", err=True)
        sys.exit(1)

    output_path = Path(output) if output else Path(f"{manifest.name}.zip")

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in tdir.rglob("*"):
            if file_path.is_file():
                # Skip __pycache__ and hidden files
                rel = file_path.relative_to(tdir)
                if any(p.startswith(".") or p == "__pycache__" for p in rel.parts):
                    continue
                zf.write(file_path, str(rel))

    click.echo(f"Packaged: {output_path} ({output_path.stat().st_size} bytes)")
