"""FLTrainer abstract base class - the contract between FL admins and the platform."""

from abc import ABC, abstractmethod
from typing import Any, Dict


class FLTrainer(ABC):
    """Abstract base class for federated learning trainers.

    FL Admins implement this interface. The platform handles all NVFlare
    communication automatically via the adapter.

    Methods:
        setup: Called once when the FL client starts.
        get_model: Return the model instance (called each round).
        train: Train one round on local data.
        validate: Validate the model on local data.
    """

    @abstractmethod
    def setup(self, data_path: str, hyperparams: Dict[str, Any]) -> None:
        """Initialize model, data loaders, and optimizer.

        Called once at client start. Load your data from data_path and
        configure training based on hyperparams.

        Args:
            data_path: Path to the client's local data directory.
            hyperparams: Dictionary of hyperparameters from template.yaml.
        """

    @abstractmethod
    def get_model(self):
        """Return the PyTorch nn.Module model instance.

        Called each round to get/set weights via state_dict.
        """

    @abstractmethod
    def train(self, model) -> Dict[str, float]:
        """Train one round on local data.

        Args:
            model: The model with global weights already loaded.

        Returns:
            Dict with at least 'train_loss' (float). May include
            'num_samples' and other metrics.
        """

    @abstractmethod
    def validate(self, model) -> Dict[str, float]:
        """Validate model on local data.

        Args:
            model: The model with global weights already loaded.

        Returns:
            Dict with metrics. Should include 'val_loss' and 'accuracy'
            if validation data is available. May return empty dict.
        """
