"""Stats computation whiteboards."""
from __future__ import annotations

import textwrap

PLANS: dict[str, dict[str, str]] = {
    "daily_forward_stats": {
        "description": "enriched base+fwd → weighted agg (one row per horizon × group)",
        "code": textwrap.dedent("""\
            import polars as pl

            # --- Config (edit these) ---
            base_path = "/path/to/enriched/base"         # Delta Lake table
            fwd_path  = "/path/to/enriched/forward"      # Delta Lake table
            date      = "20250112"
            date_iso  = f"{date[:4]}-{date[4:6]}-{date[6:8]}"

            horizons  = [1000, 5000, 10000, 30000, 60000]    # ms
            weights   = ["fill_notional"]
            values    = ["sided_markout", "sided_return",
                         "sided_fill_to_near_touch", "sided_fill_to_far_touch"]

            # --- Plan ---
            date_filter    = pl.col("data_date") == pl.lit(date_iso).str.to_date()
            horizon_filter = pl.col("horizon").is_in(horizons)

            lf_base = pl.scan_delta(base_path).filter(date_filter)
            lf_fwd  = pl.scan_delta(fwd_path).filter(date_filter).filter(horizon_filter)

            df = (
                lf_fwd.join(
                    lf_base
                    .filter(pl.col("fill_qty") > 0)
                    .filter(pl.col("create_exchange_ts") > 93100000)   # skip first 1min
                    .filter(pl.col("update_exchange_ts") < 143000000)  # skip last 30min
                    .filter(pl.col("order_price_type") != "UKWN")
                    .with_columns(fill_notional=pl.col("fill_price") * pl.col("fill_qty"))
                    .select("seq", "data_date", "fill_notional",
                            "order_price_type", "order_side"),
                    on=["seq", "data_date"],
                )
                .group_by(["horizon", "order_price_type", "order_side"])
                .agg(
                    [pl.col(w).sum().alias(f"sum_{w}") for w in weights]
                    + [
                        (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                        for w in weights
                        for v in values
                    ]
                )
                .with_columns(data_date=pl.lit(date_iso).str.to_date())
                .collect()
            )
            df  # show result"""),
    },
    "execution_stats_1d": {
        "description": "1D bucketed stats: base × fwd_update → per-bucket agg with tod_bin (complete CLI script)",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"1D bucketed execution stats (base × fwd_update).

            Computes weighted aggregations bucketed by one dimension at a time.
            All bucket definitions use base table columns only (no fwd_h0 join).
            \"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            BASE_DIR    = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            FORWARD_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/fwd_update")
            OUTPUT_DIR  = Path("/cpfs/user2/ylu/data/oic_live/execution_stats_1d")

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            GROUP_KEYS = ["horizon", "order_price_type", "order_side", "tod_bin"]
            WEIGHTS    = ["fill_notional"]
            VALUES     = ["sided_markout", "sided_return", "sided_fill_to_near_touch"]

            # --- Bucket dimensions (all source=base) ---
            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))
            far_at_order  = pl.when(is_buy).then(pl.col("ask_size0_at_order")).otherwise(pl.col("bid_size0_at_order"))

            BUCKETS = {
                "tod_spread_improvement": {
                    "expr": (
                        (pl.col("half_spread_bps") * 2 - pl.col("tod_spread_bps"))
                        / (pl.col("half_spread_bps") * 2 + pl.col("tod_spread_bps"))
                    ),
                    "edges": [-1, -0.8, -0.5, -0.2, 0, 0.2, 0.5, 0.8, 1],
                },
                "near_touch_size_improvement": {
                    "expr": (near_at_order - pl.col("avg_touch_size")) / (near_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.2, 0, 0.2, 0.5],
                },
                "far_touch_size_improvement": {
                    "expr": (far_at_order - pl.col("avg_touch_size")) / (far_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.2, 0, 0.2, 0.5],
                },
                "sta_bps": {
                    "expr": pl.col("alp_st"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
                "lta_bps": {
                    "expr": pl.col("alp_lt"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
            }

            # ═══════════════════════════════════════════════════════════════
            # CORE
            # ═══════════════════════════════════════════════════════════════
            def compute(date: str) -> dict[str, pl.DataFrame]:
                date_iso = f"{date[:4]}-{date[4:6]}-{date[6:8]}"

                # 1. Read base (already has bid/ask_size0_at_order + avg_touch_size)
                lf_base = pl.scan_parquet(str(BASE_DIR / f"{date}.parquet"))

                # 2. Compute all bucket exprs
                lf_base = lf_base.with_columns([
                    spec["expr"].alias(bname) for bname, spec in BUCKETS.items()
                ])

                # 3. Filters + derived columns
                lf_base = (
                    lf_base
                    .filter(pl.col("create_exchange_ts") > 93100000)
                    .filter(pl.col("update_exchange_ts") < 143000000)
                    .filter(pl.col("order_price_type") != "UKWN")
                    .pipe(vf.add_tod, "create_exchange_ts")
                    .with_columns(
                        fill_notional=pl.col("fill_price") * pl.col("fill_qty"),
                        order_notional=pl.col("order_price") * pl.col("order_qty"),
                        tod_bin=pl.col("tod_create_exchange_ts").dt.truncate("5m"),
                    )
                )

                # 4. Read forward table
                lf_fwd = pl.scan_parquet(str(FORWARD_DIR / f"{date}.parquet")).filter(
                    pl.col("horizon").is_in(HORIZONS)
                )

                # 5. Per bucket: cut → join → group_by → agg
                results = {}
                for bname, spec in BUCKETS.items():
                    bucket_col = f"bucket_{bname}"
                    select_cols = [
                        "seq", "data_date", "fill_notional", "order_notional",
                        "event_type", "order_price_type", "order_side", "tod_bin", bucket_col,
                    ]

                    lf_bucketed = (
                        lf_base
                        .with_columns(pl.col(bname).cut(spec["edges"]).cast(pl.Utf8).alias(bucket_col))
                        .select(select_cols)
                    )

                    df = (
                        lf_fwd.join(lf_bucketed, on=["seq", "data_date"])
                        .group_by(GROUP_KEYS + [bucket_col])
                        .agg(
                            [pl.col(w).sum().alias(f"sum_{w}") for w in WEIGHTS]
                            + [
                                (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                                for w in WEIGHTS for v in VALUES
                            ]
                            + [
                                pl.col("order_notional")
                                .filter(pl.col("event_type") == "ORDACK")
                                .sum().alias("sum_order_notional"),
                            ]
                        )
                        .with_columns(data_date=pl.lit(date_iso).str.to_date())
                        .collect()
                    )
                    results[bname] = df

                return results

            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                all_exist = all(
                    (OUTPUT_DIR / f"{b}_bucketing_stats" / f"{args.date}.parquet").exists()
                    for b in BUCKETS
                )
                if all_exist and not args.force:
                    print(f"  skip {args.date} (complete)")
                    return

                print(f"Processing {args.date}...")
                results = compute(args.date)

                for bname, df in results.items():
                    out_dir = OUTPUT_DIR / f"{bname}_bucketing_stats"
                    out_dir.mkdir(parents=True, exist_ok=True)
                    out_file = out_dir / f"{args.date}.parquet"
                    df.write_parquet(str(out_file))
                    print(f"  {bname}: {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "execution_stats_2d": {
        "description": "2D bucketed stats: base × fwd_update → (bucket_a × bucket_b) agg, no tod_bin (complete CLI script)",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"2D bucketed execution stats (base × fwd_update).

            Group by TWO bucket dimensions simultaneously.
            No tod_bin (controls data volume). Finer edges than 1D.
            \"\"\"
            from __future__ import annotations

            import argparse
            from itertools import combinations
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            BASE_DIR    = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            FORWARD_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/fwd_update")
            OUTPUT_DIR  = Path("/cpfs/user2/ylu/data/oic_live/execution_stats_2d")

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            GROUP_KEYS = ["horizon", "order_price_type", "order_side"]   # no tod_bin
            WEIGHTS    = ["fill_notional"]
            VALUES     = ["sided_markout", "sided_return", "sided_fill_to_near_touch"]

            # Finer edges for 2D analysis
            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))
            far_at_order  = pl.when(is_buy).then(pl.col("ask_size0_at_order")).otherwise(pl.col("bid_size0_at_order"))

            BUCKETS = {
                "tod_spread_improvement": {
                    "expr": (
                        (pl.col("half_spread_bps") * 2 - pl.col("tod_spread_bps"))
                        / (pl.col("half_spread_bps") * 2 + pl.col("tod_spread_bps"))
                    ),
                    "edges": [-1, -0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8, 1],
                },
                "near_touch_size_improvement": {
                    "expr": (near_at_order - pl.col("avg_touch_size")) / (near_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.5],
                },
                "far_touch_size_improvement": {
                    "expr": (far_at_order - pl.col("avg_touch_size")) / (far_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.5],
                },
                "sta_bps": {
                    "expr": pl.col("alp_st"),
                    "edges": [-20e-4, -15e-4, -10e-4, -7e-4, -5e-4, -3e-4, -2e-4, -1e-4,
                              0, 1e-4, 2e-4, 3e-4, 5e-4, 7e-4, 10e-4, 15e-4, 20e-4],
                },
                "lta_bps": {
                    "expr": pl.col("alp_lt"),
                    "edges": [-20e-4, -15e-4, -10e-4, -7e-4, -5e-4, -3e-4, -2e-4, -1e-4,
                              0, 1e-4, 2e-4, 3e-4, 5e-4, 7e-4, 10e-4, 15e-4, 20e-4],
                },
            }

            # Which 2D pairs to compute (default: all pairs)
            PAIRS = list(combinations(BUCKETS.keys(), 2))

            # ═══════════════════════════════════════════════════════════════
            # CORE
            # ═══════════════════════════════════════════════════════════════
            def compute(date: str) -> dict[str, pl.DataFrame]:
                date_iso = f"{date[:4]}-{date[4:6]}-{date[6:8]}"

                lf_base = pl.scan_parquet(str(BASE_DIR / f"{date}.parquet"))

                # Compute all bucket exprs
                lf_base = lf_base.with_columns([
                    spec["expr"].alias(bname) for bname, spec in BUCKETS.items()
                ])

                # Filters + derived
                lf_base = (
                    lf_base
                    .filter(pl.col("create_exchange_ts") > 93100000)
                    .filter(pl.col("update_exchange_ts") < 143000000)
                    .filter(pl.col("order_price_type") != "UKWN")
                    .with_columns(
                        fill_notional=pl.col("fill_price") * pl.col("fill_qty"),
                        order_notional=pl.col("order_price") * pl.col("order_qty"),
                    )
                )

                lf_fwd = pl.scan_parquet(str(FORWARD_DIR / f"{date}.parquet")).filter(
                    pl.col("horizon").is_in(HORIZONS)
                )

                # Per pair: cut both → join → group_by → agg
                results = {}
                for bname_a, bname_b in PAIRS:
                    col_a = f"bucket_{bname_a}"
                    col_b = f"bucket_{bname_b}"

                    lf_bucketed = (
                        lf_base
                        .with_columns([
                            pl.col(bname_a).cut(BUCKETS[bname_a]["edges"]).cast(pl.Utf8).alias(col_a),
                            pl.col(bname_b).cut(BUCKETS[bname_b]["edges"]).cast(pl.Utf8).alias(col_b),
                        ])
                        .select([
                            "seq", "data_date", "fill_notional", "order_notional",
                            "event_type", "order_price_type", "order_side", col_a, col_b,
                        ])
                    )

                    df = (
                        lf_fwd.join(lf_bucketed, on=["seq", "data_date"])
                        .group_by(GROUP_KEYS + [col_a, col_b])
                        .agg(
                            [pl.col(w).sum().alias(f"sum_{w}") for w in WEIGHTS]
                            + [
                                (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                                for w in WEIGHTS for v in VALUES
                            ]
                            + [
                                pl.col("order_notional")
                                .filter(pl.col("event_type") == "ORDACK")
                                .sum().alias("sum_order_notional"),
                            ]
                        )
                        .with_columns(data_date=pl.lit(date_iso).str.to_date())
                        .collect()
                    )
                    pair_name = f"{bname_a}_x_{bname_b}"
                    results[pair_name] = df

                return results

            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                print(f"Processing {args.date}... ({len(PAIRS)} pairs)")
                results = compute(args.date)

                for pair_name, df in results.items():
                    out_dir = OUTPUT_DIR / f"{pair_name}_2d_stats"
                    out_dir.mkdir(parents=True, exist_ok=True)
                    out_file = out_dir / f"{args.date}.parquet"
                    df.write_parquet(str(out_file))
                    print(f"  {pair_name}: {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "sizing_stats_1d": {
        "description": "1D bucketed stats: base × fwd_create → signal/sizing analysis with tod_bin (complete CLI script)",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"1D bucketed sizing stats (base × fwd_create).

            Same structure as execution_stats_1d but uses fwd_create (create_ts).
            Answers: "After order placement, how did the market move?"
            \"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG — only FORWARD_DIR and OUTPUT_DIR differ from execution
            # ═══════════════════════════════════════════════════════════════
            BASE_DIR    = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            FORWARD_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/fwd_create")
            OUTPUT_DIR  = Path("/cpfs/user2/ylu/data/oic_live/sizing_stats_1d")

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            GROUP_KEYS = ["horizon", "order_price_type", "order_side", "tod_bin"]
            WEIGHTS    = ["fill_notional"]
            VALUES     = ["sided_markout", "sided_return", "sided_fill_to_near_touch"]

            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))
            far_at_order  = pl.when(is_buy).then(pl.col("ask_size0_at_order")).otherwise(pl.col("bid_size0_at_order"))

            BUCKETS = {
                "tod_spread_improvement": {
                    "expr": (
                        (pl.col("half_spread_bps") * 2 - pl.col("tod_spread_bps"))
                        / (pl.col("half_spread_bps") * 2 + pl.col("tod_spread_bps"))
                    ),
                    "edges": [-1, -0.8, -0.5, -0.2, 0, 0.2, 0.5, 0.8, 1],
                },
                "near_touch_size_improvement": {
                    "expr": (near_at_order - pl.col("avg_touch_size")) / (near_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.2, 0, 0.2, 0.5],
                },
                "far_touch_size_improvement": {
                    "expr": (far_at_order - pl.col("avg_touch_size")) / (far_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.2, 0, 0.2, 0.5],
                },
                "sta_bps": {
                    "expr": pl.col("alp_st"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
                "lta_bps": {
                    "expr": pl.col("alp_lt"),
                    "edges": [-20e-4, -10e-4, -5e-4, -2e-4, -1e-4, 0, 1e-4, 2e-4, 5e-4, 10e-4, 20e-4],
                },
            }

            # ═══════════════════════════════════════════════════════════════
            # CORE (identical to execution_stats_1d)
            # ═══════════════════════════════════════════════════════════════
            def compute(date: str) -> dict[str, pl.DataFrame]:
                date_iso = f"{date[:4]}-{date[4:6]}-{date[6:8]}"

                lf_base = pl.scan_parquet(str(BASE_DIR / f"{date}.parquet"))
                lf_base = lf_base.with_columns([
                    spec["expr"].alias(bname) for bname, spec in BUCKETS.items()
                ])
                lf_base = (
                    lf_base
                    .filter(pl.col("create_exchange_ts") > 93100000)
                    .filter(pl.col("update_exchange_ts") < 143000000)
                    .filter(pl.col("order_price_type") != "UKWN")
                    .pipe(vf.add_tod, "create_exchange_ts")
                    .with_columns(
                        fill_notional=pl.col("fill_price") * pl.col("fill_qty"),
                        order_notional=pl.col("order_price") * pl.col("order_qty"),
                        tod_bin=pl.col("tod_create_exchange_ts").dt.truncate("5m"),
                    )
                )

                lf_fwd = pl.scan_parquet(str(FORWARD_DIR / f"{date}.parquet")).filter(
                    pl.col("horizon").is_in(HORIZONS)
                )

                results = {}
                for bname, spec in BUCKETS.items():
                    bucket_col = f"bucket_{bname}"
                    select_cols = [
                        "seq", "data_date", "fill_notional", "order_notional",
                        "event_type", "order_price_type", "order_side", "tod_bin", bucket_col,
                    ]
                    lf_bucketed = (
                        lf_base
                        .with_columns(pl.col(bname).cut(spec["edges"]).cast(pl.Utf8).alias(bucket_col))
                        .select(select_cols)
                    )
                    df = (
                        lf_fwd.join(lf_bucketed, on=["seq", "data_date"])
                        .group_by(GROUP_KEYS + [bucket_col])
                        .agg(
                            [pl.col(w).sum().alias(f"sum_{w}") for w in WEIGHTS]
                            + [
                                (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                                for w in WEIGHTS for v in VALUES
                            ]
                            + [
                                pl.col("order_notional")
                                .filter(pl.col("event_type") == "ORDACK")
                                .sum().alias("sum_order_notional"),
                            ]
                        )
                        .with_columns(data_date=pl.lit(date_iso).str.to_date())
                        .collect()
                    )
                    results[bname] = df
                return results

            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                all_exist = all(
                    (OUTPUT_DIR / f"{b}_bucketing_stats" / f"{args.date}.parquet").exists()
                    for b in BUCKETS
                )
                if all_exist and not args.force:
                    print(f"  skip {args.date} (complete)")
                    return

                print(f"Processing {args.date}...")
                results = compute(args.date)
                for bname, df in results.items():
                    out_dir = OUTPUT_DIR / f"{bname}_bucketing_stats"
                    out_dir.mkdir(parents=True, exist_ok=True)
                    out_file = out_dir / f"{args.date}.parquet"
                    df.write_parquet(str(out_file))
                    print(f"  {bname}: {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "sizing_stats_2d": {
        "description": "2D bucketed stats: base × fwd_create → signal/sizing 2D analysis (complete CLI script)",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"2D bucketed sizing stats (base × fwd_create).

            Same structure as execution_stats_2d but uses fwd_create (create_ts).
            \"\"\"
            from __future__ import annotations

            import argparse
            from itertools import combinations
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            BASE_DIR    = Path("/cpfs/user2/ylu/data/oic_live/enriched/base")
            FORWARD_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched/fwd_create")
            OUTPUT_DIR  = Path("/cpfs/user2/ylu/data/oic_live/sizing_stats_2d")

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            GROUP_KEYS = ["horizon", "order_price_type", "order_side"]
            WEIGHTS    = ["fill_notional"]
            VALUES     = ["sided_markout", "sided_return", "sided_fill_to_near_touch"]

            is_buy = pl.col("order_side") == "Buy"
            near_at_order = pl.when(is_buy).then(pl.col("bid_size0_at_order")).otherwise(pl.col("ask_size0_at_order"))
            far_at_order  = pl.when(is_buy).then(pl.col("ask_size0_at_order")).otherwise(pl.col("bid_size0_at_order"))

            BUCKETS = {
                "tod_spread_improvement": {
                    "expr": (
                        (pl.col("half_spread_bps") * 2 - pl.col("tod_spread_bps"))
                        / (pl.col("half_spread_bps") * 2 + pl.col("tod_spread_bps"))
                    ),
                    "edges": [-1, -0.8, -0.6, -0.4, -0.2, 0, 0.2, 0.4, 0.6, 0.8, 1],
                },
                "near_touch_size_improvement": {
                    "expr": (near_at_order - pl.col("avg_touch_size")) / (near_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.5],
                },
                "far_touch_size_improvement": {
                    "expr": (far_at_order - pl.col("avg_touch_size")) / (far_at_order + pl.col("avg_touch_size")),
                    "edges": [-0.5, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.5],
                },
                "sta_bps": {
                    "expr": pl.col("alp_st"),
                    "edges": [-20e-4, -15e-4, -10e-4, -7e-4, -5e-4, -3e-4, -2e-4, -1e-4,
                              0, 1e-4, 2e-4, 3e-4, 5e-4, 7e-4, 10e-4, 15e-4, 20e-4],
                },
                "lta_bps": {
                    "expr": pl.col("alp_lt"),
                    "edges": [-20e-4, -15e-4, -10e-4, -7e-4, -5e-4, -3e-4, -2e-4, -1e-4,
                              0, 1e-4, 2e-4, 3e-4, 5e-4, 7e-4, 10e-4, 15e-4, 20e-4],
                },
            }

            PAIRS = list(combinations(BUCKETS.keys(), 2))

            def compute(date: str) -> dict[str, pl.DataFrame]:
                date_iso = f"{date[:4]}-{date[4:6]}-{date[6:8]}"
                lf_base = pl.scan_parquet(str(BASE_DIR / f"{date}.parquet"))
                lf_base = lf_base.with_columns([
                    spec["expr"].alias(bname) for bname, spec in BUCKETS.items()
                ])
                lf_base = (
                    lf_base
                    .filter(pl.col("create_exchange_ts") > 93100000)
                    .filter(pl.col("update_exchange_ts") < 143000000)
                    .filter(pl.col("order_price_type") != "UKWN")
                    .with_columns(
                        fill_notional=pl.col("fill_price") * pl.col("fill_qty"),
                        order_notional=pl.col("order_price") * pl.col("order_qty"),
                    )
                )
                lf_fwd = pl.scan_parquet(str(FORWARD_DIR / f"{date}.parquet")).filter(
                    pl.col("horizon").is_in(HORIZONS)
                )

                results = {}
                for bname_a, bname_b in PAIRS:
                    col_a = f"bucket_{bname_a}"
                    col_b = f"bucket_{bname_b}"
                    lf_bucketed = (
                        lf_base
                        .with_columns([
                            pl.col(bname_a).cut(BUCKETS[bname_a]["edges"]).cast(pl.Utf8).alias(col_a),
                            pl.col(bname_b).cut(BUCKETS[bname_b]["edges"]).cast(pl.Utf8).alias(col_b),
                        ])
                        .select([
                            "seq", "data_date", "fill_notional", "order_notional",
                            "event_type", "order_price_type", "order_side", col_a, col_b,
                        ])
                    )
                    df = (
                        lf_fwd.join(lf_bucketed, on=["seq", "data_date"])
                        .group_by(GROUP_KEYS + [col_a, col_b])
                        .agg(
                            [pl.col(w).sum().alias(f"sum_{w}") for w in WEIGHTS]
                            + [
                                (pl.col(v) * pl.col(w)).sum().alias(f"sum_{w}_x_{v}")
                                for w in WEIGHTS for v in VALUES
                            ]
                            + [
                                pl.col("order_notional")
                                .filter(pl.col("event_type") == "ORDACK")
                                .sum().alias("sum_order_notional"),
                            ]
                        )
                        .with_columns(data_date=pl.lit(date_iso).str.to_date())
                        .collect()
                    )
                    results[f"{bname_a}_x_{bname_b}"] = df
                return results

            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                print(f"Processing {args.date}... ({len(PAIRS)} pairs)")
                results = compute(args.date)
                for pair_name, df in results.items():
                    out_dir = OUTPUT_DIR / f"{pair_name}_2d_stats"
                    out_dir.mkdir(parents=True, exist_ok=True)
                    out_file = out_dir / f"{args.date}.parquet"
                    df.write_parquet(str(out_file))
                    print(f"  {pair_name}: {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
}
