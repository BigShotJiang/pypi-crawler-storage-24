"""Enrichment pipeline whiteboards."""
from __future__ import annotations

import textwrap

PLANS: dict[str, dict[str, str]] = {
    "base_enrichment": {
        "description": "trade + quote(create_ts h=0) + univ → base table with book_at_order (complete CLI script)",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"Base table enrichment: trade events + order book at create_ts + univ.\"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            TRADE_DIR = Path("/cpfs/user2/ylu/data/oic_live/concat_sort")
            TRADE_PATTERN = "{date}.parquet"
            TRADE_SCHEMA = "oic_live"

            QUOTE_DIR = Path("/gpfs/nvmefs/marketdata/cn/stock/all/tob5")
            QUOTE_PATTERN = "{date}.feather"
            QUOTE_SCHEMA = "stock_sorted_t5ob"

            UNIV_DIR = Path("/cpfs/shared/public/ylu/univ")
            OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched")
            MARKET = "CN"

            TRADE_TIME_COL = "update_exchange_ts"
            CREATE_TIME_COL = "create_exchange_ts"
            QUOTE_TIME_COL = "ticktime"
            BOOK_REF_COLS = ["bid_size0", "ask_size0"]


            # ═══════════════════════════════════════════════════════════════
            # CORE
            # ═══════════════════════════════════════════════════════════════
            def process_date(date: str) -> pl.DataFrame:
                elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
                elapsed_create = f"elapsed_{CREATE_TIME_COL}"
                elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

                lf_trade = (
                    vf.scan_trade(date)
                    .pipe(vf.parse_time, TRADE_TIME_COL)
                    .pipe(vf.parse_time, CREATE_TIME_COL)
                    .sort(["ukey", elapsed_trade])
                    .with_columns(
                        pl.col("fill_qty").cum_sum()
                        .over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
                    )
                    .with_columns(
                        (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
                        (pl.col(elapsed_trade) - pl.col(elapsed_create)).alias("duration"),
                    )
                )

                lf_quote = (
                    vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + BOOK_REF_COLS)
                    .pipe(vf.parse_time, QUOTE_TIME_COL)
                )

                # Book at order time: backward asof on create_ts, h=0
                df_base = vf.merge_forward(
                    lf_trade, lf_quote,
                    ref_cols=BOOK_REF_COLS,
                    horizons=[0],
                    trade_time_col=elapsed_create,
                    ref_time_col=elapsed_quote,
                    strategy="backward",
                )
                df_base = df_base.rename({
                    f"{col}_0s": f"{col}_at_order" for col in BOOK_REF_COLS
                })

                # Join univ
                univ_path = UNIV_DIR / f"{date}.csv"
                if univ_path.exists():
                    df_univ = pl.read_csv(str(univ_path)).select(
                        "ukey", pl.col("avg_touch_size_mean").alias("avg_touch_size"),
                    )
                    df_base = df_base.join(df_univ, on="ukey", how="left")

                return df_base


            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                vf.set_config(vf.Config(
                    trade_dir=TRADE_DIR, trade_pattern=TRADE_PATTERN, trade_schema=TRADE_SCHEMA,
                    quote_dir=QUOTE_DIR, quote_pattern=QUOTE_PATTERN, quote_schema=QUOTE_SCHEMA,
                    market=MARKET,
                ))

                out_dir = OUTPUT_DIR / "base"
                out_file = out_dir / f"{args.date}.parquet"
                if out_file.exists() and not args.force:
                    print(f"  skip {args.date} (exists)")
                    return

                print(f"Processing {args.date}...")
                df = process_date(args.date)
                out_dir.mkdir(parents=True, exist_ok=True)
                df.write_parquet(str(out_file))
                print(f"  {len(df)} events -> {out_file}")


            if __name__ == "__main__":
                main()"""),
    },
    "forward_on_update": {
        "description": "trade + quote → forward table on update_ts (execution quality, complete CLI script)",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"Forward enrichment on update_ts: quote snapshots at each horizon after fill.\"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            TRADE_DIR = Path("/cpfs/user2/ylu/data/oic_live/concat_sort")
            TRADE_PATTERN = "{date}.parquet"
            TRADE_SCHEMA = "oic_live"

            QUOTE_DIR = Path("/gpfs/nvmefs/marketdata/cn/stock/all/tob5")
            QUOTE_PATTERN = "{date}.feather"
            QUOTE_SCHEMA = "stock_sorted_t5ob"

            OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched")
            MARKET = "CN"

            TRADE_TIME_COL = "update_exchange_ts"
            CREATE_TIME_COL = "create_exchange_ts"
            QUOTE_TIME_COL = "ticktime"

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            RAW_REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]

            # ═══════════════════════════════════════════════════════════════
            # FORWARD MERGE + DERIVED
            # ═══════════════════════════════════════════════════════════════
            def process_date(date: str) -> pl.DataFrame:
                elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
                elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

                lf_trade = (
                    vf.scan_trade(date)
                    .pipe(vf.parse_time, TRADE_TIME_COL)
                    .pipe(vf.parse_time, CREATE_TIME_COL)
                    .sort(["ukey", elapsed_trade])
                    .with_columns(
                        pl.col("fill_qty").cum_sum()
                        .over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
                    )
                    .with_columns(
                        (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
                    )
                )
                lf_quote = (
                    vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + RAW_REF_COLS)
                    .pipe(vf.parse_time, QUOTE_TIME_COL)
                )

                df_merged = vf.merge_forward(
                    lf_trade, lf_quote,
                    ref_cols=RAW_REF_COLS,
                    horizons=HORIZONS,
                    trade_time_col=elapsed_trade,
                    ref_time_col=elapsed_quote,
                    strategy="backward",
                )

                # Wide → semi-wide
                id_cols = ["seq", "data_date"]
                frames = []
                for h in HORIZONS:
                    suffix = vf.horizon_suffix(h)
                    rename_map = {f"{rc}_{suffix}": rc for rc in RAW_REF_COLS}
                    frames.append(
                        df_merged.select(id_cols + list(rename_map.keys()))
                        .rename(rename_map)
                        .with_columns(pl.lit(h, dtype=pl.Int64).alias("horizon"))
                    )
                df_fwd = pl.concat(frames)

                # Derived columns
                df_fwd = df_fwd.join(
                    df_merged.select(["seq", "data_date", "fill_price", "order_side"]),
                    on=["seq", "data_date"],
                )
                is_buy = pl.col("order_side") == "Buy"

                df_fwd = df_fwd.with_columns([
                    pl.mean_horizontal("bid_px0", "ask_px0").alias("mid"),
                    (pl.col("ask_px0") - pl.col("bid_px0")).alias("spread"),
                    pl.when(is_buy).then(pl.col("bid_px0")).otherwise(pl.col("ask_px0")).alias("near_touch_px"),
                    pl.when(is_buy).then(pl.col("ask_px0")).otherwise(pl.col("bid_px0")).alias("far_touch_px"),
                    pl.when(is_buy).then(pl.col("bid_size0")).otherwise(pl.col("ask_size0")).alias("near_touch_size"),
                    pl.when(is_buy).then(pl.col("ask_size0")).otherwise(pl.col("bid_size0")).alias("far_touch_size"),
                ])
                df_fwd = df_fwd.with_columns((pl.col("spread") / pl.col("mid") * 10000).alias("spread_bps"))

                df_fwd = df_fwd.with_columns([
                    (pl.col("mid") / pl.col("fill_price") - 1).alias("markout"),
                    (pl.col("near_touch_px") / pl.col("fill_price") - 1).alias("fill_to_near_touch"),
                    (pl.col("far_touch_px") / pl.col("fill_price") - 1).alias("fill_to_far_touch"),
                ])

                mid_0 = df_fwd.filter(pl.col("horizon") == 0).select(["seq", "data_date", pl.col("mid").alias("mid_0")])
                df_fwd = df_fwd.join(mid_0, on=["seq", "data_date"])
                df_fwd = df_fwd.with_columns(((pl.col("mid") - pl.col("mid_0")) / pl.col("mid_0")).alias("return")).drop("mid_0")

                sided_cols = ["return", "markout", "fill_to_near_touch", "fill_to_far_touch"]
                df_fwd = df_fwd.with_columns([
                    pl.when(pl.col("order_side") == "Sell").then(-pl.col(c)).otherwise(pl.col(c)).alias(f"sided_{c}")
                    for c in sided_cols
                ])
                return df_fwd.drop(["fill_price", "order_side"])

            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                vf.set_config(vf.Config(
                    trade_dir=TRADE_DIR, trade_pattern=TRADE_PATTERN, trade_schema=TRADE_SCHEMA,
                    quote_dir=QUOTE_DIR, quote_pattern=QUOTE_PATTERN, quote_schema=QUOTE_SCHEMA,
                    market=MARKET,
                ))

                out_dir = OUTPUT_DIR / "fwd_update"
                out_file = out_dir / f"{args.date}.parquet"
                if out_file.exists() and not args.force:
                    print(f"  skip {args.date} (exists)")
                    return

                print(f"Processing {args.date}...")
                df = process_date(args.date)
                out_dir.mkdir(parents=True, exist_ok=True)
                df.write_parquet(str(out_file))
                print(f"  {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "forward_on_create": {
        "description": "trade + quote → forward table on create_ts (signal/sizing analysis, complete CLI script)",
        "code": textwrap.dedent("""\
            #!/usr/bin/env python
            \"\"\"Forward enrichment on create_ts: quote snapshots at each horizon after order placement.\"\"\"
            from __future__ import annotations

            import argparse
            from pathlib import Path

            import polars as pl
            import vizflow as vf

            # ═══════════════════════════════════════════════════════════════
            # CONFIG
            # ═══════════════════════════════════════════════════════════════
            TRADE_DIR = Path("/cpfs/user2/ylu/data/oic_live/concat_sort")
            TRADE_PATTERN = "{date}.parquet"
            TRADE_SCHEMA = "oic_live"

            QUOTE_DIR = Path("/gpfs/nvmefs/marketdata/cn/stock/all/tob5")
            QUOTE_PATTERN = "{date}.feather"
            QUOTE_SCHEMA = "stock_sorted_t5ob"

            OUTPUT_DIR = Path("/cpfs/user2/ylu/data/oic_live/enriched")
            MARKET = "CN"

            TRADE_TIME_COL = "update_exchange_ts"
            CREATE_TIME_COL = "create_exchange_ts"
            QUOTE_TIME_COL = "ticktime"

            HORIZONS = [int(h * 1000) for h in [
                -10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600,
            ]]
            RAW_REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]

            # ═══════════════════════════════════════════════════════════════
            # FORWARD MERGE + DERIVED
            # ═══════════════════════════════════════════════════════════════
            def process_date(date: str) -> pl.DataFrame:
                elapsed_create = f"elapsed_{CREATE_TIME_COL}"
                elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
                elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

                lf_trade = (
                    vf.scan_trade(date)
                    .pipe(vf.parse_time, TRADE_TIME_COL)
                    .pipe(vf.parse_time, CREATE_TIME_COL)
                    .sort(["ukey", elapsed_trade])
                    .with_columns(
                        pl.col("fill_qty").cum_sum()
                        .over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
                    )
                    .with_columns(
                        (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
                    )
                )
                lf_quote = (
                    vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + RAW_REF_COLS)
                    .pipe(vf.parse_time, QUOTE_TIME_COL)
                )

                df_merged = vf.merge_forward(
                    lf_trade, lf_quote,
                    ref_cols=RAW_REF_COLS,
                    horizons=HORIZONS,
                    trade_time_col=elapsed_create,     # ← create_ts
                    ref_time_col=elapsed_quote,
                    strategy="backward",
                )

                # Wide → semi-wide
                id_cols = ["seq", "data_date"]
                frames = []
                for h in HORIZONS:
                    suffix = vf.horizon_suffix(h)
                    rename_map = {f"{rc}_{suffix}": rc for rc in RAW_REF_COLS}
                    frames.append(
                        df_merged.select(id_cols + list(rename_map.keys()))
                        .rename(rename_map)
                        .with_columns(pl.lit(h, dtype=pl.Int64).alias("horizon"))
                    )
                df_fwd = pl.concat(frames)

                # Derived columns (same pipeline as forward_on_update)
                df_fwd = df_fwd.join(
                    df_merged.select(["seq", "data_date", "fill_price", "order_side"]),
                    on=["seq", "data_date"],
                )
                is_buy = pl.col("order_side") == "Buy"

                df_fwd = df_fwd.with_columns([
                    pl.mean_horizontal("bid_px0", "ask_px0").alias("mid"),
                    (pl.col("ask_px0") - pl.col("bid_px0")).alias("spread"),
                    pl.when(is_buy).then(pl.col("bid_px0")).otherwise(pl.col("ask_px0")).alias("near_touch_px"),
                    pl.when(is_buy).then(pl.col("ask_px0")).otherwise(pl.col("bid_px0")).alias("far_touch_px"),
                    pl.when(is_buy).then(pl.col("bid_size0")).otherwise(pl.col("ask_size0")).alias("near_touch_size"),
                    pl.when(is_buy).then(pl.col("ask_size0")).otherwise(pl.col("bid_size0")).alias("far_touch_size"),
                ])
                df_fwd = df_fwd.with_columns((pl.col("spread") / pl.col("mid") * 10000).alias("spread_bps"))

                df_fwd = df_fwd.with_columns([
                    (pl.col("mid") / pl.col("fill_price") - 1).alias("markout"),
                    (pl.col("near_touch_px") / pl.col("fill_price") - 1).alias("fill_to_near_touch"),
                    (pl.col("far_touch_px") / pl.col("fill_price") - 1).alias("fill_to_far_touch"),
                ])

                mid_0 = df_fwd.filter(pl.col("horizon") == 0).select(["seq", "data_date", pl.col("mid").alias("mid_0")])
                df_fwd = df_fwd.join(mid_0, on=["seq", "data_date"])
                df_fwd = df_fwd.with_columns(((pl.col("mid") - pl.col("mid_0")) / pl.col("mid_0")).alias("return")).drop("mid_0")

                sided_cols = ["return", "markout", "fill_to_near_touch", "fill_to_far_touch"]
                df_fwd = df_fwd.with_columns([
                    pl.when(pl.col("order_side") == "Sell").then(-pl.col(c)).otherwise(pl.col(c)).alias(f"sided_{c}")
                    for c in sided_cols
                ])
                return df_fwd.drop(["fill_price", "order_side"])

            # ═══════════════════════════════════════════════════════════════
            # CLI
            # ═══════════════════════════════════════════════════════════════
            def main() -> None:
                parser = argparse.ArgumentParser()
                parser.add_argument("--date", required=True)
                parser.add_argument("--force", action="store_true")
                args = parser.parse_args()

                vf.set_config(vf.Config(
                    trade_dir=TRADE_DIR, trade_pattern=TRADE_PATTERN, trade_schema=TRADE_SCHEMA,
                    quote_dir=QUOTE_DIR, quote_pattern=QUOTE_PATTERN, quote_schema=QUOTE_SCHEMA,
                    market=MARKET,
                ))

                out_dir = OUTPUT_DIR / "fwd_create"
                out_file = out_dir / f"{args.date}.parquet"
                if out_file.exists() and not args.force:
                    print(f"  skip {args.date} (exists)")
                    return

                print(f"Processing {args.date}...")
                df = process_date(args.date)
                out_dir.mkdir(parents=True, exist_ok=True)
                df.write_parquet(str(out_file))
                print(f"  {len(df)} rows -> {out_file}")

            if __name__ == "__main__":
                main()"""),
    },
    "merge_forward": {
        "description": "trade + quote → forward enrichment (base + forward tables)",
        "code": textwrap.dedent("""\
            import polars as pl
            import vizflow as vf

            # --- Config (edit these) ---
            date = "20240827"

            vf.set_config(vf.Config(
                trade_dir="/path/to/trades",
                trade_pattern="{date}.parquet",
                trade_schema="oic_live",
                quote_dir="/path/to/quotes",
                quote_pattern="{date}.feather",
                quote_schema="stock_sorted_t5ob",
                market="CN",
            ))

            trade_time_col  = "update_exchange_ts"
            create_time_col = "create_exchange_ts"
            quote_time_col  = "ticktime"
            ref_cols   = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]
            horizons   = [int(h * 1000) for h in [-10, -5, -1, 0, 1, 5, 10, 30, 60,
                                                   120, 180, 300, 600, 1200, 1800, 3600]]

            # --- Plan ---
            elapsed_trade = f"elapsed_{trade_time_col}"
            elapsed_quote = f"elapsed_{quote_time_col}"

            lf_trade = (
                vf.scan_trade(date)
                .pipe(vf.parse_time, trade_time_col)
                .pipe(vf.parse_time, create_time_col)
                .sort(["ukey", elapsed_trade])
                .with_columns(
                    pl.col("fill_qty").cum_sum()
                      .over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
                )
                .with_columns(
                    (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
                    (pl.col(elapsed_trade) - pl.col(f"elapsed_{create_time_col}")).alias("duration"),
                )
            )

            lf_quote = (
                vf.scan_quote(date, columns=["ukey", quote_time_col] + ref_cols)
                .pipe(vf.parse_time, quote_time_col)
            )

            df_merged = vf.merge_forward(
                lf_trade, lf_quote,
                ref_cols=ref_cols,
                horizons=horizons,
                trade_time_col=elapsed_trade,
                ref_time_col=elapsed_quote,
            )
            df_merged  # show result"""),
    },
    "enrich_alpha": {
        "description": "alpha + quote → forward enrichment (wide format)",
        "code": textwrap.dedent("""\
            import polars as pl
            import vizflow as vf
            from datetime import timedelta

            # --- Config (edit these) ---
            date = "20240827"

            vf.set_config(vf.Config(
                alpha_dir="/path/to/alpha",
                alpha_pattern="alpha_{date}.feather",
                alpha_schema="jyao_v20251114",
                quote_dir="/path/to/quotes",
                quote_pattern="{date}.fst",
                quote_schema="stock_sorted_t5ob",
                market="CN",
            ))

            alpha_time_col = "ticktime"
            quote_time_col = "ticktime"
            ref_cols   = ["bid_px0", "ask_px0"]
            pred_cols  = ["x_10s", "x_60s", "x_3m", "x_30m"]
            horizons   = [timedelta(seconds=h) for h in [0, 10, 30, 60, 120, 180, 300]]
            event_cols = ["ukey", "data_date", alpha_time_col] + pred_cols

            # --- Plan ---
            elapsed_alpha = f"elapsed_{alpha_time_col}"
            elapsed_quote = f"elapsed_{quote_time_col}"

            lf_alpha = (
                vf.scan_alpha(date)
                .pipe(vf.parse_time, alpha_time_col)
                .select(event_cols + [elapsed_alpha])
            )
            lf_quote = (
                vf.scan_quote(date, columns=["ukey", quote_time_col] + ref_cols)
                .pipe(vf.parse_time, quote_time_col)
            )

            # Per-horizon merge → wide format
            partials = []
            for h in horizons:
                lf_h = vf.merge_forward(
                    lf_alpha, lf_quote,
                    ref_cols=ref_cols,
                    horizon=h,
                    trade_time_col=elapsed_alpha,
                    ref_time_col=elapsed_quote,
                )
                partials.append(lf_h)

            df = partials[0].collect()
            for lf_h in partials[1:]:
                df_h = lf_h.collect()
                new_cols = [c for c in df_h.columns if c not in df.columns]
                if new_cols:
                    df = df.hstack(df_h.select(new_cols))
            df  # show result"""),
    },
}
