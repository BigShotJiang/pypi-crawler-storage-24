"""Tests for PII sanitization — default patterns, custom patterns, and custom redaction."""

import re

import pytest
import responses

import jstverify_tracing
from jstverify_tracing._sanitizer import (
    _ALL_PATTERNS,
    _REDACTED,
    sanitize_span,
    sanitize_text,
)


# ── sanitize_text defaults ───────────────────────────────────────────────────

def test_sanitize_text_redacts_ssn():
    assert sanitize_text("SSN: 123-45-6789") == f"SSN: {_REDACTED}"


def test_sanitize_text_redacts_email():
    assert sanitize_text("user@example.com") == _REDACTED


def test_sanitize_text_redacts_phone():
    assert sanitize_text("Call 555-123-4567") == f"Call {_REDACTED}"


def test_sanitize_text_redacts_credit_card():
    assert sanitize_text("CC: 4111 1111 1111 1111") == f"CC: {_REDACTED}"


def test_sanitize_text_none_passthrough():
    assert sanitize_text(None) is None


def test_sanitize_text_empty_passthrough():
    assert sanitize_text("") == ""


# ── custom patterns ──────────────────────────────────────────────────────────

def test_sanitize_text_custom_patterns():
    custom = [re.compile(r"\bPATIENT-\d+\b")]
    result = sanitize_text("ID: PATIENT-12345 noted", patterns=custom)
    assert result == f"ID: {_REDACTED} noted"


def test_sanitize_text_custom_patterns_does_not_apply_builtins():
    """When explicit patterns are passed, only those patterns apply."""
    custom = [re.compile(r"\bPATIENT-\d+\b")]
    result = sanitize_text("user@example.com PATIENT-99", patterns=custom)
    # Email should NOT be redacted (not in custom list), but PATIENT should
    assert "user@example.com" in result
    assert "PATIENT-99" not in result


def test_sanitize_text_custom_redaction_string():
    result = sanitize_text("SSN: 123-45-6789", redaction="[HIDDEN]")
    assert result == "SSN: [HIDDEN]"


def test_sanitize_text_custom_pattern_and_redaction():
    custom = [re.compile(r"\bMRN\d{8}\b")]
    result = sanitize_text("Record MRN00112233", patterns=custom, redaction="***")
    assert result == "Record ***"


# ── sanitize_span ────────────────────────────────────────────────────────────

def _make_span(**overrides):
    span = {
        "traceId": "t1",
        "spanId": "s1",
        "parentSpanId": None,
        "operationName": "test-op",
        "serviceName": "test",
        "serviceType": "http",
        "startTime": 1000,
        "endTime": 2000,
        "duration": 1000,
    }
    span.update(overrides)
    return span


def test_sanitize_span_redacts_status_message():
    span = _make_span(statusMessage="Error for user@test.com")
    sanitize_span(span)
    assert "user@test.com" not in span["statusMessage"]
    assert _REDACTED in span["statusMessage"]


def test_sanitize_span_custom_patterns_on_status_message():
    custom = [re.compile(r"\bPATIENT-\d+\b")]
    span = _make_span(statusMessage="Failed for PATIENT-999")
    sanitize_span(span, patterns=custom, redaction="[PII]")
    assert span["statusMessage"] == "Failed for [PII]"


def test_sanitize_span_redacts_pii_in_attributes():
    span = _make_span(attributes={
        "safeKey": "no-pii-here",
        "userEmail": "contact test@example.com",
        "userSsn": "SSN is 123-45-6789",
    })
    sanitize_span(span)
    assert span["attributes"]["safeKey"] == "no-pii-here"
    assert span["attributes"]["userEmail"] == f"contact {_REDACTED}"
    assert span["attributes"]["userSsn"] == f"SSN is {_REDACTED}"


def test_sanitize_span_strips_query_from_url():
    span = _make_span(httpUrl="https://api.example.com/users?token=secret")
    sanitize_span(span)
    assert span["httpUrl"] == "/users"


def test_sanitize_span_strips_query_from_operation_name():
    span = _make_span(operationName="GET /users?page=1")
    sanitize_span(span)
    assert span["operationName"] == "GET /users"


# ── init() integration ──────────────────────────────────────────────────────

def test_init_invalid_regex_raises():
    with pytest.raises(re.error):
        jstverify_tracing.init(
            api_key="key",
            service_name="svc",
            patch_requests=False,
            pii_patterns=[r"[unclosed"],
        )


def test_init_custom_patterns_compiled_on_instance():
    instance = jstverify_tracing.init(
        api_key="key",
        service_name="svc",
        patch_requests=False,
        pii_patterns=[r"\bMRN\d{8}\b"],
    )
    # Should have built-in 4 + 1 custom
    assert len(instance._compiled_pii) == len(_ALL_PATTERNS) + 1


def test_init_custom_redaction_stored():
    instance = jstverify_tracing.init(
        api_key="key",
        service_name="svc",
        patch_requests=False,
        pii_redaction="[HIDDEN]",
    )
    assert instance.pii_redaction == "[HIDDEN]"


def test_init_default_redaction():
    instance = jstverify_tracing.init(
        api_key="key",
        service_name="svc",
        patch_requests=False,
    )
    assert instance.pii_redaction == "[REDACTED]"


@responses.activate
def test_enqueue_applies_custom_patterns():
    """Custom patterns flow through SpanBuffer.enqueue to sanitize_span."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
    instance = jstverify_tracing.init(
        api_key="key",
        service_name="svc",
        endpoint="https://example.com/spans",
        patch_requests=False,
        pii_patterns=[r"\bPATIENT-\d+\b"],
        pii_redaction="[HIDDEN]",
    )
    span = _make_span(statusMessage="Error PATIENT-123")
    instance._buffer.enqueue(span)
    assert span["statusMessage"] == "Error [HIDDEN]"


def test_sanitize_pii_false_skips_all_sanitization():
    """When sanitize_pii=False, no redaction happens even with custom patterns."""
    instance = jstverify_tracing.init(
        api_key="key",
        service_name="svc",
        patch_requests=False,
        sanitize_pii=False,
        pii_patterns=[r"\bPATIENT-\d+\b"],
    )
    # Buffer should not sanitize
    assert instance._buffer._sanitize is False


def test_relay_mode_with_custom_patterns():
    """Relay mode stores custom PII config on the instance for enqueue_relay_span."""
    instance = jstverify_tracing.init(
        api_key="key",
        service_name="svc",
        transport="relay",
        patch_requests=False,
        pii_patterns=[r"\bPATIENT-\d+\b"],
        pii_redaction="[HIDDEN]",
    )
    assert len(instance._compiled_pii) == len(_ALL_PATTERNS) + 1
    assert instance.pii_redaction == "[HIDDEN]"

    # Verify relay enqueue uses instance config
    from jstverify_tracing._relay_buffer import enqueue_relay_span, drain_relay_spans
    span = _make_span(statusMessage="Error PATIENT-456")
    enqueue_relay_span(span)
    assert span["statusMessage"] == "Error [HIDDEN]"
    drain_relay_spans()
