import sys
import types
import pytest
from unittest.mock import MagicMock

import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._context import set_root_context
from jstverify_tracing._firebase_admin_patch import (
    _wrap_rtdb_method,
    _wrap_auth_function,
    patch_firebase_admin,
    unpatch_firebase_admin,
)


def _init_sdk(**overrides):
    defaults = dict(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-svc",
        service_type="lambda",
        patch_requests=False,
        patch_boto=False,
        patch_psycopg2=False,
        patch_firebase_admin=False,
    )
    defaults.update(overrides)
    return jstverify_tracing.init(**defaults)


def _get_spans(instance):
    with instance._buffer._lock:
        return list(instance._buffer._queue)


# ── Mock firebase_admin modules ──


def _install_mock_firebase_admin():
    """Install mock firebase_admin into sys.modules for patch_firebase_admin() to import."""
    # Create mock db.Reference class
    class MockReference:
        def __init__(self, path="/"):
            self.path = path

        def get(self):
            return {"key": "value"}

        def set(self, value):
            return None

        def update(self, value):
            return None

        def delete(self):
            return None

        def push(self, value=None):
            return {"key": "new-key"}

        def transaction(self, update_fn):
            return update_fn({})

    # Create mock db module
    mock_db = types.ModuleType("firebase_admin.db")
    mock_db.Reference = MockReference

    # Create mock auth module
    mock_auth = types.ModuleType("firebase_admin.auth")
    mock_auth.create_user = MagicMock(return_value=MagicMock(uid="u1"))
    mock_auth.update_user = MagicMock(return_value=MagicMock(uid="u1"))
    mock_auth.delete_user = MagicMock(return_value=None)
    mock_auth.get_user = MagicMock(return_value=MagicMock(uid="u1"))
    mock_auth.get_user_by_email = MagicMock(return_value=MagicMock(uid="u1"))
    mock_auth.verify_id_token = MagicMock(return_value={"uid": "u1"})
    mock_auth.list_users = MagicMock(return_value=MagicMock(users=[]))

    # Create mock firebase_admin module
    mock_firebase_admin = types.ModuleType("firebase_admin")
    mock_firebase_admin.db = mock_db
    mock_firebase_admin.auth = mock_auth

    sys.modules["firebase_admin"] = mock_firebase_admin
    sys.modules["firebase_admin.db"] = mock_db
    sys.modules["firebase_admin.auth"] = mock_auth

    return mock_firebase_admin, MockReference, mock_auth


def _uninstall_mock_firebase_admin():
    for key in ["firebase_admin", "firebase_admin.db", "firebase_admin.auth"]:
        sys.modules.pop(key, None)


# ── Tests ──


class TestFirebaseAdminPatch:
    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        self.mock_admin, self.MockReference, self.mock_auth = _install_mock_firebase_admin()
        _init_sdk()
        yield
        unpatch_firebase_admin()
        JstVerifyTracing.reset()
        _uninstall_mock_firebase_admin()

    def test_rtdb_span_for_get(self):
        instance = JstVerifyTracing.get_instance()
        set_root_context("t1")

        original_get = self.MockReference.get
        self.MockReference.get = _wrap_rtdb_method(original_get, "get")

        ref = self.MockReference("/users")
        result = ref.get()

        spans = _get_spans(instance)
        assert len(spans) == 1
        assert spans[0]["operationName"] == "RTDB get /users"
        assert spans[0]["serviceType"] == "firebase-rtdb"
        assert spans[0]["serviceName"] == "Firebase RTDB"
        assert spans[0]["traceId"] == "t1"
        assert spans[0]["statusCode"] == 200
        assert result == {"key": "value"}

        # Restore
        self.MockReference.get = original_get

    def test_rtdb_span_for_set(self):
        instance = JstVerifyTracing.get_instance()
        set_root_context("t2")

        original_set = self.MockReference.set
        self.MockReference.set = _wrap_rtdb_method(original_set, "set")

        ref = self.MockReference("/users/abc")
        ref.set({"name": "test"})

        spans = _get_spans(instance)
        assert len(spans) == 1
        assert spans[0]["operationName"] == "RTDB set /users/abc"
        assert spans[0]["serviceType"] == "firebase-rtdb"

        self.MockReference.set = original_set

    def test_rtdb_span_for_update(self):
        instance = JstVerifyTracing.get_instance()
        set_root_context("t3")

        original_update = self.MockReference.update
        self.MockReference.update = _wrap_rtdb_method(original_update, "update")

        ref = self.MockReference("/users/abc")
        ref.update({"name": "updated"})

        spans = _get_spans(instance)
        assert len(spans) == 1
        assert spans[0]["operationName"] == "RTDB update /users/abc"

        self.MockReference.update = original_update

    def test_rtdb_error_on_failure(self):
        instance = JstVerifyTracing.get_instance()
        set_root_context("t4")

        def failing_get(self):
            raise RuntimeError("permission denied")

        self.MockReference.get = _wrap_rtdb_method(failing_get, "get")

        ref = self.MockReference("/restricted")
        with pytest.raises(RuntimeError, match="permission denied"):
            ref.get()

        spans = _get_spans(instance)
        assert len(spans) == 1
        assert spans[0]["statusCode"] == 500
        assert "permission denied" in spans[0]["statusMessage"]

        # Restore a simple get
        self.MockReference.get = lambda self: None

    def test_auth_span_for_create_user(self):
        instance = JstVerifyTracing.get_instance()
        set_root_context("t5")

        original = self.mock_auth.create_user
        self.mock_auth.create_user = _wrap_auth_function(original, "create_user")

        self.mock_auth.create_user(email="test@test.com")

        spans = _get_spans(instance)
        assert len(spans) == 1
        assert spans[0]["operationName"] == "Auth create_user"
        assert spans[0]["serviceType"] == "firebase-auth"
        assert spans[0]["serviceName"] == "Firebase Auth"
        assert spans[0]["statusCode"] == 200

        self.mock_auth.create_user = original

    def test_auth_span_for_verify_id_token(self):
        instance = JstVerifyTracing.get_instance()
        set_root_context("t6")

        original = self.mock_auth.verify_id_token
        self.mock_auth.verify_id_token = _wrap_auth_function(original, "verify_id_token")

        self.mock_auth.verify_id_token("fake-token")

        spans = _get_spans(instance)
        assert len(spans) == 1
        assert spans[0]["operationName"] == "Auth verify_id_token"
        assert spans[0]["serviceType"] == "firebase-auth"

        self.mock_auth.verify_id_token = original

    def test_skips_with_no_active_context(self):
        instance = JstVerifyTracing.get_instance()
        # No set_root_context

        original_get = self.MockReference.get
        self.MockReference.get = _wrap_rtdb_method(original_get, "get")

        ref = self.MockReference("/test")
        ref.get()

        spans = _get_spans(instance)
        assert len(spans) == 0

        self.MockReference.get = original_get

    def test_unpatch_restores_originals(self):
        original_get = self.MockReference.get
        original_create_user = self.mock_auth.create_user

        patch_firebase_admin()

        assert self.MockReference.get is not original_get
        assert self.mock_auth.create_user is not original_create_user

        unpatch_firebase_admin()

        assert self.MockReference.get is original_get
        assert self.mock_auth.create_user is original_create_user
