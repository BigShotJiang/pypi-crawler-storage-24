import responses
import pytest
from unittest.mock import MagicMock, patch, PropertyMock

import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._context import set_root_context
from jstverify_tracing._psycopg2_patch import (
    _extract_query_label,
    patch_psycopg2,
    unpatch_psycopg2,
)


def _init_sdk(**overrides):
    defaults = dict(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-svc",
        service_type="lambda",
        patch_requests=False,
        patch_boto=False,
        patch_psycopg2=False,
    )
    defaults.update(overrides)
    return jstverify_tracing.init(**defaults)


def _get_spans(instance):
    with instance._buffer._lock:
        return list(instance._buffer._queue)


# ── Query label extraction ──


class TestExtractQueryLabel:
    def test_select(self):
        assert _extract_query_label("SELECT * FROM users WHERE id = %s") == "SELECT users"

    def test_select_multiline(self):
        sql = """
            SELECT u.id, u.name
            FROM users u
            WHERE u.active = true
        """
        assert _extract_query_label(sql) == "SELECT users"

    def test_insert(self):
        assert _extract_query_label("INSERT INTO orders (user_id) VALUES (%s)") == "INSERT orders"

    def test_update(self):
        assert _extract_query_label("UPDATE products SET price = %s WHERE id = %s") == "UPDATE products"

    def test_delete(self):
        assert _extract_query_label("DELETE FROM sessions WHERE expired = true") == "DELETE sessions"

    def test_create_table(self):
        assert _extract_query_label("CREATE TABLE foo (id serial)") == "CREATE"

    def test_begin(self):
        assert _extract_query_label("BEGIN") == "BEGIN"

    def test_empty(self):
        assert _extract_query_label("") == "query"

    def test_none(self):
        assert _extract_query_label(None) == "query"


# ── Patching with mock psycopg2 ──


def _make_mock_cursor(db_name="testdb"):
    """Create a mock cursor with a mock connection that has a dsn."""
    cursor = MagicMock()
    cursor.connection = MagicMock()
    cursor.connection.dsn = f"dbname={db_name} user=test host=localhost"
    return cursor


class TestPsycopg2Patch:
    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """Setup and teardown for each test."""
        _init_sdk()
        yield
        unpatch_psycopg2()
        JstVerifyTracing.reset()

    @responses.activate
    def test_execute_creates_span(self):
        responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
        instance = JstVerifyTracing.get_instance()
        set_root_context("t1")

        # Create a mock cursor class to patch
        mock_cursor_cls = type("cursor", (), {
            "execute": lambda self, query, vars=None: None,
            "executemany": lambda self, query, vars_list: None,
        })

        with patch("jstverify_tracing._psycopg2_patch.patch_psycopg2") as _:
            # Manually test the wrapping logic
            from jstverify_tracing._psycopg2_patch import _wrap_execute

            original_execute = mock_cursor_cls.execute
            mock_cursor_cls.execute = _wrap_execute(original_execute)

            cursor = mock_cursor_cls()
            cursor.connection = MagicMock()
            cursor.connection.dsn = "dbname=myapp user=admin host=localhost"

            cursor.execute("SELECT * FROM users WHERE id = %s", (42,))

            spans = _get_spans(instance)
            assert len(spans) == 1
            span = spans[0]
            assert span["operationName"] == "PostgreSQL SELECT users"
            assert span["serviceName"] == "myapp"
            assert span["serviceType"] == "postgresql"
            assert span["traceId"] == "t1"
            assert span["statusCode"] == 200

    @responses.activate
    def test_execute_error_creates_error_span(self):
        responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
        instance = JstVerifyTracing.get_instance()
        set_root_context("t2")

        from jstverify_tracing._psycopg2_patch import _wrap_execute

        def failing_execute(self, query, vars=None):
            raise RuntimeError("connection refused")

        mock_cursor_cls = type("cursor", (), {
            "execute": failing_execute,
        })
        mock_cursor_cls.execute = _wrap_execute(failing_execute)

        cursor = mock_cursor_cls()
        cursor.connection = MagicMock()
        cursor.connection.dsn = "dbname=testdb"

        with pytest.raises(RuntimeError, match="connection refused"):
            cursor.execute("SELECT 1")

        spans = _get_spans(instance)
        assert len(spans) == 1
        assert spans[0]["statusCode"] == 500
        assert "connection refused" in spans[0]["statusMessage"]

    @responses.activate
    def test_executemany_creates_batch_span(self):
        responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
        instance = JstVerifyTracing.get_instance()
        set_root_context("t3")

        from jstverify_tracing._psycopg2_patch import _wrap_executemany

        mock_cursor_cls = type("cursor", (), {
            "executemany": lambda self, query, vars_list: None,
        })
        mock_cursor_cls.executemany = _wrap_executemany(mock_cursor_cls.executemany)

        cursor = mock_cursor_cls()
        cursor.connection = MagicMock()
        cursor.connection.dsn = "dbname=bulk_db"

        cursor.executemany(
            "INSERT INTO events (type, data) VALUES (%s, %s)",
            [("click", "{}"), ("view", "{}")]
        )

        spans = _get_spans(instance)
        assert len(spans) == 1
        assert spans[0]["operationName"] == "PostgreSQL INSERT events (batch)"
        assert spans[0]["serviceName"] == "bulk_db"

    @responses.activate
    def test_no_span_without_context(self):
        responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
        instance = JstVerifyTracing.get_instance()
        # No set_root_context call

        from jstverify_tracing._psycopg2_patch import _wrap_execute

        mock_cursor_cls = type("cursor", (), {
            "execute": lambda self, query, vars=None: None,
        })
        mock_cursor_cls.execute = _wrap_execute(mock_cursor_cls.execute)

        cursor = mock_cursor_cls()
        cursor.connection = MagicMock()
        cursor.connection.dsn = "dbname=testdb"

        cursor.execute("SELECT 1")

        spans = _get_spans(instance)
        assert len(spans) == 0

    @responses.activate
    def test_init_with_patch_psycopg2_flag(self):
        """Test that init(patch_psycopg2=True) calls patch_psycopg2()."""
        responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})
        JstVerifyTracing.reset()

        with patch("jstverify_tracing._psycopg2_patch.patch_psycopg2") as mock_patch:
            jstverify_tracing.init(
                api_key="key",
                endpoint="https://example.com/spans",
                service_name="svc",
                patch_requests=False,
                patch_psycopg2=True,
            )
            mock_patch.assert_called_once()
