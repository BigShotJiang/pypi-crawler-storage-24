"""Monkey-patch firebase-admin to auto-instrument RTDB and Auth operations."""

import time
import logging

from ._context import start_child_context, pop_context, get_current_context
from ._source_location import from_first_user_frame

logger = logging.getLogger("jstverify_tracing")

_patched = False
_originals = {}

# RTDB Reference methods (synchronous in Python firebase-admin)
_RTDB_METHODS = ["get", "set", "update", "delete", "push", "transaction"]

# Auth module-level functions
_AUTH_FUNCTIONS = [
    "create_user",
    "update_user",
    "delete_user",
    "get_user",
    "get_user_by_email",
    "verify_id_token",
    "list_users",
]


def _wrap_rtdb_method(original, method_name):
    """Wrap an RTDB Reference method to emit a span."""

    def patched(self, *args, **kwargs):
        from ._config import JstVerifyTracing

        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return original(self, *args, **kwargs)

        current = get_current_context()
        if current is None:
            return original(self, *args, **kwargs)

        location = from_first_user_frame()
        ctx = start_child_context()
        start_time = int(time.time() * 1000)
        status_code = 200
        status_message = None

        ref_path = getattr(self, "path", "/")
        operation_name = f"RTDB {method_name} {ref_path}"

        try:
            return original(self, *args, **kwargs)
        except Exception as e:
            status_code = 500
            status_message = str(e)
            raise
        finally:
            end_time = int(time.time() * 1000)
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": operation_name,
                "serviceName": "Firebase RTDB",
                "serviceType": "firebase-rtdb",
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
            }
            if status_message is not None:
                span["statusMessage"] = status_message
            span.update(location)
            from ._span import _enqueue
            _enqueue(instance, span)
            pop_context()

    return patched


def _wrap_auth_function(original, method_name):
    """Wrap an Auth module-level function to emit a span."""

    def patched(*args, **kwargs):
        from ._config import JstVerifyTracing

        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return original(*args, **kwargs)

        current = get_current_context()
        if current is None:
            return original(*args, **kwargs)

        location = from_first_user_frame()
        ctx = start_child_context()
        start_time = int(time.time() * 1000)
        status_code = 200
        status_message = None

        operation_name = f"Auth {method_name}"

        try:
            return original(*args, **kwargs)
        except Exception as e:
            status_code = 500
            status_message = str(e)
            raise
        finally:
            end_time = int(time.time() * 1000)
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": operation_name,
                "serviceName": "Firebase Auth",
                "serviceType": "firebase-auth",
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
            }
            if status_message is not None:
                span["statusMessage"] = status_message
            span.update(location)
            from ._span import _enqueue
            _enqueue(instance, span)
            pop_context()

    return patched


def patch_firebase_admin():
    """Monkey-patch firebase-admin to auto-instrument RTDB and Auth operations.

    Requires firebase-admin to be installed. Call after jstverify_tracing.init().
    """
    global _patched

    if _patched:
        return

    # Patch RTDB Reference class methods
    try:
        from firebase_admin import db

        ref_cls = db.Reference
        for method in _RTDB_METHODS:
            original = getattr(ref_cls, method, None)
            if original is not None and callable(original):
                _originals[f"rtdb.{method}"] = original
                setattr(ref_cls, method, _wrap_rtdb_method(original, method))
    except ImportError:
        logger.warning(
            "jstverify-tracing: firebase-admin.db not available, "
            "skipping RTDB auto-instrumentation"
        )

    # Patch Auth module-level functions
    try:
        from firebase_admin import auth

        for func_name in _AUTH_FUNCTIONS:
            original = getattr(auth, func_name, None)
            if original is not None and callable(original):
                _originals[f"auth.{func_name}"] = original
                setattr(auth, func_name, _wrap_auth_function(original, func_name))
    except ImportError:
        logger.warning(
            "jstverify-tracing: firebase-admin.auth not available, "
            "skipping Auth auto-instrumentation"
        )

    _patched = True


def unpatch_firebase_admin():
    """Restore the original firebase-admin methods (for testing)."""
    global _patched

    if not _patched:
        return

    for key, original in _originals.items():
        service, method = key.split(".", 1)
        if service == "rtdb":
            try:
                from firebase_admin import db
                setattr(db.Reference, method, original)
            except ImportError:
                pass
        elif service == "auth":
            try:
                from firebase_admin import auth
                setattr(auth, method, original)
            except ImportError:
                pass

    _originals.clear()
    _patched = False
