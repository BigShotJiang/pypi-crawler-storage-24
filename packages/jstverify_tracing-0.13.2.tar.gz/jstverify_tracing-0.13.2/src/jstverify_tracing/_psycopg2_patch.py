"""Monkey-patch psycopg2 cursor.execute/executemany to auto-instrument PostgreSQL queries."""

import time
import logging
import re

from ._context import start_child_context, pop_context, get_current_context
from ._source_location import from_first_user_frame

logger = logging.getLogger("jstverify_tracing")

_original_execute = None
_original_executemany = None
_patched = False

# Patterns for extracting a short query label
_SELECT_RE = re.compile(r"^\s*(SELECT)\b.*?\bFROM\s+(\S+)", re.IGNORECASE | re.DOTALL)
_INSERT_RE = re.compile(r"^\s*(INSERT)\s+INTO\s+(\S+)", re.IGNORECASE)
_UPDATE_RE = re.compile(r"^\s*(UPDATE)\s+(\S+)", re.IGNORECASE)
_DELETE_RE = re.compile(r"^\s*(DELETE)\s+FROM\s+(\S+)", re.IGNORECASE)


def _extract_query_label(sql):
    """Extract a short label from a SQL query (e.g. 'SELECT users', 'INSERT orders')."""
    if not sql:
        return "query"

    text = sql if isinstance(sql, str) else str(sql)

    m = _SELECT_RE.match(text)
    if m:
        return f"{m.group(1).upper()} {m.group(2)}"

    m = _INSERT_RE.match(text)
    if m:
        return f"{m.group(1).upper()} {m.group(2)}"

    m = _UPDATE_RE.match(text)
    if m:
        return f"{m.group(1).upper()} {m.group(2)}"

    m = _DELETE_RE.match(text)
    if m:
        return f"{m.group(1).upper()} {m.group(2)}"

    # Fallback: first word
    first = text.strip().split()[0].upper() if text.strip() else "query"
    return first


def _extract_db_name(cursor):
    """Extract the database name from the cursor's connection."""
    try:
        dsn = cursor.connection.dsn
        # dsn is a string like "dbname=mydb user=me host=..."
        m = re.search(r"dbname=(\S+)", dsn)
        if m:
            return m.group(1)
    except Exception:
        pass
    try:
        info = cursor.connection.info
        if hasattr(info, "dbname"):
            return info.dbname
    except Exception:
        pass
    return "postgresql"


def _wrap_execute(original):
    """Wrap cursor.execute() to emit a span for each query."""

    def patched_execute(self, query, vars=None):
        from ._config import JstVerifyTracing

        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return original(self, query, vars)

        current = get_current_context()
        if current is None:
            return original(self, query, vars)

        location = from_first_user_frame()
        ctx = start_child_context()
        start_time = int(time.time() * 1000)
        status_code = 200
        status_message = None

        label = _extract_query_label(query)
        db_name = _extract_db_name(self)
        operation_name = f"PostgreSQL {label}"

        try:
            return original(self, query, vars)
        except Exception as e:
            status_code = 500
            status_message = str(e)
            raise
        finally:
            end_time = int(time.time() * 1000)
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": operation_name,
                "serviceName": db_name,
                "serviceType": "postgresql",
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
            }
            if status_message is not None:
                span["statusMessage"] = status_message
            span.update(location)
            from ._span import _enqueue
            _enqueue(instance, span)
            pop_context()

    return patched_execute


def _wrap_executemany(original):
    """Wrap cursor.executemany() to emit a span for batch queries."""

    def patched_executemany(self, query, vars_list):
        from ._config import JstVerifyTracing

        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return original(self, query, vars_list)

        current = get_current_context()
        if current is None:
            return original(self, query, vars_list)

        location = from_first_user_frame()
        ctx = start_child_context()
        start_time = int(time.time() * 1000)
        status_code = 200
        status_message = None

        label = _extract_query_label(query)
        db_name = _extract_db_name(self)
        operation_name = f"PostgreSQL {label} (batch)"

        try:
            return original(self, query, vars_list)
        except Exception as e:
            status_code = 500
            status_message = str(e)
            raise
        finally:
            end_time = int(time.time() * 1000)
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": operation_name,
                "serviceName": db_name,
                "serviceType": "postgresql",
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
            }
            if status_message is not None:
                span["statusMessage"] = status_message
            span.update(location)
            from ._span import _enqueue
            _enqueue(instance, span)
            pop_context()

    return patched_executemany


def patch_psycopg2():
    """Monkey-patch psycopg2 to auto-instrument cursor.execute() and cursor.executemany().

    Requires psycopg2 or psycopg2-binary to be installed. Call after jstverify_tracing.init().
    """
    global _original_execute, _original_executemany, _patched

    if _patched:
        return

    try:
        from psycopg2.extensions import cursor as Cursor
    except ImportError:
        logger.warning(
            "jstverify-tracing: psycopg2 not installed, skipping PostgreSQL auto-instrumentation. "
            "Install with: pip install psycopg2-binary"
        )
        return

    _original_execute = Cursor.execute
    _original_executemany = Cursor.executemany

    Cursor.execute = _wrap_execute(_original_execute)
    Cursor.executemany = _wrap_executemany(_original_executemany)

    _patched = True


def unpatch_psycopg2():
    """Restore the original psycopg2 cursor methods (for testing)."""
    global _original_execute, _original_executemany, _patched

    if not _patched:
        return

    try:
        from psycopg2.extensions import cursor as Cursor
    except ImportError:
        return

    if _original_execute is not None:
        Cursor.execute = _original_execute
    if _original_executemany is not None:
        Cursor.executemany = _original_executemany

    _original_execute = None
    _original_executemany = None
    _patched = False
