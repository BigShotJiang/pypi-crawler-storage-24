"""JstVerify Python Tracing SDK — auto-instrument your backend for distributed tracing."""

from ._version import __version__
from ._span import trace, trace_span, trace_dynamodb
from . import _propagation as propagation


def init(**kwargs):
    """Initialize the JstVerify tracing SDK. Call once at application startup.

    Args:
        api_key: Your JstVerify SDK API key (required).
        endpoint: Span ingestion endpoint URL. Defaults to the production
            ingestion endpoint (https://sdkapi.jstverify.com/v1/tracing/spans).
            Override for dev environments.
        service_name: Name for this service in the service map (required).
        service_type: Service type, default "http".
        flush_interval: Seconds between background flushes, default 5.0.
        max_queue_size: Max spans buffered before dropping oldest, default 200.
        max_batch_size: Max spans per API call, default 50.
        debug: Enable debug logging, default False.
        patch_requests: Auto-patch requests library, default True.
        patch_boto: Auto-patch boto3 to trace AWS API calls, default False.
            Pass True to instrument all services, or a list of service names
            (e.g. ["dynamodb", "s3"]) to instrument selectively. Requires
            the boto3 package (install with ``pip install jstverify-tracing[aws]``).
        transport: "direct" (default) sends spans via HTTP; "relay" buffers
            spans per-request and encodes them into the X-JstVerify-Spans
            response header for the JS SDK to relay. Use relay when the
            backend has no outbound internet access.
        sanitize_pii: Automatically redact PII patterns from span data,
            default True. See pii_patterns and pii_redaction below.
        pii_patterns: Additional regex patterns (strings) to redact from span
            data. Compiled once at init and appended to the built-in patterns
            (SSN, email, phone, credit card). Ignored when sanitize_pii=False.
            Invalid regex raises re.error at init time. Default [].
        pii_redaction: Replacement string for PII matches. Default "[REDACTED]".
            Ignored when sanitize_pii=False.
        patch_psycopg2: Auto-patch psycopg2 to trace PostgreSQL queries,
            default False. Requires the psycopg2 or psycopg2-binary package.
        patch_firebase_admin: Auto-patch firebase-admin to trace RTDB and
            Auth operations, default False. Requires the firebase-admin package.
    """
    from ._config import JstVerifyTracing
    return JstVerifyTracing.initialize(**kwargs)


def flush():
    """Synchronously flush all buffered spans. Useful at end of Lambda invocations."""
    from ._config import JstVerifyTracing
    instance = JstVerifyTracing.get_instance()
    if instance is not None:
        instance.flush()


def shutdown():
    """Flush remaining spans and stop the background thread. Also registered via atexit."""
    from ._config import JstVerifyTracing
    instance = JstVerifyTracing.get_instance()
    if instance is not None:
        instance.shutdown()


__all__ = ["__version__", "init", "flush", "shutdown", "trace", "trace_span", "trace_dynamodb", "propagation"]
