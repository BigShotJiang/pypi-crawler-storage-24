"""JstVerifyTracing singleton — holds global configuration and references."""

import atexit
import logging
import os
import re
from typing import List, Optional

from ._buffer import SpanBuffer
from ._transport import Transport

logger = logging.getLogger("jstverify_tracing")

DEFAULT_ENDPOINT = "https://sdkapi.jstverify.com/v1/tracing/spans"
_VALID_TRANSPORTS = ("direct", "relay")


class JstVerifyTracing:
    _instance: Optional["JstVerifyTracing"] = None

    def __init__(
        self,
        api_key: str,
        service_name: str,
        endpoint: str = "",
        service_type: str = "http",
        gateway_name: Optional[str] = None,
        flush_interval: float = 5.0,
        max_queue_size: int = 200,
        max_batch_size: int = 50,
        debug: bool = False,
        patch_requests: bool = True,
        patch_boto=False,
        patch_psycopg2: bool = False,
        patch_firebase_admin: bool = False,
        transport: str = "direct",
        sanitize_pii: bool = True,
        pii_patterns: Optional[List[str]] = None,
        pii_redaction: str = "[REDACTED]",
    ):
        if transport not in _VALID_TRANSPORTS:
            raise ValueError(
                f"Invalid transport {transport!r}, must be one of {_VALID_TRANSPORTS}"
            )

        self.api_key = api_key
        self.endpoint = endpoint
        self.service_name = service_name
        # Auto-detect Lambda environment when service_type is the default.
        # AWS_LAMBDA_FUNCTION_NAME is always set in Lambda; use it to
        # classify compute type so the Application Map shows the correct icon.
        if service_type == "http" and os.environ.get("AWS_LAMBDA_FUNCTION_NAME"):
            service_type = "lambda"
        self.service_type = service_type
        self.gateway_name = gateway_name
        self.debug = debug
        self.patch_requests = patch_requests
        self.patch_boto_config = patch_boto
        self.patch_psycopg2_config = patch_psycopg2
        self.patch_firebase_admin_config = patch_firebase_admin
        self.transport = transport
        self.sanitize_pii = sanitize_pii
        self.pii_redaction = pii_redaction

        # Compile custom PII patterns at init (fail fast on invalid regex)
        from ._sanitizer import _ALL_PATTERNS
        extra = [re.compile(p) for p in (pii_patterns or [])]
        self._compiled_pii = _ALL_PATTERNS + extra

        if debug:
            logging.getLogger("jstverify_tracing").setLevel(logging.DEBUG)

        if not self.endpoint:
            self.endpoint = DEFAULT_ENDPOINT

        if self.is_relay:
            self._transport = None
            self._buffer = None
        else:
            self._transport = Transport(endpoint=self.endpoint, api_key=api_key)
            self._buffer = SpanBuffer(
                transport=self._transport,
                flush_interval=flush_interval,
                max_queue_size=max_queue_size,
                max_batch_size=max_batch_size,
                sanitize_pii=sanitize_pii,
                pii_patterns=self._compiled_pii,
                pii_redaction=self.pii_redaction,
            )
            self._buffer.start()
            atexit.register(self.shutdown)

    @property
    def is_relay(self) -> bool:
        return self.transport == "relay"

    def flush(self) -> None:
        """Synchronously flush all buffered spans. Call at end of Lambda invocations."""
        if self._buffer is not None:
            self._buffer.flush_all()

    def shutdown(self) -> None:
        if self._buffer is not None:
            self._buffer.stop()

    @classmethod
    def get_instance(cls) -> Optional["JstVerifyTracing"]:
        return cls._instance

    @classmethod
    def initialize(cls, **kwargs) -> "JstVerifyTracing":
        if cls._instance is not None:
            logger.warning("jstverify-tracing: already initialized, ignoring re-init")
            return cls._instance
        cls._instance = cls(**kwargs)
        if cls._instance.patch_requests:
            from ._requests_patch import patch_requests
            patch_requests()
        if cls._instance.patch_boto_config:
            from ._boto_patch import patch_boto
            patch_boto(cls._instance.patch_boto_config)
        if cls._instance.patch_psycopg2_config:
            from ._psycopg2_patch import patch_psycopg2
            patch_psycopg2()
        if cls._instance.patch_firebase_admin_config:
            from ._firebase_admin_patch import patch_firebase_admin
            patch_firebase_admin()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset singleton (for testing)."""
        if cls._instance is not None:
            cls._instance.shutdown()
            cls._instance = None
        from ._boto_patch import unpatch_boto
        unpatch_boto()
        from ._psycopg2_patch import unpatch_psycopg2
        unpatch_psycopg2()
        from ._firebase_admin_patch import unpatch_firebase_admin
        unpatch_firebase_admin()
