"""FastAPI / Starlette middleware for JstVerify distributed tracing."""

import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from .._context import set_root_context, pop_context, clear_context, set_session_id, get_session_id
from .._config import JstVerifyTracing


class JstVerifyTracingMiddleware(BaseHTTPMiddleware):
    """Starlette-based middleware for auto-tracing incoming requests.

    Usage:
        from jstverify_tracing.integrations.fastapi import JstVerifyTracingMiddleware
        app.add_middleware(JstVerifyTracingMiddleware)

        # With API Gateway span synthesis:
        app.add_middleware(JstVerifyTracingMiddleware, gateway_name="my-api-gateway")
    """

    def __init__(self, app, gateway_name=None, **kwargs):
        super().__init__(app, **kwargs)
        self._gateway_name = gateway_name

    async def dispatch(self, request: Request, call_next) -> Response:
        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return await call_next(request)

        trace_id = request.headers.get("x-jstverify-trace-id") or str(uuid.uuid4())
        parent_span_id = request.headers.get("x-jstverify-parent-span-id")
        session_id = request.headers.get("x-jstverify-session-id")
        set_session_id(session_id)

        # Synthesize an API Gateway span between the caller and this Lambda
        gateway_name = self._gateway_name or getattr(instance, "gateway_name", None)
        gw_span_id = None
        gw_parent_span_id = None
        if gateway_name:
            gw_span_id = str(uuid.uuid4())
            gw_parent_span_id = parent_span_id
            parent_span_id = gw_span_id

        ctx = set_root_context(trace_id, parent_span_id)
        start_time = int(time.time() * 1000)
        status_code = 500

        # Pre-initialize the relay buffer so the mutable list reference is
        # shared with threads spawned by BaseHTTPMiddleware for sync handlers.
        if instance.is_relay:
            from .._relay_buffer import _get_or_create_buffer
            _get_or_create_buffer()

        try:
            response = await call_next(request)
            status_code = response.status_code
            return response
        except Exception:
            raise
        finally:
            end_time = int(time.time() * 1000)
            session_id = get_session_id()
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": f"{request.method} {request.url.path}",
                "serviceName": instance.service_name,
                "serviceType": instance.service_type,
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
                "httpMethod": request.method,
                "httpUrl": request.url.path,
                "httpStatusCode": status_code,
            }
            if session_id:
                span["sessionId"] = session_id

            # Build the synthetic API Gateway span
            gw_span = None
            if gw_span_id and gateway_name:
                gw_start = start_time - 10
                gw_end = end_time + 2
                gw_span = {
                    "traceId": ctx.trace_id,
                    "spanId": gw_span_id,
                    "parentSpanId": gw_parent_span_id,
                    "operationName": f"{request.method} {request.url.path}",
                    "serviceName": gateway_name,
                    "serviceType": "apigateway",
                    "startTime": gw_start,
                    "endTime": gw_end,
                    "duration": gw_end - gw_start,
                    "statusCode": status_code,
                    "httpMethod": request.method,
                    "httpUrl": request.url.path,
                    "httpStatusCode": status_code,
                }
                if session_id:
                    gw_span["sessionId"] = session_id

            if instance.is_relay:
                from .._relay_buffer import (
                    enqueue_relay_span, drain_relay_spans,
                    encode_relay_header, HEADER_NAME,
                )
                if gw_span:
                    enqueue_relay_span(gw_span)
                enqueue_relay_span(span)
                spans = drain_relay_spans()
                header_value = encode_relay_header(spans)
                if header_value is not None:
                    response.headers[HEADER_NAME] = header_value
                    response.headers["Access-Control-Expose-Headers"] = HEADER_NAME
            else:
                if gw_span:
                    instance._buffer.enqueue(gw_span)
                instance._buffer.enqueue(span)

            pop_context()
            clear_context()
