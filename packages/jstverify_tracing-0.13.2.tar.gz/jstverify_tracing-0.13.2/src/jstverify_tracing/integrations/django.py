"""Django middleware for JstVerify distributed tracing."""

import time
import uuid

from .._context import set_root_context, pop_context, clear_context, set_session_id, get_session_id
from .._config import JstVerifyTracing


class JstVerifyTracingMiddleware:
    """Django middleware for auto-tracing incoming requests.

    Usage (settings.py):
        MIDDLEWARE = [
            "jstverify_tracing.integrations.django.JstVerifyTracingMiddleware",
            ...
        ]

    To enable API Gateway span synthesis, set gateway_name in init():
        jstverify_tracing.init(gateway_name="my-api-gateway", ...)
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        instance = JstVerifyTracing.get_instance()
        if instance is None:
            return self.get_response(request)

        # Django normalises headers: X-JstVerify-Trace-Id → HTTP_X_JSTVERIFY_TRACE_ID
        trace_id = request.META.get("HTTP_X_JSTVERIFY_TRACE_ID") or str(uuid.uuid4())
        parent_span_id = request.META.get("HTTP_X_JSTVERIFY_PARENT_SPAN_ID")
        session_id = request.META.get("HTTP_X_JSTVERIFY_SESSION_ID")
        set_session_id(session_id)

        # Synthesize an API Gateway span between the caller and this Lambda
        gateway_name = getattr(instance, "gateway_name", None)
        gw_span_id = None
        gw_parent_span_id = None
        if gateway_name:
            gw_span_id = str(uuid.uuid4())
            gw_parent_span_id = parent_span_id
            parent_span_id = gw_span_id

        ctx = set_root_context(trace_id, parent_span_id)
        start_time = int(time.time() * 1000)

        try:
            response = self.get_response(request)
        except Exception:
            end_time = int(time.time() * 1000)
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": f"{request.method} {request.path}",
                "serviceName": instance.service_name,
                "serviceType": instance.service_type,
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": 500,
                "httpMethod": request.method,
                "httpUrl": request.path,
                "httpStatusCode": 500,
            }
            if session_id:
                span["sessionId"] = session_id
            if instance.is_relay:
                from .._relay_buffer import drain_relay_spans
                drain_relay_spans()  # prevent stale spans leaking
            else:
                if gw_span_id and gateway_name:
                    gw_start = start_time - 10
                    gw_end = end_time + 2
                    gw_span = {
                        "traceId": ctx.trace_id,
                        "spanId": gw_span_id,
                        "parentSpanId": gw_parent_span_id,
                        "operationName": f"{request.method} {request.path}",
                        "serviceName": gateway_name,
                        "serviceType": "apigateway",
                        "startTime": gw_start,
                        "endTime": gw_end,
                        "duration": gw_end - gw_start,
                        "statusCode": 500,
                        "httpMethod": request.method,
                        "httpUrl": request.path,
                        "httpStatusCode": 500,
                    }
                    if session_id:
                        gw_span["sessionId"] = session_id
                    instance._buffer.enqueue(gw_span)
                instance._buffer.enqueue(span)
            raise
        finally:
            clear_context()

        end_time = int(time.time() * 1000)
        span = {
            "traceId": ctx.trace_id,
            "spanId": ctx.span_id,
            "parentSpanId": ctx.parent_span_id,
            "operationName": f"{request.method} {request.path}",
            "serviceName": instance.service_name,
            "serviceType": instance.service_type,
            "startTime": start_time,
            "endTime": end_time,
            "duration": end_time - start_time,
            "statusCode": response.status_code,
            "httpMethod": request.method,
            "httpUrl": request.path,
            "httpStatusCode": response.status_code,
        }
        if session_id:
            span["sessionId"] = session_id

        # Build the synthetic API Gateway span
        gw_span = None
        if gw_span_id and gateway_name:
            gw_start = start_time - 10
            gw_end = end_time + 2
            gw_span = {
                "traceId": ctx.trace_id,
                "spanId": gw_span_id,
                "parentSpanId": gw_parent_span_id,
                "operationName": f"{request.method} {request.path}",
                "serviceName": gateway_name,
                "serviceType": "apigateway",
                "startTime": gw_start,
                "endTime": gw_end,
                "duration": gw_end - gw_start,
                "statusCode": response.status_code,
                "httpMethod": request.method,
                "httpUrl": request.path,
                "httpStatusCode": response.status_code,
            }
            if session_id:
                gw_span["sessionId"] = session_id

        if instance.is_relay:
            from .._relay_buffer import (
                enqueue_relay_span, drain_relay_spans,
                encode_relay_header, HEADER_NAME,
            )
            if gw_span:
                enqueue_relay_span(gw_span)
            enqueue_relay_span(span)
            spans = drain_relay_spans()
            header_value = encode_relay_header(spans)
            if header_value is not None:
                response[HEADER_NAME] = header_value
                response["Access-Control-Expose-Headers"] = HEADER_NAME
        else:
            if gw_span:
                instance._buffer.enqueue(gw_span)
            instance._buffer.enqueue(span)

        pop_context()

        return response
