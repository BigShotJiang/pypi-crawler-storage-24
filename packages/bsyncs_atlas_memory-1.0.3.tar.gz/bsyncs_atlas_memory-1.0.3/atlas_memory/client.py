"""
ATLAS Memory SDK — Python Client
Zero-dependency (only `requests`). Works with OpenAI, LangChain, CrewAI,
AutoGen, plain Python agents, or any REST-capable framework.

Install:  pip install requests
Usage:    from atlas_sdk import AtlasMemory
"""

from __future__ import annotations
import json
import requests
from typing import Optional


class AtlasMemory:
    """
    Client for the ATLAS Knowledge Graph Memory Service.

    Parameters
    ----------
    api_key    : Your ATLAS API key (starts with 'atlas_')
    base_url   : Base URL of your ATLAS deployment (no trailing slash)
    session_id : Optional sub-namespace. Use a user_id or conversation_id
                 to keep memories isolated per user / conversation.
    timeout    : HTTP timeout in seconds (default 120 — ingest runs SLM inference)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://localhost:8000",
        session_id: Optional[str] = None,
        timeout: int = 120,
    ):
        self.api_key    = api_key
        self.base_url   = base_url.rstrip("/")
        self.session_id = session_id
        self.timeout    = timeout
        self._headers   = {"x-api-key": api_key, "Content-Type": "application/json"}

    # ── Core Methods ──────────────────────────────────────────────────────────

    def ingest(self, text: str) -> dict:
        """
        Store facts extracted from `text` into the knowledge graph.

        Returns a dict with `facts_stored` (int) and `facts` (list of triples).
        """
        payload = {"text": text}
        if self.session_id:
            payload["session_id"] = self.session_id
        return self._post("/sdk/ingest", payload)

    def search(self, query: str, k: int = 5) -> list[dict]:
        """
        Search memory for facts relevant to `query`.

        Returns a list of fact dicts, each with:
          - fact        : "Subject relation Object" as a string
          - subject     : entity name
          - relation    : relationship phrase
          - object      : entity name
          - score       : composite relevance score (higher = better)
          - V / R / F / A : individual score components
        """
        payload = {"query": query, "k": k}
        if self.session_id:
            payload["session_id"] = self.session_id
        response = self._post("/sdk/search", payload)
        return response.get("results", [])

    def clear(self) -> dict:
        """Delete all stored facts for this key / session_id. Irreversible."""
        params = {}
        if self.session_id:
            params["session_id"] = self.session_id
        r = requests.delete(
            f"{self.base_url}/sdk/clear",
            headers=self._headers,
            params=params,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def usage(self) -> dict:
        """Return current monthly usage and plan limits."""
        r = requests.get(
            f"{self.base_url}/sdk/usage",
            headers=self._headers,
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def format_context(self, results: list[dict], max_facts: int = 5) -> str:
        """
        Convert search results into a compact string for injection into
        an LLM system prompt or user message.

        Example output:
            [Memory Context]
            - Database switched to PostgreSQL (confidence: high, recent)
            - Sarah Jenkins is Lead DevOps Engineer
        """
        if not results:
            return ""
        lines = ["[Memory Context]"]
        for r in results[:max_facts]:
            recency = "recent" if r.get("R", 0) > 0.5 else "older"
            confidence = "high" if r.get("score", 0) > 0.6 else "medium"
            lines.append(f"- {r['fact']}  ({confidence} confidence, {recency})")
        return "\n".join(lines)

    # ── OpenAI Function Calling / Tool Use ───────────────────────────────────

    def get_openai_tools(self) -> list[dict]:
        """
        Return tool definitions compatible with OpenAI's function calling API
        (works with GPT-4o, GPT-3.5-turbo, and any OpenAI-compatible endpoint).
        Pass the returned list as the `tools` parameter in client.chat.completions.create().
        """
        return [
            {
                "type": "function",
                "function": {
                    "name": "atlas_save_memory",
                    "description": (
                        "Save important information, facts, or decisions to long-term memory. "
                        "Call this when the user shares something that should be remembered "
                        "for future conversations — e.g. preferences, project details, "
                        "team structure, decisions made."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "text": {
                                "type": "string",
                                "description": "The information to save. Can be a full sentence or paragraph.",
                            }
                        },
                        "required": ["text"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "atlas_search_memory",
                    "description": (
                        "Search long-term memory for context relevant to the current question. "
                        "Call this BEFORE answering questions about past decisions, project state, "
                        "team members, or anything the user may have mentioned previously."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "What you want to look up in memory.",
                            },
                            "k": {
                                "type": "integer",
                                "description": "Number of facts to retrieve (default 5, max 10).",
                                "default": 5,
                            },
                        },
                        "required": ["query"],
                    },
                },
            },
        ]

    def handle_tool_call(self, tool_name: str, tool_args: dict) -> str:
        """
        Execute a tool call dispatched by the OpenAI API and return a string
        result to send back as a tool_result message.
        Splits compound sentences before ingesting so the SLM receives one
        atomic statement per call — no client prompt engineering needed.
        """
        if tool_name == "atlas_save_memory":
            import re as _re
            text = tool_args["text"]

            # Normalise transitional pricing/value sentences:
            # "X changed from A to B" -> "X is B"
            # This converts change-of-state sentences into current-state facts
            # so the SLM extracts the new value, not a diff.
            text = _re.sub(
                r"(?i)(changed?|changing|updated?|updating|switched?|switching)"
                r"\s+from\s+[^,\.]+\s+to\s+",
                r"is now ",
                text
            )

            # Split on sentence boundaries
            pattern = _re.compile(r"(?<=[.!?])\s+")
            sentences = [s.strip() for s in pattern.split(text) if s.strip()]
            if not sentences:
                sentences = [text]
            total = 0
            for sentence in sentences:
                try:
                    result = self.ingest(sentence)
                    total += result.get("facts_stored", 0)
                except Exception:
                    pass
            return f"Saved {total} fact(s) to memory."

        if tool_name == "atlas_search_memory":
            results = self.search(tool_args["query"], k=tool_args.get("k", 5))
            if not results:
                return "No relevant memories found."
            return self.format_context(results)

        return f"Unknown tool: {tool_name}"


    def get_langchain_tools(self):
        """
        Return LangChain Tool objects for use in LangChain agents.
        Requires langchain-core: pip install langchain-core
        """
        try:
            from langchain_core.tools import Tool
        except ImportError:
            raise ImportError(
                "langchain-core is required for LangChain integration. "
                "Install it with: pip install langchain-core"
            )

        def _ingest(text: str) -> str:
            result = self.ingest(text)
            return f"Saved {result['facts_stored']} fact(s) to memory."

        def _search(query: str) -> str:
            results = self.search(query)
            return self.format_context(results) if results else "No memories found."

        return [
            Tool(
                name="atlas_save_memory",
                func=_ingest,
                description=(
                    "Save important facts or decisions to long-term memory. "
                    "Input should be a sentence or paragraph describing what to remember."
                ),
            ),
            Tool(
                name="atlas_search_memory",
                func=_search,
                description=(
                    "Search long-term memory for context relevant to a question. "
                    "Input should be a natural language query."
                ),
            ),
        ]

    # ── Internal ─────────────────────────────────────────────────────────────

    def _post(self, path: str, payload: dict) -> dict:
        r = requests.post(
            f"{self.base_url}{path}",
            headers=self._headers,
            json=payload,
            timeout=self.timeout,
        )
        if r.status_code == 429:
            raise RuntimeError(f"Rate limit exceeded: {r.json().get('detail')}")
        if r.status_code == 401:
            raise RuntimeError(f"Authentication failed: {r.json().get('detail')}")
        r.raise_for_status()
        return r.json()

    def __repr__(self) -> str:
        return (f"AtlasMemory(base_url={self.base_url!r}, "
                f"session_id={self.session_id!r})")