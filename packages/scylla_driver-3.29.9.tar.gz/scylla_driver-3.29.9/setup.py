# Copyright DataStax, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import sys
import json
import warnings
from pathlib import Path
from setuptools.command.build_ext import build_ext
from setuptools import Extension, Command, setup
from setuptools.errors import (CCompilerError, PlatformError,
                              ExecError)

try:
    import subprocess
    has_subprocess = True
except ImportError:
    has_subprocess = False


has_cqlengine = False
if __name__ == '__main__' and len(sys.argv) > 1 and sys.argv[1] == "install":
    try:
        import cqlengine
        has_cqlengine = True
    except ImportError:
        pass

PROFILING = False


class DocCommand(Command):

    description = "generate or test documentation"

    user_options = [("test", "t",
                     "run doctests instead of generating documentation")]

    boolean_options = ["test"]

    def initialize_options(self):
        self.test = False

    def finalize_options(self):
        pass

    def run(self):
        if self.test:
            path = "docs/_build/doctest"
            mode = "doctest"
        else:
            from cassandra import __version__
            path = "docs/_build/%s" % __version__
            mode = "html"

            try:
                os.makedirs(path)
            except:
                pass

        if has_subprocess:
            # Prevent run with in-place extensions because cython-generated objects do not carry docstrings
            # http://docs.cython.org/src/userguide/special_methods.html#docstrings
            import glob
            for f in glob.glob("cassandra/*.so"):
                print("Removing '%s' to allow docs to run on pure python modules." %(f,))
                os.unlink(f)

            # Build io extension to make import and docstrings work
            try:
                output = subprocess.check_output(
                    ["python", "setup.py", "build_ext", "--inplace", "--force", "--no-murmur3", "--no-cython"],
                    stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as exc:
                raise RuntimeError("Documentation step '%s' failed: %s: %s" % ("build_ext", exc, exc.output))
            else:
                print(output)

            try:
                output = subprocess.check_output(
                    ["sphinx-build", "-b", mode, "docs", path],
                    stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as exc:
                raise RuntimeError("Documentation step '%s' failed: %s: %s" % (mode, exc, exc.output))
            else:
                print(output)

            print("")
            print("Documentation step '%s' performed, results here:" % mode)
            print("   file://%s/%s/index.html" % (os.path.dirname(os.path.realpath(__file__)), path))


class BuildFailed(Exception):

    def __init__(self, ext):
        self.ext = ext

is_windows = sys.platform.startswith('win32')
is_macos = sys.platform.startswith('darwin')

def get_subdriname(directory_path):
    try:
        # List only subdirectories in the given directory
        subdirectories = [name for dir in directory_path for name in os.listdir(dir)
                          if os.path.isdir(os.path.join(directory_path, name))]
        return subdirectories
    except Exception:
        return []

def get_libev_headers_path():
    libev_hb_paths = ["/opt/homebrew/Cellar/libev", os.path.expanduser('~/homebrew/Cellar/libev')]
    for hb_path in libev_hb_paths:
        if not os.path.exists(hb_path):
            continue
        versions = [dir for dir in get_subdriname(hb_path) if dir[0] in "0123456789"]
        if not versions:
            continue
        picked_version = sorted(versions, reverse=True)[0]
        resulted_path = os.path.join(hb_path, picked_version, 'include')
        warnings.warn("found libev headers in '%s'" % resulted_path)
        return [resulted_path]
    warnings.warn("did not find libev headers in '%s'" % libev_hb_paths)
    return []


murmur3_ext = Extension('cassandra.cmurmur3',
                        sources=['cassandra/cmurmur3.c'])

is_macos = sys.platform.startswith('darwin')

def eval_env_var_as_array(varname):
    val = os.environ.get(varname)
    return None if not val else [v.strip() for v in val.split(',')]

DEFAULT_LIBEV_INCLUDES = ['/usr/include/libev', '/usr/local/include', '/opt/local/include', '/usr/include']
DEFAULT_LIBEV_LIBDIRS = ['/usr/local/lib', '/opt/local/lib', '/usr/lib64']
libev_includes = eval_env_var_as_array('CASS_DRIVER_LIBEV_INCLUDES') or DEFAULT_LIBEV_INCLUDES
libev_libdirs = eval_env_var_as_array('CASS_DRIVER_LIBEV_LIBS') or DEFAULT_LIBEV_LIBDIRS

if is_macos:
    libev_includes.extend(['/opt/homebrew/include', os.path.expanduser('~/homebrew/include'), *get_libev_headers_path()])
    libev_libdirs.extend(['/opt/homebrew/lib'])

conan_envfile = Path(__file__).parent / 'build-release/conan/conandeps.env'
if conan_envfile.exists():
    conan_paths = json.loads(conan_envfile.read_text())
    libev_includes.extend([conan_paths.get('include_dirs')])
    libev_libdirs.extend([conan_paths.get('library_dirs')])

libev_ext = Extension('cassandra.io.libevwrapper',
                      sources=['cassandra/io/libevwrapper.c'],
                      include_dirs=libev_includes,
                      libraries=['ev'],
                      library_dirs=libev_libdirs)

platform_unsupported_msg = \
"""
===============================================================================
The optional C extensions are not supported on this platform.
===============================================================================
"""

arch_unsupported_msg = \
"""
===============================================================================
The optional C extensions are not supported on big-endian systems.
===============================================================================
"""

pypy_unsupported_msg = \
"""
=================================================================================
Some optional C extensions are not supported in PyPy. Only murmur3 will be built.
=================================================================================
"""

is_pypy = "PyPy" in sys.version
if is_pypy:
    sys.stderr.write(pypy_unsupported_msg)

is_supported_platform = sys.platform != "cli" and not sys.platform.startswith("java")
is_supported_arch = sys.byteorder != "big"
if not is_supported_platform:
    sys.stderr.write(platform_unsupported_msg)
elif not is_supported_arch:
    sys.stderr.write(arch_unsupported_msg)

try_extensions = "--no-extensions" not in sys.argv and is_supported_platform and is_supported_arch and not os.environ.get('CASS_DRIVER_NO_EXTENSIONS')
try_murmur3 = try_extensions and "--no-murmur3" not in sys.argv
try_libev = try_extensions and "--no-libev" not in sys.argv and not is_pypy and not os.environ.get('CASS_DRIVER_NO_LIBEV')
try_cython = try_extensions and "--no-cython" not in sys.argv and not is_pypy and not os.environ.get('CASS_DRIVER_NO_CYTHON')
sys.argv = [a for a in sys.argv if a not in ("--no-murmur3", "--no-libev", "--no-cython", "--no-extensions")]

build_concurrency = int(os.environ.get('CASS_DRIVER_BUILD_CONCURRENCY', '0'))
if build_concurrency == 0:
    build_concurrency = None

CASS_DRIVER_BUILD_EXTENSIONS_ARE_MUST = bool(os.environ.get('CASS_DRIVER_BUILD_EXTENSIONS_ARE_MUST', 'no') == 'yes')

class NoPatchExtension(Extension):

    # Older versions of setuptools.extension has a static flag which is set False before our
    # setup_requires lands Cython. It causes our *.pyx sources to be renamed to *.c in
    # the initializer.
    # The other workaround would be to manually generate sources, but that bypasses a lot
    # of the niceness cythonize embodies (setup build dir, conditional build, etc).
    # Newer setuptools does not have this problem because it checks for cython dynamically.
    # https://bitbucket.org/pypa/setuptools/commits/714c3144e08fd01a9f61d1c88411e76d2538b2e4

    def __init__(self, *args, **kwargs):
        # bypass the patched init if possible
        if Extension.__bases__:
            base, = Extension.__bases__
            base.__init__(self, *args, **kwargs)
        else:
            Extension.__init__(self, *args, **kwargs)


class build_extensions(build_ext):
    _needs_stub = False

    error_message = """
===============================================================================
WARNING: could not compile %s.

The C extensions are not required for the driver to run, but they add support
for token-aware routing with the Murmur3Partitioner.

On Windows, make sure Visual Studio or an SDK is installed, and your environment
is configured to build for the appropriate architecture (matching your Python runtime).
This is often a matter of using vcvarsall.bat from your install directory, or running
from a command prompt in the Visual Studio Tools Start Menu.
===============================================================================
""" if is_windows else """
===============================================================================
WARNING: could not compile %s.

The C extensions are not required for the driver to run, but they add support
for libev and token-aware routing with the Murmur3Partitioner.

Linux users should ensure that GCC and the Python headers are available.

On Ubuntu and Debian, this can be accomplished by running:

    $ sudo apt-get install build-essential python-dev

On RedHat and RedHat-based systems like CentOS and Fedora:

    $ sudo yum install gcc python-devel

On OSX, homebrew installations of Python should provide the necessary headers.

libev Support
-------------
For libev support, you will also need to install libev and its headers.

On Debian/Ubuntu:

    $ sudo apt-get install libev4 libev-dev

On RHEL/CentOS/Fedora:

    $ sudo yum install libev libev-devel

On OSX, via homebrew:

    $ brew install libev

===============================================================================
    """

    def run(self):
        try:
            self._setup_extensions()
            build_ext.run(self)
        except PlatformError as exc:
            sys.stderr.write('%s\n' % str(exc))
            warnings.warn(self.error_message % "C extensions.")
            if CASS_DRIVER_BUILD_EXTENSIONS_ARE_MUST:
                raise


    def build_extensions(self):
        if build_concurrency is None or build_concurrency > 1:
            self.check_extensions_list(self.extensions)

            import multiprocessing.pool
            multiprocessing.pool.ThreadPool(processes=build_concurrency).map(self.build_extension, self.extensions)
        else:
            build_ext.build_extensions(self)

    def build_extension(self, ext):
        try:
            build_ext.build_extension(self, fix_extension_class(ext))
        except (CCompilerError, ExecError,
                PlatformError, IOError) as exc:
            sys.stderr.write('%s\n' % str(exc))
            name = "The %s extension" % (ext.name,)
            warnings.warn(self.error_message % (name,))
            if CASS_DRIVER_BUILD_EXTENSIONS_ARE_MUST:
                raise

    def _setup_extensions(self):
        # We defer extension setup until this command to leveraage 'setup_requires' pulling in Cython before we
        # attempt to import anything
        self.extensions = []

        if try_murmur3:
            self.extensions.append(murmur3_ext)

        if try_libev:
            sys.stderr.write("Appending libev extension %s" % libev_ext)
            self.extensions.append(libev_ext)

        if try_cython:
            try:
                from Cython.Build import cythonize
                cython_candidates = ['cluster', 'concurrent', 'connection', 'cqltypes', 'metadata',
                                     'pool', 'protocol', 'query', 'util', 'shard_info']
                compile_args = [] if is_windows else ['-Wno-unused-function']
                self.extensions.extend(cythonize(
                    [Extension('cassandra.%s' % m, ['cassandra/%s.py' % m],
                               extra_compile_args=compile_args)
                        for m in cython_candidates],
                    nthreads=build_concurrency,
                    compiler_directives={'language_level': 3},
                    exclude_failures=not CASS_DRIVER_BUILD_EXTENSIONS_ARE_MUST,
                ))

                self.extensions.extend(cythonize(
                    NoPatchExtension("*", ["cassandra/*.pyx"], extra_compile_args=compile_args),
                    nthreads=build_concurrency,
                    compiler_directives={'language_level': 3},
                ))
            except Exception:
                sys.stderr.write("Failed to cythonize one or more modules. These will not be compiled as extensions (optional).\n")
                if CASS_DRIVER_BUILD_EXTENSIONS_ARE_MUST:
                    raise


def fix_extension_class(ext: Extension) -> Extension:
    # Avoid bug in setuptools that requires _needs_stub
    ext._needs_stub = False
    return ext


def run_setup(extensions):

    kw = {'cmdclass': {'doc': DocCommand}}
    kw['cmdclass']['build_ext'] = build_extensions
    kw['ext_modules'] = [Extension('DUMMY', [])]  # dummy extension makes sure build_ext is called for install

    setup(**kw)

run_setup(None)

if has_cqlengine:
    warnings.warn("\n#######\n'cqlengine' package is present on path: %s\n"
                  "cqlengine is now an integrated sub-package of this driver.\n"
                  "It is recommended to remove this package to reduce the chance for conflicting usage" % cqlengine.__file__)
