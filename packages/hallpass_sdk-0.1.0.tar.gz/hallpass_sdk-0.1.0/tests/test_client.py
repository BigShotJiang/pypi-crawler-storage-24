from hallpass_sdk import HallpassClient


def test_client_has_api_methods():
    client = HallpassClient()
    assert callable(client.get_public_profile)
    assert callable(client.create_message)
    assert callable(client.verify_message)
    assert callable(client.get_message_verification)


def test_client_default_base_url():
    client = HallpassClient()
    assert "hallpass.org" in client._gen._base_url


def test_client_custom_base_url():
    client = HallpassClient("https://custom.example.com/")
    assert "custom.example.com" in client._gen._base_url


def test_generated_client_accessible():
    client = HallpassClient()
    gen = client.generated
    assert gen is not None
