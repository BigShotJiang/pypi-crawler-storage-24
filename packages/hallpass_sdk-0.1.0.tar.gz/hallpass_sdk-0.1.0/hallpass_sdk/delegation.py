"""Delegation JWT signing for user-managed key mode."""

from __future__ import annotations

from typing import Any

from hallpass_sdk.jwt import sign_compact_jwt


def create_delegation_jwt(payload: dict[str, Any], private_jwk: dict[str, Any]) -> str:
    """Sign a delegation JWT."""
    return sign_compact_jwt(
        payload,
        private_jwk,
        header={"typ": "hallpass-profile-authorization+jwt"},
    )
