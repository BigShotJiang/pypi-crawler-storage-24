"""Agent challenge-response signing."""

from __future__ import annotations

from hallpass_sdk.jwt import sign_compact_jwt
from hallpass_sdk.keys import AgentKeyMaterial


def create_agent_challenge_response(*, challenge: str, key_material: AgentKeyMaterial) -> str:
    """Sign a challenge token to prove key possession."""
    claims = {
        "iss": key_material.did,
        "challenge": challenge,
    }

    return sign_compact_jwt(
        claims,
        key_material.private_jwk,
        header={"typ": "hallpass-agent-proof+jwt", "jwk": key_material.public_jwk},
    )
