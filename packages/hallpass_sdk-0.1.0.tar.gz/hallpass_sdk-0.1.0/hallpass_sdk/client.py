"""High-level Hallpass client that composes the generated HTTP client with hand-written crypto.

The generated client in hallpass_sdk.generated handles HTTP transport and typed
models. This module re-exports a convenience wrapper with the default base URL
and shortcuts for the most common workflows.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from hallpass_sdk.generated.client import Client as GeneratedClient
from hallpass_sdk.generated.api.profiles import show_profile
from hallpass_sdk.generated.api.messages import create_message as gen_create_message
from hallpass_sdk.generated.api.verification import (
    verify_message_bundle,
    show_message_verification,
)
from hallpass_sdk.messages import MessageProofBundle

DEFAULT_BASE_URL = "https://hallpass.org"


class HallpassClient:
    """Typed client for the Hallpass API.

    Wraps the auto-generated httpx client from openapi-python-client.
    Hand-written crypto operations live in their own modules; this class
    handles HTTP transport only.
    """

    def __init__(self, base_url: str = DEFAULT_BASE_URL, session_cookie: str | None = None) -> None:
        cookies = {"_hallpass_session": session_cookie} if session_cookie else {}
        self._gen = GeneratedClient(base_url=f"{base_url.rstrip('/')}/api/v1", cookies=cookies)

    @property
    def generated(self) -> GeneratedClient:
        """Access the underlying generated client for direct API calls."""
        return self._gen

    def get_public_profile(self, username: str) -> Any:
        return show_profile.sync(username=username, client=self._gen)

    def create_message(self, bundle: MessageProofBundle) -> Any:
        from hallpass_sdk.generated.models.create_message_request import CreateMessageRequest
        from hallpass_sdk.generated.models.message_bundle import MessageBundle
        from hallpass_sdk.generated.models.message_bundle_public_jwk import MessageBundlePublicJwk

        bundle_dict = asdict(bundle)
        public_jwk = MessageBundlePublicJwk.from_dict(bundle_dict.pop("public_jwk"))
        mb = MessageBundle.from_dict({**bundle_dict, "public_jwk": public_jwk})
        body = CreateMessageRequest(bundle=mb)
        return gen_create_message.sync(client=self._gen, body=body)

    def verify_message(self, bundle: MessageProofBundle) -> Any:
        from hallpass_sdk.generated.models.create_message_request import CreateMessageRequest
        from hallpass_sdk.generated.models.message_bundle import MessageBundle
        from hallpass_sdk.generated.models.message_bundle_public_jwk import MessageBundlePublicJwk

        bundle_dict = asdict(bundle)
        public_jwk = MessageBundlePublicJwk.from_dict(bundle_dict.pop("public_jwk"))
        mb = MessageBundle.from_dict({**bundle_dict, "public_jwk": public_jwk})
        body = CreateMessageRequest(bundle=mb)
        return verify_message_bundle.sync(client=self._gen, body=body)

    def get_message_verification(self, message_id: str) -> Any:
        return show_message_verification.sync(message_id=message_id, client=self._gen)
