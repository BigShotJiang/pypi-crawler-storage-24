from enum import Enum


class WorkspaceStage(str, Enum):
    ADD_ATTESTATIONS = "add_attestations"
    DELEGATE_AGENT = "delegate_agent"
    REGISTER_AGENT = "register_agent"
    VERIFY_MESSAGES = "verify_messages"

    def __str__(self) -> str:
        return str(self.value)
