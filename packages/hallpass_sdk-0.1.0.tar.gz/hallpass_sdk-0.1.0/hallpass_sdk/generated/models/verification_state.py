from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="VerificationState")


@_attrs_define
class VerificationState:
    """
    Attributes:
        state (str | Unset):
        summary (str | Unset):
        username (str | Unset):
        display_name (str | Unset):
        agent_id (str | Unset):
        agent_did (str | Unset):
        verification_method (str | Unset):
    """

    state: str | Unset = UNSET
    summary: str | Unset = UNSET
    username: str | Unset = UNSET
    display_name: str | Unset = UNSET
    agent_id: str | Unset = UNSET
    agent_did: str | Unset = UNSET
    verification_method: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        state = self.state

        summary = self.summary

        username = self.username

        display_name = self.display_name

        agent_id = self.agent_id

        agent_did = self.agent_did

        verification_method = self.verification_method

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if state is not UNSET:
            field_dict["state"] = state
        if summary is not UNSET:
            field_dict["summary"] = summary
        if username is not UNSET:
            field_dict["username"] = username
        if display_name is not UNSET:
            field_dict["display_name"] = display_name
        if agent_id is not UNSET:
            field_dict["agent_id"] = agent_id
        if agent_did is not UNSET:
            field_dict["agent_did"] = agent_did
        if verification_method is not UNSET:
            field_dict["verification_method"] = verification_method

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        state = d.pop("state", UNSET)

        summary = d.pop("summary", UNSET)

        username = d.pop("username", UNSET)

        display_name = d.pop("display_name", UNSET)

        agent_id = d.pop("agent_id", UNSET)

        agent_did = d.pop("agent_did", UNSET)

        verification_method = d.pop("verification_method", UNSET)

        verification_state = cls(
            state=state,
            summary=summary,
            username=username,
            display_name=display_name,
            agent_id=agent_id,
            agent_did=agent_did,
            verification_method=verification_method,
        )

        verification_state.additional_properties = d
        return verification_state

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
