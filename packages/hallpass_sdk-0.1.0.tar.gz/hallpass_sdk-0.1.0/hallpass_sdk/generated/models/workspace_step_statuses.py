from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="WorkspaceStepStatuses")


@_attrs_define
class WorkspaceStepStatuses:
    """
    Attributes:
        attestations (str):
        agent (str):
        delegation (str):
        verification (str):
    """

    attestations: str
    agent: str
    delegation: str
    verification: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        attestations = self.attestations

        agent = self.agent

        delegation = self.delegation

        verification = self.verification

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "attestations": attestations,
                "agent": agent,
                "delegation": delegation,
                "verification": verification,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        attestations = d.pop("attestations")

        agent = d.pop("agent")

        delegation = d.pop("delegation")

        verification = d.pop("verification")

        workspace_step_statuses = cls(
            attestations=attestations,
            agent=agent,
            delegation=delegation,
            verification=verification,
        )

        workspace_step_statuses.additional_properties = d
        return workspace_step_statuses

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
