from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.submit_delegation_request_payload import SubmitDelegationRequestPayload


T = TypeVar("T", bound="SubmitDelegationRequest")


@_attrs_define
class SubmitDelegationRequest:
    """
    Attributes:
        agent_id (UUID):
        payload (SubmitDelegationRequestPayload):
        signed_jws (str):
        submission_origin (str | Unset):
    """

    agent_id: UUID
    payload: SubmitDelegationRequestPayload
    signed_jws: str
    submission_origin: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_id = str(self.agent_id)

        payload = self.payload.to_dict()

        signed_jws = self.signed_jws

        submission_origin = self.submission_origin

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_id": agent_id,
                "payload": payload,
                "signed_jws": signed_jws,
            }
        )
        if submission_origin is not UNSET:
            field_dict["submission_origin"] = submission_origin

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.submit_delegation_request_payload import SubmitDelegationRequestPayload

        d = dict(src_dict)
        agent_id = UUID(d.pop("agent_id"))

        payload = SubmitDelegationRequestPayload.from_dict(d.pop("payload"))

        signed_jws = d.pop("signed_jws")

        submission_origin = d.pop("submission_origin", UNSET)

        submit_delegation_request = cls(
            agent_id=agent_id,
            payload=payload,
            signed_jws=signed_jws,
            submission_origin=submission_origin,
        )

        submit_delegation_request.additional_properties = d
        return submit_delegation_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
