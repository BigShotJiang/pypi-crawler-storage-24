from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.message_delegate_verification import MessageDelegateVerification
    from ..models.message_local_verification import MessageLocalVerification


T = TypeVar("T", bound="Message")


@_attrs_define
class Message:
    """
    Attributes:
        id (UUID):
        account_id (UUID):
        username (str):
        agent_id (UUID):
        delegation_id (UUID):
        author_label (str):
        body (str):
        signer_did (str):
        verification_method (str):
        key_fingerprint (str):
        local_verification (MessageLocalVerification):
        delegate_verification (MessageDelegateVerification):
        inserted_at (datetime.datetime):
        hosted_verification_path (str | Unset):
    """

    id: UUID
    account_id: UUID
    username: str
    agent_id: UUID
    delegation_id: UUID
    author_label: str
    body: str
    signer_did: str
    verification_method: str
    key_fingerprint: str
    local_verification: MessageLocalVerification
    delegate_verification: MessageDelegateVerification
    inserted_at: datetime.datetime
    hosted_verification_path: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        account_id = str(self.account_id)

        username = self.username

        agent_id = str(self.agent_id)

        delegation_id = str(self.delegation_id)

        author_label = self.author_label

        body = self.body

        signer_did = self.signer_did

        verification_method = self.verification_method

        key_fingerprint = self.key_fingerprint

        local_verification = self.local_verification.to_dict()

        delegate_verification = self.delegate_verification.to_dict()

        inserted_at = self.inserted_at.isoformat()

        hosted_verification_path = self.hosted_verification_path

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "account_id": account_id,
                "username": username,
                "agent_id": agent_id,
                "delegation_id": delegation_id,
                "author_label": author_label,
                "body": body,
                "signer_did": signer_did,
                "verification_method": verification_method,
                "key_fingerprint": key_fingerprint,
                "local_verification": local_verification,
                "delegate_verification": delegate_verification,
                "inserted_at": inserted_at,
            }
        )
        if hosted_verification_path is not UNSET:
            field_dict["hosted_verification_path"] = hosted_verification_path

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message_delegate_verification import MessageDelegateVerification
        from ..models.message_local_verification import MessageLocalVerification

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        account_id = UUID(d.pop("account_id"))

        username = d.pop("username")

        agent_id = UUID(d.pop("agent_id"))

        delegation_id = UUID(d.pop("delegation_id"))

        author_label = d.pop("author_label")

        body = d.pop("body")

        signer_did = d.pop("signer_did")

        verification_method = d.pop("verification_method")

        key_fingerprint = d.pop("key_fingerprint")

        local_verification = MessageLocalVerification.from_dict(d.pop("local_verification"))

        delegate_verification = MessageDelegateVerification.from_dict(d.pop("delegate_verification"))

        inserted_at = isoparse(d.pop("inserted_at"))

        hosted_verification_path = d.pop("hosted_verification_path", UNSET)

        message = cls(
            id=id,
            account_id=account_id,
            username=username,
            agent_id=agent_id,
            delegation_id=delegation_id,
            author_label=author_label,
            body=body,
            signer_did=signer_did,
            verification_method=verification_method,
            key_fingerprint=key_fingerprint,
            local_verification=local_verification,
            delegate_verification=delegate_verification,
            inserted_at=inserted_at,
            hosted_verification_path=hosted_verification_path,
        )

        message.additional_properties = d
        return message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
