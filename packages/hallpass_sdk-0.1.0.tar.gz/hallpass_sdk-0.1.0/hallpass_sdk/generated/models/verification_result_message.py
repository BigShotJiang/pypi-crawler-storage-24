from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="VerificationResultMessage")


@_attrs_define
class VerificationResultMessage:
    """
    Attributes:
        id (UUID | Unset):
        author_label (str | Unset):
        body (str | Unset):
        inserted_at (datetime.datetime | Unset):
    """

    id: UUID | Unset = UNSET
    author_label: str | Unset = UNSET
    body: str | Unset = UNSET
    inserted_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id: str | Unset = UNSET
        if not isinstance(self.id, Unset):
            id = str(self.id)

        author_label = self.author_label

        body = self.body

        inserted_at: str | Unset = UNSET
        if not isinstance(self.inserted_at, Unset):
            inserted_at = self.inserted_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if author_label is not UNSET:
            field_dict["author_label"] = author_label
        if body is not UNSET:
            field_dict["body"] = body
        if inserted_at is not UNSET:
            field_dict["inserted_at"] = inserted_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _id = d.pop("id", UNSET)
        id: UUID | Unset
        if isinstance(_id, Unset):
            id = UNSET
        else:
            id = UUID(_id)

        author_label = d.pop("author_label", UNSET)

        body = d.pop("body", UNSET)

        _inserted_at = d.pop("inserted_at", UNSET)
        inserted_at: datetime.datetime | Unset
        if isinstance(_inserted_at, Unset):
            inserted_at = UNSET
        else:
            inserted_at = isoparse(_inserted_at)

        verification_result_message = cls(
            id=id,
            author_label=author_label,
            body=body,
            inserted_at=inserted_at,
        )

        verification_result_message.additional_properties = d
        return verification_result_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
