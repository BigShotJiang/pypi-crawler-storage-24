from enum import Enum


class OauthAuthorizeProvider(str, Enum):
    GITHUB = "github"
    X = "x"

    def __str__(self) -> str:
        return str(self.value)
