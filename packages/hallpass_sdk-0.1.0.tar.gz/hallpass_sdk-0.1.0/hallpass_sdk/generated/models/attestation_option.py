from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.attestation_option_method import AttestationOptionMethod


T = TypeVar("T", bound="AttestationOption")


@_attrs_define
class AttestationOption:
    """
    Attributes:
        kind (str):
        label (str):
        value_label (str):
        value_placeholder (str):
        value_help (str):
        methods (list[AttestationOptionMethod]):
    """

    kind: str
    label: str
    value_label: str
    value_placeholder: str
    value_help: str
    methods: list[AttestationOptionMethod]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        kind = self.kind

        label = self.label

        value_label = self.value_label

        value_placeholder = self.value_placeholder

        value_help = self.value_help

        methods = []
        for methods_item_data in self.methods:
            methods_item = methods_item_data.to_dict()
            methods.append(methods_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "kind": kind,
                "label": label,
                "value_label": value_label,
                "value_placeholder": value_placeholder,
                "value_help": value_help,
                "methods": methods,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.attestation_option_method import AttestationOptionMethod

        d = dict(src_dict)
        kind = d.pop("kind")

        label = d.pop("label")

        value_label = d.pop("value_label")

        value_placeholder = d.pop("value_placeholder")

        value_help = d.pop("value_help")

        methods = []
        _methods = d.pop("methods")
        for methods_item_data in _methods:
            methods_item = AttestationOptionMethod.from_dict(methods_item_data)

            methods.append(methods_item)

        attestation_option = cls(
            kind=kind,
            label=label,
            value_label=value_label,
            value_placeholder=value_placeholder,
            value_help=value_help,
            methods=methods,
        )

        attestation_option.additional_properties = d
        return attestation_option

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
