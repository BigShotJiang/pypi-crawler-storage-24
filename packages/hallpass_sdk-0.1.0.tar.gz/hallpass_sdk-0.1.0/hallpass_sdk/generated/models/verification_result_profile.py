from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="VerificationResultProfile")


@_attrs_define
class VerificationResultProfile:
    """
    Attributes:
        username (str | Unset):
        hosted_profile_path (str | Unset):
    """

    username: str | Unset = UNSET
    hosted_profile_path: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        username = self.username

        hosted_profile_path = self.hosted_profile_path

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if username is not UNSET:
            field_dict["username"] = username
        if hosted_profile_path is not UNSET:
            field_dict["hosted_profile_path"] = hosted_profile_path

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        username = d.pop("username", UNSET)

        hosted_profile_path = d.pop("hosted_profile_path", UNSET)

        verification_result_profile = cls(
            username=username,
            hosted_profile_path=hosted_profile_path,
        )

        verification_result_profile.additional_properties = d
        return verification_result_profile

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
