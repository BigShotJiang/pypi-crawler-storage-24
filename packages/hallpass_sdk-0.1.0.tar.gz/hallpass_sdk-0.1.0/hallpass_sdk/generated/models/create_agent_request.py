from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_agent_request_public_jwk import CreateAgentRequestPublicJwk


T = TypeVar("T", bound="CreateAgentRequest")


@_attrs_define
class CreateAgentRequest:
    """
    Attributes:
        display_name (str):
        public_jwk (CreateAgentRequestPublicJwk):
        description (str | Unset):
    """

    display_name: str
    public_jwk: CreateAgentRequestPublicJwk
    description: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        display_name = self.display_name

        public_jwk = self.public_jwk.to_dict()

        description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "display_name": display_name,
                "public_jwk": public_jwk,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_agent_request_public_jwk import CreateAgentRequestPublicJwk

        d = dict(src_dict)
        display_name = d.pop("display_name")

        public_jwk = CreateAgentRequestPublicJwk.from_dict(d.pop("public_jwk"))

        description = d.pop("description", UNSET)

        create_agent_request = cls(
            display_name=display_name,
            public_jwk=public_jwk,
            description=description,
        )

        create_agent_request.additional_properties = d
        return create_agent_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
