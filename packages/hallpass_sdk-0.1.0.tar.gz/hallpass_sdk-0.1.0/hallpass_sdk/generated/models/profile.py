from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.attestation import Attestation
    from ..models.profile_agent import ProfileAgent


T = TypeVar("T", bound="Profile")


@_attrs_define
class Profile:
    """
    Attributes:
        username (str):
        display_name (str):
        attestations (list[Attestation]):
        agents (list[ProfileAgent]):
    """

    username: str
    display_name: str
    attestations: list[Attestation]
    agents: list[ProfileAgent]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        username = self.username

        display_name = self.display_name

        attestations = []
        for attestations_item_data in self.attestations:
            attestations_item = attestations_item_data.to_dict()
            attestations.append(attestations_item)

        agents = []
        for agents_item_data in self.agents:
            agents_item = agents_item_data.to_dict()
            agents.append(agents_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "username": username,
                "display_name": display_name,
                "attestations": attestations,
                "agents": agents,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.attestation import Attestation
        from ..models.profile_agent import ProfileAgent

        d = dict(src_dict)
        username = d.pop("username")

        display_name = d.pop("display_name")

        attestations = []
        _attestations = d.pop("attestations")
        for attestations_item_data in _attestations:
            attestations_item = Attestation.from_dict(attestations_item_data)

            attestations.append(attestations_item)

        agents = []
        _agents = d.pop("agents")
        for agents_item_data in _agents:
            agents_item = ProfileAgent.from_dict(agents_item_data)

            agents.append(agents_item)

        profile = cls(
            username=username,
            display_name=display_name,
            attestations=attestations,
            agents=agents,
        )

        profile.additional_properties = d
        return profile

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
