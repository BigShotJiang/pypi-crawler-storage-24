from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.account_user_delegation_key_mode import AccountUserDelegationKeyMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.account_user_delegation_public_jwk import AccountUserDelegationPublicJwk


T = TypeVar("T", bound="Account")


@_attrs_define
class Account:
    """
    Attributes:
        id (UUID):
        username (str):
        display_name (str):
        user_delegation_key_mode (AccountUserDelegationKeyMode):
        user_delegation_public_jwk (AccountUserDelegationPublicJwk | Unset):
    """

    id: UUID
    username: str
    display_name: str
    user_delegation_key_mode: AccountUserDelegationKeyMode
    user_delegation_public_jwk: AccountUserDelegationPublicJwk | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        username = self.username

        display_name = self.display_name

        user_delegation_key_mode = self.user_delegation_key_mode.value

        user_delegation_public_jwk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.user_delegation_public_jwk, Unset):
            user_delegation_public_jwk = self.user_delegation_public_jwk.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "username": username,
                "display_name": display_name,
                "user_delegation_key_mode": user_delegation_key_mode,
            }
        )
        if user_delegation_public_jwk is not UNSET:
            field_dict["user_delegation_public_jwk"] = user_delegation_public_jwk

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.account_user_delegation_public_jwk import AccountUserDelegationPublicJwk

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        username = d.pop("username")

        display_name = d.pop("display_name")

        user_delegation_key_mode = AccountUserDelegationKeyMode(d.pop("user_delegation_key_mode"))

        _user_delegation_public_jwk = d.pop("user_delegation_public_jwk", UNSET)
        user_delegation_public_jwk: AccountUserDelegationPublicJwk | Unset
        if isinstance(_user_delegation_public_jwk, Unset):
            user_delegation_public_jwk = UNSET
        else:
            user_delegation_public_jwk = AccountUserDelegationPublicJwk.from_dict(_user_delegation_public_jwk)

        account = cls(
            id=id,
            username=username,
            display_name=display_name,
            user_delegation_key_mode=user_delegation_key_mode,
            user_delegation_public_jwk=user_delegation_public_jwk,
        )

        account.additional_properties = d
        return account

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
