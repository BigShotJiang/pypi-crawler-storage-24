from enum import Enum


class AccountUserDelegationKeyMode(str, Enum):
    SERVICE_MANAGED = "service_managed"
    USER_MANAGED = "user_managed"

    def __str__(self) -> str:
        return str(self.value)
