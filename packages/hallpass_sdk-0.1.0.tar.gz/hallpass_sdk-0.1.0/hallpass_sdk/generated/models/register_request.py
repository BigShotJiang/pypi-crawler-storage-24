from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.register_request_user_delegation_key_mode import RegisterRequestUserDelegationKeyMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.register_request_user_delegation_public_jwk import RegisterRequestUserDelegationPublicJwk


T = TypeVar("T", bound="RegisterRequest")


@_attrs_define
class RegisterRequest:
    """
    Attributes:
        display_name (str):
        username (str):
        password (str):
        user_delegation_key_mode (RegisterRequestUserDelegationKeyMode | Unset):
        user_delegation_public_jwk (RegisterRequestUserDelegationPublicJwk | Unset):
    """

    display_name: str
    username: str
    password: str
    user_delegation_key_mode: RegisterRequestUserDelegationKeyMode | Unset = UNSET
    user_delegation_public_jwk: RegisterRequestUserDelegationPublicJwk | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        display_name = self.display_name

        username = self.username

        password = self.password

        user_delegation_key_mode: str | Unset = UNSET
        if not isinstance(self.user_delegation_key_mode, Unset):
            user_delegation_key_mode = self.user_delegation_key_mode.value

        user_delegation_public_jwk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.user_delegation_public_jwk, Unset):
            user_delegation_public_jwk = self.user_delegation_public_jwk.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "display_name": display_name,
                "username": username,
                "password": password,
            }
        )
        if user_delegation_key_mode is not UNSET:
            field_dict["user_delegation_key_mode"] = user_delegation_key_mode
        if user_delegation_public_jwk is not UNSET:
            field_dict["user_delegation_public_jwk"] = user_delegation_public_jwk

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.register_request_user_delegation_public_jwk import RegisterRequestUserDelegationPublicJwk

        d = dict(src_dict)
        display_name = d.pop("display_name")

        username = d.pop("username")

        password = d.pop("password")

        _user_delegation_key_mode = d.pop("user_delegation_key_mode", UNSET)
        user_delegation_key_mode: RegisterRequestUserDelegationKeyMode | Unset
        if isinstance(_user_delegation_key_mode, Unset):
            user_delegation_key_mode = UNSET
        else:
            user_delegation_key_mode = RegisterRequestUserDelegationKeyMode(_user_delegation_key_mode)

        _user_delegation_public_jwk = d.pop("user_delegation_public_jwk", UNSET)
        user_delegation_public_jwk: RegisterRequestUserDelegationPublicJwk | Unset
        if isinstance(_user_delegation_public_jwk, Unset):
            user_delegation_public_jwk = UNSET
        else:
            user_delegation_public_jwk = RegisterRequestUserDelegationPublicJwk.from_dict(_user_delegation_public_jwk)

        register_request = cls(
            display_name=display_name,
            username=username,
            password=password,
            user_delegation_key_mode=user_delegation_key_mode,
            user_delegation_public_jwk=user_delegation_public_jwk,
        )

        register_request.additional_properties = d
        return register_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
