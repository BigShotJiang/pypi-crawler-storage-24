from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.account import Account
    from ..models.profile import Profile


T = TypeVar("T", bound="AccountDashboardResponse200")


@_attrs_define
class AccountDashboardResponse200:
    """
    Attributes:
        account (Account):
        profile (Profile):
    """

    account: Account
    profile: Profile
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        account = self.account.to_dict()

        profile = self.profile.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "account": account,
                "profile": profile,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.account import Account
        from ..models.profile import Profile

        d = dict(src_dict)
        account = Account.from_dict(d.pop("account"))

        profile = Profile.from_dict(d.pop("profile"))

        account_dashboard_response_200 = cls(
            account=account,
            profile=profile,
        )

        account_dashboard_response_200.additional_properties = d
        return account_dashboard_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
