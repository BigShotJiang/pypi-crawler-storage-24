from enum import Enum


class VerificationResultOverallDecision(str, Enum):
    INVALID = "invalid"
    VERIFIED = "verified"

    def __str__(self) -> str:
        return str(self.value)
