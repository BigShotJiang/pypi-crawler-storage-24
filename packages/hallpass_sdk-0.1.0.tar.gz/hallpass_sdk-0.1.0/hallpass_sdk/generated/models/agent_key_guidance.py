from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.agent_key_guidance_accepted_public_jwk import AgentKeyGuidanceAcceptedPublicJwk


T = TypeVar("T", bound="AgentKeyGuidance")


@_attrs_define
class AgentKeyGuidance:
    """
    Attributes:
        summary (str):
        accepted_public_jwk (AgentKeyGuidanceAcceptedPublicJwk):
        requirements (list[str]):
        local_generation_steps (list[str]):
    """

    summary: str
    accepted_public_jwk: AgentKeyGuidanceAcceptedPublicJwk
    requirements: list[str]
    local_generation_steps: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        summary = self.summary

        accepted_public_jwk = self.accepted_public_jwk.to_dict()

        requirements = self.requirements

        local_generation_steps = self.local_generation_steps

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "summary": summary,
                "accepted_public_jwk": accepted_public_jwk,
                "requirements": requirements,
                "local_generation_steps": local_generation_steps,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_key_guidance_accepted_public_jwk import AgentKeyGuidanceAcceptedPublicJwk

        d = dict(src_dict)
        summary = d.pop("summary")

        accepted_public_jwk = AgentKeyGuidanceAcceptedPublicJwk.from_dict(d.pop("accepted_public_jwk"))

        requirements = cast(list[str], d.pop("requirements"))

        local_generation_steps = cast(list[str], d.pop("local_generation_steps"))

        agent_key_guidance = cls(
            summary=summary,
            accepted_public_jwk=accepted_public_jwk,
            requirements=requirements,
            local_generation_steps=local_generation_steps,
        )

        agent_key_guidance.additional_properties = d
        return agent_key_guidance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
