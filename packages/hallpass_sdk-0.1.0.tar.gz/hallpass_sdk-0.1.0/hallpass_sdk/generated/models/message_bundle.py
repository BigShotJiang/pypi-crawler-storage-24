from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.message_bundle_public_jwk import MessageBundlePublicJwk


T = TypeVar("T", bound="MessageBundle")


@_attrs_define
class MessageBundle:
    """
    Attributes:
        username (str):
        message_jwt (str):
        signer_did (str):
        verification_method (str):
        public_jwk (MessageBundlePublicJwk):
        author_label (str):
        key_fingerprint (str | Unset):
    """

    username: str
    message_jwt: str
    signer_did: str
    verification_method: str
    public_jwk: MessageBundlePublicJwk
    author_label: str
    key_fingerprint: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        username = self.username

        message_jwt = self.message_jwt

        signer_did = self.signer_did

        verification_method = self.verification_method

        public_jwk = self.public_jwk.to_dict()

        author_label = self.author_label

        key_fingerprint = self.key_fingerprint

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "username": username,
                "message_jwt": message_jwt,
                "signer_did": signer_did,
                "verification_method": verification_method,
                "public_jwk": public_jwk,
                "author_label": author_label,
            }
        )
        if key_fingerprint is not UNSET:
            field_dict["key_fingerprint"] = key_fingerprint

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message_bundle_public_jwk import MessageBundlePublicJwk

        d = dict(src_dict)
        username = d.pop("username")

        message_jwt = d.pop("message_jwt")

        signer_did = d.pop("signer_did")

        verification_method = d.pop("verification_method")

        public_jwk = MessageBundlePublicJwk.from_dict(d.pop("public_jwk"))

        author_label = d.pop("author_label")

        key_fingerprint = d.pop("key_fingerprint", UNSET)

        message_bundle = cls(
            username=username,
            message_jwt=message_jwt,
            signer_did=signer_did,
            verification_method=verification_method,
            public_jwk=public_jwk,
            author_label=author_label,
            key_fingerprint=key_fingerprint,
        )

        message_bundle.additional_properties = d
        return message_bundle

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
