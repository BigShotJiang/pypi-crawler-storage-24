from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ProfileAgent")


@_attrs_define
class ProfileAgent:
    """
    Attributes:
        id (UUID):
        display_name (str):
        did (str):
        verification_method (str):
        key_fingerprint (str):
        registration_status (str):
        challenge_status (str):
        authorization_status (str):
    """

    id: UUID
    display_name: str
    did: str
    verification_method: str
    key_fingerprint: str
    registration_status: str
    challenge_status: str
    authorization_status: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        display_name = self.display_name

        did = self.did

        verification_method = self.verification_method

        key_fingerprint = self.key_fingerprint

        registration_status = self.registration_status

        challenge_status = self.challenge_status

        authorization_status = self.authorization_status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "display_name": display_name,
                "did": did,
                "verification_method": verification_method,
                "key_fingerprint": key_fingerprint,
                "registration_status": registration_status,
                "challenge_status": challenge_status,
                "authorization_status": authorization_status,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))

        display_name = d.pop("display_name")

        did = d.pop("did")

        verification_method = d.pop("verification_method")

        key_fingerprint = d.pop("key_fingerprint")

        registration_status = d.pop("registration_status")

        challenge_status = d.pop("challenge_status")

        authorization_status = d.pop("authorization_status")

        profile_agent = cls(
            id=id,
            display_name=display_name,
            did=did,
            verification_method=verification_method,
            key_fingerprint=key_fingerprint,
            registration_status=registration_status,
            challenge_status=challenge_status,
            authorization_status=authorization_status,
        )

        profile_agent.additional_properties = d
        return profile_agent

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
