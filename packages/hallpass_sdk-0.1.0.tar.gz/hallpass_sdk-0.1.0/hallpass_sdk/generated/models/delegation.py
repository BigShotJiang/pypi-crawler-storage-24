from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.delegation_user_delegation_key_mode import DelegationUserDelegationKeyMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.delegation_payload import DelegationPayload


T = TypeVar("T", bound="Delegation")


@_attrs_define
class Delegation:
    """
    Attributes:
        id (UUID):
        account_id (UUID):
        agent_id (UUID):
        user_delegation_key_mode (DelegationUserDelegationKeyMode):
        status (str):
        valid_from (datetime.datetime):
        valid_until (datetime.datetime):
        payload (DelegationPayload):
        signed_jws (str):
        submission_origin (None | str | Unset):
        revoked_at (datetime.datetime | None | Unset):
    """

    id: UUID
    account_id: UUID
    agent_id: UUID
    user_delegation_key_mode: DelegationUserDelegationKeyMode
    status: str
    valid_from: datetime.datetime
    valid_until: datetime.datetime
    payload: DelegationPayload
    signed_jws: str
    submission_origin: None | str | Unset = UNSET
    revoked_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        account_id = str(self.account_id)

        agent_id = str(self.agent_id)

        user_delegation_key_mode = self.user_delegation_key_mode.value

        status = self.status

        valid_from = self.valid_from.isoformat()

        valid_until = self.valid_until.isoformat()

        payload = self.payload.to_dict()

        signed_jws = self.signed_jws

        submission_origin: None | str | Unset
        if isinstance(self.submission_origin, Unset):
            submission_origin = UNSET
        else:
            submission_origin = self.submission_origin

        revoked_at: None | str | Unset
        if isinstance(self.revoked_at, Unset):
            revoked_at = UNSET
        elif isinstance(self.revoked_at, datetime.datetime):
            revoked_at = self.revoked_at.isoformat()
        else:
            revoked_at = self.revoked_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "account_id": account_id,
                "agent_id": agent_id,
                "user_delegation_key_mode": user_delegation_key_mode,
                "status": status,
                "valid_from": valid_from,
                "valid_until": valid_until,
                "payload": payload,
                "signed_jws": signed_jws,
            }
        )
        if submission_origin is not UNSET:
            field_dict["submission_origin"] = submission_origin
        if revoked_at is not UNSET:
            field_dict["revoked_at"] = revoked_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.delegation_payload import DelegationPayload

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        account_id = UUID(d.pop("account_id"))

        agent_id = UUID(d.pop("agent_id"))

        user_delegation_key_mode = DelegationUserDelegationKeyMode(d.pop("user_delegation_key_mode"))

        status = d.pop("status")

        valid_from = isoparse(d.pop("valid_from"))

        valid_until = isoparse(d.pop("valid_until"))

        payload = DelegationPayload.from_dict(d.pop("payload"))

        signed_jws = d.pop("signed_jws")

        def _parse_submission_origin(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        submission_origin = _parse_submission_origin(d.pop("submission_origin", UNSET))

        def _parse_revoked_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                revoked_at_type_0 = isoparse(data)

                return revoked_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        revoked_at = _parse_revoked_at(d.pop("revoked_at", UNSET))

        delegation = cls(
            id=id,
            account_id=account_id,
            agent_id=agent_id,
            user_delegation_key_mode=user_delegation_key_mode,
            status=status,
            valid_from=valid_from,
            valid_until=valid_until,
            payload=payload,
            signed_jws=signed_jws,
            submission_origin=submission_origin,
            revoked_at=revoked_at,
        )

        delegation.additional_properties = d
        return delegation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
