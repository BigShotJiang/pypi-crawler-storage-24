from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.verification_result_overall_decision import VerificationResultOverallDecision
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.verification_result_message import VerificationResultMessage
    from ..models.verification_result_profile import VerificationResultProfile
    from ..models.verification_state import VerificationState


T = TypeVar("T", bound="VerificationResult")


@_attrs_define
class VerificationResult:
    """
    Attributes:
        user_profile_verification (VerificationState):
        attestation_verification (VerificationState):
        delegation_verification (VerificationState):
        child_key_verification (VerificationState):
        message_signature_verification (VerificationState):
        overall_decision (VerificationResultOverallDecision):
        id (str | Unset):
        profile (VerificationResultProfile | Unset):
        message (VerificationResultMessage | Unset):
    """

    user_profile_verification: VerificationState
    attestation_verification: VerificationState
    delegation_verification: VerificationState
    child_key_verification: VerificationState
    message_signature_verification: VerificationState
    overall_decision: VerificationResultOverallDecision
    id: str | Unset = UNSET
    profile: VerificationResultProfile | Unset = UNSET
    message: VerificationResultMessage | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_profile_verification = self.user_profile_verification.to_dict()

        attestation_verification = self.attestation_verification.to_dict()

        delegation_verification = self.delegation_verification.to_dict()

        child_key_verification = self.child_key_verification.to_dict()

        message_signature_verification = self.message_signature_verification.to_dict()

        overall_decision = self.overall_decision.value

        id = self.id

        profile: dict[str, Any] | Unset = UNSET
        if not isinstance(self.profile, Unset):
            profile = self.profile.to_dict()

        message: dict[str, Any] | Unset = UNSET
        if not isinstance(self.message, Unset):
            message = self.message.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user_profile_verification": user_profile_verification,
                "attestation_verification": attestation_verification,
                "delegation_verification": delegation_verification,
                "child_key_verification": child_key_verification,
                "message_signature_verification": message_signature_verification,
                "overall_decision": overall_decision,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if profile is not UNSET:
            field_dict["profile"] = profile
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.verification_result_message import VerificationResultMessage
        from ..models.verification_result_profile import VerificationResultProfile
        from ..models.verification_state import VerificationState

        d = dict(src_dict)
        user_profile_verification = VerificationState.from_dict(d.pop("user_profile_verification"))

        attestation_verification = VerificationState.from_dict(d.pop("attestation_verification"))

        delegation_verification = VerificationState.from_dict(d.pop("delegation_verification"))

        child_key_verification = VerificationState.from_dict(d.pop("child_key_verification"))

        message_signature_verification = VerificationState.from_dict(d.pop("message_signature_verification"))

        overall_decision = VerificationResultOverallDecision(d.pop("overall_decision"))

        id = d.pop("id", UNSET)

        _profile = d.pop("profile", UNSET)
        profile: VerificationResultProfile | Unset
        if isinstance(_profile, Unset):
            profile = UNSET
        else:
            profile = VerificationResultProfile.from_dict(_profile)

        _message = d.pop("message", UNSET)
        message: VerificationResultMessage | Unset
        if isinstance(_message, Unset):
            message = UNSET
        else:
            message = VerificationResultMessage.from_dict(_message)

        verification_result = cls(
            user_profile_verification=user_profile_verification,
            attestation_verification=attestation_verification,
            delegation_verification=delegation_verification,
            child_key_verification=child_key_verification,
            message_signature_verification=message_signature_verification,
            overall_decision=overall_decision,
            id=id,
            profile=profile,
            message=message,
        )

        verification_result.additional_properties = d
        return verification_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
