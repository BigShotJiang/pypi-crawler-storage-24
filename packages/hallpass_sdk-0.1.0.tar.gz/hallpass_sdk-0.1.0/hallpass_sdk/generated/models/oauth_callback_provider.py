from enum import Enum


class OauthCallbackProvider(str, Enum):
    GITHUB = "github"
    X = "x"

    def __str__(self) -> str:
        return str(self.value)
