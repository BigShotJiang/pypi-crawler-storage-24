from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.revoke_delegation_response_200 import RevokeDelegationResponse200
from ...types import Response


def _get_kwargs(
    delegation_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/delegations/{delegation_id}/revoke".format(
            delegation_id=quote(str(delegation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RevokeDelegationResponse200 | None:
    if response.status_code == 200:
        response_200 = RevokeDelegationResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RevokeDelegationResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    delegation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RevokeDelegationResponse200]:
    """Revoke a delegation

     Immediately revokes an active delegation. Messages signed after revocation will fail verification.

    Args:
        delegation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RevokeDelegationResponse200]
    """

    kwargs = _get_kwargs(
        delegation_id=delegation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    delegation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> RevokeDelegationResponse200 | None:
    """Revoke a delegation

     Immediately revokes an active delegation. Messages signed after revocation will fail verification.

    Args:
        delegation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RevokeDelegationResponse200
    """

    return sync_detailed(
        delegation_id=delegation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    delegation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RevokeDelegationResponse200]:
    """Revoke a delegation

     Immediately revokes an active delegation. Messages signed after revocation will fail verification.

    Args:
        delegation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RevokeDelegationResponse200]
    """

    kwargs = _get_kwargs(
        delegation_id=delegation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    delegation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> RevokeDelegationResponse200 | None:
    """Revoke a delegation

     Immediately revokes an active delegation. Messages signed after revocation will fail verification.

    Args:
        delegation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RevokeDelegationResponse200
    """

    return (
        await asyncio_detailed(
            delegation_id=delegation_id,
            client=client,
        )
    ).parsed
