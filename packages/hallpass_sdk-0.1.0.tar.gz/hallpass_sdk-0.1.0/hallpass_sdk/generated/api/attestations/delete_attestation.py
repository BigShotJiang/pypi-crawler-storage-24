from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_attestation_response_200 import DeleteAttestationResponse200
from ...types import Response


def _get_kwargs(
    attestation_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/auth/attestations/{attestation_id}".format(
            attestation_id=quote(str(attestation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeleteAttestationResponse200 | None:
    if response.status_code == 200:
        response_200 = DeleteAttestationResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeleteAttestationResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteAttestationResponse200]:
    """Delete an attestation

     Removes an attestation from the account.

    Args:
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteAttestationResponse200]
    """

    kwargs = _get_kwargs(
        attestation_id=attestation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteAttestationResponse200 | None:
    """Delete an attestation

     Removes an attestation from the account.

    Args:
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteAttestationResponse200
    """

    return sync_detailed(
        attestation_id=attestation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteAttestationResponse200]:
    """Delete an attestation

     Removes an attestation from the account.

    Args:
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteAttestationResponse200]
    """

    kwargs = _get_kwargs(
        attestation_id=attestation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    attestation_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteAttestationResponse200 | None:
    """Delete an attestation

     Removes an attestation from the account.

    Args:
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteAttestationResponse200
    """

    return (
        await asyncio_detailed(
            attestation_id=attestation_id,
            client=client,
        )
    ).parsed
