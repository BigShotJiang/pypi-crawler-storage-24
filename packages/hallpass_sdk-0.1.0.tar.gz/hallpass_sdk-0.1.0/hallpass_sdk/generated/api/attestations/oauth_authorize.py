from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.oauth_authorize_provider import OauthAuthorizeProvider
from ...models.oauth_authorize_response_200 import OauthAuthorizeResponse200
from ...types import UNSET, Response


def _get_kwargs(
    provider: OauthAuthorizeProvider,
    *,
    attestation_id: UUID,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_attestation_id = str(attestation_id)
    params["attestation_id"] = json_attestation_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/auth/attestations/oauth/{provider}/authorize".format(
            provider=quote(str(provider), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> OauthAuthorizeResponse200 | None:
    if response.status_code == 200:
        response_200 = OauthAuthorizeResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[OauthAuthorizeResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    provider: OauthAuthorizeProvider,
    *,
    client: AuthenticatedClient | Client,
    attestation_id: UUID,
) -> Response[OauthAuthorizeResponse200]:
    """Start OAuth attestation flow

     Returns the OAuth redirect URL for the specified provider (x, github).

    Args:
        provider (OauthAuthorizeProvider):
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OauthAuthorizeResponse200]
    """

    kwargs = _get_kwargs(
        provider=provider,
        attestation_id=attestation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    provider: OauthAuthorizeProvider,
    *,
    client: AuthenticatedClient | Client,
    attestation_id: UUID,
) -> OauthAuthorizeResponse200 | None:
    """Start OAuth attestation flow

     Returns the OAuth redirect URL for the specified provider (x, github).

    Args:
        provider (OauthAuthorizeProvider):
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OauthAuthorizeResponse200
    """

    return sync_detailed(
        provider=provider,
        client=client,
        attestation_id=attestation_id,
    ).parsed


async def asyncio_detailed(
    provider: OauthAuthorizeProvider,
    *,
    client: AuthenticatedClient | Client,
    attestation_id: UUID,
) -> Response[OauthAuthorizeResponse200]:
    """Start OAuth attestation flow

     Returns the OAuth redirect URL for the specified provider (x, github).

    Args:
        provider (OauthAuthorizeProvider):
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[OauthAuthorizeResponse200]
    """

    kwargs = _get_kwargs(
        provider=provider,
        attestation_id=attestation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    provider: OauthAuthorizeProvider,
    *,
    client: AuthenticatedClient | Client,
    attestation_id: UUID,
) -> OauthAuthorizeResponse200 | None:
    """Start OAuth attestation flow

     Returns the OAuth redirect URL for the specified provider (x, github).

    Args:
        provider (OauthAuthorizeProvider):
        attestation_id (UUID):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        OauthAuthorizeResponse200
    """

    return (
        await asyncio_detailed(
            provider=provider,
            client=client,
            attestation_id=attestation_id,
        )
    ).parsed
