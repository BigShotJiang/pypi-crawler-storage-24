---
title: راهنمای استقرار
description: راهنمای استقرار کامل با تمام گزینه‌های پیکربندی.
order: 3
section: guides
---

## استقرار اساسی

```
meridian deploy 1.2.3.4
```

جادوگر شما را از طریق پیکربندی هدایت می‌کند. یا هر چیز را از قبل مشخص کنید:

```
meridian deploy 1.2.3.4 --sni www.microsoft.com --name alice --yes
```

## تمام پرچم‌ها

| پرچم | پیش‌فرض | توضیح |
|------|---------|-------------|
| `--sni HOST` | www.microsoft.com | سایتی که Reality شخصیت‌سازی می‌کند |
| `--domain DOMAIN` | (هیچ) | فعال کردن حالت دامنه با fallback CDN |
| `--email EMAIL` | (هیچ) | ایمیل برای گواهی‌های TLS (اختیاری) |
| `--xhttp / --no-xhttp` | فعال | XHTTP transport (از طریق پورت 443 via Caddy) |
| `--name NAME` | default | نام برای کلاینت اول |
| `--user USER` | root | کاربر SSH (non-root به‌طور خودکار sudo دریافت می‌کند) |
| `--yes` | | پرسش‌های تأیید را رد کنید |

## انتخاب هدف SNI

هدف SNI (Server Name Indication) دامنه‌ای است که Reality شخصیت‌سازی می‌کند. مقدار پیش‌فرض (`www.microsoft.com`) برای اکثر موارد خوب عمل می‌کند.

برای پنهان‌کاری بهینه، شبکه سرور خود را برای اهداف same-ASN اسکن کنید:

```
meridian scan 1.2.3.4
```

**اهداف خوب** (CDN جهانی):
- `www.microsoft.com` — Azure CDN، جهانی
- `www.twitch.tv` — Fastly CDN، جهانی
- `dl.google.com` — Google CDN، جهانی
- `github.com` — Fastly CDN، جهانی

**از اینها خودداری کنید** `apple.com` و `icloud.com` — Apple محدوده‌های ASN خود را کنترل می‌کند، که عدم تطابق IP/ASN را بلافاصله قابل تشخیص می‌کند.

## بررسی قبل از پرواز

مطمئن نیستید اگر سرور شما سازگار است؟

```
meridian preflight 1.2.3.4
```

دسترسی‌پذیری هدف SNI، تطابق ASN، دسترسی پورت، DNS، سازگاری OS و فضای دیسک را آزمایش می‌کند — بدون نصب هیچ چیز.

## دوباره اجرای deploy

اجرای دوباره `meridian deploy` در هر زمان ایمن است. provisioner کاملاً بی‌تغییر است:
- اعتبارات از حافظه‌پنهان بارگذاری می‌شود، دوباره تولید نمی‌شود
- مراحل وضعیت موجود را بررسی می‌کنند قبل از عمل
- هیچ کار تکراری نیست

## استقرار non-root

```
meridian deploy 1.2.3.4 --user ubuntu
```

کاربران non-root `sudo` را به‌طور خودکار دریافت می‌کنند. کاربر باید دسترسی sudo بدون رمز عبور داشته باشد.
