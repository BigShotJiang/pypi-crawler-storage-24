from __future__ import annotations

from collections import defaultdict
from datetime import date

from context_use.batch.grouper import WindowConfig
from context_use.facets.types import render_facet_types_section
from context_use.llm.base import PromptItem
from context_use.memories.prompt.base import (
    BasePromptBuilder,
    GroupContext,
    MemorySchema,
)
from context_use.models.thread import Thread
from context_use.prompt_categories import WHAT_TO_CAPTURE

_FACETS_SECTION = render_facet_types_section()

MEDIA_MEMORIES_PROMPT = (
    """\
You are given social-media posts from **{{FROM_DATE}}** to \
**{{TO_DATE}}**, grouped by day. Each post includes a timestamp and a \
text preview, and may have an attached image or video (labelled [Image N]).

## Your task

Extract the user's **memories** from this period. A memory is a vivid, \
first-person account of something the user did, experienced, or felt — \
written as if the user is journaling about their life.

**Study every image carefully.** The images are your richest source of \
detail. Read all visible text (signs, screens, menus, name badges, \
whiteboards). Note brands, logos, UI on screens, food on plates, people \
in the frame, and anything that reveals where the user was or what they \
were doing.

Then reason across **all** posts in the window. Posts from different \
days may be related — a location visible in one image may explain a \
caption from another day, or repeated appearances of the same people or \
places may signal a multi-day event. Connect the dots.

"""
    + WHAT_TO_CAPTURE
    + """

### Granularity

Let the data guide you:
- A specific moment (a meal, a selfie) → single-day memory.
- A recurring theme or multi-day event (a work sprint, a trip) → memory \
spanning the relevant dates.
- The same post can feed multiple memories at different granularities.

Generate between {{MIN_MEMORIES}} and {{MAX_MEMORIES}} memories.

### Detail level

Each memory should be **information-dense**. Pack in every observable \
detail that says something about the user's life:
- Specific food items and ingredients, not just "a sandwich".
- Venue names, street signs, neighbourhood, city — not just "an office".
- What is on their screen: language, framework, project name, file names.
- Who is around: number of people, what they are doing, any names/tags.
- Clothing, accessories, hairstyle — these reveal personal style over \
time.
- Time-of-day context when it adds meaning (morning routine vs late \
night).
- The user's apparent emotional state — a celebratory dinner, a tired \
late-night work session, an excited travel arrival.

### What to avoid

- Do not fabricate details that are not visible or stated.
- Do not write filler ("had a nice day", "as seen in the photo").
- Do not narrate the medium ("in my Instagram story") — describe the \
experience, not the post.
- Do not ignore people in images — who the user spends time with is \
central to understanding their life.

{{CONTEXT}}\
{{POSTS}}

## Output format
Return a JSON object with a ``memories`` array. Each memory has:
- ``content``: the memory text (1-2 sentences, detail-rich, first-person).
- ``from_date``: start date (YYYY-MM-DD).
- ``to_date``: end date (YYYY-MM-DD, same as from_date for single-day).
- ``facets``: an array of semantic facets extracted from the memory. Each facet has:
  - ``facet_type``: one of the types defined below.
  - ``facet_value``: the specific extracted value.
"""
    + _FACETS_SECTION
)


class MediaMemoryPromptBuilder(BasePromptBuilder):
    """Build a ``PromptItem`` for a single time-window group from media threads."""

    def __init__(
        self,
        context: GroupContext,
        config: WindowConfig | None = None,
    ) -> None:
        super().__init__(context)
        self.config = config or WindowConfig()

    def build(self) -> PromptItem:
        threads_with_assets = [
            t for t in self.context.new_threads if t.asset_uri is not None
        ]

        sorted_threads = sorted(threads_with_assets, key=lambda t: t.asat)
        from_date = sorted_threads[0].asat.date()
        to_date = sorted_threads[-1].asat.date()
        posts_block, asset_uris = self._format_posts(threads_with_assets)
        context_block = self._format_context(self.context)

        prompt = (
            MEDIA_MEMORIES_PROMPT.replace("{{FROM_DATE}}", from_date.isoformat())
            .replace("{{TO_DATE}}", to_date.isoformat())
            .replace("{{CONTEXT}}", context_block)
            .replace("{{POSTS}}", posts_block)
            .replace(
                "{{MIN_MEMORIES}}",
                str(self.config.effective_min_memories),
            )
            .replace(
                "{{MAX_MEMORIES}}",
                str(self.config.effective_max_memories),
            )
        )

        return PromptItem(
            item_id=self.context.group_id,
            prompt=prompt,
            response_schema=MemorySchema.json_schema(),
            asset_uris=asset_uris,
        )

    @staticmethod
    def _format_posts(
        threads: list[Thread],
    ) -> tuple[str, list[str]]:
        """Format threads with timestamps, grouped by day when needed."""
        by_day: dict[date, list[Thread]] = defaultdict(list)
        for t in threads:
            by_day[t.asat.date()].append(t)

        multi_day = len(by_day) > 1
        sections: list[str] = []
        asset_uris: list[str] = []
        img_idx = 0

        for day, day_threads in sorted(by_day.items()):
            lines: list[str] = []
            if multi_day:
                lines.append(f"### {day.isoformat()}")
            for t in sorted(day_threads, key=lambda t: t.asat):
                ts = t.asat.strftime("%H:%M")
                if t.asset_uri:
                    img_idx += 1
                    lines.append(f"- [{ts}] [Image {img_idx}] {t.preview}")
                    asset_uris.append(t.asset_uri)
                else:
                    lines.append(f"- [{ts}] {t.preview}")
            sections.append("\n".join(lines))

        return "\n\n".join(sections), asset_uris
