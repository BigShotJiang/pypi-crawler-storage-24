"""ZulipChat MCP Server package."""

__version__ = "0.6.2"

__all__: list[str] = []
