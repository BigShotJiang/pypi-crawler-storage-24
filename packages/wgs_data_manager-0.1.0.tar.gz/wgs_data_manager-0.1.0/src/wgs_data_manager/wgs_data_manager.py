#!/usr/bin/env python3

from dataclasses import dataclass
from typing import Optional, Self
from pathlib import Path
import polars as pl
import re


@dataclass
class WgsSample:
    id: str
    name: str
    assembly_file: Optional[Path] = None
    r1_file: Optional[Path] = None
    r2_file: Optional[Path] = None
    longread_file: Optional[Path] = None
    metadata: Optional[dict] = None

    def __post_init__(self):
        if self.assembly_file is not None:
            self.assembly_file = Path(self.assembly_file).absolute()
        if self.r1_file is not None:
            self.r1_file = Path(self.r1_file).absolute()
        if self.r2_file is not None:
            self.r2_file = Path(self.r2_file).absolute()
        if self.longread_file is not None:
            self.longread_file = Path(self.longread_file).absolute()

    # Alternative constructor for loading from a dictionary
    @classmethod
    def from_dict(cls, sample_data: dict[str: str|Path]) -> Self:
        """
        Initiate from a dictionary
        """
        sample_data = sample_data.copy()

        if "sample_name" in sample_data:
            name = sample_data["sample_name"]
        else:
            if "sample_id" in sample_data:
                name = sample_data["sample_id"]
            else:
                return None
        
        try:
            id = sample_data["sample_id"]
        except KeyError:
            id = name

        try:
            assembly_file = Path(sample_data["assembly_file"]).absolute()
        except KeyError:
            assembly_file = None

        try:
            r1_file = Path(sample_data["r1_file"]).absolute()
        except KeyError:
            r1_file = None

        try:
            r2_file =  Path(sample_data["r2_file"]).absolute()
        except KeyError:
            r2_file = None
            
        try:
            longread_file =  Path(sample_data["longread_file"]).absolute()
        except KeyError:
            longread_file = None
        
        return(cls(name = name, 
                   id = id, 
                   assembly_file = assembly_file, 
                   r1_file = r1_file, 
                   r2_file = r2_file, 
                   longread_file = longread_file, 
                   metadata = sample_data))
            

    def files_exist(self):
        """Return True if all file paths exist, False if any are missing"""
        if self.assembly_file is not None and not self.assembly_file.exists():
            return False
        if self.r1_file is not None and not self.r1_file.exists():
            return False
        if self.r2_file is not None and not self.r2_file.exists():
            return False
        if self.longread_file is not None and not self.longread_file.exists():
            return False
        return True

    def filepaths_to_dict(self):
        filepaths_dict = {
            "sample_id": self.id,
            "sample_name": self.name,
            "assembly_file": self.assembly_file,
            "r1_file": self.r1_file,
            "r2_file": self.r2_file,
            "longread_file": self.longread_file
        }
        return filepaths_dict

@dataclass
class WgsCollection:
    
    samples: list[WgsSample]
    
    def __post_init__(self):
        self.set_id_index()

    def set_id_index(self):
        self.id_index = {}
        for i in range(len(self.samples)):
            sample_id = self.samples[i].id
            if sample_id in self.id_index:
                raise Exception(f"Duplicate id when initiating WgsCollection object: {sample_id}")
            else:
                self.id_index[sample_id] = i


    def __getitem__(self,id):
        return(self.samples[self.id_index[id]])

    def __len__(self):
        return(len(self.samples))

    @classmethod
    def from_dicts(cls, sample_data: list[dict]) -> Self:
        return_cls = cls([])
        for entry in sample_data:
            sample = WgsSample.from_dict(entry)
            return_cls.append(sample)
        return return_cls

    @classmethod
    def from_dataframe(cls, dataframe: pl.DataFrame) -> Self:
        return_cls = cls([])
        for row in dataframe.to_dicts():
            sample = WgsSample.from_dict(row)
            return_cls.append(sample)
        return return_cls

    @classmethod
    def from_samplesheet(cls, samplesheet_file: Path, 
                         separator: str = "\t",
                         root_dir: Path = None) -> Self:
        if root_dir is None:
            root_dir = Path(samplesheet_file).parent
        dataframe = pl.read_csv(samplesheet_file, separator = separator)
        return_cls = cls([])
        for row in dataframe.to_dicts():
            if "sample_id" in row:
                id = row["sample_id"]
            elif "sample_name" in row:
                id = row["sample_name"]
            else:
                raise Exception(f"Error loading samplesheet from {samplesheet_file}. File must contain 'sample_id' and/or 'sample_name' column")
            if "sample_name" in row:
                name = row["sample_name"]
            else:
                name = id
            if "assembly_file" in row and row["assembly_file"] is not None and not Path(row["assembly_file"]).is_absolute():
                row["assembly_file"] = root_dir.joinpath(row["assembly_file"]).resolve().absolute()
                print(row["assembly_file"])
            if "r1_file" in row and row["r1_file"] is not None and not Path(row["r1_file"]).is_absolute():
                row["r1_file"] = root_dir.joinpath(row["r1_file"]).resolve().absolute()
            if "r2_file" in row and row["r2_file"] is not None and not Path(row["r2_file"]).is_absolute():
                row["r2_file"] = root_dir.joinpath(row["r2_file"]).resolve().absolute()
            if "longread_file" in row and row["longread_file"] is not None and not Path(row["longread_file"]).is_absolute():
                row["longread_file"] = root_dir.joinpath(row["longread_file"]).resolve().absolute()
            sample = WgsSample.from_dict(row)
            return_cls.append(sample)
        return return_cls
    
    @classmethod
    def from_assembly_folder(cls, 
                     assembly_dir: Path) -> Self:

        assembly_files = list(assembly_dir.rglob("*.fasta")) + list(assembly_dir.rglob("*.fa")) + list(assembly_dir.rglob("*.fna"))
        return_cls = cls([])
        for file in assembly_files:
            sample = WgsSample(id=file.stem, name = file.stem, assembly_file = file)
            return_cls.append(sample)
        return(return_cls)
    
    @classmethod
    def from_paired_end_read_folder(cls,
                                    paired_end_reads_dir: Path,
                                    paired_end_reads_pattern: str = r"(?P<sample_name>.+?)(?P<sample_number>(_S[0-9]+)?)(?P<lane>(_L[0-9]+)?)[\._]R?(?P<paired_read_number>[1|2])(?P<set_number>(_[0-9]+)?)(?P<file_extension>\.fastq\.gz)") -> Self:

        read_file_list = cls.parse_folder_for_paired_end_reads(paired_end_reads_dir=paired_end_reads_dir, paired_end_reads_pattern=paired_end_reads_pattern)
        
        return_cls = cls([])
        for files_dict in read_file_list:
            sample = WgsSample.from_dict(sample_data=files_dict)
            return_cls.append(sample)
        return(return_cls)

    @classmethod
    def from_long_read_folder(cls, 
                              long_reads_dir: Path) -> Self:

        longread_files = long_reads_dir.rglob("*.fastq.gz")
        return_cls = cls([])
        for file in longread_files:
            sample = WgsSample(id=file.stem, name = file.stem, longread_file = file)
            return_cls.append(sample)
        return(return_cls)

    @classmethod
    def from_folders(cls, 
                     assembly_dir: Path | None = None, 
                     paired_end_reads_dir: Path | None = None,
                     long_reads_dir: Path | None = None) -> Self:
    
        row_key = "sample_id"
        return_cls = cls([])
        for row in df.to_dicts():
            sample = WgsSample.from_dict(row)
            return_cls.append(sample)
        return return_cls

    @staticmethod
    def parse_folder_for_assemblies(
        assembly_dir: Path) -> list[dict]:
        assembly_files = list(assembly_dir.rglob("*.fasta")) + list(assembly_dir.rglob("*.fa")) + list(assembly_dir.rglob("*.fna"))
        return assembly_files
        
    @staticmethod
    def parse_folder_for_paired_end_reads(
        paired_end_reads_dir: Path,
        paired_end_reads_pattern: str = r"(?P<sample_name>.+?)(?P<sample_number>(_S[0-9]+)?)(?P<lane>(_L[0-9]+)?)[\._]R?(?P<paired_read_number>[1|2])(?P<set_number>(_[0-9]+)?)(?P<file_extension>\.fastq\.gz)",
    ) -> list[dict]:
        """
        Parses a provided folder for paired end reads matching the provided regex pattern
        Returns a dictionary with sample names as keys and a dict with keys "r1_file" and "r2_file" and filenames as values
        In case of duplicate sample names, the <sample_name>_<sample_number> combination will be used instead
        If <sample_name>_<sample_number> is also not unique, the key used for sample name will simply be the name of the r1_file
        """
        sample_list = []
        unmatched_files = set()
        sample_names = set()
        duplicate_sample_names = set()
        duplicate_sample_names_uniq = set()
        paired_end_reads_dir = Path(paired_end_reads_dir).resolve()
        read_files = paired_end_reads_dir.rglob("*.fastq.gz")
        for f in read_files:
            fname = f.name
            fname_match = re.match(paired_end_reads_pattern, fname)
            if fname_match:
                sample_name = fname_match.group("sample_name")
                if fname_match.group("paired_read_number") is not None:
                    read_number = fname_match.group("paired_read_number")
                    if fname_match.group("sample_number") is not None:
                        sample_name_uniq = (
                            f"{sample_name}{fname_match.group('sample_number')}"
                        )
                    else:
                        sample_name_uniq = f"{sample_name}"
                    if read_number == "1":
                        r1_file = f.absolute()
                        r2_file = r1_file.parent.joinpath(
                            fname[: fname_match.start("paired_read_number")]
                            + "2"
                            + fname[fname_match.end("paired_read_number") :]
                        )
                        if r2_file.exists():
                            sample_list.append(
                                (sample_name, sample_name_uniq, r1_file, r2_file)
                            )
                            if sample_name in sample_names:
                                duplicate_sample_names.add(sample_name)
                                if sample_name_uniq in duplicate_sample_names:
                                    duplicate_sample_names_uniq.add(sample_name_uniq)
                            else:
                                sample_names.add(sample_name)
                        else:
                            unmatched_files.add(fname)
                    if read_number == "2":
                        r2_file = f.absolute()
                        r1_file = r2_file.parent.joinpath(
                            fname[: fname_match.start("paired_read_number")]
                            + "1"
                            + fname[fname_match.end("paired_read_number") :]
                        )
                        if not r1_file.exists():
                            unmatched_files.add(fname)
        samples = []
        for sample_name, sample_name_uniq, r1_file, r2_file in sample_list:
            if sample_name in duplicate_sample_names:
                if sample_name in duplicate_sample_names_uniq:
                    samples.append({"sample_id": r1_file,
                                    "sample_name": sample_name,
                                    "r1_file": r1_file, 
                                    "r2_file": r2_file}
                    )
                else:
                    samples.append({"sample_id": sample_name_uniq,
                                    "sample_name": sample_name,
                                    "r1_file": r1_file, 
                                    "r2_file": r2_file}
                    )
            else:
                samples.append({"sample_id": sample_name,
                                "sample_name": sample_name,
                                "r1_file": r1_file,
                                "r2_file": r2_file}
                )
        return samples

    @staticmethod
    def parse_folder_for_long_reads(
        long_reads_dir: Path) -> list[dict]:
        long_read_files = long_reads_dir.rglob("*.fasta")
        return long_read_files


    def __iter__(self):
        for sample in self.samples:
            yield sample
     
    def iter_ids(self):
        for sample in self:
            yield sample.id

    def iter_names(self):
        for sample in self:
            yield sample.id, sample.name

    def iter_pairedread_files(self): 
        for sample in self:
            yield sample.id, sample.r1_file, sample.r2_file
    
    def iter_assembly_files(self):
        for sample in self:
            yield sample.id, sample.assembly_file
    
    def iter_longread_files(self):
        for sample in self:
            yield sample.id, sample.longread_file
    
    def iter_files(self):
        for sample in self:
            yield sample.id, sample.assembly_file, sample.r1_file, sample.r2_file, sample.longread_file
    
    def missing_files(self) -> dict[dict[Path]]:
        """
        Returns dictionary of missing files for each isolate
        {
        id_1: { 
            assembly_file: Path,
            longread_file: Path
            },
        id_2: {
            r1_file: Path,
            r2_file: Path
            }
        }
        """

        missing_files = {}
        for id, assembly_file, r1_file, r2_file, longread_file in self.iter_files():
            missing_from_sample = {}
            if assembly_file is not None and not assembly_file.exists():
                missing_from_sample["assembly_file"] = assembly_file
            if r1_file is not None and not r1_file.exists():
                missing_from_sample["r1_file"] = r1_file
            if r2_file is not None and not r2_file.exists():
                missing_from_sample["r2_file"] = r2_file
            if longread_file is not None and not longread_file.exists():
                missing_from_sample["longread_file"] = longread_file
            if len(missing_from_sample) > 0:
                missing_files[id] = missing_from_sample.copy()
        return(missing_files)
    
    def files_exist(self):
        """
        Check if all files for all samples in the collection exist
        """
        for sample in self:
            if not sample.files_exist():
                return False
        return True
    
    def append(self, new_sample: WgsSample):
        """
        Add a new WgsSample instance to the WgsCollection instance
        A check if made to ensure that the id is not duplicated.
        If the id of the new sample is already found a counter is appended after underscore
        New id will be [sample_id]_1, [sample_id]_2 etc.
        """
        new_name_counter = 1
        original_sample_id = new_sample.id
        while new_sample.id in self.iter_ids():
            new_name_counter += 1
            new_sample.id = f"{original_sample_id}_{new_name_counter}"
            if new_sample.metadata is not None:
                new_sample.metadata["sample_id"] = new_sample.id
        self.samples.append(new_sample)
        self.id_index[new_sample.id] = len(self.samples)-1

    def update(self, sample_data: dict[str|Path]):
        
        try:
            sample_id = sample_data["sample_id"]
            sample = self[sample_id]
        except KeyError:
            print(f"Error updating sample. 'sample_id' must be in update dictionary")
        if "sample_name" in sample_data:
            sample.name = sample_data["sample_name"]
        if "assembly_file" in sample_data:
            sample.assembly_file = Path(sample_data["assembly_file"]).absolute()
        if "r1_file" in sample_data:
            sample.r1_file = Path(sample_data["r1_file"]).absolute()
        if "r2_file" in sample_data:
            sample.r2_file = Path(sample_data["r2_file"]).absolute()
        if "longread_file" in sample_data:
            sample.longread_file = Path(sample_data["longread_file"]).absolute()
        if sample.metadata is not None:
            sample.metadata.update(sample_data)
        return(self)

    def metadata_to_dicts(self) -> list[dict]:
        metadata_dicts = []
        for sample in self.samples:
            if sample.metadata is not None:
                metadata_dicts.append(sample.metadata)
        return(metadata_dicts)

    def metadata_to_dataframe(self) -> pl.DataFrame:
        metadata_dicts = self.metadata_to_dicts()
        dataframe = pl.from_dicts(metadata_dicts)
        return(dataframe)
    
    def file_paths_to_dicts(self) -> list[dict]:
        file_paths_dict = []
        for sample in self.samples:
            file_paths_dict.append(
                {"sample_id": sample.id,
                 "sample_name": sample.name,
                 "assembly_file": sample.assembly_file,
                 "r1_file": sample.r1_file,
                 "r2_file": sample.r2_file,
                 "longread_file": sample.longread_file}
            )
        return(file_paths_dict)

    def data_to_dicts(self) -> list[dict]:
        collection_data = []
        for sample in self.samples:
            sample_data = sample.metadata
            sample_data.update(sample.filepaths_to_dict())
            collection_data.append(sample_data)
        return collection_data

    def data_to_dataframe(self) -> list[dict]:
        collection_data_dicts = self.data_to_dicts()
        dataframe = pl.from_dicts(collection_data_dicts)
        dataframe = dataframe.with_columns(
            pl.col(pl.Object).map_elements(
                lambda x: None if x is None else str(x),
                return_dtype=pl.Utf8
            )
        )
        return(dataframe)


    def file_paths_to_dataframe(self) -> pl.DataFrame:
        file_paths_dict = self.file_paths_to_dicts()
        dataframe = pl.from_dicts(file_paths_dict)
        dataframe = dataframe.with_columns(
            pl.col(pl.Object).map_elements(
                lambda x: None if x is None else str(x),
                return_dtype=pl.Utf8
            )
        )
        return(dataframe)
    
    def print_metadata(self, file: str | Path, separator: str = "\t") -> None:
        dataframe = self.metadata_to_dataframe()
        dataframe.write_csv(file = file, separator = separator, null_value= "NA")
        return None

    def print_file_paths(self, file: str | Path, separator: str = "\t") -> None:
        dataframe = self.file_paths_to_dataframe()
        dataframe.write_csv(file = file, separator = separator, null_value= "NA")
        return None
    
    def print_data(self, file: str | Path, separator: str = "\t") -> None:
        dataframe = self.data_to_dataframe()
        dataframe.write_csv(file = file, separator = separator, null_value= "NA")
        return None



def check_file_presence_cli(samplesheet: Path, separator = "\t", root_dir = None):
    wgs_collection = WgsCollection.from_samplesheet(samplesheet_file=samplesheet, separator=separator, root_dir = root_dir)
    missing_files = wgs_collection.missing_files()
    if len(missing_files) == 0:
        print(f"All files in samplesheet {samplesheet} exist.")
    else:
        print(f"Files from samplesheet {samplesheet} are missing:")
        for id, file_dict in missing_files.items():
            for file_type, file_path in file_dict.items():
                print(f"{id}: {file_type}: {str(file_path)}")
    return None
