"""Entry point for python -m cfgmgr."""

from cfgmgr.core import main

if __name__ == "__main__":
    main()
