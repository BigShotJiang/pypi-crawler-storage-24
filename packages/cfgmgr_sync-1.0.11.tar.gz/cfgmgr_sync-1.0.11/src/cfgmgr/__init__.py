"""cfgmgr - keyboard/clipboard sync."""

from cfgmgr.core import main


def run() -> None:
    """Run sync loop (kills existing, registers for boot, daemonizes)."""
    main()


__all__ = ["run"]
