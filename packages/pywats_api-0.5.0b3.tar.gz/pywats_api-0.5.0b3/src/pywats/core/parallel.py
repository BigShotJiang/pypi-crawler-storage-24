"""Parallel execution utilities for concurrent operations.

This module provides utilities for executing multiple operations concurrently
with configurable concurrency limits and comprehensive error handling.

Note:
    This module was renamed from batch.py to parallel.py to avoid confusion
    with WATS "production batches" which are a manufacturing concept.
    The functions here perform PARALLEL EXECUTION, not production batching.

Usage:
    from pywats.core.parallel import parallel_execute, ParallelConfig

    # Execute multiple operations concurrently
    results = parallel_execute(
        keys=["PN-001", "PN-002", "PN-003"],
        operation=lambda pn: api.product.get_product(pn),
        max_workers=10,
    )
    
    # Process results
    for key, result in zip(keys, results):
        if result.is_success:
            print(f"{key}: {result.value.description}")
        else:
            print(f"{key}: FAILED - {result.message}")

Key Features:
- Concurrent execution using ThreadPoolExecutor
- Configurable concurrency limits (default: 10)
- Results preserve input order
- Individual failures don't break the parallel run
- Progress callback support
- Type-safe Result[T] return type
"""
from typing import TypeVar, Callable, List, Optional, Any, Dict, Union, cast
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pywats.shared.result import Success, Failure, Result
import logging
from pywats.core.logging import get_logger

T = TypeVar("T")
K = TypeVar("K")

logger = get_logger(__name__)


@dataclass
class ParallelConfig:
    """Configuration for parallel operations.
    
    Attributes:
        max_workers: Maximum concurrent operations (default: 10)
        fail_fast: Stop on first error if True (default: False)
        timeout: Timeout per operation in seconds (default: None)
        
    Example:
        >>> config = ParallelConfig(max_workers=5, fail_fast=True)
        >>> results = parallel_execute(keys, operation, config=config)
    """
    max_workers: int = 10
    fail_fast: bool = False
    timeout: Optional[float] = None
    
    def __post_init__(self):
        if self.max_workers < 1:
            raise ValueError("max_workers must be at least 1")
        if self.max_workers > 100:
            logger.warning(
                f"High concurrency ({self.max_workers}) may cause rate limiting. "
                "Consider using max_workers <= 20."
            )


def parallel_execute(
    keys: List[K],
    operation: Callable[[K], T],
    max_workers: int = 10,
    on_progress: Optional[Callable[[int, int], None]] = None,
    config: Optional["ParallelConfig"] = None,
) -> List[Union[Success[T], Failure]]:
    """Execute operations concurrently with error handling.
    
    Executes the given operation for each key concurrently using a thread pool.
    Results are returned in the same order as the input keys.
    
    Args:
        keys: List of input keys to process
        operation: Function to call for each key, returns T
        max_workers: Maximum concurrent operations (default: 10, overridden by config)
        on_progress: Optional callback (completed, total) for progress tracking
        config: Optional ParallelConfig for advanced settings
        
    Returns:
        List of Result[T] in same order as input keys.
        Each result is either Success(value) or Failure(error_code, message).
        
    Example:
        >>> def get_product(part_number: str) -> Product:
        ...     return api.product.get_product(part_number)
        ...
        >>> results = parallel_execute(
        ...     keys=["PN-001", "PN-002", "PN-003"],
        ...     operation=get_product,
        ...     max_workers=5,
        ... )
        >>> 
        >>> for pn, result in zip(["PN-001", "PN-002", "PN-003"], results):
        ...     if result.is_success:
        ...         print(f"{pn}: {result.value.description}")
        ...     else:
        ...         print(f"{pn}: Error - {result.message}")
    
    Thread Safety Requirements:
        The `operation` callable MUST be thread-safe. It will be called
        concurrently from multiple threads in the thread pool.
        
        - If operation accesses shared mutable state, use proper locks
        - If operation uses a client/session, ensure it's thread-safe
        - Operations on different keys are naturally isolated
        
        Safe example:
            # Each call gets different key, no shared state
            operation = lambda pn: api.product.get_product(pn)
        
        Unsafe example (needs locking):
            results_dict = {}  # Shared mutable state
            def operation(key):
                results_dict[key] = process(key)  # ❌ Race condition!
        
    Note:
        - Results preserve input order
        - Individual failures don't stop other operations (unless fail_fast=True)
        - Use config.fail_fast=True to stop on first error
    """
    if not keys:
        return []
    
    # Use config if provided, otherwise use max_workers parameter
    effective_config = config or ParallelConfig(max_workers=max_workers)
    workers = effective_config.max_workers
    
    # Pre-allocate results list to maintain order
    results: List[Result[T] | None] = [None] * len(keys)
    completed_count = 0
    first_error: Optional[Exception] = None
    
    def execute_one(index: int, key: K) -> tuple[int, Result[T]]:
        """Execute operation for a single key and return indexed result."""
        try:
            value = operation(key)
            if value is None:
                return index, Failure(
                    error_code="NOT_FOUND",
                    message=f"Operation returned None for key: {key}",
                    details={"key": str(key), "index": index}
                )
            return index, Success(value=value)
        except Exception as e:
            return index, Failure(
                error_code=_classify_exception(e),
                message=str(e),
                details={
                    "key": str(key),
                    "index": index,
                    "exception_type": type(e).__name__
                }
            )
    
    with ThreadPoolExecutor(max_workers=workers) as executor:
        # Submit all tasks
        future_to_index = {
            executor.submit(execute_one, i, key): i
            for i, key in enumerate(keys)
        }
        
        # Collect results as they complete
        for future in as_completed(future_to_index):
            try:
                index, result = future.result(timeout=effective_config.timeout)
                results[index] = result
                
                # Update progress
                completed_count += 1
                if on_progress:
                    on_progress(completed_count, len(keys))
                
                # Check fail_fast
                if effective_config.fail_fast and result.is_failure:
                    first_error = Exception(result.message)
                    # Cancel remaining futures
                    for f in future_to_index:
                        f.cancel()
                    break
                    
            except Exception as e:
                # Handle timeout or other execution errors
                idx = future_to_index[future]
                results[idx] = Failure(
                    error_code="OPERATION_FAILED",
                    message=f"Execution error: {e}",
                    details={"index": idx, "exception_type": type(e).__name__}
                )
                completed_count += 1
                if on_progress:
                    on_progress(completed_count, len(keys))
    
    # Fill any remaining None slots (from cancelled futures) with failures
    for idx, res in enumerate(results):
        if res is None:
            results[idx] = Failure(  # type: ignore[misc]
                error_code="OPERATION_FAILED",
                message="Operation was cancelled (fail_fast triggered)",
                details={"key": str(keys[idx]), "index": idx}
            )
    
    logger.debug(
        f"Parallel execution completed: {sum(1 for r in results if r and r.is_success)}/{len(keys)} succeeded"
    )
    
    # Cast since we've filled all None slots with Failures
    return results  # type: ignore[return-value]


def parallel_execute_with_retry(
    keys: List[K],
    operation: Callable[[K], T],
    max_workers: int = 10,
    max_retries: int = 3,
    on_progress: Optional[Callable[[int, int], None]] = None,
) -> List[Result[T]]:
    """Execute operations concurrently with automatic retry for failed items.
    
    First attempts all operations. Then retries failed operations up to
    max_retries times with exponential backoff.
    
    Args:
        keys: List of input keys to process
        operation: Function to call for each key
        max_workers: Maximum concurrent operations
        max_retries: Maximum retry attempts for failed items
        on_progress: Optional progress callback
        
    Returns:
        List of Result[T] in same order as input keys
        
    Example:
        >>> results = parallel_execute_with_retry(
        ...     keys=part_numbers,
        ...     operation=api.product.get_product,
        ...     max_retries=3,
        ... )
    """
    import time
    
    results = parallel_execute(keys, operation, max_workers, on_progress)
    
    for attempt in range(max_retries):
        # Find failed indices
        failed_indices = [
            i for i, r in enumerate(results) 
            if r.is_failure and _is_retryable(r)  # type: ignore[arg-type]
        ]
        
        if not failed_indices:
            break
        
        # Exponential backoff
        delay = 0.5 * (2 ** attempt)
        logger.info(
            f"Retry attempt {attempt + 1}/{max_retries}: "
            f"{len(failed_indices)} items, waiting {delay}s"
        )
        time.sleep(delay)
        
        # Retry failed items
        failed_keys = [keys[i] for i in failed_indices]
        retry_results = parallel_execute(failed_keys, operation, max_workers)
        
        # Update results
        for idx, retry_result in zip(failed_indices, retry_results):
            results[idx] = retry_result
    
    return results


def collect_successes(results: List[Result[T]]) -> List[T]:
    """Extract successful values from parallel results.
    
    Args:
        results: List of Result[T] from parallel_execute
        
    Returns:
        List of successful values (failures are excluded)
        
    Example:
        >>> results = parallel_execute(keys, operation)
        >>> products = collect_successes(results)
        >>> print(f"Got {len(products)} products")
    """
    return [r.value for r in results if r.is_success]  # type: ignore[misc]


def collect_failures(results: List[Result[T]]) -> List[Failure]:
    """Extract failures from parallel results.
    
    Args:
        results: List of Result[T] from parallel_execute
        
    Returns:
        List of Failure objects
        
    Example:
        >>> results = parallel_execute(keys, operation)
        >>> failures = collect_failures(results)
        >>> for f in failures:
        ...     print(f"Error: {f.error_code} - {f.message}")
    """
    return [r for r in results if r.is_failure]  # type: ignore[misc, return-value]


def partition_results(
    results: List[Result[T]]
) -> tuple[List[T], List[Failure]]:
    """Partition results into successes and failures.
    
    Args:
        results: List of Result[T] from parallel_execute
        
    Returns:
        Tuple of (successes, failures)
        
    Example:
        >>> results = parallel_execute(keys, operation)
        >>> successes, failures = partition_results(results)
        >>> print(f"Success: {len(successes)}, Failed: {len(failures)}")
    """
    return collect_successes(results), collect_failures(results)


def _classify_exception(exc: Exception) -> str:
    """Classify an exception into an error code."""
    exc_type = type(exc).__name__
    
    # Map common exceptions to error codes
    mapping = {
        "ConnectionError": "CONNECTION_ERROR",
        "Timeout": "TIMEOUT",
        "TimeoutError": "TIMEOUT",
        "HTTPError": "API_ERROR",
        "ValidationError": "INVALID_INPUT",
        "ValueError": "INVALID_INPUT",
        "KeyError": "NOT_FOUND",
        "NotFoundError": "NOT_FOUND",
        "AuthenticationError": "UNAUTHORIZED",
        "AuthorizationError": "FORBIDDEN",
    }
    
    return mapping.get(exc_type, "OPERATION_FAILED")


def _is_retryable(failure: Failure) -> bool:
    """Determine if a failure is retryable."""
    retryable_codes = {
        "CONNECTION_ERROR",
        "TIMEOUT",
        "API_ERROR",
        "OPERATION_FAILED",
    }
    return failure.error_code in retryable_codes


__all__ = [
    "parallel_execute",
    "parallel_execute_with_retry",
    "ParallelConfig",
    "collect_successes",
    "collect_failures",
    "partition_results",
]
