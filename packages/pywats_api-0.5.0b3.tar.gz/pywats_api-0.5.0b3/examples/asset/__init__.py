"""Asset domain examples package."""
