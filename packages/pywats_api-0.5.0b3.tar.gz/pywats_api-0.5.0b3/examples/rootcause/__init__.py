"""RootCause domain examples package."""
