from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Set, Tuple, Optional, Union

import pytest

from tests.utils import fun1, fun2
from tomlserializer import \
    TOMLSerializer  # Assuming the original code is in toml_serializer.py


@dataclass
class SimpleModel:
    name: str
    value: int
    enabled: bool

@dataclass
class ComplexModel:
    string_field: str
    int_field: int
    float_field: float
    bool_field: bool
    list_field: List[int]
    list_with_bool: list
    set_field: Set[str]
    set_with_bool: set
    dict_field: Dict[str, int]
    dict_with_bool: dict
    tuple_field: Tuple[int, str, bool]
    path_field: Path

# Fixtures
@pytest.fixture
def temp_file(tmp_path):
    return tmp_path / "test.toml"

@pytest.fixture
def simple_model():
    return SimpleModel(name="test", value=42, enabled=True)

@pytest.fixture
def complex_model():
    return ComplexModel(
        string_field="test",
        int_field=42,
        float_field=3.14,
        bool_field=True,
        list_field=[1, 2, 3],
        list_with_bool=[True, False],
        set_field={"a", "b", "c"},
        set_with_bool={True, False},
        dict_field={"key": 1},
        dict_with_bool={"key": True},
        tuple_field=(1, "test", True),
        path_field=Path("/tmp/test")
    )

# Test Cases
def test_simple_model_save_load(simple_model, temp_file):
    # Test saving
    TOMLSerializer.save(simple_model, temp_file)
    assert temp_file.exists()

    # Test loading
    loaded_data = TOMLSerializer.load_typed_dict(temp_file)
    assert loaded_data["name"] == simple_model.name
    assert loaded_data["value"] == simple_model.value
    assert loaded_data["enabled"] == simple_model.enabled

def test_complex_model_save_load(complex_model, temp_file):
    # Test saving
    TOMLSerializer.save(complex_model, temp_file)
    assert temp_file.exists()

    # Test loading
    loaded_data = TOMLSerializer.load_typed_dict(temp_file)

    # Verify all fields
    assert loaded_data["string_field"] == complex_model.string_field
    assert loaded_data["int_field"] == complex_model.int_field
    assert loaded_data["float_field"] == complex_model.float_field
    assert loaded_data["bool_field"] == complex_model.bool_field
    assert loaded_data["list_field"] == complex_model.list_field
    assert loaded_data["list_with_bool"] == complex_model.list_with_bool
    assert set(loaded_data["set_field"]) == complex_model.set_field
    assert loaded_data["set_with_bool"] == complex_model.set_with_bool
    assert loaded_data["dict_field"] == complex_model.dict_field
    assert loaded_data["dict_with_bool"] == complex_model.dict_with_bool
    assert tuple(loaded_data["tuple_field"]) == complex_model.tuple_field
    assert Path(loaded_data["path_field"]) == complex_model.path_field

def test_function(temp_file):
    @dataclass
    class Test:
        a : Callable
    test = Test(a=fun1)

    TOMLSerializer.save(test, temp_file)
    loaded_data = TOMLSerializer.load_typed_dict(temp_file)
    assert loaded_data["a"](42) == fun1(42)

def test_function_list(temp_file):
    @dataclass
    class Test:
        a : list
    test = Test(a=[fun1, fun2])

    TOMLSerializer.save(test, temp_file)
    loaded_data = TOMLSerializer.load_typed_dict(temp_file)
    assert loaded_data["a"][0](42) == fun1(42)
    assert loaded_data["a"][1](42) == fun2(42)

    test = Test(a=(fun1, fun2))
    TOMLSerializer.save(test, temp_file)
    loaded_data = TOMLSerializer.load_typed_dict(temp_file)
    assert loaded_data["a"][0](42) == fun1(42)
    assert loaded_data["a"][1](42) == fun2(42)

    test = Test(a={fun1, fun2})
    TOMLSerializer.save(test, temp_file)
    loaded_data = TOMLSerializer.load_typed_dict(temp_file)
    assert loaded_data["a"] == {fun1, fun2}


def test_nested_dictionary():

    @dataclass
    class NestedModel:
        nested: Dict[str, Dict[str, int]]

    model = NestedModel(nested={"outer": {"inner": 42}})
    temp_file = Path("test_nested.toml")

    try:
        TOMLSerializer.save(model, temp_file)
        loaded_data = TOMLSerializer.load_typed_dict(temp_file)
        assert loaded_data["nested"]["outer"]["inner"] == 42
    finally:
        if temp_file.exists():
            temp_file.unlink()


def test_empty_model():

    @dataclass
    class EmptyModel:

        pass

    model = EmptyModel()
    temp_file = Path("test_empty.toml")

    try:
        TOMLSerializer.save(model, temp_file)
        loaded_data = TOMLSerializer.load_typed_dict(temp_file)
        assert loaded_data == {}
    finally:
        if temp_file.exists():
            temp_file.unlink()

# # Error cases
def test_invalid_file_path():
    with pytest.raises(Exception):  # Specific exception type depends on implementation
        TOMLSerializer.load_typed_dict("/nonexistent/path/file.toml")

def test_optional_fields():
    @dataclass
    class OptionalModel:
        required_field: str
        optional_field: Optional[int] = None
        optional_list: Optional[List[str]] = None

    model = OptionalModel(required_field="test")
    temp_file = Path("test_optional.toml")

    try:
        TOMLSerializer.save(model, temp_file)
        loaded_data = TOMLSerializer.load_typed_dict(temp_file)
        print(f"loaded_data: {loaded_data}")
        assert loaded_data["required_field"] == "test"
        assert loaded_data["optional_field"] == None
        assert loaded_data["optional_list"] == None
    finally:
        if temp_file.exists():
            temp_file.unlink()

def test_union_types():
    @dataclass
    class UnionModel:
        field: Union[str, int]
        list_field: List[Union[str, int]]

    model1 = UnionModel(field="test", list_field=["a", 1, "b", 2])
    model2 = UnionModel(field=42, list_field=[1, "a", 2, "b"])
    temp_file = Path("test_union.toml")

    try:
        # Test string variant
        TOMLSerializer.save(model1, temp_file)
        loaded_data = TOMLSerializer.load_typed_dict(temp_file)
        assert loaded_data["field"] == "test"
        assert loaded_data["list_field"] == ["a", 1, "b", 2]

        # Test int variant
        TOMLSerializer.save(model2, temp_file)
        loaded_data = TOMLSerializer.load_typed_dict(temp_file)
        assert loaded_data["field"] == 42
        assert loaded_data["list_field"] == [1, "a", 2, "b"]
    finally:
        if temp_file.exists():
            temp_file.unlink()


def test_empty_collections():
    @dataclass
    class EmptyCollectionsModel:
        empty_list: List[int]
        empty_dict: Dict[str, int]
        empty_set: set
        empty_tuple: tuple

    model = EmptyCollectionsModel(
        empty_list=[],
        empty_dict={},
        empty_set=set(),
        empty_tuple=()
    )
    temp_file = Path("test_empty_collections.toml")

    try:
        TOMLSerializer.save(model, temp_file)
        loaded_data = TOMLSerializer.load_typed_dict(temp_file)
        assert loaded_data["empty_list"] == []
        assert loaded_data["empty_dict"] == {}
        assert loaded_data["empty_set"] == set()
        assert loaded_data["empty_tuple"] == ()
    finally:
        if temp_file.exists():
            temp_file.unlink()

def test_inheritance():
    @dataclass
    class BaseModel:
        base_field: str

    @dataclass
    class DerivedModel(BaseModel):
        derived_field: int

    model = DerivedModel(base_field="base", derived_field=42)
    temp_file = Path("test_inheritance.toml")

    try:
        TOMLSerializer.save(model, temp_file)
        loaded_data = TOMLSerializer.load_typed_dict(temp_file)
        assert loaded_data["base_field"] == "base"
        assert loaded_data["derived_field"] == 42
    finally:
        if temp_file.exists():
            temp_file.unlink()