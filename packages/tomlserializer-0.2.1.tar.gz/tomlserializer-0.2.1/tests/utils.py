
def fun1(x):
    return x

def fun2(x):
    return x**2