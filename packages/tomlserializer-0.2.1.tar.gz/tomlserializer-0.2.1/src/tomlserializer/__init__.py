import importlib.metadata

from tomlserializer.main import TOMLSerializer

__all__ = ["TOMLSerializer"]

try:
    __version__ = importlib.metadata.version("tomlserializer")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"
