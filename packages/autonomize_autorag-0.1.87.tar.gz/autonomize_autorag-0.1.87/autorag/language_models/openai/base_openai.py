"""OpenAI Language Model module implementation"""

# pylint: disable=line-too-long, duplicate-code, too-many-locals

import os
from typing import Any, Dict, List, Optional, Union, override

try:
    from openai import AsyncOpenAI, OpenAI
    import openai
except ImportError as err:  # pragma: no cover
    raise ImportError(  # pragma: no cover
        "Unable to locate openai package. "
        'Please install it with `pip install "autonomize-autorag[openai]"`.'
    ) from err

from autorag.language_models.base import LanguageModel
from autorag.types.language_models import (
    ContentPolicyError,
    Generation,
    Logprobs,
    ParsedGeneration,
    ToolCall,
    Usage,
)
from autorag.utilities.logger import get_logger
from autorag.types.language_models.generation import ResponseFormatT



logger = get_logger(__name__)


class OpenAILanguageModel(LanguageModel):
    """
    Implementation of the LanguageModel abstract base class using OpenAI's API.

    This class utilizes OpenAI's API to generate text data. It supports different models
    provided by OpenAI for text generation tasks like conversation and RAG systems.

    Example:
    .. code-block:: python

        from autorag.language_models import OpenAILanguageModel

        model_name = "gpt-4o"
        llm = OpenAILanguageModel()

        llm.generate(
            messages=[{"role": "user", "content": "What is RAG?"}],
            model=model_name
        )
    """

    def __init__(self, api_key: Optional[str] = None):
        """
        Initializes the OpenAI language model client.

        Args:
            api_key (Optional[str]): OpenAI API key. If not provided, the key is read from the environment variable 'OPENAI_API_KEY'.

        Raises:
            ValueError: If the API key is not provided and cannot be found in the environment.
        """
        super().__init__()

        self.api_key = api_key or os.getenv("OPENAI_API_KEY")

        if not self.api_key:
            raise ValueError(
                "The api_key client option must be set either by passing api_key to the client or by setting the OPENAI_API_KEY environment variable."
            )

        self._client = OpenAI(
            api_key=self.api_key,
        )
        self._aclient = AsyncOpenAI(
            api_key=self.api_key,
        )

    def _severity_from_policy_details(self, details: Any) -> str:
        """
        Normalizes severity values from content filter payloads.
        """
        if isinstance(details, dict):
            severity = details.get("severity")
            if severity:
                return str(severity)
            if details.get("filtered") is True:
                return "filtered"
            if details.get("detected") is True:
                return "detected"
        return "unknown"

    def _policy_errors_from_result(
        self, results: Any, source: str
    ) -> list[ContentPolicyError]:
        """
        Converts content-filter result objects into normalized violations.
        """
        errors: list[ContentPolicyError] = []

        if isinstance(results, list):
            for item in results:
                errors.extend(self._policy_errors_from_result(item, source))
            return errors

        if not isinstance(results, dict):
            return errors

        for policy_type, details in results.items():
            if not isinstance(details, dict):
                continue

            severity = self._severity_from_policy_details(details)
            is_violation = (
                details.get("filtered") is True
                or details.get("detected") is True
                or details.get("blocked") is True
                or details.get("violation") is True
            )

            if not is_violation and severity.lower() in {"safe", "none"}:
                continue
            if not is_violation and severity == "unknown":
                continue

            errors.append(
                ContentPolicyError(
                    content_policy_type=str(policy_type),
                    severity=severity,
                    source=source,  # type: ignore[arg-type]
                )
            )

        return errors

    def _append_policy_errors(
        self, errors: list[ContentPolicyError], results: Any, source: str
    ) -> None:
        errors.extend(self._policy_errors_from_result(results, source))

    def _dedupe_policy_errors(
        self, errors: list[ContentPolicyError]
    ) -> list[ContentPolicyError]:
        """
        Deduplicates content-policy errors while preserving order.
        """
        deduped: list[ContentPolicyError] = []
        seen: set[tuple[str, str, str]] = set()

        for error in errors:
            key = (
                error.content_policy_type,
                error.severity,
                error.source,
            )
            if key in seen:
                continue
            seen.add(key)
            deduped.append(error)

        return deduped

    def _extract_content_policy_errors(self, response: Any) -> list[ContentPolicyError]:
        """
        Extracts prompt and completion policy violations from a Responses payload.
        """
        errors: list[ContentPolicyError] = []

        for attr_name in ("prompt_filter_results", "prompt_filter_result"):
            self._append_policy_errors(
                errors,
                getattr(response, attr_name, None),
                "Prompt",
            )

        for item in getattr(response, "input", []) or []:
            for attr_name in ("content_filter_results", "content_filter_result"):
                self._append_policy_errors(
                    errors,
                    getattr(item, attr_name, None),
                    "Prompt",
                )

        incomplete_details = getattr(response, "incomplete_details", None)
        for attr_name in ("content_filter_results", "content_filter_result"):
            self._append_policy_errors(
                errors,
                getattr(incomplete_details, attr_name, None),
                "Completion",
            )
            self._append_policy_errors(
                errors,
                getattr(response, attr_name, None),
                "Completion",
            )

        for item in getattr(response, "output", []) or []:
            for attr_name in ("content_filter_results", "content_filter_result"):
                self._append_policy_errors(
                    errors,
                    getattr(item, attr_name, None),
                    "Completion",
                )

        if (
            not errors
            and getattr(incomplete_details, "reason", None) == "content_filter"
        ):
            errors.append(
                ContentPolicyError(
                    content_policy_type="content_filter",
                    severity="unknown",
                    source="Completion",
                )
            )

        return self._dedupe_policy_errors(errors)

    def _extract_exception_content_policy_errors(
        self, error: Exception
    ) -> list[ContentPolicyError]:
        """
        Extracts prompt and completion policy violations from an API error body.
        """
        errors: list[ContentPolicyError] = []
        body = getattr(error, "body", None)
        if not isinstance(body, dict):
            return errors

        error_body = body.get("error", body)
        inner_error = error_body.get("innererror", {})

        for key in ("prompt_filter_results", "prompt_filter_result"):
            self._append_policy_errors(errors, body.get(key), "Prompt")
            self._append_policy_errors(errors, error_body.get(key), "Prompt")
            self._append_policy_errors(errors, inner_error.get(key), "Prompt")

        for key in ("content_filter_results", "content_filter_result"):
            self._append_policy_errors(errors, body.get(key), "Completion")
            self._append_policy_errors(errors, error_body.get(key), "Completion")
            self._append_policy_errors(errors, inner_error.get(key), "Prompt")

        error_code = str(error_body.get("code", "")).lower()
        inner_code = str(inner_error.get("code", "")).lower()
        if not errors and (
            "policy" in error_code
            or "content_filter" in error_code
            or "policy" in inner_code
            or "content_filter" in inner_code
        ):
            errors.append(
                ContentPolicyError(
                    content_policy_type="content_filter",
                    severity="unknown",
                    source="Prompt",
                )
            )

        return self._dedupe_policy_errors(errors)

    def _extract_response_message(self, response: Any) -> Any:
        """
        Returns the first assistant message item from a Responses API payload.
        """
        for item in getattr(response, "output", []) or []:
            if getattr(item, "type", None) == "message":
                return item
        return None

    def _extract_tool_call(self, response: Any) -> Optional[ToolCall]:
        """
        Returns the first function tool call from a Responses API payload.
        """
        for item in getattr(response, "output", []) or []:
            if getattr(item, "type", None) == "function_call":
                return ToolCall(
                    name=getattr(item, "name", None),
                    arguments=getattr(item, "arguments", None),
                )
        return None

    def _extract_logprobs(self, response: Any) -> Optional[List[Logprobs]]:
        """
        Returns token logprobs if they were requested in the response.
        """
        message = self._extract_response_message(response)
        if not message:
            return None

        for content in getattr(message, "content", []) or []:
            if getattr(content, "type", None) != "output_text":
                continue

            raw_logprobs = getattr(content, "logprobs", None)
            if not raw_logprobs:
                continue

            return [Logprobs(**item.model_dump()) for item in raw_logprobs]

        return None

    def _extract_role(self, response: Any) -> Optional[str]:
        """
        Returns the role of the first response message or a sensible default.
        """
        message = self._extract_response_message(response)
        if message is not None:
            return getattr(message, "role", "assistant")
        if self._extract_tool_call(response) is not None:
            return "assistant"
        return None

    def _extract_content(self, response: Any) -> Optional[str]:
        """
        Returns the aggregated output text from a Responses API payload.
        """
        output_text = getattr(response, "output_text", None)
        if output_text:
            return output_text

        message = self._extract_response_message(response)
        if not message:
            return None

        parts: list[str] = []
        for content in getattr(message, "content", []) or []:
            if getattr(content, "type", None) == "output_text":
                text = getattr(content, "text", None)
                if text:
                    parts.append(text)

        return "".join(parts) if parts else None

    def _extract_finish_reason(self, response: Any) -> Optional[str]:
        """
        Maps Responses API termination metadata to the Generation finish_reason.
        """
        if self._extract_tool_call(response) is not None:
            return "tool_calls"

        status = getattr(response, "status", None)
        if status == "completed":
            return "stop"

        if status == "incomplete":
            incomplete_details = getattr(response, "incomplete_details", None)
            reason = getattr(incomplete_details, "reason", None)
            if reason == "max_output_tokens":
                return "length"
            if reason == "content_filter":
                return "content_filter"

        return None

    def _build_responses_payload(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        tool: Optional[Dict[str, Any]] = None,
        max_tokens: Optional[int] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        seed: Optional[int] = None,
        stop: Optional[Union[str, List[str]]] = None,
        temperature: Optional[float] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """
        Builds a Responses API payload while preserving backward compatibility
        with the existing chat-completions-oriented method signature.
        """
        payload: dict[str, Any] = {
            "input": messages,
            "model": model,
        }

        if tool is not None:
            payload["tools"] = [tool]

        if max_tokens is not None:
            payload["max_output_tokens"] = max_tokens

        if temperature is not None:
            payload["temperature"] = temperature

        include: list[str] = []
        if logprobs or top_logprobs is not None:
            include.append("message.output_text.logprobs")
        if include:
            payload["include"] = include

        if top_logprobs is not None:
            payload["top_logprobs"] = top_logprobs

        extra_body = {
            key: value
            for key, value in {
                "frequency_penalty": frequency_penalty,
                "presence_penalty": presence_penalty,
                "seed": seed,
                "stop": stop,
                **kwargs,
            }.items()
            if value is not None
        }
        if extra_body:
            payload["extra_body"] = extra_body

        return payload

    def get_usage(self, response: Any) -> Usage:
        """
        Extracts the usage information from the response.

        Args:
            response (Any): The response object from the Responses API.

        Returns:
            Usage: An object containing the usage information.
        """

        usage = getattr(response, "usage", None)
        input_token_details = getattr(usage, "input_tokens_details", None)
        cached_tokens = (
            input_token_details.cached_tokens
            if input_token_details and input_token_details.cached_tokens
            else None
        )
        logger.debug(f"Cached Tokens {cached_tokens}")

        return Usage(
            completion_tokens=(
                usage.output_tokens
                if usage and getattr(usage, "output_tokens", None) is not None
                else None
            ),
            prompt_tokens=(
                usage.input_tokens
                if usage and getattr(usage, "input_tokens", None) is not None
                else None
            ),
            total_tokens=(
                usage.total_tokens
                if usage and getattr(usage, "total_tokens", None) is not None
                else None
            ),
            cached_tokens=cached_tokens,
        )

    def convert_to_generation(self, response: Any) -> Generation:
        """
        Converts the OpenAI Responses API response to a Generation object.

        Args:
            response (Any): The response object from the Responses API.

        Returns:
            Generation: An object containing the generated content and metadata.
        """
        usage = self.get_usage(response)

        return Generation(
            content=self._extract_content(response),
            finish_reason=self._extract_finish_reason(response), # type:ignore 
            role=self._extract_role(response),
            usage=usage,
            tool_call=self._extract_tool_call(response),
            logprobs=self._extract_logprobs(response),
            content_policy_errors=self._extract_content_policy_errors(response),
        )

    def _generate(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        tool: Optional[Dict[str, Any]] = None,
        max_tokens: Optional[int] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        seed: Optional[int] = None,
        stop: Optional[Union[str, List[str]]] = None,
        temperature: Optional[float] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        **kwargs: Any,
    ) -> Generation:
        """
        Generates a response based on the provided messages and model settings.

        Args:
            messages (List[Dict[str, Any]]): A list of dictionaries containing the conversation history or prompts.
            model (str): The model identifier to use for text generation.
            tool (Optional[Dict[str, Any]]): A dictionary containing tool definition, if applicable.
            max_tokens (Optional[int]): Maximum number of tokens to generate. Defaults to no limit.
            frequency_penalty (Optional[float]): Penalizes new tokens based on their frequency in the generated text.
            presence_penalty (Optional[float]): Penalizes new tokens based on whether they appear in the generated text.
            seed (Optional[int]): Random seed for reproducibility of results.
            stop (Optional[Union[str, List[str]]]): String or list of strings to end the generation when encountered.
            temperature (Optional[float]): Controls randomness in the generation. Higher values (e.g., 1.0) make output more random, lower values (e.g., 0.2) make it more deterministic.
            logprobs (Optional[bool]): Include log probabilities for each token.
            top_logprobs (Optional[int]): Include log probabilities for the top n tokens.
            **kwargs (Any): Additional optional arguments for further customization.

        Returns:
            Generation: Generated response based on the input messages and model parameters.
        """

        payload = self._build_responses_payload(
            messages=messages,
            model=model,
            tool=tool,
            max_tokens=max_tokens,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            seed=seed,
            stop=stop,
            temperature=temperature,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            **kwargs,
        )
        try:
            response = self._client.responses.create(**payload)
        except openai.BadRequestError as err:
            content_policy_errors = self._extract_exception_content_policy_errors(err)
            if content_policy_errors:
                return Generation(
                    finish_reason="content_filter",
                    role="assistant",
                    content_policy_errors=content_policy_errors,
                )
            raise
        output = self.convert_to_generation(response)
        return output

    @override
    async def agenerate(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        tool: Optional[Dict[str, Any]] = None,
        max_tokens: Optional[int] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        seed: Optional[int] = None,
        stop: Optional[Union[str, List[str]]] = None,
        temperature: Optional[float] = None,
        logprobs: Optional[bool] = None,
        top_logprobs: Optional[int] = None,
        **kwargs: Any,
    ) -> Generation:
        """
        Asynchronously generates a response based on the provided messages and model settings.

        Args:
            messages (List[Dict[str, Any]]): A list of dictionaries containing the conversation history or prompts.
            model (str): The model identifier to use for text generation.
            tool (Optional[Dict[str, Any]]): A dictionary containing tool definition, if applicable.
            max_tokens (Optional[int]): Maximum number of tokens to generate. Defaults to no limit.
            frequency_penalty (Optional[float]): Penalizes new tokens based on their frequency in the generated text.
            presence_penalty (Optional[float]): Penalizes new tokens based on whether they appear in the generated text.
            seed (Optional[int]): Random seed for reproducibility of results.
            stop (Optional[Union[str, List[str]]]): String or list of strings to end the generation when encountered.
            temperature (Optional[float]): Controls randomness in the generation. Higher values (e.g., 1.0) make output more random, lower values (e.g., 0.2) make it more deterministic.
            logprobs (Optional[bool]): Include log probabilities for each token.
            top_logprobs (Optional[int]): Include log probabilities for the top n tokens.
            **kwargs (Any): Additional optional arguments for further customization.

        Returns:
            Generation: Generated response based on the input messages and model parameters.
        """

        payload = self._build_responses_payload(
            messages=messages,
            model=model,
            tool=tool,
            max_tokens=max_tokens,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            seed=seed,
            stop=stop,
            temperature=temperature,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            **kwargs,
        )

        try:
            response = await self._aclient.responses.create(**payload)
        except openai.BadRequestError as err:
            content_policy_errors = self._extract_exception_content_policy_errors(err)
            if content_policy_errors:
                return Generation(
                    finish_reason="content_filter",
                    role="assistant",
                    content_policy_errors=content_policy_errors,
                )
            raise
        output = self.convert_to_generation(response)
        return output

    def convert_to_parsed_generation(
        self, response: Any
    ) -> ParsedGeneration[ResponseFormatT]:
        """
        Converts the OpenAI Responses API parsed response to a ParsedGeneration object.

        Args:
            response (Any): The parsed response object from the Responses API.

        Returns:
            ParsedGeneration[ResponseFormatT]: An object containing the generated content and metadata.
        """
        usage = self.get_usage(response)
        return ParsedGeneration(
            content=self._extract_content(response),
            finish_reason=self._extract_finish_reason(response), # type:ignore
            role=self._extract_role(response),
            usage=usage,
            tool_call=None,  # Tool calls are not supported in parsed responses
            parsed=getattr(response, "output_parsed", None),
            content_policy_errors=self._extract_content_policy_errors(response),
        )

    def _parse(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        response_format: type[ResponseFormatT],
        seed: Optional[int] = None,
        temperature: Optional[float] = None,
        **kwargs: Any,
    ) -> ParsedGeneration[ResponseFormatT]:
        """
        Generates a response based on the provided messages and model settings.

        Args:
            messages (List[Dict[str, Any]]): A list of dictionaries containing the conversation history or prompts.
            model (str): The model identifier to use for text generation.
            response_format (type[ResponseFormatT]): An object specifying the format that the model must output.
            seed (Optional[int]): Random seed for reproducibility of results.
            temperature (Optional[float]): Controls randomness in the generation. Higher values (e.g., 1.0) make output more random, lower values (e.g., 0.2) make it more deterministic.
            **kwargs (Any): Additional optional arguments for further customization.

        Returns:
            ParsedGeneration[ResponseFormatT]: Generated response based on the input messages and model parameters.
        """
        extra_body = {key: value for key, value in kwargs.items() if value is not None}
        if seed is not None:
            extra_body["seed"] = seed

        payload: dict[str, Any] = {
            "input": messages,
            "model": model,
            "text_format": response_format,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        if extra_body:
            payload["extra_body"] = extra_body

        try:
            response = self._client.responses.parse(**payload)
        except openai.BadRequestError as err:
            content_policy_errors = self._extract_exception_content_policy_errors(err)
            if content_policy_errors:
                return ParsedGeneration(
                    finish_reason="content_filter",
                    role="assistant",
                    content_policy_errors=content_policy_errors,
                )
            raise
        output: ParsedGeneration[ResponseFormatT] = self.convert_to_parsed_generation(
            response
        )
        return output

    @override
    async def aparse(
        self,
        messages: List[Dict[str, Any]],
        model: str,
        response_format: type[ResponseFormatT],
        seed: Optional[int] = None,
        temperature: Optional[float] = None,
        **kwargs: Any,
    ) -> ParsedGeneration[ResponseFormatT]:
        """
        Asynchronously generates a response based on the provided messages and model settings.

        Args:
            messages (List[Dict[str, Any]]): A list of dictionaries containing the conversation history or prompts.
            model (str): The model identifier to use for text generation.
            response_format (type[ResponseFormatT]): An object specifying the format that the model must output.
            seed (Optional[int]): Random seed for reproducibility of results.
            temperature (Optional[float]): Controls randomness in the generation. Higher values (e.g., 1.0) make output more random, lower values (e.g., 0.2) make it more deterministic.
            **kwargs (Any): Additional optional arguments for further customization.

        Returns:
            ParsedGeneration[ResponseFormatT]: Generated response based on the input messages and model parameters.
        """
        extra_body = {key: value for key, value in kwargs.items() if value is not None}
        if seed is not None:
            extra_body["seed"] = seed

        payload: dict[str, Any] = {
            "input": messages,
            "model": model,
            "text_format": response_format,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        if extra_body:
            payload["extra_body"] = extra_body

        try:
            response = await self._aclient.responses.parse(**payload)
        except openai.BadRequestError as err:
            content_policy_errors = self._extract_exception_content_policy_errors(err)
            if content_policy_errors:
                return ParsedGeneration(
                    finish_reason="content_filter",
                    role="assistant",
                    content_policy_errors=content_policy_errors,
                )
            raise
        output: ParsedGeneration[ResponseFormatT] = self.convert_to_parsed_generation(
            response
        )
        return output
