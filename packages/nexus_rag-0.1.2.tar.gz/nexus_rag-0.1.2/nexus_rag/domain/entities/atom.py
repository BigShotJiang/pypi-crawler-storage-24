from typing import Any, Dict
from pydantic import BaseModel, Field

class Atom(BaseModel):
    id: str = Field(..., description="Identificador único do átomo.")
    molecule_id: str = Field(..., description="ID da molécula à qual o átomo pertence.")
    raw_text: str = Field(..., description="Conteúdo textual do átomo, incluindo cabeçalhos contextuais.")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados auxiliares do átomo.")
