from typing import Optional
from pydantic import BaseModel, Field

class Bond(BaseModel):
    source_atom_id: str = Field(..., description="ID do átomo onde esta relação foi identificada.")
    active_molecule_id: str = Field(..., description="ID da molécula emissora (ex: documento de origem).")
    passive_molecule_id: str = Field(..., description="ID da molécula alvo (ex: documento que está sendo alterado).")
    bond_type: str = Field(..., description="Tipo de relação aplicável.")
    target_section: Optional[str] = Field("Seção não especificada", description="Seção estrutural alvo.")
