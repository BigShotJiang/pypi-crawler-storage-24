from typing import List, Optional, Any, Dict
from pydantic import BaseModel, Field

class Molecule(BaseModel):
    id: str = Field(..., description="Identificador único normalizado do documento (ex: '221/2018').")
    title: str = Field(..., description="Nome ou título descritivo do documento.")
    content: str = Field(..., description="Conteúdo textual completo do documento (Markdown ou texto puro).")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados customizados do documento.")
    aliases: List[str] = Field(
        default_factory=list, 
        description="Termos/Regex alternativos pelos quais este documento pode ser referenciado."
    )
