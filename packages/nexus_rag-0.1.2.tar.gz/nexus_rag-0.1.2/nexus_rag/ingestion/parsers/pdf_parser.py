import os
from docling.document_converter import DocumentConverter

class DoclingParser:
    """
    Utilitário para converter documentos PDF em formato Markdown
    utilizando a biblioteca Docling.
    """
    def __init__(self):
        self.converter = DocumentConverter()

    def parse_pdf(self, file_path: str) -> str:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")
            
        result = self.converter.convert(file_path)
        return result.document.export_to_markdown()
