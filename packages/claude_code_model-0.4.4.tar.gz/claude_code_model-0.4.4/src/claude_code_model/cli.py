"""CLI wrapper for Claude Code."""

from __future__ import annotations

import asyncio
from asyncio import subprocess as async_subprocess
import json
import logging
import os
import signal
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


async def _kill_process(proc: asyncio.subprocess.Process) -> None:
    """Kill a subprocess tree and wait for it to exit."""
    pid = proc.pid
    if pid is None:
        return
    try:
        os.killpg(os.getpgid(pid), signal.SIGKILL)
    except (ProcessLookupError, PermissionError, OSError):
        # Process already dead or not a group leader — fall back to direct kill
        try:
            proc.kill()
        except ProcessLookupError:
            return
    try:
        await asyncio.wait_for(proc.wait(), timeout=5)
    except (asyncio.TimeoutError, ProcessLookupError):
        pass


class ClaudeCodeError(Exception):
    """Base exception for claude-code-model."""

    pass


class ClaudeCodeNotFoundError(ClaudeCodeError):
    """Raised when claude CLI executable is not found."""

    pass


class ClaudeCodeTimeoutError(ClaudeCodeError):
    """Raised when CLI command times out."""

    pass


class ClaudeCodeExecutionError(ClaudeCodeError):
    """Raised when CLI returns non-zero exit code."""

    pass


@dataclass
class CLIResult:
    """Result from CLI execution."""

    stdout: str
    stderr: str
    exit_code: int
    elapsed_seconds: float = 0.0

    @property
    def success(self) -> bool:
        """Return True if command exited with code 0."""
        return self.exit_code == 0


@dataclass
class ClaudeCodeCLI:
    """Wrapper for Claude Code CLI."""

    model: str = "sonnet"
    timeout: int = 30  # Default 30 seconds per request
    cwd: Path | None = None
    verbose: bool = False
    _executable: Path = field(init=False, repr=False)

    def __post_init__(self) -> None:
        """Find and validate claude executable."""
        claude_path = shutil.which("claude")
        if claude_path is None:
            raise ClaudeCodeNotFoundError(
                "claude CLI not found. "
                "Install with: npm install -g @anthropic-ai/claude-code"
            )
        self._executable = Path(claude_path)
        if self.verbose:
            logger.setLevel(logging.DEBUG)
            if not logger.handlers:
                handler = logging.StreamHandler()
                handler.setFormatter(
                    logging.Formatter("[%(name)s] %(levelname)s: %(message)s")
                )
                logger.addHandler(handler)

    async def run(
        self,
        prompt: str,
        *,
        images: list[tuple[str, str]] | None = None,
    ) -> CLIResult:
        """
        Execute claude CLI with prompt and return result.

        Args:
            prompt: The prompt to send to Claude
            images: Optional list of (base64_data, media_type) tuples for image input.
                When provided, uses stdin JSON format instead of text-only mode.

        Returns:
            CLIResult with stdout, stderr, exit_code

        Raises:
            ClaudeCodeTimeoutError: If command times out
            ClaudeCodeExecutionError: If command exits with non-zero code
        """
        if images:
            return await self._run_with_images(prompt, images)

        cmd = [
            str(self._executable),
            "-p",
            prompt,
            "--model",
            self.model,
            "--no-session-persistence",  # Prevent conversation bleed-through
        ]

        if self.verbose:
            logger.debug("=" * 60)
            logger.debug("CLAUDE CLI REQUEST")
            logger.debug("=" * 60)
            logger.debug("Command: claude -p <prompt> --model %s", self.model)
            logger.debug("Timeout: %d seconds", self.timeout)
            logger.debug("Prompt (%d chars):\n%s", len(prompt), prompt[:2000])
            if len(prompt) > 2000:
                logger.debug("... (truncated, total %d chars)", len(prompt))
            logger.debug("-" * 60)

        start_time = time.perf_counter()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=async_subprocess.DEVNULL,  # Prevent hang when no TTY
                stdout=async_subprocess.PIPE,
                stderr=async_subprocess.PIPE,
                cwd=self.cwd,
                start_new_session=True,
            )

            if self.verbose:
                logger.debug(
                    "Process started (PID: %s), waiting for response...", proc.pid
                )

            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(),
                timeout=self.timeout,
            )
        except asyncio.TimeoutError as e:
            await _kill_process(proc)
            elapsed = time.perf_counter() - start_time
            logger.error("CLI timeout after %.1fs (limit: %ds)", elapsed, self.timeout)
            raise ClaudeCodeTimeoutError(
                f"CLI timeout after {self.timeout} seconds"
            ) from e
        except asyncio.CancelledError:
            await _kill_process(proc)
            elapsed = time.perf_counter() - start_time
            logger.warning("CLI request was cancelled after %.1fs", elapsed)
            raise

        elapsed = time.perf_counter() - start_time
        stdout = stdout_bytes.decode() if stdout_bytes else ""
        stderr = stderr_bytes.decode() if stderr_bytes else ""

        if self.verbose:
            logger.debug("=" * 60)
            logger.debug("CLAUDE CLI RESPONSE (took %.1fs)", elapsed)
            logger.debug("=" * 60)
            logger.debug("Exit code: %s", proc.returncode)
            logger.debug("Stdout (%d chars):\n%s", len(stdout), stdout[:2000])
            if len(stdout) > 2000:
                logger.debug("... (truncated, total %d chars)", len(stdout))
            if stderr:
                logger.debug("Stderr: %s", stderr)
            logger.debug("-" * 60)

        if proc.returncode != 0:
            logger.error("CLI exited with code %s: %s", proc.returncode, stderr)
            raise ClaudeCodeExecutionError(
                f"CLI exited with code {proc.returncode}: {stderr}"
            )

        return CLIResult(
            stdout=stdout,
            stderr=stderr,
            exit_code=proc.returncode or 0,
            elapsed_seconds=elapsed,
        )

    async def _run_with_images(
        self,
        prompt: str,
        images: list[tuple[str, str]],
    ) -> CLIResult:
        """Execute CLI with image content via stdin JSON format."""
        content_blocks: list[dict[str, Any]] = []
        for base64_data, media_type in images:
            content_blocks.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": media_type,
                        "data": base64_data,
                    },
                }
            )
        content_blocks.append({"type": "text", "text": prompt})

        stdin_data = (
            json.dumps({"type": "user_message", "content": content_blocks}) + "\n"
        )

        cmd = [
            str(self._executable),
            "--input-format",
            "stream-json",
            "--output-format",
            "stream-json",
            "--verbose",
            "--model",
            self.model,
            "--no-session-persistence",
        ]

        if self.verbose:
            logger.debug("=" * 60)
            logger.debug("CLAUDE CLI REQUEST (with %d image(s))", len(images))
            logger.debug("=" * 60)
            logger.debug(
                "Command: claude --input-format stream-json --model %s", self.model
            )
            logger.debug("Timeout: %d seconds", self.timeout)
            logger.debug("Prompt (%d chars):\n%s", len(prompt), prompt[:2000])
            logger.debug("-" * 60)

        start_time = time.perf_counter()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=async_subprocess.PIPE,
                stdout=async_subprocess.PIPE,
                stderr=async_subprocess.PIPE,
                cwd=self.cwd,
                start_new_session=True,
            )

            if self.verbose:
                logger.debug(
                    "Process started (PID: %s), sending image data...", proc.pid
                )

            # Write input and close stdin so the CLI starts processing.
            # Cannot use proc.communicate(input=...) because the CLI
            # needs stdin closed before it produces any stdout.
            assert proc.stdin is not None
            proc.stdin.write(stdin_data.encode())
            await proc.stdin.drain()
            proc.stdin.close()
            await proc.stdin.wait_closed()

            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                proc.communicate(),
                timeout=self.timeout,
            )
        except asyncio.TimeoutError as e:
            await _kill_process(proc)
            elapsed = time.perf_counter() - start_time
            logger.error("CLI timeout after %.1fs (limit: %ds)", elapsed, self.timeout)
            raise ClaudeCodeTimeoutError(
                f"CLI timeout after {self.timeout} seconds"
            ) from e
        except asyncio.CancelledError:
            await _kill_process(proc)
            elapsed = time.perf_counter() - start_time
            logger.warning("CLI request was cancelled after %.1fs", elapsed)
            raise

        elapsed = time.perf_counter() - start_time
        raw_stdout = stdout_bytes.decode() if stdout_bytes else ""
        stderr = stderr_bytes.decode() if stderr_bytes else ""

        if proc.returncode != 0:
            logger.error("CLI exited with code %s: %s", proc.returncode, stderr)
            raise ClaudeCodeExecutionError(
                f"CLI exited with code {proc.returncode}: {stderr}"
            )

        # Parse JSON output format to extract response text
        stdout = self._parse_json_output(raw_stdout)

        if self.verbose:
            logger.debug("=" * 60)
            logger.debug("CLAUDE CLI RESPONSE (took %.1fs)", elapsed)
            logger.debug("=" * 60)
            logger.debug("Exit code: %s", proc.returncode)
            logger.debug("Stdout (%d chars):\n%s", len(stdout), stdout[:2000])
            if stderr:
                logger.debug("Stderr: %s", stderr)
            logger.debug("-" * 60)

        return CLIResult(
            stdout=stdout,
            stderr=stderr,
            exit_code=proc.returncode or 0,
            elapsed_seconds=elapsed,
        )

    @staticmethod
    def _parse_json_output(raw: str) -> str:
        """Extract response text from --output-format stream-json output.

        Stream-json returns newline-delimited JSON messages. We look for
        the {"type":"result","result":"..."} message and extract the result.
        """
        raw = raw.strip()
        if not raw:
            return ""

        # Stream-json: newline-delimited JSON messages
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(data, dict):
                continue

            # Result message: {"type":"result","result":"text response"}
            if data.get("type") == "result" and "result" in data:
                return str(data["result"])

        return raw

    @staticmethod
    def _extract_text_from_json(data: dict[str, Any]) -> str | None:
        """Extract text content from a JSON response object."""
        # {"result": "text"}
        if "result" in data:
            return str(data["result"])
        # {"content": "text"} or {"content": [{"type": "text", "text": "..."}]}
        if "content" in data:
            content = data["content"]
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(str(block.get("text", "")))
                if text_parts:
                    return "\n".join(text_parts)
        return None
