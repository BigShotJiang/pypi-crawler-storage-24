"""Tests for image/vision support."""

from __future__ import annotations

import asyncio
import base64
import json

import pytest
from unittest.mock import AsyncMock, patch

from claude_code_model.cli import ClaudeCodeCLI
from claude_code_model.model import ClaudeCodeModel


# Minimal 1x1 PNG for testing
TINY_PNG = base64.b64encode(
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"
    b"\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00"
    b"\x00\x00\x0cIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00"
    b"\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82"
).decode()


class TestCLIRunWithImages:
    """Test ClaudeCodeCLI.run() with images parameter."""

    @pytest.fixture
    def cli(self) -> ClaudeCodeCLI:
        with patch(
            "claude_code_model.cli.shutil.which", return_value="/usr/bin/claude"
        ):
            return ClaudeCodeCLI()

    @pytest.mark.asyncio
    async def test_text_only_uses_devnull_stdin(self, cli: ClaudeCodeCLI) -> None:
        """Without images, stdin should be DEVNULL (backward compat)."""
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"response", b"")
        mock_proc.returncode = 0

        with patch(
            "asyncio.create_subprocess_exec", return_value=mock_proc
        ) as mock_exec:
            await cli.run("test prompt")

        kwargs = mock_exec.call_args[1]
        assert kwargs["stdin"] == asyncio.subprocess.DEVNULL

    @pytest.mark.asyncio
    async def test_images_uses_pipe_stdin(self, cli: ClaudeCodeCLI) -> None:
        """With images, stdin should be PIPE for JSON input."""
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b'{"result": "described"}', b"")
        mock_proc.returncode = 0

        with patch(
            "asyncio.create_subprocess_exec", return_value=mock_proc
        ) as mock_exec:
            await cli.run(
                "Describe this image",
                images=[(TINY_PNG, "image/png")],
            )

        kwargs = mock_exec.call_args[1]
        assert kwargs["stdin"] == asyncio.subprocess.PIPE

    @pytest.mark.asyncio
    async def test_images_sends_stream_json_format(self, cli: ClaudeCodeCLI) -> None:
        """With images, command should use streaming mode (no -p)."""
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (
            b'{"type":"result","result":"ok"}',
            b"",
        )
        mock_proc.returncode = 0

        with patch(
            "asyncio.create_subprocess_exec", return_value=mock_proc
        ) as mock_exec:
            await cli.run(
                "Describe this",
                images=[(TINY_PNG, "image/png")],
            )

        args = mock_exec.call_args[0]
        assert "--input-format" in args
        assert "stream-json" in args
        assert "--output-format" in args
        assert "--verbose" in args
        assert "-p" not in args

    @pytest.mark.asyncio
    async def test_images_stdin_contains_image_data(self, cli: ClaudeCodeCLI) -> None:
        """Stdin should contain image content blocks as JSON."""
        written: list[bytes] = []
        mock_stdin = AsyncMock()
        mock_stdin.write = lambda data: written.append(data)  # type: ignore[assignment]

        mock_proc = AsyncMock()
        mock_proc.stdin = mock_stdin
        mock_proc.communicate.return_value = (b'{"type":"result","result":"ok"}', b"")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            await cli.run(
                "What is this?",
                images=[(TINY_PNG, "image/png")],
            )

        stdin_data = json.loads(b"".join(written).decode())
        assert stdin_data["type"] == "user_message"
        assert len(stdin_data["content"]) == 2  # 1 image + 1 text
        assert stdin_data["content"][0]["type"] == "image"
        assert stdin_data["content"][0]["source"]["type"] == "base64"
        assert stdin_data["content"][0]["source"]["media_type"] == "image/png"
        assert stdin_data["content"][0]["source"]["data"] == TINY_PNG
        assert stdin_data["content"][1]["type"] == "text"
        assert stdin_data["content"][1]["text"] == "What is this?"

    @pytest.mark.asyncio
    async def test_multiple_images(self, cli: ClaudeCodeCLI) -> None:
        """Multiple images should create multiple content blocks."""
        written: list[bytes] = []
        mock_stdin = AsyncMock()
        mock_stdin.write = lambda data: written.append(data)  # type: ignore[assignment]

        mock_proc = AsyncMock()
        mock_proc.stdin = mock_stdin
        mock_proc.communicate.return_value = (b'{"type":"result","result":"ok"}', b"")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            await cli.run(
                "Compare these",
                images=[
                    (TINY_PNG, "image/png"),
                    (TINY_PNG, "image/jpeg"),
                ],
            )

        stdin_data = json.loads(b"".join(written).decode())
        assert len(stdin_data["content"]) == 3  # 2 images + 1 text
        assert stdin_data["content"][0]["source"]["media_type"] == "image/png"
        assert stdin_data["content"][1]["source"]["media_type"] == "image/jpeg"

    @pytest.mark.asyncio
    async def test_images_includes_no_session_persistence(
        self, cli: ClaudeCodeCLI
    ) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b'{"result": "ok"}', b"")
        mock_proc.returncode = 0

        with patch(
            "asyncio.create_subprocess_exec", return_value=mock_proc
        ) as mock_exec:
            await cli.run("test", images=[(TINY_PNG, "image/png")])

        args = mock_exec.call_args[0]
        assert "--no-session-persistence" in args

    @pytest.mark.asyncio
    async def test_images_parses_result_message(self, cli: ClaudeCodeCLI) -> None:
        """Stream-json result message should be extracted."""
        stream_line = json.dumps({"type": "result", "result": "A cat sitting on a mat"})
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (stream_line.encode(), b"")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            result = await cli.run("Describe", images=[(TINY_PNG, "image/png")])

        assert result.stdout == "A cat sitting on a mat"

    @pytest.mark.asyncio
    async def test_images_handles_plain_text_output(self, cli: ClaudeCodeCLI) -> None:
        """Non-JSON output should be returned as-is."""
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"Just plain text", b"")
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            result = await cli.run("Describe", images=[(TINY_PNG, "image/png")])

        assert result.stdout == "Just plain text"

    @pytest.mark.asyncio
    async def test_images_timeout_raises_exception(self, cli: ClaudeCodeCLI) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.side_effect = asyncio.TimeoutError()

        with (
            patch("asyncio.create_subprocess_exec", return_value=mock_proc),
            patch("claude_code_model.cli._kill_process", new_callable=AsyncMock),
        ):
            with pytest.raises(Exception, match="timeout"):
                await cli.run("test", images=[(TINY_PNG, "image/png")])

    @pytest.mark.asyncio
    async def test_images_timeout_kills_subprocess(self, cli: ClaudeCodeCLI) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.side_effect = asyncio.TimeoutError()
        mock_kill = AsyncMock()

        with (
            patch("asyncio.create_subprocess_exec", return_value=mock_proc),
            patch("claude_code_model.cli._kill_process", mock_kill),
        ):
            with pytest.raises(Exception, match="timeout"):
                await cli.run("test", images=[(TINY_PNG, "image/png")])

        mock_kill.assert_called_once_with(mock_proc)


class TestParseJsonOutput:
    """Test _parse_json_output static method for stream-json format."""

    def test_empty_string(self) -> None:
        assert ClaudeCodeCLI._parse_json_output("") == ""

    def test_result_message(self) -> None:
        """Standard stream-json result message."""
        line = json.dumps({"type": "result", "result": "Hello world"})
        assert ClaudeCodeCLI._parse_json_output(line) == "Hello world"

    def test_result_among_multiple_lines(self) -> None:
        """Result message found among other stream-json messages."""
        lines = "\n".join(
            [
                json.dumps({"type": "system", "message": "init"}),
                json.dumps(
                    {
                        "type": "assistant",
                        "message": {
                            "role": "assistant",
                            "content": [{"type": "text", "text": "thinking..."}],
                        },
                    }
                ),
                json.dumps({"type": "result", "result": "final answer"}),
            ]
        )
        assert ClaudeCodeCLI._parse_json_output(lines) == "final answer"

    def test_non_json_returned_raw(self) -> None:
        assert ClaudeCodeCLI._parse_json_output("plain text") == "plain text"

    def test_unknown_json_returned_raw(self) -> None:
        raw = '{"foo": "bar"}'
        assert ClaudeCodeCLI._parse_json_output(raw) == raw

    def test_blank_lines_ignored(self) -> None:
        lines = "\n\n" + json.dumps({"type": "result", "result": "ok"}) + "\n\n"
        assert ClaudeCodeCLI._parse_json_output(lines) == "ok"

    def test_no_result_message_returns_raw(self) -> None:
        """If no result message found, return raw output."""
        lines = "\n".join(
            [
                json.dumps({"type": "system", "message": "init"}),
                json.dumps({"type": "assistant", "message": {}}),
            ]
        )
        assert ClaudeCodeCLI._parse_json_output(lines) == lines


class TestModelImageExtraction:
    """Test ClaudeCodeModel._extract_images."""

    @pytest.fixture
    def model(self) -> ClaudeCodeModel:
        with patch(
            "claude_code_model.cli.shutil.which", return_value="/usr/bin/claude"
        ):
            return ClaudeCodeModel()

    def test_no_images_in_text_message(self, model: ClaudeCodeModel) -> None:
        from pydantic_ai.messages import ModelRequest, UserPromptPart

        messages = [ModelRequest(parts=[UserPromptPart(content="Hello")])]
        images = model._extract_images(messages)
        assert images == []

    def test_extracts_binary_image(self, model: ClaudeCodeModel) -> None:
        from pydantic_ai.messages import BinaryContent, ModelRequest, UserPromptPart

        img = BinaryContent(data=b"\x89PNG", media_type="image/png")
        messages = [
            ModelRequest(parts=[UserPromptPart(content=["Describe this", img])])
        ]
        images = model._extract_images(messages)
        assert len(images) == 1
        assert images[0][1] == "image/png"

    def test_skips_non_image_binary(self, model: ClaudeCodeModel) -> None:
        from pydantic_ai.messages import BinaryContent, ModelRequest, UserPromptPart

        audio = BinaryContent(data=b"\x00\x01", media_type="audio/wav")
        messages = [ModelRequest(parts=[UserPromptPart(content=["Listen", audio])])]
        images = model._extract_images(messages)
        assert images == []

    def test_multiple_images_across_messages(self, model: ClaudeCodeModel) -> None:
        from pydantic_ai.messages import BinaryContent, ModelRequest, UserPromptPart

        img1 = BinaryContent(data=b"\x89PNG1", media_type="image/png")
        img2 = BinaryContent(data=b"\xff\xd8", media_type="image/jpeg")
        messages = [
            ModelRequest(parts=[UserPromptPart(content=["First", img1])]),
            ModelRequest(parts=[UserPromptPart(content=["Second", img2])]),
        ]
        images = model._extract_images(messages)
        assert len(images) == 2


class TestBuildPromptWithImages:
    """Test _build_prompt with multimodal UserPromptPart content."""

    @pytest.fixture
    def model(self) -> ClaudeCodeModel:
        with patch(
            "claude_code_model.cli.shutil.which", return_value="/usr/bin/claude"
        ):
            return ClaudeCodeModel()

    def test_text_content_unchanged(self, model: ClaudeCodeModel) -> None:
        from pydantic_ai.messages import ModelRequest, UserPromptPart
        from pydantic_ai.models import ModelRequestParameters

        messages = [ModelRequest(parts=[UserPromptPart(content="Hello world")])]
        params = ModelRequestParameters(
            function_tools=[],
            output_tools=None,
            allow_text_output=True,
            output_mode="text",
        )
        prompt = model._build_prompt(messages, params)
        assert "User: Hello world" in prompt

    def test_multimodal_content_extracts_text(self, model: ClaudeCodeModel) -> None:
        from pydantic_ai.messages import BinaryContent, ModelRequest, UserPromptPart
        from pydantic_ai.models import ModelRequestParameters

        img = BinaryContent(data=b"\x89PNG", media_type="image/png")
        messages = [
            ModelRequest(parts=[UserPromptPart(content=["Describe this image", img])])
        ]
        params = ModelRequestParameters(
            function_tools=[],
            output_tools=None,
            allow_text_output=True,
            output_mode="text",
        )
        prompt = model._build_prompt(messages, params)
        assert "User: Describe this image" in prompt

    def test_image_only_content_shows_placeholder(self, model: ClaudeCodeModel) -> None:
        from pydantic_ai.messages import BinaryContent, ModelRequest, UserPromptPart
        from pydantic_ai.models import ModelRequestParameters

        img = BinaryContent(data=b"\x89PNG", media_type="image/png")
        messages = [ModelRequest(parts=[UserPromptPart(content=[img])])]
        params = ModelRequestParameters(
            function_tools=[],
            output_tools=None,
            allow_text_output=True,
            output_mode="text",
        )
        prompt = model._build_prompt(messages, params)
        assert "User: [image]" in prompt


class TestModelRequestWithImages:
    """Test end-to-end request flow with images."""

    @pytest.mark.asyncio
    async def test_request_with_binary_image(self) -> None:
        from pydantic_ai.messages import BinaryContent, ModelRequest, UserPromptPart
        from pydantic_ai.models import ModelRequestParameters

        with patch(
            "claude_code_model.cli.shutil.which", return_value="/usr/bin/claude"
        ):
            model = ClaudeCodeModel()

        img = BinaryContent(data=b"\x89PNG", media_type="image/png")

        stream_line = json.dumps({"type": "result", "result": "A colorful image"})
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (stream_line.encode(), b"")
        mock_proc.returncode = 0

        with patch(
            "asyncio.create_subprocess_exec", return_value=mock_proc
        ) as mock_exec:
            messages = [
                ModelRequest(parts=[UserPromptPart(content=["What is this?", img])])
            ]
            params = ModelRequestParameters(
                function_tools=[],
                output_tools=None,
                allow_text_output=True,
                output_mode="text",
            )
            response = await model.request(messages, None, params)

        # Should use PIPE stdin for images
        kwargs = mock_exec.call_args[1]
        assert kwargs["stdin"] == asyncio.subprocess.PIPE

        # Should return the parsed response
        from pydantic_ai.messages import TextPart

        assert len(response.parts) == 1
        assert isinstance(response.parts[0], TextPart)
        assert response.parts[0].content == "A colorful image"

    @pytest.mark.asyncio
    async def test_request_text_only_still_uses_devnull(self) -> None:
        from pydantic_ai.messages import ModelRequest, UserPromptPart
        from pydantic_ai.models import ModelRequestParameters

        with patch(
            "claude_code_model.cli.shutil.which", return_value="/usr/bin/claude"
        ):
            model = ClaudeCodeModel()

        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"text response", b"")
        mock_proc.returncode = 0

        with patch(
            "asyncio.create_subprocess_exec", return_value=mock_proc
        ) as mock_exec:
            messages = [ModelRequest(parts=[UserPromptPart(content="Hi")])]
            params = ModelRequestParameters(
                function_tools=[],
                output_tools=None,
                allow_text_output=True,
                output_mode="text",
            )
            await model.request(messages, None, params)

        kwargs = mock_exec.call_args[1]
        assert kwargs["stdin"] == asyncio.subprocess.DEVNULL
