"""Tests for streaming iterator wrappers, chunk joining, I/O auto-populate, and OpenAI stream enricher."""

from __future__ import annotations

import asyncio
import importlib
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from turingpulse_sdk.client import PolicyCheckResult
from turingpulse_sdk.config import GovernanceDefaults, TuringPulseConfig
from turingpulse_sdk.context import ExecutionContext, bind_context
from turingpulse_sdk.fingerprint import FingerprintConfig
from turingpulse_sdk.governance import GovernanceDirective
from turingpulse_sdk.instrumentation import InstrumentationOptions
from turingpulse_sdk.plugin import (
    TuringPulsePlugin,
    _AsyncIteratorSpanWrapper,
    _IteratorSpanWrapper,
    get_plugin,
)


# ---------------------------------------------------------------------------
# Helpers (aligned with test_bidirectional_policy patterns)
# ---------------------------------------------------------------------------


def _allow():
    return PolicyCheckResult(action="allow", triggered=False)


def _make_context(**overrides):
    defaults = dict(
        run_id="run-stream-001",
        operation="stream-op",
        labels={},
        metadata={},
        args=(),
        kwargs={},
        workflow_name="stream-workflow",
        node_type="function",
        span_id="span-stream-001",
    )
    defaults.update(overrides)
    return ExecutionContext(**defaults)


def _streaming_plugin(**config_overrides):
    """Plugin with tracing and HTTP mocked; fingerprint off to avoid side calls."""
    defaults = dict(
        api_key="test-key-streaming-sdk",
        workflow_name="stream-workflow",
        trace_enabled=False,
        fingerprint=FingerprintConfig(enabled=False),
    )
    defaults.update(config_overrides)
    config = TuringPulseConfig(**defaults)
    plugin = TuringPulsePlugin(config)
    plugin.client = MagicMock()
    plugin.client.serialize_events.return_value = b"{}"
    plugin.client.emit_serialized_payload = MagicMock()
    plugin.client.emit_serialized_payload_async = AsyncMock()
    plugin.client.policy_check = MagicMock(return_value=_allow())

    span_cm = MagicMock()
    span_cm.__enter__.return_value = None
    span_cm.__exit__.return_value = None
    plugin.tracing = MagicMock()
    plugin.tracing.span.return_value = span_cm

    return plugin, span_cm


@pytest.fixture(autouse=True)
def _reset_plugin():
    import turingpulse_sdk.plugin as pm

    pm._PLUGIN = None
    yield
    pm._PLUGIN = None


# ---------------------------------------------------------------------------
# 1–2. Iterator detection
# ---------------------------------------------------------------------------


class TestIteratorDetection:
    def test_is_unwrapped_iterator_detection(self):
        class _CustomChunks:
            def __init__(self, items):
                self._items = list(items)
                self._i = 0

            def __iter__(self):
                return self

            def __next__(self):
                if self._i >= len(self._items):
                    raise StopIteration
                v = self._items[self._i]
                self._i += 1
                return v

        assert TuringPulsePlugin._is_unwrapped_iterator(_CustomChunks([1, 2])) is True
        assert TuringPulsePlugin._is_unwrapped_iterator("not an iterator body") is False
        assert TuringPulsePlugin._is_unwrapped_iterator({"role": "user", "content": "hi"}) is False
        assert TuringPulsePlugin._is_unwrapped_iterator(["a", "b"]) is False
        assert TuringPulsePlugin._is_unwrapped_iterator(None) is False

    def test_is_unwrapped_async_iterator_detection(self):
        class _AsyncByteStream:
            def __init__(self):
                self._n = 0

            def __aiter__(self):
                return self

            async def __anext__(self):
                if self._n >= 2:
                    raise StopAsyncIteration
                self._n += 1
                return f"chunk-{self._n}"

        stream = _AsyncByteStream()
        assert TuringPulsePlugin._is_unwrapped_async_iterator(stream) is True
        assert TuringPulsePlugin._is_unwrapped_async_iterator(None) is False
        assert TuringPulsePlugin._is_unwrapped_async_iterator(["x"]) is False
        assert TuringPulsePlugin._is_unwrapped_async_iterator("async") is False


# ---------------------------------------------------------------------------
# 3–7. execute_sync / _IteratorSpanWrapper
# ---------------------------------------------------------------------------


class TestExecuteSyncIteratorWrapper:
    def test_execute_sync_wraps_iterator(self):
        plugin, span_cm = _streaming_plugin()

        def emit_numbers():
            return iter([10, 20, 30])

        opts = InstrumentationOptions(name="stream-workflow", operation="emit_numbers")
        out = plugin.execute_sync(emit_numbers, (), {}, opts)

        assert isinstance(out, _IteratorSpanWrapper)
        assert list(out) == [10, 20, 30]

        plugin.client.emit_serialized_payload.assert_called()
        span_cm.__exit__.assert_called()

    def test_iterator_wrapper_context_manager(self):
        plugin, _ = _streaming_plugin()

        def boxed():
            return iter(["alpha", "beta"])

        opts = InstrumentationOptions(name="stream-workflow")
        wrapper = plugin.execute_sync(boxed, (), {}, opts)
        assert isinstance(wrapper, _IteratorSpanWrapper)

        with wrapper as w:
            assert list(w) == ["alpha", "beta"]

        plugin.client.emit_serialized_payload.assert_called()

    def test_iterator_wrapper_close(self):
        plugin, span_cm = _streaming_plugin()

        def long_stream():
            return iter(range(100))

        opts = InstrumentationOptions(name="stream-workflow")
        wrapper = plugin.execute_sync(long_stream, (), {}, opts)
        assert isinstance(wrapper, _IteratorSpanWrapper)

        first = next(wrapper)
        assert first == 0
        wrapper.close()

        plugin.client.emit_serialized_payload.assert_called()
        span_cm.__exit__.assert_called()
        # Idempotent finalize
        wrapper.close()
        assert plugin.client.emit_serialized_payload.call_count == 1

    def test_iterator_wrapper_error_during_iteration(self):
        plugin, span_cm = _streaming_plugin()

        class _BadStream:
            def __iter__(self):
                return self

            def __next__(self):
                raise RuntimeError("upstream provider reset the connection")

        def broken():
            return _BadStream()

        opts = InstrumentationOptions(name="stream-workflow")
        wrapper = plugin.execute_sync(broken, (), {}, opts)

        with pytest.raises(RuntimeError, match="upstream provider"):
            list(wrapper)

        plugin.client.emit_serialized_payload.assert_called()
        span_cm.__exit__.assert_called()


# ---------------------------------------------------------------------------
# 4. execute_async + _AsyncIteratorSpanWrapper
# ---------------------------------------------------------------------------


class TestExecuteAsyncIteratorWrapper:
    def test_execute_async_wraps_async_iterator(self):
        async def _run():
            plugin, span_cm = _streaming_plugin()

            class _AsyncTokens:
                def __init__(self):
                    self._i = 0
                    self._values = ("token_a", "token_b", "token_c")

                def __aiter__(self):
                    return self

                async def __anext__(self):
                    if self._i >= len(self._values):
                        raise StopAsyncIteration
                    v = self._values[self._i]
                    self._i += 1
                    return v

            async def produce():
                return _AsyncTokens()

            opts = InstrumentationOptions(name="stream-workflow", operation="produce")
            wrapped = await plugin.execute_async(produce, (), {}, opts)

            assert isinstance(wrapped, _AsyncIteratorSpanWrapper)
            collected = []
            async for item in wrapped:
                collected.append(item)
            assert collected == ["token_a", "token_b", "token_c"]

            plugin.client.emit_serialized_payload_async.assert_called()
            span_cm.__exit__.assert_called()

        asyncio.run(_run())


# ---------------------------------------------------------------------------
# 8–11. _join_chunk_list and _auto_populate_io
# ---------------------------------------------------------------------------


class TestJoinChunkListAndAutoPopulateIo:
    def test_join_chunk_list_strings(self):
        assert TuringPulsePlugin._join_chunk_list(["hello", " ", "world"]) == "hello world"
        assert TuringPulsePlugin._join_chunk_list([]) == ""

    def test_join_chunk_list_objects(self):
        class _Part:
            def __init__(self, content: str):
                self.content = content

        chunks = [_Part("Q3 "), _Part("revenue "), _Part("met guidance.")]
        assert TuringPulsePlugin._join_chunk_list(chunks) == "Q3 revenue met guidance."

    def test_auto_populate_io_list(self):
        ctx = _make_context()
        TuringPulsePlugin._auto_populate_io(ctx, ["The ", "forecast ", "is stable."], None)
        assert ctx.output_data == "The forecast is stable."

    def test_garbage_skip_in_audit_only(self):
        plugin, _ = _streaming_plugin(governance_defaults=GovernanceDefaults(hitl=True))
        plugin.client.policy_check = MagicMock(return_value=_allow())

        class _UnconsumedOpenAIStream:
            def __repr__(self) -> str:
                return "<openai.Stream object at 0x7f9a8b12ac40>"

        context = _make_context()
        options = InstrumentationOptions(
            name="stream-audit-garbage",
            governance=GovernanceDirective(hitl=True),
        )
        plugin._post_check_audit_only(context, options, _UnconsumedOpenAIStream())
        plugin.client.policy_check.assert_not_called()


# ---------------------------------------------------------------------------
# 12–15. OpenAI streaming (optional package)
# ---------------------------------------------------------------------------


def _openai_wrapper_module():
    """Load OpenAI integration from site-packages or from ``packages/openai`` in this repo."""
    try:
        return importlib.import_module("turingpulse_sdk_openai._wrapper")
    except ImportError:
        pass
    repo_openai = Path(__file__).resolve().parents[1] / "packages" / "openai"
    if not (repo_openai / "turingpulse_sdk_openai").is_dir():
        pytest.skip(
            "turingpulse_sdk_openai not installed and packages/openai missing — "
            "pip install turingpulse-sdk-openai or run tests from the SDK repo checkout"
        )
    path_str = str(repo_openai)
    inserted = False
    if path_str not in sys.path:
        sys.path.insert(0, path_str)
        inserted = True
    try:
        return importlib.import_module("turingpulse_sdk_openai._wrapper")
    except ImportError:
        pytest.skip("Could not import turingpulse_sdk_openai._wrapper (needs openai>=1.78)")
    finally:
        if inserted:
            sys.path.remove(path_str)


class TestOpenAIStreaming:
    def test_openai_stream_injects_stream_options(self):
        wmod = _openai_wrapper_module()
        kwargs = {
            "stream": True,
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "Summarize the board meeting notes"}],
        }
        wmod._inject_stream_options(kwargs)
        assert kwargs["stream_options"]["include_usage"] is True

        kwargs_partial = {"stream": True, "stream_options": {}}
        wmod._inject_stream_options(kwargs_partial)
        assert kwargs_partial["stream_options"]["include_usage"] is True

    def test_openai_stream_returns_enricher(self):
        wmod = _openai_wrapper_module()
        from turingpulse_sdk import init

        init(
            api_key="openai-stream-proxy-test-key",
            workflow_name="Board Summarizer Workflow",
            trace_enabled=False,
            fingerprint=FingerprintConfig(enabled=False),
        )
        _tp = get_plugin()
        _tp.client = MagicMock()
        _tp.client.serialize_events.return_value = b"{}"
        _tp.client.emit_serialized_payload = MagicMock()

        fake_completions = MagicMock()
        # OpenAI returns a stream object that is itself an iterator; an exhausted
        # iterator is enough to exercise ``_SyncStreamEnricher`` + wrapper.
        fake_completions.create.return_value = iter(())

        proxy = wmod._CompletionsProxy(
            fake_completions,
            name="Board Summarizer Workflow",
            governance=None,
        )
        out = proxy.create(
            stream=True,
            model="gpt-4o",
            messages=[{"role": "user", "content": "Draft executive summary"}],
        )
        # ``@instrument`` defers finalization for iterators; the OpenAI layer still wraps
        # the provider stream in ``_SyncStreamEnricher`` (iter(enricher) is enricher).
        assert isinstance(out, _IteratorSpanWrapper)
        assert isinstance(out._iterable, wmod._SyncStreamEnricher)
        assert list(out) == []
        fake_completions.create.assert_called_once()
        passed = fake_completions.create.call_args.kwargs
        assert passed["stream"] is True
        assert passed["stream_options"]["include_usage"] is True

    def test_openai_stream_enricher_accumulates(self):
        wmod = _openai_wrapper_module()

        def _chunk(text: str | None, *, model: str | None = None, usage=None):
            delta = SimpleNamespace(content=text)
            choice = SimpleNamespace(delta=delta)
            return SimpleNamespace(model=model, choices=[choice], usage=usage)

        chunks = [
            _chunk("Enterprise ", model="gpt-4o-mini"),
            _chunk("ARR "),
            _chunk(
                "grew 22% YoY.",
                usage=SimpleNamespace(prompt_tokens=156, completion_tokens=48),
            ),
        ]

        ctx = ExecutionContext(
            run_id="run-openai-stream-enrich-001",
            workflow_name="revenue-insights",
        )
        kwargs = {
            "messages": [
                {"role": "system", "content": "You are a financial analyst assistant."},
                {"role": "user", "content": "How did enterprise ARR trend year over year?"},
            ]
        }

        with bind_context(ctx):
            enricher = wmod._SyncStreamEnricher(iter(chunks), kwargs)
            assert list(enricher) == chunks

        assert ctx.tokens_input == 156
        assert ctx.tokens_output == 48
        assert ctx.model == "gpt-4o-mini"
        assert ctx.provider == "openai"
        assert ctx.output_data == "Enterprise ARR grew 22% YoY."
        assert ctx.node_type == "llm"
        assert ctx.framework == "openai"

    def test_openai_non_stream_unchanged(self):
        wmod = _openai_wrapper_module()
        from turingpulse_sdk import init

        init(
            api_key="openai-nonstream-test-key",
            workflow_name="Quarterly Report Generator",
            trace_enabled=False,
            fingerprint=FingerprintConfig(enabled=False),
        )
        _tp = get_plugin()
        _tp.client = MagicMock()
        _tp.client.serialize_events.return_value = b"{}"
        _tp.client.emit_serialized_payload = MagicMock()

        message = SimpleNamespace(content="Revenue beat consensus by 4%.")
        choice = SimpleNamespace(message=message, tool_calls=None)
        response = SimpleNamespace(
            model="gpt-4o",
            choices=[choice],
            usage=SimpleNamespace(prompt_tokens=512, completion_tokens=96),
        )

        fake_completions = MagicMock()
        fake_completions.create.return_value = response

        proxy = wmod._CompletionsProxy(
            fake_completions,
            name="Quarterly Report Generator",
            governance=None,
        )

        with patch.object(wmod, "_record_span") as record_mock:
            out = proxy.create(
                stream=False,
                model="gpt-4o",
                messages=[{"role": "user", "content": "Key takeaway from Q3 earnings?"}],
            )

        assert out is response
        record_mock.assert_called_once()
        rec_response, rec_kwargs = record_mock.call_args[0]
        assert rec_response is response
        assert rec_kwargs["stream"] is False
        assert rec_kwargs["model"] == "gpt-4o"
        inner_kw = fake_completions.create.call_args.kwargs
        assert inner_kw.get("stream_options") is None


# ---------------------------------------------------------------------------
# 16–19. Bedrock dict-like access (_BedrockStreamEnricher)
# ---------------------------------------------------------------------------


class TestBedrockDictLikeAccess:
    """Tests for Bedrock enricher's dict-like interface (P0 fix)."""

    def _load_module(self):
        try:
            return importlib.import_module("turingpulse_sdk_bedrock._wrapper")
        except ImportError:
            pass
        repo_bedrock = Path(__file__).resolve().parents[1] / "packages" / "bedrock"
        if not (repo_bedrock / "turingpulse_sdk_bedrock").is_dir():
            pytest.skip("turingpulse_sdk_bedrock not available")
        path_str = str(repo_bedrock)
        inserted = False
        if path_str not in sys.path:
            sys.path.insert(0, path_str)
            inserted = True
        try:
            return importlib.import_module("turingpulse_sdk_bedrock._wrapper")
        except ImportError:
            pytest.skip("Could not import turingpulse_sdk_bedrock._wrapper")
        finally:
            if inserted:
                sys.path.remove(path_str)

    def test_dict_response_preserves_metadata(self):
        wmod = self._load_module()
        stream_events = [{"contentBlockDelta": {"delta": {"text": "Revenue "}}}]
        response = {
            "stream": iter(stream_events),
            "ResponseMetadata": {"RequestId": "abc-123", "HTTPStatusCode": 200},
        }
        enricher = wmod._BedrockStreamEnricher(response, {"modelId": "anthropic.claude-v2"})

        assert "stream" in enricher
        assert "ResponseMetadata" in enricher
        assert enricher["ResponseMetadata"]["RequestId"] == "abc-123"
        assert enricher.get("ResponseMetadata") is not None
        assert enricher.get("nonexistent", "fallback") == "fallback"
        assert "stream" in enricher.keys()
        assert "ResponseMetadata" in enricher.keys()

    def test_dict_response_stream_returns_self(self):
        wmod = self._load_module()
        response = {"stream": iter(["event1"]), "ResponseMetadata": {}}
        enricher = wmod._BedrockStreamEnricher(response, {"modelId": "us.meta.llama3-2"})
        assert enricher["stream"] is enricher

    def test_non_dict_response_works(self):
        wmod = self._load_module()
        enricher = wmod._BedrockStreamEnricher(iter(["ev1", "ev2"]), {"modelId": "test-model"})
        assert list(enricher) == ["ev1", "ev2"]
        with pytest.raises(KeyError):
            enricher["ResponseMetadata"]

    def test_iteration_enriches_context(self):
        wmod = self._load_module()
        events = [
            {"contentBlockDelta": {"delta": {"text": "Q3 "}}},
            {"contentBlockDelta": {"delta": {"text": "earnings "}}},
            {
                "metadata": {
                    "usage": {"inputTokens": 250, "outputTokens": 75}
                }
            },
        ]
        response = {"stream": iter(events), "ResponseMetadata": {}}
        ctx = _make_context()

        with bind_context(ctx):
            enricher = wmod._BedrockStreamEnricher(response, {"modelId": "anthropic.claude-3"})
            collected = list(enricher)

        assert len(collected) == 3
        assert ctx.tokens_input == 250
        assert ctx.tokens_output == 75
        assert ctx.model == "anthropic.claude-3"
        assert "Q3 earnings " in (ctx.output_data or "")


# ---------------------------------------------------------------------------
# 20. Cohere async stream enricher
# ---------------------------------------------------------------------------


class TestCohereAsyncStream:
    """Tests for Cohere _AsyncStreamEnricher (P1 fix)."""

    def _load_module(self):
        try:
            return importlib.import_module("turingpulse_sdk_cohere._wrapper")
        except ImportError:
            pass
        repo_cohere = Path(__file__).resolve().parents[1] / "packages" / "cohere"
        if not (repo_cohere / "turingpulse_sdk_cohere").is_dir():
            pytest.skip("turingpulse_sdk_cohere not available")
        path_str = str(repo_cohere)
        inserted = False
        if path_str not in sys.path:
            sys.path.insert(0, path_str)
            inserted = True
        try:
            return importlib.import_module("turingpulse_sdk_cohere._wrapper")
        except ImportError:
            pytest.skip("Could not import turingpulse_sdk_cohere._wrapper")
        finally:
            if inserted:
                sys.path.remove(path_str)

    def test_async_stream_enricher_collects_chunks(self):
        async def _run():
            wmod = self._load_module()

            class _FakeAsyncStream:
                def __init__(self, items):
                    self._items = list(items)
                    self._i = 0

                def __aiter__(self):
                    return self

                async def __anext__(self):
                    if self._i >= len(self._items):
                        raise StopAsyncIteration
                    v = self._items[self._i]
                    self._i += 1
                    return v

            chunks = [
                SimpleNamespace(text="Operating "),
                SimpleNamespace(text="margin "),
                SimpleNamespace(text="expanded.", response=SimpleNamespace(meta=SimpleNamespace(tokens=SimpleNamespace(input_tokens=100, output_tokens=25)))),
            ]
            ctx = _make_context()
            kwargs = {"model": "command-r-plus", "messages": [{"role": "user", "content": "Margin trend?"}]}

            with bind_context(ctx):
                enricher = wmod._AsyncStreamEnricher(_FakeAsyncStream(chunks), kwargs)
                collected = []
                async for c in enricher:
                    collected.append(c)

            assert len(collected) == 3

        asyncio.run(_run())


# ---------------------------------------------------------------------------
# 21. Mistral async stream enricher
# ---------------------------------------------------------------------------


class TestMistralAsyncStream:
    """Tests for Mistral _AsyncStreamEnricher (P1 fix)."""

    def _load_module(self):
        try:
            return importlib.import_module("turingpulse_sdk_mistral._wrapper")
        except ImportError:
            pass
        repo_mistral = Path(__file__).resolve().parents[1] / "packages" / "mistral"
        if not (repo_mistral / "turingpulse_sdk_mistral").is_dir():
            pytest.skip("turingpulse_sdk_mistral not available")
        path_str = str(repo_mistral)
        inserted = False
        if path_str not in sys.path:
            sys.path.insert(0, path_str)
            inserted = True
        try:
            return importlib.import_module("turingpulse_sdk_mistral._wrapper")
        except ImportError:
            pytest.skip("Could not import turingpulse_sdk_mistral._wrapper")
        finally:
            if inserted:
                sys.path.remove(path_str)

    def test_async_stream_enricher_iterates(self):
        async def _run():
            wmod = self._load_module()

            class _FakeAsyncStream:
                def __init__(self, items):
                    self._items = list(items)
                    self._i = 0

                def __aiter__(self):
                    return self

                async def __anext__(self):
                    if self._i >= len(self._items):
                        raise StopAsyncIteration
                    v = self._items[self._i]
                    self._i += 1
                    return v

            chunk = SimpleNamespace(
                choices=[SimpleNamespace(delta=SimpleNamespace(content="Pipeline metrics "))],
                model="mistral-large-latest",
                usage=None,
            )
            ctx = _make_context()
            kwargs = {"model": "mistral-large-latest", "messages": []}

            with bind_context(ctx):
                enricher = wmod._AsyncStreamEnricher(_FakeAsyncStream([chunk]), kwargs)
                collected = []
                async for c in enricher:
                    collected.append(c)

            assert len(collected) == 1

        asyncio.run(_run())


# ---------------------------------------------------------------------------
# 22. LangChain stream() output accumulation
# ---------------------------------------------------------------------------


class TestLangChainStreamOutputAccumulation:
    """Tests for LangChain stream() output accumulation (P1 fix)."""

    def _load_module(self):
        try:
            return importlib.import_module("turingpulse_sdk_langchain._wrapper")
        except ImportError:
            pass
        repo_langchain = Path(__file__).resolve().parents[1] / "packages" / "langchain"
        if not (repo_langchain / "turingpulse_sdk_langchain").is_dir():
            pytest.skip("turingpulse_sdk_langchain not available")
        path_str = str(repo_langchain)
        inserted = False
        if path_str not in sys.path:
            sys.path.insert(0, path_str)
            inserted = True
        try:
            return importlib.import_module("turingpulse_sdk_langchain._wrapper")
        except ImportError:
            pytest.skip("Could not import turingpulse_sdk_langchain._wrapper")
        finally:
            if inserted:
                sys.path.remove(path_str)

    def test_stream_concatenates_content_chunks(self):
        wmod = self._load_module()
        from turingpulse_sdk import init

        init(
            api_key="langchain-stream-test",
            workflow_name="Financial Report Stream",
            trace_enabled=False,
            fingerprint=FingerprintConfig(enabled=False),
        )
        _tp = get_plugin()
        _tp.client = MagicMock()
        _tp.client.serialize_events.return_value = b"{}"
        _tp.client.emit_serialized_payload = MagicMock()
        _tp.client.policy_check = MagicMock(return_value=_allow())

        class _FakeChunk:
            def __init__(self, content: str):
                self.content = content

        class _FakeRunnable:
            def stream(self, input_data, config=None, **kw):
                yield _FakeChunk("Revenue ")
                yield _FakeChunk("beat ")
                yield _FakeChunk("estimates.")

            def invoke(self, input_data, config=None, **kw):
                return _FakeChunk("Revenue beat estimates.")

        wrapper = wmod._InstrumentedRunnable(
            runnable=_FakeRunnable(),
            name="Financial Report Stream",
            model="gpt-4o",
            provider="openai",
        )
        chunks_out = list(wrapper.stream("Quarterly revenue analysis"))
        assert len(chunks_out) == 3
        assert chunks_out[0].content == "Revenue "
