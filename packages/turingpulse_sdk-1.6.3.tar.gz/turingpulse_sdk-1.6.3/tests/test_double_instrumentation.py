"""Tests for double-instrumentation prevention via _INSTRUMENTING context var."""

from __future__ import annotations

from contextvars import ContextVar
from unittest.mock import MagicMock

import pytest

from turingpulse_sdk import init
import turingpulse_sdk.plugin as pm


@pytest.fixture(autouse=True)
def setup():
    pm._PLUGIN = None
    plugin = init(api_key="dedup-key", workflow_name="dedup-test")
    plugin.client = MagicMock()
    plugin.client.emit_serialized_payload = MagicMock()
    plugin.client.policy_check = MagicMock(return_value=MagicMock(action="allow", blocked=False))
    yield plugin
    pm._PLUGIN = None


class TestInstrumentingGuard:
    """Verify _INSTRUMENTING context var prevents nested double spans."""

    def test_instrumenting_var_prevents_recursion(self):
        from contextvars import ContextVar

        guard: ContextVar[bool] = ContextVar("test_guard", default=False)
        call_count = 0

        def inner():
            nonlocal call_count
            if guard.get(False):
                call_count += 1
                return "skipped"
            token = guard.set(True)
            try:
                call_count += 1
                return inner()  # Recursive call should skip
            finally:
                guard.reset(token)

        result = inner()
        assert call_count == 2
        assert result == "skipped"
