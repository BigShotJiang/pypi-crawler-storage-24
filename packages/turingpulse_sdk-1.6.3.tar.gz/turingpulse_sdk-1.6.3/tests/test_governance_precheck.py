"""Tests for pre-execution governance policy check logic."""

from __future__ import annotations

import os
import threading
from unittest.mock import MagicMock, patch, AsyncMock

import pytest

from turingpulse_sdk.client import PolicyCheckResult
from turingpulse_sdk.config import GovernanceDefaults, TuringPulseConfig
from turingpulse_sdk.context import ExecutionContext
from turingpulse_sdk.exceptions import GovernanceBlockedError, ConfigurationError
from turingpulse_sdk.governance import GovernanceDirective
from turingpulse_sdk.instrumentation import InstrumentationOptions
from turingpulse_sdk.plugin import TuringPulsePlugin, get_plugin, init


@pytest.fixture
def config():
    return TuringPulseConfig(api_key="test-key", workflow_name="test-workflow")


@pytest.fixture
def plugin(config):
    return TuringPulsePlugin(config)


@pytest.fixture
def mock_context():
    return ExecutionContext(
        run_id="test-run",
        operation="test-op",
        labels={},
        metadata={},
        args=(),
        workflow_name="test-workflow",
    )


class TestResolveGovernance:
    """Test _resolve_governance() merging logic."""

    def test_no_directive_no_defaults(self, plugin):
        options = InstrumentationOptions(name="test")
        result = plugin._resolve_governance(options)
        assert result is None

    def test_no_directive_with_global_hitl(self, plugin):
        plugin.config = TuringPulseConfig(
            api_key="test-key",
            workflow_name="test",
            governance_defaults=GovernanceDefaults(hitl=True, reviewers=["admin@co.com"]),
        )
        options = InstrumentationOptions(name="test")
        result = plugin._resolve_governance(options)
        assert result is not None
        assert result.hitl is True
        assert result.reviewers == ["admin@co.com"]

    def test_directive_overrides_defaults(self, plugin):
        plugin.config = TuringPulseConfig(
            api_key="test-key",
            workflow_name="test",
            governance_defaults=GovernanceDefaults(hitl=True),
        )
        directive = GovernanceDirective(hitl=False, hatl=True)
        options = InstrumentationOptions(name="test", governance=directive)
        result = plugin._resolve_governance(options)
        assert result.hitl is True  # Defaults upgrade hitl
        assert result.hatl is True

    def test_directive_without_global_hitl(self, plugin):
        directive = GovernanceDirective(hatl=True)
        options = InstrumentationOptions(name="test", governance=directive)
        result = plugin._resolve_governance(options)
        assert result.hitl is False
        assert result.hatl is True


class TestPreExecutionPolicyCheck:
    """Test _pre_execution_policy_check() behavior."""

    def test_skip_when_no_hitl(self, plugin, mock_context):
        options = InstrumentationOptions(name="test")
        # Should not raise — no HITL enabled
        plugin._pre_execution_policy_check(mock_context, options)

    def test_block_raises_error(self, plugin, mock_context):
        plugin.client = MagicMock()
        plugin.client.policy_check.return_value = PolicyCheckResult(
            action="block", triggered=True, reason="Policy violated", policy_ids=["pol-1"]
        )
        options = InstrumentationOptions(
            name="test",
            governance=GovernanceDirective(hitl=True),
        )
        with pytest.raises(GovernanceBlockedError) as exc_info:
            plugin._pre_execution_policy_check(mock_context, options)
        assert exc_info.value.reason == "Policy violated"
        assert exc_info.value.policy_ids == ["pol-1"]

    def test_allow_passes(self, plugin, mock_context):
        plugin.client = MagicMock()
        plugin.client.policy_check.return_value = PolicyCheckResult(
            action="allow", triggered=False
        )
        options = InstrumentationOptions(
            name="test",
            governance=GovernanceDirective(hitl=True),
        )
        # Should not raise
        plugin._pre_execution_policy_check(mock_context, options)

    def test_flag_passes(self, plugin, mock_context):
        plugin.client = MagicMock()
        plugin.client.policy_check.return_value = PolicyCheckResult(
            action="flag", triggered=True, reason="Flagged for review"
        )
        options = InstrumentationOptions(
            name="test",
            governance=GovernanceDirective(hitl=True),
        )
        # Flag should not block execution
        plugin._pre_execution_policy_check(mock_context, options)

    def test_network_error_failopen(self, plugin, mock_context):
        plugin.client = MagicMock()
        plugin.client.policy_check.side_effect = ConnectionError("timeout")
        options = InstrumentationOptions(
            name="test",
            governance=GovernanceDirective(hitl=True),
        )
        # Should not raise — fail-open
        plugin._pre_execution_policy_check(mock_context, options)


class TestContextStatus:
    """Test that context.finish() correctly sets status."""

    def test_blocked_status(self):
        ctx = ExecutionContext(
            run_id="r", operation="op", labels={}, metadata={}, args=()
        )
        error = GovernanceBlockedError(reason="test")
        ctx.finish(error=error)
        assert ctx.status == "blocked"

    def test_error_status(self):
        ctx = ExecutionContext(
            run_id="r", operation="op", labels={}, metadata={}, args=()
        )
        ctx.finish(error=ValueError("bad"))
        assert ctx.status == "error"

    def test_success_status(self):
        ctx = ExecutionContext(
            run_id="r", operation="op", labels={}, metadata={}, args=()
        )
        ctx.finish(result="ok")
        assert ctx.status == "success"


class TestWorkflowNamePriority:
    """Test that decorator name= takes precedence over config.workflow_name."""

    def test_decorator_name_wins(self, plugin):
        def dummy(): pass
        options = InstrumentationOptions(name="decorator-name")
        ctx = plugin._build_context(dummy, (), {}, options)
        assert ctx.workflow_name == "decorator-name"

    def test_config_name_fallback(self, plugin):
        def dummy(): pass
        options = InstrumentationOptions()
        ctx = plugin._build_context(dummy, (), {}, options)
        assert ctx.workflow_name == "test-workflow"


class TestAutoInit:
    """Test thread-safe auto-initialization."""

    def test_auto_init_from_env(self):
        import turingpulse_sdk.plugin as plugin_mod
        plugin_mod._PLUGIN = None
        with patch.dict(os.environ, {"TP_API_KEY": "auto-key", "TP_WORKFLOW_NAME": "auto-wf"}):
            p = get_plugin()
            assert p is not None
            assert p.config.api_key == "auto-key"
        plugin_mod._PLUGIN = None

    def test_auto_init_raises_without_env(self):
        import turingpulse_sdk.plugin as plugin_mod
        plugin_mod._PLUGIN = None
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("TP_API_KEY", None)
            with pytest.raises(Exception):
                get_plugin()
        plugin_mod._PLUGIN = None
