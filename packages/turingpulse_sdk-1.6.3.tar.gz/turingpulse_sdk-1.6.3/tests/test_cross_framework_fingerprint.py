"""Cross-framework fingerprint categorization tests.

Validates that config keys extracted by every supported LLM provider are
correctly classified into the right hash categories (model, eval, policy,
general).  Uses the actual CONFIG_KEYS lists from llm_detector.py to
ensure there is no drift between what the SDK extracts and what the
fingerprint builder categorises.
"""

import pytest
from turingpulse_sdk.fingerprint import (
    FingerprintBuilder,
    FingerprintConfig,
    classify_config_key,
    split_config,
)
from turingpulse_sdk.llm_detector import PROVIDERS


def _provider_keys(name: str) -> list:
    """Look up config_keys for a provider by name from the PROVIDERS registry."""
    for spec in PROVIDERS:
        if spec.name == name:
            return spec.config_keys
    raise ValueError(f"Unknown provider: {name}")


# ---------------------------------------------------------------------------
# Provider config key definitions (from PROVIDERS registry in llm_detector)
# ---------------------------------------------------------------------------

PROVIDER_CONFIGS = {
    "openai": {
        "keys": _provider_keys("openai"),
        "sample": {"model": "gpt-4o", "temperature": 0.7, "max_tokens": 2000,
                    "top_p": 0.9, "frequency_penalty": 0.1, "presence_penalty": 0.2, "stop": ["\n"]},
        "expected_model_keys": {"model", "temperature", "max_tokens", "top_p",
                                "frequency_penalty", "presence_penalty", "stop"},
        "expected_general_keys": set(),
    },
    "anthropic": {
        "keys": _provider_keys("anthropic"),
        "sample": {"model": "claude-3-opus", "temperature": 0.5, "max_tokens": 4096,
                    "top_p": 0.95, "stop_sequences": ["</answer>"]},
        "expected_model_keys": {"model", "temperature", "max_tokens", "top_p", "stop_sequences"},
        "expected_general_keys": set(),
    },
    "google": {
        "keys": _provider_keys("google"),
        "sample": {"model": "gemini-pro", "temperature": 0.8, "max_output_tokens": 1024,
                    "top_p": 0.9, "top_k": 40},
        "expected_model_keys": {"model", "temperature", "max_output_tokens", "top_p", "top_k"},
        "expected_general_keys": set(),
    },
    "vertexai": {
        "keys": _provider_keys("vertexai"),
        "sample": {"model": "gemini-1.5-pro", "temperature": 0.4, "max_output_tokens": 2048,
                    "top_p": 0.8, "top_k": 32, "candidate_count": 1},
        "expected_model_keys": {"model", "temperature", "max_output_tokens", "top_p", "top_k", "candidate_count"},
        "expected_general_keys": set(),
    },
    "langchain": {
        "keys": _provider_keys("langchain"),
        "sample": {"model_name": "gpt-4", "temperature": 0.7, "max_tokens": 1000,
                    "model_kwargs": {"seed": 42}},
        "expected_model_keys": {"model_name", "temperature", "max_tokens", "model_kwargs"},
        "expected_general_keys": set(),
    },
    "langgraph": {
        "keys": _provider_keys("langgraph"),
        "sample": {"model_name": "gpt-4o", "temperature": 0.5, "max_tokens": 1500,
                    "recursion_limit": 25, "configurable": {"thread_id": "abc"}},
        "expected_model_keys": {"model_name", "temperature", "max_tokens"},
        "expected_general_keys": {"recursion_limit", "configurable"},
    },
    "crewai": {
        "keys": _provider_keys("crewai"),
        "sample": {"model": "gpt-4o", "temperature": 0.3, "max_tokens": 500,
                    "verbose": True, "memory": True},
        "expected_model_keys": {"model", "temperature", "max_tokens"},
        "expected_general_keys": {"verbose", "memory"},
    },
    "autogen": {
        "keys": _provider_keys("autogen"),
        "sample": {"model": "gpt-4", "temperature": 0.0, "max_tokens": 2000,
                    "timeout": 120, "cache_seed": 42},
        "expected_model_keys": {"model", "temperature", "max_tokens"},
        "expected_general_keys": {"cache_seed"},
        "expected_policy_keys": {"timeout"},
    },
    "llamaindex": {
        "keys": _provider_keys("llamaindex"),
        "sample": {"model": "gpt-4", "temperature": 0.1, "max_tokens": 3000,
                    "context_window": 128000},
        "expected_model_keys": {"model", "temperature", "max_tokens", "context_window"},
        "expected_general_keys": set(),
    },
    "bedrock": {
        "keys": _provider_keys("bedrock"),
        "sample": {"modelId": "anthropic.claude-3-sonnet", "temperature": 0.7,
                    "maxTokens": 4096, "topP": 0.9, "stopSequences": ["</result>"]},
        "expected_model_keys": {"modelId", "temperature", "maxTokens", "topP", "stopSequences"},
        "expected_general_keys": set(),
    },
    "cohere": {
        "keys": _provider_keys("cohere"),
        "sample": {"model": "command-r-plus", "temperature": 0.3, "max_tokens": 1000,
                    "p": 0.9, "k": 40},
        "expected_model_keys": {"model", "temperature", "max_tokens", "p", "k"},
        "expected_general_keys": set(),
    },
    "mistral": {
        "keys": _provider_keys("mistral"),
        "sample": {"model": "mistral-large-latest", "temperature": 0.5,
                    "max_tokens": 2000, "top_p": 0.95},
        "expected_model_keys": {"model", "temperature", "max_tokens", "top_p"},
        "expected_general_keys": set(),
    },
}


# ---------------------------------------------------------------------------
# Per-key classification tests
# ---------------------------------------------------------------------------


class TestPerProviderKeyClassification:
    """Verify every extracted config key is classified into the correct category."""

    @pytest.mark.parametrize("provider,spec", list(PROVIDER_CONFIGS.items()))
    def test_all_keys_classified_correctly(self, provider: str, spec: dict):
        """Every key from a provider should be classified as model or general (not unknown)."""
        expected_model = spec["expected_model_keys"]
        expected_general = spec["expected_general_keys"]
        expected_policy = spec.get("expected_policy_keys", set())
        expected_eval = spec.get("expected_eval_keys", set())

        for key in spec["keys"]:
            category = classify_config_key(key)
            if key in expected_model:
                assert category == "model", \
                    f"[{provider}] Key '{key}' expected model, got {category}"
            elif key in expected_eval:
                assert category == "eval", \
                    f"[{provider}] Key '{key}' expected eval, got {category}"
            elif key in expected_policy:
                assert category == "policy", \
                    f"[{provider}] Key '{key}' expected policy, got {category}"
            elif key in expected_general:
                assert category == "general", \
                    f"[{provider}] Key '{key}' expected general, got {category}"
            else:
                # Any key not explicitly expected should be model or general
                assert category in ("model", "general", "eval", "policy"), \
                    f"[{provider}] Key '{key}' got unexpected category {category}"


# ---------------------------------------------------------------------------
# Full fingerprint generation per provider
# ---------------------------------------------------------------------------


class TestPerProviderFingerprint:
    """Verify that each provider's typical config produces the right hash categories."""

    @pytest.mark.parametrize("provider,spec", list(PROVIDER_CONFIGS.items()))
    def test_provider_fingerprint_has_model_hash(self, provider: str, spec: dict):
        """Every provider config should produce a model hash (all have 'model' or equivalent)."""
        builder = FingerprintBuilder(FingerprintConfig())
        builder.record_node(f"{provider}_llm", "llm", spec["sample"], "system prompt")
        fp = builder.get_fingerprint()

        node = f"{provider}_llm"

        # Every provider should have a model hash
        assert node in fp.node_model_hashes, \
            f"[{provider}] Expected model hash but got none. Config: {spec['sample']}"

        # Combined hash should always be present (backward compat)
        assert node in fp.node_config_hashes, \
            f"[{provider}] Missing combined config hash"

        # Prompt hash should be present
        assert node in fp.node_prompt_hashes, \
            f"[{provider}] Missing prompt hash"

    @pytest.mark.parametrize("provider,spec", list(PROVIDER_CONFIGS.items()))
    def test_provider_no_spurious_eval_or_policy(self, provider: str, spec: dict):
        """Standard provider configs should NOT produce eval or policy hashes."""
        builder = FingerprintBuilder(FingerprintConfig())
        builder.record_node(f"{provider}_llm", "llm", spec["sample"])
        fp = builder.get_fingerprint()

        node = f"{provider}_llm"
        expected_eval = spec.get("expected_eval_keys", set())
        expected_policy = spec.get("expected_policy_keys", set())

        if not expected_eval:
            assert node not in fp.node_eval_config_hashes, \
                f"[{provider}] Unexpected eval hash for standard config"
        if not expected_policy:
            assert node not in fp.node_policy_config_hashes, \
                f"[{provider}] Unexpected policy hash for standard config"


# ---------------------------------------------------------------------------
# Cross-provider change detection isolation
# ---------------------------------------------------------------------------


class TestCrossProviderChangeIsolation:
    """Verify that model changes are detected correctly across different providers."""

    @pytest.mark.parametrize("provider,spec", list(PROVIDER_CONFIGS.items()))
    def test_model_swap_detected_as_model_change(self, provider: str, spec: dict):
        """Swapping the model name should change the model hash but not other hashes."""
        config_v1 = dict(spec["sample"])
        config_v2 = dict(spec["sample"])

        # Find the model key for this provider
        model_key = None
        for k in spec["sample"]:
            if classify_config_key(k) == "model" and "model" in k.lower():
                model_key = k
                break

        if model_key is None:
            pytest.skip(f"No model key found for {provider}")

        config_v2[model_key] = "different-model-v2"

        b1 = FingerprintBuilder(FingerprintConfig())
        b1.record_node("llm", "llm", config_v1, "same prompt")
        fp1 = b1.get_fingerprint()

        b2 = FingerprintBuilder(FingerprintConfig())
        b2.record_node("llm", "llm", config_v2, "same prompt")
        fp2 = b2.get_fingerprint()

        # Model hash MUST change
        assert fp1.node_model_hashes["llm"] != fp2.node_model_hashes["llm"], \
            f"[{provider}] Model hash should change when model is swapped"

        # Prompt hash MUST NOT change
        assert fp1.node_prompt_hashes["llm"] == fp2.node_prompt_hashes["llm"], \
            f"[{provider}] Prompt hash should NOT change when only model swapped"

    @pytest.mark.parametrize("provider,spec", list(PROVIDER_CONFIGS.items()))
    def test_temperature_change_detected_as_model_change(self, provider: str, spec: dict):
        """Changing temperature should change the model hash."""
        if "temperature" not in spec["sample"]:
            pytest.skip(f"No temperature for {provider}")

        config_v1 = dict(spec["sample"])
        config_v2 = dict(spec["sample"])
        config_v2["temperature"] = 0.99  # changed

        b1 = FingerprintBuilder(FingerprintConfig())
        b1.record_node("llm", "llm", config_v1)
        fp1 = b1.get_fingerprint()

        b2 = FingerprintBuilder(FingerprintConfig())
        b2.record_node("llm", "llm", config_v2)
        fp2 = b2.get_fingerprint()

        assert fp1.node_model_hashes["llm"] != fp2.node_model_hashes["llm"], \
            f"[{provider}] Model hash should change when temperature changes"


# ---------------------------------------------------------------------------
# camelCase variant validation (critical for JS SDK / Bedrock / Google)
# ---------------------------------------------------------------------------


class TestCamelCaseKeyClassification:
    """Ensure camelCase config keys from TypeScript SDKs classify correctly."""

    @pytest.mark.parametrize("key,expected", [
        # Google / Vertex AI (TS SDK uses camelCase)
        ("maxOutputTokens", "model"),
        ("topP", "model"),
        ("topK", "model"),
        ("candidateCount", "model"),
        # LangChain / LangGraph (TS SDK)
        ("modelName", "model"),
        ("maxTokens", "model"),
        ("modelKwargs", "model"),
        # Bedrock (camelCase native)
        ("modelId", "model"),
        ("stopSequences", "model"),
        # AutoGen TS
        ("cacheSeed", "general"),
        # LangGraph TS
        ("recursionLimit", "general"),
        # CrewAI / LlamaIndex TS
        ("contextWindow", "model"),
    ])
    def test_camelcase_key(self, key: str, expected: str):
        assert classify_config_key(key) == expected, \
            f"Key '{key}' should classify as '{expected}' but got '{classify_config_key(key)}'"


# ---------------------------------------------------------------------------
# Eval and Policy augmented configs
# ---------------------------------------------------------------------------


class TestAugmentedConfigs:
    """Test provider configs augmented with eval/policy keys.

    In real workflows, users may add eval or policy config to their LLM nodes.
    These should be detected separately from model changes.
    """

    def test_openai_with_eval_config(self):
        config = {
            "model": "gpt-4o",
            "temperature": 0.7,
            "eval_criteria": "helpfulness",
            "eval_rubric": "1-5 scale",
        }
        builder = FingerprintBuilder(FingerprintConfig())
        builder.record_node("llm", "llm", config)
        fp = builder.get_fingerprint()

        assert "llm" in fp.node_model_hashes
        assert "llm" in fp.node_eval_config_hashes

    def test_anthropic_with_guardrail(self):
        config = {
            "model": "claude-3-opus",
            "temperature": 0.5,
            "guardrail": "pii_filter",
            "safety_threshold": 0.95,
        }
        builder = FingerprintBuilder(FingerprintConfig())
        builder.record_node("llm", "llm", config)
        fp = builder.get_fingerprint()

        assert "llm" in fp.node_model_hashes
        assert "llm" in fp.node_policy_config_hashes

    def test_langchain_with_eval_and_policy(self):
        config = {
            "model_name": "gpt-4",
            "temperature": 0.3,
            "eval_model": "gpt-4o-mini",
            "eval_criteria": "accuracy",
            "guardrail_config": {"toxicity": True},
        }
        builder = FingerprintBuilder(FingerprintConfig())
        builder.record_node("llm", "llm", config)
        fp = builder.get_fingerprint()

        assert "llm" in fp.node_model_hashes
        assert "llm" in fp.node_eval_config_hashes
        assert "llm" in fp.node_policy_config_hashes

    def test_changing_eval_does_not_affect_model_hash(self):
        config_v1 = {
            "model": "gpt-4o",
            "eval_criteria": "helpfulness",
        }
        config_v2 = {
            "model": "gpt-4o",
            "eval_criteria": "accuracy",  # changed
        }

        b1 = FingerprintBuilder(FingerprintConfig())
        b1.record_node("llm", "llm", config_v1)
        fp1 = b1.get_fingerprint()

        b2 = FingerprintBuilder(FingerprintConfig())
        b2.record_node("llm", "llm", config_v2)
        fp2 = b2.get_fingerprint()

        assert fp1.node_model_hashes["llm"] == fp2.node_model_hashes["llm"]
        assert fp1.node_eval_config_hashes["llm"] != fp2.node_eval_config_hashes["llm"]
