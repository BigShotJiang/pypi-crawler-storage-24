"""Unit tests for fingerprinting and change detection."""

import pytest
from turingpulse_sdk.fingerprint import (
    FingerprintBuilder,
    FingerprintConfig,
    FingerprintData,
    extract_prompt_from_messages,
    extract_config_subset,
)
from turingpulse_sdk.llm_detector import (
    LLMDetector,
    ToolDetector,
    detect_node_type,
    LLMCallInfo,
)


class TestFingerprintConfig:
    """Tests for FingerprintConfig."""

    def test_default_config(self):
        """Test default configuration values."""
        config = FingerprintConfig()
        assert config.enabled is True
        assert config.capture_prompts is True
        assert config.capture_configs is True
        assert config.capture_structure is True
        assert config.send_async is True
        assert config.send_on_failure is True
        assert "api_key" in config.sensitive_config_keys

    def test_custom_config(self):
        """Test custom configuration."""
        config = FingerprintConfig(
            enabled=False,
            capture_prompts=False,
            sensitive_config_keys=["custom_secret"],
        )
        assert config.enabled is False
        assert config.capture_prompts is False
        assert "custom_secret" in config.sensitive_config_keys


class TestFingerprintBuilder:
    """Tests for FingerprintBuilder."""

    def test_record_node(self):
        """Test recording nodes."""
        config = FingerprintConfig()
        builder = FingerprintBuilder(config)
        
        builder.record_node("llm_call", "llm", {"model": "gpt-4"}, "You are helpful")
        builder.record_node("search_tool", "tool", {"api": "google"})
        
        assert "llm_call" in builder.nodes
        assert "search_tool" in builder.nodes
        assert builder.node_types["llm_call"] == "llm"
        assert builder.node_types["search_tool"] == "tool"

    def test_node_type_counts(self):
        """Test node type counting."""
        config = FingerprintConfig()
        builder = FingerprintBuilder(config)
        
        builder.record_node("llm1", "llm")
        builder.record_node("llm2", "llm")
        builder.record_node("tool1", "tool")
        
        assert builder.node_type_counts["llm"] == 2
        assert builder.node_type_counts["tool"] == 1

    def test_edge_tracking(self):
        """Test parent-child edge tracking."""
        config = FingerprintConfig()
        builder = FingerprintBuilder(config)
        
        builder.record_node("parent", "function")
        builder.push_parent("parent")
        builder.record_node("child1", "llm")
        builder.record_node("child2", "tool")
        
        assert "parent->child1" in builder.edges
        assert "parent->child2" in builder.edges

    def test_nested_edges(self):
        """Test nested parent-child relationships."""
        config = FingerprintConfig()
        builder = FingerprintBuilder(config)
        
        builder.record_node("root", "function")
        builder.push_parent("root")
        builder.record_node("middle", "function")
        builder.push_parent("middle")
        builder.record_node("leaf", "llm")
        
        assert "root->middle" in builder.edges
        assert "middle->leaf" in builder.edges
        assert "root->leaf" not in builder.edges

    def test_sensitive_config_redaction(self):
        """Test that sensitive config keys are redacted."""
        config = FingerprintConfig()
        builder = FingerprintBuilder(config)
        
        builder.record_node("llm", "llm", {
            "model": "gpt-4",
            "api_key": "sk-secret-key",
            "temperature": 0.7,
        })
        
        # The config hash should not contain the actual API key
        # We can't easily verify this from outside, but we can check the hash exists
        assert "llm" in builder.node_configs

    def test_get_fingerprint(self):
        """Test getting the final fingerprint."""
        config = FingerprintConfig()
        builder = FingerprintBuilder(config)
        
        builder.record_node("main", "function")
        builder.push_parent("main")
        builder.record_node("llm", "llm", {"model": "gpt-4"}, "You are helpful")
        builder.record_node("tool", "tool", {"api": "search"})
        
        fingerprint = builder.get_fingerprint()
        
        assert isinstance(fingerprint, FingerprintData)
        assert len(fingerprint.structure_hash) > 0
        assert fingerprint.node_sequence == ["main", "llm", "tool"]
        assert fingerprint.node_types == {"function": 1, "llm": 1, "tool": 1}
        assert len(fingerprint.edges) == 2
        assert "llm" in fingerprint.node_config_hashes
        assert "llm" in fingerprint.node_prompt_hashes

    def test_duplicate_nodes_skipped(self):
        """Test that duplicate node names are skipped."""
        config = FingerprintConfig()
        builder = FingerprintBuilder(config)
        
        builder.record_node("same_name", "llm")
        builder.record_node("same_name", "tool")  # Should be skipped
        
        assert len(builder.nodes) == 1
        assert builder.node_types["same_name"] == "llm"

    def test_structure_hash_deterministic(self):
        """Test that structure hash is deterministic."""
        config = FingerprintConfig()
        
        builder1 = FingerprintBuilder(config)
        builder1.record_node("a", "llm")
        builder1.record_node("b", "tool")
        fp1 = builder1.get_fingerprint()
        
        builder2 = FingerprintBuilder(config)
        builder2.record_node("a", "llm")
        builder2.record_node("b", "tool")
        fp2 = builder2.get_fingerprint()
        
        assert fp1.structure_hash == fp2.structure_hash

    def test_different_structures_different_hashes(self):
        """Test that different structures produce different hashes."""
        config = FingerprintConfig()
        
        builder1 = FingerprintBuilder(config)
        builder1.record_node("a", "llm")
        builder1.record_node("b", "tool")
        fp1 = builder1.get_fingerprint()
        
        builder2 = FingerprintBuilder(config)
        builder2.record_node("a", "tool")  # Different type
        builder2.record_node("b", "llm")
        fp2 = builder2.get_fingerprint()
        
        assert fp1.structure_hash != fp2.structure_hash


class TestLLMDetector:
    """Tests for LLMDetector."""

    def test_detect_openai_chat(self):
        """Test OpenAI chat detection."""
        result = LLMDetector.detect_llm_call(
            func_name="create",
            func_qualname="chat.completions.create",
            args=(),
            kwargs={
                "model": "gpt-4",
                "temperature": 0.7,
                "messages": [
                    {"role": "system", "content": "You are helpful"},
                    {"role": "user", "content": "Hello"},
                ],
            },
        )
        
        assert result is not None
        assert result.provider == "openai"
        assert result.model == "gpt-4"
        assert result.prompt == "You are helpful"
        assert result.config.get("temperature") == 0.7

    def test_detect_anthropic(self):
        """Test Anthropic detection."""
        result = LLMDetector.detect_llm_call(
            func_name="create",
            func_qualname="messages.create",
            args=(),
            kwargs={
                "model": "claude-3",
                "system": "You are Claude",
                "messages": [{"role": "user", "content": "Hello"}],
            },
        )
        
        assert result is not None
        assert result.provider == "anthropic"
        assert result.prompt == "You are Claude"

    def test_non_llm_call(self):
        """Test that non-LLM calls return None."""
        result = LLMDetector.detect_llm_call(
            func_name="process_data",
            func_qualname="DataProcessor.process_data",
            args=(),
            kwargs={},
        )
        
        assert result is None


class TestToolDetector:
    """Tests for ToolDetector."""

    def test_detect_search_tool(self):
        """Test search tool detection."""
        result = ToolDetector.detect_tool_call(
            func_name="search_web",
            func_qualname="Tools.search_web",
            args=(),
            kwargs={},
        )
        assert result == "tool"

    def test_detect_retriever(self):
        """Test retriever detection."""
        result = ToolDetector.detect_tool_call(
            func_name="retrieve",
            func_qualname="VectorStoreRetriever.retrieve",
            args=(),
            kwargs={},
        )
        assert result == "retriever"

    def test_non_tool_call(self):
        """Test that non-tool calls return None."""
        result = ToolDetector.detect_tool_call(
            func_name="calculate",
            func_qualname="Math.calculate",
            args=(),
            kwargs={},
        )
        assert result is None


class TestDetectNodeType:
    """Tests for the unified detect_node_type function."""

    def test_llm_detection(self):
        """Test LLM node detection."""
        node_type, llm_info = detect_node_type(
            func_name="create",
            func_qualname="chat.completions.create",
            args=(),
            kwargs={"model": "gpt-4", "messages": []},
        )
        assert node_type == "llm"
        assert llm_info is not None
        assert llm_info.provider == "openai"

    def test_tool_detection(self):
        """Test tool node detection."""
        node_type, llm_info = detect_node_type(
            func_name="search",
            func_qualname="tools.search",
            args=(),
            kwargs={},
        )
        assert node_type == "tool"
        assert llm_info is None

    def test_function_fallback(self):
        """Test fallback to function type."""
        node_type, llm_info = detect_node_type(
            func_name="my_function",
            func_qualname="module.my_function",
            args=(),
            kwargs={},
        )
        assert node_type == "function"
        assert llm_info is None


class TestHelperFunctions:
    """Tests for helper functions."""

    def test_extract_prompt_from_messages(self):
        """Test system prompt extraction."""
        messages = [
            {"role": "system", "content": "You are helpful"},
            {"role": "user", "content": "Hello"},
        ]
        prompt = extract_prompt_from_messages(messages)
        assert prompt == "You are helpful"

    def test_extract_prompt_no_system(self):
        """Test extraction when no system message."""
        messages = [
            {"role": "user", "content": "Hello"},
        ]
        prompt = extract_prompt_from_messages(messages)
        assert prompt is None

    def test_extract_config_subset(self):
        """Test config subset extraction."""
        kwargs = {
            "model": "gpt-4",
            "temperature": 0.7,
            "max_tokens": 100,
            "irrelevant": "value",
        }
        subset = extract_config_subset(kwargs, ["model", "temperature", "missing"])
        assert subset == {"model": "gpt-4", "temperature": 0.7}

