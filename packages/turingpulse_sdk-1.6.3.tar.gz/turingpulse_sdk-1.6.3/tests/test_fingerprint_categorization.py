"""Thorough tests for fingerprint config categorisation and hash decomposition.

Tests cover:
  - Key classification (classify_config_key)
  - Config splitting (split_config)
  - FingerprintBuilder categorised hash generation
  - Backward compatibility (node_config_hashes still populated)
  - Determinism of categorised hashes
  - Change isolation (only the affected category hash changes)
  - Edge cases (empty config, non-dict config, mixed keys)
"""

import pytest
from turingpulse_sdk.fingerprint import (
    FingerprintBuilder,
    FingerprintConfig,
    FingerprintData,
    classify_config_key,
    split_config,
)


# ---------------------------------------------------------------------------
# classify_config_key
# ---------------------------------------------------------------------------


class TestClassifyConfigKey:
    """Tests for config key classification."""

    @pytest.mark.parametrize("key,expected", [
        # Model keys
        ("model", "model"),
        ("model_name", "model"),
        ("temperature", "model"),
        ("max_tokens", "model"),
        ("top_p", "model"),
        ("top_k", "model"),
        ("frequency_penalty", "model"),
        ("presence_penalty", "model"),
        ("stop", "model"),
        ("stop_sequences", "model"),
        ("response_format", "model"),
        ("context_window", "model"),
        ("model_kwargs", "model"),
        ("candidate_count", "model"),
        ("max_output_tokens", "model"),
        ("modelId", "model"),  # case-insensitive
        ("TEMPERATURE", "model"),  # upper-case
        ("Model_Name", "model"),  # mixed case
    ])
    def test_model_keys(self, key: str, expected: str):
        assert classify_config_key(key) == expected

    @pytest.mark.parametrize("key,expected", [
        # Eval keys (exact match)
        ("eval_model", "eval"),
        ("eval_prompt", "eval"),
        ("eval_criteria", "eval"),
        ("eval_rubric", "eval"),
        ("eval_config", "eval"),
        ("eval_threshold", "eval"),
        ("scoring_rubric", "eval"),
        ("scoring_model", "eval"),
        ("judge_model", "eval"),
        ("judge_prompt", "eval"),
        ("grading_rubric", "eval"),
        ("grading_criteria", "eval"),
        ("rubric", "eval"),
        ("criteria", "eval"),
        ("judge", "eval"),
        # Eval keys (prefix fallback)
        ("eval_custom_thing", "eval"),
        ("evaluation_my_setting", "eval"),
        ("scoring_threshold_v2", "eval"),
        ("judge_temperature", "eval"),
        ("grading_mode", "eval"),
    ])
    def test_eval_keys(self, key: str, expected: str):
        assert classify_config_key(key) == expected

    @pytest.mark.parametrize("key,expected", [
        # Policy keys (exact match)
        ("policy", "policy"),
        ("policy_config", "policy"),
        ("guardrail", "policy"),
        ("guardrails", "policy"),
        ("guard_config", "policy"),
        ("content_filter", "policy"),
        ("moderation", "policy"),
        ("moderation_config", "policy"),
        ("safety", "policy"),
        ("safety_config", "policy"),
        ("safety_threshold", "policy"),
        ("rate_limit", "policy"),
        ("max_retries", "policy"),
        ("timeout", "policy"),
        # Policy keys (prefix fallback)
        ("policy_v2_rules", "policy"),
        ("guardrail_endpoint", "policy"),
        ("filter_nsfw", "policy"),
        ("moderation_level", "policy"),
        ("safety_level_v2", "policy"),
    ])
    def test_policy_keys(self, key: str, expected: str):
        assert classify_config_key(key) == expected

    @pytest.mark.parametrize("key", [
        "api", "verbose", "memory", "cache_seed",
        "recursion_limit", "configurable", "custom_setting",
        "my_app_param", "batch_size", "output_format",
    ])
    def test_general_keys(self, key: str):
        assert classify_config_key(key) == "general"


# ---------------------------------------------------------------------------
# split_config
# ---------------------------------------------------------------------------


class TestSplitConfig:
    """Tests for split_config utility."""

    def test_empty_config(self):
        assert split_config({}) == {}

    def test_all_model_keys(self):
        config = {"model": "gpt-4", "temperature": 0.7, "max_tokens": 100}
        result = split_config(config)
        assert set(result.keys()) == {"model"}
        assert result["model"] == config

    def test_all_eval_keys(self):
        config = {"eval_model": "gpt-4", "eval_criteria": "accuracy"}
        result = split_config(config)
        assert set(result.keys()) == {"eval"}
        assert result["eval"] == config

    def test_all_policy_keys(self):
        config = {"guardrail": "pii_filter", "safety_threshold": 0.9}
        result = split_config(config)
        assert set(result.keys()) == {"policy"}
        assert result["policy"] == config

    def test_mixed_keys(self):
        config = {
            "model": "gpt-4",
            "temperature": 0.7,
            "eval_criteria": "accuracy",
            "guardrail": "pii",
            "verbose": True,
        }
        result = split_config(config)
        assert "model" in result
        assert result["model"] == {"model": "gpt-4", "temperature": 0.7}
        assert "eval" in result
        assert result["eval"] == {"eval_criteria": "accuracy"}
        assert "policy" in result
        assert result["policy"] == {"guardrail": "pii"}
        assert "general" in result
        assert result["general"] == {"verbose": True}

    def test_only_general_keys(self):
        config = {"verbose": True, "batch_size": 32}
        result = split_config(config)
        assert set(result.keys()) == {"general"}


# ---------------------------------------------------------------------------
# FingerprintBuilder — categorised hashes
# ---------------------------------------------------------------------------


class TestFingerprintBuilderCategorisedHashes:
    """Tests for the decomposed hash generation in FingerprintBuilder."""

    def _builder(self) -> FingerprintBuilder:
        return FingerprintBuilder(FingerprintConfig())

    def test_model_config_produces_model_hash(self):
        builder = self._builder()
        builder.record_node("my_llm", "llm", {"model": "gpt-4", "temperature": 0.7}, "prompt")
        fp = builder.get_fingerprint()

        assert "my_llm" in fp.node_model_hashes
        assert len(fp.node_model_hashes["my_llm"]) == 16  # 16-char hex

    def test_eval_config_produces_eval_hash(self):
        builder = self._builder()
        builder.record_node("evaluator", "llm", {
            "eval_model": "gpt-4",
            "eval_criteria": "accuracy",
            "eval_rubric": "score 1-5",
        })
        fp = builder.get_fingerprint()

        assert "evaluator" in fp.node_eval_config_hashes
        assert "evaluator" not in fp.node_model_hashes  # no model keys

    def test_policy_config_produces_policy_hash(self):
        builder = self._builder()
        builder.record_node("guardrailed", "llm", {
            "guardrail": "pii_filter",
            "safety_threshold": 0.9,
            "moderation": "strict",
        })
        fp = builder.get_fingerprint()

        assert "guardrailed" in fp.node_policy_config_hashes
        assert "guardrailed" not in fp.node_model_hashes

    def test_mixed_config_produces_all_category_hashes(self):
        builder = self._builder()
        builder.record_node("complex_node", "llm", {
            "model": "gpt-4o",
            "temperature": 0.5,
            "eval_criteria": "relevance",
            "guardrail": "toxicity",
            "verbose": True,
        }, "system prompt")
        fp = builder.get_fingerprint()

        assert "complex_node" in fp.node_model_hashes
        assert "complex_node" in fp.node_eval_config_hashes
        assert "complex_node" in fp.node_policy_config_hashes
        assert "complex_node" in fp.node_config_hashes  # legacy combined
        assert "complex_node" in fp.node_prompt_hashes

    def test_backward_compat_combined_hash_still_populated(self):
        """Legacy node_config_hashes must always be populated for backward compat."""
        builder = self._builder()
        builder.record_node("llm", "llm", {"model": "gpt-4", "temperature": 0.7})
        fp = builder.get_fingerprint()

        assert "llm" in fp.node_config_hashes
        assert len(fp.node_config_hashes["llm"]) == 16

    def test_no_config_produces_empty_hashes(self):
        builder = self._builder()
        builder.record_node("tool_node", "tool")  # no config
        fp = builder.get_fingerprint()

        assert "tool_node" not in fp.node_config_hashes
        assert "tool_node" not in fp.node_model_hashes
        assert "tool_node" not in fp.node_eval_config_hashes
        assert "tool_node" not in fp.node_policy_config_hashes

    def test_general_only_config_no_category_hashes(self):
        builder = self._builder()
        builder.record_node("tool", "tool", {"api": "google", "verbose": True})
        fp = builder.get_fingerprint()

        assert "tool" in fp.node_config_hashes  # combined
        assert "tool" not in fp.node_model_hashes
        assert "tool" not in fp.node_eval_config_hashes
        assert "tool" not in fp.node_policy_config_hashes


class TestFingerprintChangeIsolation:
    """Tests that changing one category hash does NOT affect other categories."""

    def _builder(self) -> FingerprintBuilder:
        return FingerprintBuilder(FingerprintConfig())

    def test_model_change_does_not_affect_eval_or_policy(self):
        """Changing model should only change model hash, not eval or policy."""
        builder1 = self._builder()
        builder1.record_node("llm", "llm", {
            "model": "gpt-4",
            "temperature": 0.7,
            "eval_criteria": "accuracy",
            "guardrail": "pii",
        })
        fp1 = builder1.get_fingerprint()

        builder2 = self._builder()
        builder2.record_node("llm", "llm", {
            "model": "gpt-4o",  # changed
            "temperature": 0.3,  # changed
            "eval_criteria": "accuracy",  # same
            "guardrail": "pii",  # same
        })
        fp2 = builder2.get_fingerprint()

        assert fp1.node_model_hashes["llm"] != fp2.node_model_hashes["llm"]
        assert fp1.node_eval_config_hashes["llm"] == fp2.node_eval_config_hashes["llm"]
        assert fp1.node_policy_config_hashes["llm"] == fp2.node_policy_config_hashes["llm"]

    def test_eval_change_does_not_affect_model_or_policy(self):
        builder1 = self._builder()
        builder1.record_node("llm", "llm", {
            "model": "gpt-4",
            "eval_criteria": "accuracy",
            "guardrail": "pii",
        })
        fp1 = builder1.get_fingerprint()

        builder2 = self._builder()
        builder2.record_node("llm", "llm", {
            "model": "gpt-4",
            "eval_criteria": "relevance",  # changed
            "guardrail": "pii",
        })
        fp2 = builder2.get_fingerprint()

        assert fp1.node_model_hashes["llm"] == fp2.node_model_hashes["llm"]
        assert fp1.node_eval_config_hashes["llm"] != fp2.node_eval_config_hashes["llm"]
        assert fp1.node_policy_config_hashes["llm"] == fp2.node_policy_config_hashes["llm"]

    def test_policy_change_does_not_affect_model_or_eval(self):
        builder1 = self._builder()
        builder1.record_node("llm", "llm", {
            "model": "gpt-4",
            "eval_criteria": "accuracy",
            "guardrail": "pii",
        })
        fp1 = builder1.get_fingerprint()

        builder2 = self._builder()
        builder2.record_node("llm", "llm", {
            "model": "gpt-4",
            "eval_criteria": "accuracy",
            "guardrail": "toxicity",  # changed
        })
        fp2 = builder2.get_fingerprint()

        assert fp1.node_model_hashes["llm"] == fp2.node_model_hashes["llm"]
        assert fp1.node_eval_config_hashes["llm"] == fp2.node_eval_config_hashes["llm"]
        assert fp1.node_policy_config_hashes["llm"] != fp2.node_policy_config_hashes["llm"]

    def test_prompt_change_does_not_affect_config_hashes(self):
        builder1 = self._builder()
        builder1.record_node("llm", "llm", {"model": "gpt-4"}, "You are helpful")
        fp1 = builder1.get_fingerprint()

        builder2 = self._builder()
        builder2.record_node("llm", "llm", {"model": "gpt-4"}, "You are a concise assistant")
        fp2 = builder2.get_fingerprint()

        assert fp1.node_prompt_hashes["llm"] != fp2.node_prompt_hashes["llm"]
        assert fp1.node_model_hashes["llm"] == fp2.node_model_hashes["llm"]
        assert fp1.node_config_hashes["llm"] == fp2.node_config_hashes["llm"]


class TestFingerprintDeterminism:
    """Tests that hashes are deterministic and reproducible."""

    def test_identical_configs_produce_identical_hashes(self):
        config = {"model": "gpt-4", "temperature": 0.7, "eval_criteria": "accuracy"}

        b1 = FingerprintBuilder(FingerprintConfig())
        b1.record_node("llm", "llm", config, "prompt")
        fp1 = b1.get_fingerprint()

        b2 = FingerprintBuilder(FingerprintConfig())
        b2.record_node("llm", "llm", config, "prompt")
        fp2 = b2.get_fingerprint()

        assert fp1.node_model_hashes == fp2.node_model_hashes
        assert fp1.node_eval_config_hashes == fp2.node_eval_config_hashes
        assert fp1.node_config_hashes == fp2.node_config_hashes
        assert fp1.node_prompt_hashes == fp2.node_prompt_hashes

    def test_key_order_does_not_affect_hash(self):
        """JSON serialization with sort_keys should ensure order independence."""
        b1 = FingerprintBuilder(FingerprintConfig())
        b1.record_node("llm", "llm", {"model": "gpt-4", "temperature": 0.7})
        fp1 = b1.get_fingerprint()

        b2 = FingerprintBuilder(FingerprintConfig())
        b2.record_node("llm", "llm", {"temperature": 0.7, "model": "gpt-4"})
        fp2 = b2.get_fingerprint()

        assert fp1.node_model_hashes["llm"] == fp2.node_model_hashes["llm"]
        assert fp1.node_config_hashes["llm"] == fp2.node_config_hashes["llm"]


class TestFingerprintEdgeCases:
    """Edge case tests for robustness."""

    def test_non_dict_config_produces_combined_hash_only(self):
        """Non-dict configs can't be split but should still work."""
        builder = FingerprintBuilder(FingerprintConfig())
        builder.record_node("weird", "function", "just_a_string")
        fp = builder.get_fingerprint()

        assert "weird" in fp.node_config_hashes
        assert "weird" not in fp.node_model_hashes

    def test_empty_dict_config(self):
        builder = FingerprintBuilder(FingerprintConfig())
        builder.record_node("empty", "tool", {})
        fp = builder.get_fingerprint()

        assert "empty" in fp.node_config_hashes  # hash of {}
        assert "empty" not in fp.node_model_hashes

    def test_sensitive_keys_redacted_before_categorisation(self):
        builder = FingerprintBuilder(FingerprintConfig())
        builder.record_node("llm", "llm", {
            "model": "gpt-4",
            "api_key": "sk-secret",  # should be redacted
        })
        fp = builder.get_fingerprint()

        assert "llm" in fp.node_model_hashes
        # The hash should be based on the redacted version
        builder2 = FingerprintBuilder(FingerprintConfig())
        builder2.record_node("llm", "llm", {
            "model": "gpt-4",
            "api_key": "sk-different-key",
        })
        fp2 = builder2.get_fingerprint()

        # Both should produce same hash since api_key is redacted to [REDACTED]
        assert fp.node_config_hashes["llm"] == fp2.node_config_hashes["llm"]

    def test_multi_node_workflow(self):
        """Realistic multi-node workflow with different config categories per node."""
        builder = FingerprintBuilder(FingerprintConfig())

        builder.record_node("main", "function")
        builder.push_parent("main")

        builder.record_node("chat_llm", "llm", {
            "model": "gpt-4o",
            "temperature": 0.7,
            "max_tokens": 2000,
        }, "You are a helpful customer support agent")

        builder.record_node("guardrail_check", "llm", {
            "model": "gpt-4o-mini",
            "guardrail": "toxicity_filter",
            "safety_threshold": 0.95,
        })

        builder.record_node("evaluator", "llm", {
            "eval_model": "gpt-4",
            "eval_criteria": "helpfulness",
            "scoring_rubric": "1-5 scale",
        })

        builder.record_node("search_tool", "tool", {"api": "google", "max_results": 5})

        fp = builder.get_fingerprint()

        # chat_llm: model hash
        assert "chat_llm" in fp.node_model_hashes
        assert "chat_llm" not in fp.node_eval_config_hashes
        assert "chat_llm" not in fp.node_policy_config_hashes

        # guardrail_check: model hash + policy hash
        assert "guardrail_check" in fp.node_model_hashes
        assert "guardrail_check" in fp.node_policy_config_hashes
        assert "guardrail_check" not in fp.node_eval_config_hashes

        # evaluator: eval hash only
        assert "evaluator" in fp.node_eval_config_hashes
        assert "evaluator" not in fp.node_model_hashes  # eval_model maps to eval, not model

        # search_tool: no categorised hashes (all general)
        assert "search_tool" not in fp.node_model_hashes
        assert "search_tool" not in fp.node_eval_config_hashes
        assert "search_tool" not in fp.node_policy_config_hashes
        assert "search_tool" in fp.node_config_hashes  # combined

    def test_fingerprint_data_serialization(self):
        """FingerprintData should serialize to dict with all new fields."""
        builder = FingerprintBuilder(FingerprintConfig())
        builder.record_node("llm", "llm", {
            "model": "gpt-4",
            "eval_criteria": "accuracy",
            "guardrail": "pii",
        }, "system prompt")
        fp = builder.get_fingerprint()

        data = fp.model_dump()
        assert "node_model_hashes" in data
        assert "node_eval_config_hashes" in data
        assert "node_policy_config_hashes" in data
        assert "node_config_hashes" in data
        assert "node_prompt_hashes" in data
