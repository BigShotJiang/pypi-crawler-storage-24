"""Robustness tests — SDK must never crash customer code."""

from __future__ import annotations

import asyncio
import threading
from unittest.mock import MagicMock, patch

import pytest

from turingpulse_sdk import init, instrument, GovernanceDirective
from turingpulse_sdk.exceptions import GovernanceBlockedError


@pytest.fixture(autouse=True)
def setup_plugin():
    import turingpulse_sdk.plugin as pm
    pm._PLUGIN = None
    plugin = init(api_key="robustness-key", workflow_name="robustness-test")
    plugin.client = MagicMock()
    plugin.client.emit_serialized_payload = MagicMock()
    plugin.client.policy_check = MagicMock(return_value=MagicMock(action="allow", blocked=False))
    yield plugin
    pm._PLUGIN = None


class TestNoCrash:
    """SDK must never crash customer code even on internal failures."""

    def test_emit_failure_does_not_crash(self, setup_plugin):
        setup_plugin.client.emit_serialized_payload.side_effect = ConnectionError("boom")

        @instrument(name="robustness-test")
        def my_func():
            return 42

        result = my_func()
        assert result == 42

    def test_governance_failure_does_not_crash(self, setup_plugin):
        setup_plugin.governance = MagicMock()
        setup_plugin.governance.enforce.side_effect = RuntimeError("governance down")

        @instrument(name="robustness-test")
        def my_func():
            return "ok"

        result = my_func()
        assert result == "ok"

    def test_fingerprint_failure_does_not_crash(self, setup_plugin):
        setup_plugin.client.post_fingerprint = MagicMock(side_effect=RuntimeError("fp error"))

        @instrument(name="robustness-test")
        def my_func():
            return "safe"

        result = my_func()
        assert result == "safe"


class TestConcurrency:
    """Test thread-safety of the SDK."""

    def test_concurrent_instrumented_calls(self, setup_plugin):
        results = []
        errors = []

        @instrument(name="concurrent-test")
        def worker(n):
            return n * 2

        def thread_fn(n):
            try:
                results.append(worker(n))
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=thread_fn, args=(i,)) for i in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0
        assert len(results) == 20
        assert sorted(results) == [i * 2 for i in range(20)]


class TestLargePayloads:
    """Test that large inputs/outputs don't crash the SDK."""

    def test_large_return_value(self, setup_plugin):
        @instrument(name="large-payload-test")
        def big_result():
            return "x" * 10_000_000  # 10 MB string

        result = big_result()
        assert len(result) == 10_000_000
