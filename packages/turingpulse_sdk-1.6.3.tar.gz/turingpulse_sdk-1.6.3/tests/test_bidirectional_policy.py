"""Tests for bidirectional (pre + post) execution policy check logic.

Validates that:
- Pre-check extracts input_text from LLM messages and tool_args
- Post-check sends output_text with correct check_phase
- Post-check blocks execution on 'block' action
- Context.result is preserved when post-check blocks (for audit)
- Fail-open / fail-closed modes work for post-check infrastructure errors
- Generator post-check is audit-only (metadata, no raise)
- Garbage output detection skips post-check
- governance.enforce() is called exactly once even with bidirectional checks
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from turingpulse_sdk import init, instrument
from turingpulse_sdk.client import PolicyCheckResult
from turingpulse_sdk.config import GovernanceDefaults, TuringPulseConfig
from turingpulse_sdk.context import ExecutionContext
from turingpulse_sdk.exceptions import GovernanceBlockedError
from turingpulse_sdk.governance import GovernanceDirective
from turingpulse_sdk.instrumentation import InstrumentationOptions
from turingpulse_sdk.plugin import TuringPulsePlugin


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _allow():
    return PolicyCheckResult(action="allow", triggered=False)


def _block(reason="Policy violation", policy_ids=None):
    return PolicyCheckResult(
        action="block",
        triggered=True,
        reason=reason,
        policy_ids=policy_ids or ["pol-output-1"],
    )


def _make_context(**overrides):
    """Build an ExecutionContext with sane defaults for unit-level tests."""
    defaults = dict(
        run_id="run-bidir-001",
        operation="test-op",
        labels={},
        metadata={},
        args=(),
        kwargs={},
        workflow_name="bidir-test",
        node_type="function",
        span_id="span-bidir-001",
    )
    defaults.update(overrides)
    return ExecutionContext(**defaults)


def _local_plugin(**config_overrides):
    """Create a detached plugin (not global) with mocked HTTP client."""
    defaults = dict(api_key="test-key-bidir", workflow_name="bidir-test")
    defaults.update(config_overrides)
    config = TuringPulseConfig(**defaults)
    p = TuringPulsePlugin(config)
    p.client = MagicMock()
    p.client.serialize_events.return_value = b"{}"
    return p


def _global_plugin(**overrides):
    """Init the global singleton plugin with mocked HTTP client."""
    defaults = dict(api_key="test-key-bidir", workflow_name="bidir-test")
    defaults.update(overrides)
    plugin = init(**defaults)
    plugin.client = MagicMock()
    plugin.client.serialize_events.return_value = b"{}"
    plugin.client.emit_serialized_payload = MagicMock()
    plugin.client.policy_check = MagicMock(return_value=_allow())
    return plugin


@pytest.fixture(autouse=True)
def _reset_plugin():
    """Ensure clean global plugin state between tests."""
    import turingpulse_sdk.plugin as pm
    pm._PLUGIN = None
    yield
    pm._PLUGIN = None


# ---------------------------------------------------------------------------
# 1. Pre-check sends input_text for LLM-style calls
# ---------------------------------------------------------------------------

class TestPreCheckInputExtraction:

    def test_pre_check_extracts_input_from_messages(self):
        """Pre-check payload includes input_text from LLM-style messages kwarg."""
        plugin = _local_plugin()
        plugin.client.policy_check.return_value = _allow()

        context = _make_context(
            kwargs={
                "messages": [
                    {"role": "system", "content": "You are a financial analyst."},
                    {"role": "user", "content": "Summarize the quarterly earnings report"},
                ]
            }
        )
        options = InstrumentationOptions(
            name="llm-call",
            governance=GovernanceDirective(hitl=True),
        )

        plugin._pre_execution_policy_check(context, options)

        plugin.client.policy_check.assert_called_once()
        payload = plugin.client.policy_check.call_args[1]
        assert "input_text" in payload
        assert "Summarize the quarterly earnings report" in payload["input_text"]
        assert "financial analyst" not in payload["input_text"]
        assert payload["check_phase"] == "pre_execution"


# ---------------------------------------------------------------------------
# 9. Pre-check still works with tool_args
# ---------------------------------------------------------------------------

    def test_pre_check_extracts_input_from_tool_args(self):
        """Pre-check payload includes input_text from tool_args (existing behavior preserved)."""
        plugin = _local_plugin()
        plugin.client.policy_check.return_value = _allow()

        context = _make_context(
            tool_name="get_weather_forecast",
            tool_args={"city": "San Francisco", "units": "celsius"},
        )
        options = InstrumentationOptions(
            name="tool-call",
            governance=GovernanceDirective(hitl=True),
        )

        plugin._pre_execution_policy_check(context, options)

        payload = plugin.client.policy_check.call_args[1]
        assert "input_text" in payload
        assert "San Francisco" in payload["input_text"]
        assert payload["tool_name"] == "get_weather_forecast"
        assert payload["tool_args"] == {"city": "San Francisco", "units": "celsius"}


# ---------------------------------------------------------------------------
# 2. Post-check sends output_text
# ---------------------------------------------------------------------------

class TestPostCheckPayload:

    def test_post_check_sends_output_text(self):
        """Post-check payload includes output_text from context after finish."""
        plugin = _local_plugin(governance_defaults=GovernanceDefaults(hitl=True))
        plugin.client.policy_check.return_value = _allow()

        output = "Quarterly revenue increased by 15% to $2.3M, driven by enterprise growth."
        context = _make_context()
        context.finish(result=output)

        options = InstrumentationOptions(name="report-gen")

        plugin._post_execution_policy_check(context, options, output)

        plugin.client.policy_check.assert_called_once()
        payload = plugin.client.policy_check.call_args[1]
        assert "output_text" in payload
        assert "Quarterly revenue" in payload["output_text"]
        assert payload["check_phase"] == "post_execution"


# ---------------------------------------------------------------------------
# 3. Post-check blocks on block action (sync)
# ---------------------------------------------------------------------------

class TestPostCheckBlocksSync:

    def test_post_check_blocks_sync(self):
        """Post-check raises GovernanceBlockedError on block action in sync path."""
        plugin = _global_plugin(governance_defaults=GovernanceDefaults(hitl=True))
        plugin.client.policy_check.return_value = _block(
            reason="Output contains PII data",
            policy_ids=["pol-pii-001"],
        )

        @instrument(name="bidir-test")
        def generate_customer_report():
            return "Customer John Doe, SSN 123-45-6789 lives at 742 Evergreen Terrace"

        with pytest.raises(GovernanceBlockedError) as exc_info:
            generate_customer_report()

        assert "PII data" in exc_info.value.reason
        assert "pol-pii-001" in exc_info.value.policy_ids


# ---------------------------------------------------------------------------
# 4. Post-check preserves context.result when blocking
# ---------------------------------------------------------------------------

class TestPostCheckPreservesResult:

    def test_post_check_preserves_result_on_block(self):
        """When post-check blocks, context.result is preserved for audit (not erased)."""
        plugin = _global_plugin(governance_defaults=GovernanceDefaults(hitl=True))

        def _phase_aware_check(**kwargs):
            if kwargs.get("check_phase") == "pre_execution":
                return _allow()
            return _block(reason="Sensitive content detected")

        plugin.client.policy_check.side_effect = _phase_aware_check

        finalized: dict = {}
        orig_finalize = TuringPulsePlugin._finalize

        def spy_finalize(self, ctx, opts, res, err, is_async=False):
            finalized["context"] = ctx
            return orig_finalize(self, ctx, opts, res, err, is_async=is_async)

        with patch.object(TuringPulsePlugin, "_finalize", spy_finalize):

            @instrument(name="bidir-test")
            def generate_revenue_forecast():
                return "Confidential: Revenue forecast for Q3 2026 is $4.5M"

            with pytest.raises(GovernanceBlockedError):
                generate_revenue_forecast()

        ctx = finalized["context"]
        assert ctx.result is not None
        assert "Revenue forecast" in str(ctx.result)
        assert ctx.status == "blocked"


# ---------------------------------------------------------------------------
# 5. Post-check fail-open mode
# ---------------------------------------------------------------------------

class TestPostCheckFailMode:

    def test_post_check_fail_open(self):
        """When post-check HTTP fails and mode is 'open', result is still returned."""
        plugin = _global_plugin(governance_defaults=GovernanceDefaults(hitl=True), policy_fail_mode="open")
        plugin.client.policy_check.side_effect = ConnectionError("backend unreachable")

        @instrument(name="bidir-test")
        def translate_financial_summary():
            return "Le rapport trimestriel montre une croissance de 15%"

        result = translate_financial_summary()
        assert result == "Le rapport trimestriel montre une croissance de 15%"

    # -------------------------------------------------------------------
    # 6. Post-check fail-closed mode
    # -------------------------------------------------------------------

    def test_post_check_fail_closed(self):
        """When post-check HTTP fails and mode is 'closed', GovernanceBlockedError is raised."""
        plugin = _global_plugin(governance_defaults=GovernanceDefaults(hitl=True), policy_fail_mode="closed")
        plugin.client.policy_check.side_effect = ConnectionError("backend unreachable")

        @instrument(name="bidir-test")
        def translate_financial_summary():
            return "Le rapport trimestriel montre une croissance de 15%"

        with pytest.raises(GovernanceBlockedError) as exc_info:
            translate_financial_summary()
        assert "fail-closed" in exc_info.value.reason


# ---------------------------------------------------------------------------
# 7. Generator post-check is audit-only
# ---------------------------------------------------------------------------

class TestGeneratorPostCheck:

    def test_generator_post_check_audit_only(self):
        """Generator/streaming post-check sets metadata but does not raise."""
        plugin = _global_plugin(governance_defaults=GovernanceDefaults(hitl=True))

        def _phase_aware_check(**kwargs):
            if kwargs.get("check_phase") == "pre_execution":
                return _allow()
            return _block(reason="Stream output violation")

        plugin.client.policy_check.side_effect = _phase_aware_check

        finalized: dict = {}
        orig_finalize = TuringPulsePlugin._finalize

        def spy_finalize(self, ctx, opts, res, err, is_async=False):
            finalized["context"] = ctx
            return orig_finalize(self, ctx, opts, res, err, is_async=is_async)

        with patch.object(TuringPulsePlugin, "_finalize", spy_finalize):

            @instrument(name="bidir-test")
            def stream_analysis():
                yield "The quarterly earnings "
                yield "show a 15% increase "
                yield "compared to last year."

            chunks = list(stream_analysis())

        assert len(chunks) == 3
        assert "quarterly earnings" in chunks[0]

        ctx = finalized["context"]
        assert ctx.metadata.get("post_policy.action") == "block"
        assert ctx.status == "success"


# ---------------------------------------------------------------------------
# 8. Post-check skips garbage output
# ---------------------------------------------------------------------------

class TestPostCheckSkipsGarbage:

    def test_post_check_skips_garbage_output(self):
        """Post-check skips when output looks like unconsumed Stream object."""
        plugin = _global_plugin(governance_defaults=GovernanceDefaults(hitl=True))

        def _phase_aware_check(**kwargs):
            if kwargs.get("check_phase") == "pre_execution":
                return _allow()
            return _block(reason="should never reach policy engine")

        plugin.client.policy_check.side_effect = _phase_aware_check

        class _FakeOpenAIStream:
            def __repr__(self):
                return "<openai.Stream object at 0x7f9a8b123456>"

        @instrument(name="bidir-test")
        def get_stream_object():
            return _FakeOpenAIStream()

        result = get_stream_object()
        assert isinstance(result, _FakeOpenAIStream)

        assert plugin.client.policy_check.call_count == 1
        assert plugin.client.policy_check.call_args[1]["check_phase"] == "pre_execution"


# ---------------------------------------------------------------------------
# 10. No duplicate enforce() calls with bidirectional checks
# ---------------------------------------------------------------------------

class TestSingleEnforceCall:

    def test_single_enforce_call_with_bidirectional_checks(self):
        """With both pre and post checks, governance.enforce() is called exactly once in finalize."""
        plugin = _global_plugin(governance_defaults=GovernanceDefaults(hitl=True))
        plugin.client.policy_check.return_value = _allow()
        plugin.governance = MagicMock()

        @instrument(
            name="bidir-test",
            governance=GovernanceDirective(hitl=True),
        )
        def process_customer_order():
            return "Order #ORD-2026-0042 processed successfully for Acme Corp"

        result = process_customer_order()
        assert result == "Order #ORD-2026-0042 processed successfully for Acme Corp"

        assert plugin.client.policy_check.call_count == 2
        pre_call, post_call = plugin.client.policy_check.call_args_list
        assert pre_call[1]["check_phase"] == "pre_execution"
        assert post_call[1]["check_phase"] == "post_execution"

        assert plugin.governance.enforce.call_count == 1
