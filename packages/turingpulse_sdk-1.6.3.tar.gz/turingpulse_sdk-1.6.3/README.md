# TuringPulse Python SDK

End-to-end instrumentation helpers that let any Python service publish telemetry to the Agent Observability Service, open governance tasks in the Agent PM Service, and register agent entrypoints without touching the host application's core configuration.

## Framework Compatibility

<!-- COMPAT-BADGES:START -->
![AWS Bedrock](https://img.shields.io/badge/AWS%20Bedrock-passing-brightgreen) ![Mistral](https://img.shields.io/badge/Mistral-passing-brightgreen)
<!-- COMPAT-BADGES:END -->

<details>
<summary>Full Compatibility Matrix</summary>

<!-- COMPAT-MATRIX:START -->
| Framework | Version | Python 3.11 | Python 3.12 | Python 3.13 |
|---|---| ---| ---| --- |
| AWS Bedrock | 1.42.73 | -- | -- | pass |
| Mistral | 0.4.0 | pass | -- | -- |
| Mistral | 2.1.2 | -- | pass | -- |
<!-- COMPAT-MATRIX:END -->

</details>

## Highlights

- `TuringPulsePlugin.init(...)` bootstraps connectivity (base URLs, tenant headers, API keys, tracing defaults).
- `@turingpulse.instrument(...)` decorator captures latency, status, errors, KPI mappings, and governance directives (HITL/HATL/HOTL) for both sync and async functions.
- Automatic OpenTelemetry span management with optional custom labels and KPI-derived attributes.
- Governance helper automatically creates PM tasks and HITL actions with reviewer/escalation metadata.
- Trigger registry lets you invoke decorated agent entrypoints that are not exposed via HTTP/UI endpoints.

## Quickstart

```bash
pip install -e packages/interfaces-py          # shared models
pip install -e packages/turingpulse-sdk
```

```python
from turingpulse_sdk import TuringPulseConfig, init, instrument, GovernanceDirective, KPIConfig

# Minimal setup — only API key and workflow name (URLs and tenant/project resolved automatically)
init(
    TuringPulseConfig(
        api_key="sk_...",
        workflow_name="My Workflow",
        use_ingestion_service=True,
    )
)

# Or with explicit URLs/tenant (e.g. self-hosted or overrides)
init(
    TuringPulseConfig(
        api_key="sk_...",
        workflow_name="My Workflow",
        pm_url="http://localhost:8002",
        ingestion_url="http://localhost:8004",
        use_ingestion_service=True,
    )
)


@instrument(
    agent_id="agent-research",
    operation="market_scan",
    labels={"surface": "slack"},
    governance=GovernanceDirective(hitl=True, reviewers=["audit@org.com"]),
    kpis=[
        KPIConfig(kpi_id="latency_ms", use_duration=True, alert_threshold=8000, comparator="gt"),
    ],
    trigger_key="hidden.market_scan",
)
def run_market_scan(query: str) -> dict:
    ...
```

## Decorator Options

| Option | Description |
| --- | --- |
| `agent_id` | Required Agent identifier used by observability + governance |
| `operation` | Logical operation name; defaults to function __name__ |
| `labels` | Dict merged with global defaults and exposed to traces/custom metrics |
| `trace` | Enable/disable tracing per function |
| `trigger_key` | Registers callable for manual triggering via `TuringPulsePlugin.trigger_agent` |
| `governance` | `GovernanceDirective` describing HITL/HATL/HOTL expectations |
| `kpis` | List of `KPIConfig` definitions to emit custom metrics + alerts |
| `trigger_hidden_agent` | When True, plugin calls the agent even if it's hidden from UI |

## Manual Triggers

```python
from turingpulse_sdk import get_plugin

get_plugin().trigger_agent("hidden.market_scan", query="pricing updates")
```

## KPI & Alerting

- KPIs can derive values from runtime context via callables (`lambda ctx: len(ctx.result["items"])`).
- When `alert_threshold` is crossed, the plugin attaches `metric.alert=true` metadata so the observability service can raise KPI alerts downstream.

## Governance

`GovernanceDirective` supports HITL (human-in-the-loop), HATL (human-after-the-loop), and HOTL (human-on-the-loop) patterns. The directive controls:

- which reviewer queues/tasks to open in the PM service,
- escalation channels & metadata,
- auto-escalation timers,
- whether the invocation should block on HITL.

## Security

The SDK includes built-in protections to ensure safe operation in customer environments:

### Endpoint Validation
- **SSRF protection**: Private/internal IP ranges (`127.0.0.0/8`, `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`, `169.254.0.0/16`, `localhost`, `[::1]`) are blocked as endpoints.
- **CRLF injection prevention**: Newline and null characters are stripped from API keys and endpoint URLs.
- **TLS enforcement**: The SDK emits a warning if an `http://` endpoint is used instead of `https://`.

### Data Protection
- **Sensitive field redaction**: Use `redact_fields` in `TuringPulseConfig` to mask sensitive keys before telemetry leaves your environment.
- **Error sanitization**: Error messages in telemetry do not include stack traces or internal paths.
- **No content truncation**: The SDK does not truncate or limit content size — backend handles that.

```python
init(TuringPulseConfig(
    api_key="sk_...",
    workflow_name="My Workflow",
    redact_fields=["password", "api_key", "secret", "token", "authorization"],
))
```

### File Attachments
- **Path traversal prevention**: `attach_document()` normalises file paths and rejects symlinks, device files, and directory traversal patterns.
- **Filename sanitisation**: Control characters and path components are stripped from filenames.

### Network Safety
- **Retry-After compliance**: The SDK respects `Retry-After` headers from 429 responses.
- **No retry on terminal errors**: 401, 402, 403, 404 responses stop retries immediately.
- **Timeout cap**: HTTP timeout is capped at 120 seconds.

## Fingerprinting & Change Detection

The SDK automatically captures workflow fingerprints to enable root cause analysis when anomalies or drifts are detected. This works out-of-the-box with zero configuration.

### How It Works

1. The SDK automatically detects LLM calls (OpenAI, Anthropic, LangChain, etc.)
2. Prompts and configurations are hashed for change detection
3. Workflow structure (nodes and edges) is tracked
4. Fingerprints are sent to the backend after each run
5. When anomalies occur, changes are correlated for root cause attribution

### Configuration

```python
from turingpulse_sdk import init, FingerprintConfig

init(
    observability_url="http://localhost:8001/v1",
    tenant_id="tenant-42",
    fingerprint=FingerprintConfig(
        enabled=True,              # Master switch (default: True)
        capture_prompts=True,      # Hash prompts for change detection
        capture_configs=True,      # Hash configs for change detection
        capture_structure=True,    # Track DAG structure
        sensitive_config_keys=[    # Keys to redact before hashing
            "api_key", "password", "secret", "token"
        ],
        send_async=True,           # Send fingerprints asynchronously
        send_on_failure=True,      # Send even if run fails
    )
)
```

### Deploy Tracking

Register deployments to correlate anomalies with code changes:

```python
from turingpulse_sdk import register_deploy
import os

# Auto-detect from CI/CD environment (GitHub Actions, GitLab CI, etc.)
register_deploy(
    workflow_id="chat-assistant",
    auto_detect=True,
)

# Or provide explicit values
register_deploy(
    workflow_id="chat-assistant",
    version="v1.2.3",
    git_sha=os.getenv("GIT_SHA"),
    commit_message=os.getenv("GIT_COMMIT_MSG"),
)
```

Supported CI/CD environments for auto-detection:
- GitHub Actions
- GitLab CI
- CircleCI
- Jenkins
- Azure DevOps
- Bitbucket Pipelines
- Travis CI

## Roadmap

- Typed FastAPI/Flask middleware shims
- Async batch exporter for very high volume workloads
- Richer KPI authoring toolkit and alert subscriptions


