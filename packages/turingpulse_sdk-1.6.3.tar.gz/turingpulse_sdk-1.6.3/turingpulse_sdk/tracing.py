"""OpenTelemetry helpers with GenAI semantic convention support.

Enhanced to support:
- ``gen_ai.system``, ``gen_ai.request.model``, ``gen_ai.response.model``
- ``gen_ai.usage.input_tokens``, ``gen_ai.usage.output_tokens``
- ``SpanKind.CLIENT`` for LLM calls (instead of always ``INTERNAL``)
- Automatic enrichment from ``ExecutionContext`` telemetry fields
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING, Dict, Iterator, Optional

from opentelemetry import trace
from opentelemetry.trace import Span, SpanKind

from .config import TuringPulseConfig

if TYPE_CHECKING:
    from .context import ExecutionContext

# ── GenAI Semantic Convention attribute keys ──
# See: https://opentelemetry.io/docs/specs/semconv/gen-ai/
GEN_AI_SYSTEM = "gen_ai.system"
GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
GEN_AI_RESPONSE_MODEL = "gen_ai.response.model"
GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
GEN_AI_USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
GEN_AI_USAGE_COST = "gen_ai.usage.cost"


class TracingManager:
    def __init__(self, config: TuringPulseConfig):
        self._config = config
        self._tracer = trace.get_tracer(config.trace_service_name)

    @contextmanager
    def span(
        self,
        name: str,
        attributes: Optional[Dict[str, str]] = None,
        enabled: bool = True,
        *,
        node_type: Optional[str] = None,
        context: Optional["ExecutionContext"] = None,
    ) -> Iterator[Span | None]:
        """Create an OpenTelemetry span with optional GenAI attributes.

        Args:
            name: Span name.
            attributes: Static key-value attributes.
            enabled: Whether tracing is enabled.
            node_type: If ``"llm"``, uses ``SpanKind.CLIENT`` instead of
                ``INTERNAL`` and sets GenAI semantic convention attributes.
            context: If provided, GenAI attributes (model, provider,
                tokens, cost) are extracted from the context after the
                span body executes and set as span attributes.
        """
        if not self._config.trace_enabled or not enabled:
            yield None
            return

        kind = SpanKind.CLIENT if node_type == "llm" else SpanKind.INTERNAL

        with self._tracer.start_as_current_span(name, kind=kind) as span:
            # Static attributes
            if attributes:
                for key, value in attributes.items():
                    span.set_attribute(key, value)

            # Pre-execution GenAI attributes from context (model/provider)
            if context and context.model:
                span.set_attribute(GEN_AI_SYSTEM, context.provider or "unknown")
                span.set_attribute(GEN_AI_REQUEST_MODEL, context.model)

            yield span

            # Post-execution: enrich with token/cost data from context
            if context:
                if context.tokens_input:
                    span.set_attribute(GEN_AI_USAGE_INPUT_TOKENS, context.tokens_input)
                if context.tokens_output:
                    span.set_attribute(GEN_AI_USAGE_OUTPUT_TOKENS, context.tokens_output)
                if context.cost_usd:
                    span.set_attribute(GEN_AI_USAGE_COST, context.cost_usd)
                if context.model:
                    span.set_attribute(GEN_AI_RESPONSE_MODEL, context.model)
                if context.framework:
                    span.set_attribute("turingpulse.framework", context.framework)
                if context.node_type:
                    span.set_attribute("turingpulse.node_type", context.node_type)
