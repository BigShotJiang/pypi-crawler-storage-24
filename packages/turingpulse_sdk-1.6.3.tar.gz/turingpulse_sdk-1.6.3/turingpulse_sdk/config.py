"""Plugin configuration models."""

from __future__ import annotations

import logging as _logging
import os
import re as _re
from typing import Dict, List, Optional

from pydantic import BaseModel, Field, field_validator

from .fingerprint import FingerprintConfig

DEFAULT_ENDPOINT = "https://api.turingpulse.ai"
MAX_FIELD_SIZE = 500_000

_config_logger = _logging.getLogger("turingpulse.sdk.config")

_CRLF_RE = _re.compile(r"[\r\n\x00]")

_BLOCKED_HOST_PATTERNS = _re.compile(
    r"^("
    r"127\.\d{1,3}\.\d{1,3}\.\d{1,3}"       # 127.0.0.0/8
    r"|10\.\d{1,3}\.\d{1,3}\.\d{1,3}"        # 10.0.0.0/8
    r"|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}"  # 172.16.0.0/12
    r"|192\.168\.\d{1,3}\.\d{1,3}"            # 192.168.0.0/16
    r"|169\.254\.\d{1,3}\.\d{1,3}"            # link-local / cloud metadata
    r"|0\.0\.0\.0"
    r"|localhost"
    r"|\[::1\]"
    r"|\[fd[0-9a-f]{2}:"                      # ULA IPv6
    r"|\[fe80:"                                # link-local IPv6
    r")$", _re.IGNORECASE,
)


def _strip_control_chars(value: str) -> str:
    """Remove CR, LF, and NUL characters to prevent header injection."""
    return _CRLF_RE.sub("", value)


def _check_endpoint_ssrf(endpoint: str) -> None:
    """Reject endpoints pointing to private/internal networks or cloud metadata."""
    from urllib.parse import urlparse
    parsed = urlparse(endpoint)
    host = parsed.hostname or ""
    if _BLOCKED_HOST_PATTERNS.match(host):
        raise ValueError(
            "TuringPulse endpoint must not point to private/internal networks. "
            "Got a blocked host."
        )


def _get_env_float(key: str, default: float) -> float:
    """Get float value from environment variable."""
    val = os.getenv(key)
    if val is not None:
        try:
            return float(val)
        except ValueError:
            pass
    return default


def _get_env_int(key: str, default: int) -> int:
    """Get integer value from environment variable."""
    val = os.getenv(key)
    if val is not None:
        try:
            return int(val)
        except ValueError:
            pass
    return default


def _get_env_bool(key: str, default: bool) -> bool:
    """Get boolean value from environment variable.

    Recognises ``true``, ``1``, ``yes`` (case-insensitive) as *True*.
    """
    val = os.getenv(key)
    if val is not None:
        return val.strip().lower() in ("true", "1", "yes")
    return default


class GovernanceDefaults(BaseModel):
    """Global defaults applied to every GovernanceDirective unless overridden."""

    hitl: bool = False
    reviewers: List[str] = Field(default_factory=list)
    escalation_channels: List[str] = Field(default_factory=list)
    metadata: Dict[str, str] = Field(default_factory=dict)
    severity: str = "medium"
    auto_escalate_after_seconds: Optional[int] = None


class TuringPulseConfig(BaseModel):
    """
    Runtime configuration for the TuringPulse SDK.

    Required:
        api_key       - SDK API key (``TP_API_KEY``). The backend resolves
                        tenant and project from this key; the SDK never needs
                        to know those IDs.
        workflow_name - Display name for this workflow (``TP_WORKFLOW_NAME``).

    Optional:
        endpoint      - Base URL for the TuringPulse API (``TP_ENDPOINT``).
                        Defaults to ``https://api.turingpulse.ai``.
                        Override for self-hosted or staging environments.

    Behaviour / tuning (with env-var overrides):
        TP_TIMEOUT_SECONDS        - HTTP timeout (default 10.0)
        TP_POLICY_CHECK_TIMEOUT   - Policy-check timeout, fail-open (default 1.5)
        TP_MAX_RETRIES            - Retry attempts (default 3)
        TP_RETRY_BACKOFF_BASE     - Retry backoff base seconds (default 0.5)
        TP_RETRY_BACKOFF_MAX      - Max retry backoff seconds (default 2.0)
    """

    api_key: str = Field(
        default_factory=lambda: os.getenv("TP_API_KEY", "")
    )
    workflow_name: str = Field(
        default_factory=lambda: os.getenv("TP_WORKFLOW_NAME", "")
    )
    endpoint: str = Field(
        default_factory=lambda: os.getenv("TP_ENDPOINT", DEFAULT_ENDPOINT)
    )

    default_labels: Dict[str, str] = Field(default_factory=dict)
    trace_enabled: bool = True
    trace_service_name: str = "turingpulse.sdk"
    trace_scope_name: str = "turingpulse.sdk.instrumentation"

    timeout_seconds: float = Field(
        default_factory=lambda: _get_env_float("TP_TIMEOUT_SECONDS", 10.0)
    )
    policy_check_timeout: float = Field(
        default_factory=lambda: _get_env_float("TP_POLICY_CHECK_TIMEOUT", 1.5)
    )
    max_retries: int = Field(
        default_factory=lambda: _get_env_int("TP_MAX_RETRIES", 3)
    )
    retry_backoff_base: float = Field(
        default_factory=lambda: _get_env_float("TP_RETRY_BACKOFF_BASE", 0.5)
    )
    retry_backoff_max: float = Field(
        default_factory=lambda: _get_env_float("TP_RETRY_BACKOFF_MAX", 2.0)
    )

    trigger_namespace: str = "default"
    governance_defaults: GovernanceDefaults = Field(default_factory=GovernanceDefaults)
    capture_arguments: bool = Field(
        default_factory=lambda: _get_env_bool("TP_CAPTURE_ARGUMENTS", False)
    )
    capture_return_value: bool = Field(
        default_factory=lambda: _get_env_bool("TP_CAPTURE_RETURN_VALUE", False)
    )
    redact_fields: List[str] = Field(default_factory=list)
    max_serialized_field_length: int = Field(
        default_factory=lambda: _get_env_int("TP_MAX_SERIALIZED_FIELD_LENGTH", 100_000)
    )

    policy_fail_mode: str = Field(
        default_factory=lambda: os.getenv("TP_POLICY_FAIL_MODE", "open")
    )

    fingerprint: FingerprintConfig = Field(default_factory=FingerprintConfig)

    class Config:
        frozen = True

    @field_validator("api_key", mode="after")
    @classmethod
    def _validate_api_key(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError(
                "TuringPulse api_key is required and cannot be empty. "
                "Set the TP_API_KEY environment variable or pass api_key to init()."
            )
        return _strip_control_chars(v.strip())

    @field_validator("workflow_name", mode="after")
    @classmethod
    def _validate_workflow_name(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError(
                "TuringPulse workflow_name is required and cannot be empty. "
                "Pass workflow_name to init(). Example: init(api_key='...', workflow_name='My Agent')"
            )
        return v.strip()

    @field_validator("endpoint", mode="after")
    @classmethod
    def _validate_endpoint(cls, v: str) -> str:
        v = _strip_control_chars(v.rstrip("/"))
        if v and not v.startswith(("https://", "http://")):
            raise ValueError(
                "TuringPulse endpoint must start with https:// or http://"
            )
        _check_endpoint_ssrf(v)
        if v.startswith("http://"):
            _config_logger.warning(
                "TuringPulse endpoint uses http:// — API key will be sent in cleartext. "
                "Use https:// in production."
            )
        return v

    @field_validator("timeout_seconds", mode="after")
    @classmethod
    def _validate_timeout(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("timeout_seconds must be positive")
        return min(v, 120.0)

    @field_validator("max_retries", mode="after")
    @classmethod
    def _validate_retries(cls, v: int) -> int:
        return max(0, min(v, 10))

    @field_validator("policy_check_timeout", mode="after")
    @classmethod
    def _validate_policy_timeout(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("policy_check_timeout must be positive")
        return min(v, 30.0)

    @field_validator("max_serialized_field_length", mode="after")
    @classmethod
    def _validate_field_length(cls, v: int) -> int:
        return max(256, min(v, 1_000_000))

    def merged_labels(self, labels: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        merged: Dict[str, str] = dict(self.default_labels)
        if labels:
            merged.update({k: str(v) for k, v in labels.items()})
        return merged
