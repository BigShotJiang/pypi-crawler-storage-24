"""Automatic detection of LLM calls and extraction of metadata.

Uses a data-driven provider registry instead of per-provider methods,
making it trivial to add new providers without modifying detection logic.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("turingpulse.sdk.llm_detector")


@dataclass
class LLMCallInfo:
    """Information extracted from an LLM call."""

    provider: str
    model: Optional[str]
    prompt: Optional[str]
    config: Dict[str, Any]
    node_type: str = "llm"
    streaming: bool = False


# ---------------------------------------------------------------------------
# Provider registry — add new providers by appending to PROVIDERS
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ProviderSpec:
    """Declarative definition of how to detect and extract info for a provider."""

    name: str
    qualname_patterns: List[str]
    config_keys: List[str]
    method_patterns: List[str] = field(default_factory=list)
    method_context: Optional[str] = None
    system_param: Optional[str] = None
    prompt_strategy: str = "messages"
    model_key: str = "model"
    alt_model_key: Optional[str] = None


PROVIDERS: List[ProviderSpec] = [
    ProviderSpec(
        name="openai",
        qualname_patterns=["chat.completions.create", "completions.create",
                           "chatcompletion.create", "completion.create", "openai.chat", "asyncopenai"],
        config_keys=["model", "temperature", "max_tokens", "top_p",
                     "frequency_penalty", "presence_penalty", "stop"],
    ),
    ProviderSpec(
        name="anthropic",
        qualname_patterns=["messages.create", "anthropic.messages", "asyncanthropic", "claude"],
        config_keys=["model", "temperature", "max_tokens", "top_p", "stop_sequences"],
        system_param="system",
    ),
    ProviderSpec(
        name="google",
        qualname_patterns=["generate_content", "generativemodel", "google.generativeai", "gemini"],
        config_keys=["model", "temperature", "max_output_tokens", "top_p", "top_k"],
        prompt_strategy="first_arg",
        alt_model_key="model_name",
    ),
    ProviderSpec(
        name="vertexai",
        qualname_patterns=["vertexai", "palm", "text-bison", "code-bison"],
        config_keys=["model", "temperature", "max_output_tokens", "top_p", "top_k", "candidate_count"],
        prompt_strategy="first_arg",
        alt_model_key="model_name",
    ),
    ProviderSpec(
        name="langchain",
        qualname_patterns=["langchain", "chatmodel", "llmchain", "runnablesequence"],
        config_keys=["model_name", "temperature", "max_tokens", "model_kwargs"],
        method_patterns=["invoke", "ainvoke", "batch", "stream"],
        method_context="chain",
        prompt_strategy="input_kwarg",
        model_key="model_name",
        alt_model_key="model",
    ),
    ProviderSpec(
        name="langgraph",
        qualname_patterns=["langgraph", "stategraph", "compiledgraph", "messagesgraph", "astream_events"],
        config_keys=["model_name", "temperature", "max_tokens", "recursion_limit", "configurable"],
        method_patterns=["invoke", "ainvoke", "stream", "astream", "batch"],
        method_context="graph",
        prompt_strategy="state_messages",
        model_key="model_name",
        alt_model_key="model",
    ),
    ProviderSpec(
        name="crewai",
        qualname_patterns=["crewai", "crew.kickoff", "agent.execute", "task.execute"],
        config_keys=["model", "temperature", "max_tokens", "verbose", "memory"],
        method_patterns=["kickoff", "kickoff_async", "execute_task"],
        prompt_strategy="inputs_kwarg",
    ),
    ProviderSpec(
        name="autogen",
        qualname_patterns=["autogen", "conversableagent", "assistantagent", "useragent", "groupchat"],
        config_keys=["model", "temperature", "max_tokens", "timeout", "cache_seed"],
        method_patterns=["initiate_chat", "generate_reply", "run"],
        prompt_strategy="message_kwarg",
    ),
    ProviderSpec(
        name="llamaindex",
        qualname_patterns=["llama_index", "llamaindex", "queryengine", "chatengine",
                           "retrievalqa", "vectorstoreindex"],
        config_keys=["model", "temperature", "max_tokens", "context_window"],
        method_patterns=["query", "chat", "retrieve", "as_query_engine"],
        method_context="index|engine",
        prompt_strategy="query_kwarg",
        alt_model_key="llm",
    ),
    ProviderSpec(
        name="cohere",
        qualname_patterns=["cohere.chat", "cohere.generate", "cohereclient"],
        config_keys=["model", "temperature", "max_tokens", "p", "k"],
        system_param="preamble",
        prompt_strategy="message_kwarg",
    ),
    ProviderSpec(
        name="mistral",
        qualname_patterns=["mistral.chat", "mistral.complete", "mistralclient"],
        config_keys=["model", "temperature", "max_tokens", "top_p"],
    ),
    ProviderSpec(
        name="bedrock",
        qualname_patterns=["bedrock", "invoke_model", "invoke_model_with_response_stream",
                           "converse", "converse_stream"],
        config_keys=["modelId", "temperature", "maxTokens", "topP", "stopSequences"],
        prompt_strategy="bedrock",
        model_key="modelId",
    ),
]


# ---------------------------------------------------------------------------
# Detection engine
# ---------------------------------------------------------------------------

def _matches_provider(spec: ProviderSpec, qualname: str, func_name: str) -> bool:
    """Check whether a call matches a provider spec."""
    if any(p in qualname for p in spec.qualname_patterns):
        return True
    if spec.method_patterns and func_name in spec.method_patterns:
        if spec.method_context:
            return any(ctx in qualname for ctx in spec.method_context.split("|"))
        return True
    return False


from .fingerprint import extract_config_subset as _extract_config  # noqa: E402
from .fingerprint import extract_prompt_from_messages as _extract_system_prompt  # noqa: E402


def _extract_prompt(
    spec: ProviderSpec,
    args: Tuple[Any, ...],
    kwargs: Dict[str, Any],
) -> Optional[str]:
    """Extract the prompt / system prompt based on the provider's strategy."""
    strategy = spec.prompt_strategy

    if strategy == "messages":
        system = kwargs.get(spec.system_param) if spec.system_param else None
        if system and isinstance(system, str):
            return system
        return _extract_system_prompt(kwargs.get("messages", []))

    if strategy == "first_arg":
        if args:
            first = args[0]
            if isinstance(first, str):
                return first
            if isinstance(first, list):
                parts = []
                for p in first:
                    if isinstance(p, str):
                        parts.append(p)
                    elif hasattr(p, "text"):
                        parts.append(p.text)
                return " ".join(parts) if parts else str(first)
        return None

    if strategy == "input_kwarg":
        if "input" in kwargs:
            val = kwargs["input"]
            if isinstance(val, dict) and "question" in val:
                return val.get("question")
            if isinstance(val, str):
                return val
        if args and isinstance(args[0], str):
            return args[0]
        return None

    if strategy == "state_messages":
        if "messages" in kwargs:
            return _extract_system_prompt(kwargs["messages"])
        if args and isinstance(args[0], dict):
            state = args[0]
            if "messages" in state:
                return _extract_system_prompt(state["messages"])
            return state.get("input")
        return None

    if strategy == "inputs_kwarg":
        if "inputs" in kwargs:
            inputs = kwargs["inputs"]
            if isinstance(inputs, dict):
                return inputs.get("topic") or inputs.get("question") or str(inputs)
        if args and isinstance(args[0], dict):
            return str(args[0])
        return None

    if strategy == "message_kwarg":
        if "message" in kwargs:
            return kwargs["message"] if isinstance(kwargs["message"], str) else None
        if args and isinstance(args[0], str):
            return args[0]
        return None

    if strategy == "query_kwarg":
        if args and isinstance(args[0], str):
            return args[0]
        return kwargs.get("query") or kwargs.get("message")

    if strategy == "bedrock":
        return _extract_bedrock_prompt(kwargs)

    return None


def _extract_bedrock_prompt(kwargs: Dict[str, Any]) -> Optional[str]:
    """Bedrock has a unique prompt extraction flow via body JSON."""
    model_id = kwargs.get("modelId", "")
    body = kwargs.get("body")
    if body:
        import json as _json
        try:
            if isinstance(body, str):
                body_data = _json.loads(body)
            elif isinstance(body, bytes):
                body_data = _json.loads(body.decode())
            else:
                body_data = body
            if "anthropic" in str(model_id).lower():
                return _extract_system_prompt(body_data.get("messages", []))
            return body_data.get("prompt") or body_data.get("inputText")
        except Exception:
            pass
    if "messages" in kwargs:
        messages = kwargs["messages"]
        if messages and isinstance(messages, list) and isinstance(messages[0], dict):
            for msg in messages:
                if msg.get("role") == "user":
                    content = msg.get("content", [])
                    if content and isinstance(content[0], dict):
                        return content[0].get("text")
    return None


def _extract_model(spec: ProviderSpec, kwargs: Dict[str, Any]) -> Optional[str]:
    return kwargs.get(spec.model_key) or (kwargs.get(spec.alt_model_key) if spec.alt_model_key else None)


class LLMDetector:
    """Detect LLM calls using the data-driven provider registry."""

    @staticmethod
    def detect_llm_call(
        func_name: str,
        func_qualname: str,
        args: Tuple[Any, ...],
        kwargs: Dict[str, Any],
    ) -> Optional[LLMCallInfo]:
        qualname_lower = func_qualname.lower()
        func_name_lower = func_name.lower()

        for spec in PROVIDERS:
            if _matches_provider(spec, qualname_lower, func_name_lower):
                is_streaming = bool(
                    kwargs.get("stream")
                    or kwargs.get("stream_mode")
                    or kwargs.get("response_mode") == "streaming"
                )
                return LLMCallInfo(
                    provider=spec.name,
                    model=_extract_model(spec, kwargs),
                    prompt=_extract_prompt(spec, args, kwargs),
                    config=_extract_config(kwargs, spec.config_keys),
                    streaming=is_streaming,
                )
        return None


# ---------------------------------------------------------------------------
# Tool detection
# ---------------------------------------------------------------------------

_TOOL_PATTERNS = ["search", "query", "retrieve", "fetch", "call_api",
                  "execute", "run_tool", "invoke_tool"]


class ToolDetector:
    """Detect tool / retriever / database calls."""

    @staticmethod
    def detect_tool_call(
        func_name: str,
        func_qualname: str,
        args: Tuple[Any, ...],
        kwargs: Dict[str, Any],
    ) -> Optional[str]:
        fn_lower = func_name.lower()
        qn_lower = func_qualname.lower()
        if "retriever" in qn_lower or "vectorstore" in qn_lower:
            return "retriever"
        if "database" in qn_lower or "sql" in qn_lower:
            return "database"
        for pattern in _TOOL_PATTERNS:
            if pattern in fn_lower or pattern in qn_lower:
                return "tool"
        return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect_node_type(
    func_name: str,
    func_qualname: str,
    args: Tuple[Any, ...],
    kwargs: Dict[str, Any],
) -> Tuple[str, Optional[LLMCallInfo]]:
    """Detect node type and extract LLM info if applicable."""
    llm_info = LLMDetector.detect_llm_call(func_name, func_qualname, args, kwargs)
    if llm_info:
        return ("llm", llm_info)
    tool_type = ToolDetector.detect_tool_call(func_name, func_qualname, args, kwargs)
    if tool_type:
        return (tool_type, None)
    return ("function", None)
