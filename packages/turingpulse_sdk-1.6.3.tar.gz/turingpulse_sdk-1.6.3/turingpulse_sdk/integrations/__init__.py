"""Backward-compatibility shim — framework integrations have moved to separate packages.

Prefer importing from the dedicated packages::

    from turingpulse_sdk_langgraph import instrument_langgraph
    from turingpulse_sdk_crewai import instrument_crewai
    from turingpulse_sdk_autogen import instrument_autogen
    from turingpulse_sdk_llamaindex import instrument_llamaindex

These shim re-exports will be removed in a future major version.
"""

from __future__ import annotations

import warnings

__all__ = [
    "instrument_crewai",
    "instrument_autogen",
    "instrument_llamaindex",
    "instrument_langgraph",
]

_DEPRECATION_MSG = (
    "Importing from 'turingpulse_sdk.integrations' is deprecated. "
    "Install the dedicated package 'turingpulse-sdk-{pkg}' and import from "
    "'turingpulse_sdk_{mod}' instead. This shim will be removed in v1.0."
)


def instrument_crewai(*args, **kwargs):  # type: ignore[no-untyped-def]
    warnings.warn(_DEPRECATION_MSG.format(pkg="crewai", mod="crewai"), DeprecationWarning, stacklevel=2)
    from .crewai import instrument_crewai as _impl
    return _impl(*args, **kwargs)


def instrument_autogen(*args, **kwargs):  # type: ignore[no-untyped-def]
    warnings.warn(_DEPRECATION_MSG.format(pkg="autogen", mod="autogen"), DeprecationWarning, stacklevel=2)
    from .autogen import instrument_autogen as _impl
    return _impl(*args, **kwargs)


def instrument_llamaindex(*args, **kwargs):  # type: ignore[no-untyped-def]
    warnings.warn(_DEPRECATION_MSG.format(pkg="llamaindex", mod="llamaindex"), DeprecationWarning, stacklevel=2)
    from .llamaindex import instrument_llamaindex as _impl
    return _impl(*args, **kwargs)


def instrument_langgraph(*args, **kwargs):  # type: ignore[no-untyped-def]
    warnings.warn(_DEPRECATION_MSG.format(pkg="langgraph", mod="langgraph"), DeprecationWarning, stacklevel=2)
    from .langgraph import instrument_langgraph as _impl
    return _impl(*args, **kwargs)
