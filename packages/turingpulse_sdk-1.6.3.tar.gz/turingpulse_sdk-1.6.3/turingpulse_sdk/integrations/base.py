"""Base class and helpers for framework-specific instrumentations.

Provides ``emit_child_spans()`` which creates ``AgentEvent`` objects for
each child span (tool call, task, LLM reasoning step, etc.) and sends
them through the core SDK client so they appear as nested spans inside
the root workflow trace.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List
from uuid import uuid4

from turingpulse_interfaces import (
    AgentEvent,
    AgentEventPayload,
    AgentEventType,
    TokenBreakdown,
    ToolCallInfo,
)

from ..plugin import get_plugin

logger = logging.getLogger("turingpulse.sdk.integrations.base")


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def emit_child_spans(
    spans: List[Dict[str, Any]],
    *,
    run_id: str,
    parent_span_id: str,
    workflow_name: str,
    framework: str,
) -> None:
    """Create and emit child-span events for a workflow execution.

    Each dict in *spans* should contain:

    - ``node`` (str): span name
    - ``node_type`` (str): "llm" | "tool" | "processor" | "evaluator" …
    - ``duration_ms`` (int): elapsed time in ms
    - ``status`` (str): "success" | "error"

    Optional keys:

    - ``prompt`` / ``system_prompt`` (str)
    - ``model`` / ``provider`` (str)
    - ``tokens`` (dict with ``prompt`` / ``completion``)
    - ``cost_usd`` (float)
    - ``tool_calls`` (list of dicts matching ``ToolCallInfo``)
    - ``input`` / ``output`` (dict)
    - ``available_tools`` (list of str)
    - ``metadata`` (dict of extra string key-values)
    """
    try:
        plugin = get_plugin()
    except Exception:
        logger.warning("Cannot emit child spans — plugin not initialised")
        return

    try:
        events = _build_child_events(spans, run_id, parent_span_id, workflow_name, framework)
    except Exception as exc:
        logger.warning("Failed to build child span events: %s", type(exc).__name__)
        return
    _emit_events(events, run_id, plugin)


def _build_child_events(
    spans: List[Dict[str, Any]],
    run_id: str,
    parent_span_id: str,
    workflow_name: str,
    framework: str,
) -> List[AgentEvent]:
    events: List[AgentEvent] = []
    base_ts = _utcnow()
    prev_span_id = parent_span_id
    for idx, span_data in enumerate(spans):
        span_id = uuid4().hex
        ts = datetime.fromtimestamp(base_ts.timestamp() + (idx * 0.1), tz=timezone.utc)

        metadata: Dict[str, Any] = {
            "span_id": span_id,
            "parent_span_id": prev_span_id,
            "trace_id": run_id,
            "workflow_name": workflow_name,
            "framework": framework,
            "node_type": span_data.get("node_type", "processor"),
            "depth": str(idx + 1),
            "sequence_index": str(idx),
        }
        prev_span_id = span_id

        for key in ("input", "output", "context"):
            value = span_data.get(key)
            if value is not None:
                try:
                    serialized = json.dumps(value, default=str) if not isinstance(value, str) else value
                except (TypeError, ValueError):
                    serialized = str(value)
                metadata[key] = serialized

        if span_data.get("prompt"):
            metadata["prompt"] = str(span_data["prompt"])
            metadata["user_query"] = str(span_data["prompt"])
        if span_data.get("system_prompt"):
            metadata["system_prompt"] = str(span_data["system_prompt"])

        if span_data.get("model"):
            metadata["model"] = span_data["model"]
            metadata["provider"] = span_data.get("provider", "openai")

        if span_data.get("available_tools"):
            raw_tools = span_data["available_tools"]
            metadata["available_tools"] = json.dumps(raw_tools)
            tool_names = [
                t.get("name", str(t)) if isinstance(t, dict) else str(t)
                for t in raw_tools
            ]
            metadata["tools"] = json.dumps(tool_names)

        for k, v in span_data.get("metadata", {}).items():
            metadata[k] = v if isinstance(v, str) else json.dumps(v)

        tokens = None
        tok = span_data.get("tokens")
        if tok and isinstance(tok, dict):
            tokens = TokenBreakdown(prompt=tok.get("prompt", 0), completion=tok.get("completion", 0))

        tool_calls_raw = span_data.get("tool_calls")
        tool_calls = None
        if tool_calls_raw:
            tool_calls = []
            for tc in tool_calls_raw:
                raw_args = tc.get("tool_args", {})
                if isinstance(raw_args, str):
                    try:
                        raw_args = json.loads(raw_args)
                    except (json.JSONDecodeError, TypeError):
                        raw_args = {"raw": raw_args}
                tool_calls.append(ToolCallInfo(
                    tool_name=tc.get("tool_name", "unknown"),
                    tool_args=raw_args if isinstance(raw_args, dict) else {"raw": str(raw_args)},
                    tool_result=tc.get("tool_result") or "",
                    tool_id=tc.get("tool_id"),
                    success=tc.get("success", True),
                    error_message=tc.get("error_message"),
                    mcp_server=tc.get("mcp_server"),
                    mcp_transport=tc.get("mcp_transport"),
                    mcp_session_id=tc.get("mcp_session_id"),
                ))

        payload = AgentEventPayload(
            name=f"{workflow_name}.{span_data['node']}",
            duration_ms=span_data.get("duration_ms", 0),
            status=span_data.get("status", "success"),
            tokens=tokens,
            cost_usd=span_data.get("cost_usd"),
            tool_calls=tool_calls,
            metadata=metadata,
        )

        events.append(AgentEvent(
            run_id=run_id,
            agent_id=span_data["node"],
            timestamp=ts,
            type=AgentEventType.SPAN,
            payload=payload,
            workflow_name=workflow_name,
        ))
    return events


def _emit_events(events: List[AgentEvent], run_id: str, plugin) -> None:
    if not events:
        return
    try:
        serialised = plugin.client.serialize_events(events)
        plugin.client.emit_serialized_payload(serialised)
        logger.debug("Emitted %d child spans for run %s", len(events), run_id)
    except Exception as exc:
        logger.warning("Failed to emit child spans: %s", type(exc).__name__)


async def emit_child_spans_async(
    spans: List[Dict[str, Any]],
    *,
    run_id: str,
    parent_span_id: str,
    workflow_name: str,
    framework: str,
) -> None:
    """Async variant of emit_child_spans — does not block the event loop."""
    try:
        plugin = get_plugin()
    except Exception:
        logger.warning("Cannot emit child spans — plugin not initialised")
        return

    events = _build_child_events(spans, run_id, parent_span_id, workflow_name, framework)
    if events:
        try:
            serialised = plugin.client.serialize_events(events)
            await plugin.client.emit_serialized_payload_async(serialised)
            logger.debug("Emitted %d child spans (async) for run %s", len(events), run_id)
        except Exception as exc:
            logger.warning("Failed to emit child spans (async): %s", type(exc).__name__)


class _LLMClientProxy:
    """Base proxy for LLM client wrappers.

    Subclasses wrap a real LLM client, intercepting chat/completion calls
    to emit TuringPulse spans while delegating everything else to the
    underlying client via ``__getattr__``.
    """

    def __init__(self, client: Any, *, provider: str, model: str | None = None):
        object.__setattr__(self, "_tp_client", client)
        object.__setattr__(self, "_tp_provider", provider)
        object.__setattr__(self, "_tp_model", model)

    def __getattr__(self, name: str) -> Any:
        return getattr(object.__getattribute__(self, "_tp_client"), name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith("_tp_"):
            object.__setattr__(self, name, value)
        else:
            setattr(object.__getattribute__(self, "_tp_client"), name, value)
