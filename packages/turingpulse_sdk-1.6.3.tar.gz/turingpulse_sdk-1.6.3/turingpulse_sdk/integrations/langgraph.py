"""LangGraph 1.0.x instrumentation for TuringPulse SDK.

Wraps ``graph.invoke()`` (or ``graph.ainvoke()``) to capture:

- Per-node child spans with full input/output/prompt/tool_calls data.
- Token counts and cost from LLM calls.
- Workflow-level aggregated metrics.

The sync ``instrument_langgraph`` uses LangChain callbacks to automatically
capture per-node data during ``graph.invoke()``.  User-populated
``state["spans"]`` are also honoured as a supplement.

Usage::

    from turingpulse_sdk.integrations.langgraph import instrument_langgraph

    graph = build_my_langgraph_workflow()
    run_workflow = instrument_langgraph(graph, name="my-langgraph-workflow")
    result = run_workflow(state={...})
"""

from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Sequence
from uuid import uuid4

if TYPE_CHECKING:
    from ..kpi import KPIConfig

from ..config import MAX_FIELD_SIZE
from ..context import current_context
from ..decorators import instrument
from .base import emit_child_spans

logger = logging.getLogger("turingpulse.sdk.integrations.langgraph")

FRAMEWORK_NAME = "langgraph"
FRAMEWORK_VERSION = "1.0.4"

_OUTPUT_KEYS = (
    "final_response", "draft_response", "output", "final_output",
    "final_report", "response", "answer", "result", "reply",
)
_INPUT_KEYS = (
    "user_query", "input", "query", "question", "prompt", "request",
    "bank_statement", "user_input", "message",
)


def _pick_state_field(state: Dict[str, Any], keys: Sequence[str]) -> str:
    """Return the first non-empty string value found under *keys* in *state*."""
    for k in keys:
        val = state.get(k)
        if val and isinstance(val, str) and len(val.strip()) > 0:
            return val.strip()
    return ""


_HAS_LANGCHAIN_CALLBACKS = False
try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.messages import BaseMessage  # noqa: F401
    _HAS_LANGCHAIN_CALLBACKS = True
except ImportError:
    pass


def _safe_str(obj: Any, limit: int = MAX_FIELD_SIZE) -> str:
    if obj is None:
        return ""
    if isinstance(obj, str):
        return obj[:limit]
    try:
        return json.dumps(obj, default=str)[:limit]
    except Exception:
        return str(obj)[:limit]


def _messages_to_str(messages: Sequence[Any]) -> str:
    """Convert a list of LangChain messages to a readable string."""
    parts: List[str] = []
    for msg in messages:
        if hasattr(msg, "type") and hasattr(msg, "content"):
            parts.append(f"[{msg.type}] {msg.content}")
        elif isinstance(msg, dict):
            parts.append(f"[{msg.get('role', 'unknown')}] {msg.get('content', '')}")
        else:
            parts.append(str(msg))
    return "\n".join(parts)[:MAX_FIELD_SIZE]


def _extract_system_prompt(messages: Sequence[Any]) -> str:
    """Pull the system message from a list of LangChain messages."""
    for msg in messages:
        role = getattr(msg, "type", None) or (msg.get("role") if isinstance(msg, dict) else None)
        if role == "system":
            content = getattr(msg, "content", None) or (msg.get("content") if isinstance(msg, dict) else "")
            return str(content)[:MAX_FIELD_SIZE]
    return ""


def _extract_user_query(messages: Sequence[Any]) -> str:
    """Pull the last human/user message from a list of messages."""
    for msg in reversed(list(messages)):
        role = getattr(msg, "type", None) or (msg.get("role") if isinstance(msg, dict) else None)
        if role in ("human", "user"):
            content = getattr(msg, "content", None) or (msg.get("content") if isinstance(msg, dict) else "")
            return str(content)[:MAX_FIELD_SIZE]
    return ""


_STATE_INTERNAL_KEYS = frozenset({"spans", "messages", "intermediate_steps"})


def _condense_state(state: Any) -> Dict[str, Any]:
    """Remove internal/noisy keys from a LangGraph state for display.

    Strips framework-internal keys (spans, messages, intermediate_steps)
    but preserves all user-meaningful values WITHOUT truncation — the UI
    layer is responsible for display truncation.
    """
    if not isinstance(state, dict):
        return {"value": state}
    return {k: v for k, v in state.items() if k not in _STATE_INTERNAL_KEYS}


def _state_diff(inputs: Any, outputs: Any) -> Dict[str, Any]:
    """Return only the keys whose values differ between input and output.

    For non-LLM LangGraph nodes the full state goes in and comes out.
    The node's actual contribution is the delta — much more useful to
    display in the UI than repeating the entire state.  No truncation
    is applied; the UI layer handles display limits.
    """
    if not isinstance(inputs, dict) or not isinstance(outputs, dict):
        return outputs if isinstance(outputs, dict) else {"result": outputs}
    diff: Dict[str, Any] = {}
    for key, value in outputs.items():
        if key in _STATE_INTERNAL_KEYS:
            continue
        old = inputs.get(key)
        try:
            same = old == value
        except Exception:
            same = False
        if key not in inputs or not same:
            diff[key] = value
    return diff if diff else _condense_state(outputs)


if _HAS_LANGCHAIN_CALLBACKS:

    class _SpanCollector(BaseCallbackHandler):
        """LangChain callback handler that collects rich per-node span data.

        Supports both LangGraph (``serialized=None``, node name via
        ``kwargs["name"]`` + ``metadata["langgraph_node"]``) and plain
        LangChain chains (node name in ``serialized["name"]``).

        LLM calls that occur inside a named node are merged into that
        node's span so the UI shows one rich entry (e.g. ``classify_intent``
        with prompt, tokens, model) instead of a separate ``llm_0`` entry.
        """

        _SKIP_NAMES = frozenset({
            "LangGraph", "RunnableSequence", "RunnableLambda",
            "ChannelWrite", "ChannelRead", "RunnableParallel",
            "RunnablePassthrough",
        })

        def __init__(self, workflow_name: str, default_model: str, default_provider: str):
            super().__init__()
            self.workflow_name = workflow_name
            self.default_model = default_model
            self.default_provider = default_provider
            self.collected_spans: List[Dict[str, Any]] = []
            self._active_chains: Dict[str, Dict[str, Any]] = {}
            self._active_llms: Dict[str, Dict[str, Any]] = {}
            self._active_tools: Dict[str, Dict[str, Any]] = {}
            self._llm_parent_map: Dict[str, str] = {}
            self.total_prompt_tokens = 0
            self.total_completion_tokens = 0
            self.total_cost = 0.0

        def _find_named_ancestor(self, parent_run_id: Optional[str]) -> Optional[str]:
            """Walk the parent chain to find the nearest named chain run_id."""
            visited: set = set()
            rid = parent_run_id
            while rid and rid not in visited:
                visited.add(rid)
                if rid in self._active_chains:
                    return rid
                rid = self._llm_parent_map.get(rid)
            return None

        @staticmethod
        def _extract_bound_tools(
            serialized: Optional[Dict[str, Any]],
            kwargs: Dict[str, Any],
        ) -> Optional[List[Dict[str, Any]]]:
            """Extract tool schemas from an LLM that has bind_tools() applied."""
            sources = [
                kwargs.get("invocation_params", {}),
                (serialized or {}).get("kwargs", {}),
            ]
            for src in sources:
                raw = src.get("tools")
                if raw and isinstance(raw, list):
                    tools: List[Dict[str, Any]] = []
                    for t in raw:
                        if isinstance(t, dict):
                            fn = t.get("function", t)
                            tools.append({
                                "name": fn.get("name", "unknown"),
                                "description": fn.get("description", ""),
                                "parameters": fn.get("parameters", {}),
                            })
                    if tools:
                        return tools
            return None

        @staticmethod
        def _is_langgraph_node(tags: Optional[list]) -> bool:
            return any(t.startswith("graph:step:") for t in (tags or []))

        @staticmethod
        def _resolve_chain_name(
            serialized: Optional[Dict[str, Any]],
            metadata: Optional[Dict[str, Any]],
            kwargs: Dict[str, Any],
        ) -> str:
            lg_node = (metadata or {}).get("langgraph_node")
            if lg_node:
                return str(lg_node)
            kw_name = kwargs.get("name", "")
            if kw_name:
                return str(kw_name)
            if serialized:
                return serialized.get("name", "") or (serialized.get("id", [""]) or [""])[-1]
            return ""

        def on_chain_start(
            self, serialized: Optional[Dict[str, Any]], inputs: Dict[str, Any],
            *, run_id, parent_run_id=None, tags=None, metadata=None, **kwargs,
        ):
            rid = str(run_id)
            pid = str(parent_run_id) if parent_run_id else None
            name = self._resolve_chain_name(serialized, metadata, kwargs)

            is_graph_node = self._is_langgraph_node(tags)

            if is_graph_node and name:
                self._active_chains[rid] = {
                    "name": name,
                    "started_at": time.time(),
                    "inputs": dict(inputs) if isinstance(inputs, dict) else inputs,
                    "parent_run_id": pid,
                    "llm_data": None,
                    "node_type": (metadata or {}).get("langgraph_node_type", "processor"),
                }
            elif name in self._SKIP_NAMES or not name:
                if pid:
                    self._llm_parent_map[rid] = pid
            elif serialized and name:
                self._active_chains[rid] = {
                    "name": name,
                    "started_at": time.time(),
                    "inputs": dict(inputs) if isinstance(inputs, dict) else inputs,
                    "parent_run_id": pid,
                    "llm_data": None,
                    "node_type": "processor",
                }
            else:
                if pid:
                    self._llm_parent_map[rid] = pid

        def on_chain_end(self, outputs: Dict[str, Any], *, run_id, **kwargs):
            key = str(run_id)
            data = self._active_chains.pop(key, None)
            if not data:
                return
            dur = int((time.time() - data["started_at"]) * 1000)

            llm = data.get("llm_data")
            base_type = data.get("node_type", "processor")

            if llm:
                node_input = data["inputs"]
                node_output = outputs if isinstance(outputs, dict) else {"result": _safe_str(outputs)}
            else:
                node_input = _condense_state(data["inputs"])
                raw_out = outputs if isinstance(outputs, dict) else {}
                node_output = _state_diff(data["inputs"], raw_out)

            span: Dict[str, Any] = {
                "node": data["name"],
                "node_type": "llm" if llm else base_type,
                "duration_ms": dur,
                "status": "success",
                "input": node_input,
                "output": node_output,
            }

            if llm:
                span["model"] = llm.get("model", self.default_model)
                span["provider"] = self.default_provider
                span["tokens"] = llm.get("tokens")
                if llm.get("system_prompt"):
                    span["system_prompt"] = llm["system_prompt"]
                if llm.get("prompt"):
                    span["prompt"] = llm["prompt"]
                if llm.get("user_query"):
                    span["input"] = {"user_query": llm["user_query"]}
                if llm.get("tool_calls"):
                    span["tool_calls"] = llm["tool_calls"]
                if llm.get("available_tools"):
                    span["available_tools"] = llm["available_tools"]
                if llm.get("llm_output"):
                    span["output"] = llm["llm_output"]

            self.collected_spans.append(span)

        def on_llm_start(self, serialized: Dict[str, Any], prompts: List[str], *, run_id, parent_run_id=None, **kwargs):
            rid = str(run_id)
            if parent_run_id:
                self._llm_parent_map[rid] = str(parent_run_id)
            self._active_llms[rid] = {
                "started_at": time.time(),
                "prompts": prompts,
                "model": (serialized or {}).get("kwargs", {}).get("model_name", self.default_model),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
            }

        def on_chat_model_start(self, serialized: Dict[str, Any], messages: List[List[Any]], *, run_id, parent_run_id=None, **kwargs):
            rid = str(run_id)
            if parent_run_id:
                self._llm_parent_map[rid] = str(parent_run_id)
            flat = messages[0] if messages else []

            bound_tools = self._extract_bound_tools(serialized, kwargs)

            self._active_llms[rid] = {
                "started_at": time.time(),
                "messages": flat,
                "system_prompt": _extract_system_prompt(flat),
                "user_query": _extract_user_query(flat),
                "prompt": _messages_to_str(flat),
                "model": (
                    kwargs.get("invocation_params", {}).get("model_name")
                    or kwargs.get("invocation_params", {}).get("model")
                    or (serialized or {}).get("kwargs", {}).get("model_name")
                    or self.default_model
                ),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
                "available_tools": bound_tools,
            }

        def on_llm_end(self, response, *, run_id, parent_run_id=None, **kwargs):
            key = str(run_id)
            data = self._active_llms.pop(key, None)
            if not data:
                return

            dur = int((time.time() - data["started_at"]) * 1000)

            content = ""
            usage: Dict[str, int] = {}

            if hasattr(response, "generations") and response.generations:
                gen = response.generations[0]
                if gen:
                    msg = gen[0].message if hasattr(gen[0], "message") else gen[0]
                    content = getattr(msg, "content", "") or str(gen[0])

            if hasattr(response, "llm_output") and response.llm_output:
                token_usage = response.llm_output.get("token_usage", {})
                usage = {
                    "prompt": int(token_usage.get("prompt_tokens", 0)),
                    "completion": int(token_usage.get("completion_tokens", 0)),
                }

            if not usage.get("prompt") and hasattr(response, "generations") and response.generations:
                gen = response.generations[0]
                if gen:
                    msg = gen[0].message if hasattr(gen[0], "message") else gen[0]
                    um = getattr(msg, "usage_metadata", None) or {}
                    if isinstance(um, dict):
                        usage = {
                            "prompt": int(um.get("input_tokens", 0)),
                            "completion": int(um.get("output_tokens", 0)),
                        }

            self.total_prompt_tokens += usage.get("prompt", 0)
            self.total_completion_tokens += usage.get("completion", 0)

            tool_calls_raw = []
            if hasattr(response, "generations") and response.generations:
                gen = response.generations[0]
                if gen:
                    msg = gen[0].message if hasattr(gen[0], "message") else gen[0]
                    if hasattr(msg, "tool_calls") and msg.tool_calls:
                        for tc in msg.tool_calls:
                            tool_calls_raw.append({
                                "tool_name": tc.get("name", "unknown") if isinstance(tc, dict) else getattr(tc, "name", "unknown"),
                                "tool_args": tc.get("args", {}) if isinstance(tc, dict) else getattr(tc, "args", {}),
                                "tool_id": tc.get("id", str(uuid4())) if isinstance(tc, dict) else getattr(tc, "id", str(uuid4())),
                                "tool_result": "",
                                "success": True,
                            })

            llm_result = {
                "model": data.get("model", self.default_model),
                "tokens": usage if usage else None,
                "system_prompt": data.get("system_prompt"),
                "prompt": data.get("prompt"),
                "user_query": data.get("user_query"),
                "tool_calls": tool_calls_raw or None,
                "available_tools": data.get("available_tools"),
                "llm_output": {"response": _safe_str(content)},
                "duration_ms": dur,
            }

            ancestor_id = self._find_named_ancestor(
                data.get("parent_run_id") or (str(parent_run_id) if parent_run_id else None)
            )
            if ancestor_id and ancestor_id in self._active_chains:
                self._active_chains[ancestor_id]["llm_data"] = llm_result
            else:
                span: Dict[str, Any] = {
                    "node": f"llm_{len(self.collected_spans)}",
                    "node_type": "llm",
                    "duration_ms": dur,
                    "status": "success",
                    "model": data.get("model", self.default_model),
                    "provider": self.default_provider,
                    "tokens": usage if usage else None,
                    "output": {"response": _safe_str(content)},
                }
                if data.get("system_prompt"):
                    span["system_prompt"] = data["system_prompt"]
                if data.get("prompt"):
                    span["prompt"] = data["prompt"]
                if data.get("user_query"):
                    span["input"] = {"user_query": data["user_query"]}
                if tool_calls_raw:
                    span["tool_calls"] = tool_calls_raw
                if data.get("available_tools"):
                    span["available_tools"] = data["available_tools"]
                self.collected_spans.append(span)

        def on_tool_start(self, serialized: Dict[str, Any], input_str: str, *, run_id, **kwargs):
            tool_name = (serialized or {}).get("name", "unknown_tool")
            self._active_tools[str(run_id)] = {
                "name": tool_name,
                "started_at": time.time(),
                "input": input_str,
            }

        def on_tool_end(self, output: str, *, run_id, **kwargs):
            key = str(run_id)
            data = self._active_tools.pop(key, None)
            if not data:
                return
            dur = int((time.time() - data["started_at"]) * 1000)
            self.collected_spans.append({
                "node": data["name"],
                "node_type": "tool",
                "duration_ms": dur,
                "status": "success",
                "input": {"tool_input": _safe_str(data["input"])},
                "output": {"tool_output": _safe_str(output)},
                "tool_calls": [{
                    "tool_name": data["name"],
                    "tool_args": _safe_str(data["input"]),
                    "tool_result": _safe_str(output),
                    "tool_id": str(uuid4()),
                    "success": True,
                }],
            })

        def on_tool_error(self, error: BaseException, *, run_id, **kwargs):
            key = str(run_id)
            data = self._active_tools.pop(key, None)
            if not data:
                return
            dur = int((time.time() - data["started_at"]) * 1000)
            self.collected_spans.append({
                "node": data["name"],
                "node_type": "tool",
                "duration_ms": dur,
                "status": "error",
                "input": {"tool_input": _safe_str(data["input"])},
                "output": {"error": str(error)[:MAX_FIELD_SIZE]},
                "tool_calls": [{
                    "tool_name": data["name"],
                    "tool_args": _safe_str(data["input"]),
                    "tool_result": "",
                    "tool_id": str(uuid4()),
                    "success": False,
                    "error_message": str(error)[:MAX_FIELD_SIZE],
                }],
            })


def _record_spans_in_fingerprint(
    ctx: Any,
    spans: List[Dict[str, Any]],
    workflow_name: str,
    static_edges: Optional[List[str]] = None,
) -> None:
    """Record collected child spans in the fingerprint builder.

    The ``@instrument`` decorator only records the root node.  This helper
    walks the auto-collected spans and registers each one so the fingerprint
    captures the full graph structure (nodes, types, edges, prompts, configs).

    If ``static_edges`` are provided (extracted from the compiled LangGraph
    object at instrumentation time), those inter-node edges are also included
    to provide a more accurate graph topology.
    """
    fb = getattr(ctx, "fingerprint_builder", None)
    if fb is None:
        return

    seen: set = set()
    for sp in spans:
        node_name = sp.get("node", "")
        if not node_name or node_name in seen:
            continue
        seen.add(node_name)

        node_type = sp.get("node_type", "function")
        config_dict: Dict[str, Any] = {}
        if sp.get("model"):
            config_dict["model"] = sp["model"]
        if sp.get("provider"):
            config_dict["provider"] = sp["provider"]
        prompt = sp.get("prompt")

        fb.record_node(
            name=node_name,
            node_type=node_type,
            config=config_dict or None,
            prompt=prompt,
        )
        edge = f"{workflow_name}->{node_name}"
        if edge not in fb.edges:
            fb.edges.append(edge)

    if static_edges:
        for edge in static_edges:
            if edge not in fb.edges:
                fb.edges.append(edge)


def instrument_langgraph(
    graph: Any,
    *,
    name: str,
    model: str = "gpt-4o-mini",
    provider: str = "openai",
    kpis: Optional[Sequence["KPIConfig"]] = None,
    metadata: Optional[Dict[str, str]] = None,
) -> Callable[..., Any]:
    """Instrument a LangGraph compiled ``StateGraph`` for TuringPulse.

    Automatically captures per-node input/output, LLM prompts, token usage,
    and tool calls using LangChain callbacks when ``langchain_core`` is
    available.  Falls back to user-populated ``state["spans"]`` otherwise.

    Args:
        graph: A compiled ``StateGraph`` (result of ``graph.compile()``).
        name: Workflow display name for TuringPulse.
        model: Default LLM model name for metadata.
        provider: Default LLM provider.
        kpis: Optional KPI configurations for custom metric emission.
        metadata: Optional extra metadata to attach to the root span.

    Returns:
        A callable ``run(state=...) -> state``.
    """

    _static_edges: List[str] = []
    try:
        builder = getattr(graph, "builder", None)
        if builder:
            for src, dst in getattr(builder, "edges", []):
                if src not in ("__start__", "__end__") and dst not in ("__start__", "__end__"):
                    _static_edges.append(f"{src}->{dst}")
            for src, branches in getattr(builder, "branches", {}).items():
                if src in ("__start__", "__end__"):
                    continue
                for _bname, branch in branches.items():
                    for _end_key, end_node in (getattr(branch, "ends", {}) or {}).items():
                        if end_node not in ("__start__", "__end__"):
                            _static_edges.append(f"{src}->{end_node}")
        elif hasattr(graph, "graph") and hasattr(graph.graph, "edges"):
            for src, dst in graph.graph.edges:
                if src not in ("__start__", "__end__") and dst not in ("__start__", "__end__"):
                    _static_edges.append(f"{src}->{dst}")
    except Exception:
        pass

    @instrument(name=name, kpis=kpis, metadata=metadata or {})
    def run(state: Dict[str, Any]) -> Dict[str, Any]:
        t0 = time.time()

        if "spans" not in state:
            state["spans"] = []

        collector = None
        if _HAS_LANGCHAIN_CALLBACKS:
            collector = _SpanCollector(name, model, provider)

        if graph is not None:
            if collector is not None:
                try:
                    result = graph.invoke(state, config={"callbacks": [collector]})
                except TypeError:
                    logger.debug("graph.invoke() does not accept config, falling back")
                    result = graph.invoke(state)
                    collector = None
            else:
                result = graph.invoke(state)
        else:
            logger.warning("instrument_langgraph: graph is None, returning state unchanged")
            result = state

        _total_duration_ms = int((time.time() - t0) * 1000)  # noqa: F841

        ctx = current_context()
        if ctx is None:
            logger.warning("instrument_langgraph: no active context")
            return result

        user_spans: List[Dict[str, Any]] = result.get("spans", [])
        auto_spans: List[Dict[str, Any]] = collector.collected_spans if collector else []

        existing_nodes: Dict[str, int] = {
            sp.get("node", ""): i for i, sp in enumerate(user_spans)
        }
        merged_spans = list(user_spans)
        for sp in auto_spans:
            node = sp.get("node", "")
            if node in existing_nodes:
                idx = existing_nodes[node]
                for key in (
                    "input", "output", "prompt", "system_prompt",
                    "user_query", "model", "provider", "tool_calls",
                    "context", "available_tools",
                ):
                    if sp.get(key) and not merged_spans[idx].get(key):
                        merged_spans[idx][key] = sp[key]
                if sp.get("tokens") and not merged_spans[idx].get("tokens"):
                    merged_spans[idx]["tokens"] = sp["tokens"]
                if sp.get("node_type") == "llm" and merged_spans[idx].get("node_type") != "llm":
                    merged_spans[idx]["node_type"] = "llm"
            else:
                merged_spans.append(sp)
                existing_nodes[node] = len(merged_spans) - 1

        total_prompt = 0
        total_completion = 0
        total_cost = 0.0

        for sp in merged_spans:
            tok = sp.get("tokens", {})
            if isinstance(tok, dict):
                total_prompt += tok.get("prompt", 0)
                total_completion += tok.get("completion", 0)
            total_cost += sp.get("cost_usd", 0) or 0

        ctx.set_tokens(total_prompt, total_completion)
        ctx.set_cost(total_cost)
        ctx.set_model(model, provider)
        ctx.framework = FRAMEWORK_NAME
        ctx.node_type = "workflow"

        all_tool_names: List[str] = []
        seen_tool_names: set = set()
        for sp in merged_spans:
            for t in (sp.get("available_tools") or []):
                tname = t.get("name", "") if isinstance(t, dict) else str(t)
                if tname and tname not in seen_tool_names:
                    seen_tool_names.add(tname)
                    all_tool_names.append(tname)
        if all_tool_names:
            ctx.available_tools = all_tool_names

        user_query = _pick_state_field(result, _INPUT_KEYS)
        final_output = _pick_state_field(result, _OUTPUT_KEYS)
        ctx.set_io(
            input_data=_safe_str(user_query),
            output_data=_safe_str(final_output),
        )

        _record_spans_in_fingerprint(ctx, merged_spans, name, _static_edges)

        effective_workflow_name = ctx.workflow_name or name
        emit_child_spans(
            merged_spans,
            run_id=ctx.run_id,
            parent_span_id=ctx.span_id,
            workflow_name=effective_workflow_name,
            framework=FRAMEWORK_NAME,
        )

        return result

    return run


def instrument_langgraph_async(
    graph: Any,
    *,
    name: str,
    model: str = "gpt-4o-mini",
    provider: str = "openai",
    kpis: Optional[Sequence["KPIConfig"]] = None,
    metadata: Optional[Dict[str, str]] = None,
) -> Callable[..., Any]:
    """Instrument a LangGraph compiled graph using ``astream_events(v2)``.

    Unlike the synchronous ``instrument_langgraph``, this variant
    automatically captures per-node tool calls, LLM invocations, and
    errors from the event stream — nodes do **not** need to manually
    populate ``state["spans"]``.

    The existing ``instrument_langgraph`` function is preserved as-is for
    backward compatibility (AUDIT-FIX-11: do NOT replace invoke()).

    Args:
        graph: A compiled ``StateGraph`` (result of ``graph.compile()``).
        name: Workflow display name for TuringPulse.
        model: Default LLM model name.
        provider: Default LLM provider.

    Returns:
        An async callable ``run(state=...) -> state``.
    """

    _static_edges_async: List[str] = []
    try:
        builder = getattr(graph, "builder", None)
        if builder:
            for src, dst in getattr(builder, "edges", []):
                if src not in ("__start__", "__end__") and dst not in ("__start__", "__end__"):
                    _static_edges_async.append(f"{src}->{dst}")
            for src, branches in getattr(builder, "branches", {}).items():
                if src in ("__start__", "__end__"):
                    continue
                for _bname, branch in branches.items():
                    for _end_key, end_node in (getattr(branch, "ends", {}) or {}).items():
                        if end_node not in ("__start__", "__end__"):
                            _static_edges_async.append(f"{src}->{end_node}")
        elif hasattr(graph, "graph") and hasattr(graph.graph, "edges"):
            for src, dst in graph.graph.edges:
                if src not in ("__start__", "__end__") and dst not in ("__start__", "__end__"):
                    _static_edges_async.append(f"{src}->{dst}")
    except Exception:
        pass

    @instrument(name=name, kpis=kpis, metadata=metadata or {})
    async def run(state: Dict[str, Any]) -> Dict[str, Any]:
        t0 = time.time()

        ctx = current_context()
        auto_spans: List[Dict[str, Any]] = []
        final_state = dict(state)

        total_prompt = 0
        total_completion = 0
        total_cost = 0.0

        try:
            async for event in graph.astream_events(state, version="v2"):
                kind = event.get("event", "")
                ev_data = event.get("data", {})
                ev_name = event.get("name", "")

                if kind == "on_tool_start":
                    auto_spans.append({
                        "node": ev_name or "tool",
                        "node_type": "tool",
                        "status": "running",
                        "started_at": time.time(),
                        "input": ev_data.get("input", {}),
                        "tool_calls": [],
                        "metadata": {
                            "langgraph_event": "tool_start",
                            "langgraph_version": FRAMEWORK_VERSION,
                        },
                    })

                elif kind == "on_tool_end":
                    output = ev_data.get("output", "")
                    output_str = str(output)[:MAX_FIELD_SIZE] if output else ""
                    # Find the matching running tool span
                    for sp in reversed(auto_spans):
                        if sp.get("status") == "running" and sp.get("node_type") == "tool":
                            dur = int((time.time() - sp.pop("started_at", t0)) * 1000)
                            sp["duration_ms"] = dur
                            sp["status"] = "success"
                            sp["output"] = {"result": output_str}
                            sp["tool_calls"] = [{
                                "tool_name": sp.get("node", "unknown"),
                                "tool_args": sp.get("input", {}),
                                "tool_result": output_str,
                                "tool_id": str(uuid4()),
                                "success": True,
                            }]
                            break

                elif kind == "on_tool_error":
                    error_msg = str(ev_data.get("error", ""))[:MAX_FIELD_SIZE]
                    for sp in reversed(auto_spans):
                        if sp.get("status") == "running" and sp.get("node_type") == "tool":
                            dur = int((time.time() - sp.pop("started_at", t0)) * 1000)
                            sp["duration_ms"] = dur
                            sp["status"] = "error"
                            sp["output"] = {"error": error_msg}
                            sp["tool_calls"] = [{
                                "tool_name": sp.get("node", "unknown"),
                                "tool_args": sp.get("input", {}),
                                "tool_result": "",
                                "tool_id": str(uuid4()),
                                "success": False,
                                "error_message": error_msg,
                            }]
                            break

                elif kind == "on_chat_model_end":
                    llm_output = ev_data.get("output", {})
                    usage: Dict[str, Any] = {}
                    if hasattr(llm_output, "usage_metadata"):
                        usage = llm_output.usage_metadata or {}
                    elif isinstance(llm_output, dict):
                        usage = llm_output.get("usage_metadata", {})

                    prompt_tok = int(usage.get("input_tokens", 0) or 0)
                    comp_tok = int(usage.get("output_tokens", 0) or 0)
                    total_prompt += prompt_tok
                    total_completion += comp_tok

                    llm_cost = 0  # Backend calculates cost based on model pricing
                    total_cost += llm_cost

                    content = ""
                    if hasattr(llm_output, "content"):
                        content = str(llm_output.content)[:MAX_FIELD_SIZE]

                    auto_spans.append({
                        "node": ev_name or "llm",
                        "node_type": "llm",
                        "duration_ms": 0,
                        "status": "success",
                        "output": {"response": content},
                        "model": model,
                        "provider": provider,
                        "tokens": {"prompt": prompt_tok, "completion": comp_tok},
                        "cost_usd": round(llm_cost, 6),
                        "metadata": {
                            "langgraph_event": "chat_model_end",
                            "langgraph_version": FRAMEWORK_VERSION,
                        },
                    })

                # Capture the final state from the last chain_end event
                if kind == "on_chain_end" and ev_name == name:
                    if isinstance(ev_data.get("output"), dict):
                        final_state.update(ev_data["output"])

        except Exception as e:
            logger.warning("instrument_langgraph_async stream error: %s", type(e).__name__)
            # Fall back to ainvoke if streaming fails
            final_state = await graph.ainvoke(state)

        total_duration_ms = int((time.time() - t0) * 1000)

        if ctx:
            ctx.set_tokens(total_prompt, total_completion)
            ctx.set_cost(total_cost)
            ctx.set_model(model, provider)
            ctx.framework = FRAMEWORK_NAME
            ctx.node_type = "workflow"

            user_query = _pick_state_field(final_state, _INPUT_KEYS)
            final_output = _pick_state_field(final_state, _OUTPUT_KEYS)
            ctx.set_io(input_data=str(user_query)[:MAX_FIELD_SIZE], output_data=str(final_output)[:MAX_FIELD_SIZE])

            # Clean up any still-running spans (mark as timeout)
            for sp in auto_spans:
                if sp.get("status") == "running":
                    sp["status"] = "timeout"
                    sp.pop("started_at", None)
                    sp.setdefault("duration_ms", total_duration_ms)

            # Also include user-provided spans if present
            user_spans = final_state.get("spans", [])
            all_spans = auto_spans + user_spans

            _record_spans_in_fingerprint(ctx, all_spans, name, _static_edges_async)

            effective_workflow_name = ctx.workflow_name or name
            emit_child_spans(
                all_spans,
                run_id=ctx.run_id,
                parent_span_id=ctx.span_id,
                workflow_name=effective_workflow_name,
                framework=FRAMEWORK_NAME,
            )

        return final_state

    return run
