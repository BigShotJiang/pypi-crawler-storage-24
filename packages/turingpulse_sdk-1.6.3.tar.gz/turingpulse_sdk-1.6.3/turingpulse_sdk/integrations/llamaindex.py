"""LlamaIndex 0.14.x instrumentation for TuringPulse SDK.

Wraps a ``ReActAgent.run()`` invocation to capture:

- Token counts via ``TokenCountingHandler`` attached to the global
  ``Settings.callback_manager`` (the only reliable approach in v0.14+).
- Per-tool-call child spans from ``response.sources``.
- A final synthesis (LLM reasoning) span.

**Known shortfalls (LlamaIndex 0.14.x)**

1. ``TokenCountingHandler`` may **not** capture tokens when using the
   new ``agent.run()`` async API. The handler must be registered on
   ``Settings.callback_manager`` globally, not per-agent. Even then,
   some execution paths bypass the callback.
2. ``response.sources`` only contains tool-call outputs — the ReAct
   reasoning chain (Thought → Action → Observation) is **not** exposed.
3. Per-tool token breakdown is unavailable — we distribute aggregate
   totals evenly across steps.

Usage::

    from turingpulse_sdk.integrations.llamaindex import instrument_llamaindex
    from llama_index.core.agent import ReActAgent

    agent = ReActAgent(...)
    run_workflow = instrument_llamaindex(agent, name="my-llamaindex-workflow")
    result = await run_workflow(user_msg="Handle this request")
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Sequence

if TYPE_CHECKING:
    from ..kpi import KPIConfig

from ..config import MAX_FIELD_SIZE
from ..context import current_context
from ..decorators import instrument
from .base import emit_child_spans

logger = logging.getLogger("turingpulse.sdk.integrations.llamaindex")

FRAMEWORK_NAME = "llamaindex"
FRAMEWORK_VERSION = "0.14.10"


def instrument_llamaindex(
    agent: Any,
    *,
    name: str,
    model: str = "gpt-4o-mini",
    provider: str = "openai",
    tool_names: Optional[List[str]] = None,
    kpis: Optional[Sequence["KPIConfig"]] = None,
    metadata: Optional[Dict[str, str]] = None,
) -> Callable[..., Any]:
    """Instrument a LlamaIndex ``ReActAgent`` for TuringPulse observability.

    Returns an **async** callable that runs the agent and emits a root
    workflow span plus per-step child spans.

    Args:
        agent: A ``ReActAgent`` instance.
        name: Workflow display name for TuringPulse.
        model: LLM model name.
        provider: LLM provider.
        tool_names: List of available tool names for metadata.

    Returns:
        An async callable ``run(user_msg=...) -> AgentOutput``.
    """
    system_prompt = getattr(agent, "system_prompt", "") or ""
    _tool_names = tool_names or _get_agent_tool_names(agent)

    @instrument(name=name, kpis=kpis, metadata=metadata or {})
    async def run(user_msg: str) -> Any:
        # Set up a fresh TokenCountingHandler per run
        token_counter = _setup_token_counter()

        t0 = time.time()

        # LlamaIndex v0.14+ uses agent.run() which returns a coroutine
        handler = agent.run(user_msg=user_msg)
        response = await handler
        total_duration_ms = int((time.time() - t0) * 1000)

        ctx = current_context()
        if ctx is None:
            logger.warning("instrument_llamaindex: no active context")
            return response

        # ── Extract tokens ──
        total_prompt = token_counter.prompt_llm_token_count if token_counter else 0
        total_completion = token_counter.completion_llm_token_count if token_counter else 0

        # Fallback estimation if callback didn't fire
        sources = getattr(response, "sources", []) or []
        if total_prompt == 0 and total_completion == 0:
            num_steps = max(len(sources), 1)
            total_prompt = num_steps * 500
            total_completion = num_steps * 200

        total_cost = 0  # Backend calculates cost based on model pricing

        ctx.set_tokens(total_prompt, total_completion)
        ctx.set_cost(total_cost)
        ctx.set_model(model, provider)
        ctx.set_prompt(user_msg[:MAX_FIELD_SIZE], system_prompt[:MAX_FIELD_SIZE])
        ctx.framework = FRAMEWORK_NAME
        ctx.node_type = "workflow"
        if _tool_names:
            ctx.available_tools = _tool_names

        final_output = _extract_final_output(response)
        ctx.set_io(input_data=user_msg[:MAX_FIELD_SIZE], output_data=final_output[:MAX_FIELD_SIZE])

        # ── Build child spans ──
        child_spans = _build_react_spans(
            response, sources,
            total_duration_ms, total_prompt, total_completion,
            model, provider, user_msg, system_prompt,
            _tool_names,
        )
        emit_child_spans(
            child_spans,
            run_id=ctx.run_id,
            parent_span_id=ctx.span_id,
            workflow_name=name,
            framework=FRAMEWORK_NAME,
        )

        return response

    return run


# ── Helpers ──────────────────────────────────────────────────────────────


def _setup_token_counter() -> Any:
    """Create and register a ``TokenCountingHandler`` on the global Settings."""
    try:
        from llama_index.core.callbacks import CallbackManager, TokenCountingHandler
        from llama_index.core import Settings

        counter = TokenCountingHandler()
        Settings.callback_manager = CallbackManager([counter])
        return counter
    except Exception as exc:
        logger.debug("Failed to set up TokenCountingHandler: %s", exc)
        return None


def _get_agent_tool_names(agent: Any) -> List[str]:
    """Extract tool names from a ReActAgent's tool list."""
    tools = getattr(agent, "tools", []) or []
    names: List[str] = []
    for t in tools:
        meta = getattr(t, "metadata", None)
        if meta and hasattr(meta, "name"):
            names.append(meta.name)
        elif hasattr(t, "name"):
            names.append(t.name)
    return names


def _extract_final_output(response: Any) -> str:
    """Get the final text from a LlamaIndex agent response."""
    if hasattr(response, "response"):
        return str(response.response)
    if hasattr(response, "text"):
        return str(response.text)
    return str(response)


def _build_react_spans(
    response: Any,
    sources: list,
    total_duration_ms: int,
    total_prompt: int,
    total_completion: int,
    model: str,
    provider: str,
    user_msg: str,
    system_prompt: str,
    tool_names: List[str],
) -> List[Dict[str, Any]]:
    """Build child span dicts from ReActAgent sources."""
    spans: List[Dict[str, Any]] = []

    num_steps = max(len(sources) + 1, 2)  # +1 for synthesis
    step_prompt = total_prompt // num_steps
    step_completion = total_completion // num_steps
    step_cost = 0  # Backend calculates cost based on model pricing
    step_dur = total_duration_ms // num_steps

    # ── Tool-call spans from sources ──
    for i, source in enumerate(sources):
        tool_name = getattr(source, "tool_name", None) or f"step_{i}"
        raw_input = getattr(source, "raw_input", {}) or {}
        content = getattr(source, "content", str(source))

        # Detect tool call failures via LlamaIndex is_error attribute
        is_error = getattr(source, "is_error", False)
        tc_error_msg = None
        if is_error:
            tc_error_msg = str(content)[:MAX_FIELD_SIZE] if content else "Tool execution failed"

        tc_data = [{
            "tool_name": tool_name,
            "tool_args": raw_input if isinstance(raw_input, dict) else {"query": str(raw_input)[:MAX_FIELD_SIZE]},
            "tool_result": str(content)[:MAX_FIELD_SIZE],
            "tool_id": f"react_{i}",
            "success": not is_error,
            "error_message": tc_error_msg,
        }]

        tool_status = "error" if is_error else "success"
        spans.append({
            "node": f"react_{tool_name}",
            "node_type": "tool",
            "duration_ms": step_dur,
            "status": tool_status,
            "input": raw_input if isinstance(raw_input, dict) else {"query": str(raw_input)[:MAX_FIELD_SIZE]},
            "output": {"result": str(content)[:MAX_FIELD_SIZE]},
            "tokens": {"prompt": step_prompt, "completion": step_completion},
            "cost_usd": round(step_cost, 6),
            "tool_calls": tc_data,
            "available_tools": tool_names,
            "metadata": {
                "llamaindex_component": "ReActAgent",
                "llamaindex_step_type": "tool_call",
                "llamaindex_tool_name": tool_name,
                "llamaindex_step_index": str(i),
                "llamaindex_version": FRAMEWORK_VERSION,
            },
        })

    # ── Final synthesis span ──
    final_text = _extract_final_output(response)
    spans.append({
        "node": "react_synthesis",
        "node_type": "llm",
        "duration_ms": step_dur,
        "status": "success",
        "prompt": "Synthesize tool results and provide final response.",
        "system_prompt": system_prompt[:MAX_FIELD_SIZE],
        "input": {"sources_count": len(sources), "user_msg": user_msg[:MAX_FIELD_SIZE]},
        "output": {"response": final_text[:MAX_FIELD_SIZE]},
        "model": model,
        "provider": provider,
        "tokens": {"prompt": step_prompt, "completion": step_completion},
        "cost_usd": round(step_cost, 6),
        "available_tools": tool_names,
        "metadata": {
            "llamaindex_component": "ReActAgent",
            "llamaindex_step_type": "synthesis",
            "llamaindex_total_prompt_tokens": str(total_prompt),
            "llamaindex_total_completion_tokens": str(total_completion),
            "llamaindex_version": FRAMEWORK_VERSION,
        },
    })

    return spans
