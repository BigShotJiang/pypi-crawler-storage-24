"""Deploy tracking for change detection and root cause analysis."""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger("turingpulse.sdk.deploy")


@dataclass
class DeployInfo:
    """Information about a deployment."""
    
    provider: str
    """CI/CD provider (github, gitlab, jenkins, etc.)."""
    
    git_sha: Optional[str] = None
    """Git commit SHA."""
    
    version_tag: Optional[str] = None
    """Version tag or branch name."""
    
    commit_message: Optional[str] = None
    """Commit message."""
    
    deployed_at: Optional[datetime] = None
    """Deployment timestamp."""
    
    metadata: Optional[Dict[str, Any]] = None
    """Additional metadata."""


class AutoDeployDetector:
    """Automatically detect deployment info from CI/CD environment variables.
    
    Supports:
    - GitHub Actions
    - GitLab CI
    - CircleCI
    - Jenkins
    - Azure DevOps
    - Bitbucket Pipelines
    - Travis CI
    """
    
    # CI/CD provider detection and variable mapping
    PROVIDERS: Dict[str, Dict[str, List[str]]] = {
        "github": {
            "detect": ["GITHUB_ACTIONS"],
            "sha": ["GITHUB_SHA"],
            "ref": ["GITHUB_REF", "GITHUB_REF_NAME"],
            "message": ["GITHUB_EVENT_HEAD_COMMIT_MESSAGE"],
            "run_id": ["GITHUB_RUN_ID"],
            "workflow": ["GITHUB_WORKFLOW"],
            "actor": ["GITHUB_ACTOR"],
        },
        "gitlab": {
            "detect": ["GITLAB_CI"],
            "sha": ["CI_COMMIT_SHA"],
            "ref": ["CI_COMMIT_REF_NAME", "CI_COMMIT_TAG"],
            "message": ["CI_COMMIT_MESSAGE"],
            "pipeline_id": ["CI_PIPELINE_ID"],
            "job_name": ["CI_JOB_NAME"],
            "user": ["GITLAB_USER_LOGIN"],
        },
        "circleci": {
            "detect": ["CIRCLECI"],
            "sha": ["CIRCLE_SHA1"],
            "ref": ["CIRCLE_TAG", "CIRCLE_BRANCH"],
            "build_num": ["CIRCLE_BUILD_NUM"],
            "workflow_id": ["CIRCLE_WORKFLOW_ID"],
            "username": ["CIRCLE_USERNAME"],
        },
        "jenkins": {
            "detect": ["JENKINS_URL", "BUILD_NUMBER"],
            "sha": ["GIT_COMMIT"],
            "ref": ["GIT_BRANCH", "BUILD_TAG"],
            "build_num": ["BUILD_NUMBER"],
            "job_name": ["JOB_NAME"],
            "user": ["BUILD_USER"],
        },
        "azure": {
            "detect": ["TF_BUILD", "AZURE_PIPELINES"],
            "sha": ["BUILD_SOURCEVERSION"],
            "ref": ["BUILD_SOURCEBRANCH", "BUILD_SOURCEBRANCHNAME"],
            "build_id": ["BUILD_BUILDID"],
            "pipeline_name": ["BUILD_DEFINITIONNAME"],
            "requester": ["BUILD_REQUESTEDFOR"],
        },
        "bitbucket": {
            "detect": ["BITBUCKET_PIPELINE_UUID"],
            "sha": ["BITBUCKET_COMMIT"],
            "ref": ["BITBUCKET_TAG", "BITBUCKET_BRANCH"],
            "build_num": ["BITBUCKET_BUILD_NUMBER"],
            "pipeline_uuid": ["BITBUCKET_PIPELINE_UUID"],
        },
        "travis": {
            "detect": ["TRAVIS"],
            "sha": ["TRAVIS_COMMIT"],
            "ref": ["TRAVIS_TAG", "TRAVIS_BRANCH"],
            "message": ["TRAVIS_COMMIT_MESSAGE"],
            "build_id": ["TRAVIS_BUILD_ID"],
            "job_id": ["TRAVIS_JOB_ID"],
        },
    }
    
    @classmethod
    def detect(cls) -> Optional[DeployInfo]:
        """Detect deployment info from environment variables.
        
        Returns:
            DeployInfo if running in a known CI/CD environment, None otherwise
        """
        for provider, config in cls.PROVIDERS.items():
            # Check if we're in this CI environment
            detect_vars = config.get("detect", [])
            if not all(os.getenv(var) for var in detect_vars):
                continue
            
            # We're in this CI environment, extract info
            git_sha = cls._get_first_env(config.get("sha", []))
            version_tag = cls._get_first_env(config.get("ref", []))
            commit_message = cls._get_first_env(config.get("message", []))
            
            # Build metadata from other available vars
            metadata: Dict[str, str] = {}
            for key, env_vars in config.items():
                if key in ("detect", "sha", "ref", "message"):
                    continue
                value = cls._get_first_env(env_vars)
                if value:
                    metadata[key] = value
            
            return DeployInfo(
                provider=provider,
                git_sha=git_sha,
                version_tag=version_tag,
                commit_message=commit_message,
                deployed_at=datetime.now(timezone.utc),
                metadata=metadata if metadata else None,
            )
        
        return None
    
    @staticmethod
    def _get_first_env(env_vars: List[str]) -> Optional[str]:
        """Get the first non-empty environment variable value."""
        for var in env_vars:
            value = os.getenv(var)
            if value:
                return value
        return None


def register_deploy(
    workflow_id: str,
    version: Optional[str] = None,
    git_sha: Optional[str] = None,
    commit_message: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    deployed_at: Optional[datetime] = None,
    auto_detect: bool = True,
) -> bool:
    """Register a deployment event with TuringPulse.
    
    Call this from your CI/CD pipeline or application startup to track deployments.
    Deployment events are correlated with anomalies and drifts for root cause analysis.
    
    Args:
        workflow_id: The workflow ID this deployment affects
        version: Version tag (e.g., "v1.2.3")
        git_sha: Git commit SHA
        commit_message: Git commit message
        metadata: Additional metadata
        deployed_at: Deployment timestamp (defaults to now)
        auto_detect: If True, auto-detect from CI/CD environment variables
    
    Returns:
        True if deploy was registered successfully, False otherwise
    
    Example:
        from turingpulse_sdk import register_deploy
        import os
        
        # Manual registration
        register_deploy(
            workflow_id="chat-assistant",
            version="v1.2.3",
            git_sha=os.getenv("GIT_SHA"),
            commit_message=os.getenv("GIT_COMMIT_MSG"),
        )
        
        # Auto-detect from CI/CD environment
        register_deploy(
            workflow_id="chat-assistant",
            auto_detect=True,
        )
    """
    from .plugin import get_plugin
    from .exceptions import PluginNotInitializedError

    if not workflow_id or not workflow_id.strip():
        logger.warning("register_deploy called with empty workflow_id — skipping")
        return False

    # Auto-detect if requested
    if auto_detect:
        detected = AutoDeployDetector.detect()
        if detected:
            git_sha = git_sha or detected.git_sha
            version = version or detected.version_tag
            commit_message = commit_message or detected.commit_message
            deployed_at = deployed_at or detected.deployed_at
            if detected.metadata:
                metadata = {**(detected.metadata or {}), **(metadata or {})}
    
    try:
        plugin = get_plugin()
    except PluginNotInitializedError:
        logger.warning("Cannot register deploy: TuringPulse plugin not initialized")
        return False

    payload = {
        "workflow_id": workflow_id,
        "version_tag": version,
        "git_sha": git_sha,
        "commit_message": commit_message,
        "deployed_at": deployed_at.isoformat() if deployed_at else datetime.now(timezone.utc).isoformat(),
        "metadata": metadata or {},
    }

    try:
        result = plugin.client.post_deploy(payload)
        if result and result.get("success"):
            logger.debug(
                "Registered deploy for workflow %s: version=%s, git_sha=%s",
                workflow_id, version, git_sha,
            )
            return True
        logger.warning("Failed to register deploy: unexpected response")
        return False
    except Exception as exc:
        logger.warning("Failed to register deploy: %s", type(exc).__name__)
        return False

