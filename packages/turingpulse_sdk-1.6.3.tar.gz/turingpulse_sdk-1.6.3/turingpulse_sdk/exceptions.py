"""Custom exceptions used by the plugin."""

from __future__ import annotations

from typing import List, Optional


class TuringPulsePluginError(RuntimeError):
    """Base error for plugin issues."""


class PluginNotInitializedError(TuringPulsePluginError):
    """Raised when instrumentation is used before calling init()."""


class TriggerNotFoundError(TuringPulsePluginError):
    """Raised when a trigger key is missing from the registry."""


class GovernanceBlockedError(TuringPulsePluginError):
    """Raised when a HITL policy check returns 'block' before execution."""

    def __init__(
        self,
        reason: Optional[str] = None,
        policy_ids: Optional[List[str]] = None,
    ):
        self.reason = reason
        self.policy_ids = policy_ids or []
        super().__init__(
            f"Execution blocked by governance policy: {reason or 'no reason provided'}"
        )


class ConfigurationError(TuringPulsePluginError):
    """Raised when SDK configuration is invalid or incomplete."""


