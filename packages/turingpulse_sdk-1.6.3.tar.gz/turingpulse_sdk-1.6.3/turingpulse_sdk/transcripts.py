"""Helpers for capturing chat transcripts via the TuringPulse SDK."""

from __future__ import annotations

from typing import Any, Iterable, Optional, Sequence

from .instrumentation import TranscriptCollector


def serialize_messages(messages: Optional[Iterable[Any]]) -> list[dict[str, str]]:
    """Convert an iterable of message-like objects into a JSON-friendly structure."""
    serialized: list[dict[str, str]] = []
    if not messages:
        return serialized
    for message in messages:
        role = _safe_get_attr(message, "role")
        content = _safe_get_attr(message, "content")
        if content is None and hasattr(message, "model_dump"):
            data = message.model_dump()
            role = role or data.get("role")
            content = data.get("content")
        if isinstance(message, dict):
            role = role or message.get("role")
            content = content or message.get("content")
        if content is None:
            continue
        serialized.append({"role": str(role or "unknown"), "content": str(content)})
    return serialized


def chat_request_transcript(
    request_arg: str = "chat_request",
    request_messages_attr: str = "messages",
    response_messages_attr: str = "messages",
    include_response: bool = True,
) -> TranscriptCollector:
    """Return a transcript collector that extracts messages from a request/response pair."""

    def collector(args: tuple, kwargs: dict, result: Any = None, error: BaseException | None = None):
        request_obj = kwargs.get(request_arg)
        if request_obj is None and args:
            request_obj = _find_obj_with_attr(args, request_messages_attr)
        if request_obj is None:
            return None

        transcript = serialize_messages(getattr(request_obj, request_messages_attr, None))

        if include_response and result is not None:
            response_messages = getattr(result, response_messages_attr, None)
            transcript.extend(serialize_messages(response_messages))
        return transcript

    return collector


def _find_obj_with_attr(values: Sequence[Any], attr: str) -> Any | None:
    for value in values:
        if hasattr(value, attr):
            return value
    return None


def _safe_get_attr(obj: Any, attr: str) -> Any | None:
    try:
        return getattr(obj, attr, None)
    except Exception:
        return None


