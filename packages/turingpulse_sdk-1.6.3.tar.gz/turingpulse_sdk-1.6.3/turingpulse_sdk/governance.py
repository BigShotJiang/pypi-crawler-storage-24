"""Governance directives (HITL/HATL/HOTL) + enforcement helpers."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Dict, Iterable, List, Optional

from pydantic import BaseModel, Field

from .config import TuringPulseConfig
from .context import ExecutionContext
from .kpi import KPIResult

logger = logging.getLogger("turingpulse.sdk.governance")


class GovernanceMode(str, Enum):
    HITL = "hitl"
    HATL = "hatl"
    HOTL = "hotl"


@dataclass
class GovernanceTaskResult:
    mode: GovernanceMode
    task_id: Optional[str]


class GovernanceDirective(BaseModel):
    hitl: bool = False
    hatl: bool = False
    hotl: bool = False
    reviewers: List[str] = Field(default_factory=list)
    escalation_channels: List[str] = Field(default_factory=list)
    title: Optional[str] = None
    notes: Optional[str] = None
    metadata: Dict[str, str] = Field(default_factory=dict)
    severity: str = "medium"
    auto_escalate_after_seconds: Optional[int] = None
    task_prefix: Optional[str] = None

    def enabled_modes(self) -> Iterable[GovernanceMode]:
        if self.hitl:
            yield GovernanceMode.HITL
        if self.hatl:
            yield GovernanceMode.HATL
        if self.hotl:
            yield GovernanceMode.HOTL


def _mode_title(mode: GovernanceMode) -> str:
    if mode == GovernanceMode.HITL:
        return "Human-in-the-loop"
    if mode == GovernanceMode.HATL:
        return "Human-after-the-loop"
    return "Human-on-the-loop"


def _default_task_status(mode: GovernanceMode) -> str:
    if mode == GovernanceMode.HITL:
        return "needs_human"
    if mode == GovernanceMode.HOTL:
        return "in_progress"
    return "todo"


class GovernanceManager:
    def __init__(self, client, config: TuringPulseConfig):
        self._client = client
        self._config = config

    def enforce(
        self,
        directive: GovernanceDirective,
        context: ExecutionContext,
        kpi_results: Iterable[KPIResult],
    ) -> list[GovernanceTaskResult]:
        tasks: list[GovernanceTaskResult] = []
        if not directive:
            return tasks

        metadata = self._build_metadata(directive, context, kpi_results)
        for mode in directive.enabled_modes():
            payload = self._build_task_payload(mode, directive, context, metadata)
            try:
                task_id = self._client.create_task(payload)
                tasks.append(GovernanceTaskResult(mode=mode, task_id=task_id))
            except Exception as exc:  # pragma: no cover - defensive network layer
                logger.warning("Failed to create governance task for %s: %s", mode.value, type(exc).__name__)
        return tasks

    def _build_metadata(
        self,
        directive: GovernanceDirective,
        context: ExecutionContext,
        kpi_results: Iterable[KPIResult],
    ) -> Dict[str, str]:
        metadata = dict(self._config.governance_defaults.metadata)
        metadata.update(directive.metadata)
        metadata.setdefault("severity", directive.severity or self._config.governance_defaults.severity)
        metadata["agent.run_id"] = context.run_id
        metadata["agent.operation"] = context.operation
        metadata["agent.hidden_entrypoint"] = str(context.hidden_entrypoint).lower()
        for result in kpi_results:
            metadata.update(result.metadata())
        return metadata

    def _build_task_payload(
        self,
        mode: GovernanceMode,
        directive: GovernanceDirective,
        context: ExecutionContext,
        metadata: Dict[str, str],
    ) -> Dict[str, object]:
        title = directive.title or f"{_mode_title(mode)} review for {context.operation}"
        task_id_prefix = directive.task_prefix or context.run_id
        task_id = f"{task_id_prefix}-{mode.value}"
        gov_metadata: Dict[str, str] = {
            **metadata,
            "governance.mode": mode.value,
            "governance.reviewers": ",".join(directive.reviewers or self._config.governance_defaults.reviewers),
            "governance.channels": ",".join(
                directive.escalation_channels or self._config.governance_defaults.escalation_channels
            ),
        }
        if directive.notes:
            gov_metadata["governance.notes"] = directive.notes
        escalate_secs = (
            directive.auto_escalate_after_seconds
            if directive.auto_escalate_after_seconds is not None
            else self._config.governance_defaults.auto_escalate_after_seconds
        )
        if escalate_secs is not None:
            gov_metadata["governance.auto_escalate_after_seconds"] = str(escalate_secs)
        payload: Dict[str, object] = {
            "task_id": task_id,
            "title": title,
            "status": _default_task_status(mode),
            "agent_run_id": context.run_id,
            "hitl_required": mode == GovernanceMode.HITL,
            "metadata": gov_metadata,
        }
        return payload


