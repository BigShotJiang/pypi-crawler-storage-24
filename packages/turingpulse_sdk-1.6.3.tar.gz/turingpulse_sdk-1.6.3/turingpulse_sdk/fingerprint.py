"""Fingerprinting for workflow structure and change detection.

The fingerprint builder captures a compact representation of every workflow run so
that the backend can automatically detect **8 change types** by comparing
consecutive fingerprints:

    1. structure     — node/edge additions or removals
    2. config        — general configuration changes (non-model, non-eval, non-policy)
    3. prompt        — system prompt changes on LLM nodes
    4. model_change  — LLM model identity or generation parameters changed
    5. eval_config_change  — evaluation / scoring / judging config changed
    6. policy_change — guardrail / safety / moderation / rate-limit config changed
    7. graph_version_change — (detected server-side from graph_snapshot_id transitions)
    8. deploy        — (registered externally via CI/CD or API; not from fingerprint)
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger("turingpulse.sdk.fingerprint")


# ---------------------------------------------------------------------------
# Config key classification — determines which hash category a config key
# belongs to.  Keys are matched **case-insensitively**.
# ---------------------------------------------------------------------------

MODEL_CONFIG_KEYS: FrozenSet[str] = frozenset({
    # Identity (snake_case + camelCase variants across all providers)
    "model", "model_name", "modelname", "model_id", "modelid",
    # Generation parameters — snake_case
    "temperature", "top_p", "top_k", "max_tokens", "max_output_tokens",
    "frequency_penalty", "presence_penalty",
    "stop", "stop_sequences",
    "candidate_count", "response_format", "context_window", "model_kwargs",
    # Generation parameters — camelCase (JS SDKs, Bedrock, Google)
    "maxtokens", "maxoutputtokens", "topp", "topk",
    "frequencypenalty", "presencepenalty",
    "stopsequences", "candidatecount", "responseformat",
    "contextwindow", "modelkwargs",
    # Cohere aliases (p = top_p, k = top_k)
    "p", "k",
})

EVAL_CONFIG_KEYS: FrozenSet[str] = frozenset({
    "eval_model", "eval_prompt", "eval_criteria", "eval_rubric",
    "eval_config", "eval_threshold", "eval_type", "eval_template",
    "evaluation_model", "evaluation_prompt", "evaluation_criteria",
    "scoring_rubric", "scoring_model", "scoring_prompt", "scoring_criteria",
    "judge_model", "judge_prompt", "judge_criteria", "judge_config",
    "grading_rubric", "grading_model", "grading_criteria",
    "rubric", "criteria", "judge",
})

POLICY_CONFIG_KEYS: FrozenSet[str] = frozenset({
    "policy", "policy_config", "policy_rules", "policy_model",
    "guard", "guardrail", "guardrails", "guard_config",
    "guardrail_config", "guardrail_rules",
    "filter", "content_filter", "content_filter_config",
    "moderation", "moderation_config", "moderation_model",
    "safety", "safety_config", "safety_threshold",
    "rate_limit", "rate_limit_config",
    "max_retries", "timeout",
})


def classify_config_key(key: str) -> str:
    """Classify a config key into a hash category.

    Returns one of: ``"model"``, ``"eval"``, ``"policy"``, or ``"general"``.
    Matching is case-insensitive and also supports prefix matching for keys
    like ``eval_*``, ``policy_*``, ``guard*``, etc.
    """
    lower = key.lower()

    if lower in MODEL_CONFIG_KEYS:
        return "model"
    if lower in EVAL_CONFIG_KEYS:
        return "eval"
    if lower in POLICY_CONFIG_KEYS:
        return "policy"

    # Prefix-based fallback for extensibility
    if lower.startswith(("eval_", "evaluation_", "scoring_", "judge_", "grading_")):
        return "eval"
    if lower.startswith(("policy_", "guard", "guardrail", "filter_", "moderation_", "safety_")):
        return "policy"

    return "general"


def split_config(config: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Split a flat config dict into categorised sub-dicts.

    Returns ``{"model": {...}, "eval": {...}, "policy": {...}, "general": {...}}``.
    Only categories with at least one key are included.
    """
    buckets: Dict[str, Dict[str, Any]] = {}
    for key, value in config.items():
        category = classify_config_key(key)
        buckets.setdefault(category, {})[key] = value
    return buckets


class FingerprintConfig(BaseModel):
    """Configuration for fingerprinting and change detection."""

    enabled: bool = True
    """Master switch for fingerprinting."""

    capture_prompts: bool = True
    """Hash prompts for change detection."""

    capture_configs: bool = True
    """Hash configs for change detection."""

    capture_structure: bool = True
    """Track DAG structure and edges."""

    sensitive_config_keys: List[str] = Field(
        default_factory=lambda: ["api_key", "password", "secret", "token", "key", "credential"]
    )
    """Config keys to redact before hashing."""

    send_async: bool = True
    """Send fingerprint asynchronously."""

    send_on_failure: bool = True
    """Send fingerprint even if run fails."""

    class Config:
        frozen = True


class FingerprintData(BaseModel):
    """Fingerprint data to be sent to backend."""

    structure_hash: str
    """Hash of the overall workflow structure."""

    node_sequence: List[str] = Field(default_factory=list)
    """Ordered sequence of node names."""

    node_types: Dict[str, int] = Field(default_factory=dict)
    """Count of nodes by type: {"llm": 2, "tool": 1}."""

    node_type_mapping: Dict[str, str] = Field(default_factory=dict)
    """Per-node type mapping: {"my_llm_node": "llm", "my_tool_node": "tool"}."""

    edges: List[str] = Field(default_factory=list)
    """Parent->child edges: ["parent->child", ...]."""

    # -- Legacy combined hash (kept for backward compat) --
    node_config_hashes: Dict[str, str] = Field(default_factory=dict)
    """Hash of each node's *full* config: {"node_name": "hash"}."""

    node_prompt_hashes: Dict[str, str] = Field(default_factory=dict)
    """Hash of each LLM node's prompt: {"llm_node": "hash"}."""

    # -- Categorised config hashes (new) --
    node_model_hashes: Dict[str, str] = Field(default_factory=dict)
    """Hash of model-identity + generation params per LLM node."""

    node_eval_config_hashes: Dict[str, str] = Field(default_factory=dict)
    """Hash of evaluation/scoring config per node."""

    node_policy_config_hashes: Dict[str, str] = Field(default_factory=dict)
    """Hash of guardrail/safety/policy config per node."""


@dataclass
class FingerprintBuilder:
    """Builds workflow fingerprints during execution.

    Collects information about nodes, their types, configs, and prompts
    during workflow execution to create a fingerprint that enables
    fine-grained change detection across 8 attribution categories.

    Example::

        builder = FingerprintBuilder(config)
        builder.record_node(
            "chat_llm", "llm",
            {"model": "gpt-4", "temperature": 0.7},
            "You are a helpful assistant",
        )
        builder.record_node("search_tool", "tool", {"api": "google"})
        fingerprint = builder.get_fingerprint()
    """

    config: FingerprintConfig
    nodes: List[str] = field(default_factory=list)
    node_types: Dict[str, str] = field(default_factory=dict)
    node_type_counts: Dict[str, int] = field(default_factory=dict)
    edges: List[str] = field(default_factory=list)
    parent_stack: List[str] = field(default_factory=list)

    # Legacy combined config hash (backward compat)
    node_configs: Dict[str, str] = field(default_factory=dict)
    node_prompts: Dict[str, str] = field(default_factory=dict)

    # Categorised config hashes
    node_model_configs: Dict[str, str] = field(default_factory=dict)
    node_eval_configs: Dict[str, str] = field(default_factory=dict)
    node_policy_configs: Dict[str, str] = field(default_factory=dict)

    # Pre-computed lowercase sensitive keys (avoids recomputation on every call)
    _sensitive_keys_lower: frozenset = field(default_factory=frozenset, repr=False)

    def __post_init__(self):
        object.__setattr__(
            self,
            "_sensitive_keys_lower",
            frozenset(k.lower() for k in self.config.sensitive_config_keys),
        )

    def push_parent(self, node_name: str) -> None:
        """Push a node onto the parent stack for edge tracking."""
        self.parent_stack.append(node_name)

    def pop_parent(self) -> Optional[str]:
        """Pop the current parent from the stack."""
        if self.parent_stack:
            return self.parent_stack.pop()
        return None

    def current_parent(self) -> Optional[str]:
        """Get the current parent node (top of stack)."""
        return self.parent_stack[-1] if self.parent_stack else None

    def record_node(
        self,
        name: str,
        node_type: str,
        config: Optional[Any] = None,
        prompt: Optional[str] = None,
    ) -> None:
        """Record a node in the fingerprint.

        The config dict is automatically split into categories (model, eval,
        policy, general) and hashed separately.  The combined hash is also
        retained for backward compatibility with older backend versions.

        Args:
            name: Unique name for this node
            node_type: Type of node (``"llm"``, ``"tool"``, ``"function"``, ``"retriever"``)
            config: Configuration dict for the node (will be categorised and hashed)
            prompt: System prompt for LLM nodes (will be hashed)
        """
        if name in self.node_types:
            logger.debug("Node %s already recorded, skipping", name)
            return

        self.nodes.append(name)
        self.node_types[name] = node_type
        self.node_type_counts[node_type] = self.node_type_counts.get(node_type, 0) + 1

        # Record edge from parent
        if self.config.capture_structure:
            parent = self.current_parent()
            if parent:
                edge = f"{parent}->{name}"
                if edge not in self.edges:
                    self.edges.append(edge)

        # Hash and store config (both combined and per-category)
        if self.config.capture_configs and config is not None:
            sanitized = self._sanitize_config(config)

            # Legacy combined hash (backward compat)
            self.node_configs[name] = self._hash_value(sanitized)

            # Categorised hashes
            if isinstance(sanitized, dict):
                buckets = split_config(sanitized)
                if "model" in buckets:
                    self.node_model_configs[name] = self._hash_value(buckets["model"])
                if "eval" in buckets:
                    self.node_eval_configs[name] = self._hash_value(buckets["eval"])
                if "policy" in buckets:
                    self.node_policy_configs[name] = self._hash_value(buckets["policy"])

        # Hash and store prompt
        if self.config.capture_prompts and prompt is not None:
            self.node_prompts[name] = self._hash_value(prompt)

    def get_fingerprint(self) -> FingerprintData:
        """Build and return the final fingerprint data."""
        structure_data = {
            "nodes": self.nodes,
            "node_types": self.node_types,
            "edges": self.edges,
        }
        structure_hash = self._hash_value(structure_data)

        return FingerprintData(
            structure_hash=structure_hash,
            node_sequence=self.nodes.copy(),
            node_types=self.node_type_counts.copy(),
            node_type_mapping=self.node_types.copy(),
            edges=self.edges.copy(),
            node_config_hashes=self.node_configs.copy(),
            node_prompt_hashes=self.node_prompts.copy(),
            node_model_hashes=self.node_model_configs.copy(),
            node_eval_config_hashes=self.node_eval_configs.copy(),
            node_policy_config_hashes=self.node_policy_configs.copy(),
        )

    def _sanitize_config(self, config: Any, _depth: int = 0) -> Any:
        """Remove sensitive keys from config before hashing."""
        if _depth > 20 or not isinstance(config, (dict, list)):
            return config

        if isinstance(config, list):
            return [self._sanitize_config(item, _depth + 1) for item in config]

        sanitized = {}
        for key, value in config.items():
            if key.lower() in self._sensitive_keys_lower:
                sanitized[key] = "[REDACTED]"
            elif isinstance(value, (dict, list)):
                sanitized[key] = self._sanitize_config(value, _depth + 1)
            else:
                sanitized[key] = value

        return sanitized

    def _hash_value(self, value: Any) -> str:
        """Hash a value using SHA-256 (truncated to 16 hex chars)."""
        if isinstance(value, str):
            data = value.encode("utf-8")
        else:
            try:
                data = json.dumps(value, sort_keys=True, ensure_ascii=False).encode("utf-8")
            except (TypeError, ValueError):
                data = str(value).encode("utf-8")

        return hashlib.sha256(data).hexdigest()[:16]


def extract_prompt_from_messages(messages: List[Dict[str, Any]]) -> Optional[str]:
    """Extract system prompt from a list of chat messages.

    Args:
        messages: List of message dicts with 'role' and 'content' keys

    Returns:
        The system prompt if found, otherwise None
    """
    if not messages:
        return None

    for msg in messages:
        if isinstance(msg, dict) and msg.get("role") == "system":
            content = msg.get("content", "")
            if isinstance(content, str):
                return content
            elif isinstance(content, list):
                parts = []
                for part in content:
                    if isinstance(part, str):
                        parts.append(part)
                    elif isinstance(part, dict) and "text" in part:
                        parts.append(part["text"])
                return " ".join(parts) if parts else None

    return None


def extract_config_subset(kwargs: Dict[str, Any], keys: List[str]) -> Dict[str, Any]:
    """Extract a subset of config keys from kwargs.

    Args:
        kwargs: Full kwargs dict
        keys: Keys to extract

    Returns:
        Dict with only the specified keys that exist
    """
    return {k: kwargs[k] for k in keys if k in kwargs}

