"""Execution context propagated through instrumentation lifecycle.

Provides ``ExecutionContext`` which carries per-invocation state through the
``@instrument`` decorator chain and is accessible via ``current_context()``.

Fields added for framework instrumentation:
- Token / cost tracking (``set_tokens``, ``set_cost``)
- LLM model / provider (``set_model``)
- Prompt capture (``set_prompt``)
- Tool-call recording (``add_tool_call``)

These fields are populated by the framework-specific integration modules
in ``turingpulse_sdk.integrations`` and are read by ``_build_event()``
in ``plugin.py`` to populate ``AgentEventPayload.tokens``,
``AgentEventPayload.cost_usd``, and ``AgentEventPayload.tool_calls``.
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple
from uuid import uuid4

from turingpulse_interfaces import ToolCallInfo

from .config import MAX_FIELD_SIZE

MAX_TOOL_CALLS_PER_SPAN = 200

if TYPE_CHECKING:
    from .fingerprint import FingerprintBuilder


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class ExecutionContext:
    """Execution context for instrumented functions.

    Core fields (set by ``@instrument`` / plugin):
        run_id, agent_id, operation, span_id, parent_span_id, depth, …

    Telemetry fields (set by framework integrations or user code):
        tokens_input, tokens_output, cost_usd, model, provider,
        prompt_text, system_prompt, node_type, tool_calls, input_data,
        output_data, available_tools, framework.
    """

    # --- core identity ---
    run_id: str
    agent_id: Optional[str] = None  # DEPRECATED: Use workflow_name
    operation: str = ""
    trigger_key: Optional[str] = None
    hidden_entrypoint: bool = False
    labels: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, str] = field(default_factory=dict)
    args: Tuple[Any, ...] = field(default_factory=tuple)
    kwargs: Dict[str, Any] = field(default_factory=dict)
    started_at: datetime = field(default_factory=utcnow)
    completed_at: Optional[datetime] = None
    error: Optional[BaseException] = None
    result: Any = None
    status: str = "pending"
    span_id: str = field(default_factory=lambda: uuid4().hex)
    parent_span_id: Optional[str] = None
    depth: int = 0
    fingerprint_builder: Optional["FingerprintBuilder"] = None
    workflow_id: Optional[str] = None  # DEPRECATED: Backend assigns UUID
    workflow_name: Optional[str] = None

    # --- telemetry (populated by framework integrations) ---
    tokens_input: int = 0
    tokens_output: int = 0
    cost_usd: float = 0.0
    model: Optional[str] = None
    provider: Optional[str] = None
    prompt_text: Optional[str] = None
    system_prompt: Optional[str] = None
    node_type: Optional[str] = None
    tool_calls_list: List[ToolCallInfo] = field(default_factory=list)
    input_data: Optional[str] = None
    output_data: Optional[str] = None
    available_tools: Optional[List[str]] = None
    framework: Optional[str] = None
    agentic_pattern: Optional[str] = None
    attachments: List[Dict[str, Any]] = field(default_factory=list)
    input_context: Optional[str] = None  # RAG retrieval context for faithfulness evals

    # --- MCP integration ---
    tool_name: Optional[str] = None
    tool_args: Optional[Dict[str, Any]] = None
    mcp_server: Optional[str] = None

    # ------------------------------------------------------------------
    # Lifecycle helpers
    # ------------------------------------------------------------------

    def finish(self, result: Any = None, error: BaseException | None = None) -> None:
        self.completed_at = utcnow()
        self.result = result
        self.error = error
        if error:
            from .exceptions import GovernanceBlockedError
            self.status = "blocked" if isinstance(error, GovernanceBlockedError) else "error"
        else:
            self.status = "success"

    @property
    def duration_ms(self) -> Optional[int]:
        if not self.completed_at:
            return None
        delta = self.completed_at - self.started_at
        return int(delta.total_seconds() * 1000)

    # ------------------------------------------------------------------
    # Telemetry setters — used by framework integrations and user code
    # ------------------------------------------------------------------

    def set_tokens(self, input_tokens: int, output_tokens: int) -> None:
        """Record prompt / completion token counts for this span."""
        self.tokens_input = input_tokens
        self.tokens_output = output_tokens

    def set_cost(self, cost: float) -> None:
        """Record the estimated LLM cost in USD for this span."""
        self.cost_usd = cost

    def set_model(self, model: str, provider: str = "openai") -> None:
        """Record the LLM model and provider used in this span."""
        self.model = model
        self.provider = provider

    def set_prompt(self, prompt: str, system_prompt: Optional[str] = None) -> None:
        """Record the user prompt and optional system prompt."""
        self.prompt_text = prompt
        if system_prompt is not None:
            self.system_prompt = system_prompt

    def set_io(self, input_data: Optional[str] = None, output_data: Optional[str] = None) -> None:
        """Record the input/output for this span (safety cap at 500K)."""
        if input_data is not None:
            self.input_data = input_data[:MAX_FIELD_SIZE]
        if output_data is not None:
            self.output_data = output_data[:MAX_FIELD_SIZE]

    def set_input_context(self, context: str) -> None:
        """Record RAG retrieval context for faithfulness evaluation."""
        self.input_context = context[:MAX_FIELD_SIZE]

    def set_agentic_pattern(self, pattern: str) -> None:
        """Tag this run with an agentic execution pattern (e.g. 'react', 'multi_agent')."""
        self.agentic_pattern = pattern

    def add_tool_call(
        self,
        tool_name: str,
        tool_args: Optional[Dict[str, Any]] = None,
        tool_result: Optional[str] = None,
        tool_id: Optional[str] = None,
        success: bool = True,
        error_message: Optional[str] = None,
        mcp_server: Optional[str] = None,
        mcp_transport: Optional[str] = None,
        mcp_session_id: Optional[str] = None,
    ) -> None:
        """Append a tool-call record that will be sent with this span's event.

        Args:
            tool_name: Name of the tool that was invoked.
            tool_args: Arguments dictionary passed to the tool.
            tool_result: Serialized return value from the tool.
            tool_id: Unique call identifier (used for linking request/response).
            success: Whether the tool call succeeded.
            error_message: Error description when *success* is False.
            mcp_server: MCP server name that served this tool call.
            mcp_transport: MCP transport protocol (e.g. ``"stdio"``, ``"sse"``).
            mcp_session_id: MCP session identifier.
        """
        if len(self.tool_calls_list) >= MAX_TOOL_CALLS_PER_SPAN:
            return
        self.tool_calls_list.append(
            ToolCallInfo(
                tool_name=tool_name,
                tool_args=tool_args or {},
                tool_result=(tool_result or "")[:MAX_FIELD_SIZE],
                tool_id=tool_id,
                success=success,
                error_message=error_message,
                mcp_server=mcp_server,
                mcp_transport=mcp_transport,
                mcp_session_id=mcp_session_id,
            )
        )

    # ------------------------------------------------------------------
    # Fingerprinting
    # ------------------------------------------------------------------

    def record_node(
        self,
        name: str,
        node_type: str,
        config: Optional[Any] = None,
        prompt: Optional[str] = None,
    ) -> None:
        """Record a node in the fingerprint.

        Called automatically during instrumentation to track workflow structure.

        Args:
            name: Node name (typically the function name)
            node_type: Type of node (llm, tool, function, retriever, etc.)
            config: Configuration dict for the node
            prompt: System prompt for LLM nodes
        """
        if self.fingerprint_builder:
            self.fingerprint_builder.record_node(name, node_type, config, prompt)


_context_var: ContextVar[ExecutionContext | None] = ContextVar("turingpulse_execution_context", default=None)


@contextmanager
def bind_context(context: ExecutionContext):
    token = _context_var.set(context)
    try:
        yield
    finally:
        _context_var.reset(token)


def current_context() -> ExecutionContext | None:
    return _context_var.get()

