"""Keeps track of trigger registrations before the plugin is initialised."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional


@dataclass
class PendingTrigger:
    key: str
    func: Callable
    description: Optional[str] = None


_PENDING: List[PendingTrigger] = []


def queue_trigger(key: str, func: Callable, description: Optional[str] = None) -> None:
    _PENDING.append(PendingTrigger(key=key, func=func, description=description))


def flush_pending(plugin) -> None:
    if not _PENDING:
        return
    for pending in _PENDING:
        plugin.register_trigger(pending.key, pending.func, pending.description)
        setattr(pending.func, "_tp_trigger_registered", True)
    _PENDING.clear()

