"""TuringPulse SDK public interface."""

from .config import TuringPulseConfig, GovernanceDefaults, FingerprintConfig
from .context import current_context
from .decorators import instrument
from .deploy import DeployInfo, register_deploy
from .exceptions import ConfigurationError, GovernanceBlockedError
from .governance import GovernanceDirective
from .kpi import KPIConfig, KPIResult
from .attachments import AttachmentManager
from .plugin import TuringPulsePlugin, get_plugin, init
from .client import PolicyCheckResult

__all__ = [
    # Config
    "TuringPulseConfig",
    "GovernanceDefaults",
    "FingerprintConfig",
    # Plugin
    "TuringPulsePlugin",
    "init",
    "get_plugin",
    # Decorators
    "instrument",
    # Governance
    "GovernanceDirective",
    "GovernanceBlockedError",
    # Exceptions
    "ConfigurationError",
    # KPIs
    "KPIConfig",
    "KPIResult",
    # Deploy Tracking
    "register_deploy",
    "DeployInfo",
    # Context
    "current_context",
    # Policy Check
    "PolicyCheckResult",
    # Attachments
    "AttachmentManager",
    # Framework integrations (lazy-loaded)
    "integrations",
]
