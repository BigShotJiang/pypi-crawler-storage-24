"""KPI configuration + evaluation helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Sequence

from pydantic import BaseModel, Field, ConfigDict
from typing_extensions import Literal

from .context import ExecutionContext


KPIValueCallable = Callable[[ExecutionContext], float | int | None]


class KPIConfig(BaseModel):
    """Defines a KPI mapping for an agent invocation."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    kpi_id: str
    value: float | int | KPIValueCallable | None = None
    use_duration: bool = False
    from_result_path: Optional[str] = None
    labels: Dict[str, str] = Field(default_factory=dict)
    alert_threshold: float | int | None = None
    comparator: Literal["gt", "gte", "lt", "lte", "eq"] = "gt"
    description: Optional[str] = None

    def evaluate(self, context: ExecutionContext) -> Optional[float]:
        if self.use_duration and context.duration_ms is not None:
            return float(context.duration_ms)
        if callable(self.value):
            raw = self.value(context)
            return float(raw) if raw is not None else None
        if self.value is not None:
            return float(self.value)
        if self.from_result_path:
            extracted = _extract_from_result(context.result, self.from_result_path)
            return float(extracted) if extracted is not None else None
        return None

    def is_alert(self, value: Optional[float]) -> bool:
        if value is None or self.alert_threshold is None:
            return False
        threshold = float(self.alert_threshold)
        if self.comparator == "gt":
            return value > threshold
        if self.comparator == "gte":
            return value >= threshold
        if self.comparator == "lt":
            return value < threshold
        if self.comparator == "lte":
            return value <= threshold
        return value == threshold


@dataclass
class KPIResult:
    config: KPIConfig
    value: float
    alert: bool = False

    def metadata(self) -> Dict[str, str]:
        entries: Dict[str, str] = {f"metric.{self.config.kpi_id}": f"{self.value}"}
        if self.alert:
            entries[f"metric.alert.{self.config.kpi_id}"] = "true"
        if self.config.labels:
            for key, val in self.config.labels.items():
                entries[f"metric.{self.config.kpi_id}.{key}"] = str(val)
        return entries


def evaluate_kpis(configs: Sequence[KPIConfig], context: ExecutionContext) -> list[KPIResult]:
    results: list[KPIResult] = []
    for cfg in configs:
        value = cfg.evaluate(context)
        if value is None:
            continue
        results.append(KPIResult(config=cfg, value=value, alert=cfg.is_alert(value)))
    return results


_FORBIDDEN_KEYS = frozenset({"__class__", "__dict__", "__init__", "__globals__", "__module__", "__self__"})


def _extract_from_result(payload: Any, path: str) -> Any:
    if payload is None or not path:
        return None
    parts = path.split(".")
    current: Any = payload
    for part in parts:
        if part.startswith("_") or part in _FORBIDDEN_KEYS:
            return None
        if isinstance(current, dict):
            current = current.get(part)
        else:
            current = getattr(current, part, None)
        if current is None:
            return None
    return current


