"""Trigger registry to control hidden agent entrypoints."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Callable, Optional


@dataclass
class TriggerEntry:
    key: str
    func: Callable
    description: Optional[str] = None


class TriggerRegistry:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._entries: dict[str, TriggerEntry] = {}

    def register(self, key: str, func: Callable, description: Optional[str] = None) -> None:
        with self._lock:
            self._entries[key] = TriggerEntry(key=key, func=func, description=description)

    def unregister(self, key: str) -> None:
        with self._lock:
            self._entries.pop(key, None)

    def get(self, key: str) -> Optional[TriggerEntry]:
        return self._entries.get(key)

    def list(self) -> list[TriggerEntry]:
        return list(self._entries.values())


