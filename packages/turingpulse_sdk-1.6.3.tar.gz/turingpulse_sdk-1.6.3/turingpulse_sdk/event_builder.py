"""Event construction extracted from the plugin to satisfy SRP.

EventBuilder handles:
- AgentEvent assembly from ExecutionContext
- Argument/return value capture and serialization
- Sensitive data redaction
- Transcript collection
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Set

from turingpulse_interfaces import AgentEvent, AgentEventPayload, AgentEventType, TokenBreakdown

from .config import MAX_FIELD_SIZE, TuringPulseConfig
from .context import ExecutionContext
from .instrumentation import InstrumentationOptions
from .kpi import KPIResult

logger = logging.getLogger("turingpulse.sdk.event_builder")


class EventBuilder:
    """Builds AgentEvent payloads from an ExecutionContext."""

    def __init__(self, config: TuringPulseConfig):
        self._config = config
        self._redact_field_names: Set[str] = {f.lower() for f in config.redact_fields}

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def build(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        kpi_results: List[KPIResult],
    ) -> AgentEvent:
        """Construct a full AgentEvent from the completed context."""
        metadata = self._assemble_metadata(context, options, kpi_results)
        tokens = self._build_tokens(context)
        payload = AgentEventPayload(
            name=context.operation,
            duration_ms=context.duration_ms,
            status=context.status,
            tokens=tokens,
            cost_usd=context.cost_usd if context.cost_usd else None,
            tool_calls=context.tool_calls_list if context.tool_calls_list else None,
            metadata=metadata,
        )
        return AgentEvent(
            run_id=context.run_id,
            agent_id=context.agent_id,
            timestamp=context.completed_at or context.started_at,
            type=AgentEventType.SPAN,
            payload=payload,
            workflow_name=context.workflow_name,
        )

    def apply_transcript(
        self,
        options: InstrumentationOptions,
        context: ExecutionContext,
        result: Any,
        error: BaseException | None,
    ) -> None:
        """Run the transcript collector and store the result in context metadata."""
        collector = options.transcript_collector
        if not collector or "thread.transcript" in context.metadata:
            return
        try:
            transcript = collector(context.args, context.kwargs, result, error)
        except Exception as exc:
            logger.warning("Transcript collector failed: %s", type(exc).__name__)
            return
        if transcript is None:
            return
        try:
            value = json.dumps(transcript, ensure_ascii=False) if isinstance(transcript, (dict, list)) else str(transcript)
            if len(value) > MAX_FIELD_SIZE:
                value = value[:MAX_FIELD_SIZE] + "... (truncated)"
            context.metadata["thread.transcript"] = value
        except Exception as exc:
            logger.warning("Failed to serialize transcript: %s", type(exc).__name__)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _assemble_metadata(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        kpi_results: List[KPIResult],
    ) -> Dict[str, str]:
        metadata: Dict[str, str] = {}
        metadata.update({k: str(v) for k, v in context.labels.items()})
        metadata.update({k: str(v) for k, v in context.metadata.items()})
        metadata["span_id"] = context.span_id
        metadata["depth"] = str(context.depth)
        if context.parent_span_id:
            metadata["parent_span_id"] = context.parent_span_id
        metadata["agent.status"] = context.status
        metadata["agent.hidden_entrypoint"] = str(context.hidden_entrypoint).lower()
        if context.trigger_key:
            metadata["agent.trigger_key"] = context.trigger_key
        if context.error:
            metadata["error.type"] = type(context.error).__name__
            metadata["error.message"] = str(context.error)[:10_000]
        if options.governance:
            metadata["governance.hitl"] = str(options.governance.hitl).lower()
            metadata["governance.hatl"] = str(options.governance.hatl).lower()
            metadata["governance.hotl"] = str(options.governance.hotl).lower()
        if context.workflow_name:
            metadata["workflow_name"] = context.workflow_name

        for result in kpi_results:
            metadata.update(result.metadata())

        args_blob = self._capture_arguments(context)
        if args_blob:
            metadata["agent.args_json"] = args_blob

        return_blob = self._capture_return(context)
        if return_blob:
            metadata["agent.return_json"] = return_blob

        if context.prompt_text:
            metadata["prompt"] = context.prompt_text[:MAX_FIELD_SIZE]
            metadata["user_query"] = context.prompt_text[:MAX_FIELD_SIZE]
        if context.system_prompt:
            metadata["system_prompt"] = context.system_prompt[:MAX_FIELD_SIZE]
        if context.model:
            metadata["model"] = context.model
        if context.provider:
            metadata["provider"] = context.provider
        if context.node_type:
            metadata["node_type"] = context.node_type
        if context.input_data:
            metadata["input"] = context.input_data[:MAX_FIELD_SIZE]
        if context.output_data:
            metadata["output"] = context.output_data[:MAX_FIELD_SIZE]
        if context.available_tools:
            metadata["available_tools"] = json.dumps(context.available_tools)
        if context.framework:
            metadata["framework"] = context.framework
        if context.agentic_pattern:
            metadata["agentic_pattern"] = context.agentic_pattern
        if context.attachments:
            metadata["attachments"] = json.dumps(context.attachments)
        if context.input_context:
            metadata["input_context"] = context.input_context[:MAX_FIELD_SIZE]

        return metadata

    @staticmethod
    def _build_tokens(context: ExecutionContext) -> Optional[TokenBreakdown]:
        if context.tokens_input or context.tokens_output:
            return TokenBreakdown(prompt=context.tokens_input, completion=context.tokens_output)
        return None

    def _capture_arguments(self, context: ExecutionContext) -> Optional[str]:
        if not self._config.capture_arguments:
            return None
        try:
            payload = {
                "args": [self._safe_serialize(v) for v in context.args],
                "kwargs": {k: self._safe_serialize(v) for k, v in context.kwargs.items()},
            }
            return self._prepare_serialized(payload)
        except Exception as exc:
            logger.debug("Failed to serialize arguments for telemetry: %s", type(exc).__name__)
            return None

    def _capture_return(self, context: ExecutionContext) -> Optional[str]:
        if not self._config.capture_return_value or context.error is not None:
            return None
        try:
            return self._prepare_serialized({"return": self._safe_serialize(context.result)})
        except Exception as exc:
            logger.debug("Failed to serialize return value for telemetry: %s", type(exc).__name__)
            return None

    def _safe_serialize(self, value: Any, _depth: int = 0) -> Any:
        if _depth > 20:
            return repr(value)
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        if isinstance(value, dict):
            return {k: self._safe_serialize(v, _depth + 1) for k, v in value.items()}
        if isinstance(value, (list, tuple, set)):
            return [self._safe_serialize(v, _depth + 1) for v in value]
        if hasattr(value, "model_dump"):
            try:
                return value.model_dump()
            except Exception:
                return repr(value)
        return repr(value)

    def _prepare_serialized(self, payload: Dict[str, Any]) -> Optional[str]:
        redacted = self._redact(payload)
        try:
            serialized = json.dumps(redacted, ensure_ascii=False)
        except TypeError:
            serialized = str(redacted)
        max_len = max(256, self._config.max_serialized_field_length)
        if len(serialized) > max_len:
            serialized = serialized[:max_len] + "... (truncated)"
        return serialized

    def _redact(self, value: Any, _depth: int = 0) -> Any:
        if _depth > 20:
            return value
        if isinstance(value, dict):
            return {
                k: "[REDACTED]" if k.lower() in self._redact_field_names else self._redact(v, _depth + 1)
                for k, v in value.items()
            }
        if isinstance(value, list):
            return [self._redact(item, _depth + 1) for item in value]
        return value
