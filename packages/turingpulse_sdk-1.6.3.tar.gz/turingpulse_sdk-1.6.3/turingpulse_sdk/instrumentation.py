"""Shared instrumentation option container.

REFACTORED:
- Added `name` parameter for workflow display name
- `agent_id` is now DEPRECATED - use `name` instead
- `workflow_name` property returns the display name for telemetry
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional, Sequence

from .governance import GovernanceDirective
from .kpi import KPIConfig

TranscriptCollector = Callable[[tuple, dict, Any, BaseException | None], Any]


@dataclass
class InstrumentationOptions:
    """Options for @instrument decorator.
    
    REFACTORED:
    - `name` is the new preferred parameter for workflow display name
    - `agent_id` is DEPRECATED but still supported for backward compatibility
    - The backend will auto-register workflows based on `name` and assign UUID
    """
    # NEW: Display name for the workflow (e.g., "Order Processing Agent")
    # This is the preferred way to identify workflows
    name: Optional[str] = None
    
    # DEPRECATED: Use `name` instead
    # Kept for backward compatibility - will be removed in future version
    agent_id: Optional[str] = None
    
    operation: Optional[str] = None
    labels: Dict[str, str] = field(default_factory=dict)
    trace: Optional[bool] = None
    governance: Optional[GovernanceDirective] = None
    kpis: Sequence[KPIConfig] = field(default_factory=tuple)
    trigger_key: Optional[str] = None
    trigger_description: Optional[str] = None
    hidden_entrypoint: bool = False
    metadata: Dict[str, str] = field(default_factory=dict)
    transcript_collector: Optional[TranscriptCollector] = None
    agentic_pattern: Optional[str] = None

    @property
    def workflow_name(self) -> str:
        """Get the workflow display name for telemetry.
        
        Returns `name` if set, otherwise falls back to `agent_id`.
        """
        return self.name or self.agent_id or ""
    
    @property
    def effective_agent_id(self) -> str:
        """Get the effective agent ID (for backward compatibility).
        
        DEPRECATED: Use workflow_name instead.
        """
        return self.agent_id or self.name or ""

    def span_name(self, fallback: str) -> str:
        return self.operation or fallback

    def tracing_enabled(self, default_enabled: bool) -> bool:
        if self.trace is None:
            return default_enabled
        return self.trace
    
    def __post_init__(self):
        """Validate options and emit deprecation warnings."""
        if self.agent_id and not self.name:
            # Only warn if agent_id is used without name
            warnings.warn(
                "The 'agent_id' parameter is deprecated. Use 'name' instead. "
                "Example: @instrument(name='Order Processing Agent')",
                DeprecationWarning,
                stacklevel=4,  # Point to the decorator call site
            )
        
        # name/agent_id can be omitted when config.workflow_name is set at init (minimal setup)


