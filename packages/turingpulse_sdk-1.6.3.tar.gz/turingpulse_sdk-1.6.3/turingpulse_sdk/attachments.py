"""Document attachment support for the TuringPulse Python SDK.

Provides ``attach_document``, ``attach_bytes``, and ``attach_text_file``
which upload files to the ingestion service and inject attachment metadata
into the current span's event payload.

Design principle: NEVER crash customer code.  All upload failures are logged
and silently ignored — the span completes normally without the attachment.
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .client import TuringPulseHttpClient

logger = logging.getLogger("turingpulse.sdk.attachments")

_CONTROL_CHAR_RE = None

_global_pending: List[Dict[str, Any]] = []


def _validate_file_path(file_path: str) -> str:
    """Resolve and validate a file path to prevent path-traversal attacks.

    Rejects paths that resolve outside the original directory intent
    (e.g. ``../../etc/passwd``) and non-regular files.
    """
    resolved = os.path.realpath(os.path.normpath(file_path))
    if not os.path.isfile(resolved):
        raise ValueError(f"Not a regular file: {file_path}")
    return resolved


def _sanitize_filename(filename: str) -> str:
    """Strip path components and control characters from a filename."""
    import re
    global _CONTROL_CHAR_RE
    if _CONTROL_CHAR_RE is None:
        _CONTROL_CHAR_RE = re.compile(r"[\x00-\x1f\x7f]")
    name = os.path.basename(filename)
    name = _CONTROL_CHAR_RE.sub("", name)
    return name[:255] if name else "attachment"


def drain_global_pending() -> List[Dict[str, Any]]:
    """Return and clear module-level pending attachments."""
    items = list(_global_pending)
    _global_pending.clear()
    return items


class AttachmentManager:
    """Manages document uploads and metadata injection.

    Uploaded attachments are automatically injected into the current
    ``ExecutionContext`` when one is active.  Attachments uploaded outside
    a span are stored in ``pending_attachments`` so the next root span
    can pick them up.
    """

    def __init__(self, http_client: "TuringPulseHttpClient", enabled: bool = True) -> None:
        self._http = http_client
        self._enabled = enabled
        self.pending_attachments: List[Dict[str, Any]] = []

    def attach_document(
        self,
        file_path: str,
        direction: str = "input",
        mime_type: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Upload a document from a file path.

        Returns attachment metadata dict on success, None on failure.
        """
        if not self._enabled:
            return None
        try:
            validated_path = _validate_file_path(file_path)
            filename = _sanitize_filename(validated_path)
            with open(validated_path, "rb") as f:
                data = f.read()
            return self._upload(data, filename, direction, mime_type)
        except Exception:
            logger.warning("Failed to attach document: %s", type(file_path).__name__)
            return None

    def attach_bytes(
        self,
        data: bytes,
        filename: str,
        direction: str = "input",
        mime_type: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """Upload raw bytes as an attachment."""
        if not self._enabled:
            return None
        try:
            return self._upload(data, _sanitize_filename(filename), direction, mime_type)
        except Exception as exc:
            logger.warning("Failed to attach bytes: %s", type(exc).__name__)
            return None

    def attach_text_file(
        self,
        text: str,
        filename: str = "document.txt",
        direction: str = "input",
    ) -> Optional[Dict[str, Any]]:
        """Upload a string as a text attachment."""
        return self.attach_bytes(
            text.encode("utf-8"),
            filename,
            direction,
            mime_type="text/plain",
        )

    def _upload(
        self,
        data: bytes,
        filename: str,
        direction: str,
        mime_type: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        """Core upload via the HTTP client's multipart upload.

        If an ``ExecutionContext`` is active the metadata is injected into
        ``ctx.attachments`` automatically.  Otherwise it is stored in
        ``pending_attachments`` for later injection by the plugin.
        """
        try:
            result = self._http.upload_attachment(
                data=data,
                filename=filename,
                direction=direction,
                mime_type=mime_type,
            )
            if result:
                meta = {
                    "attachment_id": result.get("attachment_id"),
                    "filename": result.get("filename"),
                    "mime_type": result.get("mime_type"),
                    "size_bytes": result.get("size_bytes"),
                    "storage_path": result.get("storage_path"),
                    "direction": direction,
                    "deduplicated": result.get("deduplicated", False),
                }
                self._inject_into_context(meta)
                return meta
        except Exception as exc:
            logger.warning("Attachment upload failed: %s", type(exc).__name__)
        return None

    def _inject_into_context(self, meta: Dict[str, Any]) -> None:
        """Push attachment metadata into the active span or the global pending list."""
        try:
            from .context import current_context
            ctx = current_context()
            if ctx is not None:
                ctx.attachments.append(meta)
                return
        except Exception:
            pass
        self.pending_attachments.append(meta)
        _global_pending.append(meta)

    def drain_pending(self) -> List[Dict[str, Any]]:
        """Return and clear any attachments uploaded outside a span."""
        items = list(self.pending_attachments)
        self.pending_attachments.clear()
        return items
