"""Core TuringPulse plugin implementation."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import threading
from typing import Any, Callable, Dict, Optional
from uuid import uuid4

from .client import TuringPulseHttpClient
from .config import TuringPulseConfig
from .context import ExecutionContext, bind_context, current_context
from .event_builder import EventBuilder
from .exceptions import GovernanceBlockedError, PluginNotInitializedError, TriggerNotFoundError
from .fingerprint import FingerprintBuilder
from .governance import GovernanceDirective, GovernanceManager
from .instrumentation import InstrumentationOptions
from .kpi import KPIResult, evaluate_kpis
from .llm_detector import detect_node_type
from .registry import TriggerRegistry
from .tracing import TracingManager
from .trigger_state import flush_pending

logger = logging.getLogger("turingpulse.sdk.core")
_PLUGIN: "TuringPulsePlugin | None" = None
_INIT_LOCK = threading.Lock()


class TuringPulsePlugin:
    def __init__(self, config: TuringPulseConfig):
        self.config = config
        self.client = TuringPulseHttpClient(config)
        self.tracing = TracingManager(config)
        self.governance = GovernanceManager(self.client, config)
        self.registry = TriggerRegistry()
        self.event_builder = EventBuilder(config)

    def shutdown(self) -> None:
        self.client.close()

    async def ashutdown(self) -> None:
        await self.client.aclose()

    # ------------------------------------------------------------------
    # Trigger management
    # ------------------------------------------------------------------

    def register_trigger(self, key: str, func: Callable, description: Optional[str] = None) -> str:
        namespaced = self._namespaced_key(key)
        self.registry.register(namespaced, func, description=description)
        return namespaced

    def unregister_trigger(self, key: str) -> None:
        self.registry.unregister(self._namespaced_key(key))

    def trigger_agent(self, key: str, *args, **kwargs):
        namespaced = self._namespaced_key(key)
        entry = self.registry.get(namespaced)
        if not entry:
            safe_key = str(namespaced)[:100] if namespaced else "<empty>"
            raise TriggerNotFoundError(f"No trigger registered for key '{safe_key}'")
        return entry.func(*args, **kwargs)

    def list_triggers(self):
        return self.registry.list()

    # ------------------------------------------------------------------
    # Execution — shared span scaffolding + sync/async/gen variants
    # ------------------------------------------------------------------

    def _span_scaffold(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        """Return (context, span_cm) with all shared setup done.

        Used by all four execute variants to avoid repeating context
        build, node recording, and tracing span construction.
        """
        context = self._build_context(func, args, kwargs, options)
        self._record_node(context, func, args, kwargs)
        span_cm = self.tracing.span(
            options.span_name(func.__name__),
            attributes=context.labels,
            enabled=options.tracing_enabled(self.config.trace_enabled),
            context=context,
        )
        return context, span_cm

    # ------------------------------------------------------------------
    # Pre-execution governance (HITL blocking)
    # ------------------------------------------------------------------

    def _resolve_governance(self, options: InstrumentationOptions) -> GovernanceDirective | None:
        """Merge per-call governance with global defaults.

        Per-call directive fields take precedence over global defaults.
        If neither per-call nor global HITL is enabled, returns None to skip
        the pre-execution check.
        """
        directive = options.governance
        defaults = self.config.governance_defaults

        if directive is None and not defaults.hitl:
            return None

        if directive is None:
            return GovernanceDirective(
                hitl=defaults.hitl,
                reviewers=list(defaults.reviewers),
                escalation_channels=list(defaults.escalation_channels),
                metadata=dict(defaults.metadata),
                severity=defaults.severity,
                auto_escalate_after_seconds=defaults.auto_escalate_after_seconds,
            )

        if not directive.hitl and defaults.hitl:
            directive = directive.model_copy(update={"hitl": True})

        return directive

    @staticmethod
    def _extract_input_from_context(context: ExecutionContext) -> Optional[str]:
        """Extract user-facing input text from context kwargs for pre-check payload.

        Handles LLM-style message arrays (OpenAI, Anthropic, etc.) and
        generic tool_args. Returns truncated text suitable for policy evaluation.
        """
        _MAX = 10_000

        if context.tool_args is not None:
            try:
                return json.dumps(context.tool_args, default=str)[:_MAX]
            except Exception:
                pass

        if context.prompt_text:
            return context.prompt_text[:_MAX]

        messages = context.kwargs.get("messages") if context.kwargs else None
        if messages and isinstance(messages, (list, tuple)):
            try:
                user_msgs = [
                    m.get("content", "") if isinstance(m, dict) else str(m)
                    for m in messages
                    if isinstance(m, dict) and m.get("role") in ("user", "human")
                ]
                if user_msgs:
                    return "\n".join(user_msgs)[:_MAX]
                return json.dumps(messages, default=str)[:_MAX]
            except Exception:
                pass

        for key in ("input", "prompt", "query", "message", "question", "text"):
            val = context.kwargs.get(key) if context.kwargs else None
            if val and isinstance(val, str):
                return val[:_MAX]

        return None

    def _build_pre_check_payload(self, context: ExecutionContext) -> Dict[str, Any]:
        """Build the policy check payload for pre-execution checks."""
        payload: Dict[str, Any] = {
            "workflow_name": context.workflow_name,
            "span_id": context.span_id,
            "node_type": context.node_type,
            "operation": context.operation,
            "check_phase": "pre_execution",
        }
        if context.tool_name is not None:
            payload["tool_name"] = context.tool_name
        if context.tool_args is not None:
            payload["tool_args"] = context.tool_args
        if context.mcp_server is not None:
            payload["mcp_server"] = context.mcp_server

        input_text = self._extract_input_from_context(context)
        if input_text:
            payload["input_text"] = input_text

        return payload

    @staticmethod
    def _policy_obs_extra(context: ExecutionContext, check_phase: str) -> Dict[str, Any]:
        """Structured fields for policy-check debug counters (no PII)."""
        extra: Dict[str, Any] = {
            "workflow_name": context.workflow_name or "",
            "span_id": context.span_id,
            "check_phase": check_phase,
        }
        tid: Optional[str] = None
        if context.labels:
            tid = context.labels.get("tenant_id")
        if not tid and context.metadata:
            tid = context.metadata.get("tenant_id")
        if tid:
            extra["tenant_id"] = tid
        return extra

    def _pre_execution_policy_check(
        self, context: ExecutionContext, options: InstrumentationOptions
    ) -> None:
        """Run a synchronous pre-execution policy check. Raises GovernanceBlockedError on 'block'."""
        directive = self._resolve_governance(options)
        if directive is None or not directive.hitl:
            return

        policy_kwargs = self._build_pre_check_payload(context)

        try:
            result = self.client.policy_check(**policy_kwargs)
        except Exception:
            return

        if result.blocked:
            logger.debug(
                "policy_blocked_pre",
                extra=self._policy_obs_extra(context, "pre_execution"),
            )
            raise GovernanceBlockedError(
                reason=result.reason,
                policy_ids=result.policy_ids,
            )
        logger.debug(
            "policy_pre_checked",
            extra=self._policy_obs_extra(context, "pre_execution"),
        )

    async def _pre_execution_policy_check_async(
        self, context: ExecutionContext, options: InstrumentationOptions
    ) -> None:
        """Run an async pre-execution policy check. Raises GovernanceBlockedError on 'block'."""
        directive = self._resolve_governance(options)
        if directive is None or not directive.hitl:
            return

        policy_kwargs = self._build_pre_check_payload(context)

        try:
            result = await self.client.policy_check_async(**policy_kwargs)
        except Exception:
            return

        if result.blocked:
            logger.debug(
                "policy_blocked_pre",
                extra=self._policy_obs_extra(context, "pre_execution"),
            )
            raise GovernanceBlockedError(
                reason=result.reason,
                policy_ids=result.policy_ids,
            )
        logger.debug(
            "policy_pre_checked",
            extra=self._policy_obs_extra(context, "pre_execution"),
        )

    def _needs_post_check(self, options: InstrumentationOptions) -> bool:
        """Post-execution output check runs whenever governance (HITL) is active."""
        directive = self._resolve_governance(options)
        return directive is not None and directive.hitl

    _GARBAGE_OUTPUT_PREFIXES = ("<openai.", "<anthropic.", "<cohere.", "<httpx.", "<Stream ")

    # ------------------------------------------------------------------
    # Runtime iterator detection
    # ------------------------------------------------------------------

    _ITERATOR_PASSTHROUGH_TYPES = (str, bytes, bytearray, dict, list, tuple, set, frozenset, memoryview)

    @staticmethod
    def _is_unwrapped_iterator(result: Any) -> bool:
        """True when *result* is a sync iterator that should get deferred span finalization."""
        if result is None or isinstance(result, TuringPulsePlugin._ITERATOR_PASSTHROUGH_TYPES):
            return False
        return hasattr(result, "__iter__") and hasattr(result, "__next__")

    @staticmethod
    def _is_unwrapped_async_iterator(result: Any) -> bool:
        """True when *result* is an async iterator that should get deferred span finalization."""
        if result is None:
            return False
        return hasattr(result, "__aiter__") and hasattr(result, "__anext__")

    def _post_execution_policy_check(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
    ) -> None:
        """Synchronous post-execution output policy check. Raises GovernanceBlockedError on 'block'.

        Called from the try block AFTER context.finish(result) and BEFORE return,
        so raising prevents the caller from receiving the result.
        """
        if not self._needs_post_check(options):
            return

        self._auto_populate_io(context, result, error=None)

        output_text = context.output_data
        if not output_text or len(output_text) < 2:
            return
        if any(output_text.startswith(p) for p in self._GARBAGE_OUTPUT_PREFIXES):
            logger.debug("post_check_skipped: output looks like unconsumed stream object")
            return

        payload: Dict[str, Any] = {
            "workflow_name": context.workflow_name,
            "span_id": context.span_id,
            "node_type": context.node_type,
            "operation": context.operation,
            "output_text": output_text[:10_000],
            "check_phase": "post_execution",
        }
        if context.input_data:
            payload["input_text"] = context.input_data[:10_000]

        try:
            check_result = self.client.policy_check(**payload)
        except Exception:
            if self.config.policy_fail_mode == "closed":
                raise GovernanceBlockedError(reason="post-check infrastructure failure (fail-closed)")
            logger.debug(
                "policy_fail_open",
                extra=self._policy_obs_extra(context, "post_execution"),
            )
            return

        context.metadata = context.metadata or {}
        context.metadata["post_policy.action"] = check_result.action
        if check_result.policy_ids:
            context.metadata["post_policy.triggered_policies"] = ",".join(check_result.policy_ids)

        if check_result.blocked:
            logger.debug(
                "policy_blocked_post",
                extra=self._policy_obs_extra(context, "post_execution"),
            )
            raise GovernanceBlockedError(
                reason=check_result.reason,
                policy_ids=check_result.policy_ids,
            )
        logger.debug(
            "policy_post_checked",
            extra=self._policy_obs_extra(context, "post_execution"),
        )

    async def _post_execution_policy_check_async(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
    ) -> None:
        """Async post-execution output policy check. Raises GovernanceBlockedError on 'block'."""
        if not self._needs_post_check(options):
            return

        self._auto_populate_io(context, result, error=None)

        output_text = context.output_data
        if not output_text or len(output_text) < 2:
            return
        if any(output_text.startswith(p) for p in self._GARBAGE_OUTPUT_PREFIXES):
            logger.debug("post_check_skipped: output looks like unconsumed stream object")
            return

        payload: Dict[str, Any] = {
            "workflow_name": context.workflow_name,
            "span_id": context.span_id,
            "node_type": context.node_type,
            "operation": context.operation,
            "output_text": output_text[:10_000],
            "check_phase": "post_execution",
        }
        if context.input_data:
            payload["input_text"] = context.input_data[:10_000]

        try:
            check_result = await self.client.policy_check_async(**payload)
        except Exception:
            if self.config.policy_fail_mode == "closed":
                raise GovernanceBlockedError(reason="post-check infrastructure failure (fail-closed)")
            logger.debug(
                "policy_fail_open",
                extra=self._policy_obs_extra(context, "post_execution"),
            )
            return

        context.metadata = context.metadata or {}
        context.metadata["post_policy.action"] = check_result.action
        if check_result.policy_ids:
            context.metadata["post_policy.triggered_policies"] = ",".join(check_result.policy_ids)

        if check_result.blocked:
            logger.debug(
                "policy_blocked_post",
                extra=self._policy_obs_extra(context, "post_execution"),
            )
            raise GovernanceBlockedError(
                reason=check_result.reason,
                policy_ids=check_result.policy_ids,
            )
        logger.debug(
            "policy_post_checked",
            extra=self._policy_obs_extra(context, "post_execution"),
        )

    def _post_check_audit_only(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
    ) -> None:
        """Non-blocking post-check for generators — sets metadata flags only, never raises."""
        if not self._needs_post_check(options):
            return
        try:
            self._auto_populate_io(context, result, error=None)
            output_text = context.output_data
            if not output_text or len(output_text) < 2:
                return
            if any(output_text.startswith(p) for p in self._GARBAGE_OUTPUT_PREFIXES):
                return

            payload: Dict[str, Any] = {
                "workflow_name": context.workflow_name,
                "span_id": context.span_id,
                "node_type": context.node_type,
                "operation": context.operation,
                "output_text": output_text[:10_000],
                "check_phase": "post_execution",
            }
            if context.input_data:
                payload["input_text"] = context.input_data[:10_000]

            check_result = self.client.policy_check(**payload)
            context.metadata = context.metadata or {}
            context.metadata["post_policy.action"] = check_result.action
            if check_result.policy_ids:
                context.metadata["post_policy.triggered_policies"] = ",".join(check_result.policy_ids)
            logger.debug(
                "policy_post_checked_audit",
                extra=self._policy_obs_extra(context, "post_execution"),
            )
        except Exception:
            logger.debug("post_check_audit_only: check failed, continuing")

    async def _post_check_audit_only_async(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
    ) -> None:
        """Async non-blocking post-check for generators — sets metadata flags only, never raises."""
        if not self._needs_post_check(options):
            return
        try:
            self._auto_populate_io(context, result, error=None)
            output_text = context.output_data
            if not output_text or len(output_text) < 2:
                return
            if any(output_text.startswith(p) for p in self._GARBAGE_OUTPUT_PREFIXES):
                return

            payload: Dict[str, Any] = {
                "workflow_name": context.workflow_name,
                "span_id": context.span_id,
                "node_type": context.node_type,
                "operation": context.operation,
                "output_text": output_text[:10_000],
                "check_phase": "post_execution",
            }
            if context.input_data:
                payload["input_text"] = context.input_data[:10_000]

            check_result = await self.client.policy_check_async(**payload)
            context.metadata = context.metadata or {}
            context.metadata["post_policy.action"] = check_result.action
            if check_result.policy_ids:
                context.metadata["post_policy.triggered_policies"] = ",".join(check_result.policy_ids)
            logger.debug(
                "policy_post_checked_audit",
                extra=self._policy_obs_extra(context, "post_execution"),
            )
        except Exception:
            logger.debug("post_check_audit_only_async: check failed, continuing")

    # ------------------------------------------------------------------
    # Execution — sync/async/gen variants with pre-execution policy check
    # ------------------------------------------------------------------

    def execute_sync(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        context, span_cm = self._span_scaffold(func, args, kwargs, options)
        bind_cm = bind_context(context)
        bind_cm.__enter__()
        try:
            span_cm.__enter__()
        except Exception:
            bind_cm.__exit__(None, None, None)
            raise

        deferred = False
        result: Any = None
        error: BaseException | None = None
        try:
            self._pre_execution_policy_check(context, options)
            result = func(*args, **kwargs)

            if self._is_unwrapped_async_iterator(result):
                deferred = True
                return _AsyncIteratorSpanWrapper(
                    result, context, self, options, span_cm, bind_cm,
                )

            if self._is_unwrapped_iterator(result):
                deferred = True
                return _IteratorSpanWrapper(
                    result, context, self, options, span_cm, bind_cm,
                )

            context.finish(result=result)
            self._post_execution_policy_check(context, options, result)
            return result
        except GovernanceBlockedError as gbe:
            error = gbe
            context.status = "blocked"
            context.error = gbe
            raise
        except Exception as exc:
            error = exc
            context.finish(error=exc)
            raise
        finally:
            if not deferred:
                self._pop_node(context)
                self._finalize(context, options, result, error, is_async=False)
                exc_info = (type(error), error, getattr(error, "__traceback__", None)) if error else (None, None, None)
                try:
                    span_cm.__exit__(*exc_info)
                except Exception:
                    pass
                try:
                    bind_cm.__exit__(*exc_info)
                except Exception:
                    pass

    async def execute_async(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        context, span_cm = self._span_scaffold(func, args, kwargs, options)
        bind_cm = bind_context(context)
        bind_cm.__enter__()
        try:
            span_cm.__enter__()
        except Exception:
            bind_cm.__exit__(None, None, None)
            raise

        deferred = False
        result: Any = None
        error: BaseException | None = None
        try:
            await self._pre_execution_policy_check_async(context, options)
            result = await func(*args, **kwargs)

            if self._is_unwrapped_async_iterator(result):
                deferred = True
                return _AsyncIteratorSpanWrapper(
                    result, context, self, options, span_cm, bind_cm,
                )

            if self._is_unwrapped_iterator(result):
                deferred = True
                return _IteratorSpanWrapper(
                    result, context, self, options, span_cm, bind_cm,
                )

            context.finish(result=result)
            await self._post_execution_policy_check_async(context, options, result)
            return result
        except GovernanceBlockedError as gbe:
            error = gbe
            context.status = "blocked"
            context.error = gbe
            raise
        except Exception as exc:
            error = exc
            context.finish(error=exc)
            raise
        finally:
            if not deferred:
                self._pop_node(context)
                await self._finalize_async(context, options, result, error)
                exc_info = (type(error), error, getattr(error, "__traceback__", None)) if error else (None, None, None)
                try:
                    span_cm.__exit__(*exc_info)
                except Exception:
                    pass
                try:
                    bind_cm.__exit__(*exc_info)
                except Exception:
                    pass

    def execute_sync_gen(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        """Wrap a sync generator: span covers the full iteration lifetime."""
        context, span_cm = self._span_scaffold(func, args, kwargs, options)
        with bind_context(context), span_cm:
            error: BaseException | None = None
            chunks: list = []
            try:
                self._pre_execution_policy_check(context, options)
                for item in func(*args, **kwargs):
                    chunks.append(item)
                    yield item
                context.finish(result=chunks)
                self._post_check_audit_only(context, options, chunks)
            except GovernanceBlockedError as gbe:
                error = gbe
                context.status = "blocked"
                context.error = gbe
                raise
            except Exception as exc:
                error = exc
                context.finish(error=exc)
                raise
            finally:
                self._pop_node(context)
                self._finalize(context, options, chunks, error, is_async=False)

    async def execute_async_gen(self, func: Callable, args: tuple, kwargs: dict, options: InstrumentationOptions):
        """Wrap an async generator: span covers the full iteration lifetime."""
        context, span_cm = self._span_scaffold(func, args, kwargs, options)
        with bind_context(context), span_cm:
            error: BaseException | None = None
            chunks: list = []
            try:
                await self._pre_execution_policy_check_async(context, options)
                async for item in func(*args, **kwargs):
                    chunks.append(item)
                    yield item
                context.finish(result=chunks)
                await self._post_check_audit_only_async(context, options, chunks)
            except GovernanceBlockedError as gbe:
                error = gbe
                context.status = "blocked"
                context.error = gbe
                raise
            except Exception as exc:
                error = exc
                context.finish(error=exc)
                raise
            finally:
                self._pop_node(context)
                await self._finalize_async(context, options, chunks, error)

    # ------------------------------------------------------------------
    # Finalize — shared logic, branching only on the emit call
    # ------------------------------------------------------------------

    def _finalize_common(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
        error: BaseException | None,
    ):
        """Shared pre-emit logic: transcript, KPI, event build."""
        self._auto_populate_io(context, result, error)
        self.event_builder.apply_transcript(options, context, result, error)
        kpi_results = evaluate_kpis(options.kpis, context)
        event = self.event_builder.build(context, options, kpi_results)
        payload = self.client.serialize_events([event])
        return payload, kpi_results, options.governance

    _USER_INPUT_KEYS = ("user_query", "guest_message", "input", "query", "message", "question", "prompt", "text")

    @staticmethod
    def _auto_populate_io(
        context: ExecutionContext,
        result: Any,
        error: BaseException | None,
    ) -> None:
        """Auto-populate input_data/output_data for raw @instrument spans.

        Framework integrations (LangGraph, LangChain, etc.) explicitly call
        ``ctx.set_io()`` with rich data.  When they haven't, fall back to a
        best-effort extraction:

        * For dict arguments, extract the first user-facing key (user_query,
          input, message, …) rather than dumping the entire state dict.
        * For dict returns, extract the last-set key that looks like an output
          (final_response, action_result, output, …).
        """
        from .config import MAX_FIELD_SIZE

        if context.input_data is None:
            try:
                text: str | None = None
                if context.args:
                    first = context.args[0]
                    if isinstance(first, dict):
                        text = TuringPulsePlugin._extract_user_field(first)
                        if text is None:
                            text = json.dumps(first, default=str, ensure_ascii=False)
                    elif isinstance(first, str):
                        text = first
                    else:
                        text = repr(first)
                elif context.kwargs:
                    text = json.dumps(
                        {k: v for k, v in context.kwargs.items()},
                        default=str,
                        ensure_ascii=False,
                    )
                if text:
                    context.input_data = text[:MAX_FIELD_SIZE]
            except Exception:
                pass

        if context.output_data is None and result is not None and error is None:
            try:
                if isinstance(result, dict):
                    text = TuringPulsePlugin._extract_output_field(result)
                    if text is None:
                        text = json.dumps(result, default=str, ensure_ascii=False)
                elif isinstance(result, str):
                    text = result
                elif isinstance(result, list):
                    text = TuringPulsePlugin._join_chunk_list(result)
                else:
                    text = repr(result)
                context.output_data = text[:MAX_FIELD_SIZE]
            except Exception:
                pass

    @staticmethod
    def _extract_user_field(d: dict) -> str | None:
        for key in TuringPulsePlugin._USER_INPUT_KEYS:
            val = d.get(key)
            if val and isinstance(val, str):
                return val
        return None

    _OUTPUT_KEYS = ("final_response", "action_result", "output", "result", "response", "answer", "completion")

    @staticmethod
    def _extract_output_field(d: dict) -> str | None:
        for key in TuringPulsePlugin._OUTPUT_KEYS:
            val = d.get(key)
            if val and isinstance(val, str):
                return val
        return None

    @staticmethod
    def _join_chunk_list(chunks: list) -> str:
        """Best-effort text extraction from a list of generator/stream chunks.

        If every item is a string, join them directly. Otherwise try common
        content attributes before falling back to repr().
        """
        if not chunks:
            return ""
        if all(isinstance(c, str) for c in chunks):
            return "".join(chunks)
        parts: list[str] = []
        for item in chunks:
            if isinstance(item, str):
                parts.append(item)
                continue
            for attr in ("content", "text"):
                val = getattr(item, attr, None)
                if val and isinstance(val, str):
                    parts.append(val)
                    break
            else:
                choices = getattr(item, "choices", None)
                if choices:
                    delta = getattr(choices[0], "delta", None) if choices else None
                    cnt = getattr(delta, "content", None) if delta else None
                    if cnt and isinstance(cnt, str):
                        parts.append(cnt)
        return "".join(parts) if parts else repr(chunks)

    def _finalize(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
        error: BaseException | None,
        is_async: bool = False,
    ) -> None:
        payload, kpi_results, directive = self._finalize_common(context, options, result, error)
        try:
            self.client.emit_serialized_payload(payload)
        except Exception as exc:
            logger.warning("Failed to emit TuringPulse event: %s", type(exc).__name__)
        if not isinstance(error, GovernanceBlockedError):
            self._handle_governance(directive, context, kpi_results)
        if context.depth == 0 and context.fingerprint_builder:
            self._send_fingerprint(context, error)

    async def _finalize_async(
        self,
        context: ExecutionContext,
        options: InstrumentationOptions,
        result: Any,
        error: BaseException | None,
    ) -> None:
        payload, kpi_results, directive = self._finalize_common(context, options, result, error)
        try:
            await self.client.emit_serialized_payload_async(payload)
        except Exception as exc:
            logger.warning("Failed to emit TuringPulse event (async): %s", type(exc).__name__)
        if not isinstance(error, GovernanceBlockedError):
            await self._handle_governance_async(directive, context, kpi_results)
        if context.depth == 0 and context.fingerprint_builder:
            await self._send_fingerprint_async(context, error)

    # ------------------------------------------------------------------
    # Context building
    # ------------------------------------------------------------------

    def _build_context(
        self,
        func: Callable,
        args: tuple,
        kwargs: dict,
        options: InstrumentationOptions,
    ) -> ExecutionContext:
        trigger_key = self._namespaced_key(options.trigger_key) if options.trigger_key else None
        labels = self.config.merged_labels(options.labels)
        metadata = dict(options.metadata)
        metadata["agent.function"] = func.__name__
        metadata["agent.operation"] = options.operation or func.__name__
        parent = current_context()
        run_id = parent.run_id if parent else uuid4().hex
        parent_span_id = parent.span_id if parent else None
        depth = (parent.depth + 1) if parent else 0

        fingerprint_builder = None
        if self.config.fingerprint.enabled:
            fingerprint_builder = parent.fingerprint_builder if parent else FingerprintBuilder(self.config.fingerprint)

        workflow_name = options.workflow_name or self.config.workflow_name
        node_id = options.effective_agent_id or workflow_name

        pending_attachments: list = []
        if depth == 0:
            pending_attachments = self._drain_pending_attachments()

        return ExecutionContext(
            run_id=run_id,
            agent_id=node_id,
            operation=options.operation or func.__name__,
            trigger_key=trigger_key,
            hidden_entrypoint=options.hidden_entrypoint,
            labels=labels,
            metadata=metadata,
            args=args,
            kwargs=kwargs,
            parent_span_id=parent_span_id,
            depth=depth,
            fingerprint_builder=fingerprint_builder,
            workflow_id=node_id,
            workflow_name=workflow_name,
            agentic_pattern=options.agentic_pattern,
            attachments=pending_attachments,
        )

    @staticmethod
    def _drain_pending_attachments() -> list:
        """Collect attachments uploaded before any span was active."""
        try:
            from .attachments import drain_global_pending
            return drain_global_pending()
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Governance
    # ------------------------------------------------------------------

    def _handle_governance(
        self,
        directive: GovernanceDirective | None,
        context: ExecutionContext,
        kpi_results: list[KPIResult],
    ) -> None:
        if not directive:
            return
        try:
            self.governance.enforce(directive, context, kpi_results)
        except Exception as exc:
            logger.warning("Failed to enforce governance directive: %s", type(exc).__name__)

    async def _handle_governance_async(
        self,
        directive: GovernanceDirective | None,
        context: ExecutionContext,
        kpi_results: list[KPIResult],
    ) -> None:
        if not directive:
            return
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._handle_governance, directive, context, kpi_results)

    # ------------------------------------------------------------------
    # Fingerprinting
    # ------------------------------------------------------------------

    def _record_node(self, context: ExecutionContext, func: Callable, args: tuple, kwargs: dict) -> None:
        func_name = func.__name__
        func_qualname = getattr(func, "__qualname__", func_name)
        explicit_type = context.metadata.get("node_type")
        node_type, llm_info = detect_node_type(func_name, func_qualname, args, kwargs)
        if explicit_type:
            node_type = explicit_type

        if not context.node_type:
            context.node_type = node_type
        if llm_info:
            if not context.model:
                context.model = llm_info.model
            if not context.provider:
                context.provider = llm_info.provider

        if not context.fingerprint_builder:
            return
        if llm_info:
            context.record_node(name=func_name, node_type=node_type, config=llm_info.config, prompt=llm_info.prompt)
        else:
            context.record_node(name=func_name, node_type=node_type)
        context.fingerprint_builder.push_parent(func_name)

    def _pop_node(self, context: ExecutionContext) -> None:
        if context.fingerprint_builder:
            context.fingerprint_builder.pop_parent()

    def _build_fingerprint_payload(self, context: ExecutionContext) -> Dict[str, Any]:
        assert context.fingerprint_builder is not None
        fingerprint_data = context.fingerprint_builder.get_fingerprint()
        return {
            "run_id": context.run_id,
            "workflow_id": context.workflow_id or context.agent_id,
            "fingerprint": fingerprint_data.model_dump(),
        }

    def _send_fingerprint(self, context: ExecutionContext, error: Optional[BaseException]) -> None:
        if not self.config.fingerprint.enabled or not context.fingerprint_builder:
            return
        if error and not self.config.fingerprint.send_on_failure:
            return
        payload = self._build_fingerprint_payload(context)
        if self.config.fingerprint.send_async:
            threading.Thread(target=self._emit_fingerprint, args=(payload,), daemon=True).start()
        else:
            self._emit_fingerprint(payload)

    async def _send_fingerprint_async(self, context: ExecutionContext, error: Optional[BaseException]) -> None:
        if not self.config.fingerprint.enabled or not context.fingerprint_builder:
            return
        if error and not self.config.fingerprint.send_on_failure:
            return
        payload = self._build_fingerprint_payload(context)
        loop = asyncio.get_running_loop()
        if self.config.fingerprint.send_async:
            asyncio.ensure_future(loop.run_in_executor(None, self._emit_fingerprint, payload))
        else:
            await loop.run_in_executor(None, self._emit_fingerprint, payload)

    def _emit_fingerprint(self, payload: Dict[str, Any]) -> None:
        try:
            result = self.client.post_fingerprint(payload)
            if result:
                logger.debug("Fingerprint sent for run %s", payload.get("run_id"))
        except Exception as exc:
            logger.warning("Failed to send fingerprint: %s", type(exc).__name__)

    # ------------------------------------------------------------------
    # Custom change registration
    # ------------------------------------------------------------------

    def register_custom_change(
        self,
        change_type: str,
        details: Optional[Dict[str, Any]] = None,
        workflow_id: Optional[str] = None,
        detected_at: Optional[str] = None,
    ) -> bool:
        """Register a custom change event for root cause analysis."""
        context = current_context()
        wf_id = workflow_id or (context.workflow_id or context.agent_id if context else None)
        if not wf_id:
            logger.warning("register_custom_change: No workflow_id provided and no active context")
            return False
        payload: Dict[str, Any] = {
            "workflow_id": wf_id,
            "change_type": change_type,
            "change_details": details or {},
            "source": "sdk",
            "metadata": {},
        }
        if detected_at:
            payload["detected_at"] = detected_at
        try:
            result = self.client.post_custom_change(payload)
            if result and result.get("success"):
                logger.debug("Registered custom change: type=%s, workflow=%s", change_type, wf_id)
                return True
            logger.warning("Failed to register custom change: unexpected response")
            return False
        except Exception as exc:
            logger.warning("Failed to register custom change: %s", type(exc).__name__)
            return False

    async def register_custom_change_async(
        self,
        change_type: str,
        details: Optional[Dict[str, Any]] = None,
        workflow_id: Optional[str] = None,
        detected_at: Optional[str] = None,
    ) -> bool:
        """Async version of register_custom_change."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, lambda: self.register_custom_change(change_type, details, workflow_id, detected_at)
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _namespaced_key(self, key: str) -> str:
        return key if ":" in key else f"{self.config.trigger_namespace}:{key}"


# ======================================================================
# Iterator span wrappers — deferred finalization for streaming results
# ======================================================================


class _IteratorSpanWrapper:
    """Wraps a sync iterator returned by ``execute_sync`` for deferred span finalization.

    The span stays open while the consumer iterates.  When the iterator is
    exhausted, encounters an error, or is explicitly closed, the span is
    finalized with accumulated chunks and provider-enriched context data.
    """

    __slots__ = (
        "_iterable", "_context", "_plugin", "_options",
        "_span_cm", "_bind_cm", "_chunks", "_closed",
    )

    def __init__(self, iterable, context, plugin, options, span_cm, bind_cm):
        self._iterable = iter(iterable)
        self._context = context
        self._plugin = plugin
        self._options = options
        self._span_cm = span_cm
        self._bind_cm = bind_cm
        self._chunks: list = []
        self._closed = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._iterable)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._close_span(error=None)
            raise
        except Exception as exc:
            self._close_span(error=exc)
            raise

    def __enter__(self):
        if hasattr(self._iterable, "__enter__"):
            self._iterable.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if hasattr(self._iterable, "__exit__"):
            self._iterable.__exit__(exc_type, exc_val, exc_tb)
        self._close_span(error=exc_val)
        return False

    def close(self):
        if hasattr(self._iterable, "close"):
            self._iterable.close()
        self._close_span(error=None)

    @property
    def response(self):
        """Forward ``.response`` for HTTP header access (e.g. OpenAI ``Stream.response``)."""
        return getattr(self._iterable, "response", None)

    def __del__(self):
        self._close_span(error=None)

    def _close_span(self, error):
        if self._closed:
            return
        self._closed = True

        if error:
            self._context.finish(error=error)
        else:
            self._context.finish(result=self._chunks)
            try:
                self._plugin._post_check_audit_only(self._context, self._options, self._chunks)
            except Exception:
                pass

        self._plugin._pop_node(self._context)
        self._plugin._finalize(self._context, self._options, self._chunks, error, is_async=False)
        exc_info = (type(error), error, getattr(error, "__traceback__", None)) if error else (None, None, None)
        try:
            self._span_cm.__exit__(*exc_info)
        except Exception:
            pass
        try:
            self._bind_cm.__exit__(*exc_info)
        except Exception:
            pass


class _AsyncIteratorSpanWrapper:
    """Async counterpart of ``_IteratorSpanWrapper`` for ``AsyncStream`` and similar."""

    __slots__ = (
        "_iterable", "_context", "_plugin", "_options",
        "_span_cm", "_bind_cm", "_chunks", "_closed",
    )

    def __init__(self, iterable, context, plugin, options, span_cm, bind_cm):
        self._iterable = iterable.__aiter__()
        self._context = context
        self._plugin = plugin
        self._options = options
        self._span_cm = span_cm
        self._bind_cm = bind_cm
        self._chunks: list = []
        self._closed = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._iterable.__anext__()
            self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            await self._close_span(error=None)
            raise
        except Exception as exc:
            await self._close_span(error=exc)
            raise

    async def __aenter__(self):
        if hasattr(self._iterable, "__aenter__"):
            await self._iterable.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if hasattr(self._iterable, "__aexit__"):
            await self._iterable.__aexit__(exc_type, exc_val, exc_tb)
        await self._close_span(error=exc_val)
        return False

    async def close(self):
        if hasattr(self._iterable, "close"):
            coro = self._iterable.close()
            if asyncio.iscoroutine(coro):
                await coro
        await self._close_span(error=None)

    @property
    def response(self):
        return getattr(self._iterable, "response", None)

    def __del__(self):
        if not self._closed:
            self._closed = True
            try:
                self._span_cm.__exit__(None, None, None)
            except Exception:
                pass
            try:
                self._bind_cm.__exit__(None, None, None)
            except Exception:
                pass

    async def _close_span(self, error):
        if self._closed:
            return
        self._closed = True

        if error:
            self._context.finish(error=error)
        else:
            self._context.finish(result=self._chunks)
            try:
                await self._plugin._post_check_audit_only_async(self._context, self._options, self._chunks)
            except Exception:
                pass

        self._plugin._pop_node(self._context)
        await self._plugin._finalize_async(self._context, self._options, self._chunks, error)
        exc_info = (type(error), error, getattr(error, "__traceback__", None)) if error else (None, None, None)
        try:
            self._span_cm.__exit__(*exc_info)
        except Exception:
            pass
        try:
            self._bind_cm.__exit__(*exc_info)
        except Exception:
            pass


def init(config: TuringPulseConfig | None = None, **overrides) -> TuringPulsePlugin:
    """Initialise the TuringPulse SDK.

    No network calls are made during init — the SDK simply stores the
    configuration locally.  The backend resolves tenant_id and project_id
    from the API key when the first telemetry payload is sent.

    Usage::

        import turingpulse_sdk

        turingpulse_sdk.init(
            api_key="sk_...",
            workflow_name="customer-support",
        )
    """
    global _PLUGIN
    if config is None:
        config = TuringPulseConfig(**overrides)
    elif overrides:
        merged = config.model_dump()
        merged.update(overrides)
        config = TuringPulseConfig(**merged)

    _PLUGIN = TuringPulsePlugin(config)
    flush_pending(_PLUGIN)
    return _PLUGIN


def get_plugin() -> TuringPulsePlugin:
    global _PLUGIN
    if _PLUGIN is None:
        with _INIT_LOCK:
            if _PLUGIN is None:
                api_key = os.getenv("TP_API_KEY", "")
                if api_key:
                    logger.info("Auto-initializing TuringPulse SDK from environment variables")
                    init()
                else:
                    raise PluginNotInitializedError(
                        "TuringPulse plugin is not initialized. "
                        "Call turingpulse_sdk.init(...) once or set TP_API_KEY env var."
                    )
    assert _PLUGIN is not None
    return _PLUGIN
