import argparse
import sys
import json
from . import RpcClient
from . import __version__

def parse_args(args: list = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser('rpc-cli')

    parser.add_argument('-v', '--version',
                        action='version', version=f'%(prog)s {__version__}')

    parser.add_argument('url')
    parser.add_argument('method')
    parser.add_argument('params', nargs='*')

    return parser.parse_args(args)

def main(args: argparse.Namespace = None) -> None:
    if args is None:
        args = parse_args()

    params = args.params

    rpc = RpcClient(args.url)
    if all('=' in param and len(param.split('=')) == 2 for param in params):
        named_params = {}
        for param in params:
            key, val = param.split('=')
            named_params[key] = val
        result = rpc.call(args.method, **named_params)
    else:
        result = rpc.call(args.method, *params)

    if 'error' in result:
        print('Error:\n')
        print(result['error']['message'])
        sys.exit(result['error']['code'])

    print(json.dumps(result, indent=4))

if __name__ == '__main__':
    main()
