"""
Integration tests for xwformats.
"""
