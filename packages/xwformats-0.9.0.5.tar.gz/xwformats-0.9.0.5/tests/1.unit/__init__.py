"""
Unit tests for xwformats.
"""
