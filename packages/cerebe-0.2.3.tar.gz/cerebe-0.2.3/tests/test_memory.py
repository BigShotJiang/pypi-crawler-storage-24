"""Tests for MemoryResource — sync client."""

from __future__ import annotations

from cerebe import Cerebe


class TestMemoryAdd:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"id": "mem_1"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.memory.add("user likes dark mode", "sess_1", type="semantic", importance=0.8)

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/memory/store"
        body = req.read()
        import json

        data = json.loads(body)
        assert data["content"] == "user likes dark mode"
        assert data["session_id"] == "sess_1"
        assert data["memory_type"] == "semantic"
        assert data["importance"] == 0.8


class TestMemorySearch:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"memories": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.memory.search(
            "preferences", "sess_1", entity_id="user_1", types=["semantic", "episodic"], min_importance=0.5
        )

        req = httpx_mock.get_request()
        import json

        data = json.loads(req.read())
        assert data["query"] == "preferences"
        assert data["session_id"] == "sess_1"
        assert data["entity_id"] == "user_1"
        assert data["memory_types"] == ["semantic", "episodic"]
        assert data["min_importance"] == 0.5


class TestMemoryGet:
    def test_calls_correct_endpoint(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"id": "mem_1"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.memory.get("mem_1")

        req = httpx_mock.get_request()
        assert req.url.path == "/api/v1/memory/mem_1"


class TestMemorySession:
    def test_calls_correct_endpoint_with_params(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"memories": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.memory.session("sess_1", limit=10, memory_types=["working"])

        req = httpx_mock.get_request()
        assert "/api/v1/memory/session/sess_1" in str(req.url)
        assert "limit=10" in str(req.url)
        assert "memory_types=working" in str(req.url)


class TestMemoryRelationships:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"status": "created"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.memory.relationships("mem_1", "mem_2", "relates_to")

        req = httpx_mock.get_request()
        import json

        data = json.loads(req.read())
        assert data["source_id"] == "mem_1"
        assert data["target_id"] == "mem_2"
        assert data["relation_type"] == "relates_to"


class TestMemoryQueryTune:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"tuned_query": "optimized"}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.memory.query_tune("sess_1", "what did we discuss?")

        req = httpx_mock.get_request()
        import json

        data = json.loads(req.read())
        assert data["session_id"] == "sess_1"
        assert data["message"] == "what did we discuss?"


class TestMemoryHarvest:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"harvested_memories": []}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.memory.harvest(
            "sess_1",
            [{"role": "user", "content": "I prefer dark mode."}],
            entity_id="user_1",
        )

        req = httpx_mock.get_request()
        import json

        data = json.loads(req.read())
        assert data["session_id"] == "sess_1"
        assert data["transcript"] == [{"role": "user", "content": "I prefer dark mode."}]
        assert data["entity_id"] == "user_1"


class TestMemoryConsolidate:
    def test_sends_correct_body(self, httpx_mock) -> None:
        httpx_mock.add_response(json={"data": {"consolidated_count": 3}, "meta": {}})
        client = Cerebe(api_key="ck_test", max_retries=0)

        client.memory.consolidate("user_1", similarity_threshold=0.95, dry_run=True)

        req = httpx_mock.get_request()
        import json

        data = json.loads(req.read())
        assert data["entity_id"] == "user_1"
        assert data["similarity_threshold"] == 0.95
        assert data["dry_run"] is True
