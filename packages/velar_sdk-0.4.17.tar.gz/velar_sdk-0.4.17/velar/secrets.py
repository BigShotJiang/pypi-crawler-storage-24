"""Secret marker objects for referencing named secrets at deploy time."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Secret:
    """A marker that references a named secret stored in Velar.

    Do not instantiate directly — use :meth:`from_name`.

    Usage::

        import velar

        @app.function(gpu="L4", image=image,
                      named_secrets=[velar.Secret.from_name("huggingface")])
        def infer(prompt):
            import os
            token = os.environ["HF_TOKEN"]  # injected by Velar at runtime
            ...
    """

    name: str

    @classmethod
    def from_name(cls, name: str) -> "Secret":
        """Return a Secret marker for the given secret name.

        No network call is made — the name is resolved at deploy time.

        Args:
            name: The name of the secret as stored in Velar
                  (e.g. ``"huggingface"``).
        """
        return cls(name=name)

    def __repr__(self) -> str:
        return f"Secret.from_name({self.name!r})"
