"""Velar Python SDK - Deploy ML models to GPUs with one command."""

from velar.app import App
from velar.decorators import function, endpoint
from velar.deployment import Deployment
from velar.image import Image
from velar.serialization import serialize, deserialize
from velar.client import RemoteExecutionError
from velar.secrets import Secret
from velar import gpu


def method():
    """Mark a method inside @app.cls for remote invocation."""
    def decorator(func):
        func._velar_method = True
        return func
    return decorator


__all__ = ["App", "Deployment", "function", "endpoint", "method", "Secret", "gpu", "Image", "serialize", "deserialize", "RemoteExecutionError"]
__version__ = "0.4.16"
