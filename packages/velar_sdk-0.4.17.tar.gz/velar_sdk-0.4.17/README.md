# Velar Python SDK

Deploy ML models to GPUs with one command.

## Installation

```bash
pip install velar-sdk
```

## Quick Start

```bash
velar login        # authenticate via browser
velar run app:app  # deploy + run + cleanup
```

```python
import os
import velar

app = velar.App("my-app")
image = velar.Image.from_registry(
    "pytorch/pytorch:2.1.0-cuda12.1-cudnn8-runtime"
).pip_install("transformers", "accelerate")

@app.function(gpu="A100", image=image, timeout=600)
def run(prompt: str) -> str:
    from transformers import pipeline
    pipe = pipeline("text-generation", model="gpt2")
    return pipe(prompt, max_length=100)[0]["generated_text"]

@app.local_entrypoint()
def main():
    app.deploy(wait=True)
    print(run.remote("The future of AI is"))
```

**Full documentation:** [velar.run/docs](https://velar.run/docs)

## Links

- [Documentation](https://velar.run/docs)
- [Dashboard](https://velar.run/dashboard)
- [Pricing](https://velar.run/pricing)
