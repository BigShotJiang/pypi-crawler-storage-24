"""Two-line block-character ASCII font, ported from th's ascii_font.rs.

Each letter is a 2-element list of strings (top line, bottom line).
Characters use █ ▀ ▄ ░ block drawing chars for a compact, bold look.
"""

from __future__ import annotations

# fmt: off
_LETTERS: dict[str, list[str]] = {
    "A": ["▄▀█", "█▀█"],
    "B": ["█▀▄", "█▄█"],
    "C": ["█▀▀", "█▄▄"],
    "D": ["█▀▄", "█▄▀"],
    "E": ["█▀▀", "██▄"],
    "F": ["█▀▀", "█▀░"],
    "G": ["█▀▀", "█▄█"],
    "H": ["█░█", "█▀█"],
    "I": ["█", "█"],
    "J": ["░░█", "█▄█"],
    "K": ["█▄▀", "█░█"],
    "L": ["█░░", "█▄▄"],
    "M": ["█▀▄▀█", "█░▀░█"],
    "N": ["█▄░█", "█░▀█"],
    "O": ["█▀█", "█▄█"],
    "P": ["█▀█", "█▀▀"],
    "Q": ["█▀█", "█▄▀"],
    "R": ["█▀█", "█▀▄"],
    "S": ["█▀", "▄█"],
    "T": ["▀█▀", "░█░"],
    "U": ["█░█", "█▄█"],
    "V": ["█░█", "▀▄▀"],
    "W": ["█░█░█", "▀▄▀▄▀"],
    "X": ["▀▄▀", "█░█"],
    "Y": ["█▄█", "░█░"],
    "Z": ["▀█", "█▄"],
    " ": ["░", "░"],
    "0": ["█▀█", "█▄█"],
    "1": ["▄█", "░█"],
    "2": ["▀▀█", "█▄▄"],
    "3": ["▀▀█", "▄▄█"],
    "4": ["█░█", "░▀█"],
    "5": ["█▀▀", "▄▄█"],
    "6": ["█▀▀", "█▄█"],
    "7": ["▀▀█", "░░█"],
    "8": ["█▀█", "█▄█"],
    "9": ["█▀█", "▀▀█"],
}
# fmt: on


def render_ascii_text(text: str) -> list[str]:
    """Render *text* as two lines of block-character ASCII art.

    Returns a 2-element list: [top_line, bottom_line].
    Unknown characters are replaced with 3-space gaps.
    """
    lines = ["", ""]
    for ch in text.upper():
        letter = _LETTERS.get(ch)
        if letter:
            lines[0] += letter[0] + " "
            lines[1] += letter[1] + " "
        else:
            lines[0] += "   "
            lines[1] += "   "
    return [line.rstrip() for line in lines]
