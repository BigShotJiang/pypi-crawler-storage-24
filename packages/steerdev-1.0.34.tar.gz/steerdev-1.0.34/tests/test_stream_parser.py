"""Tests for executor/stream.py (StreamParser)."""

import json
from collections.abc import AsyncIterator
from datetime import UTC, datetime

import pytest

from steerdev_agent.executor.base import EventType, StreamEvent
from steerdev_agent.executor.stream import StreamParser


class TestStreamParserParseLine:
    """Tests for StreamParser.parse_line."""

    def test_parse_empty_line(self):
        parser = StreamParser()
        assert parser.parse_line("") is None
        assert parser.parse_line("   ") is None

    def test_parse_whitespace_only(self):
        parser = StreamParser()
        assert parser.parse_line("  \t  ") is None

    def test_parse_invalid_json(self):
        parser = StreamParser()
        assert parser.parse_line("not json") is None

    def test_parse_system_event(self):
        parser = StreamParser()
        data = {"type": "system", "message": "initialized"}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.event_type == EventType.SYSTEM
        assert event.data == data

    def test_parse_assistant_event(self):
        parser = StreamParser()
        data = {"type": "assistant", "message": {"content": "Hello"}}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.event_type == EventType.ASSISTANT
        assert event.data["message"]["content"] == "Hello"

    def test_parse_tool_use_event(self):
        parser = StreamParser()
        data = {"type": "tool_use", "tool": "read", "input": {"path": "/file"}}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.event_type == EventType.TOOL_USE

    def test_parse_tool_result_event(self):
        parser = StreamParser()
        data = {"type": "tool_result", "result": "success"}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.event_type == EventType.TOOL_RESULT

    def test_parse_error_event(self):
        parser = StreamParser()
        data = {"type": "error", "error": "something went wrong"}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.event_type == EventType.ERROR

    def test_parse_result_event(self):
        parser = StreamParser()
        data = {"type": "result", "result": {"session_id": "sess-123"}}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.event_type == EventType.RESULT

    def test_parse_unknown_type_defaults_to_system(self):
        parser = StreamParser()
        data = {"type": "custom_event", "data": "something"}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.event_type == EventType.SYSTEM

    def test_parse_missing_type_defaults_to_system(self):
        parser = StreamParser()
        data = {"data": "no type field"}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.event_type == EventType.SYSTEM

    def test_raw_json_preserved(self):
        parser = StreamParser()
        raw = '{"type": "system", "msg": "test"}'
        event = parser.parse_line(raw)

        assert event is not None
        assert event.raw_json == raw

    def test_line_with_leading_trailing_whitespace(self):
        parser = StreamParser()
        data = {"type": "assistant", "message": "hi"}
        raw = f"  {json.dumps(data)}  "
        event = parser.parse_line(raw)

        assert event is not None
        assert event.event_type == EventType.ASSISTANT


class TestStreamParserSessionId:
    """Tests for session ID extraction from result events."""

    def test_session_id_from_result_nested(self):
        parser = StreamParser()
        data = {"type": "result", "result": {"session_id": "sess-abc"}}
        parser.parse_line(json.dumps(data))

        assert parser.session_id == "sess-abc"

    def test_session_id_from_top_level(self):
        parser = StreamParser()
        data = {"type": "result", "session_id": "sess-top"}
        parser.parse_line(json.dumps(data))

        assert parser.session_id == "sess-top"

    def test_session_id_initially_none(self):
        parser = StreamParser()
        assert parser.session_id is None

    def test_session_id_not_set_from_non_result(self):
        parser = StreamParser()
        data = {"type": "assistant", "session_id": "ignored"}
        parser.parse_line(json.dumps(data))

        assert parser.session_id is None

    def test_session_id_updated_on_later_result(self):
        parser = StreamParser()

        # First result
        data1 = {"type": "result", "session_id": "sess-1"}
        parser.parse_line(json.dumps(data1))
        assert parser.session_id == "sess-1"

        # Second result overwrites
        data2 = {"type": "result", "session_id": "sess-2"}
        parser.parse_line(json.dumps(data2))
        assert parser.session_id == "sess-2"


class TestStreamParserTimestamp:
    """Tests for timestamp parsing."""

    def test_iso_timestamp(self):
        parser = StreamParser()
        data = {"type": "system", "timestamp": "2025-06-15T10:30:00+00:00"}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.timestamp.year == 2025
        assert event.timestamp.month == 6
        assert event.timestamp.hour == 10

    def test_z_suffix_timestamp(self):
        parser = StreamParser()
        data = {"type": "system", "timestamp": "2025-06-15T10:30:00Z"}
        event = parser.parse_line(json.dumps(data))

        assert event is not None
        assert event.timestamp.year == 2025

    def test_no_timestamp_uses_now(self):
        parser = StreamParser()
        before = datetime.now(UTC)
        data = {"type": "system"}
        event = parser.parse_line(json.dumps(data))
        after = datetime.now(UTC)

        assert event is not None
        assert before <= event.timestamp <= after

    def test_invalid_timestamp_uses_now(self):
        parser = StreamParser()
        before = datetime.now(UTC)
        data = {"type": "system", "timestamp": "not-a-date"}
        event = parser.parse_line(json.dumps(data))
        after = datetime.now(UTC)

        assert event is not None
        assert before <= event.timestamp <= after


class TestStreamParserFeed:
    """Tests for StreamParser.feed (buffered reading)."""

    def test_single_complete_line(self):
        parser = StreamParser()
        data = json.dumps({"type": "system"}) + "\n"
        events = parser.feed(data)

        assert len(events) == 1
        assert events[0].event_type == EventType.SYSTEM

    def test_multiple_lines_in_one_chunk(self):
        parser = StreamParser()
        line1 = json.dumps({"type": "system"})
        line2 = json.dumps({"type": "assistant", "message": "hi"})
        data = f"{line1}\n{line2}\n"
        events = parser.feed(data)

        assert len(events) == 2
        assert events[0].event_type == EventType.SYSTEM
        assert events[1].event_type == EventType.ASSISTANT

    def test_partial_line_buffered(self):
        parser = StreamParser()

        # First chunk: partial JSON
        events1 = parser.feed('{"type": "sys')
        assert events1 == []

        # Second chunk: rest of the line
        events2 = parser.feed('tem"}\n')
        assert len(events2) == 1
        assert events2[0].event_type == EventType.SYSTEM

    def test_empty_lines_skipped(self):
        parser = StreamParser()
        data = json.dumps({"type": "system"}) + "\n\n\n"
        events = parser.feed(data)

        assert len(events) == 1

    def test_multiple_chunks(self):
        parser = StreamParser()

        events1 = parser.feed(json.dumps({"type": "system"}) + "\n")
        assert len(events1) == 1

        events2 = parser.feed(json.dumps({"type": "error", "error": "x"}) + "\n")
        assert len(events2) == 1
        assert events2[0].event_type == EventType.ERROR


class TestStreamParserFlush:
    """Tests for StreamParser.flush."""

    def test_flush_empty_buffer(self):
        parser = StreamParser()
        assert parser.flush() is None

    def test_flush_whitespace_buffer(self):
        parser = StreamParser()
        parser._buffer = "   "
        assert parser.flush() is None

    def test_flush_with_buffered_data(self):
        parser = StreamParser()
        parser.feed('{"type": "system"}')  # No newline, stays in buffer

        event = parser.flush()
        assert event is not None
        assert event.event_type == EventType.SYSTEM

    def test_flush_clears_buffer(self):
        parser = StreamParser()
        parser.feed('{"type": "system"}')
        parser.flush()

        # Second flush should return None
        assert parser.flush() is None


class TestStreamParserParseStream:
    """Tests for StreamParser.parse_stream (async iterator)."""

    @pytest.mark.asyncio
    async def test_parse_async_stream(self):
        parser = StreamParser()

        async def lines() -> AsyncIterator[str]:
            yield json.dumps({"type": "system"})
            yield json.dumps({"type": "assistant", "message": "hello"})
            yield ""  # Empty line
            yield json.dumps({"type": "result", "session_id": "s1"})

        events = [event async for event in parser.parse_stream(lines())]

        assert len(events) == 3
        assert events[0].event_type == EventType.SYSTEM
        assert events[1].event_type == EventType.ASSISTANT
        assert events[2].event_type == EventType.RESULT
        assert parser.session_id == "s1"


class TestStreamEvent:
    """Tests for StreamEvent dataclass."""

    def test_is_final_result(self):
        event = StreamEvent(
            event_type=EventType.RESULT,
            timestamp=datetime.now(UTC),
            data={"type": "result"},
            raw_json="{}",
        )
        assert event.is_final is True

    def test_is_final_non_result(self):
        for event_type in [
            EventType.SYSTEM,
            EventType.ASSISTANT,
            EventType.TOOL_USE,
            EventType.ERROR,
        ]:
            event = StreamEvent(
                event_type=event_type,
                timestamp=datetime.now(UTC),
                data={},
                raw_json="{}",
            )
            assert event.is_final is False


class TestEventTypeMapping:
    """Tests for StreamParser.EVENT_TYPE_MAP completeness."""

    def test_all_known_types_mapped(self):
        """Verify all expected Claude event types are in the mapping."""
        expected = {"system", "user", "assistant", "tool_use", "tool_result", "error", "result"}
        assert set(StreamParser.EVENT_TYPE_MAP.keys()) == expected

    def test_all_mapped_to_valid_event_type(self):
        """All mapped values are valid EventType members."""
        for value in StreamParser.EVENT_TYPE_MAP.values():
            assert isinstance(value, EventType)
