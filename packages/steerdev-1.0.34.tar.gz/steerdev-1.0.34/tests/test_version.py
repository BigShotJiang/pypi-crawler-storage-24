"""Tests for version management utilities."""

from steerdev_agent.version import _predict_new_version, get_project_root


class TestGetProjectRoot:
    """Tests for get_project_root."""

    def test_returns_path(self):
        """Should return a Path object."""
        root = get_project_root()
        assert root.exists()

    def test_contains_pyproject(self):
        """Project root should contain pyproject.toml."""
        root = get_project_root()
        assert (root / "pyproject.toml").exists()


class TestPredictNewVersion:
    """Tests for _predict_new_version."""

    def test_major_bump(self):
        assert _predict_new_version("1.2.3", "major") == "2.0.0"

    def test_minor_bump(self):
        assert _predict_new_version("1.2.3", "minor") == "1.3.0"

    def test_patch_bump(self):
        assert _predict_new_version("1.2.3", "patch") == "1.2.4"

    def test_major_bump_from_zero(self):
        assert _predict_new_version("0.5.4", "major") == "1.0.0"

    def test_minor_bump_from_zero(self):
        assert _predict_new_version("0.5.4", "minor") == "0.6.0"

    def test_patch_bump_from_zero(self):
        assert _predict_new_version("0.5.4", "patch") == "0.5.5"

    def test_non_standard_bump_type(self):
        """Non-major/minor/patch bumps delegate to uv."""
        result = _predict_new_version("1.2.3", "alpha")
        assert "uv will calculate" in result

    def test_pre_release_version_patch(self):
        """Should handle versions like 0.1.0a1."""
        result = _predict_new_version("0.1.0a1", "patch")
        # "0a1" -> digits "01" -> int 1, then +1 = 2
        assert result == "0.1.2"

    def test_short_version_string(self):
        """Versions with fewer than 3 parts should return fallback."""
        result = _predict_new_version("1.2", "major")
        assert "?" in result

    def test_single_number_version(self):
        """Single number version should return fallback."""
        result = _predict_new_version("1", "patch")
        assert "?" in result

    def test_empty_version(self):
        """Empty version should return fallback."""
        result = _predict_new_version("", "patch")
        assert "?" in result
