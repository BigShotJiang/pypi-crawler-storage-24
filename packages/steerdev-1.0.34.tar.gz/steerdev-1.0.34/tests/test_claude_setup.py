"""Tests for Claude setup templates and installed skills."""

from steerdev_agent.setup.claude_setup import ClaudeSetup


class TestClaudeSetup:
    """Tests for lean default setup guidance."""

    def test_setup_skills_installs_focused_merge_skills(self, tmp_path):
        setup = ClaudeSetup(project_dir=tmp_path)

        skills_path = setup.setup_skills(force=True)

        assert (skills_path / "steerdev-task-management-skill" / "SKILL.md").exists()
        assert (skills_path / "steerdev-progress-logging-skill" / "SKILL.md").exists()
        assert (skills_path / "steerdev-single-task-merge-skill" / "SKILL.md").exists()
        assert (skills_path / "steerdev-wave-tasks-merge-skill" / "SKILL.md").exists()
        assert (skills_path / "steerdev-merge-into-canal-skill" / "SKILL.md").exists()
        # Deprecated shims are not installed
        assert not (skills_path / "steerdev-git-workflow-skill" / "SKILL.md").exists()
        assert not (skills_path / "steerdev-canal-workflow-skill" / "SKILL.md").exists()

    def test_update_claude_md_excludes_merge_instructions(self, tmp_path):
        setup = ClaudeSetup(project_dir=tmp_path)

        updated = setup.update_claude_md(force=True)
        content = (tmp_path / "CLAUDE.md").read_text()

        assert updated is True
        assert "steerdev-task-management-skill" in content
        assert "gh pr create" not in content
        assert "git checkout -b task" not in content
        assert "steerdev canal merge" not in content

    def test_task_management_skill_excludes_merge_instructions(self, tmp_path):
        setup = ClaudeSetup(project_dir=tmp_path)

        skills_path = setup.setup_skills(force=True)
        content = (skills_path / "steerdev-task-management-skill" / "SKILL.md").read_text()

        assert "agent-browser" in content
        assert "--waves/--no-waves" in content
        assert "gh pr create" not in content
        assert "git checkout -b task" not in content
        assert "steerdev canal merge" not in content
        assert "steerdev-single-task-merge-skill" not in content
