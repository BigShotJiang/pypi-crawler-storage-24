"""Extended tests for workspace module (ProjectManager setup/bootstrap paths)."""

from pathlib import Path
from typing import cast
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from steerdev_agent.api.agents import BootstrapBundle, ProjectAssignment
from steerdev_agent.workspace.project_manager import ProjectManager


def _make_manager(workspace_dir: Path) -> ProjectManager:
    mock_client = AsyncMock()
    return ProjectManager(
        workspace_dir=workspace_dir,
        api_client=mock_client,
        agent_id="agent-123",
        api_key="test-key",
    )


# ---------------------------------------------------------------------------
# setup_project
# ---------------------------------------------------------------------------


class TestSetupProject:
    """Tests for ProjectManager.setup_project."""

    @pytest.mark.asyncio
    async def test_returns_none_when_no_bootstrap(self, tmp_path: Path):
        """setup_project returns None when API returns no bootstrap bundle."""
        pm = _make_manager(tmp_path)
        pm.api_client.get_bootstrap = AsyncMock(return_value=None)

        assignment = ProjectAssignment(agent_id="a", project_id="p1")
        result = await pm.setup_project(assignment)
        assert result is None

    @pytest.mark.asyncio
    async def test_creates_project_dir(self, tmp_path: Path):
        """setup_project creates project directory from bundle name."""
        pm = _make_manager(tmp_path)

        bundle = BootstrapBundle(
            project={"name": "my-project"},
            repositories=[],
            agent_configs={},
        )
        pm.api_client.get_bootstrap = AsyncMock(return_value=bundle)

        with (
            patch.object(pm, "_run_setup"),
            patch.object(pm, "_clone_repos"),
        ):
            assignment = ProjectAssignment(agent_id="a", project_id="p1")
            result = await pm.setup_project(assignment)

        assert result is not None
        assert result.name == "my-project"
        assert result.is_dir()
        cast("AsyncMock", pm.api_client.update_assignment).assert_awaited_once()

    @pytest.mark.asyncio
    async def test_project_name_fallback_to_id(self, tmp_path: Path):
        """setup_project falls back to project_id prefix when name is missing."""
        pm = _make_manager(tmp_path)

        bundle = BootstrapBundle(project={}, repositories=[])
        pm.api_client.get_bootstrap = AsyncMock(return_value=bundle)

        with (
            patch.object(pm, "_run_setup"),
            patch.object(pm, "_clone_repos"),
        ):
            assignment = ProjectAssignment(agent_id="a", project_id="abcdefghijklmnop")
            result = await pm.setup_project(assignment)

        assert result is not None
        assert result.name == "abcdefgh"

    @pytest.mark.asyncio
    async def test_calls_clone_repos_when_present(self, tmp_path: Path):
        """setup_project calls _clone_repos when repositories are provided."""
        pm = _make_manager(tmp_path)

        bundle = BootstrapBundle(
            project={"name": "proj"},
            repositories=[{"url": "https://github.com/org/repo"}],
        )
        pm.api_client.get_bootstrap = AsyncMock(return_value=bundle)

        with (
            patch.object(pm, "_clone_repos") as mock_clone,
            patch.object(pm, "_run_setup"),
        ):
            assignment = ProjectAssignment(agent_id="a", project_id="p1")
            await pm.setup_project(assignment)

        mock_clone.assert_called_once()

    @pytest.mark.asyncio
    async def test_skips_clone_when_no_repos(self, tmp_path: Path):
        """setup_project skips _clone_repos when no repositories."""
        pm = _make_manager(tmp_path)

        bundle = BootstrapBundle(project={"name": "proj"}, repositories=[])
        pm.api_client.get_bootstrap = AsyncMock(return_value=bundle)

        with (
            patch.object(pm, "_clone_repos") as mock_clone,
            patch.object(pm, "_run_setup"),
        ):
            assignment = ProjectAssignment(agent_id="a", project_id="p1")
            await pm.setup_project(assignment)

        mock_clone.assert_not_called()

    @pytest.mark.asyncio
    async def test_updates_assignment_after_setup(self, tmp_path: Path):
        """setup_project calls update_assignment with the project path."""
        pm = _make_manager(tmp_path)

        bundle = BootstrapBundle(project={"name": "proj"})
        pm.api_client.get_bootstrap = AsyncMock(return_value=bundle)

        with (
            patch.object(pm, "_run_setup"),
            patch.object(pm, "_clone_repos"),
        ):
            assignment = ProjectAssignment(agent_id="a", project_id="p1")
            result = await pm.setup_project(assignment)

        cast("AsyncMock", pm.api_client.update_assignment).assert_awaited_once_with(
            "agent-123", "p1", local_path=str(result)
        )


# ---------------------------------------------------------------------------
# _run_setup
# ---------------------------------------------------------------------------


class TestRunSetup:
    """Tests for ProjectManager._run_setup."""

    def test_calls_claude_setup_methods(self, tmp_path: Path):
        """_run_setup invokes all ClaudeSetup configuration methods."""
        pm = _make_manager(tmp_path)
        bundle = BootstrapBundle(project={}, agent_configs={})

        mock_setup = MagicMock()
        with patch(
            "steerdev_agent.setup.claude_setup.ClaudeSetup",
            return_value=mock_setup,
        ):
            pm._run_setup(tmp_path, bundle, project_id="p1")

        mock_setup.setup_env.assert_called_once_with(project_id="p1", api_key="test-key")
        mock_setup.setup_settings.assert_called_once_with(force=False, include_hooks=True)
        mock_setup.setup_skills.assert_called_once_with(force=False)
        mock_setup.update_claude_md.assert_called_once_with(force=False)
        mock_setup.setup_steerdev_config.assert_called_once_with(force=False)

    def test_applies_platform_configs_when_present(self, tmp_path: Path):
        """_run_setup calls _apply_platform_configs when agent_configs exist."""
        pm = _make_manager(tmp_path)
        bundle = BootstrapBundle(
            project={},
            agent_configs={"system_prompt": "hello"},
        )

        mock_setup = MagicMock()
        with (
            patch(
                "steerdev_agent.setup.claude_setup.ClaudeSetup",
                return_value=mock_setup,
            ),
            patch.object(pm, "_apply_platform_configs") as mock_apply,
        ):
            pm._run_setup(tmp_path, bundle, project_id="p1")

        mock_apply.assert_called_once_with(mock_setup, bundle)

    def test_skips_platform_configs_when_empty(self, tmp_path: Path):
        """_run_setup skips _apply_platform_configs when agent_configs is empty."""
        pm = _make_manager(tmp_path)
        bundle = BootstrapBundle(project={}, agent_configs={})

        mock_setup = MagicMock()
        with (
            patch(
                "steerdev_agent.setup.claude_setup.ClaudeSetup",
                return_value=mock_setup,
            ),
            patch.object(pm, "_apply_platform_configs") as mock_apply,
        ):
            pm._run_setup(tmp_path, bundle, project_id="p1")

        mock_apply.assert_not_called()


# ---------------------------------------------------------------------------
# _apply_platform_configs
# ---------------------------------------------------------------------------


class TestApplyPlatformConfigs:
    """Tests for ProjectManager._apply_platform_configs."""

    def test_applies_config(self, tmp_path: Path):
        """_apply_platform_configs parses and applies platform config."""
        pm = _make_manager(tmp_path)
        bundle = BootstrapBundle(agent_configs={"system_prompt": "test"})
        mock_setup = MagicMock()
        mock_config = MagicMock()

        with patch("steerdev_agent.config.platform.PlatformConfig") as mock_platform_config:
            mock_platform_config.from_api_response.return_value = mock_config
            pm._apply_platform_configs(mock_setup, bundle)

        mock_platform_config.from_api_response.assert_called_once_with(bundle.agent_configs)
        mock_setup.apply_platform_configs.assert_called_once_with(mock_config)

    def test_handles_exception_gracefully(self, tmp_path: Path):
        """_apply_platform_configs logs warning on failure, does not raise."""
        pm = _make_manager(tmp_path)
        bundle = BootstrapBundle(agent_configs={"bad": "data"})
        mock_setup = MagicMock()

        with patch("steerdev_agent.config.platform.PlatformConfig") as mock_platform_config:
            mock_platform_config.from_api_response.side_effect = ValueError("parse error")
            # Should not raise
            pm._apply_platform_configs(mock_setup, bundle)


# ---------------------------------------------------------------------------
# _clone_repos
# ---------------------------------------------------------------------------


class TestCloneRepos:
    """Tests for ProjectManager._clone_repos."""

    def test_calls_check_and_clone_repos(self, tmp_path: Path):
        """_clone_repos delegates to check_and_clone_repos."""
        pm = _make_manager(tmp_path)
        bundle = BootstrapBundle(repositories=[{"url": "https://github.com/org/repo"}])

        with patch("steerdev_agent.setup.repo_setup.check_and_clone_repos") as mock_clone:
            pm._clone_repos(tmp_path, bundle)

        mock_clone.assert_called_once_with(
            workspace_dir=tmp_path,
            repositories=bundle.repositories,
            interactive=False,
            clone_all=True,
        )


# ---------------------------------------------------------------------------
# _resolve_path edge cases
# ---------------------------------------------------------------------------


class TestResolvePathEdgeCases:
    """Additional edge case tests for _resolve_path."""

    def test_env_file_read_error(self, tmp_path: Path):
        """_resolve_path handles OSError when reading .env files."""
        pm = _make_manager(tmp_path)

        # Create directory with .env that can't be read
        proj_dir = tmp_path / "proj"
        proj_dir.mkdir()
        env_file = proj_dir / ".env"
        env_file.write_text("STEERDEV_PROJECT_ID=target-id")
        env_file.chmod(0o000)  # Make unreadable

        assignment = ProjectAssignment(agent_id="a", project_id="target-id")
        # Should not raise — OSError is caught
        pm._resolve_path(assignment)
        # Restore permissions for cleanup
        env_file.chmod(0o644)
        # The key test is that it doesn't raise

    def test_workspace_dir_not_exists(self):
        """_resolve_path returns None when workspace_dir doesn't exist."""
        pm = _make_manager(Path("/nonexistent/workspace"))

        assignment = ProjectAssignment(agent_id="a", project_id="p1")
        result = pm._resolve_path(assignment)
        assert result is None

    def test_sync_projects_setup_returns_none(self, tmp_path: Path):
        """sync_projects handles setup_project returning None."""
        pm = _make_manager(tmp_path)
        assignment = ProjectAssignment(agent_id="a", project_id="p-new")
        pm.setup_project = AsyncMock(return_value=None)

        # Run sync
        import asyncio

        asyncio.get_event_loop().run_until_complete(pm.sync_projects([assignment]))
        assert pm.get_project_path("p-new") is None
