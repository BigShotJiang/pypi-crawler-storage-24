"""Tests for agents API client (models and client behavior)."""

import os
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from steerdev_agent.api.agents import (
    AgentRegisterRequest,
    AgentResponse,
    AgentsClient,
    BootstrapBundle,
    ProjectAssignment,
)


class TestAgentModels:
    """Tests for Pydantic models in agents.py."""

    def test_agent_register_request_minimal(self):
        req = AgentRegisterRequest(name="test-agent")
        assert req.name == "test-agent"
        assert req.application is None
        assert req.hostname is None

    def test_agent_register_request_full(self):
        req = AgentRegisterRequest(
            name="test-agent",
            application="claude",
            hostname="dev-machine",
        )
        assert req.application == "claude"
        assert req.hostname == "dev-machine"

    def test_agent_response_minimal(self):
        resp = AgentResponse(
            id="agent-1",
            status="online",
            created_at="2025-01-01T00:00:00Z",
            updated_at="2025-01-01T00:00:00Z",
        )
        assert resp.id == "agent-1"
        assert resp.project_id is None
        assert resp.kind is None

    def test_agent_response_full(self):
        resp = AgentResponse(
            id="agent-1",
            project_id="proj-1",
            name="my-agent",
            application="claude",
            hostname="dev-machine",
            status="online",
            last_heartbeat_at="2025-01-01T00:00:00Z",
            created_at="2025-01-01T00:00:00Z",
            updated_at="2025-01-01T00:00:00Z",
            kind="workspace",
            workspace_path="/workspace",
            capabilities={"tools": ["claude"]},
        )
        assert resp.kind == "workspace"
        assert resp.capabilities == {"tools": ["claude"]}

    def test_project_assignment_defaults(self):
        pa = ProjectAssignment(agent_id="a1", project_id="p1")
        assert pa.local_path is None
        assert pa.is_active is True
        assert pa.preferred_tool is None

    def test_project_assignment_full(self):
        pa = ProjectAssignment(
            agent_id="a1",
            project_id="p1",
            local_path="/code/project",
            default_branch="main",
            repo_full_name="org/repo",
            preferred_tool="claude",
            is_active=False,
        )
        assert pa.local_path == "/code/project"
        assert pa.is_active is False

    def test_bootstrap_bundle_defaults(self):
        bb = BootstrapBundle()
        assert bb.project == {}
        assert bb.repositories == []
        assert bb.agent_configs == {}
        assert bb.settings == {}

    def test_bootstrap_bundle_with_data(self):
        bb = BootstrapBundle(
            project={"name": "my-project"},
            repositories=[{"url": "https://github.com/org/repo"}],
            agent_configs={"system_prompt": "hello"},
        )
        assert bb.project["name"] == "my-project"
        assert len(bb.repositories) == 1


class TestAgentsClient:
    """Tests for AgentsClient initialization and properties."""

    def test_init_with_api_key(self):
        client = AgentsClient(api_key="test-key")
        assert client.api_key == "test-key"

    def test_init_from_env(self):
        with patch.dict(os.environ, {"STEERDEV_API_KEY": "env-key"}):
            client = AgentsClient()
            assert client.api_key == "env-key"

    def test_headers(self):
        client = AgentsClient(api_key="test-key")
        assert client.headers["Authorization"] == "Bearer test-key"
        assert client.headers["Content-Type"] == "application/json"

    def test_custom_timeout(self):
        client = AgentsClient(api_key="key", timeout=60.0)
        assert client.timeout == 60.0

    @pytest.mark.asyncio
    async def test_context_manager(self):
        async with AgentsClient(api_key="key") as client:
            assert client.api_key == "key"
        assert client._client is None

    @pytest.mark.asyncio
    async def test_close_without_client(self):
        client = AgentsClient(api_key="key")
        await client.close()  # Should not raise

    @pytest.mark.asyncio
    async def test_register_success(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(
            201,
            json={
                "id": "agent-new",
                "status": "online",
                "created_at": "2025-01-01T00:00:00Z",
                "updated_at": "2025-01-01T00:00:00Z",
            },
        )
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        req = AgentRegisterRequest(name="new-agent")
        result = await client.register(req)
        assert result is not None
        assert result.id == "agent-new"

    @pytest.mark.asyncio
    async def test_register_failure(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(500, text="Internal Server Error")
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        req = AgentRegisterRequest(name="fail-agent")
        result = await client.register(req)
        assert result is None

    @pytest.mark.asyncio
    async def test_register_request_error(self):
        client = AgentsClient(api_key="key")
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(side_effect=httpx.RequestError("connection failed"))
        client._client = mock_http

        req = AgentRegisterRequest(name="error-agent")
        result = await client.register(req)
        assert result is None

    @pytest.mark.asyncio
    async def test_list_agents_success(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(
            200,
            json={
                "agents": [
                    {
                        "id": "a1",
                        "status": "online",
                        "created_at": "2025-01-01T00:00:00Z",
                        "updated_at": "2025-01-01T00:00:00Z",
                    }
                ]
            },
        )
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.list_agents()
        assert len(result) == 1
        assert result[0].id == "a1"

    @pytest.mark.asyncio
    async def test_list_agents_failure(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(500, text="error")
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.list_agents()
        assert result == []

    @pytest.mark.asyncio
    async def test_get_projects_success(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(
            200,
            json={
                "assignments": [
                    {"agent_id": "a1", "project_id": "p1"},
                    {"agent_id": "a1", "project_id": "p2"},
                ]
            },
        )
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.get_projects("a1")
        assert len(result) == 2
        assert result[0].project_id == "p1"

    @pytest.mark.asyncio
    async def test_get_projects_empty(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(200, json={"assignments": []})
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.get_projects("a1")
        assert result == []

    @pytest.mark.asyncio
    async def test_get_bootstrap_success(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(
            200,
            json={
                "project": {"name": "my-proj"},
                "repositories": [{"url": "https://github.com/org/repo"}],
                "agent_configs": {},
                "settings": {},
            },
        )
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.get_bootstrap("a1", "p1")
        assert result is not None
        assert result.project["name"] == "my-proj"

    @pytest.mark.asyncio
    async def test_get_bootstrap_not_found(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(404, text="Not found")
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.get_bootstrap("a1", "p1")
        assert result is None

    @pytest.mark.asyncio
    async def test_update_assignment_success(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(200)
        mock_http = AsyncMock()
        mock_http.patch = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.update_assignment("a1", "p1", local_path="/code/proj")
        assert result is True

    @pytest.mark.asyncio
    async def test_update_assignment_no_payload(self):
        client = AgentsClient(api_key="key")
        result = await client.update_assignment("a1", "p1")
        assert result is True  # No-op returns True

    @pytest.mark.asyncio
    async def test_update_assignment_failure(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(500, text="error")
        mock_http = AsyncMock()
        mock_http.patch = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.update_assignment("a1", "p1", local_path="/code")
        assert result is False

    @pytest.mark.asyncio
    async def test_register_workspace_success(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(
            201,
            json={
                "id": "ws-agent-1",
                "status": "online",
                "kind": "workspace",
                "created_at": "2025-01-01T00:00:00Z",
                "updated_at": "2025-01-01T00:00:00Z",
            },
        )
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.register_workspace(
            name="ws-agent",
            application="claude",
            workspace_path="/workspace",
            capabilities=["claude", "codex"],
        )
        assert result is not None
        assert result.kind == "workspace"

    @pytest.mark.asyncio
    async def test_register_workspace_failure(self):
        client = AgentsClient(api_key="key")
        mock_response = httpx.Response(500, text="error")
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.register_workspace(name="fail")
        assert result is None
