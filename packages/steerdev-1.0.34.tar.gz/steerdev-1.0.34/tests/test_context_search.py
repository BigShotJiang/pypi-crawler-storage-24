"""Tests for context search API client and display function."""

from __future__ import annotations

import os
from io import StringIO
from unittest.mock import MagicMock, patch

import httpx

from steerdev_agent.api.context import ContextClient, display_search_results

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_response(status_code: int, json_body: dict | None = None, text: str = "") -> MagicMock:
    """Build a fake httpx.Response-like mock."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.text = text or (str(json_body) if json_body else "")
    if json_body is not None:
        resp.json.return_value = json_body
    return resp


SAMPLE_RESULTS = {
    "project_id": "proj-abc",
    "prompt": "pdf processing",
    "results": [
        {
            "file_path": "src/lib/pdf.ts",
            "repo_full_name": "owner/repo",
            "snippet": "function parsePdf(buf) {\n  return pdfParse(buf);\n}",
            "language": "typescript",
            "symbol": "parsePdf",
            "code_type": "function",
            "score": 0.92,
            "line_start": 10,
            "line_end": 12,
        }
    ],
    "total": 1,
}


# ---------------------------------------------------------------------------
# Unit tests: ContextClient.search_context
# ---------------------------------------------------------------------------


class TestSearchContext:
    """Tests for ContextClient.search_context method."""

    def _client(self) -> ContextClient:
        return ContextClient(api_key="test-key")

    def test_successful_search(self):
        """Returns response dict on HTTP 200."""
        client = self._client()
        mock_resp = _make_response(200, SAMPLE_RESULTS)
        with patch.object(client, "post", return_value=mock_resp) as mock_post:
            result = client.search_context(
                prompt="pdf processing",
                project_id="proj-abc",
                top_k=10,
            )

        assert result is not None
        assert result["total"] == 1
        assert result["results"][0]["file_path"] == "src/lib/pdf.ts"
        mock_post.assert_called_once_with(
            "/context",
            json={"project_id": "proj-abc", "prompt": "pdf processing", "top_k": 10},
        )

    def test_uses_default_top_k(self):
        """Default top_k is 15."""
        client = self._client()
        mock_resp = _make_response(200, SAMPLE_RESULTS)
        with patch.object(client, "post", return_value=mock_resp) as mock_post:
            client.search_context(prompt="auth", project_id="proj-abc")

        _, kwargs = mock_post.call_args
        assert kwargs["json"]["top_k"] == 15

    def test_falls_back_to_env_project_id(self):
        """Uses STEERDEV_PROJECT_ID env var when project_id arg is None."""
        client = self._client()
        mock_resp = _make_response(200, SAMPLE_RESULTS)
        with (
            patch.dict(os.environ, {"STEERDEV_PROJECT_ID": "env-proj"}),
            patch.object(client, "post", return_value=mock_resp) as mock_post,
        ):
            result = client.search_context(prompt="auth")

        assert result is not None
        _, kwargs = mock_post.call_args
        assert kwargs["json"]["project_id"] == "env-proj"

    def test_returns_none_when_no_project_id(self):
        """Returns None and prints error if project_id is not available."""
        client = self._client()
        with (
            patch.dict(os.environ, {}, clear=True),
            patch.object(client, "post") as mock_post,
        ):
            result = client.search_context(prompt="auth")

        assert result is None
        mock_post.assert_not_called()

    def test_returns_none_on_400(self):
        """Returns None on 400 Bad Request."""
        client = self._client()
        mock_resp = _make_response(400, {"error": "invalid top_k"})
        with patch.object(client, "post", return_value=mock_resp):
            result = client.search_context(prompt="auth", project_id="proj-abc")

        assert result is None

    def test_returns_none_on_403(self):
        """Returns None on 403 Forbidden."""
        client = self._client()
        mock_resp = _make_response(403, {})
        with patch.object(client, "post", return_value=mock_resp):
            result = client.search_context(prompt="auth", project_id="proj-abc")

        assert result is None

    def test_returns_none_on_500(self):
        """Returns None on 500 Server Error."""
        client = self._client()
        mock_resp = _make_response(500, None, text="Internal Server Error")
        with patch.object(client, "post", return_value=mock_resp):
            result = client.search_context(prompt="auth", project_id="proj-abc")

        assert result is None

    def test_empty_results(self):
        """Returns dict with empty results list on 200."""
        client = self._client()
        payload = {"project_id": "p", "prompt": "noop", "results": [], "total": 0}
        mock_resp = _make_response(200, payload)
        with patch.object(client, "post", return_value=mock_resp):
            result = client.search_context(prompt="noop", project_id="p")

        assert result is not None
        assert result["results"] == []
        assert result["total"] == 0

    def test_top_k_passed_correctly(self):
        """top_k argument is forwarded to the POST body."""
        client = self._client()
        mock_resp = _make_response(200, SAMPLE_RESULTS)
        with patch.object(client, "post", return_value=mock_resp) as mock_post:
            client.search_context(prompt="x", project_id="p", top_k=5)

        _, kwargs = mock_post.call_args
        assert kwargs["json"]["top_k"] == 5


# ---------------------------------------------------------------------------
# Unit tests: display_search_results
# ---------------------------------------------------------------------------


class TestDisplaySearchResults:
    """Tests for display_search_results function."""

    def test_displays_results(self, capsys):
        """Renders table rows for each result (smoke test — no crash)."""
        display_search_results(SAMPLE_RESULTS)
        capsys.readouterr()
        # Output may be empty due to Rich's ANSI detection on non-tty;
        # just assert the function runs without error.

    def test_displays_no_results_message(self, capsys):
        """Prints 'No results found' panel for empty results."""
        empty = {"project_id": "p", "prompt": "noop", "results": [], "total": 0}
        display_search_results(empty)
        # Rich output may be captured or suppressed; test that no exception is raised.

    def test_result_with_no_snippet(self):
        """Results with no snippet do not raise an error."""
        payload = {
            "project_id": "p",
            "prompt": "auth",
            "results": [
                {
                    "file_path": "src/auth.py",
                    "repo_full_name": "org/repo",
                    "snippet": "",
                    "language": "python",
                    "symbol": None,
                    "code_type": "module",
                    "score": 0.75,
                    "line_start": None,
                    "line_end": None,
                }
            ],
            "total": 1,
        }
        display_search_results(payload)  # Should not raise

    def test_symbol_code_type_combinations(self):
        """Symbol/code_type string formatting doesn't crash for all combos."""

        def _item(**kwargs):
            base = {
                "file_path": "f.py",
                "repo_full_name": "o/r",
                "snippet": "",
                "language": "python",
                "score": 0.5,
                "line_start": 1,
                "line_end": 2,
            }
            base.update(kwargs)
            return base

        cases = [
            {"symbol": "foo", "code_type": "function"},
            {"symbol": "Bar", "code_type": ""},
            {"symbol": None, "code_type": "class"},
            {"symbol": None, "code_type": ""},
        ]
        for case in cases:
            payload = {
                "project_id": "p",
                "prompt": "x",
                "results": [_item(**case)],
                "total": 1,
            }
            display_search_results(payload)  # Must not raise

    def test_long_snippet_truncated(self):
        """Snippets longer than 5 lines are truncated with '...'."""
        long_snippet = "\n".join(f"line {i}" for i in range(10))
        payload = {
            "project_id": "p",
            "prompt": "q",
            "results": [
                {
                    "file_path": "f.py",
                    "repo_full_name": "o/r",
                    "snippet": long_snippet,
                    "language": "python",
                    "symbol": "fn",
                    "code_type": "function",
                    "score": 0.8,
                    "line_start": 1,
                    "line_end": 10,
                }
            ],
            "total": 1,
        }
        # Capture rich output
        from rich.console import Console

        buf = StringIO()
        console = Console(file=buf, highlight=False, width=200)

        # Patch module-level console in display_search_results
        with patch("steerdev_agent.api.context.console", console):
            display_search_results(payload)

        output = buf.getvalue()
        assert "..." in output

    def test_multiple_results_rendered(self):
        """Multiple results render without error."""
        results = [
            {
                "file_path": f"src/file{i}.py",
                "repo_full_name": "org/repo",
                "snippet": f"def func{i}(): pass",
                "language": "python",
                "symbol": f"func{i}",
                "code_type": "function",
                "score": round(0.9 - i * 0.05, 2),
                "line_start": i * 10,
                "line_end": i * 10 + 5,
            }
            for i in range(3)
        ]
        payload = {"project_id": "p", "prompt": "functions", "results": results, "total": 3}
        display_search_results(payload)  # Must not raise

    def test_singular_result_count(self):
        """Single result uses singular 'result' in header."""
        from rich.console import Console

        buf = StringIO()
        console = Console(file=buf, highlight=False, width=200)

        payload = {
            "project_id": "p",
            "prompt": "q",
            "results": [
                {
                    "file_path": "f.py",
                    "repo_full_name": "o/r",
                    "snippet": "",
                    "language": "python",
                    "symbol": "",
                    "code_type": "",
                    "score": 0.9,
                    "line_start": 1,
                    "line_end": 2,
                }
            ],
            "total": 1,
        }
        with patch("steerdev_agent.api.context.console", console):
            display_search_results(payload)

        output = buf.getvalue()
        assert "1 result)" in output

    def test_plural_result_count(self):
        """Multiple results uses plural 'results' in header."""
        from rich.console import Console

        buf = StringIO()
        console = Console(file=buf, highlight=False, width=200)

        results = [
            {
                "file_path": f"f{i}.py",
                "repo_full_name": "o/r",
                "snippet": "",
                "language": "py",
                "symbol": "",
                "code_type": "",
                "score": 0.5,
                "line_start": 1,
                "line_end": 1,
            }
            for i in range(3)
        ]
        payload = {"project_id": "p", "prompt": "q", "results": results, "total": 3}
        with patch("steerdev_agent.api.context.console", console):
            display_search_results(payload)

        output = buf.getvalue()
        assert "3 results)" in output


# ---------------------------------------------------------------------------
# Integration tests: CLI context search command
# ---------------------------------------------------------------------------


class TestContextSearchCLI:
    """Integration tests for the `context search` CLI command."""

    def _invoke(self, args: list[str]) -> tuple[int, str]:
        """Invoke the CLI app and return (exit_code, output)."""
        from typer.testing import CliRunner

        from steerdev_agent.cli import app

        runner = CliRunner()
        result = runner.invoke(app, args)
        return result.exit_code, result.output

    def test_help_available(self):
        """Help text renders without error."""
        exit_code, output = self._invoke(["context", "search", "--help"])
        assert exit_code == 0
        assert "prompt" in output.lower() or "search" in output.lower()

    def test_exits_1_when_api_key_missing(self):
        """Exits with code 1 when STEERDEV_API_KEY is not set."""
        with patch.dict(os.environ, {}, clear=True):
            exit_code, _ = self._invoke(
                ["context", "search", "--prompt", "pdf", "--project-id", "proj-abc"]
            )
        assert exit_code == 1

    def test_exits_1_when_prompt_is_empty(self):
        """Exits with code 1 when prompt is whitespace-only."""
        with (
            patch.dict(os.environ, {"STEERDEV_API_KEY": "key", "STEERDEV_PROJECT_ID": "p"}),
            patch(
                "steerdev_agent.api.context.ContextClient.search_context",
                return_value=None,
            ),
        ):
            exit_code, _ = self._invoke(["context", "search", "--prompt", "   "])
        assert exit_code == 1

    def test_successful_search_exits_0(self):
        """Exits 0 on successful search."""
        with (
            patch.dict(os.environ, {"STEERDEV_API_KEY": "key", "STEERDEV_PROJECT_ID": "proj-abc"}),
            patch(
                "steerdev_agent.api.context.ContextClient.search_context",
                return_value=SAMPLE_RESULTS,
            ),
            patch("steerdev_agent.api.context.display_search_results"),
        ):
            exit_code, _ = self._invoke(["context", "search", "--prompt", "pdf processing"])
        assert exit_code == 0

    def test_exits_1_when_search_returns_none(self):
        """Exits 1 when search_context returns None (API error)."""
        with (
            patch.dict(os.environ, {"STEERDEV_API_KEY": "key", "STEERDEV_PROJECT_ID": "proj-abc"}),
            patch(
                "steerdev_agent.api.context.ContextClient.search_context",
                return_value=None,
            ),
        ):
            exit_code, _ = self._invoke(["context", "search", "--prompt", "pdf"])
        assert exit_code == 1

    def test_project_id_flag_forwarded(self):
        """--project-id is forwarded to search_context."""
        with (
            patch.dict(os.environ, {"STEERDEV_API_KEY": "key"}),
            patch(
                "steerdev_agent.api.context.ContextClient.search_context",
                return_value=SAMPLE_RESULTS,
            ) as mock_search,
            patch("steerdev_agent.api.context.display_search_results"),
        ):
            self._invoke(
                [
                    "context",
                    "search",
                    "--prompt",
                    "pdf",
                    "--project-id",
                    "custom-proj",
                ]
            )

        mock_search.assert_called_once()
        _, kwargs = mock_search.call_args
        assert kwargs.get("project_id") == "custom-proj"

    def test_top_k_flag_forwarded(self):
        """--top-k is forwarded to search_context."""
        with (
            patch.dict(os.environ, {"STEERDEV_API_KEY": "key", "STEERDEV_PROJECT_ID": "p"}),
            patch(
                "steerdev_agent.api.context.ContextClient.search_context",
                return_value=SAMPLE_RESULTS,
            ) as mock_search,
            patch("steerdev_agent.api.context.display_search_results"),
        ):
            self._invoke(["context", "search", "--prompt", "auth", "--top-k", "5"])

        _, kwargs = mock_search.call_args
        assert kwargs.get("top_k") == 5

    def test_short_flags_work(self):
        """-p and -k short flags work."""
        with (
            patch.dict(os.environ, {"STEERDEV_API_KEY": "key", "STEERDEV_PROJECT_ID": "p"}),
            patch(
                "steerdev_agent.api.context.ContextClient.search_context",
                return_value=SAMPLE_RESULTS,
            ) as mock_search,
            patch("steerdev_agent.api.context.display_search_results"),
        ):
            exit_code, _ = self._invoke(["context", "search", "-p", "pdf processing", "-k", "3"])

        assert exit_code == 0
        _, kwargs = mock_search.call_args
        assert kwargs.get("top_k") == 3

    def test_timeout_error_exits_1(self):
        """Timeout error exits with code 1."""
        with (
            patch.dict(os.environ, {"STEERDEV_API_KEY": "key", "STEERDEV_PROJECT_ID": "p"}),
            patch(
                "steerdev_agent.api.context.ContextClient.search_context",
                side_effect=httpx.TimeoutException("timeout"),
            ),
        ):
            exit_code, _ = self._invoke(["context", "search", "--prompt", "pdf"])
        assert exit_code == 1

    def test_http_error_exits_1(self):
        """HTTPError exits with code 1."""
        with (
            patch.dict(os.environ, {"STEERDEV_API_KEY": "key", "STEERDEV_PROJECT_ID": "p"}),
            patch(
                "steerdev_agent.api.context.ContextClient.search_context",
                side_effect=httpx.HTTPError("connection refused"),
            ),
        ):
            exit_code, _ = self._invoke(["context", "search", "--prompt", "pdf"])
        assert exit_code == 1
