"""Tests for workspace module (tool_detection, ProjectManager)."""

import shutil
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from steerdev_agent.workspace.tool_detection import detect_installed_tools


class TestDetectInstalledTools:
    """Tests for detect_installed_tools."""

    def test_no_tools_installed(self):
        """Returns empty list when no tools are found."""
        with patch.object(shutil, "which", return_value=None):
            result = detect_installed_tools()
            assert result == []

    def test_all_tools_installed(self):
        """Returns all tool names when all binaries exist."""
        with patch.object(shutil, "which", return_value="/usr/local/bin/fake"):
            result = detect_installed_tools()
            assert "claude" in result
            assert "codex" in result
            assert "gemini_cli" in result
            assert "aider" in result

    def test_only_claude_installed(self):
        """Returns only claude when only claude binary exists."""

        def selective_which(cmd: str) -> str | None:
            return "/usr/local/bin/claude" if cmd == "claude" else None

        with patch.object(shutil, "which", side_effect=selective_which):
            result = detect_installed_tools()
            assert result == ["claude"]

    def test_multiple_tools_installed(self):
        """Returns subset when only some tools exist."""
        installed = {"claude", "aider"}

        def selective_which(cmd: str) -> str | None:
            return f"/usr/local/bin/{cmd}" if cmd in installed else None

        with patch.object(shutil, "which", side_effect=selective_which):
            result = detect_installed_tools()
            assert "claude" in result
            assert "aider" in result
            assert "codex" not in result
            assert "gemini_cli" not in result

    def test_gemini_uses_correct_binary_name(self):
        """gemini_cli tool maps to 'gemini' binary."""

        def selective_which(cmd: str) -> str | None:
            return "/usr/local/bin/gemini" if cmd == "gemini" else None

        with patch.object(shutil, "which", side_effect=selective_which):
            result = detect_installed_tools()
            assert "gemini_cli" in result


class TestProjectManager:
    """Tests for ProjectManager path resolution and caching."""

    def _make_manager(self, workspace_dir: Path):
        from steerdev_agent.workspace.project_manager import ProjectManager

        mock_client = AsyncMock()
        return ProjectManager(
            workspace_dir=workspace_dir,
            api_client=mock_client,
            agent_id="agent-123",
            api_key="test-key",
        )

    def test_get_project_path_empty_cache(self, tmp_path: Path):
        """get_project_path returns None for unknown project."""
        pm = self._make_manager(tmp_path)
        assert pm.get_project_path("unknown-id") is None

    def test_get_project_path_from_cache(self, tmp_path: Path):
        """get_project_path returns cached path."""
        pm = self._make_manager(tmp_path)
        pm._path_cache["proj-1"] = tmp_path / "my-project"
        assert pm.get_project_path("proj-1") == tmp_path / "my-project"

    def test_resolve_path_from_cache(self, tmp_path: Path):
        """_resolve_path prefers cache."""
        from steerdev_agent.api.agents import ProjectAssignment

        pm = self._make_manager(tmp_path)
        cached_path = tmp_path / "cached"
        cached_path.mkdir()
        pm._path_cache["proj-1"] = cached_path

        assignment = ProjectAssignment(
            agent_id="agent-123",
            project_id="proj-1",
            local_path=str(tmp_path / "other"),
        )
        assert pm._resolve_path(assignment) == cached_path

    def test_resolve_path_from_assignment_local_path(self, tmp_path: Path):
        """_resolve_path uses assignment.local_path if it exists on disk."""
        from steerdev_agent.api.agents import ProjectAssignment

        pm = self._make_manager(tmp_path)
        local = tmp_path / "assigned-dir"
        local.mkdir()

        assignment = ProjectAssignment(
            agent_id="agent-123",
            project_id="proj-2",
            local_path=str(local),
        )
        assert pm._resolve_path(assignment) == local

    def test_resolve_path_assignment_missing_dir(self, tmp_path: Path):
        """_resolve_path returns None when assignment.local_path dir doesn't exist."""
        from steerdev_agent.api.agents import ProjectAssignment

        pm = self._make_manager(tmp_path)
        assignment = ProjectAssignment(
            agent_id="agent-123",
            project_id="proj-3",
            local_path="/nonexistent/path",
        )
        assert pm._resolve_path(assignment) is None

    def test_resolve_path_scans_workspace_env(self, tmp_path: Path):
        """_resolve_path scans workspace for .env containing project_id."""
        from steerdev_agent.api.agents import ProjectAssignment

        pm = self._make_manager(tmp_path)
        # Create a project dir with .env containing the project_id
        proj_dir = tmp_path / "my-proj"
        proj_dir.mkdir()
        (proj_dir / ".env").write_text("STEERDEV_PROJECT_ID=proj-scan-1\n")

        assignment = ProjectAssignment(
            agent_id="agent-123",
            project_id="proj-scan-1",
        )
        assert pm._resolve_path(assignment) == proj_dir

    def test_resolve_path_no_match_in_workspace(self, tmp_path: Path):
        """_resolve_path returns None when workspace has no matching .env."""
        from steerdev_agent.api.agents import ProjectAssignment

        pm = self._make_manager(tmp_path)
        # Create dir with .env for a different project
        other_dir = tmp_path / "other"
        other_dir.mkdir()
        (other_dir / ".env").write_text("STEERDEV_PROJECT_ID=different-id\n")

        assignment = ProjectAssignment(
            agent_id="agent-123",
            project_id="proj-not-found",
        )
        assert pm._resolve_path(assignment) is None

    @pytest.mark.asyncio
    async def test_sync_projects_caches_existing(self, tmp_path: Path):
        """sync_projects caches paths for already-existing projects."""
        from steerdev_agent.api.agents import ProjectAssignment

        pm = self._make_manager(tmp_path)
        proj_dir = tmp_path / "existing"
        proj_dir.mkdir()
        (proj_dir / ".env").write_text("STEERDEV_PROJECT_ID=proj-exist\n")

        assignments = [
            ProjectAssignment(
                agent_id="agent-123",
                project_id="proj-exist",
                local_path=str(proj_dir),
            )
        ]
        await pm.sync_projects(assignments)
        assert pm.get_project_path("proj-exist") == proj_dir

    @pytest.mark.asyncio
    async def test_sync_projects_calls_setup_for_missing(self, tmp_path: Path):
        """sync_projects calls setup_project when project dir is missing."""
        from steerdev_agent.api.agents import ProjectAssignment

        pm = self._make_manager(tmp_path)
        assignment = ProjectAssignment(
            agent_id="agent-123",
            project_id="proj-new",
        )

        # Mock setup_project to return a path
        new_dir = tmp_path / "new-proj"
        new_dir.mkdir()
        pm.setup_project = AsyncMock(return_value=new_dir)

        await pm.sync_projects([assignment])
        pm.setup_project.assert_awaited_once_with(assignment)
        assert pm.get_project_path("proj-new") == new_dir

    @pytest.mark.asyncio
    async def test_sync_projects_handles_setup_failure(self, tmp_path: Path):
        """sync_projects logs error but continues when setup_project fails."""
        from steerdev_agent.api.agents import ProjectAssignment

        pm = self._make_manager(tmp_path)
        assignment = ProjectAssignment(
            agent_id="agent-123",
            project_id="proj-fail",
        )
        pm.setup_project = AsyncMock(side_effect=RuntimeError("clone failed"))

        # Should not raise
        await pm.sync_projects([assignment])
        assert pm.get_project_path("proj-fail") is None
