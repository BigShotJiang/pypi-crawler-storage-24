"""Tests for workflow phase context summaries."""

from pathlib import Path

from steerdev_agent.workflow.context import get_summary_path, list_existing_summaries


class TestGetSummaryPath:
    """Tests for get_summary_path."""

    def test_basic(self, tmp_path: Path):
        """Returns correctly formatted path."""
        result = get_summary_path(tmp_path, 1, "Plan")
        assert result == tmp_path / "01_plan.md"

    def test_multi_word_name(self, tmp_path: Path):
        """Spaces in phase name become underscores."""
        result = get_summary_path(tmp_path, 3, "Code Review")
        assert result == tmp_path / "03_code_review.md"

    def test_zero_padded_order(self, tmp_path: Path):
        """Order numbers are zero-padded to 2 digits."""
        result = get_summary_path(tmp_path, 9, "Test")
        assert result == tmp_path / "09_test.md"
        result2 = get_summary_path(tmp_path, 12, "Deploy")
        assert result2 == tmp_path / "12_deploy.md"

    def test_uppercase_lowered(self, tmp_path: Path):
        """Phase names are lowercased."""
        result = get_summary_path(tmp_path, 2, "Implementation")
        assert result == tmp_path / "02_implementation.md"


class TestListExistingSummaries:
    """Tests for list_existing_summaries."""

    def test_empty_directory(self, tmp_path: Path):
        """No .md files returns empty list."""
        result = list_existing_summaries(tmp_path)
        assert result == []

    def test_nonexistent_directory(self, tmp_path: Path):
        """Nonexistent path returns empty list."""
        result = list_existing_summaries(tmp_path / "no-such-dir")
        assert result == []

    def test_returns_sorted_md_files(self, tmp_path: Path):
        """Returns .md files in sorted order."""
        (tmp_path / "02_implement.md").write_text("impl notes")
        (tmp_path / "01_plan.md").write_text("plan notes")
        (tmp_path / "03_test.md").write_text("test notes")

        result = list_existing_summaries(tmp_path)
        assert len(result) == 3
        assert result[0].name == "01_plan.md"
        assert result[1].name == "02_implement.md"
        assert result[2].name == "03_test.md"

    def test_ignores_non_md_files(self, tmp_path: Path):
        """Only .md files are returned."""
        (tmp_path / "01_plan.md").write_text("plan")
        (tmp_path / "phase-1.json").write_text("{}")
        (tmp_path / "notes.txt").write_text("notes")

        result = list_existing_summaries(tmp_path)
        assert len(result) == 1
        assert result[0].name == "01_plan.md"
