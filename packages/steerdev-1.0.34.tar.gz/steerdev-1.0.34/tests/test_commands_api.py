"""Tests for commands API client."""

import os
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from steerdev_agent.api.commands import (
    CommandListResponse,
    CommandResponse,
    CommandsClient,
    display_command,
    display_command_list,
)


def _make_command(**overrides) -> dict:
    """Create a minimal command JSON dict."""
    defaults = {
        "id": "cmd-1",
        "agent_id": "agent-1",
        "project_id": "proj-1",
        "command_type": "task",
        "status": "pending",
        "created_at": "2025-01-01T00:00:00Z",
        "updated_at": "2025-01-01T00:00:00Z",
    }
    defaults.update(overrides)
    return defaults


class TestCommandModels:
    """Tests for Pydantic models in commands.py."""

    def test_command_response_minimal(self):
        cmd = CommandResponse(**_make_command())
        assert cmd.id == "cmd-1"
        assert cmd.command_type == "task"
        assert cmd.task_id is None
        assert cmd.prompt is None
        assert cmd.priority == 0

    def test_command_response_full(self):
        cmd = CommandResponse(
            **_make_command(
                task_id="task-1",
                prompt="do something",
                priority=5,
                session_id="sess-1",
                result="done",
                error=None,
                working_directory="/code",
                metadata={"key": "value"},
            )
        )
        assert cmd.task_id == "task-1"
        assert cmd.priority == 5
        assert cmd.metadata == {"key": "value"}

    def test_command_list_response(self):
        resp = CommandListResponse(
            commands=[CommandResponse(**_make_command())],
            total=1,
            limit=50,
            offset=0,
        )
        assert len(resp.commands) == 1
        assert resp.total == 1


class TestCommandsClient:
    """Tests for CommandsClient initialization and properties."""

    def test_init_with_args(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        assert client.agent_id == "a1"
        assert client.api_key == "key"

    def test_init_from_env(self):
        with patch.dict(
            os.environ,
            {"STEERDEV_AGENT_ID": "env-agent", "STEERDEV_API_KEY": "env-key"},
        ):
            client = CommandsClient()
            assert client.agent_id == "env-agent"
            assert client.api_key == "env-key"

    def test_base_url(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        assert "agents/a1/commands" in client._base_url

    def test_headers(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        assert client.headers["Authorization"] == "Bearer key"

    @pytest.mark.asyncio
    async def test_context_manager(self):
        async with CommandsClient(agent_id="a1", api_key="key") as client:
            assert client.agent_id == "a1"
        assert client._client is None

    @pytest.mark.asyncio
    async def test_poll_next_success(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(200, json=_make_command())
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.poll_next()
        assert result is not None
        assert result.id == "cmd-1"

    @pytest.mark.asyncio
    async def test_poll_next_empty_queue(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(204)
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.poll_next()
        assert result is None

    @pytest.mark.asyncio
    async def test_poll_next_error(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(500, text="error")
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.poll_next()
        assert result is None

    @pytest.mark.asyncio
    async def test_poll_next_request_error(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(side_effect=httpx.RequestError("conn failed"))
        client._client = mock_http

        result = await client.poll_next()
        assert result is None

    @pytest.mark.asyncio
    async def test_update_command_success(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(200, json=_make_command(status="executing"))
        mock_http = AsyncMock()
        mock_http.patch = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.update_command("cmd-1", status="executing")
        assert result is not None
        assert result.status == "executing"

    @pytest.mark.asyncio
    async def test_update_command_no_fields(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        result = await client.update_command("cmd-1")
        assert result is None  # No fields to update

    @pytest.mark.asyncio
    async def test_update_command_failure(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(500, text="error")
        mock_http = AsyncMock()
        mock_http.patch = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.update_command("cmd-1", status="completed")
        assert result is None

    @pytest.mark.asyncio
    async def test_mark_executing(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(200, json=_make_command(status="executing"))
        mock_http = AsyncMock()
        mock_http.patch = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.mark_executing("cmd-1", "sess-1")
        assert result is not None
        # Verify the PATCH payload included session_id and started_at
        call_kwargs = mock_http.patch.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert payload["status"] == "executing"
        assert payload["session_id"] == "sess-1"
        assert "started_at" in payload

    @pytest.mark.asyncio
    async def test_mark_completed(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(200, json=_make_command(status="completed"))
        mock_http = AsyncMock()
        mock_http.patch = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.mark_completed("cmd-1", result="All done")
        assert result is not None
        call_kwargs = mock_http.patch.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert payload["status"] == "completed"
        assert payload["result"] == "All done"
        assert "completed_at" in payload

    @pytest.mark.asyncio
    async def test_mark_failed(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(200, json=_make_command(status="failed"))
        mock_http = AsyncMock()
        mock_http.patch = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.mark_failed("cmd-1", error="Something broke")
        assert result is not None
        call_kwargs = mock_http.patch.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert payload["status"] == "failed"
        assert payload["error"] == "Something broke"

    @pytest.mark.asyncio
    async def test_mark_pending(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(200, json=_make_command(status="pending"))
        mock_http = AsyncMock()
        mock_http.patch = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.mark_pending("cmd-1")
        assert result is not None
        call_kwargs = mock_http.patch.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert payload["status"] == "pending"
        assert payload["claimed_at"] is None
        assert payload["started_at"] is None
        assert payload["session_id"] is None

    @pytest.mark.asyncio
    async def test_get_command_success(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(200, json=_make_command())
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.get_command("cmd-1")
        assert result is not None
        assert result.id == "cmd-1"

    @pytest.mark.asyncio
    async def test_get_command_not_found(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(404, text="Not found")
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.get_command("cmd-missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_list_commands_success(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(
            200,
            json={
                "commands": [_make_command()],
                "total": 1,
                "limit": 50,
                "offset": 0,
            },
        )
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.list_commands()
        assert result is not None
        assert result.total == 1
        assert len(result.commands) == 1

    @pytest.mark.asyncio
    async def test_list_commands_with_status_filter(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(
            200,
            json={
                "commands": [],
                "total": 0,
                "limit": 50,
                "offset": 0,
            },
        )
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        await client.list_commands(status="pending")
        call_kwargs = mock_http.get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["status"] == "pending"

    @pytest.mark.asyncio
    async def test_list_commands_failure(self):
        client = CommandsClient(agent_id="a1", api_key="key")
        mock_response = httpx.Response(500, text="error")
        mock_http = AsyncMock()
        mock_http.get = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.list_commands()
        assert result is None


class TestDisplayFunctions:
    """Tests for display helper functions (smoke tests)."""

    def test_display_command_basic(self):
        """display_command should not raise for a minimal command."""
        cmd = CommandResponse(**_make_command())
        display_command(cmd)  # Should not raise

    def test_display_command_full(self):
        """display_command handles all optional fields."""
        cmd = CommandResponse(
            **_make_command(
                task_id="task-1",
                prompt="A" * 300,  # Long prompt gets truncated
                control_action="stop",
                session_id="sess-1",
                result="done",
                error="oops",
            )
        )
        display_command(cmd, title="Test Command")

    def test_display_command_list_empty(self):
        """display_command_list handles empty list."""
        display_command_list([])

    def test_display_command_list_with_commands(self):
        """display_command_list renders a table."""
        commands = [
            CommandResponse(**_make_command(id="cmd-1")),
            CommandResponse(**_make_command(id="cmd-2")),
        ]
        display_command_list(commands)

    def test_display_command_list_truncated_ids(self):
        """display_command_list with full_ids=False truncates long IDs."""
        commands = [
            CommandResponse(**_make_command(id="a" * 36)),
        ]
        display_command_list(commands, full_ids=False)
