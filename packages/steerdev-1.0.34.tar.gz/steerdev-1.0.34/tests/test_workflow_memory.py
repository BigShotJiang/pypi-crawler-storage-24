"""Tests for workflow phase memory management."""

import json
from pathlib import Path

from steerdev_agent.workflow.memory import PhaseMemory, WorkflowMemoryManager


class TestPhaseMemory:
    """Tests for PhaseMemory model."""

    def test_create_minimal(self):
        """Create with required fields only."""
        memory = PhaseMemory(
            phase_id="p1",
            phase_name="Plan",
            phase_type="plan",
        )
        assert memory.phase_id == "p1"
        assert memory.input_context == {}
        assert memory.output_context == {}
        assert memory.result_summary is None
        assert memory.summary_file is None

    def test_create_full(self):
        """Create with all fields."""
        memory = PhaseMemory(
            phase_id="p1",
            phase_name="Implement",
            phase_type="implement",
            input_context={"spec": "build login"},
            output_context={"files": ["auth.ts"]},
            result_summary="Added auth module",
        )
        assert memory.output_context["files"] == ["auth.ts"]
        assert memory.result_summary == "Added auth module"

    def test_summary_file_field(self):
        """summary_file stores the path to the phase summary."""
        memory = PhaseMemory(
            phase_id="p1",
            phase_name="Plan",
            phase_type="plan",
            summary_file="/tmp/run/01_plan.md",
        )
        assert memory.summary_file == "/tmp/run/01_plan.md"

    def test_serialization_roundtrip(self):
        """JSON serialization and deserialization should preserve data."""
        original = PhaseMemory(
            phase_id="p1",
            phase_name="Test",
            phase_type="test",
            input_context={"key": "value"},
            output_context={"result": 42},
            result_summary="All tests pass",
            summary_file="/tmp/run/01_test.md",
        )
        json_str = original.model_dump_json()
        restored = PhaseMemory(**json.loads(json_str))
        assert restored.phase_id == original.phase_id
        assert restored.output_context == original.output_context
        assert restored.result_summary == original.result_summary
        assert restored.summary_file == original.summary_file


class TestWorkflowMemoryManager:
    """Tests for WorkflowMemoryManager."""

    def _make_manager(self, tmp_path: Path) -> WorkflowMemoryManager:
        return WorkflowMemoryManager(tmp_path)

    def test_save_and_load_phase_memory(self, tmp_path: Path):
        """Save and load a single phase memory."""
        manager = self._make_manager(tmp_path)
        memory = PhaseMemory(
            phase_id="phase-1",
            phase_name="Plan",
            phase_type="plan",
            output_context={"plan": "Build REST API"},
        )

        path = manager.save_phase_memory("wf-1", "run-1", memory)
        assert path.exists()

        loaded = manager.load_phase_memory("wf-1", "run-1", "phase-1")
        assert loaded is not None
        assert loaded.phase_id == "phase-1"
        assert loaded.output_context == {"plan": "Build REST API"}

    def test_load_nonexistent_returns_none(self, tmp_path: Path):
        """Loading a phase that doesn't exist should return None."""
        manager = self._make_manager(tmp_path)
        result = manager.load_phase_memory("wf-1", "run-1", "no-such-phase")
        assert result is None

    def test_load_corrupted_json_returns_none(self, tmp_path: Path):
        """Loading corrupted JSON should return None gracefully."""
        manager = self._make_manager(tmp_path)
        # Create the directory structure and write invalid JSON
        run_path = tmp_path / ".steerdev" / "phases" / "wf-1" / "run-1"
        run_path.mkdir(parents=True)
        (run_path / "bad-phase.json").write_text("not valid json {{{")

        result = manager.load_phase_memory("wf-1", "run-1", "bad-phase")
        assert result is None

    def test_load_all_phase_memories(self, tmp_path: Path):
        """Load all phases for a workflow run."""
        manager = self._make_manager(tmp_path)

        for i, name in enumerate(["Plan", "Implement", "Test"]):
            memory = PhaseMemory(
                phase_id=f"phase-{i}",
                phase_name=name,
                phase_type=name.lower(),
                output_context={f"step_{i}": f"result_{i}"},
            )
            manager.save_phase_memory("wf-1", "run-1", memory)

        memories = manager.load_all_phase_memories("wf-1", "run-1")
        assert len(memories) == 3

    def test_load_all_empty_run(self, tmp_path: Path):
        """Loading all memories for a nonexistent run returns empty list."""
        manager = self._make_manager(tmp_path)
        result = manager.load_all_phase_memories("wf-1", "no-run")
        assert result == []

    def test_build_accumulated_context(self, tmp_path: Path):
        """Accumulated context should merge all phase outputs."""
        manager = self._make_manager(tmp_path)

        phase1 = PhaseMemory(
            phase_id="p1",
            phase_name="Plan",
            phase_type="plan",
            output_context={"plan": "REST API", "tech": "FastAPI"},
        )
        phase2 = PhaseMemory(
            phase_id="p2",
            phase_name="Implement",
            phase_type="implement",
            output_context={"files": ["main.py"], "tech": "Flask"},
        )

        manager.save_phase_memory("wf-1", "run-1", phase1)
        manager.save_phase_memory("wf-1", "run-1", phase2)

        context = manager.build_accumulated_context("wf-1", "run-1")
        assert context["plan"] == "REST API"
        assert context["files"] == ["main.py"]
        # Later phase should override earlier for duplicate keys
        assert context["tech"] == "Flask"

    def test_build_accumulated_context_empty(self, tmp_path: Path):
        """Empty run should return empty accumulated context."""
        manager = self._make_manager(tmp_path)
        context = manager.build_accumulated_context("wf-1", "no-run")
        assert context == {}

    def test_cleanup_run(self, tmp_path: Path):
        """Cleanup should remove the run directory."""
        manager = self._make_manager(tmp_path)
        memory = PhaseMemory(
            phase_id="p1",
            phase_name="Plan",
            phase_type="plan",
        )
        manager.save_phase_memory("wf-1", "run-1", memory)
        run_path = tmp_path / ".steerdev" / "phases" / "wf-1" / "run-1"
        assert run_path.exists()

        result = manager.cleanup_run("wf-1", "run-1")
        assert result is True
        assert not run_path.exists()

    def test_cleanup_nonexistent_run(self, tmp_path: Path):
        """Cleanup of nonexistent run should succeed."""
        manager = self._make_manager(tmp_path)
        result = manager.cleanup_run("wf-1", "no-run")
        assert result is True

    def test_path_structure(self, tmp_path: Path):
        """Verify the directory structure is correct."""
        manager = self._make_manager(tmp_path)
        memory = PhaseMemory(
            phase_id="phase-abc",
            phase_name="Test",
            phase_type="test",
        )
        path = manager.save_phase_memory("workflow-123", "run-456", memory)
        expected = tmp_path / ".steerdev" / "phases" / "workflow-123" / "run-456" / "phase-abc.json"
        assert path == expected
