"""Extended tests for agent_loop module (AgentLoop, WorkspaceAgentLoop, resolve logic)."""

import asyncio
from pathlib import Path
from typing import cast
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from steerdev_agent.agent_loop import (
    AgentLoop,
    CommandExecutor,
    WorkspaceAgentLoop,
)
from steerdev_agent.api.agents import ProjectAssignment
from steerdev_agent.api.commands import CommandResponse
from steerdev_agent.config.models import AgentLoopConfig, ExecutorConfig, WorkspaceConfig


def _make_command(**overrides) -> CommandResponse:
    defaults = {
        "id": "cmd-1",
        "agent_id": "agent-1",
        "project_id": "proj-1",
        "command_type": "task",
        "status": "claimed",
        "created_at": "2025-01-01T00:00:00Z",
        "updated_at": "2025-01-01T00:00:00Z",
    }
    defaults.update(overrides)
    return CommandResponse(**defaults)


# ---------------------------------------------------------------------------
# AgentLoop init & properties
# ---------------------------------------------------------------------------


class TestAgentLoopInit:
    """Tests for AgentLoop initialization."""

    def test_defaults(self):
        loop = AgentLoop(
            project_id="proj-1",
            agent_name="test-agent",
            api_key="key",
        )
        assert loop.project_id == "proj-1"
        assert loop.agent_name == "test-agent"
        assert loop.agent_type == "claude"
        assert loop.model is None
        assert loop.max_turns is None
        assert loop._enable_worktrees is False
        assert loop._workflow_id is None
        assert loop._commands_executed == 0
        assert loop._commands_succeeded == 0
        assert loop._commands_failed == 0
        assert loop._is_busy is False
        assert loop._agent_id is None

    def test_custom_config(self):
        config = AgentLoopConfig(poll_interval_seconds=2.0, gap_seconds=1.0)
        executor_config = ExecutorConfig(type="codex")
        loop = AgentLoop(
            project_id="proj-1",
            agent_name="test",
            api_key="key",
            agent_type="codex",
            model="gpt-4",
            max_turns=5,
            agent_loop_config=config,
            executor_config=executor_config,
            workflow_id="wf-1",
            enable_worktrees=True,
        )
        assert loop.agent_type == "codex"
        assert loop.model == "gpt-4"
        assert loop.max_turns == 5
        assert loop._agent_loop_config.gap_seconds == 1.0
        assert loop._executor_config.type == "codex"
        assert loop._workflow_id == "wf-1"
        assert loop._enable_worktrees is True

    def test_working_directory_defaults_to_cwd(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        assert loop.working_directory == Path.cwd()

    def test_working_directory_custom(self):
        loop = AgentLoop(
            project_id="p",
            agent_name="a",
            api_key="k",
            working_directory="/tmp/test",
        )
        assert loop.working_directory == Path("/tmp/test")


# ---------------------------------------------------------------------------
# AgentLoop._handle_control_command
# ---------------------------------------------------------------------------


class TestAgentLoopControlCommand:
    """Tests for AgentLoop._handle_control_command."""

    @pytest.mark.asyncio
    async def test_shutdown_command_sets_event(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()

        cmd = _make_command(command_type="control", control_action="shutdown")
        result = await loop._handle_control_command(cmd)

        assert result is True
        assert loop._shutdown_event.is_set()
        loop._commands_client.mark_completed.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_unknown_control_action(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()

        cmd = _make_command(command_type="control", control_action="restart")
        result = await loop._handle_control_command(cmd)

        assert result is True
        loop._commands_client.mark_failed.assert_awaited_once()


# ---------------------------------------------------------------------------
# AgentLoop._poll_once
# ---------------------------------------------------------------------------


class TestAgentLoopPollOnce:
    """Tests for AgentLoop._poll_once."""

    @pytest.mark.asyncio
    async def test_no_command_returns_false(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()
        loop._commands_client.poll_next = AsyncMock(return_value=None)

        result = await loop._poll_once()
        assert result is False

    @pytest.mark.asyncio
    async def test_control_command_delegates(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()
        cmd = _make_command(command_type="control", control_action="shutdown")
        loop._commands_client.poll_next = AsyncMock(return_value=cmd)

        result = await loop._poll_once()
        assert result is True
        assert loop._shutdown_event.is_set()

    @pytest.mark.asyncio
    async def test_task_command_executes(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()
        cmd = _make_command(command_type="task", task_id="t-1")
        loop._commands_client.poll_next = AsyncMock(return_value=cmd)

        with patch.object(loop, "_execute_command", new_callable=AsyncMock) as mock_exec:
            result = await loop._poll_once()

        assert result is True
        mock_exec.assert_awaited_once_with(cmd, "p", loop.working_directory)


# ---------------------------------------------------------------------------
# AgentLoop._recover_stale_commands
# ---------------------------------------------------------------------------


class TestAgentLoopRecoverStale:
    """Tests for AgentLoop._recover_stale_commands."""

    @pytest.mark.asyncio
    async def test_no_client_returns_early(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        loop._commands_client = None
        await loop._recover_stale_commands()  # Should not raise

    @pytest.mark.asyncio
    async def test_resets_stale_commands(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()

        mock_cmd = MagicMock()
        mock_cmd.id = "cmd-stale"
        mock_cmd.status = "claimed"
        mock_result = MagicMock()
        mock_result.commands = [mock_cmd]

        loop._commands_client.list_commands = AsyncMock(
            side_effect=[mock_result, None]  # claimed has stale, executing has none
        )

        await loop._recover_stale_commands()
        loop._commands_client.mark_pending.assert_awaited_once_with("cmd-stale")


# ---------------------------------------------------------------------------
# AgentLoop._shutdown
# ---------------------------------------------------------------------------


class TestAgentLoopShutdown:
    """Tests for AgentLoop._shutdown."""

    @pytest.mark.asyncio
    async def test_shutdown_closes_clients(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()
        loop._sessions_client = AsyncMock()

        with patch.object(loop, "_send_heartbeat", new_callable=AsyncMock):
            await loop._shutdown()

        loop._commands_client.close.assert_awaited_once()
        loop._sessions_client.close.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_shutdown_cancels_heartbeat_task(self):
        loop = AgentLoop(project_id="p", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()
        loop._sessions_client = AsyncMock()

        # Simulate a running heartbeat task
        async def fake_heartbeat():
            await asyncio.sleep(100)

        loop._heartbeat_task = asyncio.create_task(fake_heartbeat())
        with patch.object(loop, "_send_heartbeat", new_callable=AsyncMock):
            await loop._shutdown()

        assert loop._heartbeat_task.cancelled() or loop._heartbeat_task.done()


# ---------------------------------------------------------------------------
# WorkspaceAgentLoop init
# ---------------------------------------------------------------------------


class TestWorkspaceAgentLoopInit:
    """Tests for WorkspaceAgentLoop initialization."""

    def test_defaults(self):
        loop = WorkspaceAgentLoop(
            workspace_path="/workspace",
            agent_name="ws-agent",
            api_key="key",
        )
        assert loop.workspace_path == Path("/workspace")
        assert loop.agent_name == "ws-agent"
        assert loop.agent_type == "claude"
        assert loop._assignments == {}
        assert loop._agent_id is None

    def test_custom_workspace_config(self):
        ws_config = WorkspaceConfig(auto_clone=False, project_refresh_interval=60)
        loop = WorkspaceAgentLoop(
            workspace_path="/ws",
            agent_name="a",
            api_key="k",
            workspace_config=ws_config,
        )
        assert loop._workspace_config.auto_clone is False
        assert loop._workspace_config.project_refresh_interval == 60


# ---------------------------------------------------------------------------
# WorkspaceAgentLoop._resolve_working_directory
# ---------------------------------------------------------------------------


class TestWorkspaceResolveWorkingDirectory:
    """Tests for WorkspaceAgentLoop._resolve_working_directory."""

    def test_command_level_override(self, tmp_path: Path):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        cmd_dir = tmp_path / "cmd-dir"
        cmd_dir.mkdir()

        cmd = _make_command(working_directory=str(cmd_dir))
        result = loop._resolve_working_directory(cmd)
        assert result == cmd_dir

    def test_command_override_nonexistent_falls_through(self, tmp_path: Path):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        cmd = _make_command(working_directory="/nonexistent/path")
        loop._project_manager = None
        loop._assignments = {}

        result = loop._resolve_working_directory(cmd)
        assert result is None

    def test_project_manager_cache(self, tmp_path: Path):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        mock_pm = MagicMock()
        mock_pm.get_project_path.return_value = tmp_path
        loop._project_manager = mock_pm

        cmd = _make_command(project_id="proj-1")
        result = loop._resolve_working_directory(cmd)
        assert result == tmp_path

    def test_assignment_local_path(self, tmp_path: Path):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        loop._project_manager = MagicMock()
        loop._project_manager.get_project_path.return_value = None

        local = tmp_path / "proj"
        local.mkdir()
        loop._assignments = {
            "proj-1": ProjectAssignment(agent_id="a", project_id="proj-1", local_path=str(local))
        }

        cmd = _make_command(project_id="proj-1")
        result = loop._resolve_working_directory(cmd)
        assert result == local

    def test_returns_none_when_nothing_found(self):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        loop._project_manager = MagicMock()
        loop._project_manager.get_project_path.return_value = None
        loop._assignments = {}

        cmd = _make_command(project_id="proj-unknown")
        result = loop._resolve_working_directory(cmd)
        assert result is None


# ---------------------------------------------------------------------------
# WorkspaceAgentLoop._poll_once
# ---------------------------------------------------------------------------


class TestWorkspacePollOnce:
    """Tests for WorkspaceAgentLoop._poll_once."""

    @pytest.mark.asyncio
    async def test_no_command_returns_false(self):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()
        loop._commands_client.poll_next = AsyncMock(return_value=None)

        result = await loop._poll_once()
        assert result is False

    @pytest.mark.asyncio
    async def test_command_with_no_working_dir_fails(self):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()
        loop._project_manager = MagicMock()
        loop._project_manager.get_project_path.return_value = None
        loop._assignments = {}

        cmd = _make_command(project_id="proj-orphan")
        loop._commands_client.poll_next = AsyncMock(return_value=cmd)

        result = await loop._poll_once()
        assert result is True
        loop._commands_client.mark_failed.assert_awaited_once()
        assert loop._commands_failed == 1

    @pytest.mark.asyncio
    async def test_control_command_delegates(self):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()

        cmd = _make_command(command_type="control", control_action="shutdown")
        loop._commands_client.poll_next = AsyncMock(return_value=cmd)

        result = await loop._poll_once()
        assert result is True
        assert loop._shutdown_event.is_set()


# ---------------------------------------------------------------------------
# WorkspaceAgentLoop._sync_projects
# ---------------------------------------------------------------------------


class TestWorkspaceSyncProjects:
    """Tests for WorkspaceAgentLoop._sync_projects."""

    @pytest.mark.asyncio
    async def test_no_clients_returns_early(self):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        loop._agents_client = None
        await loop._sync_projects()  # Should not raise
        assert loop._assignments == {}

    @pytest.mark.asyncio
    async def test_syncs_active_assignments(self):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        loop._agent_id = "agent-1"
        loop._agents_client = AsyncMock()
        loop._project_manager = AsyncMock()

        assignments = [
            ProjectAssignment(agent_id="agent-1", project_id="p1", is_active=True),
            ProjectAssignment(agent_id="agent-1", project_id="p2", is_active=False),
            ProjectAssignment(agent_id="agent-1", project_id="p3", is_active=True),
        ]
        loop._agents_client.get_projects = AsyncMock(return_value=assignments)

        await loop._sync_projects()

        # Only active assignments should be cached
        assert "p1" in loop._assignments
        assert "p2" not in loop._assignments
        assert "p3" in loop._assignments
        loop._project_manager.sync_projects.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_auto_clone_disabled_skips_sync(self):
        ws_config = WorkspaceConfig(auto_clone=False)
        loop = WorkspaceAgentLoop(
            workspace_path="/ws",
            agent_name="a",
            api_key="k",
            workspace_config=ws_config,
        )
        loop._agent_id = "agent-1"
        loop._agents_client = AsyncMock()
        loop._project_manager = AsyncMock()
        loop._agents_client.get_projects = AsyncMock(return_value=[])

        await loop._sync_projects()
        loop._project_manager.sync_projects.assert_not_awaited()


# ---------------------------------------------------------------------------
# WorkspaceAgentLoop._handle_control_command
# ---------------------------------------------------------------------------


class TestWorkspaceControlCommand:
    """Tests for WorkspaceAgentLoop._handle_control_command."""

    @pytest.mark.asyncio
    async def test_shutdown_sets_event(self):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()

        cmd = _make_command(command_type="control", control_action="shutdown")
        result = await loop._handle_control_command(cmd)

        assert result is True
        assert loop._shutdown_event.is_set()

    @pytest.mark.asyncio
    async def test_unknown_action_fails(self):
        loop = WorkspaceAgentLoop(workspace_path="/ws", agent_name="a", api_key="k")
        loop._commands_client = AsyncMock()

        cmd = _make_command(command_type="control", control_action="reboot")
        result = await loop._handle_control_command(cmd)

        assert result is True
        loop._commands_client.mark_failed.assert_awaited_once()


# ---------------------------------------------------------------------------
# CommandExecutor edge cases
# ---------------------------------------------------------------------------


class ConcreteExecutor(CommandExecutor):
    """Concrete subclass for extended testing."""

    def __init__(self) -> None:
        self._api_key = "test-key"
        self.agent_type = "claude"
        self.agent_name = "test"
        self.model = None
        self.max_turns = None
        self._executor_config = ExecutorConfig()
        self._workflow_id = None
        self._enable_worktrees = False
        self._agent_loop_config = AgentLoopConfig()
        self._commands_client = AsyncMock()
        self._sessions_client = AsyncMock()
        self._shutdown_event = asyncio.Event()
        self._commands_executed = 0
        self._commands_succeeded = 0
        self._commands_failed = 0
        self._is_busy = False


class TestCommandExecutorExtended:
    """Extended tests for CommandExecutor._execute_command dispatch."""

    @pytest.mark.asyncio
    async def test_prompt_command_long_prompt_desc(self):
        """Prompt command with long prompt formats description correctly."""
        executor = ConcreteExecutor()
        sessions_mock = cast("AsyncMock", executor._sessions_client)
        sessions_mock.create_session = AsyncMock(return_value=None)
        long_prompt = "x" * 100
        cmd = _make_command(command_type="prompt", prompt=long_prompt)

        await executor._execute_command(cmd, "p", Path("/code"))

        # Session creation failed, so command should be marked failed
        assert executor._commands_failed == 1

    @pytest.mark.asyncio
    async def test_multiple_commands_increment_counter(self):
        """Multiple commands increment the executed counter correctly."""
        executor = ConcreteExecutor()
        cmd = _make_command(command_type="control")

        for i in range(5):
            await executor._execute_command(cmd, "p", Path("/code"))
            assert executor._commands_executed == i + 1
