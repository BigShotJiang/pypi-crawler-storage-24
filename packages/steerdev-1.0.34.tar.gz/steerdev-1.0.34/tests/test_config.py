"""Tests for configuration models."""

import tempfile

import pytest
from pydantic import ValidationError

from steerdev_agent.config.models import (
    AgentConfig,
    AgentLoopConfig,
    APIConfig,
    CanalConfig,
    EventsConfig,
    ExecutorConfig,
    SteerDevConfig,
    WorkspaceConfig,
    WorktreeConfig,
)


class TestAgentConfig:
    """Tests for AgentConfig."""

    def test_defaults(self):
        """Test default values."""
        config = AgentConfig()
        assert config.model is None
        assert config.max_turns is None
        assert config.timeout_seconds == 3600

    def test_custom_values(self):
        """Test custom values."""
        config = AgentConfig(
            model="claude-sonnet-4-20250514",
            max_turns=10,
            timeout_seconds=7200,
        )
        assert config.model == "claude-sonnet-4-20250514"
        assert config.max_turns == 10
        assert config.timeout_seconds == 7200


class TestAPIConfig:
    """Tests for APIConfig."""

    def test_defaults(self):
        """Test default values."""
        config = APIConfig()
        assert "steerdev.com" in config.api_endpoint
        assert config.api_key_env == "STEERDEV_API_KEY"
        assert config.project_id_env == "STEERDEV_PROJECT_ID"


class TestEventsConfig:
    """Tests for EventsConfig."""

    def test_defaults(self):
        """Test default values."""
        config = EventsConfig()
        assert config.batch_size == 10
        assert config.flush_interval_seconds == 5.0


class TestSteerDevConfig:
    """Tests for SteerDevConfig."""

    def test_defaults(self):
        """Test default values."""
        config = SteerDevConfig()
        assert isinstance(config.agent, AgentConfig)
        assert isinstance(config.api, APIConfig)
        assert isinstance(config.events, EventsConfig)

    def test_from_yaml(self):
        """Test loading from YAML."""
        yaml_content = """
agent:
  model: claude-opus-4-20250514
  timeout_seconds: 1800
events:
  batch_size: 20
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()

            config = SteerDevConfig.from_yaml(f.name)
            assert config.agent.model == "claude-opus-4-20250514"
            assert config.agent.timeout_seconds == 1800
            assert config.events.batch_size == 20

    def test_to_yaml(self):
        """Test saving to YAML."""
        config = SteerDevConfig()
        config.agent.model = "claude-sonnet-4-20250514"

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            config.to_yaml(f.name)

            # Read back
            loaded = SteerDevConfig.from_yaml(f.name)
            assert loaded.agent.model == "claude-sonnet-4-20250514"

    def test_from_yaml_empty_file(self):
        """Loading an empty YAML file returns defaults."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write("")
            f.flush()
            config = SteerDevConfig.from_yaml(f.name)
            assert config.agent.timeout_seconds == 3600

    def test_from_yaml_nonexistent_file(self):
        """Loading a nonexistent file raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            SteerDevConfig.from_yaml("/nonexistent/path/config.yaml")

    def test_defaults_include_new_sections(self):
        """SteerDevConfig includes workspace, canal, agent_loop, worktrees."""
        config = SteerDevConfig()
        assert isinstance(config.workspace, WorkspaceConfig)
        assert isinstance(config.canal, CanalConfig)
        assert isinstance(config.agent_loop, AgentLoopConfig)
        assert isinstance(config.worktrees, WorktreeConfig)
        assert isinstance(config.executor, ExecutorConfig)

    def test_roundtrip_yaml_with_all_sections(self):
        """All config sections survive a YAML roundtrip."""
        config = SteerDevConfig()
        config.workspace.auto_clone = False
        config.canal.enabled = True
        config.canal.base_branch = "main"
        config.agent_loop.poll_interval_seconds = 2.0

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            config.to_yaml(f.name)
            loaded = SteerDevConfig.from_yaml(f.name)
            assert loaded.workspace.auto_clone is False
            assert loaded.canal.enabled is True
            assert loaded.canal.base_branch == "main"
            assert loaded.agent_loop.poll_interval_seconds == 2.0


class TestExecutorConfig:
    """Tests for ExecutorConfig."""

    def test_defaults(self):
        config = ExecutorConfig()
        assert config.type == "claude"
        assert config.permission_mode == "dangerously-skip-permissions"
        assert config.allowed_tools == []
        assert config.disallowed_tools == []
        assert config.mcp_config is None

    def test_custom_values(self):
        config = ExecutorConfig(
            type="codex",
            permission_mode="plan",
            allowed_tools=["read", "write"],
            mcp_config="/path/to/mcp.json",
        )
        assert config.type == "codex"
        assert config.allowed_tools == ["read", "write"]


class TestWorktreeConfig:
    """Tests for WorktreeConfig."""

    def test_defaults(self):
        config = WorktreeConfig()
        assert config.enabled is False

    def test_enabled(self):
        config = WorktreeConfig(enabled=True)
        assert config.enabled is True


class TestAgentLoopConfig:
    """Tests for AgentLoopConfig."""

    def test_defaults(self):
        config = AgentLoopConfig()
        assert config.poll_interval_seconds == 5.0
        assert config.heartbeat_interval_seconds == 30.0
        assert config.idle_poll_interval_seconds == 10.0
        assert config.max_consecutive_errors == 5
        assert config.command_timeout_seconds == 3600
        assert config.gap_seconds == 0.0

    def test_custom_values(self):
        config = AgentLoopConfig(
            poll_interval_seconds=2.0,
            heartbeat_interval_seconds=15.0,
            idle_poll_interval_seconds=5.0,
            max_consecutive_errors=10,
            command_timeout_seconds=7200,
            gap_seconds=1.5,
        )
        assert config.poll_interval_seconds == 2.0
        assert config.gap_seconds == 1.5

    def test_validation_min_values(self):
        """Minimum constraint validation."""
        with pytest.raises(ValidationError):
            AgentLoopConfig(poll_interval_seconds=0.5)  # ge=1.0
        with pytest.raises(ValidationError):
            AgentLoopConfig(heartbeat_interval_seconds=5.0)  # ge=10.0
        with pytest.raises(ValidationError):
            AgentLoopConfig(command_timeout_seconds=30)  # ge=60


class TestWorkspaceConfig:
    """Tests for WorkspaceConfig."""

    def test_defaults(self):
        config = WorkspaceConfig()
        assert config.workspace_dir is None
        assert config.auto_clone is True
        assert config.project_refresh_interval == 300
        assert config.max_concurrent_tasks == 1

    def test_custom_values(self):
        from pathlib import Path

        config = WorkspaceConfig(
            workspace_dir=Path("/workspace"),
            auto_clone=False,
            project_refresh_interval=60,
            max_concurrent_tasks=3,
        )
        assert config.workspace_dir == Path("/workspace")
        assert config.auto_clone is False

    def test_validation_constraints(self):
        """Constraint validation on workspace config."""
        with pytest.raises(ValidationError):
            WorkspaceConfig(project_refresh_interval=10)  # ge=30
        with pytest.raises(ValidationError):
            WorkspaceConfig(max_concurrent_tasks=0)  # ge=1
        with pytest.raises(ValidationError):
            WorkspaceConfig(max_concurrent_tasks=20)  # le=10


class TestCanalConfig:
    """Tests for CanalConfig."""

    def test_defaults(self):
        config = CanalConfig()
        assert config.enabled is False
        assert config.base_branch == "dev"

    def test_custom_values(self):
        config = CanalConfig(enabled=True, base_branch="main")
        assert config.enabled is True
        assert config.base_branch == "main"
