"""Tests for Claude executor command building and properties."""

from unittest.mock import patch

import pytest

from steerdev_agent.executor.claude import ClaudeExecutor, ClaudeExecutorError


class TestClaudeExecutorInit:
    """Tests for ClaudeExecutor initialization."""

    def test_defaults(self):
        """Test default values."""
        executor = ClaudeExecutor(working_directory="/project")
        assert executor.working_directory == "/project"
        assert executor.model is None
        assert executor.max_turns is None
        assert executor.allowed_tools == []
        assert executor.disallowed_tools == []
        assert executor.mcp_config is None
        assert executor.permission_mode == "dangerously-skip-permissions"
        assert executor.dry_run is False
        assert executor.worktree_name is None

    def test_custom_values(self):
        """Test custom initialization values."""
        executor = ClaudeExecutor(
            working_directory="/project",
            model="claude-sonnet-4-20250514",
            max_turns=10,
            allowed_tools=["Read", "Write"],
            disallowed_tools=["Bash"],
            mcp_config="/path/to/mcp.json",
            permission_mode="default",
            dry_run=True,
            worktree_name="feature-branch",
        )
        assert executor.model == "claude-sonnet-4-20250514"
        assert executor.max_turns == 10
        assert executor.allowed_tools == ["Read", "Write"]
        assert executor.disallowed_tools == ["Bash"]
        assert executor.mcp_config == "/path/to/mcp.json"
        assert executor.permission_mode == "default"
        assert executor.dry_run is True
        assert executor.worktree_name == "feature-branch"

    def test_agent_type(self):
        """Agent type should be 'claude'."""
        executor = ClaudeExecutor(working_directory="/project")
        assert executor.agent_type == "claude"


class TestBuildCommand:
    """Tests for _build_command."""

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_basic_command(self, mock_which):
        """Basic command with just a prompt."""
        executor = ClaudeExecutor(
            working_directory="/project",
            permission_mode="dangerously-skip-permissions",
        )
        cmd = executor._build_command("Hello world")

        assert cmd[0] == "/usr/local/bin/claude"
        assert "-p" in cmd
        assert "Hello world" in cmd
        assert "--output-format" in cmd
        assert "stream-json" in cmd
        assert "--verbose" in cmd
        assert "--dangerously-skip-permissions" in cmd

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_with_model(self, mock_which):
        """Command should include model flag."""
        executor = ClaudeExecutor(
            working_directory="/project",
            model="claude-sonnet-4-20250514",
        )
        cmd = executor._build_command("test")
        assert "--model" in cmd
        idx = cmd.index("--model")
        assert cmd[idx + 1] == "claude-sonnet-4-20250514"

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_with_max_turns(self, mock_which):
        """Command should include max-turns flag."""
        executor = ClaudeExecutor(
            working_directory="/project",
            max_turns=5,
        )
        cmd = executor._build_command("test")
        assert "--max-turns" in cmd
        idx = cmd.index("--max-turns")
        assert cmd[idx + 1] == "5"

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_with_resume_session(self, mock_which):
        """Command should include resume flag when resuming."""
        executor = ClaudeExecutor(working_directory="/project")
        cmd = executor._build_command("continue", resume_session="sess-123")
        assert "--resume" in cmd
        idx = cmd.index("--resume")
        assert cmd[idx + 1] == "sess-123"

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_without_resume(self, mock_which):
        """Command should not include resume flag for new sessions."""
        executor = ClaudeExecutor(working_directory="/project")
        cmd = executor._build_command("new prompt")
        assert "--resume" not in cmd

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_with_allowed_tools(self, mock_which):
        """Command should include each allowed tool."""
        executor = ClaudeExecutor(
            working_directory="/project",
            allowed_tools=["Read", "Write", "Bash"],
        )
        cmd = executor._build_command("test")
        assert cmd.count("--allowedTools") == 3
        # Check tool names follow their respective flags
        for tool in ["Read", "Write", "Bash"]:
            assert tool in cmd

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_with_disallowed_tools(self, mock_which):
        """Command should include each disallowed tool."""
        executor = ClaudeExecutor(
            working_directory="/project",
            disallowed_tools=["Bash"],
        )
        cmd = executor._build_command("test")
        assert "--disallowedTools" in cmd
        idx = cmd.index("--disallowedTools")
        assert cmd[idx + 1] == "Bash"

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_with_mcp_config(self, mock_which):
        """Command should include MCP config path."""
        executor = ClaudeExecutor(
            working_directory="/project",
            mcp_config="/path/to/mcp.json",
        )
        cmd = executor._build_command("test")
        assert "--mcp-config" in cmd
        idx = cmd.index("--mcp-config")
        assert cmd[idx + 1] == "/path/to/mcp.json"

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_with_worktree(self, mock_which):
        """Command should include worktree flag."""
        executor = ClaudeExecutor(
            working_directory="/project",
            worktree_name="my-feature",
        )
        cmd = executor._build_command("test")
        assert "--worktree" in cmd
        idx = cmd.index("--worktree")
        assert cmd[idx + 1] == "my-feature"

    @patch("shutil.which", return_value="/usr/local/bin/claude")
    def test_non_skip_permissions(self, mock_which):
        """Non-skip permission mode should not add the flag."""
        executor = ClaudeExecutor(
            working_directory="/project",
            permission_mode="default",
        )
        cmd = executor._build_command("test")
        assert "--dangerously-skip-permissions" not in cmd

    @patch("shutil.which", return_value=None)
    def test_claude_not_found_raises(self, mock_which):
        """Should raise ClaudeExecutorError if CLI not found."""
        executor = ClaudeExecutor(working_directory="/project")
        with pytest.raises(ClaudeExecutorError, match="not found"):
            executor._build_command("test")


class TestClaudeExecutorProperties:
    """Tests for ClaudeExecutor properties."""

    def test_session_id_initially_none(self):
        """Session ID should be None before running."""
        executor = ClaudeExecutor(working_directory="/project")
        assert executor.session_id is None

    def test_is_running_before_start(self):
        """Should not be running before start."""
        executor = ClaudeExecutor(working_directory="/project")
        assert executor.is_running is False

    def test_dry_run_is_running(self):
        """Dry run starts as running, ends as not running."""
        executor = ClaudeExecutor(working_directory="/project", dry_run=True)
        assert executor.is_running is True
        executor._dry_run_complete = True
        assert executor.is_running is False
