"""Phase context summaries for workflow execution."""

from pathlib import Path


def get_summary_path(run_path: Path, phase_order: int, phase_name: str) -> Path:
    """Return the summary file path for a phase.

    Args:
        run_path: The workflow run directory.
        phase_order: The phase's order number (0-based or 1-based).
        phase_name: Human-readable phase name.

    Returns:
        Path like run_path / '01_plan.md'.
    """
    slug = phase_name.lower().replace(" ", "_")
    filename = f"{phase_order:02d}_{slug}.md"
    return run_path / filename


def list_existing_summaries(run_path: Path) -> list[Path]:
    """Return sorted list of summary .md files in the run directory.

    Args:
        run_path: The workflow run directory.

    Returns:
        Sorted list of existing .md summary files.
    """
    if not run_path.exists():
        return []
    return sorted(run_path.glob("*.md"))
