# Task Management Skill

This skill enables autonomous task management via steerdev.com API.

**You must respect the task lifecycle.**

## Task Lifecycle

Tasks use Linear-native status_type values:

```
BACKLOG → UNSTARTED → STARTED → COMPLETED
```

| Status | Description | Your Action |
|--------|-------------|-------------|
| `backlog` | Task is queued, not ready for work | Do not work on these tasks |
| `unstarted` | Ready to be worked on | Pick up task and move to `started` |
| `started` | Currently being worked on | Implement the task |
| `completed` | Task completed | No action needed |
| `canceled` | Task was canceled | No action needed |

## When to Use

- **At session start**: Fetch the next task to work on
- **When updating work status**: Move a task to `started`, `completed`, or `canceled`
- **When blocked or need clarification**: Update the task with a comment
- **When discovering new work**: Create follow-up tasks

## Available Commands

### Get Next Task

```bash
steerdev tasks next [--project-id PROJECT_ID] [--waves/--no-waves]
```

Returns the highest priority task to work on, automatically prioritizing in this order:
1. **Started** tasks (to continue work)
2. **Unstarted** tasks (to start new work)
3. **Backlog** tasks (if nothing else available)

**Options:**
- `--project-id`, `-p`: Filter by project ID (or use `STEERDEV_PROJECT_ID` env var)
- `--waves/--no-waves`: Enable or disable wave-aware scheduling

**Examples:**
```bash
# Get the next task with wave-aware scheduling
steerdev tasks next

# Force single-task scheduling
steerdev tasks next --no-waves
```

### List Tasks

```bash
steerdev tasks list [--status STATUS] [--project-id PROJECT_ID] [--limit N] [--compact]
```

List tasks with optional filters.

**Options:**
- `--status`, `-s`: Filter by status (`backlog`, `unstarted`, `started`, `completed`, `canceled`)
- `--project-id`, `-p`: Filter by project ID (or use `STEERDEV_PROJECT_ID` env var)
- `--limit`, `-l`: Maximum number of tasks to return (default: 20)
- `--compact`, `-c`: Show truncated IDs (8 chars) instead of full UUIDs

### Get Task Details

```bash
steerdev tasks get TASK_ID
```

Get details of a specific task by ID.

**Arguments:**
- `TASK_ID`: Task ID (UUID) to fetch

### Update Task

```bash
steerdev tasks update TASK_ID [OPTIONS]
```

Update a task's status or other fields. **Always update to `started` when starting work.**

**Options:**
- `--status`, `-s`: New status (`backlog`, `unstarted`, `started`, `completed`, `canceled`)
- `--title`, `-t`: Update task title
- `--prompt`: Update task prompt
- `--priority`, `-P`: Update priority (0=none, 1=urgent, 2=high, 3=medium, 4=low)
- `--result`, `-r`: Result summary (for completed tasks)
- `--error`, `-e`: Error message (for canceled tasks)
- `--comment`, `-c`: Comment text (supports markdown)

### Create Task

```bash
steerdev tasks create --title "..." --prompt "..." [OPTIONS]
```

Create a new task for discovered work items.

**Options:**
- `--title`, `-t`: Task title (required)
- `--prompt`: Task prompt/description (required)
- `--project-id`, `-p`: Project ID (or use `STEERDEV_PROJECT_ID` env var)
- `--priority`: Priority 0-4 (default: 3 = medium)
- `--workdir`, `-w`: Working directory for the task
- `--spec-id`, `-s`: Specification ID to link this task to
- `--cycle-id`, `-c`: Cycle ID to link this task to

## Default Working Pattern

1. Run `steerdev tasks next` to get the next task.
2. Update the task to `started` before implementation.
3. Create or update progress logs in the workspace root `docs/` directory.
4. Implement the requested change.
5. Verify web/UI changes visually with `agent-browser`.
6. Add task comments when useful for blockers, handoffs, or status notes.
7. Update the task result and status when the active workflow reaches completion.

**IMPORTANT**: Always write progress logs. See the **steerdev-progress-logging-skill** for details.

## Wave Scheduling

- `steerdev tasks next --waves` keeps wave-aware scheduling enabled.
- `steerdev tasks next --no-waves` forces single-task scheduling.
- If your prompt includes a **Wave Context** section, use it to understand the related tasks and current wave scope.

## Visual Verification for Web Changes (Required)

**For any task involving web UI changes, you MUST visually verify your work using `agent-browser`.**

### When to Use Browser Verification

- Adding or modifying UI components
- Changing layouts, styles, or visual elements
- Implementing new pages or routes
- Fixing visual bugs
- Any frontend work in `steerdev-app` or `steerdev.com`

### Development Environment

The `steerdev-app` runs with development settings that **skip Clerk authentication**. You can directly access:

- Dashboard: `http://localhost:3000`
- All authenticated routes work without login in dev mode

### Verification Workflow

```bash
# 1. Navigate to the page you modified
agent-browser open http://localhost:3000/your-page

# 2. Take a snapshot to see interactive elements
agent-browser snapshot -i

# 3. Take a screenshot to verify visual appearance
agent-browser screenshot

# 4. For full-page captures
agent-browser screenshot --full

# 5. If you need to interact (click buttons, fill forms)
agent-browser click @e1
agent-browser fill @e2 "test input"
agent-browser snapshot -i  # Re-snapshot after interactions
```

### Example: Verifying a New Component

```bash
# After implementing a new dashboard widget
agent-browser open http://localhost:3000/dashboard
agent-browser snapshot -i
agent-browser screenshot --full

# Check if specific elements rendered correctly
agent-browser get text @e5

# Test interactions
agent-browser click @e3
agent-browser wait --load networkidle
agent-browser snapshot -i
agent-browser screenshot
```

### Example: Testing Form Changes

```bash
# Navigate to form page
agent-browser open http://localhost:3000/settings

# Get initial state
agent-browser snapshot -i
agent-browser screenshot

# Fill and submit the form
agent-browser fill @e1 "Test Value"
agent-browser select @e2 "Option A"
agent-browser click @e3

# Verify success state
agent-browser wait --load networkidle
agent-browser snapshot -i
agent-browser screenshot
```

## Adding Comments

You can add markdown comments to tasks at any time:

```bash
steerdev tasks update abc123-... --comment "## Progress Update

- Completed initial investigation
- Found issue in auth module
- Working on fix"
```

## Environment

Requires `STEERDEV_API_KEY` environment variable to be set.

**Optional:**
- `STEERDEV_API_ENDPOINT`: Override the API base URL (default: https://platform.steerdev.com/api/v1)
- `STEERDEV_PROJECT_ID`: Default project ID for all commands
- `STEERDEV_AGENT_ID`: Agent ID for tracking
