# Wave Tasks Merge Skill

Use this skill when a workflow phase tells you to complete **multiple related tasks on one wave branch with one pull request**.

## When to Use

- The workflow prompt explicitly references `wave-tasks-merge`
- `--waves` is active and wave context is present
- `--no-canals` is active

## Expected Outcome

- One shared wave branch
- One shared pull request for the wave
- All related tasks updated with the same PR URL

## Pre-flight Sync (REQUIRED before starting a new wave)

Before creating the wave branch, check if you need to sync:

- **Starting a new wave** (not on `wave/<N>` branch yet): Sync to default branch first:
  ```bash
  git stash push -m "steerdev-preflight" 2>/dev/null || true
  git checkout main && git pull origin main --ff-only
  ```
  If `--ff-only` fails: `git fetch origin && git reset --hard origin/main`

- **Continuing a wave** (already on `wave/<N>` branch): Do NOT switch to main. Stay on the wave branch and continue with the next task.

**Why:** The agent may still be on a previous task/wave branch. New waves must branch from updated main. Mid-wave tasks must stay on the wave branch.

## Workflow

1. Create or switch to the shared wave branch:

```bash
git checkout -b wave/<wave-number>
```

2. For each task in the wave:
- Mark the task `started`
- Implement the requested change
- Commit with a task-prefixed conventional commit, such as `[task:<id>] feat: ...`

3. After the wave work is ready for review, push the shared branch:

```bash
git push -u origin HEAD
```

4. Create one pull request for the wave:

```bash
steerdev git pr --title "Wave <N>: <description>" --body "..."
```

5. Update all related tasks with the shared PR URL
6. Log progress and completion in the root `docs/` progress files

## Conventions

- Use one branch per wave: `wave/<wave-number>`
- Do not create per-task PRs inside the wave
- Keep commits traceable by including `[task:<id>]` in each task-specific commit
- Include the shared PR URL in every related task result

## Example

```bash
git checkout -b wave/3
steerdev tasks update task-aaa... --status started
# ... implement task 1 ...
git add .
git commit -m "[task:task-aaa] feat: add user endpoint"

steerdev tasks update task-bbb... --status started
# ... implement task 2 ...
git add .
git commit -m "[task:task-bbb] fix: validate email format"

git push -u origin HEAD
steerdev git pr --title "Wave 3: User management improvements" --body "..."
steerdev tasks update task-aaa... --result "PR: https://github.com/org/repo/pull/42"
steerdev tasks update task-bbb... --result "PR: https://github.com/org/repo/pull/42"
```
