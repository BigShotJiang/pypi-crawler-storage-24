# Single Task Merge Skill

Use this skill when a workflow phase tells you to complete **one task on one branch with one pull request**.

## When to Use

- The workflow prompt explicitly references `single-task-merge`
- `--no-waves` is active, or no wave context is present
- `--no-canals` is active

## Expected Outcome

- One task branch
- One pull request
- One task result update that includes the PR URL

## Pre-flight Sync (REQUIRED before every new task)

Before creating your task branch, ensure you're starting from an up-to-date default branch:

1. Stash any uncommitted changes (if any):
   ```bash
   git stash push -m "steerdev-preflight" 2>/dev/null || true
   ```

2. Switch to the default branch and pull latest:
   ```bash
   git checkout main && git pull origin main --ff-only
   ```
   If `main` doesn't exist, try `master`. If `--ff-only` fails (local main diverged), force-reset:
   ```bash
   git fetch origin && git reset --hard origin/main
   ```

3. Now proceed to create your task branch from the up-to-date default branch.

**Why:** The agent may still be on a previous task's branch. Without this step, new branches are created from stale code, causing desync with merged PRs.

## Workflow

1. Ensure the task is already marked `started`
2. Create or switch to the task branch:

```bash
steerdev git branch TASK_ID [--name NAME]
```

3. Implement the requested changes
4. Commit with a conventional commit message that explains why the change exists
5. Push the current branch:

```bash
git push -u origin HEAD
```

6. Create the pull request:

```bash
steerdev git pr --title "TITLE" --task-id TASK_ID [--body "BODY"]
```

7. Update the task result with the PR URL
8. Log completion in the root `docs/` progress files

## Conventions

- Branch naming should follow `task/<short-task-id>` unless the workflow prompt says otherwise
- Create exactly one PR for the task
- Include the PR URL in the task result summary

## Example

```bash
steerdev tasks update abc12345... --status started
steerdev git branch abc12345...
# ... implement changes ...
git add .
git commit -m "feat: add user authentication"
git push -u origin HEAD
steerdev git pr --title "Add user authentication" --task-id abc12345...
steerdev tasks update abc12345... --result "PR: https://github.com/org/repo/pull/42"
```
