# Git Workflow Skill

This broad skill is deprecated.

## Replacement Skills

- Use `steerdev-single-task-merge-skill` for one task, one branch, one PR
- Use `steerdev-wave-tasks-merge-skill` for one wave branch and one shared PR
- Use `steerdev-merge-into-canal-skill` when canal integration is active

## Compatibility Note

If an older workflow prompt still references `git-workflow` or `steerdev-git-workflow-skill`, map it to the focused replacement that matches the current execution mode.
