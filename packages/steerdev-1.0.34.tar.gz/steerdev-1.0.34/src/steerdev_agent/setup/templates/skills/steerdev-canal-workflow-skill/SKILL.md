# Canal Workflow Skill

This broad skill is deprecated.

## Replacement Skill

Use `steerdev-merge-into-canal-skill` for the focused canal integration flow.

## Compatibility Note

If an older workflow prompt still references `canal-workflow` or `steerdev-canal-workflow-skill`, map it to `steerdev-merge-into-canal-skill`.
