## Task Management

This project uses steerdev.com for task management. Use the **steerdev-task-management-skill** for full instructions on task lifecycle, available commands, workflow patterns, and environment variables.

### Quick Reference

- Fetch work: `steerdev tasks next`
- Update status: `steerdev tasks update TASK_ID --status STATUS`
- Write progress logs to the workspace root `docs/` directory (see the **steerdev-progress-logging-skill**)
- Visually verify web/UI changes with `agent-browser`
