"""Workspace agent mode — multi-project agent management."""
