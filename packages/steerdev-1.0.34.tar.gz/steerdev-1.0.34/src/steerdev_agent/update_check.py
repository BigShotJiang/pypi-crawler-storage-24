"""Check for newer versions of steerdev on PyPI."""

import json
import time
from pathlib import Path

import httpx

PYPI_URL = "https://pypi.org/pypi/steerdev/json"
CACHE_FILE = Path.home() / ".cache" / "steerdev" / "update_check.json"
CHECK_INTERVAL = 3600  # 1 hour between checks


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a version string into a tuple of ints for comparison."""
    try:
        return tuple(int(x) for x in v.split("."))
    except (ValueError, AttributeError):
        return (0,)


def _read_cache() -> dict | None:
    """Read cached update check result."""
    try:
        if CACHE_FILE.exists():
            data = json.loads(CACHE_FILE.read_text())
            if time.time() - data.get("checked_at", 0) < CHECK_INTERVAL:
                return data
    except (json.JSONDecodeError, OSError):
        pass
    return None


def _write_cache(latest: str) -> None:
    """Write update check result to cache."""
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        CACHE_FILE.write_text(json.dumps({"latest": latest, "checked_at": time.time()}))
    except OSError:
        pass


def _fetch_latest() -> str | None:
    """Fetch the latest version from PyPI. Returns None on failure."""
    try:
        resp = httpx.get(PYPI_URL, timeout=3)
        resp.raise_for_status()
        latest = resp.json()["info"]["version"]
        _write_cache(latest)
        return latest
    except Exception:
        return None


def check_for_update(current: str) -> str | None:
    """Check if a newer version is available.

    Returns the latest version string if an update is available, None otherwise.
    """
    cached = _read_cache()
    if cached:
        latest = cached["latest"]
        # Invalidate cache if the cached "latest" is not newer than current,
        # since PyPI may have a newer release we haven't seen yet.
        if _parse_version(latest) <= _parse_version(current):
            latest = _fetch_latest()
        return latest if latest and _parse_version(latest) > _parse_version(current) else None

    latest = _fetch_latest()
    if latest and _parse_version(latest) > _parse_version(current):
        return latest
    return None
