"""Canal management API client."""

from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from steerdev_agent.api.client import SteerDevClient, get_project_id

console = Console()

VALID_CANAL_STATUSES = [
    "open",
    "testing",
    "ready_for_review",
    "merged",
    "failed",
    "rejected",
    "closed",
]

STATUS_COLORS: dict[str, str] = {
    "open": "blue",
    "testing": "yellow",
    "ready_for_review": "magenta",
    "merged": "green",
    "failed": "red",
    "rejected": "red",
    "closed": "dim",
}


class CanalsClient(SteerDevClient):
    """Client for canal management operations."""

    def list_canals(
        self,
        project_id: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List canals for a project.

        Args:
            project_id: Project ID. Falls back to STEERDEV_PROJECT_ID env var.
            status: Filter by canal status.

        Returns:
            List of canal dicts.
        """
        effective_project_id = project_id or get_project_id()
        if not effective_project_id:
            console.print(
                "[red]Error: project_id is required (set STEERDEV_PROJECT_ID or use --project-id)[/red]"
            )
            return []

        params: dict[str, str] = {"project_id": effective_project_id}
        if status:
            params["status"] = status

        response = self.get("/canals", params=params)

        if response.status_code != 200:
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return []

        data = response.json()
        return data.get("canals", []) if isinstance(data, dict) else data

    def get_canal(self, canal_id: str) -> dict[str, Any] | None:
        """Get canal details with merges.

        Args:
            canal_id: Canal UUID.

        Returns:
            Canal dict or None if not found.
        """
        response = self.get(f"/canals/{canal_id}")

        if response.status_code == 404:
            return None

        if response.status_code != 200:
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return None

        return response.json()

    def get_next_canal(self, project_id: str | None = None) -> dict[str, Any] | None:
        """Get the best canal for merging.

        Args:
            project_id: Project ID. Falls back to STEERDEV_PROJECT_ID env var.

        Returns:
            Canal dict or None if no canals available.
        """
        effective_project_id = project_id or get_project_id()
        if not effective_project_id:
            console.print(
                "[red]Error: project_id is required (set STEERDEV_PROJECT_ID or use --project-id)[/red]"
            )
            return None

        params: dict[str, str] = {"project_id": effective_project_id}
        response = self.get("/canals/next", params=params)

        if response.status_code == 404:
            return None

        if response.status_code != 200:
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return None

        return response.json()

    def create_canal(
        self,
        project_id: str | None = None,
        repository_id: str | None = None,
        base_branch: str = "dev",
        created_by: str | None = None,
    ) -> dict[str, Any] | None:
        """Create a new canal.

        Args:
            project_id: Project ID. Falls back to STEERDEV_PROJECT_ID env var.
            repository_id: GitHub repository ID.
            base_branch: Base branch for the canal.
            created_by: Creator identifier.

        Returns:
            Created canal dict or None on error.
        """
        effective_project_id = project_id or get_project_id()
        if not effective_project_id:
            console.print(
                "[red]Error: project_id is required (set STEERDEV_PROJECT_ID or use --project-id)[/red]"
            )
            return None

        payload: dict[str, Any] = {
            "project_id": effective_project_id,
            "base_branch": base_branch,
        }
        if repository_id:
            payload["repository_id"] = repository_id
        if created_by:
            payload["created_by"] = created_by

        response = self.post("/canals", json=payload)

        if response.status_code not in (200, 201):
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return None

        return response.json()

    def record_merge(
        self,
        canal_id: str,
        source_branch: str,
        source_pr_number: int | None = None,
        task_id: str | None = None,
        merge_sha: str | None = None,
    ) -> dict[str, Any] | None:
        """Record a merge to a canal.

        Args:
            canal_id: Canal UUID.
            source_branch: Source branch that was merged.
            source_pr_number: GitHub PR number of the source.
            task_id: Task UUID associated with this merge.
            merge_sha: Git SHA of the merge commit.

        Returns:
            Merge record dict or None on error.
        """
        payload: dict[str, Any] = {"source_branch": source_branch}
        if source_pr_number is not None:
            payload["source_pr_number"] = source_pr_number
        if task_id:
            payload["task_id"] = task_id
        if merge_sha:
            payload["merge_sha"] = merge_sha

        response = self.post(f"/canals/{canal_id}/merge", json=payload)

        if response.status_code not in (200, 201):
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return None

        return response.json()

    def update_canal(
        self,
        canal_id: str,
        status: str,
        canal_pr_number: int | None = None,
        canal_pr_url: str | None = None,
    ) -> dict[str, Any] | None:
        """Update canal status.

        Args:
            canal_id: Canal UUID.
            status: New status.
            canal_pr_number: GitHub PR number for the canal PR.
            canal_pr_url: URL of the canal PR.

        Returns:
            Updated canal dict or None on error.
        """
        payload: dict[str, Any] = {"status": status}
        if canal_pr_number is not None:
            payload["canal_pr_number"] = canal_pr_number
        if canal_pr_url is not None:
            payload["canal_pr_url"] = canal_pr_url

        response = self.patch(f"/canals/{canal_id}", json=payload)

        if response.status_code not in (200, 204):
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return None

        return response.json()


def display_canal(canal: dict[str, Any], title: str = "Canal") -> None:
    """Display a single canal in a formatted panel."""
    status = canal.get("status", "unknown")
    color = STATUS_COLORS.get(status, "white")
    merge_count = canal.get("merge_count", len(canal.get("merges", [])))
    max_merges = canal.get("max_merges", "?")

    info_text = (
        f"[bold cyan]ID:[/bold cyan] {canal.get('id', 'N/A')}\n"
        f"[bold cyan]Branch:[/bold cyan] {canal.get('branch_name', 'N/A')}\n"
        f"[bold cyan]Base:[/bold cyan] {canal.get('base_branch', 'N/A')}\n"
        f"[bold cyan]Status:[/bold cyan] [{color}]{status}[/{color}]\n"
        f"[bold cyan]Merges:[/bold cyan] {merge_count}/{max_merges}\n"
    )

    if canal.get("canal_pr_url"):
        info_text += f"[bold cyan]Canal PR:[/bold cyan] {canal['canal_pr_url']}\n"

    if canal.get("created_by"):
        info_text += f"[bold cyan]Created by:[/bold cyan] {canal['created_by']}\n"

    info_text += f"[bold cyan]Created:[/bold cyan] {canal.get('created_at', 'N/A')}\n"

    # Show merges if available
    merges = canal.get("merges", [])
    if merges:
        info_text += "\n[bold cyan]Merged Branches:[/bold cyan]\n"
        for m in merges:
            ci = "✓" if m.get("source_ci_status") == "success" else "○"
            branch = m.get("source_branch", "?")
            pr = f" #{m['source_pr_number']}" if m.get("source_pr_number") else ""
            info_text += f"  {ci} {branch}{pr} [{m.get('merge_status', '?')}]\n"

    console.print(Panel(info_text, title=title, border_style=color))


def display_canal_list(canals: list[dict[str, Any]]) -> None:
    """Display a list of canals in a formatted table."""
    if not canals:
        console.print("[yellow]No canals found[/yellow]")
        return

    table = Table(title="Canals")
    table.add_column("Branch", style="cyan", no_wrap=True)
    table.add_column("Status", style="white")
    table.add_column("Merges", style="white", justify="center")
    table.add_column("PR", style="white")
    table.add_column("Created", style="dim")

    for canal in canals:
        status = canal.get("status", "?")
        color = STATUS_COLORS.get(status, "white")
        merge_count = canal.get("merge_count", 0)
        max_merges = canal.get("max_merges", "?")
        pr_url = canal.get("canal_pr_url", "-")
        created = str(canal.get("created_at", ""))[:10]

        table.add_row(
            canal.get("branch_name", "?"),
            f"[{color}]{status}[/{color}]",
            f"{merge_count}/{max_merges}",
            pr_url if pr_url else "-",
            created,
        )

    console.print(table)
    console.print(f"\n[dim]Total: {len(canals)} canals[/dim]")
