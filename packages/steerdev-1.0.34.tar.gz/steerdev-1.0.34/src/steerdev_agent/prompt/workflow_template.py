"""Helpers for rendering workflow prompt templates."""

from __future__ import annotations

from string import Template
from typing import Any


def render_workflow_prompt_template(template: str, variables: dict[str, Any]) -> str:
    """Render a workflow prompt template.

    Uses standard-library ``string.Template`` interpolation.
    Unknown placeholders are left unchanged via ``safe_substitute``.
    """
    kwargs = {key: "" if value is None else str(value) for key, value in variables.items()}
    prompt_template = Template(template)
    content = prompt_template.safe_substitute(kwargs)
    return content
