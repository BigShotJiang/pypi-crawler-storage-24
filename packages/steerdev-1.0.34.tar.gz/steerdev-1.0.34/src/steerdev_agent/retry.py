"""Retry utilities for failed task execution, powered by tenacity."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from loguru import logger
from rich.console import Console
from tenacity import (
    RetryCallState,
    RetryError,
    retry,
    retry_if_result,
    stop_after_attempt,
    wait_exponential,
    wait_fixed,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from steerdev_agent.config.models import RetryConfig

console = Console()

# Standard logging logger for tenacity's before_sleep_log
_tenacity_logger = logging.getLogger("steerdev_agent.retry")


def _is_failure(result: dict[str, Any]) -> bool:
    """Check if an execution result is a failure (tenacity retry_if_result predicate)."""
    return not result.get("success", False)


def _log_before_retry(retry_state: RetryCallState) -> None:
    """Log a message before each retry attempt."""
    attempt = retry_state.attempt_number
    outcome = retry_state.outcome
    next_wait = retry_state.next_action.sleep if retry_state.next_action else 0  # type: ignore[union-attr]

    error_info = ""
    if outcome and not outcome.cancelled():
        try:
            result = outcome.result()
            error_info = f" Error: {result.get('error', 'Unknown')}"
        except Exception:
            pass

    logger.warning(f"Task failed on attempt {attempt}.{error_info} Retrying in {next_wait:.0f}s...")
    console.print(
        f"[yellow]Attempt {attempt} failed.{error_info} Retrying in {next_wait:.0f}s...[/yellow]"
    )


async def execute_with_retry(
    execute_fn: Callable[[], Awaitable[dict[str, Any]]],
    retry_config: RetryConfig,
    task_description: str = "task",
) -> dict[str, Any]:
    """Execute a function with tenacity-based retry on failure.

    If retry is disabled or max_retries is 0, calls execute_fn once and returns.
    Otherwise, retries up to max_retries times with the configured wait strategy.

    Args:
        execute_fn: Async callable that returns a dict with at least a "success" key.
        retry_config: Retry configuration.
        task_description: Human-readable description for logging.

    Returns:
        The result dict from execute_fn (last attempt).
    """
    if not retry_config.enabled or retry_config.max_retries <= 0:
        return await execute_fn()

    # Build wait strategy from config
    if retry_config.backoff_multiplier > 1.0:
        wait = wait_exponential(
            multiplier=retry_config.delay_seconds,
            exp_base=retry_config.backoff_multiplier,
            max=retry_config.max_delay_seconds,
        )
    else:
        wait = wait_fixed(retry_config.delay_seconds)

    @retry(
        retry=retry_if_result(_is_failure),
        stop=stop_after_attempt(1 + retry_config.max_retries),
        wait=wait,
        before_sleep=_log_before_retry,
        reraise=True,
    )
    async def _execute_with_retry() -> dict[str, Any]:
        return await execute_fn()

    logger.info(
        f"Executing '{task_description}' with retry (max {retry_config.max_retries} retries)"
    )
    try:
        return await _execute_with_retry()
    except RetryError as e:
        # All retries exhausted — return the last result
        logger.warning(f"All {retry_config.max_retries} retries exhausted for '{task_description}'")
        return e.last_attempt.result()
