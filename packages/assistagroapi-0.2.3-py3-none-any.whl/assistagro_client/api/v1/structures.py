"""Structures API endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from uuid import UUID

from pydantic import BaseModel

if TYPE_CHECKING:
    from .client import AssistAgroClient


class Structure(BaseModel):
    model_config = {"populate_by_name": True, "extra": "ignore"}

    structure_guid: UUID
    structure_ext_id: str | None = None
    name: str
    company_guid: UUID | None = None
    area_fact_hectare: float | None = None
    superfield_count: int | None = None
    region_id: int | None = None
    structure_parent_guid: UUID | None = None
    structure_parent_ext_id: str | None = None
    inn: str | None = None
    active_flag: bool = True


class StructuresAPI:
    """Structures API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def list_(self) -> list[Structure]:
        """List structures."""
        response = await self._client.get("/structures/list")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        if isinstance(data, dict) and "structures" in data:
            structures_data = data["structures"]
        else:
            structures_data = data if data else []
        return (
            [Structure(**item) for item in structures_data] if structures_data else []
        )
