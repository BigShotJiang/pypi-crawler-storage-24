"""Techmaps API endpoints."""

from __future__ import annotations

from datetime import date, datetime
from typing import TYPE_CHECKING
from uuid import UUID

from pydantic import BaseModel

if TYPE_CHECKING:
    from .client import AssistAgroClient


class TechmapOperation(BaseModel):
    model_config = {"populate_by_name": True, "extra": "ignore"}

    techoperation_guid: UUID | None = None
    begin_date: date | None = None
    end_date: date | None = None
    name: str | None = None


class Techmap(BaseModel):
    model_config = {"populate_by_name": True, "extra": "ignore"}

    guid: UUID | None = None
    season_id: int | None = None
    crop_id: int | None = None
    structure_guid: UUID | None = None
    name: str | None = None
    technology: str | None = None
    techoperations: list[TechmapOperation] | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class TechmapCreateRequest(BaseModel):
    season_id: int
    crop_id: int
    structure_guid: UUID
    name: str
    technology: str | None = None
    techoperations: list[dict]


class TechmapsAPI:
    """Techmaps API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def create(
        self,
        season_id: int,
        crop_id: int,
        structure_guid: UUID,
        name: str,
        techoperations: list[dict],
        technology: str | None = None,
    ) -> Techmap:
        """Create a techmap."""
        response = await self._client.post(
            "/techmaps",
            json={
                "season_id": season_id,
                "crop_id": crop_id,
                "structure_guid": str(structure_guid),
                "name": name,
                "technology": technology,
                "techoperations": techoperations,
            },
        )
        response.raise_for_status()
        return Techmap(**response.json())

    async def list_(
        self,
        structure_guids: list[UUID],
        season_id: int,
    ) -> list[Techmap]:
        """List techmaps for given structure and season.

        Args:
            structure_guids: List of structure GUIDs (required, must have at least 1).
            season_id: Season ID (required).
        """
        response = await self._client.get(
            "/techmaps/list",
            params={
                "structure_guids": ",".join(str(g) for g in structure_guids),
                "season_id": season_id,
            },
        )
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        return [Techmap(**item) for item in data] if data else []

    async def get(self, techmap_guid: UUID) -> Techmap:
        """Get techmap by GUID."""
        response = await self._client.get(f"/techmaps/{techmap_guid}")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        return Techmap(**data) if data else None
