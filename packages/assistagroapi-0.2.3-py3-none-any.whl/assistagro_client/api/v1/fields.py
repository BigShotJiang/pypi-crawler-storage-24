"""Fields API endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID

from pydantic import BaseModel

if TYPE_CHECKING:
    from .client import AssistAgroClient


class FieldContour(BaseModel):
    model_config = {"populate_by_name": True, "extra": "ignore"}

    contour_guid: UUID | None = None
    field_guid: UUID | None = None
    superfield_guid: UUID | None = None
    contour: str | None = None
    area_fact_hectare: float | None = None
    area_etalon_hectare: float | None = None
    start_datetime: datetime | None = None
    author_guid: UUID | None = None
    editor_guid: UUID | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class FieldListItem(BaseModel):
    model_config = {"populate_by_name": True, "extra": "ignore"}

    field_guid: UUID | None = None
    field_ext_id: str | None = None
    field_name: str | None = None
    company_guid: UUID | None = None
    area_fact_hectare: float | None = None
    area_etalon_hectare: float | None = None


class FieldsAPI:
    """Fields API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def get_contours(
        self,
        field_guid: UUID,
        season_id: int,
    ) -> list[FieldContour]:
        """Get field contours for given season."""
        response = await self._client.get(
            "/fields/contours",
            params={
                "field_guid": str(field_guid),
                "season_id": season_id,
            },
        )
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        if isinstance(data, list):
            return [FieldContour(**item) for item in data if isinstance(item, dict)]
        return []

    async def list_(
        self,
        structure_guids: list[UUID],
        season_id: int | None = None,
    ) -> list[FieldListItem]:
        """List fields for given structure and season.

        Args:
            structure_guids: List of structure GUIDs.
            season_id: Season ID (integer, e.g., 1, 2, 3...).
        """
        if season_id is None:
            raise ValueError("season_id is required")

        params: dict[str, Any] = {
            "season_id": season_id,
            "structure_guid": ",".join(str(g) for g in structure_guids),
        }

        response = await self._client.get(
            "/fields/list",
            params=params,
            headers={"x-external-id": "true"},
        )
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        if isinstance(data, list):
            return [FieldListItem(**item) for item in data if isinstance(item, dict)]
        return []

    async def list_meta(self) -> dict:
        """List fields with metadata."""
        response = await self._client.get("/fields/list_meta")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        return data if data else {}
