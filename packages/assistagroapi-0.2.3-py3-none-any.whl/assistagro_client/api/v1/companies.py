"""Companies API endpoints."""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING
from uuid import UUID

from pydantic import BaseModel, ConfigDict

if TYPE_CHECKING:
    from .client import AssistAgroClient


class License(BaseModel):
    begin_date: date
    end_date: date
    modules: list[int]


class Company(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    company_guid: UUID
    company_ext_id: str | None = None
    name: str | None = None
    inn: str | None = None
    user_count: int = 0
    active_flag: bool = True
    license: License | None = None


class CompaniesAPI:
    """Companies API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def list_(self) -> list[Company]:
        """Get current user's company.

        Returns the company associated with the authenticated user.
        """
        response = await self._client.get("/account/users/current")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        if isinstance(data, dict) and "company" in data:
            company_data = data["company"]
            return [Company(**company_data)] if company_data else []
        return []
