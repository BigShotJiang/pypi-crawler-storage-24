"""Meteostations API endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import UUID

from pydantic import BaseModel

if TYPE_CHECKING:
    from .client import AssistAgroClient


class Meteostation(BaseModel):
    model_config = {"populate_by_name": True, "extra": "ignore"}

    guid: UUID
    name: str
    latitude: float | None = None
    longitude: float | None = None


class MeteostationsAPI:
    """Meteostations API endpoints."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def list_(self) -> list[Meteostation]:
        """List all meteostations."""
        response = await self._client.get("/meteostations")
        response.raise_for_status()
        data = self._client._parse_json_response(response)
        return [Meteostation(**item) for item in data] if data else []
