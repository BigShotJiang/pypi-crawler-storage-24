"""Authentication module."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from .client import AssistAgroClient

from .exceptions import AuthenticationError


class SignInRequest(BaseModel):
    email: str = Field(..., min_length=7, max_length=255)
    password: str = Field(..., min_length=12, max_length=255)


class OTPResponse(BaseModel):
    session_guid: str
    attempts: int
    max_attempts: int
    expires_at: datetime
    next_request_available_at: datetime
    code_request: int
    max_code_request: int


class AuthTokens(BaseModel):
    access_token: str
    access_token_expires_in: float
    refresh_token: str
    refresh_token_expires_in: float
    superset_token: str | None = None
    superset_token_expires_in: float | None = None


class RefreshTokensRequest(BaseModel):
    refresh_token: str


class Auth:
    """Authentication handler."""

    def __init__(self, client: AssistAgroClient):
        self._client = client

    async def sign_in(self, email: str, password: str) -> AuthTokens | OTPResponse:
        """Sign in with email and password.

        Returns AuthTokens if 2FA is disabled, OTPResponse if enabled.
        """
        response = await self._client.post(
            "/account/sign_in",
            json={"email": email, "password": password},
        )
        if response.status_code == 401:
            raise AuthenticationError("Invalid email or password")
        response.raise_for_status()
        data = response.json()
        if "session_guid" in data:
            return OTPResponse(**data)
        tokens = AuthTokens(**data)
        self._client.set_auth_tokens(tokens)
        return tokens

    async def confirm_otp(self, session_guid: str, code: str) -> AuthTokens:
        """Confirm OTP code."""
        response = await self._client.post(
            "/account/otp/validation",
            json={"session_guid": session_guid, "code": code},
        )
        if response.status_code == 401:
            raise AuthenticationError("Invalid OTP code")
        response.raise_for_status()
        tokens = AuthTokens(**response.json())
        self._client.set_auth_tokens(tokens)
        return tokens

    async def refresh_tokens(self, refresh_token: str) -> AuthTokens:
        """Refresh access token."""
        response = await self._client.post(
            "/account/refresh_tokens",
            json={"refresh_token": refresh_token},
        )
        if response.status_code == 401:
            raise AuthenticationError("Invalid refresh token")
        response.raise_for_status()
        tokens = AuthTokens(**response.json())
        self._client.set_auth_tokens(tokens)
        return tokens

    async def logout(self) -> None:
        """Log out and invalidate tokens."""
        await self._client.post("/account/logout")
        self._client.token = None
        self._client.set_user_data({})
        self._client.set_permissions([])
