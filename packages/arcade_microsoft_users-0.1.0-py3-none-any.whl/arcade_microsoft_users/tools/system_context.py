from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.metadata import (
    Behavior,
    Operation,
    ToolMetadata,
)

from arcade_microsoft_users.client import get_client
from arcade_microsoft_users.who_am_i_util import WhoAmIResponse, build_who_am_i_response


@tool(
    requires_auth=Microsoft(scopes=["User.Read"]),
    metadata=ToolMetadata(
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def who_am_i(
    context: Context,
) -> Annotated[
    WhoAmIResponse,
    "Get comprehensive user profile information for the signed-in user.",
]:
    """
    Get information about the current user including name, email, job title,
    department, office location, and tenant domain.
    """
    client = get_client(context.get_auth_token_or_empty())
    return await build_who_am_i_response(client)
