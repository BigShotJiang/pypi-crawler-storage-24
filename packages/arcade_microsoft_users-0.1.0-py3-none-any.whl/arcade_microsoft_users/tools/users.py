import urllib.parse
from typing import Annotated, Any, cast

import httpx
from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Operation,
    ToolMetadata,
)
from kiota_abstractions.api_error import APIError
from msgraph.generated.users.item.direct_reports.direct_reports_request_builder import (
    DirectReportsRequestBuilder,
)
from msgraph.generated.users.item.manager.manager_request_builder import ManagerRequestBuilder

from arcade_microsoft_users._sanitize import (
    escape_odata_string,
    resolve_user_id,
    try_resolve_user,
    validate_pagination_url,
)
from arcade_microsoft_users.client import get_client
from arcade_microsoft_users.constants import (
    GRAPH_BASE_URL,
    USER_SELECT,
    USER_SELECT_FIELDS,
)
from arcade_microsoft_users.models import (
    UserProfile,
    serialize_directory_object,
)


@tool(
    requires_auth=Microsoft(scopes=["User.Read.All"]),
    metadata=ToolMetadata(
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_user_profile(
    context: Context,
    user_identifiers: Annotated[
        list[str],
        "One or more email addresses, user principal names (UPNs), or Microsoft user IDs "
        "to look up. Email address is the most common identifier — use it when enriching "
        "calendar attendees or email participants. Max 20 per call.",
    ],
) -> Annotated[
    dict, "Profiles for each resolved user, plus any identifiers that could not be found"
]:
    """Look up one or more users by email address, UPN, or user ID.

    Accepts a list of identifiers and automatically optimizes between single
    and batch Graph API calls. Use this to enrich calendar attendees or email
    participants with job titles, departments, and org data.

    Requires a Microsoft 365 work or school account. Not available for
    personal Microsoft accounts (outlook.com, hotmail.com, live.com).
    """
    if not user_identifiers:
        raise ToolExecutionError("user_identifiers must contain at least one identifier.")
    if len(user_identifiers) > 20:
        raise ToolExecutionError(
            f"Too many identifiers ({len(user_identifiers)}). "
            "Maximum is 20 per call. Split into multiple calls."
        )

    token = context.get_auth_token_or_empty()

    if len(user_identifiers) == 1:
        profiles, not_found = await _resolve_single_profile(token, user_identifiers[0])
    else:
        profiles, not_found = await _batch_resolve_profiles(token, user_identifiers)

    return {
        "count": len(profiles),
        "profiles": profiles,
        "not_found": not_found,
        "not_found_count": len(not_found),
    }


async def _resolve_single_profile(
    token: str,
    user_identifier: str,
) -> tuple[list[dict[str, Any]], list[str]]:
    """Resolve a single user identifier using the SDK. Returns (profiles, not_found)."""
    client = get_client(token)
    user = await try_resolve_user(client, user_identifier)
    if user:
        profile = UserProfile.from_sdk(user).to_dict()
        profile["input_identifier"] = user_identifier
        return [profile], []
    return [], [user_identifier]


async def _batch_resolve_profiles(  # noqa: C901
    token: str,
    user_identifiers: list[str],
) -> tuple[list[dict[str, Any]], list[str]]:
    """
    Batch resolve multiple user identifiers via Graph $batch endpoint.

    Two-round strategy (at most 2 HTTP calls):
    - Round 1: Path-based lookups (/users/{identifier}) for all identifiers
    - Round 2: $filter fallback (mail eq '...') for any 404s from Round 1
    """
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=httpx.Timeout(30.0)) as http_client:
        # Round 1: path-based lookups
        round1_requests = []
        for i, identifier in enumerate(user_identifiers):
            encoded = urllib.parse.quote(identifier, safe="@.-_")
            round1_requests.append({
                "id": str(i),
                "method": "GET",
                "url": f"/users/{encoded}?$select={USER_SELECT}",
            })

        round1_response = await _post_batch(http_client, headers, round1_requests)

        found: dict[str, dict[str, Any]] = {}
        not_found_in_r1: list[tuple[int, str]] = []
        infra_errors: list[str] = []

        for sub_resp in round1_response.get("responses", []):
            idx = int(sub_resp["id"])
            identifier = user_identifiers[idx]
            status = sub_resp.get("status", 0)
            if status == 200:
                profile = UserProfile.from_graph_json(sub_resp.get("body", {})).to_dict()
                profile["input_identifier"] = identifier
                found[identifier] = profile
            elif status == 404:
                not_found_in_r1.append((idx, identifier))
            else:
                infra_errors.append(_format_subresp_error(identifier, sub_resp))

        if infra_errors:
            raise ToolExecutionError(
                "Graph API batch request had infrastructure failures:\n" + "\n".join(infra_errors)
            )

        # Round 2: $filter fallback for identifiers not found in Round 1
        not_found_identifiers: list[str] = []
        if not_found_in_r1:
            round2_requests = []
            for i, (_, identifier) in enumerate(not_found_in_r1):
                escaped = escape_odata_string(identifier)
                filter_expr = urllib.parse.quote(f"mail eq '{escaped}'", safe="")
                select_expr = urllib.parse.quote(USER_SELECT, safe=",")
                round2_requests.append({
                    "id": str(i),
                    "method": "GET",
                    "url": f"/users?$filter={filter_expr}&$select={select_expr}",
                })

            round2_response = await _post_batch(http_client, headers, round2_requests)

            for sub_resp in round2_response.get("responses", []):
                idx = int(sub_resp["id"])
                _, identifier = not_found_in_r1[idx]
                status = sub_resp.get("status", 0)
                if status == 200:
                    # Round 2 returns collections: {"value": [...]}
                    values = sub_resp.get("body", {}).get("value", [])
                    if values:
                        profile = UserProfile.from_graph_json(values[0]).to_dict()
                        profile["input_identifier"] = identifier
                        found[identifier] = profile
                    else:
                        not_found_identifiers.append(identifier)
                else:
                    infra_errors.append(_format_subresp_error(identifier, sub_resp))

            if infra_errors:
                raise ToolExecutionError(
                    "Graph API batch request had infrastructure failures:\n"
                    + "\n".join(infra_errors)
                )

    return list(found.values()), not_found_identifiers


def _format_subresp_error(identifier: str, sub_resp: dict[str, Any]) -> str:
    """Format a batch sub-response error into a human-readable line."""
    status = sub_resp.get("status", "unknown")
    body = sub_resp.get("body", {})
    error = body.get("error", {}) if isinstance(body, dict) else {}
    code = error.get("code", "")
    message = error.get("message", "")
    detail = f" ({code}: {message})" if code or message else ""
    return f"  - '{identifier}': HTTP {status}{detail}"


async def _post_batch(
    http_client: httpx.AsyncClient,
    headers: dict[str, str],
    requests: list[dict[str, Any]],
) -> dict[str, Any]:
    """Post a batch request to the Graph API $batch endpoint."""
    try:
        response = await http_client.post(
            f"{GRAPH_BASE_URL}/$batch",
            headers=headers,
            json={"requests": requests},
        )
    except httpx.HTTPError as e:
        raise ToolExecutionError(f"Graph API batch request failed: {type(e).__name__}: {e}") from e
    if response.status_code != 200:
        raise ToolExecutionError(
            f"Graph API batch request failed with status {response.status_code}: {response.text}"
        )
    return cast(dict[str, Any], response.json())


@tool(
    requires_auth=Microsoft(scopes=["User.Read.All"]),
    metadata=ToolMetadata(
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_user_manager(
    context: Context,
    user_identifier: Annotated[
        str,
        "The user's email address, UPN, or Microsoft user ID. "
        "Use the email address from a calendar attendee or email participant.",
    ],
) -> Annotated[
    dict, "The manager's profile including name, job title, department, and contact info"
]:
    """Get a user's direct manager from the organizational hierarchy.

    Returns the manager's profile data. If the user has no manager (e.g.,
    top-level executives), returns a response indicating no manager was found.

    Requires a Microsoft 365 work or school account. Not available for
    personal Microsoft accounts (outlook.com, hotmail.com, live.com).
    """
    client = get_client(context.get_auth_token_or_empty())
    user_id, _ = await resolve_user_id(client, user_identifier)

    try:
        query_params = ManagerRequestBuilder.ManagerRequestBuilderGetQueryParameters(
            select=USER_SELECT_FIELDS,
        )
        request_config = ManagerRequestBuilder.ManagerRequestBuilderGetRequestConfiguration(
            query_parameters=query_params,
        )
        manager = await client.users.by_user_id(user_id).manager.get(
            request_configuration=request_config,
        )
    except APIError as e:
        if e.response_status_code == 404:
            return {"has_manager": False, "user_identifier": user_identifier}
        raise

    if not manager:
        return {"has_manager": False, "user_identifier": user_identifier}

    return {
        "has_manager": True,
        "manager": serialize_directory_object(manager),
    }


@tool(
    requires_auth=Microsoft(scopes=["User.Read.All"]),
    metadata=ToolMetadata(
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_direct_reports(
    context: Context,
    user_identifier: Annotated[
        str,
        "The user's email address, UPN, or Microsoft user ID.",
    ],
    limit: Annotated[
        int,
        "Maximum number of direct reports to return per page.",
    ] = 100,
    pagination_token: Annotated[
        str | None,
        "Token from a previous response to get the next page of results.",
    ] = None,
) -> Annotated[dict, "List of the user's direct reports with their profiles"]:
    """Get a user's direct reports from the organizational hierarchy.

    Returns a paginated list of users and organizational contacts who report
    directly to the specified user.

    Requires a Microsoft 365 work or school account. Not available for
    personal Microsoft accounts (outlook.com, hotmail.com, live.com).
    """
    if limit < 1 or limit > 999:
        raise ToolExecutionError("limit must be between 1 and 999.")

    client = get_client(context.get_auth_token_or_empty())

    if pagination_token:
        validate_pagination_url(pagination_token)
        result = await client.users.by_user_id("_").direct_reports.with_url(pagination_token).get()
    else:
        user_id, _ = await resolve_user_id(client, user_identifier)
        query_params = DirectReportsRequestBuilder.DirectReportsRequestBuilderGetQueryParameters(
            top=limit,
            select=USER_SELECT_FIELDS,
        )
        request_config = (
            DirectReportsRequestBuilder.DirectReportsRequestBuilderGetRequestConfiguration(
                query_parameters=query_params,
            )
        )
        result = await client.users.by_user_id(user_id).direct_reports.get(
            request_configuration=request_config,
        )

    if not result or not result.value:
        return {
            "user_identifier": user_identifier,
            "count": 0,
            "has_more": False,
            "direct_reports": [],
        }

    reports = [serialize_directory_object(obj) for obj in result.value]

    response: dict[str, Any] = {
        "user_identifier": user_identifier,
        "count": len(reports),
        "direct_reports": reports,
    }

    if result.odata_next_link:
        response["has_more"] = True
        response["pagination_token"] = result.odata_next_link
    else:
        response["has_more"] = False

    return response
