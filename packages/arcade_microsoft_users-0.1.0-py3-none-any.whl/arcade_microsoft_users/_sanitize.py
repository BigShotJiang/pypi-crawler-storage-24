from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_microsoft_utils.utils import validate_pagination_url  # noqa: F401
from kiota_abstractions.api_error import APIError
from msgraph import GraphServiceClient
from msgraph.generated.models.user import User
from msgraph.generated.users.item.user_item_request_builder import UserItemRequestBuilder
from msgraph.generated.users.users_request_builder import UsersRequestBuilder

from arcade_microsoft_users.constants import USER_SELECT_FIELDS


def escape_odata_string(value: str) -> str:
    """Escape a string for use inside OData single-quoted literals."""
    return value.replace("'", "''")


async def try_resolve_user(
    client: GraphServiceClient,
    user_identifier: str,
) -> User | None:
    """
    Try to resolve an email/UPN/ID to a User object.

    Returns None if the user cannot be found. Non-404 APIErrors propagate
    to the MicrosoftGraphErrorAdaptor for automatic conversion.

    Strategy:
    1. GET /users/{user_identifier}?$select=...  (fast path for UPN and UUID)
    2. GET /users?$filter=mail eq '...'&$select=...  (fallback for email != UPN)
    """
    try:
        query_params = UserItemRequestBuilder.UserItemRequestBuilderGetQueryParameters(
            select=USER_SELECT_FIELDS,
        )
        request_config = UserItemRequestBuilder.UserItemRequestBuilderGetRequestConfiguration(
            query_parameters=query_params,
        )
        user = await client.users.by_user_id(user_identifier).get(
            request_configuration=request_config,
        )
        if user and user.id:
            return user
    except APIError as e:
        if e.response_status_code != 404:
            raise

    escaped = escape_odata_string(user_identifier)
    query_params_filter = UsersRequestBuilder.UsersRequestBuilderGetQueryParameters(
        filter=f"mail eq '{escaped}'",
        select=USER_SELECT_FIELDS,
    )
    request_config_filter = UsersRequestBuilder.UsersRequestBuilderGetRequestConfiguration(
        query_parameters=query_params_filter,
    )
    result = await client.users.get(request_configuration=request_config_filter)
    if result and result.value and len(result.value) > 0:
        return result.value[0]

    return None


async def resolve_user_id(
    client: GraphServiceClient,
    user_identifier: str,
) -> tuple[str, User]:
    """
    Resolve an email/UPN/ID to a (user_id, User) tuple.

    Raises ToolExecutionError if the user cannot be found.
    """
    user = await try_resolve_user(client, user_identifier)
    if not user or not user.id:
        raise ToolExecutionError(
            f"No user found for '{user_identifier}'. "
            "Verify the email address or user ID is correct."
        )
    return (user.id, user)
