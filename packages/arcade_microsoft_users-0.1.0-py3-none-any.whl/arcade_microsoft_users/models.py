from dataclasses import dataclass, field
from typing import Any, cast

from msgraph.generated.models.directory_object import DirectoryObject
from msgraph.generated.models.org_contact import OrgContact
from msgraph.generated.models.user import User


@dataclass
class UserProfile:
    """A user profile from Microsoft Entra ID (Azure AD)."""

    user_id: str = ""
    display_name: str = ""
    given_name: str = ""
    surname: str = ""
    mail: str = ""
    user_principal_name: str = ""
    job_title: str = ""
    department: str = ""
    company_name: str = ""
    office_location: str = ""
    employee_id: str = ""
    mobile_phone: str = ""
    business_phones: list[str] = field(default_factory=list)
    account_enabled: bool | None = None

    @classmethod
    def from_sdk(cls, user: User) -> "UserProfile":
        """Convert from msgraph User SDK object."""
        return cls(
            user_id=user.id or "",
            display_name=user.display_name or "",
            given_name=user.given_name or "",
            surname=user.surname or "",
            mail=user.mail or "",
            user_principal_name=user.user_principal_name or "",
            job_title=user.job_title or "",
            department=user.department or "",
            company_name=user.company_name or "",
            office_location=user.office_location or "",
            employee_id=user.employee_id or "",
            mobile_phone=user.mobile_phone or "",
            business_phones=list(user.business_phones) if user.business_phones else [],
            account_enabled=user.account_enabled,
        )

    @classmethod
    def from_graph_json(cls, data: dict[str, Any]) -> "UserProfile":
        """Convert from raw Graph API JSON response (camelCase keys)."""
        return cls(
            user_id=data.get("id") or "",
            display_name=data.get("displayName") or "",
            given_name=data.get("givenName") or "",
            surname=data.get("surname") or "",
            mail=data.get("mail") or "",
            user_principal_name=data.get("userPrincipalName") or "",
            job_title=data.get("jobTitle") or "",
            department=data.get("department") or "",
            company_name=data.get("companyName") or "",
            office_location=data.get("officeLocation") or "",
            employee_id=data.get("employeeId") or "",
            mobile_phone=data.get("mobilePhone") or "",
            business_phones=data.get("businessPhones") or [],
            account_enabled=data.get("accountEnabled"),
        )

    def to_dict(self) -> dict[str, Any]:  # noqa: C901
        """Serialize to dict, omitting empty/None fields. Includes 'object_type': 'user'."""
        result: dict[str, Any] = {"object_type": "user"}
        if self.user_id:
            result["user_id"] = self.user_id
        if self.display_name:
            result["display_name"] = self.display_name
        if self.given_name:
            result["given_name"] = self.given_name
        if self.surname:
            result["surname"] = self.surname
        if self.mail:
            result["mail"] = self.mail
        if self.user_principal_name:
            result["user_principal_name"] = self.user_principal_name
        if self.job_title:
            result["job_title"] = self.job_title
        if self.department:
            result["department"] = self.department
        if self.company_name:
            result["company_name"] = self.company_name
        if self.office_location:
            result["office_location"] = self.office_location
        if self.employee_id:
            result["employee_id"] = self.employee_id
        if self.mobile_phone:
            result["mobile_phone"] = self.mobile_phone
        if self.business_phones:
            result["business_phones"] = self.business_phones
        if self.account_enabled is not None:
            result["account_enabled"] = self.account_enabled
        return result


def serialize_directory_object(obj: DirectoryObject) -> dict[str, Any]:
    """
    Serialize a directoryObject based on its @odata.type discriminator.

    Returns a UserProfile.to_dict() for User objects, or a minimal dict
    for orgContact and unknown types.
    """
    odata_type = getattr(obj, "odata_type", None) or ""

    if "#microsoft.graph.user" in odata_type:
        return UserProfile.from_sdk(cast(User, obj)).to_dict()

    if "#microsoft.graph.orgContact" in odata_type:
        contact = cast(OrgContact, obj)
        result: dict[str, Any] = {"object_type": "org_contact"}
        if contact.id:
            result["id"] = contact.id
        if contact.display_name:
            result["display_name"] = contact.display_name
        if contact.mail:
            result["mail"] = contact.mail
        if contact.job_title:
            result["job_title"] = contact.job_title
        if contact.department:
            result["department"] = contact.department
        if contact.company_name:
            result["company_name"] = contact.company_name
        return result

    # Unknown type — return what we can
    result = {"object_type": odata_type.split(".")[-1] if odata_type else "unknown"}
    if obj.id:
        result["id"] = obj.id
    return result
