from typing import Any, TypedDict, cast

from msgraph import GraphServiceClient
from msgraph.generated.users.item.user_item_request_builder import UserItemRequestBuilder

from arcade_microsoft_users.constants import USER_SELECT_FIELDS

_WHO_AM_I_FIELDS: list[str] = [
    *USER_SELECT_FIELDS,
    "preferredLanguage",
]


class WhoAmIResponse(TypedDict, total=False):
    user_id: str
    display_name: str
    given_name: str
    surname: str
    user_principal_name: str
    mail: str
    job_title: str
    department: str
    company_name: str
    office_location: str
    employee_id: str
    business_phones: list[str]
    mobile_phone: str
    preferred_language: str
    tenant_domain: str
    account_enabled: bool


async def build_who_am_i_response(client: GraphServiceClient) -> WhoAmIResponse:
    """Fetch the signed-in user's profile and return it as a WhoAmIResponse."""
    query_params = UserItemRequestBuilder.UserItemRequestBuilderGetQueryParameters(
        select=_WHO_AM_I_FIELDS,
    )
    request_config = UserItemRequestBuilder.UserItemRequestBuilderGetRequestConfiguration(
        query_parameters=query_params,
    )
    response = await client.me.get(request_configuration=request_config)

    if not response:
        return cast(WhoAmIResponse, {})

    data: dict[str, Any] = {}

    if response.id:
        data["user_id"] = response.id
    for attr, key in [
        ("display_name", "display_name"),
        ("given_name", "given_name"),
        ("surname", "surname"),
        ("user_principal_name", "user_principal_name"),
        ("mail", "mail"),
        ("job_title", "job_title"),
        ("department", "department"),
        ("company_name", "company_name"),
        ("office_location", "office_location"),
        ("employee_id", "employee_id"),
        ("mobile_phone", "mobile_phone"),
        ("preferred_language", "preferred_language"),
    ]:
        value = getattr(response, attr, None)
        if value:
            data[key] = value

    if response.business_phones:
        data["business_phones"] = list(response.business_phones)

    if response.account_enabled is not None:
        data["account_enabled"] = bool(response.account_enabled)

    upn = data.get("user_principal_name", "")
    if isinstance(upn, str) and "@" in upn:
        domain = upn.split("@", 1)[1]
        if domain:
            data["tenant_domain"] = domain

    return cast(WhoAmIResponse, data)
