import sys
from typing import cast

from arcade_mcp_server import MCPApp
from arcade_mcp_server.mcp_app import TransportType

import arcade_microsoft_users

app = MCPApp(
    name="MicrosoftUsers",
    instructions=(
        "Use this server when you need to look up user profiles, organizational hierarchy, "
        "or enrich calendar attendees and email participants with job titles, departments, "
        "and reporting chains from the Microsoft corporate directory. "
        "Requires a Microsoft 365 work or school account — directory lookup tools are not "
        "available for personal Microsoft accounts (outlook.com, hotmail.com, live.com)."
    ),
)

app.add_tools_from_module(arcade_microsoft_users)


def main() -> None:
    transport = sys.argv[1] if len(sys.argv) > 1 else "stdio"
    host = sys.argv[2] if len(sys.argv) > 2 else "127.0.0.1"
    port = int(sys.argv[3]) if len(sys.argv) > 3 else 8000

    app.run(transport=cast(TransportType, transport), host=host, port=port)


if __name__ == "__main__":
    main()
