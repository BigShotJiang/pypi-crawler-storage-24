GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"

USER_SELECT_FIELDS = [
    "id",
    "displayName",
    "givenName",
    "surname",
    "mail",
    "userPrincipalName",
    "jobTitle",
    "department",
    "companyName",
    "officeLocation",
    "employeeId",
    "mobilePhone",
    "businessPhones",
    "accountEnabled",
]

USER_SELECT = ",".join(USER_SELECT_FIELDS)
