
__all__ = ['InputFeature', 'OutputFeature']

_VALID_FEATURE_TYPES = {'category', 'numeric', 'text', 'longtext'}


class InputFeature(object):

    def __init__(self, feature_name, feature_type):
        if feature_type not in _VALID_FEATURE_TYPES:
            raise ValueError(
                "feature_type {!r} is not valid. Must be one of: {}".format(
                    feature_type, sorted(_VALID_FEATURE_TYPES)))
        self.feature_name = feature_name
        self.feature_type = feature_type
        self.classes = None


class OutputFeature(object):

    def __init__(self, feature_name, child_feature=None):
        self.feature_name = feature_name
        self.child_feature = child_feature
