from setuptools import setup
from setuptools import find_packages
import os

# Single source of truth for the version number.
here = os.path.abspath(os.path.dirname(__file__))
version = {}
with open(os.path.join(here, 'pwml', '__init__.py')) as f:
    for line in f:
        if line.startswith('__version__'):
            exec(line, version)
            break

long_description = '''
Pwml is a high-level machine learning API, written in Python.
Pwml stands for Python Wrappers for Machine Learning.
Pwml is compatible with Python 3.8+ and is distributed under the MIT license.
'''

setup(
    name='pwml',
    version=version['__version__'],
    description='Python Wrappers for Machine Learning',
    long_description=long_description,
    author='Benjamin Raibaud',
    author_email='braibaud@gmail.com',
    url='https://github.com/braibaud/pwml',
    license='MIT',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Intended Audience :: Education',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Software Development :: Libraries',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Scientific/Engineering :: Artificial Intelligence'
    ],
    install_requires=[
        'numpy>=1.20.0,<3',
        'pillow>=8.0.0,<12',
        'pandas>=1.3.0,<3',
        'urllib3>=1.26.0,<3',
        'scikit-learn>=1.2.0,<2',
        'scipy>=1.7.0,<2',
        'joblib>=1.1.0,<2',
        'matplotlib>=3.5.0,<4',
        'seaborn>=0.13.0,<1',
        'sentence-transformers>=2.2.0,<4',
    ],
    extras_require={
        'timeseries': [
            'prophet>=1.1,<2',
            'statsmodels>=0.13.0,<1',
        ],
        'neptune': [
            'neptune>=3.0,<4',
        ],
        'mssql': [
            'pymssql>=2.2.0,<3',
        ],
        'all': [
            'prophet>=1.1,<2',
            'statsmodels>=0.13.0,<1',
            'neptune>=3.0,<4',
            'pymssql>=2.2.0,<3',
        ],
    },
    python_requires='>=3.8',
    packages=find_packages())
