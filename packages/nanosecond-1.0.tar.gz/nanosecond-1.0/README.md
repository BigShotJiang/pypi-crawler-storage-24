# Nanosecond v1.0
High-precision time library for perfect timings and time management.
## Functions:
```
nanosecond
├── sleep(sec)
│   └── High-precision sleep function
├── waitDo(func, sec)
│   └── Waiting and running function in another 
│       thread, perfect for timings
├── schedule(func, sec, daemon=True)
│   ├── Schedule an action after a specified time. 
│   │   Doesn't block the thread
│   ├── cancel()
│   │   └── Cancel scheduled action
│   ├── skip()
│   │   └── Do scheduled action now
│   ├── setTime()
│   │   └── Change scheduled time
│   └── Get remaining time
└── createPoint()
    ├── getPoint()
    │   └── Returns UNIX datestamp point create date
    ├── placePoint()
    │   └── Changes point create time to current
    ├── elapsed()
    │   └── Return diff of current time and point 
    │       create time in seconds
    └── elapsedFloat()
        └── Return diff of current time and point 
            create time in float seconds
```

## How to install:
- First, upgrade pip:
### Windows:
```batch
python -m pip install --upgrade pip
```
### MacOS/Linux:
```bash
pip3 install --upgrade pip
```
- Nanosecond package doesn't require dependencies, so you can install it without installing them:
### Windows:
```batch
pip install nanosecond
```
### MacOS/Linux:
```bash
pip3 install nanosecond
```
- Congratulations! Nanosecond was installed.
## How to use & Examples:
- First, import:
```python
import nanosecond
```
- Let's try to sleep:
```python
import nanosecond

nanosecond.sleep(1.5)
print("✅ Done!")
```
- Making infinite cycle:
```python
import nanosecond

while True:
    nanosecond.sleep(1.5)
    print("✅ It works!")
```
- Now we are going to use waitDo function. It waits and starting function in new thread:
```python
import nanosecond

nanosecond.waitDo(lambda:print("Hello world!🌍"), 2) # Waiting 2 seconds and printing
```
- Schedule function is literally scheduling your function, like waitDo but without blocking main thread:
```python
import nanosecond

nanosecond.schedule(lambda:print("It will appear in few seconds ⌚"), 1) # Schedule print in 1 second
print("I am first 😎")
```
Output looks like:
```
I am first 😎
It will appear in few seconds ⌚
Process finished with exit code 0
```
You can also skip or cancel this schedule using:
```python
.schedule(...).skip() # Executes a function without waiting
```
- Last function - createPoint. It creates time point for comparisons:
```python
import nanosecond

point = nanosecond.createPoint()

def printElapsed():
    print(f"Elapsed {point.elapsed()}s ({point.elapsedFloat()}s or {point.elapsedNs()}ns)⌚")

point.placePoint() # Now point has got current time
printElapsed() # About few ms
nanosecond.sleep(1)
printElapsed() # ~1s

point.placePoint() # Reset it
printElapsed()
```

## End