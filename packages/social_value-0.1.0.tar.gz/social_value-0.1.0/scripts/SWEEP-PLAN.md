# OC Platform Security Sweep Plan

## The Goal

Every OC skill gets the same treatment social-value got on 2026-03-19:
1. SecretStr from nostrkey for all sensitive fields
2. Red team security audit
3. Sanitized exceptions (no secrets in tracebacks)
4. Input validation on all entry points
5. __repr__ redaction on all objects holding secrets
6. Tests proving each security property
7. Version bump + publish (PyPI + ClawHub)

## Order of Operations

Dependencies flow downward — update foundations first.

```
Phase 1: FOUNDATION
  └─ nostrkey (0.2.9 → 0.3.0)
     Add SecretStr to nostrkey.types
     All downstream skills import from here

Phase 2: NSE PILLARS (depend on nostrkey)
  ├─ nwc (0.1.3 → 0.1.4) — HIGH priority, holds NWC connection strings
  ├─ nostrcalendar (0.2.2 → 0.2.3)
  ├─ nostrsocial (0.1.2 → 0.1.3)
  └─ social-alignment (0.1.4 → 0.1.5)

Phase 3: HUJE.TOOLS (depend on nostrkey)
  ├─ sense-memory (0.1.2 → 0.1.3) — HIGH priority, holds nsec
  ├─ nostr-profile (0.1.9 → 0.2.0) — HIGH priority, holds nsec
  ├─ sense-music (0.1.4 → 0.1.5) — MEDIUM, file I/O
  ├─ social-card (0.2.0 → 0.2.1) — MEDIUM, file I/O
  ├─ sense-wonder (0.1.1 → 0.1.2) — LOW, pure data
  └─ social-value (0.1.0 → already done) — DONE

Phase 4: ORCHESTRATOR (depends on everything)
  └─ nse-orchestrator (0.2.1 → 0.2.2)
```

## Phase 1: nostrkey — Add SecretStr

This is the critical first step. All other phases depend on it.

### What to do:
1. Move `SecretStr` from `social_value.types` into `nostrkey.types`
2. Export from `nostrkey.__init__`: `from nostrkey import SecretStr`
3. Use SecretStr for nsec/seed phrase fields within nostrkey itself
4. Red team audit nostrkey (it handles the most sensitive data in the stack)
5. Bump to 0.3.0 (minor bump — new public type)
6. Publish PyPI + ClawHub

### After nostrkey 0.3.0:
- social-value removes its local SecretStr, imports from nostrkey
- All other skills import SecretStr from nostrkey
- `nostrkey>=0.3.0` becomes the minimum version for all skills

## Per-Skill Checklist

For each skill, the red team audit should check:

- [ ] **Secret handling** — All secrets wrapped in SecretStr (nsec, passphrase, API keys, connection strings)
- [ ] **Repr redaction** — `__repr__` on config/wallet/store objects never shows secrets
- [ ] **Traceback safety** — Secrets deleted from local scope before SDK calls
- [ ] **Sanitized exceptions** — Custom error class (e.g., `SenseMemoryError`) that never embeds SDK internals
- [ ] **Input validation** — All public methods validate: amounts > 0, strings non-empty, lengths capped
- [ ] **Network validation** — Network/relay values validated against allowlist, no silent wrong-network
- [ ] **Path safety** — Any file/directory paths validated (no traversal, no absolute unless explicit)
- [ ] **Logging hygiene** — Secrets never logged, destinations truncated to 8 chars
- [ ] **Resource cleanup** — `__del__` or context manager ensures cleanup
- [ ] **Tests** — Each security property has a test proving it works

## Scripts

### Bump a single package:
```bash
./scripts/bump-versions.sh ../huje.sensememory.OC-python.src 0.1.3
```
Updates pyproject.toml, __init__.py, metadata.json, SKILL.md frontmatter.

### Dry run (see current state):
```bash
./scripts/sweep-publish.sh
```

### Publish everything:
```bash
./scripts/sweep-publish.sh --all
```

## Timeline Estimate

| Phase | Effort | Priority |
|-------|--------|----------|
| Phase 1 (nostrkey) | 1 session | Do first |
| Phase 2 (NSE pillars) | 1-2 sessions | nwc is urgent, rest can follow |
| Phase 3 (huje.tools) | 1-2 sessions | sense-memory + nostr-profile first |
| Phase 4 (orchestrator) | 0.5 session | Last — just re-export and verify |

Total: ~4-5 focused sessions to sweep the entire platform.

## Done Criteria

Every package:
- Imports SecretStr from nostrkey (not local copy)
- Has a red team audit report
- Has sanitized exceptions
- Has input validation tests
- Has repr redaction tests
- Is published at bumped version on PyPI + ClawHub
