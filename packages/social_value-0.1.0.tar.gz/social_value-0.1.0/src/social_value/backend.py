"""Backend protocol — the contract that Liquid and Spark both implement."""

from __future__ import annotations

from typing import Protocol

from .types import PaymentRecord, WalletState


class Backend(Protocol):
    """Protocol for payment backends (Liquid, Spark, or future options)."""

    def connect(self, mnemonic: str, api_key: str, network: str, working_dir: str) -> None:
        """Initialize the backend and connect."""
        ...

    def disconnect(self) -> None:
        """Clean up resources."""
        ...

    def get_state(self) -> WalletState:
        """Get current wallet state."""
        ...

    def create_invoice(self, amount_sat: int, description: str) -> str:
        """Create a Lightning invoice to receive sats."""
        ...

    def send(self, destination: str, amount_sat: int, memo: str | None = None) -> str:
        """Send sats to a destination. Returns payment ID."""
        ...

    def send_drain(self, destination: str) -> tuple[int, int, str]:
        """Drain all funds to a destination. Returns (amount, fee, payment_id)."""
        ...

    def get_send_fee(self, destination: str, amount_sat: int) -> int:
        """Get the fee for a send operation without executing it."""
        ...

    def list_payments(self, limit: int, offset: int) -> tuple[PaymentRecord, ...]:
        """List recent payments."""
        ...

    @property
    def name(self) -> str:
        """Backend name for logging ('liquid' or 'spark')."""
        ...
