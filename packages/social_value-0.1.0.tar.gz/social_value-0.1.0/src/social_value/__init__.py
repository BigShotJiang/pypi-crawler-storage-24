"""social-value — Economic intelligence for sovereign AI agents.

Supports two backends:
    pip install social-value[liquid]   # Breez SDK Liquid
    pip install social-value[spark]    # Breez SDK Spark
    pip install social-value[all]      # Both
"""

from .config import SocialValueConfig
from .types import (
    BatchTransferItem,
    FeeEstimate,
    PaymentRecord,
    SecretStr,
    TransferResult,
    WalletState,
)
from .wallet import SocialValue, SocialValueError

__version__ = "0.1.0"

__all__ = [
    "BatchTransferItem",
    "FeeEstimate",
    "PaymentRecord",
    "SecretStr",
    "SocialValue",
    "SocialValueConfig",
    "SocialValueError",
    "TransferResult",
    "WalletState",
]
