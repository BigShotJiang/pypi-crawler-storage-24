"""Tests for social-value configuration — validation and secret redaction."""

import pytest

from social_value.config import SocialValueConfig
from social_value.types import SecretStr


def test_config_defaults():
    config = SocialValueConfig(breez_api_key=SecretStr("test-key"))
    assert config.backend == "liquid"
    assert config.network == "mainnet"
    assert config.working_dir == ".breez_data"
    assert config.max_balance_sat == 0


def test_config_spark():
    config = SocialValueConfig(breez_api_key=SecretStr("test-key"), backend="spark")
    assert config.backend == "spark"


def test_config_invalid_backend():
    with pytest.raises(ValueError, match="backend must be"):
        SocialValueConfig(breez_api_key=SecretStr("test-key"), backend="invalid")


def test_config_invalid_network():
    with pytest.raises(ValueError, match="network must be"):
        SocialValueConfig(breez_api_key=SecretStr("test-key"), network="mainet")


def test_config_negative_max_balance():
    with pytest.raises(ValueError, match="non-negative"):
        SocialValueConfig(breez_api_key=SecretStr("test-key"), max_balance_sat=-1)


def test_config_path_traversal():
    with pytest.raises(ValueError, match="relative path"):
        SocialValueConfig(breez_api_key=SecretStr("test-key"), working_dir="../etc/breez")


def test_config_absolute_path():
    with pytest.raises(ValueError, match="relative path"):
        SocialValueConfig(breez_api_key=SecretStr("test-key"), working_dir="/tmp/breez")


def test_config_frozen():
    config = SocialValueConfig(breez_api_key=SecretStr("test-key"))
    with pytest.raises(AttributeError):
        config.backend = "spark"


def test_config_repr_redacts_api_key():
    config = SocialValueConfig(breez_api_key=SecretStr("super-secret-key-123"))
    r = repr(config)
    assert "super-secret" not in r
    assert "***" in r


def test_config_from_env(monkeypatch):
    monkeypatch.setenv("BREEZ_API_KEY", "env-key")
    monkeypatch.setenv("SOCIAL_VALUE_BACKEND", "spark")
    monkeypatch.setenv("SOCIAL_VALUE_NETWORK", "testnet")
    monkeypatch.setenv("SOCIAL_VALUE_MAX_BALANCE", "50000")

    config = SocialValueConfig.from_env()
    assert config.breez_api_key.get_secret_value() == "env-key"
    assert config.backend == "spark"
    assert config.network == "testnet"
    assert config.max_balance_sat == 50000


def test_config_from_env_defaults(monkeypatch):
    monkeypatch.setenv("BREEZ_API_KEY", "env-key")
    monkeypatch.delenv("SOCIAL_VALUE_BACKEND", raising=False)

    config = SocialValueConfig.from_env()
    assert config.backend == "liquid"


def test_config_from_env_missing_key(monkeypatch):
    monkeypatch.delenv("BREEZ_API_KEY", raising=False)
    with pytest.raises(ValueError, match="BREEZ_API_KEY"):
        SocialValueConfig.from_env()


def test_config_from_env_bad_max_balance(monkeypatch):
    monkeypatch.setenv("BREEZ_API_KEY", "key")
    monkeypatch.setenv("SOCIAL_VALUE_MAX_BALANCE", "not-a-number")
    with pytest.raises(ValueError, match="must be a number"):
        SocialValueConfig.from_env()
