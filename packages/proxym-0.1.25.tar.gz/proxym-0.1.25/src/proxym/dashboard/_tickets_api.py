"""Tickets and sprints endpoints for dashboard API."""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from proxym.dashboard.tickets import (
    Sprint,
    SprintStatus,
    Ticket,
    TicketComment,
    TicketManager,
    TicketPriority,
    TicketStatus,
    TicketType,
    ToolAssignment,
)

router = APIRouter(tags=["tickets"])

# Singleton
_ticket_mgr: TicketManager | None = None


def _tickets() -> TicketManager:
    global _ticket_mgr
    if _ticket_mgr is None:
        persist = Path.home() / ".local" / "share" / "proxym" / "tickets.json"
        _ticket_mgr = TicketManager(persist_path=persist)
    return _ticket_mgr


# ── Pydantic models ──────────────────────────────────────────

class CreateTicketReq(BaseModel):
    title: str
    description: str = ""
    status: str = "todo"
    priority: str = "medium"
    type: str = "task"
    sprint_id: str = ""
    tags: list[str] = []
    files: list[str] = []
    estimated_hours: float = 0


class UpdateTicketReq(BaseModel):
    title: str | None = None
    description: str | None = None
    status: str | None = None
    priority: str | None = None
    type: str | None = None
    sprint_id: str | None = None
    tags: list[str] | None = None
    files: list[str] | None = None
    estimated_hours: float | None = None
    actual_hours: float | None = None


class AssignToolReq(BaseModel):
    tool: str  # vscode, aider, claude-code, windsurf, cursor
    agent_mode: str = ""
    model: str = ""


class AddCommentReq(BaseModel):
    author: str = ""
    content: str


class CreateSprintReq(BaseModel):
    name: str
    goal: str = ""
    start_date: str = ""
    end_date: str = ""


class UpdateSprintReq(BaseModel):
    name: str | None = None
    goal: str | None = None
    status: str | None = None
    start_date: str | None = None
    end_date: str | None = None


# ── Ticket endpoints ─────────────────────────────────────────

@router.get("/tickets")
async def list_tickets(
    sprint_id: str | None = None,
    status: str | None = None,
    priority: str | None = None,
    tool: str | None = None,
    tag: str | None = None,
):
    """List tickets with optional filters."""
    mgr = _tickets()
    st = TicketStatus(status) if status else None
    pr = TicketPriority(priority) if priority else None
    tickets = mgr.list_tickets(sprint_id=sprint_id, status=st, priority=pr, tool=tool, tag=tag)
    return {"tickets": [t.summary() for t in tickets]}


@router.post("/tickets")
async def create_ticket(req: CreateTicketReq):
    """Create a new ticket."""
    ticket = Ticket(
        title=req.title,
        description=req.description,
        status=TicketStatus(req.status),
        priority=TicketPriority(req.priority),
        type=TicketType(req.type),
        sprint_id=req.sprint_id,
        tags=req.tags,
        files=req.files,
        estimated_hours=req.estimated_hours,
    )
    mgr = _tickets()
    created = mgr.create_ticket(ticket)
    return created.summary()


@router.get("/tickets/board/view")
async def ticket_board(sprint_id: str | None = None):
    """Kanban board view: tickets grouped by status columns."""
    return _tickets().board(sprint_id=sprint_id)


@router.get("/tickets/{ticket_id}")
async def get_ticket(ticket_id: str):
    """Get ticket details including comments."""
    ticket = _tickets().get_ticket(ticket_id)
    if not ticket:
        raise HTTPException(404, "Ticket not found")
    result = ticket.summary()
    result["comments"] = [c.model_dump() for c in ticket.comments]
    return result


@router.put("/tickets/{ticket_id}")
async def update_ticket(ticket_id: str, req: UpdateTicketReq):
    """Update a ticket's fields."""
    updates = {k: v for k, v in req.model_dump().items() if v is not None}
    ticket = _tickets().update_ticket(ticket_id, updates)
    if not ticket:
        raise HTTPException(404, "Ticket not found")
    return ticket.summary()


@router.delete("/tickets/{ticket_id}")
async def delete_ticket(ticket_id: str):
    """Delete a ticket."""
    if _tickets().delete_ticket(ticket_id):
        return {"ok": True}
    raise HTTPException(404, "Ticket not found")


@router.post("/tickets/{ticket_id}/assign")
async def assign_ticket_tool(ticket_id: str, req: AssignToolReq):
    """Assign a tool (vscode, aider, claude-code, etc.) to work on a ticket."""
    assignment = ToolAssignment(tool=req.tool, agent_mode=req.agent_mode, model=req.model)
    if _tickets().assign_tool(ticket_id, assignment):
        return {"ok": True, "ticket": _tickets().get_ticket(ticket_id).summary()}
    raise HTTPException(404, "Ticket not found")


@router.post("/tickets/{ticket_id}/comment")
async def add_ticket_comment(ticket_id: str, req: AddCommentReq):
    """Add a comment to a ticket (from any tool or user)."""
    comment = TicketComment(author=req.author, content=req.content)
    if _tickets().add_comment(ticket_id, comment):
        return {"ok": True}
    raise HTTPException(404, "Ticket not found")


# ── Sprint endpoints ─────────────────────────────────────────

@router.get("/sprints")
async def list_sprints(status: str | None = None):
    """List sprints."""
    st = SprintStatus(status) if status else None
    sprints = _tickets().list_sprints(status=st)
    mgr = _tickets()
    return {"sprints": [s.summary(mgr.sprint_tickets(s.id)) for s in sprints]}


@router.post("/sprints")
async def create_sprint(req: CreateSprintReq):
    """Create a new sprint."""
    sprint = Sprint(
        name=req.name,
        goal=req.goal,
        start_date=req.start_date,
        end_date=req.end_date,
    )
    created = _tickets().create_sprint(sprint)
    return created.summary()


@router.get("/sprints/{sprint_id}")
async def get_sprint(sprint_id: str):
    """Get sprint details with ticket stats."""
    mgr = _tickets()
    sprint = mgr.get_sprint(sprint_id)
    if not sprint:
        raise HTTPException(404, "Sprint not found")
    result = sprint.summary(mgr.sprint_tickets(sprint_id))
    result["stats"] = mgr.sprint_stats(sprint_id)
    return result


@router.put("/sprints/{sprint_id}")
async def update_sprint(sprint_id: str, req: UpdateSprintReq):
    """Update sprint fields."""
    updates = {k: v for k, v in req.model_dump().items() if v is not None}
    sprint = _tickets().update_sprint(sprint_id, updates)
    if not sprint:
        raise HTTPException(404, "Sprint not found")
    mgr = _tickets()
    return sprint.summary(mgr.sprint_tickets(sprint_id))


@router.delete("/sprints/{sprint_id}")
async def delete_sprint(sprint_id: str):
    """Delete a sprint."""
    if _tickets().delete_sprint(sprint_id):
        return {"ok": True}
    raise HTTPException(404, "Sprint not found")
