"""Unified CLI for Proxym — AI proxy management.

Usage:
  proxym serve                     # start the proxy server
  proxym status                    # show system status
  proxym models                    # list available models
  proxym chat                      # interactive chat (DSL + LLM fallback)

  proxym accounts list             # manage accounts
  proxym accounts add --name Work --provider anthropic --api-key sk-ant-...
  proxym accounts costs            # cost breakdown
  proxym accounts delete {id}      # remove an account
  proxym accounts bind-tool {id} --tool-type ide --tool-name vscode

  proxym vm create --tool windsurf --account work-anthropic
  proxym vm start windsurf-work
  proxym vm stop/pause/resume windsurf-work
  proxym vm delete windsurf-work   # remove a VM
  proxym vm bulk-delete --vm-ids "id1,id2"
  proxym vm open windsurf-work     # SPICE viewer
  proxym vm ssh windsurf-work      # SSH into VM
  proxym vm switch windsurf-work --project other-project

  proxym browser list/assign/sync/snapshot

  proxym vscode start/stop/open/logs/status/build

  proxym ticket list/create/show/update/assign/comment/delete
  proxym sprint list/create/show/update/delete/board

  proxym context delta/detect/stats/sessions/mcp
  proxym tests status/vscode/proxy/providers/extensions/agent-setup/agent

Command handlers live in proxym.cli/ sub-modules:
  - system.py      — serve, status, models
  - accounts.py    — accounts list/add/costs/delete/bind-tool
  - vms.py         — vm list/create/action/switch/open/ssh/logs/delete/bulk-delete
  - browser.py     — browser list/assign/sync/snapshot
  - vscode.py      — vscode start/stop/open/logs/status/build
  - tickets.py     — ticket & sprint management
  - context.py     — context delta/detect/stats, sessions, mcp
  - diagnostics.py — system tests & diagnostics
"""

from __future__ import annotations

from types import SimpleNamespace

import click

from proxym.config import get_settings
from proxym.cli import accounts as accounts_cli
from proxym.cli import browser as browser_cli
from proxym.cli import chat as chat_cli
from proxym.cli import context as context_cli
from proxym.cli import diagnostics as diag_cli
from proxym.cli import system as system_cli
from proxym.cli import vms as vms_cli
from proxym.cli import vscode as vscode_cli
from proxym.cli.tickets import (
    cmd_ticket_list, cmd_ticket_create, cmd_ticket_show, cmd_ticket_update,
    cmd_ticket_assign, cmd_ticket_comment, cmd_ticket_delete,
    cmd_sprint_list, cmd_sprint_create, cmd_sprint_show, cmd_sprint_update,
    cmd_sprint_delete, cmd_board,
)


def _make_args(ctx: click.Context, **kwargs) -> SimpleNamespace:
    """Create Namespace from ctx.obj with optional overrides."""
    d = dict(ctx.obj) if ctx.obj else {}
    d.update(kwargs)
    return SimpleNamespace(**d)


@click.group(invoke_without_command=True)
@click.option("--proxy", default=None, help="Proxy URL")
@click.option("--key", default=None, help="API key")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]), help="Output format")
@click.pass_context
def cli(ctx: click.Context, proxy: str | None, key: str | None, fmt: str):
    """Proxym — intelligent AI proxy with VM isolation."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())
        ctx.exit(0)
    settings = get_settings()
    ctx.ensure_object(dict)
    ctx.obj["proxy"] = proxy or settings.default_proxy_url
    ctx.obj["key"] = key or settings.default_api_key
    ctx.obj["format"] = fmt


@cli.command(name="serve")
@click.option("--host", default=None, help="Bind host")
@click.option("--port", type=int, default=None, help="Bind port")
@click.option("--reload", is_flag=True, help="Auto-reload on changes")
def serve(host: str | None, port: int | None, reload: bool):
    """Start the proxy server."""
    args = SimpleNamespace(host=host, port=port, reload=reload)
    system_cli.cmd_serve(args)


@cli.command(name="status")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def status(ctx: click.Context, fmt: str):
    """Show system status."""
    args = _make_args(ctx, format=fmt)
    system_cli.cmd_status(args)


@cli.command(name="models")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def models(ctx: click.Context, fmt: str):
    """List available models."""
    args = _make_args(ctx, format=fmt)
    system_cli.cmd_models(args)


@cli.command(name="chat")
@click.option("--voice", is_flag=True, help="Use microphone input (Whisper STT)")
@click.option("--tts", is_flag=True, help="Enable text-to-speech responses")
@click.pass_context
def chat(ctx: click.Context, voice: bool, tts: bool):
    """Interactive chat — DSL first, LLM fallback."""
    args = _make_args(ctx, voice=voice, tts=tts)
    chat_cli.cmd_chat(args)


@cli.group(name="accounts")
def accounts():
    """Manage accounts."""
    pass


@accounts.command(name="list")
@click.pass_context
def accounts_list(ctx: click.Context):
    """List accounts."""
    args = _make_args(ctx)
    accounts_cli.cmd_accounts_list(args)


@accounts.command(name="add")
@click.option("--name", required=True, help="Account name")
@click.option("--provider", required=True, help="Provider name")
@click.option("--api-key", default="", help="API key")
@click.option("--email", default="", help="Email")
@click.option("--daily-budget", type=float, default=5.0, help="Daily budget")
@click.option("--monthly-budget", type=float, default=60.0, help="Monthly budget")
@click.option("--tags", default="", help="Tags")
@click.pass_context
def accounts_add(ctx: click.Context, name: str, provider: str, api_key: str,
                 email: str, daily_budget: float, monthly_budget: float, tags: str):
    """Add account."""
    args = _make_args(ctx, name=name, provider=provider, api_key=api_key,
                     email=email, daily_budget=daily_budget, monthly_budget=monthly_budget, tags=tags)
    accounts_cli.cmd_accounts_add(args)


@accounts.command(name="costs")
@click.pass_context
def accounts_costs(ctx: click.Context):
    """Show cost breakdown."""
    args = _make_args(ctx)
    accounts_cli.cmd_accounts_costs(args)


@accounts.command(name="get")
@click.argument("account_id")
@click.pass_context
def accounts_get(ctx: click.Context, account_id: str):
    """Show single account details."""
    args = _make_args(ctx, account_id=account_id)
    accounts_cli.cmd_accounts_get(args)


@accounts.command(name="delete")
@click.argument("account_id")
@click.confirmation_option(prompt="Are you sure you want to delete this account?")
@click.pass_context
def accounts_delete(ctx: click.Context, account_id: str):
    """Delete an account."""
    args = _make_args(ctx, account_id=account_id)
    accounts_cli.cmd_accounts_delete(args)


@accounts.command(name="bind-tool")
@click.argument("account_id")
@click.option("--tool-type", required=True, help="Tool type (ide, browser, cli, agent)")
@click.option("--tool-name", required=True, help="Tool name (vscode, windsurf, cursor, aider, ...)")
@click.option("--vm-id", default="", help="VM ID to bind")
@click.option("--project-path", default="", help="Project path")
@click.option("--browser-profile", default="", help="Browser profile name")
@click.pass_context
def accounts_bind_tool(ctx: click.Context, account_id: str, tool_type: str,
                      tool_name: str, vm_id: str, project_path: str, browser_profile: str):
    """Bind a tool to an account."""
    args = _make_args(ctx, account_id=account_id, tool_type=tool_type,
                     tool_name=tool_name, vm_id=vm_id, project_path=project_path,
                     browser_profile=browser_profile)
    accounts_cli.cmd_accounts_bind_tool(args)


@cli.group(name="vm")
def vm():
    """Manage VMs."""
    pass


@vm.command(name="list")
@click.pass_context
def vm_list(ctx: click.Context):
    """List VMs."""
    args = _make_args(ctx)
    vms_cli.cmd_vm_list(args)


@vm.command(name="create")
@click.option("--name", default="", help="VM name")
@click.option("--tool", default="", help="Tool name")
@click.option("--account", default="", help="Account ID")
@click.option("--mount", default="", help="Mount path")
@click.option("--project", default="", help="Project path")
@click.option("--cpus", type=int, default=4, help="CPU count")
@click.option("--memory", type=int, default=6144, help="Memory in MB")
@click.option("--image", default="ubuntu-24.04", help="OS image")
@click.pass_context
def vm_create(ctx: click.Context, name: str, tool: str, account: str,
              mount: str, project: str, cpus: int, memory: int, image: str):
    """Create VM."""
    args = _make_args(ctx, name=name, tool=tool, account=account, mount=mount,
                     project=project, cpus=cpus, memory=memory, image=image)
    vms_cli.cmd_vm_create(args)


@vm.command(name="start")
@click.argument("vm_id")
@click.pass_context
def vm_start(ctx: click.Context, vm_id: str):
    """Start a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="start")
    vms_cli.cmd_vm_action(args)


@vm.command(name="stop")
@click.argument("vm_id")
@click.option("--force", is_flag=True, help="Force stop")
@click.pass_context
def vm_stop(ctx: click.Context, vm_id: str, force: bool):
    """Stop a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="stop", force=force)
    vms_cli.cmd_vm_action(args)


@vm.command(name="pause")
@click.argument("vm_id")
@click.pass_context
def vm_pause(ctx: click.Context, vm_id: str):
    """Pause a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="pause")
    vms_cli.cmd_vm_action(args)


@vm.command(name="resume")
@click.argument("vm_id")
@click.pass_context
def vm_resume(ctx: click.Context, vm_id: str):
    """Resume a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="resume")
    vms_cli.cmd_vm_action(args)


@vm.command(name="snapshot")
@click.argument("vm_id")
@click.option("--name", default=None, help="Snapshot name")
@click.pass_context
def vm_snapshot(ctx: click.Context, vm_id: str, name: str | None):
    """Snapshot a VM."""
    args = _make_args(ctx, vm_id=vm_id, action="snapshot", name=name)
    vms_cli.cmd_vm_action(args)


@vm.command(name="switch")
@click.argument("vm_id")
@click.option("--project", required=True, help="Project path")
@click.pass_context
def vm_switch(ctx: click.Context, vm_id: str, project: str):
    """Switch project in VM."""
    args = _make_args(ctx, vm_id=vm_id, project=project)
    vms_cli.cmd_vm_switch(args)


@vm.command(name="open")
@click.argument("vm_id")
@click.pass_context
def vm_open(ctx: click.Context, vm_id: str):
    """Open SPICE viewer."""
    args = _make_args(ctx, vm_id=vm_id)
    vms_cli.cmd_vm_open(args)


@vm.command(name="ssh")
@click.argument("vm_id")
@click.option("--user", default="dev", help="SSH user")
@click.pass_context
def vm_ssh(ctx: click.Context, vm_id: str, user: str):
    """SSH into VM."""
    args = _make_args(ctx, vm_id=vm_id, user=user)
    vms_cli.cmd_vm_ssh(args)


@vm.command(name="logs")
@click.argument("vm_id")
@click.pass_context
def vm_logs(ctx: click.Context, vm_id: str):
    """Show VM logs."""
    args = _make_args(ctx, vm_id=vm_id)
    vms_cli.cmd_vm_logs(args)


@vm.command(name="delete")
@click.argument("vm_id")
@click.pass_context
def vm_delete(ctx: click.Context, vm_id: str):
    """Delete a VM."""
    args = _make_args(ctx, vm_id=vm_id)
    vms_cli.cmd_vm_delete(args)


@vm.command(name="bulk-delete")
@click.option("--vm-ids", required=True, help="Comma-separated VM IDs to delete")
@click.pass_context
def vm_bulk_delete(ctx: click.Context, vm_ids: str):
    """Delete multiple VMs."""
    args = _make_args(ctx, vm_ids=vm_ids)
    vms_cli.cmd_vm_bulk_delete(args)


@vm.command(name="console")
@click.argument("vm_id")
@click.pass_context
def vm_console(ctx: click.Context, vm_id: str):
    """Open web console for a VM (prints noVNC URL)."""
    args = _make_args(ctx, vm_id=vm_id)
    vms_cli.cmd_vm_console(args)


@cli.group(name="browser")
def browser():
    """Manage browser profiles."""
    pass


@browser.command(name="list")
@click.pass_context
def browser_list(ctx: click.Context):
    """List host browser profiles."""
    args = _make_args(ctx)
    browser_cli.cmd_browser_list(args)


@browser.command(name="assign")
@click.argument("profile")
@click.option("--account", required=True, help="Account ID")
@click.pass_context
def browser_assign(ctx: click.Context, profile: str, account: str):
    """Assign profile to account."""
    args = _make_args(ctx, profile=profile, account=account)
    browser_cli.cmd_browser_assign(args)


@browser.command(name="sync")
@click.argument("vm_id")
@click.pass_context
def browser_sync(ctx: click.Context, vm_id: str):
    """Sync browser profile host ↔ VM."""
    args = _make_args(ctx, vm_id=vm_id)
    browser_cli.cmd_browser_sync(args)


@browser.command(name="snapshot")
@click.argument("vm_id")
@click.pass_context
def browser_snapshot(ctx: click.Context, vm_id: str):
    """Save browser state from VM."""
    args = _make_args(ctx, vm_id=vm_id)
    browser_cli.cmd_browser_snapshot(args)


@cli.group(name="vscode")
def vscode():
    """Manage VS Code Web service."""
    pass


@vscode.command(name="start")
@click.pass_context
def vscode_start(ctx: click.Context):
    """Start VS Code Web (docker compose up vscode)."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_start(args)


@vscode.command(name="stop")
@click.pass_context
def vscode_stop(ctx: click.Context):
    """Stop VS Code Web."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_stop(args)


@vscode.command(name="open")
@click.pass_context
def vscode_open(ctx: click.Context):
    """Open VS Code Web in browser."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_open(args)


@vscode.command(name="logs")
@click.pass_context
def vscode_logs(ctx: click.Context):
    """Show VS Code Web logs."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_logs(args)


@vscode.command(name="status")
@click.pass_context
def vscode_status_cmd(ctx: click.Context):
    """Show VS Code Web container status."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_status(args)


@vscode.command(name="build")
@click.pass_context
def vscode_build(ctx: click.Context):
    """Rebuild VS Code Web image."""
    args = _make_args(ctx)
    vscode_cli.cmd_vscode_build(args)


# ── Ticket commands ───────────────────────────────────────────

@cli.group(name="ticket")
def ticket():
    """Manage tickets (task tracking for multi-tool workflows)."""
    pass


@ticket.command(name="list")
@click.option("--status", default=None, help="Filter by status (todo, in_progress, done, ...)")
@click.option("--tool", default=None, help="Filter by assigned tool (vscode, aider, claude-code, ...)")
@click.option("--sprint", default=None, help="Filter by sprint ID")
@click.option("--priority", default=None, help="Filter by priority (critical, high, medium, low)")
@click.option("--tag", default=None, help="Filter by tag")
@click.pass_context
def ticket_list(ctx: click.Context, status, tool, sprint, priority, tag):
    """List tickets."""
    args = _make_args(ctx, status=status, tool=tool, sprint=sprint, priority=priority, tag=tag)
    cmd_ticket_list(args)


@ticket.command(name="create")
@click.option("--title", required=True, help="Ticket title")
@click.option("--description", default=None, help="Description")
@click.option("--type", "type", default="task", help="Type: task, bug, feature, refactor, test, docs")
@click.option("--priority", default="medium", help="Priority: critical, high, medium, low")
@click.option("--sprint", default=None, help="Sprint ID to assign to")
@click.option("--tags", default=None, help="Comma-separated tags")
@click.option("--files", default=None, help="Comma-separated file paths")
@click.option("--hours", type=float, default=None, help="Estimated hours")
@click.pass_context
def ticket_create(ctx: click.Context, title, description, type, priority, sprint, tags, files, hours):
    """Create a new ticket."""
    args = _make_args(ctx, title=title, description=description, type=type,
                      priority=priority, sprint=sprint, tags=tags, files=files, hours=hours)
    cmd_ticket_create(args)


@ticket.command(name="show")
@click.argument("ticket_id")
@click.pass_context
def ticket_show(ctx: click.Context, ticket_id):
    """Show ticket details."""
    args = _make_args(ctx, ticket_id=ticket_id)
    cmd_ticket_show(args)


@ticket.command(name="update")
@click.argument("ticket_id")
@click.option("--title", default=None, help="New title")
@click.option("--status", default=None, help="New status")
@click.option("--priority", default=None, help="New priority")
@click.option("--type", "type", default=None, help="New type")
@click.option("--hours", type=float, default=None, help="Actual hours spent")
@click.pass_context
def ticket_update(ctx: click.Context, ticket_id, title, status, priority, type, hours):
    """Update a ticket."""
    args = _make_args(ctx, ticket_id=ticket_id, title=title, status=status,
                      priority=priority, type=type, hours=hours)
    cmd_ticket_update(args)


@ticket.command(name="assign")
@click.argument("ticket_id")
@click.option("--tool", required=True, help="Tool name (vscode, aider, claude-code, windsurf, cursor)")
@click.option("--mode", default=None, help="Agent mode (code, architect, debug, ask)")
@click.option("--model", default=None, help="Model name or alias")
@click.pass_context
def ticket_assign(ctx: click.Context, ticket_id, tool, mode, model):
    """Assign a tool to work on a ticket."""
    args = _make_args(ctx, ticket_id=ticket_id, tool=tool, mode=mode, model=model)
    cmd_ticket_assign(args)


@ticket.command(name="comment")
@click.argument("ticket_id")
@click.option("--author", default="", help="Author (tool name or user)")
@click.option("--content", required=True, help="Comment text")
@click.pass_context
def ticket_comment(ctx: click.Context, ticket_id, author, content):
    """Add a comment to a ticket."""
    args = _make_args(ctx, ticket_id=ticket_id, author=author, content=content)
    cmd_ticket_comment(args)


@ticket.command(name="delete")
@click.argument("ticket_id")
@click.pass_context
def ticket_delete(ctx: click.Context, ticket_id):
    """Delete a ticket."""
    args = _make_args(ctx, ticket_id=ticket_id)
    cmd_ticket_delete(args)


@ticket.command(name="board")
@click.option("--sprint", default=None, help="Filter board by sprint ID")
@click.pass_context
def ticket_board(ctx: click.Context, sprint):
    """Show kanban board view."""
    args = _make_args(ctx, sprint=sprint)
    cmd_board(args)


# ── Sprint commands ───────────────────────────────────────────

@cli.group(name="sprint")
def sprint():
    """Manage sprints."""
    pass


@sprint.command(name="list")
@click.option("--status", default=None, help="Filter by status (planning, active, completed, cancelled)")
@click.pass_context
def sprint_list(ctx: click.Context, status):
    """List sprints."""
    args = _make_args(ctx, status=status)
    cmd_sprint_list(args)


@sprint.command(name="create")
@click.option("--name", required=True, help="Sprint name")
@click.option("--goal", default=None, help="Sprint goal")
@click.option("--start", default=None, help="Start date (YYYY-MM-DD)")
@click.option("--end", default=None, help="End date (YYYY-MM-DD)")
@click.pass_context
def sprint_create(ctx: click.Context, name, goal, start, end):
    """Create a new sprint."""
    args = _make_args(ctx, name=name, goal=goal, start=start, end=end)
    cmd_sprint_create(args)


@sprint.command(name="show")
@click.argument("sprint_id")
@click.pass_context
def sprint_show(ctx: click.Context, sprint_id):
    """Show sprint details and stats."""
    args = _make_args(ctx, sprint_id=sprint_id)
    cmd_sprint_show(args)


@sprint.command(name="update")
@click.argument("sprint_id")
@click.option("--name", default=None, help="New name")
@click.option("--status", default=None, help="New status")
@click.option("--goal", default=None, help="New goal")
@click.pass_context
def sprint_update(ctx: click.Context, sprint_id, name, status, goal):
    """Update a sprint."""
    args = _make_args(ctx, sprint_id=sprint_id, name=name, status=status, goal=goal)
    cmd_sprint_update(args)


@sprint.command(name="delete")
@click.argument("sprint_id")
@click.pass_context
def sprint_delete(ctx: click.Context, sprint_id):
    """Delete a sprint."""
    args = _make_args(ctx, sprint_id=sprint_id)
    cmd_sprint_delete(args)


@sprint.command(name="board")
@click.option("--sprint", default=None, help="Filter board by sprint ID")
@click.pass_context
def sprint_board(ctx: click.Context, sprint):
    """Show kanban board view."""
    args = _make_args(ctx, sprint=sprint)
    cmd_board(args)


# ── Top-level system commands ─────────────────────────────────

@cli.command(name="logs")
@click.option("-n", "--lines", default=50, type=int, help="Number of log lines")
@click.option("--level", default=None, help="Filter by level (debug|info|warning|error)")
@click.pass_context
def logs_cmd(ctx: click.Context, lines: int, level: str | None):
    """Show proxy logs."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    params: dict = {"lines": lines}
    if level:
        params["level"] = level
    r = c.get("/dashboard/logs", params=params)
    data = r.json()
    if args.format == "yaml":
        print_json(data)
        return
    for entry in data.get("logs", []):
        ts = entry.get("timestamp", "")[:19]
        lvl = entry.get("level", "INFO").upper()
        msg = entry.get("message", "")
        click.echo(f"  {ts}  {lvl:7s}  {msg}")


@cli.command(name="providers")
@click.pass_context
def providers_cmd(ctx: click.Context):
    """List configured providers and their status."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.get("/dashboard/providers")
    data = r.json()
    if args.format == "yaml":
        print_json(data)
        return
    for p in data.get("providers", []):
        icon = "\033[32m\u2713\033[0m" if p.get("has_key") else "\033[31m\u2717\033[0m"
        click.echo(f"  {icon}  {p['name']:<15s}  models: {p.get('model_count', 0)}")


@cli.command(name="routing-test")
@click.pass_context
def routing_test_cmd(ctx: click.Context):
    """Dry-run routing test — check which model would be selected."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.get("/api/v1/routing/test")
    data = r.json()
    if args.format == "yaml":
        print_json(data)
        return
    summary = data.get("summary", {})
    click.echo(f"\n  Routing: {summary.get('ok', 0)}/{summary.get('total', 0)} aliases OK\n")
    for alias, info in data.get("routing", {}).items():
        st = info.get("status", "?")
        icon = "\033[32m\u2713\033[0m" if st == "ok" else "\033[31m\u2717\033[0m"
        click.echo(f"  {icon}  {alias:<12s} -> {info.get('model', '?'):<35s}  [{info.get('provider', '?')}]")
    click.echo()


@cli.command(name="projects")
@click.pass_context
def projects_cmd(ctx: click.Context):
    """List available projects from configured projects root."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.get("/dashboard/projects")
    data = r.json()
    if args.format == "yaml":
        print_json(data)
        return
    click.echo(f"  Root: {data.get('root', '?')}")
    for p in data.get("projects", []):
        flags = []
        if p.get("has_git"):
            flags.append("git")
        if p.get("has_pyproject"):
            flags.append("py")
        if p.get("has_package_json"):
            flags.append("js")
        tag = f" [{', '.join(flags)}]" if flags else ""
        click.echo(f"  {p['name']}{tag}")


# ── Context commands ──────────────────────────────────────────

@cli.group(name="context")
def context():
    """Manage context, sessions, and MCP servers."""
    pass


@context.command(name="delta")
@click.option("--project-id", default="", help="Project ID")
@click.option("--diff-text", default="", help="Diff text")
@click.option("--file", "file", default=None, help="Read diff from file")
@click.option("--version", type=int, default=None, help="Delta version")
@click.option("--token-estimate", type=int, default=None, help="Estimated tokens")
@click.pass_context
def context_delta(ctx: click.Context, project_id, diff_text, file, version, token_estimate):
    """Push a context delta to the proxy."""
    args = _make_args(ctx, project_id=project_id, diff_text=diff_text,
                     file=file, version=version, token_estimate=token_estimate)
    context_cli.cmd_context_delta(args)


@context.command(name="detect")
@click.option("--message", default=None, help="User message to detect context from")
@click.option("--system-prompt", default=None, help="System prompt")
@click.option("--paths", default=None, help="Comma-separated file paths")
@click.pass_context
def context_detect(ctx: click.Context, message, system_prompt, paths):
    """Detect project context from messages or paths."""
    args = _make_args(ctx, message=message, system_prompt=system_prompt, paths=paths)
    context_cli.cmd_context_detect(args)


@context.command(name="stats")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def context_stats(ctx: click.Context, fmt: str):
    """Show context store statistics."""
    args = _make_args(ctx, format=fmt)
    context_cli.cmd_context_stats(args)


@context.command(name="sessions")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def context_sessions(ctx: click.Context, fmt: str):
    """List active agent sessions."""
    args = _make_args(ctx, format=fmt)
    context_cli.cmd_sessions_list(args)


@context.command(name="mcp")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def context_mcp(ctx: click.Context, fmt: str):
    """List registered MCP servers."""
    args = _make_args(ctx, format=fmt)
    context_cli.cmd_mcp_servers(args)


# ── Diagnostics commands ─────────────────────────────────────

@cli.group(name="tests")
def tests():
    """Run system diagnostics."""
    pass


@tests.command(name="status")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def tests_status(ctx: click.Context, fmt: str):
    """Run all diagnostic tests."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_tests_status(args)


@tests.command(name="vscode")
@click.pass_context
def tests_vscode(ctx: click.Context):
    """Test VS Code Web connectivity."""
    args = _make_args(ctx)
    diag_cli.cmd_test_vscode(args)


@tests.command(name="proxy")
@click.pass_context
def tests_proxy(ctx: click.Context):
    """Test LLM proxy connectivity."""
    args = _make_args(ctx)
    diag_cli.cmd_test_proxy(args)


@tests.command(name="providers")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def tests_providers(ctx: click.Context, fmt: str):
    """Check configured LLM providers."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_test_providers(args)


@tests.command(name="extensions")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def tests_extensions(ctx: click.Context, fmt: str):
    """Check installed VS Code extensions."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_test_extensions(args)


@tests.command(name="agent-setup")
@click.pass_context
def tests_agent_setup(ctx: click.Context):
    """Comprehensive agent readiness check."""
    args = _make_args(ctx)
    diag_cli.cmd_test_agent_setup(args)


@tests.command(name="agent")
@click.pass_context
def tests_agent(ctx: click.Context):
    """Test agent with a simple completion."""
    args = _make_args(ctx)
    diag_cli.cmd_test_agent(args)


# ── Diagnose alias (same as tests) ───────────────────────────

@cli.group(name="diagnose")
def diagnose():
    """Run diagnostics to verify system health (alias for 'tests')."""
    pass


@diagnose.command(name="all")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def diagnose_all(ctx: click.Context, fmt: str):
    """Run all diagnostic tests."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_tests_status(args)


@diagnose.command(name="proxy")
@click.pass_context
def diagnose_proxy(ctx: click.Context):
    """Test proxy connectivity."""
    args = _make_args(ctx)
    diag_cli.cmd_test_proxy(args)


@diagnose.command(name="vscode")
@click.pass_context
def diagnose_vscode(ctx: click.Context):
    """Test VS Code Web status."""
    args = _make_args(ctx)
    diag_cli.cmd_test_vscode(args)


@diagnose.command(name="providers")
@click.option("--format", "fmt", default="table", type=click.Choice(["table", "yaml"]))
@click.pass_context
def diagnose_providers(ctx: click.Context, fmt: str):
    """Test provider configuration."""
    args = _make_args(ctx, format=fmt)
    diag_cli.cmd_test_providers(args)


@diagnose.command(name="agent")
@click.pass_context
def diagnose_agent(ctx: click.Context):
    """Test agent setup + completion."""
    args = _make_args(ctx)
    diag_cli.cmd_test_agent(args)


@diagnose.command(name="test")
@click.argument("test_name")
@click.pass_context
def diagnose_one(ctx: click.Context, test_name: str):
    """Run a specific test (vscode|proxy|roo|extensions|providers|copilot|agent-setup|agent)."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.get(f"/tests/{test_name}", timeout=30)
    print_json(r.json())


# CLI entry point
main = cli
