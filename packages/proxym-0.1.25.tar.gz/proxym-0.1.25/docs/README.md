<!-- code2docs:start --># proxy

![version](https://img.shields.io/badge/version-0.1.0-blue) ![python](https://img.shields.io/badge/python-%3E%3D3.11-blue) ![coverage](https://img.shields.io/badge/coverage-unknown-lightgrey) ![functions](https://img.shields.io/badge/functions-773-green)
> **773** functions | **80** classes | **98** files | CC̄ = 3.5

> Auto-generated project documentation from source code analysis.

**Author:** Tom Sapletta  
**License:** Apache-2.0  
**Repository:** [https://github.com/wronai/proxy](https://github.com/wronai/proxy)

## Installation

### From PyPI

```bash
pip install proxy
```

### From Source

```bash
git clone https://github.com/wronai/proxy
cd proxy
pip install -e .
```

### Optional Extras

```bash
pip install proxy[gpu]    # gpu features
pip install proxy[jetson]    # jetson features
pip install proxy[vm]    # vm features
pip install proxy[voice]    # voice features
pip install proxy[tts]    # tts features
pip install proxy[test]    # testing tools
pip install proxy[dev]    # development tools
```

## Quick Start

### CLI Usage

```bash
# Generate full documentation for your project
proxy ./my-project

# Only regenerate README
proxy ./my-project --readme-only

# Preview what would be generated (no file writes)
proxy ./my-project --dry-run

# Check documentation health
proxy check ./my-project

# Sync — regenerate only changed modules
proxy sync ./my-project
```

### Python API

```python
from proxy import generate_readme, generate_docs, Code2DocsConfig

# Quick: generate README
generate_readme("./my-project")

# Full: generate all documentation
config = Code2DocsConfig(project_name="mylib", verbose=True)
docs = generate_docs("./my-project", config=config)
```

## Generated Output

When you run `proxy`, the following files are produced:

```
<project>/
├── README.md                 # Main project README (auto-generated sections)
├── docs/
│   ├── api.md               # Consolidated API reference
│   ├── modules.md           # Module documentation with metrics
│   ├── architecture.md      # Architecture overview with diagrams
│   ├── dependency-graph.md  # Module dependency graphs
│   ├── coverage.md          # Docstring coverage report
│   ├── getting-started.md   # Getting started guide
│   ├── configuration.md    # Configuration reference
│   └── api-changelog.md    # API change tracking
├── examples/
│   ├── quickstart.py       # Basic usage examples
│   └── advanced_usage.py   # Advanced usage examples
├── CONTRIBUTING.md         # Contribution guidelines
└── mkdocs.yml             # MkDocs site configuration
```

## Configuration

Create `proxy.yaml` in your project root (or run `proxy init`):

```yaml
project:
  name: my-project
  source: ./
  output: ./docs/

readme:
  sections:
    - overview
    - install
    - quickstart
    - api
    - structure
  badges:
    - version
    - python
    - coverage
  sync_markers: true

docs:
  api_reference: true
  module_docs: true
  architecture: true
  changelog: true

examples:
  auto_generate: true
  from_entry_points: true

sync:
  strategy: markers    # markers | full | git-diff
  watch: false
  ignore:
    - "tests/"
    - "__pycache__"
```

## Sync Markers

proxy can update only specific sections of an existing README using HTML comment markers:

```markdown
<!-- proxy:start -->
# Project Title
... auto-generated content ...
<!-- proxy:end -->
```

Content outside the markers is preserved when regenerating. Enable this with `sync_markers: true` in your configuration.

## Architecture

```
proxy/
        ├── quickstart        ├── advanced_usage    ├── proxym-voice-chat    ├── proxym/    ├── seed_sprint8        ├── dashboard/            ├── _system            ├── _costs        ├── ctl        ├── config            ├── _accounts            ├── _vms        ├── cache/        ├── middleware/            ├── browser_profiles            ├── _tickets_api            ├── _enums            ├── _infra        ├── virt/            ├── _vm_config            ├── _snapshot            ├── _check            ├── _project            ├── tickets            ├── clonebox_adapter            ├── _lifecycle            ├── _config            ├── _state            ├── browser            ├── system            ├── diagnostics        ├── cli/            ├── context            ├── _orchestrator            ├── vms            ├── _client            ├── voice            ├── chat            ├── dsl            ├── tts            ├── tickets            ├── vscode            ├── accounts            ├── registry        ├── mcp/            ├── client            ├── router        ├── accounts/            ├── self_server        ├── context/            ├── detector            ├── _context            ├── tool_selector            ├── session        ├── router/            ├── voice_actions            ├── strategy        ├── providers/            ├── vscode_api            ├── diagnostics        ├── api/            ├── _pipeline            ├── console            ├── frontend            ├── context_api            ├── _state            ├── completions        ├── watch/            ├── client        ├── proxym_tools            ├── profiles/            ├── api                ├── formatters    ├── proxym-dashboard                ├── useDashboardData            ├── panel                ├── diagnostics                ├── logs                ├── vms                ├── ui                ├── voice                ├── overview                ├── models                ├── layout                ├── accounts                    ├── DiagConfig                    ├── DiagExtensions                    ├── helpers                ├── tickets                    ├── DiagInfrastructure├── project    ├── jetson-entrypoint    ├── setup                    ├── DiagAgent    ├── proxym-voice-server        ├── entrypoint            ├── system        ├── main```

## API Overview

### Classes

- **`Settings`** — All settings with sensible defaults. Override via env vars or .env file.
- **`CreateAccountReq`** — —
- **`BindToolReq`** — —
- **`CreateVMReq`** — —
- **`SwitchProjectReq`** — —
- **`FileSnapshot`** — Immutable snapshot of a single file.
- **`DeltaPayload`** — Computed delta between two context snapshots.
- **`DeltaBuffer`** — Maintains file snapshots and computes minimal diffs.
- **`AuthMiddleware`** — Simple bearer token auth (matches LiteLLM master_key pattern).
- **`CostTrackingMiddleware`** — Log request timing and attach cost headers to responses.
- **`BrowserProfile`** — Detected browser profile on the host.
- **`AppDataSync`** — Configuration for syncing browser data into a VM.
- **`CreateTicketReq`** — —
- **`UpdateTicketReq`** — —
- **`AssignToolReq`** — —
- **`AddCommentReq`** — —
- **`CreateSprintReq`** — —
- **`UpdateSprintReq`** — —
- **`VMBackend`** — —
- **`VMState`** — —
- **`TicketStatus`** — —
- **`TicketPriority`** — —
- **`TicketType`** — —
- **`SprintStatus`** — —
- **`ToolAssignment`** — Which tool is assigned to work on a ticket.
- **`TicketComment`** — —
- **`Ticket`** — —
- **`Sprint`** — —
- **`TicketManager`** — In-memory ticket & sprint store with optional JSON persistence.
- **`CloneBoxResult`** — Result of a clonebox CLI invocation.
- **`CloneBoxAdapter`** — Adapter wrapping the clonebox CLI for VM operations.
- **`ProjectsConfig`** — Configuration for shared project mounts from the host.
- **`VMConfig`** — Configuration for a development VM.
- **`VMStatus`** — Runtime status of a VM.
- **`VMOrchestrator`** — Manages VMs for isolated dev environments.
- **`VoiceListener`** — Local STT: microphone → text via Faster-Whisper.
- **`ParsedCommand`** — Result of successfully parsing a user phrase against the DSL.
- **`DSLParser`** — Parse natural language phrases into proxym API calls.
- **`TTSEngine`** — Text-to-speech engine with pluggable backends.
- **`MCPTransport`** — Transport protocol for MCP communication.
- **`MCPServerSpec`** — Specification of a registered MCP server.
- **`MCPRegistry`** — Registry of available MCP servers.
- **`MCPToolResult`** — Result of an MCP tool invocation.
- **`MCPClient`** — HTTP client for MCP server communication.
- **`MCPRouter`** — Routes tool requests to appropriate MCP servers.
- **`ProviderType`** — —
- **`ToolType`** — —
- **`AccountCredentials`** — Credentials for a single provider account.
- **`UsageMetrics`** — Tracked usage for a single account.
- **`AccountLimits`** — Provider-imposed and user-defined limits.
- **`ToolBinding`** — Binds an account to a specific tool/IDE instance.
- **`Account`** — Single provider account with all associated data.
- **`AccountManager`** — Central account registry.
- **`VMCreateRequest`** — —
- **`VMActionRequest`** — —
- **`VMSnapshotRequest`** — —
- **`VMSwitchRequest`** — —
- **`AccountAddRequest`** — —
- **`TicketCreateRequest`** — —
- **`TicketAssignRequest`** — —
- **`SprintCreateRequest`** — —
- **`ProjectContext`** — Detected project context for a request.
- **`AgentSession`** — Stateful session for an agent working on a project.
- **`SessionStore`** — In-memory session store with TTL-based expiry.
- **`AnalysisResult`** — Result of content analysis.
- **`RoutingDecision`** — Complete routing decision with audit trail.
- **`CostLedger`** — In-memory cost ledger with Redis persistence.
- **`Router`** — Stateful router that selects the optimal model per request.
- **`TaskTier`** — Complexity tier that determines which model class is needed.
- **`Capability`** — —
- **`ModelSpec`** — Immutable specification for a single model deployment.
- **`CompletionPipeline`** — Structured pipeline for processing a chat completion request.
- **`DeltaWatchClient`** — Watches a directory and pushes context deltas to the proxy server.
- **`ProxymTools`** — Tools for managing proxym AI proxy from Open WebUI.

### Functions

- `check_voice_deps()` — Sprawdź czy zależności głosowe są zainstalowane.
- `install_voice_deps()` — Zainstaluj zależności głosowe.
- `main()` — —
- `main()` — —
- `dashboard_root()` — Dashboard root - redirects to system status.
- `system_status()` — Full system overview: accounts + VMs + costs + libvirt + providers.
- `list_providers()` — Show configured providers from .env and their model counts.
- `get_logs(lines, level)` — Get recent log entries from proxym log file.
- `list_available_projects()` — List projects from vscode_project_path with metadata.
- `cost_summary()` — Aggregate cost dashboard across all accounts.
- `cost_detailed()` — Per-account cost breakdown.
- `list_tools()` — Return available VM tool profiles (host/browser environments).
- `cli(ctx, proxy, key, fmt)` — Proxym — intelligent AI proxy with VM isolation.
- `serve(host, port, reload)` — Start the proxy server.
- `status(ctx, fmt)` — Show system status.
- `models(ctx, fmt)` — List available models.
- `chat(ctx, voice, tts)` — Interactive chat — DSL first, LLM fallback.
- `accounts()` — Manage accounts.
- `accounts_list(ctx)` — List accounts.
- `accounts_add(ctx, name, provider, api_key)` — Add account.
- `accounts_costs(ctx)` — Show cost breakdown.
- `accounts_get(ctx, account_id)` — Show single account details.
- `accounts_delete(ctx, account_id)` — Delete an account.
- `accounts_bind_tool(ctx, account_id, tool_type, tool_name)` — Bind a tool to an account.
- `vm()` — Manage VMs.
- `vm_list(ctx)` — List VMs.
- `vm_create(ctx, name, tool, account)` — Create VM.
- `vm_start(ctx, vm_id)` — Start a VM.
- `vm_stop(ctx, vm_id, force)` — Stop a VM.
- `vm_pause(ctx, vm_id)` — Pause a VM.
- `vm_resume(ctx, vm_id)` — Resume a VM.
- `vm_snapshot(ctx, vm_id, name)` — Snapshot a VM.
- `vm_switch(ctx, vm_id, project)` — Switch project in VM.
- `vm_open(ctx, vm_id)` — Open SPICE viewer.
- `vm_ssh(ctx, vm_id, user)` — SSH into VM.
- `vm_logs(ctx, vm_id)` — Show VM logs.
- `vm_delete(ctx, vm_id)` — Delete a VM.
- `vm_bulk_delete(ctx, vm_ids)` — Delete multiple VMs.
- `vm_console(ctx, vm_id)` — Open web console for a VM (prints noVNC URL).
- `browser()` — Manage browser profiles.
- `browser_list(ctx)` — List host browser profiles.
- `browser_assign(ctx, profile, account)` — Assign profile to account.
- `browser_sync(ctx, vm_id)` — Sync browser profile host ↔ VM.
- `browser_snapshot(ctx, vm_id)` — Save browser state from VM.
- `vscode()` — Manage VS Code Web service.
- `vscode_start(ctx)` — Start VS Code Web (docker compose up vscode).
- `vscode_stop(ctx)` — Stop VS Code Web.
- `vscode_open(ctx)` — Open VS Code Web in browser.
- `vscode_logs(ctx)` — Show VS Code Web logs.
- `vscode_status_cmd(ctx)` — Show VS Code Web container status.
- `vscode_build(ctx)` — Rebuild VS Code Web image.
- `ticket()` — Manage tickets (task tracking for multi-tool workflows).
- `ticket_list(ctx, status, tool, sprint)` — List tickets.
- `ticket_create(ctx, title, description, type)` — Create a new ticket.
- `ticket_show(ctx, ticket_id)` — Show ticket details.
- `ticket_update(ctx, ticket_id, title, status)` — Update a ticket.
- `ticket_assign(ctx, ticket_id, tool, mode)` — Assign a tool to work on a ticket.
- `ticket_comment(ctx, ticket_id, author, content)` — Add a comment to a ticket.
- `ticket_delete(ctx, ticket_id)` — Delete a ticket.
- `ticket_board(ctx, sprint)` — Show kanban board view.
- `sprint()` — Manage sprints.
- `sprint_list(ctx, status)` — List sprints.
- `sprint_create(ctx, name, goal, start)` — Create a new sprint.
- `sprint_show(ctx, sprint_id)` — Show sprint details and stats.
- `sprint_update(ctx, sprint_id, name, status)` — Update a sprint.
- `sprint_delete(ctx, sprint_id)` — Delete a sprint.
- `sprint_board(ctx, sprint)` — Show kanban board view.
- `logs_cmd(ctx, lines, level)` — Show proxy logs.
- `providers_cmd(ctx)` — List configured providers and their status.
- `routing_test_cmd(ctx)` — Dry-run routing test — check which model would be selected.
- `projects_cmd(ctx)` — List available projects from configured projects root.
- `context()` — Manage context, sessions, and MCP servers.
- `context_delta(ctx, project_id, diff_text, file)` — Push a context delta to the proxy.
- `context_detect(ctx, message, system_prompt, paths)` — Detect project context from messages or paths.
- `context_stats(ctx, fmt)` — Show context store statistics.
- `context_sessions(ctx, fmt)` — List active agent sessions.
- `context_mcp(ctx, fmt)` — List registered MCP servers.
- `tests()` — Run system diagnostics.
- `tests_status(ctx, fmt)` — Run all diagnostic tests.
- `tests_vscode(ctx)` — Test VS Code Web connectivity.
- `tests_proxy(ctx)` — Test LLM proxy connectivity.
- `tests_providers(ctx, fmt)` — Check configured LLM providers.
- `tests_extensions(ctx, fmt)` — Check installed VS Code extensions.
- `tests_agent_setup(ctx)` — Comprehensive agent readiness check.
- `tests_agent(ctx)` — Test agent with a simple completion.
- `diagnose()` — Run diagnostics to verify system health (alias for 'tests').
- `diagnose_all(ctx, fmt)` — Run all diagnostic tests.
- `diagnose_proxy(ctx)` — Test proxy connectivity.
- `diagnose_vscode(ctx)` — Test VS Code Web status.
- `diagnose_providers(ctx, fmt)` — Test provider configuration.
- `diagnose_agent(ctx)` — Test agent setup + completion.
- `diagnose_one(ctx, test_name)` — Run a specific test (vscode|proxy|roo|extensions|providers|copilot|agent-setup|agent).
- `get_settings()` — —
- `list_accounts(provider, tag)` — —
- `create_account(req)` — —
- `get_account(account_id)` — —
- `delete_account(account_id)` — —
- `bind_tool(account_id, req)` — —
- `list_vms()` — —
- `create_vm(req)` — —
- `start_vm(vm_id)` — —
- `stop_vm(vm_id, force)` — —
- `pause_vm(vm_id)` — —
- `resume_vm(vm_id)` — —
- `snapshot_vm(vm_id, name)` — —
- `switch_project(vm_id, req)` — —
- `delete_vm(vm_id)` — —
- `delete_vm_post(vm_id)` — POST variant for single VM deletion (matches frontend convention).
- `bulk_delete_vms(req)` — Delete multiple VMs by their IDs. Returns list of successfully deleted VM IDs.
- `detect_firefox_profiles()` — Detect Firefox profiles by parsing profiles.ini.
- `detect_chrome_profiles()` — Detect Google Chrome profiles by parsing Local State.
- `detect_chromium_profiles()` — Detect Chromium profiles by parsing Local State.
- `detect_all_profiles()` — Detect all browser profiles on the host.
- `generate_app_data_sync(profile, with_passwords)` — Generate an AppDataSync config for copying a profile into a VM.
- `list_tickets(sprint_id, status, priority, tool)` — List tickets with optional filters.
- `create_ticket(req)` — Create a new ticket.
- `ticket_board(sprint_id)` — Kanban board view: tickets grouped by status columns.
- `get_ticket(ticket_id)` — Get ticket details including comments.
- `update_ticket(ticket_id, req)` — Update a ticket's fields.
- `delete_ticket(ticket_id)` — Delete a ticket.
- `assign_ticket_tool(ticket_id, req)` — Assign a tool (vscode, aider, claude-code, etc.) to work on a ticket.
- `add_ticket_comment(ticket_id, req)` — Add a comment to a ticket (from any tool or user).
- `list_sprints(status)` — List sprints.
- `create_sprint(req)` — Create a new sprint.
- `get_sprint(sprint_id)` — Get sprint details with ticket stats.
- `update_sprint(sprint_id, req)` — Update sprint fields.
- `delete_sprint(sprint_id)` — Delete a sprint.
- `cmd_browser_list(args)` — List detected browser profiles on the host.
- `cmd_browser_assign(args)` — Assign a browser profile to an account.
- `cmd_browser_sync(args)` — Sync browser profile host ↔ VM.
- `cmd_browser_snapshot(args)` — Save browser state from VM as snapshot.
- `cmd_serve(args)` — Start the proxy server (delegates to proxym.main:cli).
- `cmd_status(args)` — Show system status (YAML or human-readable).
- `cmd_models(args)` — —
- `cmd_tests_status(args)` — Run all diagnostic tests and show results.
- `cmd_test_vscode(args)` — Test VS Code Web connectivity.
- `cmd_test_proxy(args)` — Test LLM proxy connectivity.
- `cmd_test_providers(args)` — Check configured LLM providers.
- `cmd_test_extensions(args)` — Check installed VS Code extensions.
- `cmd_test_agent_setup(args)` — Comprehensive agent readiness check.
- `cmd_test_agent(args)` — Test agent with a simple completion.
- `cmd_context_delta(args)` — Push a context delta to the proxy.
- `cmd_context_detect(args)` — Detect project context from messages or paths.
- `cmd_context_stats(args)` — Show context store statistics.
- `cmd_sessions_list(args)` — List active agent sessions.
- `cmd_mcp_servers(args)` — List registered MCP servers.
- `cmd_vm_list(args)` — —
- `cmd_vm_create(args)` — —
- `cmd_vm_action(args)` — —
- `cmd_vm_switch(args)` — —
- `cmd_vm_open(args)` — Open SPICE viewer for a VM (virt-viewer).
- `cmd_vm_ssh(args)` — SSH into a VM (auto-detect IP via dashboard).
- `cmd_vm_logs(args)` — Show cloud-init logs and tool logs from a VM.
- `cmd_vm_delete(args)` — Delete a VM.
- `cmd_vm_console(args)` — Open web console for a VM (prints noVNC URL).
- `cmd_vm_bulk_delete(args)` — Delete multiple VMs.
- `make_client(base, key)` — Create HTTP client with configuration from settings.
- `print_json(data)` — —
- `print_table(rows, columns, widths)` — —
- `cmd_chat(args)` — Interactive chat with proxym — DSL first, LLM fallback.
- `cmd_ticket_list(args)` — List tickets with optional filters.
- `cmd_ticket_create(args)` — Create a new ticket.
- `cmd_ticket_show(args)` — Show ticket details.
- `cmd_ticket_update(args)` — Update a ticket.
- `cmd_ticket_assign(args)` — Assign a tool to a ticket.
- `cmd_ticket_comment(args)` — Add a comment to a ticket.
- `cmd_ticket_delete(args)` — Delete a ticket.
- `cmd_sprint_list(args)` — List sprints.
- `cmd_sprint_create(args)` — Create a new sprint.
- `cmd_sprint_show(args)` — Show sprint details.
- `cmd_sprint_update(args)` — Update a sprint.
- `cmd_sprint_delete(args)` — Delete a sprint.
- `cmd_board(args)` — Show kanban board.
- `cmd_vscode_start(args)` — Start VS Code Web (docker compose --profile vscode up -d).
- `cmd_vscode_stop(args)` — Stop VS Code Web.
- `cmd_vscode_open(args)` — Open VS Code Web in the default browser.
- `cmd_vscode_logs(args)` — Show VS Code Web logs (follows).
- `cmd_vscode_status(args)` — Show VS Code Web container status.
- `cmd_vscode_build(args)` — Rebuild VS Code Web image.
- `cmd_accounts_list(args)` — —
- `cmd_accounts_add(args)` — —
- `cmd_accounts_costs(args)` — —
- `cmd_accounts_get(args)` — —
- `cmd_accounts_delete(args)` — —
- `cmd_accounts_bind_tool(args)` — —
- `tool_vm_list()` — List all VMs with their status.
- `tool_vm_create(req)` — Create a new VM with an AI tool.
- `tool_vm_start(req)` — Start a stopped VM.
- `tool_vm_stop(req)` — Stop a running VM.
- `tool_vm_snapshot(req)` — Create a VM snapshot.
- `tool_vm_switch_project(req)` — Switch project in a running VM.
- `tool_account_list()` — List all accounts with costs.
- `tool_account_costs()` — Cost summary per account and model.
- `tool_account_add(req)` — Add a new API account.
- `tool_status()` — Full system status: proxy, VMs, accounts, costs.
- `tool_logs(lines, level)` — Recent proxym logs.
- `tool_models()` — List available models with prices.
- `tool_ticket_list(sprint_id, status, tool)` — List tickets, optionally filtered by sprint, status, or assigned tool.
- `tool_ticket_create(req)` — Create a new ticket in the task management system.
- `tool_ticket_assign(req)` — Assign a development tool to work on a ticket.
- `tool_ticket_board(sprint_id)` — Get kanban board view of tickets grouped by status.
- `tool_sprint_create(req)` — Create a new sprint.
- `detect_project(messages, headers)` — Detect project context from request data.
- `select_tools(context, analysis, available_servers)` — Select MCP servers for a given project and task analysis.
- `analyze_request(messages)` — Analyze a chat completion request and return routing metadata.
- `vms_list()` — List VMs (alias for GET /dashboard/vms).
- `vms_start(vm_id)` — Start VM (alias for POST /dashboard/vms/{vm_id}/start).
- `vms_stop(vm_id, force)` — Stop VM (alias for POST /dashboard/vms/{vm_id}/stop).
- `vms_snapshot(vm_id, name)` — Snapshot VM (alias for POST /dashboard/vms/{vm_id}/snapshot).
- `accounts_list(provider, tag)` — List accounts (alias for GET /dashboard/accounts).
- `dashboard_costs_summary()` — Cost summary used by voice UI.
- `logs_list(lines, level)` — Recent logs (alias for GET /dashboard/logs).
- `voice_tickets(status)` — List tickets — voice-friendly summary.
- `voice_diagnose()` — Run diagnostics — voice-friendly summary.
- `models_for_tier(tier, required_caps, available_providers)` — Return models suitable for a tier, sorted by effective cost ascending.
- `cheapest_model(tier, available_providers, required_caps)` — Return the single cheapest model that satisfies constraints.
- `get_model(model_id)` — —
- `vscode_status()` — —
- `vscode_start()` — —
- `vscode_stop()` — —
- `vscode_restart()` — —
- `vscode_logs(lines)` — —
- `vscode_build()` — —
- `run_all_tests(request)` — Run all diagnostic tests and return comprehensive status.
- `test_vscode()` — Test VS Code Web connectivity.
- `test_proxy(request)` — Test LLM proxy connectivity.
- `test_roo()` — Test Roo Code configuration.
- `test_extensions()` — Check installed VS Code extensions.
- `test_providers()` — Check configured LLM providers and model aliases.
- `test_copilot()` — Detect GitHub Copilot extension conflicts.
- `test_agent_setup(request)` — Comprehensive agent readiness check.
- `test_agent()` — Test agent with a simple completion.
- `routing_test()` — Return routing status (no network calls).
- `ollama_status()` — Check Ollama connectivity and list available local models.
- `vm_console(vm_id)` — Return noVNC connection URL for a running VM.
- `root_redirect()` — Redirect root to dashboard.
- `dashboard_ui()` — Serve the React dashboard UI.
- `dashboard_hook_js()` — Serve the useDashboardData hook (plain JS, no Babel needed).
- `dashboard_api_js()` — Serve the dashboard API client (plain JS, no Babel needed).
- `dashboard_formatters_js()` — Serve formatters utility (plain JS, no Babel needed).
- `dashboard_ui_jsx()` — Serve UI primitives: StatusBadge, CostBar, Card, StateBadge.
- `dashboard_models_jsx()` — Serve ModelsTable component.
- `dashboard_accounts_jsx()` — Serve Accounts components.
- `dashboard_layout_jsx()` — Serve layout components: DashboardHeader, TabNav.
- `dashboard_overview_jsx()` — Serve overview components: CostSummary, BudgetCards, SystemCard, ProvidersCard, OverviewTab.
- `dashboard_vms_jsx()` — Serve VMs components with sort/selection hooks.
- `dashboard_logs_jsx()` — Serve LogPanel with useLogFilter hook.
- `dashboard_voice_jsx()` — Serve VoiceChat component (Web Speech API STT/TTS + LLM chat).
- `dashboard_tickets_jsx()` — Serve TicketsPanel component (tickets & sprints management).
- `dashboard_diag_helpers_jsx()` — Serve diagnostics shared helpers: _diagBadge, _diagWarnBadge, _diagRow.
- `dashboard_diag_infrastructure_jsx()` — Serve DiagVSCode + DiagProxy cards.
- `dashboard_diag_config_jsx()` — Serve DiagRooConfig + DiagProviders cards.
- `dashboard_diag_extensions_jsx()` — Serve DiagExtensions + DiagCopilot cards.
- `dashboard_diag_agent_jsx()` — Serve DiagAgentSetup + DiagAgentTest cards.
- `dashboard_diagnostics_jsx()` — Serve DiagnosticsPanel for testing VS Code, proxy, and agent.
- `dashboard_jsx()` — Serve the React dashboard JSX entry point.
- `get_frontend_config(request)` — Return configuration for frontend.
- `get_context_store()` — —
- `get_mcp_registry()` — —
- `receive_delta(request)` — Receive context delta from the file watcher client.
- `detect_context(request)` — Detect project context from request body (messages + headers).
- `list_sessions()` — List active agent sessions.
- `list_mcp_servers()` — List registered MCP servers.
- `context_stats()` — Return context store statistics.
- `get_router()` — —
- `get_delta_buffer()` — —
- `get_mcp_router()` — —
- `get_session_store()` — —
- `get_context_payload()` — —
- `set_context_payload(payload)` — —
- `completion()` — —
- `chat_completions(request, x_task_tier)` — OpenAI-compatible chat completions with intelligent routing.
- `cli()` — CLI entry point for proxym-client.
- `get_builtin_profile(tool)` — Get the path to a built-in profile YAML for a tool.
- `list_builtin_profiles()` — List all available built-in profile names.
- `merge_profiles(base, override)` — Deep-merge two profile dicts. Override values take precedence.
- `load_profile_yaml(path)` — Load a YAML profile, with graceful fallback if PyYAML is not installed.
- `ct()` — —
- `get()` — —
- `body()` — —
- `post()` — —
- `payload()` — —
- `formatDate()` — —
- `date()` — —
- `now()` — —
- `diffMs()` — —
- `diffMins()` — —
- `diffHours()` — —
- `diffDays()` — —
- `formatDuration()` — —
- `mins()` — —
- `hours()` — —
- `days()` — —
- `formatSize()` — —
- `useHealth()` — —
- `refresh()` — —
- `h()` — —
- `useBudget()` — —
- `useModels()` — —
- `m()` — —
- `useProviders()` — —
- `p()` — —
- `useResources()` — —
- `useLogs()` — —
- `l()` — —
- `useDashboardData()` — —
- `getInitialTab()` — —
- `hash()` — —
- `setTab()` — —
- `handleHashChange()` — —
- `newTab()` — —
- `healthHook()` — —
- `budgetHook()` — —
- `modelsHook()` — —
- `providersHook()` — —
- `resourcesHook()` — —
- `logsHook()` — —
- `isUp()` — —
- `i()` — —
- `useState()` — —
- `useEffect()` — —
- `useCallback()` — —
- `Dashboard()` — —
- `data()` — —
- `root()` — —
- `DiagnosticsPanel()` — —
- `runTests()` — —
- `r()` — —
- `find()` — —
- `copyErrorsToClipboard()` — —
- `failedTests()` — —
- `lines()` — —
- `issues()` — —
- `useLogFilter()` — —
- `filtered()` — —
- `errorCount()` — —
- `warnCount()` — —
- `LogRow()` — —
- `LogPanel()` — —
- `handleCopy()` — —
- `text()` — —
- `ta()` — —
- `useVMSort()` — —
- `sorted()` — —
- `cmp()` — —
- `r()` — —
- `useVMSelection()` — —
- `handleSelect()` — —
- `next()` — —
- `handleSelectAll()` — —
- `handleBulkAction()` — —
- `vmIds()` — —
- `VMCard()` — —
- `actions()` — —
- `VMsPanel()` — —
- `sel()` — —
- `detail()` — —
- `handleAction()` — —
- `isDelete()` — —
- `endpoint()` — —
- `res()` — —
- `msg()` — —
- `label()` — —
- `runningCount()` — —
- `stoppedCount()` — —
- `pausedCount()` — —
- `StatusBadge()` — —
- `CostBar()` — —
- `pct()` — —
- `color()` — —
- `Card()` — —
- `StateBadge()` — —
- `colors()` — —
- `vms()` — —
- `running()` — —
- `daily()` — —
- `monthly()` — —
- `logs()` — —
- `ids()` — —
- `routes()` — —
- `ok()` — —
- `fail()` — —
- `accounts()` — —
- `apiCall()` — —
- `r()` — —
- `err()` — —
- `matchDSL()` — —
- `t()` — —
- `m()` — —
- `captured()` — —
- `executeDSL()` — —
- `data()` — —
- `VoiceChat()` — —
- `h()` — —
- `recRef()` — —
- `abortRef()` — —
- `startListening()` — —
- `SR()` — —
- `text()` — —
- `stopListening()` — —
- `stopSpeaking()` — —
- `stopAll()` — —
- `sendMessage()` — —
- `processInput()` — —
- `dsl()` — —
- `label()` — —
- `reply()` — —
- `ctrl()` — —
- `res()` — —
- `msg()` — —
- `name()` — —
- `toolResult()` — —
- `toolReply()` — —
- `textReply()` — —
- `formatToolResult()` — —
- `finish()` — —
- `u()` — —
- `onKey()` — —
- `sc()` — —
- `CostSummary()` — —
- `BudgetCards()` — —
- `dailyUsed()` — —
- `monthlyUsed()` — —
- `SystemCard()` — —
- `ProvidersCard()` — —
- `OverviewTab()` — —
- `ModelsTable()` — —
- `DashboardHeader()` — —
- `TabNav()` — —
- `AccountRow()` — —
- `a()` — —
- `NewAccountForm()` — —
- `handleSubmit()` — —
- `AccountsPanel()` — —
- `handleCreate()` — —
- `DiagRooConfig()` — —
- `ok()` — —
- `badge()` — —
- `DiagProviders()` — —
- `DiagExtensions()` — —
- `ok()` — —
- `DiagCopilot()` — —
- `cls()` — —
- `useTickets()` — —
- `refreshTickets()` — —
- `data()` — —
- `refreshSprints()` — —
- `refresh()` — —
- `TicketCard()` — —
- `handleStatusChange()` — —
- `handleAssign()` — —
- `CreateTicketForm()` — —
- `handleSubmit()` — —
- `field()` — —
- `CreateSprintForm()` — —
- `SprintCard()` — —
- `progressColor()` — —
- `TicketsPanel()` — —
- `filtered()` — —
- `result()` — —
- `boardColumns()` — —
- `stats()` — —
- `count()` — —
- `DiagVSCode()` — —
- `DiagProxy()` — —
- `DiagAgentSetup()` — —
- `DiagAgentTest()` — —
- `skipped()` — —
- `print()` — —
- `get_cost_ledger()` — —
- `favicon()` — Return empty favicon to prevent 401 errors.
- `health(request, authorization, x_api_key)` — Health check with optional VM identification.
- `list_models()` — List available models (OpenAI-compatible) including model aliases.
- `budget_status()` — Return current budget usage.
- `lifespan(app)` — —
- `cli()` — —


## Project Structure

📄 `TODO.seed_sprint8` (1 functions)
📄 `docs.open-webui-tools.proxym_tools` (9 functions, 1 classes)
📄 `frontend.proxym-dashboard`
📄 `project`
📄 `project.examples.advanced_usage`
📄 `project.examples.quickstart`
📄 `scripts.jetson-entrypoint`
📄 `scripts.proxym-voice-chat` (3 functions)
📄 `scripts.proxym-voice-server`
📄 `scripts.setup`
📄 `services.vscode.entrypoint` (3 functions)
📦 `src.proxym`
📦 `src.proxym.accounts` (20 functions, 8 classes)
📦 `src.proxym.api`
📄 `src.proxym.api._pipeline` (16 functions, 1 classes)
📄 `src.proxym.api._state` (6 functions)
📄 `src.proxym.api.completions` (8 functions)
📄 `src.proxym.api.console` (4 functions)
📄 `src.proxym.api.context_api` (7 functions)
📄 `src.proxym.api.diagnostics` (18 functions)
📄 `src.proxym.api.frontend` (24 functions)
📄 `src.proxym.api.system` (7 functions)
📄 `src.proxym.api.voice_actions` (9 functions)
📄 `src.proxym.api.vscode_api` (11 functions)
📦 `src.proxym.cache` (10 functions, 3 classes)
📦 `src.proxym.cli`
📄 `src.proxym.cli._client` (3 functions)
📄 `src.proxym.cli.accounts` (6 functions)
📄 `src.proxym.cli.browser` (4 functions)
📄 `src.proxym.cli.chat` (12 functions)
📄 `src.proxym.cli.context` (5 functions)
📄 `src.proxym.cli.diagnostics` (7 functions)
📄 `src.proxym.cli.dsl` (8 functions, 2 classes)
📄 `src.proxym.cli.system` (6 functions)
📄 `src.proxym.cli.tickets` (13 functions)
📄 `src.proxym.cli.tts` (5 functions, 1 classes)
📄 `src.proxym.cli.vms` (11 functions)
📄 `src.proxym.cli.voice` (3 functions, 1 classes)
📄 `src.proxym.cli.vscode` (8 functions)
📄 `src.proxym.config` (3 functions, 1 classes)
📦 `src.proxym.context`
📄 `src.proxym.context._context` (1 functions, 1 classes)
📄 `src.proxym.context.detector` (9 functions)
📄 `src.proxym.context.session` (12 functions, 2 classes)
📄 `src.proxym.context.tool_selector` (2 functions)
📄 `src.proxym.ctl` (81 functions)
📦 `src.proxym.dashboard`
📄 `src.proxym.dashboard._accounts` (6 functions, 2 classes)
📄 `src.proxym.dashboard._costs` (4 functions)
📄 `src.proxym.dashboard._system` (7 functions)
📄 `src.proxym.dashboard._tickets_api` (14 functions, 6 classes)
📄 `src.proxym.dashboard._vms` (12 functions, 2 classes)
📄 `src.proxym.dashboard.api` (10 functions)
📄 `src.proxym.dashboard.components.accounts` (6 functions)
📄 `src.proxym.dashboard.components.diagnostics` (8 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagAgent` (3 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagConfig` (4 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagExtensions` (3 functions)
📄 `src.proxym.dashboard.components.diagnostics.DiagInfrastructure` (2 functions)
📄 `src.proxym.dashboard.components.diagnostics.helpers` (4 functions)
📄 `src.proxym.dashboard.components.layout` (2 functions)
📄 `src.proxym.dashboard.components.logs` (9 functions)
📄 `src.proxym.dashboard.components.models` (1 functions)
📄 `src.proxym.dashboard.components.overview` (7 functions)
📄 `src.proxym.dashboard.components.tickets` (23 functions)
📄 `src.proxym.dashboard.components.ui` (7 functions)
📄 `src.proxym.dashboard.components.vms` (30 functions)
📄 `src.proxym.dashboard.components.voice` (50 functions)
📄 `src.proxym.dashboard.hooks.useDashboardData` (31 functions)
📄 `src.proxym.dashboard.panel` (6 functions)
📄 `src.proxym.dashboard.tickets` (20 functions, 9 classes)
📄 `src.proxym.dashboard.utils.formatters` (12 functions)
📄 `src.proxym.main` (2 functions)
📦 `src.proxym.mcp`
📄 `src.proxym.mcp.client` (4 functions, 2 classes)
📄 `src.proxym.mcp.registry` (8 functions, 3 classes)
📄 `src.proxym.mcp.router` (4 functions, 1 classes)
📄 `src.proxym.mcp.self_server` (20 functions, 8 classes)
📦 `src.proxym.middleware` (4 functions, 2 classes)
📦 `src.proxym.providers` (4 functions, 3 classes)
📦 `src.proxym.router` (14 functions, 1 classes)
📄 `src.proxym.router.strategy` (14 functions, 3 classes)
📦 `src.proxym.virt`
📄 `src.proxym.virt._check` (1 functions)
📄 `src.proxym.virt._config` (1 functions, 3 classes)
📄 `src.proxym.virt._enums` (2 classes)
📄 `src.proxym.virt._infra` (4 functions, 1 classes)
📄 `src.proxym.virt._lifecycle` (12 functions, 1 classes)
📄 `src.proxym.virt._orchestrator` (5 functions, 1 classes)
📄 `src.proxym.virt._project` (2 functions, 1 classes)
📄 `src.proxym.virt._snapshot` (4 functions, 1 classes)
📄 `src.proxym.virt._state` (5 functions, 1 classes)
📄 `src.proxym.virt._vm_config` (7 functions, 1 classes)
📄 `src.proxym.virt.browser_profiles` (11 functions, 2 classes)
📄 `src.proxym.virt.clonebox_adapter` (17 functions, 2 classes)
📦 `src.proxym.virt.profiles` (4 functions)
📦 `src.proxym.watch` (5 functions, 1 classes)
📄 `src.proxym.watch.client`

## Requirements

- Python >= >=3.11
- fastapi >=0.115.0- uvicorn [standard]>=0.30.0- httpx >=0.27.0- litellm >=1.55.0- redis >=5.0.0- pydantic >=2.9.0- pydantic-settings >=2.5.0- python-dotenv >=1.0.0- tiktoken >=0.8.0- watchfiles >=0.24.0- xxhash >=3.5.0- rich >=13.9.0- structlog >=24.4.0- pyyaml >=6.0- click >=8.1.0

## Contributing

**Contributors:**
- Tom Softreck <tom@sapletta.com>
- Tom Sapletta <tom-sapletta-com@users.noreply.github.com>

We welcome contributions! Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

### Development Setup

```bash
# Clone the repository
git clone https://github.com/wronai/proxy
cd proxy

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest
```

## Documentation

- 📖 [Full Documentation](https://github.com/wronai/proxy/tree/main/docs) — API reference, module docs, architecture
- 🚀 [Getting Started](https://github.com/wronai/proxy/blob/main/docs/getting-started.md) — Quick start guide
- 📚 [API Reference](https://github.com/wronai/proxy/blob/main/docs/api.md) — Complete API documentation
- 🔧 [Configuration](https://github.com/wronai/proxy/blob/main/docs/configuration.md) — Configuration options
- 💡 [Examples](./examples) — Usage examples and code samples

### Generated Files

| Output | Description | Link |
|--------|-------------|------|
| `README.md` | Project overview (this file) | — |
| `docs/api.md` | Consolidated API reference | [View](./docs/api.md) |
| `docs/modules.md` | Module reference with metrics | [View](./docs/modules.md) |
| `docs/architecture.md` | Architecture with diagrams | [View](./docs/architecture.md) |
| `docs/dependency-graph.md` | Dependency graphs | [View](./docs/dependency-graph.md) |
| `docs/coverage.md` | Docstring coverage report | [View](./docs/coverage.md) |
| `docs/getting-started.md` | Getting started guide | [View](./docs/getting-started.md) |
| `docs/configuration.md` | Configuration reference | [View](./docs/configuration.md) |
| `docs/api-changelog.md` | API change tracking | [View](./docs/api-changelog.md) |
| `CONTRIBUTING.md` | Contribution guidelines | [View](./CONTRIBUTING.md) |
| `examples/` | Usage examples | [Browse](./examples) |
| `mkdocs.yml` | MkDocs configuration | — |

<!-- code2docs:end -->