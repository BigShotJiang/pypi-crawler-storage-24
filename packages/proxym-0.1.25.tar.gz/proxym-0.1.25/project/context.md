# System Architecture Analysis

## Overview

- **Project**: proxy
- **Language**: python
- **Files**: 83
- **Lines**: 26684
- **Functions**: 838
- **Classes**: 80
- **Avg CC**: 3.6
- **Critical (CC≥10)**: 47

## Architecture

### TODO/ (1 files, 229L, 1 functions)

- `seed_sprint8.py` — 229L, 1 methods, CC↑10

### docs/open-webui-tools/ (1 files, 90L, 9 functions)

- `proxym_tools.py` — 90L, 9 methods, CC↑1

### frontend/ (1 files, 6L, 0 functions)

- `proxym-dashboard.jsx` — 6L, 0 methods, CC↑0

### htmlcov/ (1 files, 735L, 65 functions)

- `coverage_html_cb_dd2e7eb5.js` — 735L, 65 methods, CC↑21

### root/ (1 files, 14L, 0 functions)

- `project.sh` — 14L, 0 methods, CC↑0

### scripts/ (4 files, 273L, 3 functions)

- `proxym-voice-chat.py` — 73L, 3 methods, CC↑5
- `jetson-entrypoint.sh` — 43L, 0 methods, CC↑0
- `proxym-voice-server.sh` — 64L, 0 methods, CC↑0
- `setup.sh` — 93L, 0 methods, CC↑0

### services/vscode/ (1 files, 333L, 1 functions)

- `entrypoint.sh` — 333L, 1 methods, CC↑0

### src/proxym/ (4 files, 1167L, 86 functions)

- `ctl.py` — 895L, 81 methods, CC↑7
- `config.py` — 123L, 3 methods, CC↑3
- `main.py` — 146L, 2 methods, CC↑3
- `__init__.py` — 3L, 0 methods, CC↑0

### src/proxym/accounts/ (1 files, 346L, 20 functions)

- `__init__.py` — 346L, 20 methods, CC↑10

### src/proxym/api/ (11 files, 2413L, 110 functions)

- `completions.py` — 215L, 8 methods, CC↑21
- `diagnostics.py` — 715L, 18 methods, CC↑14
- `console.py` — 177L, 4 methods, CC↑10
- `context_api.py` — 154L, 7 methods, CC↑9
- `voice_actions.py` — 118L, 9 methods, CC↑9
- _6 more files_

### src/proxym/cache/ (1 files, 333L, 10 functions)

- `__init__.py` — 333L, 10 methods, CC↑9

### src/proxym/cli/ (14 files, 1913L, 91 functions)

- `tickets.py` — 311L, 13 methods, CC↑12
- `diagnostics.py` — 151L, 7 methods, CC↑11
- `_client.py` — 39L, 3 methods, CC↑9
- `chat.py` — 215L, 12 methods, CC↑9
- `accounts.py` — 124L, 6 methods, CC↑8
- _9 more files_

### src/proxym/context/ (5 files, 613L, 24 functions)

- `detector.py` — 208L, 9 methods, CC↑9
- `session.py` — 247L, 12 methods, CC↑7
- `tool_selector.py` — 101L, 2 methods, CC↑5
- `_context.py` — 33L, 1 methods, CC↑3
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/dashboard/ (9 files, 1170L, 79 functions)

- `tickets.py` — 329L, 20 methods, CC↑17
- `_system.py` — 162L, 7 methods, CC↑13
- `panel.jsx` — 36L, 6 methods, CC↑10
- `_vms.py` — 175L, 12 methods, CC↑7
- `_costs.py` — 75L, 4 methods, CC↑4
- _4 more files_

### src/proxym/dashboard/components/ (10 files, 1899L, 136 functions)

- `voice.jsx` — 521L, 46 methods, CC↑70
- `logs.jsx` — 158L, 9 methods, CC↑34
- `vms.jsx` — 275L, 30 methods, CC↑32
- `diagnostics.jsx` — 149L, 8 methods, CC↑26
- `tickets.jsx` — 471L, 20 methods, CC↑20
- _5 more files_

### src/proxym/dashboard/components/diagnostics/ (5 files, 211L, 16 functions)

- `DiagConfig.jsx` — 59L, 4 methods, CC↑29
- `DiagExtensions.jsx` — 51L, 3 methods, CC↑20
- `DiagAgent.jsx` — 51L, 3 methods, CC↑11
- `DiagInfrastructure.jsx` — 28L, 2 methods, CC↑10
- `helpers.jsx` — 22L, 4 methods, CC↑4

### src/proxym/dashboard/hooks/ (1 files, 148L, 25 functions)

- `useDashboardData.js` — 148L, 25 methods, CC↑8

### src/proxym/dashboard/utils/ (1 files, 34L, 12 functions)

- `formatters.js` — 34L, 12 methods, CC↑7

### src/proxym/mcp/ (5 files, 913L, 36 functions)

- `client.py` — 148L, 4 methods, CC↑6
- `router.py` — 95L, 4 methods, CC↑5
- `registry.py` — 113L, 8 methods, CC↑4
- `self_server.py` — 533L, 20 methods, CC↑4
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/middleware/ (1 files, 70L, 4 functions)

- `__init__.py` — 70L, 4 methods, CC↑6

### src/proxym/providers/ (1 files, 331L, 4 functions)

- `__init__.py` — 331L, 4 methods, CC↑8

### src/proxym/router/ (2 files, 618L, 28 functions)

- `__init__.py` — 355L, 14 methods, CC↑9
- `strategy.py` — 263L, 14 methods, CC↑9

### src/proxym/virt/ (13 files, 1598L, 69 functions)

- `_config.py` — 94L, 1 methods, CC↑9
- `_vm_config.py` — 220L, 7 methods, CC↑9
- `browser_profiles.py` — 325L, 11 methods, CC↑9
- `_lifecycle.py` — 233L, 12 methods, CC↑7
- `_state.py` — 94L, 5 methods, CC↑7
- _8 more files_

### src/proxym/virt/profiles/ (1 files, 69L, 4 functions)

- `__init__.py` — 69L, 4 methods, CC↑5

### src/proxym/watch/ (2 files, 150L, 5 functions)

- `__init__.py` — 146L, 5 methods, CC↑5
- `client.py` — 4L, 0 methods, CC↑0

## Key Exports

- **VoiceChat** (function, CC=70) ⚠ split
- **processInput** (function, CC=20) ⚠ split
- **formatToolResult** (function, CC=19) ⚠ split
- **LogPanel** (function, CC=34) ⚠ split
- **VMsPanel** (function, CC=32) ⚠ split
- **DiagRooConfig** (function, CC=29) ⚠ split
- **DiagnosticsPanel** (function, CC=26) ⚠ split
- **table** (function, CC=21) ⚠ split
- **table_body_rows** (function, CC=21) ⚠ split
- **no_rows** (function, CC=21) ⚠ split
- **footer** (function, CC=21) ⚠ split
- **ratio_columns** (function, CC=21) ⚠ split
- **filter_handler** (function, CC=21) ⚠ split
- **chat_completions** (function, CC=21) ⚠ split
- **DiagExtensions** (function, CC=20) ⚠ split
- **TicketsPanel** (function, CC=20) ⚠ split
- **Sprint** (class, CC̄=7.0)
- **TicketManager** (class, CC̄=4.2)
  - `list_tickets` CC=17 ⚠ split
- **AccountCredentials** (class, CC̄=5.0)
- **ProjectsConfig** (class, CC̄=9.0)
- **_StateMixin** (class, CC̄=5.0)
- **_SnapshotMixin** (class, CC̄=5.0)

## Hotspots (High Fan-Out)

- **VoiceChat** — fan-out=54: Orchestrates 54 calls
- **chat_completions** — fan-out=32: OpenAI-compatible chat completions with intelligent routing.

Extra headers:
  X
- **run_all_tests** — fan-out=28: Run all diagnostic tests and return comprehensive status.
- **DiagnosticsPanel** — fan-out=22: Orchestrates 22 calls
- **useDashboardData** — fan-out=20: Orchestrates 20 calls
- **LogPanel** — fan-out=19: Orchestrates 19 calls
- **TicketsPanel** — fan-out=18: Orchestrates 18 calls

## Refactoring Priorities

| # | Action | Impact | Effort |
|---|--------|--------|--------|
| 1 | Split DiagnosticsPanel (CC=26 → target CC<10) | high | low |
| 2 | Split LogPanel (CC=34 → target CC<10) | high | low |
| 3 | Split VMsPanel (CC=32 → target CC<10) | high | low |
| 4 | Split VoiceChat (CC=70 → target CC<10) | high | low |
| 5 | Split DiagRooConfig (CC=29 → target CC<10) | high | low |
| 6 | Split god module src/proxym/dashboard/components/voice.jsx (521L, 0 classes) | high | high |
| 7 | Split god module htmlcov/coverage_html_cb_dd2e7eb5.js (735L, 0 classes) | high | high |
| 8 | Split god module src/proxym/api/diagnostics.py (715L, 0 classes) | high | high |
| 9 | Split god module src/proxym/ctl.py (895L, 0 classes) | high | high |
| 10 | Split god module src/proxym/mcp/self_server.py (533L, 8 classes) | high | high |

## Context for LLM

When suggesting changes:
1. Start from hotspots and high-CC functions
2. Follow refactoring priorities above
3. Maintain public API surface — keep backward compatibility
4. Prefer minimal, incremental changes

