"""Audio decoding and conversion utilities."""

from __future__ import annotations

import subprocess
from pathlib import Path

import numpy as np

SAMPLE_RATE = 16000


def decode_audio_input(
    input_data: bytes | np.ndarray | str | Path,
) -> np.ndarray:
    """Decode audio input to float32 mono 16kHz samples.

    Accepts:
    - bytes: raw audio file bytes (any format ffmpeg supports)
    - np.ndarray: float32 samples (returned as-is)
    - str | Path: file path to audio file
    """
    if isinstance(input_data, np.ndarray):
        if input_data.dtype == np.float32:
            return input_data
        return input_data.astype(np.float32)

    if isinstance(input_data, (str, Path)):
        input_data = Path(input_data).read_bytes()

    return _decode_with_ffmpeg(input_data)


def decode_audio_input_to_pcm16(
    input_data: bytes | np.ndarray | str | Path,
) -> bytes:
    """Decode audio input to mono 16kHz PCM16 little-endian bytes."""
    if isinstance(input_data, np.ndarray):
        return float32_to_pcm16(input_data.astype(np.float32, copy=False))

    if isinstance(input_data, (str, Path)):
        input_data = Path(input_data).read_bytes()

    return _decode_with_ffmpeg_pcm16(input_data)


def pcm16_to_float32(pcm16: bytes) -> np.ndarray:
    """Convert raw PCM16 bytes to float32 samples in [-1.0, 1.0]."""
    samples = np.frombuffer(pcm16, dtype=np.int16).astype(np.float32)
    return samples / 32768.0


def float32_to_pcm16(samples: np.ndarray) -> bytes:
    """Convert float32 samples in [-1, 1] to PCM16 bytes."""
    clipped = np.clip(samples.astype(np.float32, copy=False), -1.0, 1.0)
    pcm16 = (clipped * 32767.0).astype(np.int16)
    return pcm16.tobytes()


def get_audio_duration_seconds(
    samples: np.ndarray,
    sample_rate: int = SAMPLE_RATE,
) -> float:
    """Return duration in seconds."""
    return len(samples) / sample_rate


def get_pcm16_duration_seconds(
    pcm16: bytes,
    sample_rate: int = SAMPLE_RATE,
) -> float:
    """Return duration in seconds for mono PCM16 bytes."""
    return len(pcm16) / 2 / sample_rate


def _decode_with_ffmpeg(audio_bytes: bytes) -> np.ndarray:
    """Decode audio bytes using ffmpeg to mono 16kHz float32."""
    try:
        result = subprocess.run(
            [
                "ffmpeg",
                "-hide_banner",
                "-loglevel", "error",
                "-i", "pipe:0",
                "-f", "f32le",
                "-ac", "1",
                "-ar", str(SAMPLE_RATE),
                "pipe:1",
            ],
            input=audio_bytes,
            capture_output=True,
            check=True,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "ffmpeg is required for audio decoding but was not found in PATH"
        ) from None
    except subprocess.CalledProcessError as e:
        msg = e.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(
            f"failed to decode audio: {msg or f'ffmpeg exited with {e.returncode}'}"
        ) from None

    return np.frombuffer(result.stdout, dtype=np.float32)


def _decode_with_ffmpeg_pcm16(audio_bytes: bytes) -> bytes:
    """Decode audio bytes using ffmpeg to mono 16kHz PCM16."""
    try:
        result = subprocess.run(
            [
                "ffmpeg",
                "-hide_banner",
                "-loglevel", "error",
                "-i", "pipe:0",
                "-f", "s16le",
                "-ac", "1",
                "-ar", str(SAMPLE_RATE),
                "pipe:1",
            ],
            input=audio_bytes,
            capture_output=True,
            check=True,
        )
    except FileNotFoundError:
        raise RuntimeError(
            "ffmpeg is required for audio decoding but was not found in PATH"
        ) from None
    except subprocess.CalledProcessError as e:
        msg = e.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(
            f"failed to decode audio: {msg or f'ffmpeg exited with {e.returncode}'}"
        ) from None

    return bytes(result.stdout)
