"""Rust native STT engine bridge (direct PyO3 bindings)."""

from __future__ import annotations

import os

DEFAULT_LOCAL_MODEL_DTYPE = "fp16"

try:
    from genshi_stt_native import SttEngine as _NativeSttEngine  # type: ignore
except Exception:  # pragma: no cover - optional dependency path
    _NativeSttEngine = None


class NativeEngineAdapter:
    """Backward-compatible adapter around the PyO3 SttEngine class."""

    def __init__(self, inner) -> None:
        self._inner = inner

    def stop(self) -> None:
        return None

    def process_chunk(self, pcm16_chunk: bytes) -> str:
        return str(self._inner.process_chunk(pcm16_chunk))

    def process_chunk_texts(self, pcm16_chunk: bytes) -> list[str]:
        text = self.process_chunk(pcm16_chunk).strip()
        return [text] if text else []

    def transcribe_file(self, audio_bytes: bytes) -> str:
        return str(self._inner.transcribe_file(audio_bytes))

    def flush(self) -> str:
        return str(self._inner.flush())

    def flush_texts(self) -> list[str]:
        text = self.flush().strip()
        return [text] if text else []


def get_engine(
    model_path: str | None = None,
    dtype: str = DEFAULT_LOCAL_MODEL_DTYPE,
    decryption_key: bytes | None = None,
):
    """Return an activated native STT engine adapter."""
    if model_path is not None:
        raise ValueError("model_path is no longer supported; the native engine bundles its own fp16 model")
    if dtype != DEFAULT_LOCAL_MODEL_DTYPE:
        raise ValueError(f"only dtype={DEFAULT_LOCAL_MODEL_DTYPE!r} is supported by the native runtime")
    if _NativeSttEngine is None:
        raise RuntimeError("genshi_stt_native is not available")

    if decryption_key is None:
        env_key = os.getenv("GENSHI_STT_ENGINE_KEY", "").strip()
        if not env_key:
            raise RuntimeError("decryption_key is required when using low-level get_engine()")
        decryption_key = env_key.encode("utf-8")

    engine = _NativeSttEngine()
    engine.activate(decryption_key)
    return NativeEngineAdapter(engine)
