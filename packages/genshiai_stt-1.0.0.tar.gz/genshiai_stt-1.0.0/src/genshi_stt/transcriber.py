"""Realtime transcription primitives backed by the Rust native runtime."""

from __future__ import annotations

from dataclasses import dataclass
import asyncio
import json
import warnings


@dataclass
class TranscriptionEvent:
    """Event emitted during realtime transcription."""

    text: str
    raw_text: str = ""
    index: int | None = None
    processing_time_ms: int = 0
    type: str = "sentence"


@dataclass
class TranscriptionResult:
    """Result of a transcription operation."""

    text: str
    raw_text: str = ""
    processing_time_ms: int = 0


class RealtimeSession:
    """Thin async wrapper around the Rust realtime session."""

    def __init__(self, *, native_session) -> None:
        self._native = native_session
        self._closed = False
        self._has_activity = False

    async def __aenter__(self) -> "RealtimeSession":
        return self

    async def __aexit__(self, *args) -> None:
        if not self._closed:
            await self.finalize()

    async def push(
        self,
        pcm16_chunk: bytes,
        *,
        audio_duration_seconds: float | None = None,
    ) -> list[TranscriptionEvent]:
        return await self.push_audio(
            pcm16_chunk,
            audio_duration_seconds=audio_duration_seconds,
        )

    async def push_audio(
        self,
        pcm16_chunk: bytes,
        *,
        audio_duration_seconds: float | None = None,
    ) -> list[TranscriptionEvent]:
        payload = await _run_blocking(
            self._native.push_audio_sync,
            pcm16_chunk,
            audio_duration_seconds,
        )
        self._has_activity = True
        events = _parse_json_payload(payload)
        return [_event_from_payload(item) for item in events]

    async def finalize(
        self,
        *,
        audio_duration_seconds: float | None = None,
    ) -> TranscriptionResult:
        payload = await _run_blocking(
            self._native.finalize_sync,
            audio_duration_seconds,
        )
        self._closed = True
        return _result_from_payload(_parse_json_payload(payload))

    async def end(
        self,
        *,
        audio_duration_seconds: float | None = None,
    ) -> TranscriptionResult:
        return await self.finalize(audio_duration_seconds=audio_duration_seconds)

    async def close(self) -> None:
        if self._closed:
            return
        if self._has_activity:
            warnings.warn(
                "RealtimeSession.close() skips finalize(); use await session.finalize() for billing finalize.",
                stacklevel=2,
            )
        await _run_blocking(self._native.close)
        self._closed = True

    @property
    def text(self) -> str:
        return str(self._native.text())

    @property
    def sentences(self) -> list[str]:
        values = self._native.sentences()
        return [str(item) for item in values]


StreamSession = RealtimeSession


async def _run_blocking(func, *args):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: func(*args))


def _parse_json_payload(payload: str):
    return json.loads(payload)


def _result_from_payload(payload: dict) -> TranscriptionResult:
    text = str(payload.get("text", "")).strip()
    raw_text = str(payload.get("raw_text", ""))
    return TranscriptionResult(
        text=text or raw_text.strip() or "",
        raw_text=raw_text,
        processing_time_ms=int(payload.get("processing_time_ms", 0) or 0),
    )


def _event_from_payload(payload: dict) -> TranscriptionEvent:
    text = str(payload.get("text", "")).strip()
    raw_text = str(payload.get("raw_text", ""))
    index = payload.get("index")
    return TranscriptionEvent(
        text=text or raw_text.strip() or "",
        raw_text=raw_text,
        index=int(index) if index is not None else None,
        processing_time_ms=int(payload.get("processing_time_ms", 0) or 0),
        type=str(payload.get("type", "sentence")),
    )
