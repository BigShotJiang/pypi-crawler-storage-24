# Changelog

## 1.0.0 (2026-03-06)

Initial production release.

### Features
- Batch transcription via `client.transcribe(audio)` (Python / Node.js / Browser)
- Realtime streaming via `client.stream()` / `client.realtime()` with push-based audio input
- Built-in Silero VAD for voice activity detection
- Encrypted on-device STT model (fp16 ONNX) with Rust native runtime
- Platform-specific native extensions: macOS ARM64, Linux x64, Windows x64
- Browser SDK (`@genshiai/stt-web`) with ONNX Runtime Web + Transformers.js
- Domain-specific transcription support (medical, general)

### Packages
- `genshiai-stt` (PyPI) — Python SDK
- `genshiai-stt-native` (PyPI) — Python native extension (platform wheels)
- `@genshiai/stt` (npm) — Node.js SDK
- `@genshiai/stt-native-{platform}` (npm) — Node.js native addons
- `@genshiai/stt-web` (npm) — Browser SDK
