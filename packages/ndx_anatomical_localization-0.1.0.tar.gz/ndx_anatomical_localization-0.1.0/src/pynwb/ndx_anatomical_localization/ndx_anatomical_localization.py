import numpy as np
from hdmf.common import DynamicTable
from hdmf.utils import AllowPositional, get_docval
from pynwb.image import Image
from pynwb.ophys import OnePhotonSeries, TwoPhotonSeries

from pynwb import docval, get_class, register_class

TempSpace = get_class("Space", "ndx-anatomical-localization")


@register_class("Space", "ndx-anatomical-localization")
class Space(TempSpace):
    @docval(
        {"name": "name", "type": str, "doc": "name of the NWB object"},
        {"name": "space_name", "type": str, "doc": "name of the space"},
        {
            "name": "origin",
            "type": str,
            "doc": "A description of where (0,0,0) is in the space. For example, 'bregma' is a common origin for mice.",
        },
        {
            "name": "units",
            "type": str,
            "doc": "The units of measurement for the x,y,z coordinates. For example, 'mm' for millimeters.",
        },
        {
            "name": "orientation",
            "type": str,
            "doc": (
                """A 3-letter string indicating the positive direction along each axis, where the 1st letter
          is for x, 2nd for y, and 3rd for z. Each letter can be: A (Anterior), P (Posterior), L (Left),
          R (Right), S (Superior/Dorsal), or I (Inferior/Ventral). The three letters must cover all three
          anatomical dimensions (one from A/P, one from L/R, one from S/I). For example, 'RAS' means
          positive x is Right, positive y is Anterior, positive z is Superior.

          Notes:
          - These three dimensions are also commonly referred to as AP, ML, and DV.
          - This convention specifies positive directions (sometimes written as 'RAS+'), not origin
            location - use the 'origin' field to describe where (0,0,0) is located."""
            ),
        },
        {
            "name": "extent",
            "type": "array_data",
            "doc": "The spatial extent (bounding box dimensions) as [x, y, z]. Optional.",
            "default": None,
            "allow_none": True,
        },
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, name, space_name, origin, units, orientation, extent=None):
        assert len(orientation) == 3, "orientation must be a string of length 3"
        valid_values = ["A", "P", "L", "R", "S", "I"]
        for x in orientation:
            assert x in valid_values, "orientation must be a string of 'A', 'P', 'L', 'R', 'S', 'I'"

        map = {"A": "AP", "P": "AP", "L": "LR", "R": "LR", "S": "SI", "I": "SI"}
        new_var = [map[var] for var in orientation]
        assert len(set(new_var)) == 3, "orientation must be unique dimensions (AP, LR, SI)"

        if extent is not None:
            extent = np.asarray(extent, dtype=np.float64)
            if extent.shape != (3,):
                raise ValueError("extent must be an array of shape (3,)")
            if np.any(extent <= 0):
                raise ValueError("extent values must be positive")

        super().__init__(
            name=name, space_name=space_name, origin=origin, units=units, orientation=orientation, extent=extent
        )


# Get AllenCCFv3Space AFTER Space is registered, so it can see the registered Space class
TempAllenCCFv3Space = get_class("AllenCCFv3Space", "ndx-anatomical-localization")


@register_class("AllenCCFv3Space", "ndx-anatomical-localization")
class AllenCCFv3Space(TempAllenCCFv3Space):
    """
    The Allen Mouse Brain Common Coordinate Framework version 3 (2020).

    This canonical space represents the CCFv3 atlas with fixed orientation and origin.
    Uses PIR orientation (positive x=Posterior, positive y=Inferior, positive z=Right)
    with 10 micrometer resolution. The origin (0,0,0) is at the Anterior-Superior-Left (ASL)
    corner of the 3D image volume.

    The atlas extent is 13200 x 8000 x 11400 micrometers (AP x DV x ML).
    """

    @docval(
        {"name": "name", "type": str, "doc": "name of the NWB object", "default": "AllenCCFv3"},
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, name="AllenCCFv3"):
        super().__init__(
            name=name,
            space_name="AllenCCFv3",
            origin="Anterior-Superior-Left (ASL) corner of the 3D image volume",
            units="um",
            orientation="PIR",
            extent=np.array([13200.0, 8000.0, 11400.0]),
        )


TempD99v2Space = get_class("D99v2Space", "ndx-anatomical-localization")


@register_class("D99v2Space", "ndx-anatomical-localization")
class D99v2Space(TempD99v2Space):
    """
    The D99 macaque brain atlas version 2.0 (Reveley et al. 2017; Saleem et al. 2021).

    This canonical space uses RAS orientation (positive x=Right, positive y=Anterior,
    positive z=Superior) with millimeter units. The origin (0,0,0) is at the anterior commissure.
    """

    @docval(
        {"name": "name", "type": str, "doc": "name of the NWB object", "default": "D99v2"},
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, name="D99v2"):
        super().__init__(
            name=name,
            space_name="D99v2",
            origin=(
                "Anterior commissure (AC). Horizontal plane aligned to the AC-PC line"
                " (anterior commissure to posterior commissure)."
            ),
            units="mm",
            orientation="RAS",
        )


TempNMTv2Space = get_class("NMTv2Space", "ndx-anatomical-localization")


@register_class("NMTv2Space", "ndx-anatomical-localization")
class NMTv2Space(TempNMTv2Space):
    """
    The NIMH Macaque Template version 2.0 symmetric (Jung et al. 2021).

    This canonical space uses RAS orientation (positive x=Right, positive y=Anterior,
    positive z=Superior) with millimeter units. The origin (0,0,0) is at ear bar zero.
    """

    @docval(
        {"name": "name", "type": str, "doc": "name of the NWB object", "default": "NMTv2"},
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, name="NMTv2"):
        super().__init__(
            name=name,
            space_name="NMTv2",
            origin=(
                "Ear bar zero (EBZ): intersection of the midsagittal plane and the interaural line."
                " Horizontal plane aligned to the Horsley-Clarke stereotaxic convention."
            ),
            units="mm",
            orientation="RAS",
        )


TempNMTv2AsymmetricSpace = get_class("NMTv2AsymmetricSpace", "ndx-anatomical-localization")


@register_class("NMTv2AsymmetricSpace", "ndx-anatomical-localization")
class NMTv2AsymmetricSpace(TempNMTv2AsymmetricSpace):
    """
    The NIMH Macaque Template version 2.0 asymmetric (Jung et al. 2021).

    This canonical space uses RAS orientation (positive x=Right, positive y=Anterior,
    positive z=Superior) with millimeter units. The origin (0,0,0) is at ear bar zero.
    Unlike the symmetric variant, this template preserves population-level hemispheric differences.
    """

    @docval(
        {"name": "name", "type": str, "doc": "name of the NWB object", "default": "NMTv2Asymmetric"},
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, name="NMTv2Asymmetric"):
        super().__init__(
            name=name,
            space_name="NMTv2Asymmetric",
            origin=(
                "Ear bar zero (EBZ): intersection of the midsagittal plane and the interaural line."
                " Horizontal plane aligned to the Horsley-Clarke stereotaxic convention."
            ),
            units="mm",
            orientation="RAS",
        )


TempMEBRAINSSpace = get_class("MEBRAINSSpace", "ndx-anatomical-localization")


@register_class("MEBRAINSSpace", "ndx-anatomical-localization")
class MEBRAINSSpace(TempMEBRAINSSpace):
    """
    The MEBRAINS macaque brain atlas version 1.0 (Balan et al. 2024).

    This canonical space uses RAS orientation (positive x=Right, positive y=Anterior,
    positive z=Superior) with millimeter units. The origin (0,0,0) is at the anterior commissure.
    """

    @docval(
        {"name": "name", "type": str, "doc": "name of the NWB object", "default": "MEBRAINS"},
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, name="MEBRAINS"):
        super().__init__(
            name=name,
            space_name="MEBRAINS",
            origin="Anterior commissure (AC). Horizontal plane approximately aligned to the Horsley-Clarke convention.",
            units="mm",
            orientation="RAS",
        )


TempBrainRegionMasks = get_class("BrainRegionMasks", "ndx-anatomical-localization")


@register_class("BrainRegionMasks", "ndx-anatomical-localization")
class BrainRegionMasks(TempBrainRegionMasks):
    def _to_image(self, image_height: int, image_width: int) -> np.ndarray:
        """Reconstruct a 2D brain region ID array from the flat (x, y, brain_region_id) table.

        Parameters
        ----------
        image_height : int
            Height of the output array in pixels.
        image_width : int
            Width of the output array in pixels.

        Returns
        -------
        np.ndarray of shape (image_height, image_width), dtype int32
            Each pixel contains the brain_region_id at that location, or 0 where no mask entry exists.
        """
        img = np.zeros((image_height, image_width), dtype=np.int32)
        xs = self["x"].data[:]
        ys = self["y"].data[:]
        ids = self["brain_region_id"].data[:]
        img[ys, xs] = ids
        return img


Landmarks = get_class("Landmarks", "ndx-anatomical-localization")

# AffineTransformation: custom class adds shape validation on the matrix.
TempAffineTransformation = get_class("AffineTransformation", "ndx-anatomical-localization")


@register_class("AffineTransformation", "ndx-anatomical-localization")
class AffineTransformation(TempAffineTransformation):
    """A 3x3 affine transformation matrix in homogeneous coordinates.

    Supports 2D operations: translation, rotation, scaling, and shearing.
    """

    @docval(
        {"name": "name", "type": str, "doc": "name of the NWB object"},
        {
            "name": "affine_matrix",
            "type": "array_data",
            "doc": "3x3 affine transformation matrix in homogeneous coordinates",
        },
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, **kwargs):
        affine_matrix = np.asarray(kwargs["affine_matrix"], dtype=np.float64)
        if affine_matrix.shape != (3, 3):
            raise ValueError(f"Affine matrix must be a 3x3 array. Provided shape: {affine_matrix.shape}")
        kwargs["affine_matrix"] = affine_matrix
        super().__init__(**kwargs)


# AtlasRegistration: custom class validates that source_image and registered_image are provided.
TempAtlasRegistration = get_class("AtlasRegistration", "ndx-anatomical-localization")


@register_class("AtlasRegistration", "ndx-anatomical-localization")
class AtlasRegistration(TempAtlasRegistration):
    @docval(
        {
            "name": "source_image",
            "type": Image,
            "doc": "Image representing the source FOV.",
            "default": None,
            "allow_none": True,
        },
        {
            "name": "registered_image",
            "type": Image,
            "doc": "Image representing the registered FOV.",
            "default": None,
            "allow_none": True,
        },
        {
            "name": "atlas_projection",
            "type": Image,
            "doc": "The atlas projection image used as reference in the registration.",
            "default": None,
            "allow_none": True,
        },
        {
            "name": "affine_transformation",
            "type": AffineTransformation,
            "doc": "A spatial transformation used in the registration.",
            "default": None,
            "allow_none": True,
        },
        {
            "name": "landmarks",
            "type": Landmarks,
            "doc": "Landmarks used in the registration.",
            "default": None,
            "allow_none": True,
        },
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, **kwargs):
        if kwargs.get("source_image") is None:
            raise ValueError("'source_image' must be provided in AtlasRegistration.__init__")
        super().__init__(**kwargs)


# Get these AFTER Space and AllenCCFv3Space are registered
TempAnatomicalCoordinatesTable = get_class("AnatomicalCoordinatesTable", "ndx-anatomical-localization")
TempAnatomicalCoordinatesImage = get_class("AnatomicalCoordinatesImage", "ndx-anatomical-localization")
Localization = get_class("Localization", "ndx-anatomical-localization")


@register_class("AnatomicalCoordinatesTable", "ndx-anatomical-localization")
class AnatomicalCoordinatesTable(TempAnatomicalCoordinatesTable):
    @docval(
        {"name": "space", "type": Space, "doc": "space of the table"},
        {"name": "method", "type": str, "doc": "method of the table"},
        {
            "name": "target",
            "type": DynamicTable,
            "doc": 'target table. ignored if a "localized_entity" column is provided in "columns"',
            "default": None,
        },
        *get_docval(DynamicTable.__init__),
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, **kwargs):
        columns = kwargs.get("columns")
        target = kwargs.pop("target")
        if not columns or "localized_entity" not in [c.name for c in columns]:
            # set target table of "localized_entity" column only if not already in "columns"
            if target is None:
                raise ValueError(
                    '"target" (the target table that contains the objects that have these coordinates) '
                    "must be provided in AnatomicalCoordinatesTable.__init__ "
                    'if the "localized_entity" column is not in "columns".'
                )
            kwargs["target_tables"] = {"localized_entity": target}

        super().__init__(**kwargs)


@register_class("AnatomicalCoordinatesImage", "ndx-anatomical-localization")
class AnatomicalCoordinatesImage(TempAnatomicalCoordinatesImage):
    @docval(
        {"name": "name", "type": str, "doc": "name of the NWB object"},
        {"name": "description", "type": str, "doc": "description of the NWB object", "default": None},
        {"name": "space", "type": Space, "doc": "space of the image"},
        {"name": "method", "type": str, "doc": "method of the image"},
        {
            "name": "image",
            "type": Image,
            "doc": "The reference image (e.g. mean or max projection) on which the coordinate map is based",
        },
        {
            "name": "localized_entity",
            "type": (OnePhotonSeries, TwoPhotonSeries),
            "doc": "The imaging series (OnePhotonSeries or TwoPhotonSeries) that this coordinate map applies to",
            "default": None,
            "allow_none": True,
        },
        {
            "name": "x",
            "type": ("array_data", "data"),
            "doc": "2D array containing X coordinates for each pixel (width x height)",
        },
        {
            "name": "y",
            "type": ("array_data", "data"),
            "doc": "2D array containing Y coordinates for each pixel (width x height)",
        },
        {
            "name": "z",
            "type": ("array_data", "data"),
            "doc": "2D array containing Z coordinates for each pixel (width x height)",
        },
        {
            "name": "brain_region",
            "type": ("array_data", "data"),
            "doc": "2D array of brain region names for each pixel",
            "default": None,
        },
        allow_positional=AllowPositional.ERROR,
    )
    def __init__(self, **kwargs):
        image = kwargs.get("image")
        x = kwargs["x"]
        y = kwargs["y"]
        z = kwargs["z"]
        if x.shape != image.data.shape or y.shape != image.data.shape or z.shape != image.data.shape:
            raise ValueError(
                f'"x", "y", and "z" must have the same shape as the image data. '
                f"x.shape: {x.shape}, y.shape: {y.shape}, z.shape: {z.shape}, "
                f"image.data.shape: {image.data.shape}"
            )
        super().__init__(**kwargs)

    def get_coordinates(self, i=None, j=None):
        """Get the anatomical coordinates at a specific pixel or for the entire image.

        Args:
            i (int, optional): The row index of the pixel. Defaults to None.
            j (int, optional): The column index of the pixel. Defaults to None.
        Returns:
            tuple or np.ndarray: The anatomical coordinates at the specified pixel (i, j) as a tuple,
            or the entire coordinate arrays stacked along the last axis if i and j are not provided.
        """

        import numpy as np

        if i is not None and j is not None:
            return (self.x[i, j], self.y[i, j], self.z[i, j])
        else:
            return np.stack([self.x[:], self.y[:], self.z[:]], axis=-1)
