"""
Quant Module

Provides quantitative analysis tools including indicators, factors, quotes, and backtesting.
Based on Mai-language syntax compatible with TongDaXin/TongHuaShun.
"""

from typing import Any, Literal

import pandas as pd


StockMarket = Literal["cn", "hk", "us"]


class QuantModule:
    """
    Quantitative analysis module

    Access technical indicators, factors, OHLCV quotes, and backtesting functionality.
    Uses Mai-language syntax for formulas.

    Example:
        >>> quant = client.quant
        >>> # Compute RSI indicator
        >>> df = quant.indicators_compute(["000001"], "RSI(14)")
        >>> # Screen stocks by formula
        >>> stocks = quant.factors_screen(formula="RSI(14) < 30")
    """

    def __init__(self, client):
        self._client = client

    # -------------------------------------------------------------------------
    # Indicators
    # -------------------------------------------------------------------------

    def indicators(self) -> list[dict[str, Any]]:
        """
        Get list of available technical indicators

        All indicators are functions and require parentheses when used (e.g., MA(CLOSE, 20), RSI(14), MACD()).

        Returns:
            List of indicator definitions with name, description, and fields

        Example:
            >>> indicators = client.quant.indicators()
            >>> for ind in indicators:
            ...     print(f"{ind['name']}: {ind['description']}")
            ...     print(f"  Fields: {ind['fields']}")
        """
        return self._client._get("/v1/quant/indicators")

    def indicators_compute(
        self,
        symbols: list[str],
        formula: str,
        *,
        market: StockMarket = "cn",
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """
        Compute indicator values for given symbols

        Variables vs Functions:
            - Variables (no parentheses): CLOSE, OPEN, HIGH, LOW, VOLUME (aliases: C, O, H, L, V, VOL)
            - Functions (TongDaXin style: col first, n second): MA(CLOSE, 20), RSI(14), MACD(), etc.

        Args:
            symbols: List of stock codes (e.g., ["000001", "600519"])
            formula: Indicator formula (e.g., "RSI(14)", "MACD()", "MACD(12,26,9)")
            market: Stock market ("cn", "hk", "us"), default "cn"
            start_date: Start date (YYYY-MM-DD), default 3 months ago
            end_date: End date (YYYY-MM-DD), default today

        Returns:
            DataFrame with indicator values

        Example:
            >>> # RSI indicator
            >>> df = client.quant.indicators_compute(["000001"], "RSI(14)")
            >>> print(df[["symbol", "date", "rsi"]])
            
            >>> # MACD indicator
            >>> df = client.quant.indicators_compute(["000001"], "MACD()")
            >>> print(df[["symbol", "date", "dif", "dea", "macd"]])
            
            >>> # KDJ indicator
            >>> df = client.quant.indicators_compute(["000001"], "KDJ(9,3,3)")
            >>> print(df[["symbol", "date", "k", "d", "j"]])
            
            >>> # Standard deviation
            >>> df = client.quant.indicators_compute(["000001"], "STD(CLOSE, 20)")
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "formula": formula,
            "market": market,
        }
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._client._post("/v1/quant/indicators/compute", json=data)
        return self._to_dataframe(response.get("datas", []))

    # -------------------------------------------------------------------------
    # Factors
    # -------------------------------------------------------------------------

    def factors(self) -> list[dict[str, Any]]:
        """
        Get list of available factors (variables and functions)

        Variables vs Functions:
            - Variables (no parentheses): CLOSE, OPEN, HIGH, LOW, VOLUME, PE_TTM, ROE_TTM, etc.
            - Functions (TongDaXin style: col first, n second): MA(CLOSE, 20), PE(), ROE(), RSI(14), etc.

        Returns factors organized by level:
        - Level 0 Variables: CLOSE, OPEN, HIGH, LOW, VOLUME (price data, no parentheses)
        - Level 0 Functions: MA(), EMA(), REF(), HHV(), LLV(), STD(), etc. (require parentheses)
        - Level 1 Functions: CROSS(), COUNT(), EVERY(), etc. (require parentheses)
        - Level 2 Functions: MACD(), KDJ(), RSI(), BOLL(), PE(), ROE(), etc. (require parentheses)

        Returns:
            List of factor definitions

        Example:
            >>> factors = client.quant.factors()
            >>> for f in factors:
            ...     print(f"{f['name']} ({f['type']}, level {f['level']})")
        """
        return self._client._get("/v1/quant/factors")

    def factors_compute(
        self,
        symbols: list[str],
        formula: str,
        *,
        market: StockMarket = "cn",
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """
        Compute factor values for given symbols

        Uses Mai-language syntax compatible with TongDaXin/TongHuaShun.

        Variables vs Functions:
            - Variables (no parentheses): CLOSE, OPEN, HIGH, LOW, VOLUME
            - Functions (TongDaXin style: col first, n second): MA(CLOSE, 20), PE(), ROE(), RSI(14), etc.

        Args:
            symbols: List of stock codes
            formula: Factor formula using Mai-language syntax
            market: Stock market ("cn", "hk", "us"), default "cn"
            start_date: Start date (YYYY-MM-DD), default 3 months ago
            end_date: End date (YYYY-MM-DD), default today

        Returns:
            DataFrame with factor values

        Example:
            >>> # Simple indicator
            >>> df = client.quant.factors_compute(["000001"], "RSI(14)")
            
            >>> # MACD DIF line
            >>> df = client.quant.factors_compute(["000001"], "MACD().dif")
            
            >>> # Close above 20-day MA (boolean)
            >>> df = client.quant.factors_compute(["000001"], "CLOSE > MA(CLOSE, 20)")
            
            >>> # Deviation from MA20 in percent
            >>> df = client.quant.factors_compute(["000001"], "(CLOSE - MA(CLOSE, 20)) / MA(CLOSE, 20) * 100")
            
            >>> # Fundamental factors (note: functions require parentheses)
            >>> df = client.quant.factors_compute(["000001"], "PE()")
            >>> df = client.quant.factors_compute(["000001"], "ROE()")

        Supported Operators:
            - Comparison: >, <, >=, <=, ==, !=
            - Logical: & or AND, | or OR, ~ or NOT (case-insensitive)
            - Arithmetic: +, -, *, /
            - Important: expressions on both sides of logical operators (&/|/AND/OR) must be wrapped in ()

        Supported Variables (no parentheses):
            - CLOSE, C: Close price
            - OPEN, O: Open price
            - HIGH, H: High price
            - LOW, L: Low price
            - VOLUME, V, VOL: Volume

        Supported Functions (require parentheses):
            - Technical: MA(), EMA(), RSI(), MACD(), BOLL(), etc.
            - Fundamental: PE(), PB(), ROE(), ROA(), etc.
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "formula": formula,
            "market": market,
        }
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._client._post("/v1/quant/factors/compute", json=data)
        return self._to_dataframe(response.get("datas", []))

    def factors_screen(
        self,
        formula: str,
        *,
        market: StockMarket = "cn",
        check_date: str | None = None,
        symbols: list[str] | None = None,
    ) -> pd.DataFrame:
        """
        Screen stocks based on factor formula

        Returns stocks where the formula evaluates to True (for boolean formulas)
        or non-null (for numeric formulas).

        Variables vs Functions:
            - Variables (no parentheses): CLOSE, OPEN, HIGH, LOW, VOLUME
            - Functions (TongDaXin style: col first, n second): MA(CLOSE, 20), PE(), ROE(), RSI(14), etc.

        Args:
            formula: Screening formula using Mai-language syntax
            market: Stock market ("cn", "hk", "us"), default "cn"
            check_date: Check date (YYYY-MM-DD), default latest trading day
            symbols: Stock codes to screen (None = full market)

        Returns:
            DataFrame with stocks that passed the filter

        Example:
            >>> # RSI oversold
            >>> stocks = client.quant.factors_screen(formula="RSI(14) < 30")
            
            >>> # Golden cross
            >>> stocks = client.quant.factors_screen(formula="CROSS(MA(CLOSE, 5), MA(CLOSE, 10))")
            
            >>> # Uptrend
            >>> stocks = client.quant.factors_screen(formula="(CLOSE > MA(CLOSE, 20)) & (MA(CLOSE, 20) > MA(CLOSE, 60))")
            
            >>> # Above upper Bollinger Band
            >>> stocks = client.quant.factors_screen(formula="CLOSE > BOLL(20, 2).upper")
            
            >>> # Fundamental screening (note: functions require parentheses)
            >>> stocks = client.quant.factors_screen(formula="(PE() < 20) & (ROE() > 0.15)")
            
            >>> # Screen specific stocks
            >>> stocks = client.quant.factors_screen(
            ...     formula="RSI(14) < 30",
            ...     symbols=["000001", "600519", "000002"]
            ... )
        """
        data: dict[str, Any] = {
            "formula": formula,
            "market": market,
        }
        if check_date:
            data["check_date"] = check_date
        if symbols:
            data["symbols"] = symbols

        response = self._client._post("/v1/quant/factors/screen", json=data)
        return self._to_dataframe(response.get("datas", []))

    # -------------------------------------------------------------------------
    # Quotes
    # -------------------------------------------------------------------------

    def ohlcv(
        self,
        symbol: str,
        *,
        market: StockMarket = "cn",
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """
        Get OHLCV (Open, High, Low, Close, Volume) daily data for a single symbol

        Args:
            symbol: Stock code
            market: Stock market ("cn", "hk", "us"), default "cn"
            start_date: Start date (YYYY-MM-DD), default 1 month ago
            end_date: End date (YYYY-MM-DD), default today

        Returns:
            DataFrame with OHLCV data

        Example:
            >>> df = client.quant.ohlcv("000001")
            >>> print(df[["open", "high", "low", "close", "volume"]])
        """
        params: dict[str, Any] = {
            "symbol": symbol,
            "market": market,
        }
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date

        response = self._client._get("/v1/quant/quotes/ohlcv", params=params)
        return self._to_dataframe(response.get("datas", []))

    def ohlcv_batch(
        self,
        symbols: list[str],
        *,
        market: StockMarket = "cn",
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> pd.DataFrame:
        """
        Get OHLCV data for multiple symbols

        Args:
            symbols: List of stock codes
            market: Stock market ("cn", "hk", "us"), default "cn"
            start_date: Start date (YYYY-MM-DD), default 1 month ago
            end_date: End date (YYYY-MM-DD), default today

        Returns:
            DataFrame with OHLCV data sorted by date (descending), then by symbol

        Example:
            >>> df = client.quant.ohlcv_batch(["000001", "600519"])
            >>> print(df[["symbol", "date", "close", "volume"]])
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "market": market,
        }
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._client._post("/v1/quant/quotes/ohlcv/batch", json=data)
        return self._to_dataframe(response.get("datas", []))

    def kline_1m(
        self,
        symbol: str,
        start_datetime: str,
        end_datetime: str,
        *,
        market: StockMarket = "cn",
    ) -> pd.DataFrame:
        """
        Get 1-minute kline data for a single symbol

        Args:
            symbol: Stock code
            start_datetime: Start datetime (YYYY-MM-DD HH:MM:SS)
            end_datetime: End datetime (YYYY-MM-DD HH:MM:SS)
            market: Stock market ("cn", "hk", "us"), default "cn"

        Returns:
            DataFrame with 1-minute kline data

        Example:
            >>> df = client.quant.kline_1m(
            ...     symbol="000001",
            ...     start_datetime="2024-01-01 09:30:00",
            ...     end_datetime="2024-01-01 15:00:00"
            ... )
            >>> print(df[["datetime", "open", "high", "low", "close", "volume"]])
        """
        params: dict[str, Any] = {
            "symbol": symbol,
            "start_datetime": start_datetime,
            "end_datetime": end_datetime,
            "market": market,
        }
        response = self._client._get("/v1/quant/quotes/1mkline", params=params)
        return self._to_dataframe(response.get("datas", []))

    def kline_1m_batch(
        self,
        symbols: list[str],
        start_datetime: str,
        end_datetime: str,
        *,
        market: StockMarket = "cn",
    ) -> pd.DataFrame:
        """
        Get batch 1-minute kline data for multiple symbols

        Args:
            symbols: List of stock codes
            start_datetime: Start datetime (YYYY-MM-DD HH:MM:SS)
            end_datetime: End datetime (YYYY-MM-DD HH:MM:SS)
            market: Stock market ("cn", "hk", "us"), default "cn"

        Returns:
            DataFrame with 1-minute kline data sorted by date (ascending), then by symbol

        Example:
            >>> df = client.quant.kline_1m_batch(
            ...     symbols=["000001", "600519"],
            ...     start_datetime="2024-01-01 09:30:00",
            ...     end_datetime="2024-01-01 15:00:00"
            ... )
            >>> print(df[["symbol", "datetime", "close", "volume"]])
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "start_datetime": start_datetime,
            "end_datetime": end_datetime,
            "market": market,
        }
        response = self._client._post("/v1/quant/quotes/1mkline/batch", json=data)
        return self._to_dataframe(response.get("datas", []))

    def minute(
        self,
        symbol: str,
        start_datetime: str,
        end_datetime: str,
        *,
        market: StockMarket = "cn",
    ) -> pd.DataFrame:
        """
        Get minute data for a single symbol

        Args:
            symbol: Stock code
            start_datetime: Start datetime (YYYY-MM-DD HH:MM:SS)
            end_datetime: End datetime (YYYY-MM-DD HH:MM:SS)
            market: Stock market ("cn", "hk", "us"), default "cn"

        Returns:
            DataFrame with minute data

        Example:
            >>> df = client.quant.minute(
            ...     symbol="000001",
            ...     start_datetime="2024-01-01 09:30:00",
            ...     end_datetime="2024-01-01 15:00:00"
            ... )
            >>> print(df[["datetime", "open", "high", "low", "close", "volume"]])
        """
        params: dict[str, Any] = {
            "symbol": symbol,
            "start_datetime": start_datetime,
            "end_datetime": end_datetime,
            "market": market,
        }
        response = self._client._get("/v1/quant/quotes/minute", params=params)
        return self._to_dataframe(response.get("datas", []))

    def minute_batch(
        self,
        symbols: list[str],
        start_datetime: str,
        end_datetime: str,
        *,
        market: StockMarket = "cn",
    ) -> pd.DataFrame:
        """
        Get batch minute data for multiple symbols

        Args:
            symbols: List of stock codes
            start_datetime: Start datetime (YYYY-MM-DD HH:MM:SS)
            end_datetime: End datetime (YYYY-MM-DD HH:MM:SS)
            market: Stock market ("cn", "hk", "us"), default "cn"

        Returns:
            DataFrame with minute data sorted by date (ascending), then by symbol

        Example:
            >>> df = client.quant.minute_batch(
            ...     symbols=["000001", "600519"],
            ...     start_datetime="2024-01-01 09:30:00",
            ...     end_datetime="2024-01-01 15:00:00"
            ... )
            >>> print(df[["symbol", "datetime", "close", "volume"]])
        """
        data: dict[str, Any] = {
            "symbols": symbols,
            "start_datetime": start_datetime,
            "end_datetime": end_datetime,
            "market": market,
        }
        response = self._client._post("/v1/quant/quotes/minute/batch", json=data)
        return self._to_dataframe(response.get("datas", []))

    # -------------------------------------------------------------------------
    # Backtest
    # -------------------------------------------------------------------------

    def backtest(
        self,
        start_date: str,
        end_date: str,
        *,
        symbols: list[str] | None = None,
        filter_formula: str | None = None,
        entry_formula: str | None = None,
        strategy_code: str | None = None,
        exit_formula: str | None = None,
        market: StockMarket = "cn",
        initial_cash: float = 100000.0,
        commission: float = 0.0,
        stop_loss: float = 0.0,
        position_size: float = 0.2,
        max_positions: int = 5,
        min_volume: int = 100,
        auto_close: bool = True,
        signal_factors: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """
        Execute strategy backtest

        Variables vs Functions:
            - Variables (no parentheses): CLOSE, OPEN, HIGH, LOW, VOLUME
            - Functions (TongDaXin style: col first, n second): MA(CLOSE, 20), PE(), ROE(), RSI(14), etc.

        Args:
            start_date: Backtest start date (YYYY-MM-DD)
            end_date: Backtest end date (YYYY-MM-DD)
            symbols: List of stock codes (optional if filter_formula is provided)
            filter_formula: Pre-filter formula, e.g., 'NOT(IS_ST)'
            entry_formula: Buy/long entry formula (result > 0 triggers buy)
            strategy_code: Custom backtest strategy Python code. Must define `def handle_data(context, datas):`
            exit_formula: Sell/close formula (result > 0 triggers sell), optional
            market: Stock market ("cn", "hk", "us"), default "cn"
            initial_cash: Initial capital (default: 100000.0)
            commission: Commission rate (default: 0.0)
            stop_loss: Stop loss setting (default: 0.0, no stop loss)
            position_size: Max position size ratio per stock based on total assets (default: 0.2)
            max_positions: Max number of holding stocks (default: 5)
            min_volume: Minimum trading volume, e.g., 100 for A-shares (default: 100)
            auto_close: Auto close positions (default: True)
            signal_factors: Signal factors dictionary for custom strategy pre-computation

        Returns:
            Backtest results including:
            - success: Whether backtest succeeded
            - initial_cash: Initial capital
            - final_cash: Final capital
            - total_return: Total return
            - total_return_pct: Total return percentage
            - max_drawdown: Maximum drawdown
            - profit_factor: Profit factor
            - win_rate: Win rate
            - total_trades: Total number of trades
            - winning_trades: Number of winning trades
            - losing_trades: Number of losing trades
            - trades: List of trade details
            - portfolio_value: Daily portfolio values
            - error_msg: Error message if failed

        Example:

            >>> # Simple golden cross strategy
            >>> result = client.quant.backtest(
            ...     start_date="2023-01-01",
            ...     end_date="2024-01-01",
            ...     symbols=["000001"],
            ...     entry_formula="CROSS(MA(CLOSE, 5), MA(CLOSE, 20))",  # Buy when MA5 crosses above MA20
            ...     initial_cash=100000
            ... )
            >>> print(f"Total Return: {result['total_return_pct']:.2%}")
            >>> print(f"Max Drawdown: {result['max_drawdown']:.2%}")
            >>> print(f"Win Rate: {result['win_rate']:.2%}")
            
            >>> # Strategy with entry and exit signals
            >>> result = client.quant.backtest(
            ...     start_date="2023-01-01",
            ...     end_date="2024-01-01",
            ...     symbols=["000001"],
            ...     entry_formula="CROSS(MA(CLOSE, 5), MA(CLOSE, 20))",  # Buy signal
            ...     exit_formula="CROSSDOWN(MA(CLOSE, 5), MA(CLOSE, 20))"  # Sell signal
            ... )
            
            >>> # With custom python strategy code
            >>> strategy = '''
            ... def handle_data(context, datas):
            ...     for data in datas:
            ...         symbol = data.name
            ...         if not context.portfolio.get_position(symbol):
            ...             if data.pe < 20 and data.rsi < 30:  # Use pre-calculated factors
            ...                 context.order_target_percent(symbol, 0.2)
            ...         elif data.rsi > 70:
            ...             context.order_target_percent(symbol, 0)
            ... '''
            >>> result = client.quant.backtest(
            ...     start_date="2023-01-01", end_date="2023-12-31",
            ...     symbols=["000001"],
            ...     signal_factors={"rsi": "RSI(14)", "pe": "PE_TTM()"},
            ...     strategy_code=strategy
            ... )
        """
        data: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
            "market": market,
            "initial_cash": initial_cash,
            "commission": commission,
            "stop_loss": stop_loss,
            "position_size": position_size,
            "max_positions": max_positions,
            "min_volume": min_volume,
            "auto_close": auto_close,
        }
        if symbols is not None:
            data["symbols"] = symbols
        if filter_formula is not None:
            data["filter_formula"] = filter_formula
        if entry_formula is not None:
            data["entry_formula"] = entry_formula
        if strategy_code is not None:
            data["strategy_code"] = strategy_code
        if exit_formula is not None:
            data["exit_formula"] = exit_formula
        if signal_factors is not None:
            data["signal_factors"] = signal_factors

        return self._client._post("/v1/quant/backtest", json=data)

    # -------------------------------------------------------------------------
    # Helper Methods
    # -------------------------------------------------------------------------

    def _to_dataframe(self, data: list[dict[str, Any]]) -> pd.DataFrame:
        """Convert API response to DataFrame"""
        if not data:
            return pd.DataFrame()
        df = pd.DataFrame(data)
        # Convert date columns if present
        for col in ["date", "check_date", "trade_date"]:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col])
        return df
