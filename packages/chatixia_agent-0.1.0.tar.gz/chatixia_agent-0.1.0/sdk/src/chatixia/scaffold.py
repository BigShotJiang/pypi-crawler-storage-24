"""Agent manifest scaffolding for ``chatixia init``."""

from __future__ import annotations

from pathlib import Path

_MANIFEST_TEMPLATE = """\
# Chatixia Agent Manifest
# https://github.com/Chatixia-AI/chatixia-agent

name: {name}
description: ""

# LLM provider: azure | openai | ollama
provider: azure
# model: gpt-5.2   # Override default model

# System prompt — defines the agent's persona and behaviour
prompt: |
  You are a helpful AI assistant.
  Use the available tools to help the user.

# Skills configuration
skills:
  builtin:
    - calculator
    - echo
  # dirs:                  # Additional skill directories
  #   - ./skills
  # disabled:              # Skills to exclude
  #   - summarizer

# Goals (activated with `chatixia run --daemon`)
# goals:
#   - name: example_monitor
#     sensor: "Check for new items"
#     action: "Summarize and report"
#     interval: 300        # seconds
#     autonomy: auto       # auto | notify | approve

# MCP servers
# mcp_servers:
#   playwright:
#     command: npx
#     args: [-y, "@playwright/mcp@latest"]

# Environment variables
env:
  file: .env
  required:
    - AZURE_OPENAI_ENDPOINT
    - AZURE_OPENAI_API_KEY
    - AZURE_OPENAI_DEPLOYMENT

# Runtime settings
# max_turns: 10
# context_window: 120000
# data_dir: .chatixia
"""

_ENV_EXAMPLE = """\
# ──────────────────────────────────────────────
# Chatixia Agent — Environment Variables
# ──────────────────────────────────────────────

# Azure OpenAI (provider: azure)
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=
AZURE_OPENAI_DEPLOYMENT=gpt-5.2

# OpenAI (provider: openai)
# OPENAI_API_KEY=
# OPENAI_MODEL=gpt-4o

# Ollama (provider: ollama)
# OLLAMA_BASE_URL=http://localhost:11434/v1
# OLLAMA_MODEL=qwen3.5:4b

# Logging
# LOG_LEVEL=WARNING
# LOG_FORMAT=json
"""


def write_scaffold(name: str, directory: str = ".") -> Path:
    """Write an agent manifest scaffold to *directory*.

    Returns the path to the created ``agent.yaml``.
    """
    dir_path = Path(directory)
    dir_path.mkdir(parents=True, exist_ok=True)

    manifest_path = dir_path / "agent.yaml"
    if manifest_path.exists():
        raise FileExistsError(f"{manifest_path} already exists")

    manifest_path.write_text(
        _MANIFEST_TEMPLATE.format(name=name),
        encoding="utf-8",
    )

    env_example = dir_path / ".env.example"
    if not env_example.exists():
        env_example.write_text(_ENV_EXAMPLE, encoding="utf-8")

    print(f"✨ Created {manifest_path}")
    print("   1. Copy .env.example → .env and fill in credentials")
    print(f"   2. Run:  chatixia run {manifest_path}")

    return manifest_path
