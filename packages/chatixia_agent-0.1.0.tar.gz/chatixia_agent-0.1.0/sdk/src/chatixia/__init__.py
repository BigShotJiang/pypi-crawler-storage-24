"""Chatixia — deploy and run AI agents locally."""

from __future__ import annotations

import sys
from pathlib import Path

__version__ = "0.1.0"

# ---------------------------------------------------------------------------
# Core module bootstrap
# ---------------------------------------------------------------------------
# The existing core modules (skills.py, session.py, database.py, …) use flat
# imports like ``from logging_config import get_logger``.  They need their
# containing directory on sys.path.
#
#   • Wheel builds: hatch force-include copies core/ → chatixia/_core/
#   • Editable installs: fall back to the monorepo's core/ directory.
# ---------------------------------------------------------------------------
_pkg_dir = Path(__file__).resolve().parent
_vendored_core = _pkg_dir / "_core"
_dev_core = _pkg_dir.parent.parent.parent / "core"  # sdk/../core

if _vendored_core.is_dir() and (_vendored_core / "skills.py").exists():
    _core_path = str(_vendored_core)
elif _dev_core.is_dir() and (_dev_core / "skills.py").exists():
    _core_path = str(_dev_core)
else:
    _core_path = None

if _core_path and _core_path not in sys.path:
    sys.path.insert(0, _core_path)
