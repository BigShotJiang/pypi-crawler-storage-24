"""Allow running as ``python -m chatixia``."""

from chatixia.cli import main

raise SystemExit(main())
