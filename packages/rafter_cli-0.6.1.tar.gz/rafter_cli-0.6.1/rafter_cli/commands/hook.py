"""Hook handlers for agent platform integration."""
from __future__ import annotations

import json
import subprocess
import sys

import typer

from ..core.audit_logger import AuditLogger
from ..core.command_interceptor import CommandInterceptor
from ..scanners.regex_scanner import RegexScanner

hook_app = typer.Typer(name="hook", help="Hook handlers for agent platform integration", no_args_is_help=True)

_RISK_LABELS = {
    "critical": "CRITICAL", "high": "HIGH", "medium": "MEDIUM", "low": "LOW",
}

_RISK_DESCRIPTIONS = {
    "critical": "irreversible system damage",
    "high": "significant system changes",
    "medium": "moderate risk operation",
    "low": "minimal risk",
}


def _format_blocked_message(command: str, evaluation) -> str:
    cmd_display = command[:60] + "..." if len(command) > 60 else command
    rule = evaluation.matched_pattern or "policy violation"
    label = _RISK_LABELS.get(evaluation.risk_level, evaluation.risk_level.upper())
    desc = _RISK_DESCRIPTIONS.get(evaluation.risk_level, "")
    return f"\u2717 Rafter blocked: {cmd_display}\n  Rule: {rule}\n  Risk: {label}\u2014{desc}"


def _format_approval_message(command: str, evaluation) -> str:
    cmd_display = command[:60] + "..." if len(command) > 60 else command
    rule = evaluation.matched_pattern or "policy match"
    label = _RISK_LABELS.get(evaluation.risk_level, evaluation.risk_level.upper())
    desc = _RISK_DESCRIPTIONS.get(evaluation.risk_level, "")
    return (
        f"\u26a0 Rafter: approval required\n"
        f"  Command: {cmd_display}\n"
        f"  Rule: {rule}\n"
        f"  Risk: {label}\u2014{desc}\n"
        f"\n"
        f'To approve: rafter agent exec --approve "{command}"\n'
        f"To configure: rafter agent config set agent.riskLevel minimal"
    )


_STDIN_TIMEOUT_S = 5

def _read_stdin() -> str:
    import threading
    result: list[str] = [""]
    def _reader() -> None:
        try:
            result[0] = sys.stdin.read()
        except Exception:
            pass
    t = threading.Thread(target=_reader, daemon=True)
    t.start()
    t.join(timeout=_STDIN_TIMEOUT_S)
    return result[0]


def _write_decision(decision: dict) -> None:
    sys.stdout.write(json.dumps(decision) + "\n")
    sys.stdout.flush()


def _scan_staged_files() -> dict:
    try:
        output = subprocess.run(
            ["git", "diff", "--cached", "--name-only", "--diff-filter=ACM"],
            capture_output=True, text=True,
        ).stdout.strip()
        if not output:
            return {"secrets_found": False, "count": 0, "files": 0}
        staged = [f for f in output.split("\n") if f.strip()]
        scanner = RegexScanner()
        results = scanner.scan_files(staged)
        total = sum(len(r.matches) for r in results)
        return {"secrets_found": len(results) > 0, "count": total, "files": len(results)}
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as exc:
        print(f"rafter: staged file scan failed: {exc}", file=sys.stderr)
        return {"secrets_found": False, "count": 0, "files": 0}


def _evaluate_bash(command: str) -> dict:
    interceptor = CommandInterceptor()
    audit = AuditLogger()
    evaluation = interceptor.evaluate(command)

    # Blocked — hard deny
    if not evaluation.allowed and not evaluation.requires_approval:
        audit.log_command_intercepted(command, False, "blocked", evaluation.reason)
        return {"decision": "deny", "reason": _format_blocked_message(command, evaluation)}

    # Requires approval — deny (hook can't prompt interactively)
    if evaluation.requires_approval:
        audit.log_command_intercepted(command, False, "blocked", evaluation.reason)
        return {"decision": "deny", "reason": _format_approval_message(command, evaluation)}

    # Git commit/push — scan staged files
    trimmed = command.strip()
    if trimmed.startswith(("git commit", "git push")):
        result = _scan_staged_files()
        if result["secrets_found"]:
            audit.log_secret_detected("staged files", f"{result['count']} secret(s)", "blocked")
            return {
                "decision": "deny",
                "reason": f"{result['count']} secret(s) detected in {result['files']} staged file(s). "
                          "Run 'rafter scan local --staged' for details.",
            }

    audit.log_command_intercepted(command, True, "allowed")
    return {"decision": "allow"}


def _evaluate_write(tool_input: dict) -> dict:
    content = tool_input.get("content", "") or tool_input.get("new_string", "")
    if not content:
        return {"decision": "allow"}

    scanner = RegexScanner()
    if scanner.has_secrets(content):
        matches = scanner.scan_text(content)
        names = list({m.pattern.name for m in matches})
        audit = AuditLogger()
        audit.log_secret_detected(
            tool_input.get("file_path", "file content"),
            ", ".join(names),
            "blocked",
        )
        return {"decision": "deny", "reason": f"Secret detected in file content: {', '.join(names)}"}

    return {"decision": "allow"}


@hook_app.command("pretool")
def pretool():
    """PreToolUse hook handler. Reads tool input JSON from stdin, writes decision to stdout."""
    try:
        raw = _read_stdin()

        try:
            payload = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            _write_decision({"decision": "allow"})
            return

        # Validate payload is a dict with expected shape
        if not isinstance(payload, dict):
            _write_decision({"decision": "allow"})
            return

        tool_name = payload.get("tool_name", "")
        tool_input = payload.get("tool_input") or {}

        if not isinstance(tool_input, dict):
            tool_input = {}

        if tool_name == "Bash":
            decision = _evaluate_bash(tool_input.get("command", ""))
        elif tool_name in ("Write", "Edit"):
            decision = _evaluate_write(tool_input)
        else:
            decision = {"decision": "allow"}

        _write_decision(decision)
    except Exception:
        # Any unexpected error -> fail open
        _write_decision({"decision": "allow"})


@hook_app.command("posttool")
def posttool():
    """PostToolUse hook handler. Reads tool response JSON from stdin, redacts secrets in output, writes action to stdout."""
    try:
        raw = _read_stdin()

        try:
            payload = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            _write_decision({"action": "continue"})
            return

        # Validate payload is a dict
        if not isinstance(payload, dict):
            _write_decision({"action": "continue"})
            return

        tool_response = payload.get("tool_response")
        tool_name = payload.get("tool_name", "unknown")

        # No response body — pass through
        if not tool_response or not isinstance(tool_response, dict):
            _write_decision({"action": "continue"})
            return

        scanner = RegexScanner()
        modified = False
        redacted = dict(tool_response)

        # Scan and redact output field
        output_text = tool_response.get("output", "")
        if output_text and isinstance(output_text, str) and scanner.has_secrets(output_text):
            redacted["output"] = scanner.redact(output_text)
            modified = True

        # Scan and redact content field (used by some tools)
        content_text = tool_response.get("content", "")
        if content_text and isinstance(content_text, str) and scanner.has_secrets(content_text):
            redacted["content"] = scanner.redact(content_text)
            modified = True

        if modified:
            audit = AuditLogger()
            match_count = 0
            if output_text and isinstance(output_text, str):
                match_count += len(scanner.scan_text(output_text))
            if content_text and isinstance(content_text, str):
                match_count += len(scanner.scan_text(content_text))
            audit.log_content_sanitized(f"{tool_name} tool response", match_count)
            _write_decision({"action": "modify", "tool_response": redacted})
            return

        _write_decision({"action": "continue"})
    except Exception:
        # Any unexpected error -> fail open
        _write_decision({"action": "continue"})
