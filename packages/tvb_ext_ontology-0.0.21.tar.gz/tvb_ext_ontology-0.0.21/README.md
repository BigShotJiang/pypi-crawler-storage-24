# tvb_ext_ontology

[![Github Actions Status](https://github.com/the-virtual-brain/tvb-ext-ontology/workflows/Build/badge.svg)](https://github.com/the-virtual-brain/tvb-ext-ontology/actions/workflows/build.yml)

A JupyterLab extension.

This extension is composed of a Python package named `tvb_ext_ontology`
for the server extension and a NPM package named `tvb-ext-ontology`
for the frontend extension.

## Requirements

- JupyterLab >= 4.0.0
- Python >= 3.10

## Install

To install the extension, execute:

```bash
pip install tvb_ext_ontology
```

## Uninstall

To remove the extension, execute:

```bash
pip uninstall tvb_ext_ontology
```

## Troubleshoot

If you are seeing the frontend extension, but it is not working, check
that the server extension is enabled:

```bash
jupyter server extension list
```

If the server extension is installed and enabled, but you are not seeing
the frontend extension, check the frontend extension is installed:

```bash
jupyter labextension list
```

## Contributing

### Development install

Note: You will need NodeJS to build the extension package.

The `jlpm` command is JupyterLab's pinned version of
[yarn](https://yarnpkg.com/) that is installed with JupyterLab. You may use
`yarn` or `npm` in lieu of `jlpm` below.

```bash
# Clone the repo to your local environment
# Change directory to the tvb_ext_ontology directory
# Install package in development mode
pip install -e ".[test]"
# Link your development version of the extension with JupyterLab
jupyter labextension develop . --overwrite
# Server extension must be manually installed in develop mode
jupyter server extension enable tvb_ext_ontology
# Rebuild extension Typescript source after making changes
jlpm build
```

You can watch the source directory and run JupyterLab at the same time in different terminals to watch for changes in the extension's source and automatically rebuild the extension.

1. Watch the source directory in one terminal, automatically rebuilding when needed
   ```bash
   jlpm watch
   ```
2. Run JupyterLab with watchmedo in another terminal to see the changes you make to the source
   ```bash
   watchmedo auto-restart --patterns="*.py" --recursive -- jupyter lab --no-browser
   ```

With the watch command running, every saved change will immediately be built locally and available in your running JupyterLab. Refresh JupyterLab to load the change in your browser (you may need to wait several seconds for the extension to be rebuilt).

By default, the `jlpm build` command generates the source maps for this extension to make it easier to debug using the browser dev tools. To also generate source maps for the JupyterLab core extensions, you can run the following command:

```bash
jupyter lab build --minimize=False
```

### Development uninstall

```bash
# Server extension must be manually disabled in develop mode
jupyter server extension disable tvb_ext_ontology
pip uninstall tvb_ext_ontology
```

In development mode, you will also need to remove the symlink created by `jupyter labextension develop`
command. To find its location, you can run `jupyter labextension list` to figure out where the `labextensions`
folder is located. Then you can remove the symlink named `tvb-ext-ontology` within that folder.

### Testing the extension

#### Server tests

This extension is using [Pytest](https://docs.pytest.org/) for Python code testing.

Install test dependencies (needed only once):

```sh
pip install -e ".[test]"
# Each time you install the Python package, you need to restore the front-end extension link
jupyter labextension develop . --overwrite
```

To execute them, run:

```sh
pytest -vv -r ap --cov tvb_ext_ontology
```

#### Frontend tests

This extension is using [Jest](https://jestjs.io/) for JavaScript code testing.

To execute them, execute:

```sh
jlpm
jlpm test
```

#### Integration tests

This extension uses [Playwright](https://playwright.dev/docs/intro) for the integration tests (aka user level tests).
More precisely, the JupyterLab helper [Galata](https://github.com/jupyterlab/jupyterlab/tree/master/galata) is used to handle testing the extension in JupyterLab.

More information are provided within the [ui-tests](./ui-tests/README.md) README.

### Packaging the extension

See [RELEASE](RELEASE.md)
