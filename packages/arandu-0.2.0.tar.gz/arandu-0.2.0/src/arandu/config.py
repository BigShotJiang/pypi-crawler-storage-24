"""Memory configuration — dataclass with sensible defaults.

All memory system tuning parameters in one place. No database dependency.
Defaults are extracted from the original memory_constants.py and runtime_config.py.
"""

from dataclasses import dataclass, field


@dataclass
class MemoryConfig:
    """Configuration for the memory system.

    All fields have sensible defaults. Override only what you need.
    """

    # -- Extraction --
    extraction_model: str = "gpt-4o"
    extraction_mode: str = "multi_pass"  # "multi_pass" or "single_pass"
    extraction_timeout_sec: float = 30.0
    multi_pass_entity_threshold: int = 3  # ≤ this → fallback to single-pass
    entity_batch_size: int = 5  # entities per fact-extraction call
    reflexion_timeout_sec: float = 10.0

    # -- Entity Resolution --
    fuzzy_threshold: float = 0.85
    enable_llm_resolution: bool = True
    entity_resolution_model: str = "gpt-4o-mini"
    entity_resolution_timeout_sec: float = 10.0

    # -- Reconciliation --
    reconciliation_model: str = "gpt-4o-mini"
    reconciliation_timeout_sec: float = 10.0

    # -- Retrieval --
    topk_facts: int = 20
    topk_events: int = 8
    event_max_scan: int = 200
    min_similarity: float = 0.20
    min_confidence: float = 0.55
    recency_half_life_days: int = 14
    context_budget_tokens: int = 3000
    enable_reranker: bool = True
    reranker_model: str = "gpt-4o-mini"
    reranker_timeout_sec: float = 5.0

    # -- Score weights (hybrid ranking) --
    score_weights: dict = field(
        default_factory=lambda: {
            "semantic": 0.70,
            "recency": 0.20,
            "importance": 0.10,
        }
    )

    # -- Confidence --
    confidence_level_map: dict = field(
        default_factory=lambda: {
            "explicit_statement": 0.95,
            "strong_inference": 0.80,
            "weak_inference": 0.60,
            "speculation": 0.40,
        }
    )
    confidence_default: float = 0.60

    # -- Spreading Activation --
    spreading_activation_hops: int = 2
    spreading_decay_factor: float = 0.50
    spreading_max_related_entities: int = 5
    spreading_facts_per_entity: int = 3

    # -- Context Compression --
    context_max_tokens: int = 2000
    hot_tier_ratio: float = 0.5
    warm_tier_ratio: float = 0.3

    # -- Emotional Trends --
    emotional_trend_window_days: int = 30
    emotional_trend_min_events: int = 5

    # -- Clustering --
    cluster_max_age_days: int = 90
    cluster_min_facts: int = 2
    community_similarity_threshold: float = 0.75
    community_min_clusters: int = 2

    # -- Consolidation --
    consolidation_min_events: int = 3
    consolidation_lookback_days: int = 7

    # -- Sleep-time Compute --
    importance_recency_halflife_days: int = 30
    summary_refresh_interval_days: int = 7

    # -- Memify --
    vitality_stale_threshold: float = 0.2
    memify_merge_similarity_threshold: float = 0.90

    # -- Procedural Memory --
    directive_max_tokens: int = 300
    directive_cache_ttl_minutes: int = 30
    contradiction_similarity_threshold: float = 0.80

    # -- Locale / Deployment --
    timezone: str = "UTC"  # IANA timezone for temporal resolution in retrieval

    # -- Open Catalog (deployer extensions) --
    extra_attribute_keys: set[str] = field(default_factory=set)
    attribute_aliases: dict[str, str] = field(default_factory=dict)
    extra_namespaces: set[str] = field(default_factory=set)
    extra_self_references: frozenset[str] = field(default_factory=frozenset)
    extra_relationship_hints: frozenset[str] = field(default_factory=frozenset)

    # -- Limits --
    max_facts_per_event: int = 100
    embedding_dimensions: int = 1536
