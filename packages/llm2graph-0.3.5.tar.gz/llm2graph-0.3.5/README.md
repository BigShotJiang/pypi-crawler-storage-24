# LLM2Graph

`llm2graph` is a toolkit for:

1. building entity-centric knowledge graphs with LLM calls
2. generating graph-derived evaluation queries
3. running benchmark-style evaluation workflows for unlearning and retention experiments

This `0.3.5` release includes local fixes made after the `0.3.4` wheel in this environment:

- parallel question answering during graph construction
- parallel triple extraction during graph construction
- configurable question-generation prompt count instead of a fixed hard-coded ten-question prompt
- GPT-5-family OpenAI requests omit explicit `temperature`
- default timeout increased to 180 seconds across the package
- maintainer-facing documentation added locally in this workspace

## Install

```bash
pip install llm2graph
```

Optional extras:

```bash
pip install "llm2graph[gemini]"
pip install "llm2graph[hf-local]"
```

## Quickstart

```bash
llm2graph entity \
  --seed "Stephen King" \
  --provider openai \
  --model gpt-5-mini \
  --max-depth 0 \
  --elicitation-question-count 3 \
  --out graph.json
```

```bash
llm2graph gen-queries \
  --graph graph.json \
  --target "Stephen King" \
  --hops 2 \
  --out queries.json
```

```bash
llm2graph eval \
  --queries queries.json \
  --pre-provider openai \
  --pre-model gpt-5-mini \
  --post-provider openai \
  --post-model gpt-5-mini \
  --out eval_report.json
```
