﻿from __future__ import annotations

import os
import sys
import time
from contextlib import contextmanager
from contextvars import ContextVar

try:
    from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential
except ModuleNotFoundError:
    def retry(*args, **kwargs):
        def decorator(func):
            return func
        return decorator

    def stop_after_attempt(*args, **kwargs):
        return None

    def wait_exponential(*args, **kwargs):
        return None

    def retry_if_exception_type(*args, **kwargs):
        return None


class LLMError(RuntimeError):
    pass


def _debug_enabled() -> bool:
    raw = os.environ.get("LLM2GRAPH_DEBUG", "1").strip().lower()
    return raw not in {"", "0", "false", "no", "off"}


def _truncate(value: str, limit: int = 120) -> str:
    compact = " ".join(value.split())
    if len(compact) <= limit:
        return compact
    return compact[: limit - 3] + "..."


def _log_debug(message: str) -> None:
    if _debug_enabled():
        print(message, file=sys.stderr, flush=True)


class _OpenAIClient:
    def __init__(self, model: str, temperature: float, timeout_s: int):
        from openai import OpenAI

        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise LLMError("OPENAI_API_KEY env var is required for provider=openai")
        self.client = OpenAI(api_key=api_key)
        self.model = model
        self.temperature = temperature
        self.timeout_s = timeout_s

    def _supports_temperature(self) -> bool:
        normalized = self.model.strip().lower()
        return not normalized.startswith("gpt-5")

    def chat(self, system: str, user: str) -> str:
        request = {
            "model": self.model,
            "timeout": self.timeout_s,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        if self._supports_temperature():
            request["temperature"] = self.temperature
        response = self.client.chat.completions.create(**request)
        content = response.choices[0].message.content.strip()
        if not content:
            raise LLMError("Empty response from OpenAI")
        return content


class _GeminiClient:
    def __init__(self, model: str, temperature: float, timeout_s: int):
        import google.generativeai as genai

        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise LLMError("GEMINI_API_KEY env var is required for provider=gemini")
        genai.configure(api_key=api_key)
        self.genai = genai
        self.model_name = model
        self.temperature = float(temperature)
        self.timeout_s = timeout_s
        self.model = genai.GenerativeModel(self.model_name)

    def chat(self, system: str, user: str) -> str:
        prompt = f"SYSTEM:\n{system}\n\nUSER:\n{user}"
        response = self.model.generate_content(
            prompt,
            generation_config=self.genai.types.GenerationConfig(temperature=self.temperature),
        )
        if not response or not getattr(response, "text", None):
            raise LLMError("Empty response from Gemini")
        return response.text.strip()


class _HFLocalClient:
    def __init__(self, model: str, temperature: float, timeout_s: int, max_new_tokens: int, do_sample: bool):
        import torch
        import transformers as transformers_module

        self.temperature = float(temperature)
        self.max_new_tokens = int(max_new_tokens)
        self.do_sample = bool(do_sample)
        self.tokenizer = transformers_module.AutoTokenizer.from_pretrained(model, use_fast=True)
        dtype = torch.bfloat16 if torch.cuda.is_available() else None
        self.model = transformers_module.AutoModelForCausalLM.from_pretrained(
            model,
            torch_dtype=dtype,
            device_map="auto",
        )
        self.torch = torch

    def _format_chat(self, system: str, user: str) -> str:
        if hasattr(self.tokenizer, "apply_chat_template"):
            try:
                return self.tokenizer.apply_chat_template(
                    [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                    tokenize=False,
                    add_generation_prompt=True,
                )
            except Exception:
                pass
        return f"<|system|>\n{system}\n<|user|>\n{user}\n<|assistant|>\n"

    def chat(self, system: str, user: str) -> str:
        prompt = self._format_chat(system, user)
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        with self.torch.no_grad():
            output = self.model.generate(
                **inputs,
                max_new_tokens=self.max_new_tokens,
                do_sample=self.do_sample,
                temperature=self.temperature if self.do_sample else None,
                pad_token_id=self.tokenizer.eos_token_id or self.tokenizer.pad_token_id,
            )
        text = self.tokenizer.decode(output[0], skip_special_tokens=True)
        if text.startswith(prompt):
            text = text[len(prompt):]
        text = text.strip()
        if not text:
            raise LLMError("Empty response from HF local model")
        return text


class LLMClient:
    def __init__(
        self,
        provider: str = "openai",
        model: str = "",
        timeout_s: int = 60,
        temperature: float = 0.2,
        hf_max_new_tokens: int = 512,
        hf_do_sample: bool = True,
    ):
        self.provider = provider.lower().strip()
        self.model = model
        self.timeout_s = int(timeout_s)
        self.temperature = float(temperature)
        self.hf_max_new_tokens = int(hf_max_new_tokens)
        self.hf_do_sample = bool(hf_do_sample)
        self._context_stack: ContextVar[tuple[str, ...]] = ContextVar("llm2graph_context_stack", default=())
        if self.provider == "openai":
            self.impl = _OpenAIClient(model=model, temperature=temperature, timeout_s=timeout_s)
        elif self.provider == "gemini":
            self.impl = _GeminiClient(model=model, temperature=temperature, timeout_s=timeout_s)
        elif self.provider in {"hf-local", "hf_local", "local"}:
            self.impl = _HFLocalClient(
                model=model,
                temperature=temperature,
                timeout_s=timeout_s,
                max_new_tokens=hf_max_new_tokens,
                do_sample=hf_do_sample,
            )
        else:
            raise LLMError(f"Unsupported provider: {provider}")

    def describe(self) -> dict:
        return {
            "provider": self.provider,
            "model": self.model,
            "timeout_s": self.timeout_s,
            "temperature": self.temperature,
            "hf_max_new_tokens": self.hf_max_new_tokens,
            "hf_do_sample": self.hf_do_sample,
        }

    @contextmanager
    def context(self, label: str):
        current = self._context_stack.get()
        token = self._context_stack.set(current + (label,))
        try:
            yield self
        finally:
            self._context_stack.reset(token)

    def _context_label(self) -> str:
        stack = self._context_stack.get()
        if not stack:
            return "chat"
        return " > ".join(stack)

    @retry(
        reraise=True,
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type(Exception),
    )
    def chat(self, system: str, user: str) -> str:
        label = self._context_label()
        start = time.monotonic()
        _log_debug(
            f"[llm2graph] LLM start label={label} provider={self.provider} "
            f"model={self.model} timeout_s={self.timeout_s} "
            f"system={_truncate(system)!r} user={_truncate(user)!r}"
        )
        try:
            response = self.impl.chat(system, user)
        except Exception as exc:
            elapsed = time.monotonic() - start
            _log_debug(
                f"[llm2graph] LLM error label={label} provider={self.provider} "
                f"model={self.model} elapsed_s={elapsed:.2f} "
                f"error={exc.__class__.__name__}: {exc}"
            )
            raise
        elapsed = time.monotonic() - start
        _log_debug(
            f"[llm2graph] LLM ok label={label} provider={self.provider} "
            f"model={self.model} elapsed_s={elapsed:.2f} "
            f"response={_truncate(response)!r}"
        )
        return response
