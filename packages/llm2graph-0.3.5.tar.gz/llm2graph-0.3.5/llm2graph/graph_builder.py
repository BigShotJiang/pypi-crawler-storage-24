﻿from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
import json
import re
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Set, Tuple

from ._graph import nx
from .alias import AliasTools
from .llm_client import LLMClient, LLMError
from .prompts import entity_answer_prompt, entity_question_list_prompt, triple_extraction_prompt
from .settings import Config

Triple = Tuple[str, str, str]

_TRIPLE_RE = re.compile(r"\((.+?)\s*;\s*(.+?)\s*;\s*(.+?)\)")


def _clean_llm_lines(text: str) -> List[str]:
    cleaned: List[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line == "```":
            continue
        if line.startswith("```"):
            continue
        if line[:2] in {"- ", "* "}:
            line = line[2:].strip()
        if line and line[0].isdigit() and "." in line[:4]:
            line = line.split(".", 1)[1].strip()
        cleaned.append(line)
    return cleaned


def _log_debug(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


@dataclass
class KG:
    seed: str
    g: nx.DiGraph = field(default_factory=nx.DiGraph)
    meta: Dict = field(default_factory=dict)

    def add_triples(self, triples: Iterable[Triple]) -> None:
        for subject, relation, obj in triples:
            self.g.add_node(subject)
            self.g.add_node(obj)
            self.g.add_edge(subject, obj, relation=relation)

    @property
    def num_nodes(self) -> int:
        return self.g.number_of_nodes()

    @property
    def num_edges(self) -> int:
        return self.g.number_of_edges()

    def triples(self) -> List[Triple]:
        return [(u, data.get("relation", ""), v) for u, v, data in self.g.edges(data=True)]

    def to_json(self) -> Dict:
        meta = dict(self.meta)
        meta.update({"num_nodes": self.num_nodes, "num_edges": self.num_edges})
        return {
            "seed": self.seed,
            "nodes": sorted(self.g.nodes),
            "edges": [
                {"subject": u, "relation": data.get("relation", ""), "object": v}
                for u, v, data in self.g.edges(data=True)
            ],
            "meta": meta,
        }

    @classmethod
    def from_json(cls, payload: Dict) -> "KG":
        kg = cls(seed=payload["seed"], meta=dict(payload.get("meta", {})))
        kg.g.add_nodes_from(payload.get("nodes", []))
        for edge in payload.get("edges", []):
            kg.g.add_edge(edge["subject"], edge["object"], relation=edge.get("relation", ""))
        return kg

    def save_json(self, path: str | Path) -> Path:
        out_path = Path(path)
        out_path.write_text(json.dumps(self.to_json(), ensure_ascii=False, indent=2), encoding="utf-8")
        return out_path


class GraphBuilder:
    def __init__(
        self,
        cfg: Config,
        llm_client: LLMClient | None = None,
        use_relevance: bool = False,
        relevance_threshold: float = 3.0,
        decay: float = 1.0,
        max_nodes_per_depth: int | None = None,
        alias_merge: bool = True,
    ):
        self.cfg = cfg
        self.llm = llm_client or LLMClient(
            provider=cfg.provider,
            model=cfg.model,
            timeout_s=cfg.timeout_s,
            temperature=cfg.temperature,
            hf_max_new_tokens=cfg.hf_max_new_tokens,
            hf_do_sample=cfg.hf_do_sample,
        )
        self.alias = AliasTools(self.llm)
        self.use_relevance = use_relevance
        self.relevance_threshold = relevance_threshold
        self.decay = max(0.1, min(1.0, decay))
        self.max_nodes_per_depth = max_nodes_per_depth
        self.alias_merge = alias_merge
        self._alias_cache: Dict[Tuple[str, str], bool] = {}

        try:
            from .relevance import RelevanceScorer
            self.relevance = RelevanceScorer(self.llm)
        except Exception:
            self.relevance = None

    def _strict_parse_triples(self, text: str) -> List[Triple]:
        triples: List[Triple] = []
        for line in _clean_llm_lines(text):
            match = _TRIPLE_RE.fullmatch(line)
            if not match:
                continue
            triples.append((match.group(1).strip(), match.group(2).strip(), match.group(3).strip()))
        if not triples:
            raise LLMError("No triples parsed from LLM output")
        return triples

    def _generate_entity_questions(self, entity: str) -> List[str]:
        system, user = entity_question_list_prompt(entity, self.cfg.elicitation_question_count)
        with self.llm.context(f"graph.questions entity={entity}"):
            raw = self.llm.chat(system, user)
        questions = _clean_llm_lines(raw)
        if not questions:
            raise LLMError(f"No elicitation questions produced for {entity!r}")
        return questions[: self.cfg.elicitation_question_count]

    def _parallel_workers(self, item_count: int) -> int:
        return max(1, min(item_count, self.cfg.elicitation_question_count))

    def _answer_single_question(self, entity: str, question: str, index: int) -> str:
        system, user = entity_answer_prompt(entity, question)
        with self.llm.context(f"graph.answer entity={entity} question_index={index}"):
            return self.llm.chat(system, user)

    def _answer_entity_questions(self, entity: str, questions: Sequence[str]) -> List[str]:
        answers: List[str] = [""] * len(questions)
        with ThreadPoolExecutor(max_workers=self._parallel_workers(len(questions))) as executor:
            futures = [
                executor.submit(self._answer_single_question, entity, question, index)
                for index, question in enumerate(questions, start=1)
            ]
            for index, future in enumerate(futures):
                answers[index] = future.result()
        return answers

    def _extract_triples_from_answer(self, answer: str, index: int) -> List[Triple]:
        system, user = triple_extraction_prompt(answer)
        with self.llm.context(f"graph.extract_triples answer_index={index}"):
            return self._strict_parse_triples(self.llm.chat(system, user))

    def _extract_triples_from_answers(self, answers: Sequence[str]) -> List[Triple]:
        triples_by_answer: List[List[Triple]] = [[] for _ in answers]
        with ThreadPoolExecutor(max_workers=self._parallel_workers(len(answers))) as executor:
            futures = [
                executor.submit(self._extract_triples_from_answer, answer, index)
                for index, answer in enumerate(answers, start=1)
            ]
            for index, future in enumerate(futures):
                triples_by_answer[index] = future.result()
        triples: List[Triple] = []
        for answer_triples in triples_by_answer:
            triples.extend(answer_triples)
        return triples

    def _score_triples(self, seed: str, triples: Sequence[Triple]) -> List[Triple]:
        if not self.use_relevance or self.relevance is None:
            return list(triples)
        kept: List[Triple] = []
        for triple in triples:
            score = self.relevance.score(seed, triple)
            if score >= self.relevance_threshold:
                kept.append(triple)
        return kept

    def _select_children(self, triples: Sequence[Triple], depth: int, used: int) -> List[str]:
        children = [obj for _, _, obj in triples]
        limit = len(children)
        if self.decay < 1.0 and depth >= 1:
            limit = max(1, int(round(len(children) * (self.decay ** depth))))
        if self.max_nodes_per_depth is not None:
            remaining = max(0, self.max_nodes_per_depth - used)
            limit = min(limit, remaining)
        return children[:limit]

    def _alias_key(self, left: str, right: str) -> Tuple[str, str]:
        return tuple(sorted((left, right)))

    def _canonicalize(self, candidate: str, existing_nodes: Iterable[str]) -> str:
        if not self.alias_merge:
            return candidate
        for existing in existing_nodes:
            if existing == candidate:
                return existing
            cache_key = self._alias_key(existing, candidate)
            if cache_key not in self._alias_cache:
                with self.llm.context(f"graph.alias_check existing={existing} candidate={candidate}"):
                    self._alias_cache[cache_key] = self.alias.canonical_same(existing, candidate)
            if self._alias_cache[cache_key]:
                return existing
        return candidate

    def build(self, seed: str) -> KG:
        kg = KG(seed=seed)
        kg.meta["construction"] = {
            "provider": self.llm.provider,
            "model": self.llm.model,
            "max_depth": self.cfg.max_depth,
            "temperature": self.cfg.temperature,
            "timeout_s": self.cfg.timeout_s,
            "elicitation_question_count": self.cfg.elicitation_question_count,
            "use_relevance": self.use_relevance,
            "relevance_threshold": self.relevance_threshold,
            "decay": self.decay,
            "max_nodes_per_depth": self.max_nodes_per_depth,
            "alias_merge": self.alias_merge,
            "api_driven": True,
        }
        frontier: List[Tuple[str, int]] = [(seed, 0)]
        seen: Set[str] = set()
        per_depth_counts: Dict[int, int] = {}

        while frontier:
            node, depth = frontier.pop(0)
            if node in seen or depth > self.cfg.max_depth:
                continue
            seen.add(node)
            _log_debug(
                f"[llm2graph] Graph node start seed={seed} node={node} depth={depth} "
                f"frontier_remaining={len(frontier)} seen={len(seen)}"
            )

            questions = self._generate_entity_questions(node)
            _log_debug(f"[llm2graph] Graph node questions node={node} count={len(questions)}")
            answers = self._answer_entity_questions(node, questions)
            _log_debug(f"[llm2graph] Graph node answers node={node} count={len(answers)}")
            triples = self._score_triples(seed, self._extract_triples_from_answers(answers))
            _log_debug(f"[llm2graph] Graph node triples node={node} count={len(triples)}")
            if not triples:
                continue

            normalized_triples: List[Triple] = []
            for subject, relation, obj in triples:
                canonical_subject = self._canonicalize(subject, kg.g.nodes) if subject != node else node
                canonical_obj = self._canonicalize(obj, kg.g.nodes)
                normalized_triples.append((canonical_subject, relation, canonical_obj))
            kg.add_triples(normalized_triples)

            if depth >= self.cfg.max_depth:
                continue

            used_next_depth = per_depth_counts.get(depth + 1, 0)
            selected = self._select_children(normalized_triples, depth, used_next_depth)
            _log_debug(
                f"[llm2graph] Graph node children node={node} depth={depth} "
                f"selected={len(selected)} total_nodes={kg.num_nodes} total_edges={kg.num_edges}"
            )
            per_depth_counts[depth + 1] = used_next_depth + len(selected)
            for child in selected:
                if child not in seen:
                    frontier.append((child, depth + 1))

        return kg
