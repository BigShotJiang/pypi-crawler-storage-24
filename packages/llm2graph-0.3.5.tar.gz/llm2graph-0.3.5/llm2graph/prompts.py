﻿from __future__ import annotations


def entity_question_list_prompt(entity: str, count: int) -> tuple[str, str]:
    system = f"Generate {count} diverse factual questions about a target entity. Output one question per line."
    user = f'''Generate exactly {count} diverse questions regarding the entity "{entity}".
Distribute them across distinct aspects when possible, such as:
- basic introduction
- key concepts
- related entities
- functional roles
- lesser-known facts
- controversies or debates
- future trends or influence
- historical significance
- comparisons to similar entities
- missing or under-researched information

If fewer aspects are relevant, still return exactly {count} useful factual questions with no numbering.
Input: "{entity}"'''
    return system, user


def entity_answer_prompt(entity: str, question: str) -> tuple[str, str]:
    system = "Answer the question factually and compactly. Use one paragraph and avoid lists."
    user = f'Entity: "{entity}"\nQuestion: {question}'
    return system, user


def triple_extraction_prompt(text: str) -> tuple[str, str]:
    system = "Extract atomic facts as triples only. Output one triple per line in the form (subject ; relation ; object)."
    user = f'''In a knowledge graph, entities represent real-world objects, concepts, or things.
Valid entities are:
- Specific and identifiable.
- Not overly abstract, repetitive, or general.
- Relevant to a knowledge graph structure.

Extract all atomic facts from the input text.
Output each atomic fact in the format: (subject ; relation ; object), where relationships and objects are concise, meaningful, and specific.
Text: """{text}"""'''
    return system, user


def relevance_prompt(seed: str, triple: tuple[str, str, str]) -> tuple[str, str]:
    subject, relation, obj = triple
    system = "Return only a floating-point number between 0 and 10."
    user = f'Rate the relevance of the following triple to the initial query on a scale from 0 to 10.\nQuery: "{seed}"\nTriple: ("{subject}", "{relation}", "{obj}")\nProvide only the number in response.'
    return system, user


def alias_prompt(left: str, right: str) -> tuple[str, str]:
    system = "Answer strictly YES or NO."
    user = f'Is "{left}" the same as "{right}"?'
    return system, user


def question_from_path_prompt(path_lines: list[str]) -> tuple[str, str]:
    system = "Turn the ordered triples into one natural-language question. The answer must be the final object. Output exactly two lines: Q: ... and A: ..."
    user = "Triples:\n" + "\n".join(path_lines)
    return system, user


def paraphrase_prompt(question: str, count: int) -> tuple[str, str]:
    system = "Paraphrase the question into k distinct phrasings that preserve meaning. Output exactly k lines with no numbering."
    user = f"k={count}\nQuestion: {question}"
    return system, user


def distractor_prompt(answer: str, count: int) -> tuple[str, str]:
    system = "Produce k plausible but incorrect answer candidates of the same type as the gold answer. Output one per line."
    user = f'Gold answer: "{answer}"\nk={count}'
    return system, user


def judge_equivalence_prompt(prediction: str, gold: str) -> tuple[str, str]:
    system = "Answer strictly YES or NO."
    user = f'Are these two answers semantically equivalent entities or values?\nA="{prediction}"\nB="{gold}"\nAnswer:'
    return system, user
