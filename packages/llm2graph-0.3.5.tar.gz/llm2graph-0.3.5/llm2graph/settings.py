﻿from __future__ import annotations

try:
    from pydantic import BaseModel, Field
except ModuleNotFoundError:
    class BaseModel:
        model_config = {}

        def __init__(self, **kwargs):
            for name, value in self.__class__.__dict__.items():
                if name.startswith("_") or callable(value):
                    continue
                if name in {"model_config", "__module__", "__doc__", "__annotations__"}:
                    continue
                setattr(self, name, kwargs.pop(name, value))
            for name in getattr(self, "__annotations__", {}):
                if name in kwargs:
                    setattr(self, name, kwargs.pop(name))
                elif not hasattr(self, name) and hasattr(self.__class__, name):
                    setattr(self, name, getattr(self.__class__, name))
            if kwargs and self.model_config.get("extra") == "forbid":
                raise TypeError(f"Unexpected config fields: {sorted(kwargs)}")

    def Field(default=None, description="", ge=None, le=None):
        return default


class Config(BaseModel):
    provider: str = Field(default="openai", description="openai | gemini | hf-local")
    model: str = Field(default="gpt-4o-mini-2024-07-18", description="Provider-specific model id or Hugging Face repo id")
    max_depth: int = Field(default=2, ge=0, le=5)
    temperature: float = Field(default=0.2, ge=0.0, le=1.0)
    timeout_s: int = Field(default=180, ge=5, le=600)
    hf_max_new_tokens: int = Field(default=512, ge=16, le=4096)
    hf_do_sample: bool = Field(default=True)
    elicitation_question_count: int = Field(default=10, ge=1, le=20)

    model_config = {"extra": "forbid"}
