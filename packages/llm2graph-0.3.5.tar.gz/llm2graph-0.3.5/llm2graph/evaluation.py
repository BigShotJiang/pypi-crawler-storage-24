﻿from __future__ import annotations

import sys
from typing import Dict, List

from .llm_client import LLMClient, LLMError
from .metrics import aggregate, compute_residual_flags
from .prompts import judge_equivalence_prompt


def _log_debug(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


class Evaluator:
    def __init__(self, pre: LLMClient, post: LLMClient, judge: LLMClient | None = None):
        self.pre = pre
        self.post = post
        self.judge = judge

    def _ask(self, client: LLMClient, question: str) -> str:
        system = "Answer the question with the entity or value only. No extra words."
        with client.context("eval.answer"):
            return client.chat(system, question).strip()

    def _judge_equiv(self, prediction: str, gold: str) -> bool:
        if self.judge is None:
            return prediction.strip() == gold.strip()
        system, user = judge_equivalence_prompt(prediction, gold)
        with self.judge.context("eval.judge_equivalence"):
            out = self.judge.chat(system, user).strip().upper()
        if out not in {"YES", "NO"}:
            raise LLMError(f"Judge returned invalid token: {out!r}")
        return out == "YES"

    def _evaluate_query(self, query: Dict) -> Dict | None:
        gold = query["answer"]
        pre_answer = self._ask(self.pre, query["q_gold"])
        pre_correct = self._judge_equiv(pre_answer, gold)
        if not pre_correct:
            return None

        predictions: List[Dict] = []
        post_answer = self._ask(self.post, query["q_gold"])
        predictions.append({
            "variant": "gold",
            "type": "gold",
            "prompt": query["q_gold"],
            "pre": pre_answer,
            "post": post_answer,
            "pre_correct": pre_correct,
            "correct": self._judge_equiv(post_answer, gold),
        })

        for paraphrase in query.get("q_variants", [])[1:]:
            post_variant = self._ask(self.post, paraphrase)
            predictions.append({
                "variant": "paraphrase",
                "type": "paraphrase",
                "prompt": paraphrase,
                "pre": None,
                "post": post_variant,
                "pre_correct": None,
                "correct": self._judge_equiv(post_variant, gold),
            })

        for alias_variant in query.get("q_alias_variants", []):
            post_alias = self._ask(self.post, alias_variant)
            predictions.append({
                "variant": "alias",
                "type": "alias",
                "prompt": alias_variant,
                "pre": None,
                "post": post_alias,
                "pre_correct": None,
                "correct": self._judge_equiv(post_alias, gold),
            })

        item = {
            "group": query.get("group", "forget"),
            "subtype": query.get("subtype"),
            "path": query["path"],
            "answer": gold,
            "predictions": predictions,
        }
        item["residual_flags"] = compute_residual_flags(item)
        return item

    def run(self, queries: Dict) -> Dict:
        items: List[Dict] = []
        skipped = 0
        all_queries = list(queries.get("queries", []))
        retention = queries.get("retention_queries", {})
        all_queries.extend(retention.get("one_hop", []))
        all_queries.extend(retention.get("two_hop", []))
        all_queries.extend(retention.get("relationship", []))
        _log_debug(f"[llm2graph] Evaluation start queries={len(all_queries)}")

        for query in all_queries:
            item = self._evaluate_query(query)
            if item is None:
                skipped += 1
                continue
            items.append(item)
        _log_debug(f"[llm2graph] Evaluation complete kept={len(items)} skipped={skipped}")

        return {
            "meta": {
                "source_query_meta": queries.get("meta", {}),
                "pre_model": self.pre.describe() if hasattr(self.pre, "describe") else {},
                "post_model": self.post.describe() if hasattr(self.post, "describe") else {},
                "judge_model": self.judge.describe() if self.judge is not None and hasattr(self.judge, "describe") else None,
                "skipped_precheck_failures": skipped,
                "precheck_required": True,
            },
            "summary": aggregate(items),
            "items": items,
        }
