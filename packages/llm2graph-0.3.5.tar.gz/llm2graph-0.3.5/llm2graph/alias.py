from .llm_client import LLMClient, LLMError

class AliasTools:
    def __init__(self, llm: LLMClient):
        self.llm = llm

    def canonical_same(self, a: str, b: str) -> bool:
        system = "Answer strictly 'YES' or 'NO'."
        user = f'Are these two names the **same canonical entity**?\nA = "{a}"\nB = "{b}"\nAnswer:'
        out = self.llm.chat(system, user).strip().upper()
        if out not in {"YES", "NO"}:
            raise LLMError(f"Alias check returned invalid token: {out!r}")
        return out == "YES"

    def generate_aliases(self, name: str, k: int) -> list[str]:
        system = "Output exactly k alternative surface forms (aliases) for the given entity; one per line; no numbering."
        user = f'Entity: "{name}"\nk = {k}\nConstraints: common nicknames/epithets/abbreviations; no hallucinated entities.'
        text = self.llm.chat(system, user)
        aliases = [line.strip() for line in text.splitlines() if line.strip()]
        if len(aliases) < 1:
            raise LLMError("No aliases produced by LLM")
        return aliases[:k]
