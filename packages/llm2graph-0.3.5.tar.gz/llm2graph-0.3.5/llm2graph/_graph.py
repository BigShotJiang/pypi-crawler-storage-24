﻿from __future__ import annotations

try:
    import networkx as nx  # type: ignore
except ModuleNotFoundError:
    class _SimpleDiGraph:
        def __init__(self):
            self._nodes = []
            self._edges = []

        @property
        def nodes(self):
            return list(self._nodes)

        def add_node(self, node):
            if node not in self._nodes:
                self._nodes.append(node)

        def add_nodes_from(self, nodes):
            for node in nodes:
                self.add_node(node)

        def add_edge(self, source, target, relation=""):
            self.add_node(source)
            self.add_node(target)
            for edge in self._edges:
                if edge[0] == source and edge[1] == target:
                    edge[2]["relation"] = relation
                    return
            self._edges.append([source, target, {"relation": relation}])

        def edges(self, data=False):
            if data:
                return [(source, target, payload.copy()) for source, target, payload in self._edges]
            return [(source, target) for source, target, _ in self._edges]

        def out_edges(self, node, data=False):
            result = []
            for source, target, payload in self._edges:
                if source == node:
                    result.append((source, target, payload.copy()) if data else (source, target))
            return result

        def number_of_nodes(self):
            return len(self._nodes)

        def number_of_edges(self):
            return len(self._edges)

        def __contains__(self, node):
            return node in self._nodes

    class _FallbackNetworkX:
        DiGraph = _SimpleDiGraph

        @staticmethod
        def relabel_nodes(graph, mapping, copy=False):
            for index, node in enumerate(list(graph._nodes)):
                graph._nodes[index] = mapping.get(node, node)
            seen = []
            deduped = []
            for node in graph._nodes:
                if node not in seen:
                    seen.append(node)
                    deduped.append(node)
            graph._nodes = deduped
            for edge in graph._edges:
                edge[0] = mapping.get(edge[0], edge[0])
                edge[1] = mapping.get(edge[1], edge[1])
            return graph

    nx = _FallbackNetworkX()
