from .llm_client import LLMClient, LLMError

class RelevanceScorer:
    def __init__(self, llm: LLMClient):
        self.llm = llm

    def score(self, seed: str, triple: tuple[str,str,str]) -> float:
        s,r,o = triple
        system = "Return only a floating-point number between 0 and 10."
        user = f'Rate the relevance of triple to the seed entity.\nSeed: "{seed}"\nTriple: ("{s}" ; "{r}" ; "{o}")\nNumber only:'
        out = self.llm.chat(system, user).strip()
        try:
            val = float(out)
        except Exception:
            raise LLMError(f"Invalid relevance score: {out!r}")
        if not (0.0 <= val <= 10.0):
            raise LLMError(f"Relevance score out of range: {val}")
        return val
