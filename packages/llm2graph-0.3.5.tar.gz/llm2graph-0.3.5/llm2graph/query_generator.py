﻿from __future__ import annotations

import random
import re
import sys
from typing import Dict, List, Tuple

from ._graph import nx
from .alias import AliasTools
from .llm_client import LLMClient, LLMError
from .prompts import distractor_prompt, paraphrase_prompt, question_from_path_prompt


def _log_debug(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


class QueryGenerator:
    def __init__(self, llm: LLMClient):
        self.llm = llm
        self.alias = AliasTools(llm)

    def _question_from_path(self, nodes: List[str], edges: List[str]) -> Tuple[str, str]:
        sketch = [f"({nodes[index]} ; {edges[index]} ; {nodes[index + 1]})" for index in range(len(edges))]
        system, user = question_from_path_prompt(sketch)
        with self.llm.context(f"query.question path_len={len(edges)} nodes={nodes[0]}->{nodes[-1]}"):
            out = self.llm.chat(system, user)
        lines = [line.strip() for line in out.splitlines() if line.strip()]
        if len(lines) < 2 or not lines[0].startswith("Q:") or not lines[1].startswith("A:"):
            raise LLMError(f"Bad QA format from LLM: {out!r}")
        question = lines[0][2:].strip()
        answer = lines[1][2:].strip()
        if not question or not answer:
            raise LLMError("Question generation returned an empty field")
        return question, answer

    def _paraphrase(self, question: str, count: int) -> List[str]:
        if count <= 0:
            return []
        system, user = paraphrase_prompt(question, count)
        with self.llm.context(f"query.paraphrase count={count}"):
            out = self.llm.chat(system, user)
        candidates = [line.strip() for line in out.splitlines() if line.strip()]
        if not candidates:
            raise LLMError("No paraphrases produced")
        return candidates[:count]

    def _distractors(self, answer: str, count: int) -> List[str]:
        if count <= 0:
            return []
        system, user = distractor_prompt(answer, count)
        with self.llm.context(f"query.distractors count={count}"):
            out = self.llm.chat(system, user)
        values = [line.strip() for line in out.splitlines() if line.strip()]
        filtered = [value for value in values if value != answer]
        if not filtered:
            raise LLMError("No distractors produced")
        return filtered[:count]

    def sample_paths(self, graph: nx.DiGraph, seed: str, hops: int, num_paths: int, random_seed: int | None = None) -> List[Tuple[List[str], List[str]]]:
        paths: List[Tuple[List[str], List[str]]] = []

        def dfs(node: str, depth: int, nodes: List[str], edges: List[str]) -> None:
            if depth == hops:
                paths.append((nodes[:], edges[:]))
                return
            for _, nxt, data in graph.out_edges(node, data=True):
                if nxt in nodes:
                    continue
                edges.append(data.get("relation", ""))
                nodes.append(nxt)
                dfs(nxt, depth + 1, nodes, edges)
                nodes.pop()
                edges.pop()

        dfs(seed, 0, [seed], [])
        rng = random.Random(random_seed)
        rng.shuffle(paths)
        return paths[:num_paths]

    def _alias_substitution(self, question: str, aliases_by_node: Dict[str, List[str]], nodes: List[str]) -> str:
        rewritten = question
        for node in sorted(nodes, key=len, reverse=True):
            aliases = aliases_by_node.get(node) or []
            if aliases:
                rewritten = re.sub(rf"\b{re.escape(node)}\b", aliases[0], rewritten)
        return rewritten

    def _item_from_path(self, nodes: List[str], edge_labels: List[str], aliases: int, paraphrases: int, distractors: int, alias_bank: Dict[str, List[str]], group: str, subtype: str) -> Dict:
        question, answer = self._question_from_path(nodes, edge_labels)
        variants = [question] + self._paraphrase(question, paraphrases)
        alias_variants: List[str] = []
        if aliases > 0:
            alias_variants = [self._alias_substitution(variant, alias_bank, nodes) for variant in variants]
        return {
            "group": group,
            "subtype": subtype,
            "path": [{"s": nodes[index], "r": edge_labels[index], "o": nodes[index + 1]} for index in range(len(edge_labels))],
            "q_gold": question,
            "q_variants": variants,
            "q_alias_variants": alias_variants,
            "answer": answer,
            "distractors": self._distractors(answer, distractors),
        }

    def _dedupe_paths(self, paths: List[Tuple[List[str], List[str]]]) -> List[Tuple[List[str], List[str]]]:
        seen = set()
        deduped: List[Tuple[List[str], List[str]]] = []
        for nodes, labels in paths:
            key = tuple(nodes), tuple(labels)
            if key in seen:
                continue
            seen.add(key)
            deduped.append((nodes, labels))
        return deduped

    def _relation_retention_sets(self, graph: nx.DiGraph, blocked_nodes: set[str], per_kind_limit: int) -> List[Tuple[List[str], List[str]]]:
        relation_counts: Dict[str, int] = {}
        for _, _, data in graph.edges(data=True):
            relation = data.get("relation", "")
            relation_counts[relation] = relation_counts.get(relation, 0) + 1
        ranked_relations = [relation for relation, _ in sorted(relation_counts.items(), key=lambda item: (-item[1], item[0])) if relation]

        relation_paths: List[Tuple[List[str], List[str]]] = []
        for relation in ranked_relations:
            for source, target, data in graph.edges(data=True):
                if data.get("relation", "") != relation:
                    continue
                if source in blocked_nodes or target in blocked_nodes:
                    continue
                relation_paths.append(([source, target], [relation]))
                break
            if len(relation_paths) >= per_kind_limit:
                break
        return relation_paths

    def _retention_sets(self, graph: nx.DiGraph, forget_paths: List[Tuple[List[str], List[str]]], per_kind_limit: int) -> Tuple[List[Tuple[List[str], List[str]]], List[Tuple[List[str], List[str]]], List[Tuple[List[str], List[str]]]]:
        one_hop: List[Tuple[List[str], List[str]]] = []
        two_hop: List[Tuple[List[str], List[str]]] = []
        blocked_nodes = {node for nodes, _ in forget_paths for node in nodes}

        for nodes, _ in forget_paths:
            for anchor in nodes[1:]:
                for _, nxt, data in graph.out_edges(anchor, data=True):
                    if nxt in blocked_nodes:
                        continue
                    one_hop.append(([anchor, nxt], [data.get("relation", "")]))
                for _, mid, data in graph.out_edges(anchor, data=True):
                    if mid in blocked_nodes:
                        continue
                    for _, nxt, data2 in graph.out_edges(mid, data=True):
                        if nxt in blocked_nodes or nxt == anchor:
                            continue
                        two_hop.append(([anchor, mid, nxt], [data.get("relation", ""), data2.get("relation", "")]))

        one_hop = self._dedupe_paths(one_hop)[:per_kind_limit]
        two_hop = self._dedupe_paths(two_hop)[:per_kind_limit]
        relation_only = self._dedupe_paths(self._relation_retention_sets(graph, blocked_nodes, per_kind_limit))[:per_kind_limit]
        return one_hop, two_hop, relation_only

    def generate(self, graph_json: Dict, target: str, hops: int = 1, num_paths: int = 50, aliases: int = 0, paraphrases: int = 0, distractors: int = 0, random_seed: int | None = None, per_kind_limit: int = 100) -> Dict:
        _log_debug(
            f"[llm2graph] Query generation start target={target} hops={hops} "
            f"num_paths={num_paths} aliases={aliases} paraphrases={paraphrases} distractors={distractors}"
        )
        graph = nx.DiGraph()
        for node in graph_json.get("nodes", []):
            graph.add_node(node)
        for edge in graph_json.get("edges", []):
            graph.add_edge(edge["subject"], edge["object"], relation=edge.get("relation", ""))

        rng = random.Random(random_seed)
        forget_paths: List[Tuple[List[str], List[str]]] = []
        for hop_count in range(1, hops + 1):
            hop_seed = rng.randint(0, 10**9)
            forget_paths.extend(self.sample_paths(graph, target, hop_count, min(num_paths, per_kind_limit), random_seed=hop_seed))
        forget_paths = self._dedupe_paths(forget_paths)
        if not forget_paths:
            raise LLMError("No paths of requested length found")
        _log_debug(f"[llm2graph] Query generation forget_paths={len(forget_paths)}")

        unique_nodes = {node for nodes, _ in forget_paths for node in nodes}
        alias_bank: Dict[str, List[str]] = {}
        if aliases > 0:
            for node in unique_nodes:
                alias_bank[node] = self.alias.generate_aliases(node, aliases)

        forget_queries = [self._item_from_path(nodes, edge_labels, aliases, paraphrases, distractors, alias_bank, "forget", f"{len(edge_labels)}_hop") for nodes, edge_labels in forget_paths]

        retention_1, retention_2, retention_rel = self._retention_sets(graph, forget_paths, per_kind_limit)
        retention_queries = {
            "one_hop": [self._item_from_path(nodes, labels, 0, 0, 0, alias_bank, "retention", "one_hop_retention") for nodes, labels in retention_1],
            "two_hop": [self._item_from_path(nodes, labels, 0, 0, 0, alias_bank, "retention", "two_hop_retention") for nodes, labels in retention_2],
            "relationship": [self._item_from_path(nodes, labels, 0, 0, 0, alias_bank, "retention", "relationship_retention") for nodes, labels in retention_rel],
        }
        _log_debug(
            f"[llm2graph] Query generation complete target={target} "
            f"forget={len(forget_queries)} retention_1={len(retention_queries['one_hop'])} "
            f"retention_2={len(retention_queries['two_hop'])} retention_rel={len(retention_queries['relationship'])}"
        )

        return {
            "meta": {
                "target": target,
                "graph_seed": graph_json.get("seed"),
                "source_graph_meta": graph_json.get("meta", {}),
                "generator": self.llm.describe() if hasattr(self.llm, "describe") else {},
                "max_hops": hops,
                "num_paths_per_hop": num_paths,
                "per_kind_limit": per_kind_limit,
                "aliases": aliases,
                "paraphrases": paraphrases,
                "distractors": distractors,
                "random_seed": random_seed,
            },
            "queries": forget_queries,
            "retention_queries": retention_queries,
        }
