﻿from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class EvalCounts:
    total: int = 0
    correct: int = 0

    def add(self, is_correct: bool) -> None:
        self.total += 1
        if is_correct:
            self.correct += 1

    @property
    def accuracy(self) -> float:
        return 0.0 if self.total == 0 else self.correct / self.total


def compute_residual_flags(item: Dict) -> Dict:
    gold_correct = None
    alias_any = False
    paraphrase_any = False
    for prediction in item.get("predictions", []):
        if prediction.get("type") == "gold":
            gold_correct = prediction.get("correct", False)
        elif prediction.get("type") == "alias":
            alias_any = alias_any or prediction.get("correct", False)
        elif prediction.get("type") == "paraphrase":
            paraphrase_any = paraphrase_any or prediction.get("correct", False)
    residual = (gold_correct is False) and (alias_any or paraphrase_any)
    return {
        "residual": residual,
        "gold_correct": bool(gold_correct),
        "alias_any": alias_any,
        "para_any": paraphrase_any,
    }


def _harmonic(left: float, right: float) -> float:
    if left <= 0 or right <= 0:
        return 0.0
    return 2 * left * right / (left + right)


def _mean_present(metric_entries: List[Dict]) -> float:
    present = [entry["accuracy"] for entry in metric_entries if entry["total"] > 0]
    return sum(present) / len(present) if present else 0.0


def aggregate(report_items: List[Dict]) -> Dict:
    buckets = {
        "all": EvalCounts(),
        "single_hop": EvalCounts(),
        "multi_hop": EvalCounts(),
        "gold": EvalCounts(),
        "alias": EvalCounts(),
        "paraphrase": EvalCounts(),
        "pre_gold": EvalCounts(),
        "forget_1_hop": EvalCounts(),
        "forget_2_hop": EvalCounts(),
        "forget_3_hop": EvalCounts(),
        "retain_1_hop": EvalCounts(),
        "retain_2_hop": EvalCounts(),
        "retain_relation": EvalCounts(),
    }
    residual_count = 0

    for item in report_items:
        flags = compute_residual_flags(item)
        if flags["residual"]:
            residual_count += 1

        item_group = item.get("group", "forget")
        item_subtype = item.get("subtype")
        hops = len(item.get("path", []))

        for prediction in item.get("predictions", []):
            buckets["all"].add(prediction["correct"])
            if hops == 1:
                buckets["single_hop"].add(prediction["correct"])
            elif hops > 1:
                buckets["multi_hop"].add(prediction["correct"])
            if prediction.get("type") == "gold":
                buckets["gold"].add(prediction["correct"])
                if prediction.get("pre_correct") is not None:
                    buckets["pre_gold"].add(prediction["pre_correct"])
                if item_group == "forget":
                    if hops == 1:
                        buckets["forget_1_hop"].add(prediction["correct"])
                    elif hops == 2:
                        buckets["forget_2_hop"].add(prediction["correct"])
                    elif hops >= 3:
                        buckets["forget_3_hop"].add(prediction["correct"])
                elif item_group == "retention":
                    if item_subtype == "one_hop_retention":
                        buckets["retain_1_hop"].add(prediction["correct"])
                    elif item_subtype == "two_hop_retention":
                        buckets["retain_2_hop"].add(prediction["correct"])
                    elif item_subtype == "relationship_retention":
                        buckets["retain_relation"].add(prediction["correct"])
            elif prediction.get("type") == "alias":
                buckets["alias"].add(prediction["correct"])
            elif prediction.get("type") == "paraphrase":
                buckets["paraphrase"].add(prediction["correct"])

    summary = {name: {"total": bucket.total, "correct": bucket.correct, "accuracy": bucket.accuracy} for name, bucket in buckets.items()}
    avg_multi_hop = _mean_present([summary["forget_1_hop"], summary["forget_2_hop"], summary["forget_3_hop"]])
    avg_retention = _mean_present([summary["retain_1_hop"], summary["retain_2_hop"], summary["retain_relation"]])
    overall = _harmonic(1 - avg_multi_hop, avg_retention)
    summary["paper_metrics"] = {
        "avg_multi_hop_forget_score": avg_multi_hop,
        "avg_retention_score": avg_retention,
        "overall_score": overall,
    }
    summary["residual_rate"] = residual_count / len(report_items) if report_items else 0.0
    summary["residual_count"] = residual_count
    summary["num_items"] = len(report_items)
    return summary
