﻿from __future__ import annotations

import json
from pathlib import Path

import typer

from .benchmarks import BenchmarkRunner, BenchmarkRunnerConfig
from .datasets import load_seed_records
from .evaluation import Evaluator
from .graph_builder import GraphBuilder, KG
from .llm_client import LLMClient
from .query_generator import QueryGenerator
from .settings import Config

app = typer.Typer(help="LLM2Graph: build graphs, synthesize paper-aligned probes, evaluate unlearning experiments, and run benchmark workflows.")


def _write_json(path: str | Path, payload: dict) -> None:
    Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _benchmark_runner(
    benchmark: str,
    dataset: str,
    out_dir: str,
    provider: str,
    model: str,
    pre_provider: str,
    pre_model: str,
    post_provider: str,
    post_model: str,
    judge_provider: str | None,
    judge_model: str | None,
    max_depth: int,
    temperature: float,
    timeout_s: int,
    elicitation_question_count: int,
    use_relevance: bool,
    relevance_threshold: float,
    decay: float,
    max_nodes_per_depth: int | None,
    alias_merge: bool,
    hops: int,
    num_paths: int,
    per_kind_limit: int,
    aliases: int,
    paraphrases: int,
    distractors: int,
    random_seed: int | None,
    limit: int | None,
) -> dict:
    config = BenchmarkRunnerConfig(
        benchmark=benchmark,
        dataset_path=dataset,
        output_dir=out_dir,
        provider=provider,
        model=model,
        pre_provider=pre_provider,
        pre_model=pre_model,
        post_provider=post_provider,
        post_model=post_model,
        judge_provider=judge_provider,
        judge_model=judge_model,
        max_depth=max_depth,
        temperature=temperature,
        timeout_s=timeout_s,
        elicitation_question_count=elicitation_question_count,
        use_relevance=use_relevance,
        relevance_threshold=relevance_threshold,
        decay=decay,
        max_nodes_per_depth=max_nodes_per_depth,
        alias_merge=alias_merge,
        hops=hops,
        num_paths=num_paths,
        per_kind_limit=per_kind_limit,
        aliases=aliases,
        paraphrases=paraphrases,
        distractors=distractors,
        random_seed=random_seed,
        limit=limit,
    )
    return BenchmarkRunner(config).run()


def _echo_benchmark_summary(out_dir: str, summary: dict) -> None:
    typer.echo(f"Wrote benchmark summary to {Path(out_dir) / 'benchmark_summary.json'} for {summary['num_entities']} entities")


@app.command("extract-seeds")
def extract_seeds(
    dataset: str = typer.Option(..., "--dataset", help="Path to a .txt, .json, .jsonl, or .csv file"),
    benchmark: str | None = typer.Option(None, "--benchmark", help="Optional benchmark hint: rwku or tofu"),
    limit: int | None = typer.Option(None, "--limit", help="Optional number of seeds to preview"),
) -> None:
    records = load_seed_records(dataset, benchmark=benchmark, limit=limit)
    typer.echo(json.dumps([{"seed": record.seed, "source_id": record.source_id} for record in records], indent=2))


@app.command("entity")
def entity_to_graph(
    seed: str = typer.Option(..., "--seed", help="Seed entity name"),
    max_depth: int = typer.Option(2, "--max-depth", help="Maximum BFS depth"),
    model: str = typer.Option("gpt-4o-mini-2024-07-18", "--model", help="Model id or HF repo id"),
    provider: str = typer.Option("openai", "--provider", help="Provider: openai | gemini | hf-local"),
    temperature: float = typer.Option(0.2, "--temperature", help="Sampling temperature"),
    timeout_s: int = typer.Option(180, "--timeout-s", help="Per-call timeout in seconds"),
    elicitation_question_count: int = typer.Option(10, "--elicitation-question-count", help="Entity questions asked during API-driven graph construction"),
    use_relevance: bool = typer.Option(False, "--use-relevance", help="LLM-score triples before expansion"),
    relevance_threshold: float = typer.Option(3.0, "--relevance-threshold", help="Minimum relevance score"),
    decay: float = typer.Option(1.0, "--decay", help="Depth-based branching decay factor"),
    max_nodes_per_depth: int | None = typer.Option(None, "--max-nodes-per-depth", help="Optional breadth cap"),
    alias_merge: bool = typer.Option(True, "--alias-merge/--no-alias-merge", help="Merge alias-equivalent nodes"),
    out: str = typer.Option("graph.json", "--out", help="Output JSON path"),
) -> None:
    cfg = Config(model=model, provider=provider, max_depth=max_depth, temperature=temperature, timeout_s=timeout_s, elicitation_question_count=elicitation_question_count)
    builder = GraphBuilder(cfg, use_relevance=use_relevance, relevance_threshold=relevance_threshold, decay=decay, max_nodes_per_depth=max_nodes_per_depth, alias_merge=alias_merge)
    kg = builder.build(seed)
    kg.save_json(out)
    typer.echo(f"Wrote {out} with {kg.num_nodes} nodes and {kg.num_edges} edges")


@app.command("gen-queries")
def gen_queries(
    graph: str = typer.Option(..., "--graph", help="Graph JSON produced by the entity command"),
    target: str = typer.Option(..., "--target", help="Target seed entity for path sampling"),
    hops: int = typer.Option(1, "--hops", help="Maximum hop depth to sample"),
    num_paths: int = typer.Option(50, "--num-paths", help="Maximum number of sampled forget paths per hop"),
    per_kind_limit: int = typer.Option(100, "--per-kind-limit", help="Maximum probes per query kind"),
    aliases: int = typer.Option(0, "--aliases", help="Aliases to generate per entity"),
    paraphrases: int = typer.Option(0, "--paraphrases", help="Paraphrases to generate per question"),
    distractors: int = typer.Option(0, "--distractors", help="Distractors to generate per answer"),
    provider: str = typer.Option("openai", "--provider", help="LLM provider"),
    model: str = typer.Option("gpt-4o-mini-2024-07-18", "--model", help="LLM model"),
    random_seed: int | None = typer.Option(None, "--random-seed", help="Optional sampling seed"),
    out: str = typer.Option("queries.json", "--out", help="Output JSON path"),
) -> None:
    payload = json.loads(Path(graph).read_text(encoding="utf-8"))
    generator = QueryGenerator(LLMClient(provider=provider, model=model))
    queries = generator.generate(payload, target=target, hops=hops, num_paths=num_paths, aliases=aliases, paraphrases=paraphrases, distractors=distractors, random_seed=random_seed, per_kind_limit=per_kind_limit)
    _write_json(out, queries)
    typer.echo(f"Wrote {out} with {len(queries['queries'])} forget queries")


@app.command("eval")
def eval_models(
    queries: str = typer.Option(..., "--queries", help="Query JSON from gen-queries"),
    pre_provider: str = typer.Option("openai", "--pre-provider", help="Provider for the pre-unlearning model"),
    pre_model: str = typer.Option("gpt-4o-mini-2024-07-18", "--pre-model", help="Pre-unlearning model"),
    post_provider: str = typer.Option("openai", "--post-provider", help="Provider for the post-unlearning model"),
    post_model: str = typer.Option("gpt-4o-mini-2024-07-18", "--post-model", help="Post-unlearning model"),
    judge_provider: str | None = typer.Option(None, "--judge-provider", help="Optional equivalence-judge provider"),
    judge_model: str | None = typer.Option(None, "--judge-model", help="Optional equivalence-judge model"),
    out: str = typer.Option("eval_report.json", "--out", help="Output JSON path"),
) -> None:
    payload = json.loads(Path(queries).read_text(encoding="utf-8"))
    pre = LLMClient(provider=pre_provider, model=pre_model)
    post = LLMClient(provider=post_provider, model=post_model)
    judge = LLMClient(provider=judge_provider, model=judge_model) if judge_provider and judge_model else None
    report = Evaluator(pre, post, judge).run(payload)
    _write_json(out, report)
    typer.echo(f"Wrote {out} with {report['summary']['num_items']} evaluated items")


@app.command("run-benchmark")
def run_benchmark(
    benchmark: str = typer.Option(..., "--benchmark", help="Benchmark mode: rwku or tofu"),
    dataset: str = typer.Option(..., "--dataset", help="Dataset or seed file"),
    out_dir: str = typer.Option("benchmark_run", "--out-dir", help="Output directory for per-entity artifacts"),
    provider: str = typer.Option("openai", "--provider"),
    model: str = typer.Option("gpt-4o-mini-2024-07-18", "--model"),
    pre_provider: str = typer.Option("openai", "--pre-provider"),
    pre_model: str = typer.Option("gpt-4o-mini-2024-07-18", "--pre-model"),
    post_provider: str = typer.Option("openai", "--post-provider"),
    post_model: str = typer.Option("gpt-4o-mini-2024-07-18", "--post-model"),
    judge_provider: str | None = typer.Option(None, "--judge-provider"),
    judge_model: str | None = typer.Option(None, "--judge-model"),
    max_depth: int = typer.Option(2, "--max-depth"),
    temperature: float = typer.Option(0.2, "--temperature"),
    timeout_s: int = typer.Option(180, "--timeout-s"),
    elicitation_question_count: int = typer.Option(10, "--elicitation-question-count"),
    use_relevance: bool = typer.Option(False, "--use-relevance"),
    relevance_threshold: float = typer.Option(3.0, "--relevance-threshold"),
    decay: float = typer.Option(1.0, "--decay"),
    max_nodes_per_depth: int | None = typer.Option(None, "--max-nodes-per-depth"),
    alias_merge: bool = typer.Option(True, "--alias-merge/--no-alias-merge"),
    hops: int = typer.Option(3, "--hops"),
    num_paths: int = typer.Option(100, "--num-paths"),
    per_kind_limit: int = typer.Option(100, "--per-kind-limit"),
    aliases: int = typer.Option(0, "--aliases"),
    paraphrases: int = typer.Option(0, "--paraphrases"),
    distractors: int = typer.Option(0, "--distractors"),
    random_seed: int | None = typer.Option(None, "--random-seed"),
    limit: int | None = typer.Option(None, "--limit", help="Optional number of entities to run"),
) -> None:
    normalized = benchmark.lower().strip()
    if normalized not in {"rwku", "tofu"}:
        raise typer.BadParameter("--benchmark must be either 'rwku' or 'tofu'")
    summary = _benchmark_runner(normalized, dataset, out_dir, provider, model, pre_provider, pre_model, post_provider, post_model, judge_provider, judge_model, max_depth, temperature, timeout_s, elicitation_question_count, use_relevance, relevance_threshold, decay, max_nodes_per_depth, alias_merge, hops, num_paths, per_kind_limit, aliases, paraphrases, distractors, random_seed, limit)
    _echo_benchmark_summary(out_dir, summary)


@app.command("run-rwku")
def run_rwku(
    dataset: str = typer.Option(..., "--dataset", help="RWKU seed/entity dataset file"),
    out_dir: str = typer.Option("rwku_run", "--out-dir", help="Output directory for per-entity artifacts"),
    provider: str = typer.Option("openai", "--provider"),
    model: str = typer.Option("gpt-4o-mini-2024-07-18", "--model"),
    pre_provider: str = typer.Option("openai", "--pre-provider"),
    pre_model: str = typer.Option("gpt-4o-mini-2024-07-18", "--pre-model"),
    post_provider: str = typer.Option("openai", "--post-provider"),
    post_model: str = typer.Option("gpt-4o-mini-2024-07-18", "--post-model"),
    judge_provider: str | None = typer.Option(None, "--judge-provider"),
    judge_model: str | None = typer.Option(None, "--judge-model"),
    max_depth: int = typer.Option(2, "--max-depth"),
    temperature: float = typer.Option(0.2, "--temperature"),
    timeout_s: int = typer.Option(180, "--timeout-s"),
    elicitation_question_count: int = typer.Option(10, "--elicitation-question-count"),
    use_relevance: bool = typer.Option(False, "--use-relevance"),
    relevance_threshold: float = typer.Option(3.0, "--relevance-threshold"),
    decay: float = typer.Option(1.0, "--decay"),
    max_nodes_per_depth: int | None = typer.Option(None, "--max-nodes-per-depth"),
    alias_merge: bool = typer.Option(True, "--alias-merge/--no-alias-merge"),
    hops: int = typer.Option(3, "--hops"),
    num_paths: int = typer.Option(100, "--num-paths"),
    per_kind_limit: int = typer.Option(100, "--per-kind-limit"),
    aliases: int = typer.Option(0, "--aliases"),
    paraphrases: int = typer.Option(0, "--paraphrases"),
    distractors: int = typer.Option(0, "--distractors"),
    random_seed: int | None = typer.Option(None, "--random-seed"),
    limit: int | None = typer.Option(None, "--limit", help="Optional number of entities to run"),
) -> None:
    summary = _benchmark_runner("rwku", dataset, out_dir, provider, model, pre_provider, pre_model, post_provider, post_model, judge_provider, judge_model, max_depth, temperature, timeout_s, elicitation_question_count, use_relevance, relevance_threshold, decay, max_nodes_per_depth, alias_merge, hops, num_paths, per_kind_limit, aliases, paraphrases, distractors, random_seed, limit)
    _echo_benchmark_summary(out_dir, summary)


@app.command("run-tofu")
def run_tofu(
    dataset: str = typer.Option(..., "--dataset", help="TOFU author/entity dataset file"),
    out_dir: str = typer.Option("tofu_run", "--out-dir", help="Output directory for per-entity artifacts"),
    provider: str = typer.Option("openai", "--provider"),
    model: str = typer.Option("gpt-4o-mini-2024-07-18", "--model"),
    pre_provider: str = typer.Option("openai", "--pre-provider"),
    pre_model: str = typer.Option("gpt-4o-mini-2024-07-18", "--pre-model"),
    post_provider: str = typer.Option("openai", "--post-provider"),
    post_model: str = typer.Option("gpt-4o-mini-2024-07-18", "--post-model"),
    judge_provider: str | None = typer.Option(None, "--judge-provider"),
    judge_model: str | None = typer.Option(None, "--judge-model"),
    max_depth: int = typer.Option(2, "--max-depth"),
    temperature: float = typer.Option(0.2, "--temperature"),
    timeout_s: int = typer.Option(180, "--timeout-s"),
    elicitation_question_count: int = typer.Option(10, "--elicitation-question-count"),
    use_relevance: bool = typer.Option(False, "--use-relevance"),
    relevance_threshold: float = typer.Option(3.0, "--relevance-threshold"),
    decay: float = typer.Option(1.0, "--decay"),
    max_nodes_per_depth: int | None = typer.Option(None, "--max-nodes-per-depth"),
    alias_merge: bool = typer.Option(True, "--alias-merge/--no-alias-merge"),
    hops: int = typer.Option(3, "--hops"),
    num_paths: int = typer.Option(100, "--num-paths"),
    per_kind_limit: int = typer.Option(100, "--per-kind-limit"),
    aliases: int = typer.Option(0, "--aliases"),
    paraphrases: int = typer.Option(0, "--paraphrases"),
    distractors: int = typer.Option(0, "--distractors"),
    random_seed: int | None = typer.Option(None, "--random-seed"),
    limit: int | None = typer.Option(None, "--limit", help="Optional number of entities to run"),
) -> None:
    summary = _benchmark_runner("tofu", dataset, out_dir, provider, model, pre_provider, pre_model, post_provider, post_model, judge_provider, judge_model, max_depth, temperature, timeout_s, elicitation_question_count, use_relevance, relevance_threshold, decay, max_nodes_per_depth, alias_merge, hops, num_paths, per_kind_limit, aliases, paraphrases, distractors, random_seed, limit)
    _echo_benchmark_summary(out_dir, summary)


@app.command("stats")
def graph_stats(graph: str = typer.Option(..., "--graph", help="Graph JSON to inspect")) -> None:
    kg = KG.from_json(json.loads(Path(graph).read_text(encoding="utf-8")))
    typer.echo(json.dumps(kg.to_json()["meta"], indent=2))


if __name__ == "__main__":
    app()
