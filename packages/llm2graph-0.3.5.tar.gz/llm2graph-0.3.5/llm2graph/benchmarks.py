﻿from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .datasets import SeedRecord, load_seed_records
from .evaluation import Evaluator
from .graph_builder import GraphBuilder
from .llm_client import LLMClient
from .query_generator import QueryGenerator
from .settings import Config


def _log_debug(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


@dataclass
class BenchmarkRunnerConfig:
    benchmark: str
    dataset_path: str
    output_dir: str
    provider: str = "openai"
    model: str = "gpt-4o-mini-2024-07-18"
    pre_provider: str = "openai"
    pre_model: str = "gpt-4o-mini-2024-07-18"
    post_provider: str = "openai"
    post_model: str = "gpt-4o-mini-2024-07-18"
    judge_provider: str | None = None
    judge_model: str | None = None
    max_depth: int = 2
    temperature: float = 0.2
    timeout_s: int = 180
    elicitation_question_count: int = 10
    use_relevance: bool = False
    relevance_threshold: float = 3.0
    decay: float = 1.0
    max_nodes_per_depth: int | None = None
    alias_merge: bool = True
    hops: int = 3
    num_paths: int = 100
    per_kind_limit: int = 100
    aliases: int = 0
    paraphrases: int = 0
    distractors: int = 0
    random_seed: int | None = None
    limit: int | None = None


def _slugify(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "-", value.strip()).strip("-").lower()
    return slug or "entity"


class BenchmarkRunner:
    def __init__(
        self,
        config: BenchmarkRunnerConfig,
        llm_factory: Callable[..., LLMClient] | None = None,
        graph_builder_factory: Callable[..., GraphBuilder] | None = None,
        query_generator_factory: Callable[..., QueryGenerator] | None = None,
        evaluator_factory: Callable[..., Evaluator] | None = None,
    ):
        self.config = config
        self.llm_factory = llm_factory or LLMClient
        self.graph_builder_factory = graph_builder_factory or GraphBuilder
        self.query_generator_factory = query_generator_factory or QueryGenerator
        self.evaluator_factory = evaluator_factory or Evaluator

    def _config(self) -> Config:
        return Config(
            provider=self.config.provider,
            model=self.config.model,
            max_depth=self.config.max_depth,
            temperature=self.config.temperature,
            timeout_s=self.config.timeout_s,
            elicitation_question_count=self.config.elicitation_question_count,
        )

    def load_records(self) -> list[SeedRecord]:
        return load_seed_records(self.config.dataset_path, benchmark=self.config.benchmark, limit=self.config.limit)

    def _graph_builder(self) -> GraphBuilder:
        return self.graph_builder_factory(
            self._config(),
            use_relevance=self.config.use_relevance,
            relevance_threshold=self.config.relevance_threshold,
            decay=self.config.decay,
            max_nodes_per_depth=self.config.max_nodes_per_depth,
            alias_merge=self.config.alias_merge,
        )

    def _generator(self) -> QueryGenerator:
        return self.query_generator_factory(self.llm_factory(provider=self.config.provider, model=self.config.model))

    def _evaluator(self) -> Evaluator:
        judge = None
        if self.config.judge_provider and self.config.judge_model:
            judge = self.llm_factory(provider=self.config.judge_provider, model=self.config.judge_model)
        return self.evaluator_factory(
            self.llm_factory(provider=self.config.pre_provider, model=self.config.pre_model),
            self.llm_factory(provider=self.config.post_provider, model=self.config.post_model),
            judge,
        )

    def run_record(self, record: SeedRecord) -> dict:
        output_root = Path(self.config.output_dir)
        entity_dir = output_root / _slugify(record.seed)
        entity_dir.mkdir(parents=True, exist_ok=True)
        _log_debug(
            f"[llm2graph] Benchmark record start benchmark={self.config.benchmark} "
            f"seed={record.seed} out_dir={entity_dir}"
        )

        builder = self._graph_builder()
        try:
            kg = builder.build(record.seed)
        except Exception as exc:
            _log_debug(
                f"[llm2graph] Benchmark record graph_build_failed seed={record.seed} "
                f"error={exc.__class__.__name__}: {exc}"
            )
            raise
        graph_path = kg.save_json(entity_dir / "graph.json")
        _log_debug(
            f"[llm2graph] Benchmark graph_written seed={record.seed} path={graph_path} "
            f"nodes={kg.num_nodes} edges={kg.num_edges}"
        )

        generator = self._generator()
        try:
            queries = generator.generate(
                kg.to_json(),
                target=record.seed,
                hops=self.config.hops,
                num_paths=self.config.num_paths,
                aliases=self.config.aliases,
                paraphrases=self.config.paraphrases,
                distractors=self.config.distractors,
                random_seed=self.config.random_seed,
                per_kind_limit=self.config.per_kind_limit,
            )
        except Exception as exc:
            _log_debug(
                f"[llm2graph] Benchmark record query_generation_failed seed={record.seed} "
                f"error={exc.__class__.__name__}: {exc}"
            )
            raise
        queries_path = entity_dir / "queries.json"
        queries_path.write_text(json.dumps(queries, ensure_ascii=False, indent=2), encoding="utf-8")
        _log_debug(f"[llm2graph] Benchmark queries_written seed={record.seed} path={queries_path}")

        try:
            report = self._evaluator().run(queries)
        except Exception as exc:
            _log_debug(
                f"[llm2graph] Benchmark record evaluation_failed seed={record.seed} "
                f"error={exc.__class__.__name__}: {exc}"
            )
            raise
        report_path = entity_dir / "eval_report.json"
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        _log_debug(f"[llm2graph] Benchmark report_written seed={record.seed} path={report_path}")

        paper_metrics = report.get("summary", {}).get("paper_metrics", {})
        return {
            "seed": record.seed,
            "source_id": record.source_id,
            "graph_path": str(graph_path),
            "queries_path": str(queries_path),
            "report_path": str(report_path),
            "graph_nodes": kg.num_nodes,
            "graph_edges": kg.num_edges,
            "evaluated_items": report.get("summary", {}).get("num_items", 0),
            "overall_score": paper_metrics.get("overall_score"),
            "avg_multi_hop_forget_score": paper_metrics.get("avg_multi_hop_forget_score"),
            "avg_retention_score": paper_metrics.get("avg_retention_score"),
        }

    def run(self) -> dict:
        records = self.load_records()
        output_root = Path(self.config.output_dir)
        output_root.mkdir(parents=True, exist_ok=True)
        _log_debug(
            f"[llm2graph] Benchmark run start benchmark={self.config.benchmark} "
            f"records={len(records)} dataset={self.config.dataset_path}"
        )
        results = [self.run_record(record) for record in records]
        summary = {
            "benchmark": self.config.benchmark,
            "dataset_path": self.config.dataset_path,
            "num_entities": len(results),
            "results": results,
        }
        (output_root / "benchmark_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        _log_debug(
            f"[llm2graph] Benchmark run complete benchmark={self.config.benchmark} "
            f"results={len(results)} summary={output_root / 'benchmark_summary.json'}"
        )
        return summary


def run_rwku(**kwargs) -> dict:
    return BenchmarkRunner(BenchmarkRunnerConfig(benchmark="rwku", **kwargs)).run()


def run_tofu(**kwargs) -> dict:
    return BenchmarkRunner(BenchmarkRunnerConfig(benchmark="tofu", **kwargs)).run()
