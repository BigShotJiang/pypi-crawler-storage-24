﻿from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence


@dataclass(frozen=True)
class SeedRecord:
    seed: str
    source_id: str | None = None
    metadata: dict[str, Any] | None = None


_DEFAULT_FIELDS = ["seed", "entity", "target", "author", "name", "title", "subject"]
_BENCHMARK_FIELDS = {
    "rwku": ["entity", "target", "name", "title", "subject"] + _DEFAULT_FIELDS,
    "tofu": ["author", "name", "entity", "target"] + _DEFAULT_FIELDS,
}


def _iter_json_payload(payload: Any) -> Iterator[Any]:
    if isinstance(payload, list):
        yield from payload
        return
    if isinstance(payload, dict):
        for key in ("data", "items", "examples", "records", "entities", "authors"):
            value = payload.get(key)
            if isinstance(value, list):
                yield from value
                return
        yield payload
        return
    yield payload


def _read_records(dataset_path: Path) -> list[Any]:
    suffix = dataset_path.suffix.lower()
    if suffix == ".txt":
        return [line.strip() for line in dataset_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if suffix == ".jsonl":
        return [json.loads(line) for line in dataset_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if suffix == ".json":
        payload = json.loads(dataset_path.read_text(encoding="utf-8"))
        return list(_iter_json_payload(payload))
    if suffix == ".csv":
        with dataset_path.open("r", encoding="utf-8", newline="") as handle:
            return list(csv.DictReader(handle))
    raise ValueError(f"Unsupported dataset format: {dataset_path.suffix}")


def _coerce_seed(record: Any, field_order: Sequence[str], index: int) -> SeedRecord | None:
    if isinstance(record, str):
        seed = record.strip()
        return SeedRecord(seed=seed, source_id=str(index), metadata={}) if seed else None
    if not isinstance(record, dict):
        return None

    for field in field_order:
        value = record.get(field)
        if isinstance(value, str) and value.strip():
            source_id = None
            for candidate in ("id", "entity_id", "target_id", "author_id"):
                raw_id = record.get(candidate)
                if isinstance(raw_id, (str, int)):
                    source_id = str(raw_id)
                    break
            return SeedRecord(seed=value.strip(), source_id=source_id or str(index), metadata=dict(record))
    return None


def load_seed_records(dataset_path: str | Path, benchmark: str | None = None, limit: int | None = None) -> list[SeedRecord]:
    path = Path(dataset_path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")

    field_order = _BENCHMARK_FIELDS.get((benchmark or "").lower(), _DEFAULT_FIELDS)
    records = _read_records(path)
    seeds: list[SeedRecord] = []
    seen: set[str] = set()
    for index, record in enumerate(records):
        seed_record = _coerce_seed(record, field_order, index)
        if seed_record is None:
            continue
        if seed_record.seed in seen:
            continue
        seen.add(seed_record.seed)
        seeds.append(seed_record)
        if limit is not None and len(seeds) >= limit:
            break
    if not seeds:
        raise ValueError(f"No seed entities found in {path}")
    return seeds


def load_seeds(dataset_path: str | Path, benchmark: str | None = None, limit: int | None = None) -> list[str]:
    return [record.seed for record in load_seed_records(dataset_path, benchmark=benchmark, limit=limit)]
