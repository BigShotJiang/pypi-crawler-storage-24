# VidContext MCP Server — Give your AI agent eyes.
__version__ = "0.2.0"
