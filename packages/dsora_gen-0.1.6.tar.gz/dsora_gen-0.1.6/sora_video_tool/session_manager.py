"""
Luu trang thai phien chay hien tai de tiep tuc neu bi gian doan.
File: ~/.sora-tool/session.json
"""
from __future__ import annotations

import json
from datetime import datetime

from .constants import APP_DATA_DIR

_SESSION_FILE = APP_DATA_DIR / "session.json"

PENDING  = "pending"
DONE     = "done"
FAILED   = "failed"


def create_session(batches_data: list[dict]) -> None:
    """Tao phien moi. batches_data la list cac dict voi keys: profile_id, alias, products."""
    session = {
        "started_at": datetime.now().isoformat(),
        "status": "in_progress",
        "batches": batches_data,
    }
    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
    _SESSION_FILE.write_text(
        json.dumps(session, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def load_session() -> dict | None:
    if not _SESSION_FILE.exists():
        return None
    try:
        return json.loads(_SESSION_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def has_active_session() -> bool:
    s = load_session()
    return s is not None and s.get("status") == "in_progress"


def update_product_status(profile_id: str, product_id, status: str) -> None:
    s = load_session()
    if not s:
        return
    for batch in s["batches"]:
        if batch["profile_id"] == profile_id:
            for p in batch["products"]:
                if p["id"] == product_id:
                    p["status"] = status
                    break
            break
    _SESSION_FILE.write_text(
        json.dumps(s, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def mark_session_done() -> None:
    s = load_session()
    if not s:
        return
    s["status"] = "done"
    _SESSION_FILE.write_text(
        json.dumps(s, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def clear_session() -> None:
    if _SESSION_FILE.exists():
        _SESSION_FILE.unlink()
