"""AgentBase Memory Store implementation following BaseStore pattern.

This implementation uses the ops pattern and batch function handlers,
directly calling the AgentBase Memory API for create_event and retrieve_memory_records.
"""

import logging
import uuid
from collections.abc import Iterable
from datetime import datetime, timezone
from typing import Any

from langchain_core.messages import BaseMessage
from langgraph.store.base import (
    BaseStore,
    GetOp,
    Item,
    ListNamespacesOp,
    Op,
    PutOp,
    Result,
    SearchItem,
    SearchOp,
)

from greennode_agentbase.memory import MemoryClient
from greennode_agentbase.memory.models import ChatMessage, EventCreateRequest

from greennode_agent_bridge.langgraph.memory.helpers import (
    convert_langchain_messages_to_event_messages,
)

logger = logging.getLogger(__name__)


class AgentBaseMemoryRecords(BaseStore):
    """
    AgentBase Memory Store implementation using BaseStore pattern.

    This store saves chat messages as conversational events in AgentBase Memory
    and retrieves processed memories through semantic search. The embedding and
    memory processing happens automatically in the AgentBase Memory service.

    Args:
        memory_id: The AgentBase Memory resource ID
        memory_client: Optional MemoryClient instance. If not provided, creates a new one.

    Example:
        ```python
        store = AgentBaseMemoryRecords(
            memory_id="memory_abc123"
        )

        # Store a message
        from langchain_core.messages import HumanMessage
        store.put(("user123", "session456"), "msg1", {
            "message": HumanMessage("I love coffee")
        })

        # Search for processed memories
        results = store.search(("facts", "user123"), query="user preferences")
        ```
    """

    supports_ttl: bool = False
    ttl_config = None

    def __init__(self, *, memory_id: str, memory_client: MemoryClient | None = None):
        self.memory_id = memory_id
        self.memory_client = memory_client or MemoryClient()

    def batch(self, ops: Iterable[Op]) -> list[Result]:
        """Execute multiple operations in a single batch."""
        results: list[Result] = []

        for op in ops:
            if isinstance(op, PutOp):
                self._handle_put(op)
                results.append(None)
            elif isinstance(op, SearchOp):
                result = self._handle_search(op)
                results.append(result)
            elif isinstance(op, GetOp):
                result = self._handle_get(op)
                results.append(result)
            elif isinstance(op, ListNamespacesOp):
                # ListNamespacesOp not supported for AgentBase Memory
                results.append([])
            else:
                raise ValueError(f"Unknown operation type: {type(op)}")

        return results

    async def abatch(self, ops: Iterable[Op]) -> list[Result]:
        """Execute multiple operations asynchronously."""
        results: list[Result] = []

        for op in ops:
            if isinstance(op, PutOp):
                await self._handle_put_async(op)
                results.append(None)
            elif isinstance(op, SearchOp):
                result = await self._handle_search_async(op)
                results.append(result)
            elif isinstance(op, GetOp):
                result = await self._handle_get_async(op)
                results.append(result)
            elif isinstance(op, ListNamespacesOp):
                # ListNamespacesOp not supported for AgentBase Memory
                results.append([])
            else:
                raise ValueError(f"Unknown operation type: {type(op)}")

        return results

    def _handle_put(self, op: PutOp) -> None:
        """Handle PutOp by creating conversational events in AgentBase Memory."""
        if op.value is None:
            # TODO: Delete operation support - need to figure out if we are deleting events or records
            logger.warning("Delete operations not supported in AgentBase Memory")
            return

        message = op.value.get("message")
        if not isinstance(message, BaseMessage):
            raise ValueError(
                "Value must contain a 'message' key with a BaseMessage object"
            )

        # Convert namespace tuple to actor_id and session_id
        if len(op.namespace) != 2:
            raise ValueError("Namespace must be a tuple of (actor_id, session_id)")

        actor_id, session_id = op.namespace
        event_messages = convert_langchain_messages_to_event_messages([message])

        if not event_messages:
            logger.warning(
                f"No valid event messages to create for message type: {message.type}"
            )
            return

        conversational_payloads = []
        for text, role in event_messages:
            conversational_payloads.append(
                ChatMessage(content=text, role=role)
            )

        # Create events - AgentBase may support batch creation, but for now create individually
        import asyncio

        for payload in conversational_payloads:
            request = EventCreateRequest(
                payload=payload,
                event_timestamp=datetime.now(timezone.utc).isoformat(),
            )

            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    import concurrent.futures

                    with concurrent.futures.ThreadPoolExecutor() as executor:
                        future = executor.submit(
                            asyncio.run,
                            self.memory_client.createEvent_async(
                                id=self.memory_id,
                                actorId=actor_id,
                                sessionId=session_id,
                                request=request,
                            ),
                        )
                        future.result()
                else:
                    asyncio.run(
self.memory_client.createEvent_async(
                        id=self.memory_id,
                        actorId=actor_id,
                        sessionId=session_id,
                        request=request,
                    )
                )
            except RuntimeError:
                asyncio.run(
                    self.memory_client.createEvent_async(
                        id=self.memory_id,
                        actorId=actor_id,
                        sessionId=session_id,
                        request=request,
                    )
                )

        logger.debug(f"Created event for message in namespace {op.namespace}")

    async def _handle_put_async(self, op: PutOp) -> None:
        """Handle PutOp asynchronously by creating conversational events in AgentBase Memory."""
        if op.value is None:
            logger.warning("Delete operations not supported in AgentBase Memory")
            return

        message = op.value.get("message")
        if not isinstance(message, BaseMessage):
            raise ValueError(
                "Value must contain a 'message' key with a BaseMessage object"
            )

        if len(op.namespace) != 2:
            raise ValueError("Namespace must be a tuple of (actor_id, session_id)")

        actor_id, session_id = op.namespace
        event_messages = convert_langchain_messages_to_event_messages([message])

        if not event_messages:
            logger.warning(
                f"No valid event messages to create for message type: {message.type}"
            )
            return

        for text, role in event_messages:
            payload = ChatMessage(content=text, role=role)
            request = EventCreateRequest(
                payload=payload,
                event_timestamp=datetime.now(timezone.utc).isoformat(),
            )

            await self.memory_client.createEvent_async(
                id=self.memory_id,
                actorId=actor_id,
                sessionId=session_id,
                request=request,
            )

        logger.debug(f"Created event for message in namespace {op.namespace}")

    def _handle_get(self, op: GetOp) -> Result:
        """Handle GetOp by retrieving a specific memory record from AgentBase Memory.

        Uses listMemoryRecords_async (spec has no get-by-id) and filters by op.key.
        """
        try:
            import asyncio

            namespace_str = self._convert_namespace_to_string(op.namespace)

            def _fetch() -> Any:
                return asyncio.run(
                    self.memory_client.listMemoryRecords_async(
                        id=self.memory_id,
                        namespace=namespace_str,
                    )
                )

            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    import concurrent.futures

                    with concurrent.futures.ThreadPoolExecutor() as executor:
                        future = executor.submit(_fetch)
                        records = future.result()
                else:
                    records = _fetch()
            except RuntimeError:
                records = _fetch()

            # listMemoryRecords_async returns list (is_array_response)
            if not isinstance(records, list):
                records = getattr(records, "list_data", []) or []
            for record in records:
                if getattr(record, "id", None) == op.key:
                    return self._convert_memory_record_to_item(record, op.namespace)
            return None

        except Exception as e:
            error_code = getattr(e, "status_code", None)
            if error_code == 404:
                return None
            logger.error(f"Failed to get memory record: {e}")
            raise

    async def _handle_get_async(self, op: GetOp) -> Result:
        """Handle GetOp asynchronously by retrieving a specific memory record.

        Uses listMemoryRecords_async (spec has no get-by-id) and filters by op.key.
        """
        try:
            namespace_str = self._convert_namespace_to_string(op.namespace)
            records = await self.memory_client.listMemoryRecords_async(
                id=self.memory_id,
                namespace=namespace_str,
            )
            if not isinstance(records, list):
                records = getattr(records, "list_data", []) or []
            for record in records:
                if getattr(record, "id", None) == op.key:
                    return self._convert_memory_record_to_item(record, op.namespace)
            return None

        except Exception as e:
            error_code = getattr(e, "status_code", None)
            if error_code == 404:
                return None
            logger.error(f"Failed to get memory record: {e}")
            raise

    def _handle_search(self, op: SearchOp) -> Result:
        """Handle SearchOp by retrieving memory records from AgentBase Memory."""
        if not op.query:
            logger.warning("Search requires a query for AgentBase Memory")
            return []

        namespace_str = self._convert_namespace_to_string(op.namespace_prefix)

        # Create search request
        from greennode_agentbase.memory.models import MemoryRecordSearchRequest

        search_request = MemoryRecordSearchRequest(query=op.query)

        import asyncio

        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(
                        asyncio.run,
                        self.memory_client.searchMemoryRecords_async(
                            id=self.memory_id,
                            namespace=namespace_str,
                            request=search_request,
                        ),
                    )
                    response = future.result()
            else:
                response = asyncio.run(
                    self.memory_client.searchMemoryRecords_async(
                        id=self.memory_id,
                        namespace=namespace_str,
                        request=search_request,
                    )
                )
        except RuntimeError:
            response = asyncio.run(
                self.memory_client.searchMemoryRecords_async(
                    id=self.memory_id,
                    namespace=namespace_str,
                    request=search_request,
                )
            )

        # searchMemoryRecords_async returns list (is_array_response) or object with list_data
        memory_records = (
            response
            if isinstance(response, list)
            else (getattr(response, "list_data", None) or [])
        )
        return self._convert_memory_records_to_search_items(
            memory_records, op.namespace_prefix
        )

    async def _handle_search_async(self, op: SearchOp) -> Result:
        """Handle SearchOp asynchronously by retrieving memory records."""
        if not op.query:
            logger.warning("Search requires a query for AgentBase Memory")
            return []

        namespace_str = self._convert_namespace_to_string(op.namespace_prefix)

        from greennode_agentbase.memory.models import MemoryRecordSearchRequest

        search_request = MemoryRecordSearchRequest(query=op.query)

        response = await self.memory_client.searchMemoryRecords_async(
            id=self.memory_id,
            namespace=namespace_str,
            request=search_request,
        )

        memory_records = (
            response
            if isinstance(response, list)
            else (getattr(response, "list_data", None) or [])
        )
        return self._convert_memory_records_to_search_items(
            memory_records, op.namespace_prefix
        )

    def _convert_namespace_to_string(self, namespace_tuple: tuple[str, ...]) -> str:
        """Convert namespace tuple to AgentBase namespace string."""
        if not isinstance(namespace_tuple, tuple):
            raise TypeError("namespace_tuple must be a tuple")
        if not namespace_tuple:
            return "/"
        return "/" + "/".join(namespace_tuple)

    def _convert_memory_record_to_item(
        self, memory_record: Any, namespace: tuple[str, ...]
    ) -> Item:
        """Convert a single AgentBase memory record to an Item object."""
        # Extract content - adapt based on actual API response structure
        content = getattr(memory_record, "content", None) or getattr(
            memory_record, "memory", ""
        )
        if isinstance(content, dict):
            text = content.get("text", "") if isinstance(content, dict) else str(content)
        else:
            text = str(content) if content else ""

        # Extract metadata
        memory_record_id = (
            getattr(memory_record, "id", None)
            or getattr(memory_record, "memory_record_id", None)
            or str(uuid.uuid4())
        )
        created_at = getattr(memory_record, "created_at", None) or getattr(
            memory_record, "createdAt", None
        )

        # Parse timestamp
        if isinstance(created_at, str):
            try:
                created_at = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                created_at = datetime.now(timezone.utc)
        elif created_at is None:
            created_at = datetime.now(timezone.utc)

        return Item(
            namespace=namespace,
            key=str(memory_record_id),
            value={
                "content": text,
                "memory_strategy_id": getattr(memory_record, "memory_strategy_id", None),
                "namespaces": getattr(memory_record, "namespaces", []),
            },
            created_at=created_at,
            updated_at=created_at,  # Memory records are not updated
        )

    def _convert_memory_records_to_search_items(
        self, memory_records: list, namespace: tuple[str, ...]
    ) -> list[SearchItem]:
        """Convert AgentBase memory records to SearchItem objects."""
        results = []

        for record in memory_records:
            content = getattr(record, "content", None) or getattr(record, "memory", "")
            text = (
                content.get("text", "") if isinstance(content, dict) else str(content)
            )

            memory_record_id = (
                getattr(record, "id", None)
                or getattr(record, "memory_record_id", None)
                or str(uuid.uuid4())
            )
            score = getattr(record, "score", None)
            created_at = getattr(record, "created_at", None) or getattr(
                record, "createdAt", None
            )

            if isinstance(created_at, str):
                try:
                    created_at = datetime.fromisoformat(
                        created_at.replace("Z", "+00:00")
                    )
                except (ValueError, AttributeError):
                    created_at = datetime.now(timezone.utc)
            elif created_at is None:
                created_at = datetime.now(timezone.utc)

            search_item = SearchItem(
                namespace=namespace,
                key=str(memory_record_id),
                value={
                    "content": text,
                    "memory_strategy_id": getattr(record, "memory_strategy_id", None),
                    "namespaces": getattr(record, "namespaces", []),
                },
                created_at=created_at,
                updated_at=created_at,  # Memory records are not updated
                score=float(score) if score is not None else None,
            )
            results.append(search_item)

        return results
