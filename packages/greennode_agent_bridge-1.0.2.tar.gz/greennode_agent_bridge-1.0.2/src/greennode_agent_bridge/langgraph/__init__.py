"""LangGraph adaptor for GreenNode AgentBase.

This package provides adaptors for LangGraph to work with GreenNode AgentBase.
"""

# Re-export from memory submodule for backward compatibility and convenience
try:
    from greennode_agent_bridge.langgraph.memory import (
        AgentBaseMemoryEvents,
        AgentBaseMemoryRecords,
        langgraph_available,
    )

    __all__ = [
        "AgentBaseMemoryEvents",
        "AgentBaseMemoryRecords",
        "langgraph_available",
    ]
except ImportError:
    # If memory module is not available, provide empty exports
    __all__ = []
