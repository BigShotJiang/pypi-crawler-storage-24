"""GreenNode Agent Bridge - Connect agent frameworks with GreenNode AgentBase.

This package provides adaptors for various agent frameworks (LangGraph, CrewAI, etc.)
to work with GreenNode AgentBase Memory and Runtime services.
"""

__version__ = "0.1.0"

# Conditional imports for optional dependencies
try:
    from greennode_agent_bridge.langgraph.memory import (
        AgentBaseMemoryEvents,
        AgentBaseMemoryRecords,
    )

    __all__ = [
        "AgentBaseMemoryEvents",
        "AgentBaseMemoryRecords",
    ]
except ImportError as e:
    # Store the import error for later use
    _import_error = e
    __all__ = []

    # Provide helpful error message when optional dependencies are missing
    def _missing_langgraph_dependencies_error(*args, **kwargs):
        raise ImportError(
            "LangGraph functionality requires optional dependencies. "
            "Install them with: pip install 'greennode-agent-bridge[langgraph]'"
        ) from _import_error

    # Create placeholder classes that raise helpful error
    AgentBaseMemoryEvents = _missing_langgraph_dependencies_error  # type: ignore[assignment]
    AgentBaseMemoryRecords = _missing_langgraph_dependencies_error  # type: ignore[assignment]
