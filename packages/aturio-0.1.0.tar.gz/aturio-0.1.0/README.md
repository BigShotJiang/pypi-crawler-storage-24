# Aturio

**Southeast Asia Legal Intelligence Platform**

Aturio provides structured access to legislation, court decisions, and lawyer intelligence across Southeast Asia through a unified API.

## Current Release

This Python SDK currently includes Indonesia legal data access via the public [Pasal.id API](https://pasal.id/api). Broader Southeast Asia support is under active development.

## Installation

```bash
pip install aturio
```

## Usage

```python
from aturio import create_indonesia_client, get_law, list_laws, search

client = create_indonesia_client()

results = search("upah minimum", limit=3)
laws = list_laws(type="UU", limit=5)
law = get_law("/akn/id/act/uu/2003/13")

print(results["total"])
print(law["work"]["title"])
print(laws["laws"][0]["frbr_uri"])
```

## Included Methods

- `search(query, ...)` -> search Indonesian legal materials
- `list_laws(...)` -> list laws with filters and pagination
- `get_law(frbr_uri)` -> fetch a law and its article content
- `create_indonesia_client(...)` -> create a reusable client instance

## Platform Coverage

- [pasal.id](https://pasal.id) - Indonesia (live, included in this package)
- [laws.sg](https://laws.sg) - Singapore (coming soon)

## Links

- Website: [aturio.dev](https://aturio.dev)
- GitHub: [github.com/Aturio](https://github.com/Aturio)
- API docs: [pasal.id/api](https://pasal.id/api)
