"""Aturio Python SDK with Indonesia legal data access via the public Pasal API."""

from .client import (
    DEFAULT_BASE_URL,
    DEFAULT_DOCS_URL,
    AturioApiError,
    AturioClient,
    client,
    create_aturio_client,
    create_client,
    create_indonesia_client,
    create_pasal_client,
    get_law,
    list_laws,
    request,
    search,
)

__version__ = "0.1.0"

__all__ = [
    "DEFAULT_BASE_URL",
    "DEFAULT_DOCS_URL",
    "AturioApiError",
    "AturioClient",
    "client",
    "create_aturio_client",
    "create_client",
    "create_indonesia_client",
    "create_pasal_client",
    "get_law",
    "list_laws",
    "request",
    "search",
]
