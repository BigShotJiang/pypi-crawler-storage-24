"""
roboat.session
~~~~~~~~~~~~~~~~~
Interactive terminal session — the roboat REPL.

Start it with:
    from roboat import RoboatSession
    RoboatSession().run()

Or from the command line:
    python -m roboat
"""

from __future__ import annotations
import sys
import os
import textwrap
from typing import Optional

from .client import RoboatClient
from .database import SessionDatabase
from .exceptions import RobloxAPIError, DatabaseError


# ── ANSI colours ──────────────────────────────────────────────────────── #

class C:
    RED    = "\033[91m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    BLUE   = "\033[94m"
    CYAN   = "\033[96m"
    WHITE  = "\033[97m"
    GRAY   = "\033[90m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RESET  = "\033[0m"

    @staticmethod
    def _supports_color() -> bool:
        return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()

    @classmethod
    def strip(cls, text: str) -> str:
        """Remove all ANSI codes (for plain output)."""
        import re
        return re.sub(r"\033\[[0-9;]*m", "", text)


def _c(text: str, color: str) -> str:
    return f"{color}{text}{C.RESET}" if C._supports_color() else text


# ── Banner ─────────────────────────────────────────────────────────────── #

BANNER = r"""
  ____       _     _            _    ____ ___ 
 |  _ \ ___ | |__ | | _____  __/ \  |  _ \_ _|
 | |_) / _ \| '_ \| |/ _ \ \/ / _ \ | |_) | | 
 |  _ < (_) | |_) | | (_) >  < ___ \|  __/| | 
 |_| \_\___/|_.__/|_|\___/_/\_/_/  \_|_|  |___|
                                                
"""

VERSION = "2.0.0"


# ── Session ────────────────────────────────────────────────────────────── #

class RoboatSession:
    """
    Interactive terminal session for the Roblox API.

    Commands
    --------
    start <userid>       Begin session as a user (optionally authenticated)
    cookie <token>       Set .ROBLOSECURITY cookie for authenticated requests
    loaddb <name>        Load an existing local database
    newdb <name>         Create a new local database
    listdb               List all local databases
    user <userid>        Fetch user info
    game <universeid>    Fetch game info + visits
    friends <userid>     Get friends list
    followers <userid>   Get follower count & list
    likes <universeid>   Get game upvote/downvote stats
    search <keyword>     Search users or games (type: user|game <kw>)
    presence <userid>    Get user online status
    avatar <userid>      Get user avatar info
    servers <placeid>    List active game servers
    badges <universeid>  List badges in a game
    catalog <keyword>    Search the avatar catalog
    robux                Show your Robux balance (requires cookie)
    save user <id>       Save fetched user to DB
    save game <id>       Save fetched game to DB
    whoami               Show current session user
    history              Show command history
    clear                Clear the screen
    help                 Show this menu
    exit / quit          Close the session
    """

    def __init__(self):
        self.client: RoboatClient = RoboatClient()
        self.db: Optional[SessionDatabase] = None
        self.session_user_id: Optional[int] = None
        self.session_username: Optional[str] = None
        self._running = False
        self._history: list = []

    # ── I/O helpers ─────────────────────────────────────────────────────

    def _print(self, text: str = ""):
        print(text)

    def _ok(self, text: str):
        print(_c(f"  ✔  {text}", C.GREEN))

    def _err(self, text: str):
        print(_c(f"  ✖  {text}", C.RED))

    def _info(self, text: str):
        print(_c(f"  ℹ  {text}", C.CYAN))

    def _warn(self, text: str):
        print(_c(f"  ⚠  {text}", C.YELLOW))

    def _section(self, title: str):
        w = 56
        line = "─" * w
        print()
        print(_c(f"┌{line}┐", C.BLUE))
        padded = f" {title} ".center(w)
        print(_c(f"│{padded}│", C.BOLD + C.WHITE))
        print(_c(f"└{line}┘", C.BLUE))

    def _prompt(self) -> str:
        db_tag = _c(f"[{self.db.name}] ", C.GRAY) if self.db else ""
        user_tag = _c(f"{self.session_username} ", C.CYAN) if self.session_username else ""
        arrow = _c("» ", C.YELLOW)
        try:
            raw = input(f"\n{db_tag}{user_tag}{arrow}")
        except (EOFError, KeyboardInterrupt):
            print()
            return "exit"
        return raw.strip()

    def _log(self, cmd: str, result: str = ""):
        self._history.append(cmd)
        if self.db:
            try:
                self.db.log_command(cmd, result)
            except Exception:
                pass

    # ── Entry point ─────────────────────────────────────────────────────

    def run(self):
        """Start the interactive REPL."""
        os.system("cls" if os.name == "nt" else "clear")
        print(_c(BANNER, C.CYAN + C.BOLD))
        print(_c(f"  roboat v{VERSION}  —  type 'help' to begin", C.GRAY))
        print()
        self._running = True
        while self._running:
            raw = self._prompt()
            if not raw:
                continue
            self._dispatch(raw)

    def _dispatch(self, raw: str):
        parts = raw.split(None, 2)
        cmd = parts[0].lower()
        args = parts[1:]

        self._log(raw)

        handlers = {
            "help":     self._cmd_help,
            "exit":     self._cmd_exit,
            "quit":     self._cmd_exit,
            "clear":    self._cmd_clear,
            "start":    self._cmd_start,
            "cookie":   self._cmd_cookie,
            "whoami":   self._cmd_whoami,
            "newdb":    self._cmd_newdb,
            "loaddb":   self._cmd_loaddb,
            "listdb":   self._cmd_listdb,
            "user":     self._cmd_user,
            "game":     self._cmd_game,
            "friends":  self._cmd_friends,
            "followers": self._cmd_followers,
            "likes":    self._cmd_likes,
            "search":   self._cmd_search,
            "presence": self._cmd_presence,
            "avatar":   self._cmd_avatar,
            "servers":  self._cmd_servers,
            "badges":   self._cmd_badges,
            "catalog":  self._cmd_catalog,
            "robux":    self._cmd_robux,
            "save":     self._cmd_save,
            "history":  self._cmd_history,
        }
        handler = handlers.get(cmd)
        if handler:
            try:
                handler(args)
            except RobloxAPIError as e:
                self._err(str(e))
            except Exception as e:
                self._err(f"Unexpected error: {e}")
        else:
            self._err(f"Unknown command '{cmd}'. Type 'help' for commands.")

    # ── Commands ─────────────────────────────────────────────────────────

    def _cmd_help(self, args):
        self._section("Commands")
        cmds = [
            ("start <userid>",       "Begin session as a Roblox user"),
            ("cookie <token>",       "Set .ROBLOSECURITY for auth requests"),
            ("whoami",               "Show current session user"),
            ("",                     ""),
            ("newdb <name>",         "Create a new local database"),
            ("loaddb <name>",        "Load an existing database"),
            ("listdb",               "List all local databases"),
            ("",                     ""),
            ("user <userid>",        "Fetch user profile"),
            ("game <universeid>",    "Fetch game + visit stats"),
            ("friends <userid>",     "Get friends list"),
            ("followers <userid>",   "Get follower count & top followers"),
            ("likes <universeid>",   "Get game vote stats"),
            ("search user <kw>",     "Search users by keyword"),
            ("search game <kw>",     "Search games by keyword"),
            ("presence <userid>",    "Get user online status"),
            ("avatar <userid>",      "Get user avatar details"),
            ("servers <placeid>",    "List active game servers"),
            ("badges <universeid>",  "List badges in a game"),
            ("catalog <keyword>",    "Search the avatar catalog"),
            ("robux",                "Show your Robux balance (needs cookie)"),
            ("",                     ""),
            ("save user <id>",       "Save user to current DB"),
            ("save game <id>",       "Save game to current DB"),
            ("history",              "Show command history"),
            ("clear",                "Clear the screen"),
            ("exit",                 "Exit the session"),
        ]
        for cmd, desc in cmds:
            if not cmd:
                print()
                continue
            print(f"  {_c(cmd.ljust(24), C.YELLOW)}  {_c(desc, C.WHITE)}")
        print()

    def _cmd_exit(self, args):
        self._ok("Goodbye!")
        if self.db:
            self.db.close()
        self._running = False
        sys.exit(0)

    def _cmd_clear(self, args):
        os.system("cls" if os.name == "nt" else "clear")

    def _cmd_start(self, args):
        if not args:
            self._err("Usage: start <userid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("User ID must be an integer.")
            return
        self._info(f"Fetching user {uid}...")
        user = self.client.users.get_user(uid)
        self.session_user_id = user.id
        self.session_username = user.name
        self._section("Session Started")
        print(f"  {user}")
        presence = self.client.presence.get_presence(uid)
        self._info(f"Status: {presence.status}")
        if self.db:
            self.db.save_user(user)
            self.db.set("session_user_id", uid)

    def _cmd_cookie(self, args):
        if not args:
            self._err("Usage: cookie <.ROBLOSECURITY token>")
            return
        self.client.set_cookie(args[0])
        self._ok("Cookie set. Authenticated requests now enabled.")

    def _cmd_whoami(self, args):
        if not self.session_user_id:
            self._warn("No session started. Use: start <userid>")
            return
        self._info(f"@{self.session_username} (ID: {self.session_user_id})")
        if self.client.is_authenticated:
            self._ok("Authenticated (cookie set)")
        else:
            self._warn("Unauthenticated (no cookie)")

    def _cmd_newdb(self, args):
        if not args:
            self._err("Usage: newdb <name>")
            return
        name = args[0]
        try:
            self.db = SessionDatabase.create(name)
            self._ok(f"Created database '{name}' → {self.db.path}")
        except DatabaseError as e:
            self._err(str(e))

    def _cmd_loaddb(self, args):
        if not args:
            self._err("Usage: loaddb <name>")
            return
        name = args[0]
        try:
            self.db = SessionDatabase.load(name)
            s = self.db.stats()
            self._ok(f"Loaded '{name}' — {s['users']} users, {s['games']} games, {s['log_entries']} log entries")
        except DatabaseError as e:
            self._err(str(e))

    def _cmd_listdb(self, args):
        dbs = SessionDatabase.list_databases(".")
        if not dbs:
            self._warn("No databases found in current directory.")
            return
        self._section("Local Databases")
        for db_name in dbs:
            active = _c(" ← active", C.GREEN) if (self.db and self.db.name == db_name) else ""
            print(f"  {_c('•', C.CYAN)} {db_name}{active}")

    def _cmd_user(self, args):
        if not args:
            self._err("Usage: user <userid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("User ID must be an integer.")
            return
        self._info(f"Fetching user {uid}...")
        user = self.client.users.get_user(uid)
        self._section("User Profile")
        print(f"  {user}")
        if user.description:
            desc = textwrap.shorten(user.description, width=60, placeholder="...")
            self._info(f"Bio: {desc}")
        friends_count = self.client.friends.get_friend_count(uid)
        followers_count = self.client.friends.get_follower_count(uid)
        self._info(f"Friends: {friends_count:,}  |  Followers: {followers_count:,}")

    def _cmd_game(self, args):
        if not args:
            self._err("Usage: game <universeid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("Universe ID must be an integer.")
            return
        self._info(f"Fetching game {uid}...")
        game = self.client.games.get_game(uid)
        self._section("Game Info")
        print(f"  {game}")
        votes_list = self.client.games.get_votes([uid])
        if votes_list:
            self._info(f"Votes: {votes_list[0]}")
        if self.db:
            self.db.save_game(game)
            self._ok("Saved to database.")

    def _cmd_friends(self, args):
        if not args:
            uid = self.session_user_id
            if not uid:
                self._err("Usage: friends <userid>  (or start a session first)")
                return
        else:
            try:
                uid = int(args[0])
            except ValueError:
                self._err("User ID must be an integer.")
                return
        self._info(f"Fetching friends for user {uid}...")
        friends = self.client.friends.get_friends(uid)
        count = len(friends)
        self._section(f"Friends ({count})")
        if not friends:
            self._warn("No friends found.")
            return
        for i, f in enumerate(friends[:20], 1):
            print(f"  {i:>3}. {f}")
        if count > 20:
            self._info(f"... and {count - 20} more.")

    def _cmd_followers(self, args):
        if not args:
            self._err("Usage: followers <userid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("User ID must be an integer.")
            return
        count = self.client.friends.get_follower_count(uid)
        following_count = self.client.friends.get_following_count(uid)
        page = self.client.friends.get_followers(uid, limit=10)
        self._section(f"Followers ({count:,})")
        self._info(f"Following: {following_count:,}")
        for f in page.data[:10]:
            print(f"  {f}")

    def _cmd_likes(self, args):
        if not args:
            self._err("Usage: likes <universeid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("Universe ID must be an integer.")
            return
        self._info(f"Fetching votes for universe {uid}...")
        votes = self.client.games.get_votes([uid])
        if not votes:
            self._warn("No vote data found.")
            return
        v = votes[0]
        self._section("Game Votes")
        print(f"  {v}")
        fav_count = self.client.games.get_favorite_count(uid)
        self._info(f"Favourites: {fav_count:,}")

    def _cmd_search(self, args):
        if len(args) < 2:
            self._err("Usage: search user <keyword>  |  search game <keyword>")
            return
        kind = args[0].lower()
        keyword = args[1]
        if kind == "user":
            self._info(f"Searching users: '{keyword}'...")
            page = self.client.users.search_users(keyword, limit=10)
            self._section(f"User Search: '{keyword}'")
            for u in page.data:
                print(f"  {u}")
        elif kind == "game":
            self._info(f"Searching games: '{keyword}'...")
            page = self.client.games.search_games(keyword, limit=10)
            self._section(f"Game Search: '{keyword}'")
            for g in page.data:
                print(f"  🎮 {g.name} [ID: {g.id}] — {g.visits:,} visits")
        else:
            self._err("Type must be 'user' or 'game'.")

    def _cmd_presence(self, args):
        if not args:
            self._err("Usage: presence <userid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("User ID must be an integer.")
            return
        p = self.client.presence.get_presence(uid)
        self._section("User Presence")
        self._info(f"User ID: {uid}")
        self._info(f"Status : {p.status}")
        if p.last_location:
            self._info(f"Location: {p.last_location}")
        if p.last_online:
            self._info(f"Last Online: {p.last_online}")

    def _cmd_avatar(self, args):
        if not args:
            self._err("Usage: avatar <userid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("User ID must be an integer.")
            return
        av = self.client.avatar.get_user_avatar(uid)
        self._section("Avatar Info")
        self._info(f"Type  : {av.avatar_type}")
        self._info(f"Assets: {len(av.assets)} equipped items")
        self._info(f"Scales: {av.scales}")
        thumb = self.client.thumbnails.get_avatar_url(uid)
        if thumb:
            self._info(f"Thumbnail: {thumb}")

    def _cmd_servers(self, args):
        if not args:
            self._err("Usage: servers <placeid>")
            return
        try:
            pid = int(args[0])
        except ValueError:
            self._err("Place ID must be an integer.")
            return
        page = self.client.games.get_servers(pid, limit=10)
        self._section("Active Servers")
        if not page.data:
            self._warn("No active servers found.")
            return
        for s in page.data:
            print(f"  {s}")

    def _cmd_badges(self, args):
        if not args:
            self._err("Usage: badges <universeid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("Universe ID must be an integer.")
            return
        page = self.client.badges.get_universe_badges(uid, limit=15)
        self._section("Game Badges")
        if not page.data:
            self._warn("No badges found.")
            return
        for b in page.data:
            print(f"  {b}")
            print()

    def _cmd_catalog(self, args):
        if not args:
            self._err("Usage: catalog <keyword>")
            return
        keyword = " ".join(args)
        self._info(f"Searching catalog: '{keyword}'...")
        page = self.client.catalog.search(keyword=keyword, limit=10)
        self._section(f"Catalog: '{keyword}'")
        if not page.data:
            self._warn("No items found.")
            return
        for item in page.data:
            price = f"{item.price}R$" if item.price else "Free/Off Sale"
            print(f"  🛍  [{item.id}] {item.name} — {price}")

    def _cmd_robux(self, args):
        if not self.client.is_authenticated:
            self._err("Cookie required. Use: cookie <.ROBLOSECURITY>")
            return
        balance = self.client.robux()
        self._section("Robux Balance")
        print(f"  {_c(f'💎 {balance:,} Robux', C.GREEN + C.BOLD)}")

    def _cmd_save(self, args):
        if not self.db:
            self._err("No database loaded. Use: newdb <name> or loaddb <name>")
            return
        if len(args) < 2:
            self._err("Usage: save user <userid>  |  save game <universeid>")
            return
        kind = args[0].lower()
        try:
            obj_id = int(args[1])
        except ValueError:
            self._err("ID must be an integer.")
            return
        if kind == "user":
            user = self.client.users.get_user(obj_id)
            self.db.save_user(user)
            self._ok(f"Saved user {user.name} (ID: {user.id}) to '{self.db.name}'")
        elif kind == "game":
            game = self.client.games.get_game(obj_id)
            self.db.save_game(game)
            self._ok(f"Saved game '{game.name}' (ID: {game.id}) to '{self.db.name}'")
        else:
            self._err("Type must be 'user' or 'game'.")

    def _cmd_history(self, args):
        self._section("Command History")
        if not self._history:
            self._warn("No commands yet.")
            return
        for i, cmd in enumerate(self._history[-20:], 1):
            print(f"  {_c(str(i).rjust(3), C.GRAY)}  {cmd}")


def _cli_entry():
    """Console script entry point: `roboat` command after pip install."""
    RoboatSession().run()


# ── Additional commands injected into RoboatSession ───────────────────── #

def _patch_session():
    """Add new command handlers to RoboatSession."""

    def _cmd_trades(self, args):
        trade_type = args[0].capitalize() if args else "Inbound"
        self._c.require_auth("trades")
        page = self._c.trades.get_trades(trade_type, limit=10)
        self._section(f"Trades — {trade_type} ({len(page.data)})")
        if not page.data:
            self._warn("No trades found.")
            return
        for t in page.data:
            print(f"  {t}")

    def _cmd_inventory(self, args):
        if not args:
            self._err("Usage: inventory <userid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("User ID must be an integer.")
            return
        self._info(f"Fetching collectibles for user {uid}...")
        page = self._c.inventory.get_collectibles(uid, limit=25)
        self._section(f"Inventory (Limiteds) — User {uid}")
        if not page.data:
            self._warn("No collectibles found (or inventory is private).")
            return
        total_rap = sum(a.recent_average_price for a in page.data)
        for asset in page.data:
            print(f"  {asset}")
        self._info(f"Shown RAP total: {total_rap:,}R$")

    def _cmd_rap(self, args):
        if not args:
            uid = self.session_user_id
            if not uid:
                self._err("Usage: rap <userid>  (or start a session first)")
                return
        else:
            try:
                uid = int(args[0])
            except ValueError:
                self._err("User ID must be an integer.")
                return
        self._info(f"Calculating RAP for user {uid} (may take a moment)...")
        total = self._c.inventory.get_total_rap(uid)
        self._section("Total RAP")
        print(f"  {_c(f'📈 {total:,}R$ RAP', C.GREEN + C.BOLD)}")

    def _cmd_messages(self, args):
        self._c.require_auth("messages")
        unread = self._c.messages.get_unread_count()
        page = self._c.messages.get_messages(page_size=10)
        self._section(f"Messages ({unread} unread)")
        if not page.data:
            self._warn("No messages.")
            return
        for m in page.data:
            print(f"  {m}")

    def _cmd_owns(self, args):
        if len(args) < 2:
            self._err("Usage: owns <userid> <assetid>")
            return
        try:
            uid, aid = int(args[0]), int(args[1])
        except ValueError:
            self._err("IDs must be integers.")
            return
        result = self._c.inventory.owns_asset(uid, aid)
        if result:
            self._ok(f"User {uid} owns asset {aid}")
        else:
            self._warn(f"User {uid} does NOT own asset {aid}")

    def _cmd_universe(self, args):
        if not args:
            self._err("Usage: universe <universeid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("Universe ID must be an integer.")
            return
        u = self._c.develop.get_universe(uid)
        self._section("Universe Info")
        print(f"  {u}")

    def _cmd_cache(self, args):
        stats = self._c.cache_stats()
        self._section("Cache Stats")
        self._info(f"Alive entries : {stats['alive']}")
        self._info(f"Total entries : {stats['total']}")
        self._info(f"Max size      : {stats['max_size']}")
        if args and args[0] == "clear":
            self._c.invalidate_cache()
            self._ok("Cache cleared.")

    def _cmd_watch(self, args):
        if len(args) < 1:
            self._err("Usage: watch <universeid>")
            return
        try:
            uid = int(args[0])
        except ValueError:
            self._err("Universe ID must be an integer.")
            return
        self._c.events.track_game(uid)

        @self._c.events.on("visit_milestone")
        def _on_milestone(game, count):
            self._warn(f"🎉 {game.name} hit {count:,} visits!")

        self._c.events.start(interval=60)
        self._ok(f"Watching universe {uid} for visit milestones. Events fire every 60s.")

    # Inject into RoboatSession
    RoboatSession._cmd_trades    = _cmd_trades
    RoboatSession._cmd_inventory = _cmd_inventory
    RoboatSession._cmd_rap       = _cmd_rap
    RoboatSession._cmd_messages  = _cmd_messages
    RoboatSession._cmd_owns      = _cmd_owns
    RoboatSession._cmd_universe  = _cmd_universe
    RoboatSession._cmd_cache     = _cmd_cache
    RoboatSession._cmd_watch     = _cmd_watch

    # Patch dispatch table
    _orig_dispatch = RoboatSession._dispatch
    def _new_dispatch(self, raw):
        parts = raw.split(None, 2)
        cmd = parts[0].lower()
        extra = {
            "trades":    self._cmd_trades,
            "inventory": self._cmd_inventory,
            "rap":       self._cmd_rap,
            "messages":  self._cmd_messages,
            "owns":      self._cmd_owns,
            "universe":  self._cmd_universe,
            "cache":     self._cmd_cache,
            "watch":     self._cmd_watch,
        }
        handler = extra.get(cmd)
        if handler:
            try:
                handler(parts[1:])
            except Exception as e:
                self._err(str(e))
        else:
            _orig_dispatch(self, raw)

    RoboatSession._dispatch = _new_dispatch

_patch_session()
