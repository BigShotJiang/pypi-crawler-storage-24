"""
roboat v2.0.0 — The best Roblox API wrapper for Python.

Quick start::

    from roboat import RoboatClient, ClientBuilder
    from roboat import AsyncRoboatClient
    from roboat import RoboatCloudClient
    from roboat import RoboatSession
    from roboat.analytics import Analytics

    # Sync client
    client = (
        ClientBuilder()
        .set_cookie("ROBLOSECURITY")
        .set_cache_ttl(60)
        .set_rate_limit(10)
        .build()
    )

    # Async client
    async with AsyncRoboatClient(cookie="...") as c:
        user = await c.users.get_user(156)

    # Open Cloud (API key)
    cloud = RoboatCloudClient(api_key="roblox-KEY-xxx")
    cloud.datastores.set(123, "Store", "key", {"coins": 500})

    # Terminal
    python -m roboat
"""

from .client       import RoboatClient, ClientBuilder
from .async_client import AsyncRoboatClient
from .opencloud    import RoboatCloudClient
from .session      import RoboatSession
from .database     import SessionDatabase
from .events       import EventPoller
from .analytics    import Analytics
from .utils        import TokenBucket, TTLCache, Paginator, retry, cached

from .models import (
    User, UserPresence,
    Game, GameVotes, GameServer,
    CatalogItem, ResaleData,
    Group, GroupRole,
    Friend,
    Badge,
    Avatar, AvatarAsset, AvatarColors,
    RobuxBalance, Transaction,
    Page,
)
from .trades    import Trade, TradeOffer, TradeAsset
from .messages  import Message, ChatConversation
from .inventory import InventoryAsset
from .develop   import Universe, Place, DataStore
from .groups    import GroupShout, GroupPayout, GroupJoinRequest, GroupRelationship

from .exceptions import (
    RobloxAPIError,
    NotAuthenticatedError,
    UserNotFoundError,
    GameNotFoundError,
    ItemNotFoundError,
    GroupNotFoundError,
    BadgeNotFoundError,
    RateLimitedError,
    InvalidCookieError,
    InsufficientFundsError,
    DatabaseError,
)

__version__ = "2.0.0"
__author__  = "roboat contributors"
__license__ = "MIT"
