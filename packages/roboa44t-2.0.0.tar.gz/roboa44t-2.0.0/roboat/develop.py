"""
roboat.develop
~~~~~~~~~~~~~~~~~
Develop / Publishing API — develop.roblox.com
Manage universes, places, data stores, and developer stats.
All write operations require authentication.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional
from .models import Page


@dataclass
class Universe:
    id: int
    name: str
    description: str
    created: str
    updated: str
    root_place_id: int
    is_archived: bool
    is_active: bool
    privacy_type: str
    creator_type: str
    creator_id: int
    creator_name: str

    @classmethod
    def from_dict(cls, d: dict) -> "Universe":
        creator = d.get("creator", {})
        return cls(
            id=d.get("id", 0),
            name=d.get("name", ""),
            description=d.get("description", ""),
            created=d.get("created", ""),
            updated=d.get("updated", ""),
            root_place_id=d.get("rootPlaceId", 0),
            is_archived=d.get("isArchived", False),
            is_active=d.get("isActive", True),
            privacy_type=d.get("privacyType", ""),
            creator_type=creator.get("type", ""),
            creator_id=creator.get("id", 0),
            creator_name=creator.get("name", ""),
        )

    def __str__(self) -> str:
        status = "🟢 Active" if self.is_active else "🔴 Inactive"
        arch = " [Archived]" if self.is_archived else ""
        return (
            f"🔧 {self.name}{arch} [ID: {self.id}]\n"
            f"   Creator : {self.creator_name}\n"
            f"   Status  : {status}\n"
            f"   Privacy : {self.privacy_type}"
        )


@dataclass
class Place:
    id: int
    universe_id: int
    name: str
    description: str
    max_players: int
    server_fill: str
    is_root_place: bool

    @classmethod
    def from_dict(cls, d: dict) -> "Place":
        return cls(
            id=d.get("id", 0),
            universe_id=d.get("universeId", 0),
            name=d.get("name", ""),
            description=d.get("description", ""),
            max_players=d.get("maxPlayerCount", 0),
            server_fill=d.get("socialSlotType", ""),
            is_root_place=d.get("isRootPlace", False),
        )


@dataclass
class DataStore:
    name: str
    created: str

    @classmethod
    def from_dict(cls, d: dict) -> "DataStore":
        return cls(name=d.get("name", ""), created=d.get("createdTime", ""))


class DevelopAPI:
    BASE   = "https://develop.roblox.com/v1"
    CLOUD  = "https://apis.roblox.com/datastores/v1"
    OPENCLOUD = "https://apis.roblox.com/cloud/v2"

    def __init__(self, client):
        self._c = client

    # ── Universes ─────────────────────────────────────────────────────

    def get_universes_by_user(self, user_id: int, is_archived: bool = False,
                               limit: int = 50,
                               cursor: Optional[str] = None) -> Page:
        """Get all universes created by a user. Requires auth for private ones."""
        params = {"isArchived": is_archived, "limit": limit}
        if cursor:
            params["cursor"] = cursor
        data = self._c._get(
            f"{self.BASE}/user/universes",
            params=params,
        )
        universes = [Universe.from_dict(u) for u in data.get("data", [])]
        return Page(data=universes, next_cursor=data.get("nextPageCursor"))

    def get_universes_by_group(self, group_id: int, is_archived: bool = False,
                                limit: int = 50,
                                cursor: Optional[str] = None) -> Page:
        """Get all universes created by a group."""
        params = {"isArchived": is_archived, "limit": limit}
        if cursor:
            params["cursor"] = cursor
        data = self._c._get(
            f"{self.BASE}/groups/{group_id}/universes",
            params=params,
        )
        universes = [Universe.from_dict(u) for u in data.get("data", [])]
        return Page(data=universes, next_cursor=data.get("nextPageCursor"))

    def get_universe(self, universe_id: int) -> Universe:
        """Get details of a specific universe."""
        data = self._c._get(f"{self.BASE}/universes/{universe_id}")
        return Universe.from_dict(data)

    def get_universe_settings(self, universe_id: int) -> dict:
        """Get universe configuration settings. Requires auth + ownership."""
        self._c.require_auth("get_universe_settings")
        return self._c._get(f"{self.BASE}/universes/{universe_id}/configuration")

    def update_universe_settings(self, universe_id: int, **settings) -> dict:
        """
        Update universe settings. Requires auth + ownership.

        Common settings:
            name, description, allowPrivateServers, privateServerPrice,
            isForSale, price, universeAvatarType, universeScaleType,
            universeAnimationType, universeCollisionType, universeBodyType,
            universeJointPositioningType, isArchived, isFriendsOnly,
            playableDevices (list: "Computer","Phone","Tablet","Console")
        """
        self._c.require_auth("update_universe_settings")
        return self._c._patch(
            f"{self.BASE}/universes/{universe_id}/configuration",
            json=settings,
        )

    def activate_universe(self, universe_id: int) -> None:
        """Make a universe publicly accessible. Requires auth."""
        self._c.require_auth("activate_universe")
        self._c._post(f"{self.BASE}/universes/{universe_id}/activate")

    def deactivate_universe(self, universe_id: int) -> None:
        """Take a universe offline. Requires auth."""
        self._c.require_auth("deactivate_universe")
        self._c._post(f"{self.BASE}/universes/{universe_id}/deactivate")

    # ── Places ────────────────────────────────────────────────────────

    def get_places(self, universe_id: int, limit: int = 10,
                   cursor: Optional[str] = None) -> Page:
        """List all places in a universe."""
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        data = self._c._get(
            f"{self.BASE}/universes/{universe_id}/places",
            params=params,
        )
        places = [Place.from_dict(p) for p in data.get("data", [])]
        return Page(data=places, next_cursor=data.get("nextPageCursor"))

    def update_place(self, place_id: int, universe_id: int,
                     name: Optional[str] = None,
                     description: Optional[str] = None,
                     max_players: Optional[int] = None) -> dict:
        """Update place settings. Requires auth + ownership."""
        self._c.require_auth("update_place")
        payload = {}
        if name is not None:        payload["name"] = name
        if description is not None: payload["description"] = description
        if max_players is not None: payload["maxPlayerCount"] = max_players
        return self._c._patch(
            f"{self.BASE}/universes/{universe_id}/places/{place_id}/configuration",
            json=payload,
        )

    # ── Game stats ─────────────────────────────────────────────────────

    def get_game_stats(self, universe_id: int,
                       stat_type: str = "Visits",
                       granularity: str = "Daily",
                       start_time: Optional[str] = None,
                       end_time: Optional[str] = None) -> List[dict]:
        """
        Get time-series stats for a universe. Requires auth + ownership.

        stat_type: "Visits", "Revenue", "Favorites", "ArPU", "ArPDAU",
                   "PlayerHours", "ConcurrentPlayers", "NewUsers",
                   "ChatCount", "AverageVisitLength", "UniqueVisitors"
        granularity: "Hourly", "Daily", "Monthly"
        start_time/end_time: ISO 8601 strings e.g. "2024-01-01T00:00:00Z"

        Returns:
            List of {value, date} dicts.
        """
        self._c.require_auth("get_game_stats")
        params = {"type": stat_type, "granularity": granularity}
        if start_time: params["startTime"] = start_time
        if end_time:   params["endTime"] = end_time
        data = self._c._get(
            f"{self.BASE}/universes/{universe_id}/stats",
            params=params,
        )
        return data.get("data", [])

    # ── DataStores (Open Cloud) ────────────────────────────────────────

    def list_datastores(self, universe_id: int, api_key: str,
                        prefix: str = "", limit: int = 100) -> List[DataStore]:
        """
        List DataStores in a universe via Open Cloud.

        Args:
            api_key: Your Roblox Open Cloud API key (not a cookie).
            prefix: Filter by name prefix.

        Returns:
            List of DataStore objects.
        """
        resp = self._c._get(
            f"{self.CLOUD}/universes/{universe_id}/standard-datastores",
            params={"prefix": prefix, "limit": limit},
            headers={"x-api-key": api_key},
        )
        return [DataStore.from_dict(d) for d in resp.get("datastores", [])]

    def get_datastore_entry(self, universe_id: int, datastore_name: str,
                             entry_key: str, api_key: str,
                             scope: str = "global") -> dict:
        """
        Get a DataStore entry value via Open Cloud.

        Returns:
            dict with 'value' and metadata.
        """
        return self._c._get(
            f"{self.CLOUD}/universes/{universe_id}/standard-datastores/datastore/entries/entry",
            params={
                "datastoreName": datastore_name,
                "entryKey": entry_key,
                "scope": scope,
            },
            headers={"x-api-key": api_key},
        )

    def set_datastore_entry(self, universe_id: int, datastore_name: str,
                             entry_key: str, value: dict,
                             api_key: str, scope: str = "global") -> dict:
        """
        Set a DataStore entry value via Open Cloud. Requires API key.
        """
        import json
        return self._c._post(
            f"{self.CLOUD}/universes/{universe_id}/standard-datastores/datastore/entries/entry",
            params={
                "datastoreName": datastore_name,
                "entryKey": entry_key,
                "scope": scope,
            },
            headers={
                "x-api-key": api_key,
                "Content-Type": "application/json",
            },
            data=json.dumps(value),
        )
