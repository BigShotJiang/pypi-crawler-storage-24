"""Window management system."""
