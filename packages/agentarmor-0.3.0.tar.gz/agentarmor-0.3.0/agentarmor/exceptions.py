class BudgetExhausted(Exception):
    """Raised when the dollar budget is exceeded."""
    pass

class RateLimitExceeded(Exception):
    """Raised when the call rate exceeds the configured limit."""
    pass

class InjectionDetected(Exception):
    """Raised when a prompt injection attack is detected."""
    pass

class FilterViolation(Exception):
    """Raised when output contains banned content (block mode)."""
    pass

class HookError(Exception):
    """Raised when a user-defined hook raises an unhandled exception."""
    pass

class PatchError(Exception):
    """Raised when SDK patching fails (e.g., incompatible SDK version)."""
    pass

class ContextOverflow(Exception):
    """Raised when the message payload is likely to exceed the model's context window."""
    pass
