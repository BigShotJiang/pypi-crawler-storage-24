"""
Scheduler example: create a schedule using the Studio client.

Usage:
    export LYZR_API_KEY="sk-..."
    export LYZR_USER_ID="user_..."
    export LYZR_AGENT_ID="agent_..."
    export LYZR_ENV="dev"  # optional, defaults to dev
    python examples/14_scheduler_example.py
"""

import os
from lyzr import Studio


def create_agent_schedule(
    user_id: str,
    agent_id: str,
    cron_expression: str = "*/15 * * * *",
    message: str = "Scheduled run from SDK example",
    env: str = "dev",
):
    """Create and return a schedule for an agent."""
    with Studio(env=env) as studio:
        return studio.create_schedule(
            user_id=user_id,
            agent_id=agent_id,
            cron_expression=cron_expression,
            message=message,
        )


def run_example():
    """Read env vars, create a schedule, and print the result."""
    user_id = os.getenv("LYZR_USER_ID")
    agent_id = os.getenv("LYZR_AGENT_ID")
    env = os.getenv("LYZR_ENV", "dev")

    if not user_id or not agent_id:
        raise ValueError(
            "Missing required env vars. Set LYZR_USER_ID and LYZR_AGENT_ID to run this example."
        )

    schedule = create_agent_schedule(user_id=user_id, agent_id=agent_id, env=env)
    print("Schedule created successfully")
    print(f"id={schedule.id}")
    print(f"agent_id={schedule.agent_id}")
    print(f"user_id={schedule.user_id}")
    print(f"cron_expression={schedule.cron_expression}")
    print(f"is_active={schedule.is_active}")


if __name__ == "__main__":
    run_example()
