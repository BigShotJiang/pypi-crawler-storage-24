"""
Test 31: Cognis Module (Async)
Tests CognisModule async CRUD, context, messages, and summary operations with mocked HTTP.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from lyzr.http import HTTPClient, AsyncHTTPClient
from lyzr.urls import ServiceURLs
from lyzr.cognis.module import CognisModule
from lyzr.cognis.models import (
    CognisMessage,
    CognisMemoryRecord,
    CognisSearchResult,
    CognisMemoryList,
)


# ── Sample API Responses ──────────────────────────────────────────

SAMPLE_MEMORY = {
    "id": "mem_abc123",
    "memory_id": "mem_abc123",
    "content": "User likes hiking",
    "owner_id": "owner_1",
    "agent_id": "agent_1",
    "session_id": "sess_1",
    "status": "CURRENT",
    "is_current": True,
    "version": 1,
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": "2026-01-01T00:00:00Z",
}

SAMPLE_SEARCH_RESULT = {
    "id": "mem_abc123",
    "content": "User likes hiking",
    "score": 0.95,
    "owner_id": "owner_1",
}

SAMPLE_ADD_RESPONSE = {
    "success": True,
    "session_id": "sess_1",
    "messages_stored": 2,
}

SAMPLE_CONTEXT_RESPONSE = {
    "success": True,
    "has_long_term_memory": True,
    "short_term_count": 5,
    "long_term_count": 2,
    "context": [
        {"role": "system", "content": "Long-term memories: User likes hiking"},
        {"role": "user", "content": "What do I enjoy?"},
    ],
}

SAMPLE_MESSAGES_RESPONSE = {
    "success": True,
    "messages": [
        {"role": "user", "content": "Hello"},
        {"role": "assistant", "content": "Hi!"},
    ],
    "count": 2,
}

SAMPLE_SUMMARY_RESPONSE = {
    "success": True,
    "summary_id": "sum_123",
}

SAMPLE_CURRENT_SUMMARY_RESPONSE = {
    "success": True,
    "summary": {"summary_id": "sum_123", "content": "User likes hiking"},
}

SAMPLE_SEARCH_SUMMARIES_RESPONSE = {
    "success": True,
    "results": [{"summary_id": "sum_123", "content": "hiking", "score": 0.9}],
    "count": 1,
}


# ── Fixtures ──────────────────────────────────────────────────────

@pytest.fixture
def mock_http():
    """Create mock sync HTTP client."""
    http = MagicMock(spec=HTTPClient)
    http.api_key = "sk-test"
    http.base_url = "https://memory.studio.lyzr.ai"
    http.timeout = 30
    return http


@pytest.fixture
def mock_async_http():
    """Create mock async HTTP client."""
    async_http = AsyncMock(spec=AsyncHTTPClient)
    async_http.api_key = "sk-test"
    async_http.base_url = "https://memory.studio.lyzr.ai"
    async_http.timeout = 30
    return async_http


@pytest.fixture
def env_config():
    return ServiceURLs(
        agent_api="https://agent-prod.studio.lyzr.ai",
        rag_api="https://rag-prod.studio.lyzr.ai",
        rai_api="https://srs-prod.studio.lyzr.ai",
        memory_api="https://memory.studio.lyzr.ai",
    )


@pytest.fixture
def cognis_module(mock_http, mock_async_http, env_config):
    """Create CognisModule with mocked HTTP clients."""
    with patch("lyzr.http.HTTPClient", return_value=mock_http):
        module = CognisModule(api_key="sk-test", env_config=env_config)
    module._http = mock_http
    module._async_http = mock_async_http
    return module


# ── Async CRUD Tests ──────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisAsyncAdd:
    """Tests for aadd()."""

    @pytest.mark.asyncio
    async def test_aadd(self, cognis_module, mock_async_http):
        """aadd() posts messages asynchronously."""
        mock_async_http.post.return_value = SAMPLE_ADD_RESPONSE

        result = await cognis_module.aadd(
            messages=[
                CognisMessage(role="user", content="Hello"),
                CognisMessage(role="assistant", content="Hi!"),
            ],
            owner_id="owner_1",
            session_id="sess_1",
        )

        assert result["success"] is True
        body = mock_async_http.post.call_args[1]["json"]
        assert body["owner_id"] == "owner_1"
        assert body["session_id"] == "sess_1"
        assert len(body["messages"]) == 2

    @pytest.mark.asyncio
    async def test_aadd_agent_session(self, cognis_module, mock_async_http):
        """aadd() with agent_id + session_id."""
        mock_async_http.post.return_value = SAMPLE_ADD_RESPONSE

        await cognis_module.aadd(
            messages=[{"role": "user", "content": "test"}],
            agent_id="agent_1",
            session_id="sess_1",
        )

        body = mock_async_http.post.call_args[1]["json"]
        assert "owner_id" not in body
        assert body["agent_id"] == "agent_1"

    @pytest.mark.asyncio
    async def test_aadd_validation(self, cognis_module):
        """aadd() raises ValueError without IDs."""
        with pytest.raises(ValueError, match="At least one"):
            await cognis_module.aadd(
                messages=[{"role": "user", "content": "test"}],
            )


@pytest.mark.cognis
class TestCognisAsyncSearch:
    """Tests for asearch()."""

    @pytest.mark.asyncio
    async def test_asearch(self, cognis_module, mock_async_http):
        """asearch() returns search results."""
        mock_async_http.post.return_value = {"results": [SAMPLE_SEARCH_RESULT]}

        results = await cognis_module.asearch(query="hiking", owner_id="owner_1")

        assert len(results) == 1
        assert isinstance(results[0], CognisSearchResult)
        assert results[0].score == 0.95

    @pytest.mark.asyncio
    async def test_asearch_with_params(self, cognis_module, mock_async_http):
        """asearch() passes limit and cross_session."""
        mock_async_http.post.return_value = {"results": []}

        await cognis_module.asearch(
            query="test",
            owner_id="owner_1",
            limit=5,
            cross_session=True,
        )

        body = mock_async_http.post.call_args[1]["json"]
        assert body["limit"] == 5
        assert body["cross_session"] is True

    @pytest.mark.asyncio
    async def test_asearch_agent_session(self, cognis_module, mock_async_http):
        """asearch() with agent_id + session_id."""
        mock_async_http.post.return_value = {"results": [SAMPLE_SEARCH_RESULT]}

        results = await cognis_module.asearch(
            query="test",
            agent_id="agent_1",
            session_id="sess_1",
        )

        body = mock_async_http.post.call_args[1]["json"]
        assert "owner_id" not in body
        assert body["agent_id"] == "agent_1"
        assert len(results) == 1


@pytest.mark.cognis
class TestCognisAsyncGet:
    """Tests for aget() and aget_memory()."""

    @pytest.mark.asyncio
    async def test_aget(self, cognis_module, mock_async_http):
        """aget() returns CognisMemoryList."""
        mock_async_http.get.return_value = {"memories": [SAMPLE_MEMORY]}

        memories = await cognis_module.aget(owner_id="owner_1")

        assert isinstance(memories, CognisMemoryList)
        assert len(memories) == 1
        assert memories[0].content == "User likes hiking"

    @pytest.mark.asyncio
    async def test_aget_with_params(self, cognis_module, mock_async_http):
        """aget() passes limit, offset, include_historical."""
        mock_async_http.get.return_value = {"memories": []}

        await cognis_module.aget(
            owner_id="owner_1",
            limit=10,
            offset=5,
            include_historical=True,
            cross_session=True,
        )

        params = mock_async_http.get.call_args[1]["params"]
        assert params["limit"] == 10
        assert params["offset"] == 5
        assert params["include_historical"] is True
        assert params["cross_session"] is True

    @pytest.mark.asyncio
    async def test_aget_memory(self, cognis_module, mock_async_http):
        """aget_memory() returns single record."""
        mock_async_http.get.return_value = SAMPLE_MEMORY

        memory = await cognis_module.aget_memory(
            memory_id="mem_abc123",
            owner_id="owner_1",
        )

        assert isinstance(memory, CognisMemoryRecord)
        assert memory.id == "mem_abc123"


@pytest.mark.cognis
class TestCognisAsyncUpdate:
    """Tests for aupdate()."""

    @pytest.mark.asyncio
    async def test_aupdate(self, cognis_module, mock_async_http):
        """aupdate() sends PATCH then fetches updated record."""
        updated = {**SAMPLE_MEMORY, "content": "Updated content"}
        mock_async_http.patch.return_value = {"success": True}
        mock_async_http.get.return_value = {"memory": updated}

        result = await cognis_module.aupdate(
            memory_id="mem_abc123",
            content="Updated content",
            owner_id="owner_1",
        )

        assert isinstance(result, CognisMemoryRecord)
        assert result.content == "Updated content"
        body = mock_async_http.patch.call_args[1]["json"]
        assert body["content"] == "Updated content"
        assert body["owner_id"] == "owner_1"


@pytest.mark.cognis
class TestCognisAsyncDelete:
    """Tests for adelete() and adelete_session()."""

    @pytest.mark.asyncio
    async def test_adelete(self, cognis_module, mock_async_http):
        """adelete() calls DELETE."""
        mock_async_http.delete.return_value = True

        result = await cognis_module.adelete(
            memory_id="mem_abc123",
            owner_id="owner_1",
        )

        assert result is True

    @pytest.mark.asyncio
    async def test_adelete_session(self, cognis_module, mock_async_http):
        """adelete_session() calls DELETE with body."""
        mock_async_http.delete.return_value = True

        result = await cognis_module.adelete_session(
            owner_id="owner_1",
            session_id="sess_1",
            agent_id="agent_1",
        )

        assert result is True
        body = mock_async_http.delete.call_args[1]["json_body"]
        assert body["owner_id"] == "owner_1"
        assert body["session_id"] == "sess_1"
        assert body["agent_id"] == "agent_1"


# ── Async Context & Messages Tests ───────────────────────────────

@pytest.mark.cognis
class TestCognisAsyncContext:
    """Tests for acontext()."""

    @pytest.mark.asyncio
    async def test_acontext(self, cognis_module, mock_async_http):
        """acontext() returns context dict."""
        mock_async_http.post.return_value = SAMPLE_CONTEXT_RESPONSE

        ctx = await cognis_module.acontext(
            current_messages=[CognisMessage(role="user", content="What do I enjoy?")],
            owner_id="owner_1",
            session_id="sess_1",
        )

        assert ctx["success"] is True
        assert ctx["has_long_term_memory"] is True
        assert ctx["long_term_count"] == 2

    @pytest.mark.asyncio
    async def test_acontext_with_params(self, cognis_module, mock_async_http):
        """acontext() passes all parameters."""
        mock_async_http.post.return_value = SAMPLE_CONTEXT_RESPONSE

        await cognis_module.acontext(
            current_messages=[{"role": "user", "content": "test"}],
            owner_id="owner_1",
            session_id="sess_1",
            agent_id="agent_1",
            max_short_term_messages=50,
            enable_long_term_memory=False,
            cross_session=True,
        )

        body = mock_async_http.post.call_args[1]["json"]
        assert body["max_short_term_messages"] == 50
        assert body["enable_long_term_memory"] is False
        assert body["cross_session"] is True

    @pytest.mark.asyncio
    async def test_acontext_requires_owner_id(self, cognis_module):
        """acontext() with agent_id + session_id but no owner_id raises ValueError."""
        with pytest.raises(ValueError, match="owner_id is required"):
            await cognis_module.acontext(
                current_messages=[{"role": "user", "content": "test"}],
                agent_id="agent_1",
                session_id="sess_1",
            )


@pytest.mark.cognis
class TestCognisAsyncMessages:
    """Tests for aget_messages()."""

    @pytest.mark.asyncio
    async def test_aget_messages(self, cognis_module, mock_async_http):
        """aget_messages() returns messages dict."""
        mock_async_http.get.return_value = SAMPLE_MESSAGES_RESPONSE

        msgs = await cognis_module.aget_messages(
            owner_id="owner_1",
            session_id="sess_1",
        )

        assert msgs["count"] == 2
        assert len(msgs["messages"]) == 2

    @pytest.mark.asyncio
    async def test_aget_messages_with_params(self, cognis_module, mock_async_http):
        """aget_messages() passes limit, latest, cross_session."""
        mock_async_http.get.return_value = SAMPLE_MESSAGES_RESPONSE

        await cognis_module.aget_messages(
            owner_id="owner_1",
            limit=10,
            latest=True,
            cross_session=True,
        )

        params = mock_async_http.get.call_args[1]["params"]
        assert params["limit"] == 10
        assert params["latest"] == "true"
        assert params["cross_session"] == "true"


# ── Async Summaries Tests ────────────────────────────────────────

@pytest.mark.cognis
class TestCognisAsyncSummaries:
    """Tests for async summary operations."""

    @pytest.mark.asyncio
    async def test_astore_summary(self, cognis_module, mock_async_http):
        """astore_summary() posts summary."""
        mock_async_http.post.return_value = SAMPLE_SUMMARY_RESPONSE

        result = await cognis_module.astore_summary(
            owner_id="owner_1",
            session_id="sess_1",
            content="User likes hiking",
            messages_covered_count=4,
            agent_id="agent_1",
        )

        assert result["success"] is True
        body = mock_async_http.post.call_args[1]["json"]
        assert body["content"] == "User likes hiking"
        assert body["messages_covered_count"] == 4
        assert body["agent_id"] == "agent_1"

    @pytest.mark.asyncio
    async def test_aget_current_summary(self, cognis_module, mock_async_http):
        """aget_current_summary() fetches current summary."""
        mock_async_http.get.return_value = SAMPLE_CURRENT_SUMMARY_RESPONSE

        result = await cognis_module.aget_current_summary(
            owner_id="owner_1",
            session_id="sess_1",
        )

        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_asearch_summaries(self, cognis_module, mock_async_http):
        """asearch_summaries() searches archived summaries."""
        mock_async_http.post.return_value = SAMPLE_SEARCH_SUMMARIES_RESPONSE

        result = await cognis_module.asearch_summaries(
            owner_id="owner_1",
            query="hiking",
            limit=3,
        )

        assert result["count"] == 1
        body = mock_async_http.post.call_args[1]["json"]
        assert body["query"] == "hiking"
        assert body["limit"] == 3
