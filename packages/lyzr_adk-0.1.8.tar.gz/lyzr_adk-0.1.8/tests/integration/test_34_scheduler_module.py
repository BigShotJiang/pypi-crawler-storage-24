"""
Test 34: Scheduler Module
Tests SchedulerModule sync and async methods with mocked HTTP clients.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from lyzr.http import AsyncHTTPClient
from lyzr.urls import ServiceURLs
from lyzr.scheduler import Schedule, ScheduleCreate, ScheduleList, SchedulerModule


SAMPLE_SCHEDULE = {
    "id": "sched_abc123",
    "user_id": "user_123",
    "agent_id": "agent_123",
    "message": "Daily run",
    "cron_expression": "0 9 * * *",
    "timezone": "UTC",
    "max_retries": 3,
    "retry_delay": 60,
    "is_active": True,
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": "2026-01-01T00:00:00Z",
    "next_run_time": "2026-01-02T09:00:00Z",
    "last_run_at": None,
    "last_run_success": None,
}

SAMPLE_SCHEDULE_2 = {
    "id": "sched_def456",
    "user_id": "user_123",
    "agent_id": "agent_123",
    "message": "Evening run",
    "cron_expression": "0 18 * * *",
    "timezone": "UTC",
    "max_retries": 3,
    "retry_delay": 60,
    "is_active": False,
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": "2026-01-01T00:00:00Z",
    "next_run_time": "2026-01-02T18:00:00Z",
    "last_run_at": "2026-01-01T18:00:00Z",
    "last_run_success": True,
}


API_KEY = "sk-test"


@pytest.fixture
def mock_http():
    """Create mock sync HTTP client."""
    http = MagicMock()
    http.api_key = API_KEY
    http.base_url = "https://scheduler.studio.lyzr.ai"
    http.timeout = 30
    return http


@pytest.fixture
def mock_async_http():
    """Create mock async HTTP client."""
    async_http = AsyncMock(spec=AsyncHTTPClient)
    async_http.api_key = API_KEY
    async_http.base_url = "https://scheduler.studio.lyzr.ai"
    async_http.timeout = 30
    return async_http


@pytest.fixture
def env_config():
    """Create environment config with scheduler API URL."""
    return ServiceURLs(
        agent_api="https://agent-prod.studio.lyzr.ai",
        rag_api="https://rag-prod.studio.lyzr.ai",
        rai_api="https://srs-prod.studio.lyzr.ai",
        memory_api="https://memory.studio.lyzr.ai",
        scheduler_api="https://scheduler.studio.lyzr.ai",
    )


@pytest.fixture
def scheduler_module(mock_http, env_config):
    """Create SchedulerModule with mocked HTTP."""
    with patch("lyzr.http.HTTPClient", return_value=mock_http):
        module = SchedulerModule(API_KEY, env_config)
    module._http = mock_http
    return module


@pytest.mark.scheduler
class TestSchedulerModuleSync:
    """Sync tests for SchedulerModule."""

    def test_create_schedule(self, scheduler_module, mock_http):
        """create() sends expected payload and returns Schedule."""
        mock_http.post.return_value = SAMPLE_SCHEDULE

        schedule = scheduler_module.create(
            user_id="user_123",
            agent_id="agent_123",
            cron_expression="0 9 * * *",
            message="Daily run",
        )

        assert isinstance(schedule, Schedule)
        assert schedule.id == "sched_abc123"
        mock_http.post.assert_called_once_with(
            "/schedules/",
            json={
                "user_id": "user_123",
                "agent_id": "agent_123",
                "cron_expression": "0 9 * * *",
                "message": "Daily run",
                "timezone": "UTC",
                "max_retries": 3,
                "retry_delay": 60,
            },
        )

    def test_get_schedule(self, scheduler_module, mock_http):
        """get() returns a Schedule object."""
        mock_http.get.return_value = SAMPLE_SCHEDULE

        schedule = scheduler_module.get("sched_abc123")

        assert isinstance(schedule, Schedule)
        assert schedule.id == "sched_abc123"
        mock_http.get.assert_called_once_with("/schedules/sched_abc123")

    def test_list_schedules_dict_response(self, scheduler_module, mock_http):
        """list() parses wrapped list response."""
        mock_http.get.return_value = {
            "schedules": [SAMPLE_SCHEDULE, SAMPLE_SCHEDULE_2],
            "total": 2,
        }

        schedules = scheduler_module.list(agent_id="agent_123", is_active=True, skip=0, limit=25)

        assert isinstance(schedules, ScheduleList)
        assert len(schedules) == 2
        assert schedules.total == 2
        params = mock_http.get.call_args[1]["params"]
        assert params["agent_id"] == "agent_123"
        assert params["is_active"] is True
        assert params["skip"] == 0
        assert params["limit"] == 25

    def test_list_schedules_plain_list_response(self, scheduler_module, mock_http):
        """list() parses plain list response."""
        mock_http.get.return_value = [SAMPLE_SCHEDULE]

        schedules = scheduler_module.list(user_id="user_123")

        assert isinstance(schedules, ScheduleList)
        assert len(schedules) == 1
        assert schedules.total == 1

    def test_delete_schedule(self, scheduler_module, mock_http):
        """delete() calls API and returns True."""
        mock_http.delete.return_value = True

        result = scheduler_module.delete("sched_abc123")

        assert result is True
        mock_http.delete.assert_called_once_with("/schedules/sched_abc123")

    def test_pause_resume_and_trigger(self, scheduler_module, mock_http):
        """pause(), resume(), and trigger() call expected endpoints."""
        paused = dict(SAMPLE_SCHEDULE)
        paused["is_active"] = False
        resumed = dict(SAMPLE_SCHEDULE)
        resumed["is_active"] = True
        mock_http.post.side_effect = [paused, resumed, {"accepted": True}]

        pause_result = scheduler_module.pause("sched_abc123")
        resume_result = scheduler_module.resume("sched_abc123")
        trigger_result = scheduler_module.trigger("sched_abc123")

        assert pause_result.is_active is False
        assert resume_result.is_active is True
        assert trigger_result is True
        assert mock_http.post.call_args_list[0][0][0] == "/schedules/sched_abc123/pause"
        assert mock_http.post.call_args_list[1][0][0] == "/schedules/sched_abc123/resume"
        assert mock_http.post.call_args_list[2][0][0] == "/schedules/sched_abc123/trigger"


@pytest.mark.scheduler
class TestSchedulerModuleAsync:
    """Async tests for SchedulerModule."""

    @pytest.mark.asyncio
    async def test_async_methods(self, scheduler_module, mock_async_http):
        """Async methods return expected parsed types and values."""
        paused = dict(SAMPLE_SCHEDULE)
        paused["is_active"] = False
        resumed = dict(SAMPLE_SCHEDULE)
        resumed["is_active"] = True

        mock_async_http.post.side_effect = [
            SAMPLE_SCHEDULE,
            paused,
            resumed,
            {"accepted": True},
        ]
        mock_async_http.get.side_effect = [
            SAMPLE_SCHEDULE,
            {"schedules": [SAMPLE_SCHEDULE], "total": 1},
        ]
        mock_async_http.delete.return_value = True

        scheduler_module._async_http = mock_async_http

        created = await scheduler_module.acreate(
            user_id="user_123",
            agent_id="agent_123",
            cron_expression="0 9 * * *",
        )
        fetched = await scheduler_module.aget("sched_abc123")
        listed = await scheduler_module.alist(agent_id="agent_123")
        paused_result = await scheduler_module.apause("sched_abc123")
        resumed_result = await scheduler_module.aresume("sched_abc123")
        triggered = await scheduler_module.atrigger("sched_abc123")
        deleted = await scheduler_module.adelete("sched_abc123")

        assert isinstance(created, Schedule)
        assert isinstance(fetched, Schedule)
        assert isinstance(listed, ScheduleList)
        assert listed.total == 1
        assert paused_result.is_active is False
        assert resumed_result.is_active is True
        assert triggered is True
        assert deleted is True

    @pytest.mark.asyncio
    async def test_async_requires_initialization(self, scheduler_module):
        """Async methods require _async_http to be injected."""
        scheduler_module._async_http = None
        with pytest.raises(RuntimeError, match="Async not initialized"):
            await scheduler_module.aget("sched_abc123")


@pytest.mark.scheduler
class TestScheduleCreate:
    """Tests for ScheduleCreate Pydantic validation."""

    def test_valid_payload(self):
        """Valid ScheduleCreate builds without error."""
        sc = ScheduleCreate(
            user_id="user_123",
            agent_id="agent_abc",
            cron_expression="0 9 * * *",
            timezone="America/New_York",
        )
        assert sc.max_retries == 3
        assert sc.retry_delay == 60
        assert sc.timezone == "America/New_York"

    def test_cron_must_have_five_fields(self):
        """cron_expression with wrong number of fields raises ValueError."""
        with pytest.raises(ValueError, match="5 space-separated fields"):
            ScheduleCreate(
                user_id="u",
                agent_id="a",
                cron_expression="0 9 * *",
            )

    def test_max_retries_min_boundary(self):
        """max_retries=0 is valid."""
        sc = ScheduleCreate(user_id="u", agent_id="a", cron_expression="0 9 * * *", max_retries=0)
        assert sc.max_retries == 0

    def test_max_retries_max_boundary(self):
        """max_retries=5 is valid."""
        sc = ScheduleCreate(user_id="u", agent_id="a", cron_expression="0 9 * * *", max_retries=5)
        assert sc.max_retries == 5

    def test_max_retries_out_of_range(self):
        """max_retries > 5 raises ValidationError."""
        with pytest.raises(Exception):
            ScheduleCreate(user_id="u", agent_id="a", cron_expression="0 9 * * *", max_retries=6)

    def test_retry_delay_min_boundary(self):
        """retry_delay=10 is valid."""
        sc = ScheduleCreate(user_id="u", agent_id="a", cron_expression="0 9 * * *", retry_delay=10)
        assert sc.retry_delay == 10

    def test_retry_delay_max_boundary(self):
        """retry_delay=3600 is valid."""
        sc = ScheduleCreate(user_id="u", agent_id="a", cron_expression="0 9 * * *", retry_delay=3600)
        assert sc.retry_delay == 3600

    def test_retry_delay_out_of_range(self):
        """retry_delay < 10 raises ValidationError."""
        with pytest.raises(Exception):
            ScheduleCreate(user_id="u", agent_id="a", cron_expression="0 9 * * *", retry_delay=5)

    def test_create_sends_model_dump_payload(self, scheduler_module, mock_http):
        """create() sends the model_dump() of ScheduleCreate to the API."""
        mock_http.post.return_value = SAMPLE_SCHEDULE

        scheduler_module.create(
            user_id="user_123",
            agent_id="agent_abc",
            cron_expression="*/5 * * * *",
            max_retries=1,
            retry_delay=30,
        )

        payload = mock_http.post.call_args[1]["json"]
        assert payload["max_retries"] == 1
        assert payload["retry_delay"] == 30
        assert payload["cron_expression"] == "*/5 * * * *"
