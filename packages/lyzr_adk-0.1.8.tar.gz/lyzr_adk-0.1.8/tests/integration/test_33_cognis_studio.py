"""
Test 33: Cognis Studio Integration
Tests Studio cognis module registration, convenience methods, memory field integration,
and async support.
"""

import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from lyzr.cognis.config import CognisConfig
from lyzr.cognis.module import CognisModule
from lyzr.models.config import AgentConfig
from lyzr.memory import MemoryConfig


# ── Studio Registration Tests ────────────────────────────────────

@pytest.mark.cognis
class TestStudioCognisRegistration:
    """Tests that Studio properly registers the cognis module."""

    def test_studio_has_cognis_module(self):
        """Studio instance has cognis attribute."""
        with patch("lyzr.http.HTTPClient") as MockHTTP:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http

            from lyzr.studio import Studio
            studio = Studio(api_key="sk-test")

            assert hasattr(studio, "cognis")
            assert isinstance(studio.cognis, CognisModule)

    def test_studio_convenience_methods_registered(self):
        """Studio has cognis convenience methods."""
        with patch("lyzr.http.HTTPClient") as MockHTTP:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http

            from lyzr.studio import Studio
            studio = Studio(api_key="sk-test")

            assert hasattr(studio, "add_memory")
            assert hasattr(studio, "search_memories")
            assert hasattr(studio, "get_memories")
            assert hasattr(studio, "update_memory")
            assert hasattr(studio, "delete_memory")
            assert hasattr(studio, "get_memory_context")
            assert hasattr(studio, "get_memory_messages")
            assert hasattr(studio, "store_memory_summary")
            assert hasattr(studio, "get_current_memory_summary")
            assert hasattr(studio, "search_memory_summaries")
            assert hasattr(studio, "delete_memory_session")

    def test_studio_cognis_uses_api_key(self):
        """Studio passes api_key (not http_client) to CognisModule."""
        with patch("lyzr.http.HTTPClient") as MockHTTP, \
             patch("lyzr.cognis.module.CognisModule.__init__", return_value=None) as mock_init:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test-key"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http

            from lyzr.studio import Studio
            Studio(api_key="sk-test-key")

            mock_init.assert_called_once()
            call_kwargs = mock_init.call_args
            assert call_kwargs[1]["api_key"] == "sk-test-key"

    def test_studio_async_injects_into_cognis(self):
        """_ensure_async_clients() injects async HTTP into cognis module."""
        with patch("lyzr.http.HTTPClient") as MockHTTP, \
             patch("lyzr.http.AsyncHTTPClient") as MockAsyncHTTP:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http
            MockAsyncHTTP.return_value = AsyncMock()

            from lyzr.studio import Studio
            studio = Studio(api_key="sk-test")
            studio._ensure_async_clients()

            assert studio.cognis._async_http is not None


# ── Memory Field Integration Tests ──────────────────────────────

@pytest.mark.cognis
class TestMemoryFieldIntegration:
    """Tests that the memory field correctly handles CognisConfig, bool, int."""

    def test_memory_true_creates_cognis_feature(self):
        """memory=True creates cognis provider feature."""
        config = AgentConfig(
            name="test", role="r", goal="g", instructions="i",
            provider="openai/gpt-4o", memory=True,
        )
        memory_features = [f for f in config.features if f.get("type") == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider_type"] == "cognis"

    def test_memory_cognis_config_creates_feature(self):
        """memory=CognisConfig(...) creates cognis provider feature."""
        config = AgentConfig(
            name="test", role="r", goal="g", instructions="i",
            provider="openai/gpt-4o",
            memory=CognisConfig(cross_session=True, max_messages_context_count=50),
        )
        memory_features = [f for f in config.features if f.get("type") == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider_type"] == "cognis"
        assert memory_features[0]["config"]["cross_session"] is True
        assert memory_features[0]["config"]["max_messages_context_count"] == 50

    def test_memory_int_creates_lyzr_feature(self):
        """memory=50 creates lyzr provider feature (backward compat)."""
        config = AgentConfig(
            name="test", role="r", goal="g", instructions="i",
            provider="openai/gpt-4o", memory=50,
        )
        memory_features = [f for f in config.features if f.get("type") == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider"] == "lyzr"
        assert memory_features[0]["config"]["max_messages_context_count"] == 50

    def test_memory_config_creates_lyzr_feature(self):
        """memory=MemoryConfig(...) creates lyzr provider feature."""
        config = AgentConfig(
            name="test", role="r", goal="g", instructions="i",
            provider="openai/gpt-4o",
            memory=MemoryConfig(max_messages_context_count=30),
        )
        memory_features = [f for f in config.features if f.get("type") == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider"] == "lyzr"

    def test_memory_dict_cognis_detected(self):
        """memory={"provider_type": "cognis"} creates cognis feature."""
        config = AgentConfig(
            name="test", role="r", goal="g", instructions="i",
            provider="openai/gpt-4o",
            memory={"provider_type": "cognis", "cross_session": True},
        )
        memory_features = [f for f in config.features if f.get("type") == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider_type"] == "cognis"

    def test_memory_dict_cross_session_detected(self):
        """memory={"cross_session": True} creates cognis feature."""
        config = AgentConfig(
            name="test", role="r", goal="g", instructions="i",
            provider="openai/gpt-4o",
            memory={"cross_session": True},
        )
        memory_features = [f for f in config.features if f.get("type") == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider_type"] == "cognis"

    def test_memory_dict_lyzr_detected(self):
        """memory={"max_messages_context_count": 30} creates lyzr feature."""
        config = AgentConfig(
            name="test", role="r", goal="g", instructions="i",
            provider="openai/gpt-4o",
            memory={"max_messages_context_count": 30},
        )
        memory_features = [f for f in config.features if f.get("type") == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider"] == "lyzr"

    def test_cognis_field_removed_from_config(self):
        """AgentConfig no longer has a 'cognis' field."""
        assert "cognis" not in AgentConfig.model_fields


# ── Studio Async Convenience Methods ────────────────────────────

@pytest.mark.cognis
class TestStudioAsyncCognisMethods:
    """Tests that Studio async convenience methods work."""

    @pytest.mark.asyncio
    async def test_aadd_memory(self):
        """studio.aadd_memory() delegates correctly."""
        with patch("lyzr.http.HTTPClient") as MockHTTP, \
             patch("lyzr.http.AsyncHTTPClient") as MockAsyncHTTP:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http

            mock_async = AsyncMock()
            mock_async.post.return_value = {"success": True}
            MockAsyncHTTP.return_value = mock_async

            from lyzr.studio import Studio
            studio = Studio(api_key="sk-test")
            studio._ensure_async_clients()
            studio.cognis._async_http = mock_async

            result = await studio.aadd_memory(
                messages=[{"role": "user", "content": "Hello"}],
                owner_id="owner_1",
            )
            assert result["success"] is True

    @pytest.mark.asyncio
    async def test_asearch_memories(self):
        """studio.asearch_memories() delegates correctly."""
        with patch("lyzr.http.HTTPClient") as MockHTTP, \
             patch("lyzr.http.AsyncHTTPClient") as MockAsyncHTTP:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http

            mock_async = AsyncMock()
            mock_async.post.return_value = {"results": []}
            MockAsyncHTTP.return_value = mock_async

            from lyzr.studio import Studio
            studio = Studio(api_key="sk-test")
            studio._ensure_async_clients()
            studio.cognis._async_http = mock_async

            results = await studio.asearch_memories(
                query="hiking", owner_id="owner_1",
            )
            assert len(results) == 0


# ── Agent Create/Get with Cognis ─────────────────────────────────

@pytest.mark.cognis
class TestAgentCognisAttachment:
    """Tests create→get round-trip: has_memory() and get_memory_config() work for cognis."""

    @staticmethod
    def _agent_response(features=None):
        return {
            "_id": "agent_123",
            "api_key": "sk-test",
            "name": "test-bot",
            "provider_id": "openai",
            "model": "gpt-4o",
            "temperature": 0.7,
            "top_p": 0.9,
            "features": features or [],
        }

    @staticmethod
    def _cognis_feature(cross_session=False, max_messages=20):
        return {
            "type": "MEMORY",
            "config": {
                "provider_type": "cognis",
                "max_messages_context_count": max_messages,
                "cross_session": cross_session,
            },
            "priority": 0,
        }

    def test_create_with_memory_true_sends_cognis_feature(self):
        """create(memory=True) POSTs a cognis MEMORY feature."""
        from lyzr.agents import AgentModule
        mock_http = MagicMock()
        mock_http.post.return_value = {"agent_id": "agent_123"}
        mock_http.get.return_value = self._agent_response([self._cognis_feature()])

        AgentModule(mock_http).create(
            name="test-bot", provider="openai/gpt-4o",
            role="r", goal="g", instructions="i",
            memory=True,
        )

        posted = mock_http.post.call_args[1]["json"]
        memory_features = [f for f in posted["features"] if f["type"] == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider_type"] == "cognis"

    def test_create_with_cognis_config_sends_custom_feature(self):
        """create(memory=CognisConfig(...)) POSTs custom cognis settings."""
        from lyzr.agents import AgentModule
        mock_http = MagicMock()
        mock_http.post.return_value = {"agent_id": "agent_123"}
        mock_http.get.return_value = self._agent_response(
            [self._cognis_feature(cross_session=True, max_messages=50)]
        )

        AgentModule(mock_http).create(
            name="test-bot", provider="openai/gpt-4o",
            role="r", goal="g", instructions="i",
            memory=CognisConfig(cross_session=True, max_messages_context_count=50),
        )

        posted = mock_http.post.call_args[1]["json"]
        memory_features = [f for f in posted["features"] if f["type"] == "MEMORY"]
        assert memory_features[0]["config"]["provider_type"] == "cognis"
        assert memory_features[0]["config"]["cross_session"] is True
        assert memory_features[0]["config"]["max_messages_context_count"] == 50

    def test_get_agent_has_memory_true_for_cognis(self):
        """agents.get() on a cognis-enabled agent → has_memory() is True."""
        from lyzr.agents import AgentModule
        mock_http = MagicMock()
        mock_http.get.return_value = self._agent_response([self._cognis_feature()])

        agent = AgentModule(mock_http).get("agent_123")

        assert agent.has_memory() is True

    def test_get_agent_has_memory_false_without_feature(self):
        """agents.get() on agent with no memory feature → has_memory() is False."""
        from lyzr.agents import AgentModule
        mock_http = MagicMock()
        mock_http.get.return_value = self._agent_response()

        agent = AgentModule(mock_http).get("agent_123")

        assert agent.has_memory() is False
        assert agent.get_memory_config() is None

    def test_get_agent_get_memory_config_returns_cognis_dict(self):
        """agents.get() → get_memory_config() returns full cognis config dict."""
        from lyzr.agents import AgentModule
        mock_http = MagicMock()
        mock_http.get.return_value = self._agent_response(
            [self._cognis_feature(cross_session=True, max_messages=50)]
        )

        agent = AgentModule(mock_http).get("agent_123")

        config = agent.get_memory_config()
        assert config is not None
        assert config["provider_type"] == "cognis"
        assert config["cross_session"] is True
        assert config["max_messages_context_count"] == 50

    def test_create_get_round_trip_cognis_attached(self):
        """Full round-trip: create(memory=True) → get() → both have cognis attached."""
        from lyzr.agents import AgentModule
        mock_http = MagicMock()
        mock_http.post.return_value = {"agent_id": "agent_123"}
        mock_http.get.return_value = self._agent_response([self._cognis_feature()])

        agents = AgentModule(mock_http)
        created = agents.create(
            name="test-bot", provider="openai/gpt-4o",
            role="r", goal="g", instructions="i",
            memory=True,
        )
        fetched = agents.get("agent_123")

        assert created.has_memory() is True
        assert fetched.has_memory() is True
        assert created.get_memory_config()["provider_type"] == "cognis"
        assert fetched.get_memory_config()["provider_type"] == "cognis"


# ── AgentModule.update() with Cognis ─────────────────────────────

@pytest.mark.cognis
class TestAgentModuleUpdateWithCognis:
    """Tests AgentModule.update(memory=CognisConfig) sends correct feature and returns updated agent."""

    @staticmethod
    def _agent_response(features=None):
        return {
            "_id": "agent_123",
            "api_key": "sk-test",
            "name": "test-bot",
            "provider_id": "openai",
            "model": "gpt-4o",
            "temperature": 0.7,
            "top_p": 0.9,
            "features": features or [],
        }

    def test_update_memory_true_sends_cognis_feature(self):
        """update(memory=True) PUTs with cognis MEMORY feature."""
        from lyzr.agents import AgentModule
        mock_http = MagicMock()
        cognis_feature = {
            "type": "MEMORY",
            "config": {"provider_type": "cognis", "max_messages_context_count": 20, "cross_session": False},
            "priority": 0,
        }
        mock_http.get.side_effect = [
            self._agent_response(),                    # current agent (no memory)
            self._agent_response([cognis_feature]),    # agent after update
        ]
        mock_http.put.return_value = {"success": True}

        agent = AgentModule(mock_http).update("agent_123", memory=True)

        put_body = mock_http.put.call_args[1]["json"]
        memory_features = [f for f in put_body["features"] if f["type"] == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider_type"] == "cognis"
        assert agent.has_memory() is True

    def test_update_cognis_config_sets_custom_values(self):
        """update(memory=CognisConfig(...)) PUTs the correct custom config values."""
        from lyzr.agents import AgentModule
        mock_http = MagicMock()
        cognis_feature = {
            "type": "MEMORY",
            "config": {"provider_type": "cognis", "max_messages_context_count": 100, "cross_session": True},
            "priority": 0,
        }
        mock_http.get.side_effect = [
            self._agent_response(),
            self._agent_response([cognis_feature]),
        ]
        mock_http.put.return_value = {"success": True}

        agent = AgentModule(mock_http).update(
            "agent_123",
            memory=CognisConfig(cross_session=True, max_messages_context_count=100),
        )

        put_body = mock_http.put.call_args[1]["json"]
        memory_features = [f for f in put_body["features"] if f["type"] == "MEMORY"]
        assert memory_features[0]["config"]["provider_type"] == "cognis"
        assert memory_features[0]["config"]["cross_session"] is True
        assert memory_features[0]["config"]["max_messages_context_count"] == 100
        assert agent.get_memory_config()["provider_type"] == "cognis"

    def test_update_cognis_replaces_existing_lyzr_memory(self):
        """update(memory=CognisConfig()) replaces an existing lyzr MEMORY feature — only one remains."""
        from lyzr.agents import AgentModule
        mock_http = MagicMock()
        lyzr_feature = {
            "type": "MEMORY",
            "config": {"provider": "lyzr", "max_messages_context_count": 10},
            "priority": 0,
        }
        cognis_feature = {
            "type": "MEMORY",
            "config": {"provider_type": "cognis", "max_messages_context_count": 20, "cross_session": False},
            "priority": 0,
        }
        mock_http.get.side_effect = [
            self._agent_response([lyzr_feature]),      # current: has lyzr memory
            self._agent_response([cognis_feature]),    # after update: cognis
        ]
        mock_http.put.return_value = {"success": True}

        AgentModule(mock_http).update("agent_123", memory=CognisConfig())

        put_body = mock_http.put.call_args[1]["json"]
        memory_features = [f for f in put_body["features"] if f["type"] == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider_type"] == "cognis"


# ── Agent Entity .update() with Cognis ───────────────────────────

@pytest.mark.cognis
class TestAgentEntityUpdateWithCognis:
    """Tests Agent entity .update() delegates CognisConfig correctly to AgentModule."""

    @staticmethod
    def _make_agent(mock_agent_module, features=None):
        from lyzr.models.agent import Agent
        agent = Agent.model_validate({
            "_id": "agent_123",
            "api_key": "sk-test",
            "name": "test-bot",
            "provider_id": "openai",
            "model": "gpt-4o",
            "temperature": 0.7,
            "top_p": 0.9,
            "features": features or [],
        })
        # _ensure_clients() checks both _http and _inference before delegating
        agent._http = MagicMock()
        agent._inference = MagicMock()
        agent._agent_module = mock_agent_module
        return agent

    def test_agent_entity_update_passes_cognis_config(self):
        """Agent.update(memory=CognisConfig(...)) delegates CognisConfig to AgentModule.update."""
        mock_module = MagicMock()
        mock_module.update.return_value = MagicMock()

        agent = self._make_agent(mock_module)
        agent.update(memory=CognisConfig(cross_session=True))

        mock_module.update.assert_called_once()
        kwargs = mock_module.update.call_args[1]
        assert isinstance(kwargs["memory"], CognisConfig)
        assert kwargs["memory"].cross_session is True

    def test_agent_entity_update_passes_memory_true(self):
        """Agent.update(memory=True) passes True through to AgentModule.update."""
        mock_module = MagicMock()
        mock_module.update.return_value = MagicMock()

        agent = self._make_agent(mock_module)
        agent.update(memory=True)

        kwargs = mock_module.update.call_args[1]
        assert kwargs["memory"] is True

    def test_agent_entity_has_memory_true_with_cognis_feature(self):
        """Agent loaded with cognis MEMORY feature → has_memory() True."""
        cognis_feature = {
            "type": "MEMORY",
            "config": {"provider_type": "cognis", "max_messages_context_count": 20, "cross_session": False},
            "priority": 0,
        }
        agent = self._make_agent(MagicMock(), features=[cognis_feature])

        assert agent.has_memory() is True
        config = agent.get_memory_config()
        assert config["provider_type"] == "cognis"
        assert config["max_messages_context_count"] == 20

    def test_agent_entity_has_memory_false_with_no_features(self):
        """Agent loaded with no features → has_memory() False, get_memory_config() None."""
        agent = self._make_agent(MagicMock())

        assert agent.has_memory() is False
        assert agent.get_memory_config() is None

    def test_add_memory_cognis_true_sends_cognis_feature(self):
        """add_memory(cognis=True) updates agent with cognis MEMORY feature."""
        mock_module = MagicMock()
        mock_module.update.return_value = MagicMock()

        agent = self._make_agent(mock_module)
        agent.add_memory(cognis=True)

        mock_module.update.assert_called_once()
        _, kwargs = mock_module.update.call_args
        memory_features = [f for f in kwargs["features"] if f["type"] == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider_type"] == "cognis"

    def test_add_memory_cognis_custom_settings(self):
        """add_memory(cognis=True, max_messages=50, cross_session=True) sets correct config."""
        mock_module = MagicMock()
        mock_module.update.return_value = MagicMock()

        agent = self._make_agent(mock_module)
        agent.add_memory(cognis=True, max_messages=50, cross_session=True)

        _, kwargs = mock_module.update.call_args
        memory_features = [f for f in kwargs["features"] if f["type"] == "MEMORY"]
        assert memory_features[0]["config"]["provider_type"] == "cognis"
        assert memory_features[0]["config"]["max_messages_context_count"] == 50
        assert memory_features[0]["config"]["cross_session"] is True

    def test_add_memory_default_uses_lyzr_provider(self):
        """add_memory() without cognis=True uses the lyzr provider."""
        mock_module = MagicMock()
        mock_module.update.return_value = MagicMock()

        agent = self._make_agent(mock_module)
        agent.add_memory(max_messages=30)

        _, kwargs = mock_module.update.call_args
        memory_features = [f for f in kwargs["features"] if f["type"] == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"].get("provider") == "lyzr"

    def test_add_memory_cognis_replaces_existing_memory(self):
        """add_memory(cognis=True) replaces an existing lyzr MEMORY feature."""
        mock_module = MagicMock()
        mock_module.update.return_value = MagicMock()

        lyzr_feature = {
            "type": "MEMORY",
            "config": {"provider": "lyzr", "max_messages_context_count": 10},
            "priority": 0,
        }
        agent = self._make_agent(mock_module, features=[lyzr_feature])
        agent.add_memory(cognis=True)

        _, kwargs = mock_module.update.call_args
        memory_features = [f for f in kwargs["features"] if f["type"] == "MEMORY"]
        assert len(memory_features) == 1
        assert memory_features[0]["config"]["provider_type"] == "cognis"
