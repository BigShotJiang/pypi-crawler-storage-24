"""
Test 35: Scheduler Studio Integration
Tests Studio scheduler module registration and convenience methods.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from lyzr.scheduler import Schedule, ScheduleList, SchedulerModule


SAMPLE_SCHEDULE = {
    "id": "sched_abc123",
    "user_id": "user_123",
    "agent_id": "agent_123",
    "message": "Daily run",
    "cron_expression": "0 9 * * *",
    "timezone": "UTC",
    "max_retries": 3,
    "retry_delay": 60,
    "is_active": True,
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": "2026-01-01T00:00:00Z",
    "next_run_time": "2026-01-02T09:00:00Z",
    "last_run_at": None,
    "last_run_success": None,
}


@pytest.mark.scheduler
class TestStudioSchedulerRegistration:
    """Tests that Studio properly registers scheduler module."""

    def test_studio_has_scheduler_module(self):
        """Studio instance has scheduler attribute."""
        with patch("lyzr.http.HTTPClient") as MockHTTP:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http

            from lyzr.studio import Studio

            studio = Studio(api_key="sk-test")
            assert hasattr(studio, "scheduler")
            assert isinstance(studio.scheduler, SchedulerModule)

    def test_studio_sync_convenience_methods_registered(self):
        """Studio has scheduler sync convenience methods."""
        with patch("lyzr.http.HTTPClient") as MockHTTP:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http

            from lyzr.studio import Studio

            studio = Studio(api_key="sk-test")
            assert hasattr(studio, "create_schedule")
            assert hasattr(studio, "get_schedule")
            assert hasattr(studio, "list_schedules")
            assert hasattr(studio, "delete_schedule")
            assert hasattr(studio, "pause_schedule")
            assert hasattr(studio, "resume_schedule")
            assert hasattr(studio, "trigger_schedule")

    def test_studio_async_injects_scheduler_client(self):
        """_ensure_async_clients() injects async HTTP into scheduler module."""
        with patch("lyzr.http.HTTPClient") as MockHTTP, patch("lyzr.http.AsyncHTTPClient") as MockAsyncHTTP:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http
            MockAsyncHTTP.return_value = AsyncMock()

            from lyzr.studio import Studio

            studio = Studio(api_key="sk-test")
            studio._ensure_async_clients()
            assert studio.scheduler._async_http is not None


@pytest.mark.scheduler
class TestStudioAsyncSchedulerMethods:
    """Tests Studio async scheduler convenience methods."""

    @pytest.mark.asyncio
    async def test_studio_async_methods_delegate(self):
        """studio.a* scheduler methods delegate to scheduler module correctly."""
        with patch("lyzr.http.HTTPClient") as MockHTTP, patch("lyzr.http.AsyncHTTPClient") as MockAsyncHTTP:
            mock_http = MagicMock()
            mock_http.api_key = "sk-test"
            mock_http.base_url = "https://agent-prod.studio.lyzr.ai"
            mock_http.timeout = 300
            MockHTTP.return_value = mock_http
            MockAsyncHTTP.return_value = AsyncMock()

            from lyzr.studio import Studio

            studio = Studio(api_key="sk-test")
            studio._ensure_async_clients()

            studio.scheduler.acreate = AsyncMock(return_value=Schedule(**SAMPLE_SCHEDULE))
            studio.scheduler.aget = AsyncMock(return_value=Schedule(**SAMPLE_SCHEDULE))
            studio.scheduler.alist = AsyncMock(
                return_value=ScheduleList(schedules=[Schedule(**SAMPLE_SCHEDULE)], total=1)
            )
            studio.scheduler.adelete = AsyncMock(return_value=True)
            studio.scheduler.apause = AsyncMock(
                return_value=Schedule(**{**SAMPLE_SCHEDULE, "is_active": False})
            )
            studio.scheduler.aresume = AsyncMock(return_value=Schedule(**SAMPLE_SCHEDULE))
            studio.scheduler.atrigger = AsyncMock(return_value=True)

            created = await studio.acreate_schedule(
                user_id="user_123",
                agent_id="agent_123",
                cron_expression="0 9 * * *",
            )
            fetched = await studio.aget_schedule("sched_abc123")
            listed = await studio.alist_schedules(agent_id="agent_123")
            paused = await studio.apause_schedule("sched_abc123")
            resumed = await studio.aresume_schedule("sched_abc123")
            triggered = await studio.atrigger_schedule("sched_abc123")
            deleted = await studio.adelete_schedule("sched_abc123")

            assert created.id == "sched_abc123"
            assert fetched.id == "sched_abc123"
            assert listed.total == 1
            assert paused.is_active is False
            assert resumed.is_active is True
            assert triggered is True
            assert deleted is True
