"""
Detects which AI-powered IDEs and coding agents are installed on the system.

Paths are based on the Agent Skills standard (agentskills.io) where supported,
with fallbacks to each IDE's native instruction format.
"""

import os
import sys
import shutil
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

HOME = Path.home()


@dataclass
class IDETarget:
    """Represents an AI IDE or coding agent that supports skills."""
    key: str
    name: str
    # Paths where skills should be installed (ordered by preference)
    global_paths: list = field(default_factory=list)
    project_paths: list = field(default_factory=list)
    # Paths or executables to check for detection
    detection_paths: list = field(default_factory=list)
    detection_executables: list = field(default_factory=list)
    detected: bool = False
    install_path: Optional[Path] = None  # Resolved after detection

    def detect(self) -> bool:
        """Return True if this IDE appears to be installed."""
        for p in self.detection_paths:
            if p.exists():
                self.detected = True
                return True
        for exe in self.detection_executables:
            if shutil.which(exe):
                self.detected = True
                return True
        self.detected = False
        return False


def _macos() -> bool:
    return sys.platform == "darwin"

def _windows() -> bool:
    return sys.platform == "win32"

def _linux() -> bool:
    return sys.platform.startswith("linux")

def _appdata() -> Path:
    return Path(os.environ.get("APPDATA", HOME / "AppData/Roaming"))

def _localappdata() -> Path:
    return Path(os.environ.get("LOCALAPPDATA", HOME / "AppData/Local"))


def all_targets() -> list:
    """Return the full list of supported IDE targets."""

    targets = [
        # ── Native SKILL.md support ─────────────────────

        IDETarget(
            key="claude_code",
            name="Claude Code",
            global_paths=[HOME / ".claude" / "skills"],
            project_paths=[Path(".claude") / "skills"],
            detection_paths=[HOME / ".claude"],
            detection_executables=["claude"],
        ),
        IDETarget(
            key="cursor",
            name="Cursor",
            global_paths=[HOME / ".cursor" / "skills"],
            project_paths=[Path(".cursor") / "skills"],
            detection_paths=[
                HOME / ".cursor",
                Path("/Applications/Cursor.app"),
                _localappdata() / "Programs" / "cursor",
            ],
            detection_executables=["cursor"],
        ),
        IDETarget(
            key="gemini_cli",
            name="Gemini CLI",
            global_paths=[HOME / ".gemini" / "skills"],
            project_paths=[Path(".gemini") / "skills"],
            detection_paths=[HOME / ".gemini"],
            detection_executables=["gemini"],
        ),
        IDETarget(
            key="kiro",
            name="Kiro (AWS)",
            global_paths=[HOME / ".kiro" / "skills"],
            project_paths=[Path(".kiro") / "skills"],
            detection_paths=[HOME / ".kiro"],
            detection_executables=["kiro"],
        ),
        IDETarget(
            key="vscode_copilot",
            name="VS Code + GitHub Copilot",
            global_paths=[HOME / ".copilot" / "skills"],
            project_paths=[Path(".github") / "skills"],
            detection_paths=[
                HOME / ".vscode",
                Path("/Applications/Visual Studio Code.app"),
                _localappdata() / "Programs" / "Microsoft VS Code",
            ],
            detection_executables=["code"],
        ),
        IDETarget(
            key="github_copilot",
            name="GitHub Copilot CLI",
            global_paths=[HOME / ".copilot" / "skills"],
            project_paths=[Path(".github") / "skills"],
            detection_paths=[HOME / ".github-copilot"],
            detection_executables=["gh"],
        ),
        IDETarget(
            key="windsurf",
            name="Windsurf",
            global_paths=[HOME / ".codeium" / "windsurf" / "skills"],
            project_paths=[Path(".windsurf") / "skills"],
            detection_paths=[
                HOME / ".codeium" / "windsurf",
                Path("/Applications/Windsurf.app"),
                _localappdata() / "Programs" / "windsurf",
            ],
            detection_executables=["windsurf"],
        ),
        IDETarget(
            key="claude_desktop",
            name="Claude Desktop",
            global_paths=[
                HOME / ".claude" / "skills",  # Shared with Claude Code
            ],
            project_paths=[Path(".claude") / "skills"],
            detection_paths=[
                HOME / "Library" / "Application Support" / "Claude",
                _appdata() / "Claude",
                HOME / ".config" / "Claude",
                Path("/Applications/Claude.app"),
            ],
        ),

        # ── Partial / own format (skills copied as-is, IDE may read .md) ──

        IDETarget(
            key="augment",
            name="Augment Code",
            global_paths=[HOME / ".augment" / "skills"],
            project_paths=[Path(".augment") / "skills"],
            detection_paths=[HOME / ".augment"],
            detection_executables=["augment"],
        ),
        IDETarget(
            key="continue",
            name="Continue (VS Code)",
            global_paths=[HOME / ".continue" / "skills"],
            project_paths=[Path(".continue") / "skills"],
            detection_paths=[HOME / ".continue"],
        ),
        IDETarget(
            key="cline",
            name="Cline (VS Code)",
            global_paths=[HOME / ".cline" / "skills"],
            project_paths=[Path(".cline") / "skills"],
            detection_paths=[HOME / ".cline"],
        ),
        IDETarget(
            key="roo_code",
            name="Roo Code",
            global_paths=[HOME / ".roo" / "skills"],
            project_paths=[Path(".roo") / "skills"],
            detection_paths=[HOME / ".roo-code", HOME / ".roo"],
        ),
        IDETarget(
            key="zencoder",
            name="Zencoder",
            global_paths=[HOME / ".zencoder" / "skills"],
            project_paths=[Path(".zencoder") / "skills"],
            detection_paths=[HOME / ".zencoder"],
        ),
    ]

    return targets


def detect_installed(targets: list) -> list:
    """Run detection on all targets, return sorted list (detected first)."""
    for t in targets:
        t.detect()
    return sorted(targets, key=lambda t: (not t.detected, t.name))


def resolve_install_path(target: IDETarget, scope: str) -> Optional[Path]:
    """
    Given a scope ('global' or 'project'), return the best install path
    for this IDE. Returns None if no suitable path found.
    """
    paths = target.global_paths if scope == "global" else target.project_paths
    if paths:
        return paths[0]
    return None
