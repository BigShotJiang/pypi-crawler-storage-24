"""
CognisModule for direct memory CRUD operations via the Lyzr memory API
"""

from typing import Dict, Any, Optional, List, Union, TYPE_CHECKING
from lyzr.base import BaseModule
from lyzr.cognis.models import (
    CognisMessage,
    CognisMemoryRecord,
    CognisSearchResult,
    CognisMemoryList,
)
from lyzr.logger import get_logger

logger = get_logger()

if TYPE_CHECKING:
    from lyzr.http import HTTPClient
    from lyzr.urls import ServiceURLs


class CognisModule(BaseModule):
    """
    Module for direct memory operations (add/search/get/update/delete)

    Talks to the Lyzr memory service. This is distinct from MemoryModule
    which manages memory credentials/providers.

    Example (Standalone):
        >>> from lyzr.cognis import CognisModule
        >>> from lyzr.urls import ServiceURLs
        >>> env = ServiceURLs(agent_api="...", rag_api="...", rai_api="...", memory_api="...")
        >>> cognis = CognisModule(api_key="sk-xxx", env_config=env)
        >>> cognis.add(messages=[...], owner_id="user_1")

    Example (Through Studio):
        >>> from lyzr import Studio
        >>> studio = Studio(api_key="sk-xxx")
        >>> studio.cognis.add(messages=[...], owner_id="user_1")
    """

    def __init__(self, api_key: str, env_config: "ServiceURLs"):
        """
        Initialize CognisModule

        Note: Creates a separate HTTP client for the memory API (different base URL),
        following the same pattern as KnowledgeBaseModule and RAIModule.

        Args:
            api_key: Lyzr API key
            env_config: Environment URL configuration
        """
        from lyzr.http import HTTPClient as _HTTPClient

        self._http = _HTTPClient(
            api_key=api_key,
            base_url=env_config.memory_api,
            timeout=30,
        )
        self._async_http = None

    def _ensure_async(self):
        """Ensure async HTTP client is available (Cognis creates its own)"""
        if not self._async_http:
            raise RuntimeError(
                "Async not initialized. Use 'async with Studio(...) as studio:' "
                "or 'async with Cognis(...) as cognis:' to enable async support."
            )

    # ========================================================================
    # Internal Helpers
    # ========================================================================

    @staticmethod
    def _validate_ids(owner_id, agent_id, session_id):
        """Validate at least one identifier is provided"""
        if not any([owner_id, agent_id, session_id]):
            raise ValueError(
                "At least one of owner_id, agent_id, or session_id must be provided"
            )

    @staticmethod
    def _normalize_messages(
        messages: List[Union[Dict[str, str], CognisMessage]],
    ) -> List[Dict[str, str]]:
        """Convert CognisMessage objects to dicts"""
        return [
            msg.model_dump() if isinstance(msg, CognisMessage) else msg
            for msg in messages
        ]

    @staticmethod
    def _build_id_body(
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build body dict with non-None identifiers"""
        body: Dict[str, Any] = {}
        if owner_id is not None:
            body["owner_id"] = owner_id
        if agent_id is not None:
            body["agent_id"] = agent_id
        if session_id is not None:
            body["session_id"] = session_id
        return body

    @staticmethod
    def _parse_memory_list(response) -> List[CognisMemoryRecord]:
        """Parse API response into list of CognisMemoryRecord"""
        if isinstance(response, list):
            return [CognisMemoryRecord(**r) for r in response]
        elif isinstance(response, dict):
            data = response.get(
                "memories",
                response.get("results", response.get("data", [])),
            )
            return [CognisMemoryRecord(**r) for r in data]
        return []

    @staticmethod
    def _parse_search_results(response) -> List[CognisSearchResult]:
        """Parse search API response into list of CognisSearchResult"""
        results_data = (
            response
            if isinstance(response, list)
            else response.get("results", response.get("memories", []))
        )
        return [CognisSearchResult(**r) for r in results_data]

    # ========================================================================
    # Core CRUD - Sync
    # ========================================================================

    def add(
        self,
        messages: List[Union[Dict[str, str], CognisMessage]],
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Add messages to memory

        Args:
            messages: List of messages with 'role' and 'content' keys
            owner_id: Owner/user identifier
            agent_id: Agent identifier
            session_id: Session identifier

        Returns:
            Dict with success status and session info

        Raises:
            ValueError: If none of owner_id, agent_id, session_id are provided

        Example:
            >>> cognis.add(
            ...     messages=[{"role": "user", "content": "Hello"}],
            ...     owner_id="user_1",
            ... )
        """
        self._validate_ids(owner_id, agent_id, session_id)
        body = self._build_id_body(owner_id, agent_id, session_id)
        body["messages"] = self._normalize_messages(messages)

        logger.debug(f"[Cognis] Adding {len(messages)} message(s)")
        return self._http.post("/v1/memories", json=body)

    def search(
        self,
        query: str,
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: Optional[int] = None,
        cross_session: Optional[bool] = None,
    ) -> List[CognisSearchResult]:
        """
        Search memories by semantic query

        Args:
            query: Search query string
            owner_id: Owner/user identifier
            agent_id: Agent filter
            session_id: Session filter
            limit: Max results
            cross_session: Search across sessions

        Returns:
            List[CognisSearchResult]: Matching memories

        Raises:
            ValueError: If none of owner_id, agent_id, session_id are provided

        Example:
            >>> results = cognis.search(query="Hello", owner_id="user_1")
        """
        self._validate_ids(owner_id, agent_id, session_id)
        body = self._build_id_body(owner_id, agent_id, session_id)
        body["query"] = query
        if limit is not None:
            body["limit"] = limit
        if cross_session is not None:
            body["cross_session"] = cross_session

        logger.debug(f"[Cognis] Searching: '{query}'")
        response = self._http.post("/v1/memories/search", json=body)
        return self._parse_search_results(response)

    def get(
        self,
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        include_historical: Optional[bool] = None,
        cross_session: Optional[bool] = None,
    ) -> CognisMemoryList:
        """
        List memories

        Args:
            owner_id: Owner/user identifier
            agent_id: Agent filter
            session_id: Session filter
            limit: Max results
            offset: Pagination offset
            include_historical: Include historical memories
            cross_session: Search across sessions

        Returns:
            CognisMemoryList: Iterable list of memory records

        Raises:
            ValueError: If none of owner_id, agent_id, session_id are provided

        Example:
            >>> memories = cognis.get(owner_id="user_1")
            >>> for m in memories:
            ...     print(m.content)
        """
        self._validate_ids(owner_id, agent_id, session_id)
        params = self._build_id_body(owner_id, agent_id, session_id)
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if include_historical is not None:
            params["include_historical"] = include_historical
        if cross_session is not None:
            params["cross_session"] = cross_session

        logger.debug("[Cognis] Listing memories")
        response = self._http.get("/v1/memories", params=params)
        records = self._parse_memory_list(response)
        return CognisMemoryList(memories=records, total=len(records))

    def get_memory(
        self,
        memory_id: str,
        owner_id: Optional[str] = None,
    ) -> CognisMemoryRecord:
        """
        Get a specific memory by ID

        Args:
            memory_id: Memory record ID
            owner_id: Owner ID

        Returns:
            CognisMemoryRecord: Memory record
        """
        params: Dict[str, Any] = {}
        if owner_id is not None:
            params["owner_id"] = owner_id
        response = self._http.get(f"/v1/memories/{memory_id}", params=params)
        data = response.get("memory", response) if isinstance(response, dict) else response
        return CognisMemoryRecord(**data)

    def update(
        self,
        memory_id: str,
        content: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        owner_id: Optional[str] = None,
    ) -> CognisMemoryRecord:
        """
        Update a memory record

        Args:
            memory_id: Memory ID to update
            content: New content
            metadata: New metadata
            owner_id: Owner ID

        Returns:
            CognisMemoryRecord: Updated record
        """
        body: Dict[str, Any] = {}
        if content is not None:
            body["content"] = content
        if metadata is not None:
            body["metadata"] = metadata
        if owner_id is not None:
            body["owner_id"] = owner_id

        logger.debug(f"[Cognis] Updating memory: {memory_id}")
        self._http.patch(f"/v1/memories/{memory_id}", json=body)
        return self.get_memory(memory_id, owner_id)

    def delete(
        self,
        memory_id: str,
        owner_id: Optional[str] = None,
    ) -> bool:
        """
        Delete a memory record

        Args:
            memory_id: Memory record ID
            owner_id: Owner ID

        Returns:
            bool: True if successful
        """
        params: Dict[str, Any] = {}
        if owner_id is not None:
            params["owner_id"] = owner_id
        logger.debug(f"[Cognis] Deleting memory: {memory_id}")
        self._http.delete(f"/v1/memories/{memory_id}", params=params)
        return True

    # ========================================================================
    # Context & Messages - Sync
    # ========================================================================

    def context(
        self,
        current_messages: List[Union[Dict[str, str], CognisMessage]],
        owner_id: Optional[str] = None,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        max_short_term_messages: int = 30,
        enable_long_term_memory: bool = True,
        cross_session: bool = False,
    ) -> Dict[str, Any]:
        """
        Get conversation context (short-term + long-term memory)

        Assembles context from raw messages, summaries, and long-term memories.
        Mirrors the server-side context assembly in LyzrMemoryModule.

        Args:
            current_messages: Current conversation messages
            owner_id: Owner/user identifier
            session_id: Session identifier
            agent_id: Agent identifier
            max_short_term_messages: Max short-term messages to include
            enable_long_term_memory: Include long-term memories
            cross_session: Search across sessions

        Returns:
            Dict with context, has_long_term_memory, short_term_count, long_term_count

        Raises:
            ValueError: If none of owner_id, agent_id, session_id are provided

        Example:
            >>> ctx = cognis.context(
            ...     current_messages=[{"role": "user", "content": "Hello"}],
            ...     owner_id="user_1", session_id="sess_1",
            ... )
        """
        if not owner_id:
            raise ValueError("owner_id is required for context operations (server requirement)")
        self._validate_ids(owner_id, agent_id, session_id)
        body = self._build_id_body(owner_id, agent_id, session_id)
        body["current_messages"] = self._normalize_messages(current_messages)
        body["max_short_term_messages"] = max_short_term_messages
        body["enable_long_term_memory"] = enable_long_term_memory
        body["cross_session"] = cross_session

        logger.debug("[Cognis] Getting context")
        return self._http.post("/v1/memories/context", json=body)

    def get_messages(
        self,
        owner_id: Optional[str] = None,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = None,
        latest: bool = False,
        cross_session: bool = False,
    ) -> Dict[str, Any]:
        """
        Get raw conversation messages

        Args:
            owner_id: Owner/user identifier
            session_id: Session identifier
            agent_id: Agent filter
            limit: Max messages
            latest: Return last N messages in order
            cross_session: Search across sessions

        Returns:
            Dict with messages array and count

        Raises:
            ValueError: If none of owner_id, agent_id, session_id are provided

        Example:
            >>> msgs = cognis.get_messages(owner_id="user_1", session_id="sess_1")
        """
        self._validate_ids(owner_id, agent_id, session_id)
        params = self._build_id_body(owner_id, agent_id, session_id)
        if limit is not None:
            params["limit"] = limit
        if latest:
            params["latest"] = "true"
        if cross_session:
            params["cross_session"] = "true"

        logger.debug("[Cognis] Getting messages")
        return self._http.get("/v1/memories/messages", params=params)

    # ========================================================================
    # Summaries - Sync
    # ========================================================================

    def store_summary(
        self,
        owner_id: str,
        session_id: str,
        content: str,
        messages_covered_count: int,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Store a conversation summary (auto-archives previous)

        Note: owner_id is required by the memory service for all summary operations.

        Args:
            owner_id: Owner/user identifier (required)
            session_id: Session identifier
            content: Summary content
            messages_covered_count: Number of messages this summary covers
            agent_id: Agent identifier

        Returns:
            Dict with success, summary_id, archived_previous
        """
        body: Dict[str, Any] = {
            "owner_id": owner_id,
            "session_id": session_id,
            "content": content,
            "messages_covered_count": messages_covered_count,
        }
        if agent_id is not None:
            body["agent_id"] = agent_id

        logger.debug(f"[Cognis] Storing summary for session: {session_id}")
        return self._http.post("/v1/memories/summaries", json=body)

    def get_current_summary(
        self,
        owner_id: str,
        session_id: str,
    ) -> Dict[str, Any]:
        """
        Get current active summary for a session

        Note: owner_id is required by the memory service for all summary operations.

        Args:
            owner_id: Owner/user identifier (required)
            session_id: Session identifier

        Returns:
            Dict with success and summary object
        """
        params = {"owner_id": owner_id, "session_id": session_id}
        return self._http.get("/v1/memories/summaries/current", params=params)

    def search_summaries(
        self,
        owner_id: str,
        query: str,
        session_id: Optional[str] = None,
        limit: int = 5,
    ) -> Dict[str, Any]:
        """
        Search archived summaries

        Note: owner_id is required by the memory service for all summary operations.

        Args:
            owner_id: Owner/user identifier (required)
            query: Search query
            session_id: Session filter
            limit: Max results

        Returns:
            Dict with success, results, count
        """
        body: Dict[str, Any] = {
            "owner_id": owner_id,
            "query": query,
            "limit": limit,
        }
        if session_id is not None:
            body["session_id"] = session_id

        logger.debug(f"[Cognis] Searching summaries: '{query}'")
        return self._http.post("/v1/memories/summaries/search", json=body)

    def delete_session(
        self,
        owner_id: str,
        session_id: str,
        agent_id: Optional[str] = None,
    ) -> bool:
        """
        Clear all messages and memories from a session

        Args:
            owner_id: Owner/user identifier
            session_id: Session identifier
            agent_id: Agent identifier

        Returns:
            bool: True if successful
        """
        body: Dict[str, Any] = {
            "owner_id": owner_id,
            "session_id": session_id,
        }
        if agent_id is not None:
            body["agent_id"] = agent_id

        logger.warning(f"[Cognis] Deleting session: {session_id}")
        self._http.delete("/v1/memories/session", json_body=body)
        return True

    # ========================================================================
    # Async Methods
    # ========================================================================

    async def aadd(
        self,
        messages: List[Union[Dict[str, str], CognisMessage]],
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Async add messages to memory"""
        self._validate_ids(owner_id, agent_id, session_id)
        self._ensure_async()
        body = self._build_id_body(owner_id, agent_id, session_id)
        body["messages"] = self._normalize_messages(messages)
        return await self._async_http.post("/v1/memories", json=body)

    async def asearch(
        self,
        query: str,
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: Optional[int] = None,
        cross_session: Optional[bool] = None,
    ) -> List[CognisSearchResult]:
        """Async search memories"""
        self._validate_ids(owner_id, agent_id, session_id)
        self._ensure_async()
        body = self._build_id_body(owner_id, agent_id, session_id)
        body["query"] = query
        if limit is not None:
            body["limit"] = limit
        if cross_session is not None:
            body["cross_session"] = cross_session

        response = await self._async_http.post("/v1/memories/search", json=body)
        return self._parse_search_results(response)

    async def aget(
        self,
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        include_historical: Optional[bool] = None,
        cross_session: Optional[bool] = None,
    ) -> CognisMemoryList:
        """Async list memories"""
        self._validate_ids(owner_id, agent_id, session_id)
        self._ensure_async()
        params = self._build_id_body(owner_id, agent_id, session_id)
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if include_historical is not None:
            params["include_historical"] = include_historical
        if cross_session is not None:
            params["cross_session"] = cross_session

        response = await self._async_http.get("/v1/memories", params=params)
        records = self._parse_memory_list(response)
        return CognisMemoryList(memories=records, total=len(records))

    async def aget_memory(
        self,
        memory_id: str,
        owner_id: Optional[str] = None,
    ) -> CognisMemoryRecord:
        """Async get specific memory by ID"""
        self._ensure_async()
        params: Dict[str, Any] = {}
        if owner_id is not None:
            params["owner_id"] = owner_id
        response = await self._async_http.get(f"/v1/memories/{memory_id}", params=params)
        data = response.get("memory", response) if isinstance(response, dict) else response
        return CognisMemoryRecord(**data)

    async def aupdate(
        self,
        memory_id: str,
        content: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        owner_id: Optional[str] = None,
    ) -> CognisMemoryRecord:
        """Async update a memory record"""
        self._ensure_async()
        body: Dict[str, Any] = {}
        if content is not None:
            body["content"] = content
        if metadata is not None:
            body["metadata"] = metadata
        if owner_id is not None:
            body["owner_id"] = owner_id
        await self._async_http.patch(f"/v1/memories/{memory_id}", json=body)
        return await self.aget_memory(memory_id, owner_id)

    async def adelete(
        self,
        memory_id: str,
        owner_id: Optional[str] = None,
    ) -> bool:
        """Async delete a memory record"""
        self._ensure_async()
        params: Dict[str, Any] = {}
        if owner_id is not None:
            params["owner_id"] = owner_id
        await self._async_http.delete(f"/v1/memories/{memory_id}", params=params)
        return True

    async def acontext(
        self,
        current_messages: List[Union[Dict[str, str], CognisMessage]],
        owner_id: Optional[str] = None,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        max_short_term_messages: int = 30,
        enable_long_term_memory: bool = True,
        cross_session: bool = False,
    ) -> Dict[str, Any]:
        """Async get conversation context"""
        if not owner_id:
            raise ValueError("owner_id is required for context operations (server requirement)")
        self._validate_ids(owner_id, agent_id, session_id)
        self._ensure_async()
        body = self._build_id_body(owner_id, agent_id, session_id)
        body["current_messages"] = self._normalize_messages(current_messages)
        body["max_short_term_messages"] = max_short_term_messages
        body["enable_long_term_memory"] = enable_long_term_memory
        body["cross_session"] = cross_session
        return await self._async_http.post("/v1/memories/context", json=body)

    async def aget_messages(
        self,
        owner_id: Optional[str] = None,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = None,
        latest: bool = False,
        cross_session: bool = False,
    ) -> Dict[str, Any]:
        """Async get raw conversation messages"""
        self._validate_ids(owner_id, agent_id, session_id)
        self._ensure_async()
        params = self._build_id_body(owner_id, agent_id, session_id)
        if limit is not None:
            params["limit"] = limit
        if latest:
            params["latest"] = "true"
        if cross_session:
            params["cross_session"] = "true"
        return await self._async_http.get("/v1/memories/messages", params=params)

    async def astore_summary(
        self,
        owner_id: str,
        session_id: str,
        content: str,
        messages_covered_count: int,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Async store a conversation summary"""
        self._ensure_async()
        body: Dict[str, Any] = {
            "owner_id": owner_id,
            "session_id": session_id,
            "content": content,
            "messages_covered_count": messages_covered_count,
        }
        if agent_id is not None:
            body["agent_id"] = agent_id
        return await self._async_http.post("/v1/memories/summaries", json=body)

    async def aget_current_summary(
        self,
        owner_id: str,
        session_id: str,
    ) -> Dict[str, Any]:
        """Async get current summary"""
        self._ensure_async()
        params = {"owner_id": owner_id, "session_id": session_id}
        return await self._async_http.get("/v1/memories/summaries/current", params=params)

    async def asearch_summaries(
        self,
        owner_id: str,
        query: str,
        session_id: Optional[str] = None,
        limit: int = 5,
    ) -> Dict[str, Any]:
        """Async search archived summaries"""
        self._ensure_async()
        body: Dict[str, Any] = {
            "owner_id": owner_id,
            "query": query,
            "limit": limit,
        }
        if session_id is not None:
            body["session_id"] = session_id
        return await self._async_http.post("/v1/memories/summaries/search", json=body)

    async def adelete_session(
        self,
        owner_id: str,
        session_id: str,
        agent_id: Optional[str] = None,
    ) -> bool:
        """Async clear session"""
        self._ensure_async()
        body: Dict[str, Any] = {
            "owner_id": owner_id,
            "session_id": session_id,
        }
        if agent_id is not None:
            body["agent_id"] = agent_id
        await self._async_http.delete("/v1/memories/session", json_body=body)
        return True
