"""
Cognis Module for Lyzr ADK

Direct memory CRUD operations via the Lyzr memory service.

Supports:
1. Standalone usage - Cognis(api_key="sk-xxx")
2. Studio integration - studio.cognis.add(...)

Main Classes:
    - Cognis: Standalone client for memory operations
    - CognisModule: Module for Studio integration
    - CognisConfig: Agent-level cognis configuration
    - CognisMessage: Message model (role + content)
    - CognisMemoryRecord: Memory record from API
    - CognisSearchResult: Search result from API
    - CognisMemoryList: Iterable list of memory records
"""

from lyzr.cognis.models import CognisMessage, CognisMemoryRecord, CognisSearchResult, CognisMemoryList
from lyzr.cognis.config import CognisConfig
from lyzr.cognis.module import CognisModule
from lyzr.cognis.client import Cognis

__all__ = [
    "Cognis",
    "CognisModule",
    "CognisConfig",
    "CognisMessage",
    "CognisMemoryRecord",
    "CognisSearchResult",
    "CognisMemoryList",
]
