"""
Configuration for Cognis memory integration with agents
"""

from typing import Dict, Any
from pydantic import BaseModel, Field, ConfigDict


class CognisConfig(BaseModel):
    """
    Cognis memory configuration for agents

    Used when creating agents with Cognis memory enabled.

    Example:
        >>> from lyzr import Studio, CognisConfig
        >>> studio = Studio(api_key="sk-xxx")
        >>>
        >>> # Simple: enable cognis with defaults
        >>> agent = studio.create_agent(..., memory=True)
        >>>
        >>> # Custom: configure settings
        >>> agent = studio.create_agent(
        ...     ...,
        ...     memory=CognisConfig(cross_session=True)
        ... )
    """

    max_messages_context_count: int = Field(
        20,
        ge=1,
        le=200,
        description="Maximum messages to keep in conversation context",
    )
    cross_session: bool = Field(
        False,
        description="Whether to search memories across all sessions",
    )

    model_config = ConfigDict(frozen=True)

    def to_feature_format(self) -> Dict[str, Any]:
        """Convert to feature format for the agent API"""
        return {
            "type": "MEMORY",
            "config": {
                "provider_type": "cognis",
                "max_messages_context_count": self.max_messages_context_count,
                "cross_session": self.cross_session,
            },
            "priority": 0,
        }
