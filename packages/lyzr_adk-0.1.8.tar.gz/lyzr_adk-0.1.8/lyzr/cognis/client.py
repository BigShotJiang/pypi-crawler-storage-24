"""
Standalone Cognis client for direct memory operations

Usage:
    from lyzr import Cognis

    cog = Cognis(api_key="sk-xxx")
    cog.add(messages=[{"role": "user", "content": "Hello"}], owner_id="user_1")
    results = cog.search(query="Hello", owner_id="user_1")
"""

from typing import Optional, List, Dict, Any, Union, Literal
from lyzr.cognis.module import CognisModule
from lyzr.cognis.models import (
    CognisMessage,
    CognisMemoryRecord,
    CognisSearchResult,
    CognisMemoryList,
)
from lyzr.urls import ServiceURLs, get_urls
from lyzr.http import AsyncHTTPClient
from lyzr.logger import get_logger

logger = get_logger()


class Cognis:
    """
    Standalone memory operations client

    Provides direct CRUD access to the Lyzr memory service without
    requiring a Studio instance.

    Example:
        >>> from lyzr import Cognis
        >>> cog = Cognis(api_key="sk-xxx")
        >>> cog.add(
        ...     messages=[{"role": "user", "content": "Hello"}],
        ...     owner_id="user_1",
        ... )
        >>> results = cog.search(query="Hello", owner_id="user_1")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        env: Union[Literal["prod", "dev", "local"], ServiceURLs] = "prod",
        timeout: int = 30,
    ):
        """
        Initialize standalone Cognis client

        Args:
            api_key: Lyzr API key (reads from LYZR_API_KEY env var if not provided)
            env: Environment (prod, dev, local) or ServiceURLs instance
            timeout: Request timeout in seconds
        """
        if isinstance(env, ServiceURLs):
            self.env_config = env
            self.env = "custom"
        else:
            self.env_config = get_urls(env)
            self.env = env

        self._timeout = timeout
        self._module = CognisModule(api_key=api_key, env_config=self.env_config)
        logger.debug(f"[Cognis] Initialized standalone client (env={self.env})")

    # ========================================================================
    # Core CRUD - Sync
    # ========================================================================

    def add(
        self,
        messages: List[Union[Dict[str, str], CognisMessage]],
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Add messages to memory. At least one of owner_id, agent_id, or session_id required."""
        return self._module.add(messages, owner_id, agent_id, session_id)

    def search(
        self,
        query: str,
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: Optional[int] = None,
        cross_session: Optional[bool] = None,
    ) -> List[CognisSearchResult]:
        """Search memories. At least one of owner_id, agent_id, or session_id required."""
        return self._module.search(query, owner_id, agent_id, session_id, limit, cross_session)

    def get(
        self,
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        include_historical: Optional[bool] = None,
        cross_session: Optional[bool] = None,
    ) -> CognisMemoryList:
        """List memories. At least one of owner_id, agent_id, or session_id required."""
        return self._module.get(
            owner_id, agent_id, session_id, limit, offset,
            include_historical, cross_session,
        )

    def get_memory(
        self,
        memory_id: str,
        owner_id: Optional[str] = None,
    ) -> CognisMemoryRecord:
        """Get a specific memory by ID"""
        return self._module.get_memory(memory_id, owner_id)

    def update(
        self,
        memory_id: str,
        content: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        owner_id: Optional[str] = None,
    ) -> CognisMemoryRecord:
        """Update a memory record"""
        return self._module.update(memory_id, content, metadata, owner_id)

    def delete(
        self,
        memory_id: str,
        owner_id: Optional[str] = None,
    ) -> bool:
        """Delete a memory record"""
        return self._module.delete(memory_id, owner_id)

    # ========================================================================
    # Context & Messages - Sync
    # ========================================================================

    def context(
        self,
        current_messages: List[Union[Dict[str, str], CognisMessage]],
        owner_id: Optional[str] = None,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        max_short_term_messages: int = 30,
        enable_long_term_memory: bool = True,
        cross_session: bool = False,
    ) -> Dict[str, Any]:
        """Get conversation context. At least one of owner_id, agent_id, or session_id required."""
        return self._module.context(
            current_messages, owner_id, session_id, agent_id,
            max_short_term_messages, enable_long_term_memory, cross_session,
        )

    def get_messages(
        self,
        owner_id: Optional[str] = None,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = None,
        latest: bool = False,
        cross_session: bool = False,
    ) -> Dict[str, Any]:
        """Get raw conversation messages. At least one of owner_id, agent_id, or session_id required."""
        return self._module.get_messages(
            owner_id, session_id, agent_id, limit, latest, cross_session,
        )

    # ========================================================================
    # Summaries - Sync
    # ========================================================================

    def store_summary(
        self,
        owner_id: str,
        session_id: str,
        content: str,
        messages_covered_count: int,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Store a conversation summary"""
        return self._module.store_summary(
            owner_id, session_id, content, messages_covered_count, agent_id,
        )

    def get_current_summary(self, owner_id: str, session_id: str) -> Dict[str, Any]:
        """Get current summary for a session"""
        return self._module.get_current_summary(owner_id, session_id)

    def search_summaries(
        self,
        owner_id: str,
        query: str,
        session_id: Optional[str] = None,
        limit: int = 5,
    ) -> Dict[str, Any]:
        """Search archived summaries"""
        return self._module.search_summaries(owner_id, query, session_id, limit)

    def delete_session(
        self,
        owner_id: str,
        session_id: str,
        agent_id: Optional[str] = None,
    ) -> bool:
        """Clear all messages and memories from a session"""
        return self._module.delete_session(owner_id, session_id, agent_id)

    # ========================================================================
    # Core CRUD - Async
    # ========================================================================

    async def aadd(
        self,
        messages: List[Union[Dict[str, str], CognisMessage]],
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Async add messages to memory"""
        self._ensure_async()
        return await self._module.aadd(messages, owner_id, agent_id, session_id)

    async def asearch(
        self,
        query: str,
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: Optional[int] = None,
        cross_session: Optional[bool] = None,
    ) -> List[CognisSearchResult]:
        """Async search memories"""
        self._ensure_async()
        return await self._module.asearch(
            query, owner_id, agent_id, session_id, limit, cross_session,
        )

    async def aget(
        self,
        owner_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        include_historical: Optional[bool] = None,
        cross_session: Optional[bool] = None,
    ) -> CognisMemoryList:
        """Async list memories"""
        self._ensure_async()
        return await self._module.aget(
            owner_id, agent_id, session_id, limit, offset,
            include_historical, cross_session,
        )

    async def aget_memory(
        self,
        memory_id: str,
        owner_id: Optional[str] = None,
    ) -> CognisMemoryRecord:
        """Async get specific memory"""
        self._ensure_async()
        return await self._module.aget_memory(memory_id, owner_id)

    async def aupdate(
        self,
        memory_id: str,
        content: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        owner_id: Optional[str] = None,
    ) -> CognisMemoryRecord:
        """Async update memory"""
        self._ensure_async()
        return await self._module.aupdate(memory_id, content, metadata, owner_id)

    async def adelete(
        self,
        memory_id: str,
        owner_id: Optional[str] = None,
    ) -> bool:
        """Async delete memory"""
        self._ensure_async()
        return await self._module.adelete(memory_id, owner_id)

    # ========================================================================
    # Context & Messages - Async
    # ========================================================================

    async def acontext(
        self,
        current_messages: List[Union[Dict[str, str], CognisMessage]],
        owner_id: Optional[str] = None,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        max_short_term_messages: int = 30,
        enable_long_term_memory: bool = True,
        cross_session: bool = False,
    ) -> Dict[str, Any]:
        """Async get conversation context"""
        self._ensure_async()
        return await self._module.acontext(
            current_messages, owner_id, session_id, agent_id,
            max_short_term_messages, enable_long_term_memory, cross_session,
        )

    async def aget_messages(
        self,
        owner_id: Optional[str] = None,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = None,
        latest: bool = False,
        cross_session: bool = False,
    ) -> Dict[str, Any]:
        """Async get raw messages"""
        self._ensure_async()
        return await self._module.aget_messages(
            owner_id, session_id, agent_id, limit, latest, cross_session,
        )

    # ========================================================================
    # Summaries - Async
    # ========================================================================

    async def astore_summary(
        self,
        owner_id: str,
        session_id: str,
        content: str,
        messages_covered_count: int,
        agent_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Async store summary"""
        self._ensure_async()
        return await self._module.astore_summary(
            owner_id, session_id, content, messages_covered_count, agent_id,
        )

    async def aget_current_summary(
        self,
        owner_id: str,
        session_id: str,
    ) -> Dict[str, Any]:
        """Async get current summary"""
        self._ensure_async()
        return await self._module.aget_current_summary(owner_id, session_id)

    async def asearch_summaries(
        self,
        owner_id: str,
        query: str,
        session_id: Optional[str] = None,
        limit: int = 5,
    ) -> Dict[str, Any]:
        """Async search summaries"""
        self._ensure_async()
        return await self._module.asearch_summaries(owner_id, query, session_id, limit)

    async def adelete_session(
        self,
        owner_id: str,
        session_id: str,
        agent_id: Optional[str] = None,
    ) -> bool:
        """Async clear session"""
        self._ensure_async()
        return await self._module.adelete_session(owner_id, session_id, agent_id)

    # ========================================================================
    # Lifecycle
    # ========================================================================

    def _ensure_async(self):
        """Lazily create async HTTP client for standalone use"""
        if self._module._async_http is None:
            self._module._async_http = AsyncHTTPClient(
                api_key=self._module._http.api_key,
                base_url=self.env_config.memory_api,
                timeout=self._timeout,
            )

    def close(self):
        """Close HTTP clients"""
        self._module._http.close()

    async def aclose(self):
        """Close async HTTP clients"""
        if self._module._async_http:
            await self._module._async_http.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    async def __aenter__(self):
        self._ensure_async()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.aclose()
        self.close()

    def __repr__(self) -> str:
        return f"Cognis(env='{self.env}')"
