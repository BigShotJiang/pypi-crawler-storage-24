"""
Pydantic models for the Agent Scheduler service
"""

from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel, Field, field_validator


class ScheduleCreate(BaseModel):
    """
    Request model for creating an agent schedule.

    Validates payload before sending to the API.

    Timezone:
        Any IANA timezone string (e.g. "UTC", "America/New_York", "Europe/London",
        "Asia/Kolkata"). Full list: https://en.wikipedia.org/wiki/List_of_tz_database_time_zones
    """

    user_id: str
    agent_id: str
    cron_expression: str
    message: str = ""
    timezone: str = "UTC"
    max_retries: int = Field(default=3, ge=0, le=5)
    retry_delay: int = Field(default=60, ge=10, le=3600)

    @field_validator("cron_expression")
    @classmethod
    def validate_cron_fields(cls, v: str) -> str:
        parts = v.strip().split()
        if len(parts) != 5:
            raise ValueError(
                f"cron_expression must have exactly 5 space-separated fields "
                f"(minute hour day month weekday), got {len(parts)}: '{v}'"
            )
        return v


class Schedule(BaseModel):
    """Agent schedule response model"""

    id: str
    user_id: str
    agent_id: str
    message: str = ""
    cron_expression: str
    timezone: str = "UTC"
    max_retries: int = 3
    retry_delay: int = 60
    is_active: bool = True
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    next_run_time: Optional[datetime] = None
    last_run_at: Optional[datetime] = None
    last_run_success: Optional[bool] = None


class ScheduleList(BaseModel):
    """Paginated list of schedules"""

    schedules: List[Schedule] = []
    total: int = 0

    def __iter__(self):
        return iter(self.schedules)

    def __len__(self):
        return len(self.schedules)

    def __getitem__(self, index):
        return self.schedules[index]
