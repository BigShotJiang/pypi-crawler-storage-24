"""
SchedulerModule for managing agent schedules
"""

from typing import Optional, TYPE_CHECKING
from lyzr.base import BaseModule
from lyzr.scheduler.models import Schedule, ScheduleCreate, ScheduleList

if TYPE_CHECKING:
    from lyzr.urls import ServiceURLs


class SchedulerModule(BaseModule):
    """
    Module for managing agent cron schedules

    Can be used standalone or through Studio client.

    Example (Standalone):
        >>> from lyzr.http import HTTPClient
        >>> from lyzr.urls import get_urls
        >>> from lyzr.scheduler import SchedulerModule
        >>> http = HTTPClient(api_key="sk-xxx")
        >>> scheduler = SchedulerModule(http, get_urls("prod"))
        >>> schedule = scheduler.create(
        ...     user_id="user_123",
        ...     agent_id="agent_abc",
        ...     cron_expression="0 9 * * *",
        ... )

    Example (Through Studio):
        >>> from lyzr import Studio
        >>> studio = Studio(api_key="sk-xxx")
        >>> schedule = studio.create_schedule(
        ...     user_id="user_123",
        ...     agent_id="agent_abc",
        ...     cron_expression="0 9 * * *",
        ... )
    """

    def __init__(self, api_key: str, env_config: "ServiceURLs"):
        """
        Initialize SchedulerModule

        Args:
            api_key: Lyzr API key
            env_config: Environment URL configuration
        """
        from lyzr.http import HTTPClient

        self._http = HTTPClient(
            api_key=api_key,
            base_url=env_config.scheduler_api,
            timeout=30,
        )

    # ========================================================================
    # Sync Methods
    # ========================================================================

    def create(
        self,
        user_id: str,
        agent_id: str,
        cron_expression: str,
        message: str = "",
        timezone: str = "UTC",
        max_retries: int = 3,
        retry_delay: int = 60,
    ) -> Schedule:
        """
        Create a new agent schedule

        Args:
            user_id: User ID for agent execution
            agent_id: Agent ID to execute on schedule
            cron_expression: 5-field cron expression (minute hour day month weekday).
                e.g. "0 9 * * *" = 9 AM daily, "*/15 * * * *" = every 15 minutes.
                Supports standard cron syntax: *, */n, n-m, n,m,k.
            message: Message to send to the agent on each run
            timezone: IANA timezone for the cron expression (default: "UTC").
                e.g. "America/New_York", "Europe/London", "Asia/Kolkata".
                Full list: https://en.wikipedia.org/wiki/List_of_tz_database_time_zones
            max_retries: Retries on failure, 0-5 (default: 3)
            retry_delay: Seconds between retries, 10-3600 (default: 60)

        Returns:
            Schedule: Created schedule object

        Raises:
            ValidationError: If parameters fail validation (cron format, range checks)
            APIError: If API request fails

        Example:
            >>> schedule = scheduler.create(
            ...     user_id="user_123",
            ...     agent_id="agent_abc",
            ...     cron_expression="0 9 * * *",
            ...     message="Generate daily report",
            ...     timezone="America/New_York",
            ... )
        """
        payload = ScheduleCreate(
            user_id=user_id,
            agent_id=agent_id,
            cron_expression=cron_expression,
            message=message,
            timezone=timezone,
            max_retries=max_retries,
            retry_delay=retry_delay,
        )
        response = self._http.post("/schedules/", json=payload.model_dump())
        return Schedule(**response)

    def get(self, schedule_id: str) -> Schedule:
        """
        Get a schedule by ID

        Args:
            schedule_id: Schedule ID

        Returns:
            Schedule: Schedule object

        Raises:
            NotFoundError: If schedule does not exist
            APIError: If API request fails

        Example:
            >>> schedule = scheduler.get("sched_abc123")
        """
        response = self._http.get(f"/schedules/{schedule_id}")
        return Schedule(**response)

    def list(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        is_active: Optional[bool] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> ScheduleList:
        """
        List schedules with optional filters

        Args:
            user_id: Filter by user ID
            agent_id: Filter by agent ID
            is_active: Filter by active status
            skip: Number of records to skip (pagination)
            limit: Maximum number of records to return (max 100)

        Returns:
            ScheduleList: Paginated list of schedules

        Example:
            >>> schedules = scheduler.list(agent_id="agent_abc")
            >>> for s in schedules:
            ...     print(s.id, s.cron_expression)
        """
        params: dict = {"skip": skip, "limit": limit}
        if user_id is not None:
            params["user_id"] = user_id
        if agent_id is not None:
            params["agent_id"] = agent_id
        if is_active is not None:
            params["is_active"] = is_active

        response = self._http.get("/schedules/", params=params)
        if isinstance(response, dict):
            return ScheduleList(**response)
        return ScheduleList(schedules=response, total=len(response))

    def delete(self, schedule_id: str) -> bool:
        """
        Delete a schedule

        Args:
            schedule_id: Schedule ID

        Returns:
            bool: True if deleted successfully

        Raises:
            NotFoundError: If schedule does not exist
            APIError: If API request fails

        Example:
            >>> scheduler.delete("sched_abc123")
        """
        return self._http.delete(f"/schedules/{schedule_id}")

    def pause(self, schedule_id: str) -> Schedule:
        """
        Pause an active schedule

        Args:
            schedule_id: Schedule ID

        Returns:
            Schedule: Updated schedule with is_active=False

        Raises:
            NotFoundError: If schedule does not exist
            APIError: If API request fails

        Example:
            >>> schedule = scheduler.pause("sched_abc123")
        """
        response = self._http.post(f"/schedules/{schedule_id}/pause", json={})
        return Schedule(**response)

    def resume(self, schedule_id: str) -> Schedule:
        """
        Resume a paused schedule

        Args:
            schedule_id: Schedule ID

        Returns:
            Schedule: Updated schedule with is_active=True

        Raises:
            NotFoundError: If schedule does not exist
            APIError: If API request fails

        Example:
            >>> schedule = scheduler.resume("sched_abc123")
        """
        response = self._http.post(f"/schedules/{schedule_id}/resume", json={})
        return Schedule(**response)

    def trigger(self, schedule_id: str) -> bool:
        """
        Trigger a schedule to run immediately (one-off execution)

        Args:
            schedule_id: Schedule ID

        Returns:
            bool: True if triggered successfully (202 Accepted)

        Raises:
            NotFoundError: If schedule does not exist
            APIError: If API request fails

        Example:
            >>> scheduler.trigger("sched_abc123")
        """
        self._http.post(f"/schedules/{schedule_id}/trigger", json={})
        return True

    # ========================================================================
    # Async Methods
    # ========================================================================

    async def acreate(
        self,
        user_id: str,
        agent_id: str,
        cron_expression: str,
        message: str = "",
        timezone: str = "UTC",
        max_retries: int = 3,
        retry_delay: int = 60,
    ) -> Schedule:
        """Async create a new agent schedule"""
        self._ensure_async()
        payload = ScheduleCreate(
            user_id=user_id,
            agent_id=agent_id,
            cron_expression=cron_expression,
            message=message,
            timezone=timezone,
            max_retries=max_retries,
            retry_delay=retry_delay,
        )
        response = await self._async_http.post("/schedules/", json=payload.model_dump())
        return Schedule(**response)

    async def aget(self, schedule_id: str) -> Schedule:
        """Async get a schedule by ID"""
        self._ensure_async()
        response = await self._async_http.get(f"/schedules/{schedule_id}")
        return Schedule(**response)

    async def alist(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        is_active: Optional[bool] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> ScheduleList:
        """Async list schedules with optional filters"""
        self._ensure_async()
        params: dict = {"skip": skip, "limit": limit}
        if user_id is not None:
            params["user_id"] = user_id
        if agent_id is not None:
            params["agent_id"] = agent_id
        if is_active is not None:
            params["is_active"] = is_active

        response = await self._async_http.get("/schedules/", params=params)
        if isinstance(response, dict):
            return ScheduleList(**response)
        return ScheduleList(schedules=response, total=len(response))

    async def adelete(self, schedule_id: str) -> bool:
        """Async delete a schedule"""
        self._ensure_async()
        return await self._async_http.delete(f"/schedules/{schedule_id}")

    async def apause(self, schedule_id: str) -> Schedule:
        """Async pause an active schedule"""
        self._ensure_async()
        response = await self._async_http.post(f"/schedules/{schedule_id}/pause", json={})
        return Schedule(**response)

    async def aresume(self, schedule_id: str) -> Schedule:
        """Async resume a paused schedule"""
        self._ensure_async()
        response = await self._async_http.post(f"/schedules/{schedule_id}/resume", json={})
        return Schedule(**response)

    async def atrigger(self, schedule_id: str) -> bool:
        """Async trigger a schedule to run immediately"""
        self._ensure_async()
        await self._async_http.post(f"/schedules/{schedule_id}/trigger", json={})
        return True
