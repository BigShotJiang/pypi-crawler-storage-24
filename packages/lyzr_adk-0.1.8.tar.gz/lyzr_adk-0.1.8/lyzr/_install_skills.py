"""
LYZR Skills Installer
─────────────────────
Interactive CLI that copies LYZR Agent Skills into AI-powered
IDEs and coding agents (Cursor, Claude Code, Windsurf, VS Code, etc.)

Run with:   lyzr-install-skills
Or Python:  python -m lyzr._install_skills

Flags:
    --yes     Skip all prompts, install to all detected IDEs (project scope, copy)
    --refresh Re-clone the skills repo (use when the repo or skills list changed)
"""

import argparse
import os
import re
import shutil
import subprocess
import sys
import warnings
from pathlib import Path

warnings.filterwarnings(
    "ignore",
    message=".*model_.*",
    category=UserWarning,
    module="pydantic._internal._fields",
)

_IS_WINDOWS = sys.platform == "win32"

if _IS_WINDOWS:
    import msvcrt
else:
    import termios
    import tty

from lyzr._skills_detector import (
    IDETarget,
    all_targets,
    detect_installed,
    resolve_install_path,
)

# ─────────────────────────────────────────────
#  ANSI colours & formatting
# ─────────────────────────────────────────────

RESET   = "\033[0m"
BOLD    = "\033[1m"
DIM     = "\033[2m"

WHITE   = "\033[97m"
CYAN    = "\033[96m"
GREEN   = "\033[92m"
YELLOW  = "\033[93m"
RED     = "\033[91m"
GRAY    = "\033[90m"


def c(text: str, *codes: str) -> str:
    """Wrap text with ANSI codes (auto-reset)."""
    if not _supports_ansi():
        return text
    return "".join(codes) + text + RESET


def _supports_ansi() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


# ─────────────────────────────────────────────
#  Skills repo: clone/pull from GitHub, cache path from env
# ─────────────────────────────────────────────

SKILLS_SUBDIR = "skills"
DEFAULT_SKILLS_REPO_URL = "https://github.com/NeuralgoLyzr/lyzr-ide-skills.git"


def _get_repo_url() -> str:
    url = DEFAULT_SKILLS_REPO_URL.rstrip("/")
    for suffix in ("/skills", "/skill"):
        if url.endswith(suffix):
            url = url[: -len(suffix)]
            break
    return url


def _get_cache_dir() -> Path:
    raw = os.environ.get("LYZR_SKILLS_CACHE", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    return (Path.home() / ".lyzr" / "ide_skills_repo").resolve()


def _normalize_git_url(url: str) -> str:
    u = url.strip().rstrip("/").lower()
    if u.endswith(".git"):
        u = u[:-4]
    return u


def ensure_skills_cache(refresh: bool = False) -> Path:
    """
    Clone or pull the IDE skills repo into the cache dir. If the repo has a
    'skills' subfolder (with lyzr-agent, lyzr-rag, etc.), that is used;
    otherwise the repo root is the skills root.
    When refresh is True, the cache dir is removed and re-cloned.
    """
    repo_url = _get_repo_url()
    cache_dir = _get_cache_dir()
    git_dir = cache_dir / ".git"
    if refresh and git_dir.is_dir():
        shutil.rmtree(cache_dir, ignore_errors=True)
    cache_dir.mkdir(parents=True, exist_ok=True)
    if not git_dir.is_dir():
        r = subprocess.run(
            ["git", "clone", "--depth", "1", repo_url, str(cache_dir)],
            capture_output=True,
            text=True,
        )
        if r.returncode != 0:
            raise RuntimeError(
                f"Failed to clone skills repo: {r.stderr or r.stdout or 'unknown'}"
            )
    else:
        want_url = _normalize_git_url(repo_url)
        r = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=cache_dir,
            capture_output=True,
            text=True,
        )
        current_url = _normalize_git_url(r.stdout.strip()) if r.returncode == 0 else ""
        if current_url != want_url:
            subprocess.run(
                ["git", "remote", "set-url", "origin", repo_url],
                cwd=cache_dir,
                capture_output=True,
            )
        r = subprocess.run(
            ["git", "fetch", "origin", "--depth", "1"],
            cwd=cache_dir,
            capture_output=True,
            text=True,
        )
        if r.returncode != 0:
            raise RuntimeError(
                f"Failed to fetch skills repo: {r.stderr or r.stdout or 'unknown'}"
            )
        r = subprocess.run(
            ["git", "reset", "--hard", "origin/HEAD"],
            cwd=cache_dir,
            capture_output=True,
            text=True,
        )
        if r.returncode != 0:
            r2 = subprocess.run(
                ["git", "branch", "-r", "--format", "%(refname:short)"],
                cwd=cache_dir,
                capture_output=True,
                text=True,
            )
            branch = "main"
            if r2.returncode == 0 and r2.stdout.strip():
                first = r2.stdout.strip().split("\n")[0]
                branch = first.replace("origin/", "")
            subprocess.run(
                ["git", "reset", "--hard", f"origin/{branch}"],
                cwd=cache_dir,
                capture_output=True,
            )
    skills_root = cache_dir / SKILLS_SUBDIR
    if skills_root.is_dir():
        return skills_root
    return cache_dir

def _skill_info_from_skill_md(path: Path) -> tuple[str, str]:
    """Read name and description from SKILL.md frontmatter. Return (name, description)."""
    try:
        text = path.read_text(encoding="utf-8")
    except Exception:
        return path.parent.name, ""
    if not text.startswith("---"):
        return path.parent.name, ""
    parts = text.split("---", 2)
    if len(parts) < 3:
        return path.parent.name, ""
    name_match = re.search(r"^name:\s*(.+)$", parts[1], re.MULTILINE)
    desc_match = re.search(r"^description:\s*(.+)$", parts[1], re.MULTILINE)
    name = (name_match.group(1).strip() if name_match else path.parent.name).strip('"\'')
    desc = (desc_match.group(1).strip() if desc_match else "").strip('"\'')
    return name, desc


def get_skills_to_install(skills_source: Path) -> list[dict]:
    """
    Discover all skill folders from skills_source (any subdir with SKILL.md).
    Name and description come from each skill's SKILL.md frontmatter.
    """
    if not skills_source.is_dir():
        return []
    out = []
    for sub in sorted(skills_source.iterdir()):
        if not sub.is_dir():
            continue
        skill_md = sub / "SKILL.md"
        if not skill_md.is_file():
            continue
        name, desc = _skill_info_from_skill_md(skill_md)
        out.append({"folder": sub.name, "name": name, "description": desc or ""})
    return out


# ─────────────────────────────────────────────
#  UI Components
# ─────────────────────────────────────────────

def print_header():
    """Print the wizard header banner."""
    width = 60
    bar = "\u2500" * width

    print()
    print(c(f"  \u250c{bar}\u2510", CYAN))
    print(c(f"  \u2502", CYAN) + c(f"{'':^{width}}", CYAN) + c("\u2502", CYAN))
    print(c(f"  \u2502", CYAN) +
          c(f"{'LYZR Skills Installer':^{width}}", BOLD + CYAN) +
          c("\u2502", CYAN))
    print(c(f"  \u2502", CYAN) +
          c(f"{'Agent Skills for AI-powered IDEs':^{width}}", DIM + WHITE) +
          c("\u2502", CYAN))
    print(c(f"  \u2502", CYAN) + c(f"{'':^{width}}", CYAN) + c("\u2502", CYAN))
    print(c(f"  \u2514{bar}\u2518", CYAN))
    print()
    print(c("  This wizard installs LYZR Agent Skills into your AI IDEs.", DIM + WHITE))
    print(c("  Skills give coding agents step-by-step LYZR SDK guidance.", DIM + WHITE))
    print()


def print_skills_list(skills_source: Path):
    """Print the skills that will be installed (discovered from source)."""
    skills = get_skills_to_install(skills_source)
    print(c("  Skills included:", BOLD + WHITE))
    print()
    for s in skills:
        print(f"    {c('*', GREEN)}  {c(s['name'], BOLD + WHITE)}")
        print(f"       {c(s.get('description', ''), GRAY)}")
    print()


def checkbox_select(
    prompt: str,
    options: list,
    detected_keys: set,
) -> list:
    """
    Interactive checkbox list. Returns list of selected keys.
    Uses numbered input for cross-platform reliability.
    """
    print(f"\n  {c('>', YELLOW)}  {c(prompt, BOLD + WHITE)}\n")

    for i, opt in enumerate(options):
        is_detected = opt["key"] in detected_keys
        badge = c(" (detected)", DIM + GREEN) if is_detected else ""
        num = c(f"  {i + 1}.", CYAN + BOLD)
        name = c(opt["name"], WHITE)
        print(f"   {num} {name}{badge}")

    print(f"\n     {c('Enter numbers separated by commas (e.g. 1,3)', DIM + GRAY)}")
    print(f"     {c('Press Enter for detected IDEs only', DIM + GRAY)}")

    while True:
        try:
            raw = input(f"\n  {c('>', CYAN + BOLD)} ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\n  Cancelled.\n")
            sys.exit(0)

        if not raw:
            selected = [o["key"] for o in options if o["key"] in detected_keys]
            if selected:
                return selected
            print(c("    No IDEs detected — please enter numbers manually.", YELLOW))
            continue

        try:
            indices = [int(x.strip()) for x in raw.split(",")]
            selected = []
            for idx in indices:
                if 1 <= idx <= len(options):
                    selected.append(options[idx - 1]["key"])
                else:
                    raise ValueError
            if selected:
                return selected
            print(c("    Please select at least one option.", RED))
        except ValueError:
            print(c(f"    Invalid input. Enter numbers 1-{len(options)} separated by commas.", RED))


def radio_select(prompt: str, options: list) -> str:
    """
    Interactive radio (single-select). Returns selected key.
    Uses numbered input for cross-platform reliability.
    """
    print(f"\n  {c('>', YELLOW)}  {c(prompt, BOLD + WHITE)}\n")

    for i, (key, label) in enumerate(options):
        num = c(f"  {i + 1}.", CYAN + BOLD)
        name = c(label, WHITE)
        print(f"   {num} {name}")

    print(f"\n     {c('Enter number (default: 1)', DIM + GRAY)}")

    while True:
        try:
            raw = input(f"\n  {c('>', CYAN + BOLD)} ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n\n  Cancelled.\n")
            sys.exit(0)

        if not raw:
            return options[0][0]

        try:
            idx = int(raw)
            if 1 <= idx <= len(options):
                return options[idx - 1][0]
            raise ValueError
        except ValueError:
            print(c(f"    Invalid input. Enter a number 1-{len(options)}.", RED))


def confirm(prompt: str, default: bool = True) -> bool:
    """Simple yes/no prompt."""
    hint = "[Y/n]" if default else "[y/N]"
    try:
        raw = input(f"\n  {c('>', YELLOW)}  {c(prompt, BOLD + WHITE)}  {c(hint, DIM + GRAY)} ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        print("\n\n  Cancelled.\n")
        sys.exit(0)

    if not raw:
        return default
    return raw in ("y", "yes")


# ─────────────────────────────────────────────
#  Installation logic
# ─────────────────────────────────────────────

def install_skills(targets: list, scope: str, use_symlink: bool, skills_source: Path) -> dict:
    """
    Copy (or symlink) all LYZR skill folders into each target's install path.
    Returns dict of {target_key: True} or {target_key: False} with optional error message.
    """
    results = {}
    if not skills_source.is_dir():
        for t in targets:
            results[t.key] = False
        results["_last_error"] = f"Skills source not found: {skills_source}"
        return results

    for target in targets:
        install_dir = resolve_install_path(target, scope)
        if install_dir is None:
            results[target.key] = False
            continue

        try:
            install_dir = install_dir.expanduser().resolve()
            install_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            results[target.key] = False
            results["_last_error"] = str(e)
            continue

        success = True
        last_error = None
        skills_list = get_skills_to_install(skills_source)
        for skill in skills_list:
            src = skills_source / skill["folder"]
            dst = install_dir / skill["folder"]
            if not src.is_dir():
                last_error = f"Source not found: {src}"
                success = False
                break
            try:
                if dst.exists() or dst.is_symlink():
                    if dst.is_symlink():
                        dst.unlink()
                    elif dst.is_dir():
                        shutil.rmtree(dst)

                if use_symlink:
                    try:
                        dst.symlink_to(src.resolve())
                    except OSError as e:
                        last_error = str(e)
                        shutil.copytree(src, dst)
                else:
                    shutil.copytree(src, dst)
            except Exception as e:
                last_error = str(e)
                success = False
                break

        results[target.key] = success
        if not success and last_error:
            results["_last_error"] = last_error

    return results


def print_summary(selected_targets: list, scope: str, use_symlink: bool):
    """Print the installation summary box before confirming."""
    method = "Copy (real folders)" if not use_symlink else "Symlink (may show as alias on macOS)"
    scope_label = "Global (user-level)" if scope == "global" else "Project (current directory)"

    print(c("  Installation Summary", BOLD + CYAN))
    print(c("  " + "\u2500" * 50, CYAN))
    print()
    print(f"    {c('Scope:', DIM + WHITE)}    {c(scope_label, WHITE)}")
    print(f"    {c('Method:', DIM + WHITE)}   {c(method, WHITE)}")
    print()
    print(f"    {c('IDEs:', DIM + WHITE)}")
    for t in selected_targets:
        path = resolve_install_path(t, scope)
        path_str = str(path) if path else "unknown path"
        print(f"      {c('*', GREEN)}  {c(t.name, WHITE)}")
        print(f"         {c(path_str, GRAY)}")
    print()


# ─────────────────────────────────────────────
#  Non-interactive install (--yes or non-TTY)
# ─────────────────────────────────────────────

def auto_install(refresh: bool = False):
    """Install to all detected IDEs without prompts. Used by --yes flag and non-TTY."""
    try:
        skills_source = ensure_skills_cache(refresh=refresh)
    except RuntimeError as e:
        print(c(f"  {e}\n", RED))
        return False

    targets = detect_installed(all_targets())
    detected = [t for t in targets if t.detected]

    print(c("\n  LYZR Skills Installer (auto mode)\n", BOLD + CYAN))

    if not detected:
        print(c("  No supported AI IDEs detected.", YELLOW))
        print(c("  Run 'lyzr-install-skills' in a terminal for manual setup.\n", DIM))
        sys.exit(1)

    print(c(f"  Installing to {len(detected)} detected IDE(s)...\n", WHITE))
    results = install_skills(detected, scope="project", use_symlink=False, skills_source=skills_source)

    for t in detected:
        ok = results.get(t.key, False)
        icon = c("[OK]", GREEN) if ok else c("[FAIL]", RED)
        print(f"    {icon}  {t.name}")

    err_msg = results.get("_last_error")
    if err_msg:
        print(c(f"  Error: {err_msg}\n", RED + DIM))

    ok_count = sum(1 for k, v in results.items() if k != "_last_error" and v is True)
    fail_count = len(detected) - ok_count

    print()
    if fail_count == 0:
        print(c("  All skills installed successfully!\n", GREEN + BOLD))
    else:
        print(c(f"  {ok_count} succeeded, {fail_count} failed.\n", YELLOW))

    return fail_count == 0


# ─────────────────────────────────────────────
#  Main wizard
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="lyzr-install-skills",
        description="Install LYZR Agent Skills into AI-powered IDEs",
    )
    parser.add_argument(
        "--yes", "-y",
        action="store_true",
        help="Skip prompts — install to all detected IDEs (project scope, copy)",
    )
    parser.add_argument(
        "--refresh", "-r",
        action="store_true",
        help="Delete local skills cache and re-clone from the repo (use when repo or skills changed)",
    )
    args = parser.parse_args()

    # Auto mode: --yes flag or non-TTY environment
    if args.yes or not sys.stdin.isatty() or not sys.stdout.isatty():
        success = auto_install(refresh=args.refresh)
        sys.exit(0 if success else 1)

    try:
        skills_source = ensure_skills_cache(refresh=args.refresh)
    except RuntimeError as e:
        print(c(f"  {e}\n", RED))
        sys.exit(1)

    # ── Interactive wizard ─────────────────────────
    print_header()
    print_skills_list(skills_source)

    # ── Detect IDEs ────────────────────────────────
    print(c("  Scanning for AI IDEs...", DIM + WHITE))
    targets = detect_installed(all_targets())
    detected_keys = {t.key for t in targets if t.detected}
    detected_count = len(detected_keys)

    if detected_count:
        print(c(f"  Found {detected_count} AI IDE(s) on your system\n", GREEN))
    else:
        print(c("  No IDEs detected automatically — you can still select manually\n", YELLOW))

    # ── Select IDEs ────────────────────────────────
    ide_options = [{"key": t.key, "name": t.name} for t in targets]

    selected_keys = checkbox_select(
        prompt=f"Which IDEs should get LYZR skills?  ({detected_count} detected)",
        options=ide_options,
        detected_keys=detected_keys,
    )

    selected_targets = [t for t in targets if t.key in selected_keys]

    # ── Scope ──────────────────────────────────────
    scope = radio_select(
        prompt="Installation scope",
        options=[
            ("project", "Project  (current directory — committed with your repo)"),
            ("global",  "Global   (your home directory — available everywhere)"),
        ],
    )

    # ── Method ─────────────────────────────────────
    method_key = radio_select(
        prompt="Installation method",
        options=[
            ("copy",    "Copy     (recommended — real folders, works everywhere)"),
            ("symlink", "Symlink  (skills update with SDK; may show as alias on macOS)"),
        ],
    )
    use_symlink = method_key == "symlink"

    # ── Summary ────────────────────────────────────
    print_summary(selected_targets, scope, use_symlink)

    # ── Confirm ────────────────────────────────────
    go = confirm("Proceed with installation?", default=True)
    if not go:
        print(c("  Cancelled. No files were changed.\n", GRAY))
        return

    # ── Install ────────────────────────────────────
    print(c("\n  Installing skills...\n", BOLD + CYAN))
    results = install_skills(selected_targets, scope, use_symlink, skills_source)

    ok_count = sum(1 for k, v in results.items() if k != "_last_error" and v is True)
    fail_count = len(selected_targets) - ok_count

    for t in selected_targets:
        ok = results.get(t.key, False)
        icon = c("[OK]", GREEN + BOLD) if ok else c("[FAIL]", RED + BOLD)
        path = resolve_install_path(t, scope)
        path_str = c(str(path), GRAY) if path else ""
        print(f"    {icon}  {c(t.name, WHITE)}  {path_str}")

    if results.get("_last_error"):
        print(c(f"\n  Error: {results['_last_error']}", RED + DIM))

    print()

    if fail_count == 0:
        print(c("  All skills installed successfully!\n", GREEN + BOLD))
    else:
        print(c(f"  {ok_count} succeeded, {fail_count} failed.\n", YELLOW))

    print(c("  Skills installed:", BOLD + WHITE))
    for s in get_skills_to_install(skills_source):
        print(f"    {c('*', CYAN)}  {c(s['name'], WHITE)} — {c(s['description'], GRAY)}")

    print()
    print(c("  Your AI IDE will auto-discover these skills at startup.", DIM + WHITE))
    print(c("  Try asking 'create a lyzr agent' in your IDE to get started!\n", DIM + WHITE))
    print(c("  Docs: docs.lyzr.ai", DIM + WHITE))
    print()


if __name__ == "__main__":
    main()
