import os

def _find_first_nonempty(paths):
    """Return the first path that exists and has size > 0, or None."""
    for p in paths:
        try:
            if os.path.exists(p) and os.path.getsize(p) > 0:
                return p
        except Exception:
            pass
    return None

def _format_time(seconds):
    """Human-readable time duration."""
    if seconds < 1:       return "<1 second"
    elif seconds < 60:    return f"{seconds:.1f} seconds"
    elif seconds < 3600:  return f"{seconds/60:.1f} minutes"
    elif seconds < 86400: return f"{seconds/3600:.1f} hours"
    else:                 return f"{seconds/86400:.1f} days"
