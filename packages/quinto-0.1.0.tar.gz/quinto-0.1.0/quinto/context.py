
from dataclasses import dataclass

@dataclass
class CrackContext:
    patience: str = "normal"
    gpu_flags: list = None
    available_wl: dict = None

    @property
    def patience_level(self) -> int:
        return {"quick": 1, "normal": 2, "patient": 3}[self.patience]
    