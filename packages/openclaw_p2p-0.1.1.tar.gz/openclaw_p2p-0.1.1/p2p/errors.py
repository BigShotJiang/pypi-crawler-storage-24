"""Custom exceptions for openclaw-p2p."""


class A2AError(Exception):
    """Base exception for all P2P errors."""


class PeerUnreachable(A2AError):
    def __init__(self, peer_id: str, reason: str = "") -> None:
        self.peer_id = peer_id
        msg = f"Peer unreachable: {peer_id}"
        if reason:
            msg += f" ({reason})"
        super().__init__(msg)


class HandshakeFailed(A2AError):
    def __init__(self, peer_id: str, phase: str, reason: str = "") -> None:
        self.peer_id = peer_id
        self.phase = phase
        msg = f"Handshake failed with {peer_id} at '{phase}'"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class HandshakeTimeout(HandshakeFailed):
    def __init__(self, peer_id: str, phase: str) -> None:
        super().__init__(peer_id, phase, reason="timeout")


class CryptoError(A2AError):
    """Cryptographic operation failed."""


class ProtocolError(A2AError):
    """Wire-protocol violation."""


class PeerRejected(A2AError):
    def __init__(self, peer_id: str) -> None:
        self.peer_id = peer_id
        super().__init__(f"Connection rejected by {peer_id}")
