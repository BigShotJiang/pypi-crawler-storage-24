"""A2AEnvelope — wire-level message wrapper."""

from __future__ import annotations

import time
import uuid

from pydantic import BaseModel, Field


class A2AEnvelope(BaseModel):
    version: int = 1
    id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    sender_id: str = ""
    recipient_id: str = ""
    timestamp: float = Field(default_factory=time.time)
    type: str  # MessageType value
    payload: dict = Field(default_factory=dict)
    in_reply_to: str = ""
    signature_hex: str = ""

    def signing_material(self) -> bytes:
        import msgpack
        return (
            self.id.encode() + self.type.encode()
            + msgpack.packb(self.payload, use_bin_type=True)
        )
