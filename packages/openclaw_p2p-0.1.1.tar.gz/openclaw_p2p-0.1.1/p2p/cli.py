"""CLI entry points."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def keygen() -> None:
    """Generate a new P2P identity keypair."""
    p = argparse.ArgumentParser(description="Generate P2P identity")
    p.add_argument("-d", "--dir", default="~/.p2p/identity")
    p.add_argument("-p", "--passphrase", default="")
    p.add_argument("-f", "--force", action="store_true")
    a = p.parse_args()

    from p2p.identity import PeerIdentity

    d = Path(a.dir).expanduser()
    if (d / "private.pem").exists() and not a.force:
        identity = PeerIdentity.load(d, a.passphrase)
        print(f"Exists: {identity.peer_id}")
        print(f"Use --force to regenerate")
        sys.exit(0)

    identity = PeerIdentity.generate()
    identity.save(d, a.passphrase)
    print(f"PeerID: {identity.peer_id}")
    print(f"Keys:   {d}/")
