"""Configuration for P2P nodes."""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field


class A2AConfig(BaseModel):
    """Node configuration."""

    # Identity
    identity_dir: Path = Field(default=Path("~/.p2p/identity"))
    identity_passphrase: str = ""

    # Networking
    listen_host: str = "0.0.0.0"
    listen_port: int = 9090
    relay_addresses: list[str] = Field(default_factory=list)
    register_with_relays: bool = True

    # Peer store
    peer_store_path: Path = Field(default=Path("~/.p2p/peers.json"))

    # Timeouts
    handshake_timeout_seconds: float = 30.0
    owner_approval_timeout_seconds: float = 259200.0  # 72h
    owner_reminder_seconds: float = 86400.0  # 24h
    reconnect_interval_seconds: float = 30.0
    keepalive_interval_seconds: float = 30.0

    # Limits
    max_connections: int = 50
    max_message_size_bytes: int = 10 * 1024 * 1024  # 10MB

    def resolve_paths(self) -> None:
        """Expand ~ in all path fields."""
        self.identity_dir = self.identity_dir.expanduser()
        self.peer_store_path = self.peer_store_path.expanduser()
