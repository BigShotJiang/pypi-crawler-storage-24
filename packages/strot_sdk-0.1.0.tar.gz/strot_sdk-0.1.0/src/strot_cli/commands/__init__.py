"""STROT CLI commands."""
