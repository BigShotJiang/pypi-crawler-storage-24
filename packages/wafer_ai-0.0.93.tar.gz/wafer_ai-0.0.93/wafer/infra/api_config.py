"""API configuration: environment presets, URL resolution, Supabase config.

Extracted from wafer.cli.global_config so that core code can resolve API URLs
without depending on the CLI package.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import tomllib

CONFIG_DIR = Path.home() / ".wafer"
CONFIG_FILE = CONFIG_DIR / "config.toml"

EnvironmentName = Literal["staging", "prod", "local"]


@dataclass(frozen=True)
class ApiEnvironment:
    """API environment configuration. Immutable."""
    name: str
    api_url: str
    supabase_url: str
    supabase_anon_key: str

    def __post_init__(self) -> None:
        assert self.name, "environment name cannot be empty"
        assert self.api_url, "api_url cannot be empty"
        assert self.supabase_url, "supabase_url cannot be empty"
        assert self.supabase_anon_key, "supabase_anon_key cannot be empty"


BUILTIN_ENVIRONMENTS: dict[str, ApiEnvironment] = {
    "staging": ApiEnvironment(
        name="staging",
        api_url="https://wafer-api-staging.onrender.com",
        supabase_url="https://xudshwhzytyfxwwyofli.supabase.co",
        supabase_anon_key="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh1ZHNod2h6eXR5Znh3d3lvZmxpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU4Mzc5MDEsImV4cCI6MjA4MTQxMzkwMX0.JvuF4349z1ermKmrxEKGDHQj9I_ylLZYjjuouJleYhY",
    ),
    "prod": ApiEnvironment(
        name="prod",
        api_url="https://www.api.wafer.ai",
        supabase_url="https://auth.wafer.ai",
        supabase_anon_key="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh2bHB0aGNueGx5d2xxdWljaXFlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ2MjQ1NTIsImV4cCI6MjA4MDIwMDU1Mn0.1ywPDp-QHgbqPOJocQvXEKKDjGt3BsoNluvVoQ7EW3o",
    ),
    "local": ApiEnvironment(
        name="local",
        api_url="http://localhost:8000",
        supabase_url="http://localhost:54321",
        supabase_anon_key="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0",
    ),
}

DEFAULT_ENVIRONMENT = "prod"


@dataclass(frozen=True)
class GlobalConfig:
    """Global Wafer configuration. Immutable."""
    environment: str = DEFAULT_ENVIRONMENT
    environments: dict[str, ApiEnvironment] = field(
        default_factory=lambda: BUILTIN_ENVIRONMENTS.copy()
    )

    def __post_init__(self) -> None:
        assert self.environment in self.environments, (
            f"environment '{self.environment}' not found. "
            f"Available: {list(self.environments.keys())}"
        )

    def get_api_environment(self) -> ApiEnvironment:
        """Get the current API environment."""
        return self.environments[self.environment]

    @property
    def api_url(self) -> str:
        return self.get_api_environment().api_url

    @property
    def supabase_url(self) -> str:
        return self.get_api_environment().supabase_url


def _parse_api_config(path: Path) -> GlobalConfig:
    """Parse API-relevant config from TOML file."""
    with open(path, "rb") as f:
        data = tomllib.load(f)

    api_data = data.get("api", {})
    environment = api_data.get("environment", DEFAULT_ENVIRONMENT)

    environments = BUILTIN_ENVIRONMENTS.copy()
    user_envs = api_data.get("environments", {})
    for name, env_config in user_envs.items():
        if isinstance(env_config, dict):
            base_env = environments.get(name, BUILTIN_ENVIRONMENTS["prod"])
            environments[name] = ApiEnvironment(
                name=name,
                api_url=env_config.get("url", base_env.api_url),
                supabase_url=env_config.get("supabase_url", base_env.supabase_url),
                supabase_anon_key=env_config.get("supabase_anon_key", base_env.supabase_anon_key),
            )

    return GlobalConfig(environment=environment, environments=environments)


_cached_config: GlobalConfig | None = None


def _load_config() -> GlobalConfig:
    """Load API config from file (cached)."""
    global _cached_config
    if _cached_config is not None:
        return _cached_config
    if CONFIG_FILE.exists():
        config = _parse_api_config(CONFIG_FILE)
    else:
        config = GlobalConfig()
    _cached_config = config
    return config


def clear_config_cache() -> None:
    """Clear cached config. Useful after config changes."""
    global _cached_config
    _cached_config = None


def get_api_url() -> str:
    """Get API URL with env var override."""
    env_url = os.environ.get("WAFER_API_URL")
    if env_url:
        return env_url.rstrip("/")
    return _load_config().api_url


def get_supabase_url() -> str:
    """Get Supabase URL with env var override."""
    env_url = os.environ.get("SUPABASE_URL")
    if env_url:
        return env_url
    return _load_config().supabase_url


def get_supabase_anon_key() -> str:
    """Get Supabase anon key for current environment."""
    return _load_config().get_api_environment().supabase_anon_key
