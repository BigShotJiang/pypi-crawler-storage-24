---
name: wafer-guide
description: Accelerator kernel development with the Wafer CLI. Supports NVIDIA, AMD, Trainium, TPU. Use for CUDA/HIP kernels, profiling, or optimizing kernel performance.
---
<!-- AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
     Regenerate with: just generate-skill
     Source template: SKILL.md.template -->

# Wafer CLI — Quick Reference

Accelerator development primitives for optimizing CUDA and HIP kernels. Supports NVIDIA, AMD, Trainium, TPU, and other accelerators for target configuration and execution.

## Installation

```bash
uv tool install wafer-ai

# Authenticate (one-time setup)
wafer login

# Register SSH keys (required before using workspaces)
wafer settings ssh-keys add
```

## Core Commands

- `wafer tool eval --task <name>` — test kernel correctness + benchmark speedup
- `wafer tool rocprof-compute` / `rocprof-sdk` / `rocprof-systems` — AMD profiling
- `wafer target init workspace` / `wafer target sync` / `wafer target ssh` — cloud GPU workspaces (sandbox is SSH-only)
- `wafer agent -t trace-analyze` — GPU trace analysis (single-turn, read-only)
- `wafer target init` — configure GPU targets

## Detailed Guides

Load these with the `read` tool from the sub-guides directory below:
- `evaluate.md` — evaluation workflows, workspace+evaluate integration, target config
- `profiling.md` — trace analysis, docs lookup
- `workspaces.md` — remote execution workflows
- `pitfalls.md` — common mistakes and fixes
- `commands.md` — full auto-generated command reference

## Important

```bash
# Analyze a GPU trace
wafer agent -t trace-analyze "Analyze trace.json — what kernels are slowest?"
```

### 2. Kernel Evaluation

Test correctness and measure speedup against a reference using the unified eval primitive:

```bash
# List available evaluation tasks
wafer tool eval --list-tasks

# Run evaluation for a specific task
wafer tool eval --task kernelbench
wafer tool eval --task gpumode
wafer tool eval --task aiter -- <test_cmd>

# Sync files and run eval on a GPU target (one-shot)
wafer sandbox run --target <target> --sync ./my-kernel -- wafer tool eval --task gpumode

# Re-sync after editing and run again
wafer sandbox run --target <target> --sync ./my-kernel -- wafer tool eval --task kernelbench
```

### 5. Remote Execution (Workspaces)

Run on cloud GPU workspaces:

```bash
# Create a workspace with a specific GPU and environment type
wafer target init workspace my-workspace -g B200 -e baremetal

# List targets (shows SSH connection info: host, port)
wafer target list

# Sync local files to workspace (files land at /workspace/ on remote, NOT /workspace/<name>/)
wafer target sync my-workspace ./local-dir

# SSH into workspace (interactive) — sandbox does NOT support workspaces
wafer target ssh my-workspace
```

**Important: Synced files land at `/workspace/` directly** — not at `/workspace/<workspace-name>/`. For example, if you sync a directory containing `kernel.py`, it will be at `/workspace/kernel.py` on the remote machine.

### 6. SSH Target + Evaluate Integration

Run eval on an SSH target by pushing files then running eval:

```bash
# Step 1: Register SSH target
wafer target init ssh --name my-gpu --host user@host:22

# Step 2: Sync files and run eval
wafer sandbox run --target my-gpu --sync ./my-kernel -- wafer tool eval --task gpumode

# After editing, re-sync and run again
wafer sandbox run --target my-gpu --sync ./my-kernel -- wafer tool eval --task kernelbench
```

**Alternative (one-shot):** Use `--sync` to push + run in one command:

```bash
wafer sandbox run --target my-gpu --sync ./my-kernel -- python run_benchmark.py
```

## Common Pitfalls

| Mistake | Fix |
|---------|-----|
| `wafer tool eval gpumode --impl ...` | Use `wafer tool eval --task gpumode` (unified eval, no old flags) |
| `wafer tool eval --target <name>` | Compose with sandbox run: `wafer sandbox run --target <target> -- wafer tool eval --task <name>` |
| `wafer tool eval make-template` | Removed — no longer available |
| `cd /workspace/my-workspace/` on remote | Synced files land at `/workspace/`, not `/workspace/<name>/` |
| `kernel()` / `reference()` function names | GPUMode format requires `custom_kernel()`, `ref_kernel()`, and `generate_input()` |
| Missing `generate_input` in reference.py | The reference file must export both `ref_kernel` AND `generate_input` |

## Command Reference

{{ COMMAND_REFERENCE }}

## Target Configuration

Targets define GPU access methods. Initialize with:

```bash
wafer target init ssh          # Your own GPU via SSH
wafer target init workspace    # Cloud GPU workspace
```

Then use: `wafer sandbox run --target <name> -- wafer tool eval --task gpumode`
