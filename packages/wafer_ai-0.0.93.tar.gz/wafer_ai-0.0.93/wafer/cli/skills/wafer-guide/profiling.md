# Profiling Workflows

## Trace Analysis with Agent

Analyze GPU traces using the trace-analyze agent template:

```bash
wafer agent -t trace-analyze "Analyze trace.json — what kernels are slowest?"
```
