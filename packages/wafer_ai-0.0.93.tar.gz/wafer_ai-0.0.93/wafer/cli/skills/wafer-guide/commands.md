<!-- AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
     Regenerate with: just generate-skill
     Source template: SKILL.md.template -->

# Command Reference

### `wafer tool eval`
Evaluate kernel correctness and performance

Options:
  --task/-t TEXT  Code scorer name (built-in) or path to .py file (required unless --list-tasks)
  --after/-a PATH  Directory to evaluate (default: current directory)
  --before/-b PATH  Baseline directory for comparison (optional)
  --list-tasks  List available built-in scorers and exit

### `wafer tool`
Run profiling, evaluation, and analysis tools

Subcommands:
  wafer tool eval  Evaluate kernel correctness and performance
  wafer tool tracelens  TraceLens performance reports
  wafer tool compare  Compare GPU traces across platforms (AMD vs NVIDIA)
  wafer tool problems  Download and list kernel optimization problems for wafer tool eval
  wafer tool rocprof-sdk  ROCprofiler-SDK profiling tool commands
  wafer tool rocprof-systems  ROCprofiler-Systems profiling tool commands
  wafer tool rocprof-compute  ROCprofiler-Compute profiling tool commands

### `wafer target`
Set up and manage connections to GPU machines

Subcommands:
  wafer target bootstrap  Install/update wafer-ai on a target.
  wafer target verify  Verify target connectivity
  wafer target list  List all targets with accelerator status
  wafer target show  Show details for a target (workspace or host)
  wafer target remove  Remove a target (workspace or host)
  wafer target ssh  SSH into a target (workspace or host)
  wafer target sync  Sync local files to a target
  wafer target pull  Pull files from a target to local machine
  wafer target init  Initialize a new accelerator target

### `wafer agent`
AI assistant for GPU kernel development

Examples:
    wafer agent                          # interactive TUI
    wafer agent "optimize this kernel"   # with initial prompt
    wafer agent --cloud -t optimize ...  # run on cloud
    wafer agent -s <sandbox-id> -t my-gpu "prompt"  # run in sandbox

Options:
  --interactive/-i  Launch full interactive TUI mode (default when no prompt given)
  --resume/-r TEXT  Resume session by ID (or 'last' for most recent)
  --list-sessions  List recent sessions and exit
  --get-session TEXT  Get session by ID and print details (use with --json for full messages)
  --max-tool-fails INTEGER  Exit after N consecutive tool failures
  --json/-j  Output in JSON format (stream-json style)
  --list-templates  List available templates with descriptions and args, then exit
  --template/-t TEXT  Run with template (use --list-templates to see all available)
  --args TEXT  Template variable (KEY=VALUE, can be repeated)
  --output-format TEXT  Output format: 'stream-json' (Claude Code-compatible NDJSON) or 'chunk' (real-time deltas)
  --cloud  Run agent on remote server via cloud API
  --repo TEXT  Clone repo on cloud server (use with --cloud)
  --dir/-d PATH  Upload local directory to cloud agent (use with --cloud, e.g. --dir . for cwd, respects .gitignore)
  --target TEXT  Run agent directly on a GPU target by name (use with --cloud)
  --sandbox/-s TEXT  Run agent inside a sandbox on a GPU target (direct SSH, no API hop)

### `wafer settings skill`
Manage AI coding assistant skills (Claude Code, Codex)

Subcommands:
  wafer settings skill install  Install the wafer-guide skill for AI coding assistants
  wafer settings skill uninstall  Uninstall the wafer-guide skill
  wafer settings skill status  Show installation status of the wafer-guide skill
