"""Global configuration for Wafer CLI.
Handles API URLs, environment presets (staging/prod/local), and user preferences.
"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import tomllib

from wafer.infra.api_config import (
    clear_config_cache as _clear_core_config_cache,
    BUILTIN_ENVIRONMENTS,
    CONFIG_DIR,
    CONFIG_FILE,
    DEFAULT_ENVIRONMENT,
    ApiEnvironment,
    EnvironmentName,
    get_api_url,
    get_supabase_anon_key,
    get_supabase_url,
)

__all__ = [
    "ApiEnvironment",
    "BUILTIN_ENVIRONMENTS",
    "CONFIG_DIR",
    "CONFIG_FILE",
    "DEFAULT_ENVIRONMENT",
    "Defaults",
    "EnvironmentName",
    "GlobalConfig",
    "Preferences",
    "clear_config_cache",
    "get_api_url",
    "get_defaults",
    "get_preferences",
    "get_supabase_anon_key",
    "get_supabase_url",
    "init_config",
    "load_global_config",
    "save_global_config",
]


@dataclass(frozen=True)
class Preferences:
    """User preferences. Immutable.
    mode: "implicit" (default) = quiet output, use -v for status messages
          "explicit" = verbose output, shows [wafer] status messages
    analytics_enabled: True (default) = send anonymous usage analytics to PostHog
                       False = disable all analytics tracking
    """
    mode: Literal["explicit", "implicit"] = "implicit"
    analytics_enabled: bool = True
    data_retention_enabled: bool = True


@dataclass(frozen=True)
class Defaults:
    """Default values for commands. Immutable."""
    workspace: str | None = None
    repo: str | None = None  # owner/repo for cloud agent
    gpu: str = "B200"
    exec_timeout: int = 300  # seconds


@dataclass(frozen=True)
class GlobalConfig:
    """Global Wafer CLI configuration. Immutable."""
    environment: str = DEFAULT_ENVIRONMENT
    environments: dict[str, ApiEnvironment] = field(
        default_factory=lambda: BUILTIN_ENVIRONMENTS.copy()
    )
    preferences: Preferences = field(default_factory=Preferences)
    defaults: Defaults = field(default_factory=Defaults)

    def __post_init__(self) -> None:
        # Validate environment exists
        assert self.environment in self.environments, (
            f"environment '{self.environment}' not found. "
            f"Available: {list(self.environments.keys())}"
        )

    def get_api_environment(self) -> ApiEnvironment:
        """Get the current API environment."""
        return self.environments[self.environment]

    @property
    def api_url(self) -> str:
        """Get current API URL."""
        return self.get_api_environment().api_url

    @property
    def supabase_url(self) -> str:
        """Get current Supabase URL."""
        return self.get_api_environment().supabase_url


def _parse_config_file(path: Path) -> GlobalConfig:
    """Parse config from TOML file.
    Args:
        path: Path to config file
    Returns:
        GlobalConfig instance
    """
    with open(path, "rb") as f:
        data = tomllib.load(f)

    api_data = data.get("api", {})
    environment = api_data.get("environment", DEFAULT_ENVIRONMENT)
    # Merge built-in environments with user-defined ones
    environments = BUILTIN_ENVIRONMENTS.copy()
    user_envs = api_data.get("environments", {})
    for name, env_config in user_envs.items():
        if isinstance(env_config, dict):
            # User can override built-in or define new
            base_env = environments.get(name, BUILTIN_ENVIRONMENTS["prod"])
            environments[name] = ApiEnvironment(
                name=name,
                api_url=env_config.get("url", base_env.api_url),
                supabase_url=env_config.get("supabase_url", base_env.supabase_url),
                supabase_anon_key=env_config.get("supabase_anon_key", base_env.supabase_anon_key),
            )

    pref_data = data.get("preferences", {})
    mode = pref_data.get("mode", "implicit")
    assert mode in ("explicit", "implicit"), f"mode must be 'explicit' or 'implicit', got '{mode}'"
    analytics_enabled = pref_data.get("analytics_enabled", True)
    assert isinstance(analytics_enabled, bool), f"analytics_enabled must be true or false, got '{analytics_enabled}'"
    data_retention_enabled = pref_data.get("data_retention_enabled", True)
    assert isinstance(data_retention_enabled, bool), f"data_retention_enabled must be true or false, got '{data_retention_enabled}'"
    preferences = Preferences(mode=mode, analytics_enabled=analytics_enabled, data_retention_enabled=data_retention_enabled)

    defaults_data = data.get("defaults", {})
    defaults = Defaults(
        workspace=defaults_data.get("workspace"),
        repo=defaults_data.get("repo"),
        gpu=defaults_data.get("gpu", "B200"),
        exec_timeout=defaults_data.get("exec_timeout", 300),
    )
    return GlobalConfig(
        environment=environment,
        environments=environments,
        preferences=preferences,
        defaults=defaults,
    )


# Cached config instance
_cached_config: GlobalConfig | None = None


def load_global_config() -> GlobalConfig:
    """Load global config from file, with env var overrides.
    Priority (highest to lowest):
    1. Environment variables (WAFER_API_URL, SUPABASE_URL)
    2. Config file (~/.wafer/config.toml)
    3. Built-in defaults (prod environment)
    Returns:
        GlobalConfig instance
    """
    global _cached_config
    if _cached_config is not None:
        return _cached_config
    # Start with defaults
    if CONFIG_FILE.exists():
        config = _parse_config_file(CONFIG_FILE)
    else:
        config = GlobalConfig()
    _cached_config = config
    return config


def get_preferences() -> Preferences:
    """Get user preferences."""
    return load_global_config().preferences


def get_defaults() -> Defaults:
    """Get default values."""
    return load_global_config().defaults


def clear_config_cache() -> None:
    """Clear cached config. Useful after config changes."""
    global _cached_config
    _cached_config = None
    _clear_core_config_cache()


def save_global_config(config: GlobalConfig) -> None:
    """Save config to TOML file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    lines = []
    lines.append("[api]")
    lines.append(f'environment = "{config.environment}"')
    lines.append("")
    for name, env in config.environments.items():
        if name not in BUILTIN_ENVIRONMENTS or env != BUILTIN_ENVIRONMENTS[name]:
            lines.append(f"[api.environments.{name}]")
            lines.append(f'url = "{env.api_url}"')
            lines.append(f'supabase_url = "{env.supabase_url}"')
            lines.append("")
    # Preferences section (only if non-default values)
    pref_lines = []
    if config.preferences.mode != "implicit":
        pref_lines.append(f'mode = "{config.preferences.mode}"')
    if not config.preferences.analytics_enabled:
        pref_lines.append("analytics_enabled = false")
    if not config.preferences.data_retention_enabled:
        pref_lines.append("data_retention_enabled = false")
    if pref_lines:
        lines.append("[preferences]")
        lines.extend(pref_lines)
        lines.append("")
    # Defaults section (only if non-default values)
    defaults_lines = []
    if config.defaults.workspace:
        defaults_lines.append(f'workspace = "{config.defaults.workspace}"')
    if config.defaults.repo:
        defaults_lines.append(f'repo = "{config.defaults.repo}"')
    if config.defaults.gpu != "B200":
        defaults_lines.append(f'gpu = "{config.defaults.gpu}"')
    if config.defaults.exec_timeout != 300:
        defaults_lines.append(f"exec_timeout = {config.defaults.exec_timeout}")
    if defaults_lines:
        lines.append("[defaults]")
        lines.extend(defaults_lines)
        lines.append("")
    CONFIG_FILE.write_text("\n".join(lines))
    clear_config_cache()


def init_config(environment: str = DEFAULT_ENVIRONMENT) -> GlobalConfig:
    """Initialize config file with defaults.
    Args:
        environment: Initial environment to use
    Returns:
        The created GlobalConfig
    """
    config = GlobalConfig(environment=environment)
    save_global_config(config)
    return config
