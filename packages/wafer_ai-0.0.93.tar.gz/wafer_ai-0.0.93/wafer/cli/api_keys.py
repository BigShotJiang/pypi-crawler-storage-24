"""API Keys CLI - Manage API keys for cloud agent backends.

Users store their Anthropic, OpenAI, or Cursor API keys once and they are
auto-injected into cloud agent sandboxes.
"""
from __future__ import annotations

import httpx

from wafer.infra.api_config import get_api_url
from .auth import get_auth_headers


def _get_client() -> tuple[str, dict[str, str]]:
    """Get API URL and auth headers."""
    api_url = get_api_url()
    headers = get_auth_headers()
    assert api_url, "API URL must be configured"
    assert api_url.startswith("http"), "API URL must be a valid HTTP(S) URL"
    return api_url, headers


def set_api_key(provider: str, api_key: str, json_output: bool = False) -> str:
    """Set or update an API key for a provider."""
    api_url, headers = _get_client()
    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.post(
                f"{api_url}/v1/user/api-keys",
                json={"provider": provider, "api_key": api_key},
            )
            response.raise_for_status()
            data = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        try:
            detail = e.response.json().get("detail", e.response.text)
        except (OSError, ValueError, RuntimeError):
            detail = e.response.text
        raise RuntimeError(f"API error: {detail}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e
    if json_output:
        from .output import json_response
        return json_response(data=data)
    return (
        f"[ok] API key saved for {provider}\n"
        f"  Key: {data.get('key_hint', '***')}\n"
        f"  Updated: {data.get('updated_at', '')}"
    )


def list_api_keys(json_output: bool = False) -> str:
    """List all stored API keys (masked)."""
    api_url, headers = _get_client()
    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/user/api-keys")
            response.raise_for_status()
            keys = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e
    if json_output:
        from .output import json_response
        return json_response(data={"api_keys": keys})
    if not keys:
        return (
            "No API keys stored.\n"
            "\n"
            "Add one:\n"
            "  wafer settings api-keys set anthropic <your-key>\n"
            "\n"
            "Providers: anthropic, openai, cursor"
        )
    lines = ["API Keys:"]
    for key in keys:
        provider = key["provider"]
        suffix = key.get("key_suffix", "****")
        lines.append(f"  {provider:<12} ...{suffix}")
    return "\n".join(lines)


def delete_api_key(provider: str, json_output: bool = False) -> str:
    """Delete an API key by provider."""
    api_url, headers = _get_client()
    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.delete(f"{api_url}/v1/user/api-keys/{provider}")
            response.raise_for_status()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 404:
            raise RuntimeError(f"No API key found for provider: {provider}") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e
    if json_output:
        from .output import json_response
        return json_response(data={"provider": provider})
    return f"[ok] API key removed for {provider}"
