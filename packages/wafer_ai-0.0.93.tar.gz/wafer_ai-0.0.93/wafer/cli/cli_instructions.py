"""Helpers for extracting CLI help text from the wafer typer/click command tree.

Walks the command tree and formats --help text for inclusion in agent
system prompts. The CLI --help text is the single source of truth for
both human users and AI agents.
"""
from __future__ import annotations

import re

import click


def _resolve_command(root: click.BaseCommand, parts: list[str]) -> click.BaseCommand | None:
    """Walk the click command tree to find a (sub)command by name parts.
    Args:
        root: The root click command (from typer.main.get_command)
        parts: Command path segments, e.g. ["tool", "eval", "kernelbench"]
    Returns:
        The click command at that path, or None if not found.
    """
    cmd = root
    for part in parts:
        if not isinstance(cmd, click.MultiCommand):
            return None
        ctx = click.Context(cmd, info_name=part)
        child = cmd.get_command(ctx, part)
        if child is None:
            return None
        cmd = child
    return cmd


def _format_command_help(cmd_path: str, cmd: click.BaseCommand) -> str:
    """Format a single command's help text for inclusion in a system prompt.
    Extracts the description and option help text (skipping --help itself).
    """
    lines = [f"### `{cmd_path}`"]
    if cmd.help:
        lines.append(cmd.help.strip())
    option_lines = []
    for param in getattr(cmd, "params", []):
        if not isinstance(param, click.Option):
            continue

        if param.name == "help":
            continue
        name = "/".join(param.opts)
        type_name = param.type.name.upper() if hasattr(param.type, "name") else ""
        help_text = param.help or ""
        is_flag = type_name in ("BOOL", "BOOLEAN") or param.is_flag
        if type_name and not is_flag:
            option_lines.append(f"  {name} {type_name}  {help_text}")
        else:
            option_lines.append(f"  {name}  {help_text}")
    if option_lines:
        lines.append("")
        lines.append("Options:")
        lines.extend(option_lines)
    # List subcommands if this is a group
    if isinstance(cmd, click.MultiCommand):
        ctx = click.Context(cmd, info_name=cmd_path.split()[-1])
        subcmd_names = cmd.list_commands(ctx)
        if subcmd_names:
            subcmd_lines = []
            for name in subcmd_names:
                subcmd = cmd.get_command(ctx, name)
                if subcmd:
                    desc = (subcmd.help or subcmd.short_help or "").strip().split("\n")[0]
                    subcmd_lines.append(f"  {cmd_path} {name}  {desc}")
            if subcmd_lines:
                lines.append("")
                lines.append("Subcommands:")
                lines.extend(subcmd_lines)
    return "\n".join(lines)


def _build_template_instructions(bash_allowlist: list[str]) -> str:
    """Generate help text for wafer agent templates in the allowlist.
    Looks for commands matching "wafer agent -t <template>" or
    "wafer agent --template <template>" and loads their descriptions
    from the template registry.
    Args:
        bash_allowlist: List of allowed bash command prefixes.
    Returns:
        Markdown-formatted template help, or empty string if no templates found.
    """
    template_pattern = re.compile(r"wafer agent\s+(?:-t|--template)\s+(\S+)")
    template_names = []
    for cmd in bash_allowlist:
        match = template_pattern.match(cmd)
        if match:
            template_names.append((cmd, match.group(1)))
    if not template_names:
        return ""
    # Lazy import to avoid circular deps
    try:
        from wafer.agent.templates import load_template
    except ImportError:
        return ""
    sections = []
    for cmd, template_name in template_names:
        try:
            template = load_template(template_name)
            desc = template.description or f"Run the {template_name} agent template"
            sections.append(f"### `{cmd}`\n{desc}")
        except FileNotFoundError:
            # Template not found — skip silently
            continue
    if not sections:
        return ""
    return "## Wafer Agent Templates\n\n" + "\n\n".join(sections)
