# ruff: noqa: PLR0913, E402
"""Tool commands for the Wafer CLI.

All `wafer tool ...` subcommands live here: profiling (ROCprofiler),
analysis (compare), execution (eval), and inspection (TraceLens).
"""
from __future__ import annotations

from pathlib import Path

import typer

# ---------------------------------------------------------------------------
# tool_app + sub-app Typer definitions
# ---------------------------------------------------------------------------

tool_app = typer.Typer(
    name="tool",
    help="Run profiling, evaluation, and analysis tools",
    no_args_is_help=True,
)

tracelens_app = typer.Typer(help="TraceLens performance reports")
compare_app = typer.Typer(help="Compare GPU traces across platforms (AMD vs NVIDIA)")

# Register sub-apps on tool_app
tool_app.add_typer(tracelens_app, name="tracelens", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(compare_app, name="compare", rich_help_panel="Analysis")

# External sub-apps
from .evaluate import eval_main
from .problems_cli import problems_app

tool_app.command("eval", rich_help_panel="Execution")(eval_main)
tool_app.add_typer(problems_app, name="problems", rich_help_panel="Eval")

# Dynamically-defined sub-apps (registered inline below their commands)
rocprof_sdk_app = typer.Typer(help="ROCprofiler-SDK profiling tool commands")
tool_app.add_typer(rocprof_sdk_app, name="rocprof-sdk", rich_help_panel="AMD Profiling")

rocprof_systems_app = typer.Typer(help="ROCprofiler-Systems profiling tool commands")
tool_app.add_typer(rocprof_systems_app, name="rocprof-systems", rich_help_panel="AMD Profiling")

rocprof_compute_app = typer.Typer(help="ROCprofiler-Compute profiling tool commands")
tool_app.add_typer(rocprof_compute_app, name="rocprof-compute", rich_help_panel="AMD Profiling")

# ---------------------------------------------------------------------------
# Shared helpers (imported from app.py)
# ---------------------------------------------------------------------------


def _mark_command_success() -> None:
    from .app import _mark_command_success as _impl
    _impl()


def _exit_with_error(msg: str) -> None:
    typer.echo(f"Error: {msg}", err=True)
    raise typer.Exit(1) from None


# ===================================================================
# ROCprofiler-SDK
# ===================================================================

@rocprof_sdk_app.command("list-counters")
def rocprof_sdk_list_counters() -> None:
    """List available hardware counters for your GPU."""
    from .rocprof_sdk import list_counters_command
    try:
        list_counters_command()
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_sdk_app.command("profile")
def rocprof_sdk_profile(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    output_format: str = typer.Option(
        "csv", "--format", "-f", help="Output format (csv, json, rocpd, pftrace, otf2)"
    ),
    counters: str | None = typer.Option(
        None, "--counters", "-c", help="Comma-separated hardware counters"
    ),
    kernel_include: str | None = typer.Option(
        None, "--kernel-include", help="Include only kernels matching this regex"
    ),
    kernel_exclude: str | None = typer.Option(
        None, "--kernel-exclude", help="Exclude kernels matching this regex"
    ),
    trace_hip_runtime: bool = typer.Option(
        False, "--trace-hip-runtime", help="Enable HIP runtime API tracing"
    ),
    trace_hip_compiler: bool = typer.Option(
        False, "--trace-hip-compiler", help="Enable HIP compiler code tracing"
    ),
    trace_hsa: bool = typer.Option(False, "--trace-hsa", help="Enable HSA API tracing"),
    trace_marker: bool = typer.Option(False, "--trace-marker", help="Enable ROCTx marker tracing"),
    trace_memory_copy: bool = typer.Option(
        False, "--trace-memory-copy", help="Enable memory copy tracing"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Profile a command with rocprofv3.

    Examples:
        wafer rocprof-sdk profile './my_kernel'
        wafer rocprof-sdk profile './kernel' --counters SQ_WAVES,L2_CACHE_HITS
    """
    from .rocprof_sdk import profile_command
    counter_list = counters.split(",") if counters else None
    try:
        result = profile_command(
            command,
            output_dir,
            output_format,
            counter_list,
            kernel_include,
            kernel_exclude,
            trace_hip_runtime,
            trace_hip_compiler,
            trace_hsa,
            trace_marker,
            trace_memory_copy,
            json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_sdk_app.command("analyze")
def rocprof_sdk_analyze(
    file_path: Path = typer.Argument(
        ..., help="Path to rocprofiler output file (.csv, .json, .db)"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze a rocprofiler output file (CSV, JSON, or rocpd)."""
    from .rocprof_sdk import analyze_command
    if not file_path.exists():
        typer.echo(f"Error: File not found: {file_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(str(file_path), json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# ===================================================================
# ROCprofiler-Systems
# ===================================================================

@rocprof_systems_app.command("run")
def rocprof_systems_run(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    trace: bool = typer.Option(
        True, "--trace/--no-trace", help="Generate detailed trace (Perfetto)"
    ),
    profile: bool = typer.Option(False, "--profile", help="Generate call-stack-based profile"),
    flat_profile: bool = typer.Option(False, "--flat-profile", help="Generate flat profile"),
    sample: bool = typer.Option(False, "--sample", help="Enable sampling profiling"),
    host: bool = typer.Option(False, "--host", help="Enable host metrics"),
    device: bool = typer.Option(False, "--device", help="Enable device metrics"),
    wait: float | None = typer.Option(None, "--wait", help="Wait time before collecting (seconds)"),
    duration: float | None = typer.Option(
        None, "--duration", help="Duration of collection (seconds)"
    ),
    use_rocm: bool = typer.Option(True, "--use-rocm/--no-rocm", help="Enable ROCm backend"),
    use_sampling: bool = typer.Option(False, "--use-sampling", help="Enable sampling backend"),
    use_kokkosp: bool = typer.Option(
        False, "--use-kokkosp", help="Enable Kokkos profiling backend"
    ),
    use_mpip: bool = typer.Option(False, "--use-mpip", help="Enable MPI profiling backend"),
    use_rocpd: bool = typer.Option(False, "--use-rocpd", help="Enable rocpd database output"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run system profiling with rocprof-sys-run."""
    from .rocprof_systems import run_command
    try:
        result = run_command(
            command=command,
            output_dir=output_dir,
            trace=trace,
            profile=profile,
            flat_profile=flat_profile,
            sample=sample,
            host=host,
            device=device,
            wait=wait,
            duration=duration,
            use_rocm=use_rocm,
            use_sampling=use_sampling,
            use_kokkosp=use_kokkosp,
            use_mpip=use_mpip,
            use_rocpd=use_rocpd,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("analyze")
def rocprof_systems_analyze(
    file_path: Path = typer.Argument(..., help="Path to rocprof-sys output file (.json, .txt)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze a rocprof-sys output file."""
    from .rocprof_systems import analyze_command
    if not file_path.exists():
        typer.echo(f"Error: File not found: {file_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(str(file_path), json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("sample")
def rocprof_systems_sample(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    frequency: int | None = typer.Option(
        None, "--frequency", "--freq", "-f", help="Sampling frequency in Hz"
    ),
    trace: bool = typer.Option(False, "--trace", help="Generate detailed trace"),
    profile: bool = typer.Option(False, "--profile", help="Generate call-stack profile"),
    flat_profile: bool = typer.Option(False, "--flat-profile", help="Generate flat profile"),
    host: bool = typer.Option(False, "--host", help="Enable host metrics"),
    device: bool = typer.Option(False, "--device", help="Enable device metrics"),
    wait: float | None = typer.Option(None, "--wait", help="Wait time (seconds)"),
    duration: float | None = typer.Option(None, "--duration", help="Duration (seconds)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run sampling profiling with rocprof-sys-sample."""
    from .rocprof_systems import sample_command
    try:
        result = sample_command(
            command=command,
            output_dir=output_dir,
            frequency=frequency,
            trace=trace,
            profile=profile,
            flat_profile=flat_profile,
            host=host,
            device=device,
            wait=wait,
            duration=duration,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("instrument")
def rocprof_systems_instrument(
    command: str = typer.Argument(..., help="Command to instrument"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    simulate: bool = typer.Option(False, "--simulate", help="Simulate without creating binary"),
    function_include: list[str] | None = typer.Option(
        None, "--function-include", help="Function patterns to include"
    ),
    function_exclude: list[str] | None = typer.Option(
        None, "--function-exclude", help="Function patterns to exclude"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run binary instrumentation with rocprof-sys-instrument."""
    from .rocprof_systems import instrument_command
    try:
        result = instrument_command(
            command=command,
            output_dir=output_dir,
            simulate=simulate,
            function_include=function_include,
            function_exclude=function_exclude,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("query")
def rocprof_systems_query(
    components: bool = typer.Option(False, "--components", help="Query available components"),
    hw_counters: bool = typer.Option(False, "--hw-counters", help="Query hardware counters"),
    all_metrics: bool = typer.Option(False, "--all", help="Query all metrics"),
    filter_pattern: str | None = typer.Option(None, "--filter", help="Filter results"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Query available profiling metrics and components."""
    from .rocprof_systems import query_command
    try:
        result = query_command(
            components=components,
            hw_counters=hw_counters,
            all_metrics=all_metrics,
            filter_pattern=filter_pattern,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# ===================================================================
# ROCprofiler-Compute
# ===================================================================

@rocprof_compute_app.command("profile")
def rocprof_compute_profile(
    command: str = typer.Argument(..., help="Command to profile"),
    name: str = typer.Option(..., "--name", "-n", help="Workload name"),
    path: str | None = typer.Option(None, "--path", "-p", help="Workload base path"),
    kernel: str | None = typer.Option(
        None, "--kernel", "-k", help="Kernel filter (comma-separated)"
    ),
    dispatch: str | None = typer.Option(
        None, "--dispatch", "-d", help="Dispatch filter (comma-separated)"
    ),
    block: str | None = typer.Option(None, "--block", "-b", help="Block filter (comma-separated)"),
    no_roof: bool = typer.Option(False, "--no-roof", help="Skip roofline data"),
    roof_only: bool = typer.Option(False, "--roof-only", help="Profile roofline only (fastest)"),
    hip_trace: bool = typer.Option(False, "--hip-trace", help="Enable HIP trace"),
    verbose: int = typer.Option(0, "--verbose", "-v", count=True, help="Increase verbosity"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Profile a command with rocprof-compute.

    Examples:
        wafer rocprof-compute profile --name vcopy -- './vcopy -n 1048576'
        wafer rocprof-compute profile -n test -b SQ,TCC -- './kernel'
    """
    from .rocprof_compute import profile_command
    try:
        result = profile_command(
            command,
            name,
            path,
            kernel,
            dispatch,
            block,
            no_roof,
            roof_only,
            hip_trace,
            verbose,
            json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_compute_app.command("analyze")
def rocprof_compute_analyze(
    workload_path: Path = typer.Argument(..., help="Path to workload directory"),
    kernel: str | None = typer.Option(None, "--kernel", "-k", help="Kernel filter"),
    dispatch: str | None = typer.Option(None, "--dispatch", "-d", help="Dispatch filter"),
    block: str | None = typer.Option(None, "--block", "-b", help="Block filter"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file"),
    list_stats: bool = typer.Option(
        False, "--list-stats", help="List all detected kernels and dispatches"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    gui: bool = typer.Option(
        False, "--gui", help="Launch interactive GUI viewer (bundled Python viewer by default)"
    ),
    port: int = typer.Option(8050, "--port", "-p", help="Port for GUI server"),
) -> None:
    """Analyze a rocprof-compute workload directory.

    Examples:
        wafer rocprof-compute analyze ./workloads/vcopy
        wafer rocprof-compute analyze ./workloads/app --gui
    """
    from .rocprof_compute import analyze_command
    if not workload_path.exists():
        typer.echo(f"Error: Workload path not found: {workload_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(
            str(workload_path),
            kernel,
            dispatch,
            block,
            output,
            list_stats,
            json_output,
            gui,
            port,
        )
        if json_output or not gui:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_compute_app.command("list-metrics")
def rocprof_compute_list_metrics(
    arch: str = typer.Argument(..., help="Architecture (gfx90a, gfx942, etc.)"),
) -> None:
    """List available metrics for an architecture."""
    from .rocprof_compute import list_metrics_command
    try:
        result = list_metrics_command(arch)
        if result:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# ===================================================================
# TraceLens
# ===================================================================

@tracelens_app.command("check")
def tracelens_check(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check if TraceLens is installed."""
    from .tracelens import check_command
    try:
        result = check_command(json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@tracelens_app.command("report")
def tracelens_report(
    trace_path: str = typer.Argument(..., help="Path to trace file (.json, .zip, .gz, .pb)"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    trace_format: str = typer.Option(
        "auto", "--format", "-f", help="Trace format: auto, pytorch, rocprof, jax"
    ),
    short_kernel: bool = typer.Option(
        False, "--short-kernel", help="Include short kernel analysis"
    ),
    kernel_details: bool = typer.Option(
        False, "--kernel-details", help="Include detailed kernel breakdown"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Generate performance report from a trace file."""
    from .tracelens import report_command
    try:
        result = report_command(
            trace_path=trace_path,
            output_path=output,
            trace_format=trace_format,
            short_kernel=short_kernel,
            kernel_details=kernel_details,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None


@tracelens_app.command("compare")
def tracelens_compare(
    baseline: str = typer.Argument(..., help="Path to baseline Excel report"),
    candidate: str = typer.Argument(..., help="Path to candidate Excel report"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output comparison file"),
    baseline_name: str = typer.Option(
        "baseline", "--baseline-name", help="Display name for baseline"
    ),
    candidate_name: str = typer.Option(
        "candidate", "--candidate-name", help="Display name for candidate"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Compare two performance reports."""
    from .tracelens import compare_command
    try:
        result = compare_command(
            baseline_path=baseline,
            candidate_path=candidate,
            output_path=output,
            baseline_name=baseline_name,
            candidate_name=candidate_name,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None


@tracelens_app.command("collective")
def tracelens_collective(
    trace_dir: str = typer.Argument(..., help="Directory containing trace files for all ranks"),
    world_size: int = typer.Option(..., "--world-size", "-w", help="Number of ranks (GPUs)"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Generate multi-rank collective performance report."""
    from .tracelens import collective_command
    try:
        result = collective_command(
            trace_dir=trace_dir,
            world_size=world_size,
            output_path=output,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None


# ===================================================================
# Compare
# ===================================================================

@compare_app.command("analyze")
def compare_analyze(
    trace1: Path = typer.Argument(..., help="First trace file (AMD or NVIDIA)", exists=True),
    trace2: Path = typer.Argument(..., help="Second trace file (AMD or NVIDIA)", exists=True),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    phase: str = typer.Option(
        "all",
        "--phase",
        help="Filter by phase: all, prefill, or decode",
    ),
    all: bool = typer.Option(False, "--all", help="Show all items without truncation"),
    stack_traces: bool = typer.Option(False, "--stack-traces", help="Show Python stack traces for operations"),
    grouped: bool = typer.Option(False, "--grouped", help="Group kernels by operation type (default: position order)"),
    max_graphs: int = typer.Option(1, "--max-graphs", help="Maximum number of CUDA graph patterns to show (default: 1)"),
    fusion: bool = typer.Option(False, "--fusion", help="Also show fusion analysis (kernel fusion differences)"),
    min_group_size: int = typer.Option(300, "--min-group-size", help="Minimum correlation group size for fusion analysis (default: 300)"),
    json: bool = typer.Option(False, "--json", hidden=True, help="Ignored (for compatibility with cliExecutor)"),
) -> None:
    """Compare GPU traces and generate performance report.

    Examples:
        wafer compare analyze amd_trace.json nvidia_trace.json
        wafer compare analyze amd_trace.json nvidia_trace.json --fusion --json
    """
    from .trace_compare import compare_traces
    compare_traces(
        trace1=trace1,
        trace2=trace2,
        output=output,
        output_format=format,
        phase=phase,
        show_all=all,
        show_stack_traces=stack_traces,
        grouped=grouped,
        max_graphs=max_graphs,
        show_fusion=fusion,
        min_group_size=min_group_size,
    )
    _mark_command_success()


@compare_app.command("fusion")
def compare_fusion_cmd(
    trace1: Path = typer.Argument(..., help="First trace file (AMD or NVIDIA)", exists=True),
    trace2: Path = typer.Argument(..., help="Second trace file (AMD or NVIDIA)", exists=True),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    min_group_size: int = typer.Option(
        300,
        "--min-group-size",
        help="Minimum correlation group size to analyze (default: 300 for transformer layers)",
    ),
    json: bool = typer.Option(False, "--json", hidden=True, help="Ignored (for compatibility with cliExecutor)"),
) -> None:
    """Analyze kernel fusion differences using graph-based matching."""
    from .trace_compare import compare_fusion
    compare_fusion(
        trace1=trace1,
        trace2=trace2,
        output=output,
        format_type=format,
        min_group_size=min_group_size,
    )
    _mark_command_success()
