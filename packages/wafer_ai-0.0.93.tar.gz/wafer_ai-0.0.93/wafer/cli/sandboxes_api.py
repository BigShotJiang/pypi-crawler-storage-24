"""DB operations for sandbox lifecycle tracking via direct Supabase REST.

db_touch_sandbox and its helpers (_is_service_token, _get_sb_headers) are
defined in wafer.sandbox.operations and re-exported here for backward
compatibility.
"""
from __future__ import annotations

import base64
import json
import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx

from .auth import get_auth_headers
from .global_config import get_supabase_anon_key, get_supabase_url
from wafer.sandbox.operations import (
    _is_service_token,
    _get_sb_headers,
    db_touch_sandbox,
)

logger = logging.getLogger(__name__)

_TIMEOUT = 10


def _extract_uid(token: str) -> str:
    payload = token.split(".")[1]
    payload += "=" * ((4 - len(payload) % 4) % 4)
    return json.loads(base64.urlsafe_b64decode(payload))["sub"]


def db_register_sandbox(
    sandbox_id: str,
    target_name: str,
    tmux_session: str,
    timeout_hours: int,
    created_at: str,
) -> None:
    """INSERT a new sandbox row after SSH start succeeds."""
    try:
        if _is_service_token():
            from wafer.sandbox.operations import _get_api_base_and_headers
            api_url, headers = _get_api_base_and_headers()
            resp = httpx.post(
                f"{api_url}/v1/sandboxes/register",
                headers=headers,
                json={
                    "id": sandbox_id,
                    "target_name": target_name,
                    "tmux_session": tmux_session,
                    "timeout_hours": timeout_hours,
                    "created_at": created_at,
                },
                timeout=_TIMEOUT,
            )
            resp.raise_for_status()
            return

        sb_url, headers = _get_sb_headers()
        token = headers["Authorization"].removeprefix("Bearer ")
        uid = _extract_uid(token)

        created_dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        expires_at = (created_dt + timedelta(hours=timeout_hours)).isoformat()

        body = {
            "id": sandbox_id,
            "user_id": uid,
            "target_name": target_name,
            "tmux_session": tmux_session,
            "timeout_hours": timeout_hours,
            "created_at": created_at,
            "expires_at": expires_at,
            "status": "active",
        }
        resp = httpx.post(
            f"{sb_url}/rest/v1/user_sandboxes",
            headers=headers,
            json=body,
            timeout=_TIMEOUT,
        )
        resp.raise_for_status()
    except Exception as e:
        logger.warning("db_register_sandbox failed — sandbox won't appear in 'wafer sandbox list': %s", e)


def db_get_sandbox(sandbox_id: str) -> dict[str, Any] | None:
    """GET a single sandbox by ID. Returns None if not found or not active."""
    if _is_service_token():
        return None
    try:
        sb_url, headers = _get_sb_headers()
        resp = httpx.get(
            f"{sb_url}/rest/v1/user_sandboxes?id=eq.{sandbox_id}&status=eq.active&select=*",
            headers=headers,
            timeout=_TIMEOUT,
        )
        resp.raise_for_status()
        rows = resp.json()
        return rows[0] if rows else None
    except Exception as e:
        logger.debug("db_get_sandbox failed: %s", e)
        return None


def db_destroy_sandbox(sandbox_id: str) -> None:
    """Mark sandbox as destroyed."""
    if _is_service_token():
        return
    try:
        sb_url, headers = _get_sb_headers()
        now = datetime.now(timezone.utc).isoformat()

        resp = httpx.patch(
            f"{sb_url}/rest/v1/user_sandboxes?id=eq.{sandbox_id}",
            headers=headers,
            json={"status": "destroyed", "destroyed_at": now},
            timeout=_TIMEOUT,
        )
        resp.raise_for_status()
    except Exception as e:
        logger.warning("db_destroy_sandbox failed: %s", e)


def db_list_active_sandboxes(target_name: str | None = None) -> list[dict[str, Any]]:
    """List sandboxes where status=active AND expires_at > now()."""
    try:
        if _is_service_token():
            from wafer.sandbox.operations import _get_api_base_and_headers
            assert target_name, "target_name required for cloud agent sandbox listing"
            api_url, headers = _get_api_base_and_headers()
            resp = httpx.get(
                f"{api_url}/v1/sandboxes/active",
                headers=headers,
                params={"target_name": target_name},
                timeout=_TIMEOUT,
            )
            resp.raise_for_status()
            return resp.json()

        sb_url, headers = _get_sb_headers()
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")

        url = (
            f"{sb_url}/rest/v1/user_sandboxes"
            f"?status=eq.active&expires_at=gt.{now}&order=created_at.desc"
        )
        if target_name:
            url += f"&target_name=eq.{target_name}"

        resp = httpx.get(url, headers=headers, timeout=_TIMEOUT)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        logger.warning("db_list_active_sandboxes failed: %s", e)
        return []
