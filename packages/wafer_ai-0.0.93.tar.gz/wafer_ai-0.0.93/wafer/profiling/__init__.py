"""Profiling tool interfaces.

Stateful classes for ROCprofiler profiling tools.
"""


def __getattr__(name: str):
    """Lazy import profiling tool components."""
    if name == "rocprofiler":
        import importlib
        return importlib.import_module("wafer.profiling.rocprofiler")

    raise AttributeError(f"module 'wafer.profiling' has no attribute {name!r}")
