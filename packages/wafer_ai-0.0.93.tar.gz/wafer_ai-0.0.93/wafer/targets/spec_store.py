"""Spec store: CRUD for TargetSpec TOML files.
Specs live in ~/.wafer/specs/{name}.toml.
"""
from __future__ import annotations

import logging
import tomllib
from pathlib import Path
from typing import Any

from wafer.targets.config import (
    BaremetalTarget,
    ModalTarget,
    TargetConfig,
    VMTarget,
    WorkspaceTarget,
)

logger = logging.getLogger(__name__)
WAFER_DIR = Path.home() / ".wafer"
SPECS_DIR = WAFER_DIR / "specs"
CONFIG_FILE = WAFER_DIR / "config.toml"


def _ensure_specs_dir() -> None:
    """Ensure ~/.wafer/specs/ exists."""
    SPECS_DIR.mkdir(parents=True, exist_ok=True)


def _spec_path(name: str) -> Path:
    return SPECS_DIR / f"{name}.toml"


# ── Parsing ──────────────────────────────────────────────────────────────────
_TYPE_MAP: dict[str, type] = {
    "baremetal": BaremetalTarget,
    "vm": VMTarget,
    "modal": ModalTarget,
    "workspace": WorkspaceTarget,
}


def parse_spec(data: dict[str, Any]) -> TargetConfig:
    """Parse TOML dict into TargetSpec (TargetConfig union)."""
    target_type = data.get("type")
    if not target_type:
        raise ValueError("Spec must have 'type' field")
    cls = _TYPE_MAP.get(target_type)
    if cls is None:
        raise ValueError(
            f"Unknown spec type: {target_type}. Must be one of: {', '.join(sorted(_TYPE_MAP))}"
        )
    fields = {k: v for k, v in data.items() if k != "type"}
    # TOML parses lists; dataclasses may want tuples
    if "pip_packages" in fields and isinstance(fields["pip_packages"], list):
        fields["pip_packages"] = tuple(fields["pip_packages"])
    if "gpu_ids" in fields and isinstance(fields["gpu_ids"], list):
        fields["gpu_ids"] = tuple(fields["gpu_ids"])
    return cls(**fields)


# ── CRUD ─────────────────────────────────────────────────────────────────────
def load_spec(name: str) -> TargetConfig:
    """Load spec by name from ~/.wafer/specs/{name}.toml."""
    _ensure_specs_dir()
    path = _spec_path(name)
    if not path.exists():
        raise FileNotFoundError(f"Spec not found: {name} (looked in {SPECS_DIR})")
    with open(path, "rb") as f:
        data = tomllib.load(f)
    return parse_spec(data)



# ── TOML writer ──────────────────────────────────────────────────────────────
def _write_toml(path: Path, data: dict[str, Any]) -> None:
    """Write dict as flat TOML file."""
    lines = []
    for key, value in data.items():
        if value is None:
            continue
        if isinstance(value, bool):
            lines.append(f"{key} = {str(value).lower()}")
        elif isinstance(value, int | float):
            lines.append(f"{key} = {value}")
        elif isinstance(value, str):
            lines.append(f'{key} = "{value}"')
        elif isinstance(value, list):
            if all(isinstance(v, int) for v in value):
                lines.append(f"{key} = {value}")
            else:
                formatted = ", ".join(f'"{v}"' if isinstance(v, str) else str(v) for v in value)
                lines.append(f"{key} = [{formatted}]")
    path.write_text("\n".join(lines) + "\n")
