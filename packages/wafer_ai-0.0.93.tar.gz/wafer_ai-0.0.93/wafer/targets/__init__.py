"""Pluggable target system for kernel evaluation.

Allows routing kernel operations (correctness, benchmark, profiling) to different
execution targets based on capabilities and preferences.
"""

from wafer.targets.config import (
    BaremetalTarget,
    LocalTarget,
    ModalTarget,
    TargetConfig,
    VMTarget,
    WorkspaceTarget,
    is_baremetal_target,
    is_local_target,
    is_modal_target,
    is_vm_target,
    is_workspace_target,
)
from wafer.targets.selection import select_target_for_operation

__all__ = [
    "BaremetalTarget",
    "LocalTarget",
    "VMTarget",
    "ModalTarget",
    "WorkspaceTarget",
    "TargetConfig",
    "is_baremetal_target",
    "is_local_target",
    "is_vm_target",
    "is_modal_target",
    "is_workspace_target",
    "select_target_for_operation",
]
