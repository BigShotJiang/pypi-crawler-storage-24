"""Sandbox: isolated agent workspaces on targets."""
from wafer.sandbox.local import LocalSandbox, create_local_sandbox
from wafer.sandbox.manager import (
    create_sandbox,
    destroy_all_sandboxes,
    destroy_sandbox,
    list_sandboxes,
)
from wafer.sandbox.session import SandboxSession
from wafer.sandbox.types import Sandbox, WaferSandbox

__all__ = [
    "WaferSandbox",
    "Sandbox",
    "LocalSandbox",
    "SandboxSession",
    "create_local_sandbox",
    "create_sandbox",
    "destroy_all_sandboxes",
    "destroy_sandbox",
    "list_sandboxes",
]
