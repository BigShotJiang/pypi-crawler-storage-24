"""SSH sandbox operations: DB touch, resolve-or-create.

Extracted from wafer.cli.sandboxes_api and wafer.cli.sandbox_cli so that
core code (e.g. sandbox_run_tool) can use these without depending on the
CLI package (Typer, etc.).
"""
from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING

import httpx

from wafer.infra.api_config import get_supabase_anon_key, get_supabase_url
from wafer.infra.auth import get_auth_headers

if TYPE_CHECKING:
    from wafer.sandbox.types import Sandbox

logger = logging.getLogger(__name__)

_TIMEOUT = 10


def _is_service_token() -> bool:
    """True when running with a cloud agent service token (not a Supabase JWT)."""
    token = os.environ.get("WAFER_AUTH_TOKEN", "")
    return token.startswith("wfr_cloud_")


def _get_api_base_and_headers() -> tuple[str, dict[str, str]]:
    """Return (api_base_url, headers) for wafer API calls with service token auth."""
    api_url = os.environ.get("WAFER_API_URL")
    assert api_url, "WAFER_API_URL not set — required for cloud agent sandbox operations"
    token = os.environ.get("WAFER_AUTH_TOKEN", "")
    assert token, "WAFER_AUTH_TOKEN not set"
    return api_url, {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


def _get_sb_headers() -> tuple[str, dict[str, str]]:
    """Return (supabase_url, headers) for Supabase REST calls."""
    sb_url = get_supabase_url()
    anon_key = get_supabase_anon_key()
    auth = get_auth_headers()
    assert auth, "Not authenticated. Run: wafer login"
    token = auth["Authorization"].removeprefix("Bearer ")
    return sb_url, {
        "Authorization": f"Bearer {token}",
        "apikey": anon_key,
        "Content-Type": "application/json",
        "Prefer": "return=representation",
    }


def db_touch_sandbox(sandbox_id: str, timeout_hours: int) -> None:
    """UPDATE expires_at to now() + timeout_hours. Called on each run_command."""
    try:
        if _is_service_token():
            api_url, headers = _get_api_base_and_headers()
            resp = httpx.patch(
                f"{api_url}/v1/sandboxes/{sandbox_id}/touch",
                headers=headers,
                json={"timeout_hours": timeout_hours},
                timeout=_TIMEOUT,
            )
            resp.raise_for_status()
            return

        sb_url, headers = _get_sb_headers()

        now = datetime.now(timezone.utc)
        expires_at = (now + timedelta(hours=timeout_hours)).isoformat()

        resp = httpx.patch(
            f"{sb_url}/rest/v1/user_sandboxes?id=eq.{sandbox_id}",
            headers=headers,
            json={"expires_at": expires_at},
            timeout=_TIMEOUT,
        )
        resp.raise_for_status()
    except Exception as e:
        logger.debug("db_touch_sandbox failed: %s", e)


# ---------------------------------------------------------------------------
# Helpers for resolve_or_create_sandbox (extracted from sandbox_cli.py)
# ---------------------------------------------------------------------------

def _get_ssh_creds(target_name: str) -> tuple[str, str]:
    """Load target and return (ssh_target, ssh_key)."""
    from wafer.targets.operations import load_target

    target = load_target(target_name)
    assert target.ssh_target, f"Target '{target_name}' has no SSH credentials"
    return target.ssh_target, target.ssh_key


def _resolve_ssh_target(target: str | None) -> tuple[str, str, str]:
    """Resolve target to SSH credentials. Errors if workspace (sandbox is SSH-only).

    Returns (target_name, ssh_target, ssh_key).
    Raises RuntimeError instead of typer.Exit for non-CLI contexts.
    """
    from wafer.infra.auth import get_valid_token
    from wafer.cli.target_resolve import resolve_target

    target_name, kind = resolve_target(name=target)
    if kind == "workspace":
        raise RuntimeError(
            f"Sandbox only supports SSH targets. '{target_name}' is a workspace.\n"
            "  For sandbox:    wafer target init ssh --name <name> --host user@host:22"
        )

    token = get_valid_token()
    if not token:
        raise RuntimeError("Not authenticated. Run: wafer login")

    ssh_target, ssh_key = _get_ssh_creds(target_name)
    return target_name, ssh_target, ssh_key


def _run_async(async_fn):
    """Run an async function (not a coroutine) via trio with trio_asyncio bridge."""
    import trio
    import trio_asyncio

    async def _wrapper():
        async with trio_asyncio.open_loop():
            return await async_fn()

    return trio.run(_wrapper)


def _detect_gpu_info(target_name: str) -> tuple[str, int]:
    """Return (gpu_vendor, gpu_count) for an SSH target."""
    from wafer.targets.operations import load_target

    target_info = load_target(target_name)
    gpu_type = (target_info.gpu_type or "").lower()
    gpu_vendor = "amd" if "mi" in gpu_type else "nvidia"
    gpu_count = len(target_info.gpu_ids)
    return gpu_vendor, gpu_count


def resolve_or_create_sandbox(target_name: str, *, json_output: bool = False) -> Sandbox:
    """Find an existing active sandbox on target, or create one. Returns Sandbox object.

    Emits dim stderr status messages unless json_output is True.
    Raises RuntimeError on auth/target errors (no Typer dependency).
    """
    from wafer.cli.sandboxes_api import db_list_active_sandboxes, db_register_sandbox
    from wafer.sandbox import SandboxSession, create_sandbox
    from wafer.sandbox.types import Sandbox

    target_name, ssh_target, ssh_key = _resolve_ssh_target(target_name)

    active_rows = db_list_active_sandboxes(target_name=target_name)
    if active_rows:
        row = active_rows[0]
        if not json_output:
            sys.stderr.write(f"\x1b[2mReusing sandbox {row['id']} on {target_name}\x1b[0m\n")
            sys.stderr.flush()
        return Sandbox(
            id=row["id"],
            target_name=row["target_name"],
            tmux_session=row["tmux_session"],
            ssh_target=ssh_target,
            ssh_key=ssh_key,
            created_at=row["created_at"],
            timeout_hours=row["timeout_hours"],
        )

    if not json_output:
        sys.stderr.write(f"\x1b[2mCreating sandbox on {target_name}...\x1b[0m\n")
        sys.stderr.flush()

    gpu_vendor, gpu_count = _detect_gpu_info(target_name)
    sandbox = create_sandbox(target_name, ssh_target, ssh_key, gpu_vendor=gpu_vendor, gpu_count=gpu_count)

    async def _create():
        session = SandboxSession(sandbox)
        await session.start()

    _run_async(_create)

    db_register_sandbox(
        sandbox_id=sandbox.id,
        target_name=sandbox.target_name,
        tmux_session=sandbox.tmux_session,
        timeout_hours=sandbox.timeout_hours,
        created_at=sandbox.created_at,
    )

    if not json_output:
        sys.stderr.write(
            f"\x1b[2mSandbox {sandbox.id} created on {target_name}\n"
            f"  Attach: wafer sandbox attach {sandbox.id} --target {target_name}\x1b[0m\n"
        )
        sys.stderr.flush()

    return sandbox
