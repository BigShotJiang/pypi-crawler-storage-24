"""Agent execution framework for Wafer.

Full agent framework for tool-use and multi-turn interactions.
Uses lazy imports so submodules can be imported without pulling in all dependencies.
"""

import importlib
from typing import TYPE_CHECKING

# For type checkers, import everything eagerly
if TYPE_CHECKING:
    from wafer.dtypes import (
        Actor,
        AgentCheckpoint,
        AgentSession,
        AgentState,
        ChatCompletion,
        Choice,
        ContentBlock,
        Endpoint,
        Environment,
        EnvironmentConfig,
        ImageContent,
        Logprob,
        Logprobs,
        Message,
        Metric,
        RunConfig,
        Sample,
        Score,
        ScoreFn,
        SessionStatus,
        StopReason,
        TextContent,
        ThinkingContent,
        Tool,
        ToolCall,
        ToolCallContent,
        ToolConfirmResult,
        ToolFormatter,
        ToolFunction,
        ToolFunctionParameter,
        ToolResult,
        Trajectory,
        Usage,
        default_confirm_tool,
    )

    from .agent_session import AgentSessionConfig, AgentSessionResult, run_agent_session
    from .agents import (
        handle_stop_max_turns,
        inject_turn_warning,
        rollout,
        run_agent,
    )
    from .models import (
        ApiType,
        ModelCost,
        ModelMetadata,
        Provider,
        get_api_type,
        get_model,
    )
    from .providers import (
        get_provider_function,
        rollout_anthropic,
        rollout_google,
        rollout_openai,
        rollout_openai_responses,
    )
    from .store import FileSessionStore, SessionStore, SupabaseSessionStore, generate_session_id
    from .transform_messages import transform_messages


# Lazy import mappings: attribute -> (module, name)
_LAZY_IMPORTS = {
    # agent_session
    "AgentSessionConfig": (".agent_session", "AgentSessionConfig"),
    "AgentSessionResult": (".agent_session", "AgentSessionResult"),
    "run_agent_session": (".agent_session", "run_agent_session"),
    # agents
    "handle_stop_max_turns": (".agents", "handle_stop_max_turns"),
    "inject_turn_warning": (".agents", "inject_turn_warning"),
    "rollout": (".agents", "rollout"),
    "run_agent": (".agents", "run_agent"),
    # store
    "FileSessionStore": (".store", "FileSessionStore"),
    "SessionStore": (".store", "SessionStore"),
    "SupabaseSessionStore": (".store", "SupabaseSessionStore"),
    "generate_session_id": (".store", "generate_session_id"),
    # dtypes
    "Actor": ("wafer.dtypes", "Actor"),
    "AgentSession": ("wafer.dtypes", "AgentSession"),
    "AgentState": ("wafer.dtypes", "AgentState"),
    "ChatCompletion": ("wafer.dtypes", "ChatCompletion"),
    "Choice": ("wafer.dtypes", "Choice"),
    "ContentBlock": ("wafer.dtypes", "ContentBlock"),
    "Endpoint": ("wafer.dtypes", "Endpoint"),
    "Environment": ("wafer.dtypes", "Environment"),
    "EnvironmentConfig": ("wafer.dtypes", "EnvironmentConfig"),
    "ImageContent": ("wafer.dtypes", "ImageContent"),
    "Logprob": ("wafer.dtypes", "Logprob"),
    "Logprobs": ("wafer.dtypes", "Logprobs"),
    "Message": ("wafer.dtypes", "Message"),
    "RunConfig": ("wafer.dtypes", "RunConfig"),
    "SessionStatus": ("wafer.dtypes", "SessionStatus"),
    "StopReason": ("wafer.dtypes", "StopReason"),
    "AgentCheckpoint": ("wafer.dtypes", "AgentCheckpoint"),
    "TextContent": ("wafer.dtypes", "TextContent"),
    "ThinkingContent": ("wafer.dtypes", "ThinkingContent"),
    "Tool": ("wafer.dtypes", "Tool"),
    "ToolCall": ("wafer.dtypes", "ToolCall"),
    "ToolCallContent": ("wafer.dtypes", "ToolCallContent"),
    "ToolConfirmResult": ("wafer.dtypes", "ToolConfirmResult"),
    "ToolFormatter": ("wafer.dtypes", "ToolFormatter"),
    "ToolFunction": ("wafer.dtypes", "ToolFunction"),
    "ToolFunctionParameter": ("wafer.dtypes", "ToolFunctionParameter"),
    "ToolResult": ("wafer.dtypes", "ToolResult"),
    "Trajectory": ("wafer.dtypes", "Trajectory"),
    "Usage": ("wafer.dtypes", "Usage"),
    "default_confirm_tool": ("wafer.dtypes", "default_confirm_tool"),
    # Evaluation types
    "Metric": ("wafer.dtypes", "Metric"),
    "Score": ("wafer.dtypes", "Score"),
    "Sample": ("wafer.dtypes", "Sample"),
    "ScoreFn": ("wafer.dtypes", "ScoreFn"),
    # models
    "ApiType": (".models", "ApiType"),
    "ModelCost": (".models", "ModelCost"),
    "ModelMetadata": (".models", "ModelMetadata"),
    "Provider": (".models", "Provider"),
    "get_api_type": (".models", "get_api_type"),
    "get_model": (".models", "get_model"),
    # providers
    "get_provider_function": (".providers", "get_provider_function"),
    "rollout_anthropic": (".providers", "rollout_anthropic"),
    "rollout_google": (".providers", "rollout_google"),
    "rollout_openai": (".providers", "rollout_openai"),
    "rollout_openai_responses": (".providers", "rollout_openai_responses"),
    # transform_messages
    "transform_messages": (".transform_messages", "transform_messages"),
}


def __getattr__(name: str) -> object:
    """Lazy import attributes on first access."""
    if name in _LAZY_IMPORTS:
        module_name, attr_name = _LAZY_IMPORTS[name]
        module = importlib.import_module(module_name, __package__)
        return getattr(module, attr_name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Agent session
    "AgentSessionConfig",
    "AgentSessionResult",
    "run_agent_session",
    # Core types
    "Endpoint",
    "Actor",
    "AgentState",
    "RunConfig",
    "Environment",
    "Usage",
    "Logprob",
    "Logprobs",
    "Choice",
    "ChatCompletion",
    # Message types
    "Message",
    "ToolCall",
    "ToolResult",
    "Trajectory",
    # ContentBlock types
    "ContentBlock",
    "TextContent",
    "ThinkingContent",
    "ToolCallContent",
    "ImageContent",
    # Tool types
    "Tool",
    "ToolFunction",
    "ToolFunctionParameter",
    "ToolFormatter",
    "StopReason",
    "ToolConfirmResult",
    # Stream handling
    "AgentCheckpoint",
    # Agent execution
    "run_agent",
    "rollout",
    # Tool handlers
    "inject_turn_warning",
    "handle_stop_max_turns",
    "default_confirm_tool",
    # Sessions
    "SessionStore",
    "FileSessionStore",
    "SupabaseSessionStore",
    "generate_session_id",
    "AgentSession",
    "SessionStatus",
    "EnvironmentConfig",
    # Providers
    "rollout_openai",
    "rollout_anthropic",
    "get_provider_function",
    # Message transformation
    "transform_messages",
    # Model registry
    "get_model",
    "get_api_type",
    "Provider",
    "ApiType",
    "ModelMetadata",
    "ModelCost",
    "Metric",
    "Score",
    "Sample",
    "ScoreFn",
    "rollout_google",
    "rollout_openai_responses",
]

__version__ = "0.3.0"  # Added configuration protocols and base configs
