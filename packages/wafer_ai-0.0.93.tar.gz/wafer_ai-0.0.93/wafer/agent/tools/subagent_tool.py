"""Subagent tool: spawn a subagent via the wafer API.

The agent passes either a template name (string) or an inline config (dict)
alongside a prompt. No pre-configured named subagents required.
"""
from __future__ import annotations

import os
from collections.abc import Awaitable, Callable
from typing import Any

from wafer.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
    ToolResultDelta,
)

SUBAGENT_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="subagent",
        description=(
            "Spawn an autonomous agent on a GPU target for long-running or specialized tasks. "
            "Use for extended optimization loops, parallel experiments, or tasks needing "
            "their own turn budget. The subagent runs independently and streams progress back.\n\n"
            "The config must be an object with these fields:\n"
            "  - system_prompt (string): Instructions for the subagent\n"
            "  - model (string): Model name, e.g. 'claude-sonnet-4-5'\n"
            "  - max_tokens (int): Max output tokens per response\n"
            "  - tools (list of strings): Tool names like ['bash', 'read', 'write', 'edit', 'glob', 'grep']. "
            "Each entry MUST be a plain string name, NOT a dict.\n\n"
            "Do NOT include 'subagent' or 'pull_session_files' in tools — they are stripped automatically."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "prompt": {"type": "string", "description": "Task for the subagent"},
                "config": {
                    "type": "object",
                    "description": (
                        "Inline config object. Required fields: system_prompt (string), model (string). "
                        "Optional: max_tokens (int), tools (list of string names like ['bash', 'read', 'write'])."
                    ),
                },
                "target": {
                    "type": "string",
                    "description": (
                        "GPU target name to run the subagent on (e.g. 'b200', 'mi355x'). "
                        "When omitted, inherits the parent agent's target."
                    ),
                },
                "upload_dir": {
                    "type": "string",
                    "description": (
                        "Optional path to a local directory to upload as the subagent's workspace. "
                        "The subagent will start with these files available. "
                        "Use '.' to upload the current working directory."
                    ),
                },
            },
        ),
        required=["prompt", "config"],
    ),
)


def _tool_call_summary(data: dict) -> str:
    name = data.get("name") or data.get("tool_name") or "tool"
    args = data.get("args", {})
    if name in ("read", "write", "edit"):
        return f"{name} {args.get('path', '')}".rstrip()
    if name == "bash":
        cmd = str(args.get("command", ""))
        return f"bash {cmd[:80]}"
    if name == "grep":
        return f"grep {args.get('pattern', '')}".rstrip()
    if name == "glob":
        return f"glob {args.get('pattern', '')}".rstrip()
    if name == "subagent":
        agent = args.get("agent", "")
        return f"subagent {agent}".rstrip()
    return name


async def exec_subagent(
    tool_call: ToolCall,
    on_output: Callable[[ToolResultDelta], Awaitable[None]] | None = None,
    *,
    api_url: str | None = None,
    auth_token: str | None = None,
) -> ToolResult:
    """Execute a subagent via the wafer API.

    config can be a template name (string) resolved to a bundled TOML,
    or an inline config dict sent directly as inline_config.
    """
    from wafer.config.agent import get_bundled_template_path, load_agent_config

    config_arg = tool_call.args.get("config")
    prompt = tool_call.args.get("prompt", "")
    assert config_arg, "subagent 'config' argument is required"
    assert prompt, "subagent 'prompt' argument is required"

    explicit_target: str | None = tool_call.args.get("target")

    target_name: str | None = None
    if isinstance(config_arg, str):
        template_path = get_bundled_template_path(config_arg)
        assert template_path is not None, (
            f"Unknown template '{config_arg}'. "
            "Use a bundled template name (e.g. 'default') or pass an inline config dict."
        )
        file_config = load_agent_config(template_path)
        inline_config = file_config.to_dict()
        target_name = getattr(file_config, "target_name", None)
    else:
        assert isinstance(config_arg, dict), (
            f"config must be a template name (string) or inline config (dict), got {type(config_arg).__name__}"
        )
        inline_config = config_arg
        target_name = inline_config.pop("target_name", None) or inline_config.pop("target", None)

    if explicit_target:
        target_name = explicit_target

    if not target_name:
        target_name = os.environ.get("WAFER_TARGET_NAME") or os.environ.get("WAFER_DEFAULT_TARGET")

    _ORCHESTRATOR_ONLY_TOOLS = frozenset({"subagent", "pull_session_files"})
    if "tools" in inline_config and isinstance(inline_config["tools"], list):
        raw_tools = inline_config["tools"]
        normalized: list[str] = []
        for t in raw_tools:
            if isinstance(t, str):
                normalized.append(t)
            elif isinstance(t, dict):
                name = t.get("name") or t.get("type")
                assert name and isinstance(name, str), (
                    f"tools entries must be plain string names (e.g. 'bash'), got dict: {t}. "
                    "Use ['bash', 'read', 'write', 'edit', 'glob', 'grep'] format."
                )
                normalized.append(name)
            else:
                assert False, f"tools entries must be strings, got {type(t).__name__}: {t}"
        inline_config["tools"] = [t for t in normalized if t not in _ORCHESTRATOR_ONLY_TOOLS]
    elif inline_config.get("tools") is None:
        from wafer.agent.environment import ALL_TOOLS
        inline_config["tools"] = [t for t in ALL_TOOLS if t not in _ORCHESTRATOR_ONLY_TOOLS]

    if "system_prompt" in inline_config and isinstance(inline_config["system_prompt"], str):
        available = inline_config.get("tools", [])
        tool_list = ", ".join(available) if available else "read, write, edit, glob, grep, bash"
        inline_config["system_prompt"] = (
            f"IMPORTANT: Your available tools are ONLY: {tool_list}. "
            "You do NOT have access to `subagent` or `pull_session_files`. "
            "Do not attempt to call them.\n\n"
            + inline_config["system_prompt"]
        )

    upload_dir_arg = tool_call.args.get("upload_dir")

    return await _exec_wafer_api_subagent(
        tool_call, prompt, inline_config,
        on_output=on_output,
        api_url=api_url, auth_token=auth_token,
        target_name=target_name,
        upload_dir=upload_dir_arg,
    )


async def _exec_wafer_api_subagent(
    tool_call: ToolCall,
    prompt: str,
    inline_config: dict[str, Any],
    on_output: Callable[[ToolResultDelta], Awaitable[None]] | None,
    *,
    api_url: str | None,
    auth_token: str | None,
    target_name: str | None = None,
    upload_dir: str | None = None,
) -> ToolResult:
    """POST inline_config to /v1/cloud-agent/run and stream the response."""
    assert api_url, "api_url is required for subagent execution"
    assert auth_token, "auth_token is required for subagent execution"

    from pathlib import Path

    from wafer.infra.api_client import WaferApiError, fetch_wafer_api, stream_wafer_api

    workspace_storage_path: str | None = None
    if upload_dir:
        import io
        import tarfile

        import httpx

        upload_path = Path(upload_dir).resolve()
        assert upload_path.is_dir(), f"upload_dir is not a directory: {upload_path}"

        tar_buffer = io.BytesIO()
        _EXCLUDE = {".git", "__pycache__", ".venv", "venv", "node_modules", ".ruff_cache"}

        def _tar_filter(info: tarfile.TarInfo) -> tarfile.TarInfo | None:
            for exc in _EXCLUDE:
                if exc in info.name.split("/"):
                    return None
            return info

        with tarfile.open(fileobj=tar_buffer, mode="w:gz") as tar:
            for child in upload_path.iterdir():
                tar.add(str(child), arcname=child.name, filter=_tar_filter)
        tar_bytes = tar_buffer.getvalue()

        _MAX_UPLOAD_BYTES = 100 * 1024 * 1024
        assert len(tar_bytes) < _MAX_UPLOAD_BYTES, (
            f"upload_dir tarball too large: {len(tar_bytes)} bytes (max 100MB)"
        )

        upload_resp = await fetch_wafer_api(
            api_url=api_url,
            auth_token=auth_token,
            endpoint="/v1/cloud-agent/upload-url",
            method="POST",
            body={},
        )
        upload_url = upload_resp["upload_url"]
        workspace_storage_path = upload_resp["storage_path"]

        async with httpx.AsyncClient(timeout=httpx.Timeout(120.0, connect=30.0)) as client:
            resp = await client.put(
                upload_url,
                content=tar_bytes,
                headers={"Content-Type": "application/gzip"},
            )
            assert resp.status_code in (200, 201), (
                f"Upload failed: {resp.status_code} {resp.text[:200]}"
            )

    body: dict[str, object] = {
        "prompt": prompt,
        "inline_config": inline_config,
        "mode": "dir" if workspace_storage_path else "empty",
        "tags": {"source": "subagent"},
    }
    if workspace_storage_path:
        body["workspace_storage_path"] = workspace_storage_path

    if target_name:
        body["target_name"] = target_name

    volume_env = os.environ.get("WAFER_VOLUME_ENV")
    if volume_env:
        body["volume_env"] = volume_env

    text_chunks: list[str] = []
    eval_result_chunks: list[str] = []
    subagent_session_id: str = ""
    pending_tool_names: dict[str, str] = {}
    try:
        async for event in stream_wafer_api(
            api_url=api_url,
            auth_token=auth_token,
            endpoint="/v1/cloud-agent/run",
            body=body,
        ):
            if event.event_type == "session_started":
                subagent_session_id = event.data.get("session_id", "")
                if subagent_session_id and on_output:
                    await on_output(ToolResultDelta(
                        tool_call_id=tool_call.id,
                        delta=f"[subagent_session:{subagent_session_id}]\n",
                    ))
            elif event.event_type == "tool_call_end":
                tool_id = event.data.get("id", "")
                name = event.data.get("name") or event.data.get("tool_name") or "tool"
                pending_tool_names[tool_id] = name
                if on_output:
                    summary = _tool_call_summary(event.data)
                    await on_output(ToolResultDelta(
                        tool_call_id=tool_call.id,
                        delta=f"→ {summary}\n",
                    ))
            elif event.event_type == "tool_result":
                tc_id = event.data.get("tool_call_id", "")
                name = pending_tool_names.pop(tc_id, "")
                is_err = event.data.get("is_error", False)
                content = event.data.get("content") or ""
                details = event.data.get("details") or {}
                if not is_err:
                    if content and name == "bash" and '"metrics"' in content:
                        eval_result_chunks.append(content)
                if on_output:
                    if is_err:
                        snippet = (content or event.data.get("error") or "")[:120]
                        await on_output(ToolResultDelta(
                            tool_call_id=tool_call.id,
                            delta=f"  ✗ {name}: {snippet}\n",
                        ))
                    elif name in ("write", "edit"):
                        path = details.get("path") if isinstance(details, dict) else ""
                        if path:
                            await on_output(ToolResultDelta(
                                tool_call_id=tool_call.id,
                                delta=f"  ✓ {name} {path}: ok\n",
                            ))
                        if details.get("diff") and name == "edit":
                            await on_output(ToolResultDelta(
                                tool_call_id=tool_call.id,
                                delta=f"[FILE_DIFF]\n{details['diff']}\n[/FILE_DIFF]\n",
                            ))
                    else:
                        snippet = content[:500] if len(content) > 500 else content
                        await on_output(ToolResultDelta(
                            tool_call_id=tool_call.id,
                            delta=f"  ✓ {name}: {snippet}\n",
                        ))
            elif event.event_type == "text_delta":
                text = event.data.get("delta", "")
                if text:
                    text_chunks.append(text)
                    if on_output:
                        await on_output(ToolResultDelta(
                            tool_call_id=tool_call.id,
                            delta=text,
                        ))
            elif event.event_type == "error":
                error_msg = event.data.get("error", "Unknown error from wafer API")
                return ToolResult(
                    tool_call_id=tool_call.id,
                    is_error=True,
                    content="",
                    error=error_msg,
                )
    except WaferApiError as e:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=str(e),
        )

    prefix = f"[subagent_session:{subagent_session_id}]\n" if subagent_session_id else ""
    eval_section = "\n".join(eval_result_chunks) + "\n\n" if eval_result_chunks else ""
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=prefix + eval_section + "".join(text_chunks),
    )
