"""Shared tool-execution helpers used by sequential and parallel paths in agents.py."""

from dataclasses import replace
from typing import Any

from wafer.dtypes import (
    AgentState,
    Message,
    ToolCall,
    ToolResult,
)


def _build_tool_result_summary(tool_call: ToolCall, tool_result: ToolResult) -> dict[str, Any]:
    """Build result_summary dict for ToolExecutionEnd wide event."""
    result_summary: dict[str, Any] = {}
    if tool_call.name == "bash":
        if "command" in tool_call.args:
            result_summary["command"] = tool_call.args["command"]
        if tool_result.content:
            result_summary["output"] = str(tool_result.content)
    elif tool_call.name == "write":
        if "path" in tool_call.args:
            result_summary["path"] = tool_call.args["path"]
        if "content" in tool_call.args:
            result_summary["content"] = tool_call.args["content"]
    elif tool_call.name == "edit":
        if "file_path" in tool_call.args:
            result_summary["path"] = tool_call.args["file_path"]
        old_str = tool_call.args.get("old_string", "")
        new_str = tool_call.args.get("new_string", "")
        old_lines = old_str.count("\n") + (1 if old_str else 0)
        new_lines = new_str.count("\n") + (1 if new_str else 0)
        result_summary["lines_removed"] = old_lines
        result_summary["lines_added"] = new_lines
    if tool_result.details:
        for k, v in tool_result.details.items():
            if k in (
                "compiled", "correct", "speedup", "runtime_us",
                "error", "exit_code", "output_file",
            ):
                result_summary[k] = v
    if tool_result.is_error:
        if tool_result.error:
            result_summary["error"] = tool_result.error
        elif tool_result.content:
            result_summary["error"] = str(tool_result.content)
    return result_summary


async def _fresh_env_from_snapshot(
    env_class: type,
    env_data: dict,
    runtime_source: Any,
) -> Any:
    """Deserialize environment from snapshot and copy runtime attributes."""
    fresh = await env_class.deserialize(env_data)
    if hasattr(fresh, "copy_runtime_from"):
        fresh.copy_runtime_from(runtime_source)
    return fresh


def _tool_result_to_message(
    tool_call: ToolCall,
    tool_result: ToolResult,
) -> Message:
    """Convert a ToolResult into a Message for the trajectory."""
    if tool_result.is_error and tool_result.error:
        message_content = tool_result.error
        if tool_result.content:
            message_content = f"{tool_result.content}\n\nError: {tool_result.error}"
    else:
        message_content = tool_result.content
    return Message(
        role="tool",
        content=message_content,
        tool_call_id=tool_call.id,
        details=tool_result.details,
    )


def _apply_tool_outcome(
    state: AgentState,
    tool_result: ToolResult,
    messages_to_add: list[Message],
) -> AgentState:
    """Update state with tool result: append messages, update failure count."""
    updated_trajectory = replace(
        state.actor.trajectory,
        messages=state.actor.trajectory.messages + messages_to_add,
    )
    new_failures = 0 if not tool_result.is_error else state.consecutive_failures + 1
    return replace(
        state,
        actor=replace(state.actor, trajectory=updated_trajectory),
        consecutive_failures=new_failures,
    )
