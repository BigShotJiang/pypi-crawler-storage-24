"""HttpPushJsonFrontend — JsonFrontend that also pushes events via HTTPS.

When the agent runs on a target machine, SSH stdout polling adds 0.3s+ latency
per event. This frontend pushes events directly to the wafer-api ingest endpoint
via HTTPS, giving sub-100ms delivery. Stdout is still written for logging and
exit-code detection.

Activated when WAFER_EVENT_PUSH_URL is set in the environment.
"""
from __future__ import annotations

import json
import logging
import os
import queue
import threading
import time
from typing import Any

from .json_frontend import JsonFrontend

logger = logging.getLogger(__name__)

_BATCH_SIZE = 10
_FLUSH_INTERVAL_SEC = 0.1
_MAX_RETRIES = 3
_RETRY_DELAYS = (0.2, 0.5, 1.0)
_SENTINEL = object()


class HttpPushJsonFrontend(JsonFrontend):
    """JsonFrontend that also batches and POSTs events to an HTTP endpoint.

    Uses a single background worker thread that drains a queue. Events are
    batched by size (_BATCH_SIZE) or time (_FLUSH_INTERVAL_SEC), whichever
    comes first. The worker thread handles all HTTP I/O so _emit() never blocks.
    """

    def __init__(self, push_url: str, push_token: str, session_id: str, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._push_url = push_url
        self._push_token = push_token
        self._push_session_id = session_id
        self._queue: queue.Queue[dict | object] = queue.Queue()
        self._worker = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker.start()

    def _emit(self, obj: dict) -> None:
        super()._emit(obj)
        self._queue.put(obj)

    def _worker_loop(self) -> None:
        """Drain the queue, batch events, POST them. Runs until _SENTINEL."""
        import urllib.request

        url = f"{self._push_url}?session_id={self._push_session_id}&token={self._push_token}"
        batch: list[dict] = []
        last_send = time.monotonic()

        while True:
            try:
                item = self._queue.get(timeout=_FLUSH_INTERVAL_SEC)
            except queue.Empty:
                item = None

            if item is _SENTINEL:
                if batch:
                    self._post_batch(url, batch)
                return
            if item is not None:
                batch.append(item)

            should_send = (
                len(batch) >= _BATCH_SIZE
                or (batch and time.monotonic() - last_send >= _FLUSH_INTERVAL_SEC)
            )
            if should_send:
                self._post_batch(url, batch)
                batch = []
                last_send = time.monotonic()

    @staticmethod
    def _post_batch(url: str, batch: list[dict]) -> None:
        import urllib.request

        body = json.dumps(batch).encode()
        for attempt in range(_MAX_RETRIES):
            req = urllib.request.Request(
                url, data=body, method="POST",
                headers={"Content-Type": "application/json"},
            )
            try:
                with urllib.request.urlopen(req, timeout=5) as resp:
                    resp.read()
                return
            except Exception:
                if attempt < _MAX_RETRIES - 1:
                    delay = _RETRY_DELAYS[attempt]
                    logger.warning(
                        "event_push_failed attempt=%d/%d batch_size=%d, retrying in %.1fs",
                        attempt + 1, _MAX_RETRIES, len(batch), delay,
                    )
                    time.sleep(delay)
                else:
                    logger.error(
                        "event_push_failed permanently batch_size=%d — %d events lost",
                        len(batch), len(batch),
                    )

    async def stop(self) -> None:
        await super().stop()
        self._queue.put(_SENTINEL)
        self._worker.join(timeout=10)


def maybe_wrap_frontend(frontend: JsonFrontend) -> JsonFrontend:
    """If WAFER_EVENT_PUSH_URL is set, replace frontend with an HttpPushJsonFrontend."""
    push_url = os.environ.get("WAFER_EVENT_PUSH_URL")
    push_token = os.environ.get("WAFER_EVENT_PUSH_TOKEN")
    session_id = os.environ.get("WAFER_SESSION_ID")
    if not push_url or not push_token or not session_id:
        return frontend
    return HttpPushJsonFrontend(
        push_url=push_url,
        push_token=push_token,
        session_id=session_id,
        file=frontend.file,
        include_thinking=frontend.include_thinking,
        include_timing=frontend.include_timing,
    )
