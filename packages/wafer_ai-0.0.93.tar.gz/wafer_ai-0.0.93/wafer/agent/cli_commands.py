"""CLI command builders for external agent CLIs.

Used by subprocess_agents for top-level eval and subagent execution.
"""
from __future__ import annotations

import shlex


# ── Cursor ────────────────────────────────────────────────────────────────────

_CURSOR_AGENT_ARGS: tuple[str, ...] = (
    "--yolo", "--sandbox", "disabled", "--output-format", "stream-json",
)

_RESOLVE_AGENT = (
    'AGENT_BIN=$(command -v agent 2>/dev/null '
    '|| echo "$HOME/.local/bin/agent"); '
    'exec "$AGENT_BIN"'
)


def build_cursor_cli_args(
    prompt: str,
    *,
    model: str | None = None,
) -> list[str]:
    """Build Cursor CLI command as bash -c wrapper.

    Cursor installs to ~/.local/bin/agent which isn't in PATH inside
    Modal containers or Cursor's own sandbox. Wrapping via bash -c
    resolves the path at execution time on the target.
    """
    tail: list[str] = [*_CURSOR_AGENT_ARGS, "-p", prompt]
    if model:
        tail.extend(["--model", model])
    inner = " ".join(shlex.quote(a) for a in tail)
    return ["bash", "-c", f'{_RESOLVE_AGENT} {inner}']


# ── Claude Code ───────────────────────────────────────────────────────────────

_CLAUDE_CODE_ARGS: tuple[str, ...] = (
    "--output-format", "stream-json",
    "--allowedTools", "Bash,Read,Edit,Write,Glob,Grep",
)

_RESOLVE_CLAUDE = (
    'CLAUDE_BIN=$(command -v claude 2>/dev/null '
    '|| echo "$HOME/.npm-global/bin/claude"); '
    'exec "$CLAUDE_BIN"'
)


def build_claude_code_cli_args(
    prompt: str,
    *,
    system_prompt: str | None = None,
) -> list[str]:
    """Build Claude Code CLI command as bash -c wrapper.

    Claude Code installs via npm; binary may be in ~/.npm-global/bin.
    Uses --output-format stream-json for structured NDJSON output.
    No --model flag — Claude Code uses the account default.
    """
    tail: list[str] = [*_CLAUDE_CODE_ARGS, "-p", prompt]
    if system_prompt:
        tail.extend(["--append-system-prompt", system_prompt])
    inner = " ".join(shlex.quote(a) for a in tail)
    return ["bash", "-c", f'{_RESOLVE_CLAUDE} {inner}']


# ── Codex ─────────────────────────────────────────────────────────────────────

_CODEX_ARGS: tuple[str, ...] = (
    "--approval-mode", "full-auto",
)

_RESOLVE_CODEX = (
    'CODEX_BIN=$(command -v codex 2>/dev/null '
    '|| echo "$HOME/.npm-global/bin/codex"); '
    'exec "$CODEX_BIN"'
)


def build_codex_cli_args(
    prompt: str,
    *,
    model: str | None = None,
) -> list[str]:
    """Build OpenAI Codex CLI command as bash -c wrapper.

    Codex CLI installs via npm. Uses -q for quiet mode (no interactive UI)
    and --approval-mode full-auto for autonomous execution.
    """
    tail: list[str] = [*_CODEX_ARGS, "-q", prompt]
    if model:
        tail.extend(["--model", model])
    inner = " ".join(shlex.quote(a) for a in tail)
    return ["bash", "-c", f'{_RESOLVE_CODEX} {inner}']
