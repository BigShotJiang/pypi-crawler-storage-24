"""Shared parsers for CLI agent output (wafer, Claude Code, Codex).

Used by subprocess_agents for trajectory building and text extraction.
"""
from __future__ import annotations

import json
from typing import Any

from wafer.dtypes import Message, TextContent, ToolCallContent

from .wire_events import is_cursor_native_event, normalize_wire_event, translate_cursor_events


def parse_wafer_claude_code_format(output: str) -> list[Message]:
    """Parse wafer's own JsonFrontend --output-format stream-json into list[Message].

    This handles wafer's high-level event format (NOT real Claude Code CLI output).
    Wafer's JsonFrontend emits NDJSON with event types:
    - {"type": "system", "subtype": "init", ...}
    - {"type": "assistant", "message": {"content": [...]}}
    - {"type": "user", "message": {"content": [{"type": "tool_result", ...}]}}
    - {"type": "result", "subtype": "success", ...}
    JsonFrontend also emits granular tool_result events:
    - {"type": "tool_result", "tool_call_id": ..., "content": ..., "is_error": ...}
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event_type = event.get("type")
        if event_type == "assistant":
            content_blocks = _parse_claude_content_blocks(event)
            if content_blocks:
                messages.append(Message(role="assistant", content=content_blocks))
        elif event_type == "user":
            tool_messages = _parse_claude_tool_results(event)
            messages.extend(tool_messages)
        elif event_type == "tool_result":
            content = event.get("content", "")
            if isinstance(content, list):
                content = json.dumps(content)
            messages.append(
                Message(
                    role="tool",
                    content=str(content),
                    tool_call_id=event.get("tool_call_id", ""),
                )
            )
    return messages


def _parse_claude_content_blocks(event: dict[str, Any]) -> list[TextContent | ToolCallContent]:
    """Parse content blocks from Claude Code assistant message."""
    assert "message" in event
    assert "content" in event["message"]
    content_blocks: list[TextContent | ToolCallContent] = []
    raw_content = event["message"]["content"]
    for block in raw_content:
        block_type = block.get("type")
        if block_type == "text":
            content_blocks.append(TextContent(text=block.get("text", "")))
        elif block_type == "tool_use":
            content_blocks.append(
                ToolCallContent(
                    id=block.get("id", ""),
                    name=block.get("name", ""),
                    arguments=block.get("input", {}),
                )
            )
    return content_blocks


def _parse_claude_tool_results(event: dict[str, Any]) -> list[Message]:
    """Parse tool results from Claude Code user message."""
    assert "message" in event
    assert "content" in event["message"]
    messages: list[Message] = []
    raw_content = event["message"]["content"]
    for block in raw_content:
        if block.get("type") == "tool_result":
            messages.append(
                Message(
                    role="tool",
                    content=block.get("content", ""),
                    tool_call_id=block.get("tool_use_id", ""),
                )
            )
    return messages


def parse_wafer_stream_json(output: str) -> list[Message]:
    """Parse wafer agent --output-format stream-json into list[Message].

    Wafer's JsonFrontend emits NDJSON:
    - {"type": "text_delta", "delta": "..."}
    - {"type": "tool_call_start", "id": "...", "name": "..."}
    - {"type": "tool_call_end", "id": "...", "name": "...", "args": {...}}
    - {"type": "tool_result", "is_error": bool}
    - {"type": "session_complete"}
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    text_parts: list[str] = []
    tool_counter = 0

    def _flush_text() -> None:
        if text_parts:
            messages.append(Message(role="assistant", content="".join(text_parts)))
            text_parts.clear()

    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        event = normalize_wire_event(event)
        event_type = event.get("type", "")

        if event_type == "text_delta":
            text_parts.append(event.get("delta", ""))
        elif event_type == "tool_call_end":
            _flush_text()
            tool_id = f"wafer_tool_{tool_counter}"
            tool_counter += 1
            messages.append(Message(
                role="assistant",
                content=[ToolCallContent(
                    id=tool_id,
                    name=event.get("name", ""),
                    arguments=event.get("args", {}),
                )],
            ))
        elif event_type == "tool_result":
            tool_content = event.get("content", "(tool result)")
            messages.append(Message(
                role="tool",
                content=tool_content if tool_content else "(tool result)",
                tool_call_id=f"wafer_tool_{tool_counter - 1}" if tool_counter > 0 else "",
            ))
        elif event_type == "session_complete":
            break

    _flush_text()
    return messages


def parse_cursor_wire_events(output: str) -> list[Message]:
    """Parse translated cursor wire events into list[Message].

    The cloud API translates cursor stream-json events into canonical wire events:
    - {"type": "text_delta", "delta": "..."} — assistant text
    - {"type": "thinking_delta", "delta": "..."} — thinking text
    - {"type": "tool_call_start", "name": "...", "id": "...", "input": {...}}
    - {"type": "tool_call_end", "id": "...", "name": "...", "args": {...}}
    - {"type": "tool_result", "id": "...", "content": "..."}
    - {"type": "turn_end"} — end of one turn (does NOT end parsing)
    - {"type": "session_complete"} — end of session (terminates parsing)
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    text_parts: list[str] = []
    tool_calls_seen: dict[str, ToolCallContent] = {}

    def _flush_text() -> None:
        if text_parts:
            messages.append(Message(role="assistant", content="".join(text_parts)))
            text_parts.clear()

    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            raw = json.loads(line)
        except json.JSONDecodeError:
            continue
        if is_cursor_native_event(raw):
            translated = translate_cursor_events(raw)
        else:
            translated = [normalize_wire_event(raw)]
        done = False
        for event in translated:
            etype = event.get("type", "")
            if etype == "text_delta":
                text_parts.append(event.get("delta", ""))
            elif etype == "thinking_delta":
                text_parts.append(event.get("delta", ""))
            elif etype == "tool_call_start":
                _flush_text()
                call_id = event.get("id", "")
                tc = ToolCallContent(
                    id=call_id,
                    name=event.get("name", ""),
                    arguments=event.get("input", {}),
                )
                tool_calls_seen[call_id] = tc
                messages.append(Message(role="assistant", content=[tc]))
            elif etype == "tool_call_end":
                call_id = event.get("id", "")
                if call_id in tool_calls_seen:
                    tool_calls_seen[call_id] = ToolCallContent(
                        id=call_id,
                        name=event.get("name", tool_calls_seen[call_id].name),
                        arguments=event.get("args", tool_calls_seen[call_id].arguments),
                    )
            elif etype == "tool_result":
                content = event.get("content", "(tool result)")
                messages.append(Message(
                    role="tool",
                    content=content if content else "(tool result)",
                    tool_call_id=event.get("id", ""),
                ))
            elif etype == "session_complete":
                done = True
                break
        if done:
            break

    _flush_text()
    return messages


def parse_claude_code_cli_output(output: str) -> list[Message]:
    """Parse real Claude Code CLI --output-format stream-json into list[Message].

    Claude Code CLI emits raw Anthropic API streaming events:
    - content_block_start, content_block_delta, content_block_stop
    - message_start, message_delta, message_stop

    Accumulates text and tool_use blocks, flushes into Messages on message_stop.
    """
    assert isinstance(output, str)
    messages: list[Message] = []
    current_blocks: list[TextContent | ToolCallContent] = []
    text_parts: list[str] = []
    current_block_type = ""
    current_tool_id = ""
    current_tool_name = ""
    tool_json_fragments: list[str] = []

    def _flush_text() -> None:
        if text_parts:
            current_blocks.append(TextContent(text="".join(text_parts)))
            text_parts.clear()

    def _flush_message() -> None:
        _flush_text()
        if current_blocks:
            messages.append(Message(role="assistant", content=list(current_blocks)))
            current_blocks.clear()

    for line in output.strip().split("\n"):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        etype = event.get("type", "")

        if etype == "content_block_start":
            block = event.get("content_block", {})
            current_block_type = block.get("type", "")
            if current_block_type == "tool_use":
                _flush_text()
                current_tool_id = block.get("id", "")
                current_tool_name = block.get("name", "")
                tool_json_fragments = []

        elif etype == "content_block_delta":
            delta = event.get("delta", {})
            delta_type = delta.get("type", "")
            if delta_type == "text_delta":
                text_parts.append(delta.get("text", ""))
            elif delta_type == "thinking_delta":
                text_parts.append(delta.get("thinking", ""))
            elif delta_type == "input_json_delta":
                tool_json_fragments.append(delta.get("partial_json", ""))

        elif etype == "content_block_stop":
            if current_block_type == "tool_use":
                full_json = "".join(tool_json_fragments)
                try:
                    args = json.loads(full_json) if full_json else {}
                except json.JSONDecodeError:
                    args = {"_raw": full_json}
                current_blocks.append(ToolCallContent(
                    id=current_tool_id,
                    name=current_tool_name,
                    arguments=args,
                ))
                current_block_type = ""
                current_tool_id = ""
                current_tool_name = ""
                tool_json_fragments = []
            else:
                current_block_type = ""

        elif etype == "message_stop":
            _flush_message()

    # Flush any remaining content
    _flush_message()
    return messages


def parse_raw_text_fallback(output: str) -> list[Message]:
    """Fallback parser: treat entire output as single assistant message."""
    assert isinstance(output, str)
    if not output.strip():
        return []
    return [Message(role="assistant", content=output.strip())]
