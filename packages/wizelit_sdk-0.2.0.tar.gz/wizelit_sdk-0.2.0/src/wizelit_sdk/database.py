from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    create_async_engine,
    async_sessionmaker,
    AsyncSession,
    AsyncEngine
)
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional
import logging
import os

from wizelit_sdk.models.base import BaseModel

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Singleton database manager with connection pooling."""

    DATABASE_URL: str = ""
    POOL_SIZE: int = int(os.getenv("DB_POOL_SIZE", "5"))
    MAX_OVERFLOW: int = int(os.getenv("DB_MAX_OVERFLOW", "10"))
    POOL_TIMEOUT: int = int(os.getenv("DB_POOL_TIMEOUT", "30"))
    POOL_RECYCLE: int = int(os.getenv("DB_POOL_RECYCLE", "3600"))
    ECHO_SQL: bool = os.getenv("DB_ECHO_SQL", "false").lower() == "true"

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(
        self,
        database_url: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[str] = None,
        database: Optional[str] = None,
    ):
        if self._initialized:
            return

        # Prefer explicit URL first, then DATABASE_URL env var, then compose from POSTGRES_* vars.
        resolved_database_url = database_url or os.getenv("DATABASE_URL")
        if resolved_database_url:
            self.DATABASE_URL = resolved_database_url
        else:
            username_value = username or os.getenv("POSTGRES_USER")
            password_value = password or os.getenv("POSTGRES_PASSWORD")
            host_value = host or os.getenv("POSTGRES_HOST")
            port_value = port or os.getenv("POSTGRES_PORT")
            database_value = database or os.getenv("POSTGRES_DB")

            if not all([username_value, password_value, host_value, port_value, database_value]):
                raise ValueError(
                    "Database configuration is incomplete. Set DATABASE_URL or all POSTGRES_* variables."
                )

            self.DATABASE_URL = (
                f"postgresql+asyncpg://{username_value}:{password_value}@"
                f"{host_value}:{port_value}/{database_value}"
            )

        # Create async engine
        self.engine: AsyncEngine = create_async_engine(
            self.DATABASE_URL,
            pool_size=self.POOL_SIZE,
            max_overflow=self.MAX_OVERFLOW,
            pool_timeout=self.POOL_TIMEOUT,
            pool_recycle=self.POOL_RECYCLE,
            echo=self.ECHO_SQL,
            pool_pre_ping=True,
        )

        # Create async session factory
        self.async_session_factory = async_sessionmaker(
            self.engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False,
            autocommit=False,
        )

        self._initialized = True
        logger.info("Database manager initialized")

    async def init_db(self, drop_existing: bool = False):
        """
        Initialize database tables.

        Args:
            drop_existing: If True, drops all existing tables before creating
        """
        try:
            async with self.engine.begin() as conn:
                if drop_existing:
                    logger.warning("Dropping all existing tables")
                    await conn.run_sync(BaseModel.metadata.drop_all)

                await conn.run_sync(BaseModel.metadata.create_all)

            logger.info("Database tables initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
            raise

    @asynccontextmanager
    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """
        Async context manager for database sessions.

        Usage:
            async with db_manager.get_session() as session:
                user = await session.get(User, user_id)
                await session.commit()
        """
        session = self.async_session_factory()
        try:
            yield session
            await session.commit()
        except Exception as e:
            await session.rollback()
            logger.error(f"Session error: {e}")
            raise
        finally:
            await session.close()

    async def get_db(self) -> AsyncGenerator[AsyncSession, None]:
        """
        Dependency injection for FastAPI/similar frameworks.

        Usage:
            @app.get("/users")
            async def get_users(db: AsyncSession = Depends(db_manager.get_db)):
                result = await db.execute(select(User))
                return result.scalars().all()
        """
        session = self.async_session_factory()
        try:
            yield session
        finally:
            await session.close()

    async def close(self) -> None:
        """Dispose of the engine and close all connections."""
        await self.engine.dispose()
        logger.info("Database connections closed")

    async def health_check(self) -> bool:
        """Check if database connection is healthy."""
        try:
            async with self.get_session() as session:
                await session.execute(text("SELECT 1"))
            return True
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return False
