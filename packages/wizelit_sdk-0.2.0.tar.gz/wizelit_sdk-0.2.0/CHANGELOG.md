# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2026-03-09

### BREAKING CHANGES

- **Universal Bridge removed**: All bridge functionality has been moved to the standalone `wizelit-universal-bridge` package
- The `wizelit-sdk run-bridge` command has been removed
- Bridge-specific dependencies (aiohttp, pyyaml) removed from wizelit-sdk
- Optional extras `[universal-bridge]` and `[universal-bridge-grpc]` removed

### Migration Guide

If you were using the bridge functionality:

```bash
# Install the standalone bridge package
pip install wizelit-universal-bridge

# Update commands
# Old: wizelit-sdk run-bridge config.yaml
# New: wizelit-universal-bridge run-bridge config.yaml
```

See [wizelit-universal-bridge](https://github.com/wizeline/wizelit-universal-bridge) for full documentation.

## [0.1.0] - 2025-01-13

### Added

- Initial package structure
- Core wrapper functionality
- `greet()` utility function in `utils` module

[Unreleased]: https://github.com/your-org/wizelit-sdk/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/your-org/wizelit-sdk/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/your-org/wizelit-sdk/releases/tag/v0.1.0
