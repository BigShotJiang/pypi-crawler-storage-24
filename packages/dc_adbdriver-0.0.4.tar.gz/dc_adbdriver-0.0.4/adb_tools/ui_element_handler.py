import logging
import os
import re
import subprocess
import xml.etree.ElementTree as ET
from time import sleep
from typing import List, Optional, Tuple


class UiElementHandler:
    def __init__(self, deviceID):
        self.creation_flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        self.deviceID = deviceID

    def execute_command(self, command):
        full_cmd = f"adb -s {self.deviceID} {command}"
        result = subprocess.run(
            full_cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=self.creation_flags,
        )
        return result.stdout.decode().strip(), result.stderr.decode().strip()

    def find_element(self, locatorValue, locatorType="text"):
        self.execute_command("shell uiautomator dump /sdcard/window_dump.xml")
        stdout, _ = self.execute_command("shell cat /sdcard/window_dump.xml")
        try:
            root = ET.fromstring(stdout)
        except ET.ParseError:
            return []

        bounds_list = []

        if locatorType == "xpath":
            all_nodes = root.findall(".//node")
            for node in all_nodes:
                try:
                    if "contains(@text," in locatorValue:
                        search_text = re.findall(
                            r"contains\(@text, \"(.*?)\"\)", locatorValue
                        )
                        if search_text and search_text[0] in node.attrib.get(
                            "text", ""
                        ):
                            bounds_list.append(node.attrib.get("bounds"))
                    elif "contains(@content-desc," in locatorValue:
                        search_text = re.findall(
                            r"contains\(@content-desc, \"(.*?)\"\)", locatorValue
                        )
                        if search_text and search_text[0] in node.attrib.get(
                            "content-desc", ""
                        ):
                            bounds_list.append(node.attrib.get("bounds"))
                    elif "@" in locatorValue:
                        attr_match = re.findall(r"@(\w+)='(.*?)'", locatorValue)
                        if attr_match:
                            attr_name, attr_value = attr_match[0]
                            if node.attrib.get(attr_name, "") == attr_value:
                                bounds_list.append(node.attrib.get("bounds"))
                        elif "@text" in locatorValue and node.attrib.get("text", ""):
                            bounds_list.append(node.attrib.get("bounds"))
                except Exception as e:
                    logging.error(f"Error occurred while parsing XML: {e}")
                    continue
        else:
            for node in root.iter():
                if (
                    locatorType == "text"
                    and node.attrib.get("text", "") == locatorValue
                ):
                    bounds_list.append(node.attrib.get("bounds", None))
                elif (
                    locatorType in ["resource-id", "id"]
                    and node.attrib.get("resource-id", "") == locatorValue
                ):
                    bounds_list.append(node.attrib.get("bounds", None))
                elif (
                    locatorType == "des"
                    and node.attrib.get("content-desc", "") == locatorValue
                ):
                    bounds_list.append(node.attrib.get("bounds", None))
                elif locatorType == "index" and node.attrib.get("index") == str(
                    locatorValue
                ):
                    bounds_list.append(node.attrib.get("bounds", None))

        return [b for b in bounds_list if b]

    @staticmethod
    def parse_bounds(bounds_str: str) -> Optional[Tuple[int, int, int, int]]:
        try:
            parts = bounds_str.replace("[", "").replace("]", ",").strip(",").split(",")
            x1, y1, x2, y2 = map(int, parts[:4])
            return x1, y1, x2, y2
        except Exception as e:
            logging.error(f"Error parsing bounds: {e}")
            return None

    def tap_center(self, bounds_str):
        cords = self.parse_bounds(bounds_str)
        if cords:
            x1, y1, x2, y2 = cords
            cx = (x1 + x2) // 2
            cy = (y1 + y2) // 2
            self.execute_command(f"shell input tap {cx} {cy}")
            return True
        return False

    def long_press(self, bounds_str, duration=1000):
        cords = self.parse_bounds(bounds_str)
        if cords:
            x1, y1, x2, y2 = cords
            cx = (x1 + x2) // 2
            cy = (y1 + y2) // 2
            self.execute_command(f"shell input swipe {cx} {cy} {cx} {cy} {duration}")
            return True
        return False

    def enter_text(self, text):
        escaped_text = "".join("%s" if c == " " else c for c in text)
        self.execute_command(f'shell input text "{escaped_text}"')

    @staticmethod
    def filter_nodes(attribute: List[str]) -> List[str]:
        filtered_elements = []
        for element in attribute:
            if not element:
                continue

            lower_text = element.lower()
            if (
                "notification" in lower_text
                or "accounts center" in lower_text
                or "create facebook profile" in lower_text
                or "your instagram profile" in lower_text
            ):
                continue

            filtered_elements.append(element)
        return filtered_elements

    def interact_with_element(
        self,
        wait,
        locatorValue,
        locatorType="xpath",
        isJustWait=False,
        enter_text=None,
        index=None,
        is_long=False,
        get_attribute=False,
        attribute=None,
        get_all=False,
        status=False,
        filter_result=False,
    ):
        result_elements = []

        for i in range(int(wait)):
            try:
                elements = self.find_element(locatorValue, locatorType)
                if elements:
                    if get_all:
                        if get_attribute and attribute:
                            for element_bounds in elements:
                                stdout, _ = self.execute_command(
                                    "shell cat /sdcard/window_dump.xml"
                                )
                                root = ET.fromstring(stdout)
                                for node in root.iter():
                                    if node.attrib.get("bounds") == element_bounds:
                                        attr_value = node.attrib.get(attribute, None)
                                        result_elements.append(
                                            {
                                                attribute: attr_value,
                                                "bounds": element_bounds,
                                            }
                                        )
                                        break
                        else:
                            result_elements = elements
                        status = True
                        break
                    else:
                        idx = int(index) if index is not None else 0
                        if idx >= len(elements):
                            status = False
                        else:
                            element_bounds = elements[idx]
                            if get_attribute and attribute:
                                stdout, _ = self.execute_command(
                                    "shell cat /sdcard/window_dump.xml"
                                )
                                root = ET.fromstring(stdout)
                                for node in root.iter():
                                    if node.attrib.get("bounds") == element_bounds:
                                        result_elements.append(
                                            {
                                                attribute: node.attrib.get(
                                                    attribute, None
                                                ),
                                                "bounds": element_bounds,
                                            }
                                        )
                                        status = True
                                        break
                                break
                            elif enter_text is not None:
                                if self.tap_center(element_bounds):
                                    sleep(0.5)
                                    self.enter_text(enter_text)
                                    status = True
                                    break
                            else:
                                if isJustWait:
                                    status = True
                                    break
                                else:
                                    if is_long:
                                        if self.long_press(element_bounds):
                                            status = True
                                            break
                                    else:
                                        if self.tap_center(element_bounds):
                                            status = True
                                            break
                else:
                    status = False
            except Exception as e:
                logging.error(f"Error: {e}")
                status = False
            sleep(0.5)

        if filter_result and get_attribute and attribute and result_elements:
            filtered_attrs = self.filter_nodes(
                [
                    elem[attribute]
                    for elem in result_elements
                    if elem[attribute] is not None
                ]
            )
            result_elements = [
                elem for elem in result_elements if elem[attribute] in filtered_attrs
            ]

        if get_attribute or get_all:
            return status, result_elements
        return status
