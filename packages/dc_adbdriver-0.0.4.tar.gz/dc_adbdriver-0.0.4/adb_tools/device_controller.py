import base64
import json
import logging
import os
import re
import subprocess
import time
from time import sleep

from geopy.geocoders import Nominatim  # pip install geopy


class DeviceController:
    def __init__(self, deviceID: str = None):
        self.deviceID = deviceID
        self.creation_flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

    def perform_swipe(self, direction, duration=1000, wait=4):
        sleep(wait)
        try:
            output = subprocess.check_output(
                f"adb -s {self.deviceID} shell wm size",
                creationflags=self.creation_flags,
                shell=True,
            ).decode()
            _, size = output.strip().split(": ")
            width, height = map(int, size.split("x"))
        except subprocess.CalledProcessError:
            return

        if direction == "up":
            x1, y1, x2, y2 = (
                width // 2,
                int(height * 0.75),
                width // 2,
                int(height * 0.25),
            )
        elif direction == "down":
            x1, y1, x2, y2 = (
                width // 2,
                int(height * 0.25),
                width // 2,
                int(height * 0.75),
            )
        elif direction == "left":
            x1, y1, x2, y2 = (
                int(width * 0.75),
                height // 2,
                int(width * 0.25),
                height // 2,
            )
        elif direction == "right":
            x1, y1, x2, y2 = (
                int(width * 0.25),
                height // 2,
                int(width * 0.75),
                height // 2,
            )
        else:
            return

        while True:
            try:
                subprocess.check_call(
                    f"adb -s {self.deviceID} shell input swipe {x1} {y1} {x2} {y2} {duration}",
                    creationflags=self.creation_flags,
                    shell=True,
                )
                break
            except subprocess.CalledProcessError:
                sleep(wait)

    def open_url(self, url, wait=4):
        sleep(wait)
        try:
            command = f'adb -s {self.deviceID} shell am start -a android.intent.action.VIEW -d "{url}"'
            subprocess.check_output(
                command, shell=True, creationflags=self.creation_flags
            )
        except subprocess.CalledProcessError:
            return "Error opening URL"

    def start_app(self, package, wait=3):
        sleep(wait)
        try:
            subprocess.check_call(
                f'adb -s {self.deviceID} shell monkey -p {package} -c android.intent.category.LAUNCHER 1"',
                creationflags=self.creation_flags,
            )
        except subprocess.CalledProcessError:
            return "No such package"

    def stop_app(self, package, wait=3):
        sleep(wait)
        try:
            subprocess.check_call(
                f"adb -s {self.deviceID} shell am force-stop {package}",
                creationflags=self.creation_flags,
                shell=True,
            )
        except subprocess.CalledProcessError:
            return "Failed to stop app"

    def list_apps(self):
        try:
            result = subprocess.run(
                ["adb", "-s", self.deviceID, "shell", "pm", "list", "packages"],
                capture_output=True,
                text=True,
                check=True,
                creationflags=self.creation_flags,
                shell=True,
            )
            package_list = result.stdout.split("\n")
            packages = [
                package.split(":")[-1]
                for package in package_list
                if package.startswith("package:")
            ]
            return packages
        except subprocess.CalledProcessError:
            return "No such package"

    def get_device_display_info(self):
        none_resolution = "No Resolution"
        resolution = none_resolution

        try:
            result_resolution = subprocess.run(
                ['adb', '-s', self.deviceID, 'shell', 'wm', 'size'],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, creationflags=self.creation_flags
            )
            if result_resolution.returncode == 0 and "Physical size:" in result_resolution.stdout:
                resolution = result_resolution.stdout.strip().split("Physical size:")[1].strip()

            result_density = subprocess.run(
                ['adb', '-s', self.deviceID, 'shell', 'wm', 'density'],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, creationflags=self.creation_flags
            )
            if result_density.returncode == 0 and "Physical density:" in result_density.stdout:
                density = result_density.stdout.strip().split("Physical density:")[1].strip()
                if resolution == "720x1280" and density == "320":
                    return resolution
                else:
                    return none_resolution
            else:
                return none_resolution

        except Exception as e:
            logging.error(f"An unexpected error occurred: {e}")
            return none_resolution

    def get_device_model(self):
        cmd = ['adb'] + (['-s', self.deviceID] if self.deviceID else []) + [
            'shell', 'getprop', 'ro.product.model'
        ]
        try:
            return subprocess.check_output(
                cmd, creationflags=self.creation_flags, text=True
            ).strip()
        except subprocess.CalledProcessError:
            return None

    def facebook_status(self, wait=5):
        sleep(wait)
        try:
            result = subprocess.run(
                ["adb", "-s", self.deviceID, "shell", "ps"],
                capture_output=True,
                text=True,
                check=True,
                creationflags=self.creation_flags,
            )
            if "com.facebook.katana" in result.stdout:
                return "Facebook is running"
            else:
                return "Facebook is not running"
        except subprocess.CalledProcessError:
            return "Error checking if Facebook is running"

    def fetch_ip(self):
        try:
            check_ip = subprocess.check_output(
                f"adb -s {self.deviceID} shell curl ipinfo.io",
                creationflags=self.creation_flags,
                shell=True,
            )
            data = json.loads(check_ip.decode("utf-8"))
            ip_address = data["ip"]
            city = data["city"]
            country = data["country"]
            return ip_address, city, country
        except subprocess.CalledProcessError:
            return f"Error checking IP address for device: {self.deviceID}"

    def ping_test(self, timeout=4):
        try:
            result = subprocess.run(
                f"adb -s {self.deviceID} shell ping -c 1 8.8.8.8",
                shell=True,
                check=True,
                timeout=timeout,
                capture_output=True,
                text=True,
                creationflags=self.creation_flags,
            )

            match = re.search(r"time=(\d+\.?\d*)\s*ms", result.stdout)
            if match:
                ping_time = match.group(1)
                if float(ping_time) >= 250:
                    return f"{ping_time} ms (Slow Connection)"
                return f"{ping_time} ms"
            return None
        except subprocess.TimeoutExpired:
            return None

    def fetch_location(self):
        output = subprocess.check_output(
            ["adb", "-s", self.deviceID, "shell", "dumpsys", "location"],
            text=True,
            creationflags=self.creation_flags,
        )
        match = re.search(
            r"Location\[(?:gps|network|fused).*?\s([\d\.\-]+),([\d\.\-]+)", output
        )
        if not match:
            return None, None, None

        lat, lon = float(match.group(1)), float(match.group(2))
        geolocator = Nominatim(user_agent="fakegps-locator")
        location = geolocator.reverse((lat, lon), language="en")
        if location and location.raw:
            address = location.raw.get("address", {})
            city = address.get("city") or address.get("town") or address.get("village")
            country = address.get("country")
            return lat, lon, (city, country)
        return lat, lon, (None, None)

    def send_key(self, key, wait=4):
        sleep(wait)
        try:
            subprocess.check_call(
                f"adb -s {self.deviceID} shell input keyevent {str(key)}",
                creationflags=self.creation_flags,
                shell=True,
            )
        except Exception as e:
            logging.error(f"Failed to press key: {e}")

    def show_notifications(self, wait=3):
        sleep(wait)
        try:
            if (
                "device"
                in subprocess.run(
                    f"adb -s {self.deviceID}",
                    creationflags=self.creation_flags,
                    shell=True,
                    capture_output=True,
                    text=True,
                ).stdout
            ):
                subprocess.run(
                    f"adb -s {self.deviceID} shell service call statusbar 1",
                    creationflags=self.creation_flags,
                    shell=True,
                    check=True,
                )
        except subprocess.CalledProcessError:
            logging.error("Failed to open notification panel.")

    def hide_notifications(self, wait=3):
        sleep(wait)
        try:
            if (
                "device"
                in subprocess.run(
                    f"adb -s {self.deviceID}",
                    creationflags=self.creation_flags,
                    shell=True,
                    capture_output=True,
                    text=True,
                ).stdout
            ):
                subprocess.run(
                    f"adb -s {self.deviceID} shell service call statusbar 2",
                    creationflags=self.creation_flags,
                    shell=True,
                    check=True,
                )
        except subprocess.CalledProcessError:
            logging.error("Failed to close notification panel.")

    def tap(self, x, y, wait=4):
        sleep(wait)
        try:
            subprocess.check_call(
                f"adb -s {self.deviceID} shell input tap {x} {y}",
                creationflags=self.creation_flags,
                shell=True,
            )
        except subprocess.CalledProcessError as e:
            logging.error(
                f"An error occurred while clicking on position ({x}, {y}): {e}"
            )

    def type_text(self, text=None, VN=None, wait=3):
        sleep(wait)
        if text is None:
            text = str(base64.b64encode(VN.encode("utf-8")))[1:]
            subprocess.check_call(
                f"adb -s {self.deviceID} shell ime set com.android.adbkeyboard/.AdbIME",
                shell=True,
                creationflags=self.creation_flags,
            )
            subprocess.check_call(
                f"adb -s {self.deviceID} shell am broadcast -a ADB_INPUT_B64 --es msg {text}",
                shell=True,
                creationflags=self.creation_flags,
            )
            return
        for char in text:
            if char == " ":
                subprocess.check_call(
                    f"adb -s {self.deviceID} shell input keyevent SPACE",
                    shell=True,
                    creationflags=self.creation_flags,
                )
            elif char in [
                "`",
                "~",
                "!",
                "@",
                "#",
                "$",
                "%",
                "^",
                "&",
                "*",
                "(",
                ")",
                "-",
                "_",
                "=",
                "+",
                "{",
                "}",
                "[",
                "]",
                "|",
                ";",
                ":",
                "/",
                "?",
                "<",
                ">",
                ",",
                ".",
            ]:
                subprocess.check_call(
                    f'adb -s {self.deviceID} shell input text "{char}"',
                    shell=True,
                    creationflags=self.creation_flags,
                )
            else:
                subprocess.check_call(
                    f'adb -s {self.deviceID} shell input text "{char}"',
                    shell=True,
                    creationflags=self.creation_flags,
                )
            sleep(0.1)

    def extract_apk(self):
        package_name, target_root = "com.facebook.katana", "./application/app_facebook"
        try:
            result = subprocess.run(
                ["adb", "-s", self.deviceID, "shell", "pm", "path", package_name],
                capture_output=True,
                text=True,
                check=True,
                creationflags=self.creation_flags,
            )
            lines = result.stdout.strip().splitlines()
            if not lines:
                return "Not Found"
            apk_path = lines[0].replace("package:", "").strip()
        except subprocess.CalledProcessError:
            return "Not Found"

        try:
            version_result = subprocess.run(
                [
                    "adb",
                    "-s",
                    self.deviceID,
                    "shell",
                    "dumpsys",
                    "package",
                    package_name,
                ],
                capture_output=True,
                text=True,
                check=True,
                creationflags=self.creation_flags,
            )
            version_name = "Unknown"
            for line in version_result.stdout.splitlines():
                line = line.strip()
                if line.startswith("versionName="):
                    version_name = line.split("=", 1)[1]
                    break
        except subprocess.CalledProcessError:
            version_name = "Unknown"

        version_folder = os.path.join(target_root, version_name)
        target_apk_path = os.path.join(version_folder, f"{package_name}.apk")

        if os.path.exists(target_apk_path):
            return "Skipped"

        os.makedirs(version_folder, exist_ok=True)
        try:
            subprocess.run(
                ["adb", "-s", self.deviceID, "pull", apk_path, target_apk_path],
                capture_output=True,
                text=True,
                check=True,
                creationflags=self.creation_flags,
            )
            return "Success" if os.path.exists(target_apk_path) else "Failed"
        except subprocess.CalledProcessError:
            return "Failed"

    def fix_apk_version(self, apk_path: str):
        try:
            result = subprocess.run(
                ["aapt", "dump", "badging", apk_path],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                check=True,
                creationflags=self.creation_flags,
            )
            for line in result.stdout.splitlines():
                if "versionName=" in line:
                    parts = line.split("versionName='")
                    if len(parts) > 1:
                        return parts[1].split("'")[0]
        except (subprocess.CalledProcessError, FileNotFoundError):
            logging.error("Failed to get APK version")

        return None

    def check_facebook_version(self):
        try:
            result = subprocess.run(
                ['adb', '-s', self.deviceID, 'shell', 'dumpsys', 'package', 'com.facebook.katana'],
                capture_output=True,
                text=True,
                check=True,
                creationflags=self.creation_flags
            )

            output = result.stdout
            version_line = next((line for line in output.splitlines() if 'versionName' in line), None)
            if version_line:
                version = version_line.split('=')[1].strip()
                return f"{version}"

            return "Not Installed"

        except subprocess.CalledProcessError:
            logging.error("Failed to get APK version")
            return "Failed to get APK version"
        except Exception as e:
            logging.error(f"Error: {str(e)}")
            return f"Error: {str(e)}"

    def repair_facebook_apk(self):
        package_name, target_root = "com.facebook.katana", "./application/app_facebook"
        apk_entries = []
        if os.path.exists(target_root):
            for d in os.listdir(target_root):
                apk_path = os.path.join(target_root, d, f"{package_name}.apk")
                if os.path.exists(apk_path):
                    actual_version = self.fix_apk_version(apk_path)
                    if actual_version:
                        if d != actual_version:
                            correct_folder = os.path.join(target_root, actual_version)
                            os.makedirs(correct_folder, exist_ok=True)
                            new_path = os.path.join(
                                correct_folder, f"{package_name}.apk"
                            )
                            os.replace(apk_path, new_path)
                            old_folder = os.path.join(target_root, d)
                            try:
                                os.rmdir(old_folder)
                            except OSError:
                                pass
                            d = actual_version
                            apk_path = new_path
                    apk_entries.append((d, apk_path))

        if not apk_entries:
            return "Failed: No local APKs found"

        apk_entries.sort(key=lambda x: list(map(int, x[0].split("."))))
        latest_version, latest_apk_path = apk_entries[-1]

        try:
            subprocess.run(
                ["adb", "-s", self.deviceID, "install", "-r", latest_apk_path],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="ignore",
                check=True,
                creationflags=self.creation_flags,
            )
            return "Installed"
        except subprocess.CalledProcessError as e:
            return f"Failed: {e.stderr or str(e)}"

    def wait_for_install(self, package, timeout=30):
        start_time = time.time()
        while True:
            try:
                result = subprocess.run(
                    [
                        "adb",
                        "-s",
                        self.deviceID,
                        "shell",
                        "pm",
                        "list",
                        "packages",
                        package,
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )

                if package in result.stdout:
                    return "Installed"

            except Exception as e:
                logging.error(f"Error while checking package status: {e}")

            if time.time() - start_time >= timeout:
                break

            sleep(1)

        return "Not Installed"

    def network_status(self):
        try:
            result = subprocess.run(
                ["adb", "-s", self.deviceID, "shell", "ping", "-c", "1", "8.8.8.8"],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=self.creation_flags,
            )
            if result.returncode == 0:
                return "Connecting..."
            else:
                return "Not Connecting..."
        except subprocess.TimeoutExpired:
            return "Not Connecting..."

    def vpn_status(self, package):
        try:
            command = f"adb -s {self.deviceID} shell dumpsys notification --noredact | findstr {package}"
            result = subprocess.check_output(
                command, shell=True, text=True, creationflags=self.creation_flags
            )
            if "NotificationRecord" in result:
                return "Connection..."
            else:
                return "Not Connecting..."
        except subprocess.CalledProcessError:
            return "Not Connecting..."

    def remove_facebook(self, package="com.facebook.katana"):
        try:
            subprocess.run(
                ["adb", "-s", self.deviceID, "uninstall", package],
                capture_output=True,
                text=True,
                check=True,
                creationflags=self.creation_flags,
            )
            return f"Success: Uninstalled {package} on {self.deviceID}"
        except subprocess.CalledProcessError as e:
            return f"Failed: {e.stderr or str(e)}"

    def install_app(self, apk_relative_path):
        if not apk_relative_path:
            return "Not Specified"

        apk_root = "./application/app_facebook"
        full_apk_path = os.path.join(apk_root, apk_relative_path.replace("/", os.sep))
        if not os.path.exists(full_apk_path):
            return "Not Found"

        pkg_name = os.path.splitext(os.path.basename(full_apk_path))[0]
        try:
            result = subprocess.run(
                [
                    "adb",
                    "-s",
                    self.deviceID,
                    "shell",
                    "pm",
                    "list",
                    "packages",
                    pkg_name,
                ],
                capture_output=True,
                text=True,
                creationflags=self.creation_flags,
            )
            if pkg_name in result.stdout:
                return "Already Installed"
        except subprocess.CalledProcessError:
            return "Error checking"

        try:
            subprocess.run(
                ["adb", "-s", self.deviceID, "install", "-r", full_apk_path],
                check=True,
                creationflags=self.creation_flags,
            )
            return "Installation complete."
        except subprocess.CalledProcessError:
            return "Installation failed"

    def wipe_facebook_data(self):
        try:
            cmds = [
                [
                    "adb",
                    "-s",
                    self.deviceID,
                    "shell",
                    "su",
                    "-c",
                    "am force-stop com.facebook.katana",
                ],
                [
                    "adb",
                    "-s",
                    self.deviceID,
                    "shell",
                    "su",
                    "-c",
                    "pm clear com.facebook.katana",
                ],
                [
                    "adb",
                    "-s",
                    self.deviceID,
                    "shell",
                    "su",
                    "-c",
                    "rm -rf /sdcard/Android/data/com.facebook.katana",
                ],
                [
                    "adb",
                    "-s",
                    self.deviceID,
                    "shell",
                    "su",
                    "-c",
                    "rm -rf /sdcard/Android/media/com.facebook.katana",
                ],
            ]

            for cmd in cmds:
                result = subprocess.run(cmd, creationflags=self.creation_flags)
                if result.returncode != 0:
                    return "Failed to wipe Facebook data."

            return "Facebook data wipe complete."

        except Exception as e:
            return f"Error while clearing data: {e}"
