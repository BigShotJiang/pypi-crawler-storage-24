import logging
import os
import subprocess


class PermissionManager:
    def __init__(self, deviceID):
        self.deviceID = deviceID
        self.creation_flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

    def apply_permissions(self):
        permissions = [
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.READ_CONTACTS",
            "android.permission.CALL_PHONE",
            "android.permission.READ_CALL_LOG",
            "android.permission.READ_CALENDAR",
        ]
        results = {}
        for permission in permissions:
            try:
                command = [
                    "adb",
                    "-s",
                    self.deviceID,
                    "shell",
                    "pm",
                    "grant",
                    "com.facebook.katana",
                    permission,
                ]
                subprocess.run(
                    command, shell=False, creationflags=self.creation_flags, check=True
                )
                results[permission] = "Granted"
            except subprocess.CalledProcessError as e:
                logging.error(f"Failed: {e}")

        return results
