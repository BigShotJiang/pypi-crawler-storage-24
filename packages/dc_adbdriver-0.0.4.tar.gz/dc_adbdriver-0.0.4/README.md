# DC AdbDriver

**Credit:** Original development by **Dai Chao Online**

`dc-adbdriver` is a lightweight Python package for Android device automation using ADB.  
It helps developers control devices, manage apps, and automate actions with simple and clear methods.

---

## ✨ Features

- Launch and stop applications  
- Swipe and tap control  
- Text input automation  
- Network and latency checks  
- Location detection  
- APK export and installation tools  
- Facebook app management helpers  
- Supports Python 3.10+

---

## 📦 Installation

Install using pip:

```bash
pip install dc-adbdriver
```

## 🚀 Usage Example
```python
from adb_tools.device_controller import DeviceController

device = DeviceController(device_id="emulator-5554")

# Launch Facebook
print(device.start_app("com.facebook.katana"))

# Swipe up
device.perform_swipe("up")

# Check network status
print(device.network_status())
```