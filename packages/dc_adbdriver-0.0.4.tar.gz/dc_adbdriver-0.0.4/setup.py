from pathlib import Path

from setuptools import find_packages, setup

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="dc-adbdriver",
    version="0.0.4",
    packages=find_packages(),
    author="Dai Chao Online",
    description="A lightweight Khmer greeting utility for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    license="MIT",  # Choose a license (MIT, Apache-2.0, etc.)
    classifiers=[
        "Development Status :: 3 - Alpha",  # Change to Beta/Production as needed
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
    python_requires=">=3.8",  # Minimum Python version
    install_requires=[
        "requests",  # Example dependency
        "geopy",  # If you use geolocation
    ],
    extras_require={
        "dev": ["pytest", "flake8"],  # Optional dev dependencies
    },
    include_package_data=True,  # Include non-code files specified in MANIFEST.in
    keywords="adb android automation device-control",
)
