# SDK Python — `ascendkit`

Python 3.10+ SDK. httpx (async), published to PyPI.

## Commands
```bash
pip install -e ".[dev]"      # Install editable
pytest                       # Tests
ruff check . && ruff format .  # Lint + format
mypy ascendkit/              # Type checking
```

## Rules
- MUST use `httpx` — not `requests`. Support both sync and async patterns.
- Logger: drop-in for `logging` module. Keyword args for context: `logger.info("msg", port=3000)`
- Batch logs (5s / 100 events) via `POST /api/logs/ingest` — NEVER send one-at-a-time
- Flush on interpreter shutdown via `atexit`
- Public API through `ascendkit/__init__.py` — internal modules prefixed `_` (e.g., `_client.py`)
- Typed exceptions (`AscendKitError`, `AuthenticationError`) — NEVER swallow errors
- All public functions MUST have type annotations
- Gracefully handle network failures on flush — buffer and retry, NEVER crash host app
- In async frameworks, use `httpx.AsyncClient` — sync client blocks the event loop

## GUIDANCE
You are a thin client, rely on backend api for business logic validation