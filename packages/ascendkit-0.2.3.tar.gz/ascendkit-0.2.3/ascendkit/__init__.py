"""AscendKit Python SDK."""

from ascendkit._access_token import AccessTokenVerifier
from ascendkit._client import AscendKit, AsyncAscendKit
from ascendkit._errors import AscendKitError, AuthError, NotFoundError, ValidationError
from ascendkit._webhooks import verify_webhook_signature
from ascendkit.auth import AuthClient, AsyncAuthClient
from ascendkit.fastapi import get_current_user_dependency, get_current_user

__all__ = [
    "AccessTokenVerifier",
    "AscendKit",
    "AsyncAscendKit",
    "AuthClient",
    "AsyncAuthClient",
    "AscendKitError",
    "AuthError",
    "NotFoundError",
    "ValidationError",
    "verify_webhook_signature",
    "get_current_user_dependency",
    "get_current_user",
]
