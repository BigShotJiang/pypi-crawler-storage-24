"""Server-side analytics client for AscendKit.

.. deprecated::
    This module is not in use. Analytics has moved to the JS SDK
    (@ascendkit/nextjs). This file is kept for reference only.

Tracks events from your backend with trusted identity (secret key auth).
Events are queued in-memory and flushed in batches via a background thread.

Example::

    from ascendkit import Analytics

    analytics = Analytics("sk_prod_abc123")
    analytics.track("usr_456", "checkout.completed", {"orderId": "ord_789"})

    # Events flush automatically every 30s or when batch size (10) is reached.
    # On process exit, remaining events are flushed automatically via atexit.
"""

from __future__ import annotations

import atexit
import json
import logging
import os
import threading
import time
from datetime import datetime, timezone
from typing import Any
from urllib.request import Request, urlopen
from urllib.error import URLError

from ascendkit._client import _DEFAULT_API_URL
from ascendkit._version import SDK_VERSION

logger = logging.getLogger("ascendkit.analytics")
DEFAULT_FLUSH_INTERVAL = 30.0  # seconds
DEFAULT_BATCH_SIZE = 10
MAX_RETRY_ATTEMPTS = 3


class Analytics:
    """Server-side analytics client with background flushing.

    The ``secret_key`` parameter is optional — if omitted, the constructor
    reads ``ASCENDKIT_SECRET_KEY`` from the environment. Raises ``ValueError``
    if neither is provided.

    Args:
        secret_key: Your project's secret key (sk_prod_...). Falls back to ASCENDKIT_SECRET_KEY env var.
        api_url: AscendKit API base URL. Defaults to https://api.ascendkit.dev.
        flush_interval: Seconds between automatic flushes. Defaults to 30.
        batch_size: Max events before auto-flush. Defaults to 10.

    Example::

        analytics = Analytics()
        analytics.track("usr_456", "feature.used", {"feature": "dashboard"})
        analytics.shutdown()
    """

    def __init__(
        self,
        secret_key: str | None = None,
        *,
        api_url: str = _DEFAULT_API_URL,
        flush_interval: float = DEFAULT_FLUSH_INTERVAL,
        batch_size: int = DEFAULT_BATCH_SIZE,
    ) -> None:
        resolved_key = secret_key or os.environ.get("ASCENDKIT_SECRET_KEY")
        if not resolved_key:
            raise ValueError(
                "AscendKit Analytics: missing secret key. "
                "Pass secret_key or set ASCENDKIT_SECRET_KEY."
            )
        self._secret_key = resolved_key
        self._api_url = api_url.rstrip("/")
        self._flush_interval = flush_interval
        self._batch_size = batch_size
        self._queue: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._running = True

        # Background flush thread
        self._flush_thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._flush_thread.start()

        # Register atexit handler for graceful shutdown
        atexit.register(self.shutdown)

    def track(
        self,
        user_id: str,
        event_name: str,
        properties: dict[str, Any] | None = None,
    ) -> None:
        """Queue a server-side event for a user.

        Args:
            user_id: The user ID (usr_ prefixed).
            event_name: Event name (e.g. "checkout.completed").
            properties: Optional event properties.

        Example::

            analytics.track("usr_456", "checkout.completed", {"total": 99.99})
        """
        prefixed_name = event_name if event_name.startswith("app.") else f"app.{event_name}"
        event = {
            "eventName": prefixed_name,
            "userId": user_id,
            "properties": properties,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "context": {
                "sdk": "python",
                "sdkVersion": SDK_VERSION,
            },
        }

        batch: list[dict[str, Any]] | None = None
        with self._lock:
            self._queue.append(event)
            if len(self._queue) >= self._batch_size:
                batch = self._queue[:]
                self._queue.clear()

        # Flush outside the lock if batch size reached
        if batch is not None:
            self._send_batch(batch, attempt=0)

    def flush(self) -> None:
        """Manually flush the event queue."""
        with self._lock:
            if not self._queue:
                return
            batch = self._queue[:]
            self._queue.clear()

        self._send_batch(batch, attempt=0)

    def shutdown(self) -> None:
        """Gracefully shut down: stop the flush thread and flush remaining events."""
        self._running = False
        self.flush()

    # -----------------------------------------------------------------------
    # Internal
    # -----------------------------------------------------------------------

    def _flush_loop(self) -> None:
        """Background thread that periodically flushes the queue."""
        while self._running:
            time.sleep(self._flush_interval)
            try:
                self.flush()
            except Exception:
                logger.debug("Flush failed in background thread", exc_info=True)

    def _send_batch(self, batch: list[dict[str, Any]], attempt: int) -> None:
        """Send a batch of events to the API with retry."""
        if not batch:
            return

        url = f"{self._api_url}/api/v1/events"
        # Convert internal format to backend EventBatchRequest schema
        api_batch = [
            {"event": e["eventName"], "userId": e["userId"], "properties": e.get("properties"), "timestamp": e.get("timestamp")}
            for e in batch
        ]
        payload = json.dumps({"batch": api_batch}).encode("utf-8")

        req = Request(
            url,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "X-AscendKit-Secret-Key": self._secret_key,
                "X-AscendKit-Client-Version": f"python/{SDK_VERSION}",
            },
            method="POST",
        )

        try:
            with urlopen(req, timeout=10) as response:
                if response.status >= 400:
                    raise URLError(f"HTTP {response.status}")
        except Exception:
            if attempt < MAX_RETRY_ATTEMPTS:
                delay = (2 ** attempt)  # 1s, 2s, 4s
                time.sleep(delay)
                self._send_batch(batch, attempt + 1)
            else:
                logger.warning(
                    "Failed to send %d events after %d retries",
                    len(batch),
                    MAX_RETRY_ATTEMPTS,
                )
                # Put events back in the queue
                with self._lock:
                    self._queue = batch + self._queue
