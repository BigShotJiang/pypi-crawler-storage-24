# paperflow-postprocess

`paperflow-postprocess` packages the PaperFlow markdown post-processing logic as a reusable Python module.

It converts raw academic markdown into an Obsidian-friendly format by:

- normalizing LaTeX delimiters
- converting numbered citations into footnotes
- linkifying figure and table references
- injecting YAML frontmatter

## Install

```bash
pip install paperflow-postprocess
```

## Usage

```python
from paperflow_postprocess import postprocess

raw_markdown = """
Text with citation [1].

## References

[1] Example Author. Example Paper.
"""

markdown = postprocess(
    raw_markdown=raw_markdown,
    images={},
    metadata={
        "title": "Example Paper",
        "authors": ["Example Author"],
        "source": "https://example.com/paper",
        "date": "2026-03-11",
    },
)

print(markdown)
```

## API

- `postprocess(raw_markdown, images, metadata)`
- `fix_latex_delimiters(md)`
- `clean_headers_footers(md)`
- `convert_to_footnotes(md)`
- `linkify_figures(md)`
- `linkify_tables(md)`
- `inject_frontmatter(md, metadata)`
