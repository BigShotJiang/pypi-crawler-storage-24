Tryton FileStore Google Cloud Storage
=====================================

Google Cloud Storage for the Tryton application framework.

To use Google Cloud Storage, the trytond configuration must be modify to set in
the `database` section, the `class`  to `tryton_filestorage_gs.FileStoreGS` and
the `bucket` to the name of your bucket.
Here is an example the section::

    [database]
    class = tryton_filestorage_gs.FileStoreGS
    bucket = bucket-id-here

The authentication must be set using environment variable as explained in the
`Authentication section
<https://google-cloud-python.readthedocs.io/en/latest/core/auth.html>`_.
