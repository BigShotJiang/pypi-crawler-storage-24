from setuptools import setup
setup(name='privaton-beacon-img-66bafbfd9399d52a-png', version='774.508.302', py_modules=['data'])
