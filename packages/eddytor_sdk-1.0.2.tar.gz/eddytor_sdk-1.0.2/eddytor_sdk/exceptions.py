"""Eddytor SDK exceptions."""


class EddytorError(Exception):
    """Base exception for Eddytor SDK errors."""
    pass


class EddytorConnectionError(EddytorError):
    """Raised when connection to Eddytor fails."""
    pass


class EddytorQueryError(EddytorError):
    """Raised when a query fails."""
    pass


class EddytorAuthError(EddytorError):
    """Raised when authentication fails."""
    pass


class EddytorSchemaError(EddytorError):
    """Raised when data cannot be aligned to the target table schema."""
    pass
