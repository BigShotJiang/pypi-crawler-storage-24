from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Empty(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class QueryMessage(_message.Message):
    __slots__ = ("table_reference", "limit", "offset", "filters", "search_text", "search_columns", "sort_columns")
    TABLE_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    FILTERS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_TEXT_FIELD_NUMBER: _ClassVar[int]
    SEARCH_COLUMNS_FIELD_NUMBER: _ClassVar[int]
    SORT_COLUMNS_FIELD_NUMBER: _ClassVar[int]
    table_reference: ProtoTableReference
    limit: int
    offset: int
    filters: _containers.RepeatedCompositeFieldContainer[ColumnFilter]
    search_text: str
    search_columns: _containers.RepeatedScalarFieldContainer[str]
    sort_columns: _containers.RepeatedCompositeFieldContainer[SortColumn]
    def __init__(self, table_reference: _Optional[_Union[ProtoTableReference, _Mapping]] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., filters: _Optional[_Iterable[_Union[ColumnFilter, _Mapping]]] = ..., search_text: _Optional[str] = ..., search_columns: _Optional[_Iterable[str]] = ..., sort_columns: _Optional[_Iterable[_Union[SortColumn, _Mapping]]] = ...) -> None: ...

class SortColumn(_message.Message):
    __slots__ = ("column", "descending")
    COLUMN_FIELD_NUMBER: _ClassVar[int]
    DESCENDING_FIELD_NUMBER: _ClassVar[int]
    column: str
    descending: bool
    def __init__(self, column: _Optional[str] = ..., descending: bool = ...) -> None: ...

class ColumnFilter(_message.Message):
    __slots__ = ("column", "operator", "values")
    COLUMN_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_FIELD_NUMBER: _ClassVar[int]
    VALUES_FIELD_NUMBER: _ClassVar[int]
    column: str
    operator: str
    values: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, column: _Optional[str] = ..., operator: _Optional[str] = ..., values: _Optional[_Iterable[str]] = ...) -> None: ...

class ProtoTableReference(_message.Message):
    __slots__ = ("catalog", "schema", "table")
    CATALOG_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    TABLE_FIELD_NUMBER: _ClassVar[int]
    catalog: str
    schema: str
    table: str
    def __init__(self, catalog: _Optional[str] = ..., schema: _Optional[str] = ..., table: _Optional[str] = ...) -> None: ...

class ArrowRecordBatch(_message.Message):
    __slots__ = ("record_batch", "total_rows")
    RECORD_BATCH_FIELD_NUMBER: _ClassVar[int]
    TOTAL_ROWS_FIELD_NUMBER: _ClassVar[int]
    record_batch: bytes
    total_rows: int
    def __init__(self, record_batch: _Optional[bytes] = ..., total_rows: _Optional[int] = ...) -> None: ...

class TableRecordBatch(_message.Message):
    __slots__ = ("table_reference", "record_batch")
    TABLE_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    RECORD_BATCH_FIELD_NUMBER: _ClassVar[int]
    table_reference: ProtoTableReference
    record_batch: bytes
    def __init__(self, table_reference: _Optional[_Union[ProtoTableReference, _Mapping]] = ..., record_batch: _Optional[bytes] = ...) -> None: ...

class MergeRpcRequest(_message.Message):
    __slots__ = ("table_reference", "comment", "record_batch")
    TABLE_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    COMMENT_FIELD_NUMBER: _ClassVar[int]
    RECORD_BATCH_FIELD_NUMBER: _ClassVar[int]
    table_reference: ProtoTableReference
    comment: str
    record_batch: bytes
    def __init__(self, table_reference: _Optional[_Union[ProtoTableReference, _Mapping]] = ..., comment: _Optional[str] = ..., record_batch: _Optional[bytes] = ...) -> None: ...

class AddColumnRpcRequest(_message.Message):
    __slots__ = ("table_reference", "schema", "constraints")
    TABLE_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    CONSTRAINTS_FIELD_NUMBER: _ClassVar[int]
    table_reference: ProtoTableReference
    schema: bytes
    constraints: _containers.RepeatedCompositeFieldContainer[RpcConstraint]
    def __init__(self, table_reference: _Optional[_Union[ProtoTableReference, _Mapping]] = ..., schema: _Optional[bytes] = ..., constraints: _Optional[_Iterable[_Union[RpcConstraint, _Mapping]]] = ...) -> None: ...

class RpcConstraint(_message.Message):
    __slots__ = ("name", "expr")
    NAME_FIELD_NUMBER: _ClassVar[int]
    EXPR_FIELD_NUMBER: _ClassVar[int]
    name: str
    expr: str
    def __init__(self, name: _Optional[str] = ..., expr: _Optional[str] = ...) -> None: ...

class CreateTableRpcRequest(_message.Message):
    __slots__ = ("table_name", "schema", "constraints", "location", "comment", "override_table_on_insert")
    TABLE_NAME_FIELD_NUMBER: _ClassVar[int]
    SCHEMA_FIELD_NUMBER: _ClassVar[int]
    CONSTRAINTS_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    COMMENT_FIELD_NUMBER: _ClassVar[int]
    OVERRIDE_TABLE_ON_INSERT_FIELD_NUMBER: _ClassVar[int]
    table_name: str
    schema: bytes
    constraints: _containers.RepeatedCompositeFieldContainer[RpcConstraint]
    location: str
    comment: str
    override_table_on_insert: bool
    def __init__(self, table_name: _Optional[str] = ..., schema: _Optional[bytes] = ..., constraints: _Optional[_Iterable[_Union[RpcConstraint, _Mapping]]] = ..., location: _Optional[str] = ..., comment: _Optional[str] = ..., override_table_on_insert: bool = ...) -> None: ...

class CreateTableResponse(_message.Message):
    __slots__ = ("table_reference", "rows_inserted")
    TABLE_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    ROWS_INSERTED_FIELD_NUMBER: _ClassVar[int]
    table_reference: ProtoTableReference
    rows_inserted: int
    def __init__(self, table_reference: _Optional[_Union[ProtoTableReference, _Mapping]] = ..., rows_inserted: _Optional[int] = ...) -> None: ...
