"""
Eddytor Python SDK - Connect to Eddytor via Apache Arrow Flight SQL and REST APIs.

Example usage:
    from eddytor_sdk import EddytorClient

    client = EddytorClient(api_key="edd_live_xxx")

    # Query data via Flight SQL
    df = client.query("SELECT * FROM my_table LIMIT 10")
    print(df)

    # List schemas and tables
    schemas = client.list_schemas()
    tables = client.list_tables()

    # REST API operations
    # Table management
    metadata = client.rest.get_table_metadata("catalog", "schema", "table")
    history = client.rest.get_table_history("catalog", "schema", "table")

    # Storage operations
    configs = client.rest.get_storage_configs()
    objects = client.rest.list_objects(config_id, path="data/")

    # Column domains
    domain = client.rest.get_column_domain("catalog", "schema", "table", "column")
    client.rest.set_fixed_domain("catalog", "schema", "table", "column", ["A", "B", "C"])

    # AI-powered analysis
    result = client.rest.magic_dust(
        "catalog", "schema", "table",
        provider="Claude",
        action="Summary",
        model="claude-sonnet-4-5"
    )

    client.close()
"""

from .client import EddytorClient
from .exceptions import EddytorAuthError, EddytorError, EddytorConnectionError, EddytorQueryError, EddytorSchemaError
from .grpc_client import GrpcClient, StreamResult
from .rest import RestClient
from .storage import Storage
from .table import Table, Column
from .models import (
    # Enums
    SchemeType,
    AIProvider,
    AIAction,
    DomainType,
    # Table models
    ColumnInfo,
    TableMetadata,
    TableHistory,
    TableHistoryEntry,
    InferredSchema,
    MagicDustResult,
    CellReference,
    ExplainRowsResult,
    MoveTableResult,
    MoveObjectsResult,
    # Storage models
    StorageConfig,
    RegisteredTable,
    StorageObject,
    ListObjectsResult,
    # Domain models
    ColumnDomain,
    HierarchyNode,
    AllowedValues,
)

__version__ = "1.0.0"
__all__ = [
    # Main client
    "EddytorClient",
    "RestClient",
    "GrpcClient",
    "StreamResult",
    # Table/Column/Storage wrappers
    "Table",
    "Column",
    "Storage",
    # Exceptions
    "EddytorError",
    "EddytorAuthError",
    "EddytorConnectionError",
    "EddytorQueryError",
    "EddytorSchemaError",
    # Enums
    "SchemeType",
    "AIProvider",
    "AIAction",
    "DomainType",
    # Table models
    "ColumnInfo",
    "TableMetadata",
    "TableHistory",
    "TableHistoryEntry",
    "InferredSchema",
    "MagicDustResult",
    "CellReference",
    "ExplainRowsResult",
    "MoveTableResult",
    "MoveObjectsResult",
    # Storage models
    "StorageConfig",
    "RegisteredTable",
    "StorageObject",
    "ListObjectsResult",
    # Domain models
    "ColumnDomain",
    "HierarchyNode",
    "AllowedValues",
]
