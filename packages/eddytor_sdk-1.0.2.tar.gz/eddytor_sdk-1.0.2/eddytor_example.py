# ---------------------------------------------------------------------------
# SDK import — the only dependency beyond Python stdlib
# ---------------------------------------------------------------------------
import os
import sys

import pyarrow as pa

from eddytor_sdk import EddytorClient, EddytorQueryError
sys.path.insert(0, ".")  # allow running from tools/python/

with EddytorClient(api_key=os.environ["EDDYTOR_API_KEY"]) as client:
    tables = client.list_tables()              # all tables

    schemas = client.list_schemas()
    tables = client.list_tables("eddytor")      # filtered by schema

    # Via REST (tables registered in Eddytor, includes storage metadata)
    registered = client.rest.get_registered_tables(with_discovery=True)

    # Describe schema
    df = client.describe_table(
        "`eddytor`.`cfg_64529a68037a4afb98169c75c1ea2001`.`11687480588017948285_demo_products`")

    # Query as DataFrame, Arrow Table, or raw tuples
    df = client.query(
        "SELECT * FROM `eddytor`.`cfg_64529a68037a4afb98169c75c1ea2001`.`11687480588017948285_demo_products` LIMIT 10")
    print("DEMO PRODUCTS: \n", df)
    table = client.query_arrow(
        "SELECT * FROM `eddytor`.`cfg_64529a68037a4afb98169c75c1ea2001`.`11687480588017948285_demo_products` WHERE product_category = 'Electronics'")
    rows = client.execute(
        "SELECT product_id, product_name FROM `eddytor`.`cfg_64529a68037a4afb98169c75c1ea2001`.`11687480588017948285_demo_products`")

    # Helpers
    n = client.count(
        "`eddytor`.`cfg_64529a68037a4afb98169c75c1ea2001`.`11687480588017948285_demo_products`", where="status = 'Active'")
    exists = client.table_exists(
        "`eddytor`.`cfg_64529a68037a4afb98169c75c1ea2001`.`11687480588017948285_demo_products`")

    # SQL DML — all routed through Eddytor's merge pipeline
    # client.execute_dml(
    #     "INSERT INTO eddytor.cfg_64529a68037a4afb98169c75c1ea2001.11687480588017948285_demo_products VALUES (1, 'Alice')")
    # client.execute_dml(
    #     "UPDATE eddytor.cfg_64529a68037a4afb98169c75c1ea2001.11687480588017948285_demo_products SET name = 'Bob' WHERE id = 1")
    # client.execute_dml(
    #     "DELETE FROM eddytor.cfg_64529a68037a4afb98169c75c1ea2001.11687480588017948285_demo_products WHERE id = 1")

    # Bulk ingest via ADBC (Arrow or pandas)
    # data = pa.table({"id": [10, 20], "name": ["X", "Y"]})
    # client.ingest("11687480588017948285_demo_products", data, mode="append",
    #               catalog="eddytor", schema="cfg_64529a68037a4afb98169c75c1ea2001")

    # Via REST API
    table = client.table(
        catalog="eddytor",
        schema="cfg_64529a68037a4afb98169c75c1ea2001",
        table="11687480588017948285_demo_products"
    )

    history = table.history()
    # history.versions — list of versions with timestamps, operations, etc.

    metadata = table.metadata()
    print("METADATA: \n", metadata)

    num_rows = table.count()
    print("NUM ROWS: ", num_rows)

    # Rollback to a previous version
    # client.rest.rollback_table("eddytor", "cfg_64529a68037a4afb98169c75c1ea2001", "11687480588017948285_demo_products", version=3)
