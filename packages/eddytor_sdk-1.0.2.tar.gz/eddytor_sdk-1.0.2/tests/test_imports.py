"""Smoke tests — verify the SDK can be imported without errors."""


def test_import_sdk():
    from eddytor_sdk import EddytorClient, AIAction, AIProvider  # noqa: F401


def test_import_models():
    from eddytor_sdk import (  # noqa: F401
        CellReference,
        ExplainRowsResult,
        MagicDustResult,
        TableMetadata,
        TableHistory,
        StorageConfig,
        ColumnDomain,
    )


def test_explain_rows_action():
    from eddytor_sdk import AIAction

    assert AIAction.EXPLAIN_ROWS.value == "ExplainRows"
