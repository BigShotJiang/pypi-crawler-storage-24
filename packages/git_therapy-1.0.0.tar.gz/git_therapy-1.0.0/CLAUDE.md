# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

git-therapy is a CLI tool that psychoanalyzes Git history to build psychological profiles of development teams. It transforms objective commit data (timing, messages, patterns) into human narratives about developer behavior, stress patterns, and team dynamics.

## Development Commands

### Setup
```bash
# Install in development mode with all dependencies
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install
```

### Code Quality
```bash
# Run all linting and formatting
ruff check git_therapy/ tests/
ruff format git_therapy/ tests/

# Type checking
mypy git_therapy/

# Run pre-commit hooks manually
pre-commit run --all-files
```

### Testing
```bash
# Run all tests
python -m pytest

# Run specific test file
python -m pytest tests/test_git_log_parser.py

# Run specific test function
python -m pytest tests/test_git_log_parser.py::test_parse_commits

# Run tests with verbose output
python -m pytest -v
```

### CLI Testing
```bash
# Test basic functionality
python -m git_therapy.cli --max-count 5

# Test on specific repository
python -m git_therapy.cli --path /path/to/repo --max-count 10

# Test filtering options
python -m git_therapy.cli --author "name" --since "2023-01-01"

# Test JSON output
python -m git_therapy.cli --format json --max-count 3
```

## Architecture Overview

### Core Components

**git_therapy/parser/git_log.py**: Core data extraction from Git repositories
- `GitLogParser`: Main parser class that interfaces with gitpython
- `CommitData`: Dataclass representing structured commit information
- Handles filtering by author, date range, and commit count
- Lazy-loads Git repository to optimize performance

**git_therapy/cli.py**: Command-line interface
- Uses Click for argument parsing and validation
- Supports both summary and JSON output formats
- Main entry point defined in pyproject.toml as `git-therapy` command

**Analyzer modules** (git_therapy/analyzers/): Future psychological analysis components
- `rage.py`: Rage Commit Detection (planned)
- `sleep.py`: Sleep Deprivation Index (planned)
- `hero.py`: Hero Detection (planned)
- `personality.py`: Contributor personality profiling (planned)

**Report generation** (git_therapy/report/): HTML report creation (planned)
- `generator.py`: Report assembly
- `templates/`: Jinja2 HTML templates
- `assets/`: CSS, JS, Chart.js resources

### Data Flow

1. CLI receives user input and validates options
2. GitLogParser extracts structured commit data from repository
3. CommitData objects provide type-safe representation
4. Future: Analyzer modules process commit data for psychological insights
5. Future: Report generator creates interactive HTML output

### Development Patterns

- Strict type annotations enforced by mypy
- Dataclasses for structured data representation
- Click decorators require `# type: ignore[misc]` comments due to mypy limitations
- Pre-commit hooks enforce code quality (ruff, mypy, standard checks)
- Error handling uses specific exceptions with context

## Key Configuration

- **Python version**: 3.8+ (configured in pyproject.toml)
- **Linting**: ruff with line length 88, strict error checking
- **Type checking**: mypy with strict settings, relaxed for tests
- **Testing**: pytest with strict configuration
- **Pre-commit**: Enforces formatting, linting, and type checking before commits

## Testing Strategy

Tests use temporary Git repositories created with gitpython for isolation. Windows file permission errors during cleanup are expected and can be ignored - tests focus on functionality, not cleanup.

Test structure follows pytest conventions with fixtures for repository setup and comprehensive coverage of edge cases (invalid repos, merge commits, unicode handling).
