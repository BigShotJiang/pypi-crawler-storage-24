# Git Therapy - Advanced Git Repository Psychological Analysis

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Test Coverage](https://img.shields.io/badge/coverage-83%25-green.svg)](tests/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

git-therapy is a comprehensive CLI tool that psychoanalyzes Git repositories to build detailed psychological profiles of development teams. It transforms raw commit data into actionable insights about developer behavior, stress patterns, team dynamics, and workflow efficiency.

## 🚀 Features

### Core Analyzers
- **🔥 Rage Commit Detection**: Identifies frustration patterns and stress indicators
- **😴 Sleep Deprivation Analysis**: Detects unhealthy work patterns and night coding sessions
- **🦸‍♂️ Hero Moment Detection**: Recognizes emergency responders and weekend saves
- **👥 Personality Profiling**: Classifies developers into 5 psychological types
- **🤝 Team Dynamics**: Analyzes collaboration patterns and workflow efficiency

### Advanced Features
- **📊 Interactive HTML Reports**: Beautiful dashboards with Chart.js visualizations
- **⚙️ Configurable Thresholds**: YAML/JSON configuration for all analyzers
- **🚀 Performance Optimizations**: Parallel processing for large repositories
- **💡 Actionable Insights**: AI-powered recommendations and risk assessment
- **📈 Trend Analysis**: Historical patterns and regression detection

## 📦 Installation

```bash
# Install from source (recommended for development)
git clone https://github.com/yourusername/git-therapy.git
cd git-therapy
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install
```

## 🎯 Quick Start

### Basic Analysis
```bash
# Analyze current repository
git-therapy analyze

# Analyze specific repository with more commits
git-therapy analyze --path /path/to/repo --max-count 500

# Generate HTML report
git-therapy analyze --format html --output report.html
```

### Advanced Analysis with Team Dynamics
```bash
# Pro CLI with advanced features
git-therapy-pro analyze --include-team --max-count 1000

# Team-specific analysis
git-therapy-pro team --max-count 500

# With custom configuration
git-therapy-pro --config custom.yaml analyze --include-team
```

### Configuration Management
```bash
# Create default configuration
git-therapy-pro config --init

# View current settings
git-therapy-pro config --show

# Use custom config file
git-therapy-pro --config .git-therapy.yaml analyze
```

## 📊 Sample Output

### Summary Report
```
Git Therapy Analysis
==================================================
Repository: my-awesome-project
Branch: main
Total commits: 847
Contributors: 5
Analyzed commits: 500

Quick Stats:
  Lines added: +45,230
  Lines removed: -12,847
  Merge commits: 67

Team Dynamics:
  Communication Health: 76.2%
  Workflow Efficiency: 68.9%
  Knowledge Silos: 2
  Hot Files: 8

For detailed analysis:
    git-therapy-pro analyze --format html --output report.html
```

### Personality Types Detected
- **🎯 Perfezionista**: Detailed commits, extensive testing, high quality
- **🤠 Cowboy**: Large changes, infrequent commits, minimal tests
- **🚒 Pompiere**: Weekend fixes, emergency responses, irregular hours
- **👻 Ghost**: Rare but massive commits, minimal communication
- **⚖️ Tuttofare**: Balanced approach, consistent patterns

## ⚙️ Configuration

Create `.git-therapy.yaml` for custom thresholds:

```yaml
rage:
  high_rage_threshold: 0.8
  medium_rage_threshold: 0.5
  short_message_threshold: 15

sleep:
  night_start_hour: 22
  night_end_hour: 7
  high_risk_threshold: 0.3

hero:
  weekend_days: [5, 6]  # Saturday, Sunday
  emergency_keywords: ["urgent", "critical", "hotfix"]

personality:
  min_commits_threshold: 5

verbose_output: false
max_workers: 4
```

## 🔬 Analysis Examples

### Rage Commit Detection
```bash
# High rage detected: "FIX THE DAMN BUG!!!"
# Severity: HIGH | Score: 0.89 | Reasons: ALL_CAPS, SWEAR_WORDS, FRUSTRATION
```

### Sleep Deprivation Patterns
```bash
# Alice Developer: 34% night work (HIGH RISK)
# - 67 commits between 00:00-06:00
# - 3 consecutive night sessions detected
# - Estimated sleep debt: 23 hours
```

### Team Collaboration Health
```bash
# Communication Health: 68%
# - Good commit message quality
# - Moderate conflict resolution
# - Some knowledge silos detected

# Top Collaborations:
#   Alice ↔ Bob: 23 shared files
#   Carol ↔ Dave: 15 shared files (2 conflicts)
```

## 📈 Performance

git-therapy is optimized for repositories of all sizes:

- **Small repos** (<1K commits): ~2-5 seconds
- **Medium repos** (1K-10K commits): ~10-30 seconds
- **Large repos** (10K-100K commits): ~1-5 minutes
- **Enterprise repos** (100K+ commits): Use `--max-count` for faster results

### Performance Tips
```bash
# Limit scope for faster analysis
git-therapy-pro analyze --max-count 1000 --since "2024-01-01"

# Use parallel processing
git-therapy-pro analyze --max-workers 8

# Cache results with configuration
git-therapy-pro --config .git-therapy.yaml analyze
```

## 🧪 Development

### Run Tests
```bash
# All tests with coverage
python -m pytest --cov=git_therapy --cov-report=term-missing

# Specific analyzer tests
python -m pytest tests/test_rage_detector.py -v

# Integration tests
python -m pytest tests/test_advanced_cli.py -v
```

### Code Quality
```bash
# Linting and formatting
ruff check git_therapy/ tests/
ruff format git_therapy/ tests/

# Type checking
mypy git_therapy/

# Pre-commit hooks
pre-commit run --all-files
```

### Architecture Overview

```
git_therapy/
├── analyzers/          # Core psychological analyzers
│   ├── rage.py         # Rage commit detection
│   ├── sleep.py        # Sleep deprivation analysis
│   ├── hero.py         # Hero moment detection
│   ├── personality.py  # Developer personality profiling
│   ├── team_dynamics.py # Team collaboration analysis
│   └── insights.py     # AI-powered insights generation
├── parser/             # Git data extraction
│   └── git_log.py      # GitPython integration
├── report/             # HTML report generation
│   ├── generator.py    # Jinja2 + Chart.js reports
│   └── templates/      # HTML templates
├── config/             # Configuration management
│   └── __init__.py     # YAML/JSON config system
├── cli.py              # Basic CLI interface
├── advanced_cli.py     # Pro CLI with team features
└── performance.py      # Optimization utilities
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines
- Maintain >80% test coverage
- Follow PEP 8 style guidelines
- Add type annotations for all functions
- Update documentation for new features
- Test on both Windows and Unix systems

## 📋 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [GitPython](https://github.com/gitpython-developers/GitPython) for Git repository access
- [Chart.js](https://www.chartjs.org/) for beautiful visualizations
- [Click](https://click.palletsprojects.com/) for CLI framework
- [Jinja2](https://jinja.palletsprojects.com/) for HTML templating

## 📞 Support

- 📧 Email: support@git-therapy.dev
- 🐛 Issues: [GitHub Issues](https://github.com/yourusername/git-therapy/issues)
- 📖 Docs: [Documentation](https://git-therapy.readthedocs.io/)
- 💬 Discord: [Community Server](https://discord.gg/git-therapy)

---

> "Every commit tells a story. git-therapy helps you understand the human story behind the code."

Built with ❤️ for developers who want to understand their teams better.