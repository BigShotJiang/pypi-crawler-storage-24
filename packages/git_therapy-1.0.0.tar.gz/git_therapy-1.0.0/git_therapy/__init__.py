"""
git-therapy: A CLI tool that psychoanalyzes your Git history.

Your repository has a lot to say. Are you ready to listen?
"""

__version__ = "0.1.0"
