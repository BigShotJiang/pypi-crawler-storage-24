"""
Insights generator for git-therapy.

This module generates actionable recommendations and insights based on
analysis results from all analyzers.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional

from git_therapy.analyzers.hero import HeroAnalysis
from git_therapy.analyzers.personality import PersonalityProfile
from git_therapy.analyzers.sleep import SleepAnalysis
from git_therapy.analyzers.team_dynamics import TeamDynamics


@dataclass
class Insight:
    """A single actionable insight or recommendation."""

    title: str
    description: str
    severity: str  # "low", "medium", "high", "critical"
    category: str  # "communication", "workflow", "health", "performance"
    action_items: List[str]
    affected_contributors: List[str]
    priority_score: float  # 0-1, higher is more urgent


@dataclass
class InsightsReport:
    """Complete insights and recommendations report."""

    insights: List[Insight]
    overall_health_score: float
    key_risks: List[str]
    top_recommendations: List[str]
    team_strengths: List[str]


class InsightsGenerator:
    """Generates actionable insights from analysis results."""

    def __init__(self):
        self.severity_thresholds = {
            "critical": 0.8,
            "high": 0.6,
            "medium": 0.4,
            "low": 0.0,
        }

    def generate_insights(
        self,
        rage_analysis: Optional[Dict] = None,
        sleep_analysis: Optional[SleepAnalysis] = None,
        hero_analysis: Optional[HeroAnalysis] = None,
        personality_profiles: Optional[List[PersonalityProfile]] = None,
        team_dynamics: Optional[TeamDynamics] = None,
    ) -> InsightsReport:
        """Generate comprehensive insights from all analysis results."""
        insights = []

        # Rage-related insights
        if rage_analysis:
            insights.extend(self._generate_rage_insights(rage_analysis))

        # Sleep-related insights
        if sleep_analysis:
            insights.extend(self._generate_sleep_insights(sleep_analysis))

        # Hero-related insights
        if hero_analysis:
            insights.extend(self._generate_hero_insights(hero_analysis))

        # Personality-related insights
        if personality_profiles:
            insights.extend(self._generate_personality_insights(personality_profiles))

        # Team dynamics insights
        if team_dynamics:
            insights.extend(self._generate_team_insights(team_dynamics))

        # Calculate overall health score
        health_score = self._calculate_overall_health(
            rage_analysis,
            sleep_analysis,
            hero_analysis,
            personality_profiles,
            team_dynamics,
        )

        # Sort insights by priority
        insights.sort(key=lambda x: x.priority_score, reverse=True)

        # Generate summary information
        key_risks = self._extract_key_risks(insights)
        top_recommendations = self._extract_top_recommendations(insights)
        team_strengths = self._extract_team_strengths(
            rage_analysis,
            sleep_analysis,
            hero_analysis,
            personality_profiles,
            team_dynamics,
        )

        return InsightsReport(
            insights=insights,
            overall_health_score=health_score,
            key_risks=key_risks,
            top_recommendations=top_recommendations,
            team_strengths=team_strengths,
        )

    def _generate_rage_insights(self, rage_analysis: Dict) -> List[Insight]:
        """Generate insights from rage analysis."""
        insights = []
        rage_commits = rage_analysis.get("rage_commits", [])
        stats = rage_analysis.get("statistics", {})

        if not rage_commits:
            return insights

        # High rage rate insight
        total_commits = stats.get("total_rage_commits", 0) + len(rage_commits)
        rage_rate = len(rage_commits) / max(total_commits, 1)

        if rage_rate > 0.15:  # More than 15% rage commits
            severity = "high" if rage_rate > 0.25 else "medium"
            insights.append(
                Insight(
                    title="High Rage Commit Rate Detected",
                    description=f"Your team has {rage_rate:.1%} rage commits, indicating frustration and stress patterns.",
                    severity=severity,
                    category="health",
                    action_items=[
                        "Schedule team retrospective to discuss pain points",
                        "Review development tools and processes for friction",
                        "Consider pair programming to reduce individual stress",
                        "Improve code review process to catch issues earlier",
                    ],
                    affected_contributors=[],
                    priority_score=rage_rate,
                )
            )

        # Individual rage patterns
        rage_by_author = {}
        for commit in rage_commits:
            author = commit.author_email
            if author not in rage_by_author:
                rage_by_author[author] = []
            rage_by_author[author].append(commit)

        for author, commits in rage_by_author.items():
            if len(commits) >= 3:  # Multiple rage commits from same person
                insights.append(
                    Insight(
                        title="Recurring Frustration Pattern",
                        description=f"Developer {author.split('@')[0]} shows recurring frustration patterns.",
                        severity="medium",
                        category="health",
                        action_items=[
                            "Schedule 1:1 with developer to understand blockers",
                            "Review their current workload and deadlines",
                            "Provide additional tools or support",
                            "Consider rotating them to different tasks temporarily",
                        ],
                        affected_contributors=[author],
                        priority_score=len(commits) / 10,
                    )
                )

        return insights

    def _generate_sleep_insights(self, sleep_analysis: SleepAnalysis) -> List[Insight]:
        """Generate insights from sleep deprivation analysis."""
        insights = []

        if not hasattr(sleep_analysis, "contributors"):
            return insights

        for contributor in sleep_analysis.contributors:
            if contributor.night_percentage > 0.3:  # More than 30% night work
                severity = "high" if contributor.night_percentage > 0.5 else "medium"
                insights.append(
                    Insight(
                        title="Excessive Night Work Detected",
                        description=f"{contributor.author_name} is working {contributor.night_percentage:.1%} of time at night.",
                        severity=severity,
                        category="health",
                        action_items=[
                            "Review workload distribution and deadlines",
                            "Establish core working hours expectations",
                            "Provide time management training",
                            "Consider adjusting project timelines",
                            "Implement code freeze periods for work-life balance",
                        ],
                        affected_contributors=[contributor.author_email],
                        priority_score=contributor.night_percentage,
                    )
                )

            if contributor.consecutive_night_sessions >= 3:
                insights.append(
                    Insight(
                        title="Consecutive Night Work Sessions",
                        description=f"{contributor.author_name} has {contributor.consecutive_night_sessions} consecutive night work sessions.",
                        severity="high",
                        category="health",
                        action_items=[
                            "Immediate check-in with developer about workload",
                            "Review project urgency and scope",
                            "Ensure adequate rest periods between intense work",
                            "Consider bringing in additional resources",
                        ],
                        affected_contributors=[contributor.author_email],
                        priority_score=0.8,
                    )
                )

        return insights

    def _generate_hero_insights(self, hero_analysis: HeroAnalysis) -> List[Insight]:
        """Generate insights from hero analysis."""
        insights = []

        if not hasattr(hero_analysis, "hero_profiles"):
            return insights

        for hero in hero_analysis.hero_profiles:
            if hasattr(hero, "hero_score") and hero.hero_score > 0.7:
                insights.append(
                    Insight(
                        title="Hero Developer Pattern Detected",
                        description=f"{hero.author_name} frequently saves the day with emergency fixes.",
                        severity="medium",
                        category="workflow",
                        action_items=[
                            "Acknowledge and reward their contributions",
                            "Document their knowledge to reduce bus factor",
                            "Share emergency response knowledge with team",
                            "Implement better monitoring to prevent emergencies",
                            "Consider promoting them or giving them mentorship role",
                        ],
                        affected_contributors=[hero.author_email],
                        priority_score=0.6,
                    )
                )

        # Check for lack of heroes (could indicate low engagement)
        if len(hero_analysis.hero_profiles) == 0:
            insights.append(
                Insight(
                    title="No Hero Moments Detected",
                    description="Team shows no emergency response patterns, which could indicate low engagement or excellent preventive processes.",
                    severity="low",
                    category="workflow",
                    action_items=[
                        "Verify if this indicates good preventive processes or low engagement",
                        "Ensure team is equipped to handle emergencies when they arise",
                        "Consider cross-training for emergency scenarios",
                    ],
                    affected_contributors=[],
                    priority_score=0.2,
                )
            )

        return insights

    def _generate_personality_insights(
        self, personality_profiles: List[PersonalityProfile]
    ) -> List[Insight]:
        """Generate insights from personality analysis."""
        insights = []

        # Count personality types
        type_counts = {}
        for profile in personality_profiles:
            ptype = profile.personality_type
            type_counts[ptype] = type_counts.get(ptype, 0) + 1

        total_profiles = len(personality_profiles)

        # Check for imbalanced team composition
        if type_counts.get("Ghost", 0) / total_profiles > 0.4:
            insights.append(
                Insight(
                    title="High Proportion of Ghost Developers",
                    description="Team has many contributors with infrequent, large commits.",
                    severity="medium",
                    category="communication",
                    action_items=[
                        "Encourage more frequent, smaller commits",
                        "Implement regular code reviews and pair programming",
                        "Establish daily standup meetings for better communication",
                        "Create shared documentation practices",
                    ],
                    affected_contributors=[],
                    priority_score=0.5,
                )
            )

        if type_counts.get("Cowboy", 0) / total_profiles > 0.3:
            insights.append(
                Insight(
                    title="High Proportion of Cowboy Developers",
                    description="Team has many contributors making large, infrequent changes without tests.",
                    severity="high",
                    category="workflow",
                    action_items=[
                        "Implement mandatory code review process",
                        "Establish testing requirements and CI/CD",
                        "Provide training on test-driven development",
                        "Set up automated quality gates",
                    ],
                    affected_contributors=[],
                    priority_score=0.7,
                )
            )

        return insights

    def _generate_team_insights(self, team_dynamics: TeamDynamics) -> List[Insight]:
        """Generate insights from team dynamics analysis."""
        insights = []

        # Communication health insights
        if team_dynamics.communication_health < 0.6:
            insights.append(
                Insight(
                    title="Poor Team Communication Health",
                    description=f"Team communication health is {team_dynamics.communication_health:.1%}.",
                    severity="high",
                    category="communication",
                    action_items=[
                        "Improve commit message quality standards",
                        "Implement better merge conflict resolution processes",
                        "Establish communication guidelines and templates",
                        "Provide training on collaborative development practices",
                    ],
                    affected_contributors=[],
                    priority_score=1.0 - team_dynamics.communication_health,
                )
            )

        # Workflow efficiency insights
        if team_dynamics.workflow_efficiency < 0.6:
            insights.append(
                Insight(
                    title="Low Workflow Efficiency",
                    description=f"Team workflow efficiency is {team_dynamics.workflow_efficiency:.1%}.",
                    severity="medium",
                    category="workflow",
                    action_items=[
                        "Review and optimize development processes",
                        "Standardize commit sizes and frequency",
                        "Implement continuous integration best practices",
                        "Reduce revert rates through better testing",
                    ],
                    affected_contributors=[],
                    priority_score=1.0 - team_dynamics.workflow_efficiency,
                )
            )

        # Knowledge silos
        if len(team_dynamics.knowledge_silos) > 0:
            insights.append(
                Insight(
                    title="Knowledge Silos Detected",
                    description=f"Found {len(team_dynamics.knowledge_silos)} contributors with exclusive file access.",
                    severity="medium",
                    category="workflow",
                    action_items=[
                        "Implement code review rotation to spread knowledge",
                        "Organize knowledge sharing sessions",
                        "Document critical systems and processes",
                        "Encourage pair programming across team members",
                        "Create architectural decision records (ADRs)",
                    ],
                    affected_contributors=[
                        author for author, _ in team_dynamics.knowledge_silos
                    ],
                    priority_score=len(team_dynamics.knowledge_silos)
                    / team_dynamics.total_contributors,
                )
            )

        return insights

    def _calculate_overall_health(
        self,
        rage_analysis,
        sleep_analysis,
        hero_analysis,
        personality_profiles,
        team_dynamics,
    ) -> float:
        """Calculate overall team health score."""
        health_score = 85.0  # Base score

        # Rage penalty
        if rage_analysis:
            rage_commits = rage_analysis.get("rage_commits", [])
            total_commits = len(rage_commits) + rage_analysis.get("statistics", {}).get(
                "total_rage_commits", 0
            )
            if total_commits > 0:
                rage_rate = len(rage_commits) / total_commits
                health_score -= min(30, rage_rate * 100)

        # Sleep penalty
        if sleep_analysis and hasattr(sleep_analysis, "contributors"):
            avg_night_work = sum(
                c.night_percentage for c in sleep_analysis.contributors
            ) / len(sleep_analysis.contributors)
            health_score -= min(25, avg_night_work * 50)

        # Team dynamics adjustment
        if team_dynamics:
            health_score = (
                health_score
                * (
                    team_dynamics.communication_health
                    + team_dynamics.workflow_efficiency
                )
                / 2
            )

        return max(0.0, min(100.0, health_score))

    def _extract_key_risks(self, insights: List[Insight]) -> List[str]:
        """Extract top risks from insights."""
        high_priority_insights = [
            insight
            for insight in insights
            if insight.severity in ["high", "critical"] and insight.priority_score > 0.6
        ]
        return [insight.title for insight in high_priority_insights[:5]]

    def _extract_top_recommendations(self, insights: List[Insight]) -> List[str]:
        """Extract top actionable recommendations."""
        top_insights = insights[:3]  # Top 3 by priority
        recommendations = []
        for insight in top_insights:
            if insight.action_items:
                recommendations.append(insight.action_items[0])  # First action item
        return recommendations

    def _extract_team_strengths(
        self,
        rage_analysis,
        sleep_analysis,
        hero_analysis,
        personality_profiles,
        team_dynamics,
    ) -> List[str]:
        """Identify team strengths from analysis."""
        strengths = []

        # Low rage rate
        if rage_analysis:
            rage_commits = rage_analysis.get("rage_commits", [])
            total_commits = len(rage_commits) + rage_analysis.get("statistics", {}).get(
                "total_rage_commits", 0
            )
            if total_commits > 0:
                rage_rate = len(rage_commits) / total_commits
                if rage_rate < 0.1:
                    strengths.append("Low frustration levels in development process")

        # Good sleep patterns
        if sleep_analysis and hasattr(sleep_analysis, "contributors"):
            healthy_contributors = sum(
                1 for c in sleep_analysis.contributors if c.night_percentage < 0.15
            )
            if healthy_contributors / len(sleep_analysis.contributors) > 0.8:
                strengths.append(
                    "Healthy work-life balance maintained by most team members"
                )

        # Hero presence
        if (
            hero_analysis
            and hasattr(hero_analysis, "hero_profiles")
            and len(hero_analysis.hero_profiles) > 0
        ):
            strengths.append("Team has members ready to respond to emergencies")

        # Good communication
        if team_dynamics and team_dynamics.communication_health > 0.7:
            strengths.append("Excellent team communication and collaboration patterns")

        # Efficient workflow
        if team_dynamics and team_dynamics.workflow_efficiency > 0.7:
            strengths.append("Highly efficient development workflow")

        return strengths[:5]  # Top 5 strengths
