"""
Team dynamics analyzer for git-therapy.

This module analyzes collaboration patterns, identifies potential conflicts,
and provides insights into team communication and workflow health.
"""

from collections import defaultdict
from dataclasses import dataclass
from typing import Dict, List, Set, Tuple

from git_therapy.parser.git_log import CommitData


@dataclass
class CollaborationMetrics:
    """Metrics about collaboration between team members."""

    total_collaborations: int
    shared_files: Set[str]
    collaboration_frequency: float  # Collaborations per day
    overlap_percentage: float  # Percentage of files worked on by both
    merge_conflicts: int  # Estimated conflicts based on patterns


@dataclass
class TeamDynamics:
    """Overall team dynamics analysis."""

    total_contributors: int
    collaboration_matrix: Dict[Tuple[str, str], CollaborationMetrics]
    communication_health: float  # 0-1 score based on patterns
    workflow_efficiency: float  # 0-1 score based on merge patterns
    knowledge_silos: List[Tuple[str, Set[str]]]  # (contributor, exclusive_files)
    hot_files: List[Tuple[str, int]]  # (file, contributor_count)


class TeamDynamicsAnalyzer:
    """Analyzes team collaboration patterns and dynamics."""

    def __init__(self):
        self.conflict_indicators = [
            "conflict",
            "merge conflict",
            "resolve conflict",
            "fix merge",
            "merge fix",
            "revert",
            "undo",
        ]

    def analyze_team_dynamics(self, commits: List[CommitData]) -> TeamDynamics:
        """Analyze team collaboration patterns and dynamics."""
        if not commits:
            return TeamDynamics(
                total_contributors=0,
                collaboration_matrix={},
                communication_health=0.0,
                workflow_efficiency=0.0,
                knowledge_silos=[],
                hot_files=[],
            )

        # Group commits by author
        commits_by_author = defaultdict(list)
        for commit in commits:
            commits_by_author[commit.author_email].append(commit)

        total_contributors = len(commits_by_author)

        # Build collaboration matrix
        collaboration_matrix = self._build_collaboration_matrix(commits_by_author)

        # Calculate communication health
        communication_health = self._calculate_communication_health(commits)

        # Calculate workflow efficiency
        workflow_efficiency = self._calculate_workflow_efficiency(commits)

        # Identify knowledge silos
        knowledge_silos = self._identify_knowledge_silos(commits_by_author)

        # Find hot files (worked on by many people)
        hot_files = self._find_hot_files(commits)

        return TeamDynamics(
            total_contributors=total_contributors,
            collaboration_matrix=collaboration_matrix,
            communication_health=communication_health,
            workflow_efficiency=workflow_efficiency,
            knowledge_silos=knowledge_silos,
            hot_files=hot_files,
        )

    def _build_collaboration_matrix(
        self, commits_by_author: Dict[str, List[CommitData]]
    ) -> Dict[Tuple[str, str], CollaborationMetrics]:
        """Build a matrix of collaboration metrics between authors."""
        collaboration_matrix = {}
        authors = list(commits_by_author.keys())

        for i, author1 in enumerate(authors):
            for j, author2 in enumerate(authors):
                if i >= j:  # Avoid duplicates and self-comparison
                    continue

                metrics = self._calculate_collaboration_metrics(
                    commits_by_author[author1],
                    commits_by_author[author2],
                    author1,
                    author2,
                )

                collaboration_matrix[(author1, author2)] = metrics

        return collaboration_matrix

    def _calculate_collaboration_metrics(
        self,
        commits1: List[CommitData],
        commits2: List[CommitData],
        author1: str,
        author2: str,
    ) -> CollaborationMetrics:
        """Calculate collaboration metrics between two authors."""
        # Get all files touched by each author
        files1 = set()
        files2 = set()

        for commit in commits1:
            files1.update(commit.files_changed)

        for commit in commits2:
            files2.update(commit.files_changed)

        # Find shared files
        shared_files = files1.intersection(files2)

        # Calculate overlap percentage
        total_unique_files = len(files1.union(files2))
        overlap_percentage = (
            len(shared_files) / total_unique_files if total_unique_files > 0 else 0
        )

        # Estimate collaboration frequency
        all_commits = commits1 + commits2
        if all_commits:
            date_range = max(commit.timestamp for commit in all_commits) - min(
                commit.timestamp for commit in all_commits
            )
            days = max(1, date_range.days)
            collaboration_frequency = len(shared_files) / days
        else:
            collaboration_frequency = 0.0

        # Estimate merge conflicts based on overlapping files and commit patterns
        merge_conflicts = self._estimate_merge_conflicts(
            commits1, commits2, shared_files
        )

        return CollaborationMetrics(
            total_collaborations=len(shared_files),
            shared_files=shared_files,
            collaboration_frequency=collaboration_frequency,
            overlap_percentage=overlap_percentage,
            merge_conflicts=merge_conflicts,
        )

    def _estimate_merge_conflicts(
        self,
        commits1: List[CommitData],
        commits2: List[CommitData],
        shared_files: Set[str],
    ) -> int:
        """Estimate the number of merge conflicts between two authors."""
        conflicts = 0

        # Look for conflict-related keywords in commit messages
        all_commits = commits1 + commits2
        for commit in all_commits:
            message_lower = commit.message.lower()
            if any(
                indicator in message_lower for indicator in self.conflict_indicators
            ):
                conflicts += 1

        # Estimate based on overlapping work patterns
        # If two authors frequently work on the same files close in time, conflicts are likely
        for file in shared_files:
            commits1_file = [c for c in commits1 if file in c.files_changed]
            commits2_file = [c for c in commits2 if file in c.files_changed]

            # Check for commits within 24 hours of each other on the same file
            for c1 in commits1_file:
                for c2 in commits2_file:
                    time_diff = abs((c1.timestamp - c2.timestamp).total_seconds())
                    if time_diff < 24 * 3600:  # 24 hours
                        conflicts += 0.5  # Partial conflict score

        return int(conflicts)

    def _calculate_communication_health(self, commits: List[CommitData]) -> float:
        """Calculate team communication health based on commit patterns."""
        if not commits:
            return 0.0

        # Factors that indicate good communication:
        # 1. Detailed commit messages
        # 2. Low merge conflict rate
        # 3. Consistent commit patterns
        # 4. Proper merge commit usage

        total_score = 0.0
        max_score = 4.0

        # 1. Detailed commit messages (0-1 score)
        detailed_messages = sum(1 for commit in commits if len(commit.message) > 50)
        message_score = min(1.0, detailed_messages / len(commits) * 2)
        total_score += message_score

        # 2. Low conflict indicator rate (0-1 score)
        conflict_commits = sum(
            1
            for commit in commits
            if any(
                indicator in commit.message.lower()
                for indicator in self.conflict_indicators
            )
        )
        conflict_rate = conflict_commits / len(commits)
        conflict_score = max(0.0, 1.0 - conflict_rate * 3)  # Penalize conflicts heavily
        total_score += conflict_score

        # 3. Consistent commit patterns (0-1 score)
        # Look at commit frequency distribution
        commits_by_day = defaultdict(int)
        for commit in commits:
            day = commit.timestamp.date()
            commits_by_day[day] += 1

        if commits_by_day:
            daily_counts = list(commits_by_day.values())
            avg_daily = sum(daily_counts) / len(daily_counts)
            variance = sum((x - avg_daily) ** 2 for x in daily_counts) / len(
                daily_counts
            )
            consistency_score = max(0.0, 1.0 - variance / (avg_daily + 1))
            total_score += consistency_score

        # 4. Proper merge usage (0-1 score)
        merge_commits = sum(1 for commit in commits if commit.is_merge)
        merge_ratio = merge_commits / len(commits)
        # Good merge ratio is around 10-20%
        if 0.05 <= merge_ratio <= 0.25:
            merge_score = 1.0
        else:
            merge_score = max(0.0, 1.0 - abs(merge_ratio - 0.15) * 5)
        total_score += merge_score

        return min(1.0, total_score / max_score)

    def _calculate_workflow_efficiency(self, commits: List[CommitData]) -> float:
        """Calculate workflow efficiency based on commit patterns."""
        if not commits:
            return 0.0

        total_score = 0.0
        max_score = 3.0

        # 1. Reasonable commit sizes (0-1 score)
        commit_sizes = [commit.insertions + commit.deletions for commit in commits]
        avg_size = sum(commit_sizes) / len(commit_sizes)

        # Ideal commit size is 50-200 lines
        if 50 <= avg_size <= 200:
            size_score = 1.0
        else:
            size_score = max(0.0, 1.0 - abs(avg_size - 125) / 200)
        total_score += size_score

        # 2. Reasonable commit frequency (0-1 score)
        if len(commits) > 1:
            first_commit = min(commits, key=lambda x: x.timestamp)
            last_commit = max(commits, key=lambda x: x.timestamp)
            days = (last_commit.timestamp - first_commit.timestamp).days + 1
            commits_per_day = len(commits) / days

            # Ideal frequency is 2-8 commits per day
            if 2 <= commits_per_day <= 8:
                frequency_score = 1.0
            else:
                frequency_score = max(0.0, 1.0 - abs(commits_per_day - 5) / 10)
        else:
            frequency_score = 0.5
        total_score += frequency_score

        # 3. Low revert rate (0-1 score)
        revert_commits = sum(
            1 for commit in commits if "revert" in commit.message.lower()
        )
        revert_rate = revert_commits / len(commits)
        revert_score = max(0.0, 1.0 - revert_rate * 5)  # Heavily penalize reverts
        total_score += revert_score

        return min(1.0, total_score / max_score)

    def _identify_knowledge_silos(
        self, commits_by_author: Dict[str, List[CommitData]]
    ) -> List[Tuple[str, Set[str]]]:
        """Identify knowledge silos (files/areas only worked on by one person)."""
        # Track which files are touched by which authors
        files_by_author = defaultdict(set)
        authors_by_file = defaultdict(set)

        for author, commits in commits_by_author.items():
            for commit in commits:
                for file in commit.files_changed:
                    files_by_author[author].add(file)
                    authors_by_file[file].add(author)

        # Find files that are only touched by one author
        knowledge_silos = []
        for author, files in files_by_author.items():
            exclusive_files = {
                file for file in files if len(authors_by_file[file]) == 1
            }

            # Only consider it a silo if there are multiple exclusive files
            if len(exclusive_files) >= 3:
                knowledge_silos.append((author, exclusive_files))

        return knowledge_silos

    def _find_hot_files(self, commits: List[CommitData]) -> List[Tuple[str, int]]:
        """Find files that are worked on by many contributors (potential bottlenecks)."""
        authors_by_file = defaultdict(set)

        for commit in commits:
            for file in commit.files_changed:
                authors_by_file[file].add(commit.author_email)

        # Sort by number of contributors (descending)
        hot_files = [(file, len(authors)) for file, authors in authors_by_file.items()]
        hot_files.sort(key=lambda x: x[1], reverse=True)

        # Only return files worked on by 3+ people
        return [(file, count) for file, count in hot_files if count >= 3]
