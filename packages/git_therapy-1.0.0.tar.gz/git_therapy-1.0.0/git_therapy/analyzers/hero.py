"""Hero Detection analyzer.

Identifies team members who save critical situations and respond to emergencies.
"""

import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

from git_therapy.parser.git_log import CommitData


@dataclass
class HeroMoment:
    """Represents a heroic action by a developer."""

    commit: CommitData
    hero_type: str  # "weekend_save", "post_rage_fix", "hotfix", "emergency_response"
    hero_score: float
    context: str  # Description of what made this heroic
    urgency_level: str  # "low", "medium", "high", "critical"


@dataclass
class HeroProfile:
    """Hero profile for a contributor."""

    author_email: str
    author_name: str
    total_hero_score: float
    hero_moments: List[HeroMoment]
    specialties: List[str]  # Types of heroism this person excels at
    response_time_avg: Optional[float]  # Average response time to emergencies in hours
    weekend_saves: int
    emergency_fixes: int
    post_rage_interventions: int


@dataclass
class HeroAnalysis:
    """Overall hero analysis results."""

    hero_profiles: List[HeroProfile]
    team_hero_score: float
    top_heroes: List[str]  # Names of top 3 heroes
    critical_moments: List[HeroMoment]  # Most critical saves
    hero_timeline: List[Tuple[datetime, str, str]]  # (timestamp, hero, action)


class HeroDetector:
    """Detects heroic actions and team members who save critical situations."""

    def __init__(self):
        """Initialize hero detection patterns."""
        # Hotfix/emergency patterns in commit messages
        self.emergency_patterns = [
            r"\b(hotfix|emergency|urgent|critical|broken|fix.*production)\b",
            r"\b(rollback|revert.*production|emergency.*deploy)\b",
            r"\b(down|outage|incident|fire.*drill|crisis)\b",
            r"\b(ASAP|urgent.*fix|critical.*bug|production.*issue)\b",
        ]

        self.emergency_regex = re.compile(
            "|".join(self.emergency_patterns), re.IGNORECASE
        )

        # Weekend fix patterns (more heroic on weekends)
        self.weekend_fix_patterns = [
            r"\b(fix|patch|repair|resolve|solve)\b",
            r"\b(bug|issue|problem|error)\b",
        ]

        self.weekend_fix_regex = re.compile(
            "|".join(self.weekend_fix_patterns), re.IGNORECASE
        )

    def analyze_heroes(
        self, commits: List[CommitData], rage_commits: Optional[List] = None
    ) -> HeroAnalysis:
        """Analyze heroic patterns in commits.

        Args:
            commits: List of commit data to analyze
            rage_commits: Optional list of rage commits (from rage analyzer)

        Returns:
            Hero analysis results
        """
        # Sort commits chronologically
        sorted_commits = sorted(commits, key=lambda x: x.timestamp)

        # Find all hero moments
        all_hero_moments = []

        # Detect different types of heroic actions
        all_hero_moments.extend(self._detect_weekend_saves(sorted_commits))
        all_hero_moments.extend(self._detect_emergency_responses(sorted_commits))
        all_hero_moments.extend(self._detect_hotfixes(sorted_commits))

        if rage_commits:
            all_hero_moments.extend(
                self._detect_post_rage_interventions(sorted_commits, rage_commits)
            )

        # Group by contributor and create profiles
        hero_profiles = self._create_hero_profiles(all_hero_moments, sorted_commits)

        # Sort by total hero score
        hero_profiles.sort(key=lambda x: x.total_hero_score, reverse=True)

        # Calculate team statistics
        team_hero_score = sum(profile.total_hero_score for profile in hero_profiles)
        top_heroes = [profile.author_name for profile in hero_profiles[:3]]

        # Find most critical moments
        critical_moments = sorted(
            [
                moment
                for moment in all_hero_moments
                if moment.urgency_level in ["high", "critical"]
            ],
            key=lambda x: x.hero_score,
            reverse=True,
        )[:10]

        # Create hero timeline
        hero_timeline = [
            (
                moment.commit.timestamp,
                moment.commit.author_name,
                f"{moment.hero_type}: {moment.context}",
            )
            for moment in all_hero_moments
        ]
        hero_timeline.sort(key=lambda x: x[0])

        return HeroAnalysis(
            hero_profiles=hero_profiles,
            team_hero_score=round(team_hero_score, 1),
            top_heroes=top_heroes,
            critical_moments=critical_moments,
            hero_timeline=hero_timeline,
        )

    def _detect_weekend_saves(self, commits: List[CommitData]) -> List[HeroMoment]:
        """Detect commits made on weekends that appear to be emergency fixes."""
        weekend_heroes = []

        for commit in commits:
            # Check if weekend (Saturday=5, Sunday=6)
            if commit.timestamp.weekday() >= 5:
                # Check if it looks like a fix
                if self.weekend_fix_regex.search(commit.message):
                    # Higher score for more urgent-looking messages
                    urgency_score = 1.0
                    urgency_level = "medium"

                    if self.emergency_regex.search(commit.message):
                        urgency_score = 2.5
                        urgency_level = "high"

                    # Extra points for very early morning or late night weekend work
                    hour = commit.timestamp.hour
                    if hour < 6 or hour > 22:
                        urgency_score *= 1.5
                        urgency_level = (
                            "critical" if urgency_level == "high" else "high"
                        )

                    hero_moment = HeroMoment(
                        commit=commit,
                        hero_type="weekend_save",
                        hero_score=urgency_score,
                        context=f"Weekend fix at {commit.timestamp.strftime('%a %H:%M')}",
                        urgency_level=urgency_level,
                    )
                    weekend_heroes.append(hero_moment)

        return weekend_heroes

    def _detect_emergency_responses(
        self, commits: List[CommitData]
    ) -> List[HeroMoment]:
        """Detect emergency response commits based on message patterns."""
        emergency_heroes = []

        for commit in commits:
            if self.emergency_regex.search(commit.message):
                # Score based on time of day and day of week
                base_score = 2.0
                urgency_level = "high"

                # Higher score for off-hours (before 8 AM or after 6 PM)
                hour = commit.timestamp.hour
                if hour < 8 or hour > 18:
                    base_score *= 1.3
                    urgency_level = "critical"

                # Higher score for weekends
                if commit.timestamp.weekday() >= 5:
                    base_score *= 1.5
                    urgency_level = "critical"

                # Check for particularly urgent keywords
                urgent_keywords = ["critical", "production", "outage", "emergency"]
                if any(
                    keyword in commit.message.lower() for keyword in urgent_keywords
                ):
                    base_score *= 1.2

                hero_moment = HeroMoment(
                    commit=commit,
                    hero_type="emergency_response",
                    hero_score=base_score,
                    context=f"Emergency response: {commit.message.split()[0][:30]}...",
                    urgency_level=urgency_level,
                )
                emergency_heroes.append(hero_moment)

        return emergency_heroes

    def _detect_hotfixes(self, commits: List[CommitData]) -> List[HeroMoment]:
        """Detect hotfix commits that were likely urgent patches."""
        hotfix_heroes = []

        hotfix_patterns = [
            r"\bhotfix\b",
            r"\bquick.*fix\b",
            r"\bemergency.*patch\b",
            r"\brollback\b",
        ]
        hotfix_regex = re.compile("|".join(hotfix_patterns), re.IGNORECASE)

        for commit in commits:
            if hotfix_regex.search(commit.message):
                base_score = 1.5
                urgency_level = "medium"

                # Check if it's a small, focused change (likely a real hotfix)
                if commit.insertions + commit.deletions < 20:  # Small change
                    base_score *= 1.3

                # Check timing
                hour = commit.timestamp.hour
                if hour < 8 or hour > 18 or commit.timestamp.weekday() >= 5:
                    base_score *= 1.4
                    urgency_level = "high"

                hero_moment = HeroMoment(
                    commit=commit,
                    hero_type="hotfix",
                    hero_score=base_score,
                    context=f"Hotfix deployment: {commit.message.split()[0][:25]}...",
                    urgency_level=urgency_level,
                )
                hotfix_heroes.append(hero_moment)

        return hotfix_heroes

    def _detect_post_rage_interventions(
        self, commits: List[CommitData], rage_commits: List
    ) -> List[HeroMoment]:
        """Detect commits that fix issues shortly after rage commits by others."""
        intervention_heroes = []

        # Create a mapping of rage commit timestamps and authors
        rage_moments = [
            (rc.commit.timestamp, rc.commit.author_email) for rc in rage_commits
        ]

        for commit in commits:
            # Look for commits within 6 hours after each rage commit
            for rage_time, rage_author in rage_moments:
                # Skip if same author (can't save yourself from your own rage)
                if commit.author_email == rage_author:
                    continue

                time_diff = commit.timestamp - rage_time
                if timedelta(minutes=30) <= time_diff <= timedelta(hours=6):
                    # Check if it looks like a fix
                    fix_keywords = [
                        "fix",
                        "resolve",
                        "solve",
                        "repair",
                        "correct",
                        "patch",
                    ]
                    if any(
                        keyword in commit.message.lower() for keyword in fix_keywords
                    ):
                        # Calculate response time score (faster = more heroic)
                        hours_elapsed = time_diff.total_seconds() / 3600
                        response_score = max(0.5, 2.5 - (hours_elapsed * 0.3))

                        hero_moment = HeroMoment(
                            commit=commit,
                            hero_type="post_rage_fix",
                            hero_score=response_score,
                            context=f"Fixed issue {hours_elapsed:.1f}h after rage commit",
                            urgency_level="medium" if hours_elapsed < 2 else "low",
                        )
                        intervention_heroes.append(hero_moment)
                        break  # Only count once per commit

        return intervention_heroes

    def _create_hero_profiles(
        self, hero_moments: List[HeroMoment], all_commits: List[CommitData]
    ) -> List[HeroProfile]:
        """Create hero profiles for each contributor."""
        # Group hero moments by contributor
        contributor_moments = {}
        for moment in hero_moments:
            email = moment.commit.author_email
            if email not in contributor_moments:
                contributor_moments[email] = []
            contributor_moments[email].append(moment)

        profiles = []
        for email, moments in contributor_moments.items():
            if not moments:
                continue

            author_name = moments[0].commit.author_name
            total_score = sum(moment.hero_score for moment in moments)

            # Calculate specialties (most common hero types)
            hero_type_counts = {}
            for moment in moments:
                hero_type_counts[moment.hero_type] = (
                    hero_type_counts.get(moment.hero_type, 0) + 1
                )

            specialties = sorted(
                hero_type_counts.items(), key=lambda x: x[1], reverse=True
            )
            specialty_names = [
                spec[0].replace("_", " ").title() for spec, count in specialties[:3]
            ]

            # Calculate response time for emergencies
            emergency_moments = [m for m in moments if m.hero_type == "post_rage_fix"]
            avg_response_time = None
            if emergency_moments:
                # This would need rage commit timestamps to calculate properly
                # For now, we'll estimate based on urgency levels
                avg_response_time = 2.5  # Placeholder

            # Count different types of heroic actions
            weekend_saves = len([m for m in moments if m.hero_type == "weekend_save"])
            emergency_fixes = len(
                [m for m in moments if m.hero_type == "emergency_response"]
            )
            post_rage_fixes = len(
                [m for m in moments if m.hero_type == "post_rage_fix"]
            )

            profile = HeroProfile(
                author_email=email,
                author_name=author_name,
                total_hero_score=round(total_score, 1),
                hero_moments=sorted(moments, key=lambda x: x.hero_score, reverse=True),
                specialties=specialty_names,
                response_time_avg=avg_response_time,
                weekend_saves=weekend_saves,
                emergency_fixes=emergency_fixes,
                post_rage_interventions=post_rage_fixes,
            )
            profiles.append(profile)

        return profiles
