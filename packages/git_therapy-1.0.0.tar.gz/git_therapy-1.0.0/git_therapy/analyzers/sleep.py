"""Sleep Deprivation Index analyzer.

Analyzes commit timing patterns to detect sleep-deprived development sessions.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

from git_therapy.parser.git_log import CommitData


@dataclass
class SleepStats:
    """Sleep statistics for a contributor."""

    author_email: str
    author_name: str
    total_commits: int
    night_commits: int
    late_night_commits: int  # 00:00-03:00
    early_morning_commits: int  # 03:00-06:00
    weekend_commits: int
    night_percentage: float
    estimated_sleep_lost_hours: float
    risk_level: str  # "low", "medium", "high"


@dataclass
class SleepAnalysis:
    """Overall sleep deprivation analysis results."""

    contributor_stats: List[SleepStats]
    team_night_percentage: float
    total_estimated_sleep_lost: float
    highest_risk_contributors: List[str]
    night_commit_timeline: List[
        Tuple[datetime, str, str]
    ]  # (timestamp, author, message)
    consecutive_night_sessions: List[Dict]


class SleepDeprivationAnalyzer:
    """Analyzes commit timing patterns to detect sleep deprivation."""

    def __init__(self):
        """Initialize sleep analysis parameters."""
        # Time definitions
        self.night_start = 0  # 00:00
        self.night_end = 6  # 06:00
        self.late_night_end = 3  # 00:00-03:00 is "late night"

        # Sleep loss estimates (hours per night commit)
        self.sleep_loss_per_night_commit = 1.5
        self.weekend_sleep_loss_multiplier = 0.8  # Less critical on weekends

    def analyze_sleep_patterns(self, commits: List[CommitData]) -> SleepAnalysis:
        """Analyze sleep deprivation patterns in commits.

        Args:
            commits: List of commit data to analyze

        Returns:
            Sleep analysis results
        """
        # Group commits by contributor
        contributor_commits = self._group_by_contributor(commits)

        # Calculate stats for each contributor
        contributor_stats = []
        for email, author_commits in contributor_commits.items():
            stats = self._calculate_contributor_stats(author_commits)
            contributor_stats.append(stats)

        # Sort by night percentage (highest first)
        contributor_stats.sort(key=lambda x: x.night_percentage, reverse=True)

        # Calculate team-wide statistics
        total_commits = len(commits)
        total_night_commits = sum(self._is_night_commit(c.timestamp) for c in commits)
        team_night_percentage = (
            (total_night_commits / total_commits * 100) if total_commits > 0 else 0
        )

        total_sleep_lost = sum(
            stats.estimated_sleep_lost_hours for stats in contributor_stats
        )

        # Find highest risk contributors
        high_risk = [
            stats.author_name
            for stats in contributor_stats
            if stats.risk_level == "high"
        ]

        # Create night commit timeline
        night_commits = [c for c in commits if self._is_night_commit(c.timestamp)]
        night_timeline = [
            (c.timestamp, c.author_name, c.message.split("\n")[0][:60])
            for c in night_commits
        ]
        night_timeline.sort(key=lambda x: x[0])

        # Find consecutive night sessions
        consecutive_sessions = self._find_consecutive_night_sessions(commits)

        return SleepAnalysis(
            contributor_stats=contributor_stats,
            team_night_percentage=round(team_night_percentage, 2),
            total_estimated_sleep_lost=round(total_sleep_lost, 1),
            highest_risk_contributors=high_risk,
            night_commit_timeline=night_timeline,
            consecutive_night_sessions=consecutive_sessions,
        )

    def _group_by_contributor(
        self, commits: List[CommitData]
    ) -> Dict[str, List[CommitData]]:
        """Group commits by contributor email."""
        groups = {}
        for commit in commits:
            email = commit.author_email
            if email not in groups:
                groups[email] = []
            groups[email].append(commit)
        return groups

    def _calculate_contributor_stats(self, commits: List[CommitData]) -> SleepStats:
        """Calculate sleep statistics for a single contributor."""
        if not commits:
            return SleepStats(
                author_email="",
                author_name="",
                total_commits=0,
                night_commits=0,
                late_night_commits=0,
                early_morning_commits=0,
                weekend_commits=0,
                night_percentage=0.0,
                estimated_sleep_lost_hours=0.0,
                risk_level="low",
            )

        author_email = commits[0].author_email
        author_name = commits[0].author_name
        total_commits = len(commits)

        # Categorize commits by time
        night_commits = 0
        late_night_commits = 0
        early_morning_commits = 0
        weekend_commits = 0

        for commit in commits:
            timestamp = commit.timestamp
            hour = timestamp.hour
            weekday = timestamp.weekday()  # 0=Monday, 6=Sunday

            # Check if night commit (00:00-06:00)
            if self._is_night_commit(timestamp):
                night_commits += 1

                if hour < self.late_night_end:  # 00:00-03:00
                    late_night_commits += 1
                else:  # 03:00-06:00
                    early_morning_commits += 1

            # Check if weekend commit (Saturday=5, Sunday=6)
            if weekday >= 5:
                weekend_commits += 1

        # Calculate percentages and estimates
        night_percentage = (
            (night_commits / total_commits * 100) if total_commits > 0 else 0
        )

        # Estimate sleep lost (more sophisticated calculation)
        weekend_night_commits = self._count_weekend_night_commits(commits)
        weekday_night_commits = night_commits - weekend_night_commits

        estimated_sleep_lost = (
            weekday_night_commits * self.sleep_loss_per_night_commit
            + weekend_night_commits
            * self.sleep_loss_per_night_commit
            * self.weekend_sleep_loss_multiplier
        )

        # Determine risk level
        risk_level = self._determine_sleep_risk(
            night_percentage, night_commits, late_night_commits
        )

        return SleepStats(
            author_email=author_email,
            author_name=author_name,
            total_commits=total_commits,
            night_commits=night_commits,
            late_night_commits=late_night_commits,
            early_morning_commits=early_morning_commits,
            weekend_commits=weekend_commits,
            night_percentage=round(night_percentage, 2),
            estimated_sleep_lost_hours=round(estimated_sleep_lost, 1),
            risk_level=risk_level,
        )

    def _is_night_commit(self, timestamp: datetime) -> bool:
        """Check if a commit was made during night hours (00:00-06:00)."""
        hour = timestamp.hour
        return self.night_start <= hour < self.night_end

    def _count_weekend_night_commits(self, commits: List[CommitData]) -> int:
        """Count night commits that happened on weekends."""
        count = 0
        for commit in commits:
            if (
                self._is_night_commit(commit.timestamp)
                and commit.timestamp.weekday() >= 5
            ):
                count += 1
        return count

    def _determine_sleep_risk(
        self, night_percentage: float, night_commits: int, late_night_commits: int
    ) -> str:
        """Determine sleep deprivation risk level."""
        # High risk: >30% night commits OR >5 late night commits OR >50% if small sample
        if (
            night_percentage > 30
            or late_night_commits > 5
            or (night_percentage > 50 and night_commits >= 3)
        ):
            return "high"
        # Medium risk: >15% night commits OR >2 late night commits
        elif night_percentage > 15 or late_night_commits > 2:
            return "medium"
        else:
            return "low"

    def _find_consecutive_night_sessions(self, commits: List[CommitData]) -> List[Dict]:
        """Find sessions of consecutive night commits (potential crunch periods)."""
        # Sort commits by timestamp
        sorted_commits = sorted(commits, key=lambda x: x.timestamp)

        sessions = []
        current_session = []

        for commit in sorted_commits:
            if self._is_night_commit(commit.timestamp):
                # Check if this extends current session (within 24 hours of last)
                if current_session and commit.timestamp - current_session[
                    -1
                ].timestamp <= timedelta(hours=24):
                    current_session.append(commit)
                else:
                    # Save previous session if it has multiple commits
                    if len(current_session) >= 2:
                        sessions.append(self._create_session_dict(current_session))
                    # Start new session
                    current_session = [commit]
            else:
                # End of night session
                if len(current_session) >= 2:
                    sessions.append(self._create_session_dict(current_session))
                current_session = []

        # Don't forget last session
        if len(current_session) >= 2:
            sessions.append(self._create_session_dict(current_session))

        # Sort by session length (longest first)
        sessions.sort(key=lambda x: x["duration_hours"], reverse=True)

        return sessions[:5]  # Return top 5 longest sessions

    def _create_session_dict(self, session_commits: List[CommitData]) -> Dict:
        """Create a dictionary representation of a night session."""
        start_time = session_commits[0].timestamp
        end_time = session_commits[-1].timestamp
        duration = end_time - start_time

        # Get unique authors in this session
        authors = list(set(commit.author_name for commit in session_commits))

        return {
            "start_time": start_time,
            "end_time": end_time,
            "duration_hours": round(duration.total_seconds() / 3600, 1),
            "commit_count": len(session_commits),
            "authors": authors,
            "messages": [
                commit.message.split("\n")[0][:50] for commit in session_commits[:3]
            ],
        }
