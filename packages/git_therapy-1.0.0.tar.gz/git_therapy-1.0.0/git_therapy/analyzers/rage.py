"""Rage Commit Detection analyzer.

Analyzes commit messages for patterns associated with frustration and stress.
"""

import re
from dataclasses import dataclass
from typing import List, Tuple

from git_therapy.parser.git_log import CommitData


@dataclass
class RageCommit:
    """Represents a commit with detected rage patterns."""

    commit: CommitData
    rage_score: float
    reasons: List[str]
    severity: str  # "low", "medium", "high"


class RageCommitDetector:
    """Detects rage commits based on linguistic patterns in commit messages."""

    def __init__(self):
        """Initialize rage detection patterns."""
        # All caps patterns (excluding normal abbreviations)
        self.caps_pattern = re.compile(r"\b[A-Z]{4,}\b")

        # Swear words (English and Italian)
        self.swear_words = {
            "en": {
                "damn",
                "shit",
                "fuck",
                "fucking",
                "wtf",
                "omg",
                "ffs",
                "goddamn",
                "dammit",
                "crap",
                "hell",
                "bloody",
                "stupid",
                "idiot",
                "hate",
            },
            "it": {
                "merda",
                "cazzo",
                "dannazione",
                "maledetto",
                "stupido",
                "idiota",
                "schifoso",
                "porco",
                "odio",
                "basta",
            },
        }

        # Ultra-short frustrated messages
        self.short_frustrated = {
            "fix",
            "fix2",
            "fix3",
            "temp",
            "tmp",
            "ok",
            "please",
            "work",
            "why",
            "aaa",
            "ugh",
            "argh",
            "ffs",
            "omg",
            "wtf",
            "finally",
            "done",
        }

        # Multiple punctuation patterns
        self.multi_punct_pattern = re.compile(r"[!]{2,}|[?]{2,}|[.]{3,}")

        # Personal frustration indicators
        self.personal_indicators = {
            "i can't",
            "i hate",
            "this is",
            "why does",
            "i don't understand",
            "makes no sense",
            "not working",
            "broken",
            "again",
        }

    def analyze_commits(self, commits: List[CommitData]) -> List[RageCommit]:
        """Analyze a list of commits for rage patterns.

        Args:
            commits: List of commit data to analyze

        Returns:
            List of rage commits sorted by rage score (highest first)
        """
        rage_commits = []

        for commit in commits:
            rage_score, reasons = self._calculate_rage_score(commit)

            if rage_score > 0:
                severity = self._determine_severity(rage_score)
                rage_commit = RageCommit(
                    commit=commit,
                    rage_score=rage_score,
                    reasons=reasons,
                    severity=severity,
                )
                rage_commits.append(rage_commit)

        # Sort by rage score (highest first)
        rage_commits.sort(key=lambda x: x.rage_score, reverse=True)
        return rage_commits

    def _calculate_rage_score(self, commit: CommitData) -> Tuple[float, List[str]]:
        """Calculate rage score for a single commit.

        Returns:
            Tuple of (score, list of reasons)
        """
        message = commit.message.lower()
        original_message = commit.message
        score = 0.0
        reasons = []

        # Check for all caps (excluding normal abbreviations)
        caps_matches = self.caps_pattern.findall(original_message)
        if caps_matches:
            caps_score = min(len(caps_matches) * 1.5, 4.0)
            score += caps_score
            reasons.append(f"ALL CAPS words: {', '.join(caps_matches[:3])}")

        # Check for swear words
        for lang, words in self.swear_words.items():
            found_swears = [word for word in words if word in message]
            if found_swears:
                swear_score = min(len(found_swears) * 2.0, 3.0)
                score += swear_score
                reasons.append(f"Strong language detected ({lang})")

        # Check for ultra-short frustrated messages
        if len(message.strip()) <= 10:
            words = set(message.split())
            frustrated_words = words.intersection(self.short_frustrated)
            if frustrated_words:
                score += 2.5
                reasons.append(
                    f"Ultra-short frustrated message: '{original_message.strip()}'"
                )

        # Check for multiple punctuation
        punct_matches = self.multi_punct_pattern.findall(original_message)
        if punct_matches:
            punct_score = min(len(punct_matches) * 1.0, 2.0)
            score += punct_score
            reasons.append(f"Excessive punctuation: {', '.join(punct_matches[:3])}")

        # Check for personal frustration indicators
        for indicator in self.personal_indicators:
            if indicator in message:
                score += 1.5
                reasons.append(f"Personal frustration: '{indicator}'")
                break  # Only count one per commit

        # Check for commit message starting with "I" (personal vs professional)
        if (
            original_message.strip().startswith("I ")
            and len(original_message.strip()) > 10
        ):
            score += 0.5
            reasons.append("Personal tone (starts with 'I')")

        # Check for repeated words (sign of frustration)
        words = message.split()
        if len(words) >= 2:
            repeated = [
                word for word in words if words.count(word) >= 2 and len(word) > 2
            ]
            if repeated:
                score += 1.0
                reasons.append("Repeated words (possible frustration)")

        # Normalize score to 0-10 range
        final_score = min(score, 10.0)

        return final_score, reasons

    def _determine_severity(self, rage_score: float) -> str:
        """Determine severity level based on rage score."""
        if rage_score >= 6.0:
            return "high"
        elif rage_score >= 3.0:
            return "medium"
        else:
            return "low"

    def get_rage_statistics(self, rage_commits: List[RageCommit]) -> dict:
        """Calculate statistics about rage commits.

        Args:
            rage_commits: List of rage commits

        Returns:
            Dictionary with rage statistics
        """
        if not rage_commits:
            return {
                "total_rage_commits": 0,
                "average_rage_score": 0.0,
                "max_rage_score": 0.0,
                "severity_distribution": {"high": 0, "medium": 0, "low": 0},
                "most_common_reasons": [],
            }

        total_commits = len(rage_commits)
        total_score = sum(commit.rage_score for commit in rage_commits)
        average_score = total_score / total_commits
        max_score = max(commit.rage_score for commit in rage_commits)

        # Severity distribution
        severity_dist = {"high": 0, "medium": 0, "low": 0}
        for commit in rage_commits:
            severity_dist[commit.severity] += 1

        # Most common reasons
        all_reasons = []
        for commit in rage_commits:
            all_reasons.extend(commit.reasons)

        reason_counts = {}
        for reason in all_reasons:
            # Extract the reason type (before the colon if present)
            reason_type = reason.split(":")[0]
            reason_counts[reason_type] = reason_counts.get(reason_type, 0) + 1

        most_common = sorted(reason_counts.items(), key=lambda x: x[1], reverse=True)[
            :5
        ]

        return {
            "total_rage_commits": total_commits,
            "average_rage_score": round(average_score, 2),
            "max_rage_score": round(max_score, 2),
            "severity_distribution": severity_dist,
            "most_common_reasons": most_common,
        }
