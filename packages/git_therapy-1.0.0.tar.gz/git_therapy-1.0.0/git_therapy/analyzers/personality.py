"""Personality Profiler analyzer.

Categorizes developers into personality types based on their commit patterns.
"""

import re
from dataclasses import dataclass
from typing import Dict, List

from git_therapy.parser.git_log import CommitData


@dataclass
class PersonalityMetrics:
    """Metrics used to determine personality type."""

    commit_frequency: float  # commits per week
    avg_diff_size: float  # average lines changed per commit
    message_length_avg: float  # average commit message length
    test_file_ratio: float  # ratio of test files to total files
    merge_ratio: float  # ratio of merge commits
    working_hours_spread: float  # how spread out working hours are (0-1)
    weekend_ratio: float  # ratio of weekend commits
    revert_ratio: float  # ratio of commits that are reverts
    message_detail_score: float  # how detailed commit messages are (0-1)
    burst_intensity: float  # how much work is done in bursts vs steady


@dataclass
class PersonalityProfile:
    """Personality profile for a contributor."""

    author_email: str
    author_name: str
    personality_type: str  # "Perfezionista", "Cowboy", "Pompiere", "Ghost", "Tuttofare"
    confidence_score: float  # how confident we are in this classification (0-1)
    metrics: PersonalityMetrics
    characteristics: List[str]  # List of behavioral characteristics
    description: str  # Human-readable personality description
    type_scores: Dict[str, float]  # Scores for each personality type


class PersonalityProfiler:
    """Categorizes developers into personality types based on commit behavior."""

    def __init__(self):
        """Initialize personality profiling."""
        # Personality type definitions with their characteristic patterns
        self.personality_types = {
            "Perfezionista": {
                "description": "Makes many small, well-documented commits with detailed messages",
                "characteristics": [
                    "High commit frequency",
                    "Small diff sizes",
                    "Detailed commit messages",
                    "High test file ratio",
                    "Consistent working hours",
                    "Low revert ratio",
                ],
            },
            "Cowboy": {
                "description": "Makes large, infrequent commits that usually work on first try",
                "characteristics": [
                    "Low commit frequency",
                    "Large diff sizes",
                    "Short commit messages",
                    "Low test file ratio",
                    "Irregular hours",
                    "Low revert ratio",
                ],
            },
            "Pompiere": {
                "description": "Appears mainly during emergencies and critical fixes",
                "characteristics": [
                    "Irregular commit patterns",
                    "Emergency-focused",
                    "Weekend warrior",
                    "High merge ratio",
                    "Burst work style",
                    "Crisis-driven",
                ],
            },
            "Ghost": {
                "description": "Makes significant changes but commits rarely, hard to track",
                "characteristics": [
                    "Very low commit frequency",
                    "Very large diff sizes",
                    "Minimal messages",
                    "Irregular timing",
                    "High individual impact",
                    "Mysterious presence",
                ],
            },
            "Tuttofare": {
                "description": "Touches everything, commits regularly, balanced approach",
                "characteristics": [
                    "Moderate commit frequency",
                    "Varied diff sizes",
                    "Consistent presence",
                    "Balanced test/feature ratio",
                    "Regular hours",
                    "Jack of all trades",
                ],
            },
        }

        # Test file patterns
        self.test_patterns = [
            r"test.*\.py$",
            r".*_test\.py$",
            r".*\.test\.js$",
            r".*\.spec\.js$",
            r"spec/.*",
            r"tests?/.*",
            r"__tests__/.*",
        ]
        self.test_regex = re.compile("|".join(self.test_patterns), re.IGNORECASE)

    def analyze_personalities(
        self, commits: List[CommitData]
    ) -> List[PersonalityProfile]:
        """Analyze personality types for all contributors.

        Args:
            commits: List of commit data to analyze

        Returns:
            List of personality profiles sorted by confidence score
        """
        # Group commits by contributor
        contributor_commits = self._group_by_contributor(commits)

        profiles = []
        for email, author_commits in contributor_commits.items():
            if len(author_commits) < 3:  # Skip contributors with too few commits
                continue

            # Calculate metrics for this contributor
            metrics = self._calculate_metrics(author_commits, commits)

            # Determine personality type
            type_scores = self._calculate_type_scores(metrics)
            best_type = max(type_scores, key=type_scores.get)
            confidence = type_scores[best_type]

            # Create profile
            profile = PersonalityProfile(
                author_email=email,
                author_name=author_commits[0].author_name,
                personality_type=best_type,
                confidence_score=round(confidence, 2),
                metrics=metrics,
                characteristics=self.personality_types[best_type][
                    "characteristics"
                ].copy(),
                description=self.personality_types[best_type]["description"],
                type_scores={k: round(v, 2) for k, v in type_scores.items()},
            )
            profiles.append(profile)

        # Sort by confidence score (highest first)
        profiles.sort(key=lambda x: x.confidence_score, reverse=True)
        return profiles

    def _group_by_contributor(
        self, commits: List[CommitData]
    ) -> Dict[str, List[CommitData]]:
        """Group commits by contributor email."""
        groups = {}
        for commit in commits:
            email = commit.author_email
            if email not in groups:
                groups[email] = []
            groups[email].append(commit)
        return groups

    def _calculate_metrics(
        self, commits: List[CommitData], all_commits: List[CommitData]
    ) -> PersonalityMetrics:
        """Calculate personality metrics for a contributor."""
        if not commits:
            return PersonalityMetrics(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

        # Sort commits by timestamp
        sorted_commits = sorted(commits, key=lambda x: x.timestamp)

        # Time span analysis
        if len(sorted_commits) > 1:
            time_span = sorted_commits[-1].timestamp - sorted_commits[0].timestamp
            weeks = max(time_span.days / 7, 1)  # At least 1 week
        else:
            weeks = 1

        # Basic frequency metrics
        commit_frequency = len(commits) / weeks

        # Diff size metrics
        diff_sizes = [c.insertions + c.deletions for c in commits]
        avg_diff_size = sum(diff_sizes) / len(diff_sizes) if diff_sizes else 0

        # Message analysis
        message_lengths = [len(c.message) for c in commits]
        avg_message_length = (
            sum(message_lengths) / len(message_lengths) if message_lengths else 0
        )

        # Test file ratio
        test_files = 0
        total_files = 0
        for commit in commits:
            for file_path in commit.files_changed:
                total_files += 1
                if self.test_regex.search(file_path):
                    test_files += 1
        test_file_ratio = test_files / max(total_files, 1)

        # Merge ratio
        merge_commits = sum(1 for c in commits if c.is_merge)
        merge_ratio = merge_commits / len(commits)

        # Working hours analysis
        hours = [c.timestamp.hour for c in commits]
        working_hours_spread = self._calculate_hours_spread(hours)

        # Weekend ratio
        weekend_commits = sum(1 for c in commits if c.timestamp.weekday() >= 5)
        weekend_ratio = weekend_commits / len(commits)

        # Revert ratio
        revert_commits = sum(
            1
            for c in commits
            if "revert" in c.message.lower() or "rollback" in c.message.lower()
        )
        revert_ratio = revert_commits / len(commits)

        # Message detail score (based on length and structure)
        message_detail_score = self._calculate_message_detail_score(commits)

        # Burst intensity (how much work is done in bursts vs steady)
        burst_intensity = self._calculate_burst_intensity(sorted_commits)

        return PersonalityMetrics(
            commit_frequency=round(commit_frequency, 2),
            avg_diff_size=round(avg_diff_size, 1),
            message_length_avg=round(avg_message_length, 1),
            test_file_ratio=round(test_file_ratio, 3),
            merge_ratio=round(merge_ratio, 3),
            working_hours_spread=round(working_hours_spread, 3),
            weekend_ratio=round(weekend_ratio, 3),
            revert_ratio=round(revert_ratio, 3),
            message_detail_score=round(message_detail_score, 3),
            burst_intensity=round(burst_intensity, 3),
        )

    def _calculate_hours_spread(self, hours: List[int]) -> float:
        """Calculate how spread out working hours are (0 = concentrated, 1 = very spread)."""
        if not hours:
            return 0.0

        # Count commits in each hour bucket
        hour_counts = {}
        for hour in hours:
            hour_counts[hour] = hour_counts.get(hour, 0) + 1

        # Calculate standard deviation of hour distribution
        if len(set(hours)) <= 1:  # All same hour
            return 0.0

        mean_hour = sum(hours) / len(hours)
        variance = sum((hour - mean_hour) ** 2 for hour in hours) / len(hours)
        std_dev = variance**0.5

        # Normalize to 0-1 range (12 hours would be max std dev for even distribution)
        max_std = 12.0
        return min(std_dev / max_std, 1.0)

    def _calculate_message_detail_score(self, commits: List[CommitData]) -> float:
        """Calculate how detailed commit messages are (0-1)."""
        if not commits:
            return 0.0

        total_score = 0.0
        for commit in commits:
            message = commit.message.strip()
            score = 0.0

            # Length bonus
            if len(message) > 50:
                score += 0.3
            if len(message) > 100:
                score += 0.2

            # Multi-line bonus
            if "\n" in message:
                score += 0.2

            # Bullet points or structured format
            if re.search(r"[-*+]\s", message) or re.search(
                r"^\d+\.", message, re.MULTILINE
            ):
                score += 0.15

            # Explains "why" not just "what"
            why_words = ["because", "since", "to", "for", "so that", "in order to"]
            if any(word in message.lower() for word in why_words):
                score += 0.15

            total_score += min(score, 1.0)

        return total_score / len(commits)

    def _calculate_burst_intensity(self, sorted_commits: List[CommitData]) -> float:
        """Calculate burst intensity (0 = steady work, 1 = very bursty)."""
        if len(sorted_commits) < 3:
            return 0.0

        # Calculate time gaps between commits
        gaps = []
        for i in range(1, len(sorted_commits)):
            gap = sorted_commits[i].timestamp - sorted_commits[i - 1].timestamp
            gaps.append(gap.total_seconds() / 3600)  # Convert to hours

        if not gaps:
            return 0.0

        # Calculate coefficient of variation (std/mean)
        mean_gap = sum(gaps) / len(gaps)
        if mean_gap == 0:
            return 0.0

        variance = sum((gap - mean_gap) ** 2 for gap in gaps) / len(gaps)
        std_gap = variance**0.5
        coefficient_of_variation = std_gap / mean_gap

        # Normalize to 0-1 range (CV of 2.0 is considered very bursty)
        return min(coefficient_of_variation / 2.0, 1.0)

    def _calculate_type_scores(self, metrics: PersonalityMetrics) -> Dict[str, float]:
        """Calculate scores for each personality type based on metrics."""
        scores = {}

        # Perfezionista: high frequency, small diffs, detailed messages, tests
        perfectionist_score = 0.0
        perfectionist_score += self._score_range(
            metrics.commit_frequency, 3, 15, 0.25
        )  # 3-15 commits/week
        perfectionist_score += self._score_inverse(
            metrics.avg_diff_size, 80, 0.2
        )  # Small diffs
        perfectionist_score += self._score_range(
            metrics.message_detail_score, 0.4, 1.0, 0.2
        )  # Detailed messages
        perfectionist_score += self._score_range(
            metrics.test_file_ratio, 0.1, 0.8, 0.15
        )  # Good test ratio
        perfectionist_score += self._score_inverse(
            metrics.revert_ratio, 0.05, 0.2
        )  # Few reverts
        scores["Perfezionista"] = perfectionist_score

        # Cowboy: low frequency, large diffs, short messages, few tests
        cowboy_score = 0.0
        cowboy_score += self._score_inverse(
            metrics.commit_frequency, 1.5, 0.25
        )  # Infrequent commits
        cowboy_score += self._score_range(
            metrics.avg_diff_size, 150, 2000, 0.25
        )  # Large diffs
        cowboy_score += self._score_inverse(
            metrics.message_detail_score, 0.3, 0.2
        )  # Short messages
        cowboy_score += self._score_inverse(
            metrics.test_file_ratio, 0.05, 0.15
        )  # Few tests
        cowboy_score += self._score_inverse(
            metrics.revert_ratio, 0.1, 0.15
        )  # Usually works
        # Cowboys work regular hours, not weekends - penalize high weekend work
        cowboy_score -= metrics.weekend_ratio * 0.3  # Penalty for weekend work
        scores["Cowboy"] = cowboy_score

        # Pompiere: irregular patterns, weekend work, merge-heavy, bursty
        firefighter_score = 0.0
        firefighter_score += self._score_range(
            metrics.weekend_ratio, 0.3, 1.0, 0.4
        )  # Weekend work (increased weight)
        firefighter_score += self._score_range(
            metrics.burst_intensity, 0.4, 1.0, 0.2
        )  # Bursty work
        firefighter_score += self._score_range(
            metrics.merge_ratio, 0.2, 0.8, 0.2
        )  # Merge commits (increased weight)
        firefighter_score += self._score_range(
            metrics.working_hours_spread, 0.4, 1.0, 0.15
        )  # Irregular hours
        firefighter_score += (
            metrics.weekend_ratio * 0.3
        )  # Extra bonus for weekend work (increased)
        # Emergency-like behavior: moderate frequency and medium-sized urgent fixes
        firefighter_score += self._score_range(
            metrics.commit_frequency, 0.8, 4.0, 0.15
        )  # Moderate activity during crises
        # Firefighters make targeted fixes, not massive refactors - penalize very large diffs
        if metrics.avg_diff_size > 1200:
            firefighter_score -= 0.2
        scores["Pompiere"] = firefighter_score

        # Ghost: very low frequency, very large diffs, minimal messages
        ghost_score = 0.0
        ghost_score += self._score_inverse(
            metrics.commit_frequency, 0.8, 0.4
        )  # Very infrequent (increased threshold)
        ghost_score += self._score_range(
            metrics.avg_diff_size, 300, 3000, 0.4
        )  # Very large changes (increased weight)
        ghost_score += self._score_inverse(
            metrics.message_detail_score, 0.15, 0.3
        )  # Minimal messages (increased weight)
        ghost_score += self._score_range(
            metrics.working_hours_spread, 0.5, 1.0, 0.1
        )  # Irregular
        # Bonus for very large diffs (ghost trademark)
        if metrics.avg_diff_size > 1000:
            ghost_score += 0.3
        scores["Ghost"] = ghost_score

        # Tuttofare: balanced in all metrics, steady work
        balanced_score = 0.0
        balanced_score += self._score_range(
            metrics.commit_frequency, 1.5, 6, 0.2
        )  # Moderate frequency
        balanced_score += self._score_range(
            metrics.avg_diff_size, 40, 180, 0.2
        )  # Moderate diffs
        balanced_score += self._score_range(
            metrics.message_detail_score, 0.25, 0.7, 0.15
        )  # Decent messages
        balanced_score += self._score_range(
            metrics.test_file_ratio, 0.05, 0.4, 0.1
        )  # Some tests
        balanced_score += self._score_inverse(
            metrics.burst_intensity, 0.6, 0.15
        )  # Steady work
        balanced_score += self._score_range(
            metrics.working_hours_spread, 0.15, 0.5, 0.1
        )  # Regular hours
        balanced_score += self._score_inverse(
            metrics.weekend_ratio, 0.3, 0.1
        )  # Mostly weekday work
        scores["Tuttofare"] = balanced_score

        return scores

    def _score_range(
        self, value: float, min_val: float, max_val: float, weight: float
    ) -> float:
        """Score a value based on how well it fits in a range."""
        if min_val <= value <= max_val:
            return weight
        elif value < min_val:
            # Linear falloff below minimum
            distance = min_val - value
            falloff = max(0, 1 - distance / min_val)
            return weight * falloff
        else:
            # Linear falloff above maximum
            distance = value - max_val
            falloff = max(0, 1 - distance / max_val)
            return weight * falloff

    def _score_inverse(self, value: float, threshold: float, weight: float) -> float:
        """Score a value inversely (lower values get higher scores)."""
        if value <= threshold:
            return weight
        else:
            # Linear falloff above threshold
            excess = value - threshold
            falloff = max(0, 1 - excess / threshold)
            return weight * falloff
