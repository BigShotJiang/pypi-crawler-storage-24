"""
Advanced CLI interface for git-therapy with configuration support and team analysis.
"""

import json
import os
from pathlib import Path
from typing import Optional

import click
from dateutil.parser import parse as parse_date

from git_therapy.analyzers.team_dynamics import TeamDynamicsAnalyzer
from git_therapy.config import ConfigManager, load_config
from git_therapy.parser.git_log import GitLogParser
from git_therapy.report.generator import HtmlReportGenerator


@click.group()  # type: ignore[misc]
@click.option("--config", type=click.Path(), help="Path to configuration file")  # type: ignore[misc]
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")  # type: ignore[misc]
@click.pass_context
def cli(ctx: click.Context, config: Optional[str], verbose: bool) -> None:
    """Advanced Git repository psychological analysis tool.

    Analyze your development team's behavior patterns, stress indicators,
    and collaboration dynamics through commit history analysis.
    """
    # Ensure context object exists
    ctx.ensure_object(dict)

    # Load configuration
    if config:
        ctx.obj["config"] = load_config(config)
    else:
        ctx.obj["config"] = load_config()

    ctx.obj["verbose"] = verbose


@cli.command()  # type: ignore[misc]
@click.option("--path", type=click.Path(exists=True), help="Path to git repository")  # type: ignore[misc]
@click.option("--author", help="Filter commits by author (email or name)")  # type: ignore[misc]
@click.option("--since", help='Only commits after this date (e.g., "2023-01-01")')  # type: ignore[misc]
@click.option("--until", help='Only commits before this date (e.g., "2024-01-01")')  # type: ignore[misc]
@click.option(
    "--max-count", type=int, default=100, help="Maximum number of commits to analyze"
)  # type: ignore[misc]
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["json", "summary", "html"]),
    default="summary",
    help="Output format",
)  # type: ignore[misc]
@click.option(
    "--output", "output_file", help="Output file path (required for HTML format)"
)  # type: ignore[misc]
@click.option("--include-team", is_flag=True, help="Include team dynamics analysis")  # type: ignore[misc]
@click.pass_context
def analyze(
    ctx: click.Context,
    path: Optional[str],
    author: Optional[str],
    since: Optional[str],
    until: Optional[str],
    max_count: int,
    output_format: str,
    output_file: Optional[str],
    include_team: bool,
) -> None:
    """Analyze Git repository with psychological profiling."""
    config = ctx.obj["config"]
    verbose = ctx.obj["verbose"]

    try:
        # Parse date strings
        since_date = parse_date(since) if since else None
        until_date = parse_date(until) if until else None

        # Initialize parser
        parser = GitLogParser(path)

        if verbose:
            click.echo("Loading repository information...")

        # Get repository info
        repo_info = parser.get_repository_info()

        # Parse commits
        if verbose:
            click.echo(f"Analyzing up to {max_count} commits...")

        commits = parser.parse_commits(
            max_count=max_count, since=since_date, until=until_date, author=author
        )

        # Determine repository name
        repo_name = repo_info.get("path", "Unknown Repository")
        if repo_name != "Unknown Repository":
            repo_name = Path(repo_name).name

        if output_format == "html":
            # HTML report generation
            if not output_file:
                click.echo("Error: --output is required for HTML format", err=True)
                raise click.Abort()

            if not commits:
                click.echo("Error: No commits found to analyze", err=True)
                raise click.Abort()

            click.echo("Generating comprehensive HTML report...")
            generator = HtmlReportGenerator()

            try:
                output_path = generator.generate_report(
                    commits=commits, output_path=output_file, repository_name=repo_name
                )
                click.echo(f"HTML report generated: {output_path}")
                click.echo(f"Open {output_path} in your browser to view the analysis.")
            except Exception as e:
                click.echo(f"Error generating HTML report: {e}", err=True)
                raise click.Abort()

        elif output_format == "json":
            # JSON output with optional team dynamics
            output_data = {
                "repository": repo_info,
                "commits": [
                    {
                        "hash": commit.hash,
                        "author_name": commit.author_name,
                        "author_email": commit.author_email,
                        "timestamp": commit.timestamp.isoformat(),
                        "message": commit.message,
                        "files_changed": commit.files_changed,
                        "insertions": commit.insertions,
                        "deletions": commit.deletions,
                        "is_merge": commit.is_merge,
                    }
                    for commit in commits
                ],
            }

            # Add team dynamics if requested
            if include_team and commits:
                if verbose:
                    click.echo("Analyzing team dynamics...")
                team_analyzer = TeamDynamicsAnalyzer()
                team_dynamics = team_analyzer.analyze_team_dynamics(commits)

                output_data["team_dynamics"] = {
                    "total_contributors": team_dynamics.total_contributors,
                    "communication_health": team_dynamics.communication_health,
                    "workflow_efficiency": team_dynamics.workflow_efficiency,
                    "knowledge_silos": [
                        {"author": author, "exclusive_files": list(files)}
                        for author, files in team_dynamics.knowledge_silos
                    ],
                    "hot_files": [
                        {"file": file, "contributor_count": count}
                        for file, count in team_dynamics.hot_files[:10]
                    ],
                }

            click.echo(json.dumps(output_data, indent=2))
        else:
            # Enhanced summary output
            click.echo("Git Therapy Analysis")
            click.echo("=" * 50)
            click.echo(f"Repository: {repo_info.get('path', 'Unknown')}")

            if "error" in repo_info:
                click.echo(f"Warning: {repo_info['error']}")
                return

            click.echo(f"Branch: {repo_info.get('current_branch', 'Unknown')}")
            click.echo(f"Total commits: {repo_info.get('total_commits', 0)}")
            click.echo(f"Contributors: {repo_info.get('contributors', 0)}")
            click.echo(f"Analyzed commits: {len(commits)}")
            click.echo()

            if commits:
                # Basic stats
                total_insertions = sum(commit.insertions for commit in commits)
                total_deletions = sum(commit.deletions for commit in commits)
                merge_commits = sum(1 for commit in commits if commit.is_merge)

                click.echo("Quick Stats:")
                click.echo(f"  Lines added: +{total_insertions:,}")
                click.echo(f"  Lines removed: -{total_deletions:,}")
                click.echo(f"  Merge commits: {merge_commits}")

                if include_team:
                    if verbose:
                        click.echo("Analyzing team dynamics...")
                    team_analyzer = TeamDynamicsAnalyzer()
                    team_dynamics = team_analyzer.analyze_team_dynamics(commits)

                    click.echo()
                    click.echo("Team Dynamics:")
                    click.echo(
                        f"  Communication Health: {team_dynamics.communication_health:.1%}"
                    )
                    click.echo(
                        f"  Workflow Efficiency: {team_dynamics.workflow_efficiency:.1%}"
                    )
                    click.echo(
                        f"  Knowledge Silos: {len(team_dynamics.knowledge_silos)}"
                    )
                    click.echo(f"  Hot Files: {len(team_dynamics.hot_files)}")

                click.echo()

                # Most recent commits
                click.echo("Recent Activity:")
                for commit in commits[:5]:
                    date_str = commit.timestamp.strftime("%Y-%m-%d %H:%M")
                    message_preview = commit.message.split("\n")[0][:60]
                    if len(commit.message.split("\n")[0]) > 60:
                        message_preview += "..."
                    click.echo(f"  {date_str} | {message_preview}")
                    click.echo(
                        f"    {commit.author_name} (+{commit.insertions}/-{commit.deletions})"
                    )
                    click.echo()

                click.echo("For detailed analysis:")
                click.echo("    git-therapy analyze --format html --output report.html")
                click.echo(
                    "    git-therapy analyze --include-team  # Add team dynamics"
                )
            else:
                click.echo("No commits found matching the criteria.")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if verbose:
            import traceback

            traceback.print_exc()
        raise click.Abort()


@cli.command()  # type: ignore[misc]
@click.option("--show", is_flag=True, help="Show current configuration")  # type: ignore[misc]
@click.option("--init", is_flag=True, help="Create default configuration file")  # type: ignore[misc]
@click.option("--path", help="Configuration file path")  # type: ignore[misc]
@click.pass_context
def config(ctx: click.Context, show: bool, init: bool, path: Optional[str]) -> None:
    """Manage git-therapy configuration."""
    config_manager = ConfigManager()

    if show:
        # Show current configuration
        current_config = ctx.obj["config"]
        click.echo("Current Configuration:")
        click.echo("=" * 30)

        click.echo("Rage Detection:")
        click.echo(f"  High threshold: {current_config.rage.high_rage_threshold}")
        click.echo(f"  Medium threshold: {current_config.rage.medium_rage_threshold}")
        click.echo(
            f"  Short message threshold: {current_config.rage.short_message_threshold}"
        )

        click.echo("Sleep Analysis:")
        click.echo(
            f"  Night hours: {current_config.sleep.night_start_hour:02d}:00 - {current_config.sleep.night_end_hour:02d}:00"
        )
        click.echo(
            f"  High risk threshold: {current_config.sleep.high_risk_threshold:.1%}"
        )

        click.echo("Hero Detection:")
        click.echo(f"  Weekend days: {current_config.hero.weekend_days}")
        click.echo(
            f"  Emergency keywords: {len(current_config.hero.emergency_keywords)} defined"
        )

        click.echo("Personality Analysis:")
        click.echo(
            f"  Min commits threshold: {current_config.personality.min_commits_threshold}"
        )

        click.echo("Global Settings:")
        click.echo(f"  Verbose output: {current_config.verbose_output}")
        click.echo(f"  Cache analysis: {current_config.cache_analysis}")
        click.echo(f"  Parallel processing: {current_config.parallel_processing}")

    elif init:
        # Create default configuration file
        config_path = path or ".git-therapy.yaml"

        if os.path.exists(config_path):
            if not click.confirm(
                f"Configuration file {config_path} already exists. Overwrite?"
            ):
                click.echo("Configuration initialization cancelled.")
                return

        try:
            saved_path = config_manager.save_config(config_path)
            click.echo(f"Default configuration created: {saved_path}")
            click.echo("Edit this file to customize git-therapy behavior.")
        except Exception as e:
            click.echo(f"Error creating configuration: {e}", err=True)
            raise click.Abort()
    else:
        click.echo(
            "Use --show to view current config or --init to create default config"
        )


@cli.command()  # type: ignore[misc]
@click.option("--path", type=click.Path(exists=True), help="Path to git repository")  # type: ignore[misc]
@click.option("--since", help='Only commits after this date (e.g., "2023-01-01")')  # type: ignore[misc]
@click.option("--until", help='Only commits before this date (e.g., "2024-01-01")')  # type: ignore[misc]
@click.option(
    "--max-count", type=int, default=200, help="Maximum number of commits to analyze"
)  # type: ignore[misc]
@click.pass_context
def team(
    ctx: click.Context,
    path: Optional[str],
    since: Optional[str],
    until: Optional[str],
    max_count: int,
) -> None:
    """Analyze team collaboration patterns and dynamics."""
    verbose = ctx.obj["verbose"]

    try:
        # Parse date strings
        since_date = parse_date(since) if since else None
        until_date = parse_date(until) if until else None

        # Initialize parser
        parser = GitLogParser(path)

        if verbose:
            click.echo("Loading repository and analyzing team dynamics...")

        # Parse commits
        commits = parser.parse_commits(
            max_count=max_count, since=since_date, until=until_date
        )

        if not commits:
            click.echo("No commits found to analyze.")
            return

        # Analyze team dynamics
        team_analyzer = TeamDynamicsAnalyzer()
        team_dynamics = team_analyzer.analyze_team_dynamics(commits)

        # Display results
        click.echo("Team Dynamics Analysis")
        click.echo("=" * 40)
        click.echo(f"Total Contributors: {team_dynamics.total_contributors}")
        click.echo(f"Communication Health: {team_dynamics.communication_health:.1%}")
        click.echo(f"Workflow Efficiency: {team_dynamics.workflow_efficiency:.1%}")
        click.echo()

        # Knowledge silos
        if team_dynamics.knowledge_silos:
            click.echo("Knowledge Silos (Contributors with exclusive file access):")
            for author, files in team_dynamics.knowledge_silos:
                author_name = author.split("@")[0]  # Show just the name part
                click.echo(f"  {author_name}: {len(files)} exclusive files")
                if verbose:
                    for file in list(files)[:5]:  # Show first 5 files
                        click.echo(f"    - {file}")
                    if len(files) > 5:
                        click.echo(f"    ... and {len(files) - 5} more")
            click.echo()

        # Hot files
        if team_dynamics.hot_files:
            click.echo("Hot Files (Worked on by multiple contributors):")
            for file, count in team_dynamics.hot_files[:10]:
                click.echo(f"  {file}: {count} contributors")
            click.echo()

        # Collaboration insights
        if team_dynamics.collaboration_matrix:
            click.echo("Top Collaborations:")
            collaborations = [
                (authors, metrics)
                for authors, metrics in team_dynamics.collaboration_matrix.items()
                if metrics.total_collaborations > 0
            ]
            collaborations.sort(key=lambda x: x[1].total_collaborations, reverse=True)

            for (author1, author2), metrics in collaborations[:5]:
                name1 = author1.split("@")[0]
                name2 = author2.split("@")[0]
                click.echo(
                    f"  {name1} <-> {name2}: {metrics.total_collaborations} shared files"
                )
                if metrics.merge_conflicts > 0:
                    click.echo(
                        f"    Warning: Estimated conflicts: {metrics.merge_conflicts}"
                    )

        # Recommendations
        click.echo("Recommendations:")
        if team_dynamics.communication_health < 0.6:
            click.echo(
                "  - Consider improving commit message quality and reducing conflicts"
            )
        if team_dynamics.workflow_efficiency < 0.6:
            click.echo("  - Review commit sizes and frequency for better workflow")
        if len(team_dynamics.knowledge_silos) > 0:
            click.echo(
                "  - Address knowledge silos through code reviews and pair programming"
            )
        if len(team_dynamics.hot_files) > 5:
            click.echo(
                "  - Consider refactoring frequently-modified files to reduce conflicts"
            )

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if verbose:
            import traceback

            traceback.print_exc()
        raise click.Abort()


if __name__ == "__main__":
    cli()
