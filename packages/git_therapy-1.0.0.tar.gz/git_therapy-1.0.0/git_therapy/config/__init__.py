"""
Configuration management for git-therapy.

This module handles loading and managing configuration settings that control
analyzer behavior, thresholds, and output preferences.
"""

import json
import os
from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional

import yaml


@dataclass
class RageConfig:
    """Configuration for rage commit detection."""

    # Scoring weights
    all_caps_weight: float = 0.3
    swear_words_weight: float = 0.4
    short_message_weight: float = 0.15
    personal_frustration_weight: float = 0.15

    # Thresholds
    short_message_threshold: int = 10  # Characters
    high_rage_threshold: float = 0.7
    medium_rage_threshold: float = 0.4

    # Custom patterns
    custom_rage_patterns: list = None

    def __post_init__(self):
        if self.custom_rage_patterns is None:
            self.custom_rage_patterns = []


@dataclass
class SleepConfig:
    """Configuration for sleep deprivation analysis."""

    # Time boundaries (24-hour format)
    night_start_hour: int = 0  # 00:00
    night_end_hour: int = 6  # 06:00

    # Risk level thresholds (percentages)
    high_risk_threshold: float = 0.3  # 30% night commits
    medium_risk_threshold: float = 0.15  # 15% night commits

    # Consecutive session detection
    session_gap_hours: int = 4  # Hours between commits to consider same session
    long_session_threshold: int = 8  # Hours for a "long" session


@dataclass
class HeroConfig:
    """Configuration for hero moment detection."""

    # Scoring weights
    weekend_fix_weight: float = 0.4
    emergency_response_weight: float = 0.3
    hotfix_weight: float = 0.2
    post_rage_intervention_weight: float = 0.1

    # Pattern matching
    emergency_keywords: list = None
    hotfix_keywords: list = None

    # Timing thresholds
    weekend_days: list = None  # [5, 6] for Saturday, Sunday
    late_night_hour: int = 22  # 22:00
    early_morning_hour: int = 6  # 06:00

    def __post_init__(self):
        if self.emergency_keywords is None:
            self.emergency_keywords = [
                "emergency",
                "urgent",
                "critical",
                "outage",
                "down",
                "broken",
                "fix",
                "hotfix",
                "patch",
                "restore",
            ]
        if self.hotfix_keywords is None:
            self.hotfix_keywords = [
                "hotfix",
                "quickfix",
                "patch",
                "urgent fix",
                "critical fix",
            ]
        if self.weekend_days is None:
            self.weekend_days = [5, 6]  # Saturday, Sunday


@dataclass
class PersonalityConfig:
    """Configuration for personality analysis."""

    # Minimum commits required for analysis
    min_commits_threshold: int = 3

    # Scoring thresholds for personality types
    perfezionista_test_ratio_threshold: float = 0.3
    cowboy_large_diff_threshold: int = 200
    pompiere_weekend_threshold: float = 0.3
    ghost_frequency_threshold: float = 0.5
    ghost_diff_size_threshold: int = 500

    # Analysis time ranges
    analysis_lookback_days: int = 90  # Days to look back for patterns


@dataclass
class ReportConfig:
    """Configuration for report generation."""

    # Health score calculation
    base_health_score: int = 85
    max_rage_penalty: int = 30
    max_sleep_penalty: int = 25
    max_hero_bonus: int = 10

    # Chart preferences
    chart_colors: Dict[str, str] = None
    enable_animations: bool = True
    responsive_design: bool = True

    # Export options
    include_raw_data: bool = False
    compress_output: bool = False

    def __post_init__(self):
        if self.chart_colors is None:
            self.chart_colors = {
                "rage": "#e74c3c",
                "sleep": "#9b59b6",
                "hero": "#f39c12",
                "personality": "#3498db",
                "health": "#2ecc71",
            }


@dataclass
class GitTherapyConfig:
    """Main configuration container for git-therapy."""

    rage: RageConfig
    sleep: SleepConfig
    hero: HeroConfig
    personality: PersonalityConfig
    report: ReportConfig

    # Global settings
    verbose_output: bool = False
    cache_analysis: bool = True
    parallel_processing: bool = True
    max_workers: int = 4

    def __init__(self):
        self.rage = RageConfig()
        self.sleep = SleepConfig()
        self.hero = HeroConfig()
        self.personality = PersonalityConfig()
        self.report = ReportConfig()


class ConfigManager:
    """Manages loading and saving of git-therapy configuration."""

    DEFAULT_CONFIG_PATHS = [
        ".git-therapy.yaml",
        ".git-therapy.yml",
        ".git-therapy.json",
        os.path.expanduser("~/.git-therapy/config.yaml"),
        os.path.expanduser("~/.config/git-therapy/config.yaml"),
    ]

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path
        self.config = GitTherapyConfig()

    def load_config(self, config_path: Optional[str] = None) -> GitTherapyConfig:
        """Load configuration from file or use defaults."""
        if config_path:
            paths_to_try = [config_path]
        else:
            paths_to_try = self.DEFAULT_CONFIG_PATHS

        for path in paths_to_try:
            if os.path.exists(path):
                try:
                    config_dict = self._load_config_file(path)
                    self.config = self._dict_to_config(config_dict)
                    self.config_path = path
                    return self.config
                except Exception as e:
                    print(f"Warning: Could not load config from {path}: {e}")
                    continue

        # Return default config if no file found
        return self.config

    def save_config(self, config_path: Optional[str] = None) -> str:
        """Save current configuration to file."""
        if not config_path:
            config_path = self.config_path or ".git-therapy.yaml"

        config_dict = asdict(self.config)

        # Ensure directory exists
        os.makedirs(os.path.dirname(os.path.abspath(config_path)), exist_ok=True)

        if config_path.endswith((".yaml", ".yml")):
            with open(config_path, "w") as f:
                yaml.dump(config_dict, f, default_flow_style=False, indent=2)
        elif config_path.endswith(".json"):
            with open(config_path, "w") as f:
                json.dump(config_dict, f, indent=2)
        else:
            # Default to YAML
            config_path += ".yaml"
            with open(config_path, "w") as f:
                yaml.dump(config_dict, f, default_flow_style=False, indent=2)

        return config_path

    def _load_config_file(self, path: str) -> Dict[str, Any]:
        """Load configuration dictionary from file."""
        with open(path) as f:
            if path.endswith((".yaml", ".yml")):
                return yaml.safe_load(f) or {}
            elif path.endswith(".json"):
                return json.load(f)
            else:
                # Try YAML first, then JSON
                try:
                    return yaml.safe_load(f) or {}
                except yaml.YAMLError:
                    f.seek(0)
                    return json.load(f)

    def _dict_to_config(self, config_dict: Dict[str, Any]) -> GitTherapyConfig:
        """Convert configuration dictionary to GitTherapyConfig object."""
        config = GitTherapyConfig()

        if "rage" in config_dict:
            rage_dict = config_dict["rage"]
            config.rage = RageConfig(
                **{k: v for k, v in rage_dict.items() if hasattr(RageConfig, k)}
            )

        if "sleep" in config_dict:
            sleep_dict = config_dict["sleep"]
            config.sleep = SleepConfig(
                **{k: v for k, v in sleep_dict.items() if hasattr(SleepConfig, k)}
            )

        if "hero" in config_dict:
            hero_dict = config_dict["hero"]
            config.hero = HeroConfig(
                **{k: v for k, v in hero_dict.items() if hasattr(HeroConfig, k)}
            )

        if "personality" in config_dict:
            personality_dict = config_dict["personality"]
            config.personality = PersonalityConfig(
                **{
                    k: v
                    for k, v in personality_dict.items()
                    if hasattr(PersonalityConfig, k)
                }
            )

        if "report" in config_dict:
            report_dict = config_dict["report"]
            config.report = ReportConfig(
                **{k: v for k, v in report_dict.items() if hasattr(ReportConfig, k)}
            )

        # Global settings
        for key in [
            "verbose_output",
            "cache_analysis",
            "parallel_processing",
            "max_workers",
        ]:
            if key in config_dict:
                setattr(config, key, config_dict[key])

        return config

    def get_default_config_content(self) -> str:
        """Get default configuration as YAML string."""
        default_config = GitTherapyConfig()
        config_dict = asdict(default_config)
        return yaml.dump(config_dict, default_flow_style=False, indent=2)


# Global configuration instance
_config_manager = ConfigManager()


def get_config() -> GitTherapyConfig:
    """Get the current global configuration."""
    return _config_manager.config


def load_config(config_path: Optional[str] = None) -> GitTherapyConfig:
    """Load configuration from file."""
    return _config_manager.load_config(config_path)


def save_config(config_path: Optional[str] = None) -> str:
    """Save current configuration to file."""
    return _config_manager.save_config(config_path)
