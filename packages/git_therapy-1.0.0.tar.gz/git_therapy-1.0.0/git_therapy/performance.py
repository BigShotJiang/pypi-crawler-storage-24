"""
Performance optimizations for git-therapy analysis.
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from typing import List, Dict, Any, Optional
from functools import lru_cache
import time

from git_therapy.parser.git_log import CommitData
from git_therapy.analyzers.rage import RageCommitDetector
from git_therapy.analyzers.sleep import SleepDeprivationAnalyzer
from git_therapy.analyzers.hero import HeroDetector
from git_therapy.analyzers.personality import PersonalityProfiler
from git_therapy.analyzers.team_dynamics import TeamDynamicsAnalyzer


class PerformanceOptimizer:
    """Optimizations for analyzing large repositories."""

    def __init__(self, max_workers: int = 4):
        self.max_workers = max_workers
        self.cache_enabled = True

    async def analyze_parallel(self, commits: List[CommitData]) -> Dict[str, Any]:
        """Run all analyzers in parallel for better performance."""
        if len(commits) < 100:
            # For small repos, parallel overhead isn't worth it
            return await self._analyze_sequential(commits)

        loop = asyncio.get_event_loop()

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Split commits for heavy analyzers
            chunks = self._chunk_commits(commits, self.max_workers)

            # Run analyzers in parallel
            rage_task = loop.run_in_executor(executor, self._analyze_rage, commits)
            sleep_task = loop.run_in_executor(executor, self._analyze_sleep, commits)
            hero_task = loop.run_in_executor(executor, self._analyze_hero, commits)
            personality_task = loop.run_in_executor(executor, self._analyze_personality, commits)
            team_task = loop.run_in_executor(executor, self._analyze_team, commits)

            # Wait for all analyses to complete
            results = await asyncio.gather(
                rage_task, sleep_task, hero_task, personality_task, team_task
            )

            return {
                'rage_analysis': results[0],
                'sleep_analysis': results[1],
                'hero_analysis': results[2],
                'personality_profiles': results[3],
                'team_dynamics': results[4],
                'performance_stats': {
                    'total_commits': len(commits),
                    'parallel_execution': True,
                    'workers_used': self.max_workers
                }
            }

    async def _analyze_sequential(self, commits: List[CommitData]) -> Dict[str, Any]:
        """Sequential analysis for small repositories."""
        return {
            'rage_analysis': self._analyze_rage(commits),
            'sleep_analysis': self._analyze_sleep(commits),
            'hero_analysis': self._analyze_hero(commits),
            'personality_profiles': self._analyze_personality(commits),
            'team_dynamics': self._analyze_team(commits),
            'performance_stats': {
                'total_commits': len(commits),
                'parallel_execution': False
            }
        }

    @lru_cache(maxsize=128)
    def _analyze_rage(self, commits_tuple) -> Dict:
        """Cached rage analysis."""
        commits = list(commits_tuple) if isinstance(commits_tuple, tuple) else commits_tuple
        detector = RageCommitDetector()
        rage_commits = detector.analyze_commits(commits)
        stats = detector.get_rage_statistics(rage_commits)
        return {
            'rage_commits': rage_commits,
            'statistics': stats
        }

    @lru_cache(maxsize=128)
    def _analyze_sleep(self, commits_tuple):
        """Cached sleep analysis."""
        commits = list(commits_tuple) if isinstance(commits_tuple, tuple) else commits_tuple
        analyzer = SleepDeprivationAnalyzer()
        return analyzer.analyze_sleep_patterns(commits)

    @lru_cache(maxsize=128)
    def _analyze_hero(self, commits_tuple):
        """Cached hero analysis."""
        commits = list(commits_tuple) if isinstance(commits_tuple, tuple) else commits_tuple
        detector = HeroDetector()
        return detector.analyze_heroes(commits, [])  # No rage commits for caching

    @lru_cache(maxsize=128)
    def _analyze_personality(self, commits_tuple):
        """Cached personality analysis."""
        commits = list(commits_tuple) if isinstance(commits_tuple, tuple) else commits_tuple
        profiler = PersonalityProfiler()
        return profiler.analyze_personalities(commits)

    @lru_cache(maxsize=128)
    def _analyze_team(self, commits_tuple):
        """Cached team dynamics analysis."""
        commits = list(commits_tuple) if isinstance(commits_tuple, tuple) else commits_tuple
        analyzer = TeamDynamicsAnalyzer()
        return analyzer.analyze_team_dynamics(commits)

    def _chunk_commits(self, commits: List[CommitData], num_chunks: int) -> List[List[CommitData]]:
        """Split commits into chunks for parallel processing."""
        chunk_size = max(1, len(commits) // num_chunks)
        return [commits[i:i + chunk_size] for i in range(0, len(commits), chunk_size)]

    def clear_cache(self):
        """Clear analysis cache to free memory."""
        self._analyze_rage.cache_clear()
        self._analyze_sleep.cache_clear()
        self._analyze_hero.cache_clear()
        self._analyze_personality.cache_clear()
        self._analyze_team.cache_clear()


class MemoryOptimizer:
    """Memory optimization for large repository analysis."""

    @staticmethod
    def optimize_commits(commits: List[CommitData]) -> List[CommitData]:
        """Optimize commit data for memory usage."""
        optimized = []

        for commit in commits:
            # Truncate very long commit messages to save memory
            message = commit.message
            if len(message) > 1000:
                message = message[:1000] + "..."

            # Limit files changed to reasonable number
            files_changed = commit.files_changed
            if len(files_changed) > 100:
                files_changed = files_changed[:100] + [f"... and {len(files_changed) - 100} more files"]

            # Create optimized commit
            optimized_commit = CommitData(
                hash=commit.hash[:12],  # Short hash is enough
                author_name=commit.author_name,
                author_email=commit.author_email,
                timestamp=commit.timestamp,
                message=message,
                files_changed=files_changed,
                insertions=min(commit.insertions, 10000),  # Cap very large changes
                deletions=min(commit.deletions, 10000),
                is_merge=commit.is_merge
            )
            optimized.append(optimized_commit)

        return optimized

    @staticmethod
    def batch_process(commits: List[CommitData], batch_size: int = 1000):
        """Process commits in batches to reduce memory usage."""
        for i in range(0, len(commits), batch_size):
            yield commits[i:i + batch_size]


# Usage example functions
async def analyze_large_repo(commits: List[CommitData], max_workers: int = 4) -> Dict[str, Any]:
    """Optimized analysis for large repositories."""
    optimizer = PerformanceOptimizer(max_workers=max_workers)

    # Optimize memory usage for very large repos
    if len(commits) > 10000:
        commits = MemoryOptimizer.optimize_commits(commits)

    start_time = time.time()
    results = await optimizer.analyze_parallel(commits)
    end_time = time.time()

    results['performance_stats']['execution_time'] = end_time - start_time
    results['performance_stats']['commits_per_second'] = len(commits) / (end_time - start_time)

    return results


def get_performance_recommendations(commit_count: int, execution_time: float) -> List[str]:
    """Get performance optimization recommendations."""
    recommendations = []

    commits_per_second = commit_count / execution_time if execution_time > 0 else 0

    if commits_per_second < 100:
        recommendations.append("Consider using parallel processing with --max-workers option")

    if commit_count > 50000:
        recommendations.append("Use --max-count to limit analysis scope for faster results")
        recommendations.append("Consider analyzing specific date ranges with --since/--until")

    if commit_count > 100000:
        recommendations.append("Enable caching with configuration file for repeated analyses")
        recommendations.append("Consider using JSON output format for faster processing")

    return recommendations