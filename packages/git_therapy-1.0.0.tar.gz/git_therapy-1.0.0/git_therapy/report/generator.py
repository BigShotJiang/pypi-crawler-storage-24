"""
HTML Report Generator for git-therapy analysis results.

This module creates interactive HTML reports that combine all analyzer results
into a cohesive psychological profile of development teams.
"""

import json
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from jinja2 import Environment, FileSystemLoader, select_autoescape

from git_therapy.analyzers.hero import HeroAnalysis, HeroDetector
from git_therapy.analyzers.personality import PersonalityProfile, PersonalityProfiler
from git_therapy.analyzers.rage import RageCommitDetector
from git_therapy.analyzers.sleep import SleepAnalysis, SleepDeprivationAnalyzer
from git_therapy.parser.git_log import CommitData


class ReportData:
    """Container for all analysis results to be included in the report."""

    def __init__(self):
        self.rage_analysis: Optional[Dict] = None  # Results from rage analyzer
        self.sleep_analysis: Optional[SleepAnalysis] = None
        self.hero_analysis: Optional[HeroAnalysis] = None
        self.personality_profiles: List[PersonalityProfile] = []
        self.commit_count: int = 0
        self.date_range: str = ""
        self.repository_name: str = ""


class HtmlReportGenerator:
    """Generates interactive HTML reports from git-therapy analysis."""

    def __init__(self):
        # Set up Jinja2 template environment
        template_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            autoescape=select_autoescape(["html", "xml"]),
        )

        # Register custom filters
        self.env.filters["to_json"] = self._to_json_filter
        self.env.filters["format_percentage"] = self._format_percentage_filter
        self.env.filters["format_confidence"] = self._format_confidence_filter

    def _to_json_filter(self, obj: Any) -> str:
        """Convert Python object to JSON for JavaScript consumption."""
        if hasattr(obj, "__dict__"):
            return json.dumps(asdict(obj))
        return json.dumps(obj)

    def _format_percentage_filter(self, value: float) -> str:
        """Format a float as a percentage."""
        return f"{value * 100:.1f}%"

    def _format_confidence_filter(self, value: float) -> str:
        """Format confidence score as percentage."""
        return f"{value * 100:.0f}%"

    def generate_report(
        self,
        commits: List[CommitData],
        output_path: str,
        repository_name: str = "Unknown Repository",
    ) -> str:
        """
        Generate a complete HTML report from commit data.

        Args:
            commits: List of commit data to analyze
            output_path: Path where the HTML file should be written
            repository_name: Name of the repository being analyzed

        Returns:
            Path to the generated HTML file
        """
        # Run all analyzers
        report_data = self._analyze_commits(commits, repository_name)

        # Generate HTML content
        html_content = self._render_template(report_data)

        # Write to file
        output_file = Path(output_path)
        output_file.write_text(html_content, encoding="utf-8")

        return str(output_file)

    def _analyze_commits(
        self, commits: List[CommitData], repository_name: str
    ) -> ReportData:
        """Run all analyzers on the commit data."""
        report_data = ReportData()

        # Basic metadata
        report_data.commit_count = len(commits)
        report_data.repository_name = repository_name

        if commits:
            start_date = min(commit.timestamp for commit in commits)
            end_date = max(commit.timestamp for commit in commits)
            report_data.date_range = (
                f"{start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}"
            )

        # Rage analysis
        rage_detector = RageCommitDetector()
        rage_commits = rage_detector.analyze_commits(commits)
        rage_stats = rage_detector.get_rage_statistics(rage_commits)
        report_data.rage_analysis = {
            "rage_commits": rage_commits,
            "statistics": rage_stats,
        }

        # Sleep analysis
        sleep_analyzer = SleepDeprivationAnalyzer()
        report_data.sleep_analysis = sleep_analyzer.analyze_sleep_patterns(commits)

        # Hero analysis
        hero_detector = HeroDetector()
        report_data.hero_analysis = hero_detector.analyze_heroes(commits, rage_commits)

        # Personality analysis
        personality_profiler = PersonalityProfiler()
        report_data.personality_profiles = personality_profiler.analyze_personalities(
            commits
        )

        return report_data

    def _render_template(self, report_data: ReportData) -> str:
        """Render the main report template with data."""
        template = self.env.get_template("report.html")

        # Calculate summary statistics
        summary_stats = self._calculate_summary_stats(report_data)

        return template.render(
            report_data=report_data,
            summary_stats=summary_stats,
            generated_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )

    def _calculate_summary_stats(self, report_data: ReportData) -> Dict[str, Any]:
        """Calculate high-level summary statistics for the dashboard."""
        stats = {
            "total_contributors": len(report_data.personality_profiles),
            "total_rage_commits": 0,
            "total_night_commits": 0,
            "total_hero_moments": 0,
            "health_score": 85,  # Default healthy score
        }

        if report_data.rage_analysis:
            rage_commits = report_data.rage_analysis.get("rage_commits", [])
            stats["total_rage_commits"] = len(rage_commits)
            # Reduce health score based on rage percentage
            if report_data.commit_count > 0:
                rage_percentage = len(rage_commits) / report_data.commit_count
                stats["health_score"] -= min(30, rage_percentage * 100)

        if report_data.sleep_analysis and hasattr(
            report_data.sleep_analysis, "contributors"
        ):
            stats["total_night_commits"] = sum(
                contrib.night_commits
                for contrib in report_data.sleep_analysis.contributors
            )
            # Reduce health score based on sleep deprivation
            avg_night_percentage = (
                sum(
                    contrib.night_percentage
                    for contrib in report_data.sleep_analysis.contributors
                )
                / len(report_data.sleep_analysis.contributors)
                if report_data.sleep_analysis.contributors
                else 0
            )
            stats["health_score"] -= min(25, avg_night_percentage * 50)

        if report_data.hero_analysis and hasattr(
            report_data.hero_analysis, "hero_profiles"
        ):
            stats["total_hero_moments"] = sum(
                len(profile.hero_moments)
                for profile in report_data.hero_analysis.hero_profiles
                if hasattr(profile, "hero_moments") and profile.hero_moments
            )
            # Heroes slightly boost health score
            stats["health_score"] += min(
                10, len(report_data.hero_analysis.hero_profiles) * 2
            )

        # Ensure health score stays within bounds
        stats["health_score"] = max(0, min(100, round(stats["health_score"])))

        return stats
