"""Git log parser for extracting commit data."""

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import git
from git import Repo


@dataclass
class CommitData:
    """Structured representation of a git commit."""

    hash: str
    author_name: str
    author_email: str
    timestamp: datetime
    message: str
    files_changed: List[str]
    insertions: int
    deletions: int
    is_merge: bool


class GitLogParser:
    """Parser for extracting structured data from git repositories."""

    def __init__(self, repo_path: Optional[str] = None):
        """Initialize the parser with a repository path.

        Args:
            repo_path: Path to git repository. Uses current directory if None.
        """
        self.repo_path = Path(repo_path) if repo_path else Path.cwd()
        self._repo: Optional[Repo] = None

    @property
    def repo(self) -> Repo:
        """Lazy-loaded repository instance."""
        if self._repo is None:
            try:
                self._repo = Repo(self.repo_path)
            except git.exc.InvalidGitRepositoryError as e:
                raise ValueError(f"Not a git repository: {self.repo_path}") from e
        return self._repo

    def parse_commits(
        self,
        max_count: Optional[int] = None,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None,
        author: Optional[str] = None,
    ) -> List[CommitData]:
        """Extract structured commit data from the repository.

        Args:
            max_count: Maximum number of commits to parse
            since: Only include commits after this date
            until: Only include commits before this date
            author: Only include commits by this author (email or name)

        Returns:
            List of structured commit data
        """
        commits = []

        # Build kwargs for git.iter_commits()
        kwargs: Dict[str, Any] = {}
        if max_count:
            kwargs["max_count"] = max_count
        if since:
            kwargs["since"] = since
        if until:
            kwargs["until"] = until
        if author:
            kwargs["author"] = author

        try:
            for commit in self.repo.iter_commits(**kwargs):
                commit_data = self._extract_commit_data(commit)
                commits.append(commit_data)
        except git.exc.GitCommandError as e:
            raise RuntimeError(f"Failed to parse git log: {e}") from e

        return commits

    def _extract_commit_data(self, commit: git.Commit) -> CommitData:
        """Extract structured data from a git.Commit object."""
        # Get commit stats (insertions/deletions)
        try:
            stats = commit.stats.total
            insertions = stats["insertions"]
            deletions = stats["deletions"]
            files_changed = list(stats["files"].keys()) if "files" in stats else []
        except (AttributeError, KeyError):
            # Fallback for edge cases (e.g., initial commit, merge commits)
            insertions = 0
            deletions = 0
            files_changed = []

        # Check if this is a merge commit
        is_merge = len(commit.parents) > 1

        return CommitData(
            hash=commit.hexsha,
            author_name=commit.author.name,
            author_email=commit.author.email,
            timestamp=datetime.fromtimestamp(commit.committed_date),
            message=commit.message.strip(),
            files_changed=files_changed,
            insertions=insertions,
            deletions=deletions,
            is_merge=is_merge,
        )

    def get_repository_info(self) -> Dict[str, Any]:
        """Get basic information about the repository."""
        try:
            # Get remote URL if available
            remote_url = None
            if self.repo.remotes:
                remote_url = self.repo.remotes.origin.url

            return {
                "path": str(self.repo_path),
                "remote_url": remote_url,
                "current_branch": self.repo.active_branch.name,
                "total_commits": len(list(self.repo.iter_commits())),
                "contributors": len(
                    {commit.author.email for commit in self.repo.iter_commits()}
                ),
            }
        except Exception as e:
            return {"path": str(self.repo_path), "error": str(e)}
