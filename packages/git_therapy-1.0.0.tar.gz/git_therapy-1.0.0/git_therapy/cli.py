"""Command-line interface for git-therapy."""

import json
from pathlib import Path
from typing import Optional

import click
from dateutil.parser import parse as parse_date

from git_therapy.parser.git_log import GitLogParser
from git_therapy.report.generator import HtmlReportGenerator


@click.command()  # type: ignore[misc]
@click.option("--path", type=click.Path(exists=True), help="Path to git repository")  # type: ignore[misc]
@click.option("--author", help="Filter commits by author (email or name)")  # type: ignore[misc]
@click.option("--since", help='Only commits after this date (e.g., "2023-01-01")')  # type: ignore[misc]
@click.option("--until", help='Only commits before this date (e.g., "2024-01-01")')  # type: ignore[misc]
@click.option(
    "--max-count", type=int, default=100, help="Maximum number of commits to analyze"
)  # type: ignore[misc]
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["json", "summary", "html"]),
    default="summary",
    help="Output format",
)  # type: ignore[misc]
@click.option(
    "--output",
    "output_file",
    help="Output file path (required for HTML format)",
)  # type: ignore[misc]
def main(
    path: Optional[str],
    author: Optional[str],
    since: Optional[str],
    until: Optional[str],
    max_count: int,
    output_format: str,
    output_file: Optional[str],
) -> None:
    """Analyze your Git history and build a psychological profile of your development team.

    Your repository has a lot to say. Are you ready to listen?
    """
    try:
        # Parse date strings
        since_date = parse_date(since) if since else None
        until_date = parse_date(until) if until else None

        # Initialize parser
        parser = GitLogParser(path)

        # Get repository info
        repo_info = parser.get_repository_info()

        # Parse commits
        commits = parser.parse_commits(
            max_count=max_count, since=since_date, until=until_date, author=author
        )

        # Determine repository name
        repo_name = repo_info.get("path", "Unknown Repository")
        if repo_name != "Unknown Repository":
            repo_name = Path(repo_name).name

        if output_format == "html":
            # HTML report generation
            if not output_file:
                click.echo("Error: --output is required for HTML format", err=True)
                raise click.Abort()

            if not commits:
                click.echo("Error: No commits found to analyze", err=True)
                raise click.Abort()

            click.echo("Generating HTML report...")
            generator = HtmlReportGenerator()

            try:
                output_path = generator.generate_report(
                    commits=commits, output_path=output_file, repository_name=repo_name
                )
                click.echo(f"HTML report generated: {output_path}")
                click.echo(f"Open {output_path} in your browser to view the analysis.")
            except Exception as e:
                click.echo(f"Error generating HTML report: {e}", err=True)
                raise click.Abort()

        elif output_format == "json":
            # Convert to JSON-serializable format
            output = {
                "repository": repo_info,
                "commits": [
                    {
                        "hash": commit.hash,
                        "author_name": commit.author_name,
                        "author_email": commit.author_email,
                        "timestamp": commit.timestamp.isoformat(),
                        "message": commit.message,
                        "files_changed": commit.files_changed,
                        "insertions": commit.insertions,
                        "deletions": commit.deletions,
                        "is_merge": commit.is_merge,
                    }
                    for commit in commits
                ],
            }
            click.echo(json.dumps(output, indent=2))
        else:
            # Summary output
            click.echo("git-therapy Analysis")
            click.echo("=" * 50)
            click.echo(f"Repository: {repo_info.get('path', 'Unknown')}")

            if "error" in repo_info:
                click.echo(f"Warning: {repo_info['error']}")
                return

            click.echo(f"Branch: {repo_info.get('current_branch', 'Unknown')}")
            click.echo(f"Total commits: {repo_info.get('total_commits', 0)}")
            click.echo(f"Contributors: {repo_info.get('contributors', 0)}")
            click.echo(f"Analyzed commits: {len(commits)}")
            click.echo()

            if commits:
                # Basic stats
                total_insertions = sum(commit.insertions for commit in commits)
                total_deletions = sum(commit.deletions for commit in commits)
                merge_commits = sum(1 for commit in commits if commit.is_merge)

                click.echo("Quick Stats:")
                click.echo(f"  Lines added: +{total_insertions:,}")
                click.echo(f"  Lines removed: -{total_deletions:,}")
                click.echo(f"  Merge commits: {merge_commits}")
                click.echo()

                # Most recent commits
                click.echo("Recent Activity:")
                for commit in commits[:5]:
                    date_str = commit.timestamp.strftime("%Y-%m-%d %H:%M")
                    message_preview = commit.message.split("\n")[0][:60]
                    if len(commit.message.split("\n")[0]) > 60:
                        message_preview += "..."
                    click.echo(f"  {date_str} | {message_preview}")
                    click.echo(
                        f"    {commit.author_name} (+{commit.insertions}/-{commit.deletions})"
                    )
                    click.echo()

                click.echo("🧠 Full psychological analysis available!")
                click.echo(
                    "    Use --format html --output report.html for detailed insights"
                )
                click.echo(
                    "    All 4 analyzers: Rage Detection, Sleep Analysis, Hero Detection, Personality Profiling"
                )
            else:
                click.echo("No commits found matching the criteria.")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


if __name__ == "__main__":
    main()
