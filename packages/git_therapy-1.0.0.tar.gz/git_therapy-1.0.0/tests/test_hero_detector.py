"""Tests for hero detection analyzer."""

from datetime import datetime

import pytest

from git_therapy.analyzers.hero import HeroDetector
from git_therapy.parser.git_log import CommitData


@pytest.fixture
def detector():
    """Create a HeroDetector instance."""
    return HeroDetector()


@pytest.fixture
def sample_commits():
    """Create sample commits for hero detection testing."""
    return [
        # Normal weekday commit
        CommitData(
            hash="normal123",
            author_name="Alice Johnson",
            author_email="alice@company.com",
            timestamp=datetime(2024, 3, 14, 10, 0),  # Thursday 10:00 AM
            message="Add new feature to user interface",
            files_changed=["ui.py"],
            insertions=50,
            deletions=10,
            is_merge=False,
        ),
        # Weekend emergency fix
        CommitData(
            hash="weekend123",
            author_name="Bob Hero",
            author_email="bob@company.com",
            timestamp=datetime(2024, 3, 16, 23, 30),  # Saturday 11:30 PM
            message="Fix critical production bug affecting users",
            files_changed=["hotfix.py"],
            insertions=5,
            deletions=2,
            is_merge=False,
        ),
        # Emergency response
        CommitData(
            hash="emergency123",
            author_name="Carol Firefighter",
            author_email="carol@company.com",
            timestamp=datetime(2024, 3, 15, 2, 15),  # Friday 2:15 AM
            message="Emergency hotfix for production outage",
            files_changed=["critical.py"],
            insertions=8,
            deletions=3,
            is_merge=False,
        ),
        # Hotfix
        CommitData(
            hash="hotfix123",
            author_name="Dave Savior",
            author_email="dave@company.com",
            timestamp=datetime(2024, 3, 17, 19, 45),  # Sunday 7:45 PM
            message="Hotfix: rollback broken deployment",
            files_changed=["rollback.py"],
            insertions=2,
            deletions=15,
            is_merge=False,
        ),
        # Post-rage intervention (this would follow a rage commit)
        CommitData(
            hash="fix123",
            author_name="Eve Helper",
            author_email="eve@company.com",
            timestamp=datetime(2024, 3, 15, 12, 0),  # Friday noon
            message="Fix issue introduced in previous commit",
            files_changed=["repair.py"],
            insertions=10,
            deletions=5,
            is_merge=False,
        ),
    ]


@pytest.fixture
def mock_rage_commits():
    """Create mock rage commits for testing post-rage interventions."""
    from git_therapy.analyzers.rage import RageCommit

    rage_commit_data = CommitData(
        hash="rage123",
        author_name="Angry Dev",
        author_email="angry@company.com",
        timestamp=datetime(2024, 3, 15, 10, 0),  # Friday 10:00 AM
        message="THIS STUPID BUG WON'T GO AWAY!!!",
        files_changed=["broken.py"],
        insertions=20,
        deletions=5,
        is_merge=False,
    )

    return [
        RageCommit(
            commit=rage_commit_data,
            rage_score=8.5,
            reasons=["ALL CAPS words", "Strong language"],
            severity="high",
        )
    ]


def test_detector_initialization(detector):
    """Test that the detector initializes correctly."""
    assert detector.emergency_regex is not None
    assert detector.weekend_fix_regex is not None


def test_weekend_save_detection(detector, sample_commits):
    """Test detection of weekend emergency saves."""
    # Get the weekend fix commit
    weekend_commit = sample_commits[1]  # Saturday 11:30 PM fix
    weekend_saves = detector._detect_weekend_saves([weekend_commit])

    assert len(weekend_saves) == 1
    save = weekend_saves[0]
    assert save.hero_type == "weekend_save"
    assert save.urgency_level in ["high", "critical"]  # Late night + weekend
    assert save.hero_score > 1.0


def test_emergency_response_detection(detector, sample_commits):
    """Test detection of emergency response commits."""
    # Get the emergency commit
    emergency_commit = sample_commits[2]  # Friday 2:15 AM emergency
    emergency_responses = detector._detect_emergency_responses([emergency_commit])

    assert len(emergency_responses) == 1
    response = emergency_responses[0]
    assert response.hero_type == "emergency_response"
    assert response.urgency_level == "critical"  # Early morning + emergency keywords
    assert response.hero_score > 2.0


def test_hotfix_detection(detector, sample_commits):
    """Test detection of hotfix commits."""
    # Get the hotfix commit
    hotfix_commit = sample_commits[3]  # Sunday evening hotfix
    hotfixes = detector._detect_hotfixes([hotfix_commit])

    assert len(hotfixes) == 1
    hotfix = hotfixes[0]
    assert hotfix.hero_type == "hotfix"
    assert hotfix.urgency_level == "high"  # Weekend evening
    assert hotfix.hero_score > 1.0


def test_post_rage_intervention_detection(detector, sample_commits, mock_rage_commits):
    """Test detection of post-rage intervention commits."""
    # The fix commit happens 2 hours after the rage commit
    interventions = detector._detect_post_rage_interventions(
        sample_commits, mock_rage_commits
    )

    assert len(interventions) == 1
    intervention = interventions[0]
    assert intervention.hero_type == "post_rage_fix"
    assert intervention.commit.author_name == "Eve Helper"
    assert intervention.hero_score > 0


def test_full_hero_analysis(detector, sample_commits, mock_rage_commits):
    """Test complete hero analysis."""
    analysis = detector.analyze_heroes(sample_commits, mock_rage_commits)

    # Should detect multiple heroes
    assert len(analysis.hero_profiles) > 0
    assert analysis.team_hero_score > 0
    assert len(analysis.top_heroes) > 0

    # Should find critical moments
    assert len(analysis.critical_moments) > 0

    # Should have hero timeline
    assert len(analysis.hero_timeline) > 0

    # Timeline should be sorted chronologically
    timeline_timestamps = [item[0] for item in analysis.hero_timeline]
    assert timeline_timestamps == sorted(timeline_timestamps)


def test_hero_profile_creation(detector, sample_commits):
    """Test creation of hero profiles."""
    # Get some hero moments first
    hero_moments = []
    hero_moments.extend(detector._detect_weekend_saves(sample_commits))
    hero_moments.extend(detector._detect_emergency_responses(sample_commits))
    hero_moments.extend(detector._detect_hotfixes(sample_commits))

    profiles = detector._create_hero_profiles(hero_moments, sample_commits)

    # Should create profiles for contributors with hero moments
    assert len(profiles) > 0

    for profile in profiles:
        assert profile.total_hero_score > 0
        assert len(profile.hero_moments) > 0
        assert profile.author_name is not None
        assert profile.author_email is not None


def test_no_hero_moments(detector):
    """Test analysis with commits that have no heroic actions."""
    normal_commits = [
        CommitData(
            hash="normal1",
            author_name="Regular Dev",
            author_email="regular@company.com",
            timestamp=datetime(2024, 3, 14, 10, 0),  # Thursday 10:00 AM
            message="Update documentation",
            files_changed=["docs.md"],
            insertions=20,
            deletions=5,
            is_merge=False,
        )
    ]

    analysis = detector.analyze_heroes(normal_commits)

    assert len(analysis.hero_profiles) == 0
    assert analysis.team_hero_score == 0.0
    assert len(analysis.top_heroes) == 0
    assert len(analysis.critical_moments) == 0


def test_emergency_pattern_matching(detector):
    """Test emergency pattern recognition."""
    emergency_messages = [
        "Emergency hotfix for production outage",
        "CRITICAL: Fix broken production deployment",
        "Urgent rollback of failed release",
        "Fix production issue ASAP",
        "Server down - emergency patch",
    ]

    for message in emergency_messages:
        assert detector.emergency_regex.search(message) is not None

    normal_messages = [
        "Add new feature",
        "Update unit tests",
        "Refactor code structure",
        "Documentation updates",
    ]

    for message in normal_messages:
        assert detector.emergency_regex.search(message) is None


def test_weekend_fix_pattern_matching(detector):
    """Test weekend fix pattern recognition."""
    fix_messages = [
        "Fix bug in user authentication",
        "Resolve issue with database connection",
        "Patch security vulnerability",
        "Repair broken payment system",
    ]

    for message in fix_messages:
        assert detector.weekend_fix_regex.search(message) is not None

    feature_messages = [
        "Add new payment method",
        "Implement user dashboard",
        "Create admin interface",
    ]

    for message in feature_messages:
        assert detector.weekend_fix_regex.search(message) is None
