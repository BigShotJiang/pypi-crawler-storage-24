"""Tests for personality profiler analyzer."""

from datetime import datetime, timedelta

import pytest

from git_therapy.analyzers.personality import PersonalityProfiler
from git_therapy.parser.git_log import CommitData


@pytest.fixture
def profiler():
    """Create a PersonalityProfiler instance."""
    return PersonalityProfiler()


@pytest.fixture
def perfectionist_commits():
    """Create commits representing a perfectionist developer."""
    base_time = datetime(2024, 3, 1, 9, 0)  # Start March 1, 9 AM
    commits = []

    # Create many small, well-documented commits during regular hours
    for i in range(20):
        commits.append(
            CommitData(
                hash=f"perf{i}",
                author_name="Alice Perfectionist",
                author_email="alice@company.com",
                timestamp=base_time
                + timedelta(days=i // 2, hours=(i % 2) * 2),  # Regular pattern
                message="Refactor authentication module\n\n- Extract validation logic to separate function\n- Add comprehensive error handling\n- Update unit tests for edge cases\n\nThis improves code maintainability and test coverage.",
                files_changed=["auth.py", "test_auth.py"],
                insertions=15,
                deletions=8,
                is_merge=False,
            )
        )

    return commits


@pytest.fixture
def cowboy_commits():
    """Create commits representing a cowboy developer."""
    base_time = datetime(2024, 3, 1, 14, 0)  # Start March 1, 2 PM
    commits = []

    # Create few large commits with minimal messages
    for i in range(5):
        commits.append(
            CommitData(
                hash=f"cowboy{i}",
                author_name="Bob Cowboy",
                author_email="bob@company.com",
                timestamp=base_time
                + timedelta(days=i * 7, hours=(i * 3) % 12),  # Irregular timing
                message=f"big feature #{i}",  # Short message
                files_changed=[f"feature{i}.py", f"utils{i}.py", f"config{i}.py"],
                insertions=250,
                deletions=120,
                is_merge=False,
            )
        )

    return commits


@pytest.fixture
def firefighter_commits():
    """Create commits representing a firefighter developer."""
    base_time = datetime(2024, 3, 2, 23, 0)  # Start March 2, 2024, 11 PM (Saturday)
    commits = []

    # Create weekend and emergency commits
    for i in range(6):
        # Alternate between Saturday and Sunday, spread across different weekends
        days_offset = i * 7 + (
            1 if i % 2 == 1 else 0
        )  # Saturday, then Sunday, then next Saturday, etc.
        commit_time = base_time + timedelta(days=days_offset, hours=(i % 3))

        commits.append(
            CommitData(
                hash=f"fire{i}",
                author_name="Carol Firefighter",
                author_email="carol@company.com",
                timestamp=commit_time,
                message=f"Emergency fix for production issue #{i}",
                files_changed=[f"hotfix{i}.py"],
                insertions=35,
                deletions=20,
                is_merge=(i % 2 == 0),  # Some merges
            )
        )

    return commits


@pytest.fixture
def ghost_commits():
    """Create commits representing a ghost developer."""
    base_time = datetime(2024, 3, 1, 3, 0)  # Start March 1, 3 AM
    commits = []

    # Create very few, very large commits at odd hours
    for i in range(3):
        commits.append(
            CommitData(
                hash=f"ghost{i}",
                author_name="Dave Ghost",
                author_email="dave@company.com",
                timestamp=base_time
                + timedelta(days=i * 15, hours=(i * 7) % 24),  # Very irregular
                message="update",  # Minimal message
                files_changed=[
                    f"massive{i}.py",
                    f"refactor{i}.py",
                    f"complete{i}.py",
                    f"overhaul{i}.py",
                ],
                insertions=800,
                deletions=600,
                is_merge=False,
            )
        )

    return commits


@pytest.fixture
def balanced_commits():
    """Create commits representing a balanced developer."""
    base_time = datetime(2024, 3, 1, 10, 0)  # Start March 1, 10 AM
    commits = []

    # Create moderate, regular commits with decent practices
    for i in range(12):
        commits.append(
            CommitData(
                hash=f"balanced{i}",
                author_name="Eve Balanced",
                author_email="eve@company.com",
                timestamp=base_time
                + timedelta(days=i * 2, hours=(i % 8)),  # Semi-regular
                message=f"Implement feature {i}\n\nAdds new functionality for user management.",
                files_changed=[f"feature{i}.py", f"test_feature{i}.py"]
                if i % 3 == 0
                else [f"feature{i}.py"],
                insertions=80,
                deletions=40,
                is_merge=(i % 4 == 0),  # Occasional merges
            )
        )

    return commits


def test_profiler_initialization(profiler):
    """Test that the profiler initializes correctly."""
    assert len(profiler.personality_types) == 5
    assert "Perfezionista" in profiler.personality_types
    assert "Cowboy" in profiler.personality_types
    assert "Pompiere" in profiler.personality_types
    assert "Ghost" in profiler.personality_types
    assert "Tuttofare" in profiler.personality_types


def test_perfectionist_detection(profiler, perfectionist_commits):
    """Test detection of perfectionist personality."""
    profiles = profiler.analyze_personalities(perfectionist_commits)

    assert len(profiles) == 1
    profile = profiles[0]
    assert profile.personality_type == "Perfezionista"
    assert profile.confidence_score > 0.5
    assert profile.author_name == "Alice Perfectionist"

    # Check metrics make sense for perfectionist
    metrics = profile.metrics
    assert metrics.commit_frequency > 2  # High frequency
    assert metrics.avg_diff_size < 50  # Small diffs
    assert metrics.message_detail_score > 0.5  # Detailed messages


def test_cowboy_detection(profiler, cowboy_commits):
    """Test detection of cowboy personality."""
    profiles = profiler.analyze_personalities(cowboy_commits)

    assert len(profiles) == 1
    profile = profiles[0]
    assert profile.personality_type == "Cowboy"
    assert profile.author_name == "Bob Cowboy"

    # Check metrics make sense for cowboy
    metrics = profile.metrics
    assert metrics.commit_frequency < 2  # Low frequency
    assert metrics.avg_diff_size > 200  # Large diffs
    assert metrics.message_detail_score < 0.3  # Short messages


def test_firefighter_detection(profiler, firefighter_commits):
    """Test detection of firefighter personality."""
    profiles = profiler.analyze_personalities(firefighter_commits)

    assert len(profiles) == 1
    profile = profiles[0]

    assert profile.personality_type == "Pompiere"
    assert profile.author_name == "Carol Firefighter"

    # Check metrics make sense for firefighter
    metrics = profile.metrics
    assert metrics.weekend_ratio > 0.5  # High weekend work
    assert metrics.merge_ratio > 0  # Some merges


def test_ghost_detection(profiler, ghost_commits):
    """Test detection of ghost personality."""
    profiles = profiler.analyze_personalities(ghost_commits)

    assert len(profiles) == 1
    profile = profiles[0]

    assert profile.personality_type == "Ghost"
    assert profile.author_name == "Dave Ghost"

    # Check metrics make sense for ghost
    metrics = profile.metrics
    assert metrics.commit_frequency < 1.0  # Very low frequency
    assert metrics.avg_diff_size > 1000  # Large changes
    assert metrics.message_detail_score < 0.2  # Minimal messages


def test_balanced_detection(profiler, balanced_commits):
    """Test detection of balanced personality."""
    profiles = profiler.analyze_personalities(balanced_commits)

    assert len(profiles) == 1
    profile = profiles[0]
    assert profile.personality_type == "Tuttofare"
    assert profile.author_name == "Eve Balanced"

    # Check metrics are moderate/balanced
    metrics = profile.metrics
    assert 1 <= metrics.commit_frequency <= 5  # Moderate frequency
    assert 50 <= metrics.avg_diff_size <= 150  # Moderate diffs


def test_multiple_contributors(profiler, perfectionist_commits, cowboy_commits):
    """Test analysis with multiple contributors."""
    all_commits = perfectionist_commits + cowboy_commits
    profiles = profiler.analyze_personalities(all_commits)

    assert len(profiles) == 2

    # Check both personalities were detected
    personality_types = [p.personality_type for p in profiles]
    assert "Perfezionista" in personality_types
    assert "Cowboy" in personality_types

    # Profiles should be sorted by confidence
    confidences = [p.confidence_score for p in profiles]
    assert confidences == sorted(confidences, reverse=True)


def test_test_file_detection(profiler):
    """Test detection of test files."""
    test_files = [
        "test_auth.py",
        "auth_test.py",
        "user.test.js",
        "user.spec.js",
        "tests/integration/api_test.py",
        "spec/unit/model_spec.rb",
        "__tests__/component.test.jsx",
    ]

    for file_path in test_files:
        assert profiler.test_regex.search(file_path) is not None

    non_test_files = ["auth.py", "user.js", "model.py", "component.jsx", "utils.py"]

    for file_path in non_test_files:
        assert profiler.test_regex.search(file_path) is None


def test_hours_spread_calculation(profiler):
    """Test calculation of working hours spread."""
    # Concentrated hours (9-10 AM mostly)
    concentrated_hours = [9, 9, 9, 10, 9, 10]
    spread1 = profiler._calculate_hours_spread(concentrated_hours)

    # Spread out hours (throughout the day)
    spread_hours = [1, 6, 11, 16, 21, 3, 8, 13, 18, 23]
    spread2 = profiler._calculate_hours_spread(spread_hours)

    assert spread2 > spread1  # More spread should have higher value
    assert 0 <= spread1 <= 1
    assert 0 <= spread2 <= 1


def test_message_detail_score(profiler):
    """Test calculation of message detail score."""
    detailed_commits = [
        CommitData(
            hash="detailed1",
            author_name="Detailed Dev",
            author_email="detailed@company.com",
            timestamp=datetime.now(),
            message="Implement user authentication\n\n- Add login form validation\n- Integrate with OAuth provider\n- Update user session management\n\nThis change improves security and user experience because it provides better error handling and social login options.",
            files_changed=["auth.py"],
            insertions=50,
            deletions=20,
            is_merge=False,
        )
    ]

    minimal_commits = [
        CommitData(
            hash="minimal1",
            author_name="Minimal Dev",
            author_email="minimal@company.com",
            timestamp=datetime.now(),
            message="fix",
            files_changed=["fix.py"],
            insertions=5,
            deletions=2,
            is_merge=False,
        )
    ]

    detailed_score = profiler._calculate_message_detail_score(detailed_commits)
    minimal_score = profiler._calculate_message_detail_score(minimal_commits)

    assert detailed_score > minimal_score
    assert 0 <= detailed_score <= 1
    assert 0 <= minimal_score <= 1


def test_burst_intensity_calculation(profiler):
    """Test calculation of burst intensity."""
    base_time = datetime(2024, 3, 1, 10, 0)

    # Steady commits (every 2 hours)
    steady_commits = [
        CommitData(
            hash=f"steady{i}",
            author_name="Steady Dev",
            author_email="steady@company.com",
            timestamp=base_time + timedelta(hours=i * 2),
            message=f"Commit {i}",
            files_changed=["file.py"],
            insertions=10,
            deletions=5,
            is_merge=False,
        )
        for i in range(6)
    ]

    # Bursty commits (all within 1 hour, then big gap)
    bursty_commits = [
        CommitData(
            hash=f"burst{i}",
            author_name="Bursty Dev",
            author_email="bursty@company.com",
            timestamp=base_time + timedelta(minutes=i * 10)
            if i < 3
            else base_time + timedelta(days=7, minutes=i * 10),
            message=f"Commit {i}",
            files_changed=["file.py"],
            insertions=10,
            deletions=5,
            is_merge=False,
        )
        for i in range(6)
    ]

    steady_intensity = profiler._calculate_burst_intensity(steady_commits)
    bursty_intensity = profiler._calculate_burst_intensity(bursty_commits)

    assert bursty_intensity > steady_intensity
    assert 0 <= steady_intensity <= 1
    assert 0 <= bursty_intensity <= 1


def test_insufficient_commits(profiler):
    """Test handling of contributors with too few commits."""
    few_commits = [
        CommitData(
            hash="few1",
            author_name="Few Commits",
            author_email="few@company.com",
            timestamp=datetime.now(),
            message="Only commit",
            files_changed=["file.py"],
            insertions=10,
            deletions=5,
            is_merge=False,
        )
    ]

    profiles = profiler.analyze_personalities(few_commits)
    assert len(profiles) == 0  # Should skip contributors with < 3 commits
