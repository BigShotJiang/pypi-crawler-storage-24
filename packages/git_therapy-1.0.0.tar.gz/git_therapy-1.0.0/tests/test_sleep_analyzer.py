"""Tests for sleep deprivation analyzer."""

from datetime import datetime

import pytest

from git_therapy.analyzers.sleep import SleepDeprivationAnalyzer
from git_therapy.parser.git_log import CommitData


@pytest.fixture
def analyzer():
    """Create a SleepDeprivationAnalyzer instance."""
    return SleepDeprivationAnalyzer()


@pytest.fixture
def sample_commits():
    """Create sample commits with different timing patterns."""
    return [
        # Normal daytime commit
        CommitData(
            hash="day123",
            author_name="Alice Johnson",
            author_email="alice@company.com",
            timestamp=datetime(2024, 3, 15, 14, 30),  # 2:30 PM Friday
            message="Add user profile feature",
            files_changed=["profile.py"],
            insertions=50,
            deletions=10,
            is_merge=False,
        ),
        # Late night commit
        CommitData(
            hash="night123",
            author_name="Bob Smith",
            author_email="bob@company.com",
            timestamp=datetime(2024, 3, 16, 2, 15),  # 2:15 AM Saturday
            message="Fix critical bug in production",
            files_changed=["hotfix.py"],
            insertions=5,
            deletions=2,
            is_merge=False,
        ),
        # Early morning commit
        CommitData(
            hash="dawn123",
            author_name="Bob Smith",
            author_email="bob@company.com",
            timestamp=datetime(2024, 3, 16, 5, 45),  # 5:45 AM Saturday
            message="Final touches before deadline",
            files_changed=["finish.py"],
            insertions=10,
            deletions=3,
            is_merge=False,
        ),
        # Another Alice daytime commit
        CommitData(
            hash="day456",
            author_name="Alice Johnson",
            author_email="alice@company.com",
            timestamp=datetime(2024, 3, 18, 10, 15),  # 10:15 AM Monday
            message="Update documentation",
            files_changed=["docs.md"],
            insertions=20,
            deletions=5,
            is_merge=False,
        ),
        # Weekend night commit
        CommitData(
            hash="weekend123",
            author_name="Charlie Brown",
            author_email="charlie@company.com",
            timestamp=datetime(2024, 3, 17, 1, 30),  # 1:30 AM Sunday
            message="Emergency weekend fix",
            files_changed=["emergency.py"],
            insertions=15,
            deletions=8,
            is_merge=False,
        ),
    ]


def test_analyzer_initialization(analyzer):
    """Test that the analyzer initializes correctly."""
    assert analyzer.night_start == 0
    assert analyzer.night_end == 6
    assert analyzer.late_night_end == 3
    assert analyzer.sleep_loss_per_night_commit > 0


def test_is_night_commit(analyzer):
    """Test night commit detection."""
    # Night commits (00:00-06:00)
    assert analyzer._is_night_commit(datetime(2024, 3, 15, 0, 0))  # 00:00
    assert analyzer._is_night_commit(datetime(2024, 3, 15, 2, 30))  # 02:30
    assert analyzer._is_night_commit(datetime(2024, 3, 15, 5, 59))  # 05:59

    # Not night commits
    assert not analyzer._is_night_commit(datetime(2024, 3, 15, 6, 0))  # 06:00
    assert not analyzer._is_night_commit(datetime(2024, 3, 15, 12, 0))  # 12:00
    assert not analyzer._is_night_commit(datetime(2024, 3, 15, 23, 59))  # 23:59


def test_group_by_contributor(analyzer, sample_commits):
    """Test grouping commits by contributor."""
    groups = analyzer._group_by_contributor(sample_commits)

    assert len(groups) == 3  # Alice, Bob, Charlie
    assert "alice@company.com" in groups
    assert "bob@company.com" in groups
    assert "charlie@company.com" in groups

    assert len(groups["alice@company.com"]) == 2
    assert len(groups["bob@company.com"]) == 2
    assert len(groups["charlie@company.com"]) == 1


def test_calculate_contributor_stats(analyzer, sample_commits):
    """Test calculation of contributor sleep statistics."""
    # Bob has 2 commits, both at night (2:15 AM and 5:45 AM)
    bob_commits = [c for c in sample_commits if c.author_email == "bob@company.com"]
    bob_stats = analyzer._calculate_contributor_stats(bob_commits)

    assert bob_stats.author_name == "Bob Smith"
    assert bob_stats.author_email == "bob@company.com"
    assert bob_stats.total_commits == 2
    assert bob_stats.night_commits == 2
    assert bob_stats.late_night_commits == 1  # 2:15 AM
    assert bob_stats.early_morning_commits == 1  # 5:45 AM
    assert bob_stats.night_percentage == 100.0
    assert bob_stats.risk_level == "high"  # 100% night commits
    assert bob_stats.estimated_sleep_lost_hours > 0


def test_analyze_sleep_patterns(analyzer, sample_commits):
    """Test full sleep pattern analysis."""
    analysis = analyzer.analyze_sleep_patterns(sample_commits)

    assert len(analysis.contributor_stats) == 3

    # Check team statistics
    assert analysis.team_night_percentage > 0  # Should detect night commits
    assert analysis.total_estimated_sleep_lost > 0

    # Check that Bob is identified as highest risk
    assert "Bob Smith" in analysis.highest_risk_contributors

    # Check night timeline
    assert len(analysis.night_commit_timeline) == 3  # Bob's 2 + Charlie's 1

    # Timeline should be sorted by timestamp
    timeline_timestamps = [item[0] for item in analysis.night_commit_timeline]
    assert timeline_timestamps == sorted(timeline_timestamps)


def test_determine_sleep_risk(analyzer):
    """Test sleep risk level determination."""
    # High risk scenarios
    assert analyzer._determine_sleep_risk(50.0, 10, 2) == "high"  # >30% night
    assert analyzer._determine_sleep_risk(20.0, 10, 6) == "high"  # >5 late night
    assert (
        analyzer._determine_sleep_risk(60.0, 3, 1) == "high"
    )  # >50% with small sample

    # Medium risk scenarios
    assert analyzer._determine_sleep_risk(20.0, 5, 1) == "medium"  # >15% night
    assert analyzer._determine_sleep_risk(10.0, 5, 3) == "medium"  # >2 late night

    # Low risk scenarios
    assert analyzer._determine_sleep_risk(10.0, 2, 1) == "low"
    assert analyzer._determine_sleep_risk(5.0, 1, 0) == "low"


def test_consecutive_night_sessions(analyzer):
    """Test detection of consecutive night sessions."""
    # Create commits for consecutive night session
    night_session_commits = [
        CommitData(
            hash=f"night{i}",
            author_name="Insomniac Dev",
            author_email="dev@company.com",
            timestamp=datetime(2024, 3, 15, 1 + i, 0),  # 1:00, 2:00, 3:00 AM
            message=f"Commit {i} during all-nighter",
            files_changed=[f"file{i}.py"],
            insertions=10,
            deletions=2,
            is_merge=False,
        )
        for i in range(3)
    ]

    sessions = analyzer._find_consecutive_night_sessions(night_session_commits)

    assert len(sessions) > 0
    session = sessions[0]
    assert session["commit_count"] == 3
    assert session["duration_hours"] == 2.0  # 3:00 - 1:00 = 2 hours
    assert "Insomniac Dev" in session["authors"]


def test_empty_commits(analyzer):
    """Test analysis with empty commit list."""
    analysis = analyzer.analyze_sleep_patterns([])

    assert len(analysis.contributor_stats) == 0
    assert analysis.team_night_percentage == 0.0
    assert analysis.total_estimated_sleep_lost == 0.0
    assert len(analysis.highest_risk_contributors) == 0
    assert len(analysis.night_commit_timeline) == 0


def test_single_contributor_all_day(analyzer):
    """Test analysis with single contributor, all day commits."""
    day_commits = [
        CommitData(
            hash=f"day{i}",
            author_name="Day Worker",
            author_email="day@company.com",
            timestamp=datetime(2024, 3, 15, 9 + i, 0),  # 9:00, 10:00, 11:00 AM
            message=f"Day commit {i}",
            files_changed=[f"file{i}.py"],
            insertions=20,
            deletions=5,
            is_merge=False,
        )
        for i in range(3)
    ]

    analysis = analyzer.analyze_sleep_patterns(day_commits)

    assert len(analysis.contributor_stats) == 1
    stats = analysis.contributor_stats[0]
    assert stats.night_commits == 0
    assert stats.night_percentage == 0.0
    assert stats.risk_level == "low"
    assert stats.estimated_sleep_lost_hours == 0.0
