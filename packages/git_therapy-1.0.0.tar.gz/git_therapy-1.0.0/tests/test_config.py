"""Tests for the configuration management system."""

import json
import os
import tempfile

import pytest
import yaml

from git_therapy.config import (
    ConfigManager,
    GitTherapyConfig,
    HeroConfig,
    PersonalityConfig,
    RageConfig,
    ReportConfig,
    SleepConfig,
    load_config,
    save_config,
)


@pytest.fixture
def temp_config_file():
    """Create a temporary config file for testing."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        config_data = {
            "rage": {
                "high_rage_threshold": 0.8,
                "medium_rage_threshold": 0.5,
                "short_message_threshold": 15,
            },
            "sleep": {
                "night_start_hour": 23,
                "night_end_hour": 7,
                "high_risk_threshold": 0.4,
            },
            "hero": {
                "weekend_days": [6, 0],  # Sunday, Monday
                "emergency_keywords": ["urgent", "critical"],
            },
            "verbose_output": True,
            "max_workers": 8,
        }
        yaml.dump(config_data, f)
        temp_path = f.name

    yield temp_path
    os.unlink(temp_path)


@pytest.fixture
def config_manager():
    """Create a config manager instance."""
    return ConfigManager()


def test_config_manager_initialization(config_manager):
    """Test that config manager initializes with defaults."""
    assert config_manager.config is not None
    assert isinstance(config_manager.config, GitTherapyConfig)
    assert isinstance(config_manager.config.rage, RageConfig)
    assert isinstance(config_manager.config.sleep, SleepConfig)
    assert isinstance(config_manager.config.hero, HeroConfig)
    assert isinstance(config_manager.config.personality, PersonalityConfig)
    assert isinstance(config_manager.config.report, ReportConfig)


def test_default_config_values():
    """Test that default configuration has reasonable values."""
    config = GitTherapyConfig()

    # Rage config defaults
    assert config.rage.high_rage_threshold == 0.7
    assert config.rage.medium_rage_threshold == 0.4
    assert config.rage.short_message_threshold == 10

    # Sleep config defaults
    assert config.sleep.night_start_hour == 0
    assert config.sleep.night_end_hour == 6
    assert config.sleep.high_risk_threshold == 0.3

    # Hero config defaults
    assert config.hero.weekend_days == [5, 6]  # Saturday, Sunday
    assert len(config.hero.emergency_keywords) > 0

    # Personality config defaults
    assert config.personality.min_commits_threshold == 3

    # Report config defaults
    assert config.report.base_health_score == 85

    # Global defaults
    assert config.verbose_output == False
    assert config.cache_analysis == True
    assert config.parallel_processing == True
    assert config.max_workers == 4


def test_load_config_from_yaml(config_manager, temp_config_file):
    """Test loading configuration from YAML file."""
    config = config_manager.load_config(temp_config_file)

    assert config.rage.high_rage_threshold == 0.8
    assert config.rage.medium_rage_threshold == 0.5
    assert config.rage.short_message_threshold == 15

    assert config.sleep.night_start_hour == 23
    assert config.sleep.night_end_hour == 7
    assert config.sleep.high_risk_threshold == 0.4

    assert config.hero.weekend_days == [6, 0]
    assert config.hero.emergency_keywords == ["urgent", "critical"]

    assert config.verbose_output == True
    assert config.max_workers == 8


def test_load_config_from_json():
    """Test loading configuration from JSON file."""
    config_data = {
        "rage": {"all_caps_weight": 0.4, "high_rage_threshold": 0.9},
        "sleep": {"night_start_hour": 22, "session_gap_hours": 6},
    }

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(config_data, f)
        temp_path = f.name

    try:
        manager = ConfigManager()
        config = manager.load_config(temp_path)

        assert config.rage.all_caps_weight == 0.4
        assert config.rage.high_rage_threshold == 0.9
        assert config.sleep.night_start_hour == 22
        assert config.sleep.session_gap_hours == 6
    finally:
        os.unlink(temp_path)


def test_save_config_yaml(config_manager):
    """Test saving configuration to YAML file."""
    # Modify some config values
    config_manager.config.rage.high_rage_threshold = 0.9
    config_manager.config.sleep.night_start_hour = 1
    config_manager.config.verbose_output = True

    with tempfile.TemporaryDirectory() as temp_dir:
        config_path = os.path.join(temp_dir, "test_config.yaml")
        saved_path = config_manager.save_config(config_path)

        assert saved_path == config_path
        assert os.path.exists(config_path)

        # Load it back and verify
        with open(config_path) as f:
            loaded_data = yaml.safe_load(f)

        assert loaded_data["rage"]["high_rage_threshold"] == 0.9
        assert loaded_data["sleep"]["night_start_hour"] == 1
        assert loaded_data["verbose_output"] == True


def test_save_config_json(config_manager):
    """Test saving configuration to JSON file."""
    config_manager.config.personality.min_commits_threshold = 5

    with tempfile.TemporaryDirectory() as temp_dir:
        config_path = os.path.join(temp_dir, "test_config.json")
        saved_path = config_manager.save_config(config_path)

        assert saved_path == config_path
        assert os.path.exists(config_path)

        # Load it back and verify
        with open(config_path) as f:
            loaded_data = json.load(f)

        assert loaded_data["personality"]["min_commits_threshold"] == 5


def test_load_nonexistent_config(config_manager):
    """Test loading config when no file exists (should use defaults)."""
    config = config_manager.load_config("nonexistent_file.yaml")

    # Should return default config
    assert isinstance(config, GitTherapyConfig)
    assert config.rage.high_rage_threshold == 0.7  # Default value


def test_config_validation_with_invalid_fields():
    """Test that config loading handles invalid fields gracefully."""
    config_data = {
        "rage": {"high_rage_threshold": 0.8, "invalid_field": "should_be_ignored"},
        "invalid_section": {"some_setting": "ignored"},
    }

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump(config_data, f)
        temp_path = f.name

    try:
        manager = ConfigManager()
        config = manager.load_config(temp_path)

        # Valid field should be loaded
        assert config.rage.high_rage_threshold == 0.8
        # Invalid field should not crash the loading
        assert not hasattr(config.rage, "invalid_field")
    finally:
        os.unlink(temp_path)


def test_global_config_functions():
    """Test the global configuration functions."""
    # Create a temporary config
    config_data = {"verbose_output": True, "max_workers": 16}

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump(config_data, f)
        temp_path = f.name

    try:
        # Test loading
        config = load_config(temp_path)
        assert config.verbose_output == True
        assert config.max_workers == 16

        # Test saving
        config.cache_analysis = False
        with tempfile.TemporaryDirectory() as temp_dir:
            save_path = os.path.join(temp_dir, "saved_config.yaml")
            result_path = save_config(save_path)
            assert os.path.exists(result_path)

    finally:
        os.unlink(temp_path)


def test_default_config_paths_search():
    """Test that config manager searches default paths."""
    manager = ConfigManager()

    # Should have default paths to search
    assert len(manager.DEFAULT_CONFIG_PATHS) > 0
    assert any(".git-therapy" in path for path in manager.DEFAULT_CONFIG_PATHS)


def test_get_default_config_content(config_manager):
    """Test getting default config as string."""
    content = config_manager.get_default_config_content()

    assert isinstance(content, str)
    assert "rage:" in content
    assert "sleep:" in content
    assert "hero:" in content
    assert "personality:" in content
    assert "report:" in content


def test_config_dataclass_initialization():
    """Test that all config dataclasses initialize properly."""
    rage_config = RageConfig()
    assert rage_config.custom_rage_patterns == []

    hero_config = HeroConfig()
    assert len(hero_config.emergency_keywords) > 0
    assert len(hero_config.hotfix_keywords) > 0
    assert hero_config.weekend_days == [5, 6]

    report_config = ReportConfig()
    assert isinstance(report_config.chart_colors, dict)
    assert "rage" in report_config.chart_colors


def test_partial_config_loading():
    """Test loading config with only some sections defined."""
    config_data = {"rage": {"high_rage_threshold": 0.95}, "verbose_output": True}

    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
        yaml.dump(config_data, f)
        temp_path = f.name

    try:
        manager = ConfigManager()
        config = manager.load_config(temp_path)

        # Should load specified values
        assert config.rage.high_rage_threshold == 0.95
        assert config.verbose_output == True

        # Should keep defaults for unspecified values
        assert config.sleep.night_start_hour == 0  # Default value
        assert config.hero.weekend_days == [5, 6]  # Default value
    finally:
        os.unlink(temp_path)
