"""Tests for the HTML report generator."""

import os
import tempfile
from datetime import datetime
from pathlib import Path

import pytest

from git_therapy.parser.git_log import CommitData
from git_therapy.report.generator import HtmlReportGenerator, ReportData


@pytest.fixture
def sample_commits():
    """Create sample commit data for testing."""
    base_time = datetime(2024, 3, 1, 10, 0)

    commits = [
        # Alice commits (3 commits for personality analysis)
        CommitData(
            hash="abc123",
            author_name="Alice Developer",
            author_email="alice@company.com",
            timestamp=base_time,
            message="Add user authentication feature\n\nImplements OAuth2 login flow with JWT tokens.",
            files_changed=["auth.py", "test_auth.py"],
            insertions=150,
            deletions=20,
            is_merge=False,
        ),
        CommitData(
            hash="abc124",
            author_name="Alice Developer",
            author_email="alice@company.com",
            timestamp=base_time.replace(day=5),
            message="Refactor authentication module\n\nImprove error handling and validation.",
            files_changed=["auth.py"],
            insertions=80,
            deletions=30,
            is_merge=False,
        ),
        CommitData(
            hash="abc125",
            author_name="Alice Developer",
            author_email="alice@company.com",
            timestamp=base_time.replace(day=10),
            message="Add OAuth2 tests\n\nComprehensive test coverage for login flow.",
            files_changed=["test_auth.py"],
            insertions=120,
            deletions=10,
            is_merge=False,
        ),
        # Bob commits (rage commits)
        CommitData(
            hash="def456",
            author_name="Bob Coder",
            author_email="bob@company.com",
            timestamp=base_time.replace(hour=23),  # Late night
            message="FIX THE DAMN BUG!!!",
            files_changed=["bug.py"],
            insertions=5,
            deletions=2,
            is_merge=False,
        ),
        CommitData(
            hash="def457",
            author_name="Bob Coder",
            author_email="bob@company.com",
            timestamp=base_time.replace(day=3, hour=1),  # Night commit
            message="WTF is wrong with this code",
            files_changed=["bug.py"],
            insertions=15,
            deletions=8,
            is_merge=False,
        ),
        CommitData(
            hash="def458",
            author_name="Bob Coder",
            author_email="bob@company.com",
            timestamp=base_time.replace(day=7),
            message="Finally fix the stupid issue",
            files_changed=["bug.py"],
            insertions=25,
            deletions=12,
            is_merge=False,
        ),
        # Carol commits (weekend hero)
        CommitData(
            hash="ghi789",
            author_name="Carol Hero",
            author_email="carol@company.com",
            timestamp=base_time.replace(day=2, hour=14),  # Saturday
            message="Emergency fix for production outage",
            files_changed=["critical.py"],
            insertions=30,
            deletions=15,
            is_merge=True,
        ),
        CommitData(
            hash="ghi790",
            author_name="Carol Hero",
            author_email="carol@company.com",
            timestamp=base_time.replace(day=9, hour=16),  # Another Saturday
            message="Hotfix for customer issue",
            files_changed=["hotfix.py"],
            insertions=40,
            deletions=20,
            is_merge=True,
        ),
        CommitData(
            hash="ghi791",
            author_name="Carol Hero",
            author_email="carol@company.com",
            timestamp=base_time.replace(day=16, hour=18),  # Another Saturday
            message="Critical security patch",
            files_changed=["security.py"],
            insertions=60,
            deletions=25,
            is_merge=False,
        ),
    ]

    return commits


@pytest.fixture
def generator():
    """Create a report generator instance."""
    return HtmlReportGenerator()


def test_generator_initialization(generator):
    """Test that the generator initializes correctly."""
    assert generator is not None
    assert generator.env is not None

    # Check that custom filters are registered
    assert "to_json" in generator.env.filters
    assert "format_percentage" in generator.env.filters
    assert "format_confidence" in generator.env.filters


def test_to_json_filter(generator):
    """Test the to_json custom filter."""
    test_dict = {"key": "value", "number": 42}
    result = generator._to_json_filter(test_dict)
    assert '"key": "value"' in result
    assert '"number": 42' in result


def test_format_percentage_filter(generator):
    """Test the percentage formatting filter."""
    assert generator._format_percentage_filter(0.75) == "75.0%"
    assert generator._format_percentage_filter(0.333) == "33.3%"
    assert generator._format_percentage_filter(1.0) == "100.0%"


def test_format_confidence_filter(generator):
    """Test the confidence formatting filter."""
    assert generator._format_confidence_filter(0.85) == "85%"
    assert generator._format_confidence_filter(0.333) == "33%"
    assert generator._format_confidence_filter(1.0) == "100%"


def test_analyze_commits(generator, sample_commits):
    """Test that commit analysis produces valid report data."""
    report_data = generator._analyze_commits(sample_commits, "test-repo")

    assert isinstance(report_data, ReportData)
    assert report_data.commit_count == 9
    assert report_data.repository_name == "test-repo"
    assert report_data.date_range != ""

    # Check that all analyzers ran
    assert report_data.rage_analysis is not None
    assert report_data.sleep_analysis is not None
    assert report_data.hero_analysis is not None
    assert report_data.personality_profiles is not None

    # Basic validation of results
    assert report_data.rage_analysis is not None
    assert (
        len(report_data.rage_analysis["rage_commits"]) >= 1
    )  # Should detect the rage commit
    assert len(report_data.personality_profiles) > 0  # Should detect personalities


def test_calculate_summary_stats(generator, sample_commits):
    """Test summary statistics calculation."""
    report_data = generator._analyze_commits(sample_commits, "test-repo")
    summary_stats = generator._calculate_summary_stats(report_data)

    assert isinstance(summary_stats, dict)
    assert "total_contributors" in summary_stats
    assert "total_rage_commits" in summary_stats
    assert "total_night_commits" in summary_stats
    assert "total_hero_moments" in summary_stats
    assert "health_score" in summary_stats

    # Health score should be reasonable
    assert 0 <= summary_stats["health_score"] <= 100


def test_generate_report_creates_file(generator, sample_commits):
    """Test that report generation creates an HTML file."""
    with tempfile.TemporaryDirectory() as temp_dir:
        output_path = os.path.join(temp_dir, "test_report.html")

        result_path = generator.generate_report(
            commits=sample_commits,
            output_path=output_path,
            repository_name="test-repository",
        )

        assert result_path == output_path
        assert Path(output_path).exists()

        # Read and verify basic content
        html_content = Path(output_path).read_text(encoding="utf-8")
        assert "Git Therapy Report" in html_content
        assert "test-repository" in html_content
        assert "Chart.js" in html_content  # Should include charting library


def test_generate_report_html_structure(generator, sample_commits):
    """Test that generated HTML has proper structure."""
    with tempfile.TemporaryDirectory() as temp_dir:
        output_path = os.path.join(temp_dir, "test_report.html")

        generator.generate_report(
            commits=sample_commits, output_path=output_path, repository_name="test-repo"
        )

        html_content = Path(output_path).read_text(encoding="utf-8")

        # Check for main sections
        assert "Rage Commit Analysis" in html_content
        assert "Sleep Deprivation Analysis" in html_content
        assert "Hero Moment Analysis" in html_content
        assert "Personality Profiling" in html_content

        # Check for dashboard elements
        assert "Team Health Score" in html_content
        assert "Contributors" in html_content
        assert "Rage Commits" in html_content
        assert "Night Commits" in html_content
        assert "Hero Moments" in html_content

        # Check for interactive charts
        assert "rageChart" in html_content
        assert "sleepChart" in html_content
        assert "personalityChart" in html_content


def test_empty_commits_handling(generator):
    """Test handling of empty commit list."""
    report_data = generator._analyze_commits([], "empty-repo")

    assert report_data.commit_count == 0
    assert report_data.repository_name == "empty-repo"
    assert report_data.date_range == ""

    # Should not crash with empty data
    summary_stats = generator._calculate_summary_stats(report_data)
    assert summary_stats["total_contributors"] == 0


def test_single_commit_handling(generator):
    """Test handling of single commit."""
    single_commit = [
        CommitData(
            hash="single",
            author_name="Solo Dev",
            author_email="solo@company.com",
            timestamp=datetime(2024, 3, 1, 10, 0),
            message="Initial commit",
            files_changed=["README.md"],
            insertions=10,
            deletions=0,
            is_merge=False,
        )
    ]

    with tempfile.TemporaryDirectory() as temp_dir:
        output_path = os.path.join(temp_dir, "single_commit_report.html")

        result_path = generator.generate_report(
            commits=single_commit,
            output_path=output_path,
            repository_name="single-commit-repo",
        )

        assert Path(result_path).exists()
        html_content = Path(result_path).read_text(encoding="utf-8")
        assert "single-commit-repo" in html_content
        # With only 1 commit, no personality profiling should occur (minimum is 3 commits)
        # But the basic structure should be there
        assert "Team Health Score" in html_content  # Dashboard should exist
