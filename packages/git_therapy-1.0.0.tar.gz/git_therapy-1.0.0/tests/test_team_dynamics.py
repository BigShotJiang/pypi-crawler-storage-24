"""Tests for the team dynamics analyzer."""

from datetime import datetime, timedelta

import pytest

from git_therapy.analyzers.team_dynamics import TeamDynamics, TeamDynamicsAnalyzer
from git_therapy.parser.git_log import CommitData


@pytest.fixture
def sample_team_commits():
    """Create sample commits from multiple team members."""
    base_time = datetime(2024, 3, 1, 10, 0)

    commits = [
        # Alice - Backend developer
        CommitData(
            hash="alice1",
            author_name="Alice Backend",
            author_email="alice@company.com",
            timestamp=base_time,
            message="Add user authentication API",
            files_changed=["auth/api.py", "auth/models.py"],
            insertions=120,
            deletions=10,
            is_merge=False,
        ),
        CommitData(
            hash="alice2",
            author_name="Alice Backend",
            author_email="alice@company.com",
            timestamp=base_time + timedelta(days=1),
            message="Improve authentication error handling",
            files_changed=["auth/api.py", "auth/errors.py"],
            insertions=45,
            deletions=20,
            is_merge=False,
        ),
        CommitData(
            hash="alice3",
            author_name="Alice Backend",
            author_email="alice@company.com",
            timestamp=base_time + timedelta(days=3),
            message="Add database migrations for auth",
            files_changed=["migrations/001_auth.sql"],
            insertions=50,
            deletions=0,
            is_merge=False,
        ),
        # Bob - Frontend developer
        CommitData(
            hash="bob1",
            author_name="Bob Frontend",
            author_email="bob@company.com",
            timestamp=base_time + timedelta(hours=6),
            message="Create login form component",
            files_changed=[
                "frontend/components/LoginForm.jsx",
                "frontend/styles/auth.css",
            ],
            insertions=80,
            deletions=5,
            is_merge=False,
        ),
        CommitData(
            hash="bob2",
            author_name="Bob Frontend",
            author_email="bob@company.com",
            timestamp=base_time + timedelta(days=1, hours=2),
            message="Fix merge conflict in auth API integration",
            files_changed=["frontend/api/auth.js"],
            insertions=30,
            deletions=25,
            is_merge=False,
        ),
        CommitData(
            hash="bob3",
            author_name="Bob Frontend",
            author_email="bob@company.com",
            timestamp=base_time + timedelta(days=2),
            message="Update login form styling",
            files_changed=["frontend/styles/auth.css"],
            insertions=20,
            deletions=10,
            is_merge=False,
        ),
        # Carol - Full-stack, works on shared files
        CommitData(
            hash="carol1",
            author_name="Carol Fullstack",
            author_email="carol@company.com",
            timestamp=base_time + timedelta(hours=12),
            message="Connect frontend auth with backend API",
            files_changed=["frontend/api/auth.js", "auth/api.py"],
            insertions=60,
            deletions=30,
            is_merge=False,
        ),
        CommitData(
            hash="carol2",
            author_name="Carol Fullstack",
            author_email="carol@company.com",
            timestamp=base_time + timedelta(days=2, hours=3),
            message="Resolve conflict between frontend and backend auth",
            files_changed=["frontend/api/auth.js"],
            insertions=15,
            deletions=20,
            is_merge=True,
        ),
        # Dave - Documentation only (knowledge silo)
        CommitData(
            hash="dave1",
            author_name="Dave Docs",
            author_email="dave@company.com",
            timestamp=base_time + timedelta(days=1, hours=5),
            message="Add authentication documentation",
            files_changed=["docs/auth.md", "docs/api.md", "README.md"],
            insertions=200,
            deletions=5,
            is_merge=False,
        ),
    ]

    return commits


@pytest.fixture
def analyzer():
    """Create a team dynamics analyzer instance."""
    return TeamDynamicsAnalyzer()


def test_analyzer_initialization(analyzer):
    """Test that the analyzer initializes correctly."""
    assert analyzer is not None
    assert analyzer.conflict_indicators is not None
    assert len(analyzer.conflict_indicators) > 0


def test_analyze_empty_commits(analyzer):
    """Test analysis with no commits."""
    result = analyzer.analyze_team_dynamics([])

    assert isinstance(result, TeamDynamics)
    assert result.total_contributors == 0
    assert result.collaboration_matrix == {}
    assert result.communication_health == 0.0
    assert result.workflow_efficiency == 0.0
    assert result.knowledge_silos == []
    assert result.hot_files == []


def test_analyze_team_dynamics(analyzer, sample_team_commits):
    """Test full team dynamics analysis."""
    result = analyzer.analyze_team_dynamics(sample_team_commits)

    assert isinstance(result, TeamDynamics)
    assert result.total_contributors == 4  # Alice, Bob, Carol, Dave
    assert len(result.collaboration_matrix) > 0
    assert 0.0 <= result.communication_health <= 1.0
    assert 0.0 <= result.workflow_efficiency <= 1.0


def test_collaboration_matrix(analyzer, sample_team_commits):
    """Test collaboration matrix calculation."""
    result = analyzer.analyze_team_dynamics(sample_team_commits)

    # Check that collaboration matrix exists
    assert len(result.collaboration_matrix) > 0

    # Find collaboration between Alice and Carol (they both worked on auth/api.py)
    alice_carol_collab = None
    for (author1, author2), metrics in result.collaboration_matrix.items():
        if "alice@company.com" in [author1, author2] and "carol@company.com" in [
            author1,
            author2,
        ]:
            alice_carol_collab = metrics
            break

    assert alice_carol_collab is not None
    assert alice_carol_collab.total_collaborations > 0
    assert "auth/api.py" in alice_carol_collab.shared_files


def test_knowledge_silos_detection(analyzer, sample_team_commits):
    """Test detection of knowledge silos."""
    result = analyzer.analyze_team_dynamics(sample_team_commits)

    # Dave only works on documentation files, which should be detected as a silo
    dave_silo = None
    for author, files in result.knowledge_silos:
        if "dave@company.com" in author:
            dave_silo = files
            break

    assert dave_silo is not None
    assert len(dave_silo) >= 3  # Dave has exclusive access to multiple docs files


def test_hot_files_detection(analyzer, sample_team_commits):
    """Test detection of hot files (worked on by multiple people)."""
    result = analyzer.analyze_team_dynamics(sample_team_commits)

    # Verify hot files detection logic (requires 3+ contributors by design)
    # Our test data has files worked on by 2 people, so hot_files should be empty
    assert isinstance(result.hot_files, list)

    # Verify that files with multiple contributors exist in our data
    authors_by_file = {}
    for commit in sample_team_commits:
        for file in commit.files_changed:
            if file not in authors_by_file:
                authors_by_file[file] = set()
            authors_by_file[file].add(commit.author_email)

    files_with_multiple_contributors = [
        (file, len(authors))
        for file, authors in authors_by_file.items()
        if len(authors) >= 2
    ]

    # Should have at least one file worked on by multiple people
    assert len(files_with_multiple_contributors) > 0


def test_communication_health_calculation(analyzer, sample_team_commits):
    """Test communication health score calculation."""
    result = analyzer.analyze_team_dynamics(sample_team_commits)

    # Should return a score between 0 and 1
    assert 0.0 <= result.communication_health <= 1.0

    # With conflict indicators in the commits, score should be reasonable
    # (not perfect due to merge conflicts, but not terrible either)
    assert result.communication_health > 0.2  # Some communication happening


def test_workflow_efficiency_calculation(analyzer, sample_team_commits):
    """Test workflow efficiency score calculation."""
    result = analyzer.analyze_team_dynamics(sample_team_commits)

    # Should return a score between 0 and 1
    assert 0.0 <= result.workflow_efficiency <= 1.0


def test_conflict_detection(analyzer):
    """Test merge conflict detection in commit messages."""
    conflict_commits = [
        CommitData(
            hash="conflict1",
            author_name="Alice",
            author_email="alice@company.com",
            timestamp=datetime(2024, 3, 1, 10, 0),
            message="Fix merge conflict in auth.py",
            files_changed=["auth.py"],
            insertions=10,
            deletions=10,
            is_merge=False,
        ),
        CommitData(
            hash="conflict2",
            author_name="Bob",
            author_email="bob@company.com",
            timestamp=datetime(2024, 3, 1, 11, 0),
            message="Resolve conflict between branches",
            files_changed=["auth.py"],
            insertions=5,
            deletions=5,
            is_merge=True,
        ),
    ]

    result = analyzer.analyze_team_dynamics(conflict_commits)

    # Should detect conflicts and impact communication health
    alice_bob_collab = None
    for (author1, author2), metrics in result.collaboration_matrix.items():
        alice_bob_collab = metrics
        break

    assert alice_bob_collab is not None
    assert alice_bob_collab.merge_conflicts > 0


def test_single_contributor(analyzer):
    """Test analysis with only one contributor."""
    single_commits = [
        CommitData(
            hash="solo1",
            author_name="Solo Dev",
            author_email="solo@company.com",
            timestamp=datetime(2024, 3, 1, 10, 0),
            message="Initial commit",
            files_changed=["main.py"],
            insertions=100,
            deletions=0,
            is_merge=False,
        ),
        CommitData(
            hash="solo2",
            author_name="Solo Dev",
            author_email="solo@company.com",
            timestamp=datetime(2024, 3, 2, 10, 0),
            message="Add feature",
            files_changed=["feature.py"],
            insertions=50,
            deletions=0,
            is_merge=False,
        ),
    ]

    result = analyzer.analyze_team_dynamics(single_commits)

    assert result.total_contributors == 1
    assert len(result.collaboration_matrix) == 0  # No collaboration possible
    assert result.knowledge_silos == []  # Only one person, no silos
    assert result.hot_files == []  # No shared files


def test_estimate_merge_conflicts(analyzer):
    """Test merge conflict estimation logic."""
    # Create scenario with overlapping work on same file at similar times
    overlapping_commits = [
        CommitData(
            hash="overlap1",
            author_name="Alice",
            author_email="alice@company.com",
            timestamp=datetime(2024, 3, 1, 10, 0),
            message="Update shared file",
            files_changed=["shared.py"],
            insertions=20,
            deletions=5,
            is_merge=False,
        ),
        CommitData(
            hash="overlap2",
            author_name="Bob",
            author_email="bob@company.com",
            timestamp=datetime(2024, 3, 1, 12, 0),  # 2 hours later
            message="Also update shared file",
            files_changed=["shared.py"],
            insertions=15,
            deletions=10,
            is_merge=False,
        ),
    ]

    result = analyzer.analyze_team_dynamics(overlapping_commits)

    # Should detect potential conflicts due to close timing
    alice_bob_collab = list(result.collaboration_matrix.values())[0]
    assert alice_bob_collab.merge_conflicts >= 0  # At least some conflict potential
