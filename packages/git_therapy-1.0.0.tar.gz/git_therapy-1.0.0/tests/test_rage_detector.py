"""Tests for rage commit detection analyzer."""

from datetime import datetime

import pytest

from git_therapy.analyzers.rage import RageCommitDetector
from git_therapy.parser.git_log import CommitData


@pytest.fixture
def detector():
    """Create a RageCommitDetector instance."""
    return RageCommitDetector()


@pytest.fixture
def sample_commits():
    """Create sample commits for testing."""
    return [
        # Normal commit
        CommitData(
            hash="abc123",
            author_name="John Doe",
            author_email="john@example.com",
            timestamp=datetime.now(),
            message="Add user authentication feature",
            files_changed=["auth.py"],
            insertions=50,
            deletions=10,
            is_merge=False,
        ),
        # Rage commit - all caps
        CommitData(
            hash="def456",
            author_name="Jane Smith",
            author_email="jane@example.com",
            timestamp=datetime.now(),
            message="FINALLY FIXED THIS DAMN BUG!!!",
            files_changed=["bug.py"],
            insertions=5,
            deletions=2,
            is_merge=False,
        ),
        # Rage commit - short frustrated
        CommitData(
            hash="ghi789",
            author_name="Bob Wilson",
            author_email="bob@example.com",
            timestamp=datetime.now(),
            message="fix",
            files_changed=["fix.py"],
            insertions=1,
            deletions=0,
            is_merge=False,
        ),
        # Rage commit - personal frustration
        CommitData(
            hash="jkl012",
            author_name="Alice Brown",
            author_email="alice@example.com",
            timestamp=datetime.now(),
            message="I can't figure out why this is not working again",
            files_changed=["debug.py"],
            insertions=3,
            deletions=1,
            is_merge=False,
        ),
    ]


def test_rage_detector_initialization(detector):
    """Test that the rage detector initializes correctly."""
    assert detector is not None
    assert len(detector.swear_words["en"]) > 0
    assert len(detector.swear_words["it"]) > 0
    assert len(detector.short_frustrated) > 0


def test_normal_commit_no_rage(detector, sample_commits):
    """Test that normal commits are not flagged as rage commits."""
    normal_commit = sample_commits[0]
    score, reasons = detector._calculate_rage_score(normal_commit)

    assert score == 0.0
    assert len(reasons) == 0


def test_all_caps_rage_detection(detector, sample_commits):
    """Test detection of all caps rage commits."""
    rage_commit = sample_commits[1]  # "FINALLY FIXED THIS DAMN BUG!!!"
    score, reasons = detector._calculate_rage_score(rage_commit)

    assert score > 0
    assert any("ALL CAPS" in reason for reason in reasons)
    assert any("Strong language" in reason for reason in reasons)
    assert any("punctuation" in reason for reason in reasons)


def test_short_frustrated_message(detector, sample_commits):
    """Test detection of ultra-short frustrated messages."""
    rage_commit = sample_commits[2]  # "fix"
    score, reasons = detector._calculate_rage_score(rage_commit)

    assert score > 0
    assert any("Ultra-short frustrated message" in reason for reason in reasons)


def test_personal_frustration_detection(detector, sample_commits):
    """Test detection of personal frustration indicators."""
    rage_commit = sample_commits[3]  # "I can't figure out..."
    score, reasons = detector._calculate_rage_score(rage_commit)

    assert score > 0
    assert any("Personal frustration" in reason for reason in reasons)
    assert any("Personal tone" in reason for reason in reasons)


def test_analyze_commits(detector, sample_commits):
    """Test analysis of multiple commits."""
    rage_commits = detector.analyze_commits(sample_commits)

    # Should find 3 rage commits (excluding the normal one)
    assert len(rage_commits) == 3

    # Should be sorted by rage score (highest first)
    scores = [commit.rage_score for commit in rage_commits]
    assert scores == sorted(scores, reverse=True)

    # Check that all rage commits have severity assigned
    for rage_commit in rage_commits:
        assert rage_commit.severity in ["low", "medium", "high"]
        assert rage_commit.rage_score > 0
        assert len(rage_commit.reasons) > 0


def test_severity_determination(detector):
    """Test severity level determination."""
    assert detector._determine_severity(8.0) == "high"
    assert detector._determine_severity(4.5) == "medium"
    assert detector._determine_severity(2.0) == "low"


def test_rage_statistics(detector, sample_commits):
    """Test rage statistics calculation."""
    rage_commits = detector.analyze_commits(sample_commits)
    stats = detector.get_rage_statistics(rage_commits)

    assert stats["total_rage_commits"] == 3
    assert stats["average_rage_score"] > 0
    assert stats["max_rage_score"] > 0
    assert (
        stats["severity_distribution"]["high"]
        + stats["severity_distribution"]["medium"]
        + stats["severity_distribution"]["low"]
        == 3
    )
    assert len(stats["most_common_reasons"]) > 0


def test_empty_commits_statistics(detector):
    """Test statistics with empty commit list."""
    stats = detector.get_rage_statistics([])

    assert stats["total_rage_commits"] == 0
    assert stats["average_rage_score"] == 0.0
    assert stats["max_rage_score"] == 0.0
    assert stats["severity_distribution"] == {"high": 0, "medium": 0, "low": 0}
    assert stats["most_common_reasons"] == []


def test_italian_swear_words(detector):
    """Test detection of Italian swear words."""
    commit = CommitData(
        hash="ita123",
        author_name="Mario Rossi",
        author_email="mario@example.com",
        timestamp=datetime.now(),
        message="Questa merda non funziona mai!",
        files_changed=["test.py"],
        insertions=1,
        deletions=0,
        is_merge=False,
    )

    score, reasons = detector._calculate_rage_score(commit)
    assert score > 0
    assert any("Strong language detected (it)" in reason for reason in reasons)


def test_edge_cases(detector):
    """Test edge cases and special scenarios."""
    # Very long message with no rage
    long_normal = CommitData(
        hash="long123",
        author_name="Test User",
        author_email="test@example.com",
        timestamp=datetime.now(),
        message="Implement comprehensive user authentication system with OAuth2 support",
        files_changed=["auth.py"],
        insertions=100,
        deletions=20,
        is_merge=False,
    )

    score, reasons = detector._calculate_rage_score(long_normal)
    assert score == 0.0

    # Empty message
    empty_message = CommitData(
        hash="empty123",
        author_name="Test User",
        author_email="test@example.com",
        timestamp=datetime.now(),
        message="",
        files_changed=[],
        insertions=0,
        deletions=0,
        is_merge=False,
    )

    score, reasons = detector._calculate_rage_score(empty_message)
    assert score >= 0  # Should not crash
