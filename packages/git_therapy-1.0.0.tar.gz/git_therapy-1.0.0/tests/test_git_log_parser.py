"""Tests for git log parser."""

import tempfile
from datetime import datetime
from pathlib import Path

import git
import pytest

from git_therapy.parser.git_log import CommitData, GitLogParser


@pytest.fixture
def temp_repo():
    """Create a temporary git repository for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo_path = Path(tmpdir)
        repo = git.Repo.init(repo_path)

        # Configure git user for the test
        with repo.config_writer() as config:
            config.set_value("user", "name", "Test User")
            config.set_value("user", "email", "test@example.com")

        # Create a test file and commit
        test_file = repo_path / "test.txt"
        test_file.write_text("Hello, world!\n")

        repo.index.add([str(test_file)])
        repo.index.commit("Initial commit")

        # Create another commit
        test_file.write_text("Hello, world!\nSecond line\n")
        repo.index.add([str(test_file)])
        repo.index.commit("Add second line")

        yield repo_path


def test_parser_initialization():
    """Test parser initialization."""
    parser = GitLogParser()
    assert parser.repo_path == Path.cwd()

    custom_path = "/some/path"
    parser = GitLogParser(custom_path)
    assert parser.repo_path == Path(custom_path)


def test_parser_with_invalid_repo():
    """Test parser with invalid repository path."""
    with tempfile.TemporaryDirectory() as tmpdir:
        parser = GitLogParser(tmpdir)  # Not a git repo
        with pytest.raises(ValueError, match="Not a git repository"):
            _ = parser.repo  # Access property to trigger exception


def test_parse_commits(temp_repo):
    """Test commit parsing functionality."""
    parser = GitLogParser(str(temp_repo))
    commits = parser.parse_commits()

    assert len(commits) == 2
    assert all(isinstance(commit, CommitData) for commit in commits)

    # Check first commit (most recent)
    first_commit = commits[0]
    assert first_commit.author_name == "Test User"
    assert first_commit.author_email == "test@example.com"
    assert first_commit.message == "Add second line"
    assert not first_commit.is_merge
    assert isinstance(first_commit.timestamp, datetime)
    assert len(first_commit.hash) == 40  # SHA-1 hash length


def test_parse_commits_with_limit(temp_repo):
    """Test commit parsing with max_count limit."""
    parser = GitLogParser(str(temp_repo))
    commits = parser.parse_commits(max_count=1)

    assert len(commits) == 1
    assert commits[0].message == "Add second line"


def test_get_repository_info(temp_repo):
    """Test repository info extraction."""
    parser = GitLogParser(str(temp_repo))
    info = parser.get_repository_info()

    assert info["path"] == str(temp_repo)
    assert info["current_branch"] == "master"  # Default branch name
    assert info["total_commits"] == 2
    assert info["contributors"] == 1
    assert "error" not in info


def test_commit_data_structure():
    """Test CommitData dataclass structure."""
    commit_data = CommitData(
        hash="abc123",
        author_name="Test User",
        author_email="test@example.com",
        timestamp=datetime.now(),
        message="Test commit",
        files_changed=["file1.py"],
        insertions=10,
        deletions=5,
        is_merge=False,
    )

    assert commit_data.hash == "abc123"
    assert commit_data.author_name == "Test User"
    assert commit_data.files_changed == ["file1.py"]
    assert commit_data.insertions == 10
    assert commit_data.deletions == 5
    assert not commit_data.is_merge
