# 🧠 git-therapy

> *Your repository has a lot to say. Are you ready to listen?*

---

## Concept

`git-therapy` è uno strumento CLI che analizza l'intera storia dei commit di un repository Git e costruisce un **profilo psicologico del team** che ci ha lavorato.

Non è un linter. Non è un analizzatore di codice. È uno specchio.

Prende dati oggettivi (orari dei commit, messaggi, frequenza, pattern di modifica dei file, chi lavora su cosa) e li trasforma in una **narrativa umana**: chi era sotto stress, chi era in flow, quando il progetto ha quasi mollato, chi salva sempre tutto all'ultimo momento.

L'output finale è un report HTML interattivo con grafici, timeline e una "terapia" scritta in tono ironico-professionale, come se il tuo repo fosse un paziente sul divano di uno psicologo.

---

## Perché funziona (e prende stelle)

- **È divertente** — ogni developer lo condivide perché vuole vedere il report del proprio repo
- **È utile davvero** — i team lead lo usano per capire i pattern di burnout o di produttività
- **Ha una storia** — ogni repo diventa un personaggio con una narrazione
- **È completamente offline** — nessun dato esce dalla macchina, zero privacy concerns
- **Funziona su qualsiasi repo** — non serve configurazione, basta un `git clone`

---

## Funzionalità core

### 1. Rage Commit Detection
Analizza i messaggi di commit cercando pattern linguistici associati a frustrazione:
- Maiuscole eccessive ("FINALLY FIXED", "WHY IS THIS BROKEN")
- Parolacce o sfoghi
- Messaggi ultra-brevi dopo una serie di commit falliti ("fix", "fix2", "ok", "please work")
- Commit message che iniziano con "I" (indicatore di frustrazione personale vs professionale)

Ogni "rage commit" viene evidenziato nella timeline con il contesto: cosa era successo prima, quanto tempo era passato dall'ultimo commit.

### 2. Sleep Deprivation Index
Calcola un punteggio basato su:
- Frequenza di commit tra le 00:00 e le 06:00
- Errori introdotti in quei commit (misurati dai fix successivi)
- Pattern ricorrenti (sempre di notte prima di una deadline?)

Output: "Il tuo team ha perso un totale stimato di **340 ore di sonno** su questo progetto."

### 3. Hero Detection
Identifica chi ha salvato il progetto nei momenti critici:
- Chi committa nei weekend
- Chi interviene dopo i rage commit degli altri
- Chi fa commit di hotfix in produzione fuori orario

Non è una classifica di produttività — è una classifica di **sacrificio**.

### 4. Flow State Analysis
Cerca i periodi di massima produttività:
- Serie di commit regolari, messaggi chiari, pochi revert
- Stima le "ore di flow" vs "ore di lotta"
- Mostra il confronto per developer e per periodo temporale

### 5. The Breaking Point Timeline
Una timeline visiva che mostra i momenti critici del progetto:
- Quando il numero di bug fix ha superato le feature
- Quando qualcuno ha smesso di commitare per settimane
- Quando il progetto ha "resuscitato" dopo un periodo morto
- Il giorno più buio del repo (più revert, più messaggi negativi, più notti)

### 6. Commit Personality Profiles
Per ogni contributor, un profilo in stile MBTI ma basato sui dati reali:

**Esempi:**
- *"Il Perfezionista"* — 40 commit per feature, rebase costante, messaggi dettagliati
- *"Il Cowboy"* — commit enormi e rari, nessun test, ma funziona sempre
- *"Il Pompiere"* — invisibile per settimane, appare solo nelle emergenze
- *"Il Ghost"* — molte righe scritte, pochissimi commit, sembra non esistere

### 7. The Therapy Session (output narrativo)
Il pezzo più originale. Un testo in prima persona come se il repository parlasse:

> *"Caro sviluppatore, ho notato che ogni venerdì sera alle 23:47 qualcosa si rompe. Non sono io. Sei tu. Parliamone."*

Il tono è ironico ma i dati sono reali. Ogni affermazione è linkabile al commit specifico.

---

## Stack tecnico consigliato

| Componente | Tecnologia |
|---|---|
| Parsing git log | Python + `gitpython` o raw `git log` parsing |
| Analisi NLP messaggi | `transformers` (modello leggero) o regex avanzate |
| Report HTML | Jinja2 template + Chart.js |
| CLI | `click` o `typer` |
| Output opzionale | JSON (per integrazione con altri tool) |

**Perché Python:** ecosistema NLP, facilità di parsing, ampia adozione nella community DevTools.

---

## Architettura del progetto

```
git-therapy/
├── git_therapy/
│   ├── __init__.py
│   ├── cli.py              # Entry point CLI
│   ├── parser/
│   │   ├── git_log.py      # Estrae e struttura i commit
│   │   └── diff_analyzer.py # Analizza le modifiche
│   ├── analyzers/
│   │   ├── rage.py         # Rage commit detection
│   │   ├── sleep.py        # Sleep deprivation index
│   │   ├── hero.py         # Hero detection
│   │   ├── flow.py         # Flow state analysis
│   │   └── personality.py  # Contributor profiles
│   ├── report/
│   │   ├── generator.py    # Assembla il report
│   │   ├── templates/      # Jinja2 HTML templates
│   │   └── assets/         # CSS, JS, Chart.js
│   └── therapy/
│       └── narrative.py    # Genera il testo "terapia"
├── tests/
├── README.md               # Con GIF demo — fondamentale
├── pyproject.toml
└── LICENSE
```

---

## CLI Interface

```bash
# Analisi base sul repo corrente
git-therapy

# Analisi su repo specifico
git-therapy --path /path/to/repo

# Solo un contributor
git-therapy --author "mario.rossi@email.com"

# Range temporale
git-therapy --since "2023-01-01" --until "2024-01-01"

# Output JSON invece di HTML
git-therapy --format json

# Apri il report nel browser automaticamente
git-therapy --open

# Salva il report
git-therapy --output report.html
```

---

## Output: il report HTML

Il report ha queste sezioni:

1. **Executive Summary** — 3 frasi che riassumono la "salute mentale" del repo
2. **The Timeline** — grafico interattivo con tutti gli eventi critici
3. **Contributor Profiles** — una card per ogni developer con il suo "tipo"
4. **Rage Hall of Fame** — i commit più esplosivi, citati letteralmente
5. **Hero Moments** — i momenti salvifici con chi li ha fatti
6. **Sleep Deprivation Report** — grafico a heatmap degli orari di commit
7. **The Therapy Session** — il testo narrativo del repository

---

## Roadmap (1 mese)

| Settimana | Focus |
|---|---|
| 1 | Parser git log + struttura dati + CLI base |
| 2 | Analyzers (rage, sleep, hero) + unit test |
| 3 | Report HTML + template + grafici |
| 4 | Personality profiles + narrative generator + README con GIF |

---

## Strategia di lancio

1. **README killer** — GIF da 30 secondi che mostra un repo famoso (es. Linux kernel) analizzato. Il report deve sembrare sorprendentemente accurato.
2. **Post su HackerNews** — titolo: *"I built a tool that psychoanalyzes your Git history"*
3. **Thread su Twitter/X** — mostra i risultati su repo open source famosi
4. **Reddit** — r/programming, r/git, r/devops

---

## Perché un recruiter dice WOW

- Dimostra **comprensione dei sistemi reali** (Git internals, pattern di sviluppo)
- Dimostra **capacità di trasformare dati grezzi in insight leggibili**
- Dimostra **attenzione alla UX** (il report deve essere bello, non solo funzionale)
- Dimostra **sense of humor** — una qualità rara e preziosa in un developer
- È un progetto **completo e rifinito**, non un toy project abbandonato
