# QuantJourney Admin SDK (Private)

Namespace package: `quantjourney.sdkadmin`

Usage
```python
from quantjourney.sdkadmin import QuantJourneyAdmin
qja = QuantJourneyAdmin(api_url="http://localhost:8001", token="<service-token>")
print(qja.admin.routers())
```

Install
- From private index: `pip install --extra-index-url https://<private-index> quantjourney-sdkadmin`
- From GitHub subdirectory: `pip install "git+https://github.com/<org>/_repo_qj_sdk.git#subdirectory=sdkadmin"`
