# Usage Guide

## Auth and Tokens
```python
from quantjourney.sdk import QuantJourney

qj = QuantJourney(api_url="http://localhost:8001")
qj.auth.login(email="alice", password="secret", tenant_id="jakub")
print(qj.health())
```

## Using connectors
```python
qj = QuantJourney(api_url="http://localhost:8001", tenant_id="jakub")
series = qj.fred.get_series(series_id="GDPC1", start_date="2010-01-01", end_date="2020-01-01")
```

## Domain proxy
```python
qj = QuantJourney(api_url="http://localhost:8001", tenant_id="jakub")
res = qj.equities.fundamentals.get_income_statement(symbol="AAPL")
```

## Env-based configuration
- `QJ_API`, `QJ_TENANT_ID`, `QJ_API_KEY`/`QJ_ACCESS_TOKEN`
- `QJ_USER_ID`, `QJ_PASSWORD` for password login
```python
from quantjourney.sdk import QuantJourney
qj = QuantJourney.from_env()
```
