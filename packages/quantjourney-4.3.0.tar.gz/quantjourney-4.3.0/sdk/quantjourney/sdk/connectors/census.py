from ..client import ConnectorEndpoint


class CENSUSEndpoint(ConnectorEndpoint):
    def get_population(self, **params):
        return self._call("get_population", **params)

    def get_income(self, **params):
        return self._call("get_income", **params)

    def get_housing(self, **params):
        return self._call("get_housing", **params)