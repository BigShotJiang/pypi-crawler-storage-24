from ..client import ConnectorEndpoint


class TREASURYEndpoint(ConnectorEndpoint):
    """SDK endpoints for Treasury connector."""

    def get_debt_to_penny(self, **params):
        return self._call("get_debt_to_penny", **params)

    def get_average_interest_rates(self, **params):
        return self._call("get_average_interest_rates", **params)

    def get_treasury_yield_curve(self, **params):
        return self._call("get_treasury_yield_curve", **params)

    def get_savings_bonds_rates(self, **params):
        return self._call("get_savings_bonds_rates", **params)

    def get_monthly_treasury_statement(self, **params):
        return self._call("get_monthly_treasury_statement", **params)

    def get_daily_treasury_statement(self, **params):
        return self._call("get_daily_treasury_statement", **params)