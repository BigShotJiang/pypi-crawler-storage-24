from ..client import ConnectorEndpoint


class USDAEndpoint(ConnectorEndpoint):
    def get_crop_prices(self, **params):
        return self._call("get_crop_prices", **params)