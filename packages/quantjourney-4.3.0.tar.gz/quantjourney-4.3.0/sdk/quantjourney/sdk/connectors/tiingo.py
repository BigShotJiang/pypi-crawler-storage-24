from ..client import ConnectorEndpoint


class TIINGOEndpoint(ConnectorEndpoint):
    def get_daily(self, **params):
        return self._call("get_daily", **params)

    def get_meta(self, **params):
        return self._call("get_meta", **params)

    def get_news(self, **params):
        return self._call("get_news", **params)