from ..client import ConnectorEndpoint


class ECBEndpoint(ConnectorEndpoint):
    def get_currency_reference_rates(self, **params):
        return self._call("get_currency_reference_rates", **params)

    def get_currency_rates_dataframe(self, **params):
        return self._call("get_currency_rates_dataframe", **params)

    def get_series_data(self, **params):
        return self._call("get_series_data", **params)

    def get_series_dataframe(self, **params):
        return self._call("get_series_dataframe", **params)

    def get_yield_curve_data(self, **params):
        return self._call("get_yield_curve_data", **params)

    def get_balance_of_payments_data(self, **params):
        return self._call("get_balance_of_payments_data", **params)

    def get_monetary_statistics(self, **params):
        return self._call("get_monetary_statistics", **params)

    def search_series(self, **params):
        return self._call("search_series", **params)
