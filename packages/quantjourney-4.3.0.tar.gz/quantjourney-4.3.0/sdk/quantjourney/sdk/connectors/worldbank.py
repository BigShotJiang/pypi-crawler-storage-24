from ..client import ConnectorEndpoint


class WORLDBANKEndpoint(ConnectorEndpoint):
    """SDK endpoints for World Bank connector."""

    def get_indicator(self, **params):
        return self._call("get_indicator", **params)