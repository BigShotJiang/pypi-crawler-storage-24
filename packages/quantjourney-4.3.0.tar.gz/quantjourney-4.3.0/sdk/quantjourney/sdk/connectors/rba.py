from ..client import ConnectorEndpoint


class RBAEndpoint(ConnectorEndpoint):
    """SDK endpoints for RBA connector."""

    def get_rates(self, **params):
        return self._call("get_rates", **params)