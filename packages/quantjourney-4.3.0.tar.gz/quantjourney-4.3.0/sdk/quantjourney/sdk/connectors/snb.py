from ..client import ConnectorEndpoint


class SNBEndpoint(ConnectorEndpoint):
    """SDK endpoints for SNB connector."""

    def get_rates(self, **params):
        return self._call("get_rates", **params)