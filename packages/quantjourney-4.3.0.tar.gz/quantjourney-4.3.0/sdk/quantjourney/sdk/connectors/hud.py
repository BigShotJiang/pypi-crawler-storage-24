from ..client import ConnectorEndpoint


class HUDEndpoint(ConnectorEndpoint):
    def get_fmr(self, **params):
        return self._call("get_fmr", **params)