from ..client import ConnectorEndpoint


class EIAEndpoint(ConnectorEndpoint):
    def get_petroleum_prices(self, **params):
        return self._call("get_petroleum_prices", **params)

    def get_natural_gas_prices(self, **params):
        return self._call("get_natural_gas_prices", **params)

    def get_petroleum_stocks(self, **params):
        return self._call("get_petroleum_stocks", **params)