from ..client import ConnectorEndpoint


class EUROSTATEndpoint(ConnectorEndpoint):
    """SDK endpoints for Eurostat connector."""

    def get_eu_data(self, **params):
        return self._call("get_eu_data", **params)