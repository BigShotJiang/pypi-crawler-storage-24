from ..client import ConnectorEndpoint


class FINNHUBEndpoint(ConnectorEndpoint):
    def get_quote(self, **params):
        return self._call("get_quote", **params)

    def get_company_profile(self, **params):
        return self._call("get_company_profile", **params)

    def get_market_news(self, **params):
        return self._call("get_market_news", **params)

    def get_company_news(self, **params):
        return self._call("get_company_news", **params)

    def get_social_sentiment(self, **params):
        return self._call("get_social_sentiment", **params)

    def get_insider_sentiment(self, **params):
        return self._call("get_insider_sentiment", **params)

    def search_symbol(self, **params):
        return self._call("search_symbol", **params)
