from ..client import ConnectorEndpoint


class COINGECKOEndpoint(ConnectorEndpoint):
    def get_price(self, **params):
        return self._call("get_price", **params)

    def get_historical_prices(self, **params):
        return self._call("get_historical_prices", **params)

    def get_market_data(self, **params):
        return self._call("get_market_data", **params)

    def get_global_data(self, **params):
        return self._call("get_global_data", **params)

    def get_trending_coins(self, **params):
        return self._call("get_trending_coins", **params)

    def get_coin_info(self, **params):
        return self._call("get_coin_info", **params)

    def get_exchanges(self, **params):
        return self._call("get_exchanges", **params)

    def search_coins(self, **params):
        return self._call("search_coins", **params)

    def get_supported_currencies(self, **params):
        return self._call("get_supported_currencies", **params)

    def get_popular_crypto_ids(self, **params):
        return self._call("get_popular_crypto_ids", **params)

    def get_multiple_coin_data(self, **params):
        return self._call("get_multiple_coin_data", **params)
