from ..client import ConnectorEndpoint


class BLSEndpoint(ConnectorEndpoint):
    """SDK endpoints for BLS connector."""

    def get_series_data(self, **params):
        return self._call("get_series_data", **params)

    def get_unemployment_rate(self, **params):
        return self._call("get_unemployment_rate", **params)

    def get_cpi(self, **params):
        return self._call("get_cpi", **params)

    def get_employment_data(self, **params):
        return self._call("get_employment_data", **params)

    def get_ppi(self, **params):
        return self._call("get_ppi", **params)