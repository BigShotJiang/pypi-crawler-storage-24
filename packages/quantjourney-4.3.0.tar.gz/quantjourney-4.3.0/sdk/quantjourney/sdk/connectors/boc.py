from ..client import ConnectorEndpoint


class BOCEndpoint(ConnectorEndpoint):
    """SDK endpoints for Bank of Canada connector."""

    def get_rates(self, **params):
        return self._call("get_rates", **params)