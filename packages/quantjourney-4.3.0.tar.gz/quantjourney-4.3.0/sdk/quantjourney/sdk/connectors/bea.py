from ..client import ConnectorEndpoint


class BEAEndpoint(ConnectorEndpoint):
    def get_gdp(self, **params):
        return self._call("get_gdp", **params)

    def get_personal_income(self, **params):
        return self._call("get_personal_income", **params)

    def get_nipa_table(self, **params):
        return self._call("get_nipa_table", **params)

    def get_trade_balance(self, **params):
        return self._call("get_trade_balance", **params)