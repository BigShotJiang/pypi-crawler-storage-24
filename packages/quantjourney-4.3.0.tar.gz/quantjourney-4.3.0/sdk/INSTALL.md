# Install (Public)

pip install quantjourney

From GitHub (main):
pip install "git+https://github.com/<org>/_repo_qj_sdk.git#subdirectory=$PUBLIC_SUBDIR"
