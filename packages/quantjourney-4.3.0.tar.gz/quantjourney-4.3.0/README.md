# quantjourney

Python SDK for [api.quantjourney.cloud](https://api.quantjourney.cloud) — financial data API.

Version `4.3.0` syncs the public SDK with the current live API surface and expands public connector coverage across macro, central-bank, government, and alternative data endpoints.

## Install

```bash
pip install quantjourney
```

## Quick Start

### With API key

```python
from quantjourney.sdk import QuantJourneyAPI

qj = QuantJourneyAPI(token="your-api-key")
prices = qj.fmp.get_historical_prices(symbol="AAPL")
```

### With email / password

```python
from quantjourney.sdk import QuantJourneyAPI

qj = QuantJourneyAPI()
qj.auth.login(email="you@example.com", password="...")
prices = qj.fmp.get_historical_prices(symbol="AAPL")
```

## User Portal

Manage your account at [users.quantjourney.cloud](https://users.quantjourney.cloud):

- **API Keys** — generate and manage API keys for SDK access
- **Data Sources** — add your own keys for premium connectors (FMP, EOD, Tiingo, …)
- **AI Models** — add your OpenAI / Anthropic / Google AI keys for Copilot

Free connectors (FRED, SEC, OECD, World Bank, …) work without additional configuration.

## Connector Coverage

The public SDK now exposes connector clients including:

- Market data: `fmp`, `eod`, `yf`, `tiingo`, `finnhub`, `coingecko`
- Macro / public data: `fred`, `bea`, `bls`, `census`, `eia`, `usda`, `worldbank`, `oecd`, `dbnomics`, `imf`
- Rates / central banks: `treasury`, `ecb`, `boc`, `rba`, `snb`, `eurostat`
- Regulatory / reference: `sec`, `openfigi`, `finra`, `cftc`, `multpl`

Connector availability still depends on your plan and configured provider secrets where applicable.

See [CHANGELOG.md](CHANGELOG.md) for release notes and [USAGE.md](USAGE.md) for additional examples.

## Migration from 1.x

```python
# Before (1.x):
from quantjourney_sdk import QuantJourneyAPI

# After (2.0):
from quantjourney.sdk import QuantJourneyAPI
```

## Links

- [API Documentation](https://docs.quantjourney.cloud)
- [Terms of Use](https://quantjourney.cloud/terms-of-usage)
- [Privacy Policy](https://quantjourney.cloud/privacy-policy)
