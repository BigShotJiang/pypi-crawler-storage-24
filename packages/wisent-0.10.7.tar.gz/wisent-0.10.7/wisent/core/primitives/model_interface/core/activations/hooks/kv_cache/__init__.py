"""KV cache activation collection."""
