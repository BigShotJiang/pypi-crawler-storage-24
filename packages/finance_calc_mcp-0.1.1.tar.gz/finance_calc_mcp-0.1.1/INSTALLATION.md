# finance-calc-mcp — Installation & Distribution Notes

## The Problem

The PyPI page currently instructs users to add this to their Claude Desktop config:

```json
{
  "mcpServers": {
    "finance-calculator": {
      "command": "uvx",
      "args": ["finance-calc-mcp"]
    }
  }
}
```

This fails for many users on macOS. Claude Desktop is a GUI app and does not launch
from a shell session, so it never sources the user's shell profile (~/.zshrc, ~/.bashrc,
etc.). As a result, it uses a minimal hardcoded system PATH:

  /usr/local/bin, /opt/homebrew/bin, /usr/bin, /bin, /usr/sbin, /sbin

The `uv` installer places `uvx` in `~/.local/bin`, which is NOT in that list. So Claude
Desktop simply cannot find `uvx`, and the server fails to spawn with:

  Failed to spawn process: No such file or directory

## The Fix

Use a login shell to invoke uvx, so it sources the user's profile and resolves uvx
from wherever it was installed:

```json
{
  "mcpServers": {
    "finance-calculator": {
      "command": "/bin/bash",
      "args": ["-lc", "uvx finance-calc-mcp"]
    }
  }
}
```

The `-l` flag runs bash as a login shell (sources ~/.bash_profile / ~/.profile, which
includes ~/.local/bin in PATH). The `-c` flag passes the command to execute. This works
regardless of the user's username or where uv was installed.

## Action Required

Update the Claude Desktop config snippet on the PyPI project page
(https://pypi.org/project/finance-calc-mcp/) and in the README to use the login shell
version above. The current `uvx`-direct version should be removed or replaced entirely.

## Prerequisites (unchanged)

Users still need `uv` installed before this works. The install command:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

After installing uv, users should restart their terminal (or open a new one) to confirm
`uvx` is available, then add the config above and restart Claude Desktop.

## Notes

- This is a macOS-specific issue with GUI app PATH inheritance. Linux desktop behavior
  may vary but the login shell approach is safe to use universally.
- The `-lc` workaround is a standard pattern for this class of problem and is used by
  other MCP servers distributed via PyPI/uvx.
- Windows users are unaffected (different shell model), but the config snippet should
  be tested and documented separately for that platform.
