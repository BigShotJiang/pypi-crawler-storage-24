"""Tests for Store — derived from sdd/specs/001-store-api.md (STORE sections)."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    from collections.abc import Iterator

from remote_store._capabilities import Capability
from remote_store._errors import AlreadyExists, CapabilityNotSupported, InvalidPath, NotFound
from remote_store._models import FileInfo, FolderInfo
from remote_store._path import RemotePath
from remote_store._store import Store
from remote_store.backends._local import LocalBackend
from remote_store.backends._memory import MemoryBackend


@pytest.fixture
def store() -> Iterator[Store]:
    backend = MemoryBackend()
    yield Store(backend=backend, root_path="data")


class TestStoreConstruction:
    """STORE-001: Construction."""

    @pytest.mark.spec("STORE-001")
    def test_construction(self) -> None:
        backend = MemoryBackend()
        store = Store(backend=backend, root_path="myroot")
        assert store is not None


class TestStorePathValidation:
    """STORE-002: Path validation."""

    @pytest.mark.spec("STORE-002")
    def test_invalid_path_rejected(self, store: Store) -> None:
        with pytest.raises(InvalidPath):
            store.read("../escape")

    @pytest.mark.spec("STORE-002")
    def test_empty_path_resolves_to_root(self, store: Store) -> None:
        store.write("file.txt", b"data")
        assert store.is_folder("")
        assert list(store.list_files("")) == list(store.list_files("", recursive=False))


class TestStoreRootPathScoping:
    """STORE-003: Root path scoping."""

    @pytest.mark.spec("STORE-003")
    def test_root_path_prepended(self, store: Store) -> None:
        store.write("hello.txt", b"hi")
        assert store.exists("hello.txt")
        assert store.read_bytes("hello.txt") == b"hi"


class TestStoreDelegation:
    """STORE-004: Delegation to backend."""

    @pytest.mark.spec("STORE-004")
    def test_write_and_read(self, store: Store) -> None:
        store.write("test.txt", b"content")
        assert store.read_bytes("test.txt") == b"content"

    @pytest.mark.spec("STORE-004")
    def test_read_stream(self, store: Store) -> None:
        store.write("stream.txt", b"stream data")
        stream = store.read("stream.txt")
        assert stream.read() == b"stream data"


class TestStoreCapabilities:
    """STORE-005: Capability check."""

    @pytest.mark.spec("STORE-005")
    def test_supports(self, store: Store) -> None:
        assert store.supports(Capability.READ) is True
        assert store.supports(Capability.WRITE) is True


class TestStoreFullAPI:
    """STORE-008: Full API surface."""

    @pytest.mark.spec("STORE-008")
    def test_exists(self, store: Store) -> None:
        assert store.exists("nope.txt") is False
        store.write("yes.txt", b"y")
        assert store.exists("yes.txt") is True

    @pytest.mark.spec("STORE-008")
    def test_is_file_is_folder(self, store: Store) -> None:
        store.write("dir/file.txt", b"x")
        assert store.is_file("dir/file.txt") is True
        assert store.is_folder("dir") is True

    @pytest.mark.spec("STORE-008")
    def test_write_overwrite(self, store: Store) -> None:
        store.write("ow.txt", b"a")
        with pytest.raises(AlreadyExists):
            store.write("ow.txt", b"b")
        store.write("ow.txt", b"b", overwrite=True)
        assert store.read_bytes("ow.txt") == b"b"

    @pytest.mark.spec("STORE-008")
    def test_write_atomic(self, store: Store) -> None:
        store.write_atomic("at.txt", b"atomic")
        assert store.read_bytes("at.txt") == b"atomic"

    @pytest.mark.spec("SAW-002")
    def test_open_atomic(self, store: Store) -> None:
        with store.open_atomic("oa.txt") as f:
            f.write(b"streaming")
        assert store.read_bytes("oa.txt") == b"streaming"

    @pytest.mark.spec("SAW-006")
    def test_open_atomic_overwrite(self, store: Store) -> None:
        store.write("oa_ow.txt", b"old")
        with store.open_atomic("oa_ow.txt", overwrite=True) as f:
            f.write(b"new")
        assert store.read_bytes("oa_ow.txt") == b"new"

    @pytest.mark.spec("STORE-008")
    def test_delete(self, store: Store) -> None:
        store.write("del.txt", b"x")
        store.delete("del.txt")
        assert store.exists("del.txt") is False

    @pytest.mark.spec("STORE-008")
    def test_delete_missing_ok(self, store: Store) -> None:
        store.delete("nonexistent.txt", missing_ok=True)

    @pytest.mark.spec("STORE-008")
    def test_delete_not_found(self, store: Store) -> None:
        with pytest.raises(NotFound):
            store.delete("nonexistent.txt")

    @pytest.mark.spec("STORE-008")
    def test_delete_folder(self, store: Store) -> None:
        store.write("folder/file.txt", b"x")
        store.delete_folder("folder", recursive=True)
        assert store.exists("folder") is False

    @pytest.mark.spec("STORE-008")
    def test_list_files(self, store: Store) -> None:
        store.write("lf/a.txt", b"a")
        store.write("lf/b.txt", b"b")
        files = list(store.list_files("lf"))
        assert len(files) == 2
        assert all(isinstance(f, FileInfo) for f in files)

    @pytest.mark.spec("STORE-008")
    def test_list_files_recursive(self, store: Store) -> None:
        store.write("lfr/a.txt", b"a")
        store.write("lfr/sub/b.txt", b"b")
        files = list(store.list_files("lfr", recursive=True))
        assert len(files) == 2

    @pytest.mark.spec("STORE-008")
    def test_list_folders(self, store: Store) -> None:
        store.write("lfd/sub1/a.txt", b"a")
        store.write("lfd/sub2/b.txt", b"b")
        folders = set(store.list_folders("lfd"))
        assert folders == {"sub1", "sub2"}

    @pytest.mark.spec("ITER-001")
    def test_iter_children(self, store: Store) -> None:
        store.write("ic/a.txt", b"a")
        store.write("ic/b.txt", b"b")
        store.write("ic/sub/c.txt", b"c")
        children = list(store.iter_children("ic"))
        files = [c for c in children if isinstance(c, FileInfo)]
        folders = [c for c in children if isinstance(c, str)]
        assert {f.name for f in files} == {"a.txt", "b.txt"}
        assert set(folders) == {"sub"}

    @pytest.mark.spec("ITER-001")
    def test_iter_children_empty_dir(self, store: Store) -> None:
        assert list(store.iter_children("nonexistent")) == []

    @pytest.mark.spec("ITER-001")
    def test_iter_children_root(self, store: Store) -> None:
        store.write("root.txt", b"r")
        store.write("sub/nested.txt", b"n")
        children = list(store.iter_children(""))
        files = [c for c in children if isinstance(c, FileInfo)]
        folders = [c for c in children if isinstance(c, str)]
        assert {f.name for f in files} == {"root.txt"}
        assert "sub" in folders

    @pytest.mark.spec("ITER-001")
    def test_iter_children_file_paths_are_store_relative(self, store: Store) -> None:
        store.write("ic2/f.txt", b"x")
        children = list(store.iter_children("ic2"))
        files = [c for c in children if isinstance(c, FileInfo)]
        assert len(files) == 1
        assert str(files[0].path) == "ic2/f.txt"
        # Round-trip: path should work as input
        assert store.read_bytes(str(files[0].path)) == b"x"

    @pytest.mark.spec("STORE-008")
    def test_get_file_info(self, store: Store) -> None:
        store.write("info.txt", b"hello")
        fi = store.get_file_info("info.txt")
        assert isinstance(fi, FileInfo)
        assert fi.size == 5

    @pytest.mark.spec("STORE-008")
    def test_get_folder_info(self, store: Store) -> None:
        store.write("fi/a.txt", b"aaa")
        fi = store.get_folder_info("fi")
        assert isinstance(fi, FolderInfo)
        assert fi.file_count == 1

    @pytest.mark.spec("STORE-008")
    def test_move(self, store: Store) -> None:
        store.write("mv_src.txt", b"data")
        store.move("mv_src.txt", "mv_dst.txt")
        assert store.exists("mv_src.txt") is False
        assert store.read_bytes("mv_dst.txt") == b"data"

    @pytest.mark.spec("STORE-008a")
    def test_move_same_path_is_noop(self, store: Store) -> None:
        store.write("same.txt", b"original")
        store.move("same.txt", "same.txt")
        assert store.read_bytes("same.txt") == b"original"

    @pytest.mark.spec("STORE-008a")
    def test_move_same_path_nonexistent_raises(self, store: Store) -> None:
        with pytest.raises(NotFound):
            store.move("ghost.txt", "ghost.txt")

    @pytest.mark.spec("STORE-008a")
    def test_move_same_path_folder_raises(self, store: Store) -> None:
        store.write("dir/file.txt", b"x")
        with pytest.raises(NotFound):
            store.move("dir", "dir")

    @pytest.mark.spec("STORE-008a")
    def test_copy_same_path_is_noop(self, store: Store) -> None:
        store.write("same.txt", b"original")
        store.copy("same.txt", "same.txt")
        assert store.read_bytes("same.txt") == b"original"

    @pytest.mark.spec("STORE-008a")
    def test_copy_same_path_nonexistent_raises(self, store: Store) -> None:
        with pytest.raises(NotFound):
            store.copy("ghost.txt", "ghost.txt")

    @pytest.mark.spec("STORE-008a")
    def test_copy_same_path_folder_raises(self, store: Store) -> None:
        store.write("dir/file.txt", b"x")
        with pytest.raises(NotFound):
            store.copy("dir", "dir")

    @pytest.mark.spec("STORE-008")
    def test_copy(self, store: Store) -> None:
        store.write("cp_src.txt", b"data")
        store.copy("cp_src.txt", "cp_dst.txt")
        assert store.read_bytes("cp_src.txt") == b"data"
        assert store.read_bytes("cp_dst.txt") == b"data"


class TestStoreRoundTrip:
    """NPR-001, NPR-014 through NPR-016: round-trip invariant."""

    @pytest.mark.spec("NPR-001")
    def test_list_files_returns_store_relative_paths(self, store: Store) -> None:
        store.write("reports/q1.csv", b"data")
        files = list(store.list_files("reports"))
        assert len(files) == 1
        assert str(files[0].path) == "reports/q1.csv"

    @pytest.mark.spec("NPR-001")
    def test_list_files_round_trip(self, store: Store) -> None:
        """FileInfo.path from listing is directly usable as Store method input."""
        store.write("rt/a.txt", b"aaa")
        store.write("rt/b.txt", b"bbb")
        for f in store.list_files("rt"):
            data = store.read_bytes(str(f.path))
            assert len(data) == 3

    @pytest.mark.spec("NPR-014")
    def test_list_files_no_root_prefix(self, store: Store) -> None:
        """FileInfo.path must NOT include the store's root_path."""
        store.write("file.txt", b"x")
        files = list(store.list_files(""))
        paths = {str(f.path) for f in files}
        # Must be "file.txt", not "data/file.txt"
        assert "file.txt" in paths
        assert not any(p.startswith("data/") for p in paths)

    @pytest.mark.spec("NPR-016")
    def test_round_trip_recursive(self, store: Store) -> None:
        store.write("a/b/c.txt", b"deep")
        for f in store.list_files("", recursive=True):
            assert store.read_bytes(str(f.path)) == b"deep"

    @pytest.mark.spec("NPR-014")
    def test_get_file_info_returns_store_relative(self, store: Store) -> None:
        store.write("info.txt", b"hello")
        fi = store.get_file_info("info.txt")
        assert str(fi.path) == "info.txt"
        # Round-trip: path should work as input
        assert store.read_bytes(str(fi.path)) == b"hello"

    @pytest.mark.spec("NPR-014")
    def test_get_folder_info_returns_store_relative(self, store: Store) -> None:
        store.write("fold/a.txt", b"a")
        fi = store.get_folder_info("fold")
        assert str(fi.path) == "fold"


class TestGetFolderInfoRoot:
    """BUG-001: get_folder_info('') must work for root folder."""

    def test_store_get_folder_info_empty_root(self) -> None:
        """Store with root_path='' should return root FolderInfo."""
        backend = MemoryBackend()
        s = Store(backend=backend, root_path="")
        s.write("a.txt", b"aaa")
        fi = s.get_folder_info("")
        assert isinstance(fi, FolderInfo)
        assert fi.file_count == 1
        assert fi.total_size == 3
        assert str(fi.path) == "."
        assert fi.path == RemotePath.ROOT
        assert fi.path is RemotePath.ROOT

    def test_store_get_folder_info_with_root(self, store: Store) -> None:
        """Store with root_path='data' — get_folder_info('') returns root."""
        store.write("r.txt", b"rr")
        fi = store.get_folder_info("")
        assert isinstance(fi, FolderInfo)
        assert fi.file_count == 1
        assert fi.total_size == 2
        assert str(fi.path) == "."
        assert fi.path == RemotePath.ROOT
        assert fi.path is RemotePath.ROOT

    def test_backend_get_folder_info_empty_string(self) -> None:
        """Backend.get_folder_info('') should not raise InvalidPath."""
        backend = MemoryBackend()
        backend.write("x.txt", b"x")
        fi = backend.get_folder_info("")
        assert isinstance(fi, FolderInfo)
        assert fi.file_count == 1
        assert str(fi.path) == "."
        assert fi.path is RemotePath.ROOT

    def test_root_path_round_trip_get_folder_info(self, store: Store) -> None:
        """str(get_folder_info('').path) round-trips as input to get_folder_info."""
        store.write("rt.txt", b"abc")
        fi = store.get_folder_info("")
        key = str(fi.path)  # "."
        fi2 = store.get_folder_info(key)
        assert fi2.file_count == fi.file_count
        assert fi2.path is RemotePath.ROOT

    def test_root_path_round_trip_list_files(self, store: Store) -> None:
        """str(get_folder_info('').path) round-trips as input to list_files."""
        store.write("rt.txt", b"abc")
        fi = store.get_folder_info("")
        key = str(fi.path)  # "."
        names = [str(f.path) for f in store.list_files(key)]
        assert "rt.txt" in names

    def test_local_backend_get_folder_info_empty_string(self, tmp_path: object) -> None:
        """LocalBackend.get_folder_info('') should not raise InvalidPath."""
        root = Path(str(tmp_path))
        (root / "f.txt").write_bytes(b"hello")
        backend = LocalBackend(root=str(root))
        fi = backend.get_folder_info("")
        assert isinstance(fi, FolderInfo)
        assert fi.file_count == 1
        assert fi.total_size == 5
        assert str(fi.path) == "."
        assert fi.path is RemotePath.ROOT


class TestStoreToKey:
    """NPR-010 through NPR-013: Store.to_key."""

    @pytest.mark.spec("NPR-010")
    def test_to_key_strips_root(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            real_tmp = str(Path(tmp).resolve())
            backend = LocalBackend(root=tmp)
            store = Store(backend=backend, root_path="data")
            native = f"{real_tmp}/data/reports/q1.csv"
            assert store.to_key(native) == "reports/q1.csv"

    @pytest.mark.spec("NPR-012")
    def test_to_key_no_root_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            real_tmp = str(Path(tmp).resolve())
            backend = LocalBackend(root=tmp)
            store = Store(backend=backend, root_path="")
            native = f"{real_tmp}/reports/q1.csv"
            assert store.to_key(native) == "reports/q1.csv"

    @pytest.mark.spec("NPR-013")
    def test_to_key_unrelated_path_raises(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            real_tmp = str(Path(tmp).resolve())
            backend = LocalBackend(root=tmp)
            store = Store(backend=backend, root_path="data")
            with pytest.raises(InvalidPath):
                store.to_key(f"{real_tmp}/other/file.txt")


class TestStoreUnwrap:
    """STORE-013: Store.unwrap() delegation."""

    @pytest.mark.spec("STORE-013")
    def test_unwrap_delegates_to_backend(self) -> None:
        backend = MemoryBackend()
        store = Store(backend=backend, root_path="data")
        with pytest.raises(CapabilityNotSupported):
            store.unwrap(dict)

    @pytest.mark.spec("STORE-013")
    def test_unwrap_child_delegates(self) -> None:
        backend = MemoryBackend()
        store = Store(backend=backend, root_path="data")
        child = store.child("sub")
        with pytest.raises(CapabilityNotSupported):
            child.unwrap(dict)


class TestStoreNativePath:
    """STORE-015: Store.native_path() composition."""

    @pytest.mark.spec("STORE-015")
    def test_native_path_identity_backend(self) -> None:
        """Default backend.native_path is identity; Store prepends root."""
        backend = MemoryBackend()
        store = Store(backend=backend, root_path="data")
        # MemoryBackend inherits identity native_path, so result = root/key
        assert store.native_path("file.txt") == "data/file.txt"

    @pytest.mark.spec("STORE-015")
    def test_native_path_no_root(self) -> None:
        backend = MemoryBackend()
        store = Store(backend=backend)
        assert store.native_path("file.txt") == "file.txt"

    @pytest.mark.spec("STORE-015")
    def test_native_path_child_store(self) -> None:
        backend = MemoryBackend()
        store = Store(backend=backend, root_path="data")
        child = store.child("sub")
        assert child.native_path("file.txt") == "data/sub/file.txt"

    @pytest.mark.spec("STORE-015")
    def test_native_path_root_key(self) -> None:
        backend = MemoryBackend()
        store = Store(backend=backend, root_path="data")
        assert store.native_path("") == "data"


class TestStoreReadText:
    """RTXT-001: read_text() convenience method."""

    @pytest.mark.spec("RTXT-001")
    def test_read_text_utf8_default(self, store: Store) -> None:
        store.write("greet.txt", b"Hello, world!")
        assert store.read_text("greet.txt") == "Hello, world!"

    @pytest.mark.spec("RTXT-001")
    def test_read_text_custom_encoding(self, store: Store) -> None:
        text = "caf\u00e9"
        store.write("latin.txt", text.encode("latin-1"))
        assert store.read_text("latin.txt", encoding="latin-1") == text

    @pytest.mark.spec("RTXT-001")
    def test_read_text_errors_strict(self, store: Store) -> None:
        store.write("bad.bin", b"\xff\xfe")
        with pytest.raises(UnicodeDecodeError):
            store.read_text("bad.bin")

    @pytest.mark.spec("RTXT-001")
    def test_read_text_errors_replace(self, store: Store) -> None:
        store.write("bad.bin", b"\xff\xfe")
        result = store.read_text("bad.bin", errors="replace")
        assert "\ufffd" in result

    @pytest.mark.spec("RTXT-001")
    def test_read_text_errors_ignore(self, store: Store) -> None:
        store.write("bad.bin", b"hello\xffworld")
        assert store.read_text("bad.bin", errors="ignore") == "helloworld"

    @pytest.mark.spec("RTXT-001")
    def test_read_text_not_found(self, store: Store) -> None:
        with pytest.raises(NotFound):
            store.read_text("missing.txt")

    @pytest.mark.spec("RTXT-001")
    def test_read_text_empty_path(self, store: Store) -> None:
        with pytest.raises(InvalidPath):
            store.read_text("")

    @pytest.mark.spec("RTXT-001")
    def test_read_text_dot_path(self, store: Store) -> None:
        with pytest.raises(InvalidPath):
            store.read_text(".")
