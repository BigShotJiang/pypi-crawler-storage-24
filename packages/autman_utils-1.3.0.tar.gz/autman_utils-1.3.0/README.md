# autman-utils

A single-file Python utility module for payment and QingLong environment operations.

## Features

- Generate QR code URLs
- Read runtime config from middleware bucket
- Manage QingLong environment variables
- Create and query MaPay orders
- Safe import fallback when `middleware` is unavailable

## Installation

```bash
pip install autman-utils
```

## Public API

```python
from autman_utils import (
    MaPayClient,
    QingLongClient,
    generate_qrcode_url,
    get_pay_config,
)
```

## Usage

### Import module

```python
import autman_utils
```

or

```python
from autman_utils import MaPayClient, QingLongClient, get_pay_config, generate_qrcode_url
```

### Generate QR code URL

```python
from autman_utils import generate_qrcode_url

url = generate_qrcode_url("https://example.com")
print(url)
```

Example output:

```text
https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https%3A//example.com
```

### Read payment config

`get_pay_config()` reads values from the middleware bucket `dd_sign_config` and returns a normalized dictionary.

```python
from autman_utils import get_pay_config

config = get_pay_config()
print(config)
```

Example output:

```python
{
    "ma_pay_switch": False,
    "qr_pay_switch": True,
    "zsm": "example text",
    "pay_types": {
        "alipay": "支付宝",
        "wxpay": "微信支付",
    },
}
```

### Use QingLong client

`QingLongClient` is used to create, update, enable, and delete QingLong environment variables.

#### Initialize client

```python
from autman_utils import QingLongClient

client = QingLongClient("JD_COOKIE")
print(client.is_configured())
```

If you want to customize the bucket name and config key:

```python
from autman_utils import QingLongClient

client = QingLongClient(
    "JD_COOKIE",
    config_bucket="MY_BUCKET",
    config_key="my_ql_config",
)
print(client.is_configured())
```

If you want to pass the QingLong config string directly:

```python
from autman_utils import QingLongClient

client = QingLongClient(
    "JD_COOKIE",
    "http://127.0.0.1:5700丨client_id丨client_secret",
)
print(client.is_configured())
```

#### Update or create an environment variable

```python
from autman_utils import QingLongClient

client = QingLongClient("JD_COOKIE")
ok = client.update_env(
    username="demo_user",
    env_value="pt_key=xxx;pt_pin=demo;",
    remark="demo_user",
)
print(ok)
```

#### Delete an environment variable

```python
from autman_utils import QingLongClient

client = QingLongClient("JD_COOKIE")
ok = client.delete_env("demo_user")
print(ok)
```

### Use MaPay client

`MaPayClient` can create orders and query payment status.

#### Initialize client

```python
from autman_utils import MaPayClient

client = MaPayClient()
print(client.is_configured())
```

If you want to pass config directly:

```python
from autman_utils import MaPayClient

client = MaPayClient(
    gateway="https://pay.example.com",
    pid="10001",
    key="your_key",
    notify_url="https://example.com/notify",
    return_url="https://example.com/return",
)
print(client.is_configured())
```

#### Create an order

```python
from autman_utils import MaPayClient

client = MaPayClient(
    gateway="https://pay.example.com",
    pid="10001",
    key="your_key",
)

result = client.create_order(
    amount=10.5,
    pay_type="alipay",
    out_trade_no="order_10001",
    subject="测试订单",
    param="custom_data",
)
print(result)
```

Example success output:

```python
{
    "trade_no": "202603160001",
    "pay_url": "https://pay.example.com/pay/202603160001",
    "raw": {...},
}
```

#### Query order status

```python
from autman_utils import MaPayClient

client = MaPayClient(
    gateway="https://pay.example.com",
    pid="10001",
    key="your_key",
)

result = client.check_order("order_10001")
print(result)
print(client.is_paid("order_10001"))
```

## Configuration

### Middleware buckets

This package reads runtime configuration from the host-provided `middleware.bucketGet` API.

#### Global config bucket

- Bucket name: `G_AUTMAN`
- Key used by `QingLongClient`: `ql_config`

Expected `ql_config` format:

```text
host丨client_id丨client_secret
```

Example:

```text
http://127.0.0.1:5700丨abcdef丨123456
```

#### Payment config bucket

- Bucket name: `dd_sign_config`
- Supported keys:
  - `ma_pay_switch`
  - `qr_pay_switch`
  - `zsm`
  - `pay_types`
  - `ma_pay_gateway`
  - `ma_pay_pid`
  - `ma_pay_key`
  - `ma_pay_notify_url`
  - `ma_pay_return_url`

Example `pay_types` value:

```text
alipay:支付宝,wxpay:微信支付,qqpay:QQ钱包
```

## Behavior notes

- If `middleware` is unavailable, the module still imports safely.
- Missing bucket values fall back to default empty strings or `False`-like results.
- `MaPayClient(...).is_configured()` returns `False` when required payment config is incomplete.
- `QingLongClient(...).is_configured()` returns `False` when QingLong host, client id, or client secret is missing.

## Quick smoke test

```python
import autman_utils

print(autman_utils.__version__)
print(autman_utils.generate_qrcode_url("https://example.com"))
print(autman_utils.MaPayClient(gateway="", pid="", key="").is_configured())
print(autman_utils.QingLongClient("JD_COOKIE", "").is_configured())
```

## License

MIT
