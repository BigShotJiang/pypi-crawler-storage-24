from fastapi import APIRouter
import sqlite3
from ...store.db import get_shared_connection

router = APIRouter(prefix="/api/evolution", tags=["evolution"])


def _conn() -> sqlite3.Connection:
    return get_shared_connection()


@router.get("/status")
def evolution_status():
    conn = _conn()
    row = conn.execute("SELECT phase, COUNT(*) as n FROM evolution GROUP BY phase ORDER BY n DESC LIMIT 1").fetchone()
    variants = conn.execute("SELECT COUNT(DISTINCT variant_id) as n FROM evolution").fetchone()
    promoted = conn.execute("SELECT COUNT(DISTINCT variant_id) as n FROM evolution WHERE promoted=1").fetchone()
    return {
        "current_phase": row["phase"] if row else "observing",
        "total_variants": variants["n"] or 0,
        "promoted": promoted["n"] or 0,
    }


@router.get("/variants")
def list_variants():
    conn = _conn()
    rows = conn.execute("""
        SELECT
            variant_id,
            MAX(phase) as phase,
            MAX(win_rate) as win_rate,
            MAX(samples) as samples,
            MAX(promoted) as promoted,
            MAX(ts) as ts
        FROM evolution
        GROUP BY variant_id
        ORDER BY win_rate DESC
    """).fetchall()
    return [dict(r) for r in rows]


@router.get("/compare")
def compare_variants():
    conn = _conn()
    rows = conn.execute("""
        SELECT
            variant_id,
            MAX(phase) as phase,
            MAX(win_rate) as win_rate,
            MAX(samples) as samples,
            MAX(promoted) as promoted,
            MAX(ts) as ts
        FROM evolution
        GROUP BY variant_id
        ORDER BY win_rate DESC
    """).fetchall()
    variants = [dict(r) for r in rows]
    winner = variants[0]["variant_id"] if variants else None
    return {
        "variants": variants,
        "winner": winner,
        "what_evolving": None,
    }
