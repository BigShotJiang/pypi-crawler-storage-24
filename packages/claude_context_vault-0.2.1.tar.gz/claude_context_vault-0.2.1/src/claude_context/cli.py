"""CLI for installing and uninstalling claude-context-vault with Claude Code."""

import json
import sys
from pathlib import Path


def do_install(claude_dir: Path | None = None) -> None:
    """Register claude-context-vault as an MCP server with Claude Code."""
    if claude_dir is None:
        claude_dir = Path.home() / ".claude"
    claude_dir.mkdir(parents=True, exist_ok=True)

    # Create vault directory
    vault_dir = claude_dir / "context-vault"
    vault_dir.mkdir(parents=True, exist_ok=True)

    # Update settings
    settings_file = claude_dir / "settings.json"
    if settings_file.exists():
        settings = json.loads(settings_file.read_text())
    else:
        settings = {}

    if "mcpServers" not in settings:
        settings["mcpServers"] = {}

    settings["mcpServers"]["claude-context-vault"] = {
        "command": sys.executable,
        "args": ["-m", "claude_context"],
    }

    settings_file.write_text(json.dumps(settings, indent=2))
    print(f"claude-context-vault installed successfully.")
    print(f"  MCP server registered in: {settings_file}")
    print(f"  Context vault directory: {vault_dir}")


def do_uninstall(claude_dir: Path | None = None) -> None:
    """Remove claude-context-vault MCP server registration from Claude Code."""
    if claude_dir is None:
        claude_dir = Path.home() / ".claude"

    settings_file = claude_dir / "settings.json"
    if not settings_file.exists():
        print("Nothing to uninstall — no Claude settings found.")
        return

    settings = json.loads(settings_file.read_text())
    servers = settings.get("mcpServers", {})
    if "claude-context-vault" in servers:
        del servers["claude-context-vault"]
        settings_file.write_text(json.dumps(settings, indent=2))
        print("claude-context-vault uninstalled successfully.")
    else:
        print("claude-context-vault was not installed.")


def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="claude-context-vault",
        description="Context vault extension for Claude Code",
    )
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("install", help="Register with Claude Code")
    subparsers.add_parser("uninstall", help="Remove from Claude Code")

    args = parser.parse_args()

    if args.command == "install":
        do_install()
    elif args.command == "uninstall":
        do_uninstall()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
