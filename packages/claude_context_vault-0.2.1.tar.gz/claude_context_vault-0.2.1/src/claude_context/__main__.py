"""Entry point for running claude-context-vault as an MCP server."""

from claude_context.server import mcp


def main():
    mcp.run()


if __name__ == "__main__":
    main()
