# claude-context-vault

Context vault extension for Claude Code. Prevents context loss during compaction by
archiving conversation context to a local vault with layered retrieval.

## The Problem

Claude Code builds context as you work. When context gets too large, it compacts —
and important details can be lost. You lose track of earlier decisions, code changes,
and discussions.

## The Solution

`claude-context-vault` archives old conversation context to a local vault before it gets
compacted. When you need that old context back, Claude retrieves just the relevant
parts — summaries for quick answers, full chunks for deep dives.

## Install

```bash
pip install claude-context-vault
claude-context-vault install
```

That's it. The install command registers the MCP server with Claude Code and creates
the vault directory at `~/.claude/context-vault/`.

## How It Works

Once installed, Claude Code gains 6 new tools:

| Tool | What it does |
|------|-------------|
| `check_context_health` | Estimates context size, reports green/yellow/red status |
| `archive_context` | Stores conversation context in the vault with a summary |
| `retrieve_context` | Searches archived context by keywords |
| `list_archived` | Shows all archived chunks for the current project |
| `get_chunk` | Pulls full content of a specific archived chunk |
| `delete_chunk` | Removes an archived chunk |

## Usage

Claude will use these tools during your session. When context grows large:

1. `check_context_health` reports yellow/red status
2. Claude archives older context with `archive_context`
3. After compaction, the important details are safe in the vault
4. When old context is needed, `retrieve_context` finds it by keywords
5. If the summary isn't enough, `get_chunk` pulls the full original

## Vault Location

All archived context is stored locally at `~/.claude/context-vault/`, organized by
project. Nothing is sent to any server.

## Uninstall

```bash
claude-context-vault uninstall
pip uninstall claude-context-vault
```

## License

MIT
