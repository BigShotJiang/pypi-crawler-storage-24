"""Tests for context health monitoring."""

import pytest

from claude_context.health import ContextHealth


@pytest.fixture
def health():
    return ContextHealth()


class TestTokenEstimation:
    def test_estimate_tokens_short_text(self, health):
        tokens = health.estimate_tokens("Hello world")
        assert tokens > 0
        assert tokens < 10

    def test_estimate_tokens_empty(self, health):
        tokens = health.estimate_tokens("")
        assert tokens == 0

    def test_estimate_tokens_long_text(self, health):
        text = "word " * 1000
        tokens = health.estimate_tokens(text)
        assert tokens > 500


class TestHealthCheck:
    def test_green_status(self, health):
        small_text = "Short context" * 10
        result = health.check(small_text)
        assert result["status"] == "green"

    def test_yellow_status(self, health):
        # ~80k tokens worth of text
        text = "word " * 60000
        result = health.check(text, max_tokens=100000)
        assert result["status"] == "yellow"

    def test_red_status(self, health):
        text = "word " * 80000
        result = health.check(text, max_tokens=100000)
        assert result["status"] == "red"

    def test_result_has_fields(self, health):
        result = health.check("Some text")
        assert "token_estimate" in result
        assert "status" in result
        assert "recommendation" in result
        assert "percentage" in result
