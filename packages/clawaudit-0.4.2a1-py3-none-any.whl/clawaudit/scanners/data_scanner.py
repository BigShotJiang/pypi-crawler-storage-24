"""PA-DATA* — Data security scanner."""

import os
import re
from pathlib import Path
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class DataScanner(BaseScanner):
    category = Category.DATA
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        all_checks = {
            "PA-DATA01": self._data01_api_keys,
            "PA-DATA02": self._data02_private_keys,
            "PA-DATA03": self._data03_log_leakage,
            "PA-DATA04": self._data04_exfil_chain,
        }
        return self._dispatch(all_checks, checks)

    # ------------------------------------------------------------------
    # PA-DATA01: API key plaintext exposure
    # ------------------------------------------------------------------
    def _data01_api_keys(self, needs):
        check_id = "PA-DATA01"
        title = "API keys exposed in plaintext"
        hits = []
        hit_details = []

        match = self._get_match(needs)
        patterns = match.get("patterns", [])
        compiled = [(re.compile(p), p) for p in patterns]

        for f in match.get("paths", []):
            if f.name == ".env":
                continue
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for regex, _ in compiled:
                if regex.search(text):
                    hits.append(f.name)
                    hit_details.append(str(f))
                    break

        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"API keys found in: {', '.join(hits)}",
                             remediation=needs.get("remediation", ""),
                             fix_actions=[
                                 FixAction(
                                     description="Remove plaintext API keys",
                                     fix_type="manual",
                                     manual_steps=(
                                         "Plaintext API keys found in:\n"
                                         + "".join(f"  - {d}\n" for d in hit_details)
                                         + "Remove or replace the plaintext keys, and rotate the exposed keys immediately."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA02: Private key / mnemonic plaintext
    # ------------------------------------------------------------------
    # BIP39 high-frequency words used to reduce mnemonic false positives
    _BIP39_MARKERS = {
        "abandon", "ability", "abstract", "abuse", "access", "accident",
        "account", "acid", "acoustic", "actual", "alpha", "antenna",
        "armor", "artwork", "auction", "banana", "basket", "bench",
        "biology", "bonus", "brave", "bronze", "bubble", "canal",
        "canvas", "carbon", "casino", "catalog", "celery", "census",
        "cherry", "cigar", "citizen", "claim", "clutch", "coconut",
        "column", "coral", "cotton", "crystal", "cushion", "debris",
        "decorate", "diesel", "dinosaur", "dolphin", "dragon", "elder",
        "elegant", "elevator", "embark", "engage", "envelope", "erosion",
        "estate", "evoke", "exotic", "fabric", "faculty", "flavor",
        "fossil", "galaxy", "garage", "ginger", "goddess", "gorilla",
        "harvest", "hedgehog", "hybrid", "ivory", "kangaroo", "ketchup",
        "kidney", "kitten", "laptop", "lawsuit", "leopard", "lyrics",
        "magnet", "mammal", "mandate", "meadow", "miracle", "mosquito",
        "muffin", "mushroom", "neglect", "nuclear", "noodle", "oasis",
        "obscure", "october", "olive", "opera", "orbit", "ostrich",
        "oxygen", "panda", "peasant", "pelican", "picnic", "pistol",
        "plunge", "polar", "pumpkin", "puzzle", "quantum", "raccoon",
        "ranch", "raven", "ribbon", "robust", "saddle", "salmon",
        "satoshi", "scatter", "seminar", "shrimp", "siege", "slender",
        "soccer", "spatial", "stereo", "stumble", "supreme", "tattoo",
        "tobacco", "tornado", "tuna", "turtle", "umbrella", "universe",
        "vacant", "valve", "vanish", "venture", "violin", "volcano",
        "voyage", "wasp", "wealth", "weapon", "whale", "whisper",
        "wrestle", "zebra", "zone",
    }

    def _data02_private_keys(self, needs):
        check_id = "PA-DATA02"
        title = "Private key or mnemonic in plaintext"

        bip39_threshold = needs.get("bip39_threshold", 3)

        # Build named pattern matchers from match entries
        pattern_map = {}  # name -> compiled regex
        all_files = []
        for m in needs.get("match", []):
            name = m.get("name", "")
            pats = m.get("patterns", [])
            if pats:
                pattern_map[name] = re.compile(pats[0])
            all_files.extend(m.get("paths", []))

        if not all_files:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS",
                             detail="No files to scan")
            return

        eth_pattern = pattern_map.get("eth")
        pem_pattern = pattern_map.get("pem")
        mnemonic_pattern = pattern_map.get("mnemonic")

        skip_exts = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".zip", ".gz", ".tar", ".bin"}
        hits = []
        hit_paths = []
        seen = set()

        for fpath in all_files:
            if not fpath.is_file() or fpath.suffix in skip_exts:
                continue
            if ".git" in fpath.parts:
                continue
            resolved = fpath.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            try:
                text = fpath.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue

            if (eth_pattern and eth_pattern.search(text)) or \
               (pem_pattern and pem_pattern.search(text)):
                hits.append(fpath.name)
                hit_paths.append(str(fpath))
                continue

            # Mnemonic: require match AND at least N BIP39 marker words
            if mnemonic_pattern:
                m = mnemonic_pattern.search(text)
                if m:
                    words = set(m.group(0).lower().split())
                    if len(words & self._BIP39_MARKERS) >= bip39_threshold:
                        hits.append(fpath.name)
                        hit_paths.append(str(fpath))

        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Sensitive material in: {', '.join(hits)}",
                             remediation=needs.get("remediation", ""),
                             fix_actions=[
                                 FixAction(
                                     description="Remove plaintext private keys/mnemonics",
                                     fix_type="manual",
                                     manual_steps=(
                                         "Private keys or mnemonics found in:\n"
                                         + "".join(f"  - {p}\n" for p in hit_paths)
                                         + "Remove or encrypt these files. If crypto wallet mnemonics were exposed, transfer assets to a new wallet immediately."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA03: Sensitive data in logs
    # ------------------------------------------------------------------
    def _data03_log_leakage(self, needs):
        check_id = "PA-DATA03"
        title = "Sensitive data logged in output"

        match = self._get_match(needs)
        patterns = match.get("patterns", [])
        source_files = match.get("paths", [])

        if not source_files:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="No source files to scan")
            return

        hits = []
        hit_paths = []

        for src in source_files:
            try:
                text = src.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pat in patterns:
                if re.search(pat, text, re.IGNORECASE):
                    hits.append(src.name)
                    hit_paths.append(str(src))
                    break

        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Logging sensitive data in: {', '.join(hits)}",
                             remediation=needs.get("remediation", ""),
                             fix_actions=[
                                 FixAction(
                                     description="Review sensitive data in log statements",
                                     fix_type="manual",
                                     manual_steps=(
                                         "Sensitive data may be logged in:\n"
                                         + "".join(f"  - {p}\n" for p in hit_paths)
                                         + "Review each file and redact sensitive values before logging."
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-DATA04: Data exfiltration chain
    # ------------------------------------------------------------------
    def _data04_exfil_chain(self, needs):
        check_id = "PA-DATA04"
        title = "Potential data exfiltration chain"

        read_match = self._get_match(needs, "read_patterns")
        net_match = self._get_match(needs, "net_patterns")
        read_patterns = read_match.get("patterns", [])
        net_patterns = net_match.get("patterns", [])
        source_files = read_match.get("paths", [])

        read_re = [re.compile(p, re.IGNORECASE) for p in read_patterns]
        net_re = [re.compile(p, re.IGNORECASE) for p in net_patterns]

        if not source_files:
            self.add_finding(check_id, title, Severity.HIGH, "PASS",
                             detail="No source files to scan")
            return

        overlap = []
        overlap_paths = []

        for src in source_files:
            try:
                text = src.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            has_read = any(p.search(text) for p in read_re)
            has_net = any(p.search(text) for p in net_re)
            if has_read and has_net:
                overlap.append(src.name)
                overlap_paths.append(str(src))

        if overlap:
            # Try to identify skill names
            skill_names = set()
            for p in overlap_paths:
                path = Path(p)
                for parent in path.parents:
                    if (parent / "SKILL.md").is_file():
                        skill_names.add(parent.name)
                        break

            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"File read + network request in: {', '.join(overlap)}",
                             remediation=needs.get("remediation", ""),
                             fix_actions=[
                                 FixAction(
                                     description="Review potential data exfiltration in skills",
                                     fix_type="manual",
                                     manual_steps=(
                                         "Files with both file read and network request:\n"
                                         + "".join(f"  - {p}\n" for p in overlap_paths)
                                         + ("Affected skill(s): " + ", ".join(sorted(skill_names)) + "\n"
                                            if skill_names else "")
                                         + "Review these files to confirm they are not exfiltrating sensitive data. "
                                         "Remove untrusted skills:\n"
                                         + ("".join(f"  rm -rf ~/.openclaw/skills/{s}\n" for s in sorted(skill_names))
                                            if skill_names else "")
                                     ),
                                 ),
                             ])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")
