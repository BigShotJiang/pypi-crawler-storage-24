"""PA-EXEC* — Execution & sandbox scanner."""

import os
import re
import subprocess
from pathlib import Path
from typing import List, Optional

from clawaudit.scanners.base import BaseScanner
from clawaudit.fixers.actions import FixAction
from clawaudit.models.finding import Finding
from clawaudit.models.severity import Severity, Category


class ExecScanner(BaseScanner):
    category = Category.EXEC
    mode = "local"

    def run(self, checks: Optional[List[str]] = None) -> List[Finding]:
        all_checks = {
            "PA-EXEC01": self._exec01_command_injection,
            "PA-EXEC02": self._exec02_sandbox,
            "PA-EXEC03": self._exec03_unsafe_exec,
            "PA-EXEC04": self._exec04_sql_injection,
            "PA-EXEC05": self._exec05_tool_output,
            "PA-EXEC06": self._exec06_prompt_injection,
            "PA-EXEC07": self._exec07_circuit_breaker,
            "PA-EXEC08": self._exec08_self_modify,
        }
        return self._dispatch(all_checks, checks)

    # ------------------------------------------------------------------
    # PA-EXEC01: Command injection
    # ------------------------------------------------------------------
    def _exec01_command_injection(self, needs):
        check_id = "PA-EXEC01"
        title = "Command injection via unsanitized input"
        match = self._get_match(needs)
        patterns = match.get("patterns", [])
        source_files = match.get("paths", [])
        hits = self._scan_source_patterns(patterns, source_files)
        remediation = needs.get("remediation", "")
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Potential injection in: {self._hit_names(hits)}",
                             remediation=remediation,
                             fix_actions=[self._build_skill_fix_action(hits, "Command injection risk")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC02: Sandbox not enabled
    # ------------------------------------------------------------------
    def _exec02_sandbox(self, needs):
        check_id = "PA-EXEC02"
        title = "Sandbox/container isolation not detected"

        match = self._get_match(needs)
        config_files = match.get("paths", [])

        # Check 1: OpenClaw sandbox config (agents.defaults.sandbox.mode)
        sandbox_mode = self._get_sandbox_mode(config_files)
        if sandbox_mode and sandbox_mode != "off":
            self.add_finding(check_id, title, Severity.WARNING, "PASS",
                             detail=f"OpenClaw sandbox mode: {sandbox_mode}")
            return

        # Check 2: System-level container/VM isolation
        isolation = self._detect_system_isolation()
        if isolation:
            self.add_finding(check_id, title, Severity.WARNING, "PASS",
                             detail=f"Running in isolated environment: {isolation}")
            return

        detail = "No sandbox or container isolation detected"
        if sandbox_mode == "off":
            detail += " (sandbox.mode is explicitly set to 'off')"

        remediation = needs.get("remediation", "") or "Enable OpenClaw sandbox or run in Docker/VM"
        self.add_finding(check_id, title, Severity.WARNING, "FAIL",
                         detail=detail,
                         remediation=remediation,
                         fix_actions=[
                             FixAction(
                                 description="Enable sandbox isolation",
                                 fix_type="manual",
                                 manual_steps=(
                                     'Enable sandbox in openclaw.json:\n'
                                     '  "agents": {"defaults": {"sandbox": {"mode": "non-main", "backend": "docker"}}}\n'
                                     'Use mode "all" to sandbox all sessions including the main one.'
                                 ),
                             ),
                         ])

    def _get_sandbox_mode(self, config_files=None):
        """Check OpenClaw config for sandbox mode setting."""
        if config_files is None:
            config_files = self.discovery.config_files
        for f in config_files:
            try:
                config = self.discovery.read_config(f)
            except Exception:
                continue
            mode = (config.get("agents", {})
                    .get("defaults", {})
                    .get("sandbox", {})
                    .get("mode"))
            if mode is not None:
                return mode
        return None

    def _detect_system_isolation(self):
        """Detect system-level container or VM isolation. Returns description or None."""
        import platform

        # macOS: check if running inside Docker Desktop VM or sandbox
        if platform.system() == "Darwin":
            if Path("/.dockerenv").exists():
                return "Docker (macOS)"
            try:
                result = subprocess.run(
                    ["sandbox-exec", "-n", "no-network", "true"],
                    capture_output=True, timeout=3,
                )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
            return None

        # Linux: check Docker/LXC/Podman/containerd/K8s
        if Path("/.dockerenv").exists():
            return "Docker"

        cgroup = Path("/proc/1/cgroup")
        if cgroup.is_file():
            try:
                text = cgroup.read_text().lower()
                for runtime in ("docker", "kubepods", "lxc", "containerd", "podman"):
                    if runtime in text:
                        return runtime.capitalize()
            except OSError:
                pass

        # Check VM via systemd-detect-virt
        try:
            result = subprocess.run(
                ["systemd-detect-virt"],
                capture_output=True, text=True, timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip() != "none":
                return f"VM ({result.stdout.strip()})"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        return None

    # ------------------------------------------------------------------
    # PA-EXEC03: Unsafe code execution (eval/exec/os.system)
    # ------------------------------------------------------------------
    def _exec03_unsafe_exec(self, needs):
        check_id = "PA-EXEC03"
        title = "Unsafe code execution (eval/exec/os.system)"
        match = self._get_match(needs)
        patterns = match.get("patterns", [])
        source_files = match.get("paths", [])
        hits = self._scan_source_patterns(patterns, source_files)
        remediation = needs.get("remediation", "")
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {self._hit_names(hits)}",
                             remediation=remediation,
                             fix_actions=[self._build_skill_fix_action(hits, "Unsafe code execution (eval/exec)")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC04: SQL injection
    # ------------------------------------------------------------------
    def _exec04_sql_injection(self, needs):
        check_id = "PA-EXEC04"
        title = "SQL injection via string interpolation"
        match = self._get_match(needs)
        patterns = match.get("patterns", [])
        source_files = match.get("paths", [])
        hits = self._scan_source_patterns(patterns, source_files)
        remediation = needs.get("remediation", "")
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {self._hit_names(hits)}",
                             remediation=remediation,
                             fix_actions=[self._build_skill_fix_action(hits, "SQL injection risk")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC05: Tool output injected into prompt
    # ------------------------------------------------------------------
    def _exec05_tool_output(self, needs):
        check_id = "PA-EXEC05"
        title = "Tool output directly injected into prompt"
        match = self._get_match(needs)
        patterns = match.get("patterns", [])
        source_files = match.get("paths", [])
        hits = self._scan_source_patterns(patterns, source_files)
        remediation = needs.get("remediation", "")
        if hits:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Found in: {self._hit_names(hits)}",
                             remediation=remediation,
                             fix_actions=[self._build_skill_fix_action(hits, "Tool output injection risk")])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC06: System prompt injection
    # ------------------------------------------------------------------
    def _exec06_prompt_injection(self, needs):
        check_id = "PA-EXEC06"
        title = "System prompt injection: user input in SystemMessage"
        # Collect patterns and paths from all match entries
        all_patterns = []
        all_files = []
        for m in needs.get("match", []):
            all_patterns.extend(m.get("patterns", []))
            all_files.extend(m.get("paths", []))
        hits = self._scan_source_patterns(all_patterns, all_files)
        remediation = needs.get("remediation", "")
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Found in: {self._hit_names(hits)}",
                             remediation=remediation,
                             fix_actions=[self._build_skill_fix_action(hits, "System prompt injection risk")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC07: No circuit breaker / max iterations
    # ------------------------------------------------------------------
    def _exec07_circuit_breaker(self, needs):
        check_id = "PA-EXEC07"
        title = "Missing circuit breaker / max iteration limit"

        loops_match = self._get_match(needs, "loops")
        guards_match = self._get_match(needs, "guards")
        loop_patterns = loops_match.get("patterns", [])
        guard_patterns = guards_match.get("patterns", [])
        source_files = loops_match.get("paths", [])

        # Check per-file: loop without guard in the same file is a risk
        unguarded = []
        guard_re = [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in guard_patterns]
        loop_re = [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in loop_patterns]

        for src in source_files:
            try:
                text = src.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            has_loop = any(p.search(text) for p in loop_re)
            if not has_loop:
                continue
            has_guard = any(p.search(text) for p in guard_re)
            if not has_guard:
                unguarded.append(src)

        remediation = needs.get("remediation", "")
        if unguarded:
            self.add_finding(check_id, title, Severity.HIGH, "FAIL",
                             detail=f"Found in: {self._hit_names(unguarded)}",
                             remediation=remediation,
                             fix_actions=[self._build_skill_fix_action(unguarded, "Missing circuit breaker")])
        else:
            self.add_finding(check_id, title, Severity.HIGH, "PASS")

    # ------------------------------------------------------------------
    # PA-EXEC08: Plugin code self-modification
    # ------------------------------------------------------------------
    def _exec08_self_modify(self, needs):
        check_id = "PA-EXEC08"
        title = "Plugin code self-modification risk"
        match = self._get_match(needs)
        patterns = match.get("patterns", [])
        source_files = match.get("paths", [])
        hits = self._scan_source_patterns(patterns, source_files)
        remediation = needs.get("remediation", "")
        if hits:
            self.add_finding(check_id, title, Severity.CRITICAL, "FAIL",
                             detail=f"Self-modification risk in: {self._hit_names(hits)}",
                             remediation=remediation,
                             fix_actions=[self._build_skill_fix_action(hits, "Code self-modification risk")])
        else:
            self.add_finding(check_id, title, Severity.CRITICAL, "PASS")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _scan_source_patterns(self, patterns: List[str], source_files=None) -> List[Path]:
        """Scan source files for regex patterns, return list of Paths with hits."""
        if source_files is None:
            source_files = []
        hits = []
        for src in source_files:
            try:
                text = src.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for pat in patterns:
                if re.search(pat, text, re.IGNORECASE | re.MULTILINE):
                    hits.append(src)
                    break
        return hits

    def _hit_names(self, hits: List[Path]) -> str:
        """Format hit paths as comma-separated file names for display."""
        return ", ".join(h.name for h in hits)

    def _build_skill_fix_action(self, hits: List[Path], issue: str) -> FixAction:
        """Build a manual FixAction that identifies affected skills and suggests removal."""
        skill_dirs = set()
        for h in hits:
            for parent in h.parents:
                if (parent / "SKILL.md").is_file():
                    skill_dirs.add(parent.name)
                    break

        if skill_dirs:
            skill_list = ", ".join(sorted(skill_dirs))
            steps = (
                f"{issue} in skill(s): {skill_list}\n"
                f"Affected files: {self._hit_names(hits)}\n"
                f"Step 1: Review the skill code to confirm the risk.\n"
                f"Step 2: Remove dangerous skill(s):\n"
                + "".join(f"  rm -rf ~/.openclaw/skills/{s}  # or ~/.openclaw/workspace/skills/{s}\n"
                          for s in sorted(skill_dirs))
                + "Step 3: If the skill is from ClawHub, report it as malicious."
            )
        else:
            steps = (
                f"{issue} in: {self._hit_names(hits)}\n"
                f"Step 1: Review the source files to confirm the risk.\n"
                f"Step 2: Remove or fix the affected files.\n"
                f"Step 3: If the code is from a third-party source, consider removing it entirely."
            )

        return FixAction(
            description=f"Remove skill(s) with {issue.lower()}",
            fix_type="manual",
            manual_steps=steps,
        )
