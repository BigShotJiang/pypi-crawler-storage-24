# Hello Package

A simple Python package that prints Hello World.