def say_hello(name: str = "World"):
    return f"Hello, {name}!"