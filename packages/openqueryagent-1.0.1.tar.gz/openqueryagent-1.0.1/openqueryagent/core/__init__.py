"""Core engine components."""
