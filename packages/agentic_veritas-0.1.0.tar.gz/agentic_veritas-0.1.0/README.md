# AgenticVeritas Python SDK

Truth engine for AI agents -- intent compilation and claim verification.

## Install

```bash
pip install agentic-veritas
```

## Usage

```python
from agentic_veritas import VeritasEngine

ve = VeritasEngine("project.veritas")
ve.compile_intent("Deploy to production", context="release-v2")
ve.check_claim("All tests pass", evidence="CI output")
```

Requires the `veritas` CLI binary on PATH. Install via:

```bash
curl -fsSL https://agentralabs.tech/install/veritas | bash
```
