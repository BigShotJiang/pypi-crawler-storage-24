"""AgenticVeritas — Truth engine for AI agents.

Pure-Python SDK that wraps the ``veritas`` CLI binary via subprocess.
Zero required dependencies; only stdlib: subprocess, json, pathlib, dataclasses.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

__version__ = "0.1.0"

logger = logging.getLogger(__name__)


class VeritasError(Exception):
    """Raised when a veritas CLI command fails."""


@dataclass
class VeritasEngine:
    """Interface to a ``.veritas`` truth engine file.

    Parameters
    ----------
    path : str | Path
        Path to the ``.veritas`` file. Created automatically on first write
        if it does not exist.
    binary : str
        Name or path of the ``veritas`` CLI binary.
    """

    path: str | Path
    binary: str = "veritas"
    _resolved_binary: Optional[str] = field(default=None, repr=False, init=False)

    def __post_init__(self) -> None:
        self.path = Path(self.path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_binary(self) -> str:
        if self._resolved_binary is not None:
            return self._resolved_binary

        import shutil

        found = shutil.which(self.binary)
        if found is None:
            raise VeritasError(
                f"Cannot find '{self.binary}' on PATH. "
                "Install AgenticVeritas: curl -fsSL https://agentralabs.tech/install/veritas | bash"
            )
        self._resolved_binary = found
        return found

    def _run(self, *args: str, check: bool = True) -> str:
        """Execute a veritas CLI command and return stdout."""
        cmd = [self._find_binary(), "--file", str(self.path), *args]
        logger.debug("Running: %s", " ".join(cmd))
        result = subprocess.run(cmd, capture_output=True, text=True)
        if check and result.returncode != 0:
            raise VeritasError(
                f"veritas command failed (exit {result.returncode}): {result.stderr.strip()}"
            )
        return result.stdout.strip()

    def _run_json(self, *args: str) -> Any:
        """Execute a command and parse JSON output."""
        raw = self._run(*args, "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # Intent operations
    # ------------------------------------------------------------------

    def compile_intent(
        self,
        intent: str,
        *,
        context: Optional[str] = None,
    ) -> str:
        """Compile an intent statement. Returns compiled intent ID."""
        args = ["intent", "compile", intent]
        if context:
            args.extend(["--context", context])
        return self._run(*args)

    def check_claim(
        self,
        claim: str,
        *,
        evidence: Optional[str] = None,
    ) -> str:
        """Check a claim against known truths. Returns verification result."""
        args = ["claim", "check", claim]
        if evidence:
            args.extend(["--evidence", evidence])
        return self._run(*args)

    def list_intents(self) -> list[dict[str, Any]]:
        """List all compiled intents."""
        raw = self._run("intent", "list", "--format", "json")
        return json.loads(raw) if raw else []

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Get veritas engine statistics."""
        raw = self._run("stats", "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Explicit save (most operations auto-save)."""
        pass

    @property
    def exists(self) -> bool:
        """Whether the .veritas file exists on disk."""
        return self.path.exists()
