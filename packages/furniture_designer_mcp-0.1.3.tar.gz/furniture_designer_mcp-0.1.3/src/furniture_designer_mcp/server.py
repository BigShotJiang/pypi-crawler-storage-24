from __future__ import annotations

import json
import logging

from mcp.server.fastmcp import FastMCP, Context
from mcp.types import TextContent

from .knowledge.ergonomics import ERGONOMIC_STANDARDS
from .knowledge.materials import MATERIALS
from .knowledge.structural_rules import STRUCTURAL_RULES
from .knowledge.hardware import HARDWARE_CATALOG
from .knowledge.assembly_specs import ASSEMBLY_SPECS
from .knowledge.brief_formatters import (
    brief_standards,
    brief_material,
    brief_structural_rules,
    brief_hardware,
    brief_hardware_category,
    brief_assembly_specs,
)
from .engine.designer import generate_furniture_spec
from .engine.cut_optimizer import optimize_cuts as _optimize_cuts
from .engine.structural_validator import validate_structure as _validate
from .engine.bom_generator import generate_bom as _generate_bom
from .engine.spec_validator import validate_spec, validate_cut_parts
from .engine.freecad_scripts import (
    spec_to_freecad_script,
    exploded_view_script,
    cut_layout_script,
    techdraw_script as _techdraw_script,
    import_script as _import_script,
    parse_freecad_export as _parse_export,
)
from .engine.freecad_client import get_client as _get_freecad_client
from .engine.report_generator import generate_design_report as _generate_report
from .engine.spec_builder import build_spec_from_layout as _build_spec
from .engine.section_mapper import map_sections as _map_sections, resolve_reference as _resolve_section

logger = logging.getLogger(__name__)


def _spec_error_response(spec: dict) -> list[TextContent] | None:
    """Validate spec and return error response if invalid, None if valid."""
    errors = validate_spec(spec)
    if errors:
        text = "Spec inválido:\n" + "\n".join(f"  - {e}" for e in errors)
        return [TextContent(type="text", text=text)]
    return None


def _auto_convert_cut_parts(parts: list[dict]) -> list[str]:
    """Auto-convert spec-style fields (width_mm→width, height_mm→height) in-place.

    Returns a list of warning strings for each conversion performed.
    """
    warnings = []
    conversions = [("width_mm", "width"), ("height_mm", "height"), ("thickness_mm", "thickness")]
    for part in parts:
        for spec_field, cut_field in conversions:
            if spec_field in part and cut_field not in part:
                part[cut_field] = part.pop(spec_field)
                pid = part.get("id", "?")
                warnings.append(
                    f"Auto-converted '{spec_field}'→'{cut_field}' in part '{pid}'."
                )
    return warnings


def _cut_parts_error_response(parts: list[dict]) -> tuple[list[TextContent] | None, list[str]]:
    """Validate cut parts and return (error_response, warnings).

    Auto-converts spec-style fields before validation.
    Returns (None, warnings) if valid, (error_response, []) if invalid.
    """
    convert_warnings = _auto_convert_cut_parts(parts)
    errors = validate_cut_parts(parts)
    if errors:
        text = "Parts inválidos para optimize_cuts:\n" + "\n".join(f"  - {e}" for e in errors)
        return [TextContent(type="text", text=text)], []
    return None, convert_warnings


def _execute_in_freecad(code: str, description: str) -> list[TextContent]:
    """Execute a generated script in FreeCAD via XML-RPC and return a summary."""
    client = _get_freecad_client()
    result = client.execute_code(code)
    if result.get("success"):
        msg = result.get("message", "")
        # Extract the print() output from the message
        output = ""
        if "Output:" in msg:
            output = msg.split("Output:", 1)[1].strip()
        elif msg:
            output = msg.strip()
        summary = f"{description}\n{output}" if output else description
        return [TextContent(type="text", text=summary)]
    else:
        error = result.get("error", "Error desconocido")
        return [TextContent(
            type="text",
            text=f"Error ejecutando en FreeCAD: {error}",
        )]


def _compact_spec_summary(spec: dict) -> str:
    """Compact summary of a furniture spec."""
    dims = spec.get("dimensions_cm", {})
    parts = spec.get("parts", [])
    hw = spec.get("hardware", [])
    notes = spec.get("notes", [])

    # Count parts by role
    from collections import Counter
    roles = Counter(p.get("role", "?") for p in parts)
    role_str = ", ".join(f"{v}× {k}" for k, v in roles.most_common())

    lines = [
        f"Diseño: {spec.get('furniture_type', '?')} "
        f"{dims.get('width', '?')}×{dims.get('height', '?')}×{dims.get('depth', '?')}cm "
        f"({spec.get('material', '?')})",
        f"Partes: {len(parts)} ({role_str})",
        f"Hardware: {len(hw)} items",
    ]
    if notes:
        lines.append("Notas: " + " | ".join(notes))
    return "\n".join(lines)


def _compact_cut_summary(result: dict) -> str:
    """Compact summary of cut optimization."""
    lines = [
        f"Corte optimizado: {result.get('sheets_needed', '?')} tableros, "
        f"{result.get('waste_percentage', '?')}% desperdicio, "
        f"{result.get('total_pieces', '?')} piezas",
    ]
    warnings = result.get("warnings", [])
    if warnings:
        lines.append("Avisos:")
        for w in warnings:
            lines.append(f"  ⚠ {w}")
    # Include text diagrams (already compact)
    for diag in result.get("text_diagrams", []):
        lines.append(diag)
    return "\n".join(lines)


def _compact_bom_summary(bom: dict) -> str:
    """Compact summary of BOM."""
    s = bom.get("summary", {})
    lines = [
        f"BOM: {s.get('total_pieces', '?')} piezas "
        f"({s.get('total_structural_panels', '?')} estructurales + "
        f"{s.get('total_back_panels', '?')} respaldos/fondos)",
        f"Material: {s.get('structural_material', '?')} ({s.get('structural_thickness_mm', '?')}mm)",
        f"Canteado: {s.get('edge_banding_total_meters', 0)}m total",
        f"Hardware: {s.get('hardware_items', '?')} items",
    ]
    return "\n".join(lines)


def _compact_assembly_summary(result: dict) -> str:
    """Compact summary of assembly steps."""
    steps = result.get("steps", [])
    lines = [f"Ensamble: {len(steps)} pasos"]
    for step in steps:
        lines.append(f"  {step['step']}. {step['action']}")
    tips = result.get("general_tips", [])
    if tips:
        lines.append("Tips generales:")
        for tip in tips:
            lines.append(f"  • {tip}")
    return "\n".join(lines)


mcp = FastMCP(
    "FurnitureDesignerMCP",
    instructions=(
        "Professional furniture design server. Provides ergonomic standards, "
        "structural validation, cut optimization (2D bin packing), BOM generation, "
        "and assembly instructions for cabinet-making."
    ),
)


# ---------------------------------------------------------------------------
# Knowledge tools
# ---------------------------------------------------------------------------


@mcp.tool()
def get_standards(ctx: Context, furniture_type: str, brief: bool = False) -> list[TextContent]:
    """Get ergonomic standards for a furniture type.

    Args:
        furniture_type: One of: kitchen_base, kitchen_wall, closet, bookshelf,
            desk, vanity, general
        brief: If true, return a compact summary instead of full JSON (saves tokens).

    Returns:
        Ergonomic standards (heights, depths, clearances) for the given type.
    """
    standards = ERGONOMIC_STANDARDS.get(furniture_type)
    if standards is None:
        available = ", ".join(ERGONOMIC_STANDARDS.keys())
        return [TextContent(type="text", text=f"Unknown type '{furniture_type}'. Available: {available}")]
    if brief:
        return [TextContent(type="text", text=brief_standards(standards))]
    return [TextContent(type="text", text=json.dumps(standards, indent=2, ensure_ascii=False))]


@mcp.tool()
def get_material_specs(ctx: Context, material: str, brief: bool = False) -> list[TextContent]:
    """Get technical specifications for a material.

    Args:
        material: One of: mdf_15, mdf_18, melamine_16, melamine_18, plywood_18,
            solid_pine_20
        brief: If true, return a compact summary instead of full JSON (saves tokens).

    Returns:
        Material properties: max unsupported span, available thicknesses,
        standard sheet sizes, edge banding options.
    """
    specs = MATERIALS.get(material)
    if specs is None:
        available = ", ".join(MATERIALS.keys())
        return [TextContent(type="text", text=f"Unknown material '{material}'. Available: {available}")]
    if brief:
        return [TextContent(type="text", text=brief_material(specs))]
    return [TextContent(type="text", text=json.dumps(specs, indent=2, ensure_ascii=False))]


@mcp.tool()
def get_structural_rules(ctx: Context, brief: bool = False) -> list[TextContent]:
    """Get all structural rules for furniture design.

    Args:
        brief: If true, return a compact summary instead of full JSON (saves tokens).

    Returns:
        List of rules covering reinforcement, back panels, kick plates, shelf
        supports, vertical dividers, and load-bearing requirements.
    """
    if brief:
        return [TextContent(type="text", text=brief_structural_rules(STRUCTURAL_RULES))]
    return [TextContent(type="text", text=json.dumps(STRUCTURAL_RULES, indent=2, ensure_ascii=False))]


@mcp.tool()
def get_hardware_catalog(ctx: Context, category: str | None = None, brief: bool = False) -> list[TextContent]:
    """Get hardware catalog with selection rules.

    Args:
        category: Optional filter — one of: hinges, slides, connectors, shelf_pins.
            If omitted, returns the full catalog.
        brief: If true, return a compact summary instead of full JSON (saves tokens).

    Returns:
        Hardware specifications with placement rules and quantities.
    """
    if category is not None:
        data = HARDWARE_CATALOG.get(category)
        if data is None:
            available = ", ".join(HARDWARE_CATALOG.keys())
            return [TextContent(type="text", text=f"Unknown category '{category}'. Available: {available}")]
        if brief:
            return [TextContent(type="text", text=brief_hardware_category(data))]
    else:
        data = HARDWARE_CATALOG
        if brief:
            return [TextContent(type="text", text=brief_hardware(data))]
    return [TextContent(type="text", text=json.dumps(data, indent=2, ensure_ascii=False))]


@mcp.tool()
def get_assembly_specs(ctx: Context, topic: str | None = None, brief: bool = False) -> list[TextContent]:
    """Get detailed assembly specifications for furniture construction.

    Covers joint methods, fastener patterns, adhesive usage, pre-drilling
    depths, hinge mounting, drawer slide installation, and shelf pin systems.

    Args:
        topic: Optional filter — one of: panel_to_panel, back_panel,
            hinge_mounting, drawer_slide_mounting, shelf_pins, adhesive_guide,
            pre_drilling. If omitted, returns all topics.
        brief: If true, return a compact summary instead of full JSON (saves tokens).

    Returns:
        Assembly specifications with step-by-step processes, fastener types,
        and material-specific parameters.
    """
    if topic is not None:
        data = ASSEMBLY_SPECS.get(topic)
        if data is None:
            available = ", ".join(ASSEMBLY_SPECS.keys())
            return [TextContent(type="text", text=f"Unknown topic '{topic}'. Available: {available}")]
        if brief:
            return [TextContent(type="text", text=brief_assembly_specs(data))]
        return [TextContent(type="text", text=json.dumps(data, indent=2, ensure_ascii=False))]
    else:
        if brief:
            sections = [brief_assembly_specs(v) for v in ASSEMBLY_SPECS.values()]
            return [TextContent(type="text", text="\n\n".join(sections))]
        return [TextContent(type="text", text=json.dumps(ASSEMBLY_SPECS, indent=2, ensure_ascii=False))]


# ---------------------------------------------------------------------------
# Design tools
# ---------------------------------------------------------------------------


@mcp.tool()
def design_furniture(
    ctx: Context,
    furniture_type: str,
    width: float,
    height: float,
    depth: float,
    material: str = "melamine_16",
    options: dict | None = None,
    compact: bool = True,
) -> list[TextContent]:
    """Design a complete furniture piece with standards applied.

    Generates a full specification including all panels, reinforcements,
    hardware, and assembly order based on ergonomic standards and structural
    rules.

    Args:
        furniture_type: One of: kitchen_base, kitchen_wall, closet, bookshelf,
            desk, vanity
        width: Total width in cm
        height: Total height in cm
        depth: Total depth in cm
        material: Material key (default: melamine_16)
        options: Optional overrides — e.g. {"num_shelves": 3, "has_drawers": true,
            "door_type": "double", "kickplate_height": 10,
            "back_type": "full"|"rails"|"none",
            "sections": [{"content": "hanging"}, {"content": "drawers+hanging", "num_drawers": 3}, {"content": "shelves", "num_shelves": 6}]}
            Section content types: "shelves", "drawers", "hanging", "drawers+hanging", "drawers+shelves", "empty"
        compact: If true (default), return a compact summary + full JSON.
            If false, return only the full pretty-printed JSON.

    Returns:
        Complete furniture spec (JSON) with parts list, positions, hardware,
        and structural notes.
    """
    try:
        spec = generate_furniture_spec(
            furniture_type=furniture_type,
            width=width,
            height=height,
            depth=depth,
            material=material,
            options=options or {},
        )
        if compact:
            summary = _compact_spec_summary(spec)
            return [
                TextContent(type="text", text=summary),
                TextContent(type="text", text=json.dumps(spec, ensure_ascii=False)),
            ]
        return [TextContent(type="text", text=json.dumps(spec, indent=2, ensure_ascii=False))]
    except Exception as e:
        logger.exception("design_furniture failed")
        return [TextContent(type="text", text=f"Error designing furniture: {e}")]


# ---------------------------------------------------------------------------
# Validation tools
# ---------------------------------------------------------------------------


@mcp.tool()
def validate_structure(ctx: Context, spec: dict) -> list[TextContent]:
    """Validate a furniture spec against structural rules.

    Checks unsupported spans, required reinforcements, hardware quantities,
    back panel presence, and stability.

    Args:
        spec: A furniture spec as returned by design_furniture.

    Returns:
        Validation report with errors (must fix) and warnings (recommended).
    """
    if err := _spec_error_response(spec):
        return err
    try:
        report = _validate(spec)
        return [TextContent(type="text", text=json.dumps(report, indent=2, ensure_ascii=False))]
    except Exception as e:
        logger.exception("validate_structure failed")
        return [TextContent(type="text", text=f"Error validating: {e}")]


# ---------------------------------------------------------------------------
# Cut optimization tools
# ---------------------------------------------------------------------------


@mcp.tool()
def optimize_cuts(
    ctx: Context,
    parts: list[dict],
    sheet_width: float = 2440,
    sheet_height: float = 1220,
    blade_kerf: float = 3,
    grain_direction: str = "auto",
    compact: bool = True,
) -> list[TextContent]:
    """Optimize panel cuts on standard sheets using guillotine algorithm.

    Args:
        parts: List of parts — each: {"id": "side_left", "width": 580,
            "height": 750, "qty": 1, "can_rotate": true, "grain": "length"}
            Dimensions in mm.
            Grain options per piece: "length" (grain along width — no rotation),
            "width" (grain along height — auto-rotates to match sheet),
            "none" (free rotation).
        sheet_width: Sheet width in mm (default: 2440 — standard 8ft).
            Grain runs along this axis on the sheet.
        sheet_height: Sheet height in mm (default: 1220 — standard 4ft)
        blade_kerf: Saw blade width in mm (default: 3)
        grain_direction: Global default grain for pieces without explicit grain.
            "auto" (default) = use each piece's grain/can_rotate fields.
            "length" = all pieces have grain along their width.
            "none" = ignore grain, free rotation.
        compact: If true (default), return a compact summary + full JSON.
            If false, return only the full pretty-printed JSON.

    Returns:
        Optimization result: sheets used, piece positions, waste percentage,
        grain arrows, and a text diagram.
    """
    err, convert_warnings = _cut_parts_error_response(parts)
    if err:
        return err
    try:
        result = _optimize_cuts(
            parts=parts,
            sheet_width=sheet_width,
            sheet_height=sheet_height,
            blade_kerf=blade_kerf,
            grain_direction=grain_direction,
        )
        # Append auto-conversion warnings to result
        if convert_warnings:
            existing = result.get("warnings", [])
            result["warnings"] = existing + convert_warnings
        if compact:
            summary = _compact_cut_summary(result)
            if convert_warnings:
                summary = "⚠ Auto-conversión: " + "; ".join(convert_warnings) + "\n\n" + summary
            return [
                TextContent(type="text", text=summary),
                TextContent(type="text", text=json.dumps(result, ensure_ascii=False)),
            ]
        return [TextContent(type="text", text=json.dumps(result, indent=2, ensure_ascii=False))]
    except Exception as e:
        logger.exception("optimize_cuts failed")
        return [TextContent(type="text", text=f"Error optimizing cuts: {e}")]


# ---------------------------------------------------------------------------
# BOM tools
# ---------------------------------------------------------------------------


@mcp.tool()
def generate_bom(ctx: Context, spec: dict, compact: bool = True) -> list[TextContent]:
    """Generate a Bill of Materials from a furniture spec.

    Args:
        spec: A furniture spec as returned by design_furniture.
        compact: If true (default), return a compact summary + full JSON.
            If false, return only the full pretty-printed JSON.

    Returns:
        BOM with: panels (name, dimensions, material, edge banding),
        hardware (type, qty, reference), and summary.
    """
    if err := _spec_error_response(spec):
        return err
    try:
        bom = _generate_bom(spec)
        if compact:
            summary = _compact_bom_summary(bom)
            return [
                TextContent(type="text", text=summary),
                TextContent(type="text", text=json.dumps(bom, ensure_ascii=False)),
            ]
        return [TextContent(type="text", text=json.dumps(bom, indent=2, ensure_ascii=False))]
    except Exception as e:
        logger.exception("generate_bom failed")
        return [TextContent(type="text", text=f"Error generating BOM: {e}")]


# ---------------------------------------------------------------------------
# Assembly tools
# ---------------------------------------------------------------------------


def _generate_assembly_steps(spec: dict) -> dict:
    """Internal helper to generate assembly steps from a spec.

    Returns the assembly result dict.
    """
    parts = spec.get("parts", [])
    hardware = spec.get("hardware", [])
    furniture_type = spec.get("furniture_type", "general")

    steps: list[dict] = []
    step_num = 0

    # Group parts by role for assembly order
    panels = [p for p in parts if p.get("role") in ("panel_vertical", "side")]
    bottoms = [p for p in parts if p.get("role") in ("bottom", "floor")]
    tops = [p for p in parts if p.get("role") in ("top", "top_panel")]
    backs = [p for p in parts if p.get("role") == "back"]
    shelves = [p for p in parts if p.get("role") == "shelf"]
    rails = [p for p in parts if p.get("role") == "rail"]
    dividers = [p for p in parts if p.get("role") == "divider"]
    doors = [p for p in parts if p.get("role") == "door"]
    drawer_fronts = [p for p in parts if p.get("role") == "drawer_front"]
    drawer_sides = [p for p in parts if p.get("role") == "drawer_side"]
    drawer_backs = [p for p in parts if p.get("role") == "drawer_back"]
    drawer_bottoms = [p for p in parts if p.get("role") == "drawer_bottom"]
    has_drawer_boxes = bool(drawer_sides or drawer_backs or drawer_bottoms)
    kickplates = [p for p in parts if p.get("role") == "kickplate"]

    # Step 1: Bottom to sides
    if bottoms and panels:
        step_num += 1
        steps.append({
            "step": step_num,
            "action": "Fijar piso al lateral izquierdo",
            "parts": [bottoms[0]["id"], panels[0]["id"]],
            "hardware": "Tornillos confirmat 7x50mm (mín. 3)",
            "tip": "Pre-taladrar con broca de 5mm. El piso va entre los laterales."
        })

    if len(panels) > 1 and bottoms:
        step_num += 1
        steps.append({
            "step": step_num,
            "action": "Fijar lateral derecho al piso",
            "parts": [panels[-1]["id"], bottoms[0]["id"]],
            "hardware": "Tornillos confirmat 7x50mm (mín. 3)",
            "tip": "Verificar escuadra con un ángulo de 90°."
        })

    # Step 2: Dividers
    for div in dividers:
        step_num += 1
        steps.append({
            "step": step_num,
            "action": f"Instalar división vertical '{div['id']}'",
            "parts": [div["id"]],
            "hardware": "Tornillos confirmat 7x50mm (2 arriba, 2 abajo)",
            "tip": "Verificar que quede a plomo (vertical)."
        })

    # Step 3: Rails
    for rail in rails:
        step_num += 1
        steps.append({
            "step": step_num,
            "action": f"Fijar travesaño '{rail['id']}'",
            "parts": [rail["id"]],
            "hardware": "Tornillos confirmat 7x50mm (2 por lado)",
            "tip": "Los travesaños dan rigidez al mueble. No omitir."
        })

    # Step 4: Top
    for top in tops:
        step_num += 1
        steps.append({
            "step": step_num,
            "action": f"Fijar tapa superior '{top['id']}'",
            "parts": [top["id"]],
            "hardware": "Tornillos confirmat 7x50mm",
            "tip": "Asegurar que quede al ras con los laterales."
        })

    # Step 5: Back panel
    for back in backs:
        step_num += 1
        steps.append({
            "step": step_num,
            "action": f"Fijar respaldo '{back['id']}'",
            "parts": [back["id"]],
            "hardware": "Clavos de 1\" o grapas cada 15cm",
            "tip": "El respaldo cuadra el mueble. Verificar diagonales antes de fijar."
        })

    # Step 6: Shelves
    for shelf in shelves:
        step_num += 1
        adjustable = shelf.get("adjustable", False)
        steps.append({
            "step": step_num,
            "action": f"Colocar repisa '{shelf['id']}'",
            "parts": [shelf["id"]],
            "hardware": "Pernos de repisa 5mm (4 por repisa)" if adjustable else "Confirmat 7x50mm (2 por lado)",
            "tip": "Repisa ajustable." if adjustable else "Repisa fija."
        })

    # Step 7: Kickplate
    for kp in kickplates:
        step_num += 1
        steps.append({
            "step": step_num,
            "action": f"Instalar zócalo '{kp['id']}'",
            "parts": [kp["id"]],
            "hardware": "Tornillos o clips de zócalo",
            "tip": "El zócalo va retranqueado ~5cm del frente."
        })

    # Step 8: Doors
    for door in doors:
        step_num += 1
        steps.append({
            "step": step_num,
            "action": f"Montar puerta '{door['id']}'",
            "parts": [door["id"]],
            "hardware": "Bisagras de 35mm (cantidad según altura de puerta)",
            "tip": "Perforar copa de 35mm a 2.2cm del borde. Bisagras a 10cm de extremos."
        })

    # Step 9: Drawers
    for drawer in drawer_fronts:
        drawer_id = drawer["id"].replace("_front", "")
        step_num += 1
        if has_drawer_boxes:
            steps.append({
                "step": step_num,
                "action": f"Montar correderas para cajón '{drawer_id}'",
                "parts": [],
                "hardware": "Correderas telescópicas (par) — fijar al lateral del mueble",
                "tip": "Montar a la altura indicada en el plano. Verificar nivel."
            })
            step_num += 1
            box_parts = [p["id"] for p in drawer_sides + drawer_backs + drawer_bottoms
                         if p["id"].startswith(drawer_id)]
            steps.append({
                "step": step_num,
                "action": f"Armar caja de cajón '{drawer_id}' (fondo → laterales → trasera)",
                "parts": box_parts,
                "hardware": "Tornillos 4x30mm o clavos",
                "tip": "Primero el fondo, luego laterales, por último la trasera. Verificar escuadra."
            })
            step_num += 1
            steps.append({
                "step": step_num,
                "action": f"Fijar frente '{drawer['id']}' a la caja",
                "parts": [drawer["id"]],
                "hardware": "Tornillos desde interior de la caja",
                "tip": "Alinear con holgura uniforme respecto a paneles adyacentes."
            })
        else:
            steps.append({
                "step": step_num,
                "action": f"Instalar cajón '{drawer['id']}'",
                "parts": [drawer["id"]],
                "hardware": "Correderas telescópicas (par)",
                "tip": "Montar correderas primero en laterales del mueble, luego en cajón."
            })

    return {
        "furniture_type": furniture_type,
        "total_steps": len(steps),
        "steps": steps,
        "general_tips": [
            "Trabajar sobre superficie plana y limpia.",
            "Pre-taladrar siempre antes de atornillar confirmat.",
            "Verificar escuadra después de cada unión.",
            "El respaldo es el último panel estructural — cuadra todo el mueble.",
            "Las puertas y cajones se montan al final.",
        ]
    }


@mcp.tool()
def get_assembly_steps(ctx: Context, spec: dict, compact: bool = True) -> list[TextContent]:
    """Generate step-by-step assembly instructions for a furniture spec.

    Args:
        spec: A furniture spec as returned by design_furniture.
        compact: If true (default), return a compact summary + full JSON.
            If false, return only the full pretty-printed JSON.

    Returns:
        Ordered list of assembly steps with part references, hardware needed
        per step, and tips.
    """
    if err := _spec_error_response(spec):
        return err
    try:
        result = _generate_assembly_steps(spec)
        if compact:
            summary = _compact_assembly_summary(result)
            return [
                TextContent(type="text", text=summary),
                TextContent(type="text", text=json.dumps(result, ensure_ascii=False)),
            ]
        return [TextContent(type="text", text=json.dumps(result, indent=2, ensure_ascii=False))]
    except Exception as e:
        logger.exception("get_assembly_steps failed")
        return [TextContent(type="text", text=f"Error generating assembly steps: {e}")]


# ---------------------------------------------------------------------------
# FreeCAD bridge tools
# ---------------------------------------------------------------------------


@mcp.tool()
def build_3d_model(
    ctx: Context,
    spec: dict,
    doc_name: str = "Furniture",
) -> list[TextContent]:
    """Build the furniture as a 3D model in FreeCAD.

    Creates Part::Box objects for each panel, positioned and color-coded by
    role, directly in the running FreeCAD instance via XML-RPC.

    Args:
        spec: A furniture spec as returned by design_furniture.
        doc_name: Name for the FreeCAD document (default: "Furniture").

    Returns:
        Summary of what was built.
    """
    if err := _spec_error_response(spec):
        return err
    try:
        code = spec_to_freecad_script(spec, doc_name=doc_name)
        n_parts = len(spec.get("parts", []))
        return _execute_in_freecad(
            code,
            f"Modelo 3D construido: {n_parts} paneles en documento '{doc_name}'.",
        )
    except Exception as e:
        logger.exception("build_3d_model failed")
        return [TextContent(type="text", text=f"Error building 3D model: {e}")]


@mcp.tool()
def build_exploded_view(
    ctx: Context,
    spec: dict,
    gap_mm: float = 50,
    doc_name: str = "Exploded",
) -> list[TextContent]:
    """Build an exploded assembly view in FreeCAD.

    Panels are separated along their assembly axis to visualize how the
    furniture comes together. Executed directly in FreeCAD via XML-RPC.

    Args:
        spec: A furniture spec as returned by design_furniture.
        gap_mm: Gap between exploded parts in mm (default: 50).
        doc_name: Name for the FreeCAD document (default: "Exploded").

    Returns:
        Summary of what was built.
    """
    if err := _spec_error_response(spec):
        return err
    try:
        code = exploded_view_script(spec, gap_mm=gap_mm, doc_name=doc_name)
        n_parts = len(spec.get("parts", []))
        return _execute_in_freecad(
            code,
            f"Vista explosionada construida: {n_parts} paneles con separación de {gap_mm}mm en documento '{doc_name}'.",
        )
    except Exception as e:
        logger.exception("build_exploded_view failed")
        return [TextContent(type="text", text=f"Error building exploded view: {e}")]


@mcp.tool()
def build_cut_diagram(
    ctx: Context,
    cut_result: dict,
    doc_name: str = "CutLayout",
) -> list[TextContent]:
    """Build a cut layout diagram in FreeCAD.

    Creates a top-down view of each sheet with pieces placed according to the
    cut optimizer output. Executed directly in FreeCAD via XML-RPC.

    Args:
        cut_result: Result from optimize_cuts tool.
        doc_name: Name for the FreeCAD document (default: "CutLayout").

    Returns:
        Summary of what was built.
    """
    if "sheets" not in cut_result or not cut_result.get("sheets"):
        return [TextContent(
            type="text",
            text="cut_result inválido: no tiene 'sheets' o está vacío. "
                 "Pasa el resultado de optimize_cuts.",
        )]
    try:
        code = cut_layout_script(cut_result, doc_name=doc_name)
        n_sheets = len(cut_result["sheets"])
        return _execute_in_freecad(
            code,
            f"Diagrama de corte construido: {n_sheets} tableros en documento '{doc_name}'.",
        )
    except Exception as e:
        logger.exception("build_cut_diagram failed")
        return [TextContent(type="text", text=f"Error building cut diagram: {e}")]


@mcp.tool()
def build_spec(
    ctx: Context,
    layout: dict,
    compact: bool = True,
) -> list[TextContent]:
    """Build a complete furniture spec from a high-level layout description.

    This is a convenience tool that eliminates the need to manually calculate
    mm positions, slide clearances, kickplate offsets, etc. Just describe
    the furniture in columns and rows.

    Args:
        layout: High-level description with columns and rows. Example:
            {
                "furniture_type": "closet",
                "width_cm": 240, "height_cm": 240, "depth_cm": 60,
                "material": "melamine_16",
                "kickplate_height_cm": 10,
                "back_type": "full",
                "columns": [
                    {
                        "width_cm": 80,
                        "rows": [
                            {"type": "hanging_bar", "height_cm": 160},
                        ]
                    },
                    {
                        "width_cm": "auto",
                        "rows": [
                            {"type": "drawers", "count": 3, "drawer_height_mm": 140},
                            {"type": "hanging_bar", "height_cm": 160},
                        ]
                    },
                    {
                        "width_cm": "auto",
                        "rows": [
                            {"type": "shelves", "count": 6},
                        ]
                    }
                ]
            }
            Column width_cm can be a number or "auto" (distributes remaining space).
            Row types: "shelf", "shelves", "drawers", "hanging_bar", "empty".
        compact: If true (default), return compact summary + full JSON.

    Returns:
        Complete furniture spec ready for validate_structure, generate_bom,
        optimize_cuts, build_3d_model, etc.
    """
    try:
        spec = _build_spec(layout)
    except (ValueError, KeyError) as e:
        return [TextContent(type="text", text=f"Error en layout: {e}")]
    except Exception as e:
        logger.exception("build_spec failed")
        return [TextContent(type="text", text=f"Error building spec: {e}")]

    spec_json = json.dumps(spec, indent=2, ensure_ascii=False)

    if not compact:
        return [TextContent(type="text", text=spec_json)]

    # Compact summary
    parts = spec.get("parts", [])
    from collections import Counter
    role_counts = Counter(p["role"] for p in parts)
    role_summary = ", ".join(f"{v}× {k}" for k, v in role_counts.most_common())

    hw_count = len(spec.get("hardware", []))
    notes_summary = " | ".join(spec.get("notes", []))

    dims = spec.get("dimensions_cm", {})
    summary = (
        f"Spec generado: {spec.get('furniture_type', '?')} "
        f"{dims.get('width', '?')}×{dims.get('height', '?')}×{dims.get('depth', '?')}cm "
        f"({spec.get('material', '?')})\n"
        f"Partes: {len(parts)} ({role_summary})\n"
        f"Hardware: {hw_count} items\n"
        f"Notas: {notes_summary}"
    )

    return [
        TextContent(type="text", text=summary),
        TextContent(type="text", text=spec_json),
    ]


@mcp.tool()
def build_techdraw(
    ctx: Context,
    spec: dict,
    doc_name: str = "TechDraw",
    export_svg: bool = True,
    export_dir: str = "/tmp",
) -> list[TextContent]:
    """Build a TechDraw technical drawing in FreeCAD.

    Produces an A3 landscape sheet with three orthographic views (front, top,
    right side) of the furniture, auto-scaled to fit. Useful for fabrication
    documentation and client presentations.

    The script is self-contained — it rebuilds the geometry as a compound,
    so it does NOT require the 3D model to already exist in FreeCAD.

    Executed directly in FreeCAD via XML-RPC.

    Args:
        spec: A furniture spec as returned by design_furniture.
        doc_name: Name for the FreeCAD document (default: "TechDraw").
        export_svg: If true (default), export the TechDraw page to SVG.
        export_dir: Directory for SVG export (default: "/tmp").

    Returns:
        Summary of what was built, including SVG path if exported.
    """
    if err := _spec_error_response(spec):
        return err
    try:
        code = _techdraw_script(spec, doc_name=doc_name, export_svg=export_svg, export_dir=export_dir)
        n_parts = len(spec.get("parts", []))
        svg_info = ""
        if export_svg:
            svg_path = f"{export_dir.rstrip('/')}/{doc_name}.svg"
            svg_info = f" SVG exportado a: {svg_path}"
        return _execute_in_freecad(
            code,
            f"Plano técnico TechDraw creado: {n_parts} paneles, formato A3 en documento '{doc_name}'.{svg_info}",
        )
    except Exception as e:
        logger.exception("build_techdraw failed")
        return [TextContent(type="text", text=f"Error building TechDraw: {e}")]


# ---------------------------------------------------------------------------
# FreeCAD import tools
# ---------------------------------------------------------------------------


@mcp.tool()
def build_import_script(
    ctx: Context,
    doc_name: str = "Furniture",
) -> list[TextContent]:
    """Generate a FreeCAD Python script that reads all panels from a document.

    The script extracts every App::Part (with custom properties) and standalone
    Part::Box from the specified document, then prints a JSON representation
    to stdout. Execute the script via freecad-mcp's execute_code, then pass
    the output to parse_freecad_import to get a usable furniture spec.

    Workflow:
    1. Call build_import_script(doc_name) → get Python script
    2. Call mcp__freecad__execute_code(script) → get raw output with JSON
    3. Call parse_freecad_import(raw_output) → get furniture spec
    4. Use the spec with validate_structure, generate_bom, optimize_cuts, etc.

    Args:
        doc_name: Name of the FreeCAD document to read (default: "Furniture").

    Returns:
        Python code to execute in FreeCAD.
    """
    try:
        code = _import_script(doc_name=doc_name)
        return [TextContent(type="text", text=code)]
    except Exception as e:
        logger.exception("build_import_script failed")
        return [TextContent(type="text", text=f"Error generating import script: {e}")]


@mcp.tool()
def parse_freecad_import(
    ctx: Context,
    raw_output: str,
) -> list[TextContent]:
    """Parse the output of the import script into a furniture spec.

    Takes the raw stdout from executing the import script in FreeCAD and
    reconstructs a furniture spec with parts, positions, materials, and roles.

    For panels created by this system (App::Part with custom properties),
    the reconstruction is exact. For manually created Part::Box objects,
    roles are inferred from names and geometry.

    Args:
        raw_output: The stdout text from executing the import script via
            freecad-mcp's execute_code tool.

    Returns:
        A furniture spec (JSON) compatible with validate_structure,
        generate_bom, optimize_cuts, build_exploded_view, etc.
        May include "import_warnings" if any panels needed inference.
    """
    try:
        spec = _parse_export(raw_output)
        return [TextContent(type="text", text=json.dumps(spec, indent=2, ensure_ascii=False))]
    except Exception as e:
        logger.exception("parse_freecad_import failed")
        return [TextContent(type="text", text=f"Error parsing FreeCAD import: {e}")]


# ---------------------------------------------------------------------------
# Multi-design tools
# ---------------------------------------------------------------------------


@mcp.tool()
def create_design(
    ctx: Context,
    name: str,
    furniture_type: str,
) -> list[TextContent]:
    """Create a new design project.

    Sets up a directory with metadata for a new furniture design. Use this
    before calling update_design_report with a design_id.

    Args:
        name: Human-readable name (e.g., "Closet Dormitorio Principal").
        furniture_type: One of: kitchen_base, kitchen_wall, closet, bookshelf, desk, vanity.

    Returns:
        Design ID, path, and URL (if server is running).
    """
    from .engine.design_store import get_store

    store = get_store()
    result = store.create(name, furniture_type)

    # Check if server is running
    try:
        from .engine.http_server import get_server
        server = get_server()
        if server.is_running:
            result["url"] = server.get_url(result["design_id"])
    except Exception:
        pass

    return [TextContent(
        type="text",
        text=f"Diseño creado: {result['design_id']}\n"
             f"Ruta: {result['path']}\n"
             + (f"URL: {result.get('url', 'servidor no iniciado')}" ),
    )]


@mcp.tool()
def list_designs(ctx: Context) -> list[TextContent]:
    """List all active furniture designs with metadata.

    Returns:
        List of designs with name, type, iteration count, and timestamps.
    """
    from .engine.design_store import get_store

    store = get_store()
    designs = store.list_designs()

    if not designs:
        return [TextContent(type="text", text="No hay diseños activos. Usa create_design para comenzar.")]

    lines = [f"📁 {len(designs)} diseño(s) activo(s):\n"]
    for d in designs:
        status = "✅" if d.get("has_report") else "⬜"
        lines.append(
            f"  {status} {d.get('design_id', '?')} — {d.get('name', '?')} "
            f"({d.get('type', '?')}) · v{d.get('iterations_count', 0)} · "
            f"actualizado {d.get('updated', '?')}"
        )

    return [TextContent(type="text", text="\n".join(lines))]


@mcp.tool()
def get_design_context(
    ctx: Context,
    design_id: str,
) -> list[TextContent]:
    """Retrieve the full context of a design for resuming work.

    Returns the latest spec, metadata, and iteration history so the agent
    can continue from where the user left off.

    Args:
        design_id: The design identifier (slug).

    Returns:
        Spec JSON + metadata + iteration summary.
    """
    from .engine.design_store import get_store

    store = get_store()
    if not store.design_exists(design_id):
        return [TextContent(type="text", text=f"Diseño '{design_id}' no encontrado.")]

    meta = store.get_metadata(design_id)
    spec = store.get_spec(design_id)

    summary_parts = []
    if meta:
        summary_parts.append(
            f"Diseño: {meta.get('name', design_id)}\n"
            f"Tipo: {meta.get('type', '?')}\n"
            f"Iteraciones: {meta.get('iterations_count', 0)}\n"
            f"Creado: {meta.get('created', '?')}\n"
            f"Actualizado: {meta.get('updated', '?')}"
        )

    result = [TextContent(type="text", text="\n".join(summary_parts) if summary_parts else "Sin metadata.")]

    if spec:
        compact = _compact_spec_summary(spec)
        result.append(TextContent(type="text", text=compact))
        result.append(TextContent(type="text", text=json.dumps(spec, ensure_ascii=False)))

    return result


# ---------------------------------------------------------------------------
# Design server tool
# ---------------------------------------------------------------------------


@mcp.tool()
def start_design_server(
    ctx: Context,
    port: int = 8432,
    designs_dir: str = "./designs",
) -> list[TextContent]:
    """Start the local HTTP server for serving design reports with live reload.

    The server provides:
    - Index page listing all designs at http://localhost:{port}/
    - Individual design reports at http://localhost:{port}/{design_id}
    - WebSocket for live reload at ws://localhost:{port}/ws/{design_id}
    - JSON spec API at http://localhost:{port}/api/{design_id}/spec

    Args:
        port: HTTP port (default: 8432). Falls back to random port if busy.
        designs_dir: Directory for design files (default: ./designs).

    Returns:
        Server URL and status.
    """
    from .engine.http_server import get_server

    server = get_server(port=port, designs_dir=designs_dir)
    if server.is_running:
        return [TextContent(
            type="text",
            text=f"Servidor ya activo en {server.get_base_url()}",
        )]

    import asyncio

    async def _start():
        return await server.start()

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # Schedule in the running loop (MCP uses asyncio)
            future = asyncio.ensure_future(server.start())
            # We can't await here in a sync tool, so we start it as a task
            # The server will be ready almost immediately
            url = server.get_base_url()
        else:
            url = loop.run_until_complete(server.start())
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        url = loop.run_until_complete(server.start())

    return [TextContent(
        type="text",
        text=f"Servidor de diseño iniciado en {url}\n"
             f"Directorio de diseños: {server.designs_dir}\n"
             f"Abre {url} en tu navegador para ver los diseños.",
    )]


# ---------------------------------------------------------------------------
# Design report tool
# ---------------------------------------------------------------------------


@mcp.tool()
def update_design_report(
    ctx: Context,
    spec: dict,
    comment: str = "",
    iteration_name: str = "",
    design_id: str | None = None,
    output_path: str | None = None,
    cut_data: dict | None = None,
) -> list[TextContent]:
    """Generate or update an interactive HTML design report.

    Creates a self-contained HTML file with 3D visualization (Three.js),
    iteration comparison slider, and clickable panels with dimensions.

    If design_id is provided, uses the DesignStore (recommended for
    multi-design workflows with live reload). Otherwise falls back to
    output_path for backward compatibility.

    Args:
        spec: A furniture spec as returned by design_furniture.
        comment: Description of this iteration's changes (e.g. "Added drawer").
        iteration_name: Label for this version (e.g. "v2"). Auto-generated if omitted.
        design_id: Design identifier from create_design. If set, uses DesignStore.
        output_path: Path for the HTML file. Only used if design_id is not set.
            Defaults to ./design_report.html.
        cut_data: Optional cut optimization result from optimize_cuts.

    Returns:
        Path to the generated HTML report file and URL if server is running.
    """
    if err := _spec_error_response(spec):
        return err
    try:
        # Route: DesignStore (multi-design with live reload)
        if design_id:
            from .engine.design_store import get_store

            store = get_store()
            if not store.design_exists(design_id):
                return [TextContent(type="text",
                    text=f"Diseño '{design_id}' no encontrado. Usa create_design primero.")]

            result = store.save_iteration(
                design_id=design_id,
                spec=spec,
                comment=comment,
                iteration_name=iteration_name,
                cut_data=cut_data,
            )

            # Notify WebSocket clients for live reload
            url_info = ""
            try:
                from .engine.http_server import get_server
                import asyncio

                server = get_server()
                if server.is_running:
                    url_info = f"\nURL: {server.get_url(design_id)}"
                    asyncio.ensure_future(server.notify_update(design_id))
            except Exception:
                pass

            return [TextContent(
                type="text",
                text=f"Reporte actualizado: {result['iteration']} — {result['report_path']}{url_info}",
            )]

        # Route: Direct file (backward compatible)
        path = _generate_report(
            spec=spec,
            comment=comment,
            iteration_name=iteration_name,
            output_path=output_path,
            cut_data=cut_data,
        )
        return [TextContent(
            type="text",
            text=f"Reporte de diseño actualizado: {path}",
        )]
    except Exception as e:
        logger.exception("update_design_report failed")
        return [TextContent(type="text", text=f"Error generating report: {e}")]


# ---------------------------------------------------------------------------
# Full report tool (design → validate → BOM → cuts → assembly → report)
# ---------------------------------------------------------------------------


def _spec_to_cut_parts(spec: dict) -> list[dict]:
    """Convert spec parts to the format expected by optimize_cuts."""
    cut_parts = []
    t = spec.get("material_thickness_mm", 18)
    for p in spec.get("parts", []):
        role = p.get("role", "")
        # Skip MDF/thin panels — they are cut from different stock
        if role in ("back", "drawer_bottom") or p.get("thickness_mm", t) < t:
            continue
        grain = "length"
        can_rotate = True
        if role in ("side", "divider"):
            can_rotate = False
        cut_parts.append({
            "id": p["id"],
            "width": p["width_mm"],
            "height": p["height_mm"],
            "qty": 1,
            "can_rotate": can_rotate,
            "grain": grain,
        })
    return cut_parts


@mcp.tool()
def generate_full_report(
    ctx: Context,
    furniture_type: str,
    width: float,
    height: float,
    depth: float,
    material: str = "melamine_16",
    options: dict | None = None,
    comment: str = "",
    iteration_name: str = "",
    output_path: str | None = None,
) -> list[TextContent]:
    """Design furniture and generate a complete report in one step.

    Runs the full pipeline: design → validate → BOM → cut optimization →
    assembly instructions → interactive HTML report with all tabs populated.

    Args:
        furniture_type: One of: kitchen_base, kitchen_wall, closet, bookshelf,
            desk, vanity
        width: Total width in cm
        height: Total height in cm
        depth: Total depth in cm
        material: Material key (default: melamine_16)
        options: Optional overrides (same as design_furniture options)
        comment: Description for this iteration
        iteration_name: Label for this version (auto-generated if omitted)
        output_path: Path for the HTML file. Defaults to ./design_report.html.

    Returns:
        Summary of the full pipeline results and path to the HTML report.
    """
    try:
        # 1. Design
        spec = generate_furniture_spec(
            furniture_type=furniture_type,
            width=width, height=height, depth=depth,
            material=material,
            options=options,
        )

        # 2. Validate
        validation = _validate(spec)

        # 3. BOM
        bom = _generate_bom(spec)

        # 4. Cut optimization
        cut_parts = _spec_to_cut_parts(spec)
        cut_result = _optimize_cuts(parts=cut_parts)

        # 5. Assembly
        assembly = _generate_assembly_steps(spec)

        # 6. Embed extra data in spec for report
        spec["cut_data"] = cut_result
        spec["bom_data"] = bom
        spec["assembly_data"] = assembly

        # 7. Generate report
        path = _generate_report(
            spec=spec,
            comment=comment,
            iteration_name=iteration_name,
            output_path=output_path,
        )

        # Build summary
        dims = spec.get("dimensions_cm", {})
        parts = spec.get("parts", [])
        v_status = validation.get("status", "?")
        v_errors = len(validation.get("errors", []))
        v_warnings = len(validation.get("warnings", []))
        sheets = cut_result.get("sheets_needed", "?")
        waste = cut_result.get("waste_percentage", "?")
        n_steps = assembly.get("total_steps", "?")
        edge_m = bom.get("edge_banding", {}).get("total_meters", "?")

        summary = (
            f"Reporte completo generado: {path}\n"
            f"  Mueble: {furniture_type} {dims.get('width','?')}×{dims.get('height','?')}×{dims.get('depth','?')}cm ({material})\n"
            f"  Validación: {v_status} ({v_errors} errores, {v_warnings} advertencias)\n"
            f"  Partes: {len(parts)} | Canteado: {edge_m}m\n"
            f"  Corte: {sheets} tableros, {waste}% desperdicio\n"
            f"  Ensamble: {n_steps} pasos"
        )

        return [TextContent(type="text", text=summary)]

    except Exception as e:
        logger.exception("generate_full_report failed")
        return [TextContent(type="text", text=f"Error: {e}")]


# ---------------------------------------------------------------------------
# Section mapper tool
# ---------------------------------------------------------------------------


@mcp.tool()
def get_section_map(
    ctx: Context,
    design_id: str = "",
    spec: str = "",
    resolve: str = "",
) -> list[TextContent]:
    """Get or resolve section labels from a furniture spec.

    Analyzes dividers in a spec to identify sections (S1, S2, …) with
    human-readable labels and aliases for natural language resolution.

    Args:
        design_id: Load spec from a saved design (alternative to passing spec).
        spec: JSON string of a furniture spec (alternative to design_id).
        resolve: Optional natural language text to resolve to a section ID
                 (e.g. "izquierda", "centro", "S2").

    Returns:
        Section map with labels, aliases, boundaries, and parts per section.
        If resolve is provided, also includes the matched section ID.
    """
    # Get spec from design_id or inline
    spec_data = None
    if design_id:
        from .engine.design_store import get_store
        spec_data = get_store().get_spec(design_id)
        if spec_data is None:
            return [TextContent(type="text", text=f"❌ Design '{design_id}' not found or has no spec.")]
    elif spec:
        try:
            spec_data = json.loads(spec)
        except json.JSONDecodeError as e:
            return [TextContent(type="text", text=f"❌ Invalid JSON: {e}")]
    else:
        return [TextContent(type="text", text="❌ Provide either design_id or spec.")]

    # Generate section map
    section_labels = _map_sections(spec_data)

    result = {"section_labels": section_labels}

    # Resolve reference if requested
    if resolve:
        matched = _resolve_section(section_labels, resolve)
        result["resolved"] = {
            "input": resolve,
            "section_id": matched,
            "section_info": section_labels.get(matched) if matched else None,
        }

    return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2))]


# ---------------------------------------------------------------------------
# Hot-reload tool
# ---------------------------------------------------------------------------


@mcp.tool()
def reload_engine(ctx: Context) -> list[TextContent]:
    """Reload all engine modules to pick up code changes during development.

    Use after modifying engine files (designer.py, cut_optimizer.py, etc.)
    without restarting the MCP server.

    Returns:
        List of reloaded modules.
    """
    import importlib
    from .engine import (
        designer as _mod_designer,
        cut_optimizer as _mod_cut_optimizer,
        structural_validator as _mod_structural_validator,
        bom_generator as _mod_bom_generator,
        spec_validator as _mod_spec_validator,
        freecad_scripts as _mod_freecad_scripts,
        freecad_client as _mod_freecad_client,
        report_generator as _mod_report_generator,
        spec_builder as _mod_spec_builder,
        section_mapper as _mod_section_mapper,
    )

    module_list = [
        _mod_spec_validator,
        _mod_designer,
        _mod_cut_optimizer,
        _mod_structural_validator,
        _mod_bom_generator,
        _mod_freecad_scripts,
        _mod_freecad_client,
        _mod_report_generator,
        _mod_spec_builder,
        _mod_section_mapper,
    ]

    reloaded_names = []
    for mod in module_list:
        importlib.reload(mod)
        reloaded_names.append(mod.__name__.split(".")[-1])

    # Rebind module-level references used by other tools
    global generate_furniture_spec
    generate_furniture_spec = _mod_designer.generate_furniture_spec

    global _optimize_cuts
    _optimize_cuts = _mod_cut_optimizer.optimize_cuts

    global _validate
    _validate = _mod_structural_validator.validate_structure

    global _generate_bom
    _generate_bom = _mod_bom_generator.generate_bom

    global validate_spec, validate_cut_parts
    validate_spec = _mod_spec_validator.validate_spec
    validate_cut_parts = _mod_spec_validator.validate_cut_parts

    global spec_to_freecad_script, exploded_view_script, cut_layout_script
    global _techdraw_script, _import_script, _parse_export
    spec_to_freecad_script = _mod_freecad_scripts.spec_to_freecad_script
    exploded_view_script = _mod_freecad_scripts.exploded_view_script
    cut_layout_script = _mod_freecad_scripts.cut_layout_script
    _techdraw_script = _mod_freecad_scripts.techdraw_script
    _import_script = _mod_freecad_scripts.import_script
    _parse_export = _mod_freecad_scripts.parse_freecad_export

    global _get_freecad_client
    _get_freecad_client = _mod_freecad_client.get_client

    global _generate_report
    _generate_report = _mod_report_generator.generate_design_report

    global _build_spec
    _build_spec = _mod_spec_builder.build_spec_from_layout

    global _map_sections, _resolve_section
    _map_sections = _mod_section_mapper.map_sections
    _resolve_section = _mod_section_mapper.resolve_reference

    return [TextContent(
        type="text",
        text=f"Módulos recargados: {', '.join(reloaded_names)}",
    )]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main():
    mcp.run()


if __name__ == "__main__":
    main()
