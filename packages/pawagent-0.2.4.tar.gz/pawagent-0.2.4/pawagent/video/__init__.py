"""Video capability package."""
