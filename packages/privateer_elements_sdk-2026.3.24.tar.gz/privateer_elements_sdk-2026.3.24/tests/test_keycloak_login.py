import base64
import json
import os

import pytest

from elements.sdk.api.keycloak import Keycloak

ELEMENTS_USERNAME = os.environ['ELEMENTS_USERNAME']
ELEMENTS_PASSWORD = os.environ['ELEMENTS_PASSWORD']


def test_password_login():
    kc = Keycloak()
    tokens = kc.password_login(username=ELEMENTS_USERNAME, password=ELEMENTS_PASSWORD)

    assert 'access_token' in tokens
    assert len(tokens['access_token']) > 0


def test_password_login_returns_valid_jwt():
    kc = Keycloak()
    tokens = kc.password_login(username=ELEMENTS_USERNAME, password=ELEMENTS_PASSWORD)

    # Decode the access token payload and verify claims
    parts = tokens['access_token'].split('.')
    assert len(parts) == 3
    payload_b64 = parts[1] + '=' * (-len(parts[1]) % 4)
    payload = json.loads(base64.urlsafe_b64decode(payload_b64))

    assert payload.get('azp') == 'login-direct'
    assert payload.get('email') == 'test_e2e@orbitalinsight.com'
    assert 'exp' in payload
    assert 'iat' in payload


def test_password_login_offline_access():
    kc = Keycloak()
    tokens = kc.password_login(username=ELEMENTS_USERNAME, password=ELEMENTS_PASSWORD, offline_access=True)

    assert 'access_token' in tokens
    assert 'refresh_token' in tokens

    # Offline tokens should have offline_access role
    parts = tokens['access_token'].split('.')
    payload_b64 = parts[1] + '=' * (-len(parts[1]) % 4)
    payload = json.loads(base64.urlsafe_b64decode(payload_b64))
    roles = payload.get('realm_access', {}).get('roles', [])
    assert 'offline_access' in roles


def test_password_login_bad_credentials():
    kc = Keycloak()
    import requests
    with pytest.raises(requests.HTTPError):
        kc.password_login(username='nonexistent', password='wrong')
