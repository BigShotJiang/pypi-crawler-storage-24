import logging
import uuid

import pytest
import geojson
import uuid
from elements.sdk.elements_sdk import ElementsSDK
from elements.sdk.tools.io import H3Tools


class TestIO:
    @pytest.mark.asyncio
    async def test_point_to_h3_boundary(self):
        h3_tools = H3Tools()
        filepath = "tests/resources/aois/geojson/attributed_sea_ports.geojson"
        sea_port_h3_geojson = h3_tools.points_to_h3_geometry(filename=filepath, resolution=10,
                                                             output="tests/resources/aois/geojson/sea_ports.geojson",
                                                             encoding="utf-8")
        # Need a better test here.
        assert sea_port_h3_geojson is not None

        # verify upload works
        sdk = ElementsSDK()
        aoi_collection = await sdk.aoi_collection.create(str(uuid.uuid4()))

        await sdk.aoi.upload(aoi_collection_id=aoi_collection.id,
                             file_path="tests/resources/aois/geojson/sea_ports.geojson")

        logging.info(sea_port_h3_geojson)
