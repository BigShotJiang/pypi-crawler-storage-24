import uuid
import pytest
from datetime import date, datetime, timezone

from elements.sdk.elements_sdk import ElementsSDK
from tests.integration.test_analysis import (
    algorithm_create, algorithm_version_create, algorithm_config_create,
    analysis_create, analysis_version_create, analysis_config_create
)


class TestProject:
    @pytest.mark.asyncio
    async def test_create(self):
        sdk = ElementsSDK()
        name = "project-sdk-integration-test-{}".format(uuid.uuid4())
        description = "Integration test project"

        project = await sdk.project.create(name=name, description=description)
        assert project.id is not None
        assert project.name == name
        assert project.description == description

    @pytest.mark.asyncio
    async def test_update_with_dates(self):
        sdk = ElementsSDK()
        name = "project-update-test-{}".format(uuid.uuid4())
        project = await sdk.project.create(name=name, description="Update test")

        await sdk.project.update(
            project_id=project.id,
            name=name,
            description="Update test",
            start_date=date(2022, 3, 17),
            end_date=date(2022, 3, 21)
        )

        # Verify dates were set
        updated = await sdk.project.get(project_id=project.id)
        assert updated.start_date.ToDatetime().date() == date(2022, 3, 17)
        assert updated.end_date.ToDatetime().date() == date(2022, 3, 21)

    @pytest.mark.asyncio
    async def test_share(self):
        sdk = ElementsSDK()
        name = "project-share-test-{}".format(uuid.uuid4())
        project = await sdk.project.create(name=name, description="Share test")

        await sdk.project_collaborator.update(
            project_id=project.id,
            user_id='test_e2e',
            role='COLLABORATOR'
        )

        # Verify test_e2e is now a collaborator
        collaborators = await sdk.project_collaborator.get(project_id=project.id)
        user_ids = [c.user_id for c in collaborators]
        assert 'test_e2e' in user_ids


class TestProjectAnalysisConfig:
    @pytest.mark.asyncio
    async def test_update(self):
        sdk = ElementsSDK()

        # SETUP ALGORITHM
        algorithm = await algorithm_create()
        algorithm_version = await algorithm_version_create(algorithm.id)
        algorithm_config = await algorithm_config_create(algorithm_version.id)

        # SETUP ANALYSIS
        analysis = await analysis_create(
            name="project-analysis-config-test-{}".format(datetime.now()),
            author="elements-sdk")
        analysis_version, manifest = await analysis_version_create(
            analysis.id, [algorithm_version.id], [])
        analysis_config = await analysis_config_create(
            analysis_version.id, algorithm_config.id, manifest)

        # CREATE PROJECT
        project = await sdk.project.create(
            name="project-link-test-{}".format(uuid.uuid4()),
            description="Test linking analysis configs to project")

        # LINK ANALYSIS CONFIG TO PROJECT
        await sdk.project_analysis_config.update(
            project_id=project.id,
            analysis_config_ids=[analysis_config.id])


class TestProjectGroup:
    @pytest.mark.asyncio
    async def test_create(self):
        sdk = ElementsSDK()

        # CREATE PROJECTS
        project_ids = []
        for i in range(3):
            project = await sdk.project.create(
                name="project-group-member-{}-{}".format(i, uuid.uuid4()),
                description="Member project for group test")
            project_ids.append(project.id)

        # CREATE PROJECT GROUP
        group_name = "project-group-sdk-test-{}".format(uuid.uuid4())
        project_group = await sdk.project_group.create(
            name=group_name,
            project_ids=project_ids)
        assert project_group.id is not None
        assert project_group.name == group_name
