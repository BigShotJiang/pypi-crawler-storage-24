import uuid

import pytest

from elements.sdk.elements_sdk import ElementsSDK


class TestDataSource:
    @pytest.mark.asyncio
    async def test_get(self):
        sdk = ElementsSDK()
        ids = ["planet_PSScene4Band", "stac_stac"]
        sources = await sdk.data_source.get(ids=ids)
        assert len(sources) == len(ids)

    @pytest.mark.asyncio
    async def test_list(self):
        sdk = ElementsSDK()
        data_sources = await sdk.data_source.list()
        assert len(data_sources) > 0

        data_sources = await sdk.data_source.list(search_text="iceye")
        assert len(data_sources) >= 1


class TestDataType:
    @pytest.mark.asyncio
    async def test_get(self):
        sdk = ElementsSDK()
        data_types = await sdk.data_type.get(names=["pings"])
        assert len(data_types) == 1

    @pytest.mark.asyncio
    async def test_list(self):
        sdk = ElementsSDK()
        data_types = await sdk.data_type.list()
        assert len(data_types) > 0

        data_types = await sdk.data_type.list(search_text="ping")
        assert len(data_types) >= 1

    @pytest.mark.asyncio
    async def test_create(self):
        sdk = ElementsSDK()
        name = "test_data_type_{}".format(str(uuid.uuid4()).split("-")[0])
        data_type = await sdk.data_type.create(name=name, description="test description",
                                                schema="", data_source_ids=[], sensor_type="test")
