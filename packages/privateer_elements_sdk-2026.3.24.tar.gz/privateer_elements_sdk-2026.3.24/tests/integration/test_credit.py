import logging
import os
import uuid
from datetime import datetime

import pytest

from elements.sdk.builder.toi import TOIBuilder, TOIRuleBuilder, Frequency
from elements.sdk.builder.algorithm import (
    AlgorithmManifest, InterfaceType, DataType, AlgorithmConfiguration
)
from elements.sdk.elements_sdk import ElementsSDK


class TestCredit:
    @pytest.mark.asyncio
    async def test_estimate(self):
        admin_token = os.getenv('ELEMENTS_ADMIN_TOKEN')
        if not admin_token:
            pytest.skip("ELEMENTS_ADMIN_TOKEN not set")

        sdk = ElementsSDK()
        admin_client = ElementsSDK.create_client(elements_token=admin_token)
        admin_sdk = ElementsSDK(client=admin_client)

        datetime_format = '%Y-%m-%dT%H:%M:%SZ'
        toi_configuration = TOIBuilder()
        toi_configuration.build_toi(start=datetime.strptime("2019-01-05T01:00:00Z", datetime_format),
                                    finish=datetime.strptime("2019-01-06T01:00:00Z", datetime_format))
        toi_configuration.build_recurrence(TOIRuleBuilder.build_rule(
            frequency=Frequency.DAILY,
            interval=1
        ))
        toi = await sdk.toi.create(toi_configuration.get())

        aoi_collection = await sdk.aoi_collection.create(aoi_collection_name=str(uuid.uuid4()))
        await sdk.aoi.upload(aoi_collection_id=aoi_collection.id,
                             file_path="tests/resources/aois/geojson/basic_factory_phillips_66.geojson")

        device_visit_algorithm = await sdk.algorithm.create(name="device-visits-{}".format(uuid.uuid4()),
                                                            author="sdk@orbitalinsight.com",
                                                            display_name="Device Visits")

        manifest = AlgorithmManifest()
        manifest.metadata_required(description="Testing algo manifest builder")
        manifest.interface_required(interface_type=InterfaceType.FILESYSTEM_TASK_WORKER.value)
        manifest.inputs_add_data_type(data_type_name=DataType.PINGS.value)
        manifest.container_parameters_required(image="orbitalinsight/device_visits:5a579e59",
                                               command=["python",
                                                        "/orbital/base/algorithms/device_visits/src/py/"
                                                        "device_visits/device_visits.py"])
        manifest.outputs_add_data_type(data_type_name="device_visits",
                                       observation_value_columns=["unique_device_count"])
        manifest.parameter_add(name="look_back_time", type="integer", default=3600,
                               description="how far to look back")
        manifest.parameter_add(name="look_forward_time", type="integer", default=3600,
                               description="how far to look back")
        manifest.container_parameters_resource_request(memory_gb=5, cpu_millicore=200)
        device_visit_algorithm_version = await sdk.algorithm_version.create(algorithm_id=device_visit_algorithm.id,
                                                                            algorithm_manifest=manifest)

        await admin_sdk.credit.set_algorithm(algorithm_version_id=device_visit_algorithm_version.id,
                                             algorithm_execution_price=0.01,
                                             algorithm_value_price=0.01)

        config = AlgorithmConfiguration()
        config.add_data_source(data_type=DataType.PINGS.value)

        device_visit_algorithm_config = await sdk.algorithm_config.create(
            algorithm_version_id=device_visit_algorithm_version.id,
            name="device_visit_test_{}".format(uuid.uuid4()), description="a description", algorithm_config=config)

        algorithm_computation = await sdk.algorithm_computation.create(
            aoi_collection_id=aoi_collection.id,
            toi_id=toi.id,
            algorithm_config_id=device_visit_algorithm_config.id)

        credit_estimate = await sdk.credit.estimate(algorithm_computation_id=algorithm_computation.id)
        logging.info("credit estimate: {}".format(credit_estimate))
        assert credit_estimate is not None
