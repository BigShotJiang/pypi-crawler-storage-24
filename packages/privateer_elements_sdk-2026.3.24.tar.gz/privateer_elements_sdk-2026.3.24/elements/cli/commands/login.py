import base64
import json
import time

import click

from elements.sdk.api.keycloak import Keycloak


@click.command(help="Authenticate with Keycloak using password grant and print tokens.")
@click.option('--username')
@click.option('--password')
@click.option('--offline/--no-offline', default=True, show_default=True, help='Request offline_access scope')
def login(username, password, offline):
    kc = Keycloak()

    if not username:
        username = click.prompt('Username', type=str)
    if not password:
        try:
            import getpass
            password = getpass.getpass('Password: ')
        except Exception:
            password = click.prompt('Password', hide_input=True)

    tokens = kc.password_login(
        username=username, password=password, offline_access=offline)

    access_token = tokens.get('access_token')
    refresh_token = tokens.get('refresh_token')

    click.secho('Login successful.', fg='green')
    if access_token:
        click.echo(f"Access token (truncated): {access_token[:20]}...")
    if refresh_token:
        click.echo(f"Refresh token (truncated): {refresh_token[:20]}...")
        # Show refresh token expiry if available
        secs = None
        if isinstance(tokens.get('refresh_expires_in'), (int, float, str)):
            try:
                secs = int(tokens['refresh_expires_in'])
            except Exception:
                secs = None
        if secs is not None:
            eta = time.time() + secs
            click.echo(f"Refresh expires in ~{secs/3600:.2f}h ({time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(eta))})")
        else:
            try:
                parts = refresh_token.split('.')
                if len(parts) >= 2:
                    b = parts[1]
                    b += '=' * (-len(b) % 4)
                    payload = json.loads(base64.urlsafe_b64decode(b))
                    exp = payload.get('exp')
                    if isinstance(exp, (int, float)):
                        secs = max(0, int(exp - time.time()))
                        click.echo(f"Refresh expires in ~{secs/3600:.2f}h ({time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(exp)))})")
            except Exception:
                pass
