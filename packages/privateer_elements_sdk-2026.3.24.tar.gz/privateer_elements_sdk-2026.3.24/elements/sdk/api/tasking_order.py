from elements_api import ElementsAsyncClient
from elements_api.models.tasking_order_pb2 import (
    TaskingOrderCreateRequest, TaskingOrder, TaskingOrderApproveRequest, TaskingOrderCancelRequest,
    TaskingOrderGetRequest, TaskingOrderListRequest
)
from elements_api.models.order_pb2 import OrderState
from elements.sdk.tools.sdk_support import SDKSupport


class APITaskingOrder:
    def __init__(self, client: ElementsAsyncClient, timeout):
        self.__timeout = timeout
        self.__client = client
        self.sdk_support = SDKSupport()

    async def create(self, orders: list[TaskingOrder]) -> list[TaskingOrder]:
        request = TaskingOrderCreateRequest(
            orders=orders
        )
        response = await self.__client.api.tasking_order.create(request)
        return response.orders

    async def approve(self, tasking_order_ids: list[str], comment: str) -> None:
        request = TaskingOrderApproveRequest(
            ids=tasking_order_ids,
            comment=comment
        )
        await self.__client.api.tasking_order.approve(request)

    async def cancel(self, tasking_order_ids: list[str]) -> None:
        request = TaskingOrderCancelRequest(
            ids=tasking_order_ids
        )
        await self.__client.api.tasking_order.cancel(request)

    async def get(self, tasking_order_id: str) -> TaskingOrder:
        request = TaskingOrderGetRequest(
            id=tasking_order_id
        )
        response = await self.__client.api.tasking_order.get(request)
        return response.order

    async def list(self, data_source_ids: list[str], states: list[OrderState], analysis_computation_ids: list[str],
                   algorithm_computation_ids: list[str]) -> list[TaskingOrder]:
        request = TaskingOrderListRequest(
            data_source_ids=data_source_ids,
            states=states if states else [],
            analysis_computation_ids=analysis_computation_ids,
            algorithm_computation_ids=algorithm_computation_ids
        )
        responses = await self.sdk_support.get_all_paginated_objects(request,
                                                                     api_function=self.__client.api.tasking_order.list,
                                                                     timeout=self.__timeout)
        tasking_orders = []
        for response in responses:
            tasking_orders.extend(response.orders)
        return tasking_orders
