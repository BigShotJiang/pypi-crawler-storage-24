from datetime import date, datetime, timezone
from typing import List, Optional

from google.protobuf.timestamp_pb2 import Timestamp

from elements_api import ElementsAsyncClient
from elements_api.models.project_pb2 import (
    Project, ProjectCreateRequest, ProjectGetRequest, ProjectUpdateRequest
)
from elements_api.models.project_analysis_config_pb2 import (
    ProjectAnalysisConfigUpdateRequest
)
from elements_api.models.project_collaborator_pb2 import (
    ProjectCollaborator, ProjectCollaboratorGetRequest,
    ProjectCollaboratorUpdateRequest
)
from elements_api.models.project_group_pb2 import (
    ProjectGroup, ProjectGroupCreateRequest
)


def _date_to_timestamp(d: date) -> Timestamp:
    """Convert a date to a protobuf Timestamp at midnight UTC."""
    ts = Timestamp()
    ts.FromDatetime(datetime(d.year, d.month, d.day, tzinfo=timezone.utc))
    return ts


class APIProject:

    def __init__(self, client: ElementsAsyncClient, timeout):
        self.__timeout = timeout
        self.__client = client

    async def create(self, name: str, description: str) -> Project:
        """
        Create a new project.

        :param name: Project name
        :param description: Project description
        :return: Project
        """
        request = ProjectCreateRequest(
            name=name,
            description=description
        )
        response = await self.__client.api.project.create(request, timeout=self.__timeout)
        return response.project

    async def get(self, project_id: str) -> Project:
        """
        Get a project by ID.

        :param project_id: The project ID
        :return: Project
        """
        request = ProjectGetRequest(id=project_id)
        response = await self.__client.api.project.get(request, timeout=self.__timeout)
        return response.project

    async def update(self, project_id: str, name: str, description: str,
                     start_date: Optional[date] = None,
                     end_date: Optional[date] = None) -> None:
        """
        Update a project.

        :param project_id: The project ID to update
        :param name: Project name
        :param description: Project description
        :param start_date: Optional start date
        :param end_date: Optional end date
        """
        project = Project(id=project_id, name=name, description=description)
        if start_date:
            project.start_date.CopyFrom(_date_to_timestamp(start_date))
        if end_date:
            project.end_date.CopyFrom(_date_to_timestamp(end_date))
        request = ProjectUpdateRequest(projects=[project])
        await self.__client.api.project.update(request, timeout=self.__timeout)



class APIProjectAnalysisConfig:

    def __init__(self, client: ElementsAsyncClient, timeout):
        self.__timeout = timeout
        self.__client = client

    async def update(self, project_id: str, analysis_config_ids: List[str]) -> None:
        """
        Link analysis configs to a project.

        :param project_id: The project to link configs to
        :param analysis_config_ids: List of analysis config IDs to link
        """
        request = ProjectAnalysisConfigUpdateRequest(
            project_id=project_id,
            analysis_config_ids=analysis_config_ids
        )
        await self.__client.api.project_analysis_config.update(request, timeout=self.__timeout)


class APIProjectCollaborator:

    def __init__(self, client: ElementsAsyncClient, timeout):
        self.__timeout = timeout
        self.__client = client

    async def update(self, project_id: str, user_id: str,
                     role: str = 'COLLABORATOR') -> None:
        """
        Share a project with a user.

        :param project_id: The project to share
        :param user_id: The user to share with
        :param role: Role to grant (COLLABORATOR or VIEWER)
        """
        role_enum = ProjectCollaborator.ProjectRole.Value(role)
        collaborator = ProjectCollaborator(user_id=user_id, role=role_enum)
        request = ProjectCollaboratorUpdateRequest(
            project_id=project_id,
            project_collaborators=[collaborator]
        )
        await self.__client.api.project_collaborator.update(request, timeout=self.__timeout)

    async def get(self, project_id: str) -> List[ProjectCollaborator]:
        """
        Get collaborators for a project.

        :param project_id: The project ID
        :return: List of ProjectCollaborator
        """
        request = ProjectCollaboratorGetRequest(project_id=project_id)
        response = await self.__client.api.project_collaborator.get(request, timeout=self.__timeout)
        return list(response.project_collaborators)


class APIProjectGroup:

    def __init__(self, client: ElementsAsyncClient, timeout):
        self.__timeout = timeout
        self.__client = client

    async def create(self, name: str, project_ids: List[str]) -> ProjectGroup:
        """
        Create a project group containing the specified projects.

        :param name: Group name
        :param project_ids: List of project IDs to include
        :return: ProjectGroup
        """
        request = ProjectGroupCreateRequest(
            name=name,
            project_ids=project_ids
        )
        response = await self.__client.api.project_group.create(request, timeout=self.__timeout)
        return response.project_group
