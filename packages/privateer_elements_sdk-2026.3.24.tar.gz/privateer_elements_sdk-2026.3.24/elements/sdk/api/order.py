from typing import Optional

from elements.sdk.tools.sdk_support import SDKSupport

from elements_api import ElementsAsyncClient
from elements_api.models.order_pb2 import Order, OrderCreateRequest, OrderApproveRequest, OrderCancelRequest, \
    OrderGetRequest, OrderListRequest, OrderState


class APIOrder:
    def __init__(self, client: ElementsAsyncClient, timeout):
        self.__timeout = timeout
        self.__client = client
        self.sdk_support = SDKSupport()

    async def create(self, orders: list[Order],
                     approve_order: bool = False) -> list[Order]:
        request = OrderCreateRequest(
            orders=orders,
            approve_order=approve_order
        )
        response = await self.__client.api.order.create(request)
        return response.orders

    async def approve(self, order_ids: list[str], comment: str) -> None:
        request = OrderApproveRequest(
            ids=order_ids,
            comment=comment
        )
        await self.__client.api.order.approve(request)

    async def cancel(self, order_ids: list[str]) -> None:
        request = OrderCancelRequest(
            ids=order_ids
        )
        await self.__client.api.order.cancel(request)

    async def get(self, order_id: str) -> Order:
        request = OrderGetRequest(
            id=order_id
        )
        response = await self.__client.api.order.get(request)
        return response.order

    async def list(self,
                   data_source_ids: list[str],
                   states: Optional[list[str]] = None,
                   analysis_computation_ids: Optional[list[str]] = None,
                   algorithm_computation_ids: Optional[list[str]] = None) -> list[Order]:
        ord_states = [OrderState.Value(s) for s in states] if states else []
        request = OrderListRequest(
            data_source_ids=data_source_ids,
            states=ord_states,
            analysis_computation_ids=analysis_computation_ids,
            algorithm_computation_ids=algorithm_computation_ids
        )
        responses = await self.sdk_support.get_all_paginated_objects(request,
                                                                     api_function=self.__client.api.order.list,
                                                                     timeout=self.__timeout)
        orders = []
        for response in responses:
            orders.extend(response.orders)
        return orders
