import os
from typing import Dict

import requests


class Keycloak:
    """Keycloak OIDC client for password-grant flow.

    Config resolution (base URL):
    1. Explicit ``base`` argument
    2. ``OIDC_BASE_URL`` env var (same as ElementsBaseApi)
    3. Derived from ``TERRASCOPE_API_HOST`` or ``ELEMENTS_HOST`` (replace subdomain with 'keycloak')
    4. Default: https://keycloak.orbitalinsight.com
    """

    def __init__(self, base=None, realm=None, client_id=None):
        if base is None:
            base = os.getenv('OIDC_BASE_URL')
        if base is None:
            api_host = os.getenv('TERRASCOPE_API_HOST') or os.getenv('ELEMENTS_HOST')
            if api_host:
                parts = api_host.split('.', 1)
                if len(parts) == 2:
                    base = f"https://keycloak.{parts[1]}"
        if base is None:
            base = 'https://keycloak.orbitalinsight.com'

        self.base = base
        self.realm = realm or os.getenv('OIDC_REALM', 'elements')
        self.client_id = client_id or os.getenv('KEYCLOAK_CLIENT_ID', 'login-direct')

    @property
    def token_endpoint(self):
        return f"{self.base}/realms/{self.realm}/protocol/openid-connect/token"

    def password_login(self, username, password, offline_access=False) -> Dict:
        """Direct Access Grants (password grant) against the Keycloak token endpoint."""
        scope = 'openid offline_access' if offline_access else 'openid'

        data = {
            'grant_type': 'password',
            'username': username,
            'password': password,
            'client_id': self.client_id,
            'scope': scope,
        }

        resp = requests.post(
            self.token_endpoint, data=data,
            headers={'Content-Type': 'application/x-www-form-urlencoded'})
        resp.raise_for_status()
        return resp.json()
