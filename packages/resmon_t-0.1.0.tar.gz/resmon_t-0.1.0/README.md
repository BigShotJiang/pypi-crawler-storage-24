# SRM - Simple Resource Monitor

A lightweight, easy-to-use system resource monitoring tool for the command line.

## Features

- CPU Monitoring: Real-time CPU usage per core with averages
- Memory Tracking: RAM and swap usage with visual bars
- Disk Usage: Filesystem space monitoring with warnings
- Process Insights: Top processes by CPU/memory
- Cross-Platform: Works on Linux, macOS, and Windows

## Installation

```bash
pip install srm
```

## Usage

```bash
srm              # Single snapshot
srm --watch 2    # Continuous monitoring
srm --json       # JSON output
srm --top 10     # Show top 10 processes
```

## License

MIT
