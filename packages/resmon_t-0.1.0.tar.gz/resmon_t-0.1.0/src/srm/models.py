"""Data models for resource metrics."""

from dataclasses import dataclass, field
from typing import List
import json


@dataclass
class CPUMetrics:
    percent: float = 0.0
    per_core: List[float] = field(default_factory=list)
    count: int = 0
    load_avg: List[float] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            "percent": round(self.percent, 1),
            "per_core": [round(c, 1) for c in self.per_core],
            "count": self.count,
            "load_avg": [round(l, 2) for l in self.load_avg],
        }


@dataclass
class MemoryMetrics:
    total: int = 0
    available: int = 0
    used: int = 0
    percent: float = 0.0
    swap_total: int = 0
    swap_used: int = 0
    swap_percent: float = 0.0
    
    def to_dict(self) -> dict:
        return {
            "total_gb": round(self.total / (1024**3), 2),
            "available_gb": round(self.available / (1024**3), 2),
            "used_gb": round(self.used / (1024**3), 2),
            "percent": round(self.percent, 1),
        }


@dataclass
class DiskMetric:
    path: str = ""
    total: int = 0
    used: int = 0
    free: int = 0
    percent: float = 0.0
    mountpoint: str = ""
    
    def to_dict(self) -> dict:
        return {
            "path": self.path,
            "total_gb": round(self.total / (1024**3), 2),
            "used_gb": round(self.used / (1024**3), 2),
            "percent": round(self.percent, 1),
        }


@dataclass
class DiskMetrics:
    partitions: List[DiskMetric] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {"partitions": [p.to_dict() for p in self.partitions]}


@dataclass
class NetworkMetrics:
    bytes_sent: int = 0
    bytes_recv: int = 0
    connections: int = 0
    
    def to_dict(self) -> dict:
        return {
            "bytes_sent_mb": round(self.bytes_sent / (1024**2), 2),
            "bytes_recv_mb": round(self.bytes_recv / (1024**2), 2),
            "connections": self.connections,
        }


@dataclass
class ProcessInfo:
    pid: int = 0
    name: str = ""
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    
    def to_dict(self) -> dict:
        return {
            "pid": self.pid,
            "name": self.name,
            "cpu_percent": round(self.cpu_percent, 1),
            "memory_percent": round(self.memory_percent, 1),
        }


@dataclass
class AllMetrics:
    cpu: CPUMetrics = field(default_factory=CPUMetrics)
    memory: MemoryMetrics = field(default_factory=MemoryMetrics)
    disk: DiskMetrics = field(default_factory=DiskMetrics)
    network: NetworkMetrics = field(default_factory=NetworkMetrics)
    top_processes: List[ProcessInfo] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        return {
            "cpu": self.cpu.to_dict(),
            "memory": self.memory.to_dict(),
            "disk": self.disk.to_dict(),
            "network": self.network.to_dict(),
            "top_processes": [p.to_dict() for p in self.top_processes],
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)
