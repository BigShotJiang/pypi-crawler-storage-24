from .client import SecretAI
from .crypto import generate_key

__version__ = "0.1.0"
__all__ = ["SecretAI", "generate_key"]
