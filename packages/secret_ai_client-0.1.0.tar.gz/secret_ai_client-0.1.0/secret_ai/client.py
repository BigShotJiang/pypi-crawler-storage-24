import requests
import os
from .crypto import encrypt_message, decrypt_message
from .file_handler import read_task, write_response

# URL сервера по умолчанию (можно переопределить через ENV)
DEFAULT_SERVER_URL = "https://api.your-domain.com/v1/solve"

class SecretAI:
    @staticmethod
    def solve():
        """
        Основной метод: читает task.txt, шифрует, отправляет на сервер,
        расшифровывает ответ и записывает обратно в файл.
        """
        server_url = os.getenv("SECRET_AI_SERVER_URL", DEFAULT_SERVER_URL)

        try:
            # 1. Чтение промпта
            print("📖 Чтение task.txt...")
            user_prompt = read_task()

            # 2. Шифрование
            print("🔒 Шифрование данных...")
            encrypted_payload = encrypt_message(user_prompt)

            # 3. Отправка на сервер
            print(f"📡 Отправка запроса на {server_url}...")
            response = requests.post(
                server_url,
                json={"prompt": encrypted_payload},
                headers={"Content-Type": "application/json"},
                timeout=120  # 2 минуты на ответ от LLM
            )

            if response.status_code != 200:
                raise Exception(f"Ошибка сервера: {response.status_code} - {response.text}")

            data = response.json()
            encrypted_response = data.get("response")

            if not encrypted_response:
                raise ValueError("Сервер не вернул зашифрованный ответ (ключ 'response' отсутствует)")

            # 4. Расшифровка
            print("🔓 Расшифровка ответа...")
            decrypted_response = decrypt_message(encrypted_response)

            # 5. Запись в файл
            print("💾 Запись ответа в task.txt...")
            write_response(decrypted_response)

            print("✅ Готово! Ответ успешно записан.")

        except FileNotFoundError as e:
            print(f"❌ Ошибка файла: {e}")
            raise
        except Exception as e:
            print(f"❌ Критическая ошибка: {e}")
            raise
