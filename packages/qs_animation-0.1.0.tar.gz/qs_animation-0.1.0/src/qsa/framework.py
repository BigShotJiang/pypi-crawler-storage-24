import time
import typing
from collections import deque
from typing import Callable, Any, runtime_checkable

EaseFunction = typing.Callable[[float], float]
number = int | float


@runtime_checkable
class SupportAnimationMethods(typing.Protocol):
    def start(self, start_time=None): ...

    def update(self, current_time=None): ...

    def stop(self): ...

    def is_finished(self, current_time=None) -> bool: ...

    duration: number | None
    start_time: number | None
    running: bool


class AnimationBase[T](SupportAnimationMethods):
    start_time: float | int | None

    def __init__(
            self,
            start=None, end=None, easing=None,
            duration=None
    ):
        self._start = start
        self._end = end
        self._delta = end - start if start and end else None
        self._duration = duration
        self._easing = easing
        self.start_time = None
        self.value = None

    @property
    def running(self):
        return self.start_time is not None

    @property
    def easing(self) -> T:
        return self._easing

    @easing.setter
    def easing(self, easing: EaseFunction):
        self._easing = easing

    @property
    def duration(self) -> number:
        return self._duration

    @duration.setter
    def duration(self, duration: number):
        self._duration = duration

    @property
    def start_value(self) -> T:
        return self._start

    @property
    def end_value(self) -> T:
        return self._end

    @property
    def delta(self) -> T | Any:
        return self._delta

    @start_value.setter
    def start_value(self, v: T):
        if self.start_time:
            raise RuntimeError('Animation already started')

        self._start = v
        self.compute_delta()

    @end_value.setter
    def end_value(self, v: T):
        if self.start_time:
            raise RuntimeError('Animation already finished')

        self._end = v
        self.compute_delta()

    def compute_delta(self):
        self._delta = self.end_value - self.start_value

    def update(self, current_time=None):
        current_time = current_time or time.time()

        if (current_time - self.start_time) >= self.duration:
            self.value = self.end_value
            self.stop()
            return self.value

        x = (current_time - self.start_time) / self.duration
        # print(f'({current_time} - {self.start_time}) / {self.duration} = {x}')
        if self.easing is not None:
            x = self.easing(x)

        self.value = self._delta * x
        return self.value

    def start(self, start_time=None):
        self.start_time = start_time or time.time()

    def stop(self):
        self.start_time = None

    def is_finished(self, current_time=None) -> bool:
        if self.start_time is None:
            return True

        current_time = current_time or time.time()

        return (current_time - self.start_time) >= self.duration


class ParallelAnimation(SupportAnimationMethods):
    def __init__(self, *animations):
        self.animations = animations
        self.start_time = None

    def start(self, start_time=None):
        self.start_time = start_time or time.time()

    def stop(self):
        self.start_time = None

    def update(self, current_time=None) -> Any:
        current_time = current_time or time.time()
        for a in self.animations:
            a.update(current_time)


class SequentialAnimation(SupportAnimationMethods):
    def __init__(self, *animations: SupportAnimationMethods):
        self.animations = animations
        self.index = 0
        self.start_time = None


    def start(self, start_time=None):
        self.start_time = start_time or time.time()

        for animation in self.animations:
            animation.start(start_time)
            start_time += animation.duration

    def update(self, current_time=None) -> Any:
        current_time = current_time or time.time()
        while self.index < len(self.animations):
            animation = self.animations[self.index]

            if animation.is_finished(current_time):
                self.index += 1
                # continue
            else:
                animation.update(current_time)
                return

    def stop(self):
        for animation in self.animations:
            animation.stop()

        self.start_time = None


class AnimationPool:
    def __init__(self):
        self.animations = deque()

    def push(self, animation: SupportAnimationMethods):
        animation.start()
        self.animations.append(animation)

    def update(self, current_time=None) -> Any:
        current_time = current_time or time.time()

        n = len(self.animations)
        for i in range(n):
            a = self.animations.popleft()
            a.update(current_time)
            if not a.is_finished(current_time):
                self.animations.append(a)
