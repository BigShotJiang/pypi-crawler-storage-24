import numbers



class Vector:
    __slots__ = ['__data', '__length']

    def __init__(self, *args):
        self.__data = args
        self.__length = len(args)

    def __add__(self, other):
        result = [None] * self.__length
        for i in range(0, self.__length):
            result[i] = self.__data[i] + other.__data[i]
        return self.__class__(*result)

    def __sub__(self, other):
        result = [None] * self.__length
        for i in range(0, self.__length):
            result[i] = self.__data[i] - other.__data[i]

        return self.__class__(*result)

    def __mul__(self, other):
        result = [None] * self.__length
        if isinstance(other, Vector):
            for i in range(0, self.__length):
                result[i] = self.__data[i] * other.__data[i]

            # return Vector(*result)
        elif isinstance(other, numbers.Number):
            for i in range(0, self.__length):
                result[i] = self.__data[i] * other

        else:
            raise TypeError(other)

        return self.__class__(*result)

    def __str__(self):
        return f'{self.__class__.__name__}{self.__data!r}'

    def __getattr__(self, item):
        if len(item) <= 1:
            raise AttributeError(name=item, obj=self)

        return Vector(

        )

    def __iter__(self):
        return self.__data.__iter__()

    def __init_subclass__(cls, **kwargs):
        annotations = cls.__annotations__
        if annotations:
            for i, name in enumerate(annotations):
                setattr(
                    cls, name,
                    property(
                        lambda self: self.__data[i]
                    )
                )

            length = len(annotations)

            def __new__(cls, *args):
                if len(args) > length:
                    raise TypeError("Too many arguments")
                return super().__new__(cls)

            cls.__new__ = __new__

