from qsa.vector import Vector

number = int | float


class RGB(Vector):
    r: number
    g: number
    b: number


class RGBA(Vector):
    r: number
    g: number
    b: number
    a: number


class Rect(Vector):
    left: number
    top: number
    width: number
    height: number
