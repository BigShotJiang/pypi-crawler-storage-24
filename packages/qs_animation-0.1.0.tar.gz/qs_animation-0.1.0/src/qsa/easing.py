import math

def ease_in_sine(x):
    return 1 - math.cos((x * math.pi) / 2)


def ease_out_sine(x):
    return math.sin((x * math.pi) / 2)


def ease_in_out_sine(x):
    return -(math.cos(math.pi * x) - 1) / 2


def ease_in_quad(x):
    return x * x


def ease_out_quad(x):
    return 1 - (1 - x) ** 2


def ease_in_out_quad(x):
    return x ** 2 * 2 if x < 0.5 else 1 - (-2 * x + 2) ** 2 / 2


def ease_in_cubic(x):
    return math.pow(x, 3)


def ease_out_cubic(x):
    return 1 - math.pow(1 - x, 3)


def ease_in_out_cubic(x):
    return 4 * x ** 3 if x < 0.5 else 1 - math.pow(-2 * x + 2, 3) / 2


def ease_in_quart(x):
    return x ** 4


def ease_out_quart(x):
    return 1 - (1 - x) ** 4


def ease_in_out_quart(x):
    return 8 * x ** 4 if x < 0.5 else 1 - (-2 * x + 2) ** 4 / 2


def ease_in_quint(x):
    return x ** 5


def ease_out_quint(x):
    return 1 - (1 - x) ** 5


def ease_in_out_quint(x):
    return 16 * x ** 5 if x < 0.5 else 1 - (-2 * x + 2) ** 5 / 2


def ease_in_expo(x):
    if x == 0:
        return 0
    else:
        return math.pow(2, 10 * x - 10)


def ease_out_expo(x):
    return 1 if x == 1 else 1 - math.pow(2, -10 * x)


def ease_in_out_expo(x):
    if x == 1:
        return 1
    if x == 0:
        return 0

    if x < 0.5:
        return math.pow(2, 20 * x - 10) / 2
    else:
        return (2 - math.pow(2, -20 * x + 10)) / 2



def ease_in_circ(x):
    return 1 - math.sqrt(1 - x ** 2)


def ease_out_circ(x):
    return math.sqrt(1 - (x - 1) ** 2)


def ease_in_out_circ(x):
    return (1 - math.sqrt(1 - (2 * x) ** 2)) / 2 if x < 0.5 \
        else (math.sqrt(1 - (-2 * x + 2) ** 2) + 1) / 2


c1 = 1.70158
c3 = c1 + 1


def ease_in_back(x):
    return c3 * x ** 3 - c1 * x ** 2


def ease_out_back(x):
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2


c2 = c1 * 1.525


def ease_in_out_back(x):
    if x < 0.5:
        return ((2 * x) ** 2 * ((c2 + 1) * 2 * x - c2)) / 2
    else:
        return ((2 * x - 2) ** 2 * ((c2 + 1) * (x * 2 - 2) + c2) + 2) / 2


c4 = (2 * math.pi) / 3


def ease_in_elastic(x):
    if x == 0 or x == 1:
        return x
    else:
        return -math.pow(2, 10 * x - 10) * math.sin((x * 10 - 10.75) * c4)


def ease_out_elastic(x):
    if x == 0 or x == 1:
        return x
    else:
        return math.pow(2, -10 * x) * math.sin((x * 10 - 0.75) * c4) + 1


c5 = (2 * math.pi) / 5


def ease_in_out_elastic(x):
    if x == 0 or x == 1:
        return x
    elif x < 0.5:
        return -math.pow(2, 20 * x - 10) * math.sin((20 * x - 11.125) * c5) / 2
    else:
        return math.pow(2, -20 * x + 10) * math.sin((20 * x - 11.125) * c5) / 2 + 1


def ease_in_bounce(x):
    return 1 - ease_out_bounce(x)


n1 = 7.5625
d1 = 2.75

k1 = 1 / d1
k2 = 2 / d1
k3 = 2.5 / d1

t1 = 1.5 / d1
t2 = 2.25 / d1
t3 = 2.625 / d1


def ease_out_bounce(x):
    if x < k1:
        return n1 * x ** 2
    elif x < k2:
        return n1 * (x - t1) ** 2 + 0.75
    elif x < k3:
        return n1 * (x - t2) ** 2 + 0.9375
    else:
        return n1 * (x - t3) ** 2 + 0.984375


def ease_in_out_bounce(x):
    if x < 0.5:
        return (1 - ease_out_bounce(1 - 2 * x)) / 2
    else:
        return (1 + ease_out_bounce(2 * x - 1)) / 2
