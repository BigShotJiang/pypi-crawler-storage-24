import colorama

from qsa import *

animation = AnimationBase(
    RGB(0, 0, 0),
    RGB(255, 0, 128),
    easing=ease_in_out_elastic,
    duration=2
)


animation.start()
cnt = 0
while animation.running:
    animation.update()
    print(animation.value)
    cnt += 1

print(cnt)
print(cnt / 2)

# print(animation.value)