import time
import timeit


class A:
    __slots__ = ['x', 'y']
    def __init__(self, x, y):
        self.x = x
        self.y = y


class B:
    def __init__(self, x, y):
        self.x = x
        self.y = y

a = A(1, 2)
b = B(1, 2)

print(
    timeit.repeat(
        "a.x ; a.y ; a.x = 0 ; a.y = 0", globals=globals(), timer=time.perf_counter_ns
    ),
    timeit.repeat(
        "b.x ; b.y ; b.x = 0 ; b.y = 0", globals=globals(), timer=time.perf_counter_ns
    ),
    sep='\n'
)