import time

from qsa.basic_data_types import *
from qsa.framework import AnimationBase, SimpleAnimation, AnimationPool
from qsa.easing import *


rgb_start = RGB()
rgb_end = RGB(255,255,255)

rgba_start = RGBA()
rgba_end = RGBA(255,255,255, 100)

rect_start = Rect()
rect_end = Rect(800, 380, 320, 320)

rgb_animation = SimpleAnimation(rgb_start, rgb_end, easing=ease_in_expo, duration=1)
rgba_animation = SimpleAnimation(rgba_start, rgba_end, easing=ease_out_expo, duration=1)
rect_animation = SimpleAnimation(rect_start, rect_end, easing=ease_in_out_bounce, duration=1)

rgb_animation.update_callback = rgba_animation.update_callback = rect_animation.update_callback = \
    lambda v: print("Update value:", v)

pool = AnimationPool()
pool.push(rgb_animation)
pool.push(rgba_animation)
pool.push(rect_animation)

while not (rgb_animation.is_finished() and rgba_animation.is_finished() and rect_animation.is_finished()):
    cur = time.time()
    pool.update(cur)
    time.sleep(0.3)
