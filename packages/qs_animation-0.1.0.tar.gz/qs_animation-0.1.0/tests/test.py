import matplotlib.pyplot as plt
import numpy as np
import curses

from qsa import easing

x = np.arange(0, 1, 0.01)


def show_result(y, name):
    plt.figure(figsize=(6.4, 6.4))
    plt.plot(x, y, label=name)
    plt.legend()

def test_all():
    for name, func in filter(
            lambda i: i[0].startswith('ease_'),
            vars(easing).items()
    ):
        func = np.vectorize(func, otypes=[np.float64, ])
        y = func(x)
        show_result(y, name)

def test_one(name):
    func = np.vectorize(
        getattr(easing, f'ease_{name}'), otypes=[np.float64, ]
    )
    y = func(x)
    # print(y)
    show_result(y, name)


def main():
    # stdcur.clear()
    # stdcur.refresh()
    # stdcur.keypad(False)

    # test_one('in_out_back')
    test_all()



main()



plt.show(width=1366, heigth=768)
