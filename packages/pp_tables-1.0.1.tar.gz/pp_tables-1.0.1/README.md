# pp-tables

A lightweight Python library for formatting data as beautiful, colored tables in the terminal.

## Features

- Simple API for creating formatted tables
- ANSI color support with automatic terminal detection
- Configurable column alignment, padding, and borders
- Works with lists of dicts, lists of lists, or pandas DataFrames

## Installation

```bash
pip install pp-tables
```

## Quick Start

```python
from pp_tables import PrettyTable, Color

# Create a table from data
data = [
    {"name": "Alice", "score": 95, "grade": "A"},
    {"name": "Bob", "score": 87, "grade": "B+"},
    {"name": "Charlie", "score": 72, "grade": "C"},
]

table = PrettyTable(data)
print(table.render(color=Color.GREEN))
```

## API Reference

### `PrettyTable(data, headers=None)`

Create a table from data (list of dicts or list of lists).

### `table.render(color=None, border=True, padding=1)`

Render the table as a formatted string.

### `format_table(data, headers=None, color=None)`

One-liner convenience function.

### `colorize(text, color)`

Apply ANSI color to text.

## License

MIT
