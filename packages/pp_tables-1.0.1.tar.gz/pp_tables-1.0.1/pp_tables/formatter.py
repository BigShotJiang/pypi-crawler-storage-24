"""Table formatting utilities for terminal display."""

from typing import Any

from .colors import Color, colorize, supports_color


class PrettyTable:
    """Format tabular data for terminal display with optional color support."""

    def __init__(self, data: list[dict[str, Any]] | list[list[Any]], headers: list[str] | None = None):
        if not data:
            self._headers = headers or []
            self._rows = []
            return

        if isinstance(data[0], dict):
            self._headers = headers or list(data[0].keys())
            self._rows = [[str(row.get(h, "")) for h in self._headers] for row in data]
        else:
            self._headers = headers or [f"Col {i}" for i in range(len(data[0]))]
            self._rows = [[str(cell) for cell in row] for row in data]

    def render(self, color: str | None = None, border: bool = True, padding: int = 1) -> str:
        """Render the table as a formatted string.

        Args:
            color: ANSI color code to apply to headers (e.g. Color.GREEN)
            border: Whether to draw box borders
            padding: Cell padding (spaces on each side)

        Returns:
            Formatted table string
        """
        if not self._headers and not self._rows:
            return ""

        # Calculate column widths
        all_rows = [self._headers] + self._rows
        col_widths = [
            max(len(str(row[i])) for row in all_rows) + padding * 2
            for i in range(len(self._headers))
        ]

        pad = " " * padding
        lines = []

        if border:
            top = "┌" + "┬".join("─" * w for w in col_widths) + "┐"
            mid = "├" + "┼".join("─" * w for w in col_widths) + "┤"
            bot = "└" + "┴".join("─" * w for w in col_widths) + "┘"
            lines.append(top)

        # Header row
        header_cells = []
        for i, h in enumerate(self._headers):
            cell = f"{pad}{h:<{col_widths[i] - padding * 2}}{pad}"
            if color:
                cell = colorize(cell, color)
            header_cells.append(cell)
        if border:
            lines.append("│" + "│".join(header_cells) + "│")
            lines.append(mid)
        else:
            lines.append(" ".join(header_cells))
            lines.append("-" * sum(col_widths))

        # Data rows
        for row in self._rows:
            cells = []
            for i, cell in enumerate(row):
                cells.append(f"{pad}{cell:<{col_widths[i] - padding * 2}}{pad}")
            if border:
                lines.append("│" + "│".join(cells) + "│")
            else:
                lines.append(" ".join(cells))

        if border:
            lines.append(bot)

        return "\n".join(lines)

    def __str__(self) -> str:
        return self.render()


def format_table(
    data: list[dict[str, Any]] | list[list[Any]],
    headers: list[str] | None = None,
    color: str | None = None,
    border: bool = True,
    padding: int = 1,
) -> str:
    """One-liner convenience function for formatted table output.

    Args:
        data: List of dicts or list of lists
        headers: Column headers (auto-detected from dict keys if not provided)
        color: ANSI color for headers
        border: Draw box borders
        padding: Cell padding

    Returns:
        Formatted table string
    """
    return PrettyTable(data, headers).render(color=color, border=border, padding=padding)
