# oi-tools

[See the documentation for more info](https://opportunityinsights.github.io/oi-tools)

## Installation

To install the most recent version of the package from PyPI:

```bash
# using uv (recommended)
uv add oi-utils

# using pip
pip install oi-utils
```

We require at least Python 3.9.

## Usage

See the `examples` directory for usage examples (documentation coming soon).

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md).

