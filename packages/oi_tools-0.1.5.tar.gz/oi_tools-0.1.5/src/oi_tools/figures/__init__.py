"""Constants and utility functions related to making figures."""

from oi_tools.figures._colors import OIColors, view_colors
from oi_tools.figures._helpers import (
    DEFAULT_FILETYPES,
    save_figure,
    save_figures_to_folder,
    save_figures_to_pdf,
    set_default_filetypes,
)

__all__ = [
    "OIColors",
    "view_colors",
    "DEFAULT_FILETYPES",
    "save_figure",
    "save_figures_to_folder",
    "save_figures_to_pdf",
    "set_default_filetypes",
]
