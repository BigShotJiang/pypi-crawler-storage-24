from __future__ import annotations

import json
import shutil
import subprocess
import time
from collections.abc import Collection
from pathlib import Path

import humanfriendly as hf
import polars as pl


class BatchJobError(Exception):
    """PBS batch job exited with non-zero status."""

    pass


def sh(*args: str) -> str:
    """Run the arguments as a shell subprocess and return its output.

    Parameters
    ----------
    *args
        Command and arguments to execute.

    Returns
    -------
    str
        The stripped stdout of the subprocess.
    """
    return subprocess.check_output(args, text=True).strip()


def get_all_jobs() -> "pl.DataFrame":
    """Retrieve a Polars DataFrame of all PBS jobs for the current user.

    Returns
    -------
    pl.DataFrame
        A DataFrame containing job metadata.
    """
    # TODO: allow getting past jobs
    # TODO: allow filtering by user

    qstat = sh("qstat", "-f", "-Fjson")
    jobs = json.loads(qstat)["Jobs"]

    user = sh("whoami")

    return (
        pl.json_normalize(jobs.values(), infer_schema_length=None)
        .with_columns(
            id=pl.Series(jobs.keys()),
            owner=pl.col("Job_Owner").str.extract(r"(.*)@.*"),
        )
        .filter(owner=user)
    )


def wait_for_job(
    job_ids: Collection[str],
    polling_delay: int = 5,  # in seconds
    stop_on_error: bool = True,
) -> str:
    """Watch the specified jobs and return the ID of the first to finish.

    Parameters
    ----------
    job_ids
        PBS job IDs to monitor.
    polling_delay
        Seconds to wait between status checks. Default is 5.
    stop_on_error
        If ``True``, raise ``BatchJobError`` when a job exits with non-zero
        status. Default is ``True``.

    Returns
    -------
    str
        The job ID of the first job to finish.

    Raises
    ------
    BatchJobError
        If a job exits with non-zero status and ``stop_on_error`` is ``True``.
    """
    while True:
        finished_jobs = job_exit_status(*job_ids)

        if not len(finished_jobs):
            # everything still running
            time.sleep(polling_delay)
            continue

        jobid, status = finished_jobs.popitem()

        if status > 0 and stop_on_error:
            raise BatchJobError(f"Job {jobid} failed with status {status}")

        return jobid


def job_exit_status(*jobids: str | int, retries: int = 5) -> dict[str, int]:
    """Retrieve the exit status for a set of PBS jobs.

    Parameters
    ----------
    *jobids
        PBS job IDs to query.
    retries
        Number of times to retry on failure. Default is 5.

    Returns
    -------
    dict[str, int]
        Mapping of job ID to exit status, for jobs that have completed.

    Raises
    ------
    RuntimeError
        If status cannot be retrieved after all retries.
    """
    for i in range(retries):
        try:
            jobs = json.loads(sh("qstat", *map(str, jobids), "-fxFjson"))["Jobs"]
            return {
                name: job.get("Exit_status")
                for name, job in jobs.items()
                if "Exit_status" in job
            }
        except Exception:
            print("Failed to get job status. Trying again in a few seconds...")
            time.sleep(5)
    else:
        raise RuntimeError(f"Unable to get status of PBS jobs in {retries} tries")


def get_python() -> Path:
    """Get the current Python executable.

    Returns
    -------
    Path
        Absolute path to the Python executable.

    Raises
    ------
    ValueError
        If no Python executable is found.
    """
    python = shutil.which("python3") or shutil.which("python")

    if python is None:
        raise ValueError("no python executable found")

    return Path(python).absolute()


def get_stata() -> Path:
    """Get the current Stata executable, preferring faster versions.

    Returns
    -------
    Path
        Absolute path to the Stata executable.

    Raises
    ------
    ValueError
        If no Stata executable is found.
    """
    stata = (
        shutil.which("stata-mp")
        or shutil.which("stata-se")
        or shutil.which("stata-be")
        or shutil.which("stata")
    )

    if stata is None:
        raise ValueError("no stata executable found")

    return Path(stata).absolute()


def get_rscript() -> Path:
    """Get the current Rscript executable.

    Returns
    -------
    Path
        Absolute path to the Rscript executable.

    Raises
    ------
    ValueError
        If no Rscript executable is found.
    """
    r = shutil.which("Rscript")

    if r is None:
        raise ValueError("no Rscript executable found")

    return Path(r).absolute()


def format_disc_size(size: str) -> str:
    """Format a disk size string for user-facing display.

    Parameters
    ----------
    size
        A size string (e.g. ``"4gb"``).

    Returns
    -------
    str
        A human-readable size string (e.g. ``"4 GB"``).
    """
    return hf.format_size(hf.parse_size(size))


def format_path(path: Path | str) -> str:
    """Format a path for user-facing display.

    Returns the shorter of the absolute path and the path relative to the
    current working directory.

    Parameters
    ----------
    path
        The path to format.

    Returns
    -------
    str
        A string representation of the path.
    """
    if not isinstance(path, Path):
        path = Path(path)

    path = path.absolute()

    try:
        relative = path.relative_to(Path.cwd())
        if len(str(relative)) < len(str(path)):
            path = relative

    except ValueError:
        pass

    return str(path)


def _escape(s: str | int | float | Path) -> str:
    """Wrap a value in single quotes, escaping any single quotes within."""
    return "'" + str(s).replace("'", r"\'") + "'"
