"""Functions for submiting and monitoring jobs in a PBS queue."""

import typer

from oi_tools.pbs._list import list_jobs
from oi_tools.pbs._sub import submit_job, submit_many_jobs

__all__ = [
    "submit_many_jobs",
    "submit_job",
]


def main() -> None:
    app = typer.Typer(
        help="Submit and query PBS jobs.",
        epilog="[dim]Written by Alistair Pattison in Summer 2025 and incorporated into oi-tools in Spring 2026",
        rich_markup_mode="rich",
    )
    app.command("list")(list_jobs)
    app.command("sub")(submit_job)
    app()
