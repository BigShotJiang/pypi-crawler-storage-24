"""Tests for session management."""
