# sf-log-analyzer

MCP server for Salesforce debug log analysis. Connect to any Salesforce org, set up log capture, scan logs for errors, and search log content — all from your AI-powered editor (Cursor, VS Code, etc.).

## Quick Start

Add to your `.cursor/mcp.json` or `.vscode/mcp.json`:

```json
{
  "mcpServers": {
    "sf-log-analyzer": {
      "command": "uv",
      "args": ["tool", "run", "--python", ">=3.10", "sf-log-analyzer"]
    }
  }
}
```

Requires [uv](https://docs.astral.sh/uv/getting-started/installation/) installed. Works on macOS, Linux, and Windows. No other setup needed.

## Tools (16 total)

### Connection
- **sf_list_orgs** — List Salesforce CLI-authorized orgs
- **sf_connect_org** — Connect via CLI alias
- **sf_connect** — Connect via raw session ID (for subscriber/ISV orgs)
- **sf_disconnect** — Disconnect and clear cache

### Log Capture Setup
- **sf_list_users** — List active users
- **sf_list_debug_levels** — List existing debug levels
- **sf_create_debug_level** — Create a new debug level
- **sf_setup_logging** — One-step: create debug level + trace flag
- **sf_list_trace_flags** — List active trace flags
- **sf_create_trace_flag** — Create a trace flag
- **sf_delete_trace_flag** — Delete a trace flag

### Debug Log Analysis
- **sf_list_logs** — List debug logs (with filters)
- **sf_get_log** — Fetch full log body
- **sf_scan_log** — Scan a log for errors, exceptions, governor limits
- **sf_scan_all_logs** — Batch scan with summary
- **sf_search_log** — Full-text search within a log

## Requirements

- Python 3.10+
- Salesforce CLI (`sf`) for CLI-based connections (optional)

## License

MIT
