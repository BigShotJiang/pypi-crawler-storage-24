from typing import Optional
from itertools import combinations

import numpy as np
from cvxopt import matrix, solvers

from vicentin.kernels import Kernel, LinearKernel
from vicentin.optimization.problems import QP
from vicentin.machine_learning.classification.SVM import SMO


def _get_alpha0(y, C):
    pos_mask = y == 1
    neg_mask = y == -1
    n_pos = pos_mask.sum()
    n_neg = neg_mask.sum()

    epsilon = 0.01 if np.isinf(C) else 0.05 * C

    alpha0 = np.zeros_like(y, dtype=float)
    alpha0[pos_mask] = epsilon

    val_neg = (n_pos * epsilon) / n_neg
    alpha0[neg_mask] = -val_neg

    if not np.isinf(C) and val_neg >= C:
        scale = (0.9 * C) / val_neg
        alpha0 *= scale

    return alpha0


def _train_binary(
    X, y, kernel, lambda_, C, smo_threshold, vicentin_qp, **kwargs
):
    n = int(X.shape[0])
    y = np.asarray(y, dtype=float)

    if C is None:
        C = 1 / (lambda_ * n)

    if n > smo_threshold:
        return SMO(X, y, kernel, C, is_l2=True, **kwargs)

    P = kernel[:, :].copy() if isinstance(kernel, np.ndarray) else kernel(X, X)
    P += np.eye(n) / (2 * C)
    q = -y

    G = -np.diag(y).reshape(n, n)
    h = np.zeros(n)

    A = np.ones((1, n))
    b_eq = np.zeros(1)

    if vicentin_qp:
        alpha0 = _get_alpha0(y, C)
        alpha, duals = QP(
            P, q, alpha0, G, h, A, b_eq, return_dual=True, **kwargs
        )
        b = float(duals[1][0])
    else:
        solvers.options["show_progress"] = False

        P = matrix(P)
        q = matrix(q)
        G = matrix(G)
        h = matrix(h)
        A = matrix(A, (1, n))
        b_eq = matrix(0.0)

        sol = solvers.qp(P, q, G, h, A, b_eq)

        alpha = np.array(sol["x"]).flatten()
        b = float(sol["y"][0])

    return alpha, b


def L2_SVM(
    X: np.ndarray | Kernel,
    y: np.ndarray,
    lambda_: float = 1,
    C: Optional[float] = None,
    strategy: str = "ovo",
    smo_threshold: int = 10_000,
    vicentin_qp: bool = False,
    **kwargs,
):
    if isinstance(X, Kernel):
        kernel = X
        X_data = kernel.X
    else:
        kernel = LinearKernel(X)
        X_data = X

    y = y.flatten()
    classes = np.unique(y)

    if len(classes) == 2:
        mask = np.ones_like(y, dtype=bool)
        y_bin = np.where(y == classes[0], -1, 1)

        alpha, b = _train_binary(
            X_data,
            y_bin,
            kernel,
            lambda_,
            C,
            smo_threshold,
            vicentin_qp,
            **kwargs,
        )

        return {
            "classes": classes,
            "models": [(alpha, b, mask)],
            "strategy": "binary",
        }

    models = []
    if strategy == "ovo":
        for c1, c2 in combinations(classes, 2):
            mask = (y == c1) | (y == c2)
            y_bin = np.where(y[mask] == c1, -1, 1)

            alpha, b = _train_binary(
                X_data[mask],
                y_bin,
                kernel,
                lambda_,
                C,
                smo_threshold,
                vicentin_qp,
                **kwargs,
            )

            models.append((alpha, b, mask))

    elif strategy == "ovr":
        for c in classes:
            mask = np.ones_like(y, dtype=bool)
            y_bin = np.where(y == c, 1.0, -1.0)

            alpha, b = _train_binary(
                X_data,
                y_bin,
                kernel,
                lambda_,
                C,
                smo_threshold,
                vicentin_qp,
                **kwargs,
            )

            models.append((alpha, b, mask))

    return {"classes": classes, "models": models, "strategy": strategy}
