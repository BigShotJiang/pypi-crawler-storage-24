#[allow(unused)]
pub const FPGA_FCLK: usize = 160000000;
#[allow(unused)]
pub const FP_NBITS: usize = 16;
#[allow(unused)]
pub const FP_MAX: isize = 32767;
#[allow(unused)]
pub const FP_MIN: isize = -32768;
#[allow(unused)]
pub const FP_NVALS: usize = 65536;
#[allow(unused)]
pub const INTERFACE_SPI_FREQ: usize = 5000000;
#[allow(unused)]
pub const INTERFACE_SAMPLING_RATE: usize = 5000;
#[allow(unused)]
pub const INTERFACE_DATA_NUM_CHANNELS: usize = 16;
#[allow(unused)]
pub const INTERFACE_WORD_NBITS: usize = 256;
#[allow(unused)]
pub const INTERFACE_CONFIG_NUM_WORDS: usize = 4;
#[allow(unused)]
pub const INTERFACE_DATA_NUM_SAMPLES: usize = 256;
#[allow(unused)]
pub const INTERFACE_PACKET_NUM_WORDS: usize = 260;
#[allow(unused)]
pub const INTERFACE_PACKET_NBITS: usize = 66560;
#[allow(unused)]
pub const INTERFACE_PACKET_NBYTES: usize = 8320;
#[allow(unused)]
pub const INTERFACE_PACKET_VALID_KEY: [u8;32] = [47, 107, 7, 49, 211, 226, 102, 127, 38, 133, 66, 159, 53, 220, 93, 209, 204, 236, 14, 112, 116, 93, 179, 156, 152, 66, 13, 201, 249, 215, 119, 197];
#[allow(unused)]
pub const INTERFACE_CONFIG_BIT_ALIGNMENT: usize = 32;
#[allow(unused)]
pub const MONITOR_TRACE_NAMES: [&str;16] = ["Ma", "MSa", "Ia₁", "ISa₁", "Ia₂", "ISa₂", "Mb", "MSb", "Ib₁", "ISb₁", "Ib₂", "ISb₂", "F1", "F2", "F3", "F4"];
#[allow(unused)]
pub const MONITOR_TRACE_DESCRIPTIONS: [&str;16] = ["Actual modulation in channel A", "Setpoint signal for channel A modulation", "Actual amplitude of coil A1 current", "Setpoint signal for amplitude of coil A1 current", "Actual amplitude of coil A2 current", "Setpoint signal for amplitude of coil A2 current", "Actual modulation in channel B", "Setpoint signal for channel B modulation", "Actual amplitude of coil B1 current", "Setpoint signal for amplitude of coil B1 current", "Actual amplitude of coil B2 current", "Setpoint signal for amplitude of coil B2 current", "F1", "F2", "F3", "F4"];
#[allow(unused)]
pub const FP_EXTRA_BITS: usize = 8;
#[allow(unused)]
pub const PI_CONTROLLER_PARAM_FRACTION_BITS: usize = 10;
#[allow(unused)]
pub const ADC_NBITS: usize = 12;
#[allow(unused)]
pub const ADC_SPI_FREQ: usize = 32000000;
#[allow(unused)]
pub const CORDIC_NUM_ITERATIONS: usize = 14;
#[allow(unused)]
pub const CORDIC_K: usize = 39796;
#[allow(unused)]
pub const MAG_PHASE_SPARSE: usize = 1;
#[allow(unused)]
pub const FB_LOWPASS_FILTER_TYPE: usize = 0;
#[allow(unused)]
pub const FB_LOWPASS_FILTER_NTAPS: usize = 2;
#[allow(unused)]
pub const FB_LOWPASS_FILTER_CUTOFF: f64 = 0.4;
#[allow(unused)]
pub const AMP_SETPOINT_FILTER_TYPE: usize = 1;
#[allow(unused)]
pub const AMP_SETPOINT_FILTER_NTAPS: usize = 32;
#[allow(unused)]
pub const AMP_SETPOINT_FILTER_CUTOFF: usize = 400;
#[allow(unused)]
pub const SAMPLES_PER_CARRIER_PERIOD: usize = 32;
#[allow(unused)]
pub const MIN_CLK_TICKS_PER_SAMPLE: usize = 100;
#[allow(unused)]
pub const PWM_DEADTIME: f64 = 4e-07;
#[allow(unused)]
pub const PWM_DEADTIME_NTICKS: usize = 64;
#[allow(unused)]
pub const MODULATION_RESOLUTION_NBITS: usize = 12;
#[allow(unused)]
pub const SYSTEM_ENABLE_BIT: usize = 0;
#[allow(unused)]
pub const CHA_CONTROLLER_ENABLE_BIT: usize = 1;
#[allow(unused)]
pub const CHB_CONTROLLER_ENABLE_BIT: usize = 2;
#[allow(unused)]
pub const GPIO_TRIG_PIN: usize = 27;
#[allow(unused)]
pub const CAPACITOR_BANK_ADDRESSES: [u16;4] = [38, 37, 36, 35];
#[allow(unused)]
pub const CAPACITOR_BANK_IODIRA: usize = 0;
#[allow(unused)]
pub const CAPACITOR_BANK_OLATA: usize = 20;
#[allow(unused)]
pub const CAPACITOR_BANK_RELAY_PULSE_DURATION: usize = 400;
#[allow(unused)]
pub const FLOW_SENSOR_CLK_DIVIDER: usize = 16384;
#[allow(unused)]
pub const FLOW_SENSOR_MAX_HALF_PERIOD: usize = 9765;
#[allow(unused)]
pub const FLOW_SENSOR_SLOPE: f64 = 5.5021;
#[allow(unused)]
pub const FLOW_SENSOR_INTERCEPT: f64 = 57.425;
#[allow(unused)]
pub const FLOW_SENSOR_MEAS_FREQ: f64 = 9765.625;
#[allow(unused)]
pub const TEMPERATURE_SENSOR_SMA_WINDOW_SIZE: usize = 16;
#[allow(unused)]
pub const TEMPERATURE_SENSOR_ADC_SPI_FREQ: usize = 1000000;
#[allow(unused)]
pub const TEMPERATURE_SENSOR_VREF: f64 = 3.3;
#[allow(unused)]
pub const TEMPERATURE_SENSOR_RDIV: f64 = 10.0;
#[allow(unused)]
pub const TEMPERATURE_SENSOR_R0: f64 = 10.0;
#[allow(unused)]
pub const TEMPERATURE_SENSOR_T0: f64 = 25.0;
#[allow(unused)]
pub const TEMPERATURE_SENSOR_B: f64 = 3435.0;
#[allow(unused)]
pub const SMBUS_PSU_ADDRESS: usize = 95;
#[allow(unused)]
pub const SMBUS_PSU_CURRENT_READ_CMD: usize = 140;
#[allow(unused)]
pub const SMBUS_PSU_POWER_READ_CMD: usize = 150;
#[allow(unused)]
pub const MAX_SESSION_DURATION: f64 = 1800.0;
#[allow(unused)]
pub const API_PORT: usize = 8082;
