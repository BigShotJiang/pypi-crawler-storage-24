use std::env;

use crate::{ControllerConfig, M, MachineConfig, Signal, SignalSource, StimulationProtocol, TIMSError};
use serde::{Deserialize, Serialize};

#[derive(Default, Copy, Clone, Deserialize, Serialize, Debug)]
#[serde(default)]
pub struct SignalSourceSelection {
    pub internal: usize,
    pub external: usize,
    pub external_selected: bool,
}

#[derive(Default, Copy, Clone, Deserialize, Serialize, Debug)]
#[serde(default)]
pub struct ChannelSettings {
    pub enabled: bool,
    pub amplitude1_source: SignalSourceSelection,
    pub amplitude2_source: SignalSourceSelection,
    pub modulation_source: SignalSourceSelection,
    pub coil_idx: usize,
    pub coil_setting_idx: usize,
}

#[derive(Clone, Deserialize, Serialize, Debug)]
#[serde(default)]
pub struct Settings {
    pub running_on_target_machine: bool,
    pub machine_config: MachineConfig,
    pub intensity: f64,
    pub session_duration: f64,
    pub signals: Vec<Signal>,
    pub channel_a_settings: ChannelSettings,
    pub channel_b_settings: ChannelSettings,
    pub monitor_trace_visible: [bool; M],
}

impl Default for Settings {
    fn default() -> Self {
        let running_on_target_machine = env::var("TIMS_TARGET_MACHINE").is_ok();

        Self {
            running_on_target_machine,
            machine_config: MachineConfig::default(),
            intensity: 0.0,
            session_duration: 60.0,
            signals: vec![Signal::default()],
            channel_a_settings: ChannelSettings {
                enabled: true,
                ..Default::default()
            },
            channel_b_settings: ChannelSettings::default(),
            monitor_trace_visible: [false; M],
        }
    }
}

impl SignalSourceSelection {
    pub fn selected(&self) -> SignalSource {
        match self.external_selected {
            false => SignalSource::Internal(self.internal),
            true => SignalSource::External(self.external),
        }
    }
}

impl Settings {
    pub fn to_stimulation_protocol(&self) -> Result<StimulationProtocol, TIMSError> {
        Ok(StimulationProtocol::new(
            self.session_duration,
            self.signals.clone(),
            self.channel_a_settings.amplitude1_source.internal,
            self.channel_a_settings.amplitude2_source.internal,
            self.channel_b_settings.amplitude1_source.internal,
            self.channel_b_settings.amplitude2_source.internal,
            self.channel_a_settings.modulation_source.internal,
            self.channel_b_settings.modulation_source.internal,
        )?)
    }

    pub fn to_controller_config(
        &self,
        play_protocol: bool,
        stim: bool,
    ) -> Result<ControllerConfig, TIMSError> {
        let mconf = &self.machine_config;

        Ok(ControllerConfig {
            system_enabled: true,
            controller_enabled_a: stim && self.channel_a_settings.enabled,
            controller_enabled_b: stim && self.channel_b_settings.enabled,
            play_protocol,
            lc_setting_a: mconf.coils[self.channel_a_settings.coil_idx].settings
                [self.channel_a_settings.coil_setting_idx],
            lc_setting_b: mconf.coils[self.channel_a_settings.coil_idx].settings
                [self.channel_a_settings.coil_setting_idx],
            p_factor: 4.0,
            i_factor: 0.05,
            intensity_a1: mconf.max_intensity_setpoint * self.intensity,
            intensity_a2: mconf.max_intensity_setpoint * self.intensity,
            intensity_b1: mconf.max_intensity_setpoint * self.intensity,
            intensity_b2: mconf.max_intensity_setpoint * self.intensity,
            amplitude_a1_source: self.channel_a_settings.amplitude1_source.selected(),
            amplitude_a2_source: self.channel_a_settings.amplitude2_source.selected(),
            amplitude_b1_source: self.channel_b_settings.amplitude1_source.selected(),
            amplitude_b2_source: self.channel_b_settings.amplitude2_source.selected(),
            modulation_a_source: self.channel_a_settings.modulation_source.selected(),
            modulation_b_source: self.channel_b_settings.modulation_source.selected(),
        })
    }

    pub fn load_from(&mut self, other: Settings) {
        self.intensity = other.intensity;
        self.session_duration = other.session_duration;
        self.channel_a_settings = other.channel_a_settings;
        self.channel_b_settings = other.channel_b_settings;
        self.signals = other.signals;
    }
}
