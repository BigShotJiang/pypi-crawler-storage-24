import pytims

# Initialize protocol and enable channel A
protocol = pytims.Protocol()
protocol.enable_channel(pytims.Channel.A)

# Set intensity as fraction of maximum stimulator output
protocol.set_stimulation_intensity(1.0)

# Set duration in seconds
protocol.set_session_duration(600.0)

# Constant signals to control coil current amplitudes
# Currents are imbalanced to shift stimulation target towards coil 2 (the weaker
# amplitude)
const1 = protocol.add_constant_signal(value=1.0)
const2 = protocol.add_constant_signal(value=0.65)

# Sine wave for modulation
# Depth=1.0 means sine wave swings all the way down to zero.
sine = protocol.add_sine_signal(amplitude=1.0, frequency=10.0, phase=0.0, depth=1.0)

# Wire amplitude and modulation signals
protocol.set_amplitude_source(pytims.Coil.A1, external=False, index=const1)
protocol.set_amplitude_source(pytims.Coil.A2, external=False, index=const2)
protocol.set_modulation_source(pytims.Channel.A, external=False, index=sine)

# Save the protocol file
protocol.save("temporal-interference.tims")
