import pytims

# Initialize protocol and enable channel A
protocol = pytims.Protocol()
protocol.enable_channel(pytims.Channel.A)

# Set intensity as fraction of maximum stimulator output
protocol.set_stimulation_intensity(0.9)

# Set duration in seconds
protocol.set_session_duration(600.0)

# Simple sine wave to control amplitude.
# Depth=1.0 means sine wave swings all the way down to zero.
sine = protocol.add_sine_signal(amplitude=1.0, frequency=10.0, phase=0.0, depth=1.0)

# Add ramp signal and multiply it with the sine wave to slowly ramp up amplitude
# at the beginning and end of stimulation
ramp = protocol.add_ramp_signal(peak=1.0, up_duration=10.0, down_duration=5.0)
ramped_sine = protocol.add_mixed_signal(sine, ramp)

# Constant signal. Will be used to control modulation signal (i.e. relative phase
# between the two coil currents). 1.0 means coil currents are in-phase. 0 means
# 180 degrees out of phase.
const = protocol.add_constant_signal(value=1.0)

# Amplitude of both coil currents is wired to the ramped sine signal
protocol.set_amplitude_source(pytims.Coil.A1, external=False, index=ramped_sine)
protocol.set_amplitude_source(pytims.Coil.A2, external=False, index=ramped_sine)

# Modulation is set to 1.0 to have the currents in-phase
protocol.set_modulation_source(pytims.Channel.A, external=False, index=const)

# Save the protocol file
protocol.save("amplitude-modulation.tims")
