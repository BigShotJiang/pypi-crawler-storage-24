import pytims

# Initialize protocol and enable channel A
protocol = pytims.Protocol()
protocol.enable_channel(pytims.Channel.A)

# Set intensity as fraction of maximum stimulator output
protocol.set_stimulation_intensity(1.0)

# Set duration in seconds
protocol.set_session_duration(600.0)

# Wire both amplitude signals to a single source on port A0
protocol.set_amplitude_source(pytims.Coil.A1, external=True, index=0)
protocol.set_amplitude_source(pytims.Coil.A2, external=True, index=0)

# Wire modulation signal to a source on port A1
protocol.set_modulation_source(pytims.Channel.A, external=True, index=1)

# Save the protocol file
protocol.save("external-signals.tims")
