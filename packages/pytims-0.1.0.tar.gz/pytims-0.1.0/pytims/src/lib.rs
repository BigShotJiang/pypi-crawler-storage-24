use std::{fs::File, io::Write};

use numpy::PyReadonlyArray1;
use pyo3::prelude::*;

use protocols::{
    config, ArbitrarySignalParams, ConstantSignalParams, MixedSignalParams, RampSignalParams,
    Settings, Signal, SignalSourceSelection, SineSignalParams,
};

#[pyclass]
#[derive(Copy, Clone, PartialEq, Debug)]
enum Channel {
    A,
    B,
}

#[pyclass]
#[derive(Copy, Clone, PartialEq, Debug)]
enum Coil {
    A1,
    A2,
    B1,
    B2,
}

#[pyclass]
#[derive(Default, Debug)]
struct Protocol {
    settings: Settings,
}

#[pymethods]
impl Protocol {
    #[new]
    fn new() -> Self {
        Self {
            settings: Settings {
                signals: Vec::new(),
                ..Default::default()
            },
        }
    }

    fn set_stimulation_intensity(&mut self, intensity: f64) {
        assert!(intensity >= 0.0 && intensity <= 1.0);
        self.settings.intensity = intensity;
    }

    fn set_session_duration(&mut self, duration: f64) {
        assert!(duration <= config::MAX_SESSION_DURATION);
        assert!(duration >= 0.01);
        self.settings.session_duration = duration;
    }

    fn enable_channel(&mut self, channel: &Channel) {
        match channel {
            Channel::A => self.settings.channel_a_settings.enabled = true,
            Channel::B => self.settings.channel_b_settings.enabled = true,
        }
    }

    fn set_amplitude_source(&mut self, coil: &Coil, external: bool, index: usize) {
        let source = SignalSourceSelection {
            internal: !external as usize * index,
            external: external as usize * index,
            external_selected: external,
        };

        match coil {
            Coil::A1 => self.settings.channel_a_settings.amplitude1_source = source,
            Coil::A2 => self.settings.channel_a_settings.amplitude2_source = source,
            Coil::B1 => self.settings.channel_b_settings.amplitude1_source = source,
            Coil::B2 => self.settings.channel_b_settings.amplitude2_source = source,
        }
    }

    fn set_modulation_source(&mut self, channel: &Channel, external: bool, index: usize) {
        let source = SignalSourceSelection {
            internal: !external as usize * index,
            external: external as usize * index,
            external_selected: external,
        };

        match channel {
            Channel::A => self.settings.channel_a_settings.modulation_source = source,
            Channel::B => self.settings.channel_b_settings.modulation_source = source,
        }
    }

    fn add_constant_signal(&mut self, value: f64) -> usize {
        self.settings
            .signals
            .push(Signal::Constant(ConstantSignalParams { value }));

        self.settings.signals.len() - 1
    }

    fn add_sine_signal(&mut self, amplitude: f64, frequency: f64, phase: f64, depth: f64) -> usize {
        self.settings.signals.push(Signal::Sine(SineSignalParams {
            amplitude,
            frequency,
            phase,
            depth,
        }));

        self.settings.signals.len() - 1
    }

    fn add_ramp_signal(&mut self, peak: f64, up_duration: f64, down_duration: f64) -> usize {
        self.settings.signals.push(Signal::Ramp(RampSignalParams {
            peak,
            up_duration,
            down_duration,
        }));

        self.settings.signals.len() - 1
    }

    fn add_mixed_signal(&mut self, a_idx: usize, b_idx: usize) -> usize {
        self.settings
            .signals
            .push(Signal::MixedSignal(MixedSignalParams { a_idx, b_idx }));

        self.settings.signals.len() - 1
    }

    fn add_arbitrary_signal(&mut self, samples: PyReadonlyArray1<f64>) -> usize {
        let samples = samples.as_array();

        assert!(samples.len() == self.get_num_samples());

        let mut data: Vec<i16> = Vec::with_capacity(samples.len());
        for sample in samples.iter() {
            assert!(*sample >= 0.0);
            assert!(*sample <= 1.0);
            data.push(Signal::fp16(*sample));
        }

        self.settings
            .signals
            .push(Signal::Arbitrary(ArbitrarySignalParams { samples: data }));

        self.settings.signals.len() - 1
    }

    fn get_num_samples(&mut self) -> usize {
        assert!(self.settings.session_duration > 0.0);
        f64::ceil(self.settings.session_duration * self.get_sampling_rate()) as usize
    }

    fn get_sampling_rate(&self) -> f64 {
        config::INTERFACE_SAMPLING_RATE as f64
    }

    fn save(&mut self, filepath: String) {
        assert!(filepath.ends_with(".tims"));

        if self.settings.signals.is_empty() {
            self.settings.signals = vec![Signal::default()];
        }

        let buffer = postcard::to_allocvec(&self.settings).unwrap();
        let mut file = File::create(filepath).unwrap();
        file.write_all(&buffer).unwrap();
    }

    fn __str__(&self) -> String {
        format!("{:#?}", self)
    }
}

#[pymodule]
mod pytims {
    #[pymodule_export]
    use super::Protocol;

    #[pymodule_export]
    use super::Channel;

    #[pymodule_export]
    use super::Coil;
}
