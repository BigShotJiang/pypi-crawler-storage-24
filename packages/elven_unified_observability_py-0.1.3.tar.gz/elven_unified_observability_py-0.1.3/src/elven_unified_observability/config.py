from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any, Mapping

_CAMEL_BOUNDARY = re.compile(r"(?<!^)(?=[A-Z])")


@dataclass
class UnifiedServiceConfig:
    service_name: str | None = None
    service_version: str | None = None
    environment: str | None = None
    service_namespace: str | None = None
    attributes: dict[str, Any] = field(default_factory=dict)


@dataclass
class UnifiedObservabilityConfig:
    service: UnifiedServiceConfig = field(default_factory=UnifiedServiceConfig)
    logging: dict[str, Any] | None = None
    logging_integrations: dict[str, Any] | None = None
    telemetry: dict[str, Any] | None = None
    enable_logging: bool | None = None
    enable_metrics: bool | None = None
    enable_tracing: bool | None = None
    strict: bool | None = None


def parse_bool(value: object) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    normalized = str(value).strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    return None


def parse_int(value: object) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return None


def parse_float(value: object) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(str(value))
    except (TypeError, ValueError):
        return None


def normalize_data(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return normalize_data(asdict(value))
    if isinstance(value, Mapping):
        normalized: dict[str, Any] = {}
        for key, inner_value in value.items():
            normalized[_normalize_key(str(key))] = normalize_data(inner_value)
        return normalized
    if isinstance(value, list):
        return [normalize_data(item) for item in value]
    return value


def coerce_unified_config(
    value: UnifiedObservabilityConfig | Mapping[str, Any],
) -> UnifiedObservabilityConfig:
    if isinstance(value, UnifiedObservabilityConfig):
        return UnifiedObservabilityConfig(
            service=UnifiedServiceConfig(
                service_name=value.service.service_name,
                service_version=value.service.service_version,
                environment=value.service.environment,
                service_namespace=value.service.service_namespace,
                attributes=dict(value.service.attributes),
            ),
            logging=normalize_data(value.logging),
            logging_integrations=normalize_data(value.logging_integrations),
            telemetry=normalize_data(value.telemetry),
            enable_logging=value.enable_logging,
            enable_metrics=value.enable_metrics,
            enable_tracing=value.enable_tracing,
            strict=value.strict,
        )

    normalized = normalize_data(value)
    if not isinstance(normalized, dict):
        raise TypeError(
            "Unified observability config must be a mapping or UnifiedObservabilityConfig."
        )

    service_input = normalized.get("service")
    service_data = service_input if isinstance(service_input, dict) else {}

    attributes = _dict_value(service_data.get("attributes")) or {}
    top_level_attributes = _dict_value(normalized.get("service_attributes")) or {}
    merged_attributes = {**top_level_attributes, **attributes}

    service = UnifiedServiceConfig(
        service_name=(
            _string_value(service_data.get("service_name"))
            or _string_value(normalized.get("service_name"))
        ),
        service_version=(
            _string_value(service_data.get("service_version"))
            or _string_value(normalized.get("version"))
            or _string_value(normalized.get("service_version"))
        ),
        environment=(
            _string_value(service_data.get("environment"))
            or _string_value(service_data.get("deployment_environment"))
            or _string_value(normalized.get("environment"))
            or _string_value(normalized.get("deployment_environment"))
        ),
        service_namespace=(
            _string_value(service_data.get("service_namespace"))
            or _string_value(normalized.get("service_namespace"))
        ),
        attributes=merged_attributes,
    )

    return UnifiedObservabilityConfig(
        service=service,
        logging=_dict_value(normalized.get("logging")),
        logging_integrations=(
            _dict_value(normalized.get("logging_integrations"))
            or _dict_value(normalized.get("logging_bridges"))
        ),
        telemetry=_dict_value(normalized.get("telemetry")),
        enable_logging=parse_bool(normalized.get("enable_logging")),
        enable_metrics=parse_bool(normalized.get("enable_metrics")),
        enable_tracing=parse_bool(normalized.get("enable_tracing")),
        strict=parse_bool(normalized.get("strict")),
    )


def merge_configs(
    explicit: UnifiedObservabilityConfig,
    env_config: UnifiedObservabilityConfig,
) -> UnifiedObservabilityConfig:
    service = UnifiedServiceConfig(
        service_name=explicit.service.service_name or env_config.service.service_name,
        service_version=explicit.service.service_version or env_config.service.service_version,
        environment=explicit.service.environment or env_config.service.environment,
        service_namespace=explicit.service.service_namespace
        or env_config.service.service_namespace,
        attributes={**env_config.service.attributes, **explicit.service.attributes},
    )

    return UnifiedObservabilityConfig(
        service=service,
        logging=deep_merge(env_config.logging, explicit.logging),
        logging_integrations=deep_merge(
            env_config.logging_integrations,
            explicit.logging_integrations,
        ),
        telemetry=deep_merge(env_config.telemetry, explicit.telemetry),
        enable_logging=(
            explicit.enable_logging
            if explicit.enable_logging is not None
            else env_config.enable_logging
        ),
        enable_metrics=(
            explicit.enable_metrics
            if explicit.enable_metrics is not None
            else env_config.enable_metrics
        ),
        enable_tracing=(
            explicit.enable_tracing
            if explicit.enable_tracing is not None
            else env_config.enable_tracing
        ),
        strict=explicit.strict if explicit.strict is not None else env_config.strict,
    )


def deep_merge(
    base: dict[str, Any] | None, override: dict[str, Any] | None
) -> dict[str, Any] | None:
    if base is None and override is None:
        return None
    if base is None:
        return normalize_data(override)
    if override is None:
        return normalize_data(base)

    merged = dict(normalize_data(base))
    normalized_override = normalize_data(override)
    for key, value in normalized_override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def build_logging_init_input(config: UnifiedObservabilityConfig) -> dict[str, Any]:
    service_name = config.service.service_name or "unknown-service"
    service_version = config.service.service_version or "1.0.0"
    environment = config.service.environment or "development"
    logging_config = dict(config.logging or {})
    labels = _dict_value(logging_config.get("labels")) or {}
    labels.setdefault("service", service_name)
    labels.setdefault("environment", environment)

    logging_config["app_name"] = service_name
    logging_config["version"] = service_version
    logging_config["environment"] = environment
    logging_config["labels"] = labels
    return logging_config


def has_minimum_logging_config(logging_config: dict[str, Any]) -> bool:
    transport = _dict_value(logging_config.get("transport")) or {}
    return bool(
        transport.get("url") and transport.get("tenant_id") and logging_config.get("app_name")
    )


def _normalize_key(key: str) -> str:
    key = key.replace("-", "_")
    if "_" in key:
        return key.lower()
    return _CAMEL_BOUNDARY.sub("_", key).lower()


def _dict_value(value: Any) -> dict[str, Any] | None:
    if isinstance(value, Mapping):
        normalized = normalize_data(value)
        return normalized if isinstance(normalized, dict) else None
    return None


def _string_value(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None
