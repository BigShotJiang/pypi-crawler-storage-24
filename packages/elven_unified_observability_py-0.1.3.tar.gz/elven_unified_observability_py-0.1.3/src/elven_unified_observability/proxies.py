from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, TypeVar

T = TypeVar("T")


class _NoOpCounter:
    def add(self, value: int | float, attributes: dict[str, Any] | None = None) -> None:
        del value, attributes


class _NoOpHistogram:
    def record(self, value: int | float, attributes: dict[str, Any] | None = None) -> None:
        del value, attributes


@dataclass
class _DummySpan:
    name: str

    def set_attribute(self, key: str, value: Any) -> None:
        del key, value

    def record_exception(self, exc: BaseException) -> None:
        del exc

    def end(self) -> None:
        return None

    def set_status(self, status: Any) -> None:
        del status


class NoOpLogger:
    def debug(self, message: str, context: dict[str, Any] | None = None) -> None:
        del message, context

    def info(self, message: str, context: dict[str, Any] | None = None) -> None:
        del message, context

    def warn(self, message: str, context: dict[str, Any] | None = None) -> None:
        del message, context

    def error(self, message: str, context: dict[str, Any] | None = None) -> None:
        del message, context

    def fatal(self, message: str, context: dict[str, Any] | None = None) -> None:
        del message, context

    def log(self, level: str, message: str, context: dict[str, Any] | None = None) -> None:
        del level, message, context

    def track_event(self, event_name: str, properties: dict[str, Any] | None = None) -> None:
        del event_name, properties

    def with_context(self, context: dict[str, Any], fn: Callable[[], T]) -> T:
        del context
        return fn()

    async def with_context_async(
        self, context: dict[str, Any], fn: Callable[[], Awaitable[T]]
    ) -> T:
        del context
        return await fn()

    def flush(self) -> None:
        return None

    async def aflush(self) -> None:
        return None

    def get_metrics(self) -> dict[str, Any]:
        return {}

    def get_health(self) -> dict[str, str]:
        return {"status": "disabled"}

    def destroy(self) -> None:
        return None

    async def adestroy(self) -> None:
        return None


class NoOpTracer:
    def with_span(
        self,
        name: str,
        fn: Callable[[_DummySpan], T | Awaitable[T]],
        **_: Any,
    ) -> T | Awaitable[T]:
        span = _DummySpan(name)
        result = fn(span)
        if inspect.isawaitable(result):
            return result
        return result

    def start_span(self, name: str, **_: Any) -> _DummySpan:
        return _DummySpan(name)


class NoOpMetrics:
    def get_counter(self, name: str, description: str | None = None) -> _NoOpCounter:
        del name, description
        return _NoOpCounter()

    def get_histogram(
        self,
        name: str,
        description: str | None = None,
        unit: str | None = None,
    ) -> _NoOpHistogram:
        del name, description, unit
        return _NoOpHistogram()

    def get_up_down_counter(self, name: str, description: str | None = None) -> _NoOpCounter:
        del name, description
        return _NoOpCounter()

    def record_histogram(
        self,
        name: str,
        value: float,
        attributes: dict[str, Any] | None = None,
        **_: Any,
    ) -> None:
        del name, value, attributes

    def increment(
        self,
        name: str,
        value: int | float = 1,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        del name, value, attributes


class LoggerProxy:
    def __init__(self) -> None:
        self._target: Any = NoOpLogger()

    def set_target(self, target: Any | None) -> None:
        self._target = target or NoOpLogger()

    def __getattr__(self, name: str) -> Any:
        return getattr(self._target, name)


class DynamicProxy:
    def __init__(self, fallback: Any) -> None:
        self._target: Any = fallback
        self._fallback = fallback

    def set_target(self, target: Any | None) -> None:
        self._target = target or self._fallback

    def __getattr__(self, name: str) -> Any:
        return getattr(self._target, name)


logger = LoggerProxy()
tracer = DynamicProxy(NoOpTracer())
metrics = DynamicProxy(NoOpMetrics())
