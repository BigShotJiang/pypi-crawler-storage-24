from __future__ import annotations

from types import SimpleNamespace
from typing import Iterator

import pytest

from elven_unified_observability.config import UnifiedObservabilityConfig, UnifiedServiceConfig
from elven_unified_observability.runtime import force_flush, init, is_initialized, shutdown


class FakeLogger:
    def __init__(self, calls: list[str]) -> None:
        self.calls = calls

    def flush(self) -> None:
        self.calls.append("logs.flush")


class FakeTelemetryHandle:
    def __init__(self, calls: list[str]) -> None:
        self.calls = calls
        self.tracer = object()
        self.metrics = object()

    def force_flush(self) -> None:
        self.calls.append("otel.flush")

    def shutdown(self) -> None:
        self.calls.append("otel.shutdown")


@pytest.fixture(autouse=True)
def reset_runtime() -> Iterator[None]:
    shutdown()
    yield
    shutdown()


def test_init_is_idempotent(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []
    logger = FakeLogger(calls)
    telemetry = FakeTelemetryHandle(calls)

    monkeypatch.setattr(
        "elven_unified_observability.runtime.load_config_from_env",
        lambda: UnifiedObservabilityConfig(
            service=UnifiedServiceConfig(service_name="svc"),
            logging={"transport": {"url": "http://logs", "tenant_id": "tenant"}},
            telemetry={},
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._load_logs_module",
        lambda: SimpleNamespace(
            init=lambda payload: logger, destroy=lambda: calls.append("logs.destroy")
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._load_otel_module",
        lambda: SimpleNamespace(init_observability=lambda config: telemetry),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._build_telemetry_config",
        lambda config: {},
    )

    first = init()
    second = init()

    assert first is second
    assert is_initialized() is True


def test_force_flush_flushes_logs_before_telemetry(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []
    logger = FakeLogger(calls)
    telemetry = FakeTelemetryHandle(calls)

    monkeypatch.setattr(
        "elven_unified_observability.runtime.load_config_from_env",
        lambda: UnifiedObservabilityConfig(
            service=UnifiedServiceConfig(service_name="svc"),
            logging={"transport": {"url": "http://logs", "tenant_id": "tenant"}},
            telemetry={},
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._load_logs_module",
        lambda: SimpleNamespace(
            init=lambda payload: logger, destroy=lambda: calls.append("logs.destroy")
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._load_otel_module",
        lambda: SimpleNamespace(init_observability=lambda config: telemetry),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._build_telemetry_config",
        lambda config: {},
    )

    init()
    force_flush()

    assert calls[:2] == ["logs.flush", "otel.flush"]


def test_strict_mode_rolls_back_partial_startup(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []
    logger = FakeLogger(calls)

    monkeypatch.setattr(
        "elven_unified_observability.runtime.load_config_from_env",
        lambda: UnifiedObservabilityConfig(
            service=UnifiedServiceConfig(service_name="svc"),
            logging={"transport": {"url": "http://logs", "tenant_id": "tenant"}},
            telemetry={},
            strict=True,
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._load_logs_module",
        lambda: SimpleNamespace(
            init=lambda payload: logger, destroy=lambda: calls.append("logs.destroy")
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._load_otel_module",
        lambda: SimpleNamespace(
            init_observability=lambda config: (_ for _ in ()).throw(RuntimeError("boom"))
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._build_telemetry_config",
        lambda config: {},
    )

    with pytest.raises(RuntimeError):
        init()

    assert "logs.destroy" in calls
    assert is_initialized() is False


def test_partial_startup_skips_logs_without_minimum_config(monkeypatch: pytest.MonkeyPatch) -> None:
    telemetry = FakeTelemetryHandle([])

    monkeypatch.setattr(
        "elven_unified_observability.runtime.load_config_from_env",
        lambda: UnifiedObservabilityConfig(
            service=UnifiedServiceConfig(service_name="svc"),
            logging={"transport": {"url": "http://logs"}},
            telemetry={},
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._load_otel_module",
        lambda: SimpleNamespace(init_observability=lambda config: telemetry),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._build_telemetry_config",
        lambda config: {},
    )

    handle = init()

    assert handle.tracer is telemetry.tracer
    assert handle.metrics is telemetry.metrics


def test_shutdown_uninstalls_logging_integrations_before_destroy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[str] = []
    logger = FakeLogger(calls)

    monkeypatch.setattr(
        "elven_unified_observability.runtime.load_config_from_env",
        lambda: UnifiedObservabilityConfig(
            service=UnifiedServiceConfig(service_name="svc"),
            logging={"transport": {"url": "http://logs", "tenant_id": "tenant"}},
            enable_metrics=False,
            enable_tracing=False,
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime._load_logs_module",
        lambda: SimpleNamespace(
            init=lambda payload: logger, destroy=lambda: calls.append("logs.destroy")
        ),
    )
    monkeypatch.setattr(
        "elven_unified_observability.runtime.install_logging_integrations",
        lambda config, logger_instance, warn: [
            lambda: calls.append("bridges.uninstall"),
        ],
    )

    init()
    shutdown()

    assert calls == ["logs.flush", "bridges.uninstall", "logs.destroy"]
