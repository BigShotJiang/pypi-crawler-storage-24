from __future__ import annotations

from elven_unified_observability.config import coerce_unified_config, merge_configs
from elven_unified_observability.env import load_config_from_env


def test_load_config_from_env_uses_wrapper_and_component_fallbacks() -> None:
    config = load_config_from_env(
        {
            "OTEL_SERVICE_NAME": "billing",
            "OTEL_SERVICE_VERSION": "2.1.0",
            "LOGS_TENANT": "tenant-a",
            "LOKI_URL": "https://loki.example.com/loki/api/v1/push",
            "ENABLE_LOGGING": "true",
            "UO_ENABLE_METRICS": "false",
            "OTEL_INSTR_FASTAPI": "true",
            "OTEL_EXPORTER_OTLP_ENDPOINT": "http://collector:4318",
            "OTEL_EXPORTER_OTLP_PROTOCOL": "http/protobuf",
        }
    )

    assert config.service.service_name == "billing"
    assert config.service.service_version == "2.1.0"
    assert config.enable_logging is True
    assert config.enable_metrics is False
    assert config.logging is not None
    assert config.logging["transport"]["url"] == "https://loki.example.com/loki/api/v1/push"
    assert config.logging["transport"]["tenant_id"] == "tenant-a"
    assert config.telemetry is not None
    assert "url" not in config.telemetry["exporters"]
    assert config.telemetry["exporters"]["protocol"] == "http/protobuf"
    assert config.telemetry["instrumentations"]["fastapi"]["enabled"] is True


def test_load_config_from_env_parses_logging_integration_bridges() -> None:
    config = load_config_from_env(
        {
            "UO_LOGGING_INTEGRATIONS": "auto,loguru",
            "UO_LOGGING_EXCLUDE_PREFIXES": "httpx,httpcore",
            "UO_ENABLE_LOGURU_BRIDGE": "true",
            "UO_LOGURU_LEVEL": "INFO",
            "UO_LOGURU_ENQUEUE": "false",
            "UO_LOGURU_EXCLUDE_PREFIXES": "custom_stack",
            "UO_ENABLE_STRUCTLOG_BRIDGE": "false",
        }
    )

    assert config.logging_integrations == {
        "auto_install": ["auto", "loguru"],
        "exclude_prefixes": ["httpx", "httpcore"],
        "loguru": {
            "enabled": True,
            "level": "INFO",
            "enqueue": False,
            "exclude_prefixes": ["custom_stack"],
        },
        "structlog": {"enabled": False},
    }


def test_coerce_unified_config_accepts_js_style_aliases() -> None:
    config = coerce_unified_config(
        {
            "serviceName": "orders",
            "version": "9.9.9",
            "environment": "staging",
            "enableLogging": True,
            "enableTracing": False,
            "logging": {
                "transport": {
                    "tenantId": "tenant-b",
                    "url": "https://logs.example.com",
                }
            },
        }
    )

    assert config.service.service_name == "orders"
    assert config.service.service_version == "9.9.9"
    assert config.service.environment == "staging"
    assert config.enable_logging is True
    assert config.enable_tracing is False
    assert config.logging == {
        "transport": {
            "tenant_id": "tenant-b",
            "url": "https://logs.example.com",
        }
    }


def test_merge_configs_prefers_explicit_service_and_merges_attributes() -> None:
    env_config = coerce_unified_config(
        {
            "service": {
                "service_name": "billing",
                "service_version": "1.0.0",
                "environment": "production",
                "attributes": {"region": "sa-east-1"},
            },
            "logging": {"filter": {"sanitize": True}},
            "telemetry": {"privacy": {"hash_user_id": True}},
            "enable_metrics": False,
        }
    )
    explicit = coerce_unified_config(
        {
            "service": {
                "service_name": "billing-worker",
                "attributes": {"team": "core"},
            },
            "logging": {"filter": {"sampling_rate": 0.5}},
            "enable_metrics": True,
        }
    )

    merged = merge_configs(explicit, env_config)

    assert merged.service.service_name == "billing-worker"
    assert merged.service.service_version == "1.0.0"
    assert merged.service.attributes == {"region": "sa-east-1", "team": "core"}
    assert merged.logging == {
        "filter": {
            "sanitize": True,
            "sampling_rate": 0.5,
        }
    }
    assert merged.telemetry == {"privacy": {"hash_user_id": True}}
    assert merged.enable_metrics is True
