from __future__ import annotations

import json
import os

from elven_unified_observability import is_initialized

print(
    json.dumps(
        {
            "fixture_flag": os.getenv("FIXTURE_FLAG"),
            "preloaded": os.getenv("ELVEN_UNIFIED_OBSERVABILITY_PRELOADED"),
            "initialized": is_initialized(),
        }
    )
)
