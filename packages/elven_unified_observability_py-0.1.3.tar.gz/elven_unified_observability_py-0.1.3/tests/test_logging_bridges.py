from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest

from elven_unified_observability.config import UnifiedObservabilityConfig
from elven_unified_observability.logging_bridges import (
    install_logging_integrations,
    resolve_requested_logging_integrations,
)


class FakeLoguruLogger:
    def __init__(self) -> None:
        self.add_calls: list[tuple[object, dict[str, object]]] = []
        self.removed_ids: list[int] = []

    def add(self, sink: object, **kwargs: object) -> int:
        self.add_calls.append((sink, kwargs))
        return 7

    def remove(self, sink_id: int) -> None:
        self.removed_ids.append(sink_id)


class FakeStructlogModule:
    def __init__(self) -> None:
        self.current: dict[str, Any] = {
            "processors": ["baseline"],
            "wrapper_class": "wrapper",
            "context_class": "context",
            "logger_factory": "factory",
            "cache_logger_on_first_use": True,
        }
        self.configure_calls: list[dict[str, object]] = []
        self.configure_once_calls: list[dict[str, object]] = []

    def get_config(self) -> dict[str, object]:
        return dict(self.current)

    def configure(self, **kwargs: object) -> None:
        self.current = dict(kwargs)
        self.configure_calls.append(dict(kwargs))

    def configure_once(self, **kwargs: object) -> None:
        self.current = dict(kwargs)
        self.configure_once_calls.append(dict(kwargs))


class FakeLoguruSink:
    def __init__(self, logger: object) -> None:
        self.logger = logger


class StructlogProcessor:
    __module__ = "logs_interceptor.integrations.structlog"

    def __init__(self, logger: object) -> None:
        self.logger = logger


def test_resolve_requested_logging_integrations_supports_auto_and_overrides() -> None:
    config = UnifiedObservabilityConfig(
        logging_integrations={
            "auto_install": ["auto"],
            "structlog": {"enabled": False},
        }
    )

    requests = resolve_requested_logging_integrations(config)

    assert [request.name for request in requests] == ["loguru"]
    assert [request.explicit for request in requests] == [False]


def test_install_logging_integrations_installs_loguru_and_uninstalls(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake_loguru = SimpleNamespace(logger=FakeLoguruLogger())
    fake_integrations = SimpleNamespace(
        LoguruSink=FakeLoguruSink,
        StructlogProcessor=StructlogProcessor,
    )

    def fake_import(name: str) -> object:
        if name == "loguru":
            return fake_loguru
        if name == "logs_interceptor.integrations":
            return fake_integrations
        raise ModuleNotFoundError(name)

    monkeypatch.setattr(
        "elven_unified_observability.logging_bridges.importlib.import_module",
        fake_import,
    )

    config = UnifiedObservabilityConfig(
        logging_integrations={
            "auto_install": ["loguru"],
            "loguru": {
                "level": "INFO",
                "enqueue": False,
                "backtrace": True,
                "diagnose": True,
            },
        }
    )
    warnings: list[str] = []

    uninstallers = install_logging_integrations(config, object(), warn=warnings.append)

    assert warnings == []
    assert len(uninstallers) == 1
    assert len(fake_loguru.logger.add_calls) == 1
    sink, kwargs = fake_loguru.logger.add_calls[0]
    assert isinstance(sink, FakeLoguruSink)
    assert kwargs == {
        "level": "INFO",
        "enqueue": False,
        "backtrace": True,
        "diagnose": True,
        "filter": kwargs["filter"],
    }
    loguru_filter = kwargs["filter"]
    assert callable(loguru_filter)
    assert loguru_filter({"name": "service.handlers", "module": "api", "extra": {}}) is True
    assert loguru_filter({"name": "httpx", "module": "client", "extra": {}}) is False
    assert loguru_filter({"name": "", "module": "httpcore._sync.http11", "extra": {}}) is False

    uninstallers[0]()

    assert fake_loguru.logger.removed_ids == [7]


def test_install_logging_integrations_merges_global_and_loguru_exclusions(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake_loguru = SimpleNamespace(logger=FakeLoguruLogger())
    fake_integrations = SimpleNamespace(
        LoguruSink=FakeLoguruSink,
        StructlogProcessor=StructlogProcessor,
    )

    def fake_import(name: str) -> object:
        if name == "loguru":
            return fake_loguru
        if name == "logs_interceptor.integrations":
            return fake_integrations
        raise ModuleNotFoundError(name)

    monkeypatch.setattr(
        "elven_unified_observability.logging_bridges.importlib.import_module",
        fake_import,
    )

    config = UnifiedObservabilityConfig(
        logging_integrations={
            "auto_install": ["loguru"],
            "exclude_prefixes": ["botocore"],
            "loguru": {"exclude_prefixes": ["custom_stack"]},
        }
    )

    uninstallers = install_logging_integrations(config, object(), warn=lambda _: None)

    assert len(uninstallers) == 1
    _, kwargs = fake_loguru.logger.add_calls[0]
    loguru_filter = kwargs["filter"]
    assert callable(loguru_filter)
    assert loguru_filter({"name": "botocore.endpoint", "module": "endpoint", "extra": {}}) is False
    assert loguru_filter({"name": "custom_stack.worker", "module": "worker", "extra": {}}) is False


def test_install_logging_integrations_wraps_structlog_configure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake_structlog = FakeStructlogModule()
    fake_integrations = SimpleNamespace(
        LoguruSink=FakeLoguruSink,
        StructlogProcessor=StructlogProcessor,
    )

    def fake_import(name: str) -> object:
        if name == "structlog":
            return fake_structlog
        if name == "logs_interceptor.integrations":
            return fake_integrations
        raise ModuleNotFoundError(name)

    monkeypatch.setattr(
        "elven_unified_observability.logging_bridges.importlib.import_module",
        fake_import,
    )

    config = UnifiedObservabilityConfig(logging_integrations={"auto_install": ["structlog"]})
    warnings: list[str] = []

    uninstallers = install_logging_integrations(config, object(), warn=warnings.append)

    assert warnings == []
    assert len(uninstallers) == 1
    assert isinstance(fake_structlog.current["processors"][0], StructlogProcessor)

    fake_structlog.configure(processors=["custom"])

    processors = fake_structlog.current["processors"]
    assert isinstance(processors[0], StructlogProcessor)
    assert processors[1:] == ["custom"]

    uninstallers[0]()

    assert fake_structlog.current["processors"] == ["custom"]


def test_install_logging_integrations_skips_missing_auto_dependencies_without_warning(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "elven_unified_observability.logging_bridges.importlib.import_module",
        lambda name: (_ for _ in ()).throw(ModuleNotFoundError(name)),
    )

    config = UnifiedObservabilityConfig(logging_integrations={"auto_install": ["auto"]})
    warnings: list[str] = []

    uninstallers = install_logging_integrations(config, object(), warn=warnings.append)

    assert uninstallers == []
    assert warnings == []


def test_install_logging_integrations_warns_for_missing_explicit_dependency(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "elven_unified_observability.logging_bridges.importlib.import_module",
        lambda name: (_ for _ in ()).throw(ModuleNotFoundError(name)),
    )

    config = UnifiedObservabilityConfig(logging_integrations={"auto_install": ["loguru"]})
    warnings: list[str] = []

    uninstallers = install_logging_integrations(config, object(), warn=warnings.append)

    assert uninstallers == []
    assert warnings == [
        "Logging bridge 'loguru' was requested but its dependency is not installed."
    ]
