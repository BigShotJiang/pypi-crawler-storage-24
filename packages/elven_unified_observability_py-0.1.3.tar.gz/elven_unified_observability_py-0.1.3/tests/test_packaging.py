from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path


def test_package_build_and_twine_check() -> None:
    root = Path(__file__).resolve().parents[1]
    dist = root / "dist"
    if dist.exists():
        shutil.rmtree(dist)

    build = subprocess.run(
        [sys.executable, "-m", "build", "--sdist", "--wheel"],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert build.returncode == 0, build.stderr

    files = sorted(str(path) for path in dist.iterdir())
    assert files, "build should produce files in dist/"

    twine = subprocess.run(
        [sys.executable, "-m", "twine", "check", *files],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )
    assert twine.returncode == 0, twine.stderr
