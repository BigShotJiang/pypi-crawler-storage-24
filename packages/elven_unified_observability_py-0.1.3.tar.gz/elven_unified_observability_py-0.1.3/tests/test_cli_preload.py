from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from elven_unified_observability.cli import main


def test_cli_injects_preload_and_loads_dotenv(tmp_path: Path) -> None:
    fixture = Path(__file__).parent / "fixtures" / "zero_code_probe.py"
    env_file = tmp_path / ".env"
    env_file.write_text(
        "UO_ENABLED=false\nFIXTURE_FLAG=loaded-from-dotenv\n",
        encoding="utf-8",
    )

    env = os.environ.copy()
    src_path = Path(__file__).resolve().parents[1] / "src"
    env["PYTHONPATH"] = str(src_path)

    process = subprocess.run(
        [
            sys.executable,
            "-m",
            "elven_unified_observability",
            "--",
            sys.executable,
            str(fixture),
        ],
        cwd=tmp_path,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert process.returncode == 0, process.stderr
    payload = json.loads(process.stdout.strip())
    assert payload == {
        "fixture_flag": "loaded-from-dotenv",
        "preloaded": "true",
        "initialized": True,
    }


def test_cli_returns_130_on_keyboard_interrupt(monkeypatch) -> None:
    def raise_interrupt(*args, **kwargs):
        del args, kwargs
        raise KeyboardInterrupt

    monkeypatch.setattr("elven_unified_observability.cli.subprocess.run", raise_interrupt)

    assert main(["--", "python", "-V"]) == 130
