"""Search functionality for docsctx (local and global)."""

from __future__ import annotations

import struct
from typing import Sequence


from docsctx.db.models import Document, DocumentChunk, DocumentEntity
from docsctx.db.repository import DocsRepository
from docsctx.embedder import BaseEmbedder, cosine_similarity
from docsctx.provider import BaseProvider


def decode_vector(data: bytes) -> list[float]:
    """Unpack a bytes blob into a float list."""
    count = len(data) // 4
    return list(struct.unpack(f"<{count}f", data))


class LocalSearch:
    """Vector similarity search combined with graph walk (BFS)."""

    def __init__(self, repository: DocsRepository, embedder: BaseEmbedder) -> None:
        self.repository = repository
        self.embedder = embedder

    def search(
        self,
        query: str,
        top_k: int = 10,
        graph_depth: int = 2,
        min_score: float = 0.3,
    ) -> dict[str, object]:
        """
        Search for chunks via vector similarity, then walk graph from top entities.

        Args:
            query: Search query
            top_k: Number of top chunks to return
            graph_depth: Max depth for BFS graph walk from entities
            min_score: Minimum cosine similarity score

        Returns:
            Dict with chunks, entities, and relationships
        """
        # Embed the query
        query_embedding = self.embedder.embed_query(query)

        # Find similar chunks via vector search
        chunks = self.repository.search_chunks_by_embedding(
            query_embedding,
            limit=top_k,
            min_score=min_score,
        )

        # Collect entities from top chunks
        entity_ids = set()
        for chunk in chunks:
            doc_entities = self.repository.list_entities(chunk["document_id"])
            for entity in doc_entities:
                entity_ids.add(entity["id"])

        # Graph walk from entities (BFS up to graph_depth)
        graph_entities = self._graph_walk(entity_ids, depth=graph_depth)

        return {
            "query": query,
            "chunks": chunks,
            "entities": graph_entities,
            "count": len(chunks),
        }

    def _graph_walk(
        self,
        start_entity_ids: set[int],
        depth: int = 2,
    ) -> list[dict]:
        """BFS walk from entity set."""
        visited = set(start_entity_ids)
        frontier = list(start_entity_ids)
        depth_map = {eid: 0 for eid in frontier}

        for _ in range(depth):
            next_frontier = []
            for entity_id in frontier:
                # Get neighbors via relationships
                entity = self.repository.get_entity(entity_id)
                if not entity:
                    continue

                rels_from = self.repository.list_relationships_from_entity(entity["name"])
                rels_to = self.repository.list_relationships_to_entity(entity["name"])

                for rel in rels_from + rels_to:
                    target_name = rel["target"] if rel["source"] == entity["name"] else rel["source"]
                    target_entity = self.repository.get_entity_by_name(target_name)
                    if target_entity and target_entity["id"] not in visited:
                        visited.add(target_entity["id"])
                        depth_map[target_entity["id"]] = depth_map[entity_id] + 1
                        next_frontier.append(target_entity["id"])

            frontier = next_frontier
            if not frontier:
                break

        # Return all visited entities
        return [self.repository.get_entity(entity_id) for entity_id in visited if self.repository.get_entity(entity_id)]


class GlobalSearch:
    """Community-level search with synthesis."""

    def __init__(self, repository: DocsRepository, provider: BaseProvider | None = None) -> None:
        self.repository = repository
        self.provider = provider

    def search(self, query: str, top_k: int = 5) -> dict[str, object]:
        """
        Search across community summaries.

        Args:
            query: Search query
            top_k: Number of top communities

        Returns:
            Dict with communities and entities
        """
        communities = self.repository.list_communities()

        # Simple keyword matching on summaries (in a real impl, would use semantic search)
        scored_communities = []
        query_terms = set(query.lower().split())

        for community in communities:
            summary = community.get("summary", "").lower()
            label = community.get("label", "").lower()
            score = 0
            for term in query_terms:
                if term in summary:
                    score += 2
                if term in label:
                    score += 1
            if score > 0:
                scored_communities.append((community, score))

        scored_communities.sort(key=lambda x: (-x[1], x[0].get("id", 0)))
        top_communities = [c for c, _ in scored_communities[:top_k]]

        # Collect all entities in top communities
        all_entities = []
        for community in top_communities:
            entities = self.repository.list_entities_in_community(community["id"])
            all_entities.extend(entities)

        # LLM synthesis if provider is available
        synthesized_answer: str | None = None
        if self.provider and top_communities:
            summaries_text = "\n\n".join(
                f"Community: {c.get('label', '')}\n{c.get('summary', '')}"
                for c in top_communities
            )
            try:
                answer = self.provider.synthesize_global_answer(query, summaries_text)
                synthesized_answer = answer or None
            except Exception:
                pass

        return {
            "query": query,
            "communities": top_communities,
            "entities": all_entities,
            "count": len(top_communities),
            "synthesized_answer": synthesized_answer,
        }
