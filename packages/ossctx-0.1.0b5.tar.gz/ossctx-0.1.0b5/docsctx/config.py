"""Configuration for the docs context subsystem."""

from pathlib import Path
from typing import ClassVar, Tuple

from pydantic import BaseModel, Field

from common.config import BaseAppSettings


class ChatConfig(BaseModel):
    provider: str = Field(default="none")
    model: str = Field(default="gpt-4o-mini")
    base_url: str = Field(default="https://api.openai.com/v1")
    api_key: str = Field(default="")
    timeout_seconds: float = Field(default=20.0)
    max_retries: int = Field(default=2)
    retry_backoff_seconds: float = Field(default=0.25)
    fallback_on_error: bool = Field(default=True)


class EmbeddingConfig(BaseModel):
    provider: str = Field(default="")
    model: str = Field(default="")
    base_url: str = Field(default="")
    api_key: str = Field(default="")
    batch_size: int = Field(default=20)


class DocsSettings(BaseAppSettings):
    """Settings for docsctx."""

    default_config_files: ClassVar[Tuple[str, ...]] = (
        ".docscontext.yaml",
        ".docscontext.yml",
        ".docscontext.properties",
        "~/.docscontext.yaml",
        "~/.docscontext.yml",
        "~/.docscontext.properties",
    )

    db_path: Path = Field(default=Path(".docscontext.db"), alias="DOCSCTX_DB_PATH")
    host: str = Field(default="127.0.0.1", alias="DOCSCTX_HOST")
    port: int = Field(default=8090, alias="DOCSCTX_PORT")
    chunk_size: int = Field(default=1200, alias="DOCSCTX_CHUNK_SIZE")
    chunk_overlap: int = Field(default=150, alias="DOCSCTX_CHUNK_OVERLAP")
    max_pages: int = Field(default=100, alias="DOCSCTX_MAX_PAGES")
    max_depth: int = Field(default=2, alias="DOCSCTX_MAX_DEPTH")
    community_min_size: int = Field(default=1, alias="DOCSCTX_COMMUNITY_MIN_SIZE")
    community_max_levels: int = Field(default=3, alias="DOCSCTX_COMMUNITY_MAX_LEVELS")
    extract_claims: bool = Field(default=True, alias="DOCSCTX_EXTRACT_CLAIMS")

    chat: ChatConfig = Field(default_factory=ChatConfig, alias="DOCSCTX_CHAT")
    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig, alias="DOCSCTX_EMBEDDING")

