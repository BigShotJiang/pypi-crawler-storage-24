"""CLI entrypoint for the unified UI."""

from __future__ import annotations

from pathlib import Path

import typer
import uvicorn

from ui.app import build_app
from otelctx.db.repository import OtelRepository
from otelctx.api.routes import ingest_payload


app = typer.Typer(help="Unified UI commands.", no_args_is_help=True)


@app.command("serve")
def serve() -> None:
    """[DEPRECATED] Run the unified ossctx UI and API server."""
    typer.echo("❌ The 'ui serve' command has been moved to the root CLI.")
    typer.echo("👉 Please use: uv run ossCtx serve")
    raise typer.Exit(1)


def compat_main() -> None:
    """Compatibility entrypoint for a direct UI command."""
    app()
