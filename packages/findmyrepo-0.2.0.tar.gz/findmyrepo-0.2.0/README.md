# findmyrepo

Quickly open local repositories in VS Code.

## Usage

### Search and open a repo

``` bash
# Search by partial name and open in VS Code
fmr search auth

# Shortcut (assumes search)
fmr auth
```

### Multiple matches

If multiple repositories match your search query, **findmyrepo will show a
selection menu** so you can choose which repo to open.

Example:

    Multiple matches found:

    1. auth-service
    2. auth-api
    3. auth-utils

    Select a repo number:

Enter the number corresponding to the repository you want, and **findmyrepo
will open it in VS Code**.

### List all Git repos on Desktop

``` bash
fmr list
```

This scans your **Desktop recursively** and prints the names of all Git
repositories found.

### Show help

``` bash
fmr help
```
