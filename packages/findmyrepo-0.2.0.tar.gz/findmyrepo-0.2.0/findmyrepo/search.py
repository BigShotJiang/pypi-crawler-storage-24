from pathlib import Path
from typing import List
import subprocess
import sys
import json

SEARCH_ROOT = Path.home() / "Desktop"
CACHE_FILE = Path.home() / ".fmr_cache.json"


def scan_git_repos() -> List[Path]:
    """Recursively find all git repos under Desktop."""
    if not SEARCH_ROOT.exists():
        sys.exit(f"Search root does not exist: {SEARCH_ROOT}")

    repos = [p for p in SEARCH_ROOT.rglob("*") if (p / ".git").exists()]
    return sorted(repos)


def save_cache(repos: List[Path]) -> None:
    """Save list of repos to cache file."""
    with open(CACHE_FILE, "w") as f:
        json.dump({"repos": [str(r) for r in repos]}, f, indent=2)


def load_cache() -> List[Path]:
    """Load repo paths from cache file."""
    if CACHE_FILE.exists():
        with open(CACHE_FILE, "r") as f:
            data = json.load(f)
        return [Path(p) for p in data.get("repos", [])]
    return []


def get_repos(refresh: bool = False) -> List[Path]:
    """Return list of repos; refresh cache if requested."""
    if refresh or not CACHE_FILE.exists():
        print("Refreshing repo cache...")
        repos = scan_git_repos()
        save_cache(repos)
        return repos
    return load_cache()


def search_and_open(query: str, refresh: bool = False) -> None:
    """Search for matching git repos and open in VS Code."""
    repos = get_repos(refresh)
    matches = [r for r in repos if query.lower() in r.name.lower()]

    if not matches:
        sys.exit(f"No git repositories found matching '{query}'")

    if len(matches) == 1:
        subprocess.run(["code", str(matches[0])])
        return

    print("\nMultiple matches found:\n")
    for i, repo in enumerate(matches, start=1):
        print(f"{i}. {repo.name}")

    choice = input("\nSelect a repo number: ").strip()
    try:
        index = int(choice) - 1
        selected = matches[index]
    except (ValueError, IndexError):
        sys.exit("Invalid selection.")

    subprocess.run(["code", str(selected)])


def list_git_repos(refresh: bool = False) -> None:
    """List all git repos under Desktop (cached)."""
    repos = get_repos(refresh)
    if not repos:
        print(f"No git repositories found under {SEARCH_ROOT}")
        return

    for repo in repos:
        print(f"  {repo.name}")
