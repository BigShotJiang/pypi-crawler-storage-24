import sys
from .search import search_and_open, list_git_repos


def show_help() -> None:
    help_text = """
Usage: fmr <command> [arguments]

Commands:
  --help              Show this help message
  --refresh           Refresh the cached repo list
  list                List all git repositories located within your Desktop folder
  <repo_name>         Shortcut: search and open by repo name

"""
    print(help_text)


def main():
    args = sys.argv[1:]
    if not args or "--help" in args:
        show_help()
        sys.exit(0)

    refresh = False
    if "--refresh" in args:
        refresh = True
        args = [a for a in args if a != "--refresh"]

    if not args:
        list_git_repos(refresh)
        return

    cmd = args[0].lower()

    if cmd == "list":
        list_git_repos(refresh)
    else:
        # Treat as repo name search shortcut
        query = " ".join(args)
        search_and_open(query, refresh)


if __name__ == "__main__":
    main()
