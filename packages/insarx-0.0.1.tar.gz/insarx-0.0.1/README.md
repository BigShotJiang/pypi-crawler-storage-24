# INSARX

INSARX is an open framework for large-scale InSAR processing and analysis.

INSARX aims to support:

- large-scale processing
- automated updates with new observations
- GPU-accelerated processing
- time-series analysis


## Status

This is an early placeholder release intended to reserve the package name on PyPI and prepare for future public development.

## Installation

```bash
pip install insarx
```

## Author

Tatsuo Kusano


## License

The license for INSARX has not yet been finalized.
It will be specified in a future release.

