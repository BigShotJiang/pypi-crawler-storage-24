"""Purple-team defense simulation — propose, apply and verify defenses."""

from .simulator import DefenseSimulator
from .strategies import (
    DefenseStrategy,
    InputSanitizationDefense,
    OutputFilteringDefense,
    SystemPromptHardeningDefense,
)

__all__ = [
    "DefenseSimulator",
    "DefenseStrategy",
    "InputSanitizationDefense",
    "OutputFilteringDefense",
    "SystemPromptHardeningDefense",
]
