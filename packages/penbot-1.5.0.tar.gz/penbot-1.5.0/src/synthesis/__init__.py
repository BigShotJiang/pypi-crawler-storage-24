"""Attack method synthesis — composite attacks from multiple agent techniques."""

from .attack_synthesizer import AttackSynthesizer

__all__ = ["AttackSynthesizer"]
