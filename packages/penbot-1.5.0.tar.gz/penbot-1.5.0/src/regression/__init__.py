"""Automated regression testing with baseline management."""

from .baseline import BaselineManager, BaselineRecord, RegressionResult

__all__ = ["BaselineManager", "BaselineRecord", "RegressionResult"]
