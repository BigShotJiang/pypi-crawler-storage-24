"""CLI entry point for icommand.

Provides commands: init, search, ask, uninstall, capture.
"""

import shutil
from datetime import datetime
from pathlib import Path

import click

from icommand.embeddings import get_implemented_provider_names, get_local_model_cache_dir
from icommand.config import get_config_path, get_icommand_dir, load_config, save_config, Config
from icommand.db import init_db
from icommand.search import search_with_messages
from icommand.search import sync


def _relative_time(timestamp_str: str) -> str:
    """Convert a timestamp string to a human-readable relative time."""
    try:
        then = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return timestamp_str

    now = datetime.now()
    diff = now - then

    seconds = int(diff.total_seconds())
    if seconds < 60:
        return "just now"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif seconds < 86400:
        hours = seconds // 3600
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif seconds < 604800:
        days = seconds // 86400
        return f"{days} day{'s' if days != 1 else ''} ago"
    elif seconds < 2592000:
        weeks = seconds // 604800
        return f"{weeks} week{'s' if weeks != 1 else ''} ago"
    else:
        months = seconds // 2592000
        return f"{months} month{'s' if months != 1 else ''} ago"


def _get_hook_path() -> Path:
    """Return the absolute path to hook.sh bundled inside the package."""
    return Path(__file__).parent / "hook.sh"


def _get_hook_source_line() -> str:
    """Return the line that should be appended to shell rc files."""
    return f'\n# icommand: AI-powered command history search\nsource "{_get_hook_path()}"\n'


_HOOK_MARKER = "# icommand: AI-powered command history search"


def _format_bytes(total_bytes: int) -> str:
    """Render bytes in a compact human-readable form."""
    value = float(total_bytes)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            return f"{value:.0f}{unit}" if unit == "B" else f"{value:.1f}{unit}"
        value /= 1024
    return f"{total_bytes}B"


def _echo_sync_status(result) -> None:
    """Show retained/indexed counts plus local storage usage."""
    click.echo(
        "  state    "
        f"{result.retained_commands} retained"
        f"  ·  {result.indexed_commands} indexed"
        f"  ·  {_format_bytes(result.storage_usage_bytes)} local"
    )
    for message in result.messages:
        click.echo(f"  notice   {message}")


def _echo_search_notices(messages: list[str]) -> None:
    """Show non-fatal search notices."""
    for message in messages:
        click.echo(f"  notice   {message}")


@click.group()
def cli():
    """icommand — AI-powered terminal command history search."""
    pass


@cli.command(hidden=True)
@click.argument("cmd")
@click.argument("directory")
@click.option("--exit-code", "exit_code", default=None, type=int, help="Exit code of the command.")
def capture(cmd: str, directory: str, exit_code):
    """Record a command (called by the shell hook — not for direct use)."""
    from icommand.capture import capture_command
    capture_command(cmd, directory, exit_code)


@cli.command()
def init():
    """Initialize icommand: set up database, config, and shell hook."""
    from icommand.db import rebuild_fts_index
    
    icommand_dir = get_icommand_dir()
    click.echo(f"  created  {icommand_dir}")

    # Initialize the database
    init_db()
    click.echo("  db       initialized")
    
    # Rebuild FTS index (for keyword search)
    indexed = rebuild_fts_index()
    if indexed > 0:
        click.echo(f"  fts      indexed {indexed} commands")

    # Embed all commands so TUI search works immediately.
    # This also pre-warms the ONNX model on first run (~30s, one-time cost).
    from icommand.search import sync
    click.echo("  embedding commands (first run may take ~30s)…", nl=False)
    try:
        sync_result = sync()
        if sync_result.synced_commands > 0:
            click.echo(f" {sync_result.synced_commands} embedded.")
        else:
            click.echo(" up to date.")
        _echo_sync_status(sync_result)
    except Exception as e:
        click.echo(f" warning: {e}", err=True)

    # Write default config if it doesn't exist
    config_path = get_config_path()
    if not config_path.exists():
        example_config = Path(__file__).parent.parent / "config.example.toml"
        if example_config.exists():
            shutil.copy(example_config, config_path)
        else:
            config_path.write_text(
                '\n'.join(
                    [
                        '# icommand configuration',
                        'provider = "local"',
                        'max_results = 10',
                        'tui_max_results = 5',
                        'storage_soft_limit_mb = 1024',
                        'storage_hard_limit_mb = 2048',
                        'live_command_limit = 1000000',
                        'semantic_command_limit = 250000',
                        '',
                    ]
                )
            )
        click.echo(f"  config   {config_path}")
    else:
        click.echo(f"  config   {config_path}")

    # Append hook to shell rc files
    hook_line = _get_hook_source_line()
    hook_path = _get_hook_path()
    hook_installed = False

    if not hook_path.exists():
        click.echo(f"  error    hook not found at {hook_path}", err=True)
    else:
        for rc_name in [".bashrc", ".zshrc"]:
            rc_path = Path.home() / rc_name
            if rc_path.exists():
                content = rc_path.read_text()
                if _HOOK_MARKER not in content:
                    with open(rc_path, "a") as f:
                        f.write(hook_line)
                    click.echo(f"  hook     appended to ~/{rc_name}")
                else:
                    click.echo(f"  hook     ~/{rc_name} (already present)")
                hook_installed = True

    if not hook_installed:
        click.echo()
        click.echo("  error    shell hook was not installed", err=True)
        click.echo("  manual   add this line to ~/.zshrc or ~/.bashrc:", err=True)
        click.echo(f'           source "{hook_path}"', err=True)
        click.echo("  note     init only updates existing shell rc files.", err=True)
        raise click.exceptions.Exit(1)

    click.echo()
    click.echo("  ready.")
    click.echo()
    click.echo("  open a new terminal, then:")
    click.echo("    ic               — open the TUI and search your history")
    click.echo('    icommand search "<query>"   — quick CLI search')


@cli.command()
@click.argument("query")
def search(query: str):
    """Semantically search your command history."""
    config = load_config()
    seen_notices: set[str] = set()

    click.echo("syncing...", nl=False)
    try:
        sync_result = sync()
    except Exception as exc:
        click.echo(" failed.")
        fallback_notice = f"semantic sync unavailable: {exc}"
        click.echo(f"  notice   {fallback_notice}")
        seen_notices.add(fallback_notice)
    else:
        if sync_result.synced_commands > 0:
            click.echo(
                f" {sync_result.synced_commands} command"
                f"{'s' if sync_result.synced_commands != 1 else ''} synced."
            )
        else:
            click.echo(" up to date.")
        _echo_sync_status(sync_result)
        seen_notices.update(sync_result.messages)

    click.echo()

    outcome = search_with_messages(query, config.max_results)
    fresh_notices = [message for message in outcome.messages if message not in seen_notices]
    _echo_search_notices(fresh_notices)
    if fresh_notices:
        click.echo()

    results = outcome.results

    if not results:
        click.echo("No matching commands found.")
        click.echo("Tip: Make sure you have some command history captured first.")
        return

        click.echo(f"{len(results)} result{'s' if len(results) != 1 else ''}:\n")

    for i, result in enumerate(results, 1):
        time_ago = _relative_time(result.timestamp)
        similarity_pct = f"{result.similarity_score * 100:.0f}%"

        click.echo(f"  {i}. {click.style(result.command, fg='green', bold=True)}")
        click.echo(f"     in  {result.directory or 'unknown'}")
        click.echo(f"     at  {time_ago}  ·  {similarity_pct} match")
        click.echo()


@cli.command()
@click.argument("question")
def ask(question: str):
    """Ask a natural language question about your command history."""
    click.echo("conversational search is not yet available.")
    click.echo()
    click.echo("use: icommand search \"<query>\"")


@cli.command()
def tui():
    """Launch the interactive TUI for semantic history search."""
    from icommand.tui import launch
    launch()


@cli.command(name="import-history")
@click.option("--limit", default=5000, show_default=True, help="Max commands to import.")
@click.option("--file", "history_file", default=None, help="Path to history file (auto-detected if omitted).")
def import_history(limit: int, history_file):
    """Import existing shell history into icommand's database."""
    import os
    from icommand.db import init_db, insert_command
    from icommand.capture import capture_command

    init_db()

    # Auto-detect history file
    if history_file:
        paths = [Path(history_file)]
    else:
        paths = []
        for candidate in ["~/.zsh_history", "~/.bash_history"]:
            p = Path(candidate).expanduser()
            if p.exists():
                paths.append(p)

    if not paths:
        click.echo("  error    no history file found (~/.zsh_history or ~/.bash_history)", err=True)
        return

    total_imported = 0

    for path in paths:
        click.echo(f"  reading  {path}")
        try:
            raw = path.read_bytes()
        except Exception as e:
            click.echo(f"  error    could not read {path}: {e}", err=True)
            continue

        # Parse: zsh extended history lines look like `: 1234567890:0;command`
        # bash history is just one command per line (no metadata)
        commands = []
        for line in raw.splitlines():
            try:
                text = line.decode("utf-8", errors="replace").strip()
            except Exception:
                continue
            if not text:
                continue
            # zsh extended_history format: `: timestamp:elapsed;command`
            if text.startswith(": ") and ";" in text:
                text = text.split(";", 1)[1]
            # Skip blank or comment-only lines
            if not text or text.startswith("#"):
                continue
            commands.append(text)

        # Deduplicate while preserving order, take last `limit` unique entries
        seen: set = set()
        unique: list = []
        for cmd in reversed(commands):
            if cmd not in seen:
                seen.add(cmd)
                unique.append(cmd)
        unique = list(reversed(unique))[-limit:]

        home = str(Path.home())
        for cmd in unique:
            try:
                insert_command(cmd, home)
                total_imported += 1
            except Exception:
                pass

    click.echo(f"  imported {total_imported} commands")
    click.echo()
    click.echo("  run `icommand tui` to browse your history!")


@cli.command()
def uninstall():
    """Fully remove icommand: data, local model cache, shell hooks, and the binary."""
    icommand_dir = Path.home() / ".icommand"
    model_cache_dir = get_local_model_cache_dir()

    if not click.confirm(
        "This will remove the icommand binary, local model cache, all data, and shell hooks. Continue?"
    ):
        click.echo("Cancelled.")
        return

    # Remove hook lines from shell rc files
    for rc_name in [".bashrc", ".zshrc"]:
        rc_path = Path.home() / rc_name
        if rc_path.exists():
            lines = rc_path.read_text().splitlines(keepends=True)
            cleaned = []
            skip_next = False
            for line in lines:
                if _HOOK_MARKER in line:
                    skip_next = True
                    continue
                if skip_next and line.strip().startswith("source") and "hook.sh" in line:
                    skip_next = False
                    continue
                # Remove the alias line if it was somehow written directly to rc
                if line.strip() in ("alias ic='icommand tui'", 'alias ic="icommand tui"'):
                    continue
                skip_next = False
                cleaned.append(line)
            rc_path.write_text("".join(cleaned))
            click.echo(f"  hook     removed from ~/{rc_name}")

    # Remove the ~/.icommand directory (includes SQLite DB and FAISS index)
    if icommand_dir.exists():
        shutil.rmtree(icommand_dir)
        click.echo(f"  removed  {icommand_dir}")

    # Remove the cached local embedding model repo from Hugging Face Hub cache
    if model_cache_dir is not None:
        try:
            shutil.rmtree(model_cache_dir)
            click.echo(f"  model    removed {model_cache_dir}")
        except OSError as exc:
            click.echo(f"  warning  failed to remove local model cache: {exc}", err=True)

    # Remove the binary — prefer pipx, fall back to pip
    import subprocess, sys
    pipx = shutil.which("pipx")
    if pipx:
        click.echo("  binary   uninstalling via pipx…")
        # Run in a subprocess so the binary can delete itself
        subprocess.Popen(
            [pipx, "uninstall", "icommand"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        click.echo("  binary   uninstalling via pip…")
        subprocess.Popen(
            [sys.executable, "-m", "pip", "uninstall", "-y", "icommand"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    click.echo("  done.")
    click.echo()
    click.echo("  open a new terminal to apply shell changes.")


@cli.command()
@click.argument("key", required=False)
@click.argument("value", required=False)
@click.option("--reset", is_flag=True, help="Reset all settings to defaults")
def config(key, value, reset):
    """View or update configuration settings.
    
    Show current config:
        icommand config
    
    Update a setting:
        icommand config max_results 5
    
    Reset to defaults:
        icommand config --reset
    
    Available settings:
        max_results       Maximum number of search results (default: 10)
        tui_max_results   Number of results to show in TUI (default: 5, max: 20)
        provider          Embedding provider: local (Arctic Embed XS) (default: local)
        storage_soft_limit_mb   Soft cap for ~/.icommand data (default: 1024)
        storage_hard_limit_mb   Hard cap for ~/.icommand data (default: 2048)
        live_command_limit      Max commands retained locally (default: 1000000)
        semantic_command_limit  Max commands kept semantically indexed (default: 250000)
    """
    config_path = get_config_path()
    
    if reset:
        save_config(Config())
        click.echo("  config   reset to defaults")
        return
    
    # Show current config
    if key is None:
        cfg = load_config()
        click.echo(f"Configuration file: {config_path}")
        click.echo()
        click.echo(f"  max_results     = {cfg.max_results}")
        click.echo(f"  tui_max_results = {cfg.tui_max_results}")
        click.echo(f"  provider        = {cfg.provider}")
        click.echo(f"  storage_soft_limit_mb = {cfg.storage_soft_limit_mb}")
        click.echo(f"  storage_hard_limit_mb = {cfg.storage_hard_limit_mb}")
        click.echo(f"  live_command_limit    = {cfg.live_command_limit}")
        click.echo(f"  semantic_command_limit = {cfg.semantic_command_limit}")
        if cfg.llm_provider:
            click.echo(f"  llm_provider = {cfg.llm_provider}")
        if cfg.llm_model:
            click.echo(f"  llm_model    = {cfg.llm_model}")
        return
    
    # Validate key
    valid_keys = [
        "max_results",
        "tui_max_results",
        "provider",
        "storage_soft_limit_mb",
        "storage_hard_limit_mb",
        "live_command_limit",
        "semantic_command_limit",
    ]
    if key not in valid_keys:
        click.echo(f"Error: Unknown setting '{key}'", err=True)
        click.echo(f"Valid settings: {', '.join(valid_keys)}", err=True)
        return
    
    # Get current config and update
    cfg = load_config()
    
    if value is None:
        # Show specific key
        click.echo(f"  {key} = {getattr(cfg, key)}")
        return
    
    # Update the value
    if key in (
        "max_results",
        "tui_max_results",
        "storage_soft_limit_mb",
        "storage_hard_limit_mb",
        "live_command_limit",
        "semantic_command_limit",
    ):
        try:
            value = int(value)
            if key == "max_results":
                if value < 1 or value > 100:
                    click.echo("Error: max_results must be between 1 and 100", err=True)
                    return
            elif key == "tui_max_results":
                if value < 1 or value > 20:
                    click.echo("Error: tui_max_results must be between 1 and 20", err=True)
                    return
            elif key in ("storage_soft_limit_mb", "storage_hard_limit_mb"):
                if value < 128:
                    click.echo(f"Error: {key} must be at least 128", err=True)
                    return
            elif key == "live_command_limit":
                if value < 10_000:
                    click.echo("Error: live_command_limit must be at least 10000", err=True)
                    return
            elif key == "semantic_command_limit":
                if value < 1_000:
                    click.echo("Error: semantic_command_limit must be at least 1000", err=True)
                    return
        except ValueError:
            click.echo(f"Error: {key} must be a number", err=True)
            return
    elif key == "provider":
        supported = get_implemented_provider_names()
        if value not in supported:
            click.echo(
                f"Error: provider must be one of: {', '.join(supported)}",
                err=True,
            )
            raise click.exceptions.Exit(1)
    
    setattr(cfg, key, value)
    if cfg.storage_soft_limit_mb > cfg.storage_hard_limit_mb:
        click.echo("Error: storage_soft_limit_mb must be <= storage_hard_limit_mb", err=True)
        return
    if cfg.semantic_command_limit > cfg.live_command_limit:
        click.echo("Error: semantic_command_limit must be <= live_command_limit", err=True)
        return
    save_config(cfg)
    click.echo(f"  config   {key} = {value}")
