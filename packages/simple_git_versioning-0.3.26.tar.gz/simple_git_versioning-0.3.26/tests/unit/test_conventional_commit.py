# SPDX-License-Identifier: MIT

from textwrap import dedent

import pytest

from versioning.conventional_commit import (
    ConventionalCommit,
    InvalidConventionalCommitMessage,
    InvalidConventionalCommitSubject,
)


def test_cc_missing_blank_line_between_subject_and_body():
    with pytest.raises(InvalidConventionalCommitMessage):
        ConventionalCommit.parse(dedent("""
                fix: some fix
                No blank line
                """))


def test_cc_invalid_subject():
    with pytest.raises(InvalidConventionalCommitSubject):
        ConventionalCommit.parse("not a conventional commit")


def test_cc_feat():
    cc = ConventionalCommit.parse("feat: add login")
    assert cc.type == "feat"
    assert cc.scope is None
    assert cc.description == "add login"
    assert cc.breaking_change is None
    assert cc.footers == {}


def test_cc_fix():
    cc = ConventionalCommit.parse("fix: crash on startup")
    assert cc.type == "fix"
    assert cc.scope is None
    assert cc.description == "crash on startup"
    assert cc.breaking_change is None
    assert cc.footers == {}


def test_cc_scoped():
    cc = ConventionalCommit.parse("feat(auth): add oauth")
    assert cc.type == "feat"
    assert cc.scope == "auth"
    assert cc.description == "add oauth"
    assert cc.breaking_change is None
    assert cc.footers == {}


def test_cc_breaking_bang():
    cc = ConventionalCommit.parse("feat!: remove API")
    assert cc.type == "feat"
    assert cc.scope is None
    assert cc.description == "remove API"
    assert cc.breaking_change == ""
    assert cc.footers == {}


def test_cc_scoped_breaking_bang():
    cc = ConventionalCommit.parse("feat(auth)!: rewrite auth")
    assert cc.type == "feat"
    assert cc.scope == "auth"
    assert cc.description == "rewrite auth"
    assert cc.breaking_change == ""
    assert cc.footers == {}


def test_cc_breaking_change_with_space():
    cc = ConventionalCommit.parse(dedent("""
            fix: some fix

            BREAKING CHANGE: removed old API
            """))
    assert cc.type == "fix"
    assert cc.scope is None
    assert cc.description == "some fix"
    assert cc.breaking_change == "removed old API"
    assert cc.footers == {"BREAKING CHANGE": "removed old API"}


def test_cc_breaking_change_trailer_with_hyphen():
    cc = ConventionalCommit.parse(dedent("""
            fix: some fix

            BREAKING-CHANGE: removed old API
            """))
    assert cc.type == "fix"
    assert cc.scope is None
    assert cc.description == "some fix"
    assert cc.breaking_change == "removed old API"
    assert cc.footers == {"BREAKING-CHANGE": "removed old API"}
