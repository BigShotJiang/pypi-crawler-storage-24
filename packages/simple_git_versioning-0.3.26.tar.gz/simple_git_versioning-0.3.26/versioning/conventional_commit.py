# SPDX-License-Identifier: MIT

import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from functools import partial
from sys import version_info

try:
    from typing import Self
except ImportError:  # pragma: no cover  # python<3.11
    from typing_extensions import Self

if version_info >= (3, 11):
    dataclass = partial(dataclass, kw_only=True)


class InvalidConventionalCommitMessage(ValueError):
    """
    Raised when a commit body does not follow the conventional commit specification.

    https://www.conventionalcommits.org
    """

    @property
    def body(self):
        return self.args[0]


class InvalidConventionalCommitSubject(ValueError):
    """
    Raised when a commit subject does not follow the conventional commit specification.

    https://www.conventionalcommits.org
    """

    @property
    def subject(self):
        return self.args[0]


@dataclass(frozen=True)
class ConventionalCommit:
    """
    Conventional commit
    """

    type: str
    scope: str
    description: str
    breaking_change: str | None
    footers: Mapping[str, str] = field(hash=False, default_factory=dict)

    _CONVENTIONAL_COMMIT_TITLE_PATTERN = r"""
        ^                          # Commits MUST be prefixed
        (?P<type>[^(:!]+)          # with a type, which consists of a noun, feat, fix, etc.
        (?:\((?P<scope>[^)]+)\))?  # followed by the OPTIONAL scope
        (?P<breaking_change>!)?    # OPTIONAL !
        :\                         # and REQUIRED terminal colon and space.
        (?P<description>.+)        # A description MUST immediately follow the colon and space
    """

    _CONVENTIONAL_COMMIT_TITLE_REGEX = re.compile(_CONVENTIONAL_COMMIT_TITLE_PATTERN, re.VERBOSE)

    _CONVENTIONAL_COMMIT_FOOTER_TOKEN_PATTERN = r"""
        ^                    #
        (?P<token>           # Each footer MUST consist of a word token
          [^: ]+             # [which] MUST use - in place of whitespace characters.
          |BREAKING\ CHANGE  # An exception is made for BREAKING CHANGE
        )
        (?:(:\ |\ \#))       # followed by either a :<space> or <space># separator
        (?P<value>.*)        # followed by a string value
    """

    _CONVENTIONAL_COMMIT_FOOTER_TOKEN_REGEX = re.compile(_CONVENTIONAL_COMMIT_FOOTER_TOKEN_PATTERN, re.VERBOSE)

    @classmethod
    def parse(cls, message: str) -> Self:
        try:
            # A longer commit body MAY be provided after the short description.
            subject, body = message.lstrip().split("\n", maxsplit=1)
        except ValueError:
            subject = message.rstrip()
            body = ""
        else:
            # The body MUST begin one blank line after the description.
            if body[0] != "\n":
                raise InvalidConventionalCommitMessage(message)
            body = body.strip()

        if (subject := cls._CONVENTIONAL_COMMIT_TITLE_REGEX.match(subject)) is None:
            raise InvalidConventionalCommitSubject(subject)

        lines = body.split("\n")
        footers = {}
        blank = True
        for i, line in (_lines := iter(enumerate(lines))):
            if blank:
                # One or more footers MAY be provided one blank line after the body
                if footer := cls._CONVENTIONAL_COMMIT_FOOTER_TOKEN_REGEX.match(line):
                    body = "\n".join(lines[: i - 1])  # discard the last blank line

                    print(footer, f'{footer.group("token")=}, {footer.group("value")=}')
                    token = footer.group("token")
                    value = [footer.group("value")]
                    # A footer’s value MAY contain spaces and newlines, and parsing MUST terminate when the next valid
                    # footer token/separator pair is observed.
                    for _, line in _lines:
                        if footer := cls._CONVENTIONAL_COMMIT_FOOTER_TOKEN_REGEX.match(line):
                            footers[token] = "\n".join(value)

                            token = footer.group("token")
                            value = [footer.group("value")]
                        else:
                            value.append(line)
                    else:
                        footers[token] = "\n".join(value)

                    break
            blank = line == ""

        type_ = subject.group("type")
        scope = subject.group("scope")
        description = subject.group("description")
        breaking_change = footers.get(
            "BREAKING-CHANGE", footers.get("BREAKING CHANGE", subject.group("breaking_change") and body)
        )

        return cls(type=type_, scope=scope, breaking_change=breaking_change, description=description, footers=footers)
