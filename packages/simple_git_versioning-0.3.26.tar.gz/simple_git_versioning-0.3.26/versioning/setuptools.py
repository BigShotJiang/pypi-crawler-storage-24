# SPDX-License-Identifier: MIT

import logging
from collections.abc import Mapping
from dataclasses import replace
from io import TextIOWrapper
from pathlib import Path

try:
    import tomllib
except ImportError:  # pragma: no cover  # python<3.11
    import toml

from sh.contrib import git

from setuptools import Distribution
from setuptools.errors import SetupError
from versioning import pep440, semver2
from versioning.project import (
    InvalidReference,
    InvalidVersionBumpTrailer,
    NotAGitWorkTree,
    NoVersion,
    NoVersionInShallowRepository,
)

LOGGER = logging.getLogger(__name__)


def finalize_distribution_options(distribution: Distribution) -> None:  # pragma: no cover
    if distribution.metadata.version is not None:
        LOGGER.debug(f"version is set already to: {distribution.metadata.version}")
        return

    try:
        with open("pyproject.toml", mode="rb") as stream:
            try:
                pyproject = tomllib.load(stream)
            except NameError:
                pyproject = toml.load(TextIOWrapper(stream))  # toml.load expects a TextIO
    except FileNotFoundError:
        LOGGER.debug("pyproject.toml not found: bailing out")
        return

    if (
        "project" not in pyproject
        or "dynamic" not in pyproject["project"]
        or "version" not in pyproject["project"]["dynamic"]
    ):
        LOGGER.debug("'version' is not set to be dynamic in pyproject.toml")
        return

    try:
        config = pyproject["tool"]["simple-git-versioning"]["setuptools"]
    except KeyError:
        LOGGER.debug("simple-git-versioning is not enabled")
        return

    if isinstance(config, str):
        scheme = config
        sh_log_level = "WARNING"
    elif isinstance(config, Mapping):
        scheme = config.get("scheme", "pep440")
        if not isinstance(scheme, str):
            raise SetupError(f"unexpected type for `tool.simple-git-versioning.setuptools.scheme`: '{type(config)}'")
        sh_log_level = config.get("sh-log-level", "WARNING")
    else:
        raise SetupError(f"unexpected type for `tool.simple-git-versioning.setuptools`: '{type(config)}'")

    scheme = scheme.casefold()
    if scheme == "pep440":
        Project = pep440.Project
    elif scheme == "semver2":
        Project = semver2.Project
    else:
        raise SetupError(
            f"unexpected value for `tool.simple-git-versioning.setuptools.scheme`: '{scheme}', expected 'pep440' or 'semver2'"
        )

    logging.getLogger("sh").setLevel(sh_log_level)

    if distribution.metadata.name is None:
        distribution.metadata.name = pyproject["project"]["name"]

    try:
        version_bump_source = pyproject["tool"]["simple-git-versioning"].get("version-bump-source")
    except (KeyError, TypeError, AttributeError):
        version_bump_source = None

    try:
        with Project(
            path=Path("."), **({"version_bump_source": version_bump_source} if version_bump_source else {})
        ) as proj:
            try:
                distribution.metadata.version = str(proj.version())
            except NoVersion:
                revision = git("rev-parse", "--short", "HEAD").strip()
                if isinstance(proj, pep440.Project):
                    options = dict(dev=0, local=(revision,))
                elif isinstance(proj, semver2.Project):
                    options = dict(build=revision)

                try:
                    distribution.metadata.version = str(proj.release(**options))
                except (NoVersionInShallowRepository, pep440.IllegalRelease, InvalidVersionBumpTrailer) as exc:
                    raise SetupError(str(exc))
            except InvalidReference:
                version = proj.scheme()
                if isinstance(proj, pep440.Project):
                    version = replace(version, dev=0, local=("norevision",))
                elif isinstance(proj, semver2.Project):
                    version = replace(version, build="norevision")
                distribution.metadata.version = str(version)
    except NotAGitWorkTree:
        with open("PKG-INFO") as stream:
            for line in stream:
                key, value = line.split(": ", maxsplit=1)
                if key == "Version":
                    distribution.metadata.version = value
                    break
