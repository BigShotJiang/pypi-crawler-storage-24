from typing import Any, Literal, Protocol, Self

class _BaseNode(Protocol):
    id: str
    name: str
    children: list[Self]

    @property
    def is_hidden(self) -> bool: ...

class NodeWithString(_BaseNode, Protocol):
    formula: str
    value: str

class NodeWithList(_BaseNode, Protocol):
    formula: list[str]
    value: list[str]

class NodeWithStringOrList(_BaseNode, Protocol):
    formula: str | list[str]
    value: str | list[str]

Node = NodeWithString | NodeWithList | NodeWithStringOrList
"""A node in the formula evaluation tree.

Attributes:
    id: Unique identifier for the node
    name: Display name for the node
    formula: Formula string or list of formula strings to evaluate (e.g., "=10+5", ["=10+5"], or ["=@ref1"])
    value: Evaluated result as string or list of strings (empty before evaluation)
    is_hidden: Whether the node is hidden
    children: List of child nodes
"""

def evaluate(formula: str) -> str:
    """Evaluates a single formula string.

    Args:
        formula: Formula string to evaluate (e.g., "=10+5" or "=@ref1")

    Returns:
        The evaluated result as a string, or an error indication.
    """
    ...

def evaluate_boolean(formula: str) -> str:
    """Evaluates a boolean expression formula string.

    Args:
        formula: Boolean expression string to evaluate (e.g., "1 == 1" or "5 > 3")

    Returns:
        The evaluated result as a string ("true" or "false"), or an error indication.
    """
    ...

def evaluate_tree[T: Node](root: T, in_place: bool = False) -> T:
    """Evaluates a tree of nodes with formulas.

    This function evaluates all formulas in the tree, handling references
    between nodes (e.g., "=@ref1" references another node's value).

    Args:
        root: A Node object representing the root of the tree to evaluate
        in_place: If True, modifies the tree in place. If False (default), creates a new tree.

    Returns:
        The tree structure with all 'value' fields populated with evaluation results.
        If in_place=False, returns a new tree (deep copy). If in_place=True, returns
        the same tree object that was passed in.

    Raises:
        TypeError: If the input does not match the Node protocol or attribute types are incorrect
        AttributeError: If required attributes are missing or cannot be accessed
        ValueError: If the input cannot be processed
    """
    ...

def get_tokens(
    formula: str,
) -> list[
    tuple[
        str,
        Literal[
            "number",
            "operator",
            "nodereference",
            "modifier",
            "function",
            "aggregation",
            "conditional",
            "parenthesis",
            "unexpected",
        ],
    ]
]:
    """Parses a formula string into tokens with preserved number formats.

    This function parses a formula and returns a list of tokens, where each token
    contains the original string value and its type. Numbers preserve their original
    decimal separator (comma or point) for locale-based formatting.

    Args:
        formula: Formula string to tokenize (e.g., "=3,14 + 2.5")

    Returns:
        A list of tuples, where each tuple contains (value, token_type)

    Raises:
        ValueError: If the input cannot be parsed or is invalid
    """
    ...

def rename_nodes[T: Node](old_root: T, new_root: T, in_place: bool = False) -> T:
    """Updates formulas in new_root based on node renames detected between old_root and new_root.

    This function compares two trees with identical topology to detect node renames and updates
    all formulas in new_root to use the correct unambiguous references. This handles cases where
    renames create or resolve ambiguity (e.g., renaming "ItemA" to "ItemB" when another "ItemB"
    already exists, resulting in "ItemB[1]" and "ItemB[2]").

    Args:
        old_root: A Node object representing the tree before renaming
        new_root: A Node object representing the tree after renaming
        in_place: If True, modifies new_root in place. If False (default), creates a new tree.

    Returns:
        The new_root tree structure with all formulas updated.
        If in_place=False, returns a new tree (deep copy). If in_place=True, returns
        the same new_root object that was passed in.

    Raises:
        TypeError: If the input does not match the Node protocol or attribute types are incorrect
        AttributeError: If required attributes are missing or cannot be accessed
        ValueError: If the input cannot be processed or trees have different topology
    """
    ...

def expand_tree_formulas[T: Node](root: T) -> T:
    """Recursively expands node references in all formulas throughout the tree.

    This function traverses the tree and replaces node references in each formula with their expanded
    formulas until all references point to "leaf" nodes (nodes whose formulas don't contain other references).
    This allows you to see the final line of dependencies without fully evaluating to concrete values.

    Args:
        root: A Node object representing the root of the tree

    Returns:
        The same tree structure with all formulas expanded

    Raises:
        TypeError: If the input does not match the Node protocol or attribute types are incorrect
        AttributeError: If required attributes are missing or cannot be accessed
        ValueError: If the input cannot be processed
    """
    ...

def explain_node(root: Node, node_id: str) -> dict[str, Any] | None:
    """Creates a flattened view of a node's formula dependencies.

    This function finds the target node by ID, expands its formula, and returns a new tree where:
    - The root is the target node with its formula fully expanded
    - All children are the nodes that the target node's formula directly references
    - Children are flattened to a single level (no nesting)
    - Children appear in the order they are referenced in the expanded formula

    Args:
        root: A Node object representing the root of the tree to search
        node_id: The ID of the node to explain

    Returns:
        A dictionary representing the new tree structure with the target as root and
        its dependencies as direct children, or None if the node ID is not found

    Raises:
        TypeError: If the input does not match the Node protocol or attribute types are incorrect
        AttributeError: If required attributes are missing or cannot be accessed
        ValueError: If the input cannot be processed
    """
    ...

def irr(values: list[float]) -> float:
    """Calculates the internal rate of return (IRR) for a series of cash flows.

    The IRR is the discount rate that makes the net present value (NPV) of all
    cash flows equal to zero. This function uses the Newton-Raphson method to
    find the rate.

    Args:
        values: List of cash flows where the first value is typically the initial
                investment (negative) and subsequent values are returns (positive or negative).

    Returns:
        The internal rate of return as a decimal (e.g., 0.1 for 10%). Returns NaN
        if the calculation does not converge or if the input is invalid.
    """
    ...

def npv(rate: float, values: list[float]) -> float:
    """Calculates the net present value (NPV) for a series of cash flows.

    NPV is the sum of the present values of incoming and outgoing cash flows over a period of time.

    Args:
        rate: The discount rate per period (e.g., 0.1 for 10%)
        values: List of cash flows where the first value is typically the initial
                investment (negative) and subsequent values are returns (positive or negative).

    Returns:
        The net present value as a number.
    """
    ...

def distribute_flat(value: float, periods: int) -> list[float]:
    """Distributes a value evenly across a number of periods.

    Each period receives an equal portion of the value. The last period is adjusted
    to account for any floating-point rounding errors, ensuring the sum equals the
    original value.

    Args:
        value: The total value to distribute
        periods: Number of periods to distribute across (must be >= 0)

    Returns:
        A list of values, one per period. Returns an empty list if periods is 0.
    """
    ...

def distribute_bell(value: float, periods: int) -> list[float]:
    """Distributes a value using a bell curve (Gaussian distribution) across periods.

    The distribution follows a normal distribution with the peak at the middle period
    and tapering off towards the edges. The sum of all values equals the original value.

    Args:
        value: The total value to distribute
        periods: Number of periods to distribute across (must be >= 0)

    Returns:
        A list of values following a bell curve distribution. Returns an empty list
        if periods is 0, or the full value if periods is 1.
    """
    ...

def distribute_scurve(value: float, periods: int) -> list[float]:
    """Distributes a value using an S-curve (sigmoid distribution) across periods.

    The distribution starts slow, accelerates in the middle periods, then decelerates
    towards the end. This pattern is common in project timelines and adoption curves.
    The sum of all values equals the original value.

    Args:
        value: The total value to distribute
        periods: Number of periods to distribute across (must be >= 0)

    Returns:
        A list of values following an S-curve distribution. Returns an empty list
        if periods is 0, or the full value if periods is 1.
    """
    ...
