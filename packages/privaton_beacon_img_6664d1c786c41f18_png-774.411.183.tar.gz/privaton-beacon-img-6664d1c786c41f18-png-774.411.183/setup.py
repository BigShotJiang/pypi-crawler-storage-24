from setuptools import setup
setup(name='privaton-beacon-img-6664d1c786c41f18-png', version='774.411.183', py_modules=['data'])
