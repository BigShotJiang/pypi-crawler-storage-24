from xmas_app.util.get_models import get_model_for_select

__all__ = ["get_model_for_select"]
