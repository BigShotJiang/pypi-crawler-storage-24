"""Fixtures for connector tests."""
