"""Fixtures for core tests."""
