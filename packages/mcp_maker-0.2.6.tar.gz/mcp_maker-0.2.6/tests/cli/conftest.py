"""Fixtures for CLI tests."""
