"""Core geometric metrics for OOD detection (pure numpy, no torch)."""

from __future__ import annotations

import numpy as np

__all__ = ["intrinsic_dim", "mahalanobis_distance", "cosine_to_centroid"]


def intrinsic_dim(X: np.ndarray, threshold: float = 0.95) -> int:
    """Number of PCA components needed to explain *threshold* variance."""
    X = X - X.mean(axis=0)
    cov = np.cov(X, rowvar=False)
    eigenvalues = np.linalg.eigvalsh(cov)[::-1]
    eigenvalues = np.maximum(eigenvalues, 0)
    total = eigenvalues.sum()
    if total == 0:
        return len(eigenvalues)
    cumvar = np.cumsum(eigenvalues) / total
    return int(np.searchsorted(cumvar, threshold) + 1)


def mahalanobis_distance(
    x: np.ndarray, centroid: np.ndarray, cov: np.ndarray,
) -> float:
    """Mahalanobis distance from *x* to *centroid* under *cov*."""
    reg_cov = cov + np.eye(cov.shape[0]) * 1e-6
    cov_inv = np.linalg.pinv(reg_cov)
    diff = x - centroid
    return float(np.sqrt(diff @ cov_inv @ diff))


def cosine_to_centroid(x: np.ndarray, centroid: np.ndarray) -> float:
    """Cosine similarity between *x* and *centroid*."""
    norm_x = np.linalg.norm(x)
    norm_c = np.linalg.norm(centroid)
    if norm_x < 1e-8 or norm_c < 1e-8:
        return 0.0
    return float(np.dot(x, centroid) / (norm_x * norm_c))
