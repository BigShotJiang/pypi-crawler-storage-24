from __future__ import annotations

from typing import Union

from geood.result import DetectionResult
from geood.detector import Detector

__version__ = "0.1.2"


def calibrate(
    model: Union[str, object],
    ref_texts: list[str],
    tokenizer: object | None = None,
    layer: Union[str, int] = "auto",
) -> Detector:
    """Calibrate an OOD detector from reference in-distribution texts.

    Args:
        model: HuggingFace model name (str) or loaded PreTrainedModel.
        ref_texts: List of in-distribution reference texts.
        tokenizer: Required when model is an object.
        layer: ``"auto"`` to auto-select best layer, or int for manual override.

    Returns:
        Calibrated detector ready for ``detect()`` calls.
    """
    detector = Detector()
    detector.calibrate(model, ref_texts, tokenizer=tokenizer, layer=layer)
    return detector


def load(path: str) -> Detector:
    """Load a previously saved detector.

    Args:
        path: Path to a ``.geood`` file created by ``Detector.save()``.

    Returns:
        Loaded detector ready for ``detect()`` calls.
    """
    return Detector.load(path)


__all__ = ["calibrate", "load", "DetectionResult", "Detector"]
