from __future__ import annotations

import importlib

from nexus.api.builder import WorkflowBuilder
from nexus.api.decorators import agent, task, tool

__all__ = [
    "agent",
    "task",
    "tool",
    "Nexus",
    "NexusConfig",
    "NexusResult",
    "WorkflowBuilder",
    "BranchStrategy",
    "LoopStrategy",
    "LocalProvider",
]

__version__ = "1.0.0"


_LAZY_IMPORTS = {
    "Nexus": ("nexus.runtime", "Nexus"),
    "NexusConfig": ("nexus.runtime", "NexusConfig"),
    "NexusResult": ("nexus.runtime", "NexusResult"),
    "BranchStrategy": ("nexus.core.graph.branch_manager", "BranchStrategy"),
    "LoopStrategy": ("nexus.core.graph.loop_detective", "LoopStrategy"),
    "LocalProvider": ("nexus.protocols.providers.local_provider", "LocalProvider"),
}


def __getattr__(name: str):
    if name in _LAZY_IMPORTS:
        mod_name, attr = _LAZY_IMPORTS[name]
        module = importlib.import_module(mod_name)
        return getattr(module, attr)
    raise AttributeError(name)
