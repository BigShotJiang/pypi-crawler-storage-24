"""Resilience fabric modules."""
