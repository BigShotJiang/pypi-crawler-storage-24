"""Tool registry and adapters."""
