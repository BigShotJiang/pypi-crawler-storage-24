"""Provider and protocol bridge modules."""
