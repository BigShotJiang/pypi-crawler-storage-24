"""Fluid state mesh layers and diffing."""
