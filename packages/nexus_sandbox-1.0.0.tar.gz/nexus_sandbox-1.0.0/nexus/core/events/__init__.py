"""Typed events and event bus."""
