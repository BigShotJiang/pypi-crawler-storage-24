"""Core runtime modules for NEXUS."""
