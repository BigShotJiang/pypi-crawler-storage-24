from __future__ import annotations


RESILIENCE_PRESETS: dict[str, dict] = {
    "low": {"circuit_breaker_threshold": 8, "retry_max": 2, "checkpoint_every_n_nodes": 10},
    "standard": {"circuit_breaker_threshold": 5, "retry_max": 3, "checkpoint_every_n_nodes": 5},
    "high": {"circuit_breaker_threshold": 3, "retry_max": 5, "checkpoint_every_n_nodes": 2},
}

MEMORY_PRESETS: dict[str, dict] = {
    "session": {"hot_layer_ttl": 300, "warm_max_entries": 500},
    "persistent": {"hot_layer_ttl": 600, "warm_max_entries": 1000, "cold_layer_backend": "chroma"},
    "frugal": {"hot_layer_ttl": 120, "warm_max_entries": 200},
}


def get_resilience_preset(name: str) -> dict:
    """Return resilience preset map by name."""
    return RESILIENCE_PRESETS.get(name, RESILIENCE_PRESETS["standard"]).copy()


def get_memory_preset(name: str) -> dict:
    """Return memory preset map by name."""
    return MEMORY_PRESETS.get(name, MEMORY_PRESETS["session"]).copy()
