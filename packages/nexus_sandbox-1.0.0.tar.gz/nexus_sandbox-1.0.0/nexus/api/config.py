from __future__ import annotations

from pathlib import Path
from typing import Any

import tomli
import yaml

from nexus.api.builder import WorkflowDefinition


def load_config(path: str) -> WorkflowDefinition:
    """Load workflow definition from YAML or TOML file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    if p.suffix.lower() in {".yaml", ".yml"}:
        payload = yaml.safe_load(p.read_text(encoding="utf-8"))
    elif p.suffix.lower() == ".toml":
        payload = tomli.loads(p.read_text(encoding="utf-8"))
    else:
        raise ValueError("Unsupported config format; use .yaml/.yml/.toml")
    return WorkflowDefinition.model_validate(payload)
