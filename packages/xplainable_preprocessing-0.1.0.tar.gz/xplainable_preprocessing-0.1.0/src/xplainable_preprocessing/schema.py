"""Pydantic models for pipeline specification."""

from typing import Dict, List, Optional

from pydantic import BaseModel, field_validator


class StepSpec(BaseModel):
    """A single preprocessing step in the pipeline."""

    id: str
    type: str
    columns: Optional[List[str]] = None
    params: Dict = {}
    description: Optional[str] = None

    @field_validator("id")
    @classmethod
    def id_must_be_non_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Step id must be non-empty")
        return v

    @field_validator("type")
    @classmethod
    def type_must_be_non_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Step type must be non-empty")
        return v


class PipelineSpec(BaseModel):
    """Full pipeline specification containing ordered steps."""

    version: str = "2.0"
    steps: List[StepSpec] = []

    @field_validator("steps")
    @classmethod
    def step_ids_must_be_unique(cls, v: List[StepSpec]) -> List[StepSpec]:
        ids = [step.id for step in v]
        if len(ids) != len(set(ids)):
            duplicates = [id_ for id_ in ids if ids.count(id_) > 1]
            raise ValueError(f"Duplicate step ids: {set(duplicates)}")
        return v


def validate_spec(spec: PipelineSpec) -> None:
    """Validate a PipelineSpec. Raises ValueError if invalid.

    Checks beyond Pydantic validation:
    - All non-custom types must exist in the registry
    - Custom steps must have 'code' and 'class_name' in params
    """
    from xplainable_preprocessing.registry import REGISTRY

    for step in spec.steps:
        if step.type == "custom":
            if "code" not in step.params:
                raise ValueError(
                    f"Step '{step.id}': custom type requires 'code' in params"
                )
            if "class_name" not in step.params:
                raise ValueError(
                    f"Step '{step.id}': custom type requires 'class_name' in params"
                )
        elif step.type not in REGISTRY:
            raise ValueError(
                f"Step '{step.id}': unknown type '{step.type}'. "
                f"Available: {sorted(REGISTRY.keys())}"
            )
