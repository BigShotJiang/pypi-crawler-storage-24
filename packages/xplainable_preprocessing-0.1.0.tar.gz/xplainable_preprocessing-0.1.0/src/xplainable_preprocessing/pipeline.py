"""DataFrame-preserving pipeline and column transformer."""

from __future__ import annotations

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class DataFrameColumnTransformer(BaseEstimator, TransformerMixin):
    """Applies a transformer to specific columns, passes the rest through."""

    def __init__(self, transformer: TransformerMixin, columns: list[str]):
        self.transformer = transformer
        self.columns = columns

    def fit(self, X: pd.DataFrame, y=None):
        self.transformer.fit(X[self.columns], y)
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()
        result = self.transformer.transform(Xt[self.columns])
        if isinstance(result, pd.DataFrame):
            Xt = Xt.drop(columns=self.columns)
            Xt = pd.concat([Xt, result], axis=1)
        elif hasattr(result, 'shape') and len(result.shape) == 2 and result.shape[1] != len(self.columns):
            # Column count changed (e.g., OneHotEncoder) — get proper names
            Xt = Xt.drop(columns=self.columns)
            if hasattr(self.transformer, 'get_feature_names_out'):
                new_cols = list(self.transformer.get_feature_names_out())
            else:
                new_cols = [f"{self.columns[0]}_{i}" for i in range(result.shape[1])]
            result_df = pd.DataFrame(result, columns=new_cols, index=Xt.index)
            Xt = pd.concat([Xt, result_df], axis=1)
        else:
            # numpy array with same column count — replace in place
            Xt[self.columns] = result
        return Xt

    def fit_transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        self.fit(X, y)
        return self.transform(X)


class DataFramePipeline(BaseEstimator, TransformerMixin):
    """Sequential pipeline that preserves DataFrame structure.

    Unlike sklearn's Pipeline which converts DataFrames to numpy arrays,
    this pipeline passes DataFrames between steps.

    Parameters
    ----------
    steps : list of (name, transformer) tuples
        The ordered sequence of transformers to apply.
    """

    def __init__(self, steps: list[tuple[str, TransformerMixin]]):
        self.steps = steps

    def fit(self, X: pd.DataFrame, y=None):
        Xt = X.copy()
        for name, transformer in self.steps:
            Xt = transformer.fit_transform(Xt, y)
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()
        for name, transformer in self.steps:
            Xt = transformer.transform(Xt)
        return Xt

    def fit_transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        Xt = X.copy()
        for name, transformer in self.steps:
            Xt = transformer.fit_transform(Xt, y)
        return Xt

    def get_step(self, name: str) -> TransformerMixin:
        """Get a step by name."""
        for step_name, transformer in self.steps:
            if step_name == name:
                return transformer
        raise KeyError(f"Step '{name}' not found")

    @property
    def step_names(self) -> list[str]:
        return [name for name, _ in self.steps]
