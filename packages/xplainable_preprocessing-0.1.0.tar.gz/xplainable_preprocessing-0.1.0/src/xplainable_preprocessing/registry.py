"""Transformer registry mapping names to sklearn-compatible classes."""

from __future__ import annotations

import inspect
from typing import Any

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import (
    Binarizer,
    KBinsDiscretizer,
    MinMaxScaler,
    OneHotEncoder,
    OrdinalEncoder,
    PowerTransformer,
    QuantileTransformer,
    RobustScaler,
    StandardScaler,
)

from xplainable_preprocessing.transformers import (
    CategoryCondenseTransformer,
    DateTimeExtractTransformer,
    DropColumnsTransformer,
    ExpressionTransformer,
    FillMissingTransformer,
    GroupedLagTransformer,
    RenameColumnsTransformer,
    RollingAggTransformer,
    TextCleanTransformer,
    TypeCastTransformer,
)

# Registry: name -> class
REGISTRY: dict[str, type] = {
    # Standard sklearn
    "SimpleImputer": SimpleImputer,
    "StandardScaler": StandardScaler,
    "MinMaxScaler": MinMaxScaler,
    "RobustScaler": RobustScaler,
    "OneHotEncoder": OneHotEncoder,
    "OrdinalEncoder": OrdinalEncoder,
    "PowerTransformer": PowerTransformer,
    "QuantileTransformer": QuantileTransformer,
    "KBinsDiscretizer": KBinsDiscretizer,
    "Binarizer": Binarizer,
    # Custom transformers
    "ExpressionTransformer": ExpressionTransformer,
    "DropColumnsTransformer": DropColumnsTransformer,
    "RenameColumnsTransformer": RenameColumnsTransformer,
    "TypeCastTransformer": TypeCastTransformer,
    "FillMissingTransformer": FillMissingTransformer,
    "CategoryCondenseTransformer": CategoryCondenseTransformer,
    "TextCleanTransformer": TextCleanTransformer,
    "DateTimeExtractTransformer": DateTimeExtractTransformer,
    "GroupedLagTransformer": GroupedLagTransformer,
    "RollingAggTransformer": RollingAggTransformer,
}


def generate_catalog() -> str:
    """Generate a prompt-ready catalog of available transformer types.

    Introspects the REGISTRY to produce a formatted string listing
    each transformer with its constructor parameters, defaults, and
    a one-line description from the class docstring.

    Returns a string suitable for embedding in LLM system prompts.
    """
    lines = []
    for name, cls in REGISTRY.items():
        # First line of docstring as description
        doc = (cls.__doc__ or "").strip().split("\n")[0]

        # Constructor signature (skip 'self')
        sig = inspect.signature(cls.__init__)
        params = []
        for pname, param in sig.parameters.items():
            if pname == "self":
                continue
            if param.default is inspect.Parameter.empty:
                params.append(pname)
            else:
                params.append(f"{pname}={param.default!r}")

        param_str = ", ".join(params)
        lines.append(f"- {name}({param_str}) — {doc}")

    # Add custom code option
    lines.append(
        '- custom(code="...", class_name="...", description="...") '
        "— Write a custom sklearn-compatible transformer when no built-in type fits"
    )

    return "\n".join(lines)


def register(name: str, cls: type) -> None:
    """Register a new transformer class.

    Parameters
    ----------
    name : str
        The name to register the transformer under.
    cls : type
        The transformer class (must be sklearn-compatible).
    """
    REGISTRY[name] = cls
