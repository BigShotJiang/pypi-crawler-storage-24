"""Compile a PipelineSpec into a DataFramePipeline."""

from __future__ import annotations

import inspect

from xplainable_preprocessing.pipeline import DataFrameColumnTransformer, DataFramePipeline
from xplainable_preprocessing.registry import REGISTRY
from xplainable_preprocessing.sandbox import compile_custom
from xplainable_preprocessing.schema import PipelineSpec


def _coerce_params(cls, params: dict) -> dict:
    """Convert list params to tuples where the constructor expects them.

    JSON has no tuple type, so specs always contain lists. sklearn transformers
    like MinMaxScaler expect tuples for params like feature_range.
    """
    sig = inspect.signature(cls.__init__)
    coerced = {}
    for key, value in params.items():
        if isinstance(value, list) and key in sig.parameters:
            param = sig.parameters[key]
            if param.default is not inspect.Parameter.empty and isinstance(param.default, tuple):
                value = tuple(value)
        coerced[key] = value
    return coerced


def compile_spec(spec: PipelineSpec) -> DataFramePipeline:
    """Convert a PipelineSpec into a DataFramePipeline.

    Parameters
    ----------
    spec : PipelineSpec
        The pipeline specification to compile.

    Returns
    -------
    DataFramePipeline
        An unfitted pipeline ready for .fit() and .transform().

    Raises
    ------
    ValueError
        If a step type is not found in the registry and is not "custom".
    """
    steps = []

    for step in spec.steps:
        if step.type == "custom":
            transformer = compile_custom(step.params)
        else:
            if step.type not in REGISTRY:
                raise ValueError(
                    f"Step '{step.id}': unknown type '{step.type}'. "
                    f"Available: {sorted(REGISTRY.keys())}"
                )
            cls = REGISTRY[step.type]
            params = _coerce_params(cls, step.params)
            transformer = cls(**params)

        if step.columns:
            transformer = DataFrameColumnTransformer(transformer, step.columns)

        steps.append((step.id, transformer))

    return DataFramePipeline(steps)
