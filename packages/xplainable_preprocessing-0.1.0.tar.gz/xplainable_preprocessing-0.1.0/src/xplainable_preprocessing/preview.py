"""Preview and delta computation for UI display."""

from __future__ import annotations

import math

import pandas as pd

from xplainable_preprocessing.pipeline import DataFramePipeline


def _sanitize_records(records: list[dict]) -> list[dict]:
    """Replace NaN/Inf with None for JSON-safe output."""
    sanitized = []
    for row in records:
        sanitized.append({
            k: None if isinstance(v, float) and (math.isnan(v) or math.isinf(v)) else v
            for k, v in row.items()
        })
    return sanitized


def infer_schema(df: pd.DataFrame) -> dict:
    """Infer column schema from a DataFrame.

    Returns
    -------
    dict
        {"columns": [{"name": str, "dtype": str}, ...],
         "sample": [dict] (first row, JSON-safe)}
    """
    return {
        "columns": [
            {"name": col, "dtype": str(df[col].dtype)}
            for col in df.columns
        ],
        "sample": _sanitize_records(df.head(1).to_dict("records")) if len(df) > 0 else [],
    }


def compute_delta(before: pd.DataFrame, after: pd.DataFrame) -> dict:
    """Compute the transformation delta between two DataFrames.

    Returns
    -------
    dict with keys:
        - dropped: list of column names removed
        - added: list of column names added
        - updated: list of column names whose values changed
        - rows_before: int
        - rows_after: int
    """
    before_cols = set(before.columns)
    after_cols = set(after.columns)

    dropped = sorted(before_cols - after_cols)
    added = sorted(after_cols - before_cols)

    common = before_cols & after_cols
    updated = []
    for col in sorted(common):
        try:
            if not before[col].equals(after[col]):
                updated.append(col)
        except Exception:
            updated.append(col)

    return {
        "dropped": dropped,
        "added": added,
        "updated": updated,
        "rows_before": len(before),
        "rows_after": len(after),
    }


def compute_step_deltas(
    pipeline: DataFramePipeline,
    df: pd.DataFrame,
) -> list[dict]:
    """Compute per-step deltas for a fitted pipeline.

    Parameters
    ----------
    pipeline : DataFramePipeline
        A fitted pipeline.
    df : pd.DataFrame
        Sample data to transform.

    Returns
    -------
    list of dict
        One delta per step, each containing step_id, step_type, and the delta.
    """
    deltas = []
    Xt = df.copy()

    for name, transformer in pipeline.steps:
        before = Xt.copy()
        Xt = transformer.transform(Xt)
        delta = compute_delta(before, Xt)
        deltas.append({
            "step_id": name,
            "delta": delta,
            "sample_after": _sanitize_records(Xt.head(5).to_dict("records")),
        })

    return deltas


def compute_preview(
    pipeline: DataFramePipeline,
    df: pd.DataFrame,
) -> dict:
    """Compute a full preview of pipeline transformation.

    Returns
    -------
    dict with keys:
        - input_schema: schema of input data
        - output_schema: schema of output data
        - step_deltas: per-step deltas
        - sample_before: first 5 rows of input
        - sample_after: first 5 rows of output
    """
    input_schema = infer_schema(df)
    result = pipeline.transform(df)
    output_schema = infer_schema(result)
    step_deltas = compute_step_deltas(pipeline, df)

    return {
        "input_schema": input_schema,
        "output_schema": output_schema,
        "step_deltas": step_deltas,
        "sample_before": _sanitize_records(df.head(5).to_dict("records")),
        "sample_after": _sanitize_records(result.head(5).to_dict("records")),
    }
