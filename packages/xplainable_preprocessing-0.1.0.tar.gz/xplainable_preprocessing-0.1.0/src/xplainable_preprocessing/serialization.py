"""Cloudpickle-based pipeline serialization."""

from __future__ import annotations

from typing import TYPE_CHECKING

import cloudpickle

if TYPE_CHECKING:
    from xplainable_preprocessing.pipeline import DataFramePipeline


def save_pipeline(pipeline: DataFramePipeline) -> bytes:
    """Serialize a fitted pipeline to bytes."""
    return cloudpickle.dumps(pipeline)


def load_pipeline(data: bytes) -> DataFramePipeline:
    """Deserialize a fitted pipeline from bytes."""
    return cloudpickle.loads(data)  # noqa: S301 - trusted internal data
