"""Grouped lag feature transformer."""

from __future__ import annotations

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class GroupedLagTransformer(BaseEstimator, TransformerMixin):
    """Create lag features within groups.

    Parameters
    ----------
    columns : list[str]
        Columns to create lag features for.
    group_by : list[str]
        Columns to group by.
    order_by : str
        Column to sort by within groups before computing lags.
    periods : list[int]
        Lag periods to create. E.g. [1, 7, 30].
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        group_by: list[str] | None = None,
        order_by: str = "",
        periods: list[int] | None = None,
    ):
        self.columns = columns or []
        self.group_by = group_by or []
        self.order_by = order_by
        self.periods = periods or [1]

    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()

        if self.order_by and self.order_by in Xt.columns:
            Xt = Xt.sort_values(self.group_by + [self.order_by])

        for col in self.columns:
            if col not in Xt.columns:
                continue
            for period in self.periods:
                new_col = f"{col}_lag_{period}"
                if self.group_by:
                    Xt[new_col] = Xt.groupby(self.group_by)[col].shift(period)
                else:
                    Xt[new_col] = Xt[col].shift(period)

        return Xt
