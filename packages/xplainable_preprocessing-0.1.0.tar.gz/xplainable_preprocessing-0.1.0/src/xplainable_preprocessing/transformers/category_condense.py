"""Category condensing transformer."""

from __future__ import annotations

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class CategoryCondenseTransformer(BaseEstimator, TransformerMixin):
    """Collapse low-frequency categories into an 'Other' category.

    Parameters
    ----------
    max_categories : int
        Maximum number of categories to keep. The rest become `other_label`.
    other_label : str
        Label for condensed categories. Default "Other".
    min_frequency : float | None
        If set, categories with frequency below this fraction are condensed.
        Takes precedence over max_categories.
    """

    def __init__(
        self,
        max_categories: int = 10,
        other_label: str = "Other",
        min_frequency: float | None = None,
    ):
        self.max_categories = max_categories
        self.other_label = other_label
        self.min_frequency = min_frequency

    def fit(self, X: pd.DataFrame, y=None):
        self.keep_categories_ = {}
        for col in X.columns:
            if X[col].dtype == "object" or isinstance(X[col].dtype, pd.CategoricalDtype):
                counts = X[col].value_counts(normalize=True)
                if self.min_frequency is not None:
                    keep = counts[counts >= self.min_frequency].index.tolist()
                else:
                    keep = counts.head(self.max_categories).index.tolist()
                self.keep_categories_[col] = set(keep)
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()
        for col, keep in self.keep_categories_.items():
            if col in Xt.columns:
                Xt[col] = Xt[col].where(Xt[col].isin(keep), self.other_label)
        return Xt
