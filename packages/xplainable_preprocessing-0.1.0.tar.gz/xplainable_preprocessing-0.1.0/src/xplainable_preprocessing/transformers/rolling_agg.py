"""Rolling window aggregation transformer."""

from __future__ import annotations

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class RollingAggTransformer(BaseEstimator, TransformerMixin):
    """Create rolling window aggregate features.

    Parameters
    ----------
    columns : list[str]
        Columns to compute rolling aggregates for.
    group_by : list[str] | None
        Columns to group by. If None, computes globally.
    window : int
        Rolling window size.
    operation : str
        Aggregation operation: "mean", "sum", "min", "max", "std", "count".
    min_periods : int
        Minimum number of observations required. Default 1.
    order_by : str
        Column to sort by before computing rolling stats.
    """

    OPERATIONS = {"mean", "sum", "min", "max", "std", "count", "median"}

    def __init__(
        self,
        columns: list[str] | None = None,
        group_by: list[str] | None = None,
        window: int = 7,
        operation: str = "mean",
        min_periods: int = 1,
        order_by: str = "",
    ):
        self.columns = columns or []
        self.group_by = group_by
        self.window = window
        self.operation = operation
        self.min_periods = min_periods
        self.order_by = order_by

    def fit(self, X: pd.DataFrame, y=None):
        if self.operation not in self.OPERATIONS:
            raise ValueError(
                f"Unknown operation '{self.operation}'. "
                f"Available: {sorted(self.OPERATIONS)}"
            )
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()

        if self.order_by and self.order_by in Xt.columns:
            sort_cols = (self.group_by or []) + [self.order_by]
            Xt = Xt.sort_values(sort_cols)

        for col in self.columns:
            if col not in Xt.columns:
                continue
            new_col = f"{col}_rolling_{self.operation}_{self.window}"
            if self.group_by:
                rolling = (
                    Xt.groupby(self.group_by)[col]
                    .rolling(window=self.window, min_periods=self.min_periods)
                )
                Xt[new_col] = getattr(rolling, self.operation)().reset_index(
                    level=list(range(len(self.group_by))), drop=True
                )
            else:
                rolling = Xt[col].rolling(
                    window=self.window, min_periods=self.min_periods
                )
                Xt[new_col] = getattr(rolling, self.operation)()

        return Xt
