"""Type casting transformer."""

from __future__ import annotations

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class TypeCastTransformer(BaseEstimator, TransformerMixin):
    """Cast column dtypes in a DataFrame.

    Parameters
    ----------
    dtypes : dict[str, str]
        Column name -> target dtype mapping.
        E.g. {"age": "float64", "name": "string"}
    errors : str
        How to handle casting errors. Default "coerce" (invalid -> NaN).
    """

    def __init__(self, dtypes: dict[str, str] | None = None, errors: str = "coerce"):
        self.dtypes = dtypes or {}
        self.errors = errors

    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()
        for col, dtype in self.dtypes.items():
            if col in Xt.columns:
                if dtype in ("int", "int64", "int32", "float", "float64", "float32"):
                    Xt[col] = pd.to_numeric(Xt[col], errors=self.errors)
                    if dtype.startswith("int") and self.errors == "coerce":
                        Xt[col] = Xt[col].astype("Int64")
                    else:
                        Xt[col] = Xt[col].astype(dtype)
                elif dtype in ("datetime", "datetime64[ns]"):
                    Xt[col] = pd.to_datetime(Xt[col], errors=self.errors)
                else:
                    Xt[col] = Xt[col].astype(dtype)
        return Xt
