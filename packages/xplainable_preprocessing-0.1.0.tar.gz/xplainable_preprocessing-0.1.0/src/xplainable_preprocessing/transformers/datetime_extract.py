"""Datetime feature extraction transformer."""

from __future__ import annotations

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class DateTimeExtractTransformer(BaseEstimator, TransformerMixin):
    """Extract datetime components as new columns.

    Parameters
    ----------
    components : list[str]
        Components to extract. Options:
        "year", "month", "day", "hour", "minute", "second",
        "dayofweek", "dayofyear", "weekofyear", "quarter",
        "is_weekend", "is_month_start", "is_month_end"
    drop_original : bool
        Whether to drop the original datetime columns. Default True.
    """

    COMPONENT_MAP = {
        "year": lambda s: s.dt.year,
        "month": lambda s: s.dt.month,
        "day": lambda s: s.dt.day,
        "hour": lambda s: s.dt.hour,
        "minute": lambda s: s.dt.minute,
        "second": lambda s: s.dt.second,
        "dayofweek": lambda s: s.dt.dayofweek,
        "dayofyear": lambda s: s.dt.dayofyear,
        "weekofyear": lambda s: s.dt.isocalendar().week.astype(int),
        "quarter": lambda s: s.dt.quarter,
        "is_weekend": lambda s: s.dt.dayofweek.isin([5, 6]).astype(int),
        "is_month_start": lambda s: s.dt.is_month_start.astype(int),
        "is_month_end": lambda s: s.dt.is_month_end.astype(int),
    }

    def __init__(
        self,
        components: list[str] | None = None,
        drop_original: bool = True,
    ):
        self.components = components or ["year", "month", "day"]
        self.drop_original = drop_original

    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()
        original_cols = list(Xt.columns)

        for col in original_cols:
            if not pd.api.types.is_datetime64_any_dtype(Xt[col]):
                try:
                    Xt[col] = pd.to_datetime(Xt[col], errors="coerce")
                except Exception:
                    continue

            if not pd.api.types.is_datetime64_any_dtype(Xt[col]):
                continue

            for component in self.components:
                extractor = self.COMPONENT_MAP.get(component)
                if extractor:
                    Xt[f"{col}_{component}"] = extractor(Xt[col])

            if self.drop_original:
                Xt = Xt.drop(columns=[col])

        return Xt
