"""Expression-based transformer using pandas.eval()."""

from __future__ import annotations

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class ExpressionTransformer(BaseEstimator, TransformerMixin):
    """Create new columns using pandas.eval() expressions.

    Uses pandas.eval() for safe expression evaluation without exec/eval.

    Parameters
    ----------
    expression : str
        A pandas-compatible expression (e.g. "age * salary / 1000").
    output_column : str
        Name of the new column to create.
    """

    def __init__(self, expression: str = "", output_column: str = ""):
        self.expression = expression
        self.output_column = output_column

    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()
        # Support both bare column names ("age * salary") and df reference ("df['age'] * df['salary']")
        local_dict = {col: Xt[col] for col in Xt.columns}
        local_dict["df"] = Xt
        Xt[self.output_column] = pd.eval(self.expression, local_dict=local_dict, engine="python")
        return Xt
