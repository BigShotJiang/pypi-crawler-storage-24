"""DataFrame-aware missing value fill transformer."""

from __future__ import annotations

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class FillMissingTransformer(BaseEstimator, TransformerMixin):
    """Fill missing values with per-column strategies.

    Parameters
    ----------
    strategies : dict[str, str | int | float]
        Column name -> fill strategy. Strategy can be:
        - "mean": fill with column mean (numeric only)
        - "median": fill with column median (numeric only)
        - "mode": fill with most frequent value
        - "ffill": forward fill
        - "bfill": backward fill
        - Any scalar value: fill with that constant
    default : str | int | float | None
        Default strategy for columns not in strategies dict.
    """

    def __init__(
        self,
        strategies: dict | None = None,
        default: str | int | float | None = None,
    ):
        self.strategies = strategies or {}
        self.default = default

    def fit(self, X: pd.DataFrame, y=None):
        self.fill_values_ = {}
        for col, strategy in self.strategies.items():
            if col not in X.columns:
                continue
            if strategy == "mean":
                self.fill_values_[col] = X[col].mean()
            elif strategy == "median":
                self.fill_values_[col] = X[col].median()
            elif strategy == "mode":
                mode = X[col].mode()
                self.fill_values_[col] = mode.iloc[0] if len(mode) > 0 else None
            # ffill/bfill and constants don't need fitting
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()
        for col, strategy in self.strategies.items():
            if col not in Xt.columns:
                continue
            if strategy in ("mean", "median", "mode"):
                Xt[col] = Xt[col].fillna(self.fill_values_.get(col))
            elif strategy == "ffill":
                Xt[col] = Xt[col].ffill()
            elif strategy == "bfill":
                Xt[col] = Xt[col].bfill()
            else:
                # Treat as constant value
                Xt[col] = Xt[col].fillna(strategy)

        if self.default is not None:
            for col in Xt.columns:
                if col not in self.strategies:
                    if self.default in ("ffill", "bfill"):
                        Xt[col] = getattr(Xt[col], self.default)()
                    else:
                        Xt[col] = Xt[col].fillna(self.default)
        return Xt
