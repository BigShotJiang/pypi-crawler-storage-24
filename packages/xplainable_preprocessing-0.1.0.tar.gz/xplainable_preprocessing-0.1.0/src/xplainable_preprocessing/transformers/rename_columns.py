"""Rename columns transformer."""

from __future__ import annotations

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class RenameColumnsTransformer(BaseEstimator, TransformerMixin):
    """Rename columns in a DataFrame.

    Parameters
    ----------
    mapping : dict[str, str]
        Old name -> new name mapping.
    """

    def __init__(self, mapping: dict[str, str] | None = None):
        self.mapping = mapping or {}

    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        return X.rename(columns=self.mapping)
