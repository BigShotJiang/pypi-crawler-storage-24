"""Text cleaning transformer."""

from __future__ import annotations

import re

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class TextCleanTransformer(BaseEstimator, TransformerMixin):
    """Clean text columns with configurable operations.

    Parameters
    ----------
    operations : list[str]
        Ordered list of operations to apply. Options:
        - "lowercase": convert to lowercase
        - "uppercase": convert to uppercase
        - "strip": strip whitespace
        - "remove_digits": remove all digits
        - "remove_punctuation": remove punctuation
        - "remove_extra_whitespace": collapse multiple spaces
        - "remove_html": strip HTML tags
    regex_pattern : str | None
        Optional regex pattern to remove.
    regex_replacement : str
        Replacement for regex matches. Default "".
    """

    def __init__(
        self,
        operations: list[str] | None = None,
        regex_pattern: str | None = None,
        regex_replacement: str = "",
    ):
        self.operations = operations or []
        self.regex_pattern = regex_pattern
        self.regex_replacement = regex_replacement

    def fit(self, X: pd.DataFrame, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        Xt = X.copy()
        for col in Xt.columns:
            if Xt[col].dtype != "object":
                continue
            series = Xt[col]
            for op in self.operations:
                if op == "lowercase":
                    series = series.str.lower()
                elif op == "uppercase":
                    series = series.str.upper()
                elif op == "strip":
                    series = series.str.strip()
                elif op == "remove_digits":
                    series = series.str.replace(r"\d+", "", regex=True)
                elif op == "remove_punctuation":
                    series = series.str.replace(r"[^\w\s]", "", regex=True)
                elif op == "remove_extra_whitespace":
                    series = series.str.replace(r"\s+", " ", regex=True).str.strip()
                elif op == "remove_html":
                    series = series.str.replace(r"<[^>]+>", "", regex=True)
            if self.regex_pattern:
                series = series.str.replace(
                    self.regex_pattern, self.regex_replacement, regex=True
                )
            Xt[col] = series
        return Xt
