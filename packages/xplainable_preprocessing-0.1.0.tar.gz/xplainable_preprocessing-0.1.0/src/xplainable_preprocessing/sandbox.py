"""AST-based code validator and restricted executor for custom transformers."""

from __future__ import annotations

import ast

FORBIDDEN_IMPORTS = {
    "os", "sys", "subprocess", "socket", "shutil", "pathlib",
    "http", "urllib", "requests", "importlib", "ctypes", "signal",
    "multiprocessing", "threading", "asyncio", "pickle", "shelve",
    "tempfile", "glob", "io", "builtins", "code", "codeop",
}

FORBIDDEN_CALLS = {
    "exec", "eval", "__import__", "open", "compile",
    "globals", "locals", "breakpoint", "exit", "quit",
    "getattr", "setattr", "delattr",
}


def validate_code(code: str) -> None:
    """AST-validate custom transformer code. Raises ValueError if unsafe."""
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        raise ValueError(f"Syntax error in custom code: {e}") from e

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root_module = alias.name.split(".")[0]
                if root_module in FORBIDDEN_IMPORTS:
                    raise ValueError(f"Forbidden import: {alias.name}")

        elif isinstance(node, ast.ImportFrom):
            if node.module:
                root_module = node.module.split(".")[0]
                if root_module in FORBIDDEN_IMPORTS:
                    raise ValueError(f"Forbidden import: {node.module}")

        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                if node.func.id in FORBIDDEN_CALLS:
                    raise ValueError(f"Forbidden call: {node.func.id}")
            elif isinstance(node.func, ast.Attribute):
                if node.func.attr in FORBIDDEN_CALLS:
                    raise ValueError(f"Forbidden call: {node.func.attr}")


def compile_custom(params: dict):
    """Compile custom transformer code into a class instance.

    Validates the code via AST, executes it in a restricted namespace,
    and returns an instance of the specified class.

    Parameters
    ----------
    params : dict
        Must contain 'code' (str) and 'class_name' (str).
        May contain additional constructor kwargs.

    Returns
    -------
    transformer : object
        An instance of the custom transformer class.
    """
    code = params["code"]
    class_name = params["class_name"]

    validate_code(code)

    # Execute in a restricted namespace with limited builtins
    # Defense in depth: restrict __builtins__ to prevent class-hierarchy escapes
    safe_builtins = {
        name: __builtins__[name] if isinstance(__builtins__, dict) else getattr(__builtins__, name)
        for name in (
            "__build_class__",  # Required for class definitions
            "True", "False", "None", "int", "float", "str", "bool", "list",
            "dict", "tuple", "set", "frozenset", "range", "enumerate", "zip",
            "map", "filter", "sorted", "reversed", "len", "min", "max", "sum",
            "abs", "round", "isinstance", "issubclass", "type", "super",
            "property", "staticmethod", "classmethod", "print", "repr",
            "hasattr", "ValueError", "TypeError", "KeyError", "IndexError",
            "AttributeError", "RuntimeError", "Exception", "NotImplementedError",
            "StopIteration", "object", "slice", "any", "all",
        )
        if (isinstance(__builtins__, dict) and name in __builtins__)
        or (not isinstance(__builtins__, dict) and hasattr(__builtins__, name))
    }
    # Allow __import__ for whitelisted modules only
    safe_builtins["__import__"] = __builtins__["__import__"] if isinstance(__builtins__, dict) else __builtins__.__import__

    namespace = {
        "__builtins__": safe_builtins,
        "__name__": "__custom_transformer__",
    }
    exec(code, namespace)  # noqa: S102 - AST-validated above

    if class_name not in namespace:
        raise ValueError(
            f"Class '{class_name}' not found in custom code. "
            f"Available: {[k for k in namespace if not k.startswith('_')]}"
        )

    cls = namespace[class_name]

    # Extract constructor kwargs (exclude code/class_name/description)
    constructor_params = {
        k: v for k, v in params.items()
        if k not in ("code", "class_name", "description")
    }

    return cls(**constructor_params)
