# DAG-Based Feature Pipeline

## Problem

The current `PipelineSpec` is a flat ordered list of steps. This creates three issues:

1. **Ordering burden on the LLM** — the LLM must emit steps in correct dependency order. If step C needs the output of steps A and B, the LLM must place A and B before C. With complex feature graphs this is error-prone.

2. **No parallelism** — independent branches (e.g. extract datetime features vs compute rolling aggregates) run sequentially even though they don't share state.

3. **Post-hoc dependency analysis** — the autotrain agent already has `analyze_feature_dependencies_tool` which makes an extra LLM call to figure out execution order. A DAG makes this structural.

## Proposal

Add an optional `depends_on` field to `StepSpec`. When present on any step, the compiler builds a DAG and resolves execution order via topological sort. When absent on all steps, the pipeline behaves identically to today (flat sequential).

### Spec Changes

```python
# schema.py
class StepSpec(BaseModel):
    id: str
    type: str
    columns: Optional[List[str]] = None
    params: Dict = {}
    description: Optional[str] = None
    depends_on: Optional[List[str]] = None  # NEW — step IDs this step requires
```

```python
# schema.py
class PipelineSpec(BaseModel):
    version: str = "2.0"  # stays 2.0 — depends_on is additive, not breaking
    steps: List[StepSpec] = []
```

### Example Spec

```json
{
  "version": "2.0",
  "steps": [
    {
      "id": "extract_dow",
      "type": "DateTimeExtractTransformer",
      "columns": ["order_date"],
      "params": {"components": ["dayofweek"]},
      "depends_on": []
    },
    {
      "id": "rolling_sales",
      "type": "RollingAggTransformer",
      "columns": ["sales"],
      "params": {"group_by": ["store_id"], "window": 7, "operation": "mean", "order_by": "order_date"},
      "depends_on": []
    },
    {
      "id": "dow_sales_interaction",
      "type": "ExpressionTransformer",
      "params": {"expression": "order_date_dayofweek * sales_mean_7", "output_column": "dow_sales_x"},
      "depends_on": ["extract_dow", "rolling_sales"]
    },
    {
      "id": "drop_raw_date",
      "type": "DropColumnsTransformer",
      "params": {"columns": ["order_date"]},
      "depends_on": ["extract_dow", "rolling_sales"]
    }
  ]
}
```

This forms the graph:

```
extract_dow ──┬──> dow_sales_interaction
              ├──> drop_raw_date
rolling_sales ┘
```

Steps `extract_dow` and `rolling_sales` have no dependencies so they can run in parallel. `dow_sales_interaction` and `drop_raw_date` wait for both to complete, then they can also run in parallel.

## Implementation Plan

### Phase 1: Schema + Validation (no runtime changes)

**Files**: `schema.py`

1. Add `depends_on: Optional[List[str]] = None` to `StepSpec`
2. Add validation in `PipelineSpec`:
   - All `depends_on` IDs must reference existing step IDs
   - No cycles (topological sort must succeed)
   - No self-references
3. Add `validate_spec()` check: if any step has `depends_on`, verify the DAG is valid

```python
# In validate_spec():
def _validate_dag(spec: PipelineSpec) -> None:
    """Validate DAG constraints if any step uses depends_on."""
    has_dag = any(step.depends_on is not None for step in spec.steps)
    if not has_dag:
        return  # flat pipeline, no DAG validation needed

    step_ids = {step.id for step in spec.steps}
    for step in spec.steps:
        if step.depends_on:
            for dep in step.depends_on:
                if dep not in step_ids:
                    raise ValueError(f"Step '{step.id}' depends on unknown step '{dep}'")
                if dep == step.id:
                    raise ValueError(f"Step '{step.id}' cannot depend on itself")

    # Cycle detection via topological sort
    _topological_sort(spec.steps)  # raises ValueError on cycle
```

**Tests**: Spec with valid DAG parses. Spec with cycle raises. Spec with missing dep raises. Flat spec (no `depends_on`) still works.

### Phase 2: DAG Compiler

**Files**: `compiler.py`, new `dag.py`

Create a `compile_dag()` function that:
1. Builds an adjacency graph from `depends_on`
2. Topologically sorts steps into execution "stages" (groups of independent steps)
3. Returns a `DAGPipeline` (or falls back to `DataFramePipeline` for flat specs)

```python
# dag.py
from collections import defaultdict, deque

def topological_stages(steps: list[StepSpec]) -> list[list[StepSpec]]:
    """Group steps into parallel execution stages via Kahn's algorithm.

    Returns a list of stages. Steps within a stage have no mutual
    dependencies and can run in parallel.
    """
    step_map = {s.id: s for s in steps}
    in_degree = {s.id: 0 for s in steps}
    dependents = defaultdict(list)  # step_id -> list of steps that depend on it

    for step in steps:
        for dep in (step.depends_on or []):
            in_degree[step.id] += 1
            dependents[dep].append(step.id)

    stages = []
    queue = deque(sid for sid, deg in in_degree.items() if deg == 0)

    while queue:
        # All items currently in queue have in_degree 0 — they form a parallel stage
        stage = []
        next_queue = deque()
        while queue:
            sid = queue.popleft()
            stage.append(step_map[sid])
            for dependent in dependents[sid]:
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    next_queue.append(dependent)
        stages.append(stage)
        queue = next_queue

    # Check for cycles
    processed = sum(len(s) for s in stages)
    if processed != len(steps):
        raise ValueError("Cycle detected in step dependencies")

    return stages
```

Update `compile_spec()`:

```python
# compiler.py
def compile_spec(spec: PipelineSpec) -> DataFramePipeline:
    has_dag = any(step.depends_on is not None for step in spec.steps)
    if has_dag:
        return _compile_dag(spec)
    return _compile_flat(spec)  # existing logic
```

### Phase 3: DAGPipeline Runtime

**Files**: new `dag_pipeline.py`

```python
class DAGPipeline(BaseEstimator, TransformerMixin):
    """Pipeline that executes steps in DAG-resolved stage order.

    Steps within the same stage are independent and can be run
    concurrently (future optimization). Steps across stages run
    sequentially — each stage sees the DataFrame produced by all
    prior stages.
    """

    def __init__(self, stages: list[list[tuple[str, TransformerMixin]]]):
        # stages[i] = [(step_id, transformer), ...] — all independent
        self.stages = stages

    def fit(self, X: pd.DataFrame, y=None):
        Xt = X.copy()
        for stage in self.stages:
            # All transformers in a stage fit on the same Xt
            for name, transformer in stage:
                transformer.fit(Xt, y)
            # Then apply all transforms (order within stage doesn't matter
            # because they read from the same Xt snapshot)
            Xt_snapshot = Xt.copy()
            for name, transformer in stage:
                result = transformer.transform(Xt_snapshot)
                # Merge result columns back into Xt
                new_cols = [c for c in result.columns if c not in Xt.columns]
                for col in new_cols:
                    Xt[col] = result[col]
                # Handle column modifications (existing cols that changed)
                modified_cols = [c for c in result.columns if c in Xt.columns and c in (transformer.columns if hasattr(transformer, 'columns') else [])]
                for col in modified_cols:
                    Xt[col] = result[col]
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        # Same logic but without fit
        ...
```

**Key design decisions**:

- **Snapshot per stage**: Each stage gets a snapshot of the DataFrame. Transforms within a stage read from the snapshot (not from each other's outputs). This prevents order-dependence within a stage.
- **Merge strategy**: New columns are added. Modified columns are overwritten. Dropped columns are removed. This needs careful handling — see "Tricky Bits" below.
- **Sequential first, parallel later**: Start with sequential execution within stages. Add `joblib.Parallel` or `concurrent.futures` as an optimization later.

### Phase 4: LLM Integration

**Files**: `feature_engineer.py` system prompts

Update the `generate()` and `generate_next()` prompts to tell the LLM about `depends_on`:

```
Each step_spec can optionally include "depends_on": ["step_id_1", "step_id_2"]
to declare that this step requires columns created by other steps.
If a step only uses original dataset columns, omit depends_on or set it to [].
```

The LLM doesn't need to worry about ordering — just declare dependencies. The compiler handles the rest.

### Phase 5: Autotrain Agent Integration

**Files**: `feature_engineering.py` handler, `batch_apply_steps_tool`

- `batch_apply_steps_tool` already accepts a list of step specs and creates a single `PipelineSpec`. No changes needed — the DAG resolution happens at compile time.
- `analyze_feature_dependencies_tool` can be simplified to just set `depends_on` on each step based on column analysis, rather than trying to reorder indices.
- Interactive mode: as the user approves features one at a time, the `depends_on` edges naturally build up. A new feature can reference previously applied feature IDs.

## Tricky Bits

### 1. Schema Propagation

The hardest problem. Within a stage, transformer A might create column `foo` that transformer B in the **next** stage needs. The compiler needs to know the intermediate schema at each stage to validate column references.

**Options**:
- **Lazy (recommended for v1)**: Don't validate column existence at compile time. Let it fail at runtime with a clear error: "Step 'X' references column 'foo' which doesn't exist. Check depends_on."
- **Eager (future)**: Add an `output_schema` field to `StepSpec` that declares what columns a step adds/removes/modifies. The compiler walks the DAG and checks that every step's input columns exist in the union of original columns + upstream output columns.

### 2. Column Conflicts Within a Stage

If two steps in the same stage both modify column `age`, the result is ambiguous.

**Solution**: Validate at compile time that steps within a stage don't write to the same columns. Steps that create new columns (ExpressionTransformer) are fine. Steps that modify existing columns (StandardScaler on `age`) must not share target columns with other steps in the same stage.

### 3. Drop Steps

`DropColumnsTransformer` is tricky in a DAG because you need to ensure no downstream step needs the dropped column.

**Solution**: Drop steps should depend on all steps that read the column being dropped. The compiler can warn if a drop step doesn't depend on all readers.

### 4. Fitted State Serialization

Currently `save_pipeline` / `load_pipeline` use cloudpickle on the entire `DataFramePipeline`. A `DAGPipeline` has a `stages` structure instead of flat `steps`. Cloudpickle should handle this transparently since it serializes the object graph. But test this explicitly.

### 5. Backwards Compatibility

A `PipelineSpec` with no `depends_on` on any step is exactly today's flat pipeline. The compiler detects this and returns a `DataFramePipeline`. Zero breaking changes for existing specs in the database.

## Testing Strategy

1. **Unit: `topological_stages()`** — Valid DAG, diamond dependency, linear chain, single node, disjoint subgraphs, cycle detection
2. **Unit: `DAGPipeline.fit_transform()`** — Two independent branches merge into one step, verify output columns are correct
3. **Integration: `compile_spec()` with DAG** — Full round-trip: spec with `depends_on` -> compile -> fit -> transform -> verify output
4. **Regression: Flat specs** — All existing 88 tests must still pass unchanged
5. **Edge cases**: Step depends on itself, step depends on non-existent ID, two steps create same output column in same stage

## Recommended Implementation Order

| Step | Effort | Risk | What it unblocks |
|------|--------|------|-----------------|
| 1. `depends_on` field + validation | Small | None | Everything else |
| 2. `topological_stages()` | Small | None | DAGPipeline |
| 3. `DAGPipeline` (sequential within stages) | Medium | Medium | Full DAG execution |
| 4. `compile_spec()` DAG branch | Small | Low | End-to-end usage |
| 5. LLM prompt updates | Small | Low | Agent generates DAGs |
| 6. Parallel execution within stages | Medium | Medium | Performance gain |
| 7. Schema propagation validation | Large | High | Compile-time safety |

Steps 1-4 give you a working DAG pipeline. Step 5 lets the LLM use it. Steps 6-7 are optimizations you can add later.
