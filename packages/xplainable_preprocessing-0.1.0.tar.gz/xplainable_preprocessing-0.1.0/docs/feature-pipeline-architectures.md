# Feature Pipeline Architectures: Alternatives Analysis

## The Core Problem

How should an LLM express feature transformations so they're executable, composable, and don't require manual ordering?

The current system (after the inline step_spec work) has the LLM produce flat, ordered step specs. This works but pushes ordering logic onto the LLM and limits composability. There are several fundamentally different paradigms worth considering.

---

## 1. DAG Pipeline

**See**: `dag-pipeline-proposal.md` for full implementation plan.

Steps declare dependencies via `depends_on`. The compiler topologically sorts and groups into parallel execution stages.

```json
{
  "steps": [
    {"id": "extract_dow", "type": "DateTimeExtractTransformer", "depends_on": []},
    {"id": "rolling_sales", "type": "RollingAggTransformer", "depends_on": []},
    {"id": "interaction", "type": "ExpressionTransformer", "depends_on": ["extract_dow", "rolling_sales"]}
  ]
}
```

**Strengths**:
- Closest to current model — additive change to StepSpec
- Explicit dependencies are debuggable and inspectable
- Enables parallel execution within stages
- LLM no longer needs to worry about ordering

**Weaknesses**:
- LLM still thinks in terms of transformer types and wiring
- Schema propagation between stages is complex to validate at compile time
- Adding a step mid-graph requires understanding the full dependency structure

**Effort**: Medium. Builds directly on existing schema/compiler/pipeline.

**Best for**: Incremental improvement with low risk.

---

## 2. Declarative Column Specs

Instead of "run these transformers in this order", the LLM declares "I want these output columns defined by these expressions." The compiler resolves what transformers to use and in what order.

### Spec Format

```json
{
  "version": "3.0",
  "target_columns": {
    "age_income_ratio": {
      "expr": "age / income",
      "description": "Ratio of age to income"
    },
    "log_salary": {
      "expr": "log(salary)",
      "description": "Log-transformed salary to reduce skewness"
    },
    "order_dayofweek": {
      "extract": "dayofweek",
      "from": "order_date",
      "description": "Day of week from order timestamp"
    },
    "sales_7d_avg": {
      "rolling": "mean",
      "column": "sales",
      "window": 7,
      "group_by": ["store_id"],
      "order_by": "order_date",
      "description": "7-day rolling average sales per store"
    },
    "risk_category": {
      "bin": "risk_score",
      "strategy": "quantile",
      "n_bins": 5,
      "description": "Risk score bucketed into quintiles"
    }
  },
  "drop_columns": ["order_date", "customer_name"],
  "transformations": {
    "salary": {"impute": "median"},
    "country": {"encode": "onehot"}
  }
}
```

### How the Compiler Works

1. Parse `target_columns` — each is a column definition with a known pattern (`expr`, `extract`, `rolling`, `bin`, etc.)
2. Map each pattern to a transformer type:
   - `expr` → `ExpressionTransformer`
   - `extract` → `DateTimeExtractTransformer`
   - `rolling` → `RollingAggTransformer`
   - `bin` → `KBinsDiscretizer`
3. Infer dependencies by parsing column references in expressions
4. Topologically sort and compile to a `DataFramePipeline` (or `DAGPipeline`)

### What the LLM Prompt Looks Like

```
You are a data scientist. Given a dataset summary, declare what new columns
would improve model performance.

Available column definition patterns:
- expr: pandas expression (e.g. "col_a * col_b", "log(price)")
- extract: datetime component (dayofweek, month, hour, year)
- rolling: rolling window aggregate (mean, sum, std, min, max)
- lag: grouped lag features
- bin: discretize continuous values
- custom: Python code for anything else

Respond with a JSON object listing desired columns:
{"target_columns": {"column_name": {"expr": "...", "description": "..."}}}
```

**Strengths**:
- Better abstraction for LLMs — "what do you want?" not "how do you build it?"
- Dependencies are implicit (parsed from expressions) — no `depends_on` to manage
- Closer to how data scientists think: "I want a column called X"
- The DSL is small and learnable — ~6 patterns cover 95% of feature engineering
- Compiler owns all transformer selection logic — single source of truth
- Naturally deduplicates: two recommendations that want the same column just merge

**Weaknesses**:
- Requires designing a column definition DSL (the patterns above)
- Expression parsing needs to extract column references reliably
- Complex features (custom sklearn transformers) still need an escape hatch
- More upfront design than DAG, which is purely additive

**Effort**: Medium-large. New spec format, new compiler path, new prompt design.

**Best for**: Clean long-term architecture. Ideal if rebuilding the spec layer.

---

## 3. Expression Graph (Polars-Style Lazy Evaluation)

Every feature is a lazy column expression. The engine builds a computation graph, optimizes it (predicate pushdown, common subexpression elimination, projection pushdown), then executes.

### What It Looks Like

```python
import polars as pl

features = (
    df.lazy()
    .with_columns([
        (pl.col("age") / pl.col("income")).alias("age_income_ratio"),
        pl.col("salary").log().alias("log_salary"),
        pl.col("order_date").dt.weekday().alias("order_dow"),
        pl.col("sales").rolling_mean(7).over("store_id").alias("sales_7d_avg"),
    ])
    .drop(["order_date", "customer_name"])
    .collect()
)
```

### Architecture

- LLM generates Polars expressions (or a JSON DSL that compiles to Polars)
- The lazy evaluation engine handles ordering, optimization, and execution
- No manual pipeline construction needed — the engine IS the pipeline

### Spec Format (JSON → Polars)

```json
{
  "expressions": [
    {"alias": "age_income_ratio", "expr": "col('age') / col('income')"},
    {"alias": "log_salary", "expr": "col('salary').log()"},
    {"alias": "order_dow", "expr": "col('order_date').dt.weekday()"}
  ]
}
```

A thin compiler converts these to `pl.Expr` objects.

**Strengths**:
- 10-100x faster than sequential pandas for large datasets
- Automatic query optimization — the engine handles parallelism and ordering
- No pipeline/DAG/ordering logic to maintain — the engine does it all
- Polars expressions are more powerful and composable than sklearn transformers
- Memory efficient: streaming execution, no intermediate DataFrame copies

**Weaknesses**:
- Requires Polars dependency (currently using pandas + sklearn)
- sklearn transformers (StandardScaler, OneHotEncoder, etc.) don't work with Polars natively — need wrappers or reimplementation
- Fit/transform semantics don't exist in Polars — need to handle stateful transforms (e.g., imputer learns mean from training data, applies to new data) separately
- LLMs are more familiar with pandas than Polars syntax
- Large migration from current architecture

**Effort**: Large. New runtime, new serialization, adapter layer for sklearn.

**Best for**: Performance-critical pipelines with large datasets. Consider if pandas becomes the bottleneck.

---

## 4. Feature Store Pattern

Each feature is a standalone, versioned computation with a defined contract: input columns, output columns, and the transformation logic. Features are registered in a catalog and can be composed across models.

### Architecture

```
FeatureRegistry
├── age_income_ratio (v1)
│   ├── inputs: [age, income]
│   ├── outputs: [age_income_ratio]
│   ├── transformer: ExpressionTransformer(...)
│   └── fitted_state: {...}
├── sales_7d_avg (v2)
│   ├── inputs: [sales, store_id, order_date]
│   ├── outputs: [sales_mean_7]
│   ├── transformer: RollingAggTransformer(...)
│   └── fitted_state: {...}
└── ...
```

### How It Works

1. LLM recommends features → each becomes a registered feature with input/output contract
2. User selects features → system resolves dependencies from input/output declarations
3. Compiler builds a pipeline from selected features (ordering resolved from contracts)
4. Features are cached — once computed for a dataset, they're reused across models
5. Features are versioned — changing the definition creates a new version

### Spec Format

```json
{
  "features": ["age_income_ratio@v1", "sales_7d_avg@v2", "order_dow@v1"],
  "drop": ["order_date"],
  "target": "churn"
}
```

The spec is just a list of feature references. The registry has all the logic.

**Strengths**:
- Features become reusable assets across autotrain runs
- Natural caching: compute once, use everywhere
- Versioning: change a feature definition without breaking existing models
- Input/output contracts make dependency resolution trivial
- Testing is per-feature, not per-pipeline
- Aligns with industry direction (Feast, Tecton, Featureform)

**Weaknesses**:
- Heavyweight for single-run autotrain — overhead only pays off with feature reuse
- Requires a feature registry (new infrastructure)
- Fitted state becomes per-feature — serialization/loading is more complex
- LLM needs to know what features already exist in the registry (growing context)

**Effort**: Large. New registry, versioning system, caching layer.

**Best for**: Platform with many models sharing features. Overkill for single autotrain runs today, but could become the right abstraction as the platform scales.

---

## 5. Auto-Feature Synthesis (Featuretools-Style)

Algorithmic feature generation, not LLM-driven. Given columns and their types, systematically generate all meaningful combinations and score them against the target.

### How It Works

1. Define "primitives": ratio, product, sum, difference, log, sqrt, datetime_extract, grouped_agg
2. Enumerate: for each pair of numeric columns, generate ratio, product, difference. For each datetime, extract all components. For each numeric + categorical pair, generate grouped aggregates.
3. Score: compute mutual information (or correlation, or permutation importance) between each candidate feature and the target variable
4. Rank and select: keep the top N features

### Integration with Current System

This doesn't replace LLM recommendations — it complements them:

```
Auto-mode pipeline:
1. Auto-feature synthesis → 50 candidate features, scored
2. Filter to top 10 by mutual information
3. LLM reviews candidates → refines, combines, adds domain insight
4. Final feature set → compile and apply
```

Or simpler:

```
Auto-mode pipeline:
1. LLM generates 5 creative features (current flow)
2. Auto-synthesis generates 20 mechanical features (ratios, interactions)
3. Score all 25 against target
4. Keep top N
```

**Strengths**:
- Exhaustive: finds features the LLM wouldn't think of (e.g., `col7 * col13 / col2` that happens to be predictive)
- No hallucination risk — purely data-driven
- Deterministic and reproducible
- Can run without any LLM calls
- Well-established technique (Featuretools, AutoFeat, tsfresh)

**Weaknesses**:
- Combinatorial explosion: N columns → O(N^2) pairwise features, O(N^3) for triples
- Generates many useless features — needs aggressive filtering
- Requires a target variable (supervised) for scoring
- Features lack semantic meaning — "col3_times_col7" isn't interpretable
- Doesn't handle complex domain-specific features (e.g., "customer lifetime value")

**Effort**: Medium. Can be implemented as a standalone tool alongside LLM recommendations.

**Best for**: Auto-mode where speed matters more than interpretability. Excellent complement to LLM-generated features.

---

## Comparison Matrix

| Approach | Ordering Problem | LLM Cognitive Load | Performance | Reusability | Migration Effort |
|----------|-----------------|-------------------|-------------|-------------|-----------------|
| **Current (flat)** | LLM must order | High | Sequential | None | N/A |
| **DAG** | Compiler resolves | Medium | Parallelizable | None | Small |
| **Declarative columns** | Implicit from expressions | Low | Parallelizable | None | Medium |
| **Expression graph** | Engine resolves | Low | Optimal | None | Large |
| **Feature store** | Contracts resolve | Low | Cached | Full reuse | Large |
| **Auto-synthesis** | N/A (scored) | None | Parallel | Cacheable | Medium |

## Recommended Path

### Short-term (now → 1 month)
**DAG** — additive to existing spec, solves the immediate ordering problem, low risk.

### Medium-term (1-3 months)
**Declarative column specs** — design the DSL, build a compiler that maps column definitions to the existing transformer infrastructure. This becomes the LLM-facing abstraction while the DAG handles execution underneath.

### Long-term (3-6 months)
**Feature store** — as the platform handles more models, feature reuse becomes valuable. The declarative column spec format naturally evolves into feature definitions with input/output contracts.

### Orthogonal (can start anytime)
**Auto-feature synthesis** — independent of pipeline architecture. Add as an auto-mode enhancement alongside LLM recommendations. Start with pairwise numeric interactions + datetime extractions, score by mutual information, filter aggressively.

### Consider later
**Expression graph (Polars)** — only pursue if pandas performance becomes a bottleneck on real workloads. The migration cost is high and the current DataFrame sizes in autotrain may not justify it.

---

## Architecture Layering

These approaches aren't mutually exclusive. The ideal architecture layers them:

```
┌─────────────────────────────────────────┐
│  LLM / Auto-Synthesis (feature ideas)   │  ← what columns to create
├─────────────────────────────────────────┤
│  Declarative Column Specs (DSL)         │  ← user-facing format
├─────────────────────────────────────────┤
│  DAG Compiler (dependency resolution)   │  ← execution planning
├─────────────────────────────────────────┤
│  Pipeline Runtime (execution)           │  ← fit/transform
├─────────────────────────────────────────┤
│  Feature Store (versioning + caching)   │  ← persistence + reuse
└─────────────────────────────────────────┘
```

Each layer can be built independently. The inline step_spec work we just completed is the foundation — it gives us structured specs flowing from the LLM. Every architecture above builds on that.
