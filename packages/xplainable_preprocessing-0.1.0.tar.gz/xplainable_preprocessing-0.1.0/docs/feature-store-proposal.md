# Feature Store for Multi-Dataset AI Agent

## Why Feature Store

The trigger for a feature store isn't "multiple models" — it's **multiple datasets with relationships**. When a user brings sales data, inventory data, and customer demographics into the agent, the most valuable features often live at the intersections: customer lifetime value (customers + transactions), inventory turnover (inventory + sales), seasonal demand patterns (sales + calendar).

Without a feature store, each autotrain run is an island. Features are computed from scratch, there's no reuse, no versioning, and no way to express cross-dataset features. The agent treats each dataset as if it's the only one that exists.

With a feature store, features become **first-class assets** that persist across runs, span datasets, and evolve through versions.

---

## Core Concepts

### Feature

A named, versioned computation with a declared contract:

```
Feature: customer_lifetime_value@v2
  Inputs:  transactions.amount, transactions.customer_id, transactions.date
  Output:  customer_lifetime_value (float64)
  Logic:   Sum of transactions per customer, weighted by recency
  Fitted:  None (stateless)
  Created: 2025-03-15
  Used by: churn_model@v3, upsell_model@v1
```

A feature knows what it needs (input columns from which datasets), what it produces (output column name and type), and how to compute it (transformer or expression).

### Dataset Registry

The agent's view of what data exists and how it's structured:

```
Registry:
  sales:       {date, store_id, product_id, amount, quantity}
  customers:   {customer_id, name, signup_date, region, tier}
  inventory:   {product_id, store_id, stock_level, reorder_point, last_restocked}
  calendar:    {date, is_holiday, day_of_week, month, quarter}
```

This is the foundation. Without knowing what datasets exist and their schemas, the agent can't reason about cross-dataset features. The registry is what turns a feature store from a cache into an intelligent system.

### Feature Groups

Related features that share the same input datasets and grain (row-level granularity):

```
FeatureGroup: customer_behavior
  Grain:    one row per customer_id
  Sources:  [customers, transactions]
  Join:     customers.customer_id = transactions.customer_id
  Features:
    - total_spend: sum(transactions.amount)
    - avg_order_value: mean(transactions.amount)
    - days_since_last_order: today - max(transactions.date)
    - order_frequency: count(transactions) / tenure_months
    - lifetime_value: weighted_sum(transactions.amount, recency_weight)
```

Feature groups solve the join problem — instead of each feature independently declaring how to join datasets, the group declares the join once and all features within it share that context.

---

## Architecture

### System Layers

```
┌──────────────────────────────────────────────────────────┐
│  AI Agent (feature discovery + recommendation)           │
│  "I see sales + customers. Here are 12 features I can   │
│   derive across both datasets."                          │
├──────────────────────────────────────────────────────────┤
│  Feature Registry (catalog + versioning + lineage)       │
│  Knows every feature, its contract, its versions,        │
│  what datasets it needs, and what models use it.         │
├──────────────────────────────────────────────────────────┤
│  Feature Compiler (resolution + optimization)            │
│  Given a set of requested features, resolves joins,      │
│  orders computation, deduplicates shared sub-expressions.│
├──────────────────────────────────────────────────────────┤
│  Feature Compute (execution + caching)                   │
│  Runs the compiled plan. Caches results keyed by         │
│  (feature_version, dataset_version, parameters).         │
├──────────────────────────────────────────────────────────┤
│  Storage (feature values + metadata)                     │
│  Persists computed feature values, fitted state,         │
│  and provenance metadata.                                │
└──────────────────────────────────────────────────────────┘
```

### How the Agent Uses It

**Single dataset (current flow, enhanced)**:

1. User uploads `sales.csv`
2. Agent registers dataset: `sales {date, store_id, product_id, amount, quantity}`
3. Agent checks feature registry: "Any existing features that can be computed from `sales` columns?"
4. Registry returns: `sales_7d_avg@v1` (from a previous run), `product_revenue_rank@v2`
5. Agent recommends: reuse 2 existing features + generate 3 new ones
6. New features are registered, computed, and cached

**Multiple datasets (the real payoff)**:

1. User has `sales`, `customers`, `inventory` in their workspace
2. Agent sees all three datasets in the registry
3. Agent reasons: "With sales + customers joined on customer_id, I can compute customer behavior features. With sales + inventory joined on product_id + store_id, I can compute supply/demand features."
4. Agent recommends feature groups:
   - `customer_behavior`: lifetime_value, order_frequency, churn_risk_signals
   - `supply_demand`: stockout_rate, days_of_supply, demand_volatility
   - `temporal`: day_of_week_sales, monthly_seasonality_index
5. User selects features → compiler resolves joins, orders computation, executes
6. All features are registered and cached for future models

**Cross-run reuse**:

1. User trains churn model using `customer_behavior` features
2. Later, user trains upsell model — agent sees `customer_behavior@v1` already exists
3. Agent: "I can reuse lifetime_value and order_frequency from your churn model's features. Plus I recommend 4 new features specific to upsell."
4. Only the 4 new features are computed. The 2 reused features are loaded from cache.

---

## Data Model

### Feature Definition

```python
class FeatureDefinition(BaseModel):
    """A versioned, reusable feature computation."""

    # Identity
    name: str                          # e.g. "customer_lifetime_value"
    version: int                       # auto-incremented
    feature_group: Optional[str]       # e.g. "customer_behavior"

    # Contract
    input_datasets: List[str]          # e.g. ["customers", "transactions"]
    input_columns: Dict[str, List[str]]  # dataset -> columns needed
    output_column: str                 # column name this feature produces
    output_dtype: str                  # e.g. "float64"

    # Computation
    computation_type: str              # "expression", "transformer", "aggregation", "custom"
    spec: Dict[str, Any]              # the actual computation spec (varies by type)
    # For expressions:  {"expr": "amount / quantity"}
    # For transformers: {"type": "RollingAggTransformer", "params": {...}}
    # For aggregations: {"agg": "sum", "column": "amount", "group_by": ["customer_id"]}
    # For custom:       {"code": "...", "class_name": "..."}

    # Join context (for cross-dataset features)
    join_spec: Optional[JoinSpec]      # how to join input datasets

    # Metadata
    description: str
    created_by: str                    # user_id or "agent"
    created_at: str
    tags: List[str] = []               # e.g. ["temporal", "behavioral", "financial"]

    # State
    is_stateful: bool = False          # does this feature need fit/transform?
    fitted_state_uri: Optional[str]    # pointer to serialized fitted state
```

### Join Specification

```python
class JoinSpec(BaseModel):
    """How to join multiple datasets for a feature group."""

    left_dataset: str
    right_dataset: str
    left_on: List[str]                 # join columns in left dataset
    right_on: List[str]                # join columns in right dataset
    how: str = "left"                  # left, inner, outer
    chain: Optional['JoinSpec'] = None  # for multi-way joins: A join B join C
```

Example:
```json
{
  "left_dataset": "customers",
  "right_dataset": "transactions",
  "left_on": ["customer_id"],
  "right_on": ["customer_id"],
  "how": "left"
}
```

### Feature Instance (Computed Values)

```python
class FeatureInstance(BaseModel):
    """A computed + cached feature for a specific dataset version."""

    feature_ref: str                   # "customer_lifetime_value@v2"
    dataset_hash: str                  # hash of input data (for cache invalidation)
    computed_at: str
    row_count: int
    storage_uri: str                   # where the computed column is stored
    compute_time_ms: int
    fitted_state_uri: Optional[str]    # for stateful features
```

### Lineage

```python
class FeatureLineage(BaseModel):
    """Tracks what models use which features."""

    feature_ref: str
    model_id: str
    model_version_id: str
    used_at: str
```

This answers "if I change `customer_lifetime_value`, which models are affected?"

---

## The Join Problem

Cross-dataset features are where the real complexity lives. The system needs to answer:

1. **How do these datasets relate?** — The agent needs to discover or be told join keys.
2. **What grain should the features be at?** — Row-level in which dataset? If joining customers (1 row per customer) with transactions (many rows per customer), features need aggregation.
3. **When do joins happen?** — Before feature computation (materialize a wide table) or during (compute each feature with its own join)?

### Approach: Explicit Feature Groups with Join Specs

The agent declares feature groups with explicit join context:

```json
{
  "feature_group": "customer_behavior",
  "grain": "customer_id",
  "base_dataset": "customers",
  "joins": [
    {
      "dataset": "transactions",
      "on": {"customers.customer_id": "transactions.customer_id"},
      "how": "left"
    }
  ],
  "features": {
    "total_spend": {"agg": "sum", "column": "transactions.amount"},
    "avg_order_value": {"agg": "mean", "column": "transactions.amount"},
    "order_count": {"agg": "count", "column": "transactions.customer_id"},
    "days_since_last_order": {
      "expr": "(today() - max(transactions.date)).dt.days"
    }
  }
}
```

The compiler materializes the join once, then computes all features in the group on the joined DataFrame.

### How the Agent Discovers Joins

Three strategies, in order of preference:

1. **Schema matching**: If `customers.customer_id` and `transactions.customer_id` share a name, infer the join. Works for well-named columns.

2. **Foreign key metadata**: If the dataset registry includes foreign key declarations, use them directly. Most reliable but requires metadata.

3. **LLM inference**: Show the agent both schemas and ask it to identify relationships. Works for messy data where column names don't match (e.g., `customers.id` ↔ `orders.cust_id`).

In practice, the agent would try (1), fall back to (3), and allow the user to correct via (2).

---

## Agent Integration

### Feature Discovery Prompt

When the agent sees multiple datasets, it needs a new capability: **cross-dataset feature recommendation**.

```
You are a data scientist with access to multiple datasets. Given their schemas
and relationships, recommend features that combine information across datasets.

Available datasets:
- sales: {date, store_id, product_id, amount, quantity}
- customers: {customer_id, name, signup_date, region, tier}
- inventory: {product_id, store_id, stock_level, reorder_point}

Identified relationships:
- sales.customer_id → customers.customer_id (if customer_id existed in sales)
- sales.product_id + sales.store_id → inventory.product_id + inventory.store_id

For each feature group, declare:
1. The grain (what does one row represent?)
2. The join(s) needed
3. The features to compute

Format as JSON with feature group definitions.
```

### Reuse Discovery Prompt

Before generating new features, the agent checks the registry:

```
The following features have been previously computed for datasets with
similar schemas:

- customer_lifetime_value@v2 (inputs: [customer_id, amount, date])
- sales_7d_avg@v1 (inputs: [sales, store_id, date])
- product_revenue_rank@v1 (inputs: [product_id, amount])

The current dataset has columns: {date, store_id, product_id, amount, quantity}

Which existing features can be reused? Which new features should be created?
```

### Autotrain Pipeline Changes

```
Current autotrain flow:
1. Upload dataset
2. Summarize → recommend labels
3. Data prep (inline step_specs) ← we just built this
4. Feature engineering (inline step_specs) ← we just built this
5. Train model

Enhanced flow with feature store:
1. Upload dataset(s)
2. Register in dataset registry
3. Agent discovers cross-dataset relationships
4. Summarize → recommend labels
5. Data prep (inline step_specs, per dataset)
6. Feature engineering:
   a. Check registry for reusable features → load from cache
   b. LLM recommends new features (single-dataset + cross-dataset)
   c. Auto-synthesis generates candidate features (optional)
   d. Compile feature plan (resolve joins, order computation)
   e. Execute and cache
   f. Register new features in store
7. Train model
8. Record lineage (model → features → datasets)
```

---

## Caching Strategy

### Cache Key

A feature instance is uniquely identified by:

```
cache_key = hash(feature_name, feature_version, dataset_hash, params_hash)
```

Where `dataset_hash` is a content hash of the input data (or a version identifier if datasets are versioned).

### Cache Invalidation

- **Data changes**: If the dataset is re-uploaded or updated, `dataset_hash` changes → cache miss → recompute.
- **Feature definition changes**: New version → new `feature_version` → cache miss.
- **Parameter changes**: If the feature has tunable parameters (e.g., window size for rolling features), `params_hash` changes.

### What to Cache

- **Computed column values**: The actual feature column (e.g., a parquet file or Redis blob). Fast to load, avoids recomputation.
- **Fitted state**: For stateful features (imputers, scalers), the fitted parameters. Needed for transform-only (inference) mode.
- **Metadata**: Compute time, row count, null rate, value distribution. Useful for the agent to assess feature quality.

### Storage Tiers

```
Hot:   Redis (active autotrain runs, features being iterated on)
Warm:  Object storage / S3 (computed features from recent runs)
Cold:  Database metadata only (feature definitions, lineage, no values)
```

For most autotrain workloads, the hot tier is sufficient — features are computed during the run and used immediately. The warm tier matters when a user starts a new run and wants to reuse features from a previous run.

---

## Versioning

### When to Create a New Version

- User modifies a feature's computation logic
- Agent refines a feature (e.g., changes window size from 7 to 14)
- Upstream dataset schema changes (column renamed, type changed)

### Version Semantics

```
customer_lifetime_value@v1  →  sum(amount) per customer
customer_lifetime_value@v2  →  sum(amount) per customer, weighted by recency
customer_lifetime_value@v3  →  same as v2 but with 90-day lookback window
```

Each version is immutable. Models reference specific versions. Changing a version's logic is not allowed — create a new version instead.

### Migration

When the agent recommends updating a feature:

```
Agent: "I notice customer_lifetime_value@v1 doesn't account for recency.
        I recommend creating v2 with recency weighting. This would affect
        churn_model@v3 which currently uses v1.
        Options:
        1. Create v2 and retrain churn_model with it
        2. Create v2 for new models only, keep v1 for churn_model
        3. Skip"
```

---

## Implementation Phases

### Phase 1: Dataset Registry (foundation)

**What**: The agent knows what datasets exist and their schemas.

**Scope**:
- `DatasetRegistry` class: register dataset name + schema + sample stats
- Store in `DatasetSpec` on `TrainingRunState` (already has `schema` field)
- Agent summarizer populates registry on dataset upload
- Multi-dataset support: state can hold multiple `DatasetSpec` entries

**Why first**: Everything else depends on the agent knowing what data is available.

**Effort**: Small. Mostly wiring existing summarization output into a registry structure.

### Phase 2: Feature Definitions + Registry

**What**: Features are defined as standalone, named computations with contracts.

**Scope**:
- `FeatureDefinition` model (as described above, minus join specs)
- `FeatureRegistry`: in-memory store during a run, persisted to DB between runs
- LLM-generated features are automatically registered after application
- Registry query: "what features can be computed from these columns?"

**Why second**: Makes features queryable and reusable within a run. Lays foundation for cross-run reuse.

**Effort**: Medium. New models, storage, and registry query logic.

### Phase 3: Cross-Run Reuse + Caching

**What**: Features computed in one run can be reused in another.

**Scope**:
- Feature instance caching (computed values keyed by feature version + data hash)
- Agent checks registry before generating new features
- "Reuse discovery" prompt for the LLM
- Cache hit/miss metrics in telemetry

**Why third**: This is where the feature store starts paying for itself. But it requires Phase 2's registry to know what to look for.

**Effort**: Medium. Cache infrastructure, hit/miss logic, agent prompt changes.

### Phase 4: Cross-Dataset Features

**What**: Features that join multiple datasets.

**Scope**:
- `JoinSpec` model and feature group definitions
- Join discovery (schema matching + LLM inference)
- Feature compiler that resolves joins before computing features
- Cross-dataset feature recommendation prompt for the LLM

**Why fourth**: This is the highest-value capability but also the most complex. Requires all prior phases to be stable.

**Effort**: Large. Join resolution, multi-dataset state management, new prompts.

### Phase 5: Lineage + Impact Analysis

**What**: Track which models use which features from which datasets.

**Scope**:
- `FeatureLineage` records: feature → model mapping
- Impact analysis: "if I change this feature, which models break?"
- Agent-driven migration recommendations
- Dashboard visibility into feature usage

**Why last**: Operational concern. Important for production but not needed to get value from the feature store.

**Effort**: Medium. Mostly bookkeeping and UI.

---

## When to Start

The feature store becomes worth building when **any** of these are true:

1. **Users bring multiple related datasets** to the agent (the join problem)
2. **Users run multiple autotrain sessions** on similar data and waste time regenerating the same features
3. **Feature quality matters** — you want to curate, version, and test features as assets rather than treating them as ephemeral computation
4. **The platform has a concept of "workspace"** where datasets and models persist across sessions

If none of these are true today, the DAG pipeline (from `dag-pipeline-proposal.md`) is the right next step. The feature store is the step after that — and the DAG compiler becomes a building block inside the feature store's compute layer.

---

## Relationship to Other Proposals

```
Current state (flat step_specs)
    │
    ▼
DAG Pipeline (dag-pipeline-proposal.md)
    │   Adds: dependency resolution, parallel execution
    │   Solves: LLM ordering burden
    │
    ▼
Declarative Column Specs (feature-pipeline-architectures.md §2)
    │   Adds: intent-based abstraction for LLMs
    │   Solves: LLM wiring burden (type selection, param construction)
    │
    ▼
Feature Store (this document)
    │   Adds: persistence, versioning, cross-dataset, reuse
    │   Solves: multi-dataset features, redundant computation
    │
    ▼
Auto-Feature Synthesis (feature-pipeline-architectures.md §5)
        Adds: algorithmic feature generation alongside LLM
        Solves: exhaustive exploration the LLM wouldn't think of
```

Each layer builds on the previous. The inline step_spec work we just completed is the foundation for all of them.
