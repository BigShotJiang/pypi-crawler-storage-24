"""Tests for the AST sandbox validator."""

import pytest

from xplainable_preprocessing.sandbox import compile_custom, validate_code


class TestValidateCode:
    def test_safe_code_passes(self):
        code = (
            "import numpy as np\n"
            "from sklearn.base import BaseEstimator, TransformerMixin\n"
            "class MyTransformer(BaseEstimator, TransformerMixin):\n"
            "    def fit(self, X, y=None): return self\n"
            "    def transform(self, X): return X\n"
        )
        validate_code(code)  # should not raise

    def test_forbidden_import_os(self):
        with pytest.raises(ValueError, match="Forbidden import: os"):
            validate_code("import os")

    def test_forbidden_import_subprocess(self):
        with pytest.raises(ValueError, match="Forbidden import: subprocess"):
            validate_code("import subprocess")

    def test_forbidden_import_from(self):
        with pytest.raises(ValueError, match="Forbidden import: os"):
            validate_code("from os import path")

    def test_forbidden_import_sys(self):
        with pytest.raises(ValueError, match="Forbidden import: sys"):
            validate_code("import sys")

    def test_forbidden_import_socket(self):
        with pytest.raises(ValueError, match="Forbidden import: socket"):
            validate_code("import socket")

    def test_forbidden_import_shutil(self):
        with pytest.raises(ValueError, match="Forbidden import: shutil"):
            validate_code("import shutil")

    def test_forbidden_import_requests(self):
        with pytest.raises(ValueError, match="Forbidden import: requests"):
            validate_code("import requests")

    def test_forbidden_call_exec(self):
        with pytest.raises(ValueError, match="Forbidden call: exec"):
            validate_code("exec('print(1)')")

    def test_forbidden_call_eval(self):
        with pytest.raises(ValueError, match="Forbidden call: eval"):
            validate_code("eval('1+1')")

    def test_forbidden_call_open(self):
        with pytest.raises(ValueError, match="Forbidden call: open"):
            validate_code("open('file.txt')")

    def test_forbidden_call___import__(self):
        with pytest.raises(ValueError, match="Forbidden call: __import__"):
            validate_code("__import__('os')")

    def test_forbidden_call_compile(self):
        with pytest.raises(ValueError, match="Forbidden call: compile"):
            validate_code("compile('1+1', '', 'eval')")

    def test_syntax_error(self):
        with pytest.raises(ValueError, match="Syntax error"):
            validate_code("def f(:")

    def test_numpy_import_allowed(self):
        validate_code("import numpy as np")

    def test_pandas_import_allowed(self):
        validate_code("import pandas as pd")

    def test_sklearn_import_allowed(self):
        validate_code("from sklearn.base import BaseEstimator")

    def test_math_import_allowed(self):
        validate_code("import math")

    def test_forbidden_method_call(self):
        with pytest.raises(ValueError, match="Forbidden call: exec"):
            validate_code("obj.exec('code')")


class TestCompileCustom:
    def test_compile_basic_transformer(self):
        params = {
            "code": (
                "from sklearn.base import BaseEstimator, TransformerMixin\n"
                "class MyT(BaseEstimator, TransformerMixin):\n"
                "    def fit(self, X, y=None): return self\n"
                "    def transform(self, X): return X\n"
            ),
            "class_name": "MyT",
        }
        transformer = compile_custom(params)
        assert transformer.__class__.__name__ == "MyT"

    def test_class_not_found_error(self):
        params = {
            "code": "class Foo: pass",
            "class_name": "Bar",
        }
        with pytest.raises(ValueError, match="Class 'Bar' not found"):
            compile_custom(params)

    def test_forbidden_code_rejected(self):
        params = {
            "code": "import os\nclass Foo: pass",
            "class_name": "Foo",
        }
        with pytest.raises(ValueError, match="Forbidden import"):
            compile_custom(params)

    def test_constructor_params_passed(self):
        params = {
            "code": (
                "from sklearn.base import BaseEstimator, TransformerMixin\n"
                "class MyT(BaseEstimator, TransformerMixin):\n"
                "    def __init__(self, multiplier=1):\n"
                "        self.multiplier = multiplier\n"
                "    def fit(self, X, y=None): return self\n"
                "    def transform(self, X): return X * self.multiplier\n"
            ),
            "class_name": "MyT",
            "multiplier": 3,
        }
        transformer = compile_custom(params)
        assert transformer.multiplier == 3
