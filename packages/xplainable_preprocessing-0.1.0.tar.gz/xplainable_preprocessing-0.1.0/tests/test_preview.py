"""Tests for preview and delta computation."""

import numpy as np
import pandas as pd

from xplainable_preprocessing.compiler import compile_spec
from xplainable_preprocessing.preview import (
    compute_delta,
    compute_preview,
    compute_step_deltas,
    infer_schema,
)
from xplainable_preprocessing.schema import PipelineSpec, StepSpec


class TestInferSchema:
    def test_basic_schema(self):
        df = pd.DataFrame({"a": [1, 2], "b": ["x", "y"]})
        schema = infer_schema(df)
        assert len(schema["columns"]) == 2
        assert schema["columns"][0]["name"] == "a"
        assert schema["columns"][1]["name"] == "b"
        assert "int" in schema["columns"][0]["dtype"]


class TestComputeDelta:
    def test_no_changes(self):
        df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
        delta = compute_delta(df, df)
        assert delta["dropped"] == []
        assert delta["added"] == []
        assert delta["updated"] == []

    def test_column_dropped(self):
        before = pd.DataFrame({"a": [1], "b": [2]})
        after = pd.DataFrame({"a": [1]})
        delta = compute_delta(before, after)
        assert delta["dropped"] == ["b"]

    def test_column_added(self):
        before = pd.DataFrame({"a": [1]})
        after = pd.DataFrame({"a": [1], "b": [2]})
        delta = compute_delta(before, after)
        assert delta["added"] == ["b"]

    def test_column_updated(self):
        before = pd.DataFrame({"a": [1, 2, 3]})
        after = pd.DataFrame({"a": [10, 20, 30]})
        delta = compute_delta(before, after)
        assert delta["updated"] == ["a"]

    def test_row_count(self):
        before = pd.DataFrame({"a": [1, 2, 3]})
        after = pd.DataFrame({"a": [1, 2]})
        delta = compute_delta(before, after)
        assert delta["rows_before"] == 3
        assert delta["rows_after"] == 2


class TestComputeStepDeltas:
    def test_step_deltas(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="drop_b", type="DropColumnsTransformer", params={"columns": ["b"]}),
        ])
        pipeline = compile_spec(spec)
        df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
        pipeline.fit(df)

        deltas = compute_step_deltas(pipeline, df)
        assert len(deltas) == 1
        assert deltas[0]["step_id"] == "drop_b"
        assert "b" in deltas[0]["delta"]["dropped"]


class TestComputePreview:
    def test_preview_structure(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="impute", type="SimpleImputer", columns=["a"], params={"strategy": "mean"}),
        ])
        pipeline = compile_spec(spec)
        df = pd.DataFrame({"a": [1.0, np.nan, 3.0]})
        pipeline.fit(df)

        preview = compute_preview(pipeline, df)
        assert "input_schema" in preview
        assert "output_schema" in preview
        assert "step_deltas" in preview
        assert "sample_before" in preview
        assert "sample_after" in preview
        assert len(preview["step_deltas"]) == 1
