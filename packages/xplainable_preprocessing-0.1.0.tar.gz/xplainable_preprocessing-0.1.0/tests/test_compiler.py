"""Tests for the compiler module."""

import numpy as np
import pandas as pd
import pytest

from xplainable_preprocessing.compiler import compile_spec
from xplainable_preprocessing.pipeline import DataFrameColumnTransformer, DataFramePipeline
from xplainable_preprocessing.schema import PipelineSpec, StepSpec


class TestCompileSpec:
    def test_empty_pipeline(self):
        spec = PipelineSpec(steps=[])
        pipeline = compile_spec(spec)
        assert isinstance(pipeline, DataFramePipeline)
        assert len(pipeline.steps) == 0

    def test_single_registry_step(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="scale", type="StandardScaler", columns=["age"]),
        ])
        pipeline = compile_spec(spec)
        assert len(pipeline.steps) == 1
        name, transformer = pipeline.steps[0]
        assert name == "scale"
        assert isinstance(transformer, DataFrameColumnTransformer)

    def test_step_without_columns_no_wrapper(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="drop", type="DropColumnsTransformer", params={"columns": ["id"]}),
        ])
        pipeline = compile_spec(spec)
        name, transformer = pipeline.steps[0]
        assert not isinstance(transformer, DataFrameColumnTransformer)

    def test_unknown_type_raises(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="bad", type="FakeTransformer"),
        ])
        with pytest.raises(ValueError, match="unknown type"):
            compile_spec(spec)

    def test_custom_step(self):
        code = (
            "from sklearn.base import BaseEstimator, TransformerMixin\n"
            "class DoubleIt(BaseEstimator, TransformerMixin):\n"
            "    def fit(self, X, y=None): return self\n"
            "    def transform(self, X): return X * 2\n"
        )
        spec = PipelineSpec(steps=[
            StepSpec(id="double", type="custom", params={
                "code": code, "class_name": "DoubleIt",
            }),
        ])
        pipeline = compile_spec(spec)
        df = pd.DataFrame({"a": [1, 2, 3]})
        pipeline.fit(df)
        result = pipeline.transform(df)
        assert list(result["a"]) == [2, 4, 6]

    def test_full_pipeline_fit_transform(self):
        spec = PipelineSpec(steps=[
            StepSpec(
                id="impute",
                type="SimpleImputer",
                columns=["age"],
                params={"strategy": "median"},
            ),
            StepSpec(
                id="scale",
                type="MinMaxScaler",
                columns=["age"],
            ),
        ])
        pipeline = compile_spec(spec)

        df = pd.DataFrame({"age": [10.0, np.nan, 30.0], "name": ["a", "b", "c"]})
        pipeline.fit(df)
        result = pipeline.transform(df)

        # age should be imputed and scaled, name should pass through
        assert "name" in result.columns
        assert "age" in result.columns
        assert not result["age"].isna().any()
        assert result["age"].min() >= 0
        assert result["age"].max() <= 1

    def test_expression_step(self):
        spec = PipelineSpec(steps=[
            StepSpec(
                id="ratio",
                type="ExpressionTransformer",
                params={"expression": "df['a'] * df['b']", "output_column": "ab"},
            ),
        ])
        pipeline = compile_spec(spec)
        df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
        pipeline.fit(df)
        result = pipeline.transform(df)
        assert list(result["ab"]) == [4, 10, 18]

    def test_multi_step_pipeline(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="drop_id", type="DropColumnsTransformer", params={"columns": ["id"]}),
            StepSpec(id="impute", type="SimpleImputer", columns=["value"], params={"strategy": "mean"}),
            StepSpec(id="scale", type="StandardScaler", columns=["value"]),
        ])
        pipeline = compile_spec(spec)

        df = pd.DataFrame({
            "id": [1, 2, 3],
            "value": [10.0, np.nan, 30.0],
        })
        pipeline.fit(df)
        result = pipeline.transform(df)

        assert "id" not in result.columns
        assert "value" in result.columns
        assert not result["value"].isna().any()
