"""Tests for pipeline spec schema."""

import pytest
from pydantic import ValidationError

from xplainable_preprocessing.schema import PipelineSpec, StepSpec, validate_spec


class TestStepSpec:
    def test_basic_step(self):
        step = StepSpec(id="impute", type="SimpleImputer", params={"strategy": "median"})
        assert step.id == "impute"
        assert step.type == "SimpleImputer"
        assert step.params == {"strategy": "median"}
        assert step.columns is None

    def test_step_with_columns(self):
        step = StepSpec(id="scale", type="StandardScaler", columns=["age", "salary"])
        assert step.columns == ["age", "salary"]

    def test_empty_id_rejected(self):
        with pytest.raises(ValidationError):
            StepSpec(id="", type="StandardScaler")

    def test_empty_type_rejected(self):
        with pytest.raises(ValidationError):
            StepSpec(id="step1", type="")

    def test_default_params(self):
        step = StepSpec(id="scale", type="StandardScaler")
        assert step.params == {}


class TestPipelineSpec:
    def test_empty_pipeline(self):
        spec = PipelineSpec()
        assert spec.version == "2.0"
        assert spec.steps == []

    def test_pipeline_with_steps(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="impute", type="SimpleImputer", params={"strategy": "mean"}),
            StepSpec(id="scale", type="StandardScaler"),
        ])
        assert len(spec.steps) == 2

    def test_duplicate_ids_rejected(self):
        with pytest.raises(ValidationError, match="Duplicate step ids"):
            PipelineSpec(steps=[
                StepSpec(id="same", type="StandardScaler"),
                StepSpec(id="same", type="MinMaxScaler"),
            ])

    def test_from_dict(self):
        data = {
            "version": "2.0",
            "steps": [
                {"id": "impute", "type": "SimpleImputer", "columns": ["age"], "params": {"strategy": "median"}},
            ],
        }
        spec = PipelineSpec(**data)
        assert spec.steps[0].id == "impute"
        assert spec.steps[0].columns == ["age"]

    def test_model_dump_roundtrip(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="impute", type="SimpleImputer", columns=["age"], params={"strategy": "median"}),
        ])
        data = spec.model_dump()
        spec2 = PipelineSpec(**data)
        assert spec == spec2


class TestValidateSpec:
    def test_valid_registry_type(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="impute", type="SimpleImputer", params={"strategy": "mean"}),
        ])
        validate_spec(spec)  # should not raise

    def test_unknown_type_rejected(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="bad", type="NonExistentTransformer"),
        ])
        with pytest.raises(ValueError, match="unknown type"):
            validate_spec(spec)

    def test_custom_without_code_rejected(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="custom1", type="custom", params={"class_name": "Foo"}),
        ])
        with pytest.raises(ValueError, match="requires 'code'"):
            validate_spec(spec)

    def test_custom_without_class_name_rejected(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="custom1", type="custom", params={"code": "class Foo: pass"}),
        ])
        with pytest.raises(ValueError, match="requires 'class_name'"):
            validate_spec(spec)

    def test_valid_custom_type(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="custom1", type="custom", params={
                "code": "from sklearn.base import BaseEstimator, TransformerMixin\nclass Foo(BaseEstimator, TransformerMixin):\n    def fit(self, X, y=None): return self\n    def transform(self, X): return X",
                "class_name": "Foo",
            }),
        ])
        validate_spec(spec)  # should not raise
