"""Tests for all custom transformers."""

import numpy as np
import pandas as pd
import pytest

from xplainable_preprocessing.transformers.category_condense import CategoryCondenseTransformer
from xplainable_preprocessing.transformers.datetime_extract import DateTimeExtractTransformer
from xplainable_preprocessing.transformers.drop_columns import DropColumnsTransformer
from xplainable_preprocessing.transformers.fill_missing import FillMissingTransformer
from xplainable_preprocessing.transformers.grouped_lag import GroupedLagTransformer
from xplainable_preprocessing.transformers.rename_columns import RenameColumnsTransformer
from xplainable_preprocessing.transformers.rolling_agg import RollingAggTransformer
from xplainable_preprocessing.transformers.text_clean import TextCleanTransformer
from xplainable_preprocessing.transformers.type_cast import TypeCastTransformer


class TestDropColumnsTransformer:
    def test_drop_columns(self):
        t = DropColumnsTransformer(columns=["b", "c"])
        df = pd.DataFrame({"a": [1], "b": [2], "c": [3]})
        result = t.fit_transform(df)
        assert list(result.columns) == ["a"]

    def test_drop_nonexistent_columns(self):
        t = DropColumnsTransformer(columns=["x"])
        df = pd.DataFrame({"a": [1]})
        result = t.fit_transform(df)
        assert list(result.columns) == ["a"]


class TestRenameColumnsTransformer:
    def test_rename(self):
        t = RenameColumnsTransformer(mapping={"a": "alpha", "b": "beta"})
        df = pd.DataFrame({"a": [1], "b": [2]})
        result = t.fit_transform(df)
        assert list(result.columns) == ["alpha", "beta"]


class TestTypeCastTransformer:
    def test_cast_to_float(self):
        t = TypeCastTransformer(dtypes={"a": "float64"})
        df = pd.DataFrame({"a": ["1", "2", "3"]})
        result = t.fit_transform(df)
        assert result["a"].dtype == np.float64

    def test_cast_with_errors(self):
        t = TypeCastTransformer(dtypes={"a": "float64"}, errors="coerce")
        df = pd.DataFrame({"a": ["1", "bad", "3"]})
        result = t.fit_transform(df)
        assert pd.isna(result["a"].iloc[1])


class TestFillMissingTransformer:
    def test_fill_mean(self):
        t = FillMissingTransformer(strategies={"a": "mean"})
        df = pd.DataFrame({"a": [1.0, np.nan, 3.0]})
        t.fit(df)
        result = t.transform(df)
        assert result["a"].iloc[1] == 2.0

    def test_fill_median(self):
        t = FillMissingTransformer(strategies={"a": "median"})
        df = pd.DataFrame({"a": [1.0, np.nan, 3.0, 4.0]})
        t.fit(df)
        result = t.transform(df)
        assert result["a"].iloc[1] == 3.0

    def test_fill_constant(self):
        t = FillMissingTransformer(strategies={"a": 0})
        df = pd.DataFrame({"a": [1.0, np.nan, 3.0]})
        t.fit(df)
        result = t.transform(df)
        assert result["a"].iloc[1] == 0

    def test_fill_mode(self):
        t = FillMissingTransformer(strategies={"a": "mode"})
        df = pd.DataFrame({"a": ["x", "x", np.nan, "y"]})
        t.fit(df)
        result = t.transform(df)
        assert result["a"].iloc[2] == "x"

    def test_fill_ffill(self):
        t = FillMissingTransformer(strategies={"a": "ffill"})
        df = pd.DataFrame({"a": [1.0, np.nan, 3.0]})
        t.fit(df)
        result = t.transform(df)
        assert result["a"].iloc[1] == 1.0


class TestCategoryCondenseTransformer:
    def test_condense(self):
        t = CategoryCondenseTransformer(max_categories=2)
        df = pd.DataFrame({"cat": ["a"] * 10 + ["b"] * 5 + ["c"] * 2 + ["d"] * 1})
        t.fit(df)
        result = t.transform(df)
        unique = set(result["cat"])
        assert "a" in unique
        assert "b" in unique
        assert "c" not in unique
        assert "Other" in unique

    def test_min_frequency(self):
        t = CategoryCondenseTransformer(min_frequency=0.3)
        df = pd.DataFrame({"cat": ["a"] * 10 + ["b"] * 5 + ["c"] * 1})
        t.fit(df)
        result = t.transform(df)
        unique = set(result["cat"])
        assert "a" in unique
        assert "b" in unique
        assert "c" not in unique


class TestTextCleanTransformer:
    def test_lowercase(self):
        t = TextCleanTransformer(operations=["lowercase"])
        df = pd.DataFrame({"text": ["HELLO", "World"]})
        result = t.fit_transform(df)
        assert list(result["text"]) == ["hello", "world"]

    def test_strip(self):
        t = TextCleanTransformer(operations=["strip"])
        df = pd.DataFrame({"text": ["  hello  ", " world"]})
        result = t.fit_transform(df)
        assert list(result["text"]) == ["hello", "world"]

    def test_remove_digits(self):
        t = TextCleanTransformer(operations=["remove_digits"])
        df = pd.DataFrame({"text": ["hello123", "world456"]})
        result = t.fit_transform(df)
        assert list(result["text"]) == ["hello", "world"]

    def test_regex_pattern(self):
        t = TextCleanTransformer(regex_pattern=r"\d+", regex_replacement="NUM")
        df = pd.DataFrame({"text": ["price: 100", "qty: 5"]})
        result = t.fit_transform(df)
        assert result["text"].iloc[0] == "price: NUM"

    def test_skips_non_string_columns(self):
        t = TextCleanTransformer(operations=["lowercase"])
        df = pd.DataFrame({"num": [1, 2], "text": ["HELLO", "WORLD"]})
        result = t.fit_transform(df)
        assert list(result["num"]) == [1, 2]
        assert list(result["text"]) == ["hello", "world"]


class TestDateTimeExtractTransformer:
    def test_extract_components(self):
        t = DateTimeExtractTransformer(components=["year", "month", "dayofweek"])
        df = pd.DataFrame({"date": pd.to_datetime(["2024-01-15", "2024-06-20"])})
        result = t.fit_transform(df)
        assert "date_year" in result.columns
        assert "date_month" in result.columns
        assert "date_dayofweek" in result.columns
        assert list(result["date_year"]) == [2024, 2024]
        assert list(result["date_month"]) == [1, 6]

    def test_drop_original(self):
        t = DateTimeExtractTransformer(components=["year"], drop_original=True)
        df = pd.DataFrame({"date": pd.to_datetime(["2024-01-15"])})
        result = t.fit_transform(df)
        assert "date" not in result.columns
        assert "date_year" in result.columns

    def test_keep_original(self):
        t = DateTimeExtractTransformer(components=["year"], drop_original=False)
        df = pd.DataFrame({"date": pd.to_datetime(["2024-01-15"])})
        result = t.fit_transform(df)
        assert "date" in result.columns
        assert "date_year" in result.columns

    def test_string_datetime_input(self):
        t = DateTimeExtractTransformer(components=["year", "month"])
        df = pd.DataFrame({"date": ["2024-01-15", "2024-06-20"]})
        result = t.fit_transform(df)
        assert list(result["date_year"]) == [2024, 2024]


class TestGroupedLagTransformer:
    def test_basic_lag(self):
        t = GroupedLagTransformer(columns=["value"], periods=[1])
        df = pd.DataFrame({"value": [10, 20, 30, 40]})
        result = t.fit_transform(df)
        assert "value_lag_1" in result.columns
        assert pd.isna(result["value_lag_1"].iloc[0])
        assert result["value_lag_1"].iloc[1] == 10

    def test_grouped_lag(self):
        t = GroupedLagTransformer(
            columns=["value"],
            group_by=["group"],
            periods=[1],
        )
        df = pd.DataFrame({
            "group": ["A", "A", "A", "B", "B"],
            "value": [1, 2, 3, 10, 20],
        })
        result = t.fit_transform(df)
        assert "value_lag_1" in result.columns

    def test_multiple_periods(self):
        t = GroupedLagTransformer(columns=["v"], periods=[1, 2])
        df = pd.DataFrame({"v": [10, 20, 30, 40, 50]})
        result = t.fit_transform(df)
        assert "v_lag_1" in result.columns
        assert "v_lag_2" in result.columns


class TestRollingAggTransformer:
    def test_rolling_mean(self):
        t = RollingAggTransformer(columns=["value"], window=3, operation="mean")
        df = pd.DataFrame({"value": [1.0, 2.0, 3.0, 4.0, 5.0]})
        t.fit(df)
        result = t.transform(df)
        assert "value_rolling_mean_3" in result.columns
        assert result["value_rolling_mean_3"].iloc[2] == 2.0  # mean of [1,2,3]

    def test_rolling_sum(self):
        t = RollingAggTransformer(columns=["value"], window=2, operation="sum")
        df = pd.DataFrame({"value": [1.0, 2.0, 3.0]})
        t.fit(df)
        result = t.transform(df)
        assert result["value_rolling_sum_2"].iloc[2] == 5.0  # sum of [2,3]

    def test_invalid_operation(self):
        t = RollingAggTransformer(columns=["v"], operation="invalid")
        with pytest.raises(ValueError, match="Unknown operation"):
            t.fit(pd.DataFrame({"v": [1]}))
