"""Tests for ExpressionTransformer."""

import pandas as pd

from xplainable_preprocessing.transformers.expression import ExpressionTransformer


class TestExpressionTransformer:
    def test_basic_expression(self):
        t = ExpressionTransformer(expression="df['a'] * df['b']", output_column="ab")
        df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
        result = t.fit_transform(df)
        assert list(result["ab"]) == [4, 10, 18]
        assert "a" in result.columns
        assert "b" in result.columns

    def test_division_expression(self):
        t = ExpressionTransformer(expression="df['a'] / df['b']", output_column="ratio")
        df = pd.DataFrame({"a": [10, 20], "b": [2, 5]})
        result = t.fit_transform(df)
        assert list(result["ratio"]) == [5.0, 4.0]

    def test_complex_expression(self):
        t = ExpressionTransformer(
            expression="df['a'] * df['b'] / 1000",
            output_column="result",
        )
        df = pd.DataFrame({"a": [100, 200], "b": [50, 60]})
        result = t.fit_transform(df)
        assert list(result["result"]) == [5.0, 12.0]
