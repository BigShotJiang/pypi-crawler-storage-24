"""Tests for pipeline serialization."""

import numpy as np
import pandas as pd

from xplainable_preprocessing.compiler import compile_spec
from xplainable_preprocessing.schema import PipelineSpec, StepSpec
from xplainable_preprocessing.serialization import load_pipeline, save_pipeline


class TestSerialization:
    def test_roundtrip_simple_pipeline(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="scale", type="StandardScaler", columns=["a", "b"]),
        ])
        pipeline = compile_spec(spec)

        df = pd.DataFrame({"a": [1.0, 2.0, 3.0], "b": [4.0, 5.0, 6.0]})
        pipeline.fit(df)

        data = save_pipeline(pipeline)
        assert isinstance(data, bytes)

        loaded = load_pipeline(data)
        result_original = pipeline.transform(df)
        result_loaded = loaded.transform(df)
        pd.testing.assert_frame_equal(result_original, result_loaded)

    def test_roundtrip_with_imputer(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="impute", type="SimpleImputer", columns=["a"], params={"strategy": "mean"}),
        ])
        pipeline = compile_spec(spec)

        df = pd.DataFrame({"a": [1.0, np.nan, 3.0], "b": [4, 5, 6]})
        pipeline.fit(df)

        data = save_pipeline(pipeline)
        loaded = load_pipeline(data)

        result = loaded.transform(df)
        assert not result["a"].isna().any()
        assert result["a"].iloc[1] == 2.0  # mean of 1 and 3

    def test_roundtrip_multi_step(self):
        spec = PipelineSpec(steps=[
            StepSpec(id="impute", type="SimpleImputer", columns=["a"], params={"strategy": "median"}),
            StepSpec(id="scale", type="MinMaxScaler", columns=["a"]),
        ])
        pipeline = compile_spec(spec)

        df = pd.DataFrame({"a": [10.0, np.nan, 30.0]})
        pipeline.fit(df)

        data = save_pipeline(pipeline)
        loaded = load_pipeline(data)

        result_original = pipeline.transform(df)
        result_loaded = loaded.transform(df)
        pd.testing.assert_frame_equal(result_original, result_loaded)

    def test_roundtrip_custom_transformer(self):
        code = (
            "from sklearn.base import BaseEstimator, TransformerMixin\n"
            "class DoubleIt(BaseEstimator, TransformerMixin):\n"
            "    def fit(self, X, y=None): return self\n"
            "    def transform(self, X): return X * 2\n"
        )
        spec = PipelineSpec(steps=[
            StepSpec(id="double", type="custom", params={
                "code": code, "class_name": "DoubleIt",
            }),
        ])
        pipeline = compile_spec(spec)

        df = pd.DataFrame({"a": [1, 2, 3]})
        pipeline.fit(df)

        data = save_pipeline(pipeline)
        loaded = load_pipeline(data)

        result = loaded.transform(df)
        assert list(result["a"]) == [2, 4, 6]
