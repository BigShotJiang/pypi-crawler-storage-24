# FastAPI Webhooks Integration

This document outlines a plan to extend the SweatStack FastAPI integration with webhook support.

## The Statelessness Challenge

The current FastAPI integration is **deliberately stateless**: OAuth tokens are stored only in encrypted browser cookies. This works well for user-initiated requests because the browser sends cookies with each request.

**Webhooks are fundamentally different:**

```
User's browser                    Your FastAPI app                  SweatStack
      │                                  │                               │
      │──── Request (with cookies) ─────>│                               │
      │                                  │  (has tokens from cookie)     │
      │                                  │                               │
      │                                  │                               │
      │                                  │<──── Webhook (no cookies) ────│
      │                                  │  (NO tokens available!)       │
      │                                  │                               │
```

When SweatStack sends a webhook to your app:
- The payload contains `user_id`, `event_type`, `resource_id`, `timestamp`
- It does NOT contain user tokens
- There are no browser cookies (it's a server-to-server call)
- **You cannot fetch user data without tokens**

### Implications

1. **Signature verification is always possible** — The webhook secret is app-level, not user-level
2. **Fetching user data requires stored tokens** — You need server-side token storage
3. **The stateless cookie approach doesn't work for webhooks**

---

## Proposed Architecture

A layered approach that keeps the stateless integration intact while enabling webhook functionality:

### Layer 1: Stateless Webhook Handling (Always Available)

This layer requires no server-side state and handles:
- Signature verification
- Payload parsing
- FastAPI dependency for verified webhooks

```python
from sweatstack.fastapi import configure, WebhookPayload

configure(webhook_secret="whsec_...")  # or SWEATSTACK_WEBHOOK_SECRET env var

@app.post("/webhooks/sweatstack")
def handle_webhook(payload: WebhookPayload):
    # Signature already verified by the dependency
    print(f"Event: {payload.event_type} for user {payload.user_id}")

    if payload.event_type == "activity_created":
        # Queue a job, send notification, update cache, etc.
        # But you CAN'T fetch the activity data without stored tokens
        background_tasks.add_task(notify_user, payload.user_id, payload.resource_id)

    return {"status": "received"}
```

**Use cases for Layer 1:**
- Triggering background jobs
- Invalidating caches
- Sending push notifications (if you have push tokens stored separately)
- Updating counters/metrics
- Any action that doesn't require fetching the user's SweatStack data

### Layer 2: Stateful Webhook Handling (Opt-in)

For applications that need to fetch user data in webhook handlers, we provide:
- A `TokenStore` protocol for persisting tokens
- Integration with the OAuth callback to store tokens on login
- **`AuthenticatedUser` works in webhook context** — loads from TokenStore automatically

```python
from sweatstack.fastapi import configure, instrument, WebhookPayload, AuthenticatedUser

# Configure with token store
token_store = SQLAlchemyTokenStore(session_factory)

configure(
    token_store=token_store,      # Tokens persisted on OAuth callback
    webhook_secret="whsec_...",   # Webhook verification
)

app = FastAPI()
instrument(app)

@app.post("/webhooks/sweatstack")
def handle_webhook(payload: WebhookPayload, user: AuthenticatedUser):
    # payload: verified webhook data
    # user: loaded from TokenStore using payload.user_id

    if payload.event_type == "activity_created":
        activity = user.client.get_activity(payload.resource_id)
        process_activity(activity)

    return {"status": "received"}
```

**The key insight:** `AuthenticatedUser` detects webhook context and loads the user from `TokenStore` instead of cookies. Same dependency, both contexts.

---

## Unified Dependencies: Browser and Webhook

The elegant part of this design is that `AuthenticatedUser` works transparently in both contexts:

| Context | How `AuthenticatedUser` loads tokens |
|---------|-------------------------------------|
| Browser request | From encrypted session cookie |
| Webhook request | From `TokenStore` using `payload.user_id` |

This is implemented by having `AuthenticatedUser` depend on an internal webhook detection dependency:

```python
from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True, slots=True)
class WebhookPayloadModel:
    """Verified webhook payload data."""

    user_id: str
    event_type: str
    resource_id: str
    timestamp: datetime


# Internal: cached per-request webhook detection
async def _detect_webhook_context(request: Request) -> WebhookPayloadModel | None:
    """Detect if this is a webhook request. Cached per request."""
    signature = request.headers.get("X-Sweatstack-Signature")
    if not signature:
        return None  # Not a webhook - fast path

    # Verify signature and parse payload
    config = get_config()

    if not config.webhook_secret:
        raise WebhookVerificationError(
            "Webhook received but webhook_secret not configured. "
            "Add webhook_secret to configure() to enable webhook handling."
        )

    body = await request.body()
    verify_signature(body, signature, config.webhook_secret)

    data = json.loads(body)
    return WebhookPayloadModel(
        user_id=data["user_id"],
        event_type=data["event_type"],
        resource_id=data["resource_id"],
        timestamp=datetime.fromisoformat(data["timestamp"]),
    )


# Dependency that requires a verified webhook payload
async def _require_webhook_payload(
    webhook_context: Annotated[WebhookPayloadModel | None, Depends(_detect_webhook_context)]
) -> WebhookPayloadModel:
    if webhook_context is None:
        raise HTTPException(status_code=400, detail="Missing or invalid webhook signature")
    return webhook_context


# Public type: always returns verified webhook payload
WebhookPayload = Annotated[WebhookPayloadModel, Depends(_require_webhook_payload)]


# AuthenticatedUser depends on optional webhook context
def _require_authenticated_user(
    request: Request,
    response: Response,
    webhook_context: Annotated[WebhookPayloadModel | None, Depends(_detect_webhook_context)],
) -> SweatStackUser:
    if webhook_context:
        # Webhook context: load from TokenStore
        return _load_user_from_store(webhook_context.user_id)
    else:
        # Browser context: load from cookie (existing behavior)
        session = _get_session_or_raise(request)
        return _create_user(session, response, use_delegated=False)
```

**Important:** `WebhookPayload` is an `Annotated` dependency type, not a plain Pydantic model. This ensures signature verification always happens before your handler runs.

**Why this works:**
- FastAPI caches dependencies per-request (`use_cache=True` by default)
- `_detect_webhook_context` only reads the body if `X-Sweatstack-Signature` header is present
- For regular browser requests, it's just a fast header check returning `None`

---

## TokenStore Protocol

The `TokenStore` protocol defines how tokens are persisted and retrieved. Applications implement this interface to enable webhook user loading.

```python
from typing import Protocol, runtime_checkable
from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True, slots=True)
class StoredTokens:
    """Token data for storage.

    Note: This class intentionally does NOT encrypt tokens.
    Encryption at rest is your responsibility - see Security section.
    """

    user_id: str
    access_token: str
    refresh_token: str
    expires_at: datetime

    def __repr__(self) -> str:
        """Hide sensitive data in logs."""
        return (
            f"StoredTokens(user_id={self.user_id!r}, "
            f"access_token='***', refresh_token='***', "
            f"expires_at={self.expires_at!r})"
        )


@runtime_checkable
class TokenStore(Protocol):
    """Protocol for persisting OAuth tokens.

    IMPORTANT: TokenStore only stores PRINCIPAL tokens, never delegated tokens.
    Delegated tokens (for user switching/coaching scenarios) are stored in the
    session cookie only. This is by design:
    - Principal tokens represent the authenticated user's identity
    - Delegated tokens are temporary and session-scoped
    - Webhooks always relate to the principal user who owns the data

    Implement this interface to:
    1. Store principal tokens when users authenticate (OAuth callback)
    2. Load principal tokens when handling webhooks
    3. Update principal tokens when they're refreshed
    4. Delete tokens on logout

    The library calls these methods automatically at the right times.
    You just need to implement the storage layer.

    Thread Safety:
        All methods may be called concurrently from different requests.
        Your implementation must be thread-safe.

    Error Handling:
        - save(): Should not raise on duplicate user_id (upsert semantics)
        - load(): Return None if user not found, don't raise
        - delete(): Should not raise if user doesn't exist (idempotent)

    Example:
        class MyTokenStore(TokenStore):
            def save(self, tokens: StoredTokens) -> None:
                # INSERT ... ON CONFLICT UPDATE
                ...

            def load(self, user_id: str) -> StoredTokens | None:
                # SELECT ... WHERE user_id = ?
                ...

            def delete(self, user_id: str) -> None:
                # DELETE ... WHERE user_id = ?
                ...
    """

    def save(self, tokens: StoredTokens) -> None:
        """Save or update tokens for a user.

        Called:
        - After successful OAuth callback (new login)
        - After successful token refresh

        Must use upsert semantics (insert or update if exists).
        """
        ...

    def load(self, user_id: str) -> StoredTokens | None:
        """Load tokens for a user.

        Called:
        - When handling webhooks to get user's tokens
        - During token refresh to get current refresh_token

        Returns:
            StoredTokens if found, None if user has no stored tokens.
        """
        ...

    def delete(self, user_id: str) -> None:
        """Delete tokens for a user.

        Called:
        - On logout
        - When user revokes access

        Must be idempotent (no error if user doesn't exist).
        """
        ...
```

### SQLite Reference Implementation (Development Only)

The library provides a built-in SQLite token store for **local development and reference only**.

```python
import logging
import sqlite3
import threading
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)


class SQLiteTokenStore(TokenStore):
    """SQLite-based TokenStore for local development and reference.

    WARNING: This implementation is for LOCAL DEVELOPMENT ONLY.
    Do not use in production. For production, implement your own
    TokenStore with proper database infrastructure, encryption,
    and monitoring.

    Features:
    - File-based storage (no external database required)
    - Thread-safe with connection-per-call pattern
    - Auto-creates table on first use

    Args:
        db_path: Path to SQLite database file. Defaults to "sweatstack_tokens.db"
            in current directory.
    """

    def __init__(self, db_path: str | Path = "sweatstack_tokens.db"):
        self.db_path = str(db_path)
        self._local = threading.local()
        self._init_logged = False

        # Log warning on initialization
        logger.warning(
            "SQLiteTokenStore is for LOCAL DEVELOPMENT ONLY. "
            "Do not use in production. Implement a proper TokenStore "
            "with your production database."
        )

        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        """Get thread-local database connection."""
        if not hasattr(self._local, "connection"):
            self._local.connection = sqlite3.connect(
                self.db_path,
                check_same_thread=False,
            )
            self._local.connection.row_factory = sqlite3.Row
        return self._local.connection

    def _init_db(self) -> None:
        """Create tokens table if it doesn't exist."""
        conn = self._get_connection()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sweatstack_tokens (
                user_id TEXT PRIMARY KEY,
                access_token TEXT NOT NULL,
                refresh_token TEXT NOT NULL,
                expires_at TEXT NOT NULL
            )
        """)
        conn.commit()

    def save(self, tokens: StoredTokens) -> None:
        if not self._init_logged:
            logger.debug("SQLiteTokenStore: saving tokens for user %s", tokens.user_id)

        conn = self._get_connection()
        conn.execute(
            """
            INSERT INTO sweatstack_tokens (user_id, access_token, refresh_token, expires_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                access_token = excluded.access_token,
                refresh_token = excluded.refresh_token,
                expires_at = excluded.expires_at
            """,
            (
                tokens.user_id,
                tokens.access_token,
                tokens.refresh_token,
                tokens.expires_at.isoformat(),
            ),
        )
        conn.commit()

    def load(self, user_id: str) -> StoredTokens | None:
        conn = self._get_connection()
        row = conn.execute(
            "SELECT * FROM sweatstack_tokens WHERE user_id = ?",
            (user_id,),
        ).fetchone()

        if row:
            return StoredTokens(
                user_id=row["user_id"],
                access_token=row["access_token"],
                refresh_token=row["refresh_token"],
                expires_at=datetime.fromisoformat(row["expires_at"]),
            )
        return None

    def delete(self, user_id: str) -> None:
        conn = self._get_connection()
        conn.execute(
            "DELETE FROM sweatstack_tokens WHERE user_id = ?",
            (user_id,),
        )
        conn.commit()
```

### Encrypted SQLite Reference Implementation (Development Only)

For testing encryption patterns locally:

```python
import logging
import sqlite3
import threading
from datetime import datetime
from pathlib import Path

from cryptography.fernet import Fernet

logger = logging.getLogger(__name__)


class EncryptedSQLiteTokenStore(TokenStore):
    """Encrypted SQLite TokenStore for local development and reference.

    WARNING: This implementation is for LOCAL DEVELOPMENT ONLY.
    Do not use in production. This demonstrates the encryption wrapper
    pattern - adapt it for your production database.

    Encrypts access_token and refresh_token using Fernet (AES-128-CBC + HMAC).
    user_id and expires_at are stored unencrypted for queries.

    Args:
        db_path: Path to SQLite database file.
        encryption_key: Fernet key for encryption. Generate with:
            python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
    """

    def __init__(
        self,
        encryption_key: str | bytes,
        db_path: str | Path = "sweatstack_tokens_encrypted.db",
    ):
        self.db_path = str(db_path)
        self._local = threading.local()

        if isinstance(encryption_key, str):
            encryption_key = encryption_key.encode()
        self.fernet = Fernet(encryption_key)

        logger.warning(
            "EncryptedSQLiteTokenStore is for LOCAL DEVELOPMENT ONLY. "
            "Do not use in production. This demonstrates the encryption "
            "pattern - implement with your production database."
        )

        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        if not hasattr(self._local, "connection"):
            self._local.connection = sqlite3.connect(
                self.db_path,
                check_same_thread=False,
            )
            self._local.connection.row_factory = sqlite3.Row
        return self._local.connection

    def _init_db(self) -> None:
        conn = self._get_connection()
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sweatstack_tokens (
                user_id TEXT PRIMARY KEY,
                access_token_encrypted TEXT NOT NULL,
                refresh_token_encrypted TEXT NOT NULL,
                expires_at TEXT NOT NULL
            )
        """)
        conn.commit()

    def _encrypt(self, value: str) -> str:
        return self.fernet.encrypt(value.encode()).decode()

    def _decrypt(self, value: str) -> str:
        return self.fernet.decrypt(value.encode()).decode()

    def save(self, tokens: StoredTokens) -> None:
        logger.debug(
            "EncryptedSQLiteTokenStore: saving encrypted tokens for user %s",
            tokens.user_id,
        )

        conn = self._get_connection()
        conn.execute(
            """
            INSERT INTO sweatstack_tokens
                (user_id, access_token_encrypted, refresh_token_encrypted, expires_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                access_token_encrypted = excluded.access_token_encrypted,
                refresh_token_encrypted = excluded.refresh_token_encrypted,
                expires_at = excluded.expires_at
            """,
            (
                tokens.user_id,
                self._encrypt(tokens.access_token),
                self._encrypt(tokens.refresh_token),
                tokens.expires_at.isoformat(),
            ),
        )
        conn.commit()

    def load(self, user_id: str) -> StoredTokens | None:
        conn = self._get_connection()
        row = conn.execute(
            "SELECT * FROM sweatstack_tokens WHERE user_id = ?",
            (user_id,),
        ).fetchone()

        if row:
            return StoredTokens(
                user_id=row["user_id"],
                access_token=self._decrypt(row["access_token_encrypted"]),
                refresh_token=self._decrypt(row["refresh_token_encrypted"]),
                expires_at=datetime.fromisoformat(row["expires_at"]),
            )
        return None

    def delete(self, user_id: str) -> None:
        conn = self._get_connection()
        conn.execute(
            "DELETE FROM sweatstack_tokens WHERE user_id = ?",
            (user_id,),
        )
        conn.commit()
```

**Usage (development only):**

```python
from sweatstack.fastapi import configure, SQLiteTokenStore, EncryptedSQLiteTokenStore

# Simple local development
configure(
    token_store=SQLiteTokenStore(),  # Creates ./sweatstack_tokens.db
    webhook_secret="whsec_...",
)

# Local development with encryption testing
configure(
    token_store=EncryptedSQLiteTokenStore(
        encryption_key=os.environ["TOKEN_ENCRYPTION_KEY"],
    ),
    webhook_secret="whsec_...",
)
```

### Production Example: SQLAlchemy

For production, implement your own `TokenStore` with proper infrastructure:

```python
from sqlalchemy import String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, Session
from sweatstack.fastapi import TokenStore, StoredTokens


class TokenModel(Base):
    """SQLAlchemy model for token storage.

    For encryption at rest, see the Security section.
    """

    __tablename__ = "sweatstack_tokens"

    user_id: Mapped[str] = mapped_column(String, primary_key=True)
    access_token: Mapped[str] = mapped_column(String, nullable=False)
    refresh_token: Mapped[str] = mapped_column(String, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)


class SQLAlchemyTokenStore(TokenStore):
    """TokenStore implementation using SQLAlchemy.

    Thread-safe when using scoped_session or creating sessions per-call.

    Args:
        session_factory: Callable that returns a SQLAlchemy Session.
            Typically a sessionmaker or scoped_session.
    """

    def __init__(self, session_factory):
        self.session_factory = session_factory

    def save(self, tokens: StoredTokens) -> None:
        with self.session_factory() as session:
            existing = session.get(TokenModel, tokens.user_id)
            if existing:
                existing.access_token = tokens.access_token
                existing.refresh_token = tokens.refresh_token
                existing.expires_at = tokens.expires_at
            else:
                session.add(
                    TokenModel(
                        user_id=tokens.user_id,
                        access_token=tokens.access_token,
                        refresh_token=tokens.refresh_token,
                        expires_at=tokens.expires_at,
                    )
                )
            session.commit()

    def load(self, user_id: str) -> StoredTokens | None:
        with self.session_factory() as session:
            model = session.get(TokenModel, user_id)
            if model:
                return StoredTokens(
                    user_id=model.user_id,
                    access_token=model.access_token,
                    refresh_token=model.refresh_token,
                    expires_at=model.expires_at,
                )
            return None

    def delete(self, user_id: str) -> None:
        with self.session_factory() as session:
            session.query(TokenModel).filter_by(user_id=user_id).delete()
            session.commit()
```

---

## Token Loading in Webhooks

When `AuthenticatedUser` is used in a webhook endpoint, it loads from `TokenStore`:

```python
from datetime import datetime, timezone

from ..utils import decode_jwt_body


def _extract_expiry(access_token: str) -> datetime:
    """Extract expiry time from JWT access token."""
    body = decode_jwt_body(access_token)
    return datetime.fromtimestamp(body["exp"], tz=timezone.utc)


def _extract_timezone(access_token: str) -> str:
    """Extract timezone from JWT access token."""
    body = decode_jwt_body(access_token)
    return body.get("tz", "UTC")


def _load_user_from_store(user_id: str) -> SweatStackUser:
    """Load user from TokenStore for webhook context."""
    config = get_config()

    if not config.token_store:
        raise WebhookTokenStoreError(
            "TokenStore required when using AuthenticatedUser in webhook handlers. "
            "Configure with: configure(token_store=...)"
        )

    tokens = config.token_store.load(user_id)
    if not tokens:
        raise WebhookUserNotFoundError(
            f"No stored tokens for user {user_id}. "
            "User may not have authenticated with your app yet."
        )

    # Check if tokens need refresh
    if _is_token_expiring(tokens.access_token):
        tokens = _refresh_and_save(tokens, config)

    return SweatStackUser(
        client=Client(
            api_key=tokens.access_token,
            refresh_token=tokens.refresh_token,
            client_id=config.client_id,
            client_secret=config.client_secret,
        )
    )


def _refresh_and_save(tokens: StoredTokens, config: FastAPIConfig) -> StoredTokens:
    """Refresh tokens and persist to store."""
    try:
        new_access_token = _refresh_access_token(
            refresh_token=tokens.refresh_token,
            client_id=config.client_id,
            client_secret=config.client_secret.get_secret_value(),
            tz=_extract_timezone(tokens.access_token),
        )

        new_tokens = StoredTokens(
            user_id=tokens.user_id,
            access_token=new_access_token,
            refresh_token=tokens.refresh_token,
            expires_at=_extract_expiry(new_access_token),
        )

        config.token_store.save(new_tokens)
        return new_tokens

    except Exception as e:
        raise WebhookTokenRefreshError(
            f"Failed to refresh tokens for user {tokens.user_id}: {e}"
        ) from e
```

### Webhook-Specific Exceptions

Explicit exceptions make error handling clear for developers:

```python
class WebhookError(Exception):
    """Base class for webhook-related errors."""
    pass


class WebhookVerificationError(WebhookError):
    """Raised when webhook signature verification fails."""
    pass


class WebhookTokenStoreError(WebhookError):
    """Raised when TokenStore is required but not configured."""
    pass


class WebhookUserNotFoundError(WebhookError):
    """Raised when no stored tokens exist for the webhook's user_id."""
    pass


class WebhookTokenRefreshError(WebhookError):
    """Raised when token refresh fails in webhook context."""
    pass
```

When using `AuthenticatedUser` in a webhook handler, these exceptions may be raised during dependency resolution. Use FastAPI exception handlers for custom error responses:

```python
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from sweatstack.fastapi import (
    WebhookPayload, AuthenticatedUser,
    WebhookUserNotFoundError, WebhookTokenRefreshError,
)

app = FastAPI()


@app.exception_handler(WebhookUserNotFoundError)
async def handle_user_not_found(request: Request, exc: WebhookUserNotFoundError):
    # User hasn't authenticated with your app yet
    return JSONResponse(status_code=200, content={"status": "user_not_found"})


@app.exception_handler(WebhookTokenRefreshError)
async def handle_token_refresh_error(request: Request, exc: WebhookTokenRefreshError):
    # Tokens expired and refresh failed
    return JSONResponse(status_code=200, content={"status": "auth_required"})


@app.post("/webhooks/sweatstack")
def handle_webhook(payload: WebhookPayload, user: AuthenticatedUser):
    # If we get here, both payload and user are valid
    activity = user.client.get_activity(payload.resource_id)
    return {"status": "processed"}
```

**Note:** Returning 200 for user-related errors prevents webhook retries for unrecoverable situations. Return 5xx if you want the webhook provider to retry.

---

## Security: Token Storage

**The library does NOT encrypt tokens. This is a deliberate design decision.**

### Why the Library Doesn't Encrypt

1. **Key management is your responsibility** — We can't manage encryption keys for you
2. **Storage varies widely** — Database encryption, HSMs, cloud KMS, etc.
3. **Compliance requirements vary** — PCI, HIPAA, GDPR have different requirements
4. **Defense in depth** — Encryption at rest is one layer; you need others too

### What You Must Do

**Minimum requirements:**

1. **Use encrypted connections** — TLS for database connections
2. **Restrict database access** — Principle of least privilege
3. **Don't log tokens** — `StoredTokens.__repr__` helps, but audit your logs
4. **Secure your backups** — Encrypted backups, secure storage

**Recommended: Encrypt at rest**

The simplest approach is database-level encryption (transparent data encryption). Most production databases support this:

- PostgreSQL: `pgcrypto` extension or TDE
- MySQL: InnoDB tablespace encryption
- Cloud databases: Usually enabled by default (AWS RDS, Cloud SQL, etc.)

**For higher security: Application-level encryption**

If you need application-level encryption (e.g., for multi-tenant isolation), wrap the token store:

```python
from cryptography.fernet import Fernet


class EncryptedTokenStore(TokenStore):
    """Wrapper that encrypts tokens before storage.

    Uses Fernet (AES-128-CBC with HMAC) for symmetric encryption.
    You manage the encryption key separately.
    """

    def __init__(self, inner: TokenStore, key: bytes):
        self.inner = inner
        self.fernet = Fernet(key)

    def save(self, tokens: StoredTokens) -> None:
        encrypted = StoredTokens(
            user_id=tokens.user_id,  # Don't encrypt - needed for lookup
            access_token=self._encrypt(tokens.access_token),
            refresh_token=self._encrypt(tokens.refresh_token),
            expires_at=tokens.expires_at,  # Don't encrypt - needed for queries
        )
        self.inner.save(encrypted)

    def load(self, user_id: str) -> StoredTokens | None:
        encrypted = self.inner.load(user_id)
        if not encrypted:
            return None
        return StoredTokens(
            user_id=encrypted.user_id,
            access_token=self._decrypt(encrypted.access_token),
            refresh_token=self._decrypt(encrypted.refresh_token),
            expires_at=encrypted.expires_at,
        )

    def delete(self, user_id: str) -> None:
        self.inner.delete(user_id)

    def _encrypt(self, value: str) -> str:
        return self.fernet.encrypt(value.encode()).decode()

    def _decrypt(self, value: str) -> str:
        return self.fernet.decrypt(value.encode()).decode()


# Usage:
encryption_key = os.environ["TOKEN_ENCRYPTION_KEY"].encode()
inner_store = SQLAlchemyTokenStore(session_factory)
token_store = EncryptedTokenStore(inner_store, encryption_key)

configure(token_store=token_store, ...)
```

### Security Checklist

Before deploying to production:

- [ ] Database connections use TLS
- [ ] Database credentials are not in code (use environment variables/secrets manager)
- [ ] Database user has minimal permissions (only the tokens table)
- [ ] Tokens are encrypted at rest (database-level or application-level)
- [ ] Encryption keys are stored securely (not in code, not in database)
- [ ] Backups are encrypted
- [ ] Logs don't contain tokens (check all logging configurations)
- [ ] Monitoring/alerting for failed token operations
- [ ] Webhook handlers are idempotent (SweatStack retries failed deliveries)

---

## Configuration

Webhook configuration is merged into the main `configure()` function:

```python
from sweatstack.fastapi import configure, instrument

# Layer 1: Webhooks without data fetching
configure(
    client_id="...",
    client_secret="...",
    session_secret="...",
    app_url="...",
    webhook_secret="whsec_...",  # or SWEATSTACK_WEBHOOK_SECRET env var
)

# Layer 2: Webhooks with data fetching
token_store = SQLAlchemyTokenStore(session_factory)

configure(
    client_id="...",
    client_secret="...",
    session_secret="...",
    app_url="...",
    webhook_secret="whsec_...",
    token_store=token_store,  # Enables AuthenticatedUser in webhooks
)

app = FastAPI()
instrument(app)
```

### Configuration Parameters

```python
def configure(
    *,
    # Existing parameters...
    client_id: str | None = None,
    client_secret: str | SecretStr | None = None,
    app_url: str | None = None,
    session_secret: str | SecretStr | list[str | SecretStr] | None = None,
    scopes: list[str] | None = None,
    cookie_secure: bool | None = None,
    cookie_max_age: int = 86400,
    auth_route_prefix: str = "/auth/sweatstack",
    redirect_unauthenticated: bool = True,

    # New parameters
    webhook_secret: str | SecretStr | None = None,  # env: SWEATSTACK_WEBHOOK_SECRET
    token_store: TokenStore | None = None,
) -> None:
    ...
```

### Updated FastAPIConfig Dataclass

```python
@dataclass
class FastAPIConfig:
    """Internal configuration for the FastAPI plugin."""

    # Existing fields...
    client_id: str
    client_secret: SecretStr
    app_url: str
    session_secret: SecretStr | list[SecretStr]
    scopes: list[str]
    cookie_secure: bool
    cookie_max_age: int
    auth_route_prefix: str
    redirect_unauthenticated: bool

    # New fields
    webhook_secret: SecretStr | None = None
    token_store: TokenStore | None = None
```

### Startup Configuration Validation

The `instrument()` function validates webhook configuration at startup. If any route uses `WebhookPayload` but `webhook_secret` is not configured, an error is logged immediately:

```
ERROR - Route '/webhooks/sweatstack' uses WebhookPayload but webhook_secret is not configured.
        Webhook signature verification will fail at runtime.
        Configure with: configure(webhook_secret='whsec_...')
```

This provides immediate feedback during development rather than waiting for the first webhook to arrive.

**Note:** This validation only catches routes defined before `instrument()` is called. Routes added afterward (e.g., via `include_router()` after instrumentation) are caught by the runtime check in `_detect_webhook_context`. In practice, most apps define routes before calling `instrument()`, so this catches the common case.

**Implementation:**

```python
import logging

logger = logging.getLogger(__name__)


def instrument(app: FastAPI) -> None:
    """Add SweatStack auth routes to a FastAPI application."""
    config = get_config()
    router = create_router()
    app.include_router(router, prefix=config.auth_route_prefix)

    # Validate webhook configuration
    _warn_if_webhook_misconfigured(app)


def _warn_if_webhook_misconfigured(app: FastAPI) -> None:
    """Log error if WebhookPayload is used but webhook_secret not configured."""
    config = get_config()

    if config.webhook_secret:
        return  # Properly configured

    # Check if any route uses WebhookPayload dependency
    for route in app.routes:
        if not hasattr(route, 'dependant'):
            continue

        if _uses_webhook_payload(route.dependant):
            logger.error(
                "Route '%s' uses WebhookPayload but webhook_secret is not configured. "
                "Webhook signature verification will fail at runtime. "
                "Configure with: configure(webhook_secret='whsec_...')",
                route.path
            )
            return  # One warning is enough


def _uses_webhook_payload(dependant) -> bool:
    """Check if a dependency tree includes the WebhookPayload dependency."""
    for dep in dependant.dependencies:
        # Check if this is the webhook payload dependency
        if dep.call is _require_webhook_payload:
            return True
        # Recursively check nested dependencies
        if hasattr(dep, 'dependant') and _uses_webhook_payload(dep.dependant):
            return True
    return False
```

**Note:** The runtime check in `_detect_webhook_context` is kept as a fallback for routes added after `instrument()` is called.

---

## Signature Verification

SweatStack uses HMAC-SHA256 signatures. The `X-Sweatstack-Signature` header format:

```
t={timestamp},v1={signature}
```

Verification process:
1. Extract timestamp and signature from header
2. Check timestamp is within tolerance (5 minutes) to prevent replay attacks
3. Construct signed payload: `{timestamp}.{raw_json_body}`
4. Compute HMAC-SHA256 with webhook secret
5. Compare signatures using constant-time comparison

```python
import hmac
import hashlib
import time

TIMESTAMP_TOLERANCE = 300  # 5 minutes


def verify_signature(
    payload: bytes,
    signature_header: str,
    secret: str,
) -> None:
    """Verify webhook signature.

    Raises:
        WebhookVerificationError: If signature is invalid or timestamp too old.
    """
    try:
        parts = dict(p.split("=", 1) for p in signature_header.split(","))
        timestamp = int(parts["t"])
        signature = parts["v1"]
    except (KeyError, ValueError) as e:
        raise WebhookVerificationError("Invalid signature header format") from e

    # Check timestamp (prevents replay attacks)
    if abs(time.time() - timestamp) > TIMESTAMP_TOLERANCE:
        raise WebhookVerificationError("Timestamp outside tolerance window")

    # Compute expected signature
    signed_payload = f"{timestamp}.{payload.decode()}"
    expected = hmac.new(
        secret.encode(),
        signed_payload.encode(),
        hashlib.sha256,
    ).hexdigest()

    # Constant-time comparison (prevents timing attacks)
    if not hmac.compare_digest(expected, signature):
        raise WebhookVerificationError("Invalid signature")
```

---

## Integration with OAuth Flow

When `token_store` is configured, **principal tokens** are automatically persisted.

**Important:** Only principal tokens are stored, never delegated tokens. Delegated tokens (used for user switching in coaching scenarios) remain in the session cookie only. This is intentional:
- Principal tokens represent the user's own identity
- Delegated tokens are temporary and session-scoped
- Webhooks are always about the principal user who owns the data

### On Login (OAuth Callback)

```python
def callback(...):
    # ... existing token exchange ...

    # Existing: Set session cookie
    set_session_cookie(response, session_data)

    # New: Persist PRINCIPAL tokens to token store if configured
    if config.token_store:
        config.token_store.save(
            StoredTokens(
                user_id=user_id,
                access_token=tokens["access_token"],
                refresh_token=tokens["refresh_token"],
                expires_at=extract_expiry(tokens["access_token"]),
            )
        )

    return response
```

### On Token Refresh (Browser Context)

```python
def _create_user(session, response, *, use_delegated: bool) -> SweatStackUser:
    # ... existing refresh logic ...

    if refreshed:
        # Existing: Update session cookie
        set_session_cookie(response, session.to_dict())

        # New: Update token store ONLY for principal tokens
        # Delegated tokens are session-only and not persisted
        if config.token_store and not is_delegated:
            config.token_store.save(
                StoredTokens(
                    user_id=session.principal.user_id,
                    access_token=refreshed.access_token,
                    refresh_token=refreshed.refresh_token,
                    expires_at=extract_expiry(refreshed.access_token),
                )
            )

    return SweatStackUser(client=...)
```

### On Logout

```python
def logout(request: Request) -> Response:
    response = RedirectResponse(url="/", status_code=302)

    # Existing: Clear session cookie (clears both principal and delegated)
    clear_session_cookie(response)

    # New: Delete principal tokens from token store if configured
    if config.token_store:
        session = _get_session_or_none(request)
        if session:
            config.token_store.delete(session.principal.user_id)

    return response
```

---

## Usage Examples

### Layer 1: Webhooks Without Data Fetching

```python
from fastapi import FastAPI, BackgroundTasks
from sweatstack.fastapi import configure, WebhookPayload

configure(
    client_id="...",
    client_secret="...",
    session_secret="...",
    app_url="http://localhost:8000",
    webhook_secret="whsec_...",
)

app = FastAPI()


@app.post("/webhooks/sweatstack")
async def handle_webhook(
    payload: WebhookPayload,
    background_tasks: BackgroundTasks,
):
    """Handle webhook - queue work, don't fetch data."""

    if payload.event_type == "activity_created":
        background_tasks.add_task(
            queue_activity_sync,
            user_id=payload.user_id,
            activity_id=payload.resource_id,
        )

    elif payload.event_type == "activity_deleted":
        cache.delete(f"activity:{payload.resource_id}")

    return {"status": "received"}
```

### Layer 2: Webhooks With Data Fetching

```python
from fastapi import FastAPI
from sweatstack.fastapi import (
    configure, instrument, WebhookPayload, AuthenticatedUser,
)

token_store = SQLAlchemyTokenStore(session_factory)

configure(
    client_id="...",
    client_secret="...",
    session_secret="...",
    app_url="http://localhost:8000",
    webhook_secret="whsec_...",
    token_store=token_store,
)

app = FastAPI()
instrument(app)


@app.post("/webhooks/sweatstack")
def handle_webhook(payload: WebhookPayload, user: AuthenticatedUser):
    """Handle webhook with data fetching."""

    if payload.event_type == "activity_created":
        # user is loaded from TokenStore based on payload.user_id
        activity = user.client.get_activity(payload.resource_id)

        store_activity_in_database(activity)
        update_user_stats(payload.user_id, activity)
        notify_followers(payload.user_id, activity)

    return {"status": "processed"}
```

### Coaching Platform: Unified Dependencies

```python
from sweatstack.fastapi import (
    configure, instrument,
    AuthenticatedUser, SelectedUser, WebhookPayload,
)

token_store = SQLAlchemyTokenStore(session_factory)

configure(
    token_store=token_store,
    webhook_secret="whsec_...",
    # ... other config
)

app = FastAPI()
instrument(app)


# Browser routes - tokens from cookies
@app.get("/dashboard")
def dashboard(user: SelectedUser):
    return user.client.get_activities()


@app.get("/athletes")
def athletes(user: AuthenticatedUser):
    return user.client.get_users()


# Webhook route - tokens from TokenStore
@app.post("/webhooks/sweatstack")
def webhook(payload: WebhookPayload, user: AuthenticatedUser):
    if payload.event_type == "activity_created":
        activity = user.client.get_activity(payload.resource_id)

        # Notify the athlete's coach
        coach_id = get_coach_for_athlete(payload.user_id)
        if coach_id:
            send_push_notification(
                coach_id,
                f"New activity from {payload.user_id}: {activity.name}"
            )

    return {"status": "received"}
```

---

## Responding Within 2 Seconds

SweatStack requires a 2xx response within 2 seconds. Best practices:

1. **Verify and acknowledge immediately** — Don't process synchronously
2. **Queue heavy work** — Use background tasks, Celery, or similar
3. **Keep database operations fast** — Index by user_id
4. **Handle duplicates** — SweatStack retries failed deliveries, so design handlers to be idempotent

```python
@app.post("/webhooks/sweatstack")
async def webhook(
    payload: WebhookPayload,
    background_tasks: BackgroundTasks,
):
    # Fast: just queue the work
    background_tasks.add_task(process_webhook, payload)

    # Respond immediately
    return {"status": "received"}


def process_webhook(payload: WebhookPayloadModel):
    # This runs after response is sent
    # For background tasks, load user via token_store directly
    tokens = token_store.load(payload.user_id)
    if not tokens:
        return  # User not found, handle appropriately

    client = Client(api_key=tokens.access_token, ...)
    activity = client.get_activity(payload.resource_id)
    # ... process activity
```

---

## File Structure

```
src/sweatstack/fastapi/
├── __init__.py          # Add: WebhookPayload, TokenStore, exceptions, SQLite stores
├── config.py            # Add: webhook_secret, token_store parameters
├── routes.py            # Add: principal token persistence, startup webhook validation
├── dependencies.py      # Modify: AuthenticatedUser webhook detection
├── session.py           # Unchanged
├── models.py            # Add: StoredTokens, TokenStore protocol
├── webhooks.py          # NEW: signature verification, WebhookPayload dependency
└── token_stores.py      # NEW: SQLiteTokenStore, EncryptedSQLiteTokenStore (dev only)
```

### New Exports

```python
# sweatstack/fastapi/__init__.py

__all__ = [
    # Configuration
    "configure",
    "instrument",
    "urls",
    # User dependencies
    "AuthenticatedUser",
    "OptionalUser",
    "SelectedUser",
    "OptionalSelectedUser",
    "SweatStackUser",
    # Webhook dependencies
    "WebhookPayload",
    "WebhookPayloadModel",  # For type hints in background tasks
    # Token storage
    "TokenStore",
    "StoredTokens",
    "SQLiteTokenStore",           # Development only
    "EncryptedSQLiteTokenStore",  # Development only
    # Webhook utilities
    "verify_signature",
    # Exceptions
    "WebhookError",
    "WebhookVerificationError",
    "WebhookTokenStoreError",
    "WebhookUserNotFoundError",
    "WebhookTokenRefreshError",
]
```

---

## Implementation Phases

### Phase 1: Core Webhook Support

**New files:**
- `webhooks.py` — signature verification, `WebhookPayloadModel`, `_detect_webhook_context`, `WebhookPayload`

**Modifications:**
- `config.py` — add `webhook_secret` parameter and `FastAPIConfig.webhook_secret` field
- `routes.py` — add `_warn_if_webhook_misconfigured()` in `instrument()`
- `__init__.py` — export `WebhookPayload`, `WebhookPayloadModel`, `verify_signature`, `WebhookError`, `WebhookVerificationError`

**Tasks:**
1. Create `WebhookPayloadModel` dataclass
2. Implement `verify_signature()` function
3. Implement `_detect_webhook_context()` async dependency (signature verification + payload parsing)
4. Implement `_require_webhook_payload()` dependency
5. Create `WebhookPayload` type alias
6. Add `webhook_secret` to `configure()` with env var fallback (`SWEATSTACK_WEBHOOK_SECRET`)
7. Add `WebhookError` and `WebhookVerificationError` exceptions
8. Add startup validation in `instrument()`
9. Write tests for signature verification and `WebhookPayload` dependency
10. Document Layer 1 usage

### Phase 2: Token Store Integration

**New files:**
- `token_stores.py` — `SQLiteTokenStore`, `EncryptedSQLiteTokenStore`

**Modifications:**
- `models.py` — add `StoredTokens` dataclass, `TokenStore` protocol
- `config.py` — add `token_store` parameter and `FastAPIConfig.token_store` field
- `dependencies.py` — modify `_require_authenticated_user` to depend on `_detect_webhook_context`, add `_load_user_from_store`
- `routes.py` — persist tokens in callback, refresh, and logout
- `__init__.py` — export `TokenStore`, `StoredTokens`, `SQLiteTokenStore`, `EncryptedSQLiteTokenStore`, remaining exceptions

**Tasks:**
1. Define `StoredTokens` dataclass and `TokenStore` protocol
2. Add `token_store` to `configure()`
3. Modify `_require_authenticated_user` to accept webhook context and branch on it
4. Implement `_load_user_from_store()` with token refresh logic
5. Add `_extract_expiry()` and `_extract_timezone()` helpers
6. Modify OAuth callback to persist principal tokens
7. Modify `_create_user` to persist refreshed principal tokens
8. Modify logout to delete tokens from store
9. Add `WebhookTokenStoreError`, `WebhookUserNotFoundError`, `WebhookTokenRefreshError`
10. Implement `SQLiteTokenStore` (with dev-only warning)
11. Implement `EncryptedSQLiteTokenStore` (with dev-only warning)
12. Write tests for token persistence and webhook user loading
13. Document Layer 2 usage and security considerations

---

## Summary

| Layer | Configuration | What You Can Do |
|-------|--------------|-----------------|
| Layer 1 | `webhook_secret` only | Verify webhooks, trigger jobs, invalidate caches |
| Layer 2 | `webhook_secret` + `token_store` | All of Layer 1 + use `AuthenticatedUser` in webhooks |

**Key design decisions:**

1. **Merged configuration** — `webhook_secret` in `configure()`, not separate function
2. **Unified dependencies** — `AuthenticatedUser` works in both browser and webhook contexts
3. **Principal tokens only** — `TokenStore` stores principal tokens, never delegated tokens
4. **Explicit exceptions** — `WebhookUserNotFoundError`, `WebhookTokenRefreshError` force handling
5. **Security is your job** — Library doesn't encrypt; provides guidance and patterns
6. **Development stores included** — `SQLiteTokenStore` and `EncryptedSQLiteTokenStore` for local dev
7. **Sync-only** — No async token store protocol (yet)
