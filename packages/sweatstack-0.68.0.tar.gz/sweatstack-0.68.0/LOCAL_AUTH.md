# Local Authentication: Issues and Fixes

## Issues

### Issue 1: Refresh Token Not Available During Refresh

`_do_token_refresh()` accesses `self._refresh_token` directly, but when tokens are loaded from persistent storage via the `api_key` property, only the access token value is retrieved—`self._refresh_token` remains `None`.

**Location:** `client.py:702`

```python
def _do_token_refresh(self, tz: str) -> str:
    refresh_token = self._refresh_token  # None when loaded from storage!
```

### Issue 2: Refreshed Tokens Not Persisted

After a successful refresh, the new access token is stored in memory but never written back to persistent storage. On the next script run, the old expired token is loaded again.

**Location:** `client.py:730-731`

```python
token = self._do_token_refresh(body["tz"])
self._api_key = SecretStr(token)
# Missing: _save_tokens() call
```

### Issue 3: All Exceptions Swallowed

Token refresh failures are logged as warnings and silently ignored, causing subsequent API calls to fail with unclear 401 errors.

**Location:** `client.py:732-736`

```python
except Exception as exception:
    logging.warning("Exception checking token expiry: %s", exception)
    pass  # Continues with expired token
```

---

## API Redesign: `authenticate()` vs `login()`

### Current State

The SDK has two public methods:
- `login()` - Always opens browser for OAuth
- `authenticate()` - Opens browser only if no tokens exist

This is confusing and redundant (`authenticate(force_login=True)` duplicates `login()`).

### Decision: Single `authenticate()` Method

**Why `authenticate()` over `login()`:**

1. **Semantics match the default behavior.** When tokens exist, the method does nothing. "Already authenticated" makes sense. "Called login but didn't log in" feels wrong.

2. **It's a guard, not an action.** The method ensures authenticated state; it doesn't always perform a login.

3. **`force=True` reads naturally.** "Force re-authentication" vs "force login again" (login is already forceful).

4. **Broader meaning.** `authenticate()` encompasses both checking existing tokens and obtaining new ones.

### Environment Variables

The method correctly respects `SWEATSTACK_API_KEY` and `SWEATSTACK_REFRESH_TOKEN` environment variables. If set, `authenticate()` returns early without opening a browser—important for headless/automated environments.

---

## Proposed Implementation

### Exception

```python
class TokenRefreshError(Exception):
    """Raised when token refresh fails."""
    pass
```

### Constants

```python
TOKEN_EXPIRY_MARGIN_SECONDS = 5
```

### Token Loading

```python
def _load_token_pair(self) -> tuple[str | None, str | None]:
    """Load access and refresh tokens from available sources.

    Checks in order: instance, environment, persistent storage.
    Returns (access_token, refresh_token) tuple. Either or both may be None.
    """
    access_token: str | None = None
    refresh_token: str | None = None

    # Instance tokens
    if self._api_key is not None:
        access_token = self._api_key.get_secret_value()
    if self._refresh_token is not None:
        refresh_token = self._refresh_token.get_secret_value()

    # Environment variables
    if access_token is None:
        access_token = os.getenv("SWEATSTACK_API_KEY")
    if refresh_token is None:
        refresh_token = os.getenv("SWEATSTACK_REFRESH_TOKEN")

    # Persistent storage
    if access_token is None or refresh_token is None:
        stored_access, stored_refresh = self._load_persistent_tokens()
        if access_token is None:
            access_token = stored_access
        if refresh_token is None:
            refresh_token = stored_refresh

    return access_token, refresh_token
```

### Token Refresh

```python
def _do_token_refresh(self, tz: str, refresh_token: str) -> str:
    """Exchange refresh token for a new access token.

    Args:
        tz: Timezone from the expired token's JWT claims.
        refresh_token: The refresh token to use.

    Returns:
        New access token string.

    Raises:
        TokenRefreshError: If the refresh request fails.
    """
    with self._http_client(skip_token_check=True) as client:
        response = client.post(
            "/api/v1/oauth/token",
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "tz": tz,
                "client_id": self.client_id,
                "client_secret": self._client_secret.get_secret_value() if self._client_secret else None,
            },
        )

        try:
            self._raise_for_status(response)
        except httpx.HTTPStatusError as e:
            raise TokenRefreshError(f"Token refresh failed: {e}") from e

        return response.json()["access_token"]
```

### Token Expiry Check

```python
def _refresh_if_expired(self, access_token: str, refresh_token: str | None) -> str:
    """Check token expiry and refresh if needed.

    Args:
        access_token: The current access token (JWT).
        refresh_token: The refresh token, if available.

    Returns:
        Valid access token (refreshed if necessary).

    Raises:
        TokenRefreshError: If refresh is needed but fails.
    """
    try:
        payload = decode_jwt_body(access_token)
    except Exception as e:
        raise TokenRefreshError(f"Invalid access token: {e}") from e

    expires_at = payload.get("exp")
    if expires_at is None:
        raise TokenRefreshError("Access token missing 'exp' claim")

    is_expired = expires_at - TOKEN_EXPIRY_MARGIN_SECONDS < time.time()
    if not is_expired:
        return access_token

    if refresh_token is None:
        raise TokenRefreshError(
            "Access token expired but no refresh token available. "
            "Call client.authenticate(force=True) to re-authenticate."
        )

    tz = payload.get("tz", "UTC")
    new_access_token = self._do_token_refresh(tz, refresh_token)

    # Update instance state
    self._api_key = SecretStr(new_access_token)

    # Persist refreshed token
    self._save_tokens(new_access_token, refresh_token)
    logger.debug("Refreshed and persisted access token")

    return new_access_token
```

### API Key Property

```python
@property
def api_key(self) -> SecretStr | None:
    """The current API access token.

    Loads from instance, environment (SWEATSTACK_API_KEY), or persistent
    storage. Automatically refreshes expired tokens.

    Returns:
        SecretStr containing the access token, or None if not authenticated.

    Raises:
        TokenRefreshError: If the token is expired and refresh fails.
    """
    access_token, refresh_token = self._load_token_pair()

    if access_token is None:
        return None

    valid_token = self._refresh_if_expired(access_token, refresh_token)
    return SecretStr(valid_token)
```

### Public Authentication Method

```python
def authenticate(self, force: bool = False, persist: bool = True) -> None:
    """Ensure the client is authenticated.

    Checks for existing tokens in order: instance, environment variables,
    persistent storage. Opens browser for OAuth only if no tokens are found
    or if force=True.

    For headless environments, set SWEATSTACK_API_KEY and SWEATSTACK_REFRESH_TOKEN
    environment variables instead of calling this method.

    Args:
        force: Re-authenticate even if tokens exist.
        persist: Save new tokens to persistent storage (default: True).

    Example:
        client = Client()
        client.authenticate()  # Opens browser only if needed

        # Force fresh authentication
        client.authenticate(force=True)

        # Headless: use env vars, don't call authenticate()
        # SWEATSTACK_API_KEY=... SWEATSTACK_REFRESH_TOKEN=... python script.py
    """
    if not force:
        access_token, _ = self._load_token_pair()
        if access_token is not None:
            return

    self._open_browser_oauth(persist=persist)
```

### Private Browser OAuth (renamed from `login()`)

```python
def _open_browser_oauth(self, persist: bool = True) -> None:
    """Open browser for OAuth authentication flow.

    Args:
        persist: Save tokens to persistent storage after successful auth.
    """
    # ... existing login() implementation, renamed ...
```

---

## Summary of Changes

| Component | Change |
|-----------|--------|
| `TokenRefreshError` | **New.** Explicit exception for refresh failures. |
| `_load_token_pair()` | **New.** Loads both tokens together from all sources. |
| `_do_token_refresh()` | Takes `refresh_token` as parameter. Raises `TokenRefreshError`. |
| `_refresh_if_expired()` | **New.** Replaces `_check_token_expiry()`. Persists after refresh. |
| `api_key` property | Uses `_load_token_pair()` and `_refresh_if_expired()`. |
| `authenticate()` | Replaces both old `authenticate()` and `login()`. Single entry point. |
| `_open_browser_oauth()` | **Renamed** from `login()`. Now private. |
| `login()` | **Removed** as public method. |

---

## Migration Notes

- `TokenRefreshError` is a new exception that calling code may need to handle
- `login()` is removed; use `authenticate(force=True)` for the same behavior
- `authenticate(force_login=True)` parameter renamed to `authenticate(force=True)`
- `authenticate(persist_api_key=True)` parameter renamed to `authenticate(persist=True)`
