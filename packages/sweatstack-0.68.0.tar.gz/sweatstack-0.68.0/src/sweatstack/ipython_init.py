import sweatstack


print("\n")
print(">>>>>>>>>> Sweat Stack Initialization <<<<<<<<<")
print("Initializing....")

sweatstack.authenticate()