# Client Library: Converting Optimized DTypes to Standard DTypes

This document provides instructions for implementing dtype conversion in the SweatStack Python client library. The API returns parquet files with optimized dtypes for bandwidth efficiency, but client code should receive standard dtypes for ease of use.

## Why This Conversion Is Needed

The SweatStack API returns parquet files with space-optimized dtypes:

| Optimized DType | Standard DType | Why Optimized |
|-----------------|----------------|---------------|
| `Int8` | `float64` | Smaller integers (lap, session_id) |
| `Int16` | `float64` | Metrics (power, heart_rate, cadence) |
| `float16` | `float64` | Metrics (speed, altitude, temperature, etc.) |
| `float32` | `float64` | GPS and distance |
| `datetime64[s]` | `datetime64[ns]` | Timestamp precision |
| `timedelta64[s]` | `timedelta64[ns]` | Duration precision |

These optimized dtypes reduce transfer size by 50-70%, but have limitations that can frustrate users:

- `Int16` overflows on cumulative operations (`cumsum()` fails at 32,767)
- `float16` cannot be used as a pandas index
- `float16` has only ~3 decimal digits of precision
- Some numpy/scipy/sklearn functions expect `float64`

## Backwards Compatibility

**Important:** The current API does not yet return optimized dtypes. The conversion function must be designed to work correctly in both scenarios:

1. **Current API behavior:** Returns standard dtypes (`float64`, `datetime64[ns]`, etc.)
2. **Future API behavior:** Returns optimized dtypes (`float16`, `Int16`, `datetime64[s]`, etc.)

### Idempotent Conversion

The conversion function must be **idempotent** - calling it on data that's already in standard dtypes should be a no-op (or at most a very cheap operation). This ensures:

- No errors when processing data from the current API
- No performance penalty for already-converted data
- Safe to call unconditionally without version checking

### Implementation Strategy

```python
# This check is essentially free for float64 columns
elif pd.api.types.is_float_dtype(dtype) and dtype != np.float64:
    df[col] = df[col].astype("float64")
# If dtype IS np.float64, the condition is False and no conversion happens

# For datetime/timedelta, use the .unit attribute (not string matching)
elif pd.api.types.is_timedelta64_dtype(dtype):
    if df[col].dt.unit != "ns":  # Only convert if not already ns
        df[col] = df[col].astype("timedelta64[ns]")
```

The `.unit` attribute returns `'s'`, `'ms'`, `'us'`, or `'ns'`, providing a reliable way to check precision without fragile string parsing.

### No API Version Detection Needed

The client library should NOT try to detect API versions or conditionally apply conversion. Instead:

- Always call `convert_to_standard_dtypes()` on all parquet responses
- The function handles both cases transparently
- When the API migrates to optimized dtypes, client code requires no changes

## Robustness: Handling New Metrics

The conversion function must handle **any** new metric added to the API in the future, not just the known columns listed below. This is achieved through dtype-based detection rather than column-name-based conversion.

### Design Principle: Convert by DType, Not by Column Name

```python
# CORRECT: dtype-based detection (handles any column)
if pd.api.types.is_integer_dtype(dtype):
    df[col] = df[col].astype("float64")

# WRONG: column-name-based detection (breaks on new columns)
if col in ["power", "heart_rate", "cadence"]:
    df[col] = df[col].astype("float64")
```

### What This Means in Practice

If the API adds a new metric like `vertical_oscillation` as `float16`, the conversion function automatically converts it to `float64` without any code changes. The same applies to:

| Future Metric | Likely DType | Conversion |
|---------------|--------------|------------|
| `vertical_oscillation` | float16 | → float64 |
| `ground_contact_time` | Int16 | → float64 |
| `power_balance` | float16 | → float64 |
| `grit` | float32 | → float64 |
| Any new metric | Int8/Int16/Int32/float16/float32 | → float64 |

### Conversion Rules Summary

The function applies these rules to **all columns**, regardless of name:

| Source DType | Target DType | Rationale |
|--------------|--------------|-----------|
| Any integer (`int8`, `int16`, `int32`, `int64`, `Int8`, `Int16`, etc.) | `float64` | Prevents overflow, supports NaN |
| Any float smaller than 64-bit (`float16`, `float32`) | `float64` | Full precision, indexable |
| `float64` | `float64` | No-op (idempotent) |
| `datetime64[s]`, `datetime64[ms]`, `datetime64[us]` | `datetime64[ns]` | Standard pandas precision |
| `datetime64[ns]` | `datetime64[ns]` | No-op (idempotent) |
| `timedelta64[s]`, `timedelta64[ms]`, `timedelta64[us]` | `timedelta64[ns]` | Standard pandas precision |
| `timedelta64[ns]` | `timedelta64[ns]` | No-op (idempotent) |
| `category`, `object`, `bool`, `string` | unchanged | Already suitable for use |

## DType Mapping Reference

### Integer Columns (nullable `Int8`/`Int16` → `float64`)

| Column | Optimized DType | Range | Notes |
|--------|-----------------|-------|-------|
| `power` | Int16 | 0-2000 W typical | Nullable for missing data |
| `heart_rate` | Int16 | 30-220 bpm | Nullable for missing data |
| `cadence` | Int16 | 0-250 rpm | Nullable for missing data |
| `lap` | Int8 | 0-127 | Lap index |
| `session_id` | Int8 | 0-127 | Multi-session FIT files |

### Float16 Columns (`float16` → `float64`)

| Column | Optimized DType | Typical Range | Notes |
|--------|-----------------|---------------|-------|
| `speed` | float16 | 0-30 m/s | ~0.01 m/s precision |
| `altitude` | float16 | -500 to 9000 m | ~1m precision |
| `temperature` | float16 | -40 to 50 °C | ~0.1°C precision |
| `core_temperature` | float16 | 35-42 °C | ~0.1°C precision |
| `smo2` | float16 | 0-100 % | Muscle oxygen saturation |
| `respiration_rate` | float16 | 5-60 breaths/min | |

### Float32 Columns (`float32` → `float64`)

| Column | Optimized DType | Notes |
|--------|-----------------|-------|
| `distance` | float32 | Cumulative, can exceed 65km |
| `latitude` | float32 | ~1m precision (GPS is 3-5m accurate) |
| `longitude` | float32 | ~1m precision |

### Timestamp/Duration Columns

| Column | Optimized DType | Standard DType |
|--------|-----------------|----------------|
| index (timestamp) | `datetime64[s, UTC]` | `datetime64[ns, UTC]` |
| `duration` | `timedelta64[s]` | `timedelta64[ns]` |

### Category Columns (no conversion needed)

| Column | DType | Notes |
|--------|-------|-------|
| `activity_id` | category | ULID string, dictionary encoded |
| `sport` | category | Enum value, dictionary encoded |

## Conversion Function

```python
import numpy as np
import pandas as pd


def convert_to_standard_dtypes(df: pd.DataFrame) -> pd.DataFrame:
    """
    Convert optimized parquet dtypes to standard dtypes for general use.

    This function is idempotent and backwards compatible:
    - Safe to call on data with standard dtypes (no-op for already-converted data)
    - Safe to call on data with optimized dtypes (performs conversion)
    - Handles any column name (not limited to known metrics)

    Conversions performed:
    - All integer types (Int8, Int16, int8, int16, int32, int64) → float64
    - Smaller floats (float16, float32) → float64
    - datetime64 (any precision) → datetime64[ns] (preserves timezone)
    - timedelta64 (any precision) → timedelta64[ns]

    Types left unchanged:
    - float64 (already standard)
    - datetime64[ns] (already standard)
    - timedelta64[ns] (already standard)
    - category (efficient, works well with pandas)
    - object, string, bool (no conversion needed)

    Args:
        df: DataFrame with any dtypes (optimized or standard)

    Returns:
        DataFrame with standard dtypes suitable for general use

    Note:
        This function always creates a copy of the DataFrame to avoid modifying
        the original and ensure consistent behavior. For memory-constrained
        scenarios with large datasets, consider using the raw (optimized) data.
    """
    df = df.copy()

    for col in df.columns:
        dtype = df[col].dtype

        # Integer types → float64 (handles nullable Int8/Int16 and regular int types)
        # This is NOT idempotent, but integers are never the target dtype
        if pd.api.types.is_integer_dtype(dtype):
            df[col] = df[col].astype("float64")

        # Float16/float32 → float64 (idempotent: skips if already float64)
        elif pd.api.types.is_float_dtype(dtype) and dtype != np.float64:
            df[col] = df[col].astype("float64")

        # Timedelta → ns precision (idempotent: skips if already ns)
        elif pd.api.types.is_timedelta64_dtype(dtype):
            if df[col].dt.unit != "ns":
                df[col] = df[col].astype("timedelta64[ns]")

        # Datetime columns (not index) → ns precision
        elif pd.api.types.is_datetime64_any_dtype(dtype):
            if df[col].dt.unit != "ns":
                # Preserve timezone if present
                if df[col].dt.tz is not None:
                    df[col] = df[col].dt.as_unit("ns")
                else:
                    df[col] = df[col].astype("datetime64[ns]")

    # Convert DatetimeIndex if present
    if isinstance(df.index, pd.DatetimeIndex):
        if df.index.unit != "ns":
            df.index = df.index.as_unit("ns")

    # Convert TimedeltaIndex if present
    elif isinstance(df.index, pd.TimedeltaIndex):
        if df.index.unit != "ns":
            df.index = df.index.as_unit("ns")

    # Handle MultiIndex with datetime/timedelta levels
    elif isinstance(df.index, pd.MultiIndex):
        new_levels = list(df.index.levels)
        changed = False
        for i, level in enumerate(new_levels):
            if isinstance(level, (pd.DatetimeIndex, pd.TimedeltaIndex)):
                if level.unit != "ns":
                    new_levels[i] = level.as_unit("ns")
                    changed = True
        if changed:
            df.index = df.index.set_levels(new_levels)

    return df
```

## Usage in Client Library

### Basic Integration

```python
from io import BytesIO
import pandas as pd


class SweatStackClient:
    """SweatStack API client with automatic dtype conversion."""

    def __init__(self, api_key: str, base_url: str = "https://api.sweatstack.io"):
        self._api_key = api_key
        self._base_url = base_url
        self._session = requests.Session()
        self._session.headers["Authorization"] = f"Bearer {api_key}"

    def _get_parquet(self, endpoint: str, params: dict = None) -> pd.DataFrame:
        """Fetch parquet data and convert to standard dtypes."""
        response = self._session.get(
            f"{self._base_url}{endpoint}",
            params=params,
        )
        response.raise_for_status()

        df = pd.read_parquet(BytesIO(response.content))
        return convert_to_standard_dtypes(df)

    def get_activity_data(self, activity_id: str) -> pd.DataFrame:
        """
        Get activity timeseries data.

        Returns DataFrame with columns like power, speed, heart_rate, etc.
        All numeric columns are float64 for easy manipulation.
        """
        return self._get_parquet(f"/api/v1/activities/{activity_id}/data")

    def get_activity_mean_max(
        self,
        activity_id: str,
        metric: str,
    ) -> pd.DataFrame:
        """Get mean-max curve for an activity."""
        return self._get_parquet(
            f"/api/v1/activities/{activity_id}/mean-max",
            params={"metric": metric},
        )

    def get_longitudinal_data(
        self,
        sport: str,
        metrics: list[str],
        start: str,
        end: str,
    ) -> pd.DataFrame:
        """Get longitudinal data across multiple activities."""
        return self._get_parquet(
            "/api/v1/activities/longitudinal-data",
            params={
                "sport": sport,
                "metrics": ",".join(metrics),
                "start": start,
                "end": end,
            },
        )
```

### Optional: Expose Raw Data for Advanced Users

```python
class SweatStackClient:
    # ... other methods ...

    def get_activity_data_raw(self, activity_id: str) -> pd.DataFrame:
        """
        Get activity data with original optimized dtypes.

        Use this if you need smaller memory footprint and are comfortable
        handling Int16/float16 limitations. For most use cases, prefer
        get_activity_data() which returns standard float64 dtypes.
        """
        response = self._session.get(
            f"{self._base_url}/api/v1/activities/{activity_id}/data",
        )
        response.raise_for_status()
        return pd.read_parquet(BytesIO(response.content))
```

## Edge Cases and Considerations

### Missing Values (NA/NaN)

The conversion handles missing values correctly:

```python
# Optimized: Int16 with pandas NA
>>> df["power"]
0     100
1    <NA>
2     200
dtype: Int16

# After conversion: float64 with NaN
>>> convert_to_standard_dtypes(df)["power"]
0    100.0
1      NaN
2    200.0
dtype: float64
```

### Infinity Values

Infinity values in float16/float32 are preserved as infinity in float64:

```python
>>> df["speed"] = pd.array([1.0, float("inf"), float("-inf")], dtype="float16")
>>> convert_to_standard_dtypes(df)["speed"]
0    1.0
1    inf
2   -inf
dtype: float64
```

### Category Columns

Category columns (`activity_id`, `sport`) are intentionally not converted. They're already memory-efficient and work well with pandas groupby/filtering:

```python
>>> df["sport"].dtype
CategoricalDtype(categories=['cycling', 'running', ...], ordered=False)

# After conversion - unchanged
>>> convert_to_standard_dtypes(df)["sport"].dtype
CategoricalDtype(categories=['cycling', 'running', ...], ordered=False)
```

### Timezone Handling

The datetime index preserves its timezone during conversion:

```python
# Optimized: datetime64[s, UTC]
>>> df.index
DatetimeIndex(['2024-01-01 10:00:00+00:00', ...], dtype='datetime64[s, UTC]')

# After conversion: datetime64[ns, UTC]
>>> convert_to_standard_dtypes(df).index
DatetimeIndex(['2024-01-01 10:00:00+00:00', ...], dtype='datetime64[ns, UTC]')
```

### Memory Impact

Converting to float64 increases memory usage. For a 1-hour activity (3,600 rows):

| Scenario | Approximate Memory |
|----------|-------------------|
| Optimized dtypes | ~50-80 KB |
| Standard dtypes | ~200-250 KB |

This is typically acceptable for single activities. For bulk operations on many activities, consider:

1. Processing activities one at a time
2. Using the raw (optimized) data if memory is constrained
3. Selecting only needed columns before conversion

## Performance Considerations

### Efficiency of the Conversion

The conversion function is designed to be fast and efficient:

| Operation | Complexity | Notes |
|-----------|------------|-------|
| DType checking | O(columns) | Uses pandas dtype introspection (very fast) |
| Skip already-standard | O(1) | Condition check only, no data copying |
| Numeric conversion | O(n) per column | Single pass, vectorized by numpy |
| DataFrame copy | O(n × columns) | Required for consistent, safe behavior |

### Benchmarks (Typical Activity)

For a 1-hour activity (3,600 rows, 15 columns):

| Scenario | Time |
|----------|------|
| Full conversion (optimized → standard) | ~1-2ms |
| No-op (already standard dtypes) | ~0.3-0.5ms |

The conversion overhead is negligible compared to network latency (~50-200ms) and parquet parsing (~5-10ms).

### Why Always Copy?

The function always copies the DataFrame, even when no conversion is needed. This ensures **consistent behavior**: callers always receive a DataFrame they can safely modify without affecting the original. The ~0.3ms copy overhead is negligible and eliminates a class of subtle bugs where modifications accidentally propagate to cached or shared data.

### Bulk Processing Strategy

When processing many activities (e.g., longitudinal analysis):

```python
# GOOD: Process one at a time, let garbage collection free memory
results = []
for activity_id in activity_ids:
    df = client.get_activity_data(activity_id)
    summary = compute_summary(df)  # Process immediately
    results.append(summary)
    # df goes out of scope, memory freed

# AVOID: Loading all activities into memory at once
all_dfs = [client.get_activity_data(aid) for aid in activity_ids]  # Memory explosion
```

## Testing the Conversion

```python
import math
import numpy as np
import pandas as pd


def test_dtype_conversion_optimized_to_standard():
    """Verify conversion handles optimized dtypes correctly."""

    # Create test data with optimized dtypes
    df = pd.DataFrame({
        "power": pd.array([100, 200, pd.NA], dtype="Int16"),
        "heart_rate": pd.array([120, 150, 180], dtype="Int16"),
        "speed": pd.array([5.0, 10.0, np.nan], dtype="float16"),
        "altitude": pd.array([100.0, 500.0, 1000.0], dtype="float16"),
        "distance": pd.array([0.0, 1000.0, 5000.0], dtype="float32"),
        "latitude": pd.array([52.123, 52.124, 52.125], dtype="float32"),
        "longitude": pd.array([4.123, 4.124, 4.125], dtype="float32"),
        "lap": pd.array([0, 0, 1], dtype="Int8"),
        "session_id": pd.array([0, 0, 0], dtype="Int8"),
        "duration": pd.to_timedelta([1, 2, 3], unit="s").astype("timedelta64[s]"),
        "activity_id": pd.Categorical(["abc123", "abc123", "abc123"]),
        "sport": pd.Categorical(["running", "running", "running"]),
    }, index=pd.DatetimeIndex(
        ["2024-01-01 10:00:00", "2024-01-01 10:00:01", "2024-01-01 10:00:02"],
        tz="UTC",
    ).as_unit("s"))

    result = convert_to_standard_dtypes(df)

    # Verify numeric columns are float64
    assert result["power"].dtype == np.float64
    assert result["heart_rate"].dtype == np.float64
    assert result["speed"].dtype == np.float64
    assert result["altitude"].dtype == np.float64
    assert result["distance"].dtype == np.float64
    assert result["latitude"].dtype == np.float64
    assert result["longitude"].dtype == np.float64
    assert result["lap"].dtype == np.float64
    assert result["session_id"].dtype == np.float64

    # Verify timedelta is nanosecond precision
    assert result["duration"].dtype == np.dtype("timedelta64[ns]")

    # Verify datetime index is nanosecond precision with timezone
    assert result.index.unit == "ns"
    assert result.index.tz is not None

    # Verify category columns unchanged
    assert result["activity_id"].dtype.name == "category"
    assert result["sport"].dtype.name == "category"

    # Verify NA handling
    assert result["power"].iloc[0] == 100.0
    assert np.isnan(result["power"].iloc[2])
    assert np.isnan(result["speed"].iloc[2])

    # Verify values preserved (use math.isclose for float comparison)
    assert math.isclose(result["latitude"].iloc[0], 52.123, rel_tol=1e-3)
    assert result["distance"].iloc[2] == 5000.0


def test_backwards_compatibility_standard_dtypes():
    """Verify conversion is a no-op for already-standard dtypes (current API)."""

    # Create test data with standard dtypes (what current API returns)
    df = pd.DataFrame({
        "power": pd.array([100.0, 200.0, np.nan], dtype="float64"),
        "heart_rate": pd.array([120.0, 150.0, 180.0], dtype="float64"),
        "speed": pd.array([5.0, 10.0, np.nan], dtype="float64"),
        "distance": pd.array([0.0, 1000.0, 5000.0], dtype="float64"),
        "duration": pd.to_timedelta([1, 2, 3], unit="s").astype("timedelta64[ns]"),
        "activity_id": pd.Categorical(["abc123", "abc123", "abc123"]),
        "sport": pd.Categorical(["running", "running", "running"]),
    }, index=pd.DatetimeIndex(
        ["2024-01-01 10:00:00", "2024-01-01 10:00:01", "2024-01-01 10:00:02"],
        tz="UTC",
    ))  # Already ns precision

    result = convert_to_standard_dtypes(df)

    # Verify dtypes unchanged
    assert result["power"].dtype == np.float64
    assert result["speed"].dtype == np.float64
    assert result["duration"].dtype == np.dtype("timedelta64[ns]")
    assert result.index.unit == "ns"

    # Verify values unchanged
    assert result["power"].iloc[0] == 100.0
    assert np.isnan(result["power"].iloc[2])


def test_idempotency():
    """Verify calling conversion twice produces identical results."""

    df = pd.DataFrame({
        "power": pd.array([100, 200, pd.NA], dtype="Int16"),
        "speed": pd.array([5.0, 10.0, np.nan], dtype="float16"),
        "duration": pd.to_timedelta([1, 2, 3], unit="s").astype("timedelta64[s]"),
    }, index=pd.DatetimeIndex(
        ["2024-01-01 10:00:00", "2024-01-01 10:00:01", "2024-01-01 10:00:02"],
        tz="UTC",
    ).as_unit("s"))

    # Convert once
    result1 = convert_to_standard_dtypes(df)

    # Convert again
    result2 = convert_to_standard_dtypes(result1)

    # Verify dtypes identical
    assert result1["power"].dtype == result2["power"].dtype == np.float64
    assert result1["speed"].dtype == result2["speed"].dtype == np.float64
    assert result1["duration"].dtype == result2["duration"].dtype

    # Verify values identical
    pd.testing.assert_frame_equal(result1, result2)


def test_unknown_columns_with_various_dtypes():
    """Verify conversion handles new/unknown metrics with any dtype."""

    # Simulate future API adding new metrics with various optimized dtypes
    df = pd.DataFrame({
        # Known columns
        "power": pd.array([100, 200], dtype="Int16"),

        # Future columns the client code doesn't know about
        "vertical_oscillation": pd.array([8.5, 9.2], dtype="float16"),
        "ground_contact_time": pd.array([250, 245], dtype="Int16"),
        "power_balance": pd.array([0.48, 0.52], dtype="float16"),
        "grit": pd.array([45.5, 50.2], dtype="float32"),
        "some_int8_metric": pd.array([1, 2], dtype="Int8"),
        "some_int32_metric": pd.array([1000000, 2000000], dtype="int32"),
        "some_int64_metric": pd.array([10**12, 2*10**12], dtype="int64"),
    })

    result = convert_to_standard_dtypes(df)

    # ALL numeric columns should be float64, regardless of name
    for col in result.columns:
        assert result[col].dtype == np.float64, f"{col} should be float64"

    # Values should be preserved
    assert math.isclose(result["vertical_oscillation"].iloc[0], 8.5, rel_tol=1e-2)
    assert result["ground_contact_time"].iloc[0] == 250.0
    assert result["some_int64_metric"].iloc[0] == 10**12


def test_original_dataframe_unchanged():
    """Verify conversion doesn't modify the original DataFrame."""

    df = pd.DataFrame({
        "power": pd.array([100, 200], dtype="Int16"),
        "speed": pd.array([5.0, 10.0], dtype="float16"),
    })

    original_power_dtype = df["power"].dtype
    original_speed_dtype = df["speed"].dtype

    _ = convert_to_standard_dtypes(df)

    # Original should be unchanged
    assert df["power"].dtype == original_power_dtype
    assert df["speed"].dtype == original_speed_dtype


def test_datetime_columns_not_just_index():
    """Verify datetime columns (not just index) are also converted."""

    df = pd.DataFrame({
        "power": pd.array([100, 200], dtype="Int16"),
        "start_time": pd.to_datetime(["2024-01-01", "2024-01-02"]).as_unit("s"),
        "end_time": pd.to_datetime(["2024-01-01 01:00", "2024-01-02 01:00"]).as_unit("s"),
    })

    result = convert_to_standard_dtypes(df)

    # Datetime columns should be ns precision
    assert result["start_time"].dt.unit == "ns"
    assert result["end_time"].dt.unit == "ns"


def test_mixed_dtypes_partial_conversion():
    """Verify only non-standard dtypes are converted."""

    df = pd.DataFrame({
        # Already standard
        "power": pd.array([100.0, 200.0], dtype="float64"),
        "bool_col": pd.array([True, False], dtype="bool"),
        "string_col": pd.array(["a", "b"], dtype="object"),

        # Needs conversion
        "speed": pd.array([5.0, 10.0], dtype="float16"),
        "hr": pd.array([120, 150], dtype="Int16"),
    })

    result = convert_to_standard_dtypes(df)

    # Already standard - unchanged
    assert result["power"].dtype == np.float64
    assert result["bool_col"].dtype == np.bool_
    assert result["string_col"].dtype == np.object_

    # Converted
    assert result["speed"].dtype == np.float64
    assert result["hr"].dtype == np.float64


def test_index_name_preserved():
    """Verify index name is preserved during conversion."""

    df = pd.DataFrame(
        {"power": pd.array([100, 200], dtype="Int16")},
        index=pd.DatetimeIndex(
            ["2024-01-01", "2024-01-02"],
            tz="UTC",
            name="timestamp",
        ).as_unit("s"),
    )

    result = convert_to_standard_dtypes(df)

    assert result.index.name == "timestamp"
    assert result.index.unit == "ns"


def test_timedelta_index():
    """Verify TimedeltaIndex is converted to ns precision."""

    # Mean-max curve indexed by duration window
    df = pd.DataFrame(
        {"power": pd.array([400, 350, 300], dtype="Int16")},
        index=pd.TimedeltaIndex([1, 5, 60], unit="s").as_unit("s"),
    )
    df.index.name = "duration"

    result = convert_to_standard_dtypes(df)

    assert isinstance(result.index, pd.TimedeltaIndex)
    assert result.index.unit == "ns"
    assert result.index.name == "duration"


def test_multiindex_with_datetime_level():
    """Verify MultiIndex with DatetimeIndex level is converted."""

    dates = pd.DatetimeIndex(
        ["2024-01-01", "2024-01-01", "2024-01-02"],
        tz="UTC",
    ).as_unit("s")
    activities = ["abc", "abc", "xyz"]

    df = pd.DataFrame(
        {"power": pd.array([100, 200, 150], dtype="Int16")},
        index=pd.MultiIndex.from_arrays(
            [dates, activities],
            names=["timestamp", "activity_id"],
        ),
    )

    result = convert_to_standard_dtypes(df)

    assert isinstance(result.index, pd.MultiIndex)
    assert result.index.names == ["timestamp", "activity_id"]
    # Check the datetime level was converted
    datetime_level = result.index.get_level_values("timestamp")
    assert datetime_level.unit == "ns"


def test_empty_dataframe():
    """Verify empty DataFrame is handled correctly."""

    df = pd.DataFrame({
        "power": pd.array([], dtype="Int16"),
        "speed": pd.array([], dtype="float16"),
    })

    result = convert_to_standard_dtypes(df)

    assert len(result) == 0
    assert result["power"].dtype == np.float64
    assert result["speed"].dtype == np.float64


def test_dataframe_no_numeric_columns():
    """Verify DataFrame with only category/object columns works."""

    df = pd.DataFrame({
        "activity_id": pd.Categorical(["abc", "xyz"]),
        "sport": pd.Categorical(["running", "cycling"]),
        "notes": pd.array(["good", "great"], dtype="object"),
    })

    result = convert_to_standard_dtypes(df)

    # All columns should be unchanged
    assert result["activity_id"].dtype.name == "category"
    assert result["sport"].dtype.name == "category"
    assert result["notes"].dtype == np.object_


def test_pyarrow_backed_dtypes():
    """Verify PyArrow-backed dtypes are converted correctly."""
    try:
        import pyarrow  # noqa: F401
    except ImportError:
        print("Skipping PyArrow test (pyarrow not installed)")
        return

    df = pd.DataFrame({
        "x": pd.array([1, 2, 3], dtype="int16[pyarrow]"),
        "y": pd.array([1.5, 2.5, 3.5], dtype="float[pyarrow]"),
    })

    result = convert_to_standard_dtypes(df)

    assert result["x"].dtype == np.float64
    assert result["y"].dtype == np.float64


if __name__ == "__main__":
    test_dtype_conversion_optimized_to_standard()
    test_backwards_compatibility_standard_dtypes()
    test_idempotency()
    test_unknown_columns_with_various_dtypes()
    test_original_dataframe_unchanged()
    test_datetime_columns_not_just_index()
    test_mixed_dtypes_partial_conversion()
    test_index_name_preserved()
    test_timedelta_index()
    test_multiindex_with_datetime_level()
    test_empty_dataframe()
    test_dataframe_no_numeric_columns()
    test_pyarrow_backed_dtypes()
    print("All tests passed!")
```

## Summary

1. **Always convert** parquet responses before returning to users
2. **Use `convert_to_standard_dtypes()`** after `pd.read_parquet()` - unconditionally, no version checks needed
3. **Backwards compatible** - works correctly whether API returns optimized or standard dtypes
4. **Idempotent** - safe to call multiple times; no-op on already-converted data
5. **Robust** - handles any new metrics automatically via dtype-based detection (not column-name-based)
6. **Handles all index types** - DatetimeIndex, TimedeltaIndex, and MultiIndex with datetime/timedelta levels
7. **Consistent behavior** - always returns a copy, ensuring safe mutation without side effects
8. **Efficient** - minimal overhead (~1-2ms), negligible compared to network/parsing
9. **Optionally expose raw data** for advanced users who want optimized dtypes
10. **Category columns** don't need conversion - they're already efficient
11. **Test thoroughly** with the provided test functions covering all edge cases
