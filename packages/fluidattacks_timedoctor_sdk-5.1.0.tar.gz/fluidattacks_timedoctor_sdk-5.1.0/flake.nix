{
  description = "Timedoctor fluid SDK";

  inputs = {
    observes_flake_builder = {
      url = "git+ssh://git@gitlab.com/fluidattacks/universe?shallow=1&rev=2ec9c61f8d8dfe8e8ba3a80b12577ec88c3bc7cb&dir=observes/common/std_flake_2";
    };
  };

  outputs =
    { self, ... }@inputs:
    let
      build_args =
        {
          system,
          python_version,
          nixpkgs,
          builders,
          scripts,
        }:
        import ./build {
          inherit nixpkgs builders scripts;
          src = import ./build/filter.nix nixpkgs.nix-filter self;
        };
    in
    {
      packages = inputs.observes_flake_builder.outputs.build build_args;
    };
}
