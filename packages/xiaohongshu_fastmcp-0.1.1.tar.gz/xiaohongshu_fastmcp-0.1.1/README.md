# xiaohongshu-fastmcp

Python + FastMCP implementation of `xiaohongshu-mcp` with the same MCP tool surface.

## Goals

- Keep MCP tool names and arguments aligned with the Go server
- Keep transport compatible at `http://localhost:18060/mcp`
- Migrate in small batches while preserving behavior contracts

## Prerequisites

1. Python 3.11+
2. Chrome/Chromium installed
3. Playwright browser runtime:

```bash
pip install -e .
playwright install chromium
```

## Run

```bash
xiaohongshu-fastmcp --port 18060 --headless
```

or:

```bash
python -m xiaohongshu_fastmcp.server --port 18060 --headless
```

Run as stdio MCP server (for clients configured via `uvx`, e.g. Manus):

```bash
xiaohongshu-fastmcp --transport stdio --headless
```

or:

```bash
python -m xiaohongshu_fastmcp.server --transport stdio --headless
```

Example Manus stdio command using uvx:

```bash
uvx --from xiaohongshu-fastmcp xiaohongshu-fastmcp --transport stdio --headless
```

## Endpoints

- MCP: `http://localhost:18060/mcp`
- Health: `http://localhost:18060/health`
- REST: `http://localhost:18060/api/v1/*`

## Environment Variables

- `XHS_PROXY`: optional proxy URL
- `COOKIES_PATH`: optional cookies file path
- `ROD_BROWSER_BIN`: browser binary path compatibility alias
- `XHS_BROWSER_BIN`: browser binary path

## Notes

- This project now exposes both MCP (`/mcp`) and REST compatibility routes (`/api/v1/*`, `/health`) in one process.
- FastMCP runtime is pinned to `fastmcp==3.1.1`.
- Publish flow prefers Go-parity selectors and keeps fallback selectors for DOM drift.
