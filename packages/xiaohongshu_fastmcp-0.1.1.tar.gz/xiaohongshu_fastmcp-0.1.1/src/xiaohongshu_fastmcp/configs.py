from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from pathlib import Path


IMAGES_DIR_NAME = "xiaohongshu_images"
DEFAULT_USERNAME = "xiaohongshu-mcp"


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def get_default_images_path() -> Path:
    return Path(tempfile.gettempdir()) / IMAGES_DIR_NAME


def get_default_cookies_path() -> Path:
    old_path = Path(tempfile.gettempdir()) / "cookies.json"
    if old_path.exists():
        return old_path

    raw = os.getenv("COOKIES_PATH")
    if raw:
        return Path(raw)

    return Path("cookies.json")


def get_browser_bin_from_env() -> str | None:
    # Compatibility alias with Go version.
    return os.getenv("XHS_BROWSER_BIN") or os.getenv("ROD_BROWSER_BIN")


@dataclass(slots=True)
class RuntimeConfig:
    host: str = "0.0.0.0"
    port: int = 18060
    headless: bool = True
    browser_bin_path: str | None = None
    proxy: str | None = None
    cookies_path: Path = get_default_cookies_path()
    images_path: Path = get_default_images_path()
    debug: bool = False

    @classmethod
    def from_env(cls) -> "RuntimeConfig":
        return cls(
            host=os.getenv("XHS_HOST", "0.0.0.0"),
            port=int(os.getenv("XHS_PORT", "18060")),
            headless=_env_bool("XHS_HEADLESS", True),
            browser_bin_path=get_browser_bin_from_env(),
            proxy=os.getenv("XHS_PROXY"),
            cookies_path=get_default_cookies_path(),
            images_path=get_default_images_path(),
            debug=_env_bool("XHS_DEBUG", False),
        )

