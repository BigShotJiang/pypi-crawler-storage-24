from __future__ import annotations

import asyncio
from dataclasses import asdict, replace
from datetime import datetime, timedelta
from pathlib import Path
import re
from typing import Any

from .browser import BrowserManager
from .configs import DEFAULT_USERNAME, RuntimeConfig
from .cookies import delete_cookies as delete_cookies_file
from .cookies import save_cookies
from .models import FilterOption
from .utils.image_downloader import ImageDownloader
from .utils.title_len import calc_title_length
from .xiaohongshu import (
    CommentFeedAction,
    CommentLoadConfig,
    FavoriteAction,
    FeedDetailAction,
    FeedsListAction,
    LikeAction,
    LoginAction,
    PublishAction,
    PublishImageContent,
    PublishVideoContent,
    SearchAction,
    UserProfileAction,
)
from .xiaohongshu.common import URL_EXPLORE
from .xiaohongshu.common import safe_wait_networkidle
from .xiaohongshu.search import FilterOption as SearchFilterOption

_RFC3339_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T"
    r"\d{2}:\d{2}:\d{2}"
    r"(?:\.\d+)?"
    r"(?:Z|[+-]\d{2}:\d{2})$"
)


class XiaohongshuService:
    def __init__(self, config: RuntimeConfig) -> None:
        self.config = config
        self.browser_manager = BrowserManager(config)
        self._background_tasks: set[asyncio.Task[Any]] = set()

    async def delete_cookies(self) -> None:
        delete_cookies_file(self.config.cookies_path)

    async def check_login_status(self) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = LoginAction(bundle.page)
            logged_in = await action.check_login_status()
            return {
                "is_logged_in": logged_in,
                "username": DEFAULT_USERNAME,
            }

    async def get_login_qrcode(self) -> dict[str, Any]:
        managers: list[BrowserManager] = [self.browser_manager]
        if self.config.headless:
            managers.append(BrowserManager(replace(self.config, headless=False)))

        last_exc: Exception | None = None
        for idx, manager in enumerate(managers):
            bundle = await manager.open_page()
            action = LoginAction(bundle.page)
            try:
                img, logged_in = await action.fetch_qrcode_image()
                if logged_in:
                    await bundle.close()
                    return {
                        "timeout": "0s",
                        "is_logged_in": True,
                        "img": "",
                    }

                timeout_seconds = 4 * 60
                task = asyncio.create_task(self._wait_for_login_and_save(bundle, timeout_seconds))
                self._track_task(task)
                return {
                    "timeout": "4m0s",
                    "is_logged_in": False,
                    "img": img,
                }
            except Exception as exc:
                await bundle.close()
                last_exc = exc
                can_retry_with_headed = (
                    idx < len(managers) - 1
                    and any(
                        token in str(exc).lower()
                        for token in ("login panel not found", "qrcode not ready yet")
                    )
                )
                if can_retry_with_headed:
                    continue
                raise

        if last_exc is not None:
            raise last_exc
        raise RuntimeError("获取登录二维码失败")

    async def publish_content(
        self,
        *,
        title: str,
        content: str,
        images: list[str],
        tags: list[str],
        schedule_at: str | None,
        is_original: bool,
        visibility: str | None,
        products: list[str],
    ) -> dict[str, Any]:
        if calc_title_length(title) > 20:
            raise RuntimeError("标题长度超过限制")

        image_paths = await self._process_images(images)
        schedule_time = self._parse_schedule_at(schedule_at)

        publish_content = PublishImageContent(
            title=title,
            content=content,
            tags=tags,
            image_paths=image_paths,
            schedule_time=schedule_time,
            is_original=is_original,
            visibility=visibility or "",
            products=products,
        )

        async with self.browser_manager.new_page() as bundle:
            action = PublishAction(bundle.page)
            await action.publish_image(publish_content)

        return {
            "title": title,
            "content": content,
            "images": len(image_paths),
            "status": "发布完成",
        }

    async def publish_video(
        self,
        *,
        title: str,
        content: str,
        video: str,
        tags: list[str],
        schedule_at: str | None,
        visibility: str | None,
        products: list[str],
    ) -> dict[str, Any]:
        if calc_title_length(title) > 20:
            raise RuntimeError("标题长度超过限制")
        if not video:
            raise RuntimeError("必须提供本地视频文件")
        if not Path(video).exists():
            raise RuntimeError("视频文件不存在或不可访问")

        schedule_time = self._parse_schedule_at(schedule_at)
        publish_content = PublishVideoContent(
            title=title,
            content=content,
            tags=tags,
            video_path=video,
            schedule_time=schedule_time,
            visibility=visibility or "",
            products=products,
        )

        async with self.browser_manager.new_page() as bundle:
            action = PublishAction(bundle.page)
            await action.publish_video(publish_content)

        return {
            "title": title,
            "content": content,
            "video": video,
            "status": "发布完成",
        }

    async def list_feeds(self) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = FeedsListAction(bundle.page)
            feeds = await action.get_feeds_list()
        return {"feeds": feeds, "count": len(feeds)}

    async def search_feeds(self, keyword: str, filters: FilterOption | None = None) -> dict[str, Any]:
        search_filters = None
        if filters is not None:
            search_filters = SearchFilterOption(
                sort_by=filters.sort_by,
                note_type=filters.note_type,
                publish_time=filters.publish_time,
                search_scope=filters.search_scope,
                location=filters.location,
            )
        async with self.browser_manager.new_page() as bundle:
            action = SearchAction(bundle.page)
            feeds = await action.search(keyword=keyword, filter_option=search_filters)
        return {"feeds": feeds, "count": len(feeds)}

    async def get_feed_detail_with_config(
        self,
        *,
        feed_id: str,
        xsec_token: str,
        load_all_comments: bool,
        config: CommentLoadConfig,
    ) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = FeedDetailAction(bundle.page)
            data = await action.get_feed_detail_with_config(
                feed_id=feed_id,
                xsec_token=xsec_token,
                load_all_comments=load_all_comments,
                config=config,
            )
        return {"feed_id": feed_id, "data": data}

    async def user_profile(self, user_id: str, xsec_token: str) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = UserProfileAction(bundle.page)
            return await action.user_profile(user_id=user_id, xsec_token=xsec_token)

    async def get_my_profile(self) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            page = bundle.page
            await page.goto(URL_EXPLORE, wait_until="domcontentloaded")
            await safe_wait_networkidle(page)
            sidebar = page.locator("div.main-container li.user.side-bar-component a.link-wrapper span.channel").first
            if await sidebar.count() == 0:
                raise RuntimeError("未找到个人主页入口，可能未登录")
            await sidebar.click()
            await safe_wait_networkidle(page)
            action = UserProfileAction(page)
            return await action.extract_user_profile_data()

    async def post_comment_to_feed(self, feed_id: str, xsec_token: str, content: str) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = CommentFeedAction(bundle.page)
            await action.post_comment(feed_id=feed_id, xsec_token=xsec_token, content=content)
        return {
            "feed_id": feed_id,
            "success": True,
            "message": "评论发表成功",
        }

    async def reply_comment_to_feed(
        self,
        feed_id: str,
        xsec_token: str,
        comment_id: str | None,
        user_id: str | None,
        content: str,
    ) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = CommentFeedAction(bundle.page)
            await action.reply_to_comment(
                feed_id=feed_id,
                xsec_token=xsec_token,
                comment_id=comment_id,
                user_id=user_id,
                content=content,
            )
        return {
            "feed_id": feed_id,
            "target_comment_id": comment_id or "",
            "target_user_id": user_id or "",
            "success": True,
            "message": "评论回复成功",
        }

    async def like_feed(self, feed_id: str, xsec_token: str) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = LikeAction(bundle.page)
            result = await action.like(feed_id=feed_id, xsec_token=xsec_token)
        return asdict(result)

    async def unlike_feed(self, feed_id: str, xsec_token: str) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = LikeAction(bundle.page)
            result = await action.unlike(feed_id=feed_id, xsec_token=xsec_token)
        return asdict(result)

    async def favorite_feed(self, feed_id: str, xsec_token: str) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = FavoriteAction(bundle.page)
            result = await action.favorite(feed_id=feed_id, xsec_token=xsec_token)
        return asdict(result)

    async def unfavorite_feed(self, feed_id: str, xsec_token: str) -> dict[str, Any]:
        async with self.browser_manager.new_page() as bundle:
            action = FavoriteAction(bundle.page)
            result = await action.unfavorite(feed_id=feed_id, xsec_token=xsec_token)
        return asdict(result)

    async def _process_images(self, images: list[str]) -> list[str]:
        downloader = ImageDownloader(self.config.images_path)
        try:
            return await downloader.process_images(images)
        finally:
            await downloader.close()

    def _parse_schedule_at(self, schedule_at: str | None) -> datetime | None:
        if not schedule_at:
            return None
        raw = schedule_at.strip()
        if not _RFC3339_RE.match(raw):
            raise RuntimeError("定时发布时间格式错误，请使用 ISO8601 格式: invalid RFC3339 timestamp")
        if raw.endswith("Z"):
            raw = raw[:-1] + "+00:00"
        try:
            dt = datetime.fromisoformat(raw)
        except ValueError as exc:
            raise RuntimeError(f"定时发布时间格式错误，请使用 ISO8601 格式: {exc}") from exc

        now = datetime.now(dt.tzinfo)
        min_time = now + timedelta(hours=1)
        max_time = now + timedelta(days=14)
        if dt < min_time:
            raise RuntimeError(
                f"定时发布时间必须至少在1小时后，当前设置: {dt.strftime('%Y-%m-%d %H:%M')}，"
                f"最早可选: {min_time.strftime('%Y-%m-%d %H:%M')}"
            )
        if dt > max_time:
            raise RuntimeError(
                f"定时发布时间不能超过14天，当前设置: {dt.strftime('%Y-%m-%d %H:%M')}，"
                f"最晚可选: {max_time.strftime('%Y-%m-%d %H:%M')}"
            )
        return dt

    async def _wait_for_login_and_save(self, bundle, timeout_seconds: int) -> None:
        try:
            action = LoginAction(bundle.page)
            ok = await action.wait_for_login(timeout_seconds=timeout_seconds)
            if ok:
                cks = await bundle.context.cookies()
                save_cookies(self.config.cookies_path, cks)
        finally:
            await bundle.close()

    def _track_task(self, task: asyncio.Task[Any]) -> None:
        self._background_tasks.add(task)

        def _done(_task: asyncio.Task[Any]) -> None:
            self._background_tasks.discard(_task)

        task.add_done_callback(_done)
