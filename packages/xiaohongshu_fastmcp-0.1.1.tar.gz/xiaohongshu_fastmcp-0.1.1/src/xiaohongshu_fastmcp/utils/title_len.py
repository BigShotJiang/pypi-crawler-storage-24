from __future__ import annotations


def calc_title_length(value: str) -> int:
    """
    Keep parity with Go implementation:
    - iterate UTF-16 code units
    - code unit > 127 counts as 2 bytes
    - code unit <= 127 counts as 1 byte
    - final length is ceil(byte_len / 2)
    """
    byte_len = 0
    utf16_le = value.encode("utf-16-le")
    for idx in range(0, len(utf16_le), 2):
        code_unit = utf16_le[idx] | (utf16_le[idx + 1] << 8)
        if code_unit > 127:
            byte_len += 2
        else:
            byte_len += 1
    return (byte_len + 1) // 2
