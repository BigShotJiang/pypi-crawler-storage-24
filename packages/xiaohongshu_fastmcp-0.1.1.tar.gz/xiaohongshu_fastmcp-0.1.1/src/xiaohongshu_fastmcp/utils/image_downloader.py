from __future__ import annotations

import hashlib
import time
from pathlib import Path
from urllib.parse import urlparse

import filetype
import httpx


def is_image_url(path_or_url: str) -> bool:
    lower = path_or_url.lower()
    return lower.startswith("http://") or lower.startswith("https://")


class ImageDownloader:
    def __init__(self, save_path: Path) -> None:
        self.save_path = save_path
        self.save_path.mkdir(parents=True, exist_ok=True)
        self._client = httpx.AsyncClient(timeout=30.0, follow_redirects=True)

    async def close(self) -> None:
        await self._client.aclose()

    async def download_image(self, image_url: str) -> str:
        parsed = urlparse(image_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("invalid image URL format")

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            "Referer": f"{parsed.scheme}://{parsed.netloc}/",
        }

        resp = await self._client.get(image_url, headers=headers)
        resp.raise_for_status()
        data = resp.content

        kind = filetype.guess(data)
        if kind is None or not kind.mime.startswith("image/"):
            raise ValueError("downloaded file is not a valid image")

        file_name = self._generate_file_name(image_url, kind.extension)
        file_path = self.save_path / file_name
        file_path.write_bytes(data)
        return str(file_path)

    async def process_images(self, images: list[str]) -> list[str]:
        local_paths: list[str] = []
        for image in images:
            if is_image_url(image):
                local_paths.append(await self.download_image(image))
            else:
                local_paths.append(image)
        if not local_paths:
            raise ValueError("no valid images found")
        return local_paths

    @staticmethod
    def _generate_file_name(image_url: str, extension: str) -> str:
        digest = hashlib.sha256(image_url.encode("utf-8")).hexdigest()[:16]
        now = int(time.time())
        return f"img_{digest}_{now}.{extension}"

