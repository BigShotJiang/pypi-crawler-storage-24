from __future__ import annotations

import asyncio
from urllib.parse import quote_plus

from playwright.async_api import Page


URL_EXPLORE = "https://www.xiaohongshu.com/explore"
URL_HOME = "https://www.xiaohongshu.com"
URL_PUBLISH = "https://creator.xiaohongshu.com/publish/publish?source=official"


def make_feed_detail_url(feed_id: str, xsec_token: str) -> str:
    return f"https://www.xiaohongshu.com/explore/{feed_id}?xsec_token={xsec_token}&xsec_source=pc_feed"


def make_user_profile_url(user_id: str, xsec_token: str) -> str:
    return (
        f"https://www.xiaohongshu.com/user/profile/{user_id}"
        f"?xsec_token={xsec_token}&xsec_source=pc_note"
    )


def make_search_url(keyword: str) -> str:
    return (
        "https://www.xiaohongshu.com/search_result"
        f"?keyword={quote_plus(keyword)}&source=web_explore_feed"
    )


async def wait_initial_state(page: Page, timeout_ms: int = 15000) -> None:
    await page.wait_for_function("() => window.__INITIAL_STATE__ !== undefined", timeout=timeout_ms)


async def safe_wait_networkidle(page: Page, timeout_ms: int = 5000) -> None:
    """Best-effort wait for networkidle.

    XHS pages continuously send telemetry / polling requests so the
    ``networkidle`` state is rarely reached.  We cap the wait to avoid
    blocking the whole tool call with a ``Timeout 30000ms exceeded`` error.
    """
    try:
        await page.wait_for_load_state("networkidle", timeout=timeout_ms)
    except Exception:
        pass


async def is_logged_in(page: Page) -> bool:
    selectors = [
        ".main-container .user .link-wrapper .channel",
        ".side-bar-component .user .link-wrapper .channel",
        "a.link-wrapper[href*='/user/profile/'] .channel",
    ]
    for selector in selectors:
        try:
            await page.wait_for_selector(selector, timeout=1000, state="attached")
            return True
        except Exception:
            continue

    # Some web builds store login status in Vue refs under __INITIAL_STATE__.
    try:
        logged = await page.evaluate(
            """() => {
                const user = window.__INITIAL_STATE__?.user;
                if (!user) return null;
                const v = user.loggedIn;
                if (typeof v === "boolean") return v;
                if (v && typeof v === "object") {
                    if (typeof v._value === "boolean") return v._value;
                    if (typeof v.value === "boolean") return v.value;
                }
                // Note: do NOT check userId here — guest users also have a userId.
                return null;
            }"""
        )
        if isinstance(logged, bool):
            return logged
    except Exception:
        pass

    return False


async def sleep(seconds: float) -> None:
    await asyncio.sleep(seconds)


async def check_page_accessible(page: Page) -> None:
    text = await page.evaluate(
        """() => {
            const node = document.querySelector(
                '.access-wrapper, .error-wrapper, .not-found-wrapper, .blocked-wrapper'
            );
            return node ? (node.innerText || '').trim() : '';
        }"""
    )
    if not text:
        return

    keywords = [
        "当前笔记暂时无法浏览",
        "该内容因违规已被删除",
        "该笔记已被删除",
        "内容不存在",
        "笔记不存在",
        "已失效",
        "私密笔记",
        "仅作者可见",
        "因用户设置，你无法查看",
        "因违规无法查看",
    ]
    for kw in keywords:
        if kw in text:
            raise RuntimeError(f"笔记不可访问: {kw}")

    raise RuntimeError(f"笔记不可访问: {text}")
