from __future__ import annotations

import asyncio
import time

from playwright.async_api import Page

from .common import URL_EXPLORE, is_logged_in, safe_wait_networkidle


class LoginAction:
    def __init__(self, page: Page) -> None:
        self.page = page

    async def check_login_status(self) -> bool:
        await self.page.goto(URL_EXPLORE, wait_until="domcontentloaded")
        await safe_wait_networkidle(self.page)
        await asyncio.sleep(1.0)
        return await is_logged_in(self.page)

    async def fetch_qrcode_image(self) -> tuple[str, bool]:
        img, logged_in, panel_seen = await self._fetch_qrcode_for_url(
            URL_EXPLORE,
            open_panel=True,
            rounds=6,
        )
        if logged_in:
            return "", True
        if img:
            return img, False

        # Fallback to dedicated login page when explore page does not expose panel in time.
        img, logged_in, panel_seen_login = await self._fetch_qrcode_for_url(
            "https://www.xiaohongshu.com/login",
            open_panel=False,
            rounds=6,
        )
        if logged_in:
            return "", True
        if img:
            return img, False

        if panel_seen or panel_seen_login:
            raise RuntimeError("qrcode not ready yet")
        raise RuntimeError("login panel not found")

    async def wait_for_login(self, timeout_seconds: int = 240) -> bool:
        # Capture the initial web_session value — XHS always issues a web_session
        # to guests too, so we cannot just check for its *presence*.
        # Real login is detected when the session value *changes* (guest → user)
        # or when the page navigates to a logged-in state.
        initial_session = await self._get_web_session_value()

        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline:
            if await is_logged_in(self.page):
                return True
            current_session = await self._get_web_session_value()
            if current_session and current_session != initial_session:
                # Session token replaced: real user login happened
                return True
            await asyncio.sleep(0.5)
        return False

    async def _ensure_login_panel_open(self) -> None:
        if await self._has_login_panel_hint():
            return

        selectors = [
            ".main-container .user .login-btn",
            ".side-bar-component button:has-text('登录')",
            "button:has-text('登录')",
            "a:has-text('登录')",
            "span:has-text('登录')",
            "text=立即登录",
            "text=去登录",
            "text=登录",
        ]
        for selector in selectors:
            node = self.page.locator(selector).first
            if await node.count() == 0:
                continue
            try:
                await node.click(timeout=1200)
                await asyncio.sleep(0.6)
                if await self._has_login_panel_hint():
                    return
            except Exception:
                continue

        await self.page.evaluate(
            """() => {
                const candidates = Array.from(document.querySelectorAll("button,a,span,div"));
                for (const el of candidates) {
                    const text = (el.textContent || "").trim();
                    if (!text) continue;
                    if (text !== "登录" && !text.includes("立即登录") && !text.includes("去登录")) continue;
                    const rect = el.getBoundingClientRect();
                    if (rect.width <= 0 || rect.height <= 0) continue;
                    if (rect.bottom < 0 || rect.top > window.innerHeight) continue;
                    try {
                        el.click();
                        return true;
                    } catch (e) {}
                }
                return false;
            }"""
        )
        await asyncio.sleep(0.6)

    async def _has_login_panel_hint(self) -> bool:
        return bool(
            await self.page.evaluate(
                """() => {
                    if (document.querySelector(".login-container")) return true;
                    if (document.querySelector(".qrcode-img")) return true;
                    const text = document.body?.innerText || "";
                    return (
                        text.includes("扫码登录") ||
                        text.includes("请扫码登录") ||
                        text.includes("手机号登录")
                    );
                }"""
            )
        )

    async def _extract_qrcode_from_img(self) -> str:
        src = str(
            await self.page.evaluate(
                """() => {
                    const roots = Array.from(
                        document.querySelectorAll(".login-container, [class*='login-container'], [role='dialog']")
                    );
                    const images = [];
                    for (const root of roots) {
                        for (const img of root.querySelectorAll("img")) images.push(img);
                    }
                    if (images.length === 0) {
                        for (const img of document.querySelectorAll("img.qrcode-img, img[src*='qrcode'], img[src*='qr']")) {
                            images.push(img);
                        }
                    }

                    let best = null;
                    let bestArea = 0;
                    for (const img of images) {
                        const src = img.getAttribute("src") || "";
                        if (!src) continue;
                        const rect = img.getBoundingClientRect();
                        const area = rect.width * rect.height;
                        if (rect.width < 80 || rect.height < 80) continue;
                        if (area > bestArea) {
                            best = src;
                            bestArea = area;
                        }
                    }
                    return best || "";
                }"""
            )
        ).strip()
        return src

    async def _extract_qrcode_from_canvas(self) -> str:
        src = str(
            await self.page.evaluate(
                """() => {
                    const roots = Array.from(
                        document.querySelectorAll(".login-container, [class*='login-container'], [role='dialog']")
                    );
                    const canvasNodes = [];
                    for (const root of roots) {
                        for (const canvas of root.querySelectorAll("canvas")) canvasNodes.push(canvas);
                    }
                    if (canvasNodes.length === 0) {
                        for (const canvas of document.querySelectorAll("canvas")) canvasNodes.push(canvas);
                    }

                    let best = null;
                    let bestArea = 0;
                    for (const canvas of canvasNodes) {
                        const rect = canvas.getBoundingClientRect();
                        const area = rect.width * rect.height;
                        if (rect.width < 80 || rect.height < 80) continue;
                        if (area <= bestArea) continue;
                        try {
                            const data = canvas.toDataURL("image/png");
                            if (!data) continue;
                            best = data;
                            bestArea = area;
                        } catch (e) {}
                    }
                    return best || "";
                }"""
            )
        ).strip()
        return src

    async def _fetch_qrcode_for_url(
        self,
        url: str,
        *,
        open_panel: bool,
        rounds: int,
    ) -> tuple[str, bool, bool]:
        await self.page.goto(url, wait_until="domcontentloaded")
        await safe_wait_networkidle(self.page)
        await asyncio.sleep(1.0)

        if await is_logged_in(self.page):
            return "", True, False

        panel_seen = False
        for _ in range(rounds):
            if open_panel:
                await self._ensure_login_panel_open()

            if await is_logged_in(self.page):
                return "", True, panel_seen

            src = await self._extract_qrcode_from_img()
            if src:
                return src, False, True

            canvas_src = await self._extract_qrcode_from_canvas()
            if canvas_src:
                return canvas_src, False, True

            seen = await self._has_login_panel_hint()
            panel_seen = panel_seen or seen
            await asyncio.sleep(1.0)

        return "", False, panel_seen

    async def _get_web_session_value(self) -> str | None:
        """Return the current web_session cookie value, or None if absent."""
        try:
            cookies = await self.page.context.cookies()
        except Exception:
            return None
        for cookie in cookies:
            if cookie.get("name") == "web_session":
                return str(cookie.get("value", "")).strip() or None
        return None

    async def _has_login_cookie(self) -> bool:
        """Deprecated: kept for reference only. Use _get_web_session_value instead."""
        return (await self._get_web_session_value()) is not None
