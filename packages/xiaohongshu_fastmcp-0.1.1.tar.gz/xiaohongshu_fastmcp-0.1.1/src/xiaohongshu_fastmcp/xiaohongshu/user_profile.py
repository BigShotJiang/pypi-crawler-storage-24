from __future__ import annotations

from typing import Any

from playwright.async_api import Page

from .common import make_user_profile_url, wait_initial_state, safe_wait_networkidle


class UserProfileAction:
    def __init__(self, page: Page) -> None:
        self.page = page

    async def user_profile(self, user_id: str, xsec_token: str) -> dict[str, Any]:
        await self.page.goto(make_user_profile_url(user_id, xsec_token), wait_until="domcontentloaded")
        await safe_wait_networkidle(self.page)
        return await self.extract_user_profile_data()

    async def extract_user_profile_data(self) -> dict[str, Any]:
        await wait_initial_state(self.page)

        user_data = await self.page.evaluate(
            """() => {
                if (window.__INITIAL_STATE__ &&
                    window.__INITIAL_STATE__.user &&
                    window.__INITIAL_STATE__.user.userPageData) {
                    const userPageData = window.__INITIAL_STATE__.user.userPageData;
                    return userPageData.value !== undefined ? userPageData.value : userPageData._value;
                }
                return null;
            }"""
        )
        if not user_data:
            raise RuntimeError("user.userPageData.value not found in __INITIAL_STATE__")

        notes_data = await self.page.evaluate(
            """() => {
                if (window.__INITIAL_STATE__ &&
                    window.__INITIAL_STATE__.user &&
                    window.__INITIAL_STATE__.user.notes) {
                    const notes = window.__INITIAL_STATE__.user.notes;
                    return notes.value !== undefined ? notes.value : notes._value;
                }
                return null;
            }"""
        )
        if notes_data is None:
            raise RuntimeError("user.notes.value not found in __INITIAL_STATE__")

        interactions = user_data.get("interactions") if isinstance(user_data, dict) else []
        basic_info = user_data.get("basicInfo") if isinstance(user_data, dict) else {}

        flattened_feeds: list[dict[str, Any]] = []
        if isinstance(notes_data, list):
            for group in notes_data:
                if isinstance(group, list):
                    for item in group:
                        if isinstance(item, dict):
                            flattened_feeds.append(item)
                elif isinstance(group, dict):
                    flattened_feeds.append(group)

        return {
            "userBasicInfo": basic_info,
            "interactions": interactions,
            "feeds": flattened_feeds,
        }

