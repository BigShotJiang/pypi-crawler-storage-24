from __future__ import annotations

import asyncio
import os
import random
import re
from dataclasses import dataclass
from datetime import datetime

from playwright.async_api import Locator, Page

from .common import URL_PUBLISH, safe_wait_networkidle


@dataclass(slots=True)
class PublishImageContent:
    title: str
    content: str
    tags: list[str]
    image_paths: list[str]
    schedule_time: datetime | None = None
    is_original: bool = False
    visibility: str = ""
    products: list[str] | None = None


@dataclass(slots=True)
class PublishVideoContent:
    title: str
    content: str
    tags: list[str]
    video_path: str
    schedule_time: datetime | None = None
    visibility: str = ""
    products: list[str] | None = None


class PublishAction:
    def __init__(self, page: Page) -> None:
        self.page = page

    async def publish_image(self, content: PublishImageContent) -> None:
        if not content.image_paths:
            raise RuntimeError("图片不能为空")

        await self._open_publish_page("上传图文")
        await self._upload_images(content.image_paths)
        await self._submit_publish(
            title=content.title,
            content=content.content,
            tags=content.tags[:10],
            schedule_time=content.schedule_time,
            visibility=content.visibility,
            is_original=content.is_original,
            products=content.products or [],
        )

    async def publish_video(self, content: PublishVideoContent) -> None:
        if not content.video_path:
            raise RuntimeError("视频不能为空")
        if not os.path.exists(content.video_path):
            raise RuntimeError(f"视频文件不存在: {content.video_path}")

        await self._open_publish_page("上传视频")
        await self._upload_video(content.video_path)
        await self._submit_publish(
            title=content.title,
            content=content.content,
            tags=content.tags[:10],
            schedule_time=content.schedule_time,
            visibility=content.visibility,
            is_original=False,
            products=content.products or [],
        )

    async def _open_publish_page(self, tab_name: str) -> None:
        await self.page.goto(URL_PUBLISH, wait_until="domcontentloaded")
        await safe_wait_networkidle(self.page)
        # Wait for the upload area to appear (mirrors Go's MustWaitVisible)
        try:
            await self.page.locator("div.upload-content").first.wait_for(
                state="visible", timeout=15000
            )
        except Exception:
            # Fallback: just wait a bit longer
            await asyncio.sleep(3.0)
        await asyncio.sleep(1.0)
        await self._click_publish_tab(tab_name)
        await asyncio.sleep(1.0)

    async def _click_publish_tab(self, tab_name: str) -> None:
        aliases = [tab_name]
        if tab_name == "上传图文":
            aliases.extend(["图文", "发布图文"])
        elif tab_name == "上传视频":
            aliases.extend(["视频", "发布视频"])

        # Retry loop matching Go's 15-second deadline approach.
        deadline = asyncio.get_event_loop().time() + 15
        last_err: Exception | None = None
        while asyncio.get_event_loop().time() < deadline:
            # Remove popover overlays that can block the tab
            await self.page.evaluate("""() => {
                document.querySelectorAll('div.d-popover').forEach(el => el.remove());
            }""")

            found_tab = False
            for alias in aliases:
                tabs = self.page.locator("div.creator-tab, [role='tab']", has_text=alias)
                if await tabs.count() == 0:
                    continue

                found_tab = True
                tab = tabs.first
                try:
                    await tab.evaluate(
                        "el => { el.scrollIntoView({block:'center'}); el.click(); }"
                    )
                    await asyncio.sleep(0.3)
                    return
                except Exception as exc:
                    last_err = exc
                    await asyncio.sleep(0.3)
                    continue

            if tab_name == "上传图文" and not found_tab:
                # Some page versions default to image mode and hide tabs.
                upload = self.page.locator(".upload-input, input[type='file']").first
                if await upload.count() > 0:
                    return

            await asyncio.sleep(0.5)

        if last_err:
            raise RuntimeError(f"点击发布 TAB 失败 - {tab_name}: {last_err}")
        raise RuntimeError(f"没有找到发布 TAB - {tab_name}")

    async def _upload_images(self, image_paths: list[str]) -> None:
        valid_paths: list[str] = []
        for path in image_paths:
            if not os.path.exists(path):
                raise RuntimeError(f"文件不存在: {path}")
            valid_paths.append(path)

        for idx, path in enumerate(valid_paths):
            selector = ".upload-input" if idx == 0 else "input[type='file']"
            upload = self.page.locator(selector).first
            if await upload.count() == 0:
                raise RuntimeError(f"查找上传输入框失败(第{idx + 1}张)")

            await upload.set_input_files(path)
            await self._wait_image_upload_complete(idx + 1)
            await asyncio.sleep(1.0)

    async def _wait_image_upload_complete(self, expected_count: int) -> None:
        deadline = asyncio.get_event_loop().time() + 60
        while asyncio.get_event_loop().time() < deadline:
            count = await self.page.locator(".img-preview-area .pr").count()
            if count >= expected_count:
                return
            await asyncio.sleep(0.5)
        raise RuntimeError(f"第{expected_count}张图片上传超时(60s)，请检查网络连接和图片大小")

    async def _upload_video(self, video_path: str) -> None:
        upload = self.page.locator(".upload-input").first
        if await upload.count() == 0:
            upload = self.page.locator("input[type='file']").first
        if await upload.count() == 0:
            raise RuntimeError("未找到视频上传输入框")

        await upload.set_input_files(video_path)
        await self._wait_publish_button_clickable(max_wait_seconds=600)

    async def _wait_publish_button_clickable(self, max_wait_seconds: int = 120) -> None:
        selector = ".publish-page-publish-btn button.bg-red"
        loops = int(max_wait_seconds)
        for _ in range(loops):
            button = self.page.locator(selector).first
            if await button.count() > 0:
                disabled = await button.get_attribute("disabled")
                if disabled is None:
                    return
            await asyncio.sleep(1.0)
        raise RuntimeError("等待发布按钮可点击超时")

    async def _submit_publish(
        self,
        *,
        title: str,
        content: str,
        tags: list[str],
        schedule_time: datetime | None,
        visibility: str,
        is_original: bool,
        products: list[str],
    ) -> None:
        # Wait for title input to be ready
        title_input = self.page.locator("div.d-input input").first
        try:
            await title_input.wait_for(state="visible", timeout=10000)
        except Exception:
            raise RuntimeError("查找标题输入框失败")

        await title_input.click()
        await title_input.fill(title)
        await asyncio.sleep(0.5)
        await self._check_title_max_length()

        await asyncio.sleep(1.0)
        content_input = await self._get_content_input()
        await content_input.click()
        await content_input.fill(content)
        await asyncio.sleep(1.0)

        await title_input.click()
        await asyncio.sleep(1.0)

        await self._input_tags(content_input, tags)
        await self._check_content_max_length()

        if schedule_time is not None:
            await self._set_schedule_publish(schedule_time)

        await self._set_visibility(visibility)

        if is_original:
            await self._set_original()

        if products:
            await self._bind_products(products)

        submit = self.page.locator(".publish-page-publish-btn button.bg-red").first
        if await submit.count() == 0:
            raise RuntimeError("查找发布按钮失败")
        await submit.click(timeout=8000)
        await asyncio.sleep(3.0)

    async def _get_content_input(self) -> Locator:
        # Wait for the Quill editor to appear (may take a moment after tab click)
        ql = self.page.locator("div.ql-editor").first
        try:
            await ql.wait_for(state="visible", timeout=10000)
            return ql
        except Exception:
            pass

        # Fallback: find the textbox role parent of the placeholder <p>,
        # matching the Go implementation's findTextboxParent strategy.
        textbox = self.page.locator("div[role='textbox']").first
        if await textbox.count() > 0:
            return textbox

        # Last resort
        for sel in ["p[data-placeholder*='输入正文描述']", "p.content-input"]:
            loc = self.page.locator(sel).first
            if await loc.count() > 0:
                return loc
        raise RuntimeError("没有找到内容输入框")

    async def _check_title_max_length(self) -> None:
        suffix = self.page.locator("div.title-container div.max_suffix").first
        if await suffix.count() == 0:
            return
        text = (await suffix.inner_text()).strip()
        if not _is_length_over_limit(text):
            return
        raise RuntimeError(_make_max_length_error(text))

    async def _check_content_max_length(self) -> None:
        suffix = self.page.locator("div.edit-container div.length-error").first
        if await suffix.count() == 0:
            return
        text = (await suffix.inner_text()).strip()
        if not _is_length_over_limit(text):
            return
        raise RuntimeError(_make_max_length_error(text))

    async def _input_tags(self, content_input: Locator, tags: list[str]) -> None:
        if not tags:
            return

        for tag in tags[:10]:
            clean = tag.strip().lstrip("#")
            if not clean:
                continue
            await self._input_single_tag(content_input, clean)

    async def _input_single_tag(self, content_input: Locator, tag: str) -> None:
        await content_input.type("#")
        await asyncio.sleep(0.2)
        await content_input.type(tag, delay=50)
        await asyncio.sleep(1.0)

        suggestion = self.page.locator("#creator-editor-topic-container .item").first
        if await suggestion.count() > 0:
            await suggestion.click()
            await asyncio.sleep(0.2)
            return

        await content_input.type(" ")
        await asyncio.sleep(0.5)

    async def _set_visibility(self, visibility: str) -> None:
        if visibility in {"", "公开可见"}:
            return
        if visibility not in {"仅自己可见", "仅互关好友可见"}:
            raise RuntimeError(f"不支持的可见范围: {visibility}，支持: 公开可见、仅自己可见、仅互关好友可见")

        dropdown = self.page.locator("div.permission-card-wrapper div.d-select-content").first
        if await dropdown.count() > 0:
            await dropdown.click(timeout=5000)
            await asyncio.sleep(0.5)

            options = self.page.locator("div.d-options-wrapper div.d-grid-item div.custom-option")
            option_count = await options.count()
            for idx in range(option_count):
                item = options.nth(idx)
                text = (await item.inner_text()).strip()
                if visibility in text:
                    await item.click(timeout=5000)
                    await asyncio.sleep(0.2)
                    return

        clicked = await self.page.evaluate(
            """(targetText) => {
                const all = Array.from(document.querySelectorAll('div,span,li,button'));
                for (const node of all) {
                    const text = (node.textContent || '').trim();
                    if (!text || !text.includes(targetText)) continue;
                    node.click();
                    return true;
                }
                return false;
            }""",
            visibility,
        )
        if not clicked:
            raise RuntimeError(f"未找到可见范围选项: {visibility}")
        await asyncio.sleep(0.3)

    async def _set_schedule_publish(self, schedule_time: datetime) -> None:
        switch = self.page.locator(".post-time-wrapper .d-switch").first
        if await switch.count() > 0:
            await switch.click(timeout=5000)
            await asyncio.sleep(0.8)

            date_input = self.page.locator(".date-picker-container input").first
            if await date_input.count() > 0:
                value = schedule_time.strftime("%Y-%m-%d %H:%M")
                await date_input.click()
                await date_input.fill(value)
                await asyncio.sleep(0.5)
                return

        toggled = await self.page.evaluate(
            """() => {
                const cards = Array.from(document.querySelectorAll('.custom-switch-card, div, label'));
                for (const card of cards) {
                    const text = (card.textContent || '').trim();
                    if (text.includes('定时发布')) {
                        const sw = card.querySelector('.d-switch, input[type="checkbox"], button');
                        if (sw) {
                            sw.click();
                            return true;
                        }
                        card.click();
                        return true;
                    }
                }
                return false;
            }"""
        )
        if not toggled:
            raise RuntimeError("设置定时发布失败: 未找到定时发布开关")

        date_text = schedule_time.strftime("%Y-%m-%d")
        time_text = schedule_time.strftime("%H:%M")
        filled = await self.page.evaluate(
            """(dateText, timeText) => {
                const inputs = Array.from(document.querySelectorAll('input'));
                let used = 0;
                for (const input of inputs) {
                    const placeholder = (input.getAttribute('placeholder') || '').toLowerCase();
                    if (placeholder.includes('日期') || placeholder.includes('yyyy') || placeholder.includes('年')) {
                        input.focus();
                        input.value = dateText;
                        input.dispatchEvent(new Event('input', { bubbles: true }));
                        input.dispatchEvent(new Event('change', { bubbles: true }));
                        used++;
                    } else if (placeholder.includes('时间') || placeholder.includes('hh') || placeholder.includes(':')) {
                        input.focus();
                        input.value = timeText;
                        input.dispatchEvent(new Event('input', { bubbles: true }));
                        input.dispatchEvent(new Event('change', { bubbles: true }));
                        used++;
                    }
                }
                return used > 0;
            }""",
            date_text,
            time_text,
        )
        if not filled:
            raise RuntimeError("设置定时发布失败: 未找到日期/时间输入框")

    async def _set_original(self) -> None:
        cards = self.page.locator("div.custom-switch-card")
        count = await cards.count()
        for idx in range(count):
            card = cards.nth(idx)
            text = (await card.inner_text()).strip()
            if "原创声明" not in text:
                continue

            switch = card.locator("div.d-switch").first
            if await switch.count() == 0:
                continue

            checked = bool(
                await switch.evaluate(
                    """(node) => {
                        const input = node.querySelector('input[type="checkbox"]');
                        return input ? input.checked : false;
                    }"""
                )
            )
            if checked:
                return

            await switch.click(timeout=5000)
            await asyncio.sleep(0.5)
            await self._confirm_original_declaration()
            return

        raise RuntimeError("未找到原创声明选项")

    async def _confirm_original_declaration(self) -> None:
        await asyncio.sleep(0.8)

        await self.page.evaluate(
            """() => {
                const footers = Array.from(document.querySelectorAll('div.footer'));
                for (const footer of footers) {
                    if (!footer.textContent.includes('原创声明须知')) continue;
                    const checkbox = footer.querySelector('div.d-checkbox input[type="checkbox"]');
                    if (checkbox && !checkbox.checked) {
                        checkbox.click();
                    }
                    return true;
                }
                return false;
            }"""
        )

        await asyncio.sleep(0.5)
        status = str(
            await self.page.evaluate(
                """() => {
                    const footers = Array.from(document.querySelectorAll('div.footer'));
                    for (const footer of footers) {
                        if (!footer.textContent.includes('声明原创')) continue;
                        const btn = footer.querySelector('button.custom-button');
                        if (!btn) return 'button_not_found';
                        if (btn.classList.contains('disabled') || btn.disabled) {
                            const checkbox = footer.querySelector('div.d-checkbox input[type="checkbox"]');
                            if (checkbox && !checkbox.checked) checkbox.click();
                            return 'button_disabled';
                        }
                        btn.click();
                        return 'clicked';
                    }
                    return 'button_not_found';
                }"""
            )
        )
        if status == "button_not_found":
            raise RuntimeError("未找到声明原创按钮")
        if status == "button_disabled":
            raise RuntimeError("声明原创按钮仍处于禁用状态")

    async def _bind_products(self, products: list[str]) -> None:
        if not products:
            return

        opened = await self._click_add_product_button()
        if not opened:
            raise RuntimeError("未找到添加商品按钮，账号可能未开通商品功能")
        await asyncio.sleep(1.0)

        modal = await self._wait_for_product_modal()
        failed_products: list[str] = []
        for keyword in products:
            kw = keyword.strip()
            if not kw:
                continue
            try:
                await self._search_and_select_product(modal, kw)
            except Exception:
                failed_products.append(kw)
            await asyncio.sleep(0.5)

        await self._click_modal_save_button(modal)
        await self._wait_modal_close()

        if failed_products:
            raise RuntimeError(f"部分商品未找到: {failed_products}")
        await asyncio.sleep(1.0)

    async def _click_add_product_button(self) -> bool:
        clicked = bool(
            await self.page.evaluate(
                """() => {
                    const spans = Array.from(document.querySelectorAll('span.d-text'));
                    for (const span of spans) {
                        const text = (span.textContent || '').trim();
                        if (text !== '添加商品') continue;
                        let parent = span;
                        for (let i = 0; i < 5; i++) {
                            parent = parent.parentElement;
                            if (!parent) break;
                            const tag = (parent.tagName || '').toLowerCase();
                            const cls = parent.className || '';
                            if (tag === 'button' || cls.includes('d-button')) {
                                parent.click();
                                return true;
                            }
                        }
                    }
                    return false;
                }"""
            )
        )
        if clicked:
            await asyncio.sleep(0.3)
            return True

        fallback = bool(
            await self.page.evaluate(
                """() => {
                    const candidates = Array.from(document.querySelectorAll('button, span, div'));
                    for (const node of candidates) {
                        const text = (node.textContent || '').trim();
                        if (!text) continue;
                        if (text.includes('添加商品') || text.includes('去选品') || text.includes('选择商品')) {
                            node.click();
                            return true;
                        }
                    }
                    return false;
                }"""
            )
        )
        if fallback:
            await asyncio.sleep(0.3)
        return fallback

    async def _wait_for_product_modal(self) -> Locator:
        modal = self.page.locator(".multi-goods-selector-modal").first
        deadline = asyncio.get_event_loop().time() + 10
        while asyncio.get_event_loop().time() < deadline:
            if await modal.count() > 0 and await modal.is_visible():
                return modal
            await asyncio.sleep(0.1)
        raise RuntimeError("等待商品选择弹窗超时")

    async def _search_and_select_product(self, modal: Locator, keyword: str) -> None:
        search_input = modal.locator('input[placeholder="搜索商品ID 或 商品名称"]').first
        if await search_input.count() == 0:
            search_input = modal.locator("input[placeholder*='搜索商品ID'], input[placeholder*='商品名称']").first
        if await search_input.count() == 0:
            raise RuntimeError("未找到商品搜索框")

        await search_input.click()
        await search_input.fill(keyword)
        await self.page.keyboard.press("Enter")
        await asyncio.sleep(1.0)

        loading = modal.locator(".goods-list-loading").first
        deadline = asyncio.get_event_loop().time() + 10
        while asyncio.get_event_loop().time() < deadline:
            if await loading.count() == 0:
                break
            if not await loading.is_visible():
                break
            await asyncio.sleep(0.1)

        cards = modal.locator(".goods-list-normal .good-card-container")
        deadline = asyncio.get_event_loop().time() + 10
        while asyncio.get_event_loop().time() < deadline:
            if await cards.count() > 0:
                break
            await asyncio.sleep(0.1)

        checkbox = modal.locator(".goods-list-normal .good-card-container .d-checkbox").first
        if await checkbox.count() == 0:
            raise RuntimeError("未找到商品选择框")

        checked = bool(
            await checkbox.evaluate(
                """(el) => {
                    return el.querySelector('.d-checkbox-simulator.checked') !== null
                        || el.querySelector('input[type="checkbox"]:checked') !== null;
                }"""
            )
        )
        if not checked:
            await checkbox.click(timeout=5000)

        await asyncio.sleep(random.uniform(0.8, 1.5))

    async def _click_modal_save_button(self, modal: Locator) -> None:
        save_btn = modal.locator(".goods-selected-footer button").first
        if await save_btn.count() > 0:
            await save_btn.click(timeout=5000)
            return

        primary_btn = modal.locator(".goods-selected-footer .d-button--primary").first
        if await primary_btn.count() > 0:
            await primary_btn.click(timeout=5000)

    async def _wait_modal_close(self) -> None:
        modal = self.page.locator(".multi-goods-selector-modal").first
        deadline = asyncio.get_event_loop().time() + 5
        while asyncio.get_event_loop().time() < deadline:
            if await modal.count() == 0:
                return
            if not await modal.is_visible():
                return
            await asyncio.sleep(0.2)


def _make_max_length_error(text: str) -> str:
    parts = [part.strip() for part in text.split("/", 1)]
    if len(parts) != 2:
        return f"长度超过限制: {text}"
    return f"当前输入长度为{parts[0]}，最大长度为{parts[1]}"


def _is_length_over_limit(text: str) -> bool:
    matched = re.search(r"(\d+)\s*/\s*(\d+)", text)
    if matched:
        current = int(matched.group(1))
        max_value = int(matched.group(2))
        return current > max_value

    return any(keyword in text for keyword in ("超出", "超过", "上限", "过长"))
