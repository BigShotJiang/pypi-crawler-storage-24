from __future__ import annotations

import asyncio

from playwright.async_api import Locator, Page

from .common import check_page_accessible, make_feed_detail_url, safe_wait_networkidle


class CommentFeedAction:
    def __init__(self, page: Page) -> None:
        self.page = page

    async def post_comment(self, feed_id: str, xsec_token: str, content: str) -> None:
        await self.page.goto(make_feed_detail_url(feed_id, xsec_token), wait_until="domcontentloaded")
        await safe_wait_networkidle(self.page)
        await asyncio.sleep(1.0)
        await check_page_accessible(self.page)

        await self.page.locator("div.input-box div.content-edit span").first.click(timeout=4000)
        input_node = self.page.locator("div.input-box div.content-edit p.content-input").first
        await input_node.fill(content)
        await asyncio.sleep(0.8)
        await self.page.locator("div.bottom button.submit").first.click(timeout=4000)
        await asyncio.sleep(1.0)

    async def reply_to_comment(
        self,
        feed_id: str,
        xsec_token: str,
        comment_id: str | None,
        user_id: str | None,
        content: str,
    ) -> None:
        await self.page.goto(make_feed_detail_url(feed_id, xsec_token), wait_until="domcontentloaded")
        await safe_wait_networkidle(self.page)
        await asyncio.sleep(1.0)
        await check_page_accessible(self.page)

        target = await self._find_comment_element(comment_id=comment_id, user_id=user_id)
        if target is None:
            raise RuntimeError(f"未找到评论 (comment_id={comment_id}, user_id={user_id})")

        await target.scroll_into_view_if_needed()
        await asyncio.sleep(0.6)
        await target.locator(".right .interactions .reply").first.click(timeout=3500)
        await asyncio.sleep(0.6)

        await self.page.locator("div.input-box div.content-edit p.content-input").first.fill(content)
        await asyncio.sleep(0.4)
        await self.page.locator("div.bottom button.submit").first.click(timeout=3500)
        await asyncio.sleep(1.5)

    async def _find_comment_element(self, comment_id: str | None, user_id: str | None) -> Locator | None:
        max_attempts = 100
        stagnant_checks = 0
        last_count = 0

        await self.page.evaluate("() => window.scrollBy(0, window.innerHeight * 0.8)")
        await asyncio.sleep(1.0)

        for _ in range(max_attempts):
            if await self._is_end_of_comments():
                return None

            count = await self._comment_count()
            if count == last_count:
                stagnant_checks += 1
            else:
                stagnant_checks = 0
                last_count = count
            if stagnant_checks >= 10:
                return None

            if comment_id:
                target = self.page.locator(f"#comment-{comment_id}").first
                if await target.count() > 0:
                    return target

            if user_id:
                user_target = self.page.locator(
                    f".comment-item:has([data-user-id='{user_id}']), "
                    f".parent-comment:has([data-user-id='{user_id}'])"
                ).first
                if await user_target.count() > 0:
                    return user_target

            await self.page.evaluate("() => window.scrollBy(0, window.innerHeight * 0.8)")
            await asyncio.sleep(0.8)

        return None

    async def _is_end_of_comments(self) -> bool:
        return bool(
            await self.page.evaluate(
                """() => {
                    const txt = document.body?.innerText || "";
                    return txt.includes("THE END") || txt.includes("已经到底了");
                }"""
            )
        )

    async def _comment_count(self) -> int:
        return int(
            await self.page.evaluate(
                "() => document.querySelectorAll('.parent-comment, .comment-item, .comment').length"
            )
        )

