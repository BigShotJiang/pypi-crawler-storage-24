from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from playwright.async_api import Page

from .common import make_feed_detail_url, safe_wait_networkidle


SELECTOR_LIKE_BUTTON = ".interact-container .left .like-lottie"
SELECTOR_COLLECT_BUTTON = ".interact-container .left .reds-icon.collect-icon"


@dataclass(slots=True)
class ActionResult:
    feed_id: str
    success: bool
    message: str


class _InteractAction:
    def __init__(self, page: Page) -> None:
        self.page = page

    async def prepare_page(self, feed_id: str, xsec_token: str) -> None:
        await self.page.goto(make_feed_detail_url(feed_id, xsec_token), wait_until="domcontentloaded")
        await safe_wait_networkidle(self.page)
        await asyncio.sleep(1.0)

    async def get_interact_state(self, feed_id: str) -> tuple[bool, bool]:
        payload = await self.page.evaluate(
            """() => {
                if (window.__INITIAL_STATE__ &&
                    window.__INITIAL_STATE__.note &&
                    window.__INITIAL_STATE__.note.noteDetailMap) {
                    return window.__INITIAL_STATE__.note.noteDetailMap;
                }
                return null;
            }"""
        )
        if not payload or not isinstance(payload, dict):
            raise RuntimeError("noteDetailMap not found")

        detail = payload.get(feed_id)
        if not isinstance(detail, dict):
            raise RuntimeError(f"feed {feed_id} not found in noteDetailMap")

        interact_info: dict[str, Any] = ((detail.get("note") or {}).get("interactInfo") or {})  # type: ignore[assignment]
        liked = bool(interact_info.get("liked"))
        collected = bool(interact_info.get("collected"))
        return liked, collected

    async def click(self, selector: str) -> None:
        await self.page.locator(selector).first.click(timeout=4000)


class LikeAction(_InteractAction):
    async def like(self, feed_id: str, xsec_token: str) -> ActionResult:
        return await self._perform(feed_id, xsec_token, target_liked=True)

    async def unlike(self, feed_id: str, xsec_token: str) -> ActionResult:
        return await self._perform(feed_id, xsec_token, target_liked=False)

    async def _perform(self, feed_id: str, xsec_token: str, target_liked: bool) -> ActionResult:
        action_text = "点赞" if target_liked else "取消点赞"
        await self.prepare_page(feed_id, xsec_token)

        try:
            liked, _ = await self.get_interact_state(feed_id)
        except Exception:
            liked = not target_liked

        if liked == target_liked:
            return ActionResult(feed_id=feed_id, success=True, message=f"{action_text}成功或状态已满足")

        await self.click(SELECTOR_LIKE_BUTTON)
        await asyncio.sleep(2.5)

        try:
            liked, _ = await self.get_interact_state(feed_id)
            if liked == target_liked:
                return ActionResult(feed_id=feed_id, success=True, message=f"{action_text}成功")
        except Exception:
            pass

        await self.click(SELECTOR_LIKE_BUTTON)
        await asyncio.sleep(1.5)
        return ActionResult(feed_id=feed_id, success=True, message=f"{action_text}已执行")


class FavoriteAction(_InteractAction):
    async def favorite(self, feed_id: str, xsec_token: str) -> ActionResult:
        return await self._perform(feed_id, xsec_token, target_collected=True)

    async def unfavorite(self, feed_id: str, xsec_token: str) -> ActionResult:
        return await self._perform(feed_id, xsec_token, target_collected=False)

    async def _perform(self, feed_id: str, xsec_token: str, target_collected: bool) -> ActionResult:
        action_text = "收藏" if target_collected else "取消收藏"
        await self.prepare_page(feed_id, xsec_token)

        try:
            _, collected = await self.get_interact_state(feed_id)
        except Exception:
            collected = not target_collected

        if collected == target_collected:
            return ActionResult(feed_id=feed_id, success=True, message=f"{action_text}成功或状态已满足")

        await self.click(SELECTOR_COLLECT_BUTTON)
        await asyncio.sleep(2.5)

        try:
            _, collected = await self.get_interact_state(feed_id)
            if collected == target_collected:
                return ActionResult(feed_id=feed_id, success=True, message=f"{action_text}成功")
        except Exception:
            pass

        await self.click(SELECTOR_COLLECT_BUTTON)
        await asyncio.sleep(1.5)
        return ActionResult(feed_id=feed_id, success=True, message=f"{action_text}已执行")
