from __future__ import annotations

import asyncio
from dataclasses import dataclass
import random
from typing import Any

from playwright.async_api import Page

from .common import check_page_accessible, make_feed_detail_url, sleep, wait_initial_state, safe_wait_networkidle


@dataclass(slots=True)
class CommentLoadConfig:
    click_more_replies: bool = False
    max_replies_threshold: int = 10
    max_comment_items: int = 0
    scroll_speed: str = "normal"


def default_comment_load_config() -> CommentLoadConfig:
    return CommentLoadConfig()


class FeedDetailAction:
    def __init__(self, page: Page) -> None:
        self.page = page

    async def get_feed_detail_with_config(
        self,
        feed_id: str,
        xsec_token: str,
        load_all_comments: bool,
        config: CommentLoadConfig,
    ) -> dict[str, Any]:
        await self.page.goto(make_feed_detail_url(feed_id, xsec_token), wait_until="domcontentloaded")
        await safe_wait_networkidle(self.page)
        await sleep(1.0)
        await check_page_accessible(self.page)
        await wait_initial_state(self.page)

        if load_all_comments:
            await self._load_all_comments(config)

        return await self._extract_feed_detail(feed_id)

    async def _load_all_comments(self, config: CommentLoadConfig) -> None:
        max_attempts = config.max_comment_items * 3 if config.max_comment_items > 0 else 500
        interval = _get_scroll_interval(config.scroll_speed)
        stagnant_checks = 0
        last_count = 0

        for idx in range(max_attempts):
            if await self._check_no_comments():
                return

            if await self._check_end_container():
                return

            if config.click_more_replies and idx % 3 == 0:
                await self._click_show_more_buttons(config.max_replies_threshold)

            current_count = await self._get_comment_count()
            if current_count == last_count:
                stagnant_checks += 1
            else:
                stagnant_checks = 0
                last_count = current_count

            if config.max_comment_items > 0 and current_count >= config.max_comment_items:
                return

            if stagnant_checks >= 20:
                return

            await self.page.evaluate("() => { window.scrollBy(0, window.innerHeight * 0.8); }")
            await asyncio.sleep(interval)

    async def _click_show_more_buttons(self, max_replies_threshold: int) -> None:
        buttons = self.page.locator("span.show-more, .show-more, .reply-more")
        count = await buttons.count()
        for i in range(min(count, 8)):
            btn = buttons.nth(i)
            text = (await btn.inner_text()).strip()
            if _should_skip_button(text, max_replies_threshold):
                continue
            try:
                await btn.click(timeout=1200)
                await asyncio.sleep(0.15)
            except Exception:
                continue

    async def _check_no_comments(self) -> bool:
        return bool(
            await self.page.evaluate(
                """() => {
                    const txt = document.body?.innerText || "";
                    return txt.includes("还没有评论")
                        || txt.includes("暂无评论")
                        || txt.includes("这是一片荒地");
                }"""
            )
        )

    async def _check_end_container(self) -> bool:
        return bool(
            await self.page.evaluate(
                """() => {
                    const txt = document.body?.innerText || "";
                    const upper = txt.toUpperCase();
                    return upper.includes("THE END")
                        || upper.includes("THEEND")
                        || txt.includes("已经到底了");
                }"""
            )
        )

    async def _get_comment_count(self) -> int:
        return int(
            await self.page.evaluate(
                """() => {
                    return document.querySelectorAll(".parent-comment, .comment-item, .comment").length;
                }"""
            )
        )

    async def _extract_feed_detail(self, feed_id: str) -> dict[str, Any]:
        note_detail_map = await self.page.evaluate(
            """() => {
                if (window.__INITIAL_STATE__ &&
                    window.__INITIAL_STATE__.note &&
                    window.__INITIAL_STATE__.note.noteDetailMap) {
                    return window.__INITIAL_STATE__.note.noteDetailMap;
                }
                return null;
            }"""
        )
        if not note_detail_map or not isinstance(note_detail_map, dict):
            raise RuntimeError("提取Feed详情失败: noteDetailMap为空")

        entry = note_detail_map.get(feed_id)
        if not isinstance(entry, dict):
            raise RuntimeError(f"feed {feed_id} not found in noteDetailMap")

        return {
            "note": entry.get("note"),
            "comments": entry.get("comments"),
        }


def _get_scroll_interval(speed: str) -> float:
    if speed == "slow":
        return random.uniform(1.2, 1.5)
    if speed == "fast":
        return random.uniform(0.3, 0.4)
    return random.uniform(0.6, 0.8)


def _should_skip_button(text: str, threshold: int) -> bool:
    if threshold <= 0:
        return False
    if not text:
        return False
    # Handles cases like "展开 12 条回复".
    digits = "".join(ch for ch in text if ch.isdigit())
    if not digits:
        return False
    try:
        return int(digits) > threshold
    except ValueError:
        return False
