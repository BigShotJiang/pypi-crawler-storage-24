from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from playwright.async_api import Page

from .common import make_search_url, wait_initial_state


@dataclass(slots=True)
class FilterOption:
    sort_by: str | None = None
    note_type: str | None = None
    publish_time: str | None = None
    search_scope: str | None = None
    location: str | None = None


_FILTER_OPTIONS_MAP: dict[int, list[tuple[int, str]]] = {
    1: [(1, "综合"), (2, "最新"), (3, "最多点赞"), (4, "最多评论"), (5, "最多收藏")],
    2: [(1, "不限"), (2, "视频"), (3, "图文")],
    3: [(1, "不限"), (2, "一天内"), (3, "一周内"), (4, "半年内")],
    4: [(1, "不限"), (2, "已看过"), (3, "未看过"), (4, "已关注")],
    5: [(1, "不限"), (2, "同城"), (3, "附近")],
}


def _find_internal_option(filters_index: int, text: str) -> tuple[int, int]:
    options = _FILTER_OPTIONS_MAP.get(filters_index)
    if not options:
        raise ValueError(f"筛选组 {filters_index} 不存在")
    for tags_index, label in options:
        if label == text:
            return filters_index, tags_index
    raise ValueError(f"在筛选组 {filters_index} 中未找到文本 '{text}'")


def _convert_to_internal_filters(filter_option: FilterOption) -> list[tuple[int, int]]:
    internal: list[tuple[int, int]] = []
    if filter_option.sort_by:
        try:
            internal.append(_find_internal_option(1, filter_option.sort_by))
        except ValueError as exc:
            raise ValueError(f"排序依据错误: {exc}") from exc
    if filter_option.note_type:
        try:
            internal.append(_find_internal_option(2, filter_option.note_type))
        except ValueError as exc:
            raise ValueError(f"笔记类型错误: {exc}") from exc
    if filter_option.publish_time:
        try:
            internal.append(_find_internal_option(3, filter_option.publish_time))
        except ValueError as exc:
            raise ValueError(f"发布时间错误: {exc}") from exc
    if filter_option.search_scope:
        try:
            internal.append(_find_internal_option(4, filter_option.search_scope))
        except ValueError as exc:
            raise ValueError(f"搜索范围错误: {exc}") from exc
    if filter_option.location:
        try:
            internal.append(_find_internal_option(5, filter_option.location))
        except ValueError as exc:
            raise ValueError(f"位置距离错误: {exc}") from exc
    return internal


class SearchAction:
    def __init__(self, page: Page) -> None:
        self.page = page

    async def search(self, keyword: str, filter_option: FilterOption | None = None) -> list[dict[str, Any]]:
        await self.page.goto(make_search_url(keyword), wait_until="domcontentloaded")
        await wait_initial_state(self.page)

        if filter_option is not None:
            internal_filters = _convert_to_internal_filters(filter_option)
            if internal_filters:
                await self._apply_filters(internal_filters)

        payload = await self.page.evaluate(
            """() => {
                if (window.__INITIAL_STATE__ &&
                    window.__INITIAL_STATE__.search &&
                    window.__INITIAL_STATE__.search.feeds) {
                    const feeds = window.__INITIAL_STATE__.search.feeds;
                    const feedsData = feeds.value !== undefined ? feeds.value : feeds._value;
                    return feedsData || null;
                }
                return null;
            }"""
        )
        if not payload:
            raise RuntimeError("no feeds found in search result")
        if not isinstance(payload, list):
            raise RuntimeError("invalid search feeds payload type")
        return payload

    async def _apply_filters(self, internal_filters: list[tuple[int, int]]) -> None:
        filter_button = self.page.locator("div.filter").first
        await filter_button.hover()
        await self.page.wait_for_selector("div.filter-panel", timeout=6000)

        for filters_index, tags_index in internal_filters:
            selector = (
                f"div.filter-panel div.filters:nth-child({filters_index}) "
                f"div.tags:nth-child({tags_index})"
            )
            await self.page.locator(selector).first.click()

        await self.page.wait_for_timeout(800)
        await wait_initial_state(self.page)
