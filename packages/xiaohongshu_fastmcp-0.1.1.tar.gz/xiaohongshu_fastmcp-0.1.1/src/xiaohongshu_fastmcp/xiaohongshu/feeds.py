from __future__ import annotations

import asyncio
from typing import Any

from playwright.async_api import Page

from .common import URL_HOME, wait_initial_state


class FeedsListAction:
    def __init__(self, page: Page) -> None:
        self.page = page

    async def get_feeds_list(self) -> list[dict[str, Any]]:
        await self.page.goto(URL_HOME, wait_until="domcontentloaded")
        await wait_initial_state(self.page)
        await asyncio.sleep(1.0)

        payload = await self.page.evaluate(
            """() => {
                if (window.__INITIAL_STATE__ &&
                    window.__INITIAL_STATE__.feed &&
                    window.__INITIAL_STATE__.feed.feeds) {
                    const feeds = window.__INITIAL_STATE__.feed.feeds;
                    const feedsData = feeds.value !== undefined ? feeds.value : feeds._value;
                    return feedsData || null;
                }
                return null;
            }"""
        )
        if not payload:
            raise RuntimeError("no feeds found in __INITIAL_STATE__")
        if not isinstance(payload, list):
            raise RuntimeError("invalid feeds payload type")
        return payload

