from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from dataclasses import replace

import uvicorn

from .app import create_http_app
from .configs import RuntimeConfig
from .mcp_registry import create_mcp_server


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="xiaohongshu FastMCP server")
    parser.add_argument(
        "--transport",
        choices=["http", "stdio"],
        default="http",
        help="MCP transport mode: http (default) or stdio",
    )
    parser.add_argument("--host", default=None, help="HTTP host, default from env or 0.0.0.0")
    parser.add_argument("--port", type=int, default=None, help="HTTP port, default from env or 18060")
    parser.add_argument("--bin", dest="browser_bin_path", default=None, help="Browser executable path")
    parser.add_argument("--headless", action="store_true", help="Run browser in headless mode")
    parser.add_argument("--no-headless", action="store_true", help="Run browser in headed mode")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    return parser


def resolve_config(args: argparse.Namespace) -> RuntimeConfig:
    config = RuntimeConfig.from_env()

    if args.host:
        config = replace(config, host=args.host)
    if args.port:
        config = replace(config, port=args.port)
    if args.browser_bin_path:
        config = replace(config, browser_bin_path=args.browser_bin_path)
    if args.headless:
        config = replace(config, headless=True)
    if args.no_headless:
        config = replace(config, headless=False)
    if args.debug:
        config = replace(config, debug=True)

    return config


def configure_runtime() -> None:
    # On Windows, selector loop is more tolerant to short-lived HTTP disconnects
    # from MCP clients (avoids noisy Proactor connection-reset callbacks).
    if sys.platform != "win32":
        return

    policy_cls = getattr(asyncio, "WindowsSelectorEventLoopPolicy", None)
    if policy_cls is None:
        return
    asyncio.set_event_loop_policy(policy_cls())


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()
    config = resolve_config(args)
    configure_runtime()

    logging.basicConfig(
        level=logging.DEBUG if config.debug else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    if args.transport == "stdio":
        mcp = create_mcp_server(config)
        mcp.run(
            transport="stdio",
            log_level="debug" if config.debug else "info",
        )
        return

    app = create_http_app(config)
    uvicorn.run(
        app,
        host=config.host,
        port=config.port,
        log_level="debug" if config.debug else "info",
    )


if __name__ == "__main__":
    main()
