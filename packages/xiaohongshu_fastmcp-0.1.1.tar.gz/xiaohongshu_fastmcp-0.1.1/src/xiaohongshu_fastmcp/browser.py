from __future__ import annotations

import contextlib
from dataclasses import dataclass
from typing import Any, AsyncIterator
from urllib.parse import urlparse, urlunparse

from playwright.async_api import Browser, BrowserContext, Page, Playwright, async_playwright

from .configs import RuntimeConfig
from .cookies import load_cookies

_DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

_STEALTH_INIT_SCRIPT = """
Object.defineProperty(navigator, "webdriver", { get: () => undefined });
window.chrome = window.chrome || { runtime: {} };
"""


def mask_proxy_credentials(proxy_url: str) -> str:
    parsed = urlparse(proxy_url)
    if not parsed.username:
        return proxy_url
    host = parsed.hostname or ""
    if parsed.port:
        host = f"{host}:{parsed.port}"
    netloc = "***:***@" + host
    return urlunparse((parsed.scheme, netloc, parsed.path, parsed.params, parsed.query, parsed.fragment))


def _build_proxy(proxy_url: str | None) -> dict[str, Any] | None:
    if not proxy_url:
        return None
    parsed = urlparse(proxy_url)
    if not parsed.scheme or not parsed.hostname:
        return {"server": proxy_url}

    server = f"{parsed.scheme}://{parsed.hostname}"
    if parsed.port:
        server = f"{server}:{parsed.port}"
    proxy: dict[str, Any] = {"server": server}
    if parsed.username:
        proxy["username"] = parsed.username
    if parsed.password:
        proxy["password"] = parsed.password
    return proxy


@dataclass(slots=True)
class BrowserBundle:
    playwright: Playwright
    browser: Browser
    context: BrowserContext
    page: Page

    async def close(self) -> None:
        with contextlib.suppress(Exception):
            await self.page.close()
        with contextlib.suppress(Exception):
            await self.context.close()
        with contextlib.suppress(Exception):
            await self.browser.close()
        with contextlib.suppress(Exception):
            await self.playwright.stop()


class BrowserManager:
    def __init__(self, config: RuntimeConfig) -> None:
        self.config = config

    async def open_page(self) -> BrowserBundle:
        playwright = await async_playwright().start()

        launch_kwargs: dict[str, Any] = {
            "headless": self.config.headless,
            "args": [
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
            ],
        }
        if self.config.browser_bin_path:
            launch_kwargs["executable_path"] = self.config.browser_bin_path

        proxy = _build_proxy(self.config.proxy)
        if proxy is not None:
            launch_kwargs["proxy"] = proxy

        browser = await playwright.chromium.launch(**launch_kwargs)
        context = await browser.new_context(
            user_agent=_DEFAULT_USER_AGENT,
            locale="zh-CN",
            timezone_id="Asia/Shanghai",
            viewport={"width": 1440, "height": 900},
        )
        await context.add_init_script(_STEALTH_INIT_SCRIPT)

        cookies = load_cookies(self.config.cookies_path)
        if cookies:
            try:
                await context.add_cookies(cookies)
            except Exception:
                # Keep server running even if existing cookies are stale/incompatible.
                pass

        page = await context.new_page()
        return BrowserBundle(
            playwright=playwright,
            browser=browser,
            context=context,
            page=page,
        )

    @contextlib.asynccontextmanager
    async def new_page(self) -> AsyncIterator[BrowserBundle]:
        bundle = await self.open_page()
        try:
            yield bundle
        finally:
            await bundle.close()
