from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_cookies(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []

    raw = path.read_text(encoding="utf-8")
    if not raw.strip():
        return []

    payload = json.loads(raw)
    if not isinstance(payload, list):
        return []

    normalized: list[dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        cookie = _normalize_cookie(item)
        if cookie is not None:
            normalized.append(cookie)
    return normalized


def save_cookies(path: Path, cookies: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(cookies, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def delete_cookies(path: Path) -> None:
    if path.exists():
        path.unlink()


def _normalize_cookie(raw: dict[str, Any]) -> dict[str, Any] | None:
    # Accept both Go/Rod style and Playwright style keys.
    name = raw.get("name") or raw.get("Name")
    value = raw.get("value") or raw.get("Value")
    domain = raw.get("domain") or raw.get("Domain")
    path = raw.get("path") or raw.get("Path") or "/"

    if not (name and value and domain):
        return None

    cookie: dict[str, Any] = {
        "name": str(name),
        "value": str(value),
        "domain": str(domain),
        "path": str(path),
    }

    expires = raw.get("expires")
    if expires is None:
        expires = raw.get("Expires")
    if expires is not None:
        try:
            cookie["expires"] = float(expires)
        except (TypeError, ValueError):
            pass

    http_only = raw.get("httpOnly")
    if http_only is None:
        http_only = raw.get("HTTPOnly")
    if isinstance(http_only, bool):
        cookie["httpOnly"] = http_only

    secure = raw.get("secure")
    if secure is None:
        secure = raw.get("Secure")
    if isinstance(secure, bool):
        cookie["secure"] = secure

    same_site = raw.get("sameSite") or raw.get("SameSite")
    if isinstance(same_site, str) and same_site:
        cookie["sameSite"] = same_site

    return cookie

