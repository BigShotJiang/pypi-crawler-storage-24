from __future__ import annotations

from pydantic import BaseModel, Field


class FilterOption(BaseModel):
    sort_by: str | None = Field(default=None, description="排序依据")
    note_type: str | None = Field(default=None, description="笔记类型")
    publish_time: str | None = Field(default=None, description="发布时间")
    search_scope: str | None = Field(default=None, description="搜索范围")
    location: str | None = Field(default=None, description="位置距离")


class PublishContentArgs(BaseModel):
    title: str = Field(description="内容标题（小红书限制：最多20个中文字或英文单词）")
    content: str = Field(description="正文内容")
    images: list[str] = Field(description="图片路径列表（至少需要1张图片）")
    tags: list[str] = Field(default_factory=list, description="话题标签列表")
    schedule_at: str | None = Field(default=None, description="定时发布时间（ISO8601）")
    is_original: bool = Field(default=False, description="是否声明原创")
    visibility: str | None = Field(default=None, description="可见范围")
    products: list[str] = Field(default_factory=list, description="商品关键词列表")


class PublishVideoArgs(BaseModel):
    title: str = Field(description="内容标题（小红书限制：最多20个中文字或英文单词）")
    content: str = Field(description="正文内容")
    video: str = Field(description="本地视频绝对路径")
    tags: list[str] = Field(default_factory=list, description="话题标签列表")
    schedule_at: str | None = Field(default=None, description="定时发布时间（ISO8601）")
    visibility: str | None = Field(default=None, description="可见范围")
    products: list[str] = Field(default_factory=list, description="商品关键词列表")


class SearchFeedsArgs(BaseModel):
    keyword: str = Field(description="搜索关键词")
    filters: FilterOption | None = Field(default=None, description="筛选选项")


class FeedDetailArgs(BaseModel):
    feed_id: str = Field(description="小红书笔记ID")
    xsec_token: str = Field(description="访问令牌")
    load_all_comments: bool = Field(default=False, description="是否加载全部评论")
    limit: int | None = Field(default=None, description="评论数量上限")
    click_more_replies: bool = Field(default=False, description="是否展开二级回复")
    reply_limit: int | None = Field(default=None, description="回复阈值")
    scroll_speed: str | None = Field(default=None, description="滚动速度")


class UserProfileArgs(BaseModel):
    user_id: str = Field(description="小红书用户ID")
    xsec_token: str = Field(description="访问令牌")


class PostCommentArgs(BaseModel):
    feed_id: str = Field(description="小红书笔记ID")
    xsec_token: str = Field(description="访问令牌")
    content: str = Field(description="评论内容")


class ReplyCommentArgs(BaseModel):
    feed_id: str = Field(description="小红书笔记ID")
    xsec_token: str = Field(description="访问令牌")
    comment_id: str | None = Field(default=None, description="目标评论ID")
    user_id: str | None = Field(default=None, description="目标评论用户ID")
    content: str = Field(description="回复内容")


class LikeFeedArgs(BaseModel):
    feed_id: str = Field(description="小红书笔记ID")
    xsec_token: str = Field(description="访问令牌")
    unlike: bool = Field(default=False, description="是否取消点赞")


class FavoriteFeedArgs(BaseModel):
    feed_id: str = Field(description="小红书笔记ID")
    xsec_token: str = Field(description="访问令牌")
    unfavorite: bool = Field(default=False, description="是否取消收藏")


class CommentLoadConfigModel(BaseModel):
    click_more_replies: bool = Field(default=False)
    max_replies_threshold: int = Field(default=10)
    max_comment_items: int = Field(default=0)
    scroll_speed: str = Field(default="normal")


class FeedDetailRequest(BaseModel):
    feed_id: str
    xsec_token: str
    load_all_comments: bool = False
    comment_config: CommentLoadConfigModel | None = None


class SearchFeedsRequest(BaseModel):
    keyword: str
    filters: FilterOption | None = None
