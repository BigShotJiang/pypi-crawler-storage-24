from __future__ import annotations

from typing import Any

from fastmcp import FastMCP

from .configs import RuntimeConfig
from .mcp_handlers import MCPHandlers
from .models import FilterOption
from .service import XiaohongshuService


def _ann(
    *,
    title: str,
    read_only: bool | None = None,
    destructive: bool | None = None,
) -> dict[str, object]:
    payload: dict[str, object] = {"title": title}
    if read_only is not None:
        payload["readOnlyHint"] = read_only
    if destructive is not None:
        payload["destructiveHint"] = destructive
    return payload


def create_mcp_server(config: RuntimeConfig, service: XiaohongshuService | None = None) -> FastMCP:
    mcp = FastMCP(
        name="xiaohongshu-mcp",
        version="2.0.0",
        mask_error_details=False,
    )

    if service is None:
        service = XiaohongshuService(config)
    handlers = MCPHandlers(service, config)

    @mcp.tool(
        name="check_login_status",
        description="检查小红书登录状态",
        annotations=_ann(title="Check Login Status", read_only=True),
    )
    async def check_login_status() -> Any:
        return await handlers.handle_check_login_status()

    @mcp.tool(
        name="get_login_qrcode",
        description="获取登录二维码（返回 Base64 图片和超时时间）",
        annotations=_ann(title="Get Login QR Code", read_only=True),
    )
    async def get_login_qrcode() -> Any:
        return await handlers.handle_get_login_qrcode()

    @mcp.tool(
        name="delete_cookies",
        description="删除 cookies 文件，重置登录状态。删除后需要重新登录。",
        annotations=_ann(title="Delete Cookies", destructive=True),
    )
    async def delete_cookies() -> Any:
        return await handlers.handle_delete_cookies()

    @mcp.tool(
        name="publish_content",
        description="发布小红书图文内容",
        annotations=_ann(title="Publish Content", destructive=True),
    )
    async def publish_content(
        title: str,
        content: str,
        images: list[str],
        tags: list[str] | None = None,
        schedule_at: str | None = None,
        is_original: bool = False,
        visibility: str | None = None,
        products: list[str] | None = None,
    ) -> Any:
        return await handlers.handle_publish_content(
            title=title,
            content=content,
            images=images,
            tags=tags,
            schedule_at=schedule_at,
            is_original=is_original,
            visibility=visibility,
            products=products,
        )

    @mcp.tool(
        name="list_feeds",
        description="获取首页 Feeds 列表",
        annotations=_ann(title="List Feeds", read_only=True),
    )
    async def list_feeds() -> Any:
        return await handlers.handle_list_feeds()

    @mcp.tool(
        name="search_feeds",
        description="搜索小红书内容（需要已登录）",
        annotations=_ann(title="Search Feeds", read_only=True),
    )
    async def search_feeds(keyword: str, filters: FilterOption | None = None) -> Any:
        return await handlers.handle_search_feeds(keyword=keyword, filters=filters)

    @mcp.tool(
        name="get_feed_detail",
        description=(
            "获取小红书笔记详情，返回笔记内容、图片、作者信息、互动数据及评论列表。"
            "默认返回前10条一级评论，如需更多评论请设置load_all_comments=true"
        ),
        annotations=_ann(title="Get Feed Detail", read_only=True),
    )
    async def get_feed_detail(
        feed_id: str,
        xsec_token: str,
        load_all_comments: bool | str | int | None = False,
        limit: int | str | float | None = None,
        click_more_replies: bool | str | int | None = False,
        reply_limit: int | str | float | None = None,
        scroll_speed: str | None = None,
    ) -> Any:
        return await handlers.handle_get_feed_detail(
            feed_id=feed_id,
            xsec_token=xsec_token,
            load_all_comments=load_all_comments,
            limit=limit,
            click_more_replies=click_more_replies,
            reply_limit=reply_limit,
            scroll_speed=scroll_speed,
        )

    @mcp.tool(
        name="user_profile",
        description="获取指定的小红书用户主页，返回用户基本信息与其笔记内容",
        annotations=_ann(title="User Profile", read_only=True),
    )
    async def user_profile(user_id: str, xsec_token: str) -> Any:
        return await handlers.handle_user_profile(user_id=user_id, xsec_token=xsec_token)

    @mcp.tool(
        name="post_comment_to_feed",
        description="发表评论到小红书笔记",
        annotations=_ann(title="Post Comment", destructive=True),
    )
    async def post_comment_to_feed(feed_id: str, xsec_token: str, content: str) -> Any:
        return await handlers.handle_post_comment_to_feed(
            feed_id=feed_id,
            xsec_token=xsec_token,
            content=content,
        )

    @mcp.tool(
        name="reply_comment_in_feed",
        description="回复小红书笔记下的指定评论",
        annotations=_ann(title="Reply Comment", destructive=True),
    )
    async def reply_comment_in_feed(
        feed_id: str,
        xsec_token: str,
        content: str,
        comment_id: str | None = None,
        user_id: str | None = None,
    ) -> Any:
        return await handlers.handle_reply_comment_in_feed(
            feed_id=feed_id,
            xsec_token=xsec_token,
            content=content,
            comment_id=comment_id,
            user_id=user_id,
        )

    @mcp.tool(
        name="publish_with_video",
        description="发布小红书视频内容（仅支持本地单个视频文件）",
        annotations=_ann(title="Publish Video", destructive=True),
    )
    async def publish_with_video(
        title: str,
        content: str,
        video: str,
        tags: list[str] | None = None,
        schedule_at: str | None = None,
        visibility: str | None = None,
        products: list[str] | None = None,
    ) -> Any:
        return await handlers.handle_publish_video(
            title=title,
            content=content,
            video=video,
            tags=tags,
            schedule_at=schedule_at,
            visibility=visibility,
            products=products,
        )

    @mcp.tool(
        name="like_feed",
        description="为指定笔记点赞或取消点赞（如已点赞将跳过点赞，如未点赞将跳过取消点赞）",
        annotations=_ann(title="Like Feed", destructive=True),
    )
    async def like_feed(feed_id: str, xsec_token: str, unlike: bool = False) -> Any:
        return await handlers.handle_like_feed(feed_id=feed_id, xsec_token=xsec_token, unlike=unlike)

    @mcp.tool(
        name="favorite_feed",
        description="收藏指定笔记或取消收藏（如已收藏将跳过收藏，如未收藏将跳过取消收藏）",
        annotations=_ann(title="Favorite Feed", destructive=True),
    )
    async def favorite_feed(feed_id: str, xsec_token: str, unfavorite: bool = False) -> Any:
        return await handlers.handle_favorite_feed(
            feed_id=feed_id,
            xsec_token=xsec_token,
            unfavorite=unfavorite,
        )

    return mcp
