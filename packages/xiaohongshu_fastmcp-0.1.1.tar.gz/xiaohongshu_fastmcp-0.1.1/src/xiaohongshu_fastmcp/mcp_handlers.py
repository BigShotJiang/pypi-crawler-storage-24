from __future__ import annotations

import json
from datetime import datetime, timedelta
from typing import Any

from fastmcp.exceptions import ToolError
from fastmcp.tools.tool import ToolResult
from mcp.types import ImageContent, TextContent

from .configs import RuntimeConfig
from .models import FilterOption
from .service import XiaohongshuService
from .xiaohongshu import default_comment_load_config

ToolOutput = str | ToolResult


class MCPHandlers:
    def __init__(self, service: XiaohongshuService, config: RuntimeConfig) -> None:
        self.service = service
        self.config = config

    async def handle_check_login_status(self) -> ToolOutput:
        try:
            status = await self.service.check_login_status()
        except Exception as exc:
            _fail(f"检查登录状态失败: {exc}")

        if status.get("is_logged_in"):
            return f"✅ 已登录\n用户名: {status.get('username', '')}\n\n你可以使用其他功能了。"
        return "❌ 未登录\n\n请使用 get_login_qrcode 工具获取二维码进行登录。"

    async def handle_get_login_qrcode(self) -> ToolOutput:
        try:
            result = await self.service.get_login_qrcode()
        except Exception as exc:
            _fail(f"获取登录扫码图片失败: {exc}")

        if result.get("is_logged_in"):
            return "你当前已处于登录状态"

        timeout_text = str(result.get("timeout", "4m0s"))
        deadline = _deadline_from_duration(timeout_text)
        image_src = str(result.get("img", ""))
        data = image_src.removeprefix("data:image/png;base64,")

        return ToolResult(
            content=[
                TextContent(type="text", text=f"请用小红书 App 在 {deadline} 前扫码登录 👇"),
                ImageContent(type="image", mimeType="image/png", data=data),
            ]
        )

    async def handle_delete_cookies(self) -> ToolOutput:
        try:
            await self.service.delete_cookies()
        except Exception as exc:
            _fail(f"删除 cookies 失败: {exc}")

        return (
            "Cookies 已成功删除，登录状态已重置。\n\n"
            f"删除的文件路径: {self.config.cookies_path}\n\n"
            "下次操作时，需要重新登录。"
        )

    async def handle_publish_content(
        self,
        *,
        title: str,
        content: str,
        images: list[str],
        tags: list[str] | None,
        schedule_at: str | None,
        is_original: bool,
        visibility: str | None,
        products: list[str] | None,
    ) -> ToolOutput:
        try:
            result = await self.service.publish_content(
                title=title,
                content=content,
                images=images,
                tags=tags or [],
                schedule_at=schedule_at,
                is_original=is_original,
                visibility=visibility,
                products=products or [],
            )
        except Exception as exc:
            _fail(f"发布失败: {exc}")
        return f"内容发布成功: {_pretty_json(result)}"

    async def handle_publish_video(
        self,
        *,
        title: str,
        content: str,
        video: str,
        tags: list[str] | None,
        schedule_at: str | None,
        visibility: str | None,
        products: list[str] | None,
    ) -> ToolOutput:
        try:
            result = await self.service.publish_video(
                title=title,
                content=content,
                video=video,
                tags=tags or [],
                schedule_at=schedule_at,
                visibility=visibility,
                products=products or [],
            )
        except Exception as exc:
            _fail(f"发布失败: {exc}")
        return f"视频发布成功: {_pretty_json(result)}"

    async def handle_list_feeds(self) -> ToolOutput:
        try:
            result = await self.service.list_feeds()
        except Exception as exc:
            _fail(f"获取Feeds列表失败: {exc}")
        return _pretty_json(result)

    async def handle_search_feeds(
        self,
        *,
        keyword: str,
        filters: FilterOption | dict[str, Any] | None,
    ) -> ToolOutput:
        if not keyword:
            _fail("搜索Feeds失败: 缺少关键词参数")

        parsed_filter: FilterOption | None = None
        if isinstance(filters, FilterOption):
            parsed_filter = filters
        elif isinstance(filters, dict):
            parsed_filter = FilterOption.model_validate(filters)

        try:
            result = await self.service.search_feeds(keyword=keyword, filters=parsed_filter)
        except Exception as exc:
            _fail(f"搜索Feeds失败: {exc}")
        return _pretty_json(result)

    async def handle_get_feed_detail(
        self,
        *,
        feed_id: str,
        xsec_token: str,
        load_all_comments: bool | str | int | None = False,
        limit: int | str | float | None = None,
        click_more_replies: bool | str | int | None = False,
        reply_limit: int | str | float | None = None,
        scroll_speed: str | None = None,
    ) -> ToolOutput:
        if not feed_id:
            _fail("获取Feed详情失败: 缺少feed_id参数")
        if not xsec_token:
            _fail("获取Feed详情失败: 缺少xsec_token参数")

        config = default_comment_load_config()
        parsed_load_all_comments = _parse_bool(load_all_comments)
        if parsed_load_all_comments:
            config.click_more_replies = _parse_bool(click_more_replies)

            parsed_limit = _parse_int(limit)
            if parsed_limit is None or parsed_limit <= 0:
                parsed_limit = 20
            config.max_comment_items = parsed_limit

            parsed_reply_limit = _parse_int(reply_limit)
            if parsed_reply_limit is None or parsed_reply_limit <= 0:
                parsed_reply_limit = 10
            config.max_replies_threshold = parsed_reply_limit

            if scroll_speed:
                config.scroll_speed = scroll_speed

        try:
            result = await self.service.get_feed_detail_with_config(
                feed_id=feed_id,
                xsec_token=xsec_token,
                load_all_comments=parsed_load_all_comments,
                config=config,
            )
        except Exception as exc:
            _fail(f"获取Feed详情失败: {exc}")
        return _pretty_json(result)

    async def handle_user_profile(self, *, user_id: str, xsec_token: str) -> ToolOutput:
        if not user_id:
            _fail("获取用户主页失败: 缺少user_id参数")
        if not xsec_token:
            _fail("获取用户主页失败: 缺少xsec_token参数")
        try:
            result = await self.service.user_profile(user_id=user_id, xsec_token=xsec_token)
        except Exception as exc:
            _fail(f"获取用户主页失败: {exc}")
        return _pretty_json(result)

    async def handle_like_feed(self, *, feed_id: str, xsec_token: str, unlike: bool = False) -> ToolOutput:
        if not feed_id:
            _fail("操作失败: 缺少feed_id参数")
        if not xsec_token:
            _fail("操作失败: 缺少xsec_token参数")

        action = "取消点赞" if unlike else "点赞"
        try:
            if unlike:
                res = await self.service.unlike_feed(feed_id=feed_id, xsec_token=xsec_token)
            else:
                res = await self.service.like_feed(feed_id=feed_id, xsec_token=xsec_token)
        except Exception as exc:
            _fail(f"{action}失败: {exc}")
        return f"{action}成功 - Feed ID: {res.get('feed_id')}"

    async def handle_favorite_feed(
        self,
        *,
        feed_id: str,
        xsec_token: str,
        unfavorite: bool = False,
    ) -> ToolOutput:
        if not feed_id:
            _fail("操作失败: 缺少feed_id参数")
        if not xsec_token:
            _fail("操作失败: 缺少xsec_token参数")

        action = "取消收藏" if unfavorite else "收藏"
        try:
            if unfavorite:
                res = await self.service.unfavorite_feed(feed_id=feed_id, xsec_token=xsec_token)
            else:
                res = await self.service.favorite_feed(feed_id=feed_id, xsec_token=xsec_token)
        except Exception as exc:
            _fail(f"{action}失败: {exc}")
        return f"{action}成功 - Feed ID: {res.get('feed_id')}"

    async def handle_post_comment_to_feed(
        self,
        *,
        feed_id: str,
        xsec_token: str,
        content: str,
    ) -> ToolOutput:
        if not feed_id:
            _fail("发表评论失败: 缺少feed_id参数")
        if not xsec_token:
            _fail("发表评论失败: 缺少xsec_token参数")
        if not content:
            _fail("发表评论失败: 缺少content参数")
        try:
            res = await self.service.post_comment_to_feed(
                feed_id=feed_id,
                xsec_token=xsec_token,
                content=content,
            )
        except Exception as exc:
            _fail(f"发表评论失败: {exc}")
        return f"评论发表成功 - Feed ID: {res.get('feed_id')}"

    async def handle_reply_comment_in_feed(
        self,
        *,
        feed_id: str,
        xsec_token: str,
        content: str,
        comment_id: str | None = None,
        user_id: str | None = None,
    ) -> ToolOutput:
        if not feed_id:
            _fail("回复评论失败: 缺少feed_id参数")
        if not xsec_token:
            _fail("回复评论失败: 缺少xsec_token参数")
        if not comment_id and not user_id:
            _fail("回复评论失败: 缺少comment_id或user_id参数")
        if not content:
            _fail("回复评论失败: 缺少content参数")
        try:
            res = await self.service.reply_comment_to_feed(
                feed_id=feed_id,
                xsec_token=xsec_token,
                comment_id=comment_id,
                user_id=user_id,
                content=content,
            )
        except Exception as exc:
            _fail(f"回复评论失败: {exc}")
        return (
            "评论回复成功 - Feed ID: "
            f"{res.get('feed_id')}, Comment ID: {res.get('target_comment_id')}, User ID: {res.get('target_user_id')}"
        )


def _pretty_json(payload: Any) -> str:
    return json.dumps(payload, ensure_ascii=False, indent=2)


def _fail(message: str) -> None:
    raise ToolError(message)


def _parse_bool(value: bool | str | int | None) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value != 0
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "t", "true", "yes", "y", "on"}:
            return True
        if normalized in {"0", "f", "false", "no", "n", "off"}:
            return False
    return False


def _parse_int(value: int | str | float | None) -> int | None:
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        try:
            return int(value.strip())
        except ValueError:
            return None
    return None


def _deadline_from_duration(duration_text: str) -> str:
    total_seconds = 0
    token = ""
    for ch in duration_text.strip():
        if ch.isdigit():
            token += ch
            continue
        if not token:
            continue
        num = int(token)
        token = ""
        if ch == "h":
            total_seconds += num * 3600
        elif ch == "m":
            total_seconds += num * 60
        elif ch == "s":
            total_seconds += num
    if token:
        total_seconds += int(token)
    if total_seconds <= 0:
        total_seconds = 240
    return (datetime.now() + timedelta(seconds=total_seconds)).strftime("%Y-%m-%d %H:%M:%S")
