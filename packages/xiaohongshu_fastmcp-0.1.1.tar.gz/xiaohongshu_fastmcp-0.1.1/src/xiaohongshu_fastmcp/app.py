from __future__ import annotations

from datetime import datetime
from typing import Any

from fastapi import FastAPI, Query
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .configs import RuntimeConfig
from .mcp_registry import create_mcp_server
from .models import FeedDetailRequest, PostCommentArgs, PublishContentArgs, PublishVideoArgs, ReplyCommentArgs, SearchFeedsRequest, UserProfileArgs
from .service import XiaohongshuService
from .xiaohongshu import CommentLoadConfig, default_comment_load_config


def _success(data: Any, message: str) -> dict[str, Any]:
    return {
        "success": True,
        "data": data,
        "message": message,
    }


def _error(code: str, message: str, details: Any) -> dict[str, Any]:
    return {
        "error": message,
        "code": code,
        "details": details,
    }


def create_http_app(config: RuntimeConfig) -> FastAPI:
    service = XiaohongshuService(config)
    mcp = create_mcp_server(config, service=service)
    mcp_app = mcp.http_app(path="/mcp")

    app = FastAPI(title="xiaohongshu-fastmcp", version="0.1.0", lifespan=mcp_app.lifespan)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.exception_handler(RequestValidationError)
    async def _request_validation_error(_request, exc: RequestValidationError):  # type: ignore[no-untyped-def]
        return JSONResponse(
            status_code=400,
            content=_error("INVALID_REQUEST", "请求参数错误", exc.errors()),
        )

    @app.get("/health")
    async def health() -> dict[str, Any]:
        return _success(
            {
                "status": "healthy",
                "service": "xiaohongshu-mcp",
                "account": "ai-report",
                "timestamp": datetime.now().isoformat(),
            },
            "服务正常",
        )

    @app.get("/api/v1/login/status")
    async def login_status():  # type: ignore[no-untyped-def]
        try:
            result = await service.check_login_status()
            return _success(result, "检查登录状态成功")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("STATUS_CHECK_FAILED", "检查登录状态失败", str(exc)),
            )

    @app.get("/api/v1/login/qrcode")
    async def login_qrcode():  # type: ignore[no-untyped-def]
        try:
            result = await service.get_login_qrcode()
            return _success(result, "获取登录二维码成功")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("STATUS_CHECK_FAILED", "获取登录二维码失败", str(exc)),
            )

    @app.delete("/api/v1/login/cookies")
    async def login_cookies_delete():  # type: ignore[no-untyped-def]
        try:
            await service.delete_cookies()
            return _success(
                {
                    "cookie_path": str(config.cookies_path),
                    "message": "Cookies 已成功删除，登录状态已重置。下次操作时需要重新登录。",
                },
                "删除 cookies 成功",
            )
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("DELETE_COOKIES_FAILED", "删除 cookies 失败", str(exc)),
            )

    @app.post("/api/v1/publish")
    async def publish(req: PublishContentArgs):  # type: ignore[no-untyped-def]
        try:
            result = await service.publish_content(
                title=req.title,
                content=req.content,
                images=req.images,
                tags=req.tags,
                schedule_at=req.schedule_at,
                is_original=req.is_original,
                visibility=req.visibility,
                products=req.products,
            )
            return _success(result, "发布成功")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("PUBLISH_FAILED", "发布失败", str(exc)),
            )

    @app.post("/api/v1/publish_video")
    async def publish_video(req: PublishVideoArgs):  # type: ignore[no-untyped-def]
        try:
            result = await service.publish_video(
                title=req.title,
                content=req.content,
                video=req.video,
                tags=req.tags,
                schedule_at=req.schedule_at,
                visibility=req.visibility,
                products=req.products,
            )
            return _success(result, "视频发布成功")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("PUBLISH_VIDEO_FAILED", "视频发布失败", str(exc)),
            )

    @app.get("/api/v1/feeds/list")
    async def feeds_list():  # type: ignore[no-untyped-def]
        try:
            result = await service.list_feeds()
            return _success(result, "获取Feeds列表成功")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("LIST_FEEDS_FAILED", "获取Feeds列表失败", str(exc)),
            )

    @app.get("/api/v1/feeds/search")
    async def feeds_search_get(keyword: str = Query(default="")):  # type: ignore[no-untyped-def]
        if not keyword:
            return JSONResponse(
                status_code=400,
                content=_error("MISSING_KEYWORD", "缺少关键词参数", "keyword parameter is required"),
            )
        try:
            result = await service.search_feeds(keyword=keyword)
            return _success(result, "搜索Feeds成功")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("SEARCH_FEEDS_FAILED", "搜索Feeds失败", str(exc)),
            )

    @app.post("/api/v1/feeds/search")
    async def feeds_search_post(req: SearchFeedsRequest):  # type: ignore[no-untyped-def]
        if not req.keyword:
            return JSONResponse(
                status_code=400,
                content=_error("MISSING_KEYWORD", "缺少关键词参数", "keyword parameter is required"),
            )
        try:
            result = await service.search_feeds(keyword=req.keyword, filters=req.filters)
            return _success(result, "搜索Feeds成功")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("SEARCH_FEEDS_FAILED", "搜索Feeds失败", str(exc)),
            )

    @app.post("/api/v1/feeds/detail")
    async def feed_detail(req: FeedDetailRequest):  # type: ignore[no-untyped-def]
        try:
            if req.comment_config is None:
                cfg = default_comment_load_config()
            else:
                cfg = CommentLoadConfig(
                    click_more_replies=req.comment_config.click_more_replies,
                    max_replies_threshold=req.comment_config.max_replies_threshold,
                    max_comment_items=req.comment_config.max_comment_items,
                    scroll_speed=req.comment_config.scroll_speed,
                )
            result = await service.get_feed_detail_with_config(
                feed_id=req.feed_id,
                xsec_token=req.xsec_token,
                load_all_comments=req.load_all_comments,
                config=cfg,
            )
            return _success(result, "获取Feed详情成功")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("GET_FEED_DETAIL_FAILED", "获取Feed详情失败", str(exc)),
            )

    @app.post("/api/v1/user/profile")
    async def user_profile(req: UserProfileArgs):  # type: ignore[no-untyped-def]
        try:
            result = await service.user_profile(user_id=req.user_id, xsec_token=req.xsec_token)
            return _success({"data": result}, "result.Message")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("GET_USER_PROFILE_FAILED", "获取用户主页失败", str(exc)),
            )

    @app.post("/api/v1/feeds/comment")
    async def comment(req: PostCommentArgs):  # type: ignore[no-untyped-def]
        try:
            result = await service.post_comment_to_feed(
                feed_id=req.feed_id,
                xsec_token=req.xsec_token,
                content=req.content,
            )
            return _success(result, result.get("message", "发表评论成功"))
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("POST_COMMENT_FAILED", "发表评论失败", str(exc)),
            )

    @app.post("/api/v1/feeds/comment/reply")
    async def comment_reply(req: ReplyCommentArgs):  # type: ignore[no-untyped-def]
        if not req.comment_id and not req.user_id:
            return JSONResponse(
                status_code=400,
                content=_error("INVALID_REQUEST", "请求参数错误", "comment_id or user_id is required"),
            )
        try:
            result = await service.reply_comment_to_feed(
                feed_id=req.feed_id,
                xsec_token=req.xsec_token,
                comment_id=req.comment_id,
                user_id=req.user_id,
                content=req.content,
            )
            return _success(result, result.get("message", "回复评论成功"))
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("REPLY_COMMENT_FAILED", "回复评论失败", str(exc)),
            )

    @app.get("/api/v1/user/me")
    async def user_me():  # type: ignore[no-untyped-def]
        try:
            result = await service.get_my_profile()
            return _success({"data": result}, "获取我的主页成功")
        except Exception as exc:
            return JSONResponse(
                status_code=500,
                content=_error("GET_MY_PROFILE_FAILED", "获取我的主页失败", str(exc)),
            )

    # Mount MCP handler last so explicit REST routes take precedence.
    app.mount("/", mcp_app)

    return app
