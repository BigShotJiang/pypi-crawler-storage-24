# Go MCP -> FastMCP Python Parity Checklist

## Core Runtime

- [x] Server name/version: `xiaohongshu-mcp` / `2.0.0`
- [x] HTTP MCP endpoint: `/mcp`
- [x] Default port: `18060`
- [x] Env compatibility: `XHS_PROXY`, `COOKIES_PATH`, `ROD_BROWSER_BIN` (alias retained)
- [x] Cookies compatibility path strategy (`%TEMP%/cookies.json` fallback)
- [x] Image temp directory strategy (`%TEMP%/xiaohongshu_images`)
- [x] FastMCP runtime pinned to latest validated version: `fastmcp==3.1.1`

## MCP Tool Contract (13 tools)

- [x] `check_login_status`
- [x] `get_login_qrcode` (text + image content)
- [x] `delete_cookies`
- [x] `publish_content`
- [x] `publish_with_video`
- [x] `list_feeds`
- [x] `search_feeds`
- [x] `get_feed_detail`
- [x] `user_profile`
- [x] `like_feed`
- [x] `favorite_feed`
- [x] `post_comment_to_feed`
- [x] `reply_comment_in_feed`

## Parity Fixes Applied

- [x] Strict RFC3339 validation for `schedule_at` (with timezone required)
- [x] `get_feed_detail` default behavior aligned when `load_all_comments=true`:
  - `limit` default -> `20`
  - `reply_limit` default -> `10`
- [x] Removed wrong `feed_id` fallback in feed detail extraction
- [x] Removed wrong `feed_id` fallback in like/favorite state extraction
- [x] Title length algorithm aligned to Go UTF-16 code-unit behavior
- [x] Feed accessibility keyword set aligned to Go rules
- [x] Search filter error messages aligned by dimension (排序依据/笔记类型/发布时间/搜索范围/位置距离)
- [x] Publish flow aligned to Go selectors first, with fallback selectors retained for DOM drift

## REST Compatibility Routes

- [x] `/health`
- [x] `/api/v1/login/status`
- [x] `/api/v1/login/qrcode`
- [x] `/api/v1/login/cookies`
- [x] `/api/v1/publish`
- [x] `/api/v1/publish_video`
- [x] `/api/v1/feeds/list`
- [x] `/api/v1/feeds/search` (GET/POST)
- [x] `/api/v1/feeds/detail`
- [x] `/api/v1/user/profile`
- [x] `/api/v1/feeds/comment`
- [x] `/api/v1/feeds/comment/reply`
- [x] `/api/v1/user/me`

## Added Regression Tests

- [x] Feed detail default config behavior test
- [x] RFC3339 strict parsing test
- [x] UTF-16 emoji title length parity test
- [x] 13-tool contract set test
