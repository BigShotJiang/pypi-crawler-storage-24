"""
Logguard Python SDK
~~~~~~~~~~~~~~~~~~~

Official Python SDK for Logguard — lightweight security monitoring
with user-defined alert rules and IP/user blacklisting.

Quick start:
    from logguard import monitor
    from logguard.models import AlertRule, AlertCondition, BlacklistEntry

    monitor.init(api_key="lg_live_xxx", env="production")

    # Track events
    monitor.event(type="login_failed", ip="1.2.3.4", path="/login", status_code=401)

    # Fire-and-forget (non-blocking, for production traffic)
    monitor.event_fire_and_forget(type="http_error", ip="1.2.3.4", path="/api", status_code=500)

    # Create an alert rule
    rule = monitor.alerts.create(AlertRule(
        name="Brute force",
        conditions=[
            AlertCondition(field="type",            op="eq",  value="login_failed"),
            AlertCondition(field="rate_per_minute", op="gt",  value=10),
        ],
        severity="high",
        actions=["notify", "block"],
    ))

    # Blacklist an IP
    monitor.blacklist.block_ip("185.220.101.1", reason="Known scanner")

    # Check if an IP is blacklisted
    result = monitor.blacklist.check(type="ip", value="185.220.101.1")

Docs: https://docs.logguard.io/sdk/python
"""

from .monitor import monitor
from .models import (
    AlertCondition,
    AlertRule,
    AlertOut,
    BlacklistEntry,
    Event,
    IngestResult,
    UsageInfo,
)
from .exceptions import (
    LogguardError,
    LogguardNotInitializedError,
    LogguardAuthError,
    LogguardQuotaError,
    LogguardConnectionError,
    LogguardValidationError,
    LogguardNotFoundError,
    LogguardConflictError,
)

__version__ = "2.0.0"

__all__ = [
    # Core
    "monitor",
    "__version__",
    # Models
    "Event",
    "IngestResult",
    "AlertOut",
    "UsageInfo",
    "AlertRule",
    "AlertCondition",
    "BlacklistEntry",
    # Exceptions
    "LogguardError",
    "LogguardNotInitializedError",
    "LogguardAuthError",
    "LogguardQuotaError",
    "LogguardConnectionError",
    "LogguardValidationError",
    "LogguardNotFoundError",
    "LogguardConflictError",
]
