from __future__ import annotations


class LogguardError(Exception):
    """Base exception for all Logguard SDK errors."""


class LogguardNotInitializedError(LogguardError):
    """Raised when monitor.event() is called before monitor.init()."""


class LogguardAuthError(LogguardError):
    """Raised when API key is invalid, missing, or subscription expired."""


class LogguardQuotaError(LogguardError):
    """Raised when monthly event quota is exceeded."""


class LogguardConnectionError(LogguardError):
    """Raised when the Logguard API is unreachable or returns a server error."""


class LogguardValidationError(LogguardError):
    """Raised when event data fails validation."""


class LogguardNotFoundError(LogguardError):
    """Raised when a requested resource (alert rule, blacklist entry) is not found."""


class LogguardConflictError(LogguardError):
    """Raised when creating a resource that already exists (e.g. duplicate blacklist entry)."""
