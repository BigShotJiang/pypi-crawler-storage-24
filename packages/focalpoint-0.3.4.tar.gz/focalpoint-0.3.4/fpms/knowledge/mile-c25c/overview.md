# Payment Core

## Purpose
Serve as the central orchestration layer for all payment-domain flows, including payin, payout, refund, transfer, deposit, and withdrawal.

## Responsibilities
- Accept normalized payment requests from access and business layers
- Validate request shape, permissions, and required fields
- Create and manage payment-domain orders and attempts
- Drive state transitions through a canonical payment state machine
- Invoke routing and gateway layers
- Handle synchronous responses and asynchronous callbacks
- Emit internal events to downstream systems such as accounts, settlement, and reconciliation

## Non-Responsibilities
- Does not own external protocol details
- Does not directly mutate balances outside the account system
- Does not own final settlement accounting
- Does not replace reconciliation or audit layers

## Primary Outputs
- PaymentOrder
- PaymentAttempt
- RefundOrder
- Domain events and status updates

## Success Condition
Every payment flow can be expressed as a controlled lifecycle with explicit state, traceability, retries, and downstream event propagation.