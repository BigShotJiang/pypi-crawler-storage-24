# Payment Core Architecture

## Internal Subdomains
- Request normalization
- Validation and guardrails
- Order creation
- Attempt orchestration
- State machine engine
- Result processing
- Event emission

## Upstream Dependencies
- Product and access layer
- Shared contracts and schemas
- Human-approved business constraints

## Downstream Dependencies
- Routing
- Gateway and provider adapters
- Account system via posting or event interfaces
- Clearing and settlement via transaction outcome events
- Reconciliation via traceable references

## Core Invariants
- Every externally visible payment action maps to a canonical order object
- Every external provider interaction maps to an attempt or callback record
- Payment state transitions must be explicit and non-ambiguous
- Idempotency is mandatory for externally initiated flows
- Payment state, clearing state, and settlement state remain separate

## Key Entities
- PaymentOrder
- PaymentAttempt
- RefundOrder
- RefundAttempt
- CallbackRecord
- RouteDecisionReference

## Open Evolution Path
Later extensions may add tokenization, mandates, scheduled payouts, and richer retry policies without breaking the core order/attempt model.