# POS Execution Plan

## Goal
Translate the POS project into a practical v1 delivery path for a restaurant-focused cashier product.

## Phase 1: Product and UX Baseline
Scope:
- Lock restaurant POS scope and non-goals
- Complete Android wireframe structure
- Approve restaurant visual direction
- Align Android preview web with approved direction

Outputs:
- Approved Android information architecture
- Approved cashier-first visual direction
- Preview web screens for key Android flows

## Phase 2: Android and Backend Core Loop
Scope:
- Complete Android UI for cashier core screens
- Implement or connect product browsing and order creation
- Complete backend product, order, and reporting support
- Add payment, refund, and print service modules on backend

Outputs:
- Working cashier flow with real data path
- Searchable orders and visible transaction states

## Phase 3: Merchant Operations Completion
Scope:
- Complete merchant admin workflows
- Finalize products, categories, orders, refunds, and reporting paths
- Connect admin to real backend services

Outputs:
- Usable merchant operational backend for restaurant merchants

## Phase 4: Owner Monitoring and Operational Support
Scope:
- Build mobile owner monitoring surface
- Expose overview, orders, and financial summary pages
- Improve settlement and operational reporting

Outputs:
- Lightweight owner visibility product

## Phase 5: Pilot Readiness
Scope:
- Stabilize end-to-end flow
- Improve diagnostics and logging
- Finalize reprint and refund reliability
- Prepare store onboarding and trial checklist

Outputs:
- Restaurant POS ready for trial-store rollout

## Current Recommended Focus
The immediate high-leverage work is:
1. finish Android wireframes and visual direction
2. align the Android preview web screen set
3. complete backend payment, refund, and print modules
4. connect Android and merchant admin to real APIs

## Current Completion Signal
- Product and planning foundation: strong
- Visual and preview foundation: partially established
- Engineering skeleton: established
- Real business loop: still early
- Pilot readiness: not yet reached