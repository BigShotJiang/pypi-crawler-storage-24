# POS Architecture

## System Overview
The restaurant POS system is structured as four coordinated product surfaces plus a shared backend service layer:
- Android cashier app
- Merchant admin web backend
- Mobile owner monitoring web app
- Local preview and design validation surface
- Backend transaction and configuration services

The architecture should support a practical restaurant operation model for small and medium merchants, with cashier efficiency and transaction reliability as the highest priorities.

## Product Surfaces
### 1. Android Cashier App
Purpose:
- Front-of-house cashier operation
- Order creation
- Payment flow handling
- Receipt print feedback
- Order search and refund
- Settlement and device status

Characteristics:
- Android-first
- Operational UI optimized for repeated cashier use
- Restaurant-focused but without full table-management complexity in V1

### 2. Merchant Admin Web
Purpose:
- Product and category maintenance
- Order and refund review
- Revenue reporting
- Store and staff administration

Characteristics:
- Web-based merchant operations console
- Simple, practical, back-office workflow support

### 3. Mobile Owner Monitoring Web
Purpose:
- Daily business visibility for owners
- Revenue, order, refund, and payment monitoring

Characteristics:
- Lightweight mobile surface
- Fast-read business dashboard rather than full management console

### 4. Android Preview Web
Purpose:
- Fast browser-based validation of Android UI
- Design iteration before native sync
- Visual and flow alignment between product and implementation

Characteristics:
- Non-production preview layer
- Design and review accelerator only

## Backend Service Layer
The backend should provide the persistent source of truth for all business objects required by the POS system.

### Core service domains
- Auth and session context
- Store configuration
- Product and category management
- Order management
- Payment records
- Refund records
- Print records
- Reporting and summaries
- Staff/user administration

### Backend principles
- Use the backend as the system of record for transactional truth
- Separate order, payment, refund, and print state clearly
- Preserve traceability for all transaction events
- Support idempotent writes for payment and refund outcomes

## V1 Business Scope Boundary
### Included in V1
- Quick-service and lightweight restaurant cashier workflow
- Menu and category browsing
- Cart and order creation
- Payment flow handling
- Print status and reprint support
- Order search and detail
- Full refund flow
- Daily settlement
- Merchant admin and owner monitoring basics

### Excluded from V1
- Full table management
- Table maps and table state transitions
- Kitchen display routing
- Kitchen print orchestration
- Delivery platform integration
- Membership and marketing systems
- Partial refunds
- Complex multi-store headquarters features

## Frontend Architecture
### Android Cashier App
Suggested layers:
- UI layer
- ViewModel/state layer
- Domain/use case layer
- Repository/data layer
- Device adapters

Key responsibilities:
- UI layer presents cashier screens and high-frequency workflows
- ViewModel layer owns page state and flow transitions
- Domain layer owns transaction rules and formatting logic
- Repository layer coordinates backend and local persistence
- Device adapters isolate payment SDK and printer SDK integrations

### Merchant Admin Web
Suggested layers:
- Page layer
- Shared component layer
- API service layer
- Auth/session layer
- State hooks and local interaction state

Key responsibilities:
- Pages expose merchant workflows
- Shared components preserve admin consistency
- API services isolate backend integration
- Auth/session layer guards merchant access

### Mobile Owner Monitoring Web
Suggested layers:
- Overview pages
- Lightweight API service layer
- Shared mobile components

Key responsibility:
- Present compact, trustworthy metrics with minimal interaction depth

### Android Preview Web
Suggested role:
- Mirror Android information architecture
- Validate visual hierarchy and flow design
- Serve as the fastest design-to-code feedback loop

## Data and State Model
### Core transactional objects
- Product
- Category
- Order
- Order item
- Payment record
- Refund record
- Print record
- Cashier session
- Store settings

### State separation
The system must track these independently:
- Order state
- Payment state
- Refund state
- Print state

This prevents print or device errors from corrupting payment truth.

## Core Transaction Flow
### Cashier order flow
1. Cashier opens cashier screen
2. Cashier selects menu items
3. Cart totals are calculated
4. Order is created before payment execution
5. Payment is processed
6. Payment result is persisted
7. Print result is tracked separately
8. Order becomes searchable and reportable

### Refund flow
1. Cashier or staff opens order detail
2. System validates refund eligibility
3. Refund request is initiated
4. Refund result is persisted
5. Refund receipt may be printed
6. Admin and owner surfaces reflect refund outcome

### Settlement flow
1. Cashier reviews current shift/day totals
2. System aggregates transaction metrics
3. Shift or day close is confirmed
4. Settlement data becomes visible in merchant and owner reporting

## Design-to-Implementation Flow
The intended flow is:
1. Product scope and wireframes
2. Android preview web alignment
3. High-fidelity design direction approval
4. Native Android sync
5. Backend/API integration
6. Merchant/admin/owner surface alignment

This keeps design iteration fast while preserving a clear path into production implementation.

## Technical Delivery Principles
- Build the cashier transaction loop first
- Keep preview and production concerns separate
- Avoid overcommitting to full-service restaurant complexity in V1
- Use milestone-based decomposition across UX, Android, backend, admin, and pilot rollout
- Shape every implementation toward pilot-store readiness

## Current Architectural State
Already established:
- Android cashier project scaffold
- Merchant admin project scaffold
- Backend scaffold with core domain modules
- Dockerized local environment
- Android preview web for design iteration

Still needed:
- Payment, refund, and print backend modules
- Full restaurant design language rollout across Android screens
- Real data integration across Android and admin surfaces
- Mobile owner monitoring implementation
- Pilot-readiness hardening