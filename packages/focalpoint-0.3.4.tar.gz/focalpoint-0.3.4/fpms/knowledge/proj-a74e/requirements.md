# POS Requirements

## Product Positioning
Build a restaurant-focused POS system for small and medium food-service merchants. The product should support fast front-of-house operations, reliable payment and receipt handling, lightweight merchant management, and operational visibility for owners.

## Target Merchants
- Small restaurants
- Fast casual and quick-service restaurants
- Tea, coffee, bakery, dessert, and snack shops
- Single-store and small multi-store food-service businesses

## Primary Users
- Cashiers
- Store managers
- Restaurant owners
- Merchant operations staff

## Product Scope
The system should include:
- Android cashier POS app
- Merchant admin web backend
- Mobile owner monitoring web app
- Backend services and merchant configuration support

## Core Business Goal
Deliver a restaurant POS that can be piloted in real stores and supports the full daily operating loop from order taking through payment, receipt output, refund handling, and daily settlement.

## V1 Strategic Focus
V1 should optimize for quick-service and lightweight restaurant operations rather than full-service dining complexity. This means prioritizing:
- Fast item selection
- Efficient cashier workflow
- Payment and print reliability
- Order lookup and refund handling
- Daily settlement and business reporting

## V1 Non-Goals
The first version should not include:
- Full table management
- Table maps, merge/split tables, transfer tables
- Kitchen display system
- Kitchen ticket routing
- Delivery platform aggregation
- Membership and loyalty system
- Marketing campaigns and coupons
- Partial refund flows
- Complex multi-store headquarters control

## Restaurant Use Cases
1. Cashier opens the register and starts shift
2. Cashier creates an order from a menu/product list
3. Cashier submits payment and confirms successful transaction
4. Receipt is printed or queued for reprint if needed
5. Staff can search orders and view details
6. Staff can issue a full refund for eligible paid orders
7. Staff can complete end-of-day or end-of-shift settlement
8. Owners can review revenue, refunds, and order trends from web surfaces

## Android Cashier App Requirements
### Required V1 Capabilities
- Cashier login
- Home dashboard for store operations
- Product/category browsing and search
- Cart building and quantity edits
- Item price adjustment and order-level discount
- Order note support
- Payment confirmation flow
- Payment result handling
- Receipt print status display
- Order search and order detail
- Full refund flow
- Daily settlement view
- Device and configuration status page

### Operational Principles
- Minimize taps for common cashier actions
- Keep payment amount and transaction status highly visible
- Support busy-hour operation with large touch targets
- Ensure print failure does not invalidate payment success
- Preserve clear order status, payment status, and print status separation

## Merchant Admin Web Requirements
### Required V1 Capabilities
- Merchant login
- Product management
- Category management
- Order query and detail view
- Refund record view
- Revenue and transaction reporting
- Store-level configuration
- Staff management

### Merchant Admin Goal
Provide restaurant operators with a simple, efficient backend to maintain menus, review business activity, and support front-of-house operations.

## Mobile Owner Monitoring Requirements
### Required V1 Capabilities
- Owner login
- Daily revenue overview
- Order count and recent orders
- Refund monitoring
- Payment method summary
- Core business snapshot for quick review

### Mobile Goal
Allow owners to quickly check business health from a phone without using the full admin backend.

## Key Domain Rules
### Orders
- Orders are created before payment processing begins
- Order, payment, and print states must be tracked independently
- Restaurant menu items must be saved as an order snapshot at purchase time

### Payments
- Payment success must be persisted with traceable transaction metadata
- Duplicate callbacks or submissions must be idempotent
- Payment success must remain valid even if receipt printing fails

### Refunds
- V1 supports full refunds only
- Only eligible paid orders can be refunded
- Refund events must be persisted and visible in both cashier and admin views

### Printing
- Receipt printing status must be tracked separately
- Reprint capability is required from order detail
- Refund receipts should be supported in V1

## UX Direction
The UI should feel like professional restaurant cashier software used in real stores in China:
- Practical, fast, and trustworthy
- Strong operational hierarchy
- Clear emphasis on payable amount, transaction state, and next action
- Suitable for repeated use over long shifts

## Release Milestone Direction
### V1 Foundation
- Product and category management
- Android cashier shell
- Merchant admin shell
- Reporting skeleton

### V1 Transaction Loop
- Cashier order creation
- Payment flow
- Receipt handling
- Order lookup

### V1 Operational Completion
- Refund flow
- Settlement flow
- Owner monitoring views
- Pilot readiness and store onboarding

## Immediate Next Step
Translate these requirements into:
1. Android cashier information architecture and wireframes
2. Merchant admin information architecture
3. Execution milestones for V1 restaurant POS delivery