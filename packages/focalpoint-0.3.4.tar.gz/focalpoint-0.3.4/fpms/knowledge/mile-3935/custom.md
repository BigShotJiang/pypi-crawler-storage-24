# Android POS Wireframe Guidance

## Purpose
Provide a low-fidelity structural guide for the restaurant POS Android app so design and implementation can align around cashier efficiency before high-fidelity visual exploration expands.

## V1 Scope Constraint
This wireframe guidance assumes a restaurant-focused POS without full table management in V1. The cashier flow should support quick-service and lightweight food-service operations rather than full dine-in table orchestration.

## Priority Screens
Priority wireframes for V1:
- Login
- Home
- Cashier
- Payment Confirm
- Payment Processing
- Payment Success
- Orders List
- Order Detail
- Refund
- Settlement
- Settings

## Screen Structures
### Login
Blocks:
- Brand/header
- Terminal/store identity
- Device and network status summary
- Login form
- Primary action
- Footer status

Goal:
- Convey trust and merchant readiness while keeping entry fast

### Home
Blocks:
- Store and cashier identity
- Business summary metrics
- Quick actions for cashier, orders, settlement, settings
- Device and network health

Goal:
- Act as an operational workbench, not a content dashboard

### Cashier
Blocks:
- Search
- Category tabs
- Product browsing area
- Cart area
- Quantity controls
- Discount and note support
- Total and payable summary
- Primary proceed-to-payment action

Goal:
- Optimize for speed, scanning, and confidence in totals

### Payment Confirm
Blocks:
- Order summary
- Discount summary
- Payable amount emphasis
- Payment method selection
- Primary confirm action

Goal:
- Reduce ambiguity before transaction submission

### Payment Processing
Blocks:
- Processing state
- Order number
- Amount
- Optional cancel or query action

Goal:
- Reduce cashier uncertainty during wait time

### Payment Success
Blocks:
- Success state
- Paid amount
- Order number
- Print status
- Finish and optional reprint actions

Goal:
- Confirm transaction completion clearly

### Orders List
Blocks:
- Search
- Filters
- Transaction list with amount and status

Goal:
- Make lookup fast under store pressure

### Order Detail
Blocks:
- Order summary
- Item lines
- Payment section
- Print section
- Actions for reprint and refund

Goal:
- Preserve transaction clarity and operational follow-up

### Refund
Blocks:
- Original order identity
- Refundable amount
- Refund reason
- Confirm action

Goal:
- Support a simple, safe full-refund flow

### Settlement
Blocks:
- Revenue summary
- Order count
- Payment totals by method
- Refund total
- Shift information
- Close-shift action

Goal:
- Support quick operational review at the end of a shift or day

### Settings
Blocks:
- Store info
- Cashier info
- Payment SDK status
- Printer SDK status
- Version info
- Test print and logout actions

Goal:
- Surface operational status rather than deep configuration

## Wireframe Rules
- Keep primary actions low and easy to reach
- Use large touch zones for cashier actions
- Make payable amount the most visually dominant number in checkout screens
- Separate list browsing from transaction confirmation
- Minimize modal complexity
- Show transaction state clearly and consistently

## Next Step
Convert these structures into approved restaurant POS screen layouts, then use the Android preview web to validate them before native sync.