# Account System Architecture

## Internal Components
- Subject model
- Account registry
- Balance store
- Flow store
- Posting rule engine
- Freeze rule engine
- Query layer for balances and statements

## Key Entities
- Subject
- Account
- AccountBalance
- AccountFlow
- FeeItem
- PostingRule
- FreezeRule

## Core Invariants
- Balance changes must be represented by flows or postings
- Available, frozen, pending, and reserved semantics must remain explicit
- Ownership and account type must be queryable independently of balance state
- No direct balance mutation may bypass posting or flow recording

## Interfaces
- Inbound posting requests from payment core, settlement, and manual operations
- Outbound balance and statement queries for product surfaces and admin tools

## Evolution Path
Can later evolve into a richer ledger architecture while preserving the subject/account/flow abstraction.