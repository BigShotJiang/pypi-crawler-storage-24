# Account System

## Purpose
Represent who owns what funds, how balances are structured, and how balance-affecting events become durable flows and postings.

## Responsibilities
- Manage subjects and account ownership
- Maintain account registry and account types
- Store balances and balance structures
- Record account flows and postings
- Apply posting rules from payment and settlement events
- Handle freeze and unfreeze operations

## Non-Responsibilities
- Does not determine whether a payment is approved
- Does not replace reconciliation or settlement logic
- Does not embed business-specific payment routing logic

## Success Condition
All money movement inside the platform can be traced through account ownership, balance changes, and durable flows.