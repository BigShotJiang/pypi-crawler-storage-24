# Requirements

## System Goals
- Support AI-only implementation workflows
- Preserve long-term context across sessions
- Make all critical work products AI-friendly
- Keep human decision load focused on goals, risks, and acceptance
- Support large, high-risk systems such as payments

## Mandatory Rules
- No work starts without a Human PRD
- No implementation starts without an AI Spec
- No payment flow work starts without a state machine definition
- No integration starts without an API contract
- No acceptance starts without both AI Acceptance Spec and Human Acceptance Sheet
- All AI changes must include tests
- High-risk changes must include rollback guidance

## Required Artifact Families
- Human vision, requirements, architecture, acceptance
- AI specs, architecture specs, task packets, test plans, acceptance specs
- Shared contracts, schemas, state machines, glossary
- Delivery release notes, runbooks, rollback plans, postmortems

## Payment-Specific Expectations
- Separate payment state, clearing state, and settlement state
- Model entities explicitly: PaymentOrder, Attempt, RefundOrder, Account, Posting, ReconciliationCase
- Treat auditability, traceability, and rollback as first-class concerns

## Operational Expectation
The system must make large-project context retrievable by layer:
- Project blueprint
- Module blueprint
- Task packet
- Shared facts
- Acceptance gates