# Reconciliation and Exceptions

## Purpose
Ensure the platform can compare internal records with provider, bank, and settlement records, identify mismatches, and safely process corrections.

## Responsibilities
- Trade reconciliation between platform and provider records
- Funds reconciliation between expected and actual settlement funds
- Exception creation and tracking
- In-transit classification and aging
- Manual and semi-automated correction workflows

## Non-Responsibilities
- Does not decide product behavior
- Does not mutate payment state arbitrarily
- Does not replace accounting or account posting discipline

## Success Condition
Every mismatch can be classified, tracked, and resolved without losing traceability.