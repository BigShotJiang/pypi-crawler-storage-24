# Reconciliation and Exceptions Architecture

## Internal Components
- Trade reconciliation engine
- Funds reconciliation engine
- Exception case manager
- In-transit classifier
- Resolution workflow handler
- Audit linkage layer

## Key Entities
- ReconciliationCase
- TradeMismatch
- FundsMismatch
- InTransitRecord
- ResolutionAction

## Core Invariants
- Platform records and external records remain independently observable
- Exceptions are durable records, not temporary logs
- Corrections must preserve who, why, and what changed
- Resolution actions must not erase original mismatches

## Interfaces
- Inbound provider files or normalized records
- Inbound internal transaction and settlement records
- Outbound resolution instructions to operations, settlement, or account postings
- Outbound audit evidence to governance surfaces