# Admin, Audit, and Governance

## Purpose
Provide the human and AI control surface for operating a high-risk payment platform safely, with clear permissions, auditability, and change discipline.

## Responsibilities
- Channel management
- Route rule management
- Permissioned operational tools
- Audit log visibility
- Manual exception operations
- Monitoring and governance controls

## Non-Responsibilities
- Does not own payment execution logic
- Does not replace source-of-truth storage for payment, account, or settlement states
- Does not permit unrestricted mutation of critical records

## Success Condition
Operators can observe, control, and correct the platform without bypassing system boundaries or losing traceability.