# Gateway and Provider Adapters

## Purpose
Provide the normalized edge between the internal payment platform and external providers such as banks, acquirers, payout services, crypto providers, and other settlement endpoints.

## Responsibilities
- Translate internal requests into provider-specific protocol calls
- Manage signing, encryption, authentication, and protocol formatting
- Normalize provider responses and callback payloads
- Isolate provider quirks from payment core
- Maintain traceability between internal references and provider references

## Non-Responsibilities
- Does not own payment lifecycle decisions
- Does not own account postings
- Does not decide business routing policy

## Success Condition
The platform can add, replace, or degrade providers without rewriting payment-core business logic.