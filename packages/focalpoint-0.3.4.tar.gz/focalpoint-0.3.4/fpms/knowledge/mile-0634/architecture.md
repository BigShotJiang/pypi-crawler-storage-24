# Gateway and Provider Adapter Architecture

## Internal Components
- Provider registry
- Request transformer
- Security and signing layer
- Transport execution layer
- Response normalizer
- Callback verifier
- Provider error mapping

## Inputs
- Canonical payment requests from payment core
- RouteDecision-selected provider configuration
- Shared contracts for callback and query models

## Outputs
- Normalized sync response
- Normalized callback event
- Query results for polling or reconciliation support

## Core Invariants
- Provider-specific logic stays inside adapters
- Internal contracts remain provider-agnostic
- All outbound and inbound interactions are referenceable and auditable
- Error mapping must preserve enough detail for safe handling while hiding provider-specific sprawl from upper layers

## Future Growth
Support multiple provider families: acquiring, banking, card issuing, crypto ramp, FX, and internal pseudo-providers such as ledger-backed balance operations.