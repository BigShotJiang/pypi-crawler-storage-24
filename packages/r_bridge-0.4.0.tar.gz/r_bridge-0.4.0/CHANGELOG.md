# Changelog

All notable changes to this project will be documented in this file.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.4.0] — 2026-03-21

### Added
- `RBridge.execute(code, /, *, timeout=None) -> None` — runs an R script string
  via `source(textConnection(...))` in the global environment; return value is
  always discarded. Suited for multi-line scripts and function definitions where
  only side-effects matter.
- Verbose prefix `[R exec]` showing the first line of the script (with ` ...`
  suffix for multi-line code).
- 9 new tests covering `execute`: side-effects, function definitions, loops,
  error propagation, bridge survival, and verbose output.

---

## [0.3.0] — 2026-03-21

### Added
- `verbose=False` constructor parameter: prints all R calls and R output to
  `sys.stderr` in real time (`[R call]`, `[R eval]`, `[R set]`, `[R get]`,
  `[R stdout]`, `[R stderr]` prefixes).
- `drain_stderr` accepts an optional `on_line` callback for real-time stderr
  streaming (used by verbose mode).
- `jsonlite` auto-install: `bridge_loop.R` attempts `install.packages("jsonlite")`
  before giving up, so a fresh R environment works out of the box.
- Zensical documentation site (`docs/`, `zensical.toml`) with 7 pages.
- Read the Docs configuration (`.readthedocs.yaml`).
- GitLab CI configuration (`.gitlab-ci.yml`) for Ubuntu 22.04, 24.04, and Windows.
- Full PyPI metadata: classifiers, keywords, author, project URLs, `LICENSE` file.
- `README.md` with emoji section headers and full API overview.
- `CHANGELOG.md` (this file).

### Fixed
- Windows encoding: `subprocess.Popen` now uses `encoding="utf-8"` explicitly
  instead of relying on the system default (`cp1252`).
- `LANG=en_US.UTF-8` is now only set on non-Windows; `bridge_loop.R` calls
  `Sys.setlocale` on Windows instead.
- `R_LIBS_USER` separator changed from hard-coded `:` to `os.pathsep`
  (`;` on Windows, `:` on Unix).
- Ubuntu CI: `DEBIAN_FRONTEND=noninteractive` suppresses the `tzdata` interactive
  prompt triggered by `r-base`.

### Removed
- `[arrow]` optional dependency and all Arrow installation instructions — the
  feature is not yet implemented (tracked in `PLAN.md`).

---

## [0.1.0] — 2026-03-21

### Added
- Initial release.
- `RBridge` class with persistent R subprocess over stdin/stdout.
- Sentinel-prefixed line-delimited JSON protocol (`__RBRIDGE__:`).
- Operations: `set_var`, `get_var`, `call_func`, `eval_expr`, `ls`, `ping`, `shutdown`.
- Full Python ↔ R type conversion: scalars, vectors, `numpy.ndarray`, `pandas.DataFrame`,
  `pandas.Categorical`, `datetime`, `factor`, `matrix`, `NA`, `NaN`, `Inf`.
- `register_serializer` / `register_deserializer` extension points.
- Thread-safe single-lock design; per-call and bridge-wide timeouts.
- Stderr drain daemon thread; `last_stderr` property.
- `RBridgeError` exception hierarchy (`RStartupError`, `RTimeoutError`, `RError`,
  `RProtocolError`).
