# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for qRemoteX standalone binary.

Produces a single-file executable (~50MB) that bundles Python + all deps.
Target: air-gapped / no-Python environments.

Build:
    pip install pyinstaller
    pyinstaller qremotex.spec
"""

import sys
from pathlib import Path

block_cipher = None

# Collect all source files
a = Analysis(
    ["src/qremotex/main.py"],
    pathex=["src"],
    binaries=[],
    datas=[],
    hiddenimports=[
        # Core deps
        "aiohttp",
        "psutil",
        "pydantic",
        # Tool extras (optional — bundled so binary is self-contained)
        "asyncpg",
        "httpx",
        "bs4",
        # Internal modules (ensure PyInstaller finds them)
        "qremotex.config",
        "qremotex.connection",
        "qremotex.connection.manager",
        "qremotex.connection.auth",
        "qremotex.connection.reconnect",
        "qremotex.connection.key_rotation",
        "qremotex.protocol",
        "qremotex.protocol.messages",
        "qremotex.protocol.router",
        "qremotex.protocol.serializer",
        "qremotex.execution",
        "qremotex.execution.script_executor",
        "qremotex.execution.tool_executor",
        "qremotex.execution.job_queue",
        "qremotex.tools",
        "qremotex.tools.registry",
        "qremotex.tools.db_query",
        "qremotex.tools.http_request",
        "qremotex.tools.file_parse",
        "qremotex.tools.web_crawler",
        "qremotex.transfer",
        "qremotex.transfer.downloader",
        "qremotex.transfer.uploader",
        "qremotex.plan_gating",
        "qremotex.metrics",
        "qremotex.metrics.collector",
        "qremotex.logging",
        "qremotex.logging.logger",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Exclude test/dev-only modules
        "pytest",
        "pytest_asyncio",
        "ruff",
        "tkinter",
        "unittest",
        # Exclude heavy unused stdlib/third-party modules
        "matplotlib",
        "numpy",
        "pandas",
        "scipy",
        "PIL",
        "xml.etree.ElementTree",
        "multiprocessing.popen_spawn_win32",
        "win32com",
        "_tkinter",
        "email",
        "distutils",
        "setuptools",
        "pkg_resources",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="qremotex",
    debug=False,
    bootloader_ignore_signals=False,
    strip=True,
    upx=False,          # UPX disabled — saves 15+ min on CI for ~10% size reduction
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
