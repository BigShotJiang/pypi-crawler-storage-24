"""qRemoteX — Federated Remote Execution Agent for qRaptor."""

__version__ = "2.0.11898"
