"""Tests for qremotex.metrics.collector — MetricsCollector."""



from qremotex.metrics.collector import MetricsCollector


class TestMetricsCollector:

    def test_initial_snapshot(self) -> None:
        mc = MetricsCollector()
        snap = mc.snapshot()
        assert snap["active_executions"] == 0
        assert snap["queued_executions"] == 0
        assert snap["total_executions"] == 0
        assert snap["total_errors"] == 0
        assert snap["uptime_seconds"] >= 0
        assert "cpu_percent" in snap
        assert "memory_used_mb" in snap
        assert "memory_total_mb" in snap

    def test_record_execution_success(self) -> None:
        mc = MetricsCollector()
        mc.record_execution_start()
        assert mc.snapshot()["active_executions"] == 1
        mc.record_execution_end(success=True)
        snap = mc.snapshot()
        assert snap["active_executions"] == 0
        assert snap["total_executions"] == 1
        assert snap["total_errors"] == 0

    def test_record_execution_failure(self) -> None:
        mc = MetricsCollector()
        mc.record_execution_start()
        mc.record_execution_end(success=False)
        snap = mc.snapshot()
        assert snap["total_executions"] == 1
        assert snap["total_errors"] == 1

    def test_set_queued_count(self) -> None:
        mc = MetricsCollector()
        mc.set_queued_count(5)
        assert mc.snapshot()["queued_executions"] == 5

    def test_active_never_negative(self) -> None:
        mc = MetricsCollector()
        mc.record_execution_end(success=True)  # Without a start
        assert mc.snapshot()["active_executions"] == 0

    def test_multiple_executions(self) -> None:
        mc = MetricsCollector()
        for _ in range(5):
            mc.record_execution_start()
            mc.record_execution_end(success=True)
        for _ in range(3):
            mc.record_execution_start()
            mc.record_execution_end(success=False)
        snap = mc.snapshot()
        assert snap["total_executions"] == 8
        assert snap["total_errors"] == 3
