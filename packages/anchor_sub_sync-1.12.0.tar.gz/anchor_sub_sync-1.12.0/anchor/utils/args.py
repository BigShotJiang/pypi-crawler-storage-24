import argparse
from anchor import __version__

def parse_arguments():
    """
    Handles CLI argument parsing for Anchor.
    Returns:
        Namespace: The parsed arguments.
    """
    parser = argparse.ArgumentParser(description="Anchor Subtitle Sync")

    parser.add_argument(
        "-V", "--version", 
        action="version", 
        version=f"%(prog)s {__version__}",
        help="Show program's version number and exit."
    )
    
    # Model Configuration
    parser.add_argument(
        "-a", "--audio-model", 
        type=str, 
        help="Force a specific model size (e.g., tiny, base, small, medium, large-v3)",
        default=None
    )
    parser.add_argument(
        "-b", "--batch-size",
        type=int,
        help="Force a specific batch size (overrides automatic selection)",
        default=None
    )
    parser.add_argument(
        "-t", "--translation-model",
        type=str,
        help="Force a specific translation model (overrides automatic selection)",
        default=None
    )

    # Sync Options
    parser.add_argument(
        "-o", "--overwrite",
        action="store_true",
        help="Overwrite synced files without adding .synced suffix.",
        default=False
    )

    # Automation / Files
    parser.add_argument(
        "-r", "--reference",
        type=str,
        help="For unattended sync, provide reference subtitle file path for point sync.",
        default=None
    )
    parser.add_argument(
        "-s", "--subtitle",
        type=str,
        help="Runs unattended sync on a single subtitle file (provide path to .srt, .ass, etc.)",
        default=None
    )
    parser.add_argument(
        "-v", "--video",
        type=str,
        help="For unattended sync, provide path to the video file if the script fails to auto-match.",
        default=None
    )
    parser.add_argument(
        "-l", "--language",
        type=str,
        help="For unattended mode, provide the target language code (e.g. 'en', 'pt', 'fr') for translation or download.",
        default=None
    )
    parser.add_argument(
        "-d", "--download",
        action="store_true",
        help="For unattended mode, automatically download subtitles. Provide -v with the video file path, or anchor downloads for all videos in the directory.",
        default=False
    )
    
    return parser.parse_args()