import re
import requests
import zipfile
import io
import subprocess
import tempfile
import shutil
import unicodedata
from pathlib import Path
from anchor import __version__

SUBDL_SEARCH_URL = "https://api.subdl.com/api/v1/subtitles"
SUBDL_DOWNLOAD_BASE = "https://dl.subdl.com"
USER_AGENT = "Anchor-Sub-Sync " + __version__

def map_subdl_language(lang_code: str) -> str:
    """
    Converts standard ISO codes to SubDL's specific uppercase format.
    """
    l = lang_code.strip().lower()
    
    # Brazilian Portuguese mapping
    if l in ["pt-br", "br", "pob"]:
        return "BR_PT"
    
    # European Portuguese mapping
    if l in ["pt", "pt-pt"]:
        return "PT"
        
    return l.upper()

def _normalize_title(title: str) -> str:
    t = re.sub(r'[\._]', ' ', title.lower())
    return re.sub(r'[^\w\s]', '', t).strip()

def sanitize_filename(text: str) -> str:
    """Crushes weird Unicode/Fullwidth fonts back to standard ASCII."""
    if not text:
        return ""
    # NFKC converts compatibility characters (like ＷＥＢ) to their standard equivalents (WEB)
    return unicodedata.normalize('NFKC', text)

def _pick_best_show(results: list, parsed_data: dict) -> dict | None:
    """
    Picks the best show from SubDL's disambiguation results list.
    Prefers exact title + year match, then title only, then first result.
    """
    target_title = _normalize_title(parsed_data.get("title", ""))
    target_year = str(parsed_data.get("year", ""))

    # Pass 1: exact title + year
    for show in results:
        show_title = _normalize_title(show.get("name", ""))
        show_year = str(show.get("year") or "")
        if show_title == target_title and (not target_year or show_year == target_year):
            return show

    # Pass 2: title only
    for show in results:
        if _normalize_title(show.get("name", "")) == target_title:
            return show

    # Pass 3: last resort
    return results[0] if results else None


# SubDL sometimes returns full language names instead of 2-letter codes
_LANG_NAME_TO_CODE = {
    "english": "en", "portuguese": "pt", "brazilian portuguese": "pt-BR",
    "spanish": "es", "french": "fr", "german": "de", "italian": "it",
    "dutch": "nl", "russian": "ru", "arabic": "ar", "chinese": "zh",
    "japanese": "ja", "korean": "ko", "turkish": "tr", "polish": "pl",
    "swedish": "sv", "norwegian": "no", "danish": "da", "finnish": "fi",
    "czech": "cs", "hungarian": "hu", "romanian": "ro", "greek": "el",
    "hebrew": "he", "croatian": "hr", "serbian": "sr", "slovak": "sk",
    "slovenian": "sl", "bulgarian": "bg", "ukrainian": "uk",
}

def _normalize_lang_code(raw: str) -> str:
    """Converts 'English' or 'EN' to 'en' for pipeline consistency."""
    cleaned = raw.strip().lower()
    if cleaned == "br":
        return "pt-br"
    if len(cleaned) == 2:
        return cleaned
    return _LANG_NAME_TO_CODE.get(cleaned, cleaned[:2])


def _build_params(parsed_data: dict, langs_upper: str, api_key: str) -> dict:
    """Builds the base query params shared between first and retry requests."""
    content_type = "tv" if parsed_data.get("season") else "movie"

    params = {
        "api_key": api_key,
        "languages": langs_upper,
        "type": content_type,
        "releases": 1,
        "subs_per_page": 30,
    }

    if parsed_data.get("year"):
        params["year"] = parsed_data.get("year")
    if parsed_data.get("season"):
        params["season_number"] = parsed_data.get("season")
    if parsed_data.get("episode"):
        params["episode_number"] = parsed_data.get("episode")

    return params


def _normalize_results(raw_subs: list) -> list:
    """Converts raw SubDL subtitle dicts into the normalized pipeline shape."""
    normalized = []

    for sub in raw_subs:
        url_path = sub.get("url", "")
        if not url_path:
            continue

        releases = sub.get("releases", [])
        if isinstance(releases, str):
            releases = [releases] if releases else []

        release_name = sub.get("release_name", "")
        if release_name and release_name not in releases:
            releases.insert(0, release_name)

        filename = (releases[0] + ".srt") if releases else (sub.get("name", "Unknown") + ".srt")

        lang_code = _normalize_lang_code(sub.get("language", "en"))
        is_hi = bool(sub.get("hi", 0))

        normalized.append({
            "provider": "SubDL",
            "id": url_path,           # Full path used directly for download
            "filename": filename,
            "language": lang_code,
            "releases": releases,
            "download_url": f"{SUBDL_DOWNLOAD_BASE}{url_path}",
            "hash_match": False,      # SubDL has no hash search
            "score": 0,
            "_is_hi": is_hi,          # Direct HI flag, avoids regex in scoring
        })

    return normalized

def search_subdl(parsed_data: dict, language: str, api_key: str) -> list:
    """
    Searches SubDL using text metadata for a single language.
    """
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
    }

    # 1. Map the single requested language to SubDL's format
    requested_lang_lower = language.strip().lower()
    lang_upper = map_subdl_language(requested_lang_lower)
    
    params = _build_params(parsed_data, lang_upper, api_key)
    params["film_name"] = parsed_data.get("title", "")

    all_raw_subs = []

    try:
        response = requests.get(
            SUBDL_SEARCH_URL,
            headers=headers,
            params=params,
            timeout=10,
        )

        if response.status_code == 200:
            data = response.json()

            if data.get("status"):
                raw_subs = data.get("subtitles", [])

                # Handle SubDL disambiguation (if they return shows but no direct subs)
                if not raw_subs and data.get("results"):
                    best_match = _pick_best_show(data["results"], parsed_data)

                    if best_match:
                        retry_params = params.copy()
                        retry_params.pop("film_name", None)
                        retry_params.pop("languages", None) # Remove the plural key
                        retry_params["sd_id"] = best_match["sd_id"]
                        
                        # The disambiguation sd_id endpoint strictly requires singular 'language'
                        retry_params["language"] = lang_upper

                        try:
                            response2 = requests.get(
                                SUBDL_SEARCH_URL,
                                headers=headers,
                                params=retry_params,
                                timeout=10,
                            )

                            if response2.status_code == 200:
                                data2 = response2.json()
                                if data2.get("status"):
                                    raw_subs += data2.get("subtitles", [])
                        except Exception as e:
                            print(f"   [red]❌ SubDL retry [{lang_upper}] Exception: {e}[/red]")

                all_raw_subs.extend(raw_subs)

    except Exception as e:
        print(f"   [red]❌ SubDL Search Exception [{lang_upper}]: {e}[/red]")
        return []
    
    # 2. Normalize results and filter
    normalized = _normalize_results(all_raw_subs)
    filtered_results = []
    
    for sub in normalized:
        # _normalize_lang_code safely converted SubDL's "BR_PT" back to "pt-br"
        # so we can compare it directly against the original requested language!
        if sub["language"] == requested_lang_lower:
            sub["filename"] = sanitize_filename(sub.get("filename", ""))
            if "releases" in sub:
                sub["releases"] = [sanitize_filename(r) for r in sub["releases"]]
                
            filtered_results.append(sub)
            
    return filtered_results


def download_subdl(url_path: str, target_video_path: Path, custom_suffix: str = ".srt", episode: str = None) -> bool:
    """
    Downloads a subtitle ZIP/RAR from SubDL, extracts the right .srt inside,
    and saves it next to the video with the given custom_suffix.
    """
    headers = {
        "User-Agent": USER_AGENT,
    }

    download_url = f"{SUBDL_DOWNLOAD_BASE}{url_path}"

    try:
        response = requests.get(download_url, headers=headers, timeout=15)

        if response.status_code != 200:
            return False

        final_path = target_video_path.with_suffix(custom_suffix)

        try:
            # ATTEMPT 1: Try to open it as a standard ZIP archive
            with zipfile.ZipFile(io.BytesIO(response.content)) as zf:
                srt_names = [
                    name for name in zf.namelist()
                    if name.lower().endswith((".srt", ".sub", ".ass", ".vtt"))
                ]
                if not srt_names:
                    return False

                chosen = _pick_episode_from_pack(srt_names, episode)
                srt_content = zf.read(chosen)

            with open(final_path, "wb") as f:
                f.write(srt_content)
            return True

        except zipfile.BadZipFile:
            # ATTEMPT 2: FALLBACK (It's not a ZIP archive)
            
            # Check for the dreaded RAR format using its magic bytes
            if response.content.startswith(b'Rar!'):
                # 1. Check if unrar is actually installed on the system
                if not shutil.which("unrar"):
                    print("   [yellow]⚠️ SubDL served a .RAR archive, but 'unrar' is missing from your system. Skipping...[/yellow]")
                    return False
                    
                # 2. Extract using a temporary directory
                try:
                    with tempfile.TemporaryDirectory() as temp_dir:
                        temp_rar_path = Path(temp_dir) / "temp.rar"
                        
                        # Save the raw RAR bytes to disk
                        with open(temp_rar_path, "wb") as tr:
                            tr.write(response.content)
                            
                        # Call system unrar: 'unrar e -y temp.rar temp_dir/'
                        subprocess.run(
                            ["unrar", "e", "-y", str(temp_rar_path), str(temp_dir)],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            check=True
                        )
                        
                        # Find the extracted subtitles
                        extracted_files = list(Path(temp_dir).glob("*"))
                        srt_files = [f for f in extracted_files if f.suffix.lower() in [".srt", ".sub", ".ass", ".vtt"]]
                        
                        if not srt_files:
                            return False
                            
                        # Re-use your episode picker logic
                        srt_names = [f.name for f in srt_files]
                        chosen_name = _pick_episode_from_pack(srt_names, episode)
                        chosen_path = next(f for f in srt_files if f.name == chosen_name)
                        
                        # Copy the chosen file to the final destination
                        shutil.copy(chosen_path, final_path)
                        return True
                        
                except subprocess.CalledProcessError as e:
                    print(f"   [red]❌ unrar failed to extract the archive: {e}[/red]")
                    return False
            
            # ATTEMPT 3: It's just a raw text stream (.srt, .ass, etc.)
            with open(final_path, "wb") as f:
                f.write(response.content)
            return True

    except Exception as e:
        print(f"   [red]❌ SubDL Download Exception: {e}[/red]")

    return False

def _pick_episode_from_pack(srt_names: list, episode: str) -> str:
    """
    Given a list of .srt filenames from a ZIP, returns the best match
    for the target episode number. Falls back to srt_names[0] if no match.
    """
    if not episode or len(srt_names) == 1:
        return srt_names[0]

    ep_num = str(episode).zfill(2)  # "1" -> "01"

    # Match patterns like S01E01, E01, _01_, .01.
    ep_pattern = re.compile(
        rf'[Ee]{ep_num}|[^0-9]{ep_num}[^0-9]',
    )

    for name in srt_names:
        if ep_pattern.search(name):
            return name

    # Fallback
    return srt_names[0]
