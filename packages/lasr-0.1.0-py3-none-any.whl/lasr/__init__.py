"""LASR (LASER) — Least Action Semantic Router.

Globally optimal text chunking for RAG pipelines.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from lasr.types import Chunk, LaserConfig, SentenceSpan
from lasr.pipeline import LaserPipeline

if TYPE_CHECKING:
    pass

__all__ = [
    "chunk",
    "Chunk",
    "LaserConfig",
    "LaserPipeline",
    "SentenceSpan",
]


def chunk(
    text: str,
    *,
    alpha: float = 2.5,
    min_sentences: int = 5,
    max_sentences: int = 30,
    model: str = "all-MiniLM-L6-v2",
    device: str | None = None,
    batch_size: int = 128,
) -> List[Chunk]:
    """Chunk a document into semantically optimal segments.

    This is the main entry point for LASR.  It creates a pipeline
    internally and returns a list of ``Chunk`` objects.

    Parameters
    ----------
    text : str
        The document text to chunk.
    alpha : float
        Boundary cost — higher values produce fewer, larger chunks.
    min_sentences : int
        Minimum sentences per chunk (hard constraint).
    max_sentences : int
        Maximum sentences per chunk (hard constraint).
    model : str
        Sentence-transformer model name for encoding.
    device : str or None
        Device for the encoder (``"cpu"``, ``"cuda"``, ``"mps"``).
        Auto-detected if *None*.
    batch_size : int
        Encoder batch size.

    Returns
    -------
    list[Chunk]
        Optimally partitioned chunks with text, positions, and context.

    Examples
    --------
    >>> from lasr import chunk
    >>> chunks = chunk(open("document.txt").read())
    >>> for c in chunks:
    ...     print(c.text[:80])
    """
    config = LaserConfig(
        alpha_base=alpha,
        l_min=min_sentences,
        l_max=max_sentences,
        model_name=model,
        device=device,
        batch_size=batch_size,
    )
    pipeline = LaserPipeline(config)
    return pipeline.chunk(text)
