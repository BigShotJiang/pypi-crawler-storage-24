"""Core data structures for LASER."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class SentenceSpan:
    """A single sentence with positional and structural metadata.

    Metadata is populated by ``TextPreprocessor`` so downstream modules
    (``PriorEstimator``) can operate on structured signals instead of
    re-parsing raw text.
    """

    index: int
    text: str
    start_char: int
    end_char: int
    raw_suffix: str = ""
    raw_prefix: str = ""
    is_header: bool = False


@dataclass(frozen=True)
class Chunk:
    """A contiguous group of sentences determined to be semantically cohesive.

    ``context_before`` and ``context_after`` hold the 1-sentence bleed
    window grabbed from the neighbouring chunks.  They are *not* part of the
    DP-optimal partition stored in ``sentences`` / ``text``.  Use
    ``text_with_context`` when you need the enriched version (e.g. for
    vector-DB insertion).
    """

    sentences: tuple[SentenceSpan, ...]
    text: str
    start_char: int
    end_char: int
    context_before: tuple[SentenceSpan, ...] = ()
    context_after: tuple[SentenceSpan, ...] = ()

    @property
    def num_sentences(self) -> int:
        return len(self.sentences)

    @property
    def text_with_context(self) -> str:
        parts: list[str] = []
        if self.context_before:
            parts.extend(s.text for s in self.context_before)
        parts.extend(s.text for s in self.sentences)
        if self.context_after:
            parts.extend(s.text for s in self.context_after)
        return " ".join(parts)


@dataclass
class LaserConfig:
    """All tuneable hyper-parameters for the LASER pipeline.

    Default values are calibrated for general-purpose retrieval:
      alpha_base = 2.5   (boundary cost — higher = fewer, larger chunks)
      rho        = 1.0   (anchor — all costs relative to semantic tension)
      w_struct   = 0.25  (structural discount for headers / double newlines)
      w_bind     = 1.0   (coreference binding penalty)
      w_disc     = 0.3   (discourse connective penalty)
    """

    # --- Lagrangian ---------------------------------------------------------
    alpha_base: float = 2.5
    rho: float = 1.0

    # --- Prior weights (3-signal decomposition) -----------------------------
    w_struct: float = 0.25
    w_bind: float = 1.0
    w_disc: float = 0.3

    # --- Hard constraints ---------------------------------------------------
    l_min: int = 5
    l_max: int = 30

    # --- Encoder ------------------------------------------------------------
    encoder: str = "sbert"
    model_name: str = "all-MiniLM-L6-v2"
    batch_size: int = 128
    device: str | None = None
