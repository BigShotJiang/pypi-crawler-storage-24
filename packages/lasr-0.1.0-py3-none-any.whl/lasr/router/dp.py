"""OptimalDPChunker — globally optimal segmentation via dynamic programming.

Solves the Bellman recurrence:

    OPT[i] = min_{j} ( OPT[j] + C(j, i) )

where j ranges over [max(0, i - l_max), i - l_min] and

    C(j, i) = rho * Tension(j, i) + alpha_{i-1}

Tension is computed in O(d) using the prefix-sum norm trick:

    Tension(j, i) = (i - j) - ||P[i] - P[j]||_2

where P is the cumulative sum of L2-normalised sentence embeddings.
"""

from __future__ import annotations

import numpy as np


class OptimalDPChunker:
    """Finds the globally optimal set of chunk boundaries."""

    def route(
        self,
        embeddings: np.ndarray,
        alphas: np.ndarray,
        rho: float = 1.0,
        l_min: int = 5,
        l_max: int = 30,
    ) -> list[int]:
        """Return boundary indices (sentence indices *after* which to split).

        Parameters
        ----------
        embeddings : (T, d) array
            Sentence embedding matrix.
        alphas : (T-1,) array
            Context-aware boundary costs.  ``alphas[t]`` is the cost of
            placing a boundary after sentence *t*.
        rho : float
            Semantic tension coefficient.
        l_min, l_max : int
            Hard min/max sentences per chunk.

        Returns
        -------
        list[int]
            Sorted boundary indices.  A boundary at index *b* means
            "split after sentence *b*".
        """
        T = embeddings.shape[0]

        if T == 0:
            return []

        # L2-normalise embeddings row-wise.
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1.0, norms)
        H = embeddings / norms

        # Prefix sums for O(d) tension.
        P = np.zeros((T + 1, H.shape[1]), dtype=np.float64)
        np.cumsum(H, axis=0, out=P[1:])

        # DP arrays.
        INF = float("inf")
        opt = np.full(T + 1, INF, dtype=np.float64)
        back = np.full(T + 1, -1, dtype=np.intp)
        opt[0] = 0.0

        for i in range(l_min, T + 1):
            j_lo = max(0, i - l_max)
            j_hi = i - l_min

            j_arr = np.arange(j_lo, j_hi + 1)
            valid_mask = opt[j_arr] != INF

            if not np.any(valid_mask):
                continue

            j_valid = j_arr[valid_mask]

            S = P[i] - P[j_valid]
            norms_S = np.linalg.norm(S, axis=1)
            tensions = np.maximum((i - j_valid) - norms_S, 0.0)

            boundary_cost = alphas[i - 1] if i < T else 0.0
            costs = rho * tensions + boundary_cost
            totals = opt[j_valid] + costs

            best_idx = np.argmin(totals)
            if totals[best_idx] < opt[i]:
                opt[i] = totals[best_idx]
                back[i] = j_valid[best_idx]

        if opt[T] == INF:
            return self._fallback(T, l_min, l_max)

        # Backtrack to recover boundaries.
        boundaries: list[int] = []
        cur = T
        while cur > 0:
            prev = int(back[cur])
            if prev < 0:
                break
            if prev > 0:
                boundaries.append(prev - 1)
            cur = prev

        boundaries.sort()
        return boundaries

    @staticmethod
    def _fallback(T: int, l_min: int, l_max: int) -> list[int]:
        """Even split when DP finds no feasible solution (e.g. T < l_min)."""
        if T <= l_max:
            return []
        boundaries: list[int] = []
        pos = l_max - 1
        while pos < T - 1:
            boundaries.append(pos)
            pos += l_max
        return boundaries
