"""Abstract router protocol for LASER."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import numpy as np


@runtime_checkable
class BaseRouter(Protocol):
    """Contract for all LASER router backends.

    ``route`` takes an embedding matrix and per-boundary costs and returns
    a list of boundary indices (positions *after* which a chunk break occurs).
    """

    def route(
        self,
        embeddings: np.ndarray,
        alphas: np.ndarray,
        rho: float,
        l_min: int,
        l_max: int,
    ) -> list[int]: ...
