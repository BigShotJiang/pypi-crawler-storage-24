"""LaserPipeline — orchestrate the full LASER chunking flow."""

from __future__ import annotations

from typing import List

import numpy as np

from lasr.aggregator import ChunkAggregator
from lasr.encoder.base import BaseEncoder
from lasr.preprocessor import TextPreprocessor
from lasr.prior import PriorEstimator
from lasr.router.base import BaseRouter
from lasr.router.dp import OptimalDPChunker
from lasr.types import Chunk, LaserConfig


def _build_encoder(config: LaserConfig) -> BaseEncoder:
    if config.encoder == "openai":
        from lasr.encoder.openai import OpenAIEncoder

        return OpenAIEncoder(model_name=config.model_name)

    from lasr.encoder.sbert import SentenceTransformerEncoder

    return SentenceTransformerEncoder(
        model_name=config.model_name,
        batch_size=config.batch_size,
        device=config.device,
    )


class LaserPipeline:
    """End-to-end chunking pipeline.

    Wires together:
    ``TextPreprocessor -> PriorEstimator -> BaseEncoder -> BaseRouter -> ChunkAggregator``
    """

    def __init__(
        self,
        config: LaserConfig | None = None,
        *,
        encoder: BaseEncoder | None = None,
        router: BaseRouter | None = None,
    ) -> None:
        self.config = config or LaserConfig()
        self._preprocessor = TextPreprocessor()
        self._prior = PriorEstimator(self.config)
        self._encoder = encoder or _build_encoder(self.config)
        self._router = router or OptimalDPChunker()
        self._aggregator = ChunkAggregator()

    def chunk(self, text: str) -> List[Chunk]:
        """Chunk a single document and return the optimal ``Chunk`` list."""
        spans = self._preprocessor.split(text)
        if not spans:
            return []

        texts = [s.text for s in spans]
        embeddings = self._encoder.encode(texts)
        alphas = self._prior.estimate(spans)

        boundaries = self._router.route(
            embeddings=embeddings,
            alphas=alphas,
            rho=self.config.rho,
            l_min=self.config.l_min,
            l_max=self.config.l_max,
        )

        return self._aggregator.aggregate(spans, boundaries)

    def chunk_many(self, texts: List[str]) -> List[List[Chunk]]:
        """Chunk multiple documents."""
        return [self.chunk(t) for t in texts]
