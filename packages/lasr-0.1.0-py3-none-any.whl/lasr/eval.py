"""Evaluation utilities for LASER chunking quality."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

import numpy as np

from lasr.types import Chunk


@dataclass
class ChunkingStats:
    """Summary statistics for a chunked document."""

    num_chunks: int
    total_sentences: int
    avg_sentences_per_chunk: float
    min_sentences: int
    max_sentences: int
    avg_intra_chunk_variance: float


def compute_intra_chunk_variance(
    chunks: Sequence[Chunk],
    embeddings: np.ndarray,
) -> float:
    """Average cosine distance from each sentence to its chunk centroid.

    Lower values indicate tighter semantic cohesion within chunks.
    """
    if not chunks:
        return 0.0

    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms = np.where(norms == 0, 1.0, norms)
    H = embeddings / norms

    total_distance = 0.0
    total_sentences = 0

    for chunk in chunks:
        indices = [s.index for s in chunk.sentences]
        if not indices:
            continue
        vecs = H[indices]
        centroid = vecs.mean(axis=0)
        c_norm = np.linalg.norm(centroid)
        if c_norm > 0:
            centroid = centroid / c_norm
        distances = 1.0 - vecs @ centroid
        total_distance += float(np.sum(np.maximum(distances, 0.0)))
        total_sentences += len(indices)

    if total_sentences == 0:
        return 0.0
    return total_distance / total_sentences


def summarize_chunking(
    chunks: Sequence[Chunk],
    embeddings: np.ndarray,
) -> ChunkingStats:
    """Compute summary statistics for a set of chunks."""
    if not chunks:
        return ChunkingStats(
            num_chunks=0,
            total_sentences=0,
            avg_sentences_per_chunk=0.0,
            min_sentences=0,
            max_sentences=0,
            avg_intra_chunk_variance=0.0,
        )

    counts = [c.num_sentences for c in chunks]
    return ChunkingStats(
        num_chunks=len(chunks),
        total_sentences=sum(counts),
        avg_sentences_per_chunk=sum(counts) / len(counts),
        min_sentences=min(counts),
        max_sentences=max(counts),
        avg_intra_chunk_variance=compute_intra_chunk_variance(chunks, embeddings),
    )
