"""PriorEstimator — compute context-aware boundary costs alpha_t.

Implements the refined 3-signal formula in O(T):

    alpha_t = alpha_base
              - w_struct * I_struct(t)
              + w_bind   * I_bind(t)
              + w_disc   * I_disc(t)
"""

from __future__ import annotations

import re
from typing import List, Sequence

import numpy as np

from lasr.types import LaserConfig, SentenceSpan

# Pronouns that likely refer back to the previous sentence.
_BINDING_PREFIXES = (
    "He ", "She ", "It ", "They ",
    "His ", "Her ", "Its ", "Their ",
    "This ", "These ", "Those ",
    "He,", "She,", "It,", "They,",
)

# Discourse connectives / transitional markers.
_DISCOURSE_PREFIXES = (
    "However", "Therefore", "Moreover", "Furthermore",
    "Additionally", "Consequently", "Nevertheless", "Meanwhile",
    "Thus", "Hence", "Indeed", "Nonetheless",
    "In addition", "As a result", "On the other hand",
    "In contrast", "For example", "For instance",
    "And ", "But ", "So ", "Yet ", "Or ",
)

_LIST_MARKER_RE = re.compile(r"^\s*(?:[-*+]|\d+[.)]) ")


class PriorEstimator:
    """Computes an array of boundary costs ``alpha_t`` for ``T-1`` potential
    split points between consecutive sentences.

    Each ``alpha_t`` value encodes three independent signals derived from the
    metadata on ``SentenceSpan`` objects, without re-parsing the raw text.
    """

    def __init__(self, config: LaserConfig | None = None) -> None:
        self.cfg = config or LaserConfig()

    def estimate(self, spans: Sequence[SentenceSpan]) -> np.ndarray:
        """Return shape ``(T-1,)`` array of boundary costs.

        ``alpha[t]`` is the cost of placing a boundary *after* sentence ``t``
        (i.e. between sentence ``t`` and sentence ``t+1``).
        """
        n = len(spans)
        if n <= 1:
            return np.array([], dtype=np.float64)

        alphas = np.full(n - 1, self.cfg.alpha_base, dtype=np.float64)

        for t in range(n - 1):
            current = spans[t]
            nxt = spans[t + 1]

            if self._is_structural_break(current, nxt):
                alphas[t] -= self.cfg.w_struct

            if self._is_binding(nxt):
                alphas[t] += self.cfg.w_bind

            if self._is_discourse(nxt):
                alphas[t] += self.cfg.w_disc

        return alphas

    # ------------------------------------------------------------------
    # Signal detectors
    # ------------------------------------------------------------------

    @staticmethod
    def _is_structural_break(current: SentenceSpan, nxt: SentenceSpan) -> bool:
        """I_struct: natural document boundary between current and nxt."""
        if "\n\n" in current.raw_suffix:
            return True
        if nxt.is_header:
            return True
        if current.is_header:
            return True
        if _LIST_MARKER_RE.match(nxt.text):
            return True
        return False

    @staticmethod
    def _is_binding(nxt: SentenceSpan) -> bool:
        """I_bind: unresolved coreference — next sentence starts with a
        pronoun that likely refers to an entity in the current sentence."""
        stripped = nxt.text.lstrip()
        return stripped.startswith(_BINDING_PREFIXES)

    @staticmethod
    def _is_discourse(nxt: SentenceSpan) -> bool:
        """I_disc: transitional marker at the start of the next sentence."""
        stripped = nxt.text.lstrip()
        for prefix in _DISCOURSE_PREFIXES:
            if stripped.startswith(prefix):
                after = stripped[len(prefix) :]
                if not after or not after[0].isalpha():
                    return True
        return False
