"""ChunkAggregator — reassemble text from boundary indices."""

from __future__ import annotations

from typing import List, Sequence

from lasr.types import Chunk, SentenceSpan


class ChunkAggregator:
    """Converts a list of ``SentenceSpan`` objects and boundary indices into
    ``Chunk`` objects by slicing and joining the sentence texts."""

    def aggregate(
        self,
        spans: Sequence[SentenceSpan],
        boundaries: Sequence[int],
    ) -> List[Chunk]:
        """Build ``Chunk`` objects from sentences and split points.

        Parameters
        ----------
        spans :
            Ordered sentence spans for the full document.
        boundaries :
            Sorted indices — a boundary at *b* means "split after sentence *b*".
            For example, ``[3, 7]`` produces three chunks:
            ``[0..3], [4..7], [8..end]``.

        Returns
        -------
        list[Chunk]
        """
        if not spans:
            return []

        n = len(spans)
        cut_points = sorted(set(boundaries))
        chunks: List[Chunk] = []
        start = 0

        for bp in cut_points:
            end = bp + 1
            if end > n:
                end = n
            if start < end:
                ctx_before = (spans[start - 1],) if start > 0 else ()
                ctx_after = (spans[end],) if end < n else ()
                chunks.append(self._make_chunk(spans[start:end], ctx_before, ctx_after))
            start = end

        if start < n:
            ctx_before = (spans[start - 1],) if start > 0 else ()
            chunks.append(self._make_chunk(spans[start:], ctx_before, ()))

        return chunks

    @staticmethod
    def _make_chunk(
        spans: Sequence[SentenceSpan],
        context_before: tuple[SentenceSpan, ...] = (),
        context_after: tuple[SentenceSpan, ...] = (),
    ) -> Chunk:
        text = " ".join(s.text for s in spans)
        return Chunk(
            sentences=tuple(spans),
            text=text,
            start_char=spans[0].start_char,
            end_char=spans[-1].end_char,
            context_before=context_before,
            context_after=context_after,
        )
