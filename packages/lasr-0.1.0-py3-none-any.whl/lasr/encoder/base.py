"""Abstract encoder protocol for LASER."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import numpy as np


@runtime_checkable
class BaseEncoder(Protocol):
    """Contract that every LASER encoder backend must satisfy.

    ``encode`` accepts a list of sentence strings and returns an embedding
    matrix of shape ``(T, d)`` where *d* is the model's hidden dimension.
    """

    def encode(self, texts: list[str]) -> np.ndarray: ...
