"""Encoder backends for LASER."""

from lasr.encoder.base import BaseEncoder
from lasr.encoder.sbert import SentenceTransformerEncoder

__all__ = ["BaseEncoder", "SentenceTransformerEncoder"]
