"""SentenceTransformer encoder backend (local, no API key required)."""

from __future__ import annotations

import numpy as np


class SentenceTransformerEncoder:
    """Wraps the ``sentence-transformers`` library.

    Default model is ``all-MiniLM-L6-v2`` (384-d, fast).

    Parameters
    ----------
    model_name : str
        Hugging Face model identifier.
    batch_size : int
        Inference batch size forwarded to ``SentenceTransformer.encode``.
        Larger values improve GPU utilisation (default 256).
    device : str or None
        PyTorch device string (``"cpu"``, ``"cuda"``, ``"mps"``).
        *None* lets ``sentence-transformers`` auto-detect.
    """

    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        batch_size: int = 128,
        device: str | None = None,
    ) -> None:
        from sentence_transformers import SentenceTransformer

        self._model = SentenceTransformer(model_name, device=device)
        self._batch_size = batch_size

    def encode(self, texts: list[str]) -> np.ndarray:
        embeddings = self._model.encode(
            texts,
            batch_size=self._batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        return np.asarray(embeddings, dtype=np.float64)
