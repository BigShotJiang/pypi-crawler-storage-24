"""OpenAI embeddings encoder backend (requires ``openai`` extra)."""

from __future__ import annotations

import os
from typing import List

import numpy as np

_BATCH_SIZE = 2048


class OpenAIEncoder:
    """Calls the OpenAI embeddings API.

    Requires the ``OPENAI_API_KEY`` environment variable (or pass *api_key*).
    """

    def __init__(
        self,
        model_name: str = "text-embedding-3-small",
        api_key: str | None = None,
    ) -> None:
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise ImportError(
                "The 'openai' package is required for OpenAIEncoder. "
                "Install it with: pip install laser-chunker[openai]"
            ) from exc

        self._client = OpenAI(api_key=api_key or os.environ.get("OPENAI_API_KEY"))
        self._model = model_name

    def encode(self, texts: list[str]) -> np.ndarray:
        all_embeddings: List[list[float]] = []
        for i in range(0, len(texts), _BATCH_SIZE):
            batch = texts[i : i + _BATCH_SIZE]
            response = self._client.embeddings.create(input=batch, model=self._model)
            for item in response.data:
                all_embeddings.append(item.embedding)
        return np.array(all_embeddings, dtype=np.float64)
