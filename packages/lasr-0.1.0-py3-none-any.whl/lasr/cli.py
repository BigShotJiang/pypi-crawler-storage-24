"""LASR CLI — thin Click wrapper around LaserPipeline."""

from __future__ import annotations

import json

import click

from lasr.types import LaserConfig


@click.group()
def main() -> None:
    """LASR (LASER) — Least Action Semantic Router."""


@main.command()
@click.argument("input_file", type=click.Path(exists=True))
@click.option("--alpha", type=float, default=2.5, show_default=True, help="Base boundary cost.")
@click.option("--rho", type=float, default=1.0, show_default=True, help="Tension coefficient.")
@click.option("--w-struct", type=float, default=0.25, show_default=True, help="Structural discount weight.")
@click.option("--w-bind", type=float, default=1.0, show_default=True, help="Coreference binding weight.")
@click.option("--w-disc", type=float, default=0.3, show_default=True, help="Discourse connective weight.")
@click.option("--l-min", type=int, default=5, show_default=True, help="Min sentences per chunk.")
@click.option("--l-max", type=int, default=30, show_default=True, help="Max sentences per chunk.")
@click.option(
    "--encoder",
    type=click.Choice(["sbert", "openai"]),
    default="sbert",
    show_default=True,
    help="Encoder backend.",
)
@click.option("--model", type=str, default=None, help="Override encoder model name.")
@click.option("--batch-size", type=int, default=128, show_default=True, help="Encoder batch size.")
@click.option("--device", type=str, default=None, help="Device for encoding (cpu, cuda, mps). Auto-detect if omitted.")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["json", "text"]),
    default="json",
    show_default=True,
    help="Output format.",
)
@click.option("--output", "-o", type=click.Path(), default=None, help="Output file (default: stdout).")
def chunk(
    input_file: str,
    alpha: float,
    rho: float,
    w_struct: float,
    w_bind: float,
    w_disc: float,
    l_min: int,
    l_max: int,
    encoder: str,
    model: str | None,
    batch_size: int,
    device: str | None,
    output_format: str,
    output: str | None,
) -> None:
    """Chunk a document into semantically optimal segments."""
    from lasr.pipeline import LaserPipeline

    config = LaserConfig(
        alpha_base=alpha,
        rho=rho,
        w_struct=w_struct,
        w_bind=w_bind,
        w_disc=w_disc,
        l_min=l_min,
        l_max=l_max,
        encoder=encoder,
        batch_size=batch_size,
        device=device,
    )
    if model:
        config.model_name = model

    text = open(input_file, encoding="utf-8").read()
    pipeline = LaserPipeline(config)
    chunks = pipeline.chunk(text)

    if output_format == "json":
        payload = [
            {
                "index": i,
                "text": c.text,
                "text_with_context": c.text_with_context,
                "start_char": c.start_char,
                "end_char": c.end_char,
                "num_sentences": c.num_sentences,
            }
            for i, c in enumerate(chunks)
        ]
        result = json.dumps(payload, indent=2, ensure_ascii=False)
    else:
        result = "\n---\n".join(c.text for c in chunks)

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(result)
        click.echo(f"Wrote {len(chunks)} chunks to {output}")
    else:
        click.echo(result)
