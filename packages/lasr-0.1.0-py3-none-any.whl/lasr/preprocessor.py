"""TextPreprocessor — split raw text into SentenceSpan objects with metadata."""

from __future__ import annotations

import re
from typing import List

from lasr.types import SentenceSpan

_HEADER_RE = re.compile(
    r"^\s*(?:#{1,6}\s|<h[1-6][^>]*>)",
    re.IGNORECASE,
)

_PARA_SPLIT_RE = re.compile(r"\n\n+")

_FALLBACK_SENT_RE = re.compile(r"(?<=[.!?])\s+")


def _load_spacy():
    """Attempt to load spaCy with the small English model."""
    try:
        import spacy

        return spacy.load("en_core_web_sm")
    except (ImportError, OSError):
        return None


class TextPreprocessor:
    """Splits raw text into ``SentenceSpan`` objects.

    Uses spaCy ``en_core_web_sm`` for sentence segmentation when available,
    otherwise falls back to a simple regex splitter.  In both cases the
    original inter-sentence whitespace and structural markers are preserved
    as ``raw_prefix`` / ``raw_suffix`` / ``is_header`` metadata on each span.

    Structural boundaries (double newlines) are respected *before* linguistic
    sentence splitting so that paragraph-level structure is never lost.
    """

    def __init__(self) -> None:
        self._nlp = _load_spacy()

    def split(self, text: str) -> List[SentenceSpan]:
        if not text or not text.strip():
            return []

        blocks = self._split_into_blocks(text)
        spans: List[SentenceSpan] = []

        for block_text, block_start in blocks:
            block_sents = self._split_block(block_text)

            for sent_offset, sent_end_offset in block_sents:
                abs_start = block_start + sent_offset
                abs_end = block_start + sent_end_offset
                sent_text = text[abs_start:abs_end].strip()
                if not sent_text:
                    continue

                content_start = abs_start + (abs_end - abs_start - len(text[abs_start:abs_end].lstrip()))
                content_end = abs_end - (abs_end - abs_start - len(text[abs_start:abs_end].rstrip()))

                spans.append(
                    SentenceSpan(
                        index=len(spans),
                        text=sent_text,
                        start_char=content_start,
                        end_char=content_end,
                        raw_prefix="",
                        raw_suffix="",
                        is_header=bool(_HEADER_RE.match(sent_text)),
                    )
                )

        self._fill_affixes(text, spans)
        return spans

    # ------------------------------------------------------------------
    # Paragraph-level splitting
    # ------------------------------------------------------------------

    @staticmethod
    def _split_into_blocks(text: str) -> List[tuple[str, int]]:
        """Split text on double-newline boundaries.

        Returns a list of ``(block_text, start_offset)`` pairs where
        *start_offset* is the character position of the block within the
        original *text*.
        """
        blocks: List[tuple[str, int]] = []
        prev_end = 0
        for m in _PARA_SPLIT_RE.finditer(text):
            block = text[prev_end : m.start()]
            if block.strip():
                blocks.append((block, prev_end))
            prev_end = m.end()
        tail = text[prev_end:]
        if tail.strip():
            blocks.append((tail, prev_end))
        return blocks

    # ------------------------------------------------------------------
    # Sentence-level splitting within a block
    # ------------------------------------------------------------------

    def _split_block(self, block_text: str) -> List[tuple[int, int]]:
        """Return sentence ``(start, end)`` offsets relative to *block_text*.

        If the block is a structural element (header), treat it as an
        indivisible unit — do not apply sentence segmentation.
        """
        stripped = block_text.strip()
        if _HEADER_RE.match(stripped):
            return [(0, len(block_text))]

        if self._nlp is not None:
            return self._split_block_spacy(block_text)
        return self._split_block_regex(block_text)

    def _split_block_spacy(self, block_text: str) -> List[tuple[int, int]]:
        doc = self._nlp(block_text)
        return [(sent.start_char, sent.end_char) for sent in doc.sents]

    @staticmethod
    def _split_block_regex(block_text: str) -> List[tuple[int, int]]:
        spans: List[tuple[int, int]] = []
        prev = 0
        for m in _FALLBACK_SENT_RE.finditer(block_text):
            spans.append((prev, m.start()))
            prev = m.end()
        if prev < len(block_text):
            spans.append((prev, len(block_text)))
        return spans

    # ------------------------------------------------------------------
    # Affix computation
    # ------------------------------------------------------------------

    @staticmethod
    def _fill_affixes(text: str, spans: List[SentenceSpan]) -> None:
        """Populate ``raw_prefix`` and ``raw_suffix`` using the gaps between
        adjacent content spans in the original text."""
        rebuilt: List[SentenceSpan] = []
        for i, span in enumerate(spans):
            if i == 0:
                prefix = text[: span.start_char]
            else:
                prefix = text[spans[i - 1].end_char : span.start_char]

            if i < len(spans) - 1:
                suffix = text[span.end_char : spans[i + 1].start_char]
            else:
                suffix = text[span.end_char :]

            rebuilt.append(
                SentenceSpan(
                    index=span.index,
                    text=span.text,
                    start_char=span.start_char,
                    end_char=span.end_char,
                    raw_prefix=prefix,
                    raw_suffix=suffix,
                    is_header=span.is_header,
                )
            )

        spans.clear()
        spans.extend(rebuilt)
