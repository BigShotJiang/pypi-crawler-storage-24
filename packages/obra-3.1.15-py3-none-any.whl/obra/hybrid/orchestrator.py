"""Hybrid Orchestrator for EPIC-HYBRID-001.

This module provides the client-side orchestration logic for the Unified Hybrid Architecture.
It connects to the server, dispatches actions to appropriate handlers, and manages the
orchestration loop.

Design Principle (from PRD):
    - Server owns the brain (decisions, orchestration logic)
    - Client owns the hands (execution, code access)

The HybridOrchestrator:
    1. Starts a session with the server
    2. Receives action instructions from the server
    3. Dispatches to appropriate handlers (derive, examine, revise, execute, review, fix)
    4. Reports results back to the server
    5. Repeats until completion or escalation

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 3
    - obra/api/protocol.py
    - obra/hybrid/handlers/*.py
"""

from __future__ import annotations

import logging
import os
import sys
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from http import HTTPStatus
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from pydantic import BaseModel

if TYPE_CHECKING:
    from obra.hybrid.dispatch.handler_factory import HandlerFactory

from obra.api import APIClient
from obra.api.protocol import (
    DEFAULT_REPORT_REVIEW_AGENT_TYPES,
    ActionType,
    CompletionNotice,
    EscalationDecision,
    EscalationNotice,
    ResumeContext,
    ServerAction,
    SessionPhase,
)
from obra.config import (
    get_watchdog_enabled,
    get_watchdog_max_silent_seconds,
    get_watchdog_stall_timeout,
)
from obra.constants import (
    HYBRID_POLLING_BACKOFF_MULTIPLIER,
    HYBRID_POLLING_BASE_DELAY_S,
    HYBRID_POLLING_MAX_DELAY_S,
)
from obra.constants import (
    MAX_POLLING_RETRIES as DEFAULT_MAX_POLLING_RETRIES,
)

# FEAT-PROCESS-LIFECYCLE-001: Process lifecycle management for subprocess cleanup
from obra.core.process_registry import (
    ProcessRegistry,
    create_process_registry_from_config,
)
from obra.display import console, print_info, print_warning
from obra.display.observability import ObservabilityConfig, ProgressEmitter
from obra.escalation.config import EscalationConfig
from obra.escalation.manager import EscalationManager
from obra.exceptions import (
    APIError,
    ConfigurationError,
    ConnectionError,
    ErrorContext,
    OrchestratorError,
)
from obra.hybrid.contract_validator import SessionContractValidator

# ISSUE-SAAS-042: Use HybridEventLogger for observability
# This is the SaaS-spec logger - always available in published package
from obra.hybrid.dispatch.dispatcher import ActionDispatcher
from obra.hybrid.error_handler import ErrorHandler
from obra.hybrid.event_logger import HybridEventLogger
from obra.hybrid.git_ops import GitOperations
from obra.hybrid.health_monitor import HealthMonitor
from obra.hybrid.llm_setup import LLMConfigurator
from obra.hybrid.plan_merger import PlanMerger
from obra.hybrid.progress_tracker import ProgressTracker
from obra.hybrid.project_context import ProjectContextBuilder
from obra.hybrid.runtime_bootstrap import (
    SessionDisplayContext,
    build_dispatcher,
    build_dispatcher_handler_factory,
    build_execution_state,
    build_handler_factory,
    build_observability_context,
    build_phase_control,
    resolve_from_config_bootstrap,
)
from obra.hybrid.session_flow_runtime import HybridSessionFlowRuntime
from obra.hybrid.runtime_state import HybridRuntimeState
from obra.hybrid.server_protocol import (
    ServerProtocol,
    normalize_plan_items_for_api,
    summarize_plan_items,
)

# FEAT-SESSION-GUARD-001: Session runtime guard (zombie prevention)
from obra.hybrid.session_guard import SessionGuard
from obra.messages import get_message

# Production logger for detailed derivation metrics and quality observability
from obra.observability.production_logger import ProductionLogger
from obra.review.config import ReviewConfig
from obra.utils.obra_home import get_runtime_dir

logger = logging.getLogger(__name__)

DEFAULT_MAX_USERPLAN_STEPS_LOGGED = 200
DEFAULT_MAX_DERIVED_ITEMS_LOGGED = 200
DEFAULT_MAX_PLAN_TITLE_LEN = 300
PLAN_SNAPSHOT_DIRNAME = "plan_snapshots"

# ISSUE-CLI-012: Maximum polling retry attempts before circuit breaker triggers
# Set to 5 per industry best practices (AWS, Google Cloud, Stripe all use 3-5)
# Observed behavior showed 7 attempts before manual termination
MAX_POLLING_RETRIES = DEFAULT_MAX_POLLING_RETRIES

# Bypass mode severity classification.
# Safety overrides relax quality gates or validation — these warrant a prominent Warning.
# All other modes (workflow modifiers, continuation optimizations) are informational.
_SAFETY_OVERRIDE_MODES: frozenset[str] = frozenset({
    "planning_permissive",
    "permissive_planning",
    "permissive",
    "skip_quality_check",
    "skip_tier_check",
    "skip_complexity_check",
})

_PERMISSIVE_PLANNING_MODES: frozenset[str] = frozenset({
    "planning_permissive",
    "permissive_planning",
    "permissive",
})



# ---------------------------------------------------------------------------
# Value objects — group logically related __init__ attributes
# ---------------------------------------------------------------------------


@dataclass
class TraceContext:
    """Telemetry trace identifiers for the current session."""

    trace_id: str | None = None
    pipeline_start_time: float | None = None
    pipeline_span_id: str | None = None
    phase_span_id: str | None = None
    component: str = "hybrid_client"


@dataclass
class InvocationState:
    """Per-invocation mutable counters and identifiers."""

    was_interrupted: bool = False
    items_completed_this_invocation: int = 0
    invocation_id: str | None = None
    invocation_index: int | None = None
    invocation_start_time: float | None = None

    def reset(self) -> None:
        """Reset all fields to their defaults."""
        self.was_interrupted = False
        self.items_completed_this_invocation = 0
        self.invocation_id = None
        self.invocation_index = None
        self.invocation_start_time = None


@dataclass
class WatchdogState:
    """Watchdog timer configuration and runtime state."""

    enabled: bool = False
    stall_timeout: float = 300.0
    max_silent_seconds: float = 600.0
    last_event_time: float = field(default_factory=time.time)
    handler_active: bool = False
    last_action_payload: dict[str, Any] = field(default_factory=dict)


@dataclass
class RefinementState:
    """Refinement-loop cycle counters and parallel batch metrics."""

    cycle_count: int = 0
    start_time: float | None = None
    last_blocking_count: int = 0
    parallel_examine_speedups: list[float] = field(default_factory=list)
    parallel_examine_stragglers: list[float] = field(default_factory=list)
    parallel_examine_metrics_by_cycle: dict[int, dict[str, float]] = field(
        default_factory=dict
    )
    parallel_revise_speedups: list[float] = field(default_factory=list)
    parallel_max_straggler: float = 1.0


# P0-2: Module-level callback for force-quit terminal event emission.
# Set when an orchestrator session starts; called by CLI before os._exit().
# os._exit() bypasses atexit handlers, so this explicit hook is required.
_force_quit_terminal_callback: Callable[[], None] | None = None


def emit_force_quit_terminal_event() -> None:
    """Emit session_interrupted event before os._exit() force-quit.

    Called by the CLI signal handler immediately before os._exit(130).
    The atexit handler does NOT fire on os._exit(), so this explicit
    call is the only way to ensure dashboard reconciliation.
    """
    global _force_quit_terminal_callback
    if _force_quit_terminal_callback is not None:
        try:
            _force_quit_terminal_callback()
        except Exception:
            pass  # Best-effort — must not block force-quit


class HybridOrchestrator:
    """Client-side orchestrator for Obra hybrid architecture.

    ## Architecture

    This orchestrator implements the **client-side** of the Obra SaaS hybrid
    architecture (ADR-035):

    - **Server**: Provides orchestration decisions, action instructions, and validation
    - **Client**: Builds prompts locally, executes LLM/agents, reports results

    ## Handler Responsibilities

    Each handler (`DeriveHandler`, `ExamineHandler`, etc.) implements client-side logic:
    1. Receives action request from server (objective, plan items, issues, etc.)
    2. Builds prompts entirely client-side
    3. Gathers tactical context locally (files, git, errors)
    4. Invokes LLM or agent locally
    5. Reports results back to server for validation

    Note: The marker-based prompt enrichment described in ADR-035 is an aspirational
    design. The current implementation builds prompts entirely client-side.

    ## Privacy Model

    Tactical context (file contents, git messages, errors) stays client-side.
    Server never receives file contents or local project details.

    See: docs/decisions/ADR-035-unified-hybrid-architecture.md
    """

    def __init__(
        self,
        client: APIClient,
        working_dir: Path | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        on_escalation: Callable[[EscalationNotice], EscalationDecision] | None = None,
        on_stream: Callable[[str, str], None] | None = None,
        review_config: ReviewConfig | None = None,
        defaults_json: bool = False,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
    ) -> None:
        """Initialize HybridOrchestrator.

        Args:
            client: APIClient for server communication
            working_dir: Working directory for file operations
            on_progress: Optional callback for progress updates (action, payload)
            on_escalation: Optional callback for handling escalations
            on_stream: Optional callback for LLM streaming chunks (event_type, content)
            review_config: Review configuration (selection/modifiers/output)
            defaults_json: Whether to output JSON defaults
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
        """
        self._client = client
        # GIT-HARD-001 S2.T3: Track if working_dir was explicitly provided (for Inbox exemption)
        self._working_dir_explicit = working_dir is not None
        self._working_dir = working_dir or Path.cwd()
        self._runtime_state = HybridRuntimeState(
            session_display_context=SessionDisplayContext()
        )
        self._trace = TraceContext()
        self._project_name: str | None = None
        self._on_progress = on_progress
        self._on_escalation = on_escalation
        self._on_stream = on_stream
        self._bypass_notice_keys: set[str] = set()  # Dedupe bypass warnings per phase/session
        self._session_start_contract_warnings: list[str] = []
        self._defaults_json = defaults_json
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        # REFACTOR-SERVER-PROTOCOL-001 S1.T0: All dedup state and resume timestamp
        # moved to ServerProtocol. Tier 2 (item/phase) sets are exposed via delegation
        # properties below; Tier 1 (event-ID) sets are exclusively on ServerProtocol.
        self._config: dict[str, Any] | None = None
        self._domain: Any = None
        try:
            from obra.domains.loader import load_domain

            self._domain = load_domain("software")
        except Exception:
            self._domain = None

        # REFACTOR-SERVER-PROTOCOL-001 S0.T3: ServerProtocol created here;
        # _progress_cursor is a delegation property (see below the class init block).
        # Callbacks use lambdas so test patches on orchestrator attributes are picked up
        # at call time (e.g. patch.object(orchestrator, "_log_session_event") works).
        self._server_protocol = ServerProtocol(
            session_id=self._runtime_state.session_id or "",
            request_fn=lambda *a, **kw: self._request_with_observability(*a, **kw),
            emit_progress=self._emit_progress,
            log_session_event=lambda *a, **kw: self._log_session_event(*a, **kw),
            on_progress=(
                (lambda *a, **kw: self._on_progress(*a, **kw))
                if self._on_progress is not None
                else None
            ),
            on_server_progress=lambda *a, **kw: self._handle_server_progress_event(
                *a, **kw
            ),
            progress_emitter=self._progress_emitter,
            config=self._config,
            # REFACTOR-SERVER-PROTOCOL-001 S2.T5: injectable callables for payload builders
            # Plan normalization and summarization relocated to server_protocol module.
            normalize_plan_items_fn=lambda items: normalize_plan_items_for_api(
                items,
                allowed_keys=self._get_derived_plan_api_keys(),
                log_event=getattr(self, "_log_event", None),
                session_id=self._runtime_state.session_id,
                trace_id=self._trace.trace_id,
                phase_span_id=self._trace.phase_span_id,
                production_logger=self._production_logger,
            ),
            summarize_plan_items_fn=lambda items: summarize_plan_items(items),
            merge_rederivation_fn=lambda **kw: self._plan_merger.merge_plan_items_for_rederivation(**kw),
            update_userplan_steps_fn=lambda **kw: self._client.update_userplan_steps_status_batch(**kw),
        )

        # Handler registry - pre-allocated so tests can pre-populate before factory init.
        # Passed as handlers_cache to HandlerFactory so both share the same dict object.
        self._handlers: dict[ActionType | tuple[ActionType, str], Any] = {}

        # Runtime collaborators are prepared explicitly before use and rebuilt when
        # session-start state changes.
        self._handler_factory: HandlerFactory | None = None

        # Action dispatcher is prepared explicitly alongside the handler factory.
        self._dispatcher: ActionDispatcher | None = None

        # LLM config - set by from_config() or defaults to None
        self._llm_config: dict[str, Any] | None = None

        self._imported_plan_context: dict[str, Any] | None = None

        # P1-2: Track in-flight client requests for shutdown reconciliation
        self._inflight_client_requests: set[str] = set()

        # Escalation lifecycle management (REFACTOR-ESCALATION-001)
        self._escalation_manager = EscalationManager(
            log_session_event=self._log_session_event,
            progress_emitter=self._progress_emitter,
            on_escalation=self._on_escalation,
            config=EscalationConfig.from_config(self._config or {}),
            fix_result_history=self._runtime_state.fix_result_history,
        )

        # FEAT-SESSION-CLOSEOUT-001: Invocation tracking for cumulative runtime
        self._invocation = InvocationState()

        # Refinement cycle tracking and parallelization telemetry
        self._refinement = RefinementState()

        # REFACTOR-PLAN-MERGE-001: Plan merging module delegation
        self._plan_merger = PlanMerger(
            working_dir=self._working_dir,
            llm_config=self._llm_config or {},
            progress_emitter=self._progress_emitter,
            log_event=self._log_session_event,
            trace_id=self._trace.trace_id,
        )
        self._project_context_builder = ProjectContextBuilder(
            working_dir=self._working_dir,
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        self._contract_validator = SessionContractValidator(
            logger=logger,
            safety_override_modes=_SAFETY_OVERRIDE_MODES,
            console=console,
            # Resolve through module globals at call time so tests patching
            # obra.hybrid.orchestrator.print_warning/print_info still intercept.
            print_warning=lambda message: print_warning(message),
            print_info=lambda message: print_info(message),
        )

        # S0.T7: Track verification tools for mid-session Story 0 injection
        # If FIX needs verification tools and none are available, re-run Story 0
        # ISSUE-SAAS-042: Initialize HybridEventLogger for observability
        # This is the SaaS-spec logger - always available in published package
        self._event_logger = HybridEventLogger()
        self._event_logger.set_component(self._trace.component)

        # Production logger for detailed derivation/quality metrics
        # Writes to resolved runtime logs/production.jsonl with structured events
        self._production_logger: ProductionLogger | None = None

        # FEAT-REFINEMENT-PARALLEL-001 S3.T4: C9 dependency validation cache.
        # Stores SHA256 of the dependency graph to skip redundant validation.
        self._c9_graph_hash: str | None = None

        # Review configuration for handler creation
        # Use from_cli_and_config to respect feature gates (quality_automation.agents.*)
        self._review_config = review_config or ReviewConfig.from_cli_and_config(
            project_path=Path(self._working_dir) if self._working_dir else None
        )
        self._server_review_agent_types: set[str] = set(
            DEFAULT_REPORT_REVIEW_AGENT_TYPES
        )

        # FEAT-PROCESS-LIFECYCLE-001: Process registry for subprocess cleanup
        # Set by from_config() based on orchestration.process_cleanup config
        self._process_registry: ProcessRegistry | None = None

        # ISSUE-HYBRID-003: Session watchdog for stall detection
        self._watchdog = WatchdogState(
            enabled=get_watchdog_enabled(),
            stall_timeout=get_watchdog_stall_timeout(),
            max_silent_seconds=get_watchdog_max_silent_seconds(),
            last_event_time=time.time(),
        )

        # FEAT-SESSION-GUARD-001: Session runtime guard (zombie prevention)
        self._session_guard: SessionGuard | None = None

        # REFACTOR-ORCH-EXTRACT-001: Git operations extracted module
        self._git_ops = GitOperations(
            working_dir=self._working_dir,
            session_id_getter=lambda: self._runtime_state.session_id,
            get_session_files=lambda field: self._get_session_files(field),
            llm_config_getter=lambda: self._llm_config,
            working_dir_explicit=self._working_dir_explicit,
            domain=lambda: self._domain,
        )

        # REFACTOR-ORCH-EXTRACT-001: Health monitoring extracted module
        self._health_monitor = HealthMonitor(
            watchdog=self._watchdog,
            runtime_state=self._runtime_state,
            session_guard_getter=lambda: self._session_guard,
            config_getter=lambda: self._config,
            event_logger_getter=lambda: self._event_logger,
            working_dir_getter=lambda: self._working_dir,
            invocation=self._invocation,
        )

        # REFACTOR-ORCH-EXTRACT-001: Error and interrupt handling extracted module
        self._error_handler = ErrorHandler(
            invocation=self._invocation,
            trace=self._trace,
            watchdog=self._watchdog,
            refinement=self._refinement,
            event_logger=self._event_logger,
            runtime_state=self._runtime_state,
            was_escalated_getter=lambda: self._was_escalated,
            locally_completed_phases=self._server_protocol._locally_completed_phases,
            emit_progress=self._emit_progress,
            session_completed_logged_getter=lambda: self._event_logger.session_completed_logged,
            session_interrupted_logged_getter=lambda: self._event_logger.session_interrupted_logged,
            session_interrupted_logged_setter=lambda v: setattr(self._event_logger, "session_interrupted_logged", v),
        )

        # REFACTOR-ORCH-EXTRACT-001: Progress and phase tracking extracted module
        self._progress_tracker = ProgressTracker(
            invocation=self._invocation,
            trace=self._trace,
            refinement=self._refinement,
            event_logger=self._event_logger,
            runtime_state=self._runtime_state,
            locally_completed_items=self._server_protocol._locally_completed_items,
            locally_completed_phases=self._server_protocol._locally_completed_phases,
            locally_started_phases=self._server_protocol._locally_started_phases,
            was_escalated_getter=lambda: self._was_escalated,
            emit_progress=self._emit_progress,
            log_session_event=lambda evt, **kw: self._log_session_event(evt, **kw),
        )

        # REFACTOR-ORCH-EXTRACT-001: LLM configuration extracted module
        self._llm_configurator = LLMConfigurator(
            llm_config_getter=lambda: self._llm_config,
            server_review_agent_types=self._server_review_agent_types,
            working_dir=self._working_dir,
            build_error_context=lambda **kw: self._error_handler._build_error_context(**kw),
            runtime_state=self._runtime_state,
        )
        self._session_flow_runtime = self._build_session_flow_runtime()

        # REFACTOR-HANDLER-ORCHESTRATOR-001 S5: Session lifecycle collaborator
        from obra.hybrid._session_lifecycle import HybridSessionLifecycle

        self._session_lifecycle = HybridSessionLifecycle(
            runtime_state_getter=lambda: self._runtime_state,
            event_logger_getter=lambda: self._event_logger,
            error_handler_getter=lambda: self._error_handler,
            watchdog_getter=lambda: self._watchdog,
            emit_progress=self._emit_progress,
        )

        logger.debug(f"HybridOrchestrator initialized for {self._working_dir}")

    @property
    def _was_escalated(self) -> bool:
        """Whether this session ever experienced an escalation (permanent flag).

        Delegates to EscalationManager.was_escalated which tracks the
        permanent ``_ever_escalated`` flag in the state machine.
        """
        return self._escalation_manager.was_escalated


    def _record_invocation(
        self,
        invocation_id: str,
        started_at: float,
        duration_seconds: float,
        termination: str,
        phase_reached: str,
        items_completed: int,
    ) -> None:
        """Record an invocation to session metadata — delegates to HybridSessionLifecycle."""
        self._session_lifecycle.record_invocation(
            invocation_id=invocation_id,
            started_at=started_at,
            duration_seconds=duration_seconds,
            termination=termination,
            phase_reached=phase_reached,
            items_completed=items_completed,
        )

    def _get_session_files(self, field: str) -> list[str]:
        """Get list of files created or modified during this session.

        FEAT-SESSION-CLOSEOUT-001 S4.T1: Extract session files for closeout display.

        Args:
            field: Either "added" (created files) or "modified" (modified files).

        Returns:
            Sorted list of file paths, or empty list if unavailable.
        """
        from obra.hybrid.handlers.execute import ExecuteHandler

        execute_handler = self._handlers.get(ActionType.EXECUTE)
        if isinstance(execute_handler, ExecuteHandler):
            changes = execute_handler.get_session_file_changes()
            return sorted(getattr(changes, field))
        return []

    def _log_session_event(self, event_type: str, **kwargs: Any) -> None:
        """Log hybrid session event — delegates to HybridSessionLifecycle."""
        self._session_lifecycle.log_session_event(event_type, **kwargs)

    def log_closeout_rendered(
        self,
        banner_mode: str,
        *,
        state: str,
        quality_score: float | None,
        quality_status: str,
        epics_completed: int,
        epics_total: int,
        stories_completed: int,
        stories_total: int,
        tasks_completed: int,
        tasks_total: int,
    ) -> None:
        """Record closeout rendering details for telemetry correlation.

        Args:
            banner_mode: Banner variant used by CLI closeout rendering.
            state: Session termination state shown in closeout.
        """
        self._event_logger.log_closeout_rendered(
            banner_mode,
            state=state,
            quality_score=quality_score,
            quality_status=quality_status,
            epics_completed=epics_completed,
            epics_total=epics_total,
            stories_completed=stories_completed,
            stories_total=stories_total,
            tasks_completed=tasks_completed,
            tasks_total=tasks_total,
        )

    def _cleanup_story0_containers(self) -> None:
        """Cleanup Story 0 Docker containers on session completion."""
        if not self._runtime_state.session_id:
            return
        try:
            from obra.config.loaders import load_layered_config
            from obra.hybrid.handlers.story0 import cleanup_containers

            config = self._config
            if config is None:
                config, _, _ = load_layered_config(include_defaults=True)
                self._config = config
            if not config.get("story0", {}).get("docker", {}).get("cleanup_on_complete", True):
                return
            cleanup_containers(self._runtime_state.session_id)
        except Exception as exc:
            logger.debug("Story 0 cleanup failed: %s", exc)

    def _with_graceful_degradation(
        self,
        operation_name: str,
        operation: Callable[[], Any],
        default_result: Any,
    ) -> Any:
        """Execute operation with graceful degradation on failure.

        FEAT-RESILIENCE-P2-001: Graceful degradation wrapper for non-critical operations.
        Use this for operations like metrics emission and optional logging where failures
        should not abort the session.

        Args:
            operation_name: Name of the operation for logging
            operation: Callable that performs the operation
            default_result: Value to return if operation fails

        Returns:
            Result of operation if successful, otherwise default_result

        Example:
            >>> result = self._with_graceful_degradation(
            ...     "emit_metrics",
            ...     lambda: self._emit_quality_metrics(scores),
            ...     default_result=None
            ... )
        """
        try:
            return operation()
        except Exception as e:
            logger.warning("Operation %s failed in degraded mode: %s", operation_name, str(e))
            self._runtime_state.degraded_mode = True
            return default_result

    def _request_with_observability(
        self,
        method: str,
        endpoint: str,
        json: dict[str, Any] | None = None,
        response_schema: type[BaseModel] | None = None,
    ) -> dict[str, Any]:
        """Make API request with observability timing events."""
        request_id = uuid.uuid4().hex
        start_time = time.time()
        start_monotonic = time.perf_counter()
        start_dt = datetime.now(UTC)
        start_iso = start_dt.isoformat()
        parent_span_id = self._event_logger.subphase_span_id or self._trace.phase_span_id or self._trace.pipeline_span_id
        self._log_session_event(
            "client_request_started",
            request_id=request_id,
            endpoint=endpoint,
            method=method,
            client_request_start_ts=start_iso,
            span_id=self._trace.pipeline_span_id,
            parent_span_id=parent_span_id,
        )
        self._inflight_client_requests.add(request_id)
        try:
            response = self._client._request(
                method,
                endpoint,
                json=json,
                response_schema=response_schema,
                request_id=request_id,
                client_request_start_ts=start_time,
            )
            status = "success"
            return cast(dict[str, Any], response)
        except Exception as e:
            status = "error"
            error_message = str(e)
            # Compute response_ts from start_dt + monotonic duration to avoid
            # wall-clock sensitivity (NTP adjustments can invert timestamps).
            duration_s = time.perf_counter() - start_monotonic
            response_ts = (start_dt + timedelta(seconds=duration_s)).isoformat()
            self._log_session_event(
                "client_request_completed",
                request_id=request_id,
                endpoint=endpoint,
                method=method,
                client_request_start_ts=start_iso,
                client_response_ts=response_ts,
                duration_ms=max(0, int(duration_s * 1000)),
                status=status,
                error_class=type(e).__name__,
                error_message=error_message,
                span_id=self._trace.pipeline_span_id,
                parent_span_id=parent_span_id,
            )
            self._inflight_client_requests.discard(request_id)
            # Attach error context to ObraError instances for debugging
            from obra.exceptions import ObraError

            if isinstance(e, ObraError) and not getattr(e, "error_context", None):
                e.error_context = self._error_handler._build_error_context(action=endpoint)
            raise
        finally:
            if status == "success":
                # Compute response_ts from start_dt + monotonic duration to
                # guarantee response_ts >= start_ts regardless of clock skew.
                duration_s = time.perf_counter() - start_monotonic
                response_ts = (start_dt + timedelta(seconds=duration_s)).isoformat()
                self._log_session_event(
                    "client_request_completed",
                    request_id=request_id,
                    endpoint=endpoint,
                    method=method,
                    client_request_start_ts=start_iso,
                    client_response_ts=response_ts,
                    duration_ms=max(0, int(duration_s * 1000)),
                    status=status,
                    span_id=self._trace.pipeline_span_id,
                    parent_span_id=parent_span_id,
                )
                self._inflight_client_requests.discard(request_id)

    @classmethod
    def from_config(
        cls,
        client: APIClient | None = None,
        working_dir: Path | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        on_escalation: Callable[[EscalationNotice], EscalationDecision] | None = None,
        on_stream: Callable[[str, str], None] | None = None,
        domain: str | None = None,
        domain_resolution: dict[str, Any] | None = None,
        impl_provider: str | None = None,
        impl_model: str | None = None,
        reasoning_level: str | None = None,
        review_config: ReviewConfig | None = None,
        bypass_modes: list[str] | None = None,
        defaults_json: bool = False,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
        skip_git_check: bool | None = None,
        auto_init_git: bool | None = None,
        planning_mode: str | None = None,
        config_override: dict[str, Any] | None = None,
        session_display: SessionDisplayContext | None = None,
        preflight_results: dict[str, Any] | None = None,
        effective_map: dict[str, Any] | None = None,
        verbose: int = 0,
    ) -> HybridOrchestrator:
        """Create HybridOrchestrator from configuration.

        Loads APIClient from ~/.obra/config-layers/01-user.yaml.

        Args:
            client: Optional pre-authenticated APIClient override
            working_dir: Working directory for file operations
            on_progress: Optional progress callback
            on_escalation: Optional escalation callback
            on_stream: Optional streaming callback for LLM output
            domain: Optional domain module override
            impl_provider: Optional implementation provider override (S5.T1)
            impl_model: Optional implementation model override (S5.T1)
            reasoning_level: Optional reasoning level override (S5.T1)
            review_config: Optional review configuration to pass to handlers
            bypass_modes: Optional list of validation modes to bypass
            defaults_json: Whether to output JSON defaults
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
            skip_git_check: Optional CLI flag to skip git validation (overrides config)
            auto_init_git: Optional CLI flag to auto-init git (overrides config)
            planning_mode: Optional planning mode override (auto, quick, standard, thorough)
            config_override: Optional config dict to replace the loaded config (e.g. story0 overrides)
            session_display: Optional typed session-display context for CLI banner data
            preflight_results: Legacy preflight results input for session display
            effective_map: Legacy effective-map input retained for compatibility
            verbose: Legacy verbosity input for session display

        Returns:
            Configured HybridOrchestrator

        Raises:
            ConfigurationError: If configuration is invalid or missing
        """
        _ = effective_map

        if client is None:
            try:
                client = APIClient.from_config()
            except ConfigurationError:
                raise
            except Exception as e:
                msg = f"Failed to create API client: {e}"
                raise ConfigurationError(msg) from e

        orchestrator = cls(
            client=client,
            working_dir=working_dir,
            on_progress=on_progress,
            on_escalation=on_escalation,
            on_stream=on_stream,
            review_config=review_config,
            defaults_json=defaults_json,
            observability_config=observability_config,
            progress_emitter=progress_emitter,
        )

        bootstrap = resolve_from_config_bootstrap(
            working_dir=working_dir,
            domain=domain,
            domain_resolution=domain_resolution,
            impl_provider=impl_provider,
            impl_model=impl_model,
            reasoning_level=reasoning_level,
            bypass_modes=bypass_modes,
            skip_git_check=skip_git_check,
            auto_init_git=auto_init_git,
            planning_mode=planning_mode,
            config_override=config_override,
            session_display=session_display,
            preflight_results=preflight_results,
            verbose=verbose,
        )

        # S5.T2: Store resolved config for handler creation
        orchestrator._llm_config = bootstrap.llm_config
        orchestrator._runtime_state.bypass_modes = bootstrap.bypass_modes
        orchestrator._runtime_state.planning_mode = bootstrap.planning_mode
        orchestrator._config = bootstrap.config
        # Re-inject real config into EscalationManager and ServerProtocol, which
        # both received None (→ {}) at __init__ time before config was loaded.
        orchestrator._escalation_manager._config = EscalationConfig.from_config(
            orchestrator._config
        )
        orchestrator._server_protocol._config = orchestrator._config
        orchestrator._domain = bootstrap.domain
        orchestrator._runtime_state.domain_resolution = bootstrap.domain_resolution
        orchestrator._runtime_state.session_display_context = bootstrap.session_display_context
        orchestrator.startup()
        return orchestrator

    def startup(self) -> None:
        """Run side-effect initialization (signal handlers, cleanup, atexit).

        Separated from from_config() so construction and initialization are
        distinct lifecycle phases. Called automatically by from_config() before
        returning, so existing callers do not need to change.
        """
        story0_config = self._config.get("story0", {}) if self._config else {}
        if story0_config.get("docker", {}).get("orphan_check_on_start", True):
            try:
                from obra.hybrid.handlers.story0 import check_orphaned_containers

                from obra.cli.run_support.interaction_mode import current_mode_is_interactive

                check_orphaned_containers(is_tty=current_mode_is_interactive())
            except Exception as exc:
                logger.debug("Story 0 orphan check failed: %s", exc)

        self._process_registry = create_process_registry_from_config(self._config or {})
        if self._process_registry:
            self._process_registry.install_signal_handlers()
            self._process_registry.register_atexit()
            logger.debug("ProcessRegistry initialized for subprocess lifecycle management")

    @property
    def client(self) -> APIClient:
        """Get the API client."""
        return self._client

    @property
    def working_dir(self) -> Path:
        """Get the working directory."""
        return self._working_dir

    def _handle_server_progress_event(
        self,
        event_type: str,
        payload: dict[str, Any],
    ) -> None:
        """Handle internal server progress events regardless of UI callbacks."""
        if event_type != "plan_snapshot":
            return
        self._maybe_refresh_business_workflow_plan(payload)

    def _maybe_refresh_business_workflow_plan(
        self,
        payload: dict[str, Any],
    ) -> None:
        """Refresh local WORKFLOW_PLAN.json after accepted business decomposition."""
        source = str(payload.get("source") or "").strip()
        mode = str(payload.get("mode") or "").strip().lower()
        if source != "decomposition_revise_accepted" or mode != "authoritative":
            return

        resolved_domain = (
            getattr(getattr(self._runtime_state, "domain_resolution", None), "domain_id", None)
            or getattr(self._domain, "domain_id", None)
            or getattr(self._domain, "name", None)
        )
        if str(resolved_domain or "").strip().lower() != "business":
            return

        plan_items = payload.get("plan_items")
        if not isinstance(plan_items, list) or not plan_items:
            return

        try:
            from obra_business.compilation.runtime_plan_export import (
                refresh_workflow_plan_export,
            )

            refresh_workflow_plan_export(
                workflow_dir=self._working_dir,
                authoritative_plan_items=plan_items,
            )
        except Exception:
            logger.warning(
                "Failed to refresh business WORKFLOW_PLAN.json after accepted decomposition revision",
                exc_info=True,
            )

    @property
    def session_id(self) -> str | None:
        """Get the current session ID."""
        return self._runtime_state.session_id

    @property
    def degraded_mode(self) -> bool:
        """Check if orchestrator is running in degraded mode.

        Returns:
            True if non-critical operations have failed and degraded mode is active.
        """
        return self._runtime_state.degraded_mode

    def is_online(self) -> bool:
        """Check if the server is reachable.

        Returns:
            True if server is reachable, False otherwise.
        """
        try:
            self._client.health_check()
            return True
        except APIError as e:
            if e.status_code == HTTPStatus.UNAUTHORIZED.value:
                logger.warning("Health check failed: Authentication invalid (401) - %s", e)
            elif e.status_code == HTTPStatus.FORBIDDEN.value:
                logger.warning("Health check failed: Access forbidden (403) - %s", e)
            else:
                logger.warning(
                    "Health check failed: API error (status %s) - %s",
                    e.status_code or "unknown",
                    e,
                )
            return False
        except Exception as e:
            logger.warning(
                "Health check failed: %s - %s",
                type(e).__name__,
                e,
            )
            return False

    def _ensure_online(self) -> None:
        """Ensure server is reachable.

        Raises:
            ConnectionError: If server is not reachable
            APIError: If client version is unsupported by server policy
        """
        if not self.is_online():
            raise ConnectionError()
        # Fail fast on incompatible client versions before session bootstrap.
        version_info = self._client.assert_client_version_supported()
        self._llm_configurator._refresh_server_review_capabilities(version_info)
        self._server_review_agent_types = self._llm_configurator._server_review_agent_types

    @property
    def effective_llm_map(self) -> dict[str, dict[str, str]]:
        """The effective LLM map built during session initialization."""
        return getattr(self, "_effective_llm_map", {})

    @property
    def preflight_results(self) -> dict[str, dict[str, str | None]]:
        """Provider preflight check results."""
        return getattr(self, "_preflight_results", {})

    def _emit_runtime_banner(self) -> None:
        """Emit a one-line banner showing backend target and log file paths.

        Helps operators verify whether the session is hitting the emulator
        or production, and where to find telemetry files.
        """
        import os

        runtime_dir = get_runtime_dir()
        hybrid_log = runtime_dir / "logs" / "hybrid.jsonl"
        production_log = runtime_dir / "logs" / "production.jsonl"
        api_url = os.environ.get("OBRA_API_BASE_URL", "")
        backend = api_url if api_url else "production"

        console.print(f"Backend: [cyan]{backend}[/cyan]")
        console.print(
            f"Logs: [dim]{hybrid_log}[/dim]  |  [dim]{production_log}[/dim]"
        )

    def _get_project_context(self) -> dict[str, Any]:
        """Gather minimal project context (no code content)."""
        self._project_context_builder.update_runtime(
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        return self._project_context_builder.build()

    def _build_imported_plan_workflow_artifact_refs(self) -> list[dict[str, Any]]:
        """Translate imported-plan workflow identity into canonical workflow refs."""
        self._project_context_builder.update_runtime(
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        return self._project_context_builder.build_imported_plan_workflow_artifact_refs()

    def _build_imported_plan_execution_input_refs(self) -> list[dict[str, Any]]:
        """Translate imported-plan execution input metadata into canonical refs."""
        self._project_context_builder.update_runtime(
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        return self._project_context_builder.build_imported_plan_execution_input_refs()

    def _build_pipeline_config_execution_input_refs(
        self,
        pipeline_config: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        """Infer execution-input refs from active pipeline runner configuration."""
        return self._project_context_builder.build_pipeline_config_execution_input_refs(
            pipeline_config
        )

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        """Emit progress update.

        Args:
            action: Action being performed
            payload: Action payload
        """
        if self._on_progress:
            try:
                self._on_progress(action, payload)
            except Exception as e:
                logger.warning(
                    f"Progress callback failed for action '{action}': {e}",
                    exc_info=True,
                )

    def _display_bypass_notices(self, server_action: ServerAction) -> None:
        """Render bypass-related warnings for the current action."""
        self._contract_validator.display_bypass_notices(
            server_action,
            current_phase=self._runtime_state.current_phase.value if self._runtime_state.current_phase else None,
            bypass_notice_keys=self._bypass_notice_keys,
            session_id=self._runtime_state.session_id,
            is_skip_tracking_enabled=self._is_skip_tracking_enabled,
            validate_bypass_modes_applied=self._validate_bypass_modes_applied,
        )

    def _validate_bypass_modes_applied(self, server_action: ServerAction) -> list[str]:
        """Check if requested bypass modes were acknowledged by server.

        Warns user if any requested modes were not activated. This helps detect
        bugs where CLI flags are parsed but not transmitted to the server.

        Args:
            server_action: Server response containing bypass_modes_active

        Returns:
            List of modes that were requested but not activated
        """
        # Only validate once per session
        if self._runtime_state.bypass_modes_validated:
            return []
        self._runtime_state.bypass_modes_validated = True

        return self._contract_validator.validate_bypass_modes_applied(
            server_action,
            requested_bypass_modes=self._runtime_state.bypass_modes,
        )

    def _is_skip_tracking_enabled(self, source_key: str) -> bool:
        config = self._config or {}
        skip_config = config.get("orchestration", {}).get("skip_tracking", {})
        return bool(skip_config.get("enabled", True)) and bool(
            skip_config.get("sources", {}).get(source_key, True)
        )

    def _should_prompt_for_defaults(self) -> bool:
        """Determine if we should prompt the user for defaults confirmation."""
        if self._defaults_json:
            return False

        from obra.hybrid.interaction_policy import check_interactive_or_auto_accept

        return check_interactive_or_auto_accept("proposed-defaults confirmation")

    # ------------------------------------------------------------------
    # FEAT-REFINEMENT-PARALLEL-001: Parallel batch fan-out
    # ------------------------------------------------------------------

    def _handle_parallel_examine_batches(
        self,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Fan out examination batches to parallel ExamineHandler workers."""
        result = self._plan_merger._parallel.handle_parallel_examine_batches(
            payload,
            role_llm_config=self._llm_configurator._get_role_llm_config(ActionType.EXAMINE),
            refinement_cycle_count=self._refinement.cycle_count,
            straggler_threshold=self._health_monitor._get_straggler_alert_threshold(),
        )
        # Sync metrics back for backward compatibility with tests that read _parallel_* attrs.
        self._refinement.parallel_examine_speedups = list(self._plan_merger.metrics.examine_speedups)
        self._refinement.parallel_examine_stragglers = list(self._plan_merger.metrics.examine_stragglers)
        self._refinement.parallel_examine_metrics_by_cycle = dict(self._plan_merger.metrics.examine_metrics_by_cycle)
        self._refinement.parallel_max_straggler = self._plan_merger.metrics.max_straggler
        return result

    # ------------------------------------------------------------------
    # FEAT-REFINEMENT-PARALLEL-001: Parallel revision batch fan-out
    # ------------------------------------------------------------------

    def _handle_parallel_revise_batches(
        self,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Fan out revision batches to parallel ReviseHandler workers."""
        # Cross-phase sync: push orchestrator examine metrics into PlanMerger before revise
        # so the parallelization_cycle_summary telemetry can read cycle-matched examine data.
        self._plan_merger.metrics.examine_metrics_by_cycle = self._refinement.parallel_examine_metrics_by_cycle
        self._plan_merger.metrics.examine_speedups = list(self._refinement.parallel_examine_speedups)
        self._plan_merger.metrics.examine_stragglers = list(self._refinement.parallel_examine_stragglers)
        result = self._plan_merger._parallel.handle_parallel_revise_batches(
            payload,
            role_llm_config=self._llm_configurator._get_role_llm_config(ActionType.REVISE),
            refinement_cycle_count=self._refinement.cycle_count,
            c9_graph_hash=self._c9_graph_hash,
            straggler_threshold=self._health_monitor._get_straggler_alert_threshold(),
        )
        # Write back state from result.
        self._c9_graph_hash = result.get("c9_graph_hash", self._c9_graph_hash)
        self._refinement.parallel_revise_speedups = list(self._plan_merger.metrics.revise_speedups)
        self._refinement.parallel_max_straggler = self._plan_merger.metrics.max_straggler
        return result

    def _get_log_viewer_int(self, env_var: str, default: int) -> int:
        """Read an int from env for log viewer payload caps."""
        try:
            return max(0, int(os.environ.get(env_var, default)))
        except (TypeError, ValueError):
            return default

    def _get_derived_plan_api_keys(self) -> set[str]:
        """Return allowed DerivedPlan item keys based on schema."""
        self._project_context_builder.update_runtime(
            llm_config=self._llm_config,
            imported_plan_context=self._imported_plan_context,
        )
        return self._project_context_builder.get_derived_plan_api_keys()

    # _normalize_plan_items_for_api relocated to obra.hybrid.server_protocol.normalize_plan_items_for_api

    def _resolve_project_name(self, project_id: str | None) -> str | None:
        """Resolve project name for logging if available."""
        if not project_id:
            return None
        try:
            project = self._client.get_project(project_id)
            if isinstance(project, dict):
                name = project.get("name") or project.get("project_name")
                if isinstance(name, str) and name.strip():
                    return name.strip()
        except Exception:
            logger.debug("Failed to resolve project name for %s", project_id, exc_info=True)
        return None

    # _summarize_plan_items relocated to obra.hybrid.server_protocol.summarize_plan_items

    def _get_handler(
        self,
        action: ActionType,
        payload: dict[str, Any] | None = None,
    ) -> Any:
        """Get handler for action type.

        Lazily imports and instantiates handlers.

        Args:
            action: Action type

        Returns:
            Handler instance

        Raises:
            OrchestratorError: If handler not found
            ConfigurationError: If llm_config is invalid or missing required keys
        """
        self._session_flow_runtime.prepare_collaborators()
        return self._handler_factory.get_handler(action, payload)

    def _build_dispatcher(self) -> ActionDispatcher:
        """Construct an ActionDispatcher wired to current orchestrator state."""
        return build_dispatcher(
            observability=build_observability_context(
                runtime_state=self._runtime_state,
                trace=self._trace,
                production_logger=self._production_logger,
                progress_emitter=self._progress_emitter,
                log_session_event=self._log_session_event,
                get_log_viewer_int=self._get_log_viewer_int,
            ),
            phase_control=build_phase_control(
                current_phase_getter=lambda: self._runtime_state.current_phase,
                current_phase_setter=lambda p: setattr(self._runtime_state, "current_phase", p),
                event_logger=self._event_logger,
                phase_start_time_getter=lambda: self._runtime_state.phase_start_time,
                phase_start_time_setter=lambda t: setattr(self._runtime_state, "phase_start_time", t),
            ),
            execution_state=build_execution_state(
                runtime_state=self._runtime_state,
                session_guard=self._session_guard,
                working_dir=self._working_dir,
                invocation=self._invocation,
                refinement=self._refinement,
                server_protocol=self._server_protocol,
                emit_progress=self._emit_progress,
                is_skip_tracking_enabled=self._is_skip_tracking_enabled,
                defaults_json=self._defaults_json,
                should_prompt_for_defaults=self._should_prompt_for_defaults,
            ),
            handler_factory=build_dispatcher_handler_factory(
                get_handler=self._get_handler,
                build_execute_handler=self._handler_factory.build_execute_handler,
                request_with_observability=self._request_with_observability,
                handle_parallel_examine_batches=self._handle_parallel_examine_batches,
                handle_parallel_revise_batches=self._handle_parallel_revise_batches,
                ordered_supported_review_agents=self._llm_configurator._ordered_supported_review_agents,
                write_plan_snapshot=self._server_protocol._write_plan_snapshot,
            ),
        )

    def _build_handler_factory_runtime(self) -> HandlerFactory:
        """Construct the current session-scoped handler factory."""
        return build_handler_factory(
            working_dir=self._working_dir,
            llm_config=self._llm_config,
            domain=self._domain,
            config=self._config,
            session_id=self._runtime_state.session_id,
            trace_id=self._trace.trace_id,
            phase_span_id=self._trace.phase_span_id,
            on_stream=self._on_stream,
            on_progress=self._on_progress,
            observability_config=self._observability_config,
            progress_emitter=self._progress_emitter,
            production_logger=self._production_logger,
            review_config=self._review_config,
            client=self._client,
            planning_mode=self._runtime_state.planning_mode,
            bypass_modes=self._runtime_state.bypass_modes,
            work_type_override=getattr(self, "_work_type_override", None),
            process_registry=self._process_registry,
            objective=self._runtime_state.objective,
            log_session_event=self._log_session_event,
            get_role_llm_config=self._llm_configurator._get_role_llm_config,
            get_review_config=self._llm_configurator._get_review_config,
            create_monitoring_context=self._health_monitor.create_monitoring_context,
            handlers_cache=self._handlers,
        )

    def _build_session_flow_runtime(self) -> HybridSessionFlowRuntime:
        """Construct the extracted session-flow owner for dispatch/report wiring."""
        return HybridSessionFlowRuntime(
            build_handler_factory=self._build_handler_factory_runtime,
            get_handler_factory=lambda: self._handler_factory,
            set_handler_factory=lambda factory: setattr(self, "_handler_factory", factory),
            build_dispatcher=self._build_dispatcher,
            get_dispatcher=lambda: self._dispatcher,
            set_dispatcher=lambda dispatcher: setattr(self, "_dispatcher", dispatcher),
            get_handler=self._get_handler,
            emit_phase_event=self._progress_tracker._emit_phase_event,
            handle_escalation=self._handle_escalation,
            display_bypass_notices=self._display_bypass_notices,
            build_error_context=self._error_handler._build_error_context,
            runtime_state=self._runtime_state,
            server_protocol=self._server_protocol,
            watchdog=self._watchdog,
            fix_result_history=self._runtime_state.fix_result_history,
            ordered_supported_review_agents=self._llm_configurator._ordered_supported_review_agents,
            session_id_getter=lambda: self._runtime_state.session_id,
            current_phase_getter=lambda: self._runtime_state.current_phase,
            phase_span_id_getter=lambda: self._trace.phase_span_id,
            pipeline_span_id_getter=lambda: self._trace.pipeline_span_id,
            subphase_span_id_getter=lambda: self._event_logger.subphase_span_id,
        )

    def _handle_action(self, server_action: ServerAction) -> dict[str, Any]:
        """Handle a server action by dispatching to appropriate handler.

        Args:
            server_action: Server action to handle

        Returns:
            Result to report back to server

        Raises:
            OrchestratorError: If action handling fails
        """
        return self._session_flow_runtime.handle_action(server_action)


    def _handle_escalation(self, notice: EscalationNotice) -> dict[str, Any]:
        """Handle escalation — delegates to EscalationManager.

        Returns backward-compatible dict consumed by ``_report_result``
        (keys: escalation_id, decision, reason).
        """
        outcome = self._escalation_manager.handle(notice)
        return {
            "escalation_id": outcome.escalation_id,
            "decision": outcome.decision,
            "reason": outcome.decision_reason,
        }

    def _report_result(
        self,
        action: ActionType,
        result: dict[str, Any],
    ) -> ServerAction:
        """Report action result to server.

        Args:
            action: Action that was handled
            result: Result from handler

        Returns:
            Next server action
        """
        return self._session_flow_runtime.report_result(action, result)

    def derive(
        self,
        objective: str,
        working_dir: Path | None = None,
        project_id: str | None = None,
        max_iterations: int | None = None,
        plan_id: str | None = None,
        plan_only: bool = False,
        bypass_modes: list[str] | None = None,
        skip_completed_items: list[str] | None = None,
        userplan_id: str | None = None,
        from_step: int | None = None,
        work_type: str | None = None,
        workflow_derivation_request: dict[str, Any] | None = None,
    ) -> CompletionNotice:
        """Start a new derivation session.

        This is the main entry point for the hybrid orchestration loop.
        It creates a new session, derives a plan, refines it, executes
        the plan items, runs quality review, and completes the session.

        Args:
            objective: Task objective to plan and execute
            working_dir: Working directory (overrides instance default)
            project_id: Optional project ID override
            llm_provider: LLM provider to use
            max_iterations: Maximum orchestration loop iterations (None = use config)
            plan_id: Optional reference to uploaded plan (for plan import workflow)
            plan_only: If True, stop before execution once plan is ready (default: False)
            skip_completed_items: List of task titles to skip (for --continue-from recovery)
            userplan_id: Optional UserPlan ID (for plan file import - S2.T3)
            from_step: Re-derive from step N onwards (1-indexed), preserving earlier steps
            work_type: Manual work type override (bypasses auto-detection when provided)
            workflow_derivation_request: Optional workflow-derivation envelope
                materialized from objective and imported plan context.

        Returns:
            CompletionNotice with session summary

        Raises:
            ConnectionError: If server is not reachable
            OrchestratorError: If orchestration fails
        """
        from obra.hybrid.flows._runtime import SessionFlowRuntime
        from obra.hybrid.flows.derive import DeriveFlow

        rt = SessionFlowRuntime(self)
        flow = DeriveFlow(
            rt,
            objective=objective,
            working_dir=working_dir,
            project_id=project_id,
            max_iterations=max_iterations,
            plan_id=plan_id,
            plan_only=plan_only,
            bypass_modes=bypass_modes,
            skip_completed_items=skip_completed_items,
            userplan_id=userplan_id,
            from_step=from_step,
            work_type=work_type,
            workflow_derivation_request=workflow_derivation_request,
        )
        return flow.run()

    def resume(
        self,
        session_id: str,
        *,
        resume_target: str | None = None,
    ) -> CompletionNotice:
        """Resume an interrupted session.

        Args:
            session_id: Session ID to resume
            resume_target: Optional lifecycle-aware phase target override

        Returns:
            CompletionNotice with session summary

        Raises:
            ConnectionError: If server is not reachable
            OrchestratorError: If session cannot be resumed
        """
        from obra.hybrid.flows._runtime import SessionFlowRuntime
        from obra.hybrid.flows.resume import ResumeFlow

        rt = SessionFlowRuntime(self)
        flow = ResumeFlow(
            rt,
            session_id=session_id,
            resume_target=resume_target,
        )
        return flow.run()

    def get_status(self, session_id: str | None = None) -> ResumeContext:
        """Get session status.

        Args:
            session_id: Session ID to check (defaults to current session)

        Returns:
            ResumeContext with session status

        Raises:
            OrchestratorError: If no session ID provided and no active session
        """
        sid = session_id or self._runtime_state.session_id
        if not sid:
            msg = "No session ID provided"
            raise OrchestratorError(
                msg,
                recovery="Provide a session ID or start a new session with 'obra derive'",
            )

        try:
            response = self._request_with_observability("GET", f"session/{sid}")
            return ResumeContext.from_dict(response)
        except APIError as e:
            if e.status_code == HTTPStatus.NOT_FOUND.value:
                msg = f"Session not found: {sid}"
                raise OrchestratorError(
                    msg,
                    recovery="The session may have expired.",
                ) from e
            raise


__all__ = [
    "ConnectionError",
    "HybridOrchestrator",
    "OrchestratorError",
    "emit_force_quit_terminal_event",
]
