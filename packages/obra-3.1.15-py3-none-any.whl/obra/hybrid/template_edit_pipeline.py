"""Template Edit Pipeline for LLM JSON Responses.

This module provides a unified pipeline for requesting structured JSON outputs
from LLMs using file editing instead of text response parsing. This approach
eliminates preamble/prose contamination issues where LLMs naturally add
explanatory text before JSON ("I need to carefully examine..."), causing
parse failures.

The Template Method pattern separates pipeline mechanics (retry, validation,
observability) from domain logic (schemas, validators, fallbacks).
"""

import json
import logging
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, ClassVar, Literal
from uuid import uuid4

from obra.config.llm import DEFAULT_REASONING_LEVEL
from obra.config.loaders import (
    get_llm_logging_preview_max_response_chars,
    get_template_edit_max_retries,
    get_template_retention_settings,
)
from obra.hybrid.json_utils import _sanitize_control_chars
from obra.hybrid.template_json_parser import TemplateJsonParser
from obra.hybrid.template_outcome_resolver import TemplateOutcomeResolver
from obra.llm.cli_runner import get_default_llm_timeout, invoke_llm_via_cli
from obra.prompts.fragments.template_edit import (
    build_template_edit_prompt,
    build_template_edit_prompt_text,
    build_template_stdout_prompt,
    build_template_stdout_prompt_text,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _ExecutionContext:
    """Stable bootstrap inputs shared across attempts."""

    template_path: Path
    initial_content: str
    augmented_prompt: str
    max_attempts: int


@dataclass(frozen=True)
class _InvokePolicy:
    """Resolved invoke settings for the current pipeline execution."""

    provider: str
    model: str
    reasoning_level: str
    auth_method: str
    timeout_s: int
    skip_git_check: bool
    bypass_sandbox: bool
    approval_mode: str | None
    mode: Literal["execute", "text"]
    response_format: Literal["text", "json"]
    allowed_tools: list[str] | None
    output_schema: dict[str, Any] | None


@dataclass(frozen=True)
class _AttemptContent:
    """Raw attempt outputs before parsing/validation."""

    content: str
    llm_stdout: str
    content_unchanged: bool


@dataclass(frozen=True)
class _ParsedAttempt:
    """Parsed attempt data plus its raw content."""

    data: dict[str, Any] | str
    attempt_content: _AttemptContent


class TemplateFileManager:
    """Manages template file I/O: creation, result reading, and cleanup.

    Extracted from TemplateEditPipeline to separate file-system concerns
    from orchestration logic.
    """

    def __init__(
        self,
        *,
        working_dir: Path,
        action_name: str,
        output_format: Literal["json", "text"],
        write_scope: Literal["workspace", "safe_output_only"],
    ) -> None:
        self._working_dir = working_dir
        self._action_name = action_name
        self._output_format = output_format
        self._write_scope = write_scope

    def create_template(self, template_content: dict[str, Any] | str) -> Path:
        """Create a template file with the given content.

        For JSON format: The template file is a JSON file containing the schema
        structure with an _instructions field providing guidance to the LLM.

        For text format: The template file is a markdown file containing prose
        content with <FILL:...> placeholders for the LLM to populate.

        Args:
            template_content: Dictionary with schema structure (JSON format) or
                string with prose template (text format)

        Returns:
            Path to the created template file
        """
        # Create output directory if it doesn't exist
        output_dir = self._working_dir / ".obra" / "llm_output"
        output_dir.mkdir(parents=True, exist_ok=True)

        # Generate unique filename with timestamp + UUID suffix to prevent
        # collisions when concurrent threads create templates in the same second
        # (e.g., parallel epic serialization via ThreadPoolExecutor)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        unique_suffix = uuid4().hex[:8]

        # Choose file extension based on output format
        extension = ".md" if self._output_format == "text" else ".json"
        filename = f"{self._action_name}_{timestamp}_{unique_suffix}{extension}"
        template_path = output_dir / filename

        # Write content to template file
        if self._output_format == "text":
            # Text format: write string directly
            template_path.write_text(template_content)
        else:
            # JSON format: serialize dictionary
            template_path.write_text(json.dumps(template_content, indent=2))

        logger.debug(f"Created template file: {template_path}")
        return template_path

    def read_result(self, template_path: Path) -> str:
        """Read the result content from a template file.

        Args:
            template_path: Path to the template file

        Returns:
            Content of the template file as a string
        """
        return template_path.read_text(encoding="utf-8")

    def persist_safe_output(
        self,
        template_path: Path,
        data: dict[str, Any] | str,
    ) -> None:
        """Persist validated stdout-only output into the canonical template path."""
        if self._write_scope != "safe_output_only":
            return
        if self._output_format == "text":
            template_path.write_text(str(data), encoding="utf-8")
            return
        if not isinstance(data, dict):
            return
        template_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def schedule_cleanup(self, template_path: Path, on_error: bool) -> None:
        """Clean up template file based on retention policy.

        Retention policy:
        - Success: Delete template unless retention configured
        - Error: Keep template unless retention disabled

        Args:
            template_path: Path to template file
            on_error: Whether the pipeline ended in error state
        """
        keep_on_success, keep_on_error = get_template_retention_settings()
        should_keep = keep_on_error if on_error else keep_on_success
        if should_keep:
            logger.debug(
                "Template kept (on_error=%s, keep_on_success=%s, keep_on_error=%s): %s",
                on_error,
                keep_on_success,
                keep_on_error,
                template_path,
            )
            return

        try:
            template_path.unlink()
            logger.debug("Template cleaned up: %s", template_path)
        except Exception as e:
            logger.warning("Failed to cleanup template %s: %s", template_path, e)


class TemplateLLMInvoker:
    """Handles LLM prompt building and invocation for the template edit pipeline.

    Extracted from TemplateEditPipeline to separate LLM interaction concerns
    from orchestration logic.
    """

    # ISSUE-HYBRID-056: Patterns in server-generated prompts that contradict
    # template-edit mode.  The server may instruct "Do NOT create/modify files"
    # for text-mode JSON output, but template-edit requires file editing.
    _TEXT_MODE_PREAMBLE_PATTERNS: ClassVar[list[re.Pattern[str]]] = [
        re.compile(
            r"\*\*CRITICAL OUTPUT REQUIREMENT\*\*:.*?(?=\n\n|\n#|\Z)",
            re.DOTALL,
        ),
        re.compile(
            r"Your ENTIRE response must be parseable by json\.loads\(\)\..*?(?=\n\n|\n#|\Z)",
            re.DOTALL,
        ),
    ]

    def __init__(
        self,
        *,
        working_dir: Path,
        action_name: str,
        output_format: Literal["json", "text"],
        write_scope: Literal["workspace", "safe_output_only"],
        on_stream: Callable[[str], None] | None,
        log_event: Callable[..., None] | None,
    ) -> None:
        self._working_dir = working_dir
        self._action_name = action_name
        self._output_format = output_format
        self._write_scope = write_scope
        self._on_stream = on_stream
        self._log_event = log_event

    @staticmethod
    def _strip_text_mode_preamble(prompt: str) -> str:
        """Remove text-mode JSON output instructions that contradict file-edit mode.

        Server-generated prompts may contain directives like "Do NOT create files"
        intended for text-mode JSON responses.  These conflict with the template-edit
        suffix that instructs the LLM to edit a file, causing the model to either
        refuse or write JSON to stdout instead of editing the template
        (ISSUE-HYBRID-056).
        """
        cleaned = prompt
        for pattern in TemplateLLMInvoker._TEXT_MODE_PREAMBLE_PATTERNS:
            cleaned = pattern.sub("", cleaned)
        # Collapse runs of 3+ blank lines left by removal
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
        return cleaned

    def build_prompt(self, base_prompt: str, template_path: Path) -> str:
        """Build augmented prompt for either file-edit or stdout-only mode.

        Transforms a base prompt into a template edit prompt by adding
        instructions to edit the template file instead of responding with prose.
        This forces the LLM to use tool actions (structural) rather than text
        responses (prose), eliminating preamble contamination.

        Args:
            base_prompt: Original prompt describing the task
            template_path: Path to the template file to edit

        Returns:
            Augmented prompt with file editing instructions
        """
        # ISSUE-HYBRID-056: Strip text-mode JSON preamble that conflicts with
        # file-edit instructions (defense-in-depth; server-side fix is primary).
        cleaned_prompt = self._strip_text_mode_preamble(base_prompt)

        # Calculate relative path if possible, fallback to absolute
        try:
            relative_path = template_path.relative_to(self._working_dir)
        except ValueError:
            # Template path is not relative to working_dir, use absolute
            relative_path = template_path

        # Build augmented prompt with editing instructions (dispatch based on format)
        if self._write_scope == "safe_output_only":
            if self._output_format == "text":
                return build_template_stdout_prompt_text(cleaned_prompt, relative_path)
            task_verb = "revisions" if self._action_name == "revise" else "findings"
            return build_template_stdout_prompt(
                cleaned_prompt,
                relative_path,
                task_verb=task_verb,
            )

        if self._output_format == "text":
            return build_template_edit_prompt_text(cleaned_prompt, relative_path)
        task_verb = "revisions" if self._action_name == "revise" else "findings"
        return build_template_edit_prompt(
            cleaned_prompt,
            relative_path,
            task_verb=task_verb,
        )

    def invoke(self, prompt: str, policy: _InvokePolicy) -> str:
        """Run one LLM attempt with the resolved invoke policy.

        Args:
            prompt: The augmented prompt to send to the LLM
            policy: Resolved invoke settings for the call

        Returns:
            Raw LLM stdout output
        """
        return invoke_llm_via_cli(
            prompt=prompt,
            cwd=self._working_dir,
            provider=policy.provider,
            model=policy.model,
            reasoning_level=policy.reasoning_level,
            auth_method=policy.auth_method,
            timeout_s=policy.timeout_s,
            on_stream=self._on_stream,
            log_event=self._log_event,
            call_site=f"template_edit:{self._action_name}",
            skip_git_check=policy.skip_git_check,
            bypass_sandbox=policy.bypass_sandbox,
            approval_mode=policy.approval_mode,
            mode=policy.mode,
            response_format=policy.response_format,
            allowed_tools=policy.allowed_tools,
            output_schema=policy.output_schema,
        )


class TemplateEditPipeline:
    """Pipeline for structured JSON responses via file editing.

    This class handles the mechanics of template-based JSON generation:
    - Creates template files with schema guidance
    - Invokes LLM with file editing instructions
    - Validates responses and retries on failure
    - Provides observability hooks for monitoring

    Handlers provide domain-specific components:
    - Template schema (initial JSON structure with _instructions)
    - Validator function (checks fields, types, constraints)
    - Fallback function (safe default on validation failure)

    Example:
        pipeline = TemplateEditPipeline(
            working_dir=Path('/project'),
            action_name='examine',
            max_retries=3
        )

        def validator(data: dict) -> tuple[bool, str | None]:
            if 'issues' not in data:
                return (False, 'Missing issues field')
            return (True, None)

        def fallback() -> list:
            return []

        result, metadata = pipeline.execute(
            base_prompt="Examine this code",
            template_content={'issues': [], '_instructions': '...'},
            validator=validator,
            fallback_fn=fallback,
            llm_config={'provider': 'claude'}
        )
    """

    def __init__(
        self,
        working_dir: Path,
        action_name: str,
        output_format: Literal["json", "text"] = "json",
        write_scope: Literal["workspace", "safe_output_only"] = "workspace",
        on_stream: Callable[[str], None] | None = None,
        log_event: Callable[..., None] | None = None,
        production_logger: Any | None = None,
        max_retries: int | None = None,
    ):
        """Initialize the template edit pipeline.

        Args:
            working_dir: Project working directory (base for relative paths)
            action_name: Action identifier (e.g., 'examine', 'derive')
            output_format: Output format ('json' for structured data, 'text' for prose)
            write_scope: Whether the model may edit files in the working tree
                ("workspace") or must remain read-only and return output via
                stdout only ("safe_output_only"). Pre-execution derivation and
                intake stages must use safe_output_only.
            on_stream: Optional callback for streaming LLM output
            log_event: Optional callback for observability events
            max_retries: Maximum validation retry attempts (default from config: 3)
        """
        self._working_dir = working_dir
        self._action_name = action_name
        self._output_format = output_format
        self._write_scope = write_scope
        self._on_stream = on_stream
        self._log_event = log_event
        self._production_logger = production_logger
        self._max_retries = (
            max_retries if max_retries is not None else get_template_edit_max_retries()
        )
        self._file_manager = TemplateFileManager(
            working_dir=working_dir,
            action_name=action_name,
            output_format=output_format,
            write_scope=write_scope,
        )
        self._invoker = TemplateLLMInvoker(
            working_dir=working_dir,
            action_name=action_name,
            output_format=output_format,
            write_scope=write_scope,
            on_stream=on_stream,
            log_event=log_event,
        )
        self._json_parser = TemplateJsonParser(
            log_event=self._emit_log_event,
            action_name=self._action_name,
        )
        self._outcome_resolver = TemplateOutcomeResolver(
            log_event=self._emit_log_event,
            schedule_cleanup=self._schedule_cleanup,
            build_success_result=self._build_success_result,
            build_validation_retry_prompt=self._build_validation_retry_prompt,
            build_json_retry_prompt=self._build_json_retry_prompt,
            output_format=self._output_format,
            action_name=self._action_name,
            try_recover_from_stdout=self._json_parser.try_recover_from_stdout,
        )

    def _emit_log_event(self, event_type: str, **kwargs: Any) -> None:
        """Emit a log event using the configured callback.

        This wrapper normalizes the calling convention to use **kwargs,
        matching HybridOrchestrator._log_session_event signature.

        Args:
            event_type: Event type string (e.g., 'template_created')
            **kwargs: Event-specific data as keyword arguments
        """
        if self._log_event:
            try:
                self._log_event(event_type, **kwargs)
            except Exception as e:
                logger.debug(f"Failed to log event '{event_type}': {e}")
        if self._production_logger:
            try:
                self._production_logger.log_event(event_type, **kwargs)
            except Exception as e:
                logger.debug(f"Failed to log production event '{event_type}': {e}")

    def _create_template(self, template_content: dict[str, Any] | str) -> Path:
        """Create a template file with the given content.

        Delegates to TemplateFileManager.create_template.
        """
        return self._file_manager.create_template(template_content)

    # ISSUE-HYBRID-056: Patterns in server-generated prompts that contradict
    # template-edit mode.  The server may instruct "Do NOT create/modify files"
    # for text-mode JSON output, but template-edit requires file editing.
    _TEXT_MODE_PREAMBLE_PATTERNS: ClassVar[list[re.Pattern[str]]] = [
        re.compile(
            r"\*\*CRITICAL OUTPUT REQUIREMENT\*\*:.*?(?=\n\n|\n#|\Z)",
            re.DOTALL,
        ),
        re.compile(
            r"Your ENTIRE response must be parseable by json\.loads\(\)\..*?(?=\n\n|\n#|\Z)",
            re.DOTALL,
        ),
    ]

    @staticmethod
    def _strip_text_mode_preamble(prompt: str) -> str:
        """Remove text-mode JSON output instructions that contradict file-edit mode.

        Delegates to TemplateLLMInvoker._strip_text_mode_preamble.
        """
        return TemplateLLMInvoker._strip_text_mode_preamble(prompt)

    def _build_template_edit_prompt(self, base_prompt: str, template_path: Path) -> str:
        """Build augmented prompt for either file-edit or stdout-only mode.

        Delegates to TemplateLLMInvoker.build_prompt.
        """
        return self._invoker.build_prompt(base_prompt, template_path)

    def _persist_safe_output(
        self,
        template_path: Path,
        data: dict[str, Any] | str,
    ) -> None:
        """Persist validated stdout-only output into the canonical template path.

        Delegates to TemplateFileManager.persist_safe_output.
        """
        self._file_manager.persist_safe_output(template_path, data)

    def _bootstrap_execution(
        self,
        *,
        base_prompt: str,
        template_content: dict[str, Any] | str,
        max_retries: int | None,
    ) -> _ExecutionContext:
        """Create attempt-invariant runtime context for the pipeline."""
        template_path = self._create_template(template_content)
        initial_content = template_path.read_text(encoding="utf-8")
        self._emit_log_event(
            "template_created",
            template_path=str(template_path),
            action=self._action_name,
        )
        return _ExecutionContext(
            template_path=template_path,
            initial_content=initial_content,
            augmented_prompt=self._build_template_edit_prompt(base_prompt, template_path),
            max_attempts=self._max_retries if max_retries is None else max_retries,
        )

    def _resolve_invoke_policy(
        self,
        llm_config: dict[str, Any],
        *,
        timeout_s: int | None,
        output_schema: dict[str, Any] | None,
    ) -> _InvokePolicy:
        """Resolve provider policy and CLI parameters once per execution."""
        codex_config = llm_config.get("codex", {})
        if not isinstance(codex_config, dict):
            codex_config = {}
        git_config = llm_config.get("git", {})
        if not isinstance(git_config, dict):
            git_config = {}

        has_top_bypass = "bypass_sandbox" in llm_config
        has_codex_bypass = "bypass_sandbox" in codex_config
        has_top_skip = "skip_git_check" in llm_config
        has_git_skip = "skip_check" in git_config

        bypass_sandbox = bool(
            llm_config.get(
                "bypass_sandbox",
                codex_config.get("bypass_sandbox", False),
            )
        )
        approval_mode = llm_config.get("approval_mode", codex_config.get("approval_mode"))
        skip_git_check = bool(
            llm_config.get(
                "skip_git_check",
                git_config.get("skip_check", True),
            )
        )

        provider = str(llm_config.get("provider", ""))
        if provider == "openai":
            if self._write_scope == "workspace" and not has_top_bypass and not has_codex_bypass:
                bypass_sandbox = True
            if approval_mode is None:
                approval_mode = "full-auto"
            if not has_top_skip and not has_git_skip:
                skip_git_check = True

        mode: Literal["execute", "text"] = (
            "execute" if self._write_scope == "workspace" else "text"
        )
        if self._write_scope == "workspace":
            response_format: Literal["text", "json"] = "text"
        else:
            response_format = "text" if self._output_format == "text" else "json"

        allowed_tools = llm_config.get("allowed_tools")
        if allowed_tools is not None:
            allowed_tools = list(allowed_tools)

        return _InvokePolicy(
            provider=str(llm_config["provider"]),
            model=str(llm_config["model"]),
            reasoning_level=str(
                llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)
            ),
            auth_method=str(llm_config.get("auth_method") or llm_config.get("auth", "oauth")),
            timeout_s=timeout_s if timeout_s is not None else get_default_llm_timeout(),
            skip_git_check=skip_git_check,
            bypass_sandbox=bypass_sandbox,
            approval_mode=approval_mode,
            mode=mode,
            response_format=response_format,
            allowed_tools=allowed_tools,
            output_schema=output_schema,
        )

    def _invoke_with_policy(self, prompt: str, policy: _InvokePolicy) -> str:
        """Run one attempt with the resolved invoke policy.

        Delegates to TemplateLLMInvoker.invoke.
        """
        return self._invoker.invoke(prompt, policy)

    def _load_attempt_content(
        self,
        context: _ExecutionContext,
        llm_stdout: str,
    ) -> _AttemptContent:
        """Load either stdout-only or template-backed attempt output."""
        if self._write_scope == "safe_output_only":
            return _AttemptContent(
                content=llm_stdout,
                llm_stdout=llm_stdout,
                content_unchanged=False,
            )
        content = self._file_manager.read_result(context.template_path)
        return _AttemptContent(
            content=content,
            llm_stdout=llm_stdout,
            content_unchanged=content == context.initial_content,
        )

    def _parse_attempt_content(
        self,
        *,
        attempt_index: int,
        attempt_content: _AttemptContent,
        template_content: dict[str, Any] | str,
        output_schema: dict[str, Any] | None,
        llm_config: dict[str, Any],
        context: _ExecutionContext,
    ) -> _ParsedAttempt:
        """Parse one attempt into typed template-edit data."""
        if self._output_format == "text":
            return _ParsedAttempt(data=attempt_content.content, attempt_content=attempt_content)

        data = self._json_parser.parse_json_attempt(
            attempt_index=attempt_index,
            attempt_content=attempt_content,
            template_content=template_content,
            output_schema=output_schema,
            llm_config=llm_config,
            context=context,
        )
        return _ParsedAttempt(data=data, attempt_content=attempt_content)

    def _emit_parse_telemetry(self, attempt_index: int, content: str, max_attempts: int) -> None:
        """Emit parse-stage telemetry after content normalization."""
        attempt_number = attempt_index + 1
        try:
            self._emit_log_event("template_read", file_size=len(content), attempt=attempt_number)
        except Exception:
            self._emit_log_event("template_read", file_size=0, attempt=attempt_number)
        self._emit_log_event("parse_attempt", attempt=attempt_number, max_retries=max_attempts)

    def _validate_attempt(
        self,
        parsed_attempt: _ParsedAttempt,
        *,
        validator: Callable[[dict | str], tuple[bool, str | None]],
        allow_unchanged: bool,
    ) -> tuple[bool, str | None]:
        """Apply unchanged policy and validator for one attempt."""
        if parsed_attempt.attempt_content.content_unchanged and not allow_unchanged:
            return (False, "Template file unchanged but edits are required")
        return validator(parsed_attempt.data)

    def _build_validation_retry_prompt(
        self,
        *,
        base_prompt: str,
        context: _ExecutionContext,
        error_msg: str | None,
    ) -> str:
        """Build the validation retry prompt for the next attempt."""
        prompt = self._build_template_edit_prompt(base_prompt, context.template_path)
        if self._output_format == "text":
            prompt += (
                f"\n\nNote: Previous attempt had validation error: {error_msg}. "
                "Fill remaining placeholders and fix this specific issue."
            )
        else:
            prompt += (
                f"\n\nNote: Previous attempt had validation error: {error_msg}. "
                "Please fix this specific issue."
            )
        return prompt

    def _build_json_retry_prompt(
        self,
        *,
        base_prompt: str,
        context: _ExecutionContext,
        error: json.JSONDecodeError,
    ) -> str:
        """Build the JSON syntax retry prompt for the next attempt."""
        prompt = self._build_template_edit_prompt(base_prompt, context.template_path)
        prompt += (
            f"\n\nNote: Previous attempt had JSON parse error: {error!s}. "
            "Fix the JSON syntax."
        )
        return prompt

    def _build_success_result(
        self,
        *,
        attempt_index: int,
        parsed_attempt: _ParsedAttempt,
        context: _ExecutionContext,
    ) -> tuple[Any, dict[str, Any]]:
        """Finalize a successful attempt, including unchanged handling."""
        attempt_number = attempt_index + 1
        data = parsed_attempt.data
        max_preview = get_llm_logging_preview_max_response_chars()
        if isinstance(data, dict):
            preview_str = json.dumps(data, indent=2)[:max_preview]
        else:
            preview_str = str(data)[:max_preview]
        self._emit_log_event(
            "parse_success",
            attempts=attempt_number,
            action=self._action_name,
            content_preview=preview_str,
        )

        if parsed_attempt.attempt_content.content_unchanged:
            self._emit_log_event(
                "template_unchanged_accepted",
                attempt=attempt_number,
                template_path=str(context.template_path),
            )
            logger.debug("Template unchanged after LLM call - accepting as 'no changes required'")
            self._schedule_cleanup(context.template_path, on_error=False)
            return (data, {"status": "no_changes_required", "attempts": attempt_number})

        self._persist_safe_output(context.template_path, data)
        self._schedule_cleanup(context.template_path, on_error=False)
        status = "template_success" if attempt_index == 0 else "template_retry_success"
        return (data, {"status": status, "attempts": attempt_number})

    def execute(
        self,
        base_prompt: str,
        template_content: dict[str, Any] | str,
        validator: Callable[[dict | str], tuple[bool, str | None]],
        fallback_fn: Callable[[], Any],
        llm_config: dict[str, Any],
        timeout_s: int | None = None,
        max_retries: int | None = None,
        allow_unchanged: bool = True,
        output_schema: dict[str, Any] | None = None,
    ) -> tuple[Any, dict[str, Any]]:
        """Execute the template edit pipeline with retry loop.

        This is the main entry point for the pipeline. It orchestrates:
        1. Template creation
        2. LLM invocation with editing instructions
        3. Response validation with retry on failure
        4. Fallback on exhausted retries

        Args:
            base_prompt: The task description prompt
            template_content: Initial content - JSON dict with _instructions
                (JSON format) or prose string with <FILL:> placeholders (text format)
            validator: Function that validates parsed data (dict for JSON, str
                for text) and returns (is_valid, error_msg). Return (True, None)
                if valid.
            fallback_fn: Function that returns a safe default value if
                all retry attempts fail
            llm_config: LLM configuration dict with keys:
                - provider: str (e.g., 'anthropic', 'openai')
                - model: str (model identifier)
                - reasoning_level: str (reasoning level)
                - auth: str (auth method, default 'oauth')
                - allowed_tools: Optional list[str] tool allowlist
            timeout_s: Optional timeout override for the LLM call.
            max_retries: Optional retry override for this execution.
            allow_unchanged: When False, unchanged template files are treated
                as validation failures and retried/fallbacked instead of being
                accepted as "no changes required".
            output_schema: Optional JSON Schema used to enforce structured
                output for provider CLIs that support native schema contracts.

        Returns:
            Tuple of (result_data, metadata). Metadata includes:
            - status: 'template_success' (first attempt), 'template_retry_success' (retry succeeded), or 'template_fallback' (all retries failed)
            - attempts: number of attempts made

        Example:
            >>> def validator(data: dict) -> tuple[bool, str | None]:
            ...     if 'issues' not in data:
            ...         return (False, 'Missing issues field')
            ...     return (True, None)
            >>> def fallback() -> list:
            ...     return []
            >>> result, meta = pipeline.execute(
            ...     base_prompt="Examine this code",
            ...     template_content={'issues': [], '_instructions': '...'},
            ...     validator=validator,
            ...     fallback_fn=fallback,
            ...     llm_config={'provider': 'anthropic', 'model': 'claude-3-5-sonnet-20241022', 'thinking': 'off', 'auth': 'oauth'}
            ... )
        """
        context = self._bootstrap_execution(
            base_prompt=base_prompt,
            template_content=template_content,
            max_retries=max_retries,
        )
        invoke_policy = self._resolve_invoke_policy(
            llm_config,
            timeout_s=timeout_s,
            output_schema=output_schema,
        )
        current_prompt = context.augmented_prompt

        for attempt in range(context.max_attempts):
            try:
                llm_stdout = self._invoke_with_policy(current_prompt, invoke_policy)
                attempt_content = self._load_attempt_content(context, llm_stdout)
                parsed_attempt = self._parse_attempt_content(
                    attempt_index=attempt,
                    attempt_content=attempt_content,
                    template_content=template_content,
                    output_schema=output_schema,
                    llm_config=llm_config,
                    context=context,
                )
                self._emit_parse_telemetry(
                    attempt,
                    attempt_content.content,
                    context.max_attempts,
                )
                is_valid, error_msg = self._validate_attempt(
                    parsed_attempt,
                    validator=validator,
                    allow_unchanged=allow_unchanged,
                )
                next_prompt, result = self._outcome_resolver.resolve_validation(
                    attempt_index=attempt,
                    max_attempts=context.max_attempts,
                    parsed_attempt=parsed_attempt,
                    is_valid=is_valid,
                    error_msg=error_msg,
                    base_prompt=base_prompt,
                    context=context,
                    template_content=template_content,
                    validator=validator,
                    fallback_fn=fallback_fn,
                    llm_config=llm_config,
                )
                if result is not None:
                    return result
                if next_prompt is not None:
                    current_prompt = next_prompt
                continue
            except json.JSONDecodeError as e:
                next_prompt, result = self._outcome_resolver.resolve_json_parse_failure(
                    attempt_index=attempt,
                    max_attempts=context.max_attempts,
                    error=e,
                    base_prompt=base_prompt,
                    context=context,
                    fallback_fn=fallback_fn,
                )
                if result is not None:
                    return result
                if next_prompt is not None:
                    current_prompt = next_prompt
                continue
            except Exception as e:
                result = self._outcome_resolver.resolve_exception(
                    attempt_index=attempt,
                    max_attempts=context.max_attempts,
                    error=e,
                    llm_config=llm_config,
                    context=context,
                    validator=validator,
                    fallback_fn=fallback_fn,
                )
                if result is not None:
                    return result
                continue

        # Should never reach here, but add fallback for safety
        self._schedule_cleanup(context.template_path, on_error=True)
        fallback_result = fallback_fn()
        return (
            fallback_result,
            {"status": "validation_failed", "attempts": context.max_attempts},
        )

    def _schedule_cleanup(self, template_path: Path, on_error: bool) -> None:
        """Clean up template file based on retention policy.

        Delegates to TemplateFileManager.schedule_cleanup.
        """
        self._file_manager.schedule_cleanup(template_path, on_error)
