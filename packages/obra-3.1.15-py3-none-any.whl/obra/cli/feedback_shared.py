"""Shared feedback and telemetry helpers."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import typer
import yaml  # type: ignore[import-untyped]

from obra.display import console, glyphs, print_error, print_info, print_success
from obra.exceptions import ConfigurationError

if TYPE_CHECKING:
    from obra.feedback import PrivacyLevel, Severity

logger = logging.getLogger(__name__)

def _get_privacy_level(privacy: str) -> "PrivacyLevel":
    """Convert string privacy level to enum."""
    from obra.feedback import PrivacyLevel

    mapping = {
        "full": PrivacyLevel.FULL,
        "standard": PrivacyLevel.STANDARD,
        "minimal": PrivacyLevel.MINIMAL,
    }
    return mapping.get(privacy.lower(), PrivacyLevel.STANDARD)


def _get_severity(severity: str) -> "Severity":
    """Convert string severity to enum."""
    from obra.feedback import Severity

    mapping = {
        "critical": Severity.CRITICAL,
        "high": Severity.HIGH,
        "medium": Severity.MEDIUM,
        "low": Severity.LOW,
    }
    return mapping.get(severity.lower(), Severity.MEDIUM)


def _get_recent_session_id() -> str | None:
    """Get the most recent session ID from session logs.

    Returns:
        Session ID string or None if no recent session found.
    """
    try:
        from obra.feedback.session_logger import SessionConsoleLogger

        session_id, _ = SessionConsoleLogger.get_recent_session_log()
        return cast(str | None, session_id)
    except Exception:
        return None


def offer_bug_report(
    error: Exception | None = None,
    context: str = "operation",
    session_id: str | None = None,
    command_used: str | None = None,
    objective: str | None = None,
    auto_report: bool = False,
    failure_reason: str | None = None,
    orchestrator: Any | None = None,
    diagnostic_payloads: dict[str, Any] | None = None,
) -> None:
    """Offer to file a bug report after a failure.

    Prompts user to submit feedback with pre-filled error context.
    Supports both hard failures (exceptions) and soft failures (e.g., 0 items completed).

    Args:
        error: The exception that occurred (optional for soft failures)
        context: Description of what was happening (e.g., "orchestration", "derive")
        session_id: Session ID if known
        command_used: The command that was run
        objective: The user's objective (what they were trying to accomplish)
        auto_report: If True, skip prompt and submit automatically (for CI/CD)
        failure_reason: Human-readable failure reason (for soft failures without exception)
        orchestrator: HybridOrchestrator instance (if available) for crash state snapshot
        diagnostic_payloads: Additional structured diagnostics to embed in the report
    """
    import traceback

    # Determine summary and error details based on failure type
    if error:
        error_type = type(error).__name__
        error_message = str(error)
        error_tb = "".join(traceback.format_exception(type(error), error, error.__traceback__))
        summary = f"{context.title()} failed: {error_type}"
        error_display = f"{error_type}: {error_message[:80]}..."
    else:
        error_type = "SoftFailure"
        error_message = failure_reason or "Operation did not complete successfully"
        error_tb = ""
        summary = f"{context.title()} failed: {failure_reason or 'no items completed'}"
        error_display = failure_reason or "No items completed"

    # Build description with objective if available
    description_parts = [f"Automatic bug report from {context} failure."]
    if objective:
        # Truncate very long objectives for the description
        from obra.config.loaders import get_display_limit

        obj_limit = get_display_limit("objective_preview_max_chars")
        obj_preview = objective[:obj_limit] + "..." if len(objective) > obj_limit else objective
        description_parts.append(f"Objective: {obj_preview}")
    description = "\n\n".join(description_parts)

    session_id = session_id or _get_recent_session_id()

    # Collect orchestrator crash state if available
    session_snapshot: dict[str, Any] = {}
    last_server_action: dict[str, Any] = {}
    if orchestrator is not None:
        try:
            session_snapshot = orchestrator._error_handler.get_crash_snapshot()
            last_server_action = orchestrator._error_handler.get_last_server_action_redacted()
            # Use orchestrator's session_id if caller didn't provide one
            if not session_id:
                session_id = session_snapshot.get("session_id")
        except Exception as snap_err:
            logger.debug(f"Failed to collect crash snapshot: {snap_err}")

    if diagnostic_payloads:
        session_snapshot = dict(session_snapshot)
        session_snapshot["diagnostics"] = dict(diagnostic_payloads)

    # Auto-report mode: skip prompts entirely
    if auto_report:
        try:
            from obra.feedback import FeedbackCollector, PrivacyLevel, Severity

            collector = FeedbackCollector(privacy_level=PrivacyLevel.FULL)
            report = collector.create_bug_report(
                summary=summary,
                severity=Severity.HIGH,
                description=description,
                error_message=error_message,
                error_traceback=error_tb,
                command_used=command_used or "",
                objective=objective or "",
                session_id=session_id,
                session_snapshot=session_snapshot,
                last_server_action=last_server_action,
            )
            result = collector.submit(report)
            console.print()

            # Build captured data summary
            captured_parts = []
            if report.session_snapshot:
                captured_parts.append("session state")
                diagnostics_payload = report.session_snapshot.get("diagnostics", {})
                if isinstance(diagnostics_payload, dict):
                    captured_parts.extend(sorted(str(key) for key in diagnostics_payload.keys()))
            if report.observability_events:
                captured_parts.append(f"{len(report.observability_events)} events")
            if report.console_log:
                captured_parts.append(f"{len(report.console_log.split(chr(10)))} lines log")
            if objective:
                captured_parts.append("objective")
            captured_str = f" ({', '.join(captured_parts)})" if captured_parts else ""

            if result.get("success"):
                console.print(
                    f"[dim]Bug report auto-submitted: {result.get('report_id', 'N/A')}{captured_str}[/dim]"
                )
            else:
                console.print(
                    f"[dim]Bug report saved locally{captured_str} (will sync later)[/dim]"
                )
        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[dim]Auto-report failed: {e}[/dim]")
        return

    # Interactive mode: prompt user
    console.print()
    console.print("[bold yellow]Would you like to report this issue?[/bold yellow]")
    console.print("[dim]Your report helps us fix bugs faster.[/dim]")
    console.print()

    console.print("[dim]The report will include:[/dim]")
    console.print(f"  [dim]• Error: {error_display}[/dim]")
    if objective:
        from obra.config.loaders import get_display_limit

        desc_limit = get_display_limit("description_max_chars")
        obj_short = objective[:desc_limit] + "..." if len(objective) > desc_limit else objective
        console.print(f"  [dim]• Objective: {obj_short}[/dim]")
    if session_id:
        console.print("  [dim]• Session logs and events[/dim]")
    console.print("  [dim]• System info (OS, Obra version)[/dim]")
    console.print()

    # Skip interactive prompts in headless mode
    from obra.cli.run_support.interaction_mode import current_mode_is_interactive

    if not current_mode_is_interactive():
        console.print("[dim]Headless mode: skipping interactive bug report prompt.[/dim]")
        return

    try:
        from obra.display.prompting import prompt_input

        response = (
            prompt_input("(R)eport (s)kip (p)review > ", console=console, markup=False)
            .strip()
            .lower()
        )
    except (EOFError, KeyboardInterrupt):
        console.print("\n[dim]Skipped.[/dim]")
        return

    if response in ("", "r", "report", "y", "yes"):
        # Submit the bug report
        try:
            from obra.feedback import FeedbackCollector, PrivacyLevel, Severity

            collector = FeedbackCollector(privacy_level=PrivacyLevel.FULL)
            report = collector.create_bug_report(
                summary=summary,
                severity=Severity.HIGH,
                description=description,
                error_message=error_message,
                error_traceback=error_tb,
                command_used=command_used or "",
                objective=objective or "",
                session_id=session_id,
                session_snapshot=session_snapshot,
                last_server_action=last_server_action,
            )

            result = collector.submit(report)
            _display_submission_result(
                result,
                console,
                events_count=len(report.observability_events),
                console_lines=(len(report.console_log.split("\n")) if report.console_log else 0),
                has_objective=bool(objective),
            )

        except Exception as submit_error:
            print_error(f"Failed to submit report: {submit_error}")
            console.print("[dim]You can manually report at: obra feedback bug 'description'[/dim]")

    elif response in ("s", "skip", "n", "no"):
        console.print("[dim]Skipped. You can report later with: obra feedback bug[/dim]")
        return

    elif response in ("p", "preview"):
        # Show preview then ask again
        try:
            import json

            from obra.feedback import FeedbackCollector, PrivacyLevel, Severity

            collector = FeedbackCollector(privacy_level=PrivacyLevel.FULL)
            report = collector.create_bug_report(
                summary=summary,
                severity=Severity.HIGH,
                description=description,
                error_message=error_message,
                error_traceback=error_tb,
                command_used=command_used or "",
                objective=objective or "",
                session_id=session_id,
                session_snapshot=session_snapshot,
                last_server_action=last_server_action,
            )

            preview_data = collector.preview_submission(report)
            console.print()
            console.print("[bold cyan]Preview - Data that will be submitted:[/bold cyan]")
            console.print(json.dumps(preview_data, indent=2, default=str))
            console.print()

            try:
                from obra.display.prompting import prompt_input

                confirm = (
                    prompt_input("(S)ubmit (c)ancel > ", console=console, markup=False)
                    .strip()
                    .lower()
                )
            except (EOFError, KeyboardInterrupt):
                console.print("\n[dim]Cancelled.[/dim]")
                return

            if confirm in ("", "s", "submit", "y", "yes"):
                result = collector.submit(report)
                _display_submission_result(
                    result,
                    console,
                    events_count=len(report.observability_events),
                    console_lines=(
                        len(report.console_log.split("\n")) if report.console_log else 0
                    ),
                    has_objective=bool(objective),
                )
            else:
                console.print(
                    "[dim]Report saved as draft. Submit later with: obra feedback drafts[/dim]"
                )

        except Exception as preview_error:
            print_error(f"Failed to generate preview: {preview_error}")
    else:
        console.print("[dim]Skipped. Report later with: obra feedback bug 'description'[/dim]")


def _display_submission_result(
    result: dict,
    console,
    events_count: int = 0,
    console_lines: int = 0,
    has_system_info: bool = True,
    has_objective: bool = False,
) -> None:
    """Display feedback submission result with details of captured data.

    Args:
        result: Submission result dict from collector.submit()
        console: Rich console for output
        events_count: Number of observability events included
        console_lines: Number of console log lines included
        has_system_info: Whether system info was included
        has_objective: Whether objective was included
    """
    console.print()
    if result.get("stored_locally"):
        # Submission failed but report was saved locally for retry
        console.print("[yellow]Could not reach server — feedback saved locally.[/yellow]")
        if result.get("submit_error"):
            console.print(f"[dim]Reason: {result['submit_error']}[/dim]")
        console.print("Run [bold]obra feedback sync[/bold] to retry submission.")
        console.print(f"[dim]Report ID: {result.get('report_id', 'N/A')}[/dim]")
    elif result.get("success"):
        print_success("Feedback submitted successfully!")
        console.print(f"[dim]Report ID: {result.get('report_id', 'N/A')}[/dim]")

        # Show what was captured for confidence
        captured_parts = []
        if events_count > 0:
            captured_parts.append(f"{events_count} events")
        if console_lines > 0:
            captured_parts.append(f"{console_lines} lines console log")
        if has_objective:
            captured_parts.append("objective")
        if has_system_info:
            captured_parts.append("system info")

        if captured_parts:
            console.print(f"[dim]Included: {', '.join(captured_parts)}[/dim]")
    else:
        print_error(f"Submission failed: {result.get('message', 'Unknown error')}")


def _load_feedback_config() -> dict[str, Any]:
    """Load feedback config with customer overrides.

    Loads from:
    1. obra/config/defaults/feedback.yaml (default)
    2. .obra/config/feedback.yaml (customer override, if exists)

    Returns:
        Merged configuration dictionary
    """
    # Load default config
    obra_root = Path(__file__).parent.parent
    default_config_path = obra_root / "config" / "defaults" / "feedback.yaml"

    if not default_config_path.exists():
        msg = f"Default feedback config not found: {default_config_path}"
        raise ConfigurationError(msg)

    with default_config_path.open(encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}

    # Check for customer override
    customer_config_path = Path.cwd() / ".obra" / "config" / "feedback.yaml"
    if customer_config_path.exists():
        with customer_config_path.open(encoding="utf-8") as f:
            customer_config = yaml.safe_load(f) or {}
            # Merge customer config (customer values override defaults)
            config.update(customer_config)

    return config


def _save_feedback_consent(consent: bool) -> None:
    """Save telemetry consent to customer config.

    Args:
        consent: True to enable, False to disable
    """
    customer_config_path = Path.cwd() / ".obra" / "config" / "feedback.yaml"
    customer_config_path.parent.mkdir(parents=True, exist_ok=True)

    # Load existing customer config if present
    if customer_config_path.exists():
        with customer_config_path.open(encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}
    else:
        config = {}

    # Update telemetry_consent
    config["telemetry_consent"] = consent

    # Save back to file
    with customer_config_path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)


def _check_telemetry_consent(non_interactive: bool = False) -> bool:
    """Check if user has consented to telemetry.

    Args:
        non_interactive: If True, will not prompt and will raise exception if no consent

    Returns:
        True if consent is granted, False otherwise

    Raises:
        typer.Exit: If non-interactive mode and consent not granted (exit code 1)
    """
    try:
        config = _load_feedback_config()
        consent = config.get("telemetry_consent")

        # If consent is explicitly granted, allow submission
        if consent is True:
            return True

        # If consent is explicitly denied, block submission
        if consent is False:
            if non_interactive:
                print_error("Telemetry disabled. Enable with: obra telemetry enable")
                raise typer.Exit(1)
            console.print()
            console.print(f"[yellow]{glyphs.warning} Telemetry is disabled[/yellow]")
            console.print("Enable with: obra telemetry enable")
            console.print()
            raise typer.Exit(1)

        # If consent not yet given (None), prompt interactively or require action
        if consent is None:
            if non_interactive:
                print_error("Telemetry consent required. Enable with: obra telemetry enable")
                raise typer.Exit(1)
            console.print()
            console.print(f"[yellow]{glyphs.warning} Telemetry consent not configured[/yellow]")
            console.print()
            console.print("Before submitting feedback, you must consent to data collection.")
            console.print("To see what data is collected: obra telemetry explain")
            console.print()

            # Interactive prompt to enable telemetry inline
            allow = typer.confirm("Enable telemetry and submit feedback?", default=False)
            if allow:
                _save_feedback_consent(True)
                console.print("[green]Telemetry enabled. Submitting feedback...[/green]")
                return True

            _save_feedback_consent(False)
            console.print()
            console.print("Telemetry disabled. Enable later with: obra telemetry enable")
            console.print()
            raise typer.Exit(1)

        return False

    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Failed to check telemetry consent: {e}")
        raise typer.Exit(1) from e
