"""Planning-context helpers for CLI run/derive flows."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import typer
import yaml  # type: ignore[import-untyped]

from obra.api.protocol import ActionType
from obra.display import console, print_error

logger = logging.getLogger(__name__)

AUTHORITATIVE_IMPORTED_PLAN_BYPASS = "authoritative_imported_plan"


def _plan_search_paths(plan_id: str, base_dir: Path) -> list[Path]:
    """Build search paths for local plan files (JSON or YAML)."""
    paths: list[Path] = []
    for ext in [".json", ".yaml", ".yml"]:
        paths.extend(
            [
                base_dir / "docs" / "development" / f"{plan_id}_MACHINE_PLAN{ext}",
                base_dir / ".obra" / "plans" / f"{plan_id}{ext}",
                base_dir / f"{plan_id}{ext}",
            ]
        )
    return paths


def _format_plan_search_paths(plan_id: str, base_dir: Path) -> list[str]:
    """Format search paths relative to base directory when possible."""
    formatted_paths = []
    for path in _plan_search_paths(plan_id, base_dir):
        try:
            relative_path = path.relative_to(base_dir)
            relative_str = str(relative_path)
            if relative_path.parent == Path() and not relative_str.startswith("."):
                relative_str = f"./{relative_str}"
            formatted_paths.append(relative_str)
        except ValueError:
            formatted_paths.append(str(path))
    return formatted_paths


def _extract_plan_context(plan_data: Any, source: str) -> dict[str, Any]:
    """Validate and extract plan context from loaded data."""
    if plan_data is None:
        print_error(f"Plan file is empty: {source}")
        raise typer.Exit(1)

    if not isinstance(plan_data, dict):
        print_error(f"Plan file must be a YAML/JSON object: {source}")
        raise typer.Exit(1)

    epics = plan_data.get("epics")
    if not isinstance(epics, list) or not epics:
        print_error(f"Plan file missing 'epics' array: {source}")
        raise typer.Exit(1)

    for epic in epics:
        if not isinstance(epic, dict):
            print_error(f"Plan file contains an invalid epic entry: {source}")
            raise typer.Exit(1)

        stories = epic.get("stories")
        if not isinstance(stories, list) or not stories:
            print_error(f"Epic {epic.get('id', '<unknown>')} missing 'stories' array: {source}")
            raise typer.Exit(1)

        for story in stories:
            if not isinstance(story, dict):
                print_error(f"Plan file contains an invalid story entry: {source}")
                raise typer.Exit(1)

            tasks = story.get("tasks")
            if tasks is None:
                print_error(f"Story {story.get('id', '<unknown>')} missing 'tasks' array: {source}")
                raise typer.Exit(1)
            if not isinstance(tasks, list):
                print_error(
                    f"Story {story.get('id', '<unknown>')} has invalid tasks format (expected list): {source}"
                )
                raise typer.Exit(1)

    plan_context = dict(plan_data)
    plan_context["epics"] = epics
    plan_context["_obra_plan_source_path"] = source
    return plan_context


def _is_authoritative_imported_plan_context(plan_context: dict[str, Any] | None) -> bool:
    """Return whether plan context carries explicit executable plan items."""
    if not isinstance(plan_context, dict):
        return False

    epics = plan_context.get("epics")
    if not isinstance(epics, list) or not epics:
        return False

    for epic in epics:
        if not isinstance(epic, dict):
            return False
        stories = epic.get("stories")
        if not isinstance(stories, list) or not stories:
            return False
        for story in stories:
            if not isinstance(story, dict):
                return False
            tasks = story.get("tasks")
            if not isinstance(tasks, list):
                return False

    return True


def _load_plan_context_from_file(plan_path: Path) -> dict[str, Any]:
    """Load plan context from a local YAML/JSON file."""
    try:
        with plan_path.open(encoding="utf-8") as handle:
            try:
                plan_data = json.load(handle)
            except json.JSONDecodeError:
                handle.seek(0)
                plan_data = yaml.safe_load(handle)
    except json.JSONDecodeError as exc:
        print_error(f"Plan file is not valid JSON: {plan_path} ({exc})")
        logger.error("Plan file JSON decode error for %s: %s", plan_path, exc, exc_info=True)
        raise typer.Exit(1) from exc
    except yaml.YAMLError as exc:
        print_error(f"Plan file is not valid YAML: {plan_path} ({exc})")
        logger.error("Plan file YAML parse error for %s: %s", plan_path, exc, exc_info=True)
        raise typer.Exit(1) from exc
    except UnicodeDecodeError as exc:
        print_error(f"Plan file encoding error (expected UTF-8): {exc}")
        logger.error("Encoding error reading plan file %s: %s", plan_path, exc, exc_info=True)
        raise typer.Exit(1) from exc
    except OSError as exc:
        print_error(f"Failed to read plan file {plan_path}: {exc}")
        logger.error("File I/O error reading plan file %s: %s", plan_path, exc, exc_info=True)
        raise typer.Exit(1) from exc

    return _extract_plan_context(plan_data, str(plan_path))


def _install_imported_plan_handler(
    orchestrator: Any,
    plan_context: dict[str, Any] | None,
) -> None:
    """Preload a deterministic derive handler for imported machine plans."""
    if plan_context is None:
        return

    from obra.hybrid.handlers.imported_plan import ImportedPlanDeriveHandler

    orchestrator._handlers[ActionType.DERIVE] = ImportedPlanDeriveHandler(plan_context)
    orchestrator._imported_plan_context = plan_context


def _print_plan_lookup_error(plan_id: str, base_dir: Path) -> None:
    """Display a user-friendly error when local plan file is missing."""
    searched_paths = _format_plan_search_paths(plan_id, base_dir)
    print_error(
        "Plan file not found locally. When using --plan-id, keep the original plan file (JSON or YAML)."
    )
    console.print()
    console.print("Searched:")
    for path in searched_paths:
        console.print(f"  - {path}")
    console.print()
    console.print("Suggestion: Re-upload the plan or use --objective without --plan-id.")


def _find_plan_yaml(plan_id: str, base_dir: Path | None = None) -> Path | None:
    """Find a plan YAML/JSON file by ID in standard locations."""
    root = base_dir or Path.cwd()
    for path in _plan_search_paths(plan_id, root):
        if path.exists():
            return path
    return None
