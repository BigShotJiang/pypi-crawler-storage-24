"""Session bootstrap and config assembly helpers for CLI run/derive flows."""

from __future__ import annotations

import atexit
import logging
import os
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

import typer

from obra.cli._shared import setup_logging
from obra.cli.interrupt import _manager as _interrupt_manager
from obra.config import (
    DEFAULT_PROVIDER,
    REASONING_LEVELS,
    infer_provider_from_model,
)
from obra.display import (
    ObservabilityConfig,
    ProgressEmitter,
    console,
    print_error,
    print_warning,
    set_runtime_verbosity,
)
from obra.feedback.session_logger import start_session_logging, stop_session_logging

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ResolvedRuntime:
    """Effective model, provider, and reasoning config after resolution."""

    effective_model: str | None
    effective_fast_model: str | None
    effective_high_model: str | None
    effective_provider: str | None
    effective_reasoning: str | None


def init_session_runtime(
    *,
    resume_session: str | None,
    continue_from: str | None,
    verbose: int,
) -> None:
    """Initialize session logging and interrupt manager."""
    setup_logging(verbose)
    initial_log_session_id: str | None = None
    if resume_session is None:
        # Continue-from starts a new session, so do not attach its console log
        # to the source session ID.
        initial_log_session_id = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    if initial_log_session_id is not None:
        start_session_logging(session_id=initial_log_session_id)
    atexit.register(stop_session_logging)
    _interrupt_manager.reset()
    _interrupt_manager.install()


def resolve_effective_runtime(
    *,
    model: str | None,
    fast_model: str | None,
    high_model: str | None,
    impl_provider: str | None,
    reasoning_level: str | None,
    verbose: int,
) -> ResolvedRuntime:
    """Resolve effective model, provider, and reasoning config from CLI args and config."""
    from obra.config.resolution import resolve_run_config

    run_config = resolve_run_config(
        cli_model=model,
        cli_fast_model=fast_model,
        cli_high_model=high_model,
        cli_provider=impl_provider,
        cli_reasoning_level=reasoning_level,
    )
    effective_model = run_config.model
    effective_fast_model = run_config.fast_model
    effective_high_model = run_config.high_model
    effective_provider = run_config.provider
    effective_reasoning = run_config.reasoning_level

    if effective_fast_model is not None:
        os.environ["OBRA_FAST_MODEL"] = effective_fast_model
    if effective_high_model is not None:
        os.environ["OBRA_HIGH_MODEL"] = effective_high_model

    if effective_reasoning is not None and effective_reasoning not in REASONING_LEVELS:
        print_error(f"Invalid reasoning level: '{effective_reasoning}'")
        console.print(f"\nValid levels: {', '.join(REASONING_LEVELS)}")
        raise typer.Exit(2)

    if effective_model and not effective_provider:
        detected = infer_provider_from_model(effective_model)
        if detected:
            effective_provider = detected
            if verbose > 0:
                console.print(f"[dim]Detected provider: {detected}[/dim]")
        else:
            print_warning(
                f"Unknown model '{effective_model}', using default provider: {DEFAULT_PROVIDER}"
            )
            effective_provider = DEFAULT_PROVIDER

    return ResolvedRuntime(
        effective_model=effective_model,
        effective_fast_model=effective_fast_model,
        effective_high_model=effective_high_model,
        effective_provider=effective_provider,
        effective_reasoning=effective_reasoning,
    )


def collect_bypass_modes(
    *,
    permissive: bool,
    config_permissive: bool,
    no_closeout: bool,
    skip_intent: bool,
    review_intent: bool,
    enrich: bool,
    no_enrich: bool,
    skip_quality_check: bool,
    skip_complexity_check: bool,
    parallel: bool,
    skip_tier_check: bool,
    skip_explore: bool,
    force_explore: bool,
) -> list[str]:
    """Build the bypass mode list from CLI flags and config."""
    bypass_modes: list[str] = []
    if permissive or config_permissive:
        bypass_modes.append("planning_permissive")
    if no_closeout:
        bypass_modes.append("no_closeout")
    if skip_intent:
        bypass_modes.append("skip_intent")
    if review_intent:
        bypass_modes.append("review_intent")
    if enrich:
        bypass_modes.append("enrich")
    if no_enrich:
        bypass_modes.append("no_enrich")
    if skip_quality_check:
        bypass_modes.append("skip_quality_check")
    if skip_complexity_check:
        bypass_modes.append("skip_complexity_check")
    if parallel:
        bypass_modes.append("parallel")
    if skip_tier_check:
        bypass_modes.append("skip_tier_check")
    if skip_explore:
        bypass_modes.append("skip_explore")
    if force_explore:
        bypass_modes.append("force_explore")
    return bypass_modes


@dataclass
class ObservabilitySetup:
    """Result of building session observability config."""

    obs_config: Any
    progress_emitter: Any
    parallel: bool
    bypass_modes: list[str]
    story0_override_config: dict[str, Any] | None


def build_session_observability(
    *,
    config: dict[str, Any],
    verbose: int,
    stream: bool,
    parallel: bool,
    bypass_modes: list[str],
    yes: bool,
    mock_credentials: bool,
) -> ObservabilitySetup:
    """Build observability config, progress emitter, and related adjustments."""
    story0_override_config: dict[str, Any] | None = None
    if yes or mock_credentials:
        from obra.config.loaders import load_layered_config

        story0_override_config, _, _ = load_layered_config(include_defaults=True)
        if yes:
            story0_override_config.setdefault("story0", {})["auto_approve"] = True
        if mock_credentials:
            story0_override_config.setdefault("story0", {})["mock_credentials"] = True

    ux_config = config.get("features", {}).get("user_experience", {})
    parallel_config = config.get("execution", {}).get("parallel", {})
    parallel_enabled = bool(parallel_config.get("enabled", False))
    parallel_env_override = os.environ.get("OBRA_PARALLEL_EXECUTION", "").lower() in (
        "1",
        "true",
        "yes",
    )
    explicit_parallel_requested = parallel
    parallel = explicit_parallel_requested or parallel_enabled or parallel_env_override
    if parallel:
        if "parallel" not in bypass_modes:
            bypass_modes.append("parallel")
        max_workers_override = os.environ.get("OBRA_PARALLEL_MAX_WORKERS")
        resolved_max_workers = parallel_config.get("max_workers", 4)
        if max_workers_override:
            try:
                resolved_max_workers = int(max_workers_override)
            except ValueError:
                resolved_max_workers = parallel_config.get("max_workers", 4)
        os.environ["OBRA_PARALLEL_EXECUTION"] = "1"
        os.environ["OBRA_PARALLEL_MAX_WORKERS"] = str(resolved_max_workers)
    elif "parallel" in bypass_modes:
        bypass_modes.remove("parallel")

    dashboard_config = ux_config.get("dashboard", {})
    ux_enabled = bool(ux_config.get("enabled", True))
    dashboard_enabled = bool(dashboard_config.get("enabled", True)) and ux_enabled
    footer_hint_enabled = bool(dashboard_config.get("footer_hint", True))
    task_tracker_enabled = bool(dashboard_config.get("task_tracker", True))
    task_tracker_max_next = dashboard_config.get("task_tracker_max_next", 3)
    if not isinstance(task_tracker_max_next, int):
        try:
            task_tracker_max_next = int(task_tracker_max_next)
        except (TypeError, ValueError):
            task_tracker_max_next = 3

    obs_config = ObservabilityConfig(
        verbosity=verbose,
        stream=stream,
        timestamps=True,
        dashboard_enabled=dashboard_enabled,
        footer_hint_enabled=footer_hint_enabled,
        task_tracker_enabled=task_tracker_enabled,
        task_tracker_max_next=task_tracker_max_next,
    )
    set_runtime_verbosity(verbose)

    progress_emitter = ProgressEmitter(obs_config, console)

    return ObservabilitySetup(
        obs_config=obs_config,
        progress_emitter=progress_emitter,
        parallel=parallel,
        bypass_modes=bypass_modes,
        story0_override_config=story0_override_config,
    )


def try_create_userplan(
    *,
    objective: str,
    project_id: str | None,
    userplan_id: str | None,
) -> str | None:
    """Attempt to create and persist a UserPlan from the objective.

    Returns the userplan_id (possibly updated if creation succeeds).
    """
    try:
        from obra.execution.userplan_construction import create_userplan_from_objective_text
        from obra.execution.userplan_persistence import persist_userplan_via_api

        userplan = create_userplan_from_objective_text(
            objective=objective,
            project_id=project_id or "default",
        )
        userplan_id = userplan.id

        from obra.api import APIClient as UserPlanAPIClient

        userplan_client = UserPlanAPIClient.from_config()
        persist_userplan_via_api(
            userplan,
            client=userplan_client,
        )
        console.print(f"[dim]UserPlan created: {userplan_id}[/dim]")
        logger.info("Created UserPlan %s from objective", userplan_id)
        return userplan_id

    except typer.Exit:
        raise
    except Exception as exc:
        require_persistence = False
        try:
            from obra.config.loaders import load_layered_config

            cfg, _, _ = load_layered_config(include_defaults=True)
            require_persistence = (
                cfg.get("features", {})
                .get("userplan", {})
                .get("require_persistence", False)
            )
        except Exception:
            pass

        if require_persistence:
            logger.exception("Failed to create UserPlan (persistence required): %s", exc)
            console.print(
                f"[red]Error: UserPlan creation failed ({exc})[/red]\n"
                "[dim]Set features.userplan.require_persistence: false for standalone mode[/dim]"
            )
            raise typer.Exit(1) from exc
        error_detail = str(exc)
        is_schema_mismatch = "schema" in error_detail.lower() or "extra inputs" in error_detail.lower()
        category = "API schema mismatch" if is_schema_mismatch else "error"
        logger.warning(
            "UserPlan creation skipped (%s): %s",
            category,
            error_detail,
            exc_info=True,
        )
        print_warning(f"UserPlan creation skipped ({category}: {error_detail})")
        return userplan_id
