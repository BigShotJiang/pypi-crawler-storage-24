"""Gateway server commands for the Obra CLI.

Extracted from obra/cli/_main.py as part of REFACTOR-CLI-SUBAPPS-001.
"""
import json

from rich.markup import escape
import typer

from obra.display import (
    console,
    handle_encoding_errors,
    print_error,
    print_info,
    print_success,
    print_warning,
)

gateway_app = typer.Typer(
    name="gateway",
    help="Local gateway server for Workflow Studio and private automation access",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


@gateway_app.command("start")
@handle_encoding_errors
def gateway_start(
    host: str | None = typer.Option(
        None,
        "--host",
        help="Host to bind the gateway server (default: from config, 127.0.0.1)",
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        help="Port to bind the gateway server (default: from config, 18790)",
    ),
    token: str | None = typer.Option(
        None,
        "--token",
        help="Bearer auth token (required for private-automation profile; otherwise auto-generated)",
    ),
    max_sessions: int | None = typer.Option(
        None,
        "--max-sessions",
        help="Max concurrent sessions (default: from config, 5)",
    ),
    profile: str | None = typer.Option(
        None,
        "--profile",
        help="Gateway profile: standard or private-automation",
    ),
) -> None:
    """Start the local gateway server.

    Launches a FastAPI server providing canonical Workflow Studio routes and
    a private automation control surface. The supported private automation
    topology keeps the gateway on loopback and reaches it remotely through
    SSH tunnels or private overlays.

    Requires gateway dependencies. Install with
    `uv tool install obra --with 'obra[gateway]'`.

    Examples:
        obra gateway start
        obra gateway start --port 9000
        obra gateway start --token my-secret-token
    """
    from obra.config.loaders import get_gateway_config

    gateway_config = get_gateway_config()

    # Apply CLI overrides
    if token is not None:
        gateway_config["auth_token"] = token
    if max_sessions is not None:
        gateway_config["max_sessions"] = max_sessions
    if profile is not None:
        gateway_config["profile"] = profile

    try:
        from obra.gateway.server import GatewayServer
    except ImportError:
        from obra.cli.studio import _studio_gateway_install_hint

        print_error(
            "Gateway requires additional dependencies.\n"
            f"Install with: {escape(_studio_gateway_install_hint())}"
        )
        raise typer.Exit(code=1) from None

    server = GatewayServer(config=gateway_config)

    try:
        server.run(host=host, port=port)
    except (RuntimeError, ValueError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1) from exc
    except KeyboardInterrupt:
        console.print()
        print_info("Gateway server shutting down")


@gateway_app.command("status")
@handle_encoding_errors
def gateway_status(
    host: str | None = typer.Option(
        None,
        "--host",
        help="Gateway host to check (default: from config)",
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        help="Gateway port to check (default: from config)",
    ),
) -> None:
    """Check if the gateway server is running.

    Probes the gateway /health endpoint and reports status.

    Examples:
        obra gateway status
        obra gateway status --port 9000
    """
    import requests

    from obra.config.loaders import get_gateway_config

    gateway_config = get_gateway_config()
    check_host = host or gateway_config.get("host", "127.0.0.1")
    check_port = port or gateway_config.get("port", 18790)

    url = f"http://{check_host}:{check_port}/health"
    try:
        resp = requests.get(url, timeout=2)
        data = resp.json()
        status_value = data.get("status", "unknown")
        print_success(
            f"Gateway running on {check_host}:{check_port}\n"
            f"  Status: {status_value}"
        )
    except requests.ConnectionError:
        print_warning(f"Gateway is not running (tried {check_host}:{check_port})")
    except Exception as exc:
        print_error(f"Failed to check gateway status: {exc}")


@gateway_app.command("automation-template")
@handle_encoding_errors
def gateway_automation_template() -> None:
    """Print the generic bootstrap contract for private automation clients."""
    from obra.config.loaders import get_gateway_config
    from obra.gateway.automation.control_surface import GatewayAutomationControlSurface

    template = GatewayAutomationControlSurface.build_bootstrap_template_from_config(
        get_gateway_config()
    )
    console.print_json(json.dumps(template))
