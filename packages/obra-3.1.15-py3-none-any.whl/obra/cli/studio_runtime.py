"""Launch-state helpers for the `obra studio` command."""

from __future__ import annotations

import json
import subprocess
import sys
import time
import contextlib
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path

import psutil
import requests

from obra.utils.obra_home import resolve_runtime_dir

_DEFAULT_LAUNCH_TIMEOUT_S = 15.0


@dataclass
class StudioGatewayState:
    """Persisted launcher-owned gateway state."""

    host: str
    port: int
    token: str
    pid: int | None
    started_at: str
    process_create_time: float | None = None


def _state_path() -> Path:
    return resolve_runtime_dir().path / "studio" / "gateway_state.json"


def _gateway_log_path() -> Path:
    return resolve_runtime_dir().path / "studio" / "gateway.log"


def _gateway_base_url(host: str, port: int) -> str:
    return f"http://{host}:{port}"


def load_studio_gateway_state() -> StudioGatewayState | None:
    path = _state_path()
    if not path.exists():
        return None
    payload = json.loads(path.read_text(encoding="utf-8"))
    return StudioGatewayState(
        host=str(payload["host"]),
        port=int(payload["port"]),
        token=str(payload["token"]),
        pid=int(payload["pid"]) if payload.get("pid") is not None else None,
        started_at=str(payload["started_at"]),
        process_create_time=(
            float(payload["process_create_time"])
            if payload.get("process_create_time") is not None
            else None
        ),
    )


def save_studio_gateway_state(state: StudioGatewayState) -> None:
    path = _state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(asdict(state), indent=2, sort_keys=True) + "\n", encoding="utf-8")


def clear_studio_gateway_state() -> None:
    path = _state_path()
    if path.exists():
        path.unlink()


def _process_from_pid(
    pid: int | None,
    *,
    expected_create_time: float | None = None,
) -> psutil.Process | None:
    if pid is None or pid <= 0:
        return None
    try:
        process = psutil.Process(pid)
        if not process.is_running():
            return None
        with contextlib.suppress(psutil.Error):
            if process.status() == psutil.STATUS_ZOMBIE:
                return None
        if expected_create_time is not None:
            create_time = process.create_time()
            if abs(create_time - expected_create_time) > 1.0:
                return None
        return process
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None


def _process_create_time(process: psutil.Process | None) -> float | None:
    if process is None:
        return None
    try:
        return float(process.create_time())
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None


def is_process_running(
    pid: int | None,
    *,
    expected_create_time: float | None = None,
) -> bool:
    return _process_from_pid(pid, expected_create_time=expected_create_time) is not None


def probe_gateway(base_url: str) -> bool:
    try:
        response = requests.get(f"{base_url}/health", timeout=1.5)
    except requests.RequestException:
        return False
    return response.ok


def probe_gateway_auth(base_url: str, token: str | None) -> bool:
    normalized_token = str(token or "").strip()
    if not normalized_token:
        return False
    try:
        response = requests.get(
            f"{base_url}/api/health/details",
            headers={"Authorization": f"Bearer {normalized_token}"},
            timeout=2,
        )
    except requests.RequestException:
        return False
    return response.ok


def _extract_connection_address(laddr: object) -> tuple[str, int] | None:
    if hasattr(laddr, "ip") and hasattr(laddr, "port"):
        return str(getattr(laddr, "ip")), int(getattr(laddr, "port"))
    if isinstance(laddr, tuple) and len(laddr) >= 2:
        return str(laddr[0]), int(laddr[1])
    return None


def _listener_matches_host(target_host: str, listen_host: str) -> bool:
    normalized_target = target_host.strip().lower()
    normalized_listen = listen_host.strip().lower()
    if normalized_target in {"127.0.0.1", "localhost", "::1"}:
        return normalized_listen in {"127.0.0.1", "localhost", "::1", "0.0.0.0", "::", ""}
    return normalized_target == normalized_listen


def find_gateway_listener_process(host: str, port: int) -> psutil.Process | None:
    try:
        connections = psutil.net_connections(kind="inet")
    except (psutil.Error, OSError):
        return None

    candidates: list[psutil.Process] = []
    for connection in connections:
        if getattr(connection, "status", "") != psutil.CONN_LISTEN:
            continue
        address = _extract_connection_address(getattr(connection, "laddr", None))
        if address is None:
            continue
        listen_host, listen_port = address
        if listen_port != port or not _listener_matches_host(host, listen_host):
            continue
        process = _process_from_pid(getattr(connection, "pid", None))
        if process is not None:
            candidates.append(process)

    if not candidates:
        return None
    return min(candidates, key=lambda process: process.pid)


def _process_cmdline(process: psutil.Process) -> list[str]:
    try:
        return [str(part) for part in process.cmdline() if str(part).strip()]
    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.Error):
        return []


def _looks_like_obra_gateway_process(process: psutil.Process) -> bool:
    cmdline = _process_cmdline(process)
    if not cmdline:
        return False

    normalized_args = [part.strip().lower() for part in cmdline if part.strip()]
    normalized_basenames = {Path(part).name.strip().lower() for part in cmdline if part.strip()}

    has_gateway_start = "gateway" in normalized_args and "start" in normalized_args
    if not has_gateway_start:
        return False

    if "obra.cli" in normalized_args:
        return True

    obra_entrypoints = {
        "obra",
        "obra.exe",
        "obra-script.py",
        "obra-script.pyw",
    }
    return any(name in obra_entrypoints for name in normalized_basenames)


def find_obra_gateway_listener_process(host: str, port: int) -> psutil.Process | None:
    process = find_gateway_listener_process(host, port)
    if process is None:
        return None
    if not _looks_like_obra_gateway_process(process):
        return None
    return process


def recover_studio_gateway_state(state: StudioGatewayState) -> StudioGatewayState | None:
    base_url = _gateway_base_url(state.host, state.port)
    if not probe_gateway(base_url):
        return None
    if not probe_gateway_auth(base_url, state.token):
        return None

    process = _process_from_pid(
        state.pid,
        expected_create_time=state.process_create_time,
    )
    if process is None:
        process = find_gateway_listener_process(state.host, state.port)

    return StudioGatewayState(
        host=state.host,
        port=state.port,
        token=state.token,
        pid=process.pid if process is not None else None,
        started_at=state.started_at,
        process_create_time=_process_create_time(process),
    )


def terminate_studio_gateway_process(pid: int, *, timeout_s: float = 5.0) -> None:
    """Terminate a launcher-owned Studio gateway process tree."""
    if pid <= 0:
        raise RuntimeError(f"Invalid Studio gateway pid: {pid}")

    try:
        process = psutil.Process(pid)
    except psutil.NoSuchProcess:
        return
    except psutil.AccessDenied as exc:
        raise RuntimeError(f"Access denied while stopping Studio gateway pid {pid}") from exc

    children: list[psutil.Process] = []
    with contextlib.suppress(psutil.NoSuchProcess, psutil.AccessDenied):
        children = process.children(recursive=True)

    all_processes = [*children, process]
    for child in all_processes:
        with contextlib.suppress(psutil.NoSuchProcess, psutil.AccessDenied):
            child.terminate()

    _gone, alive = psutil.wait_procs(all_processes, timeout=timeout_s)
    for child in alive:
        with contextlib.suppress(psutil.NoSuchProcess, psutil.AccessDenied):
            child.kill()


def stop_studio_gateway(
    *,
    state: StudioGatewayState | None = None,
    timeout_s: float = 5.0,
) -> dict[str, object]:
    """Stop the launcher-owned Studio gateway when it is safe to do so."""
    current = state or load_studio_gateway_state()
    if current is None:
        return {"stopped": False, "reason": "not_tracked"}

    base_url = _gateway_base_url(current.host, current.port)
    if current.pid is None:
        recovered = recover_studio_gateway_state(current)
        if recovered is not None and recovered.pid is not None:
            current = recovered
            save_studio_gateway_state(current)
        else:
            if probe_gateway(base_url):
                return {
                    "stopped": False,
                    "reason": "unowned_gateway",
                    "host": current.host,
                    "port": current.port,
                }
            clear_studio_gateway_state()
            return {
                "stopped": False,
                "reason": "stale_state_cleared",
                "host": current.host,
                "port": current.port,
            }

    if not is_process_running(
        current.pid,
        expected_create_time=current.process_create_time,
    ):
        recovered = recover_studio_gateway_state(current)
        if recovered is None or recovered.pid is None:
            clear_studio_gateway_state()
            return {
                "stopped": False,
                "reason": "stale_state_cleared",
                "host": current.host,
                "port": current.port,
                "pid": current.pid,
            }
        current = recovered
        save_studio_gateway_state(current)

    terminate_studio_gateway_process(current.pid, timeout_s=timeout_s)
    clear_studio_gateway_state()
    return {
        "stopped": True,
        "reason": "stopped",
        "host": current.host,
        "port": current.port,
        "pid": current.pid,
    }


def stop_untracked_studio_gateway(
    *,
    host: str,
    port: int,
    timeout_s: float = 5.0,
) -> dict[str, object]:
    """Stop an untracked listener when it is positively identified as an Obra gateway."""
    process = find_obra_gateway_listener_process(host, port)
    if process is None:
        return {
            "stopped": False,
            "reason": "untracked_process_not_identified",
            "host": host,
            "port": port,
        }

    terminate_studio_gateway_process(process.pid, timeout_s=timeout_s)
    return {
        "stopped": True,
        "reason": "stopped_untracked",
        "host": host,
        "port": port,
        "pid": process.pid,
    }


def resolve_or_create_gateway_state(*, host: str, port: int, configured_token: str | None) -> StudioGatewayState | None:
    existing = load_studio_gateway_state()
    if existing and existing.host == host and existing.port == port:
        recovered = recover_studio_gateway_state(existing)
        if recovered is not None:
            save_studio_gateway_state(recovered)
            return recovered
        clear_studio_gateway_state()

    if configured_token and probe_gateway(_gateway_base_url(host, port)):
        process = find_gateway_listener_process(host, port)
        reused = StudioGatewayState(
            host=host,
            port=port,
            token=configured_token,
            pid=process.pid if process is not None else None,
            started_at=datetime.now(UTC).isoformat(),
            process_create_time=_process_create_time(process),
        )
        save_studio_gateway_state(reused)
        return reused

    return None


def start_studio_gateway(*, host: str, port: int, token: str | None = None, timeout_s: float = _DEFAULT_LAUNCH_TIMEOUT_S) -> StudioGatewayState:
    from obra.gateway.auth import generate_token

    studio_token = token or generate_token()
    if probe_gateway(_gateway_base_url(host, port)):
        raise RuntimeError(
            f"Gateway already appears to be running on {_gateway_base_url(host, port)}, "
            "but `obra studio` does not have a reusable token for it. Set "
            "`OBRA_GATEWAY_AUTH_TOKEN` or `gateway.auth_token`, or stop the existing "
            "gateway and launch through `obra studio`."
        )

    log_path = _gateway_log_path()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("ab") as log_handle:
        process = subprocess.Popen(  # noqa: S603
            [
                sys.executable,
                "-m",
                "obra.cli",
                "gateway",
                "start",
                "--host",
                host,
                "--port",
                str(port),
                "--token",
                studio_token,
            ],
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )

    deadline = time.monotonic() + timeout_s
    base_url = _gateway_base_url(host, port)
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(
                f"Studio gateway exited before becoming ready. Check {_gateway_log_path()}."
            )
        if probe_gateway(base_url):
            process_info = _process_from_pid(process.pid)
            state = StudioGatewayState(
                host=host,
                port=port,
                token=studio_token,
                pid=process.pid,
                started_at=datetime.now(UTC).isoformat(),
                process_create_time=_process_create_time(process_info),
            )
            save_studio_gateway_state(state)
            return state
        time.sleep(0.25)

    terminate_studio_gateway_process(process.pid, timeout_s=1.0)
    raise RuntimeError(f"Timed out waiting for Studio gateway at {base_url} to become ready.")


def mint_studio_launch_url(*, base_url: str, token: str, next_path: str) -> str:
    try:
        response = requests.post(
            f"{base_url}/studio/api/bootstrap-links",
            params={"next": next_path},
            headers={"Authorization": f"Bearer {token}"},
            timeout=5,
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"Failed to mint Studio browser launch URL: {exc}") from exc
    if response.status_code != 200:
        raise RuntimeError(
            f"Gateway rejected Studio browser bootstrap ({response.status_code}): {response.text}"
        )
    payload = response.json()
    launch_url = str(payload.get("launch_url") or "").strip()
    if not launch_url:
        raise RuntimeError("Gateway bootstrap response did not include a Studio launch URL.")
    return launch_url
