"""Doctor command implementation extracted from obra.cli._main."""

from __future__ import annotations

import logging
import os
import platform
import sys
from pathlib import Path
from typing import Any

from rich.markup import escape
import typer

from obra import __version__
from obra.cli.feedback import offer_bug_report
from obra.config import DEFAULT_MODEL, DEFAULT_PROVIDER, DEFAULT_REASONING_LEVEL
from obra.display import console, glyphs, handle_encoding_errors, print_error
from obra.exceptions import APIError
from obra.messages import get_message
from obra.model_registry import resolve_quality_tier

logger = logging.getLogger(__name__)

def _resolve_doctor_llm_config() -> dict[str, Any]:
    """Resolve the effective implementation LLM config for doctor output."""

    from obra.config.llm import resolve_llm_config

    return resolve_llm_config(
        "implementation",
        override_provider=os.environ.get("OBRA_PROVIDER") or None,
        override_model=os.environ.get("OBRA_MODEL") or None,
    )

def doctor(
    report: bool = typer.Option(
        False,
        "--report",
        help="Submit diagnostic report if checks fail (for troubleshooting)",
    ),
) -> None:
    """Run health checks on your Obra environment.

    Validates:
    - Python version compatibility
    - Authentication status
    - Provider CLI availability (claude, codex, gemini, ollama)
    - API connectivity and server compatibility
    - Working directory write permissions
    - Provider-specific configuration (git for Codex, etc.)

    Run this before 'obra run' to catch configuration issues early.

    Examples:
        $ obra doctor
        $ obra doctor --report   # Auto-submit if issues found
    """

    console.print()
    console.print("[bold]Obra Health Check[/bold]", style="cyan")
    console.print()

    # Show client info first (not a check, just informational)
    console.print("[bold]Client Info:[/bold]")
    console.print(f"  Obra: v{__version__}")
    console.print(f"  Platform: {platform.system()} {platform.release()}")
    console.print()

    checks_passed = 0
    total_checks = 7  # Python, Auth, Provider CLIs, API, Working Dir, Studio, Provider Config
    doctor_llm_config: dict[str, Any] | None = None
    studio_payload: dict[str, Any] | None = None

    # Check 1: Python version
    console.print("[bold]Python Version:[/bold]")
    python_version = sys.version_info
    version_str = f"{python_version.major}.{python_version.minor}.{python_version.micro}"

    if python_version >= (3, 12):
        console.print(f"  [green]{glyphs.success}[/green] Python {version_str} (recommended)")
        checks_passed += 1
    else:
        console.print(
            f"  [yellow]{glyphs.warning}[/yellow] Python {version_str} (Python 3.12+ recommended)"
        )
        console.print(
            "    [dim]Obra works with Python 3.10+, but 3.12+ is recommended for best performance[/dim]"
        )
        if python_version >= (3, 10):
            checks_passed += 1  # Still passes, just with warning

    console.print()

    # Check 2: Authentication status
    console.print("[bold]Authentication:[/bold]")
    try:
        from obra.auth import get_current_auth

        auth = get_current_auth()

        if auth:
            console.print(f"  [green]{glyphs.success}[/green] Logged in as {auth.email}")
            checks_passed += 1
        else:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Not logged in")
            console.print(f"    [dim]{get_message('recovery.auth.login')}[/dim]")
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] Authentication check failed: {e}")
        logger.debug(f"Auth check error: {e}", exc_info=True)

    console.print()

    # Check 3: Provider CLIs
    console.print("[bold]Provider CLIs:[/bold]")
    try:
        from obra.config import LLM_PROVIDERS, check_provider_status

        provider_count = 0
        for provider_key in LLM_PROVIDERS:
            status = check_provider_status(provider_key)
            provider_name = LLM_PROVIDERS[provider_key].get("name", provider_key)

            if status.installed:
                console.print(
                    f"  [green]{glyphs.success}[/green] {provider_name} ({status.cli_command})"
                )
                provider_count += 1
            else:
                console.print(
                    f"  [red]{glyphs.failure}[/red] {provider_name} ({status.cli_command}) - not found"
                )

        # At least one provider installed counts as passing
        if provider_count > 0:
            checks_passed += 1
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] Provider check failed: {e}")
        logger.debug(f"Provider check error: {e}", exc_info=True)

    console.print()

    # Check 4: API Connectivity and Server Compatibility
    console.print("[bold]API Connectivity:[/bold]")
    try:
        from obra.api import APIClient
        from obra.config import get_api_base_url

        # Create unauthenticated client for version check
        client = APIClient(base_url=get_api_base_url())

        try:
            server_info = client.get_version()
            server_version = server_info.get("version", "N/A")
            api_version = server_info.get("api_version", "N/A")
            compatible = server_info.get("compatible", True)
            min_client = server_info.get("min_client_version", "0.0.0")

            console.print(f"  [green]{glyphs.success}[/green] Obra API reachable")
            console.print(f"    [dim]Server: v{server_version} (API {api_version})[/dim]")

            if compatible:
                console.print("    [dim]Client compatible with server[/dim]")
                checks_passed += 1
            else:
                console.print(
                    f"    [yellow]{glyphs.warning} Client update required (minimum: {min_client})[/yellow]"
                )
                console.print("    [dim]Run: pip install --upgrade obra[/dim]")
                # Still count as passed since API is reachable
                checks_passed += 1

        except APIError as e:
            if e.status_code == 0:
                console.print(f"  [red]{glyphs.failure}[/red] Cannot reach Obra API")
                console.print("    [dim]Check your network connection[/dim]")
            else:
                console.print(f"  [yellow]{glyphs.warning}[/yellow] API returned error: {e}")
            logger.debug(f"API error in doctor: {e}", exc_info=True)
        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"  [red]{glyphs.failure}[/red] Cannot reach Obra API")
            console.print(f"    [dim]Error: {e}[/dim]")
            logger.debug(f"Connection error in doctor: {e}", exc_info=True)

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] API check failed: {e}")
        logger.debug(f"API check error: {e}", exc_info=True)

    console.print()

    # Check 5: Working Directory
    console.print("[bold]Working Directory:[/bold]")
    try:
        cwd = Path.cwd()
        console.print(f"  Path: {cwd}")

        # Test if we can write to the directory
        test_file = cwd / ".obra_doctor_test"
        try:
            test_file.write_text("test")
            test_file.unlink()
            console.print(f"  [green]{glyphs.success}[/green] Directory is writable")
            checks_passed += 1
        except PermissionError:
            console.print(f"  [red]{glyphs.failure}[/red] Directory is not writable")
            console.print("    [dim]Obra needs write access to create files[/dim]")
        except OSError as e:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Write test failed: {e}")
            # Still pass if it's not a permission issue (e.g., disk full is recoverable)
            checks_passed += 1

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] Working directory check failed: {e}")
        logger.debug(f"Working directory check error: {e}", exc_info=True)

    console.print()

    # Check 6: Workflow Studio readiness
    console.print("[bold]Workflow Studio:[/bold]")
    try:
        from obra.cli.studio import (
            _collect_studio_preflight,
            _studio_gateway_install_hint,
            _voice_dependency_available,
            _voice_install_hint,
        )

        studio_payload = _collect_studio_preflight(no_browser=True, host=None, port=None)
        if bool(studio_payload.get("healthy")):
            console.print(f"  [green]{glyphs.success}[/green] Workflow Studio preflight passed")
            checks_passed += 1
        else:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Workflow Studio needs attention")
            has_gateway_runtime_issue = False
            for check in studio_payload.get("checks", []):
                if not isinstance(check, dict) or str(check.get("status")) != "fail":
                    continue
                if str(check.get("name")) == "gateway_python_extra":
                    has_gateway_runtime_issue = True
                console.print(f"    [dim]{escape(str(check.get('detail')))}[/dim]")
            console.print("    [dim]Run: obra studio doctor[/dim]")
            if has_gateway_runtime_issue:
                console.print(
                    "    [dim]"
                    f"Install Workflow Studio runtime: {escape(_studio_gateway_install_hint())}"
                    "[/dim]"
                )
        if not _voice_dependency_available():
            console.print(
                "    [dim]"
                f"Optional voice dictation: {escape(_voice_install_hint())}"
                "[/dim]"
            )

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [yellow]{glyphs.warning}[/yellow] Workflow Studio check failed: {e}")
        logger.debug(f"Workflow Studio doctor check error: {e}", exc_info=True)

    console.print()

    # Check 7: Provider Configuration
    # Validates provider-specific requirements before execution
    console.print("[bold]Provider Configuration:[/bold]")
    try:
        from obra.cli.config import (
            _config_schema,
            _config_schema_version_warnings,
            _maybe_emit_ollama_fast_tip,
        )
        from obra.config.loaders import load_config_with_warnings

        config, warnings, _ = load_config_with_warnings()
        llm_config = config.get("llm", {})

        # Use resolve_llm_config to properly handle "per-role" delegation
        # This ensures we get the actual provider, not the delegation placeholder
        doctor_llm_config = _resolve_doctor_llm_config()
        selected_provider = doctor_llm_config.get("provider", DEFAULT_PROVIDER)

        schema = _config_schema()
        schema_warnings = _config_schema_version_warnings(config, schema)
        if warnings or schema_warnings:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] Config warnings detected")
            for warning in warnings + schema_warnings:
                console.print(f"    [dim]{warning}[/dim]")

        provider_issues = []
        provider_warnings = []

        # Codex-specific checks
        if selected_provider == "openai":
            # Check 6a: Git repository status for Codex
            cwd = Path.cwd()
            is_git_repo = (cwd / ".git").exists() or any(
                (parent / ".git").exists() for parent in cwd.parents
            )

            # Check config for auto_init_git and skip_git_check
            codex_config = llm_config.get("codex", {})
            auto_init_git = codex_config.get("auto_init_git", False)
            skip_git_check = codex_config.get("skip_git_check", False)

            if is_git_repo:
                console.print(
                    f"  [green]{glyphs.success}[/green] Git repository detected (Codex requirement)"
                )
            elif auto_init_git:
                console.print(
                    f"  [green]{glyphs.success}[/green] Git auto-init enabled (llm.codex.auto_init_git: true)"
                )
            elif skip_git_check:
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] Git check disabled (llm.codex.skip_git_check: true)"
                )
                provider_warnings.append("Git safety features bypassed")
            else:
                console.print(f"  [red]{glyphs.failure}[/red] Not in a git repository")
                console.print("    [dim]Codex requires git. Options:[/dim]")
                console.print("    [dim]  1. Run 'git init' in your project[/dim]")
                console.print("    [dim]  2. Set llm.codex.auto_init_git: true in config[/dim]")
                console.print("    [dim]  3. Set llm.codex.skip_git_check: true to bypass[/dim]")
                provider_issues.append("Git repository required for Codex")

        # Gemini-specific checks
        elif selected_provider == "google":
            console.print(f"  [green]{glyphs.success}[/green] Gemini provider configured")
            console.print("    [dim]Sandbox mode: permissive (for execution)[/dim]")

        # Anthropic/Claude-specific checks
        elif selected_provider == "anthropic":
            console.print(f"  [green]{glyphs.success}[/green] Claude provider configured")

        # Ollama-specific checks
        elif selected_provider == "ollama":
            console.print(f"  [green]{glyphs.success}[/green] Ollama provider configured")
            console.print("    [dim]Ensure Ollama server is running locally[/dim]")
            _maybe_emit_ollama_fast_tip(config)
            reasoning_level = doctor_llm_config.get("reasoning_level", "medium")
            enrichment = config.get("planning", {}).get("enrichment", {}).get("enabled", True)
            refinement_planning = (
                config.get("refinement", {}).get("planning", {}).get("enabled", True)
            )
            if reasoning_level not in ("off", "low"):
                console.print(
                    f"    [yellow]{glyphs.warning}[/yellow] Ollama runs faster with reasoning_level=off "
                    "(or use --profile ollama-fast)"
                )
            if enrichment or refinement_planning:
                console.print(
                    f"    [yellow]{glyphs.warning}[/yellow] Enrichment/refinement planning can be slow on local models; "
                    "consider --profile ollama-fast"
                )

        else:
            console.print(
                f"  [yellow]{glyphs.warning}[/yellow] Unknown provider: {selected_provider}"
            )
            provider_warnings.append(f"Unrecognized provider: {selected_provider}")

        # Determine pass/fail for this check
        if not provider_issues:
            if provider_warnings:
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] {len(provider_warnings)} warning(s) - check config"
                )
            checks_passed += 1
        else:
            console.print(
                f"  [red]{glyphs.failure}[/red] {len(provider_issues)} issue(s) need resolution"
            )

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [red]{glyphs.failure}[/red] Provider config check failed: {e}")
        logger.debug(f"Provider config check error: {e}", exc_info=True)

    console.print()

    # FEAT-MODEL-QUALITY-001 S3.T1: Show LLM Config with quality tier
    console.print("[bold]LLM Config:[/bold]")
    try:
        if doctor_llm_config is None:
            doctor_llm_config = _resolve_doctor_llm_config()

        llm_provider = doctor_llm_config.get("provider", DEFAULT_PROVIDER)
        llm_model = doctor_llm_config.get("model", DEFAULT_MODEL)
        reasoning_level = doctor_llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)
        quality_tier = resolve_quality_tier(llm_provider, llm_model)
        tier_suffix = " (auto-permissive)" if quality_tier == "fast" else ""
        console.print(f"  Provider: {llm_provider}")
        console.print(f"  Model: {llm_model}")
        console.print(f"  Reasoning level: {reasoning_level}")
        console.print(f"  Quality tier: {quality_tier}{tier_suffix}")
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"  [yellow]{glyphs.warning}[/yellow] Could not resolve LLM config: {e}")
        logger.debug(f"LLM config resolution error: {e}", exc_info=True)

    console.print()

    # Summary - Report Card Style
    console.print("[bold]Overall Health:[/bold]")
    percentage = int((checks_passed / total_checks) * 100)

    if percentage == 100:
        status_icon = f"[green]{glyphs.success}[/green]"
        status_text = "[green]Excellent - All checks passed![/green]"
    elif percentage >= 80:
        status_icon = f"[green]{glyphs.success}[/green]"
        status_text = "[green]Good - System is functional[/green]"
    elif percentage >= 60:
        status_icon = f"[yellow]{glyphs.warning}[/yellow]"
        status_text = "[yellow]Fair - Some issues detected[/yellow]"
    else:
        status_icon = f"[red]{glyphs.failure}[/red]"
        status_text = "[red]Poor - Multiple issues need attention[/red]"

    console.print(f"  {status_icon} {checks_passed}/{total_checks} checks passed ({percentage}%)")
    console.print(f"  {status_text}")
    console.print()

    # Offer to report issues if checks failed
    if percentage < 100:
        failed_checks = total_checks - checks_passed
        if report:
            # Auto-submit diagnostic report
            offer_bug_report(
                context="doctor diagnostics",
                command_used="obra doctor --report",
                failure_reason=f"{failed_checks} health check(s) failed ({percentage}%)",
                auto_report=True,
                diagnostic_payloads=(
                    {"workflow_studio": studio_payload}
                    if isinstance(studio_payload, dict)
                    else None
                ),
            )
        else:
            console.print(
                "[dim]Having trouble? Run 'obra doctor --report' to submit diagnostics[/dim]"
            )
            console.print()

    # Show log paths hint
    console.print("[dim]Logs & monitoring: See ~/.obra/README.md for log paths and commands[/dim]")
    console.print()
