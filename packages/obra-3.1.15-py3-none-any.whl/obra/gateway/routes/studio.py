"""Gateway-mounted Workflow Studio browser shell and bootstrap routes."""

from __future__ import annotations

from http import HTTPStatus
from typing import Annotated
from urllib.parse import urlencode

from fastapi import APIRouter, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse, RedirectResponse

from obra.gateway.studio_browser import (
    clear_studio_browser_session,
    consume_studio_launch_token,
    is_bearer_authenticated,
    is_studio_browser_authenticated_request,
    issue_studio_browser_session,
    issue_studio_launch_token,
    refresh_studio_browser_session,
    studio_session_ttl_s,
    studio_launch_token_ttl_s,
)
from obra.studio_web import StudioWebAssetStore, StudioWebAssetsMissingError

router = APIRouter(tags=["studio"])

_ASSET_STORE = StudioWebAssetStore()
_NO_STORE_HEADERS = {
    "Cache-Control": "no-store",
    "Pragma": "no-cache",
}


def _expected_gateway_token(request: Request) -> str:
    return str(request.app.state.gateway_token)


def _require_bearer_auth(request: Request) -> None:
    if is_bearer_authenticated(request.headers, expected_token=_expected_gateway_token(request)):
        return
    raise HTTPException(
        status_code=HTTPStatus.UNAUTHORIZED,
        detail="Valid bearer token is required",
    )


def _normalize_next_path(next_path: str | None) -> str:
    normalized = (next_path or "").strip()
    if not normalized:
        return "/studio/"
    if not normalized.startswith("/studio/") and normalized != "/studio":
        return "/studio/"
    return normalized if normalized != "/studio" else "/studio/"


@router.post("/studio/api/auth/session")
async def create_studio_browser_session(request: Request) -> JSONResponse:
    """Create a browser session cookie for same-origin Studio usage."""
    _require_bearer_auth(request)
    response = JSONResponse({"authenticated": True, "mode": "browser_session"})
    issue_studio_browser_session(response, request)
    response.headers.update(_NO_STORE_HEADERS)
    return response


@router.get("/studio/api/auth/session")
async def get_studio_browser_session(request: Request) -> JSONResponse:
    """Report whether the browser currently has a valid Studio session cookie."""
    response = JSONResponse(
        {
            "authenticated": True,
            "mode": "browser_session",
            "ttl_s": studio_session_ttl_s(request.app),
        }
    )
    if not refresh_studio_browser_session(response, request):
        raise HTTPException(
            status_code=HTTPStatus.UNAUTHORIZED,
            detail="Studio browser session required",
        )
    response.headers.update(_NO_STORE_HEADERS)
    return response


@router.put("/studio/api/auth/session")
async def refresh_studio_browser_session_route(request: Request) -> JSONResponse:
    """Extend an existing Studio browser session cookie."""
    response = JSONResponse(
        {
            "authenticated": True,
            "mode": "browser_session",
            "ttl_s": studio_session_ttl_s(request.app),
        }
    )
    if not refresh_studio_browser_session(response, request):
        raise HTTPException(
            status_code=HTTPStatus.UNAUTHORIZED,
            detail="Studio browser session required",
        )
    response.headers.update(_NO_STORE_HEADERS)
    return response


@router.delete("/studio/api/auth/session")
async def delete_studio_browser_session(request: Request) -> Response:
    """Clear the current Studio browser session."""
    response = Response(status_code=HTTPStatus.NO_CONTENT)
    clear_studio_browser_session(response, request)
    response.headers.update(_NO_STORE_HEADERS)
    return response


@router.post("/studio/api/bootstrap-links")
async def create_studio_bootstrap_link(
    request: Request,
    next: Annotated[str | None, Query(alias="next")] = None,
) -> JSONResponse:
    """Mint a one-time Studio launch link for the CLI-owned browser bootstrap path."""
    _require_bearer_auth(request)
    next_path = _normalize_next_path(next)
    launch_token = issue_studio_launch_token(request)
    launch_query = urlencode({"launch_token": launch_token, "next": next_path})
    base_url = str(request.base_url).rstrip("/")
    response = JSONResponse(
        {
            "launch_url": f"{base_url}/studio/bootstrap?{launch_query}",
            "launch_token_ttl_s": studio_launch_token_ttl_s(request.app),
            "next": next_path,
        }
    )
    response.headers.update(_NO_STORE_HEADERS)
    return response


@router.get("/studio/bootstrap", include_in_schema=False)
async def bootstrap_studio_browser_session(
    request: Request,
    launch_token: str,
    next: Annotated[str | None, Query(alias="next")] = None,
) -> RedirectResponse:
    """Consume a one-time launch token, set the browser session, and redirect into Studio."""
    next_path = _normalize_next_path(next)
    if not consume_studio_launch_token(request, launch_token):
        failure_query = urlencode({"bootstrap_error": "expired", "next": next_path})
        return RedirectResponse(
            url=f"/studio/?{failure_query}",
            status_code=HTTPStatus.SEE_OTHER,
        )

    response = RedirectResponse(url=next_path, status_code=HTTPStatus.SEE_OTHER)
    issue_studio_browser_session(response, request)
    response.headers.update(_NO_STORE_HEADERS)
    return response


@router.get("/studio", include_in_schema=False)
async def redirect_studio_root() -> RedirectResponse:
    return RedirectResponse(url="/studio/", status_code=HTTPStatus.TEMPORARY_REDIRECT)


def _serve_packaged_studio_asset(relative_path: str) -> Response:
    if not relative_path or "." not in relative_path.rsplit("/", 1)[-1]:
        return Response(
            content=_ASSET_STORE.read_index_html(),
            media_type="text/html; charset=utf-8",
            headers=_NO_STORE_HEADERS,
        )

    content, media_type = _ASSET_STORE.read_asset(relative_path)
    headers = {"Cache-Control": "public, max-age=31536000, immutable"}
    return Response(content=content, media_type=media_type, headers=headers)


@router.get("/studio/", include_in_schema=False)
@router.get("/studio/{asset_path:path}", include_in_schema=False)
async def serve_studio_shell(asset_path: str = "") -> Response:
    """Serve the packaged Workflow Studio browser shell with SPA deep-link fallback."""
    try:
        return _serve_packaged_studio_asset(asset_path)
    except StudioWebAssetsMissingError as exc:
        raise HTTPException(
            status_code=HTTPStatus.SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail=f"Studio asset not found: {asset_path}",
        ) from exc
