"""Helpers for consistent assistant proposal records."""

from __future__ import annotations

from typing import Any


def build_proposal_record(
    *,
    action_id: str,
    action_type: str,
    action_inputs: dict[str, Any],
    preview_type: str | None = None,
    proposal_group: str | None = None,
    **fields: Any,
) -> dict[str, Any]:
    """Return a normalized proposal record payload."""
    record: dict[str, Any] = {
        "action_id": action_id,
        "action_type": action_type,
        "action_inputs": action_inputs,
        "status": "pending",
    }
    if preview_type:
        record["preview_type"] = preview_type
    if proposal_group:
        record["proposal_group"] = proposal_group
    record.update(fields)
    return record
