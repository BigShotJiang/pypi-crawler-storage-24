"""Tool schema helpers for assistant guided tool-use prompts."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.gateway.assistant.action_registry import V1_ACTIONS


@dataclass(frozen=True)
class ToolDefinition:
    """User-facing tool definition exposed to the LLM."""

    name: str
    description: str
    parameters: dict[str, Any]


TOOL_NAME_TO_ACTION_ID: dict[str, str] = {
    "build_workflow_scaffold": "execute_draft_workflow_from_thread",
    "add_stage": "propose_stage_insert",
    "remove_stage": "propose_stage_remove",
    "update_stage": "propose_stage_update",
    "reorder_stages": "propose_stage_reorder",
    "connect_stages": "propose_connection_add",
    "disconnect_stages": "propose_connection_remove",
    "update_workflow_metadata": "propose_workflow_metadata_update",
    "set_quality_gate": "propose_quality_gate_set",
    "batch_mutation": "propose_batch_mutation",
    "edit_template": "propose_template_edit",
    "generate_documentation": "generate_documentation",
    "launch_run": "execute_launch_run",
    "approve_operator_review": "execute_approve_operator_review",
    "resolve_escalation": "execute_resolve_escalation",
    "add_quality_gate": "__composite_quality_gate__",
    "review_output": "__composite_output_review__",
}


def _parameter_schema(parameter_type: str, *, required: bool = False, **fields: Any) -> dict[str, Any]:
    schema: dict[str, Any] = {
        "type": parameter_type,
        "required": required,
    }
    schema.update(fields)
    return schema


def _custom_parameters(tool_name: str) -> dict[str, Any] | None:
    if tool_name == "build_workflow_scaffold":
        return {
            "scaffold_definition": _parameter_schema(
                "object",
                required=True,
                properties={
                    "title": _parameter_schema("string", required=True),
                    "domain_id": _parameter_schema("string"),
                    "description": _parameter_schema("string"),
                    "stages": _parameter_schema(
                        "array",
                        required=True,
                        items={
                            "type": "object",
                            "properties": {
                                "id": _parameter_schema("string"),
                                "title": _parameter_schema("string", required=True),
                                "purpose": _parameter_schema("string"),
                                "depends_on": _parameter_schema("array", items={"type": "string"}),
                            },
                        },
                    ),
                    "quality_gates": _parameter_schema(
                        "array",
                        items={
                            "type": "object",
                            "properties": {
                                "after_stage_id": _parameter_schema("string", required=True),
                                "gate_type": _parameter_schema("string"),
                                "loop_back_to": _parameter_schema("string"),
                            },
                        },
                    ),
                },
            )
        }
    if tool_name == "add_stage":
        return {
            "title": _parameter_schema("string", required=True),
            "stage_id": _parameter_schema("string"),
            "purpose": _parameter_schema("string"),
            "after_stage_id": _parameter_schema("string"),
            "depends_on": _parameter_schema("array", items={"type": "string"}),
            "category": _parameter_schema("string"),
            "stage_type": _parameter_schema("string"),
            "lane_id": _parameter_schema("string"),
        }
    if tool_name == "remove_stage":
        return {"stage_id": _parameter_schema("string", required=True)}
    if tool_name == "update_stage":
        return {
            "stage_id": _parameter_schema("string", required=True),
            "updates": _parameter_schema(
                "object",
                required=True,
                properties={
                    "title": _parameter_schema("string"),
                    "purpose": _parameter_schema("string"),
                    "depends_on": _parameter_schema("array", items={"type": "string"}),
                    "category": _parameter_schema("string"),
                    "stage_type": _parameter_schema("string"),
                    "model_tier": _parameter_schema("string"),
                    "lane_id": _parameter_schema("string"),
                    "verification": _parameter_schema("array", items={"type": "string"}),
                },
            ),
        }
    if tool_name == "reorder_stages":
        return {"ordered_stage_ids": _parameter_schema("array", required=True, items={"type": "string"})}
    if tool_name in {"connect_stages", "disconnect_stages"}:
        return {
            "source_stage_id": _parameter_schema("string", required=True),
            "target_stage_id": _parameter_schema("string", required=True),
        }
    if tool_name == "update_workflow_metadata":
        return {
            "title": _parameter_schema("string"),
            "description": _parameter_schema("string"),
            "domain_id": _parameter_schema("string"),
            "summary": _parameter_schema("string"),
            "quality_dimensions": _parameter_schema("array", items={"type": "string"}),
            "lifecycle_capabilities": _parameter_schema("array", items={"type": "string"}),
        }
    if tool_name == "set_quality_gate":
        return {
            "stage_id": _parameter_schema("string", required=True),
            "loop_back_to": _parameter_schema("string"),
            "evaluators": _parameter_schema("array", items={"type": "object"}),
            "thresholds": _parameter_schema("object"),
        }
    if tool_name == "batch_mutation":
        return {
            "operations": _parameter_schema(
                "array",
                required=True,
                description=(
                    "Ordered batch of workflow mutations. Use `operation` on each item. "
                    "Supported values: insert_stage, remove_stage, connect, disconnect, "
                    "update_stage, update_workflow_metadata, set_quality_gate, edit_template."
                ),
                items={
                    "type": "object",
                    "properties": {
                        "operation": _parameter_schema(
                            "string",
                            required=True,
                            description=(
                                "One of: insert_stage, remove_stage, connect, disconnect, "
                                "update_stage, update_workflow_metadata, set_quality_gate, edit_template"
                            ),
                        ),
                        "after_stage_id": _parameter_schema("string"),
                        "stage_definition": _parameter_schema("object"),
                        "stage_id": _parameter_schema("string"),
                        "updates": _parameter_schema("object"),
                        "source_stage_id": _parameter_schema("string"),
                        "target_stage_id": _parameter_schema("string"),
                        "template_role": _parameter_schema("string"),
                        "proposed_content": _parameter_schema("string"),
                        "loop_back_to": _parameter_schema("string"),
                        "quality_loop": _parameter_schema("object"),
                        "evaluators": _parameter_schema("array", items={"type": "object"}),
                        "thresholds": _parameter_schema("object"),
                    },
                },
            )
        }
    if tool_name == "edit_template":
        return {
            "stage_id": _parameter_schema("string"),
            "template_role": _parameter_schema("string", required=True),
            "proposed_content": _parameter_schema(
                "string",
                required=True,
                description=(
                    "Stage template content — see Template Authoring Guidelines "
                    "in the system prompt for quality criteria and structural guidance"
                ),
            ),
        }
    if tool_name == "generate_documentation":
        return {}
    if tool_name == "launch_run":
        return {"objective": _parameter_schema("string")}
    if tool_name == "approve_operator_review":
        return {}
    if tool_name == "resolve_escalation":
        return {"choice": _parameter_schema("string", required=True)}
    return None


def _parameters_from_action(tool_name: str, action_id: str) -> dict[str, Any]:
    custom = _custom_parameters(tool_name)
    if custom is not None:
        return custom

    action = V1_ACTIONS[action_id]
    parameters: dict[str, Any] = {}
    for name, schema in action.input_schema.items():
        if not isinstance(schema, dict):
            continue
        parameters[name] = dict(schema)
    return parameters


def build_tool_catalog() -> list[ToolDefinition]:
    """Build the assistant tool catalog from the action registry."""
    catalog: list[ToolDefinition] = []
    reverse_map = {
        action_id: tool_name
        for tool_name, action_id in TOOL_NAME_TO_ACTION_ID.items()
        if action_id != "__composite_quality_gate__"
    }
    for action_id, tool_name in sorted(reverse_map.items(), key=lambda item: item[1]):
        action = V1_ACTIONS.get(action_id)
        if action is None:
            continue
        catalog.append(
            ToolDefinition(
                name=tool_name,
                description=str(action.label or tool_name).strip(),
                parameters=_parameters_from_action(tool_name, action_id),
            )
        )
    return catalog


def build_quality_gate_tool() -> ToolDefinition:
    """Return the synthetic quality-gate helper tool."""
    return ToolDefinition(
        name="add_quality_gate",
        description="Add a review or quality gate after a stage and optionally loop back.",
        parameters={
            "after_stage_id": _parameter_schema("string", required=True),
            "gate_type": _parameter_schema("string", default="review"),
            "loop_back_to": _parameter_schema("string"),
        },
    )


def build_output_review_tool() -> ToolDefinition:
    """Return the synthetic output-review helper tool."""
    return ToolDefinition(
        name="review_output",
        description=(
            "Review the currently selected run or artifact output and prepare findings plus "
            "concrete workflow fix proposals."
        ),
        parameters={},
    )


def _schema_type_label(schema: dict[str, Any]) -> str:
    parameter_type = str(schema.get("type") or "any").strip() or "any"
    if parameter_type == "array":
        item_type = "any"
        items = schema.get("items")
        if isinstance(items, dict):
            item_type = str(items.get("type") or "any").strip() or "any"
        return f"array[{item_type}]"
    return parameter_type


def _flatten_parameter_rows(
    parameters: dict[str, Any],
    *,
    prefix: str = "",
) -> list[tuple[str, str, bool, str]]:
    rows: list[tuple[str, str, bool, str]] = []
    for name, raw_schema in parameters.items():
        if not isinstance(raw_schema, dict):
            continue
        label = f"{prefix}{name}"
        description = str(raw_schema.get("description") or "").strip()
        rows.append((label, _schema_type_label(raw_schema), bool(raw_schema.get("required")), description))
        properties = raw_schema.get("properties")
        if isinstance(properties, dict):
            rows.extend(_flatten_parameter_rows(properties, prefix=f"{label}."))
        items = raw_schema.get("items")
        if isinstance(items, dict):
            item_properties = items.get("properties")
            if isinstance(item_properties, dict):
                rows.extend(_flatten_parameter_rows(item_properties, prefix=f"{label}[]."))
    return rows


def format_tool_catalog_markdown(tools: list[ToolDefinition] | None = None) -> str:
    """Render the current tool catalog as markdown."""
    rendered_tools = tools or [
        *build_tool_catalog(),
        build_quality_gate_tool(),
        build_output_review_tool(),
    ]
    lines = [
        "You have the following tools available. Call them by including a `tool_calls` array in your JSON response.",
    ]
    for tool in rendered_tools:
        lines.append(f"\n### `{tool.name}`")
        lines.append(tool.description)
        rows = _flatten_parameter_rows(tool.parameters)
        if not rows:
            lines.append("No arguments required when the relevant workflow or run is already selected in context.")
            continue
        lines.append("| Parameter | Type | Required | Description |")
        lines.append("| --- | --- | --- | --- |")
        for name, parameter_type, required, description in rows:
            lines.append(
                f"| `{name}` | `{parameter_type}` | `{'yes' if required else 'no'}` | {description or '-'} |"
            )
    return "\n".join(lines).strip()


def generate_tool_catalog_context() -> str:
    """Generate the full markdown context section used in guided prompts."""
    lines = [
        "## Available Tools",
        format_tool_catalog_markdown(
            [*build_tool_catalog(), build_quality_gate_tool(), build_output_review_tool()]
        ),
        "",
        "## Response Format",
        'Respond with a JSON object: {"message": "your explanation", "tool_calls": [{"tool": "tool_name", "args": {...}}]}.',
        "For advice-only responses, omit `tool_calls`.",
        "Use one tool call when a single proposal is enough. Use multiple tool calls only when the user explicitly asked for a bundle of coordinated changes.",
        "Prefer `batch_mutation` when the user asked for one coordinated approval covering multiple workflow changes.",
    ]
    return "\n".join(lines).strip()


def write_tool_catalog_context(output_path: Path) -> None:
    """Write the generated tool catalog context to *output_path*."""
    output_path.write_text(generate_tool_catalog_context(), encoding="utf-8")
