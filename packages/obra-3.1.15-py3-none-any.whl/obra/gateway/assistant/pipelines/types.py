"""Domain types for assistant action pipelines."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal

PipelineTriggerMode = Literal["auto", "semi_auto", "manual"]
PipelineTriggerSource = Literal["system_auto", "llm_proposed", "user_explicit"]
PipelineStepType = Literal["generate", "review", "diagnose", "audit"]
PipelineStepStatus = Literal[
    "pending",
    "running",
    "reviewing",
    "completed",
    "failed",
    "skipped",
]
PipelineStatus = Literal["completed", "cancelled", "failed", "partial"]

StepsFactory = Callable[[dict[str, Any]], list["StepDefinition"]]
StepExecutor = Callable[
    ["StepDefinition", dict[str, Any], list[dict[str, Any]], str | None],
    dict[str, Any],
]
PipelineRunner = Callable[[Any], Any]


@dataclass(frozen=True)
class StepDefinition:
    """One executable unit inside a pipeline."""

    step_id: str
    description: str
    step_type: PipelineStepType
    depends_on: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class StepResult:
    """Execution result for one pipeline step."""

    step_id: str
    status: PipelineStepStatus
    output: dict[str, Any] | None
    duration_ms: int
    review_feedback: str | None = None


@dataclass(frozen=True)
class PipelineResult:
    """Final outcome for a pipeline run."""

    pipeline_id: str
    status: PipelineStatus
    step_results: list[StepResult]
    proposals: list[dict[str, Any]] = field(default_factory=list)
    summary_message: str | None = None


@dataclass(frozen=True)
class QualityVerdict:
    """Advisory review verdict used by review-oriented pipelines."""

    verdict: Literal["pass", "revise"]
    affected_step_ids: list[str]
    issues: list[str]
    suggestions: list[str]


@dataclass(frozen=True)
class PipelineDefinition:
    """Registered assistant pipeline definition."""

    pipeline_id: str
    display_name: str
    trigger_mode: PipelineTriggerMode
    timeout_s: int = 300
    steps_factory: StepsFactory | None = None
    step_executor: StepExecutor | None = None
    runner: PipelineRunner | None = None
