"""Built-in assistant action pipelines."""

from __future__ import annotations

from obra.gateway.assistant.pipelines.builtin import bulk_template_gen, compliance_audit, diagnostic, self_review
from obra.gateway.assistant.pipelines.registry import get_pipeline, register_pipeline


def register_builtin_pipelines() -> None:
    """Register all gateway-owned built-in pipelines."""
    for factory in (
        bulk_template_gen.create_definition,
        self_review.create_definition,
        diagnostic.create_definition,
        compliance_audit.create_definition,
    ):
        definition = factory()
        if get_pipeline(definition.pipeline_id) is None:
            register_pipeline(definition)
