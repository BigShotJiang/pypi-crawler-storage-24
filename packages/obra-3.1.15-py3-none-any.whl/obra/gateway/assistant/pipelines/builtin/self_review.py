"""Background self-review pipeline for scaffold drafts."""

from __future__ import annotations

import json
from typing import Any

from obra.config.loaders import get_gateway_assistant_config
from obra.gateway.assistant.pipelines.engine import PipelineEngine
from obra.gateway.assistant.pipelines.llm import run_structured_json
from obra.gateway.assistant.pipelines.types import PipelineDefinition, PipelineResult, StepDefinition, StepResult

PIPELINE_ID = "pipeline_self_review"


def _workflow_stages(workflow_context: dict[str, Any]) -> list[dict[str, Any]]:
    stages = workflow_context.get("stages")
    if isinstance(stages, list):
        return [stage for stage in stages if isinstance(stage, dict)]
    definition = workflow_context.get("workflow_definition")
    if isinstance(definition, dict) and isinstance(definition.get("stages"), list):
        return [stage for stage in definition["stages"] if isinstance(stage, dict)]
    return []


def build_review_steps(workflow_context: dict[str, Any]) -> list[StepDefinition]:
    """Return the four fixed self-review steps."""
    _ = workflow_context
    return [
        StepDefinition(
            step_id="review_purpose_coherence",
            description="Check stage purpose overlap and missing ownership boundaries.",
            step_type="review",
        ),
        StepDefinition(
            step_id="review_dependency_chain",
            description="Check dependency reachability and circular edges.",
            step_type="review",
        ),
        StepDefinition(
            step_id="review_gate_placement",
            description="Check high-risk stages for missing quality gates.",
            step_type="review",
        ),
        StepDefinition(
            step_id="review_naming_consistency",
            description="Check naming and terminology consistency across the workflow.",
            step_type="review",
        ),
    ]


def execute_review_step(
    engine: PipelineEngine,
    step: StepDefinition,
    workflow_context: dict[str, Any],
) -> dict[str, Any]:
    """Run one structured scaffold review check."""
    prompt = (
        f"Review step: {step.step_id}\n"
        f"Workflow stages: {json.dumps(_workflow_stages(workflow_context), sort_keys=True)}\n"
        "Return JSON with issues_found, issues, affected_stages, suggestions."
    )
    template = {
        "issues_found": False,
        "issues": [],
        "affected_stages": [],
        "suggestions": [],
        "_instructions": "Return targeted workflow review findings for this one review step.",
    }

    def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
        if not isinstance(data.get("issues_found"), bool):
            return (False, "issues_found must be a boolean")
        return (True, None)

    return run_structured_json(
        working_dir=engine.working_dir,
        action_name=f"{PIPELINE_ID}_{step.step_id}",
        prompt=prompt,
        template_content=template,
        validator=validator,
        llm_config=engine.llm_config,
        timeout_s=engine.timeout_s,
        fallback_fn=lambda: {
            "issues_found": False,
            "issues": [],
            "affected_stages": [],
            "suggestions": [],
        },
    )


def build_amendment_events(step_results: list[StepResult]) -> list[dict[str, Any]]:
    """Translate step results into review amendment events."""
    events: list[dict[str, Any]] = []
    for result in step_results:
        output = result.output or {}
        if not output.get("issues_found"):
            continue
        events.append(
            {
                "event": "review_amendment_available",
                "step_id": result.step_id,
                "affected_stages": [str(item) for item in output.get("affected_stages", []) if str(item).strip()],
                "issues": [str(item) for item in output.get("issues", []) if str(item).strip()],
                "suggestions": [str(item) for item in output.get("suggestions", []) if str(item).strip()],
            }
        )
    return events


async def run_self_review_pipeline(engine: PipelineEngine) -> Any:
    """Run the four fixed review checks and emit amendment events."""
    engine.set_step_handler(
        lambda step, workflow_context, _predecessors, _review_feedback=None: execute_review_step(
            engine,
            step,
            workflow_context,
        )
    )
    steps = build_review_steps(engine.workflow_context)
    for step in steps:
        for event in await engine.execute_step_with_events(step):
            yield event
        if engine.cancelled:
            remaining = steps[steps.index(step) + 1 :]
            engine.mark_pending_steps_skipped(remaining)
            engine.set_result(
                PipelineResult(
                    pipeline_id=PIPELINE_ID,
                    status="cancelled",
                    step_results=engine.step_results,
                    proposals=[],
                    summary_message="Background scaffold review was cancelled.",
                )
            )
            return

    amendment_events = build_amendment_events(engine.step_results)
    if amendment_events:
        for event in amendment_events:
            yield event
        engine.set_result(
            PipelineResult(
                pipeline_id=PIPELINE_ID,
                status="completed",
                step_results=engine.step_results,
                proposals=[],
                summary_message=f"Found {len(amendment_events)} scaffold improvements.",
            )
        )
        return

    yield {
        "event": "review_complete",
        "status": "passed",
        "message": "Review passed, no changes needed",
    }
    engine.set_result(
        PipelineResult(
            pipeline_id=PIPELINE_ID,
            status="completed",
            step_results=engine.step_results,
            proposals=[],
            summary_message="Background scaffold review passed with no changes needed.",
        )
    )


def create_definition() -> PipelineDefinition:
    """Create the registered self-review pipeline definition."""
    assistant_config = get_gateway_assistant_config()
    pipeline_config = assistant_config.get("pipelines", {})
    return PipelineDefinition(
        pipeline_id=PIPELINE_ID,
        display_name="Workflow Self Review",
        trigger_mode="auto",
        timeout_s=int(pipeline_config.get("self_review_timeout_s", 120)),
        steps_factory=build_review_steps,
        runner=run_self_review_pipeline,
    )
