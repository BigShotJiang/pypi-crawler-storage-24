"""Bulk template generation pipeline."""

from __future__ import annotations

import json
from typing import Any
from uuid import uuid4

from obra.config.loaders import get_gateway_assistant_config
from obra.gateway.assistant.handlers.structural import _find_stage, _get_stages
from obra.gateway.assistant.handlers.template_edit import build_template_edit_proposal
from obra.gateway.assistant.pipelines.engine import PipelineEngine
from obra.gateway.assistant.pipelines.llm import run_structured_json
from obra.gateway.assistant.pipelines.types import (
    PipelineDefinition,
    PipelineResult,
    QualityVerdict,
    StepDefinition,
    StepResult,
)

PIPELINE_ID = "pipeline_generate_templates"


def _workflow_stages(workflow_context: dict[str, Any]) -> list[dict[str, Any]]:
    stages = workflow_context.get("stages")
    if isinstance(stages, list):
        return [stage for stage in stages if isinstance(stage, dict)]
    return _get_stages(workflow_context)


def build_steps(workflow_context: dict[str, Any]) -> list[StepDefinition]:
    """Create one template-generation step per workflow stage."""
    steps: list[StepDefinition] = []
    for stage in _workflow_stages(workflow_context):
        stage_id = str(stage.get("stage_id") or stage.get("id") or "").strip()
        if not stage_id:
            continue
        label = str(stage.get("title") or stage.get("name") or stage_id)
        steps.append(
            StepDefinition(
                step_id=f"gen_template_{stage_id}",
                description=f"Generate template for stage: {label}",
                step_type="generate",
            )
        )
    return steps


def execute_template_step(
    engine: PipelineEngine,
    step: StepDefinition,
    workflow_context: dict[str, Any],
    predecessors: list[dict[str, Any]],
    review_feedback: str | None = None,
) -> dict[str, Any]:
    """Generate one purpose template with neighboring stage context."""
    stage_id = step.step_id.removeprefix("gen_template_")
    stages = _workflow_stages(workflow_context)
    stage = _find_stage(stages, stage_id)
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")

    index = next((idx for idx, item in enumerate(stages) if _find_stage([item], stage_id)), 0)
    previous_stage = stages[index - 1] if index > 0 else None
    next_stage = stages[index + 1] if index + 1 < len(stages) else None
    prompt = (
        f"Target stage id: {stage_id}\n"
        f"Target stage title: {stage.get('title') or stage_id}\n"
        f"Target stage purpose: {stage.get('purpose') or stage.get('description') or ''}\n"
        f"Previous stage: {json.dumps(previous_stage or {}, sort_keys=True)}\n"
        f"Next stage: {json.dumps(next_stage or {}, sort_keys=True)}\n"
        f"Predecessor summaries: {json.dumps(predecessors, sort_keys=True)}\n"
        f"Review feedback: {review_feedback or 'none'}\n"
        "Return JSON with keys stage_id, template_role, proposed_content."
    )
    template = {
        "stage_id": stage_id,
        "template_role": "purpose",
        "proposed_content": "",
        "_instructions": "Return a concise but specific purpose template for this stage.",
    }

    def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
        if not str(data.get("stage_id") or "").strip():
            return (False, "stage_id is required")
        if not str(data.get("proposed_content") or "").strip():
            return (False, "proposed_content is required")
        return (True, None)

    return run_structured_json(
        working_dir=engine.working_dir,
        action_name=f"{PIPELINE_ID}_{stage_id}",
        prompt=prompt,
        template_content=template,
        validator=validator,
        llm_config=engine.llm_config,
        timeout_s=engine.timeout_s,
        log_event=engine.log_event,
        production_logger=engine.production_logger,
        fallback_fn=lambda: {
            "stage_id": stage_id,
            "template_role": "purpose",
            "proposed_content": str(stage.get("purpose") or stage.get("description") or "").strip(),
        },
    )


def review_templates(
    engine: PipelineEngine,
    step_results: list[StepResult],
    workflow_context: dict[str, Any],
) -> QualityVerdict:
    """Review generated templates for cross-stage consistency."""
    summaries = [
        {
            "stage_id": str((result.output or {}).get("stage_id") or ""),
            "preview": str((result.output or {}).get("proposed_content") or "")[:150],
        }
        for result in step_results
        if result.output
    ]
    prompt = (
        f"Workflow stages: {json.dumps(_workflow_stages(workflow_context), sort_keys=True)}\n"
        f"Generated templates: {json.dumps(summaries, sort_keys=True)}\n"
        "Review terminology consistency, handoff clarity, and scope overlap.\n"
        "Return JSON with verdict, issues, affected_stages, suggestions."
    )
    template = {
        "verdict": "pass",
        "issues": [],
        "affected_stages": [],
        "suggestions": [],
        "_instructions": "Return advisory review feedback for the generated stage templates.",
    }

    def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
        verdict = str(data.get("verdict") or "").strip()
        if verdict not in {"pass", "revise"}:
            return (False, "verdict must be pass or revise")
        return (True, None)

    data = run_structured_json(
        working_dir=engine.working_dir,
        action_name=f"{PIPELINE_ID}_review",
        prompt=prompt,
        template_content=template,
        validator=validator,
        llm_config=engine.llm_config,
        timeout_s=engine.timeout_s,
        log_event=engine.log_event,
        production_logger=engine.production_logger,
        fallback_fn=lambda: {
            "verdict": "pass",
            "issues": [],
            "affected_stages": [],
            "suggestions": [],
        },
    )
    affected_stages = [str(item) for item in data.get("affected_stages", []) if str(item).strip()]
    return QualityVerdict(
        verdict="revise" if data.get("verdict") == "revise" else "pass",
        affected_step_ids=[f"gen_template_{stage_id}" for stage_id in affected_stages],
        issues=[str(item) for item in data.get("issues", []) if str(item).strip()],
        suggestions=[str(item) for item in data.get("suggestions", []) if str(item).strip()],
    )


def build_template_proposals(
    pipeline_result: PipelineResult,
    workflow_context: dict[str, Any],
) -> list[dict[str, Any]]:
    """Build assistant proposal records from generated templates."""
    workflow_id = str(workflow_context.get("workflow_id") or "")
    proposal_group = str(uuid4())
    proposals: list[dict[str, Any]] = []
    workflow_like = workflow_context if isinstance(workflow_context.get("workflow_definition"), dict) else {
        "workflow_definition": {
            **workflow_context,
            "stages": _workflow_stages(workflow_context),
        }
    }
    for result in pipeline_result.step_results:
        if result.status != "completed" or not result.output:
            continue
        stage_id = str(result.output.get("stage_id") or "").strip()
        proposed_content = str(result.output.get("proposed_content") or "").strip()
        template_role = str(result.output.get("template_role") or "purpose").strip() or "purpose"
        if not stage_id or not proposed_content:
            continue
        proposals.append(
            build_template_edit_proposal(
                workflow=workflow_like,
                workflow_id=workflow_id,
                stage_id=stage_id,
                template_role=template_role,
                proposed_content=proposed_content,
                proposal_group=proposal_group,
            )
        )
    return proposals


async def run_bulk_template_pipeline(engine: PipelineEngine) -> Any:
    """Execute the full generate -> review -> revise -> present flow."""
    engine.set_step_handler(
        lambda step, workflow_context, predecessors, review_feedback=None: execute_template_step(
            engine,
            step,
            workflow_context,
            predecessors,
            review_feedback,
        )
    )
    steps = build_steps(engine.workflow_context)
    results: list[StepResult] = []
    for step in steps:
        for event in await engine.execute_step_with_events(step):
            yield event
        result = engine.get_step_result(step.step_id)
        if result is not None:
            results.append(result)
        if engine.cancelled:
            remaining = steps[steps.index(step) + 1 :]
            engine.mark_pending_steps_skipped(remaining)
            engine.set_result(
                PipelineResult(
                    pipeline_id=PIPELINE_ID,
                    status="cancelled",
                    step_results=engine.step_results,
                    proposals=[],
                    summary_message="Bulk template generation was cancelled.",
                )
            )
            return

    verdict = review_templates(engine, results, engine.workflow_context)
    if verdict.verdict == "revise":
        feedback = "\n".join(verdict.issues + verdict.suggestions)
        for step_id in verdict.affected_step_ids:
            step = next((item for item in steps if item.step_id == step_id), None)
            if step is None:
                continue
            yield {
                "event": "step_review",
                "step_id": step.step_id,
                "issues": verdict.issues,
                "suggestions": verdict.suggestions,
            }
            for event in await engine.execute_step_with_events(step, review_feedback=feedback):
                yield event

    pipeline_result = PipelineResult(
        pipeline_id=PIPELINE_ID,
        status="completed",
        step_results=engine.step_results,
        proposals=[],
        summary_message=f"Prepared {len(steps)} template updates across the workflow.",
    )
    proposals = build_template_proposals(pipeline_result, engine.workflow_context)
    engine.set_result(
        PipelineResult(
            pipeline_id=PIPELINE_ID,
            status="completed",
            step_results=engine.step_results,
            proposals=proposals,
            summary_message=f"Prepared {len(proposals)} template proposals.",
        )
    )


def create_definition() -> PipelineDefinition:
    """Create the registered bulk-template pipeline definition."""
    assistant_config = get_gateway_assistant_config()
    pipeline_config = assistant_config.get("pipelines", {})
    return PipelineDefinition(
        pipeline_id=PIPELINE_ID,
        display_name="Bulk Template Generation",
        trigger_mode="semi_auto",
        timeout_s=int(pipeline_config.get("bulk_template_timeout_s", pipeline_config.get("default_timeout_s", 300))),
        steps_factory=build_steps,
        runner=run_bulk_template_pipeline,
    )
