"""Quality-gate mutation handlers for the studio assistant."""

from __future__ import annotations

import copy
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.assistant.handlers.structural import _find_stage, _get_stages
from obra.gateway.workflow_studio.assistant_response_planner import _quality_loop
from obra.workflow.quality_loop import collect_stage_quality_loop_issues


def build_quality_loop_payload(
    workflow: dict[str, Any],
    *,
    stage_id: str,
    loop_back_to: str | None = None,
    evaluators: list[dict[str, Any]] | None = None,
    thresholds: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a canonical quality_loop payload for one stage."""
    stages = _get_stages(workflow)
    if _find_stage(stages, stage_id) is None:
        raise ValueError(f"Stage not found: {stage_id}")
    if loop_back_to and _find_stage(stages, loop_back_to) is None:
        raise ValueError(f"Loop-back stage not found: {loop_back_to}")

    quality_loop = _quality_loop(f"{stage_id}-loop")
    routing = dict(quality_loop.get("routing") or {})
    if loop_back_to:
        routing["on_revise_required"] = "revise_to_stage"
        quality_loop["routing_targets"] = {
            "on_revise_required": {"target_stage_id": loop_back_to}
        }
    else:
        routing["on_revise_required"] = "revise_same_stage"
        quality_loop.pop("routing_targets", None)
    quality_loop["routing"] = routing

    if evaluators is not None:
        if not isinstance(evaluators, list) or not evaluators:
            raise ValueError("Quality gate evaluators must be a non-empty list when provided.")
        quality_loop["evaluators"] = [dict(item) for item in evaluators if isinstance(item, dict)]
        if not quality_loop["evaluators"]:
            raise ValueError("Quality gate evaluators must contain objects.")
    if thresholds is not None:
        if not isinstance(thresholds, dict):
            raise ValueError("Quality gate thresholds must be an object when provided.")
        quality_loop["thresholds"] = dict(thresholds)

    issues = collect_stage_quality_loop_issues({"id": stage_id, "quality_loop": quality_loop})
    if issues:
        raise ValueError(issues[0]["message"])
    return quality_loop


def apply_quality_gate_to_candidate(candidate: dict[str, Any], stage_id: str, quality_loop: dict[str, Any]) -> None:
    """Apply a canonical quality_loop to one stage in *candidate*."""
    stage = _find_stage(_get_stages(candidate), stage_id)
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")
    stage["quality_loop"] = copy.deepcopy(quality_loop)


def build_quality_gate_proposal(
    *,
    workflow: dict[str, Any],
    workflow_id: str,
    stage_id: str,
    quality_loop: dict[str, Any],
    expected_revision_id: str = "",
    proposal_group: str | None = None,
) -> dict[str, Any]:
    """Build the canonical quality-gate proposal payload."""
    stage = _find_stage(_get_stages(workflow), stage_id)
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")

    before_quality_loop = (
        dict(stage.get("quality_loop"))
        if isinstance(stage.get("quality_loop"), dict)
        else {}
    )
    return build_proposal_record(
        action_id="execute_quality_gate_set",
        action_type="propose_quality_gate_set",
        action_inputs={
            "workflow_id": workflow_id,
            "stage_id": stage_id,
            "quality_loop": quality_loop,
            "expected_revision_id": expected_revision_id,
        },
        preview_type="diff",
        proposal_group=proposal_group,
        outcome="proposal",
        workflow_id=workflow_id,
        stage_id=stage_id,
        before_quality_loop=before_quality_loop,
        after_quality_loop=quality_loop,
    )


def propose_set(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose setting a canonical quality gate on a stage."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id = str(inputs.get("stage_id") or "").strip()
    quality_loop = inputs.get("quality_loop")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not stage_id:
        return {"outcome": "invalid", "detail": "Stage id is required."}
    if not isinstance(quality_loop, dict) or not quality_loop:
        return {"outcome": "invalid", "detail": "Quality gate payload is required."}

    stage = _find_stage(_get_stages(workflow), stage_id)
    if stage is None:
        return {"outcome": "invalid", "detail": f"Stage not found: {stage_id}"}
    return build_quality_gate_proposal(
        workflow=workflow,
        workflow_id=wf_id,
        stage_id=stage_id,
        quality_loop=quality_loop,
        expected_revision_id=str(inputs.get("expected_revision_id") or ""),
    )


def execute_set(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a canonical quality gate update."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id = str(inputs.get("stage_id") or "").strip()
    quality_loop = inputs.get("quality_loop")
    expected_revision_id = str(inputs.get("expected_revision_id") or "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not stage_id:
        return {"outcome": "invalid", "detail": "Stage id is required."}
    if not isinstance(quality_loop, dict) or not quality_loop:
        return {"outcome": "invalid", "detail": "Quality gate payload is required."}

    candidate = copy.deepcopy(workflow)
    try:
        apply_quality_gate_to_candidate(candidate, stage_id, quality_loop)
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = ctx.action_service.apply_workflow(
        wf_id,
        candidate,
        expected_revision_id=expected_revision_id,
    )
    outcome = result.get("outcome", "")
    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
        }
    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
        }
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
        "stage_id": stage_id,
    }
