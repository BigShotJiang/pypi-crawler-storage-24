"""Structural workflow change handlers — propose and execute stage/connection mutations."""

from __future__ import annotations

import copy
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.proposal_records import build_proposal_record


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_stages(workflow: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the stages list from a workflow dict."""
    return workflow.get("workflow_definition", {}).get("stages", [])


def _stage_id(stage: dict[str, Any]) -> str:
    """Return the normalized stage identifier."""
    return str(stage.get("id") or stage.get("stage_id") or "").strip()


def _find_stage(stages: list[dict[str, Any]], stage_id: str) -> dict[str, Any] | None:
    """Find a stage by its normalized identifier."""
    return next((stage for stage in stages if _stage_id(stage) == stage_id), None)


def _stage_title(stage: dict[str, Any]) -> str:
    return str(stage.get("title") or _stage_id(stage)).strip()


def _find_stage_index(stages: list[dict[str, Any]], stage_id: str) -> int | None:
    """Return the index for a normalized stage identifier."""
    for index, stage in enumerate(stages):
        if _stage_id(stage) == stage_id:
            return index
    return None


def _stage_update_fields(updates: dict[str, Any]) -> dict[str, Any]:
    """Return only the explicit stage fields supplied by the caller."""
    return {
        str(key): value
        for key, value in updates.items()
        if str(key).strip() and key not in {"id", "stage_id"}
    }


def apply_stage_update_to_candidate(
    candidate: dict[str, Any],
    stage_id: str,
    updates: dict[str, Any],
) -> dict[str, Any]:
    """Apply a partial stage update to *candidate* in place."""
    stages = _get_stages(candidate)
    stage = _find_stage(stages, stage_id)
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")
    stage.update(_stage_update_fields(updates))
    return stage


def insert_stage_into_candidate(
    candidate: dict[str, Any],
    *,
    after_stage_id: str | None,
    stage_definition: dict[str, Any],
) -> int:
    """Insert a stage into *candidate* and return the insertion index."""
    stages = _get_stages(candidate)
    if after_stage_id is None:
        insertion_index = 0
    else:
        idx = _find_stage_index(stages, after_stage_id)
        if idx is None:
            raise ValueError(f"Stage not found: {after_stage_id}")
        insertion_index = idx + 1
    stages.insert(insertion_index, stage_definition)
    return insertion_index


def remove_stage_from_candidate(candidate: dict[str, Any], stage_id: str) -> None:
    """Remove one stage and clean dependent references in *candidate*."""
    stages = _get_stages(candidate)
    if _find_stage(stages, stage_id) is None:
        raise ValueError(f"Stage not found: {stage_id}")
    candidate["workflow_definition"]["stages"] = [
        stage for stage in stages if _stage_id(stage) != stage_id
    ]
    for stage in candidate["workflow_definition"]["stages"]:
        deps = stage.get("depends_on", [])
        if stage_id in deps:
            stage["depends_on"] = [dependency for dependency in deps if dependency != stage_id]


def reorder_stages_in_candidate(candidate: dict[str, Any], ordered_stage_ids: list[str]) -> None:
    """Reorder stages in *candidate* using normalized identifiers."""
    stages = _get_stages(candidate)
    stage_map = {_stage_id(stage): stage for stage in stages}
    candidate["workflow_definition"]["stages"] = [
        stage_map[stage_id] for stage_id in ordered_stage_ids if stage_id in stage_map
    ]


def connect_stages_in_candidate(
    candidate: dict[str, Any],
    source_stage_id: str,
    target_stage_id: str,
) -> None:
    """Add a dependency edge to *candidate*."""
    stages = _get_stages(candidate)
    if _find_stage(stages, source_stage_id) is None:
        raise ValueError(f"Source stage not found: {source_stage_id}")
    target = _find_stage(stages, target_stage_id)
    if target is None:
        raise ValueError(f"Target stage not found: {target_stage_id}")
    deps = target.setdefault("depends_on", [])
    if source_stage_id not in deps:
        deps.append(source_stage_id)


def disconnect_stages_in_candidate(
    candidate: dict[str, Any],
    source_stage_id: str,
    target_stage_id: str,
) -> None:
    """Remove a dependency edge from *candidate*."""
    stages = _get_stages(candidate)
    if _find_stage(stages, source_stage_id) is None:
        raise ValueError(f"Source stage not found: {source_stage_id}")
    target = _find_stage(stages, target_stage_id)
    if target is None:
        raise ValueError(f"Target stage not found: {target_stage_id}")
    deps = target.get("depends_on", [])
    target["depends_on"] = [dependency for dependency in deps if dependency != source_stage_id]


# ---------------------------------------------------------------------------
# Propose handlers
# ---------------------------------------------------------------------------


def propose_insert(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose inserting a new stage into the workflow."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    after_stage_id: str | None = inputs.get("after_stage_id")
    stage_definition: dict[str, Any] = inputs.get("stage_definition", {})

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)

    # Compute insertion position
    if after_stage_id is None:
        insertion_index = 0
    else:
        idx = _find_stage_index(stages, after_stage_id)
        if idx is None:
            return {"outcome": "invalid", "detail": f"Stage not found: {after_stage_id}"}
        insertion_index = idx + 1

    # Surrounding context
    prev_title = _stage_title(stages[insertion_index - 1]) if insertion_index > 0 else None
    next_title = _stage_title(stages[insertion_index]) if insertion_index < len(stages) else None

    return build_proposal_record(
        action_id="execute_stage_insert",
        action_type="propose_stage_insert",
        action_inputs={
            "workflow_id": wf_id,
            "after_stage_id": after_stage_id,
            "stage_definition": stage_definition,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="scaffold",
        outcome="proposal",
        proposed_stage=stage_definition,
        insertion_index=insertion_index,
        surrounding_stages={
            "previous": prev_title,
            "next": next_title,
        },
        workflow_id=wf_id,
    )


def execute_insert(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed stage insert."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    after_stage_id: str | None = inputs.get("after_stage_id")
    stage_definition: dict[str, Any] = inputs.get("stage_definition", {})
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    try:
        insert_stage_into_candidate(
            candidate,
            after_stage_id=after_stage_id,
            stage_definition=stage_definition,
        )
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


def propose_remove(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose removing a stage from the workflow."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str = inputs.get("stage_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)
    target = _find_stage(stages, stage_id)
    if target is None:
        return {"outcome": "invalid", "detail": f"Stage not found: {stage_id}"}

    # Affected connections: stages that depend on or are depended upon by this stage
    affected_connections: list[dict[str, str]] = []
    for s in stages:
        if stage_id in s.get("depends_on", []):
            affected_connections.append(
                {
                    "stage_id": _stage_id(s),
                    "title": _stage_title(s),
                    "relationship": "depends_on_removed",
                }
            )

    return build_proposal_record(
        action_id="execute_stage_remove",
        action_type="propose_stage_remove",
        action_inputs={
            "workflow_id": wf_id,
            "stage_id": stage_id,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="diff",
        outcome="proposal",
        removed_stage={
            "stage_id": stage_id,
            "title": _stage_title(target),
        },
        affected_connections=affected_connections,
        workflow_id=wf_id,
    )


def execute_remove(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed stage removal."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str = inputs.get("stage_id", "")
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    try:
        remove_stage_from_candidate(candidate, stage_id)
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


def propose_reorder(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose reordering stages in the workflow."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    ordered_stage_ids: list[str] = inputs.get("ordered_stage_ids", [])

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)
    stage_map = {_stage_id(stage): stage for stage in stages}

    before_order = [
        {"stage_id": _stage_id(stage), "title": _stage_title(stage)}
        for stage in stages
    ]

    after_order = []
    for sid in ordered_stage_ids:
        stage = stage_map.get(sid)
        if stage:
            after_order.append({"stage_id": sid, "title": _stage_title(stage)})

    return build_proposal_record(
        action_id="execute_stage_reorder",
        action_type="propose_stage_reorder",
        action_inputs={
            "workflow_id": wf_id,
            "ordered_stage_ids": ordered_stage_ids,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="diff",
        outcome="proposal",
        before_order=before_order,
        after_order=after_order,
        workflow_id=wf_id,
    )


def execute_reorder(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed stage reorder."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    ordered_stage_ids: list[str] = inputs.get("ordered_stage_ids", [])
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    reorder_stages_in_candidate(candidate, ordered_stage_ids)

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


def propose_connect(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose adding a connection (dependency edge) between two stages."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    source_stage_id: str = inputs.get("source_stage_id", "")
    target_stage_id: str = inputs.get("target_stage_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)
    source = _find_stage(stages, source_stage_id)
    target = _find_stage(stages, target_stage_id)

    if source is None:
        return {"outcome": "invalid", "detail": f"Source stage not found: {source_stage_id}"}
    if target is None:
        return {"outcome": "invalid", "detail": f"Target stage not found: {target_stage_id}"}

    return build_proposal_record(
        action_id="execute_connection_add",
        action_type="propose_connection_add",
        action_inputs={
            "workflow_id": wf_id,
            "source_stage_id": source_stage_id,
            "target_stage_id": target_stage_id,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="diff",
        outcome="proposal",
        edge_added={
            "source_stage_id": source_stage_id,
            "source_title": _stage_title(source),
            "target_stage_id": target_stage_id,
            "target_title": _stage_title(target),
        },
        workflow_id=wf_id,
    )


def execute_connect(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed connection add."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    source_stage_id: str = inputs.get("source_stage_id", "")
    target_stage_id: str = inputs.get("target_stage_id", "")
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    try:
        connect_stages_in_candidate(candidate, source_stage_id, target_stage_id)
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


def propose_disconnect(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose removing a connection (dependency edge) between two stages."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    source_stage_id: str = inputs.get("source_stage_id", "")
    target_stage_id: str = inputs.get("target_stage_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    stages = _get_stages(workflow)
    source = _find_stage(stages, source_stage_id)
    target = _find_stage(stages, target_stage_id)

    if source is None:
        return {"outcome": "invalid", "detail": f"Source stage not found: {source_stage_id}"}
    if target is None:
        return {"outcome": "invalid", "detail": f"Target stage not found: {target_stage_id}"}

    return build_proposal_record(
        action_id="execute_connection_remove",
        action_type="propose_connection_remove",
        action_inputs={
            "workflow_id": wf_id,
            "source_stage_id": source_stage_id,
            "target_stage_id": target_stage_id,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="diff",
        outcome="proposal",
        edge_removed={
            "source_stage_id": source_stage_id,
            "source_title": _stage_title(source),
            "target_stage_id": target_stage_id,
            "target_title": _stage_title(target),
        },
        workflow_id=wf_id,
    )


def execute_disconnect(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed connection removal."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    source_stage_id: str = inputs.get("source_stage_id", "")
    target_stage_id: str = inputs.get("target_stage_id", "")
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    try:
        disconnect_stages_in_candidate(candidate, source_stage_id, target_stage_id)
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = ctx.action_service.apply_workflow(
        wf_id, candidate, expected_revision_id=expected_revision_id
    )
    return _apply_result(result, wf_id)


# ---------------------------------------------------------------------------
# Shared apply result mapper
# ---------------------------------------------------------------------------


def _apply_result(result: dict[str, Any], wf_id: str) -> dict[str, Any]:
    """Map the action service result to a handler response."""
    outcome = result.get("outcome", "")

    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
        }

    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
        }

    # accepted
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
    }


def propose_update(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose updating explicit fields on an existing stage."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id = str(inputs.get("stage_id") or "").strip()
    updates = inputs.get("updates")
    normalized_updates = _stage_update_fields(updates) if isinstance(updates, dict) else {}

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not stage_id:
        return {"outcome": "invalid", "detail": "Stage id is required."}
    if not normalized_updates:
        return {"outcome": "invalid", "detail": "At least one stage update is required."}

    stages = _get_stages(workflow)
    target = _find_stage(stages, stage_id)
    if target is None:
        return {"outcome": "invalid", "detail": f"Stage not found: {stage_id}"}

    before_stage = copy.deepcopy(target)
    after_stage = copy.deepcopy(target)
    after_stage.update(normalized_updates)

    return build_proposal_record(
        action_id="execute_stage_update",
        action_type="propose_stage_update",
        action_inputs={
            "workflow_id": wf_id,
            "stage_id": stage_id,
            "updates": normalized_updates,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="diff",
        outcome="proposal",
        workflow_id=wf_id,
        stage_id=stage_id,
        changed_fields=sorted(normalized_updates),
        before_stage=before_stage,
        after_stage=after_stage,
    )


def execute_update(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed stage update."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id = str(inputs.get("stage_id") or "").strip()
    updates = inputs.get("updates")
    normalized_updates = _stage_update_fields(updates) if isinstance(updates, dict) else {}
    expected_revision_id = str(inputs.get("expected_revision_id") or "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not stage_id:
        return {"outcome": "invalid", "detail": "Stage id is required."}
    if not normalized_updates:
        return {"outcome": "invalid", "detail": "At least one stage update is required."}

    candidate = copy.deepcopy(workflow)
    try:
        apply_stage_update_to_candidate(candidate, stage_id, normalized_updates)
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = ctx.action_service.apply_workflow(
        wf_id,
        candidate,
        expected_revision_id=expected_revision_id,
    )
    return _apply_result(result, wf_id)
