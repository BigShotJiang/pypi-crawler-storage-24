"""Assistant LLM provider resolution helpers.

Routes assistant turns through the configured LLM provider. Guided mode sends
tool definitions and parses tool call responses.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

from obra.gateway.workflow_studio.tool_call_translator import (
    parse_tool_calls,
    translate_tool_calls,
)
from obra.gateway.workflow_studio.assistant_types import AssistantLlmResponse

logger = logging.getLogger(__name__)


def _strip_reasoning_and_json(text: str) -> str:
    """Clean LLM output that may contain chain-of-thought and/or JSON contracts.

    If the text contains an embedded JSON object with a ``message`` field,
    extract that message.  Otherwise strip common reasoning preambles
    (e.g. "The user is asking..." paragraphs before the real answer).
    """
    import re

    from obra.gateway.workflow_studio.assistant_response_planner import _extract_embedded_json

    stripped = text.strip()
    if not stripped:
        return stripped

    # If the text contains a JSON contract with a "message" key, extract it.
    data = _extract_embedded_json(stripped)
    if data is not None:
        return str(data["message"]).strip()

    # Strip chain-of-thought reasoning that precedes the actual answer.
    divider = re.split(r'\n---+\n', stripped, maxsplit=1)
    if len(divider) == 2 and len(divider[1].strip()) > 20:
        return divider[1].strip()

    return stripped


async def call_assistant_llm(
    system_prompt: str,
    user_message: str,
    *,
    app_state: Any | None = None,
    provider: Callable[..., Any] | None = None,
    resolved_context: dict[str, Any] | None = None,
    model_id: str | None = None,
    **kwargs: Any,
) -> AssistantLlmResponse:
    """Call the configured assistant LLM provider.

    Uses the CLI subprocess pipeline (claude/codex/gemini) by default.
    """
    safety_mode = str((resolved_context or {}).get("safety_mode") or "advisory")

    llm_provider = provider or (
        getattr(app_state, "assistant_llm_provider", None) if app_state is not None else None
    )

    if llm_provider is None:
        raise RuntimeError(
            "Assistant LLM provider is not available. "
            "Verify the provider CLI is installed and authenticated "
            "(e.g. 'claude login' for Anthropic, 'codex --login' for OpenAI)."
        )

    # --- Provider is available: invoke via CLI subprocess pipeline ---

    if safety_mode == "guided":
        guided_result = await asyncio.to_thread(
            _invoke_provider_guided,
            llm_provider,
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
        )
        if isinstance(guided_result, dict):
            guided_text = json.dumps(guided_result)
        else:
            guided_text = str(guided_result)
        message, tool_calls = parse_tool_calls(guided_text)
        return translate_tool_calls(
            message,
            tool_calls,
            resolved_context=resolved_context,
            construction_context=(resolved_context or {}).get("construction_context"),
        )

    # Advisory mode: plain text response.
    text_result = await asyncio.to_thread(
        _invoke_provider_text,
        llm_provider,
        system_prompt=system_prompt,
        user_message=user_message,
        model_id=model_id,
    )
    # Normalize result — may be str, InvocationResult, or dict.
    if isinstance(text_result, str):
        message = _strip_reasoning_and_json(text_result)
        return AssistantLlmResponse(message=message)
    if isinstance(text_result, dict):
        return AssistantLlmResponse(
            message=str(text_result.get("message") or text_result.get("content") or "").strip(),
            outcome=str(text_result.get("outcome") or "advice"),
            action_records=text_result.get("action_records"),
        )
    if hasattr(text_result, "content"):
        message = _strip_reasoning_and_json(str(getattr(text_result, "content", "")))
        return AssistantLlmResponse(message=message)
    return AssistantLlmResponse(message=str(text_result).strip())


def _resolve_provider_result(result: Any) -> Any:
    """Await coroutines and normalize provider results.

    Returns the result as-is if it's already a dict/str.
    """
    import asyncio as _aio

    if _aio.iscoroutine(result):
        result = _aio.run(result)
    # InvocationResult from LLMInvoker — check for failures.
    if hasattr(result, "success") and getattr(result, "success") is False:
        raise RuntimeError(str(getattr(result, "error_message", "") or "assistant LLM call failed"))
    return result


def _invoke_provider_text(
    llm_provider: Any,
    *,
    system_prompt: str,
    user_message: str,
    model_id: str | None,
) -> Any:
    """Synchronous helper — runs in a thread via asyncio.to_thread."""
    if hasattr(llm_provider, "generate_text"):
        result = llm_provider.generate_text(
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
        )
        return _resolve_provider_result(result)
    raise RuntimeError("LLM provider does not implement generate_text")


def _invoke_provider_guided(
    llm_provider: Any,
    *,
    system_prompt: str,
    user_message: str,
    model_id: str | None,
) -> Any:
    """Synchronous helper — runs in a thread via asyncio.to_thread."""
    if hasattr(llm_provider, "generate_guided_contract"):
        result = llm_provider.generate_guided_contract(
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
        )
        return _resolve_provider_result(result)
    raise RuntimeError("LLM provider does not implement generate_guided_contract")


def call_assistant_llm_sync(
    system_prompt: str,
    user_message: str,
    *,
    app_state: Any | None = None,
    provider: Callable[..., Any] | None = None,
    resolved_context: dict[str, Any] | None = None,
    **kwargs: Any,
) -> AssistantLlmResponse:
    """Synchronous bridge for broker handlers executed from a worker thread."""
    return asyncio.run(
        call_assistant_llm(
            system_prompt,
            user_message,
            app_state=app_state,
            provider=provider,
            resolved_context=resolved_context,
            **kwargs,
        )
    )
