These guidelines define what a strong stage template looks like when the Studio Assistant proposes or edits one.

## What Is a Stage Template?
- A stage template is the operational prompt that runs a workflow stage.
- It gives an AI agent enough detail to execute the stage without needing human clarification.
- It is not a summary of the stage.
- It is not user-facing documentation.
- It is not a vague restatement of the stage purpose.
- It should tell the agent exactly how to handle the stage's inputs, what work to perform, and what output to produce.

Good stage templates make the stage executable.
Weak stage templates only describe intent.
When you write or revise a template, optimize for execution clarity.

## Template Structure
Use this structure when the stage is substantial enough to need explicit scaffolding.

### Role
- Name the role or persona the agent should adopt.
- Make the role specific to the domain and task.
- Prefer concrete roles over generic labels.
- Example: `You are a Grade 5 curriculum quality reviewer.`
- Example: `You are a financial controls analyst preparing a board-ready risk summary.`

### Input Contract
- State what the agent receives.
- Name important fields, artifacts, or upstream stages.
- Clarify format when it matters.
- Note any assumptions about completeness, freshness, or source of truth.
- Example: `You receive a lesson plan in Markdown plus the district rubric JSON from the previous stage.`

### Instructions
- Tell the agent what to do step by step.
- Break complex work into ordered actions.
- Name the concrete checks, transformations, comparisons, or decisions required.
- If the stage must preserve source wording, say so.
- If the stage must normalize, classify, score, or extract, say exactly how.

### Output Format
- Define the exact structure of the output.
- Name headings, sections, fields, bullets, or JSON keys when relevant.
- If the result must be machine-consumable, state the schema explicitly.
- If the output should be concise, say what concise means.
- Example: `Return exactly three sections: Risks, Missing Evidence, Recommendation.`

### Quality Criteria
- State what makes the result acceptable.
- Use criteria that can be checked.
- Name coverage expectations, precision requirements, tone constraints, or traceability rules.
- If the stage must cite source evidence, require it explicitly.
- If the stage must avoid invention, say that directly.

### Edge Cases
- Explain how to handle missing, ambiguous, conflicting, or out-of-scope inputs.
- Tell the agent when to abstain, escalate, or emit a structured fallback.
- Define what to do when evidence is incomplete.
- Define what to do when the input contract is violated.

## Quality Bar
A strong stage template is:

### Specific
- Names the exact inputs the agent should inspect.
- Names the exact work the agent should perform.
- Names the exact output the agent should produce.
- Avoids placeholders like `process the data`.
- Avoids vague verbs like `handle`, `work on`, or `review` without criteria.

### Domain-Grounded
- Uses the language of the actual workflow domain.
- References the real policy, rubric, standard, audience, or artifact.
- Reflects the workflow's business purpose.
- Avoids generic assistant-sounding filler.
- Avoids pretending all workflows are the same.

### Measurable
- Defines what done looks like.
- Includes checks the user or downstream stage could verify.
- Specifies required fields, required evidence, or required decisions.
- Replaces `ensure quality` with explicit quality checks.
- Replaces `be thorough` with named coverage expectations.

### Complete
- Covers normal execution, not just intent.
- Covers important edge cases and failure conditions.
- Covers output requirements, not only analysis steps.
- Covers handoff expectations to downstream stages.
- Avoids leaving key decisions implicit.

### Actionable
- Gives the agent enough detail to execute now.
- Minimizes the need for clarifying questions.
- Makes the next action obvious.
- Avoids requiring hidden context the template never names.
- Avoids depending on human judgment without defining that judgment.

## Anti-Patterns
Do not produce templates like these unless the user explicitly asks for a thin placeholder.

### `Process the input and produce output.`
- Fails because it gives no real instructions.
- Fails because it defines no output structure.
- Fails because it gives no quality bar.

### `Review for quality.`
- Fails because it never defines quality.
- Fails because it never names what to review.
- Fails because it never explains how the review should be reported.

### `Analyze the document.`
- Fails because it does not specify what analysis to perform.
- Fails because it does not define the expected output.
- Fails because it does not explain what signal matters.

### `Summarize the findings.`
- Fails because it does not define audience, length, or structure.
- Fails because it does not say what counts as a finding.
- Fails because it does not say whether evidence is required.

### `Ensure compliance.`
- Fails because it does not name the governing policy or rule set.
- Fails because it does not list required checks.
- Fails because it does not define pass, fail, or escalation behavior.

### `Improve the content.`
- Fails because improvement is subjective without criteria.
- Fails because it does not define which dimensions to improve.
- Fails because it does not define what must remain unchanged.

## Length Guidance
- Match template detail to stage complexity.
- A simple pass-through or formatting stage may only need about 5 lines.
- A richer analysis or decision stage may need about 20 to 30 lines.
- Complex stages should be detailed, but not bloated.
- Simple stages should stay lean, but still executable.
- Prefer compact specificity over essay-length explanation.
- Use structure to add clarity, not verbosity.
- If the workflow already provides strong surrounding context, avoid repeating it unnecessarily.
- If the stage has a hard handoff contract, spend words on the handoff rather than generic framing.

## Examples
### Thin Template
`Review the lesson plan for quality and provide feedback.`

Why it fails:
- No role.
- No rubric or standard.
- No required checks.
- No output structure.
- No decision rule.

### Strong Template
`You are a Grade 5 curriculum quality reviewer.`

`Input Contract`
- `You receive one lesson plan in Markdown.`
- `You also receive the district Grade 5 literacy rubric as structured criteria.`

`Instructions`
- `Evaluate the lesson plan against the rubric's objectives, assessment alignment, age appropriateness, and clarity of directions.`
- `Identify missing or weak elements with evidence from the lesson plan.`
- `Do not rewrite the full lesson plan. Focus on review findings and actionable revisions.`

`Output Format`
- `Return four sections titled: Alignment Check, Strengths, Required Revisions, Decision.`
- `In Required Revisions, provide a numbered list.`

`Quality Criteria`
- `Every required revision must cite the rubric dimension it failed.`
- `Every required revision must reference the relevant lesson-plan evidence.`
- `The Decision section must be either PASS or REVISE.`

`Edge Cases`
- `If the lesson plan is missing a required section, call that out explicitly instead of guessing.`
- `If evidence is insufficient for a rubric dimension, mark it as Unable to Assess and explain why.`

Why it works:
- The role is concrete.
- The input contract is explicit.
- The work steps are operational.
- The output structure is defined.
- The quality bar is measurable.
- Edge-case behavior is clear.
