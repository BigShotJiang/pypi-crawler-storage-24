# Tool Use Contract

For guided turns, respond with a JSON object shaped like:

`{"message": "short explanation", "tool_calls": [{"tool": "tool_name", "args": {...}}]}`

Rules:

- Put user-facing explanation in `message`.
- Use `tool_calls` only when you are preparing a concrete proposal.
- Omit `tool_calls` for advice-only responses.
- Use one tool call for one coherent proposal unless the user explicitly asked for a coordinated bundle.
- Do not invent tools or arguments outside the documented catalog.
