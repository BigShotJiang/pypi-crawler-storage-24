"""Context assembler for assistant conversation turns."""

from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel

from obra.gateway.workflow_studio.output_review_context import build_output_review_context
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.starter_catalog import (
    normalize_starter_domain_id,
    resolve_domain_starters,
)

logger = logging.getLogger(__name__)


def _resolve_business_tier_defaults(
    *,
    domain_id: str | None,
    workflow: dict[str, Any] | None,
) -> dict[str, Any]:
    """Return configured business tier defaults for prompt guidance."""
    normalized_domain_id = normalize_starter_domain_id(domain_id)
    if not normalized_domain_id and isinstance(workflow, dict):
        normalized_domain_id = normalize_starter_domain_id(
            str(workflow.get("domain_id") or workflow.get("domain") or "")
        )
    if normalized_domain_id != "business":
        return {}

    try:
        from obra_business.config.loader import get_config_value, load_config

        config = load_config()
        return {
            "business_execution_tier": get_config_value(config, "business.llm.execution_tier"),
            "business_stage_type_tiers": dict(
                get_config_value(config, "business.llm.stage_type_tiers")
            ),
        }
    except Exception as exc:
        logger.warning("Failed to resolve business tier defaults for assistant context: %s", exc)
        return {}


class UIState(BaseModel):
    """Typed UI state fields matching client EditorContext interface."""

    editor_surface: str | None = None
    editor_mode: str | None = None
    dirty: bool = False
    stage_count: int = 0
    last_change_kind: str | None = None
    last_change_summary: str | None = None
    has_validation_errors: bool = False
    validation_error_count: int = 0
    validation_error_stages: list[str] = []
    validation_issues: list[dict[str, Any]] = []
    has_conflict: bool = False
    last_save_status: str | None = None
    save_readiness: str | None = None
    semantic_projection: dict[str, Any] | None = None
    recent_interactions: list[dict[str, Any]] | None = None
    last_diff_summary: dict[str, Any] | None = None
    screenshot: str | None = None


class ContextAttachment(BaseModel):
    """Client-supplied context for a conversation turn."""

    project_id: str
    safety_mode: str = "advisory"
    working_dir: str | None = None
    domain_id: str | None = None
    workflow_id: str | None = None
    revision_id: str | None = None
    run_id: str | None = None
    artifact_id: str | None = None
    derivation_id: str | None = None
    selected_nodes: list[str] | None = None
    current_route: str | None = None
    ui_state: dict[str, Any] | None = None

    def resolve_ui_state(self) -> UIState:
        """Parse ui_state dict into typed UIState with defaults."""
        if self.ui_state is None:
            return UIState()
        return UIState.model_validate(self.ui_state)


class AssistantContextAssembler:
    """Resolves Studio context for an assistant conversation turn.

    Reads from the existing WorkflowStudioRepository to populate workflow
    and run context alongside client-supplied UI state.
    """

    def __init__(
        self,
        repository: WorkflowStudioRepository,
        project_root: Any | None = None,
    ) -> None:
        self._repository = repository
        self._project_root = project_root

    def resolve(self, context: ContextAttachment) -> dict[str, Any]:
        """Resolve full context from a client-supplied attachment.

        Returns a dict with keys: project_id, workflow, latest_run,
        ui_context, safety_mode.
        """
        resolved_workflow: dict[str, Any] | None = None
        resolved_latest_run: dict[str, Any] | None = None
        resolved_selected_run: dict[str, Any] | None = None
        resolved_selected_artifact: dict[str, Any] | None = None
        resolved_selected_derivation: dict[str, Any] | None = None
        resolved_run_replay: dict[str, Any] | None = None
        artifact_content: str | None = None
        output_review: dict[str, Any] | None = None
        resolved_domain_id = normalize_starter_domain_id(context.domain_id)
        selected_run_bundle = None

        if context.workflow_id is not None:
            try:
                resolved_workflow = self._repository.get_workflow(context.workflow_id)
            except Exception as exc:
                logger.warning("Failed to resolve workflow %s: %s", context.workflow_id, exc)
                resolved_workflow = None

            if resolved_workflow is not None:
                try:
                    matching_runs = self._repository.list_runs(workflow_id=context.workflow_id)
                    if matching_runs:
                        resolved_latest_run = matching_runs[0]
                except Exception as exc:
                    logger.warning("Failed to list runs for workflow %s: %s", context.workflow_id, exc)
                    resolved_latest_run = None

        if context.run_id is not None:
            try:
                resolved_selected_run = self._repository.get_run(context.run_id)
            except Exception as exc:
                logger.warning("Failed to resolve run %s: %s", context.run_id, exc)
                resolved_selected_run = None
            try:
                selected_run_bundle = self._repository.get_run_bundle(context.run_id)
            except Exception as exc:
                logger.warning("Failed to resolve run bundle %s: %s", context.run_id, exc)
                selected_run_bundle = None
            if resolved_selected_run is not None:
                try:
                    resolved_run_replay = self._repository.get_run_replay(context.run_id)
                except Exception as exc:
                    logger.warning("Failed to resolve run replay %s: %s", context.run_id, exc)
                    resolved_run_replay = None
                if resolved_workflow is None:
                    selected_workflow_id = (
                        resolved_selected_run.get("workflow_ref", {}).get("workflow_id")
                        if isinstance(resolved_selected_run.get("workflow_ref"), dict)
                        else resolved_selected_run.get("workflow_id")
                    )
                    if selected_workflow_id:
                        try:
                            resolved_workflow = self._repository.get_workflow(str(selected_workflow_id))
                        except Exception as exc:
                            logger.warning("Failed to resolve workflow %s from run: %s", selected_workflow_id, exc)
                            resolved_workflow = None

        if context.artifact_id is not None:
            try:
                resolved_selected_artifact = self._repository.get_artifact(context.artifact_id)
            except Exception as exc:
                logger.warning("Failed to resolve artifact %s: %s", context.artifact_id, exc)
                resolved_selected_artifact = None
            try:
                artifact_content = self._repository.get_artifact_content(context.artifact_id)
            except Exception as exc:
                logger.warning("Failed to resolve artifact content %s: %s", context.artifact_id, exc)
                artifact_content = None
            if resolved_selected_artifact is not None:
                producer_run_id = resolved_selected_artifact.get("producer_run_id")
                if producer_run_id and resolved_selected_run is None:
                    try:
                        resolved_selected_run = self._repository.get_run(str(producer_run_id))
                    except Exception as exc:
                        logger.warning("Failed to resolve producer run %s: %s", producer_run_id, exc)
                        resolved_selected_run = None
                    try:
                        selected_run_bundle = self._repository.get_run_bundle(str(producer_run_id))
                    except Exception as exc:
                        logger.warning("Failed to resolve producer run bundle %s: %s", producer_run_id, exc)
                        selected_run_bundle = None
                    if resolved_selected_run is not None:
                        try:
                            resolved_run_replay = self._repository.get_run_replay(str(producer_run_id))
                        except Exception as exc:
                            logger.warning("Failed to resolve producer run replay %s: %s", producer_run_id, exc)
                            resolved_run_replay = None
                if resolved_workflow is None and resolved_selected_run is not None:
                    selected_workflow_id = (
                        resolved_selected_run.get("workflow_ref", {}).get("workflow_id")
                        if isinstance(resolved_selected_run.get("workflow_ref"), dict)
                        else resolved_selected_run.get("workflow_id")
                    )
                    if selected_workflow_id:
                        try:
                            resolved_workflow = self._repository.get_workflow(str(selected_workflow_id))
                        except Exception as exc:
                            logger.warning("Failed to resolve workflow %s from artifact: %s", selected_workflow_id, exc)
                            resolved_workflow = None

        if context.derivation_id is not None:
            try:
                resolved_selected_derivation = self._repository.get_derivation(context.derivation_id)
            except Exception as exc:
                logger.warning("Failed to resolve derivation %s: %s", context.derivation_id, exc)
                resolved_selected_derivation = None

        if resolved_selected_run is not None:
            resolved_latest_run = resolved_selected_run

        if selected_run_bundle is None and resolved_selected_run is not None:
            selected_run_id = (
                str(resolved_selected_run.get("workflow_run_id") or resolved_selected_run.get("run_id") or "")
                .strip()
            )
            if selected_run_id:
                try:
                    selected_run_bundle = self._repository.get_run_bundle(selected_run_id)
                except Exception as exc:
                    logger.warning("Failed to resolve run bundle %s (fallback): %s", selected_run_id, exc)
                    selected_run_bundle = None

        if not resolved_domain_id and isinstance(resolved_workflow, dict):
            resolved_domain_id = normalize_starter_domain_id(
                str(resolved_workflow.get("domain_id") or resolved_workflow.get("domain") or "")
            )

        ui_context: dict[str, Any] = {}
        if context.selected_nodes is not None:
            ui_context["selected_nodes"] = context.selected_nodes
        if context.current_route is not None:
            ui_context["current_route"] = context.current_route
        if context.ui_state is not None:
            ui_context.update(context.ui_state)
        if resolved_domain_id:
            ui_context["domain_id"] = resolved_domain_id

        # Revision history
        revision_history: list[dict[str, Any]] = []
        if context.workflow_id is not None and resolved_workflow is not None:
            try:
                from obra.config.loaders import get_gateway_assistant_config
                ac = get_gateway_assistant_config()
                max_revisions = ac.get("revision_history_max_revisions", 5)
                revisions = self._repository.list_workflow_revisions(context.workflow_id)
                revision_history = revisions[-max_revisions:]
            except Exception as exc:
                logger.warning("Failed to resolve revision history for workflow %s: %s", context.workflow_id, exc)
                revision_history = []

        # Run timeline (for failed/cancelled runs)
        run_timeline: list[dict[str, Any]] = []
        if resolved_latest_run and isinstance(resolved_latest_run, dict):
            run_status = str(resolved_latest_run.get("status") or "")
            if run_status in {"failed", "cancelled"}:
                run_id = resolved_latest_run.get("run_id") or resolved_latest_run.get("id")
                if run_id:
                    try:
                        from obra.config.loaders import get_gateway_assistant_config as _get_ac
                        _ac = _get_ac()
                        max_events = _ac.get("run_timeline_max_events", 10)
                        replay = self._repository.get_run_replay(run_id)
                        if replay and isinstance(replay, dict):
                            run_timeline = (replay.get("entries") or [])[-max_events:]
                    except Exception as exc:
                        logger.warning("Failed to resolve run timeline for run %s: %s", run_id, exc)
                        run_timeline = []

        # Template assets
        template_assets: dict[str, str] = {}
        if resolved_workflow is not None:
            stages = (
                resolved_workflow.get("stages")
                or resolved_workflow.get("definition", {}).get("stages")
                or []
            )
            for stage in stages:
                bindings = stage.get("template_asset_bindings") or []
                stage_id = stage.get("stage_id") or stage.get("id") or ""
                for binding in bindings:
                    asset_id = binding.get("asset_id") or binding.get("template_id")
                    if asset_id:
                        try:
                            content = self._repository.get_template_asset(asset_id)
                            if content:
                                template_assets[stage_id] = content
                        except Exception as exc:
                            logger.warning("Failed to resolve template asset %s for stage %s: %s", asset_id, stage_id, exc)

        # Knowledge documents
        knowledge_documents: list[dict[str, Any]] = []
        if self._project_root is not None:
            try:
                from obra.config.loaders import get_gateway_assistant_config as _get_kac
                from obra.gateway.workflow_studio.knowledge_repository import KnowledgeRepository

                kac = _get_kac()
                krepo = KnowledgeRepository(
                    self._project_root,
                    max_document_bytes=kac["knowledge_max_document_bytes"],
                    max_total_bytes=kac["knowledge_max_total_bytes"],
                )
                # Org-wide docs
                for doc in krepo.list_documents(scope="org-wide"):
                    try:
                        _, content_text = krepo.get_document(doc["id"])
                        knowledge_documents.append({
                            "name": doc.get("name", ""),
                            "scope": doc.get("scope", "org-wide"),
                            "description": doc.get("description"),
                            "content_text": content_text,
                        })
                    except Exception as exc:
                        logger.warning("Failed to resolve org-wide knowledge document %s: %s", doc.get("id"), exc)
                # Workflow-specific docs
                if context.workflow_id:
                    for doc in krepo.list_documents(scope="workflow", workflow_id=context.workflow_id):
                        try:
                            _, content_text = krepo.get_document(doc["id"])
                            knowledge_documents.append({
                                "name": doc.get("name", ""),
                                "scope": doc.get("scope", "workflow"),
                                "description": doc.get("description"),
                                "content_text": content_text,
                            })
                        except Exception as exc:
                            logger.warning("Failed to resolve workflow knowledge document %s: %s", doc.get("id"), exc)
            except Exception as exc:
                logger.warning("Failed to initialize knowledge repository: %s", exc)
                knowledge_documents = []

        starter_catalog = [
            {
                "id": str(starter.get("id") or ""),
                "title": str(starter.get("title") or ""),
                "description": str(starter.get("description") or ""),
                "intended_use_cases": starter.get("intended_use_cases") or [],
            }
            for starter in resolve_domain_starters(resolved_domain_id)
        ]

        output_review = build_output_review_context(
            bundle=selected_run_bundle,
            selected_run=resolved_selected_run,
            selected_artifact=resolved_selected_artifact,
            artifact_content=artifact_content,
            run_replay=resolved_run_replay,
        )
        business_tier_defaults = _resolve_business_tier_defaults(
            domain_id=resolved_domain_id,
            workflow=resolved_workflow,
        )

        return {
            "project_id": context.project_id,
            "working_dir": context.working_dir,
            "domain_id": resolved_domain_id or None,
            "workflow_id": context.workflow_id,
            "revision_id": context.revision_id,
            "workflow": resolved_workflow,
            "latest_run": resolved_latest_run,
            "selected_run": resolved_selected_run,
            "selected_artifact": resolved_selected_artifact,
            "selected_derivation": resolved_selected_derivation,
            "run_replay": resolved_run_replay,
            "artifact_content": artifact_content,
            "ui_context": ui_context,
            "safety_mode": context.safety_mode,
            "revision_history": revision_history,
            "run_timeline": run_timeline,
            "template_assets": template_assets,
            "starter_catalog": starter_catalog,
            "knowledge_documents": knowledge_documents,
            "output_review": output_review,
            **business_tier_defaults,
        }
