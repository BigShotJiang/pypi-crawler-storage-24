"""Aptis API client"""
import requests
from typing import List, Dict, Any, Optional
from datetime import date
from aptis_strategy_sdk.models import Signal, Position, Bar, Quote
from aptis_strategy_sdk.exceptions import AptisAPIError, AuthenticationError

class AptisClient:
    """Client for Aptis platform API"""
    
    def __init__(self, api_key: str, base_url: str = "http://localhost:8082"):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Bearer {api_key}"})
        self._config_cache = {}
    
    def get_config(self, strategy_name: str) -> Dict[str, Any]:
        """Get strategy configuration (NAV, funds, portfolio_weight)"""
        if strategy_name in self._config_cache:
            return self._config_cache[strategy_name]
        
        response = self._request("GET", "/api/v1/strategy/config", params={"strategy_name": strategy_name})
        config = response.get("config", {})
        self._config_cache[strategy_name] = config
        return config
    
    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make API request with error handling"""
        url = f"{self.base_url}{endpoint}"
        try:
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                raise AuthenticationError("Invalid API key")
            raise AptisAPIError(f"API error: {e.response.text}")
        except requests.exceptions.RequestException as e:
            raise AptisAPIError(f"Request failed: {str(e)}")
    
    def submit_signal(self, signal: Signal = None, strategy_name: str = None,
                       account: str = None, symbol: str = None, asset_class: str = None,
                       quantity: float = None, side: str = None, signal_type: str = None,
                       order_parameters: dict = None, metadata: dict = None) -> Dict[str, Any]:
        """Submit trading signal - accepts Signal object or individual kwargs"""
        if signal is None:
            signal = Signal(symbol=symbol, asset_class=asset_class, quantity=quantity,
                            side=side, signal_type=signal_type,
                            order_parameters=order_parameters, metadata=metadata)
        payload = {
            "symbol": signal.symbol,
            "asset_class": signal.asset_class,
            "quantity": signal.quantity,
            "side": signal.side,
            "signal_type": signal.signal_type,
            "strategy_name": strategy_name,
            "account": account,
            "order_parameters": signal.order_parameters,
            "metadata": signal.metadata,
        }
        return self._request("POST", "/api/v1/strategy/signals/submit", json=payload)
    
    def get_features(self, symbols: List[str], date: date, features: List[str]) -> Dict[str, Dict[str, float]]:
        """Get Dagster-calculated features"""
        params = {
            "symbols": ",".join(symbols),
            "date": date.isoformat(),
            "features": ",".join(features),
        }
        response = self._request("GET", "/api/v1/strategy/features", params=params)
        return response.get("data", {})
    
    def get_quotes(self, symbols: List[str], asset_class: Optional[str] = None) -> List[Dict]:
        """Get market quotes"""
        params = {"symbols": ",".join(symbols)}
        if asset_class:
            params["asset_class"] = asset_class
        response = self._request("GET", "/api/v1/strategy/market-data/quotes", params=params)
        return response.get("data", [])
    
    def get_bars(self, symbol: str, asset_class: str, timeframe: str, 
                 start: str, end: str, limit: int = 1000) -> List[Bar]:
        """Get OHLCV bars"""
        params = {
            "symbol": symbol,
            "asset_class": asset_class,
            "timeframe": timeframe,
            "start": start,
            "end": end,
            "limit": limit,
        }
        response = self._request("GET", "/api/v1/strategy/market-data/bars", params=params)
        return response.get("bars", [])
    
    def get_positions(self, account: str, strategy_name: Optional[str] = None) -> List[Position]:
        """Get current positions"""
        params = {"account": account}
        if strategy_name:
            params["strategy_name"] = strategy_name
        response = self._request("GET", "/api/v1/strategy/positions", params=params)
        return [Position(**p) for p in response.get("positions", [])]
    
    def get_pnl(self, account: str, start_date: date, end_date: date, 
                strategy_name: Optional[str] = None) -> Dict[str, Any]:
        """Get P&L summary"""
        params = {
            "account": account,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
        }
        if strategy_name:
            params["strategy_name"] = strategy_name
        response = self._request("GET", "/api/v1/strategy/pnl", params=params)
        return response.get("summary", {})
