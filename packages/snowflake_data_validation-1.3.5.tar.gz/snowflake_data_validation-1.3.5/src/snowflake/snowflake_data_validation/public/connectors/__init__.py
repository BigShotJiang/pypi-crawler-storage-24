# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Database connectors and factories for the public validation API.

This module exposes all database connector classes and their factories
for connecting to different database platforms for data validation.

Connectors:
    - ConnectorBase: Abstract base class for custom connector implementations
    - ConnectorSnowflake: Connector for Snowflake databases
    - ConnectorSqlServer: Connector for SQL Server databases
    - ConnectorRedshift: Connector for Amazon Redshift databases
    - ConnectorTeradata: Connector for Teradata databases

Factories:
    - ConnectorFactoryBase: Abstract base class for connector factories
    - ConnectorFactory: Generic factory to create connectors based on Platform enum
    - SnowflakeConnectorFactory: Factory for Snowflake connectors
    - SqlServerConnectorFactory: Factory for SQL Server connectors
    - RedshiftConnectorFactory: Factory for Redshift connectors
    - TeradataConnectorFactory: Factory for Teradata connectors

Example usage:
    # Direct connector instantiation
    from snowflake.snowflake_data_validation.public.connectors import ConnectorSnowflake

    connector = ConnectorSnowflake()
    connector.connect(mode="credentials", account="...", username="...", ...)

    # Using the generic factory
    from snowflake.snowflake_data_validation.public.connectors import ConnectorFactory
    from snowflake.snowflake_data_validation.public.enums import Platform

    connector = ConnectorFactory.create_connector(Platform.SNOWFLAKE, connection_config)

    # Using platform-specific factory
    from snowflake.snowflake_data_validation.public.connectors import SnowflakeConnectorFactory

    connector = SnowflakeConnectorFactory.create_connector(connection_config)

"""

# =============================================================================
# CONNECTORS
# =============================================================================
from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.redshift.connector.connector_redshift import (
    ConnectorRedshift,
)
from snowflake.snowflake_data_validation.snowflake.connector.connector_snowflake import (
    ConnectorSnowflake,
)
from snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server import (
    ConnectorSqlServer,
)
from snowflake.snowflake_data_validation.teradata.connector.connector_teradata import (
    ConnectorTeradata,
)

# =============================================================================
# CONNECTOR FACTORIES
# =============================================================================
from snowflake.snowflake_data_validation.connector.connector_factory_base import (
    ConnectorFactoryBase,
)
from snowflake.snowflake_data_validation.redshift.connector.connector_factory_redshift import (
    RedshiftConnectorFactory,
)
from snowflake.snowflake_data_validation.snowflake.connector.connector_factory_snowflake import (
    SnowflakeConnectorFactory,
)
from snowflake.snowflake_data_validation.sqlserver.connector.connector_factory_sql_server import (
    SqlServerConnectorFactory,
)
from snowflake.snowflake_data_validation.teradata.connector.connector_factory_teradata import (
    TeradataConnectorFactory,
)
from snowflake.snowflake_data_validation.utils.connector_factory import ConnectorFactory

__all__ = [
    "ConnectorBase",
    "ConnectorFactoryBase",
    "ConnectorSnowflake",
    "ConnectorSqlServer",
    "ConnectorRedshift",
    "ConnectorTeradata",
    "ConnectorFactory",
    "SnowflakeConnectorFactory",
    "SqlServerConnectorFactory",
    "RedshiftConnectorFactory",
    "TeradataConnectorFactory",
]
