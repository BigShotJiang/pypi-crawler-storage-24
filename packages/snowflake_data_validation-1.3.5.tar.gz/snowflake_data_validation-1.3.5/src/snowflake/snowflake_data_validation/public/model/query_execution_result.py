# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Query execution result data transfer object."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd
import polars as pl


@dataclass(frozen=True)
class QueryExecutionResult:
    """Output of the query execution step.

    This immutable data structure encapsulates the result of executing
    a query.

    Attributes:
        dataframe: The DataFrame containing query results, which can be
            either a pandas DataFrame or a polars DataFrame.

    """

    dataframe: pd.DataFrame | pl.DataFrame
