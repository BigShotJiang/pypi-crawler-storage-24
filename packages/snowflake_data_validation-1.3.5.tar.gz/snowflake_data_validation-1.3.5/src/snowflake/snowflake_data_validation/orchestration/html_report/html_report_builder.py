# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Builder class for generating HTML validation reports."""

from __future__ import annotations

import os

import pandas as pd

from snowflake.snowflake_data_validation.orchestration.html_report.report_metadata import (
    ReportMetadata,
)


# CSS styles for the HTML report
CSS_STYLES = """
body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
    line-height: 1.6;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    background-color: #f5f5f5;
    color: #333;
}
h1 {
    color: #29B5E8;
    border-bottom: 2px solid #29B5E8;
    padding-bottom: 10px;
}
h2 {
    color: #29B5E8;
    margin-top: 30px;
    border-bottom: 1px solid #ddd;
    padding-bottom: 5px;
}
table.dataTable {
    border-collapse: collapse;
    width: 100%;
    margin: 15px 0;
    background-color: white;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
table.dataTable th,
table.dataTable td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
}
table.dataTable thead th {
    background-color: #29B5E8;
    color: white;
    font-weight: 600;
}
table.dataTable tbody tr:nth-child(even) {
    background-color: #f8f9fa;
}
table.dataTable tbody tr:hover {
    background-color: #e8f0fe;
}
.simple-text{
    color: #666;
    font-size: 0.95em;
    margin-bottom: 20px;
}
.dataTables_wrapper {
    margin-bottom: 30px;
}
.dataTables_filter input {
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px 10px;
    margin-left: 5px;
    margin-bottom: 10px;
}
.dataTables_length select {
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px;
}
.dataTables_paginate .paginate_button.current {
    background: #29B5E8 !important;
    color: white !important;
    border: 1px solid #29B5E8 !important;
}
.dataTables_paginate .paginate_button:hover {
    background: #e8f0fe !important;
    color: #29B5E8 !important;
    border: 1px solid #ddd !important;
}
/* Simple table styling without pagination */
table.simple-table {
    border-collapse: collapse;
    width: 100%;
    margin: 15px 0;
    background-color: white;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
table.simple-table th,
table.simple-table td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
}
table.simple-table thead th {
    background-color: #29B5E8;
    color: white;
    font-weight: 600;
}
table.simple-table tbody tr:nth-child(even) {
    background-color: #f8f9fa;
}
table.simple-table tbody tr:hover {
    background-color: #e8f0fe;
}
.simple-table-wrapper {
    margin-bottom: 30px;
    overflow-x: auto;
}
"""

# JavaScript for DataTables initialization
DATATABLES_SCRIPT = """
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('table.display').DataTable({
            pageLength: 10,
            lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
            order: [],
            language: {
                search: "Filter:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "Next",
                    previous: "Previous"
                }
            }
        });
    });
</script>
"""


class HtmlReportBuilder:
    """Builder class for generating HTML validation reports.

    This class provides a fluent interface for constructing HTML reports
    with sections, tables, and metadata.

    """

    def __init__(self) -> None:
        """Initialize the HtmlReportBuilder with empty sections."""
        self._sections: list[str] = []

    def add_header(self, title: str) -> HtmlReportBuilder:
        """Add the HTML document header with CSS styles.

        Args:
            title: The title for the HTML document.

        Returns:
            HtmlReportBuilder: Self for method chaining.

        """
        header = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
    <style>
{CSS_STYLES}
    </style>
</head>
<body>
<h1>{title}</h1>
"""
        self._sections.append(header)
        return self

    def add_metadata(self, metadata: ReportMetadata) -> HtmlReportBuilder:
        """Add report metadata section (date, platforms, execution ID).

        Args:
            metadata: ReportMetadata instance containing report information.

        Returns:
            HtmlReportBuilder: Self for method chaining.

        """
        metadata_html = f"""<p class="simple-text">Date: {metadata.date}</p>
<p class="simple-text">Source platform: {metadata.source_platform}</p>
<p class="simple-text">Source connection identifier: {metadata.source_connection}</p>
<p class="simple-text">Target platform: {metadata.target_platform}</p>
<p class="simple-text">Target connection identifier: {metadata.target_connection}</p>
<p class="simple-text">Execution ID: {metadata.execution_id}</p>
"""
        self._sections.append(metadata_html)
        return self

    def add_summary_table(self, dataframe: pd.DataFrame) -> HtmlReportBuilder:
        """Add a summary table without a section header.

        Args:
            dataframe: DataFrame to render as an HTML table.

        Returns:
            HtmlReportBuilder: Self for method chaining.

        """
        table_html = dataframe.to_html(index=False, border=0, classes="simple-table")
        self._sections.append(f"{table_html}\n")
        return self

    def add_section(
        self,
        title: str,
        summary_df: pd.DataFrame,
        details_df: pd.DataFrame,
    ) -> HtmlReportBuilder:
        """Add a validation section with summary and details tables.

        Args:
            title: The section title (e.g., "SCHEMA VALIDATION SUMMARY").
            summary_df: DataFrame for the summary table (simple styling).
            details_df: DataFrame for the details table (with DataTables pagination).

        Returns:
            HtmlReportBuilder: Self for method chaining.

        """
        summary_table = summary_df.to_html(
            index=False, border=0, classes="simple-table"
        )
        details_table = details_df.to_html(index=False, border=0, classes="display")

        section_html = f"""<h2>{title}</h2>
{summary_table}
<br>
{details_table}
"""
        self._sections.append(section_html)
        return self

    def add_scripts(self) -> HtmlReportBuilder:
        """Add JavaScript for DataTables functionality.

        Returns:
            HtmlReportBuilder: Self for method chaining.

        """
        self._sections.append(DATATABLES_SCRIPT)
        return self

    def add_footer(self) -> HtmlReportBuilder:
        """Add the HTML document footer (closing tags).

        Returns:
            HtmlReportBuilder: Self for method chaining.

        """
        self._sections.append("</body>\n</html>")
        return self

    def build(self) -> str:
        """Build and return the complete HTML document.

        Returns:
            str: The complete HTML document as a string.

        """
        return "".join(self._sections)

    def write_to_file(self, path: str) -> None:
        """Write the HTML report to a file.

        Creates the directory if it doesn't exist and writes
        the complete HTML document to the specified path.

        Args:
            path: The file path where the report should be written.

        """
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

        with open(path, "w", encoding="utf-8") as report_file:
            report_file.write(self.build())
