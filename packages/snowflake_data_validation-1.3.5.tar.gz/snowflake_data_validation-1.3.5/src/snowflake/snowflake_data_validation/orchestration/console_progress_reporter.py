from snowflake.snowflake_data_validation.utils.base_output_handler import (
    OutputHandlerBase,
    OutputMessageLevel,
)
from snowflake.snowflake_data_validation.validation.results_summary_report import (
    ResultsSummaryReport,
)


class ConsoleProgressReporter:
    """Handles console output reporting for validation results."""

    def __init__(self, output_handler: OutputHandlerBase) -> None:
        """Initialize the console output reporter.

        Args:
            output_handler: The output handler to use for console reporting.

        """
        self.output_handler = output_handler

    def generate_console_output_report(
        self, results_summary: ResultsSummaryReport
    ) -> None:
        """Generate console output report DataFrame.

        Args:
            results_summary: The ResultsSummaryReport instance to use.

        """
        self.output_handler.handle_message(
            level=OutputMessageLevel.INFO,
            header="DATA VALIDATION SUMMARY RESULTS REPORTS",
            dataframe=results_summary.summary,
        )

        self.output_handler.handle_message(
            level=OutputMessageLevel.INFO,
            header="SCHEMA VALIDATION SUMMARY",
            dataframe=results_summary.schema_validation_summary,
        )

        self.output_handler.handle_message(
            level=OutputMessageLevel.INFO,
            header="METRICS VALIDATION SUMMARY",
            dataframe=results_summary.metrics_validation_summary,
        )

        self.output_handler.handle_message(
            level=OutputMessageLevel.INFO,
            header="ROW VALIDATION SUMMARY",
            dataframe=results_summary.row_validation_summary,
        )
