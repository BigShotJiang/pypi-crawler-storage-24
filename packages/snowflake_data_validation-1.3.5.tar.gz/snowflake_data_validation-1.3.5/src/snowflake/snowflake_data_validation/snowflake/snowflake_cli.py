# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Snowflake CLI commands for data validation."""

import logging

from functools import wraps
from pathlib import Path
from typing import Annotated

import typer

from snowflake.snowflake_data_validation.common_cli.cli_partitioning import (
    run_column_partitioning_helper,
    run_row_partitioning_helper,
)
from snowflake.snowflake_data_validation.common_cli.cli_sync_validation import (
    sync_validation_results,
)
from snowflake.snowflake_data_validation.comparison_orchestrator import (
    ComparisonOrchestrator,
)
from snowflake.snowflake_data_validation.configuration.configuration_loader import (
    ConfigurationLoader,
)
from snowflake.snowflake_data_validation.snowflake.model.snowflake_credentials_connection import (
    SnowflakeCredentialsConnection,
)
from snowflake.snowflake_data_validation.snowflake.model.snowflake_named_connection import (
    SnowflakeNamedConnection,
)
from snowflake.snowflake_data_validation.snowflake.snowflake_arguments_manager import (
    SnowflakeArgumentsManager,
)
from snowflake.snowflake_data_validation.utils import configuration_file_generator
from snowflake.snowflake_data_validation.utils.arguments_manager_factory import (
    create_validation_environment_from_config,
)
from snowflake.snowflake_data_validation.utils.console_output_handler import (
    ConsoleOutputHandler,
)
from snowflake.snowflake_data_validation.utils.constants import (
    CREDENTIALS_CONNECTION_MODE,
    DEFAULT_CONNECTION_MODE,
    NAME_CONNECTION_MODE,
    ExecutionMode,
    Platform,
)
from snowflake.snowflake_data_validation.utils.logging_config import setup_logging
from snowflake.snowflake_data_validation.utils.validation_utils import (
    build_snowflake_credentials,
    validate_snowflake_credentials,
)


# Create logger for this module
LOGGER = logging.getLogger(__name__)


# Create Snowflake typer app
snowflake_app = typer.Typer()


def handle_validation_errors(func):
    """Handle validation errors and provide user-friendly messages."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except typer.BadParameter as e:
            typer.secho(f"Invalid parameter: {e}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1) from None
        except FileNotFoundError as e:
            typer.secho(
                f"Configuration file not found: {e}", fg=typer.colors.RED, err=True
            )
            raise typer.Exit(1) from None
        except ConnectionError as e:
            typer.secho(f"Connection error: {e}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1) from None
        except Exception as e:
            typer.secho(f"Validation failed: {e}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1) from None

    return wrapper


def create_environment_from_config(
    data_validation_config_file: str,
    execution_mode: ExecutionMode,
    console_output: bool = True,
):
    """Create validation environment from configuration file."""
    config_path = Path(data_validation_config_file)
    config_loader = ConfigurationLoader(config_path)
    config_model = config_loader.get_configuration_model()

    return create_validation_environment_from_config(
        config_model=config_model,
        data_validation_config_file=data_validation_config_file,
        execution_mode=execution_mode,
        output_handler=ConsoleOutputHandler(enable_console_output=console_output),
    )


@snowflake_app.command("run-validation")
@handle_validation_errors
def snowflake_run_validation(
    data_validation_config_file: Annotated[
        str,
        typer.Option(
            "--data-validation-config-file",
            "-dvf",
            help="Data validation configuration file path. ",
        ),
    ],
    log_level: Annotated[
        str,
        typer.Option(
            "--log-level",
            "-ll",
            help="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL). Defaults to INFO.",
        ),
    ] = "INFO",
    logs_path: Annotated[
        str | None,
        typer.Option(
            "--logs-path",
            "-lp",
            help="Custom directory path for log files. Defaults to current directory.",
        ),
    ] = None,
):
    """Run data validation for Snowflake to Snowflake."""
    # Load configuration to check for logging settings
    from pathlib import Path

    from snowflake.snowflake_data_validation.configuration.configuration_loader import (
        ConfigurationLoader,
    )

    config_loader = ConfigurationLoader(Path(data_validation_config_file))
    config_model = config_loader.get_configuration_model()

    # CLI parameter takes precedence over config file settings
    if config_model.logging_configuration and log_level == "INFO":
        # Use config file settings only if CLI parameter is default (INFO)
        logging_config = config_model.logging_configuration
        # CLI --logs-path takes precedence over config file logs_path
        effective_logs_path = logs_path or logging_config.logs_path
        setup_logging(
            log_level=logging_config.level,
            console_level=logging_config.console_level,
            file_level=logging_config.file_level,
            logs_path=effective_logs_path,
        )
    else:
        # Use CLI parameter (overrides config file)
        setup_logging(log_level=log_level, logs_path=logs_path)

    typer.secho("Starting Snowflake to Snowflake validation...", fg=typer.colors.BLUE)

    validation_env = create_environment_from_config(
        data_validation_config_file, ExecutionMode.SYNC_VALIDATION
    )
    orchestrator = ComparisonOrchestrator.from_validation_environment(validation_env)
    orchestrator.run_sync_comparison()
    typer.secho("Validation completed successfully!", fg=typer.colors.GREEN)


@snowflake_app.command("run-async-validation")
@handle_validation_errors
def snowflake_run_async_validation(
    data_validation_config_file: Annotated[
        str,
        typer.Option(
            "--data-validation-config-file",
            "-dvf",
            help="Data validation configuration file path. ",
        ),
    ],
):
    """Run data validation for Snowflake to Snowflake."""
    typer.secho("Starting Snowflake to Snowflake validation...", fg=typer.colors.BLUE)

    validation_env = create_environment_from_config(
        data_validation_config_file, ExecutionMode.ASYNC_VALIDATION
    )
    orchestrator = ComparisonOrchestrator.from_validation_environment(validation_env)
    orchestrator.run_async_comparison()
    typer.secho("Validation completed successfully!", fg=typer.colors.GREEN)


@snowflake_app.command("source-validate")
@handle_validation_errors
def snowflake_source_validate(
    data_validation_config_file: Annotated[
        str,
        typer.Option(
            "--data-validation-config-file",
            "-dvf",
            help="Data validation configuration file path. ",
        ),
    ],
    log_level: Annotated[
        str,
        typer.Option(
            "--log-level",
            "-ll",
            help="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL). Defaults to INFO.",
        ),
    ] = "INFO",
    logs_path: Annotated[
        str | None,
        typer.Option(
            "--logs-path",
            "-lp",
            help="Custom directory path for log files. Defaults to current directory.",
        ),
    ] = None,
) -> None:
    """Execute validation queries on source only and save results as Parquet files.

    This command extracts schema and metrics data from the source Snowflake database
    without performing any validation or comparison. Results are saved as Parquet
    files for later validation without needing source database access.
    """
    # Load configuration to check for logging settings
    from pathlib import Path

    from snowflake.snowflake_data_validation.configuration.configuration_loader import (
        ConfigurationLoader,
    )

    config_loader = ConfigurationLoader(Path(data_validation_config_file))
    config_model = config_loader.get_configuration_model()

    # CLI parameter takes precedence over config file settings
    if config_model.logging_configuration and log_level == "INFO":
        # Use config file settings only if CLI parameter is default (INFO)
        logging_config = config_model.logging_configuration
        # CLI --logs-path takes precedence over config file logs_path
        effective_logs_path = logs_path or logging_config.logs_path
        setup_logging(
            log_level=logging_config.level,
            console_level=logging_config.console_level,
            file_level=logging_config.file_level,
            logs_path=effective_logs_path,
        )
    else:
        # Use CLI parameter (overrides config file)
        setup_logging(log_level=log_level, logs_path=logs_path)

    typer.secho("Starting Snowflake source validation...", fg=typer.colors.BLUE)

    validation_env = create_environment_from_config(
        data_validation_config_file, ExecutionMode.SOURCE_VALIDATION
    )
    orchestrator = ComparisonOrchestrator.from_validation_environment(validation_env)
    orchestrator.run_source_validation()
    typer.secho(
        "Source validation completed - data saved as Parquet files!",
        fg=typer.colors.GREEN,
    )


@snowflake_app.command("run-validation-ipc")
@handle_validation_errors
def snowflake_run_validation_ipc(
    snow_account: Annotated[
        str | None,
        typer.Option("--snow-account", "-sa", help="Source Snowflake account name"),
    ] = None,
    snow_username: Annotated[
        str | None,
        typer.Option("--snow_username", "-su", help="Source Snowflake Username"),
    ] = None,
    snow_database: Annotated[
        str | None,
        typer.Option("--snow_database", "-sd", help="Source Snowflake Database used"),
    ] = None,
    snow_schema: Annotated[
        str | None,
        typer.Option("--snow_schema", "-ss", help="Source Snowflake Schema used"),
    ] = None,
    snow_warehouse: Annotated[
        str | None,
        typer.Option("--snow_warehouse", "-sw", help="Source Snowflake Warehouse used"),
    ] = None,
    snow_role: Annotated[
        str | None,
        typer.Option("--snow_role", "-sr", help="Source Snowflake Role used"),
    ] = None,
    snow_authenticator: Annotated[
        str | None,
        typer.Option(
            "--snow_authenticator",
            "-sau",
            help="Source Snowflake Authenticator method used",
        ),
    ] = None,
    snow_password: Annotated[
        str | None,
        typer.Option("--snow_password", "-sp", help="Source Snowflake Password"),
    ] = None,
    snow_connection_name: Annotated[
        str | None,
        typer.Option(
            "--snow_connection_name",
            "-scn",
            help="Source Snowflake named connection from config.toml or connections.toml",
        ),
    ] = None,
    # Target connection parameters
    target_snow_account: Annotated[
        str | None,
        typer.Option(
            "--target-snow-account", "-tsa", help="Target Snowflake account name"
        ),
    ] = None,
    target_snow_username: Annotated[
        str | None,
        typer.Option(
            "--target-snow_username", "-tsu", help="Target Snowflake Username"
        ),
    ] = None,
    target_snow_database: Annotated[
        str | None,
        typer.Option(
            "--target-snow_database", "-tsd", help="Target Snowflake Database used"
        ),
    ] = None,
    target_snow_schema: Annotated[
        str | None,
        typer.Option(
            "--target-snow_schema", "-tss", help="Target Snowflake Schema used"
        ),
    ] = None,
    target_snow_warehouse: Annotated[
        str | None,
        typer.Option(
            "--target-snow_warehouse", "-tsw", help="Target Snowflake Warehouse used"
        ),
    ] = None,
    target_snow_role: Annotated[
        str | None,
        typer.Option("--target-snow_role", "-tsr", help="Target Snowflake Role used"),
    ] = None,
    target_snow_authenticator: Annotated[
        str | None,
        typer.Option(
            "--target-snow_authenticator",
            "-tsau",
            help="Target Snowflake Authenticator method used",
        ),
    ] = None,
    target_snow_password: Annotated[
        str | None,
        typer.Option(
            "--target-snow_password", "-tsp", help="Target Snowflake Password"
        ),
    ] = None,
    target_connection_name: Annotated[
        str | None,
        typer.Option(
            "--target-connection-name",
            "-tcn",
            help="Target Snowflake named connection from config.toml or connections.toml",
        ),
    ] = None,
    data_validation_config_file: Annotated[
        str | None,
        typer.Option(
            "--data-validation-config-file",
            "-dvf",
            help="Data validation configuration file path. ",
        ),
    ] = None,
):
    """Run Snowflake data validation with IPC (In-Process Communication).

    This command allows direct specification of connection parameters without requiring
    pre-saved connection files. You can use either a named connection from config.toml
    or specify individual credentials. If target parameters are not specified, the default
    session connection will be used for the target.
    """
    typer.secho(
        "Starting Snowflake to Snowflake validation (IPC mode)...",
        fg=typer.colors.BLUE,
    )

    # Set up arguments manager and connections
    args_manager = SnowflakeArgumentsManager()

    # Set up source connection
    if snow_connection_name:
        # Use named connection from config.toml
        source_connector = SnowflakeNamedConnection(
            mode=NAME_CONNECTION_MODE,
            name=snow_connection_name,
        )
    else:
        # Use credentials-based connection
        snow_credential_object = build_snowflake_credentials(
            account=snow_account,
            username=snow_username,
            database=snow_database,
            schema=snow_schema,
            warehouse=snow_warehouse,
            role=snow_role,
            authenticator=snow_authenticator,
            password=snow_password,
        )

        # Validate Snowflake credentials if provided
        validate_snowflake_credentials(snow_credential_object)

        source_connector = SnowflakeCredentialsConnection(
            mode=CREDENTIALS_CONNECTION_MODE,
            account=snow_credential_object.get("account"),
            username=snow_credential_object.get("username"),
            database=snow_credential_object.get("database"),
            warehouse=snow_credential_object.get("warehouse"),
            schema=snow_credential_object.get("schema"),
            role=snow_credential_object.get("role"),
            authenticator=snow_credential_object.get("authenticator"),
            password=snow_credential_object.get("password"),
            private_key_file=snow_credential_object.get("private_key_file"),
            private_key_passphrase=snow_credential_object.get("private_key_passphrase"),
        )

    # Set up target connection
    if target_connection_name:
        # Use named connection from config.toml
        target_connector = SnowflakeNamedConnection(
            mode=NAME_CONNECTION_MODE,
            name=target_connection_name,
        )
    elif (
        target_snow_account
        and target_snow_username
        and target_snow_database
        and target_snow_schema
        and target_snow_warehouse
    ):
        # Use credentials-based connection
        snow_credential_object = build_snowflake_credentials(
            account=target_snow_account,
            username=target_snow_username,
            database=target_snow_database,
            schema=target_snow_schema,
            warehouse=target_snow_warehouse,
            role=target_snow_role,
            authenticator=target_snow_authenticator,
            password=target_snow_password,
        )

        # Validate Snowflake credentials if provided
        validate_snowflake_credentials(snow_credential_object)

        target_connector = SnowflakeCredentialsConnection(
            mode=CREDENTIALS_CONNECTION_MODE,
            account=snow_credential_object.get("account"),
            username=snow_credential_object.get("username"),
            database=snow_credential_object.get("database"),
            warehouse=snow_credential_object.get("warehouse"),
            schema=snow_credential_object.get("schema"),
            role=snow_credential_object.get("role"),
            authenticator=snow_credential_object.get("authenticator"),
            password=snow_credential_object.get("password"),
            private_key_file=snow_credential_object.get("private_key_file"),
            private_key_passphrase=snow_credential_object.get("private_key_passphrase"),
        )
    else:
        # Use default session connection
        target_connector = args_manager.setup_target_connection(
            target_conn_mode=DEFAULT_CONNECTION_MODE,
        )

    # Set up validation environment
    validation_env = args_manager.setup_validation_environment(
        source_connection_config=source_connector,
        target_connection_config=target_connector,
        data_validation_config_file=data_validation_config_file,
        output_handler=ConsoleOutputHandler(enable_console_output=True),
        execution_mode=ExecutionMode.SYNC_VALIDATION,
    )

    orchestrator = ComparisonOrchestrator.from_validation_environment(validation_env)
    orchestrator.run_sync_comparison()
    typer.secho("Validation completed successfully!", fg=typer.colors.GREEN)


@snowflake_app.command("generate-validation-scripts")
@handle_validation_errors
def snowflake_run_async_generation(
    data_validation_config_file: Annotated[
        str,
        typer.Option(
            "--data-validation-config-file",
            "-dvf",
            help="Data validation configuration file path. ",
        ),
    ],
):
    """Generate validation scripts for Snowflake to Snowflake.

    This command uses ScriptWriter instances to write SQL queries to files
    instead of executing them for validation.
    """
    typer.secho(
        "Starting Snowflake validation script generation...", fg=typer.colors.BLUE
    )

    validation_env = create_environment_from_config(
        data_validation_config_file, ExecutionMode.ASYNC_GENERATION
    )
    orchestrator = ComparisonOrchestrator.from_validation_environment(validation_env)
    orchestrator.run_async_generation()
    typer.secho("Validation scripts generated successfully!", fg=typer.colors.GREEN)


@snowflake_app.command(
    "get-configuration-files", help="Get configuration files for Snowflake validation."
)
def snowflake_get_configuration_files(
    templates_directory: Annotated[
        str | None,
        typer.Option(
            "--templates-directory",
            "-td",
            help="Directory to save the configuration templates.",
        ),
    ] = None,
    query_templates: Annotated[
        bool,
        typer.Option(
            "--query-templates",
            help="Include J2 query template files in the output.",
        ),
    ] = False,
):
    """Get configuration files for Snowflake validation."""
    try:
        typer.secho(
            "Retrieving Snowflake validation configuration files...",
            fg=typer.colors.BLUE,
        )
        args_manager = SnowflakeArgumentsManager()
        output_dir = templates_directory if templates_directory else "."
        args_manager.dump_and_write_yaml_templates(
            source=Platform.SNOWFLAKE.value,
            templates_directory=output_dir,
            query_templates=query_templates,
        )
        typer.secho("Configuration files were generated ", fg=typer.colors.GREEN)
    except PermissionError as e:
        raise RuntimeError(
            f"Permission denied while writing template files: {e}"
        ) from e
    except Exception as e:
        raise RuntimeError(f"Failed to generate configuration files: {e}") from e


@snowflake_app.command(
    "auto-generated-configuration-file",
    help="Generate a basic configuration file by prompting for Snowflake connection parameters.",
)
@handle_validation_errors
def snowflake_auto_generated_configuration_file():
    """Generate a basic configuration file by prompting for Snowflake connection parameters."""
    typer.secho(
        "Generating basic configuration file for Snowflake validation...",
        fg=typer.colors.BLUE,
    )
    typer.secho(
        "Please provide the following connection information:\n",
        fg=typer.colors.CYAN,
    )

    name_connection = typer.prompt(
        "Snowflake Named Connection name", type=str, default="default"
    )
    snowflake_connection = SnowflakeNamedConnection(
        mode=NAME_CONNECTION_MODE, name=name_connection
    )

    source_database = typer.prompt("Snowflake database", type=str)
    source_schema = typer.prompt("Snowflake schema", type=str)
    output_path = typer.prompt("Output path for the configuration file", type=str)

    try:
        success = configuration_file_generator.generate_configuration_file(
            platform=Platform.SNOWFLAKE,
            credentials_connection=snowflake_connection,
            database=source_database,
            schema=source_schema,
            output_path=output_path,
        )

        if success:
            typer.secho(
                "Configuration file generated successfully!", fg=typer.colors.GREEN
            )
            LOGGER.info("Configuration file generated successfully at: %s", output_path)
        else:
            typer.secho("Failed to generate configuration file.", fg=typer.colors.RED)
            LOGGER.warning("Failed to generate configuration file.")

    except Exception as e:
        typer.secho(f"Error generating configuration file: {e}", fg=typer.colors.RED)
        LOGGER.error("Error generating configuration file: %s", e)


@snowflake_app.command(
    "row-partitioning-helper",
    help="Interactive helper to configure row partitioning for tables in the configuration file.",
)
@snowflake_app.command("table-partitioning-helper", hidden=True)
@handle_validation_errors
def snowflake_row_partitioning_helper():
    """Generate a configuration file for Snowflake row partitioning.

    This interactive helper function processes each table in the configuration file,
    allowing users to either skip row partitioning or specify row partitioning parameters
    for each table.
    """
    run_row_partitioning_helper(Platform.SNOWFLAKE)


@snowflake_app.command(
    "column-partitioning-helper",
    help="Interactive helper to configure column partitioning for tables in the configuration file.",
)
@handle_validation_errors
def snowflake_column_partitioning_helper():
    """Generate a configuration file for Snowflake column partitioning.

    This interactive helper function processes each table in the configuration file,
    allowing users to either skip column partitioning or specify column partitioning parameters
    for each table.
    """
    run_column_partitioning_helper(Platform.SNOWFLAKE)


@snowflake_app.command(
    "sync-validation-results",
    help=(
        "Remove from the configuration file the tables and views that passed "
        "all validations levels in the given execution summary report file"
    ),
)
@handle_validation_errors
def snowflake_sync_validation_results(
    configuration_file_path: Annotated[
        str,
        typer.Option(
            "--configuration-file-path",
            "-cfp",
            help="Path to the configuration file",
        ),
    ],
    execution_summary_report_file_path: Annotated[
        str,
        typer.Option(
            "--execution-summary-report-file-path",
            "-esrfp",
            help="Path to the execution summary report file",
        ),
    ],
):
    """Sync the configuration file with the execution summary report.

    Remove tables and views that passed all validation levels.
    """
    sync_validation_results(
        configuration_file_path=configuration_file_path,
        execution_summary_report_file_path=execution_summary_report_file_path,
    )
