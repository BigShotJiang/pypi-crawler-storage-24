# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os

from snowflake.snowflake_data_validation.configuration.model.configuration_model import (
    ConfigurationModel,
)
from snowflake.snowflake_data_validation.utils.arguments_manager_base import (
    ArgumentsManagerBase,
    ValidationEnvironmentObject,
)
from snowflake.snowflake_data_validation.utils.console_output_handler import (
    ConsoleOutputHandler,
)
from snowflake.snowflake_data_validation.utils.constants import (
    ExecutionMode,
    Platform,
)


class ResultSetArgumentsManager(ArgumentsManagerBase):
    """Arguments manager for Result Set validation.

    This manager is primarily used for exporting Result Set templates.
    Result Set validation does not use database connections, so the
    create_validation_environment_from_config method is not supported.
    """

    def __init__(self):
        """Initialize the Result Set arguments manager."""
        super().__init__(Platform.RESULT_SET, Platform.RESULT_SET)

    @property
    def is_snowflake_to_snowflake(self) -> bool:
        """Check if this is a Snowflake-to-Snowflake validation scenario.

        Returns:
            bool: False - Result Set validation is not Snowflake-to-Snowflake

        """
        return False

    def create_validation_environment_from_config(
        self,
        config_model: ConfigurationModel,
        data_validation_config_file: str,
        execution_mode: ExecutionMode,
        output_handler: ConsoleOutputHandler | None = None,
    ) -> ValidationEnvironmentObject:
        """Not supported for Result Set validation.

        Result Set validation does not use database connections and therefore
        does not support creating a validation environment from configuration.

        Raises:
            NotImplementedError: Always raised as this operation is not supported.

        """
        raise NotImplementedError(
            "Result Set validation does not support creating validation environments "
            "from configuration. Use result_set_cell_level_validation or "
            "result_set_metrics_level_validation API functions instead."
        )

    def get_source_templates_path(self) -> str:
        """Get Result Set templates path."""
        current_dir = os.path.dirname(__file__)
        return os.path.join(current_dir, "extractor", "templates")

    def get_target_templates_path(self) -> str:
        """Get Result Set target templates path (same as source)."""
        return self.get_source_templates_path()
