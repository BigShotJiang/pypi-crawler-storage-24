# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import re
import struct

from typing import Literal

from shared.sqlserver.constants import SUPPORTED_ODBC_DRIVERS
from shared.sqlserver.odbc_driver_utils import (
    get_best_sqlserver_driver,
    is_driver_available,
)
from shared.sqlserver.version_detection import detect_sql_server_version
from snowflake.snowflake_data_validation.connector.connector_base import (
    ConnectorBase as BaseConnector,
)
from snowflake.snowflake_data_validation.utils.constants import (
    COLUMN_VALUES_CONCATENATED_ERROR_SQL_SERVER,
    CONNECTION_NOT_ESTABLISHED,
    EXCEED_MAX_STRING_LENGHT_SQL_SERVER_ERROR_CODE,
    FAILED_TO_EXECUTE_QUERY,
    FAILED_TO_EXECUTE_STATEMENT,
    TABLE_NOT_FOUND_ERROR_CODE_SQL_SERVER,
)
from snowflake.snowflake_data_validation.utils.helper import Helper
from snowflake.snowflake_data_validation.utils.logging_utils import log
from snowflake.snowflake_data_validation.utils.telemetry import (
    report_telemetry,
)


LOGGER = logging.getLogger(__name__)

# SQL Server connection mode type
SqlServerMode = Literal[
    "sql_auth", "windows_auth", "service_principal", "managed_identity"
]


@Helper.import_dependencies("sqlserver")
def import_mssql():
    """Import the pyodbc module for SQL Server connection."""
    import pyodbc

    return pyodbc


@Helper.import_dependencies("sqlserver")
def import_azure_identity():
    """Import the azure-identity module for Azure Entra ID authentication."""
    from azure.identity import (
        ClientSecretCredential,
        DefaultAzureCredential,
        ManagedIdentityCredential,
    )

    return ClientSecretCredential, DefaultAzureCredential, ManagedIdentityCredential


NAMED_INSTANCE_PATTERN_DETAILED = r"^[a-zA-Z0-9.-]+\\[a-zA-Z0-9_]+$"
DEFAULT_SQL_SERVER_PORT = 1433

def _escape_odbc_value(value: str) -> str:
    """Escape a value for safe inclusion in an ODBC connection string.

    ODBC uses `;` as a key-value separator and `{`/`}` as quoting
    characters.  Wrapping in braces and doubling `}` is always safe,
    even when the value has no special characters.
    """
    return "{" + value.replace("}", "}}") + "}"

# Azure SQL Database scope for token authentication
AZURE_SQL_SCOPE = "https://database.windows.net/.default"

# SQL Server Authentication connection strings
SQLSERVER_CONNECTION_STRING = (
    "DRIVER={{{driver}}};"
    "SERVER={server},{port};"
    "DATABASE={database};"
    "UID={user};"
    "PWD={password};"
    "TrustServerCertificate={trust_server_certificate};"
    "Encrypt={encrypt}"
)

SQLSERVER_CONNECTION_STRING_NAMED = (
    "DRIVER={{{driver}}};"
    "SERVER={server};"
    "DATABASE={database};"
    "UID={user};"
    "PWD={password};"
    "TrustServerCertificate={trust_server_certificate};"
    "Encrypt={encrypt}"
)

# Windows Authentication connection strings (Trusted Connection)
SQLSERVER_CONNECTION_STRING_WIN_AUTH = (
    "DRIVER={{{driver}}};"
    "SERVER={server},{port};"
    "DATABASE={database};"
    "Trusted_Connection=yes;"
    "TrustServerCertificate={trust_server_certificate};"
    "Encrypt={encrypt}"
)

SQLSERVER_CONNECTION_STRING_WIN_AUTH_NAMED = (
    "DRIVER={{{driver}}};"
    "SERVER={server};"
    "DATABASE={database};"
    "Trusted_Connection=yes;"
    "TrustServerCertificate={trust_server_certificate};"
    "Encrypt={encrypt}"
)

# Azure Entra ID connection strings (token-based authentication)
SQLSERVER_CONNECTION_STRING_AZURE_TOKEN = (
    "DRIVER={{{driver}}};"
    "SERVER={server},{port};"
    "DATABASE={database};"
    "TrustServerCertificate={trust_server_certificate};"
    "Encrypt={encrypt}"
)

SQLSERVER_CONNECTION_STRING_AZURE_TOKEN_NAMED = (
    "DRIVER={{{driver}}};"
    "SERVER={server};"
    "DATABASE={database};"
    "TrustServerCertificate={trust_server_certificate};"
    "Encrypt={encrypt}"
)


class ConnectorSqlServer(BaseConnector):
    """Connector for SQL Server database."""

    def __init__(self) -> None:
        """Initialize the SQL Server connector."""
        super().__init__()
        self.connection: object | None = None
        self.pyodbc = import_mssql()

        # SQL Server version detection properties (set after connection)
        self.sql_server_major_version: int | None = None
        self.is_azure_sql_db: bool = False
        self.supports_string_agg: bool = True  # Safe default for 2017+

    def _detect_odbc_driver(self, requested_driver: str | None = None) -> str:
        """Select the ODBC driver for SQL Server, with optional user override.

        When ``requested_driver`` is given and available, it is used directly.
        If it is not installed, the method falls back to auto-detection and
        logs a warning.  When no driver is specified, the best available one
        is auto-detected via shared.sqlserver.odbc_driver_utils.

        Args:
            requested_driver: Explicit ODBC driver name from user configuration.

        Returns:
            str: The name of the ODBC driver to use.

        Raises:
            ConnectionError: If no compatible ODBC driver is found.

        """
        if requested_driver:
            if is_driver_available(requested_driver):
                LOGGER.info("Using requested ODBC driver: %s", requested_driver)
                return requested_driver
            LOGGER.warning(
                "Requested ODBC driver '%s' is not installed. "
                "Falling back to auto-detection.",
                requested_driver,
            )

        driver = get_best_sqlserver_driver()
        if driver is None:
            raise ConnectionError(
                "No compatible ODBC driver found for SQL Server. "
                "Please install one of the following:\n"
                + "\n".join(f"  - {d}" for d in SUPPORTED_ODBC_DRIVERS[:2])
                + "\nSee: https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server"
            )
        LOGGER.info("Using %s (auto-detected)", driver)
        return driver

    def _detect_sql_server_version(self) -> None:
        """Detect the SQL Server version and set capability flags.

        Delegates to shared.sqlserver.version_detection.detect_sql_server_version().
        Updates instance attributes based on the detected version info.

        This method is called after connection verification and should not raise
        exceptions — version detection failure defaults to supports_string_agg=True.

        """
        if self.connection is None:
            return

        version_info = detect_sql_server_version(self.connection)
        self.sql_server_major_version = version_info.major_version
        self.is_azure_sql_db = version_info.is_azure_sql_db
        self.supports_string_agg = version_info.supports_string_agg

    def _get_azure_access_token(
        self,
        mode: SqlServerMode,
        client_id: str | None = None,
        client_secret: str | None = None,
        tenant_id: str | None = None,
    ) -> bytes:
        """Get an Azure access token for SQL Server authentication.

        Args:
            mode: The authentication mode ('service_principal' or 'managed_identity')
            client_id: Azure client ID (required for service_principal, optional for managed_identity)
            client_secret: Azure client secret (required for service_principal)
            tenant_id: Azure tenant ID (required for service_principal)

        Returns:
            bytes: The access token encoded for ODBC driver

        Raises:
            ValueError: If required parameters are missing
            ConnectionError: If token acquisition fails

        """
        try:
            (
                client_secret_credential_class,
                default_azure_credential_class,
                managed_identity_credential_class,
            ) = import_azure_identity()

            if mode == "service_principal":
                if not all([client_id, client_secret, tenant_id]):
                    raise ValueError(
                        "client_id, client_secret, and tenant_id are required "
                        "for Service Principal authentication."
                    )
                credential = client_secret_credential_class(
                    tenant_id=tenant_id,
                    client_id=client_id,
                    client_secret=client_secret,
                )
                LOGGER.debug(
                    "Using Service Principal credential for Azure authentication"
                )

            elif mode == "managed_identity":
                if client_id:
                    # User-assigned managed identity
                    credential = managed_identity_credential_class(client_id=client_id)
                    LOGGER.debug(
                        "Using User-assigned Managed Identity credential for Azure authentication"
                    )
                else:
                    # System-assigned managed identity
                    credential = default_azure_credential_class()
                    LOGGER.debug(
                        "Using System-assigned Managed Identity credential for Azure authentication"
                    )
            else:
                raise ValueError(f"Unsupported mode for Azure token: {mode}")

            # Get the access token
            token = credential.get_token(AZURE_SQL_SCOPE)
            access_token = token.token

            # Encode the token for ODBC driver
            # The token needs to be encoded as a UTF-16-LE byte string
            token_bytes = access_token.encode("UTF-16-LE")
            token_struct = struct.pack(
                f"<I{len(token_bytes)}s", len(token_bytes), token_bytes
            )

            LOGGER.debug("Successfully obtained Azure access token")
            return token_struct

        except Exception as e:
            LOGGER.error("Failed to obtain Azure access token: %s", str(e))
            raise ConnectionError(f"Failed to obtain Azure access token: {e}") from e

    @staticmethod
    def _get_driver_version(driver_name: str) -> int | None:
        """Extract the numeric version from an ODBC driver name.

        Args:
            driver_name: e.g. ``"ODBC Driver 17 for SQL Server"``

        Returns:
            The major version number, or ``None`` if parsing fails.

        """
        match = re.search(r"ODBC Driver (\d+)", driver_name, re.IGNORECASE)
        return int(match.group(1)) if match else None

    @log(log_args=False)
    @report_telemetry(params_list=["host", "port", "database", "user", "mode"])
    def connect(
        self,
        host: str,
        port: int,
        database: str,
        user: str | None = None,
        password: str | None = None,
        mode: SqlServerMode = "sql_auth",
        client_id: str | None = None,
        client_secret: str | None = None,
        tenant_id: str | None = None,
        trust_server_certificate: str | None = None,
        encrypt: str | None = None,
        odbc_driver: str | None = None,
        max_attempts: int = 3,
        delay_seconds: float = 1.0,
        delay_multiplier: float = 2.0,
    ):
        """Establish a connection to a SQL Server database using the provided connection details.

        Supports multiple authentication modes:
        1. SQL Server Authentication (sql_auth): Uses username and password
        2. Windows Authentication (windows_auth): Uses trusted connection (integrated security)
        3. Service Principal (service_principal): Uses Azure Entra ID with client credentials
        4. Managed Identity (managed_identity): Uses Azure Managed Identity

        Args:
            host (str): The hostname or IP address of the SQL Server.
            port (int): The port number on which the SQL Server is listening.
            database (str): The name of the database to connect to.
            user (str | None): The username for authentication (required for SQL Server Auth).
            password (str | None): The password for authentication (required for SQL Server Auth).
            mode (SqlServerMode): Authentication mode to use. Defaults to "sql_auth".
            client_id (str | None): Azure client ID for Service Principal or User-assigned MI.
            client_secret (str | None): Azure client secret for Service Principal.
            tenant_id (str | None): Azure tenant ID for Service Principal.
            trust_server_certificate (str | None): Whether to trust the server certificate.
                When ``None``, the default is chosen based on the ODBC driver version.
            encrypt (str | None): Whether to encrypt the connection.
                When ``None``, the default is chosen based on the ODBC driver version.
            odbc_driver (str | None): Explicit ODBC driver name. When ``None``,
                the best available driver is auto-detected.
            max_attempts (int): Maximum number of connection attempts. Defaults to 3.
            delay_seconds (float): Initial delay between retries in seconds. Defaults to 1.0.
            delay_multiplier (float): Multiplier for exponential backoff. Defaults to 2.0.

        Raises:
            ValueError: If any connection parameters are invalid
            ConnectionError: If connection cannot be established

        """
        mode_display_names = {
            "sql_auth": "SQL Server Authentication",
            "windows_auth": "Windows Authentication",
            "service_principal": "Azure Service Principal",
            "managed_identity": "Azure Managed Identity",
        }
        mode_display = mode_display_names.get(mode, mode)

        LOGGER.info(
            "Attempting to connect to SQL Server at %s:%d using %s",
            host,
            port,
            mode_display,
        )

        # Validate required parameters based on mode
        if not all([host, port, database]):
            error_msg = "Connection parameters (host, port, database) are required"
            LOGGER.error(error_msg)
            raise ValueError(error_msg)

        if mode == "sql_auth":
            if not user or not password:
                error_msg = (
                    "Username and password are required for SQL Server Authentication. "
                    "Use mode='windows_auth' for Windows Authentication, "
                    "mode='service_principal' for Azure Service Principal, or "
                    "mode='managed_identity' for Azure Managed Identity."
                )
                LOGGER.error(error_msg)
                raise ValueError(error_msg)

        elif mode == "service_principal":
            if not all([client_id, client_secret, tenant_id]):
                error_msg = (
                    "client_id, client_secret, and tenant_id are required "
                    "for Service Principal authentication."
                )
                LOGGER.error(error_msg)
                raise ValueError(error_msg)

        self.connect_with_retry(
            self._attempt_connection_and_verify,
            max_attempts,
            delay_seconds,
            delay_multiplier,
            self._internal_connect,
            host,
            port,
            database,
            user,
            password,
            mode,
            client_id,
            client_secret,
            tenant_id,
            trust_server_certificate,
            encrypt,
            odbc_driver,
        )

    def _internal_connect(
        self,
        host: str,
        port: int,
        database: str,
        user: str | None,
        password: str | None,
        mode: SqlServerMode = "sql_auth",
        client_id: str | None = None,
        client_secret: str | None = None,
        tenant_id: str | None = None,
        trust_server_certificate: str | None = None,
        encrypt: str | None = None,
        odbc_driver: str | None = None,
    ):
        """Establish the actual connection. Default implementation without retry logic.

        Args:
            host (str): The hostname or IP address of the SQL Server.
            port (int): The port number on which the SQL Server is listening.
            database (str): The name of the database to connect to.
            user (str | None): The username for authentication (required for SQL Server Auth).
            password (str | None): The password for authentication (required for SQL Server Auth).
            mode (SqlServerMode): Authentication mode to use.
            client_id (str | None): Azure client ID for Service Principal or User-assigned MI.
            client_secret (str | None): Azure client secret for Service Principal.
            tenant_id (str | None): Azure tenant ID for Service Principal.
            trust_server_certificate (str | None): Whether to trust the server certificate.
                When ``None``, defaults are chosen based on the ODBC driver version.
            encrypt (str | None): Whether to encrypt the connection.
                When ``None``, defaults are chosen based on the ODBC driver version.
            odbc_driver (str | None): Explicit ODBC driver name or ``None`` for auto-detection.

        Raises:
            ConnectionError: If connection cannot be established

        """
        try:
            # Select ODBC driver (explicit or auto-detected)
            driver = self._detect_odbc_driver(requested_driver=odbc_driver)

            # Resolve encryption settings based on driver version when the
            # caller did not supply explicit values.  Driver 18+ defaults to
            # mandatory encryption (encrypt="yes", trust_server_certificate="no")
            # while Driver 17 and below do not, so we pick safe defaults for
            # each.  Explicit user values are never overridden.
            driver_version = self._get_driver_version(driver)
            is_legacy_driver = driver_version is not None and driver_version <= 17

            if encrypt is None:
                encrypt = "no" if is_legacy_driver else "yes"
                LOGGER.info(
                    "No explicit encrypt value; defaulting to '%s' for %s.",
                    encrypt,
                    driver,
                )
            if trust_server_certificate is None:
                trust_server_certificate = "yes" if is_legacy_driver else "no"
                LOGGER.info(
                    "No explicit trust_server_certificate value; defaulting to '%s' for %s.",
                    trust_server_certificate,
                    driver,
                )

            LOGGER.info(
                "Using ODBC driver '%s' (version %s) with Encrypt=%s, "
                "TrustServerCertificate=%s.",
                driver,
                driver_version if driver_version is not None else "unknown",
                encrypt,
                trust_server_certificate,
            )

            # Determine if this is a named instance connection
            is_named_instance = (
                re.match(NAMED_INSTANCE_PATTERN_DETAILED, host) is not None
            )
            is_custom_port = port != DEFAULT_SQL_SERVER_PORT

            # Select appropriate connection string template based on mode
            if mode == "windows_auth":
                # Windows Authentication (Trusted Connection)
                if is_named_instance and not is_custom_port:
                    self.string_connection = (
                        SQLSERVER_CONNECTION_STRING_WIN_AUTH_NAMED.format(
                            driver=driver,
                            server=host,
                            port=port,
                            database=database,
                            trust_server_certificate=trust_server_certificate,
                            encrypt=encrypt,
                        )
                    )
                else:
                    self.string_connection = (
                        SQLSERVER_CONNECTION_STRING_WIN_AUTH.format(
                            driver=driver,
                            server=host,
                            port=port,
                            database=database,
                            trust_server_certificate=trust_server_certificate,
                            encrypt=encrypt,
                        )
                    )
                LOGGER.debug(
                    "Connecting to SQL Server database: %s using Windows Authentication",
                    database,
                )
                self.connection = self.pyodbc.connect(self.string_connection)

            elif mode in ("service_principal", "managed_identity"):
                # Azure Entra ID Authentication (token-based)
                if is_named_instance and not is_custom_port:
                    self.string_connection = (
                        SQLSERVER_CONNECTION_STRING_AZURE_TOKEN_NAMED.format(
                            driver=driver,
                            server=host,
                            port=port,
                            database=database,
                            trust_server_certificate=trust_server_certificate,
                            encrypt=encrypt,
                        )
                    )
                else:
                    self.string_connection = (
                        SQLSERVER_CONNECTION_STRING_AZURE_TOKEN.format(
                            driver=driver,
                            server=host,
                            port=port,
                            database=database,
                            trust_server_certificate=trust_server_certificate,
                            encrypt=encrypt,
                        )
                    )

                # Get Azure access token
                token_struct = self._get_azure_access_token(
                    mode=mode,
                    client_id=client_id,
                    client_secret=client_secret,
                    tenant_id=tenant_id,
                )

                # ODBC connection attribute for access token (value: 1256)
                sql_copt_ss_access_token = 1256

                LOGGER.debug(
                    "Connecting to SQL Server database: %s using Azure %s",
                    database,
                    (
                        "Service Principal"
                        if mode == "service_principal"
                        else "Managed Identity"
                    ),
                )
                self.connection = self.pyodbc.connect(
                    self.string_connection,
                    attrs_before={sql_copt_ss_access_token: token_struct},
                )

            else:
                # SQL Server Authentication (username/password)
                safe_user = _escape_odbc_value(user) if user else user
                safe_password = _escape_odbc_value(password) if password else password

                if is_named_instance and not is_custom_port:
                    self.string_connection = SQLSERVER_CONNECTION_STRING_NAMED.format(
                        driver=driver,
                        server=host,
                        port=port,
                        database=database,
                        user=safe_user,
                        password=safe_password,
                        trust_server_certificate=trust_server_certificate,
                        encrypt=encrypt,
                    )
                else:
                    self.string_connection = SQLSERVER_CONNECTION_STRING.format(
                        driver=driver,
                        server=host,
                        port=port,
                        database=database,
                        user=safe_user,
                        password=safe_password,
                        trust_server_certificate=trust_server_certificate,
                        encrypt=encrypt,
                    )
                LOGGER.debug(
                    "Connecting to SQL Server database: %s using SQL Server Authentication",
                    database,
                )
                self.connection = self.pyodbc.connect(self.string_connection)

        except Exception as e:
            LOGGER.error("Failed to connect to SQL Server: %s", str(e))
            self.connection = None
            raise ConnectionError(f"Failed to connect to SQL Server: {e}") from e

    @log
    def _verify_connection(self):
        """Verify the connection by executing a simple test query and detect server version.

        Raises:
            ConnectionError: If connection verification fails

        """
        try:
            LOGGER.debug("Verifying SQL Server connection")
            if self.connection is None:
                raise ConnectionError("Connection is None")
            cursor_method = getattr(self.connection, "cursor", None)
            if cursor_method is None:
                raise ConnectionError("Connection does not have cursor method")
            with cursor_method() as cursor:
                cursor.execute("SELECT 1")
                cursor.fetchone()
            LOGGER.debug("SQL Server connection verified successfully")

            # Detect SQL Server version after successful verification
            self._detect_sql_server_version()

        except Exception as e:
            LOGGER.error("Failed to verify SQL Server connection: %s", str(e))
            self.connection = None
            raise ConnectionError(f"Failed to verify SQL Server connection: {e}") from e

    @log
    def execute_statement(self, statement: str) -> None:
        if self.connection is None:
            raise Exception(CONNECTION_NOT_ESTABLISHED)

        try:
            LOGGER.debug("Executing SQL Server statement: %s", statement)
            with self.connection.cursor() as cursor:
                cursor.execute(statement)
                self.connection.commit()
            LOGGER.debug("Statement executed successfully")
        except self.pyodbc.Error as e:
            raise Exception(
                FAILED_TO_EXECUTE_STATEMENT.format(statement=statement)
            ) from e

    @log
    def execute_query_no_return(self, query: str) -> None:
        if self.connection is None:
            raise Exception(CONNECTION_NOT_ESTABLISHED)

        try:
            LOGGER.debug("Executing SQL Server query: %s", query)
            with self.connection.cursor() as cursor:
                cursor.execute(query)
            LOGGER.debug("Query executed successfully, returned 0 rows")
        except self.pyodbc.Error as e:
            error_message = str(e)

            is_concatenation_error = (
                EXCEED_MAX_STRING_LENGHT_SQL_SERVER_ERROR_CODE in error_message
            )
            if is_concatenation_error:
                error_message = COLUMN_VALUES_CONCATENATED_ERROR_SQL_SERVER
                LOGGER.error(error_message)
                raise Exception(error_message) from e

            LOGGER.error(FAILED_TO_EXECUTE_QUERY)
            raise Exception(FAILED_TO_EXECUTE_QUERY) from e

    @log
    def execute_query(self, query: str):
        """Execute a given SQL query and return the column names and fetched results.

        Args:
            query (str): The SQL query to be executed.

        Returns:
            tuple: A tuple containing a list of column names and a list of fetched rows.

        Raises:
            Exception: If the database connection is not established.

        """
        if self.connection is None:
            error_msg = (
                "Database connection is not established. Please call connect() first."
            )
            LOGGER.error(error_msg)
            raise Exception(error_msg)

        try:
            LOGGER.debug(
                "Executing SQL Server query: %s",
                query[:100] + "..." if len(query) > 100 else query,
            )
            with self.connection.cursor() as cursor:
                cursor.execute(query)
                column_names = [desc[0] for desc in cursor.description]
                results = cursor.fetchall()
                LOGGER.debug(
                    "Query executed successfully, returned %d rows", len(results)
                )
                return column_names, results
        except self.pyodbc.Error as e:
            if e.args[0] == TABLE_NOT_FOUND_ERROR_CODE_SQL_SERVER:
                LOGGER.error("SQL Server table not found: %s", str(e))
            LOGGER.error("Failed to execute SQL Server query: %s", str(e))
            raise Exception(FAILED_TO_EXECUTE_QUERY) from e

    @log
    def close(self):
        """Close the connection to the SQL Server database if it is open."""
        if self.connection:
            try:
                LOGGER.info("Closing SQL Server connection")
                self.connection.close()
                LOGGER.info("SQL Server connection closed successfully")
            except Exception as e:
                LOGGER.warning("Error while closing SQL Server connection: %s", str(e))
        else:
            LOGGER.debug("No active SQL Server connection to close")
