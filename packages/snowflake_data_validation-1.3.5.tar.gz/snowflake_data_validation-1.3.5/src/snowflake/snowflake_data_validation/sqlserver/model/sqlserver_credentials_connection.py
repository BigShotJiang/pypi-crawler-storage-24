# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""SQL Server credentials connection configuration model."""

from typing import Literal

from pydantic import BaseModel, Field, model_validator
from typing_extensions import Self

from snowflake.snowflake_data_validation.utils.constants import (
    DATABASE_DESC,
    HOST_DESC,
    PASSWORD_DESC,
    PORT_DESC,
    USERNAME_DESC,
)


# SQL Server connection mode description
SQLSERVER_MODE_DESC = (
    "Authentication mode. Options: "
    "'sql_auth' (username/password), "
    "'windows_auth' (Windows integrated security), "
    "'service_principal' (Azure Entra ID with client credentials), "
    "'managed_identity' (Azure Managed Identity). "
    "'credentials' is supported for backward compatibility (same as 'sql_auth')."
)

# SSL/TLS connection parameter descriptions
TRUST_SERVER_CERTIFICATE_DESC = (
    "Whether to trust the server certificate (yes/no). Defaults to 'no'."
)
ENCRYPT_DESC = "Whether to encrypt the connection (yes/no/optional). Defaults to 'yes'."

# ODBC driver field description
ODBC_DRIVER_DESC = (
    "ODBC driver name to use for the connection. If not specified, the best "
    "available driver is auto-detected (preferring Driver 18 over Driver 17). "
    "Example: 'ODBC Driver 17 for SQL Server'."
)

# Azure Entra ID field descriptions
CLIENT_ID_DESC = (
    "Azure Application (client) ID for Service Principal authentication, "
    "or Client ID for User-assigned Managed Identity."
)
CLIENT_SECRET_DESC = "Azure client secret for Service Principal authentication."
TENANT_ID_DESC = "Azure tenant (directory) ID for Service Principal authentication."

# Valid authentication modes
SqlServerMode = Literal[
    "sql_auth", "windows_auth", "service_principal", "managed_identity", "credentials"
]


class SqlServerCredentialsConnection(BaseModel):
    """SQL Server credentials connection configuration model.

    Supports multiple authentication modes via the 'mode' field:
    1. sql_auth (or 'credentials'): Uses username and password
    2. windows_auth: Uses trusted connection (integrated security)
    3. service_principal: Uses Azure Entra ID with client credentials
    4. managed_identity: Uses Azure Managed Identity

    Examples:
        # SQL Server Authentication
        mode: sql_auth
        username: myuser
        password: mypassword

        # Windows Authentication
        mode: windows_auth

        # Azure Service Principal
        mode: service_principal
        client_id: xxx
        client_secret: xxx
        tenant_id: xxx

        # Azure Managed Identity (system-assigned)
        mode: managed_identity

        # Azure Managed Identity (user-assigned)
        mode: managed_identity
        client_id: xxx

    Args:
        BaseModel: pydantic BaseModel

    """

    mode: SqlServerMode = Field(
        default="sql_auth",
        description=SQLSERVER_MODE_DESC,
    )
    host: str = Field(..., description=HOST_DESC)
    port: int = Field(default=1433, description=PORT_DESC)
    username: str | None = Field(default=None, description=USERNAME_DESC)
    password: str | None = Field(default=None, description=PASSWORD_DESC)
    database: str = Field(..., description=DATABASE_DESC)

    # Azure Entra ID fields
    client_id: str | None = Field(
        default=None,
        description=CLIENT_ID_DESC,
    )
    client_secret: str | None = Field(
        default=None,
        description=CLIENT_SECRET_DESC,
    )
    tenant_id: str | None = Field(
        default=None,
        description=TENANT_ID_DESC,
    )

    # SSL/TLS settings — default to None so the connector can apply
    # driver-version-aware defaults when the user doesn't specify.
    trust_server_certificate: str | None = Field(
        default=None,
        description=TRUST_SERVER_CERTIFICATE_DESC,
    )
    encrypt: str | None = Field(
        default=None,
        description=ENCRYPT_DESC,
    )

    # ODBC driver override
    odbc_driver: str | None = Field(
        default=None,
        description=ODBC_DRIVER_DESC,
    )

    def get_effective_mode(self) -> str:
        """Get the effective authentication mode.

        'credentials' is treated as 'sql_auth' for backward compatibility.

        Returns:
            str: The resolved authentication mode.

        """
        if self.mode == "credentials":
            return "sql_auth"
        return self.mode

    @model_validator(mode="after")
    def validate_authentication(self) -> Self:
        """Validate authentication configuration based on mode.

        Different modes require different fields:
        - sql_auth/credentials: username and password required
        - windows_auth: no additional fields required
        - service_principal: client_id, client_secret, and tenant_id required
        - managed_identity: client_id optional (for user-assigned identity)
        """
        effective_mode = self.get_effective_mode()

        if effective_mode == "sql_auth":
            if not self.username or not self.username.strip():
                raise ValueError(
                    "Username is required for SQL Server Authentication (mode: sql_auth). "
                    "Use 'mode: windows_auth' for Windows Authentication, "
                    "'mode: service_principal' for Azure Service Principal, or "
                    "'mode: managed_identity' for Azure Managed Identity."
                )
            if not self.password:
                raise ValueError(
                    "Password is required for SQL Server Authentication (mode: sql_auth). "
                    "Use 'mode: windows_auth' for Windows Authentication, "
                    "'mode: service_principal' for Azure Service Principal, or "
                    "'mode: managed_identity' for Azure Managed Identity."
                )

        elif effective_mode == "service_principal":
            if not self.client_id:
                raise ValueError(
                    "client_id is required for Service Principal authentication."
                )
            if not self.client_secret:
                raise ValueError(
                    "client_secret is required for Service Principal authentication."
                )
            if not self.tenant_id:
                raise ValueError(
                    "tenant_id is required for Service Principal authentication."
                )

        # windows_auth and managed_identity don't require additional validation
        # managed_identity client_id is optional (only needed for user-assigned)

        return self

    def get_connection_identifier(self) -> str:
        """Return the connection identifier (host for SQL Server)."""
        return self.host

    def configuration_file_connection_string(self) -> str:
        """Return a formatted string representation of the connection configuration."""
        effective_mode = self.get_effective_mode()
        tsc_line = (
            f"\n  trust_server_certificate: {self.trust_server_certificate}"
            if self.trust_server_certificate is not None
            else ""
        )
        encrypt_line = (
            f"\n  encrypt: {self.encrypt}" if self.encrypt is not None else ""
        )
        odbc_driver_line = (
            f"\n  odbc_driver: {self.odbc_driver}" if self.odbc_driver else ""
        )

        if effective_mode == "windows_auth":
            return f"""  mode: windows_auth
  host: {self.host}
  port: {self.port}
  database: {self.database}{tsc_line}{encrypt_line}{odbc_driver_line}"""

        elif effective_mode == "service_principal":
            return f"""  mode: service_principal
  host: {self.host}
  port: {self.port}
  database: {self.database}
  client_id: {self.client_id}
  client_secret: <your-secret>
  tenant_id: {self.tenant_id}{tsc_line}{encrypt_line}{odbc_driver_line}"""

        elif effective_mode == "managed_identity":
            client_id_line = (
                f"\n  client_id: {self.client_id}" if self.client_id else ""
            )
            return f"""  mode: managed_identity
  host: {self.host}
  port: {self.port}
  database: {self.database}{client_id_line}{tsc_line}{encrypt_line}{odbc_driver_line}"""

        else:  # sql_auth
            return f"""  mode: sql_auth
  host: {self.host}
  port: {self.port}
  username: {self.username}
  password: <your-password>
  database: {self.database}{tsc_line}{encrypt_line}{odbc_driver_line}"""
