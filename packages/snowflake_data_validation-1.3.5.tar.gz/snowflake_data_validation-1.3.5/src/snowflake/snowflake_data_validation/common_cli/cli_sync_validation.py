# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared CLI sync validation functions for data validation."""

import logging

import typer

from snowflake.snowflake_data_validation.utils import configuration_file_synchronizer


LOGGER = logging.getLogger(__name__)


def sync_validation_results(
    configuration_file_path: str,
    execution_summary_report_file_path: str,
) -> None:
    """Sync the configuration file with the execution summary report.

    Remove tables and views that passed all validation levels.

    Args:
        configuration_file_path: Path to the configuration file.
        execution_summary_report_file_path: Path to the execution summary report file.

    """
    try:
        configuration_file_synchronizer.sync_configuration_file(
            configuration_file_path=configuration_file_path,
            execution_summary_report_file_path=execution_summary_report_file_path,
        )
        typer.secho(
            "Configuration file updated successfully based on validation results.",
            fg=typer.colors.GREEN,
        )

        LOGGER.info(
            "Configuration file updated successfully based on validation results."
        )

    except Exception as e:
        typer.secho(f"Error syncing configuration file: {e}", fg=typer.colors.RED)
        LOGGER.error("Error syncing configuration file: %s", e)
