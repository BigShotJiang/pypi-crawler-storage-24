# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Validation database manager for managing database operations for validation reports."""

import logging

import pandas as pd

from snowflake.snowflake_data_validation.utils.thread_safe_singleton import (
    ThreadSafeSingleton,
)
from snowflake.snowflake_data_validation.validation.results_summary_report import (
    ResultsSummaryReport,
)
from snowflake.snowflake_data_validation.validation.validation_database import (
    DatabaseType,
    SQLiteValidationConnection,
    ValidationDatabaseConnectionBase,
)


LOGGER = logging.getLogger(__name__)


class ValidationDatabaseManager(metaclass=ThreadSafeSingleton):
    """Thread-safe singleton class for managing database operations for validation reports.

    This class provides a centralized interface for writing validation results to a database.
    It supports multiple database backends through the ValidationDatabaseConnectionBase interface.
    The default backend is SQLite, but it can be configured to use other databases.
    """

    def __init__(self):
        """Initialize the database manager.

        Note: This method may be called multiple times due to the metaclass implementation,
        but initialization is protected to ensure it only happens once.
        The connection is created lazily when initialize_database() is called with context.
        """
        if not hasattr(self, "_initialized"):
            self._connection: ValidationDatabaseConnectionBase | None = None
            self._database_type: DatabaseType = DatabaseType.SQLITE
            self._initialized = True
            LOGGER.debug(
                "ValidationDatabaseManager singleton initialized (connection will be created on initialize_database)"
            )

    def set_database_type(self, database_type: DatabaseType) -> None:
        """Set the database type to use for storing validation reports.

        Args:
            database_type: The type of database to use (SQLITE or SNOWFLAKE).

        """
        self._database_type = database_type
        self._connection = None  # Reset connection, will be created with new type
        LOGGER.info("Database type set to: %s", database_type.value)

    def set_connection(self, connection: ValidationDatabaseConnectionBase) -> None:
        """Set a custom database connection.

        This allows injecting a custom connection implementation for testing
        or for using a pre-configured connection.

        Args:
            connection: The database connection to use.

        """
        self._connection = connection
        LOGGER.info("Custom database connection set")

    def _create_connection(self, context) -> ValidationDatabaseConnectionBase:
        """Create a new database connection based on the configured type.

        Args:
            context: The execution context containing configuration and runtime info.

        Returns:
            ValidationDatabaseConnectionBase: A new connection instance.

        """
        if self._database_type == DatabaseType.SQLITE:
            return SQLiteValidationConnection(context)
        else:
            raise ValueError(f"Unsupported database type: {self._database_type}")

    def initialize_database(self, context) -> str:
        """Initialize the database with the required tables.

        Creates the connection with context if not already set, then initializes the database.

        Args:
            context: The execution context containing configuration and runtime info.

        Returns:
            str: The connection identifier (path for SQLite, table path for Snowflake).

        """
        if self._connection is None:
            self._connection = self._create_connection(context)

        return self._connection.initialize()

    def upload_validation_report(self, dataframe: pd.DataFrame) -> int:
        """Upload validation report data to the database.

        Args:
            dataframe: DataFrame containing validation report data.

        Returns:
            int: Number of rows inserted.

        Raises:
            RuntimeError: If the database has not been initialized.

        """
        if self._connection is None:
            raise RuntimeError(
                "Database not initialized. Call initialize_database() first."
            )
        return self._connection.upload_validation_report(dataframe)

    def upload_row_validation_report(self, dataframe: pd.DataFrame) -> int:
        """Upload row validation report data to the database.

        Args:
            dataframe: DataFrame containing row validation report data.

        Returns:
            int: Number of rows inserted.

        Raises:
            RuntimeError: If the database has not been initialized.

        """
        if self._connection is None:
            raise RuntimeError(
                "Database not initialized. Call initialize_database() first."
            )
        return self._connection.upload_row_validation_report(dataframe)

    def upload_row_validation_execution_status(self, dataframe: pd.DataFrame) -> int:
        """Upload row validation execution status data to the database.

        Args:
            dataframe: DataFrame containing row validation execution status data.

        Returns:
            int: Number of rows inserted.

        Raises:
            RuntimeError: If the database has not been initialized.

        """
        if self._connection is None:
            raise RuntimeError(
                "Database not initialized. Call initialize_database() first."
            )
        return self._connection.upload_row_validation_execution_status(dataframe)

    def get_database_path(self) -> str | None:
        """Get the current database connection identifier.

        Returns:
            str | None: The connection identifier, or None if database not yet initialized.

        """
        if self._connection is None:
            return None
        return self._connection.get_connection_identifier()

    def get_database_type(self) -> DatabaseType:
        """Get the current database type.

        Returns:
            DatabaseType: The configured database type.

        """
        return self._database_type

    def is_initialized(self) -> bool:
        """Check if the database connection has been initialized.

        Returns:
            bool: True if the database connection is initialized, False otherwise.

        """
        return self._connection is not None

    def __enter__(self) -> "ValidationDatabaseManager":
        """Enter the context manager.

        Returns:
            ValidationDatabaseManager: Self for use in with statements.

        """
        LOGGER.debug("Entering ValidationDatabaseManager context")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        """Exit the context manager and cleanup resources.

        Automatically calls cleanup() when exiting the context,
        ensuring the temporary database file is removed.

        Args:
            exc_type: Exception type if an exception was raised, None otherwise.
            exc_val: Exception value if an exception was raised, None otherwise.
            exc_tb: Exception traceback if an exception was raised, None otherwise.

        Returns:
            bool: False to propagate any exceptions, not suppressing them.

        """
        if exc_type is not None:
            LOGGER.warning(
                "Exiting ValidationDatabaseManager context with exception: %s", exc_val
            )
        else:
            LOGGER.debug("Exiting ValidationDatabaseManager context normally")

        self.cleanup()
        return False  # Do not suppress exceptions

    def cleanup(self) -> None:
        """Clean up the database file after reports have been generated.

        This method removes the temporary database file from the filesystem.
        Should be called after all CSV reports have been generated.
        """
        if self._connection is not None:
            self._connection.cleanup()
            self._connection = None
        LOGGER.info("ValidationDatabaseManager cleanup completed")

    def clear(self) -> None:
        """Clear the database manager state.

        This closes the current connection and resets the manager,
        allowing for a fresh initialization.
        """
        if self._connection is not None:
            self._connection.close()
            self._connection = None
        self._database_type = DatabaseType.SQLITE
        LOGGER.info("ValidationDatabaseManager state cleared")

    def get_execution_summary_report_dataframe(self) -> pd.DataFrame:
        """Generate execution summary report DataFrame.

        Returns:
            pd.DataFrame: DataFrame containing the execution summary report.

        """
        execution_summary_query = self._connection.get_execution_summary_report_query()
        execution_summary_df = self._connection.execute_query(execution_summary_query)
        return execution_summary_df

    def get_results_summary_report_dataframe(
        self,
    ) -> ResultsSummaryReport:
        """Generate results summary report DataFrame.

        Returns:
            ResultsSummaryReport: A dataclass containing all validation summary DataFrames.

        """
        if not self.is_initialized():
            LOGGER.warning("Skipping results summary report - database not initialized")
            return

        summary_query = self._connection.get_validation_summary_query()
        summary_df = self._connection.execute_query(summary_query)

        schema_validation_summary_query = (
            self._connection.get_schema_validation_summary_query()
        )
        schema_validation_summary_df = self._connection.execute_query(
            schema_validation_summary_query
        )

        schema_results_summary_query = (
            self._connection.get_schema_validation_results_summary_query()
        )
        schema_results_summary_df = self._connection.execute_query(
            schema_results_summary_query
        )

        metrics_validation_summary_query = (
            self._connection.get_metrics_validation_summary_query()
        )
        metrics_validation_summary_df = self._connection.execute_query(
            metrics_validation_summary_query
        )

        metrics_results_summary_query = (
            self._connection.get_metrics_validation_results_summary_query()
        )
        metrics_results_summary_df = self._connection.execute_query(
            metrics_results_summary_query
        )

        row_validation_summary_query = (
            self._connection.get_row_validation_summary_query()
        )
        row_validation_summary_df = self._connection.execute_query(
            row_validation_summary_query
        )

        row_results_summary_query = (
            self._connection.get_row_validation_results_summary_query()
        )
        row_results_summary_df = self._connection.execute_query(
            row_results_summary_query
        )

        return ResultsSummaryReport(
            summary=summary_df,
            schema_validation_summary=schema_validation_summary_df,
            schema_results_summary=schema_results_summary_df,
            metrics_validation_summary=metrics_validation_summary_df,
            metrics_results_summary=metrics_results_summary_df,
            row_validation_summary=row_validation_summary_df,
            row_results_summary=row_results_summary_df,
        )
