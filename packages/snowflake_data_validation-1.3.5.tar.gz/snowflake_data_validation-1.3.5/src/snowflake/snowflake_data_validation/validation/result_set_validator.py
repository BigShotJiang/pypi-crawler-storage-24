from pathlib import Path

import pandas as pd
import polars as pl

from snowflake.snowflake_data_validation.public.model.query_generator_factory import (
    QueryGeneratorFactory,
)
from snowflake.snowflake_data_validation.public.model.result_set import ResultSet
from snowflake.snowflake_data_validation.utils.constants import (
    COLUMN_DATATYPES_MAPPING_NAME_FORMAT,
    DEFAULT_OBJECT_ID,
    ObjectType,
    Origin,
    Platform,
)
from snowflake.snowflake_data_validation.utils.helper import Helper
from snowflake.snowflake_data_validation.utils.helpers.helper_misc import (
    get_current_timestamp,
)
from snowflake.snowflake_data_validation.utils.model.column_metadata import (
    ColumnMetadata,
)
from snowflake.snowflake_data_validation.utils.model.table_context import (
    create_table_context,
)
from snowflake.snowflake_data_validation.validation.cell_data_validator import (
    CellDataValidator,
)
from snowflake.snowflake_data_validation.validation.metrics_data_validator import (
    MetricsDataValidator,
)


# Path to the result_set templates directory (relative to this module)
_RESULT_SET_TEMPLATES_DIR = (
    Path(__file__).parent.parent / "result_set" / "extractor" / "templates"
)


class ResultSetValidator:
    """Validator class for comparing two ResultSet objects."""

    def __init__(
        self,
        custom_templates_directory: str | None = None,
    ):
        """Initialize the ResultSetValidator."""
        if custom_templates_directory is None:
            self.templates_directory_path = _RESULT_SET_TEMPLATES_DIR
        else:
            self.templates_directory_path = Path(custom_templates_directory)

        datatypes_file_path = (
            self.templates_directory_path
            / COLUMN_DATATYPES_MAPPING_NAME_FORMAT.format(
                source_platform=Platform.SNOWFLAKE.value,
                target_platform=Platform.RESULT_SET.value,
            )
        )
        self.datatypes_mappings: dict[str, pl.DataType] = self._load_datatypes(
            datatypes_file_path=datatypes_file_path
        )

    def metrics_level_validation(
        self,
        first_result_set: ResultSet,
        second_result_set: ResultSet,
        column_mappings: dict[str, str],
        tolerance: float,
    ) -> pd.DataFrame:
        first_df = self._result_set_to_polars_dataframe(result_set=first_result_set)
        second_df = self._result_set_to_polars_dataframe(result_set=second_result_set)

        first_metrics_df = self._calculate_column_metrics(
            result_set=first_result_set,
            polar_df=first_df,
            column_mappings={},  # No mapping needed for source metrics calculation
        )

        second_metrics_df = self._calculate_column_metrics(
            result_set=second_result_set,
            polar_df=second_df,
            column_mappings=column_mappings,
        )

        metrics_validator = MetricsDataValidator()
        validation_results = metrics_validator.validate_column_metadata(
            object_name="ResultSet Metrics Comparison",
            object_id=DEFAULT_OBJECT_ID,
            object_type=ObjectType.RESULT_SET,
            source_df=first_metrics_df,
            target_df=second_metrics_df,
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

        return validation_results

    def cell_level_validation(
        self,
        first_result_set: ResultSet,
        second_result_set: ResultSet,
    ) -> pd.DataFrame:
        """
        Validate the cell values between two result sets.

        Args:
            first_result_set: The first result set to compare.
            second_result_set: The second result set to compare.

        Returns:
            A DataFrame containing the validation results for each cell, including
            whether the values match and any discrepancies found.

        """
        first_df = self._result_set_to_polars_dataframe(result_set=first_result_set)
        second_df = self._result_set_to_polars_dataframe(result_set=second_result_set)

        cell_validator = CellDataValidator()
        validation_results = cell_validator.validate_cell_comparison(
            object_name="ResultSet Cell Comparison",
            source_df=first_df,
            target_df=second_df,
        )

        return validation_results

    def _calculate_column_metrics(
        self,
        result_set: ResultSet,
        polar_df: pl.DataFrame,
        column_mappings: dict[str, str],
    ) -> pd.DataFrame:

        result_set_column_metadata = []
        for column in result_set.column_types.keys():
            column_name = column_mappings.get(column, column)
            metadata = ColumnMetadata(
                name=column_name,
                data_type=str(polar_df.schema[column]).upper(),
                nullable=False,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            )
            result_set_column_metadata.append(metadata)

        templates_path = str(self.templates_directory_path)
        table_context = create_table_context(
            columns=result_set_column_metadata,
            database_name="result_set_database",
            fully_qualified_name="ResultSet",
            id=1,
            internal_fully_qualified_name="ResultSet",
            internal_table_name="ResultSet",
            object_type=ObjectType.RESULT_SET,
            origin=Origin.SOURCE,
            platform=Platform.RESULT_SET,
            queries_templates_directory_path=templates_path,
            row_count=len(polar_df),
            run_id=1,
            run_start_time=get_current_timestamp(include_microseconds=True),
            schema_name="result_set_schema",
            table_name="result_set_table",
            templates_directory_path=templates_path,
        )

        query_generator = QueryGeneratorFactory.create(table_context.platform)
        query_string = query_generator.generate_metrics_query(
            table_context=table_context,
        )

        metrics_df = polar_df.sql(query=query_string).to_pandas()
        return metrics_df

    def _load_datatypes(self, datatypes_file_path: Path) -> dict[str, pl.DataType]:
        temp_datatypes_mappings: dict[str, str] = (
            Helper.load_datatypes_mapping_templates_from_yaml(
                yaml_path=datatypes_file_path
            )
        )
        datatypes_mappings: dict[str, pl.DataType] = {
            key: getattr(pl, value) for key, value in temp_datatypes_mappings.items()
        }
        return datatypes_mappings

    def _result_set_to_polars_dataframe(self, result_set: ResultSet) -> pl.DataFrame:
        """
        Convert a ResultSet object to a Polars DataFrame.

        Args:
            result_set: The ResultSet object to convert.

        Returns:
            A Polars DataFrame representing the data in the ResultSet.

        """
        df = pl.DataFrame(data=result_set.rows)

        target_schema = self._translate_snowflake_schema_to_polars(
            column_types=result_set.column_types
        )

        cast_expressions = []
        for col_name, target_type in target_schema.items():
            if col_name not in df.columns:
                continue

            current_type = df[col_name].dtype
            cast_expr = self._build_cast_expression(
                col_name=col_name,
                current_type=current_type,
                target_type=target_type,
            )
            cast_expressions.append(cast_expr)

        if cast_expressions:
            df = df.with_columns(cast_expressions)

        return df

    def _build_cast_expression(
        self,
        col_name: str,
        current_type: pl.DataType,
        target_type: pl.DataType,
    ) -> pl.Expr:
        """
        Build a Polars expression to cast a column to a target type.

        Handles special cases for temporal types (Datetime, Date, Time) and Boolean
        when the source is a string, using appropriate parsing methods instead of
        direct casting.

        Args:
            col_name: The name of the column to cast.
            current_type: The current Polars data type of the column.
            target_type: The target Polars data type to cast to.

        Returns:
            A Polars expression that casts the column to the target type.

        """
        col_expr = pl.col(col_name)

        if target_type == pl.Datetime:
            if current_type == pl.Utf8:
                col_expr = col_expr.str.to_datetime(strict=False)
            else:
                col_expr = col_expr.cast(pl.Datetime, strict=False)
        elif target_type == pl.Date:
            if current_type == pl.Utf8:
                col_expr = col_expr.str.to_date(strict=False)
            else:
                col_expr = col_expr.cast(pl.Date, strict=False)
        elif target_type == pl.Time:
            if current_type == pl.Utf8:
                col_expr = col_expr.str.to_time(strict=False)
            else:
                col_expr = col_expr.cast(pl.Time, strict=False)
        elif target_type == pl.Boolean:
            if current_type == pl.Utf8:
                col_expr = col_expr.str.to_lowercase().is_in(["true", "1", "yes"])
            else:
                col_expr = col_expr.cast(pl.Boolean, strict=False)
        else:
            col_expr = col_expr.cast(target_type, strict=False)

        return col_expr.alias(col_name)

    def _translate_snowflake_schema_to_polars(
        self, column_types: dict[str, str]
    ) -> dict[str, pl.DataType]:
        """
        Translate a dictionary of column types from string representations to Polars data types.

        Args:
            column_types: A dictionary mapping column names to their respective data types as strings.

        Returns:
            A dictionary mapping column names to their respective Polars data types.

        """
        translated_schema = {}
        for column_name, column_type in column_types.items():
            normalized_type = column_type.upper()
            if normalized_type in self.datatypes_mappings:
                translated_schema[column_name] = self.datatypes_mappings[
                    normalized_type
                ]
            else:
                # Default to string type if the data type is unrecognized
                translated_schema[column_name] = pl.Utf8

        return translated_schema
