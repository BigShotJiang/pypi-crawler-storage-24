# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Validation database module for storing validation reports.

This module provides database connection implementations for storing
validation reports to different database backends.
"""

from snowflake.snowflake_data_validation.utils.constants import (
    ROW_VALIDATION_EXECUTION_STATUS_TABLE,
    ROW_VALIDATION_REPORT_TABLE,
    VALIDATION_DATABASE_NAME,
    VALIDATION_REPORT_TABLE,
    DatabaseType,
)
from snowflake.snowflake_data_validation.validation.validation_database.sqlite_validation_connection import (
    SQLiteValidationConnection,
)
from snowflake.snowflake_data_validation.validation.validation_database.validation_database_connection_base import (
    ValidationDatabaseConnectionBase,
)


__all__ = [
    "DatabaseType",
    "ValidationDatabaseConnectionBase",
    "SQLiteValidationConnection",
    "VALIDATION_DATABASE_NAME",
    "VALIDATION_REPORT_TABLE",
    "ROW_VALIDATION_REPORT_TABLE",
    "ROW_VALIDATION_EXECUTION_STATUS_TABLE",
]
