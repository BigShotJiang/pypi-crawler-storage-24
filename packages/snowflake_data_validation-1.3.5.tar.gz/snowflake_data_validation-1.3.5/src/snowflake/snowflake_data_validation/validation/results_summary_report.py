# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Data container for results summary report."""

from dataclasses import dataclass

import pandas as pd


@dataclass
class ResultsSummaryReport:
    """Data container for results summary report DataFrames.

    Attributes:
        summary: Overall validation summary DataFrame.
        schema_validation_summary: Schema validation summary by object type.
        schema_results_summary: Detailed schema validation results per object.
        metrics_validation_summary: Metrics validation summary by object type.
        metrics_results_summary: Detailed metrics validation results per object.
        row_validation_summary: Row validation summary by object type.
        row_results_summary: Detailed row validation results per object.

    """

    summary: pd.DataFrame
    schema_validation_summary: pd.DataFrame
    schema_results_summary: pd.DataFrame
    metrics_validation_summary: pd.DataFrame
    metrics_results_summary: pd.DataFrame
    row_validation_summary: pd.DataFrame
    row_results_summary: pd.DataFrame
