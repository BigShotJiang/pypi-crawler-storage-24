# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging

import pandas as pd

from snowflake.snowflake_data_validation.executer.base_validation_executor import (
    BaseValidationExecutor,
)
from snowflake.snowflake_data_validation.public import (
    data_validation_api,
)
from snowflake.snowflake_data_validation.public.model import (
    DataValidationExceptionError,
    QueryExecutionResult,
)
from snowflake.snowflake_data_validation.utils.base_output_handler import (
    OutputMessageLevel,
)
from snowflake.snowflake_data_validation.utils.constants import (
    DEFAULT_TOLERANCE,
    METRICS_VALIDATION_KEY,
    SCHEMA_VALIDATION_KEY,
)
from snowflake.snowflake_data_validation.utils.logging_utils import log
from snowflake.snowflake_data_validation.utils.model.table_context import TableContext


LOGGER = logging.getLogger(__name__)


class AsyncValidationExecutor(BaseValidationExecutor):
    """Executor for asynchronous validation operations.

    This executor performs real-time validation by using extracted validation files with metadata from both
    source and target systems and comparing them immediately. Used for run-validation
    commands.
    """

    @log
    def execute_schema_validation(
        self,
        table_context: TableContext,
    ) -> bool:
        """Execute schema validation by comparing table metadata.

        Uses the public workflow API to validate schema data loaded from files.

        Args:
            table_context: Table context containing all necessary validation parameters

        Returns:
            bool: True if validation passes, False otherwise

        """
        LOGGER.info(
            "Starting async schema validation for table: %s",
            table_context.fully_qualified_name,
        )

        source_result, target_result = self._load_validation_files(
            validation_type=SCHEMA_VALIDATION_KEY,
            table_context=table_context,
        )

        if source_result.dataframe.empty or target_result.dataframe.empty:
            LOGGER.warning(
                "Schema validation failed - empty source or target data for table: %s",
                table_context.fully_qualified_name,
            )
            self.context.output_handler.handle_message(
                header="Schema validation failed.",
                message="Source or target validation file is missing or empty.",
                level=OutputMessageLevel.FAILURE,
            )
            return False

        try:
            LOGGER.debug(
                "Executing schema validation for table: %s",
                table_context.fully_qualified_name,
            )

            # Use public API for validation (results already in QueryExecutionResult format)
            validation_result = data_validation_api.validate_schema(
                source_query_result=source_result,
                target_query_result=target_result,
                table_context=table_context,
                column_mappings=table_context.column_mappings,
                datatypes_mappings=self.context.datatypes_mappings,
            )

            validation_status = "passed" if validation_result.is_valid else "failed"
            LOGGER.info(
                "Schema validation %s for table: %s",
                validation_status,
                table_context.fully_qualified_name,
            )
            self.context.output_handler.handle_message(
                header=f"Schema validation {validation_status}.",
                message="",
                level=(
                    OutputMessageLevel.SUCCESS
                    if validation_result.is_valid
                    else OutputMessageLevel.FAILURE
                ),
            )
            return validation_result.is_valid
        except Exception as e:
            LOGGER.error(
                "Schema validation failed for table %s: %s",
                table_context.fully_qualified_name,
                str(e),
            )
            self.context.output_handler.handle_message(
                header="Schema validation failed.",
                message=f"Error during schema validation: {str(e)}",
                level=OutputMessageLevel.FAILURE,
            )
            return False

    @log
    def execute_metrics_validation(
        self,
        table_context: TableContext,
    ) -> bool:
        """Execute metrics validation by comparing column metadata.

        Uses the public workflow API to validate metrics data loaded from files.

        Args:
            table_context: Table context containing all necessary validation parameters

        Returns:
            bool: True if validation passes, False otherwise

        """
        LOGGER.info(
            "Starting async metrics validation for table: %s",
            table_context.fully_qualified_name,
        )

        source_result, target_result = self._load_validation_files(
            validation_type=METRICS_VALIDATION_KEY,
            table_context=table_context,
        )

        if source_result.dataframe.empty or target_result.dataframe.empty:
            LOGGER.warning(
                "Metrics validation failed - empty source or target data for table: %s",
                table_context.fully_qualified_name,
            )
            self.context.output_handler.handle_message(
                header="Metrics validation failed.",
                message="Source or target validation file is missing or empty.",
                level=OutputMessageLevel.FAILURE,
            )
            return False

        try:
            LOGGER.debug(
                "Executing metrics validation for table: %s",
                table_context.fully_qualified_name,
            )

            tolerance = DEFAULT_TOLERANCE
            if (
                self.context.configuration.comparison_configuration
                and "tolerance" in self.context.configuration.comparison_configuration
            ):
                tolerance = float(
                    self.context.configuration.comparison_configuration["tolerance"]
                )
                LOGGER.debug("Using tolerance from configuration: %f", tolerance)
            else:
                LOGGER.debug("Using default tolerance: %f", tolerance)

            validation_result = data_validation_api.validate_metrics(
                source_query_result=source_result,
                target_query_result=target_result,
                table_context=table_context,
                column_mappings=table_context.column_mappings,
                tolerance=tolerance,
            )

            validation_status = "passed" if validation_result.is_valid else "failed"
            LOGGER.info(
                "Metrics validation %s for table: %s",
                validation_status,
                table_context.fully_qualified_name,
            )
            self.context.output_handler.handle_message(
                header=f"Metrics validation {validation_status}.",
                message="",
                level=(
                    OutputMessageLevel.SUCCESS
                    if validation_result.is_valid
                    else OutputMessageLevel.FAILURE
                ),
            )
            return validation_result.is_valid
        except Exception as e:
            LOGGER.error(
                "Metrics validation failed for table %s: %s",
                table_context.fully_qualified_name,
                str(e),
            )
            self.context.output_handler.handle_message(
                header="Metrics validation failed.",
                message=f"Error during metrics validation: {str(e)}",
                level=OutputMessageLevel.FAILURE,
            )
            return False

    @log
    def execute_row_validation(
        self,
        table_context: TableContext,
    ) -> bool:
        """Execute row validation (placeholder implementation).

        Args:
            table_context: Table context containing all necessary validation parameters

        Returns:
            bool: True (placeholder - row validation not yet implemented)

        """
        LOGGER.info(
            "Starting async row validation for table: %s",
            table_context.fully_qualified_name,
        )
        LOGGER.warning("Row validation not yet implemented - returning False")
        return False

    @log
    def _load_validation_files(
        self,
        validation_type: str,
        table_context: TableContext,
    ) -> tuple[QueryExecutionResult, QueryExecutionResult]:
        """Load validation files for the given table context using public API.

        Args:
            validation_type: Type of validation to load (e.g., schema, metrics)
            table_context: Table context containing all necessary parameters

        Returns:
            tuple[QueryExecutionResult, QueryExecutionResult]: Source and target results

        """
        LOGGER.debug(
            "Loading validation files for %s validation of table: %s",
            validation_type,
            table_context.fully_qualified_name,
        )

        source_file_path = data_validation_api.build_validation_file_path(
            base_directory=self.context.configuration.source_validation_files_path,
            validation_type=validation_type,
            table_context=table_context,
            custom_filename=table_context.source_validation_file_name,
        )

        target_file_path = data_validation_api.build_validation_file_path(
            base_directory=self.context.configuration.target_validation_files_path,
            validation_type=validation_type,
            table_context=table_context,
            custom_filename=table_context.target_validation_file_name,
        )

        LOGGER.debug("Loading source file: %s", source_file_path)
        LOGGER.debug("Loading target file: %s", target_file_path)

        try:
            source_result, target_result = data_validation_api.load_validation_results(
                source_file_path=source_file_path,
                target_file_path=target_file_path,
            )

            LOGGER.debug(
                "Successfully loaded source file with %d rows",
                len(source_result.dataframe),
            )
            LOGGER.debug(
                "Successfully loaded target file with %d rows",
                len(target_result.dataframe),
            )

            return source_result, target_result

        except DataValidationExceptionError as e:
            LOGGER.error("Error loading validation files: %s", str(e))
            self.context.output_handler.handle_message(
                header="Error loading validation files.",
                message=f"Failed to load validation files: {str(e.message)}",
                level=OutputMessageLevel.ERROR,
            )
            return (
                QueryExecutionResult(dataframe=pd.DataFrame()),
                QueryExecutionResult(dataframe=pd.DataFrame()),
            )

    def _get_schema_validation_message(self, table_configuration: TableContext) -> str:
        """Get async validation message for schema validation.

        Args:
            table_configuration: Table configuration containing all necessary validation parameters

        Returns:
            str: Message for schema validation in async mode

        """
        return (
            f"Validating schema for {table_configuration.fully_qualified_name} "
            f"with columns {table_configuration.column_selection_list}."
        )

    def _get_metrics_validation_message(self, table_configuration: TableContext) -> str:
        """Get async validation message for metrics validation.

        Args:
            table_configuration: Table configuration containing all necessary validation parameters

        Returns:
            str: Message for metrics validation in async mode

        """
        return (
            f"Validating metrics for {table_configuration.fully_qualified_name} "
            f"with columns {table_configuration.column_selection_list}."
        )

    def _get_row_validation_message(self, table_configuration: TableContext) -> str:
        """Get async validation message for row validation.

        Args:
            table_configuration: Table context containing all necessary validation parameters

        Returns:
            str: Message for row validation in async mode

        """
        return (
            f"Validating rows for {table_configuration.fully_qualified_name} "
            f"with columns {table_configuration.column_selection_list}."
        )
