# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Asynchronous Query Generation Executor with decoupled workflow steps.

This module provides the AsyncGenerationExecutor class that generates async
comparison queries and writes them to files instead of executing actual validation.

The generation workflow follows the decoupled pattern using the public workflow API:
1. Query Generation - Uses data_validation_api.generate_schema_query / generate_metrics_query
2. Query Output - Write generated queries to files via public API functions

Note: This executor only performs query generation (Step 1) and writes the queries
to files. The execution and validation steps happen separately in async validation mode.
"""

import logging

from snowflake.snowflake_data_validation.executer.base_validation_executor import (
    BaseValidationExecutor,
    validation_handler,
)
from snowflake.snowflake_data_validation.public import (
    data_validation_api,
)
from snowflake.snowflake_data_validation.utils.base_output_handler import (
    OutputMessageLevel,
)
from snowflake.snowflake_data_validation.utils.logging_utils import log
from snowflake.snowflake_data_validation.utils.model.table_context import TableContext


LOGGER = logging.getLogger(__name__)


class AsyncGenerationExecutor(BaseValidationExecutor):
    """Executor for asynchronous query generation operations.

    This executor generates async comparison queries and writes them to files
    instead of executing actual validation. Uses script writers to delegate
    the actual file generation and writing operations.

    The workflow is decoupled to clearly separate query generation from
    the file writing operation:
    1. Generate queries for source and target platforms
    2. Write queries to files using script writers
    """

    @validation_handler(
        "Schema validation async generation failed.",
        "Error generating schema validation queries: {error}",
    )
    @log
    def execute_schema_validation(
        self,
        source_table_context: TableContext,
        target_table_context: TableContext,
        column_mappings: dict[str, str],
    ) -> bool:
        """Generate schema validation queries and write to files.

        This method uses the decoupled workflow with public API:
        1. Generate schema query for source using data_validation_api
        2. Generate schema query for target using data_validation_api
        3. Write both queries to files via public API functions

        Args:
            source_table_context: Source table context.
            target_table_context: Target table context.
            column_mappings: Mapping of source to target columns.

        Returns:
            bool: True if queries are successfully generated and written.

        """
        LOGGER.info(
            "Generating schema validation queries for table: %s",
            source_table_context.fully_qualified_name,
        )

        try:
            # Step 1: Generate queries using public API
            source_query = data_validation_api.generate_schema_query(
                source_table_context
            )
            target_query = data_validation_api.generate_schema_query(
                target_table_context
            )

            LOGGER.debug(
                "Generated schema queries for source: %s and target: %s",
                source_table_context.fully_qualified_name,
                target_table_context.fully_qualified_name,
            )

            # Step 2: Write queries to files via public API
            # Use report_path from extractors (ScriptWriterBase instances)
            data_validation_api.write_schema_query_to_script(
                table_context=source_table_context,
                generated_query=source_query,
                output_directory=self.source_extractor.report_path,
                timestamp=self.context.run_start_time,
            )

            data_validation_api.write_schema_query_to_script(
                table_context=target_table_context,
                generated_query=target_query,
                output_directory=self.source_extractor.report_path,
                timestamp=self.context.run_start_time,
            )

            self.context.output_handler.handle_message(
                header="Schema validation queries generated.",
                message=f"Queries generated for table: {source_table_context.fully_qualified_name}",
                level=OutputMessageLevel.SUCCESS,
            )
            return True
        except Exception:
            return False

    @validation_handler(
        "Metrics validation async generation failed.",
        "Error generating metrics validation queries: {error}",
    )
    @log
    def execute_metrics_validation(
        self,
        source_table_context: TableContext,
        target_table_context: TableContext,
        column_mappings: dict[str, str],
    ) -> bool:
        """Generate metrics validation queries and write to files.

        This method uses the decoupled workflow with public API:
        1. Generate metrics query for source using data_validation_api
        2. Generate metrics query for target using data_validation_api
        3. Write both queries to files via public API functions

        Args:
            source_table_context: Source table context.
            target_table_context: Target table context.
            column_mappings: Mapping of source to target columns.

        Returns:
            bool: True if queries are successfully generated and written.

        """
        LOGGER.info(
            "Generating metrics validation queries for table: %s",
            source_table_context.fully_qualified_name,
        )

        try:
            source_query = data_validation_api.generate_metrics_query(
                source_table_context
            )
            target_query = data_validation_api.generate_metrics_query(
                target_table_context
            )

            LOGGER.debug(
                "Generated metrics queries for source: %s and target: %s",
                source_table_context.fully_qualified_name,
                target_table_context.fully_qualified_name,
            )

            data_validation_api.write_metrics_query_to_script(
                table_context=source_table_context,
                generated_query=source_query,
                output_directory=self.source_extractor.report_path,
                timestamp=self.context.run_start_time,
            )

            data_validation_api.write_metrics_query_to_script(
                table_context=target_table_context,
                generated_query=target_query,
                output_directory=self.target_extractor.report_path,
                timestamp=self.context.run_start_time,
            )

            self.context.output_handler.handle_message(
                header="Metrics validation queries generated.",
                message=f"Queries generated for table: {target_table_context.fully_qualified_name}",
                level=OutputMessageLevel.SUCCESS,
            )
            return True
        except Exception:
            return False

    @validation_handler(
        "Row validation async generation failed.",
        "Error in row validation async generation: {error}",
    )
    @log
    def execute_row_validation(
        self,
        source_table_context: TableContext,
        target_table_context: TableContext,
    ) -> bool:
        """Generate row validation queries (placeholder implementation).

        Note: Row validation async generation is not yet implemented.

        Args:
            source_table_context: Source table context for validation.
            target_table_context: Target table context for validation.

        Returns:
            bool: True (placeholder - always succeeds).

        """
        LOGGER.info(
            "Row validation async generation skipped for table: %s",
            source_table_context.fully_qualified_name,
        )

        self.context.output_handler.handle_message(
            header="Row validation async generation skipped.",
            message="Row validation async generation is not yet implemented.",
            level=OutputMessageLevel.INFO,
        )
        return True

    def _get_schema_validation_message(self, table_configuration: TableContext) -> str:
        """Get async generation message for schema validation."""
        return (
            f"Generating async schema validation queries for {table_configuration.fully_qualified_name} "
            f"with columns {table_configuration.column_selection_list}."
        )

    def _get_metrics_validation_message(self, table_configuration: TableContext) -> str:
        """Get async generation message for metrics validation."""
        return (
            f"Generating async metrics validation queries for {table_configuration.fully_qualified_name} "
            f"with columns {table_configuration.column_selection_list}."
        )

    def _get_row_validation_message(self, table_configuration: TableContext) -> str:
        """Get async generation message for row validation."""
        return (
            f"Generating async row validation queries for {table_configuration.fully_qualified_name} "
            f"with columns {table_configuration.column_selection_list}."
        )
