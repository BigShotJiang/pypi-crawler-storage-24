# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

"""Unit tests for SQLiteValidationConnection."""

import os
from unittest.mock import MagicMock

import pandas as pd
import pytest

from snowflake.snowflake_data_validation.validation.validation_database.sqlite_validation_connection import (
    SQLiteValidationConnection,
)


@pytest.fixture
def mock_context(tmp_path):
    """Create a mock context with temporary directory."""
    context = MagicMock()
    context.report_path = str(tmp_path)
    context.run_start_time = "2026-01-01_12-00-00"
    return context


@pytest.fixture
def connection(mock_context):
    """Create a SQLiteValidationConnection instance."""
    return SQLiteValidationConnection(mock_context)


def test_init_sets_context(mock_context):
    """Test that initialization stores the context."""
    conn = SQLiteValidationConnection(mock_context)
    assert conn._context == mock_context
    assert conn._db_path is None


def test_initialize_creates_database_file(connection, mock_context):
    """Test that initialize creates the database file."""
    db_path = connection.initialize()

    assert os.path.exists(db_path)
    assert "validation_report.db" in db_path
    assert mock_context.run_start_time in db_path


def test_initialize_creates_required_tables(connection):
    """Test that initialize creates the validation tables."""
    connection.initialize()

    tables_df = connection.execute_query(
        "SELECT name FROM sqlite_master WHERE type='table'"
    )
    table_names = tables_df["name"].tolist()

    assert "VALIDATION_REPORT" in table_names
    assert "ROW_VALIDATION_REPORT" in table_names


def test_get_connection_identifier_before_init(connection):
    """Test that get_connection_identifier returns None before initialization."""
    assert connection.get_connection_identifier() is None


def test_get_connection_identifier_after_init(connection):
    """Test that get_connection_identifier returns path after initialization."""
    db_path = connection.initialize()
    assert connection.get_connection_identifier() == db_path


def test_upload_validation_report_with_data(connection):
    """Test uploading validation report data."""
    connection.initialize()

    df = pd.DataFrame(
        {
            "VALIDATION_TYPE": ["COUNT"],
            "TABLE": ["TEST_TABLE"],
            "OBJECT_TYPE": ["TABLE"],
            "OBJECT_ID": [1],
            "COLUMN_VALIDATED": ["col1"],
            "EVALUATION_CRITERIA": ["EQUAL"],
            "SOURCE_VALUE": ["100"],
            "SNOWFLAKE_VALUE": ["100"],
            "STATUS": ["PASSED"],
            "COMMENTS": ["Test comment"],
        }
    )

    rows_inserted = connection.upload_validation_report(df)
    assert rows_inserted == 1

    result = connection.execute_query("SELECT * FROM VALIDATION_REPORT")
    assert len(result) == 1
    assert result.iloc[0]["OBJECT_NAME"] == "TEST_TABLE"


def test_upload_validation_report_empty_dataframe(connection):
    """Test uploading empty validation report returns zero."""
    connection.initialize()
    df = pd.DataFrame()

    rows_inserted = connection.upload_validation_report(df)
    assert rows_inserted == 0


def test_upload_row_validation_report_with_data(connection):
    """Test uploading row validation report data."""
    connection.initialize()

    df = pd.DataFrame(
        {
            "TABLE_NAME": ["TEST_TABLE"],
            "OBJECT_TYPE": ["TABLE"],
            "OBJECT_ID": [1],
            "RESULT": ["MATCH"],
        }
    )

    rows_inserted = connection.upload_row_validation_report(df)
    assert rows_inserted == 1

    result = connection.execute_query("SELECT * FROM ROW_VALIDATION_REPORT")
    assert len(result) == 1
    assert result.iloc[0]["OBJECT_NAME"] == "TEST_TABLE"


def test_upload_row_validation_report_empty_dataframe(connection):
    """Test uploading empty row validation report returns zero."""
    connection.initialize()
    df = pd.DataFrame()

    rows_inserted = connection.upload_row_validation_report(df)
    assert rows_inserted == 0


def test_execute_query_returns_dataframe(connection):
    """Test that execute_query returns results as DataFrame."""
    connection.initialize()

    result = connection.execute_query("SELECT 1 as value")
    assert isinstance(result, pd.DataFrame)
    assert result.iloc[0]["value"] == 1


def test_execute_query_without_init_raises_error(connection):
    """Test that execute_query raises error if not initialized."""
    with pytest.raises(RuntimeError, match="Database not initialized"):
        connection.execute_query("SELECT 1")


def test_get_connection_without_init_raises_error(connection):
    """Test that _get_connection raises error if not initialized."""
    with pytest.raises(RuntimeError, match="Database not initialized"):
        with connection._get_connection():
            pass


def test_close_resets_db_path(connection):
    """Test that close resets the database path."""
    connection.initialize()
    assert connection._db_path is not None

    connection.close()
    assert connection._db_path is None


def test_cleanup_removes_database_file(connection):
    """Test that cleanup removes the database file from filesystem."""
    db_path = connection.initialize()
    assert os.path.exists(db_path)

    connection.cleanup()

    assert not os.path.exists(db_path)
    assert connection._db_path is None


def test_cleanup_when_file_does_not_exist(connection):
    """Test that cleanup handles non-existent file gracefully."""
    db_path = connection.initialize()

    # Manually remove the file first
    os.remove(db_path)
    assert not os.path.exists(db_path)

    # cleanup should not raise an error
    connection.cleanup()
    assert connection._db_path is None


def test_cleanup_when_not_initialized(connection):
    """Test that cleanup handles uninitialized connection gracefully."""
    assert connection._db_path is None

    # Should not raise an error
    connection.cleanup()
    assert connection._db_path is None
