"""Unit tests for logging configuration functionality."""

import logging
import os
import tempfile

import pytest

from snowflake.snowflake_data_validation.configuration.model.logging_configuration import (
    LoggingConfiguration,
)
from snowflake.snowflake_data_validation.utils.logging_config import LoggingManager


# ---------------------------------------------------------------------------
# LoggingManager.setup_logging
# ---------------------------------------------------------------------------


class TestLoggingManagerSetupLogging:
    """Tests for LoggingManager.setup_logging."""

    def _make_manager(self) -> LoggingManager:
        """Create a fresh LoggingManager instance (avoids singleton state)."""
        return LoggingManager()

    def test_default_log_file_created_in_cwd(self):
        """Log file is created in the current directory when no logs_path."""
        manager = self._make_manager()
        log_file = manager.setup_logging(log_level="INFO")

        assert os.path.basename(log_file).startswith("data_validation_")
        assert log_file.endswith(".log")
        # No directory component – file lives in CWD
        assert os.path.dirname(log_file) == ""

    def test_custom_logs_path_creates_directory_and_file(self):
        """Log file is created inside the specified logs_path directory."""
        manager = self._make_manager()

        with tempfile.TemporaryDirectory() as tmpdir:
            log_file = manager.setup_logging(log_level="DEBUG", logs_path=tmpdir)

            assert os.path.dirname(log_file) == tmpdir
            assert os.path.exists(log_file)
            assert log_file.endswith(".log")

            # Release file handles so Windows can clean up the temp dir
            manager.setup_logging(log_level="INFO")

    def test_custom_logs_path_creates_nested_directory(self):
        """Nested logs_path directories are created automatically."""
        manager = self._make_manager()

        with tempfile.TemporaryDirectory() as tmpdir:
            nested = os.path.join(tmpdir, "a", "b", "c")
            log_file = manager.setup_logging(log_level="INFO", logs_path=nested)

            assert os.path.isdir(nested)
            assert os.path.dirname(log_file) == nested

            manager.setup_logging(log_level="INFO")

    def test_logs_path_sets_custom_flag(self):
        """_custom_logs_path flag is True after logs_path is provided."""
        manager = self._make_manager()
        assert manager._custom_logs_path is False

        with tempfile.TemporaryDirectory() as tmpdir:
            manager.setup_logging(log_level="INFO", logs_path=tmpdir)
            assert manager._custom_logs_path is True

            manager.setup_logging(log_level="INFO")

    def test_no_logs_path_does_not_set_custom_flag(self):
        """_custom_logs_path flag stays False when logs_path is omitted."""
        manager = self._make_manager()
        manager.setup_logging(log_level="INFO")
        assert manager._custom_logs_path is False

    def test_log_levels_are_applied(self):
        """Console and file log levels are forwarded correctly."""
        manager = self._make_manager()
        manager.setup_logging(
            log_level="WARNING", console_level="ERROR", file_level="DEBUG"
        )
        # If we got here without error, dictConfig accepted the levels
        assert manager.get_current_log_file().endswith(".log")


# ---------------------------------------------------------------------------
# LoggingManager.relocate_log_file
# ---------------------------------------------------------------------------


class TestLoggingManagerRelocateLogFile:
    """Tests for LoggingManager.relocate_log_file."""

    def _make_manager(self) -> LoggingManager:
        return LoggingManager()

    def test_relocate_moves_file_when_no_custom_logs_path(self):
        """Log file is moved to the output directory by default."""
        manager = self._make_manager()

        with tempfile.TemporaryDirectory() as tmpdir:
            # Set up logging in a source subdirectory
            src_dir = os.path.join(tmpdir, "src")
            os.makedirs(src_dir)
            log_file = manager.setup_logging(log_level="INFO", logs_path=src_dir)
            # Reset the flag to simulate the default (no --logs-path) behavior
            manager._custom_logs_path = False
            assert os.path.exists(log_file)

            # Relocate to a destination subdirectory
            dest_dir = os.path.join(tmpdir, "dest")
            result = manager.relocate_log_file(dest_dir)

            assert result is True
            assert os.path.isdir(dest_dir)
            assert os.path.dirname(manager.get_current_log_file()) == dest_dir
            # Original file should no longer exist
            assert not os.path.exists(log_file)

            # Release handles for Windows cleanup
            manager.setup_logging(log_level="INFO")

    def test_relocate_skipped_when_custom_logs_path_is_set(self):
        """Log file stays in place when a custom logs_path was specified."""
        manager = self._make_manager()

        with tempfile.TemporaryDirectory() as tmpdir:
            custom_dir = os.path.join(tmpdir, "custom")
            log_file = manager.setup_logging(log_level="INFO", logs_path=custom_dir)
            assert manager._custom_logs_path is True

            dest_dir = os.path.join(tmpdir, "output")
            result = manager.relocate_log_file(dest_dir)

            assert result is False
            # Log file is still in the custom directory
            assert manager.get_current_log_file() == log_file
            assert os.path.dirname(manager.get_current_log_file()) == custom_dir
            # Destination directory should NOT have been created
            assert not os.path.exists(dest_dir)

            manager.setup_logging(log_level="INFO")

    def test_relocate_returns_false_when_no_log_file(self):
        """relocate_log_file returns False when no log file exists."""
        manager = self._make_manager()
        assert manager.relocate_log_file("/some/path") is False

    def test_relocate_returns_false_when_empty_output_path(self):
        """relocate_log_file returns False for empty output path."""
        manager = self._make_manager()
        manager.setup_logging(log_level="INFO")
        assert manager.relocate_log_file("") is False


# ---------------------------------------------------------------------------
# LoggingConfiguration model
# ---------------------------------------------------------------------------


class TestLoggingConfigurationModel:
    """Tests for the LoggingConfiguration pydantic model."""

    def test_default_values(self):
        config = LoggingConfiguration()
        assert config.level == "INFO"
        assert config.console_level is None
        assert config.file_level is None
        assert config.logs_path is None

    def test_custom_values(self):
        config = LoggingConfiguration(
            level="DEBUG",
            console_level="ERROR",
            file_level="WARNING",
            logs_path="/var/log/validations",
        )
        assert config.level == "DEBUG"
        assert config.console_level == "ERROR"
        assert config.file_level == "WARNING"
        assert config.logs_path == "/var/log/validations"

    def test_level_helpers(self):
        config = LoggingConfiguration(
            level="INFO", console_level="ERROR", file_level="DEBUG"
        )
        assert config.get_console_level() == "ERROR"
        assert config.get_file_level() == "DEBUG"
        assert config.get_console_level_int() == logging.ERROR
        assert config.get_file_level_int() == logging.DEBUG

    def test_level_helpers_fallback_to_level(self):
        config = LoggingConfiguration(level="WARNING")
        assert config.get_console_level() == "WARNING"
        assert config.get_file_level() == "WARNING"

    def test_invalid_level_raises_error(self):
        with pytest.raises(ValueError, match="Invalid logging level"):
            LoggingConfiguration(level="INVALID")

    def test_invalid_console_level_raises_error(self):
        with pytest.raises(ValueError, match="Invalid logging level"):
            LoggingConfiguration(level="INFO", console_level="NOTREAL")

    def test_invalid_file_level_raises_error(self):
        with pytest.raises(ValueError, match="Invalid logging level"):
            LoggingConfiguration(level="INFO", file_level="NOTREAL")

    def test_logs_path_defaults_to_none(self):
        config = LoggingConfiguration(level="INFO")
        assert config.logs_path is None

    def test_logs_path_accepts_string(self):
        path = os.path.join(tempfile.gettempdir(), "my_logs")
        config = LoggingConfiguration(level="INFO", logs_path=path)
        assert config.logs_path == path
