# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import pytest
from unittest.mock import MagicMock
import pandas as pd

from snowflake.snowflake_data_validation.orchestration.console_progress_reporter import (
    ConsoleProgressReporter,
)
from snowflake.snowflake_data_validation.utils.base_output_handler import (
    OutputMessageLevel,
)
from snowflake.snowflake_data_validation.validation.results_summary_report import (
    ResultsSummaryReport,
)


@pytest.fixture
def mock_output_handler():
    """Create a mock output handler."""
    return MagicMock()


@pytest.fixture
def mock_results_summary():
    """Create a mock ResultsSummaryReport."""
    return ResultsSummaryReport(
        summary=pd.DataFrame(
            {"OBJECT TYPE": ["TABLE"], "NUMBER OF OBJECTS VALIDATED": [5]}
        ),
        schema_validation_summary=pd.DataFrame(
            {"OBJECT_NAME": ["table1"], "STATUS": ["SUCCESS"]}
        ),
        schema_results_summary=pd.DataFrame(
            {"OBJECT_NAME": ["table1"], "STATUS": ["SUCCESS"]}
        ),
        metrics_validation_summary=pd.DataFrame(
            {"OBJECT_NAME": ["table1"], "STATUS": ["SUCCESS"]}
        ),
        metrics_results_summary=pd.DataFrame(
            {"OBJECT_NAME": ["table1"], "STATUS": ["SUCCESS"]}
        ),
        row_validation_summary=pd.DataFrame(
            {"OBJECT_NAME": ["table1"], "STATUS": ["SUCCESS"]}
        ),
        row_results_summary=pd.DataFrame(
            {"OBJECT_NAME": ["table1"], "STATUS": ["SUCCESS"]}
        ),
    )


class TestConsoleProgressReporter:
    """Tests for ConsoleProgressReporter class."""

    def test_init_stores_output_handler(self, mock_output_handler):
        """Test that initialization stores the output handler."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        assert reporter.output_handler == mock_output_handler

    def test_generate_console_output_report_calls_handle_message_four_times(
        self, mock_output_handler, mock_results_summary
    ):
        """Test that handle_message is called four times for each report section."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        reporter.generate_console_output_report(results_summary=mock_results_summary)

        assert mock_output_handler.handle_message.call_count == 4

    def test_generate_console_output_report_uses_info_level(
        self, mock_output_handler, mock_results_summary
    ):
        """Test that all handle_message calls use INFO level."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        reporter.generate_console_output_report(results_summary=mock_results_summary)

        for call in mock_output_handler.handle_message.call_args_list:
            assert call.kwargs["level"] == OutputMessageLevel.INFO

    def test_generate_console_output_report_headers(
        self, mock_output_handler, mock_results_summary
    ):
        """Test that correct headers are passed to handle_message."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        reporter.generate_console_output_report(results_summary=mock_results_summary)

        headers = [
            call.kwargs["header"]
            for call in mock_output_handler.handle_message.call_args_list
        ]

        assert "DATA VALIDATION SUMMARY RESULTS REPORTS" in headers
        assert "SCHEMA VALIDATION SUMMARY" in headers
        assert "METRICS VALIDATION SUMMARY" in headers
        assert "ROW VALIDATION SUMMARY" in headers

    def test_generate_console_output_report_passes_dataframes(
        self, mock_output_handler, mock_results_summary
    ):
        """Test that dataframes are passed to handle_message."""
        reporter = ConsoleProgressReporter(output_handler=mock_output_handler)

        reporter.generate_console_output_report(results_summary=mock_results_summary)

        for call in mock_output_handler.handle_message.call_args_list:
            assert "dataframe" in call.kwargs
            assert isinstance(call.kwargs["dataframe"], pd.DataFrame)
