# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Unit tests for multi-version SQL Server support.

Tests cover:
1. shared.sqlserver ODBC driver detection utilities
2. shared.sqlserver SQL Server version detection
3. ConnectorSqlServer integration with shared modules
4. Jinja2 template conditional rendering (STRING_AGG vs FOR XML PATH)
5. ExecutorFactory propagation of supports_string_agg
6. QueryGeneratorSqlServer threading of supports_string_agg
"""

import os
from pathlib import Path
from unittest.mock import MagicMock, PropertyMock, patch

import jinja2
import pytest

from shared.sqlserver.constants import (
    MIN_VERSION_STRING_AGG,
    SQL_SERVER_VERSION_MAP,
    SUPPORTED_ODBC_DRIVERS,
)
from shared.sqlserver.odbc_driver_utils import (
    get_best_sqlserver_driver,
    get_sqlserver_drivers,
    validate_sqlserver_driver,
)
from shared.sqlserver.version_detection import (
    SqlServerVersionInfo,
    detect_sql_server_version,
)
from snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server import (
    ConnectorSqlServer,
)
from snowflake.snowflake_data_validation.sqlserver.query.query_generator_sqlserver import (
    QueryGeneratorSqlServer,
)
from snowflake.snowflake_data_validation.executer.executor_factory import (
    ExecutorFactory,
)
from snowflake.snowflake_data_validation.executer.extractor_types import (
    ExtractorType,
)
from snowflake.snowflake_data_validation.utils.constants import Platform


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# shared.sqlserver ODBC Driver Utilities Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestSharedOdbcDriverUtils:
    """Tests for shared.sqlserver.odbc_driver_utils functions."""

    @patch("shared.odbc.driver_utils._get_pyodbc")
    def test_get_best_driver_prefers_18(self, mock_get_pyodbc):
        """Driver 18 should be preferred when both 17 and 18 are available."""
        mock_pyodbc = MagicMock()
        mock_pyodbc.drivers.return_value = [
            "ODBC Driver 17 for SQL Server",
            "ODBC Driver 18 for SQL Server",
            "Some Other Driver",
        ]
        mock_get_pyodbc.return_value = mock_pyodbc

        result = get_best_sqlserver_driver()
        assert result == "ODBC Driver 18 for SQL Server"

    @patch("shared.odbc.driver_utils._get_pyodbc")
    def test_get_best_driver_falls_back_to_17(self, mock_get_pyodbc):
        """When only Driver 17 is installed, should use it."""
        mock_pyodbc = MagicMock()
        mock_pyodbc.drivers.return_value = [
            "ODBC Driver 17 for SQL Server",
            "Some Other Driver",
        ]
        mock_get_pyodbc.return_value = mock_pyodbc

        result = get_best_sqlserver_driver()
        assert result == "ODBC Driver 17 for SQL Server"

    @patch("shared.odbc.driver_utils._get_pyodbc")
    def test_get_best_driver_returns_none_when_no_drivers(self, mock_get_pyodbc):
        """When no SQL Server drivers are available, returns None."""
        mock_pyodbc = MagicMock()
        mock_pyodbc.drivers.return_value = ["PostgreSQL ODBC Driver"]
        mock_get_pyodbc.return_value = mock_pyodbc

        result = get_best_sqlserver_driver()
        assert result is None

    @patch("shared.odbc.driver_utils._get_pyodbc")
    def test_get_best_driver_empty_list(self, mock_get_pyodbc):
        """When no drivers at all, returns None."""
        mock_pyodbc = MagicMock()
        mock_pyodbc.drivers.return_value = []
        mock_get_pyodbc.return_value = mock_pyodbc

        result = get_best_sqlserver_driver()
        assert result is None

    @patch("shared.odbc.driver_utils._get_pyodbc")
    def test_get_sqlserver_drivers_filters_correctly(self, mock_get_pyodbc):
        """Should only return drivers with 'SQL Server' in the name."""
        mock_pyodbc = MagicMock()
        mock_pyodbc.drivers.return_value = [
            "ODBC Driver 18 for SQL Server",
            "PostgreSQL Unicode",
            "ODBC Driver 17 for SQL Server",
        ]
        mock_get_pyodbc.return_value = mock_pyodbc

        result = get_sqlserver_drivers()
        assert len(result) == 2
        assert "PostgreSQL Unicode" not in result

    @patch("shared.odbc.driver_utils._get_pyodbc")
    def test_validate_driver_valid(self, mock_get_pyodbc):
        """Validate returns True for an available driver."""
        mock_pyodbc = MagicMock()
        mock_pyodbc.drivers.return_value = ["ODBC Driver 18 for SQL Server"]
        mock_get_pyodbc.return_value = mock_pyodbc

        is_valid, message = validate_sqlserver_driver("ODBC Driver 18 for SQL Server")
        assert is_valid is True

    def test_validate_driver_empty_name(self):
        """Validate returns False for empty driver name."""
        is_valid, message = validate_sqlserver_driver("")
        assert is_valid is False
        assert "empty" in message.lower()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# shared.sqlserver Version Detection Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestSharedVersionDetection:
    """Tests for shared.sqlserver.version_detection.detect_sql_server_version()."""

    def _create_mock_connection(self, cursor_return_row):
        """Helper to create a mock connection with a cursor returning a row."""
        mock_cursor = MagicMock()
        mock_cursor.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchone.return_value = cursor_return_row

        mock_connection = MagicMock()
        mock_connection.cursor.return_value = mock_cursor
        return mock_connection

    def test_detects_sql_server_2016(self):
        """SQL Server 2016 (major version 13) should NOT support STRING_AGG."""
        conn = self._create_mock_connection(
            ("13", "Standard Edition", "Microsoft SQL Server 2016...")
        )

        info = detect_sql_server_version(conn)

        assert info.major_version == 13
        assert info.is_azure_sql_db is False
        assert info.supports_string_agg is False
        assert info.version_name == "SQL Server 2016"

    def test_detects_sql_server_2017(self):
        """SQL Server 2017 (major version 14) SHOULD support STRING_AGG."""
        conn = self._create_mock_connection(
            ("14", "Enterprise Edition", "Microsoft SQL Server 2017...")
        )

        info = detect_sql_server_version(conn)

        assert info.major_version == 14
        assert info.is_azure_sql_db is False
        assert info.supports_string_agg is True
        assert info.version_name == "SQL Server 2017"

    def test_detects_sql_server_2019(self):
        """SQL Server 2019 (major version 15) SHOULD support STRING_AGG."""
        conn = self._create_mock_connection(
            ("15", "Standard Edition", "Microsoft SQL Server 2019...")
        )

        info = detect_sql_server_version(conn)

        assert info.major_version == 15
        assert info.supports_string_agg is True

    def test_detects_sql_server_2022(self):
        """SQL Server 2022 (major version 16) SHOULD support STRING_AGG."""
        conn = self._create_mock_connection(
            ("16", "Developer Edition", "Microsoft SQL Server 2022...")
        )

        info = detect_sql_server_version(conn)

        assert info.major_version == 16
        assert info.supports_string_agg is True

    def test_detects_azure_sql_db(self):
        """Azure SQL DB should always support STRING_AGG regardless of version."""
        conn = self._create_mock_connection(
            ("12", "SQL Azure", "Microsoft SQL Azure (RTM)...")
        )

        info = detect_sql_server_version(conn)

        assert info.is_azure_sql_db is True
        assert info.supports_string_agg is True

    def test_azure_sql_db_with_standard_version(self):
        """Azure SQL DB with a standard major version should still detect Azure."""
        conn = self._create_mock_connection(
            ("16", "SQL Azure (64-bit)", "Microsoft SQL Azure...")
        )

        info = detect_sql_server_version(conn)

        assert info.major_version == 16
        assert info.is_azure_sql_db is True
        assert info.supports_string_agg is True

    def test_defaults_to_true_on_query_failure(self):
        """If version detection query fails, should default supports_string_agg=True."""
        mock_connection = MagicMock()
        mock_connection.cursor.side_effect = Exception("Permission denied")

        info = detect_sql_server_version(mock_connection)

        assert info.supports_string_agg is True

    def test_handles_none_cursor_return(self):
        """If the cursor returns None, should keep safe defaults."""
        conn = self._create_mock_connection(cursor_return_row=None)

        info = detect_sql_server_version(conn)

        assert info.major_version is None
        assert info.supports_string_agg is True

    def test_returns_dataclass(self):
        """Return type should be SqlServerVersionInfo dataclass."""
        conn = self._create_mock_connection(
            ("15", "Standard Edition", "Microsoft SQL Server 2019...")
        )

        info = detect_sql_server_version(conn)

        assert isinstance(info, SqlServerVersionInfo)
        assert info.edition == "Standard Edition"
        assert info.full_version == "Microsoft SQL Server 2019..."


def _make_bare_connector(**overrides) -> ConnectorSqlServer:
    """Create a ConnectorSqlServer without calling __init__.

    Sets the minimum attributes needed to exercise individual methods.
    Pass keyword overrides to replace any default attribute value.
    """
    defaults = {
        "connection": None,
        "sql_server_major_version": None,
        "is_azure_sql_db": False,
        "supports_string_agg": True,
        "pyodbc": MagicMock(),
        "string_connection": None,
    }
    defaults.update(overrides)
    connector = ConnectorSqlServer.__new__(ConnectorSqlServer)
    for attr, value in defaults.items():
        setattr(connector, attr, value)
    return connector


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ConnectorSqlServer Integration Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestConnectorIntegrationWithShared:
    """Tests for ConnectorSqlServer using shared modules."""

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.get_best_sqlserver_driver"
    )
    def test_detect_odbc_driver_delegates_to_shared(self, mock_get_best):
        """_detect_odbc_driver should delegate to shared get_best_sqlserver_driver."""
        mock_get_best.return_value = "ODBC Driver 18 for SQL Server"

        connector = _make_bare_connector()
        result = connector._detect_odbc_driver()
        assert result == "ODBC Driver 18 for SQL Server"

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.get_best_sqlserver_driver"
    )
    def test_detect_odbc_driver_raises_when_none(self, mock_get_best):
        """_detect_odbc_driver should raise ConnectionError when shared returns None."""
        mock_get_best.return_value = None

        connector = _make_bare_connector()
        with pytest.raises(ConnectionError, match="No compatible ODBC driver found"):
            connector._detect_odbc_driver()

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.detect_sql_server_version"
    )
    def test_detect_version_delegates_to_shared(self, mock_detect):
        """_detect_sql_server_version should delegate to shared detect_sql_server_version."""
        mock_detect.return_value = SqlServerVersionInfo(
            major_version=15,
            is_azure_sql_db=False,
            supports_string_agg=True,
            version_name="SQL Server 2019",
        )

        connector = _make_bare_connector(connection=MagicMock())
        connector._detect_sql_server_version()

        assert connector.sql_server_major_version == 15
        assert connector.is_azure_sql_db is False
        assert connector.supports_string_agg is True

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.detect_sql_server_version"
    )
    def test_detect_version_propagates_2016_flags(self, mock_detect):
        """SQL Server 2016 flags should propagate from shared to connector."""
        mock_detect.return_value = SqlServerVersionInfo(
            major_version=13,
            is_azure_sql_db=False,
            supports_string_agg=False,
            version_name="SQL Server 2016",
        )

        connector = _make_bare_connector(connection=MagicMock())
        connector._detect_sql_server_version()

        assert connector.sql_server_major_version == 13
        assert connector.supports_string_agg is False

    def test_detect_version_skips_when_no_connection(self):
        """Should skip detection when connection is None."""
        connector = _make_bare_connector()
        connector._detect_sql_server_version()

        assert connector.supports_string_agg is True  # Unchanged default

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.is_driver_available"
    )
    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.get_best_sqlserver_driver"
    )
    def test_detect_odbc_driver_uses_requested_driver(
        self, mock_get_best, mock_is_available
    ):
        """When a requested driver is available, it should be used instead of auto-detect."""
        mock_is_available.return_value = True

        connector = _make_bare_connector()
        result = connector._detect_odbc_driver(
            requested_driver="ODBC Driver 17 for SQL Server"
        )
        assert result == "ODBC Driver 17 for SQL Server"
        mock_get_best.assert_not_called()

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.is_driver_available"
    )
    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.get_best_sqlserver_driver"
    )
    def test_detect_odbc_driver_falls_back_when_requested_not_found(
        self, mock_get_best, mock_is_available
    ):
        """When the requested driver is not available, should fall back to auto-detect."""
        mock_is_available.return_value = False
        mock_get_best.return_value = "ODBC Driver 18 for SQL Server"

        connector = _make_bare_connector()
        result = connector._detect_odbc_driver(
            requested_driver="ODBC Driver 17 for SQL Server"
        )
        assert result == "ODBC Driver 18 for SQL Server"
        mock_get_best.assert_called_once()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Driver Version Parsing & Encryption Defaults Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestDriverVersionParsing:
    """Tests for _get_driver_version static method."""

    def test_parses_driver_18(self):
        assert (
            ConnectorSqlServer._get_driver_version("ODBC Driver 18 for SQL Server")
            == 18
        )

    def test_parses_driver_17(self):
        assert (
            ConnectorSqlServer._get_driver_version("ODBC Driver 17 for SQL Server")
            == 17
        )

    def test_parses_driver_13(self):
        assert (
            ConnectorSqlServer._get_driver_version("ODBC Driver 13 for SQL Server")
            == 13
        )

    def test_returns_none_for_native_client(self):
        assert (
            ConnectorSqlServer._get_driver_version("SQL Server Native Client 11.0")
            is None
        )

    def test_returns_none_for_unversioned(self):
        assert ConnectorSqlServer._get_driver_version("Some Custom Driver") is None


class TestDriver17EncryptionDefaults:
    """Tests for driver-version-aware encryption defaults in _internal_connect.

    With the sentinel approach, ``encrypt`` and ``trust_server_certificate``
    default to ``None``.  The connector resolves them based on driver version:
    * Driver 17 and below → encrypt="no", trust_server_certificate="yes"
    * Driver 18 and above → encrypt="yes", trust_server_certificate="no"

    Explicit user values are never overridden.
    """

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.is_driver_available"
    )
    def test_driver17_none_defaults_to_no_encrypt(self, mock_is_available):
        """With Driver 17 and no explicit values, should default to safe settings."""
        mock_is_available.return_value = True
        connector = _make_bare_connector()

        connector._internal_connect(
            host="localhost",
            port=1433,
            database="testdb",
            user="sa",
            password="pass",
            mode="sql_auth",
            odbc_driver="ODBC Driver 17 for SQL Server",
        )

        conn_str = connector.string_connection
        assert "Encrypt=no" in conn_str
        assert "TrustServerCertificate=yes" in conn_str

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.is_driver_available"
    )
    def test_driver18_none_defaults_to_yes_encrypt(self, mock_is_available):
        """With Driver 18 and no explicit values, should default to encrypted settings."""
        mock_is_available.return_value = True
        connector = _make_bare_connector()

        connector._internal_connect(
            host="localhost",
            port=1433,
            database="testdb",
            user="sa",
            password="pass",
            mode="sql_auth",
            odbc_driver="ODBC Driver 18 for SQL Server",
        )

        conn_str = connector.string_connection
        assert "Encrypt=yes" in conn_str
        assert "TrustServerCertificate=no" in conn_str

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.is_driver_available"
    )
    def test_driver17_explicit_values_are_respected(self, mock_is_available):
        """When user explicitly sets encrypt/trust, Driver 17 should not override them."""
        mock_is_available.return_value = True
        connector = _make_bare_connector()

        connector._internal_connect(
            host="localhost",
            port=1433,
            database="testdb",
            user="sa",
            password="pass",
            mode="sql_auth",
            trust_server_certificate="no",
            encrypt="yes",
            odbc_driver="ODBC Driver 17 for SQL Server",
        )

        conn_str = connector.string_connection
        assert "Encrypt=yes" in conn_str
        assert "TrustServerCertificate=no" in conn_str

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.is_driver_available"
    )
    def test_driver17_explicit_encrypt_no_keeps_values(self, mock_is_available):
        """When user explicitly sets encrypt=no, should keep it."""
        mock_is_available.return_value = True
        connector = _make_bare_connector()

        connector._internal_connect(
            host="localhost",
            port=1433,
            database="testdb",
            user="sa",
            password="pass",
            mode="sql_auth",
            trust_server_certificate="no",
            encrypt="no",
            odbc_driver="ODBC Driver 17 for SQL Server",
        )

        conn_str = connector.string_connection
        assert "Encrypt=no" in conn_str
        assert "TrustServerCertificate=no" in conn_str

    @patch(
        "snowflake.snowflake_data_validation.sqlserver.connector.connector_sql_server.is_driver_available"
    )
    def test_driver18_explicit_no_encrypt_keeps_values(self, mock_is_available):
        """When user explicitly sets encrypt=no on Driver 18, should keep it."""
        mock_is_available.return_value = True
        connector = _make_bare_connector()

        connector._internal_connect(
            host="localhost",
            port=1433,
            database="testdb",
            user="sa",
            password="pass",
            mode="sql_auth",
            trust_server_certificate="yes",
            encrypt="no",
            odbc_driver="ODBC Driver 18 for SQL Server",
        )

        conn_str = connector.string_connection
        assert "Encrypt=no" in conn_str
        assert "TrustServerCertificate=yes" in conn_str


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SqlServerCredentialsConnection ODBC Driver Field Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestCredentialsConnectionOdbcDriver:
    """Tests for the odbc_driver field on SqlServerCredentialsConnection."""

    def test_odbc_driver_defaults_to_none(self):
        from snowflake.snowflake_data_validation.sqlserver.model.sqlserver_credentials_connection import (
            SqlServerCredentialsConnection,
        )

        conn = SqlServerCredentialsConnection(
            host="localhost", database="testdb", username="sa", password="pass"
        )
        assert conn.odbc_driver is None

    def test_odbc_driver_can_be_set_to_driver17(self):
        from snowflake.snowflake_data_validation.sqlserver.model.sqlserver_credentials_connection import (
            SqlServerCredentialsConnection,
        )

        conn = SqlServerCredentialsConnection(
            host="localhost",
            database="testdb",
            username="sa",
            password="pass",
            odbc_driver="ODBC Driver 17 for SQL Server",
        )
        assert conn.odbc_driver == "ODBC Driver 17 for SQL Server"

    def test_configuration_string_includes_odbc_driver_when_set(self):
        from snowflake.snowflake_data_validation.sqlserver.model.sqlserver_credentials_connection import (
            SqlServerCredentialsConnection,
        )

        conn = SqlServerCredentialsConnection(
            host="localhost",
            database="testdb",
            username="sa",
            password="pass",
            odbc_driver="ODBC Driver 17 for SQL Server",
        )
        config_str = conn.configuration_file_connection_string()
        assert "odbc_driver: ODBC Driver 17 for SQL Server" in config_str

    def test_configuration_string_omits_odbc_driver_when_none(self):
        from snowflake.snowflake_data_validation.sqlserver.model.sqlserver_credentials_connection import (
            SqlServerCredentialsConnection,
        )

        conn = SqlServerCredentialsConnection(
            host="localhost", database="testdb", username="sa", password="pass"
        )
        config_str = conn.configuration_file_connection_string()
        assert "odbc_driver" not in config_str

    def test_configuration_string_omits_encrypt_and_tsc_when_none(self):
        from snowflake.snowflake_data_validation.sqlserver.model.sqlserver_credentials_connection import (
            SqlServerCredentialsConnection,
        )

        conn = SqlServerCredentialsConnection(
            host="localhost", database="testdb", username="sa", password="pass"
        )
        config_str = conn.configuration_file_connection_string()
        assert "encrypt" not in config_str
        assert "trust_server_certificate" not in config_str

    def test_configuration_string_includes_encrypt_and_tsc_when_set(self):
        from snowflake.snowflake_data_validation.sqlserver.model.sqlserver_credentials_connection import (
            SqlServerCredentialsConnection,
        )

        conn = SqlServerCredentialsConnection(
            host="localhost",
            database="testdb",
            username="sa",
            password="pass",
            encrypt="yes",
            trust_server_certificate="no",
        )
        config_str = conn.configuration_file_connection_string()
        assert "encrypt: yes" in config_str
        assert "trust_server_certificate: no" in config_str


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Jinja2 Template Tests (STRING_AGG vs FOR XML PATH)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestComputeMd5Template:
    """Tests for sqlserver_compute_md5_sql.j2 conditional rendering."""

    @pytest.fixture
    def jinja_env(self):
        """Create Jinja2 environment pointing to SQL Server templates."""
        templates_path = (
            Path(__file__).parent.parent.parent
            / "src/snowflake/snowflake_data_validation"
            / "sqlserver/extractor/templates"
        )
        return jinja2.Environment(loader=jinja2.FileSystemLoader(str(templates_path)))

    @pytest.fixture
    def template_vars(self):
        """Common template variables for rendering."""
        index_col = MagicMock()
        index_col.name = "id"
        index_col.data_type = "INT"

        col = MagicMock()
        col.name = "name"
        col.data_type = "VARCHAR"
        col.nullable = False

        return {
            "chunk_id": "test_chunk_1",
            "table_id": 1,
            "normalized_fully_qualified_name": "db_schema_table",
            "index_column_collection": [index_col],
            "column_collection": [col],
            "column_names_separate_by_comma": '"name"',
            "datatypes_normalization_renderer_templates": {"name": '"name"'},
            "fully_qualified_name": "[db].[schema].[table]",
            "has_where_clause": False,
            "where_clause": "",
            "offset": 0,
            "fetch": 1000,
        }

    def test_renders_string_agg_when_supported(self, jinja_env, template_vars):
        """When supports_string_agg=True, output should contain STRING_AGG."""
        template = jinja_env.get_template("sqlserver_compute_md5_sql.j2")
        result = template.render(**template_vars, supports_string_agg=True)

        assert "STRING_AGG" in result
        assert "FOR XML PATH" not in result

    def test_renders_for_xml_path_when_not_supported(self, jinja_env, template_vars):
        """When supports_string_agg=False, output should contain FOR XML PATH."""
        template = jinja_env.get_template("sqlserver_compute_md5_sql.j2")
        result = template.render(**template_vars, supports_string_agg=False)

        assert "FOR XML PATH" in result
        assert "STRING_AGG" not in result

    def test_for_xml_path_uses_type_and_value(self, jinja_env, template_vars):
        """FOR XML PATH fallback should use TYPE and .value() for proper encoding."""
        template = jinja_env.get_template("sqlserver_compute_md5_sql.j2")
        result = template.render(**template_vars, supports_string_agg=False)

        assert "TYPE).value('.', 'VARCHAR(MAX)')" in result

    def test_both_paths_contain_hashbytes_md5(self, jinja_env, template_vars):
        """Both STRING_AGG and FOR XML PATH paths should use HASHBYTES('MD5', ...)."""
        template = jinja_env.get_template("sqlserver_compute_md5_sql.j2")

        result_agg = template.render(**template_vars, supports_string_agg=True)
        result_xml = template.render(**template_vars, supports_string_agg=False)

        assert "HASHBYTES('MD5'" in result_agg
        assert "HASHBYTES('MD5'" in result_xml

    def test_both_paths_insert_into_chunks_table(self, jinja_env, template_vars):
        """Both paths should INSERT INTO the chunks MD5 table."""
        template = jinja_env.get_template("sqlserver_compute_md5_sql.j2")

        result_agg = template.render(**template_vars, supports_string_agg=True)
        result_xml = template.render(**template_vars, supports_string_agg=False)

        expected_table = "#CHUNKS_MD5_db_schema_table_1"
        assert expected_table in result_agg
        assert expected_table in result_xml

    def test_string_agg_path_has_from_clause(self, jinja_env, template_vars):
        """STRING_AGG path needs FROM clause (aggregate operates on result set)."""
        template = jinja_env.get_template("sqlserver_compute_md5_sql.j2")
        result = template.render(**template_vars, supports_string_agg=True)

        lines = result.strip().split("\n")
        last_insert_idx = max(
            i
            for i, line in enumerate(lines)
            if "INSERT INTO" in line and "CHUNKS_MD5" in line
        )
        last_block = "\n".join(lines[last_insert_idx:])
        assert 'FROM "#ROW_MD5_' in last_block

    def test_for_xml_path_has_subquery_from(self, jinja_env, template_vars):
        """FOR XML PATH path embeds FROM in the subquery, not as outer FROM."""
        template = jinja_env.get_template("sqlserver_compute_md5_sql.j2")
        result = template.render(**template_vars, supports_string_agg=False)

        assert 'FROM "#ROW_MD5_test_chunk_1_1"' in result


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# QueryGeneratorSqlServer Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestQueryGeneratorSqlServerStringAgg:
    """Tests for supports_string_agg on QueryGeneratorSqlServer."""

    def test_default_supports_string_agg_true(self):
        """Default initialization should have supports_string_agg=True."""
        generator = QueryGeneratorSqlServer()
        assert generator.supports_string_agg is True

    def test_init_with_supports_string_agg_false(self):
        """Should accept supports_string_agg=False in constructor."""
        generator = QueryGeneratorSqlServer(supports_string_agg=False)
        assert generator.supports_string_agg is False

    def test_passes_supports_string_agg_to_template(self):
        """_generate_compute_md5_chunk_query should pass supports_string_agg to template generator."""
        generator = QueryGeneratorSqlServer(supports_string_agg=False)

        mock_table_context = MagicMock()
        mock_table_context.templates_loader_manager.datatypes_normalization_templates = {
            "VARCHAR": '"{{ col_name }}"'
        }
        mock_col = MagicMock()
        mock_col.name = "test_col"
        mock_col.data_type = "VARCHAR"
        mock_table_context.columns_to_validate = [mock_col]
        mock_table_context.join_column_names_with_commas.return_value = '"test_col"'
        mock_table_context.index_column_collection = []
        mock_table_context.fully_qualified_name = "[db].[schema].[table]"
        mock_table_context.has_where_clause = False
        mock_table_context.where_clause = ""
        mock_table_context.internal_table_name = "table"
        mock_table_context.normalized_fully_qualified_name = "db_schema_table"
        mock_table_context.database_name = "db"
        mock_table_context.schema_name = "schema"
        mock_table_context.id = 1

        mock_sql_generator = MagicMock()
        mock_table_context.sql_generator = mock_sql_generator

        generator._generate_compute_md5_chunk_query(
            table_context=mock_table_context,
            chunk_id="chunk_1",
            fetch=1000,
            offset=0,
        )

        mock_sql_generator.generate_compute_md5_query.assert_called_once()
        call_kwargs = mock_sql_generator.generate_compute_md5_query.call_args
        assert call_kwargs.kwargs.get("supports_string_agg") is False or (
            len(call_kwargs.args) > 0
            and call_kwargs[1].get("supports_string_agg") is False
        )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ExecutorFactory Propagation Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestExecutorFactoryStringAggPropagation:
    """Tests for propagation of supports_string_agg from connector to query generator."""

    def test_propagates_supports_string_agg_false_for_sqlserver(self):
        """When SQL Server connector has supports_string_agg=False, query generator should too."""
        factory = ExecutorFactory()

        mock_connector = MagicMock(spec=ConnectorSqlServer)
        mock_connector.supports_string_agg = False

        extractor = factory.create_extractor_from_connector(
            connector=mock_connector,
            extractor_type=ExtractorType.METADATA_EXTRACTOR,
            platform=Platform.SQLSERVER,
        )

        assert extractor is not None

    def test_propagates_supports_string_agg_true_for_sqlserver(self):
        """When SQL Server connector has supports_string_agg=True, query generator should too."""
        factory = ExecutorFactory()

        mock_connector = MagicMock(spec=ConnectorSqlServer)
        mock_connector.supports_string_agg = True

        extractor = factory.create_extractor_from_connector(
            connector=mock_connector,
            extractor_type=ExtractorType.METADATA_EXTRACTOR,
            platform=Platform.SQLSERVER,
        )

        assert extractor is not None

    def test_does_not_affect_non_sqlserver_platforms(self):
        """Non-SQL Server platforms should not be affected by the propagation logic."""
        factory = ExecutorFactory()

        mock_connector = MagicMock()

        extractor = factory.create_extractor_from_connector(
            connector=mock_connector,
            extractor_type=ExtractorType.METADATA_EXTRACTOR,
            platform=Platform.SNOWFLAKE,
        )

        assert extractor is not None


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Constants / Configuration Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestMultiVersionConstants:
    """Tests for shared constants used in multi-version support."""

    def test_supported_odbc_drivers_order(self):
        """Driver 18 should be first (preferred) in the list."""
        assert SUPPORTED_ODBC_DRIVERS[0] == "ODBC Driver 18 for SQL Server"
        assert SUPPORTED_ODBC_DRIVERS[1] == "ODBC Driver 17 for SQL Server"

    def test_min_version_string_agg(self):
        """STRING_AGG minimum version should be 14 (SQL Server 2017)."""
        assert MIN_VERSION_STRING_AGG == 14

    def test_version_map_contains_all_supported_versions(self):
        """Version map should contain 2016, 2017, 2019, 2022."""
        assert 13 in SQL_SERVER_VERSION_MAP  # 2016
        assert 14 in SQL_SERVER_VERSION_MAP  # 2017
        assert 15 in SQL_SERVER_VERSION_MAP  # 2019
        assert 16 in SQL_SERVER_VERSION_MAP  # 2022

    def test_version_info_dataclass_defaults(self):
        """SqlServerVersionInfo should have safe defaults."""
        info = SqlServerVersionInfo()

        assert info.major_version is None
        assert info.is_azure_sql_db is False
        assert info.supports_string_agg is True  # Safe default
        assert info.version_name == "Unknown"
        assert info.edition is None
        assert info.full_version is None
