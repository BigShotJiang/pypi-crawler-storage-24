"""Supply chain analysis helpers.

Provides both generic classification-based grouping (using structured data
from the database) and legacy semantic matching for databases without
classification metadata.
"""

from dataclasses import dataclass, field

from .classify import SemanticClassifier
from .client import Client
from .types import SupplyChainEntry


def group_supply_chain_by_classification(
    client: Client, process_id: str, prefix: str | None = None, limit: int = 1000
) -> dict[str, list[SupplyChainEntry]]:
    """Group supply chain entries by their classification path.

    If prefix given (e.g. 'Agricultural\\Animal feed'), only entries
    matching that prefix are included.
    """
    chain = client.get_supply_chain(process_id, limit=limit)
    groups: dict[str, list[SupplyChainEntry]] = {}
    for entry in chain.entries:
        cat = entry.classifications.get("Category", "")
        if not cat:
            cat = "(unclassified)"
        if prefix and not cat.startswith(prefix):
            continue
        groups.setdefault(cat, []).append(entry)
    return groups


# -- Legacy semantic matching (for databases without classification data) --

# Reference phrases for semantic matching
ANIMAL_PHRASES = [
    "live animal at farm gate",
    "livestock for slaughter at farm",
]

FEED_PHRASES = [
    "animal feed ingredient for livestock",
]

FEED_CATEGORIES = [
    "grazed grass/pasture",
    "hay/dried forage",
    "silage maize",
    "cereal grain",
    "soybean meal",
    "rapeseed meal",
    "sunflower meal",
    "compound feed/premix",
    "milk for calf",
    "amino acids/additives",
    "DDGS/co-products",
]


# -- Exchange accessors (handle the nested API response structure) --

def _exch_name(inp: dict) -> str:
    return inp.get("edFlow", {}).get("flowName", "")


def _exch_amount(inp: dict) -> float:
    exch = inp.get("edExchange", {})
    return abs(float(exch.get("techAmount", 0) or exch.get("bioAmount", 0)))


def _exch_unit(inp: dict) -> str:
    return inp.get("edExchangeUnitName", "")


def _exch_linked_id(inp: dict) -> str:
    target = inp.get("edTargetActivity")
    return target.get("prsId", "") if target else ""


@dataclass
class AnimalCandidate:
    process_id: str
    name: str
    location: str
    score: float
    quantity: float
    unit: str


@dataclass
class FeedInput:
    name: str
    category: str
    category_score: float
    amount: float
    unit: str


@dataclass
class SubAnimal:
    process_id: str
    name: str
    amount: float
    unit: str
    feeds: list[FeedInput] = field(default_factory=list)


def find_animal_candidates(
    client: Client,
    process_id: str,
    classifier: SemanticClassifier,
    top_k: int = 5,
) -> list[AnimalCandidate]:
    """Find live animal candidates in a product's supply chain.

    Pre-filters to "at farm" entries (structural LCA marker), then ranks
    by semantic similarity to animal reference phrases.
    """
    chain = client.get_supply_chain(process_id, limit=1000)
    # Pre-filter: "at farm" processes, excluding feed/processing/slaughter
    exclude = {"feed", "slaughter", "processing", "manure", "housing", "emission"}
    farm_entries = [
        e for e in chain.entries
        if "at farm" in e.name.lower()
        and not any(w in e.name.lower() for w in exclude)
    ]
    if not farm_entries:
        farm_entries = chain.entries  # fallback to full chain
    names = [e.name for e in farm_entries]
    ranked = classifier.rank_by_similarity(names, ANIMAL_PHRASES, top_k=top_k)
    return [
        AnimalCandidate(
            process_id=farm_entries[i].process_id,
            name=name,
            location=farm_entries[i].location,
            score=score,
            quantity=farm_entries[i].quantity,
            unit=farm_entries[i].unit,
        )
        for i, name, score in ranked
    ]


def _is_sub_animal(name: str) -> bool:
    """Check if an input name looks like a sub-animal process.

    Sub-animals are "at farm gate" processes that are not feed or supplements.
    We check the beginning of the name (before the first comma) to avoid
    false exclusions on names like "Cull cow, ..., silage maize 30%, at farm".
    """
    low = name.lower()
    if "at farm" not in low:
        return False
    # Check only the first part of the name (the main subject)
    subject = low.split(",")[0].strip()
    feed_terms = {"feed", "grain", "straw", "meal", "silage", "hay", "oil",
                  "lysine", "methionine", "tryptophane", "ddgs", "seed",
                  "reproductive", "alfalfa", "rapeseed", "soybean", "sunflower",
                  "wheat", "maize", "barley"}
    return not any(w in subject for w in feed_terms)


def detect_aggregation(client: Client, animal_id: str) -> tuple[bool, list[dict]]:
    """Detect if an animal process aggregates sub-animals or has direct feed.

    Sub-animals are "at farm gate" kg-unit inputs that aren't feed.
    Returns (is_aggregated, sub_animal_inputs).
    """
    inputs = client.get_inputs(animal_id)
    linked = [inp for inp in inputs if _exch_linked_id(inp)]
    if len(linked) <= 1:
        return False, linked
    sub_animals = [
        inp for inp in linked
        if _exch_unit(inp) == "kg" and _is_sub_animal(_exch_name(inp))
    ]
    return len(sub_animals) > 1, sub_animals


def get_feed_inputs(
    client: Client,
    animal_id: str,
    classifier: SemanticClassifier,
    threshold: float = 0.4,
) -> list[FeedInput]:
    """Identify and categorize feed inputs for a single animal process."""
    inputs = client.get_inputs(animal_id)
    names = [_exch_name(inp) for inp in inputs]
    if not names:
        return []

    # Filter to feed-like inputs
    feed_matches = classifier.filter_by_similarity(names, FEED_PHRASES, threshold)
    if not feed_matches:
        return []

    feed_indices = {i for i, _, _ in feed_matches}
    feed_names = [names[i] for i in sorted(feed_indices)]
    feed_inputs_raw = [inputs[i] for i in sorted(feed_indices)]

    # Classify into categories
    classified = classifier.classify(feed_names, FEED_CATEGORIES)
    return [
        FeedInput(
            name=name,
            category=cat,
            category_score=score,
            amount=_exch_amount(feed_inputs_raw[j]),
            unit=_exch_unit(feed_inputs_raw[j]),
        )
        for j, (name, cat, score) in enumerate(classified)
    ]


def get_reference_amount(client: Client, process_id: str) -> float:
    """Get the reference product amount for normalization."""
    activity = client.get_activity(process_id)
    products = activity.get("piActivity", {}).get("pfaAllProducts", [])
    if products:
        return float(products[0].get("prsProductAmount", 1.0))
    return float(activity.get("prsProductAmount", 1.0))


def analyze_animal_feed(
    client: Client,
    animal_id: str,
    classifier: SemanticClassifier,
    feed_threshold: float = 0.4,
) -> tuple[list[SubAnimal], float]:
    """Full feed analysis: detect aggregation, get feeds for each (sub-)animal.

    Returns (sub_animals_with_feeds, reference_amount).
    """
    ref_amount = get_reference_amount(client, animal_id)
    is_agg, sub_inputs = detect_aggregation(client, animal_id)

    if is_agg:
        sub_animals = []
        for inp in sub_inputs:
            sub_id = _exch_linked_id(inp)
            sub_ref = get_reference_amount(client, sub_id)
            feeds = get_feed_inputs(client, sub_id, classifier, feed_threshold)
            # Normalize feed amounts: per kg of sub-animal output
            for f in feeds:
                f.amount = f.amount / sub_ref if sub_ref > 0 else f.amount
            sub = SubAnimal(
                process_id=sub_id,
                name=_exch_name(inp),
                amount=_exch_amount(inp),
                unit=_exch_unit(inp),
                feeds=feeds,
            )
            sub_animals.append(sub)
        return sub_animals, ref_amount
    else:
        # Single animal — feeds are direct inputs, normalize per kg
        feeds = get_feed_inputs(client, animal_id, classifier, feed_threshold)
        for f in feeds:
            f.amount = f.amount / ref_amount if ref_amount > 0 else f.amount
        single = SubAnimal(
            process_id=animal_id,
            name="(direct)",
            amount=ref_amount,
            unit="kg",
            feeds=feeds,
        )
        return [single], ref_amount
