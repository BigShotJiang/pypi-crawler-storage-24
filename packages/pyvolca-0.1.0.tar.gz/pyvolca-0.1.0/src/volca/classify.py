"""Semantic classification using sentence-transformers embeddings."""

import numpy as np
from sentence_transformers import SentenceTransformer


class SemanticClassifier:
    """Classify and rank text strings by cosine similarity to reference phrases.

    Uses all-mpnet-base-v2 (768 dims) for high-quality semantic matching.
    Single model instance handles all classification tasks.
    """

    def __init__(self, model_name: str = "all-mpnet-base-v2"):
        self._model = SentenceTransformer(model_name)

    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Cosine similarity between row vectors of a and b."""
        a_norm = a / np.linalg.norm(a, axis=1, keepdims=True)
        b_norm = b / np.linalg.norm(b, axis=1, keepdims=True)
        return a_norm @ b_norm.T

    def rank_by_similarity(
        self, names: list[str], reference_phrases: list[str], top_k: int = 5
    ) -> list[tuple[int, str, float]]:
        """Rank names by max similarity to any reference phrase.

        Returns list of (original_index, name, score) sorted by score descending.
        """
        if not names:
            return []
        name_emb = self._model.encode(names)
        ref_emb = self._model.encode(reference_phrases)
        sims = self._cosine_similarity(name_emb, ref_emb)
        max_scores = sims.max(axis=1)
        ranked_indices = np.argsort(-max_scores)[:top_k]
        return [(int(i), names[i], float(max_scores[i])) for i in ranked_indices]

    def classify(
        self, names: list[str], categories: list[str]
    ) -> list[tuple[str, str, float]]:
        """Assign each name to its closest category.

        Returns list of (name, category, score) preserving input order.
        """
        if not names:
            return []
        name_emb = self._model.encode(names)
        cat_emb = self._model.encode(categories)
        sims = self._cosine_similarity(name_emb, cat_emb)
        best_cat = sims.argmax(axis=1)
        return [
            (names[i], categories[best_cat[i]], float(sims[i, best_cat[i]]))
            for i in range(len(names))
        ]

    def filter_by_similarity(
        self, names: list[str], reference_phrases: list[str], threshold: float = 0.3
    ) -> list[tuple[int, str, float]]:
        """Return names above similarity threshold to any reference phrase.

        Returns list of (original_index, name, score) sorted by score descending.
        """
        ranked = self.rank_by_similarity(names, reference_phrases, top_k=len(names))
        return [(i, n, s) for i, n, s in ranked if s >= threshold]
