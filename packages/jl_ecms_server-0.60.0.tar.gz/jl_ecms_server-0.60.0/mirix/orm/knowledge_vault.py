import datetime as dt
from datetime import datetime
from typing import TYPE_CHECKING, Optional

from sqlalchemy import JSON, Column, ForeignKey, Index, String, text
from sqlalchemy.orm import Mapped, declared_attr, mapped_column, relationship

from mirix.constants import MAX_EMBEDDING_DIM
from mirix.orm.custom_columns import CommonVector, EmbeddingConfigColumn
from mirix.orm.mixins import OrganizationMixin, UserMixin
from mirix.orm.sqlalchemy_base import SqlalchemyBase
from mirix.schemas.knowledge_vault import KnowledgeVaultItem as PydanticKnowledgeVaultItem
from mirix.settings import settings

if TYPE_CHECKING:
    from mirix.orm.agent import Agent
    from mirix.orm.organization import Organization
    from mirix.orm.user import User


class KnowledgeVaultItem(SqlalchemyBase, OrganizationMixin, UserMixin):
    """
    Stores verbatim knowledge vault entries like credentials, bookmarks, addresses,
    or other structured data that needs quick retrieval.

    type:        The category (e.g. 'credential', 'bookmark', 'contact')
    source:      The origin or context (e.g. 'user-provided on 2025-03-01')
    sensitivity: Level of data sensitivity (e.g. 'low', 'high')
    secret_value: The actual data or secret (e.g. password, token)
    """

    __tablename__ = "knowledge_vault"
    __pydantic_model__ = PydanticKnowledgeVaultItem

    # Primary key
    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        doc="Unique ID for this knowledge vault entry",
    )

    # Foreign key to agent
    agent_id: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("agents.id", ondelete="CASCADE"),
        nullable=True,
        doc="ID of the agent this knowledge vault item belongs to",
    )

    # Foreign key to client (for access control and filtering)
    client_id: Mapped[Optional[str]] = mapped_column(
        String,
        ForeignKey("clients.id", ondelete="CASCADE"),
        nullable=True,
        doc="ID of the client application that created this item",
    )

    # Distinguish the type/category of the entry
    entry_type: Mapped[str] = mapped_column(
        String,
        nullable=False,
        doc="Category (e.g., 'credential', 'bookmark', 'api_key')",
    )

    # Source (where or how it was provided)
    source: Mapped[str] = mapped_column(
        String,
        doc="Information on who/where it was provided (e.g. 'user on 2025-03-01')",
    )

    # Sensitivity level
    sensitivity: Mapped[str] = mapped_column(String, doc="Data sensitivity (e.g. 'low', 'medium', 'high')")

    # Actual data or secret, e.g. password, API token
    secret_value: Mapped[str] = mapped_column(String, doc="The actual credential or data value")

    # Description or notes about the entry
    caption: Mapped[str] = mapped_column(String, doc="Description or notes about the entry")

    # NEW: Filter tags for flexible filtering and categorization
    filter_tags: Mapped[Optional[dict]] = mapped_column(
        JSON, nullable=True, default=None, doc="Custom filter tags for filtering and categorization"
    )

    # When was this item last modified and what operation?
    last_modify: Mapped[dict] = mapped_column(
        JSON,
        nullable=False,
        default=lambda: {
            "timestamp": datetime.now(dt.timezone.utc).isoformat(),
            "operation": "created",
        },
        doc="Last modification info including timestamp and operation type",
    )

    embedding_config: Mapped[Optional[dict]] = mapped_column(
        EmbeddingConfigColumn, nullable=True, doc="Embedding configuration"
    )

    # Vector embedding field based on database type
    if settings.mirix_pg_uri_no_default:
        from pgvector.sqlalchemy import Vector

        caption_embedding = mapped_column(Vector(MAX_EMBEDDING_DIM), nullable=True)
    else:
        caption_embedding = Column(CommonVector, nullable=True)

    # Database indexes for efficient querying
    __table_args__ = tuple(
        filter(
            None,
            [
                # Organization-level query optimization indexes
                (
                    Index("ix_knowledge_vault_organization_id", "organization_id")
                    if settings.mirix_pg_uri_no_default
                    else None
                ),
                (
                    Index(
                        "ix_knowledge_vault_org_created_at",
                        "organization_id",
                        "created_at",
                        postgresql_using="btree",
                    )
                    if settings.mirix_pg_uri_no_default
                    else None
                ),
                (
                    Index(
                        "ix_knowledge_vault_filter_tags_gin",
                        text("(filter_tags::jsonb)"),
                        postgresql_using="gin",
                    )
                    if settings.mirix_pg_uri_no_default
                    else None
                ),
                (
                    Index(
                        "ix_knowledge_vault_org_filter_scope",
                        "organization_id",
                        text("((filter_tags->>'scope')::text)"),
                        postgresql_using="btree",
                    )
                    if settings.mirix_pg_uri_no_default
                    else None
                ),
                # SQLite indexes
                (
                    Index("ix_knowledge_vault_organization_id_sqlite", "organization_id")
                    if not settings.mirix_pg_uri_no_default
                    else None
                ),
            ],
        )
    )

    @declared_attr
    def agent(cls) -> Mapped[Optional["Agent"]]:
        """
        Relationship to the Agent that owns this knowledge vault item.
        """
        return relationship("Agent", lazy="selectin")

    @declared_attr
    def organization(cls) -> Mapped["Organization"]:
        """
        Relationship to organization (mirroring your existing patterns).
        Adjust 'back_populates' to match the collection name in your `Organization` model.
        """
        return relationship("Organization", back_populates="knowledge_vault", lazy="selectin")

    @declared_attr
    def user(cls) -> Mapped["User"]:
        """
        Relationship to the User that owns this knowledge vault item.
        """
        return relationship("User", lazy="selectin")

    def to_pydantic(self) -> "PydanticKnowledgeVaultItem":
        """
        Convert to Pydantic model, safely handling relationship loading.
        This prevents MissingGreenlet errors when converting detached instances.
        """
        state = {
            "id": self.id,
            "agent_id": self.agent_id,
            "client_id": self.client_id,
            "user_id": self.user_id,
            "organization_id": self.organization_id,
            "entry_type": self.entry_type,
            "source": self.source,
            "sensitivity": self.sensitivity,
            "secret_value": self.secret_value,
            "caption": self.caption,
            "filter_tags": self.filter_tags,
            "last_modify": self.last_modify,
            "embedding_config": self.embedding_config,
            "caption_embedding": self.caption_embedding,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }
        return self.__pydantic_model__(**state)
