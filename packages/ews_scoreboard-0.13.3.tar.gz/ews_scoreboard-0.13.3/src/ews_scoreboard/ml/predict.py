"""
Prediction engine: load trained model, predict YI probability, generate SHAP reasons.

Called by marts.py during every pipeline run.

Usage:
    from ews_scoreboard.ml.predict import run_predictions
    scoreboard = run_predictions(db_path, scoreboard, model_dir)
"""

import pickle
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False

from ews_scoreboard.ml.features import (
    build_features, FEATURE_COLS, FEATURE_LABELS
)


def _load_model(model_dir: Path) -> dict:
    """Load model artifacts from pickle."""
    model_path = Path(model_dir) / "yi_model.pkl"
    if not model_path.exists():
        return None
    with open(model_path, "rb") as f:
        return pickle.load(f)


def _generate_reason(shap_values: np.ndarray, feature_values: pd.Series,
                     top_n: int = 3) -> str:
    """Generate human-readable reason from SHAP values.

    Takes the top N features by absolute SHAP value and builds
    a reason string like:
      "Skor 3 dönemdir yükseliyor (+0.23) | Risk %40 arttı (+0.18)"
    """
    # Pair features with their SHAP values
    pairs = []
    for i, col in enumerate(FEATURE_COLS):
        sv = shap_values[i]
        fv = feature_values[col] if col in feature_values.index else None
        pairs.append((col, sv, fv))

    # Sort by absolute SHAP value
    pairs.sort(key=lambda x: abs(x[1]), reverse=True)

    reasons = []
    for col, sv, fv in pairs[:top_n]:
        label = FEATURE_LABELS.get(col, col)
        direction = "↑" if sv > 0 else "↓"

        # Build contextual explanation
        if fv is not None and fv != -999:
            if col == "ews_score":
                reasons.append(f"{label}: {int(fv)} {direction}")
            elif col == "ews_delta_1":
                reasons.append(f"{label}: {'+' if fv > 0 else ''}{int(fv)} {direction}")
            elif col == "ews_delta_3":
                reasons.append(f"{label}: {'+' if fv > 0 else ''}{int(fv)} {direction}")
            elif col == "ews_consec_rise":
                if fv > 0:
                    reasons.append(f"{int(fv)} dönemdir yükseliyor {direction}")
            elif col == "ews_above_825_count":
                if fv > 0:
                    reasons.append(f"{int(fv)} dönemde 825+ {direction}")
            elif col == "risk_delta_pct":
                reasons.append(f"Risk değişimi: %{fv*100:.0f} {direction}")
            elif col == "risk_mio":
                reasons.append(f"Risk: {fv:.1f}M TL {direction}")
            elif col in ("yi_flag_current", "yi_flag_prev", "was_yi_prev"):
                if fv > 0:
                    reasons.append(f"{label} {direction}")
            elif col == "yi_flag_count_4":
                if fv > 0:
                    reasons.append(f"Son 4 dönemde {int(fv)} YI flag {direction}")
            elif col.startswith("seg_"):
                if fv > 0:
                    reasons.append(f"{label} {direction}")
            elif col == "ews_max_3":
                reasons.append(f"Maks skor (3d): {int(fv)} {direction}")
            elif col == "ews_mean_3":
                reasons.append(f"Ort skor (3d): {int(fv)} {direction}")
            else:
                reasons.append(f"{label}: {fv:.1f} {direction}")
        else:
            reasons.append(f"{label} {direction}")

    return " | ".join(reasons) if reasons else ""


def run_predictions(db_path: Path, scoreboard: dict,
                    model_dir: Path = None) -> dict:
    """Run YI predictions and enrich scoreboard with ML-based reasons.

    Args:
        db_path: Path to DuckDB file.
        scoreboard: Scoreboard dict from _build_scoreboard.
        model_dir: Directory containing yi_model.pkl. Defaults to db parent / ml_models.

    Returns:
        Updated scoreboard dict with _ml_yi_prob and _ml_neden fields.
    """
    db_path = Path(db_path)
    if model_dir is None:
        model_dir = db_path.parent.parent / "ml_models"

    artifacts = _load_model(model_dir)
    if artifacts is None:
        print("  [ML] No trained model found, skipping predictions")
        return scoreboard

    model = artifacts["model"]
    explainer = artifacts.get("explainer")
    metrics = artifacts.get("metrics", {})

    print(f"  [ML] Model loaded (AUC: {metrics.get('auc', '?'):.4f})")

    # Build features for current data
    print("  [ML] Building features for prediction...")
    df = build_features(db_path)

    if df.empty:
        print("  [ML] No data for prediction")
        return scoreboard

    # Only predict on the latest period
    son_donem = scoreboard.get("meta", {}).get("son_donem")
    if not son_donem:
        donemler = scoreboard.get("meta", {}).get("donemler", [])
        son_donem = donemler[-1] if donemler else None

    if son_donem:
        df_pred = df[df["donem"] == son_donem].copy()
    else:
        df_pred = df.copy()

    if df_pred.empty:
        print("  [ML] No data for latest period")
        return scoreboard

    X = df_pred[FEATURE_COLS].fillna(-999)

    # Predict probabilities
    probs = model.predict_proba(X)[:, 1]
    df_pred = df_pred.copy()
    df_pred["yi_prob"] = probs

    # SHAP explanations
    reasons = {}
    if explainer is not None and HAS_SHAP:
        print("  [ML] Generating SHAP explanations...")
        import warnings
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message="LightGBM binary classifier")
            shap_values = explainer.shap_values(X)
        # LightGBM binary classifier: shap_values may be a list [class0, class1]
        if isinstance(shap_values, list):
            shap_values = shap_values[1]  # positive class

        for idx in range(len(df_pred)):
            eid = df_pred.iloc[idx]["entity_id"]
            sv = shap_values[idx]
            fv = X.iloc[idx]
            reason = _generate_reason(sv, fv, top_n=3)
            reasons[str(eid)] = reason
    else:
        print("  [ML] No SHAP explainer, using probability-only reasons")
        for idx in range(len(df_pred)):
            eid = df_pred.iloc[idx]["entity_id"]
            prob = probs[idx]
            reasons[str(eid)] = f"YI olasılığı: %{prob*100:.0f}"

    # Build probability lookup (vectorized)
    prob_map = dict(zip(
        df_pred["entity_id"].astype(str),
        df_pred["yi_prob"].round(4).astype(float)
    ))

    # Enrich scoreboard rows
    n_enriched = 0
    for row in scoreboard.get("rows", []):
        m = str(row.get("muta", ""))
        prob = prob_map.get(m)
        if prob is not None:
            row["_ml_yi_prob"] = prob
            # ML reason: merge with existing rule-based reason
            ml_reason = reasons.get(m, "")
            existing = row.get("_ews_neden", "")
            if ml_reason:
                if existing:
                    row["_ews_neden"] = f"{existing} | {ml_reason}"
                else:
                    row["_ews_neden"] = ml_reason
            n_enriched += 1

    print(f"  [ML] Enriched {n_enriched} entities "
          f"(mean prob: {np.mean(list(prob_map.values())):.3f}, "
          f"max: {np.max(list(prob_map.values())):.3f})")

    # Print high-risk summary
    high_risk = [(m, p) for m, p in prob_map.items() if p >= 0.5]
    high_risk.sort(key=lambda x: x[1], reverse=True)
    if high_risk:
        print(f"  [ML] High YI probability (>=50%): {len(high_risk)} entities")
        for m, p in high_risk[:5]:
            reason = reasons.get(m, "")
            print(f"    {m}: {p:.1%} — {reason[:80]}")

    return scoreboard
