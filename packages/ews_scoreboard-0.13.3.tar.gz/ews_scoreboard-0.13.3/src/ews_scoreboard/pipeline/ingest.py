"""
Ingest: source files → DuckDB bronze tables.

Handles cp1254 decoding, dynamic column matching, MUTA normalization.
Supports Access DB (.mdb/.accdb) via access-parser.
"""

import re
from pathlib import Path

import duckdb
import pandas as pd
import numpy as np

from ews_scoreboard.paths import get_ddl_path


def _normalize_muta(series: pd.Series) -> pd.Series:
    """MUTA normalize: str → numeric → int → str, drop NaN."""
    cleaned = series.astype(str).str.strip()
    cleaned = cleaned.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA, "NaN": pd.NA, "<NA>": pd.NA})
    s = pd.to_numeric(cleaned, errors="coerce")
    return s.dropna().astype(int).astype(str)


def _clean_str_col(series: pd.Series) -> pd.Series:
    """Clean string column: strip whitespace, convert empty/nan/None → proper NaN."""
    s = series.astype(str).str.strip()
    s = s.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA, "NaN": pd.NA, "<NA>": pd.NA, "NaT": pd.NA})
    return s


def _find_skor_col(columns, prefix=""):
    """Find score column dynamically (may be 'skor', 'yis_skor', 'eus_skor', etc)."""
    for c in columns:
        if "skor" in c.lower():
            return c
    return None


def _find_ihtimal_col(columns):
    for c in columns:
        if "ihtimal" in c.lower():
            return c
    return None


def read_access_table(db_path: Path, table_name: str) -> pd.DataFrame:
    """Read a table from Access DB (.mdb/.accdb) → pandas DataFrame.

    Args:
        db_path: Path to .mdb or .accdb file.
        table_name: Table name in the Access DB.

    Returns:
        DataFrame with the table contents.
    """
    from access_parser import AccessParser
    db = AccessParser(str(db_path))
    parsed = db.parse_table(table_name)
    return pd.DataFrame(dict(parsed))


def list_access_tables(db_path: Path) -> list:
    """List table names in an Access DB."""
    from access_parser import AccessParser
    db = AccessParser(str(db_path))
    return list(db.catalog.keys())


def _execute_sql_file(con, sql_path: Path):
    """Execute a SQL file, splitting on semicolons and stripping comments."""
    text = sql_path.read_text(encoding="utf-8")
    lines = [l for l in text.split("\n") if not l.strip().startswith("--")]
    clean = "\n".join(lines)
    for stmt in clean.split(";"):
        stmt = stmt.strip()
        if stmt:
            try:
                con.execute(stmt)
            except Exception:
                pass  # table/index already exists


def _create_bronze_tables(con):
    """Create all tables from DDL files."""
    ddl_dir = get_ddl_path()
    for sql_file in sorted(ddl_dir.glob("*.sql")):
        _execute_sql_file(con, sql_file)


def _filter_mutas(df: pd.DataFrame, muta_filter: set = None) -> pd.DataFrame:
    """Filter DataFrame to only include rows with MUTAs in the filter set."""
    if muta_filter is None:
        return df
    return df[df["muta"].isin(muta_filter)].copy()


def _ingest_kik_izleme(con, kik_dir: Path, muta_filter: set = None):
    """Ingest KIK İzleme Kriterleri CSV files → brz_kik_izleme."""
    if not kik_dir.exists():
        print("  [SKIP] kik_data_ham_csv not found")
        return

    unvan_candidates = ["Must Ad", "Cari Hesap Adı", "Cari Hesap Adi", "UNVAN", "Unvan"]
    total = 0

    for fpath in sorted(kik_dir.glob("*.csv")):
        fname = fpath.name
        if "Kurumsal" not in fname:
            continue

        m = re.search(r"20(\d{4})02", fname)
        if not m:
            continue
        donem = m.group(1)

        try:
            df = pd.read_csv(fpath, sep=";", encoding="cp1254", dtype=str)
        except Exception:
            df = pd.read_csv(fpath, sep=None, engine="python", encoding="cp1254", dtype=str)

        if "Must No" not in df.columns:
            continue

        df["muta"] = _normalize_muta(df["Must No"])
        df = df[df["muta"].notna()].copy()
        df = _filter_mutas(df, muta_filter)
        df["donem"] = donem

        unvan_col = None
        for uc in unvan_candidates:
            if uc in df.columns:
                unvan_col = uc
                break
        df["unvan"] = _clean_str_col(df[unvan_col]) if unvan_col else None

        df["ykn_izl_flag"] = _clean_str_col(df.get("Ykn Izl Flag", pd.Series(dtype=str)))
        df["tfrs_rating"] = _clean_str_col(df.get("Rtng Kod", pd.Series(dtype=str)))
        df["rating_tarihi"] = _clean_str_col(df.get("Rating Tar", pd.Series(dtype=str)))

        risk_raw = df.get("Risk Bky Tl", pd.Series(dtype=str))
        if risk_raw is not None and len(risk_raw) > 0:
            risk_clean = risk_raw.astype(str).str.replace(".", "", regex=False).str.replace(",", ".", regex=False)
            df["kik_risk"] = pd.to_numeric(risk_clean, errors="coerce").round(0).astype("Int64")
        else:
            df["kik_risk"] = pd.array([pd.NA] * len(df), dtype="Int64")

        # New columns for EUS kapsam pipeline
        ggs_raw = df.get("Gckm Gun Say", df.get("Gckm_Gun_Say", pd.Series(dtype=str)))
        df["gckm_gun_say"] = pd.to_numeric(ggs_raw, errors="coerce").fillna(0).astype("Int64")

        df["erkn_izlm_kod"] = _clean_str_col(df.get("Erkn Izlm Kod", df.get("Erkn_Izlm_Kod", pd.Series(dtype=str))))

        # CISS aggregate: any CISS column != 0 → ciss_flag=1
        ciss_cols = [c for c in df.columns if c.upper().startswith("CISS")]
        if ciss_cols:
            ciss_vals = df[ciss_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
            df["ciss_flag"] = (ciss_vals.ne(0).any(axis=1)).astype(int)
        else:
            df["ciss_flag"] = 0

        out = df[["muta", "donem", "ykn_izl_flag", "tfrs_rating", "rating_tarihi",
                   "kik_risk", "unvan", "gckm_gun_say", "erkn_izlm_kod", "ciss_flag"]].copy()
        con.execute("INSERT INTO brz_kik_izleme SELECT * FROM out")
        total += len(out)

    print(f"  brz_kik_izleme: {total} rows")


def _ingest_kredi_risk(con, kredi_dir: Path, muta_filter: set = None):
    """Ingest kredi risk parquet → brz_kredi_risk."""
    if not kredi_dir.exists():
        print("  [SKIP] kredi_db not found")
        return

    total = 0
    for fpath in sorted(kredi_dir.glob("kurumsal_risk_*.parquet")):
        donem = fpath.stem.replace("kurumsal_risk_", "")
        df = pd.read_parquet(fpath)
        df["muta"] = _normalize_muta(df["MUTA"])
        df = df[df["muta"].notna()].copy()
        df = _filter_mutas(df, muta_filter)
        df["donem"] = donem
        df["kredi_risk"] = pd.to_numeric(df["Risk_Bky_Tl"], errors="coerce")
        df["kredi_risk"] = df["kredi_risk"].where(df["kredi_risk"].notna()).round(0).astype("Int64")
        out = df[["muta", "donem", "kredi_risk"]].copy()
        con.execute("INSERT INTO brz_kredi_risk SELECT * FROM out")
        total += len(out)

    print(f"  brz_kredi_risk: {total} rows")


def _ingest_yis_tahmin(con, yis_dir: Path, muta_filter: set = None):
    """Ingest YIS prediction CSV → brz_yis_tahmin."""
    if not yis_dir.exists():
        print("  [SKIP] yis_tahmin_data not found")
        return

    total = 0
    for fpath in sorted(yis_dir.glob("*_pred_n_scor.csv")):
        parts = fpath.stem.split("_")
        donem = parts[0][2:] + parts[1]

        df = pd.read_csv(fpath, dtype={"MUTA": str})
        df["muta"] = df["MUTA"].astype(str).str.strip()
        df = _filter_mutas(df, muta_filter)
        df["donem"] = donem

        skor_col = _find_skor_col(df.columns)
        if skor_col:
            df["yis_skor"] = pd.to_numeric(df[skor_col], errors="coerce").round(0).astype("Int64")
        else:
            df["yis_skor"] = pd.array([pd.NA] * len(df), dtype="Int64")

        ihtimal_col = _find_ihtimal_col(df.columns)
        df["yis_ihtimal"] = pd.to_numeric(df[ihtimal_col], errors="coerce") if ihtimal_col else np.nan

        label_raw = df.get("label", pd.Series([0] * len(df)))
        df["yis_label"] = pd.to_numeric(label_raw, errors="coerce").fillna(0).astype(int)

        out = df[["muta", "donem", "yis_skor", "yis_ihtimal", "yis_label"]].copy()
        con.execute("INSERT INTO brz_yis_tahmin SELECT * FROM out")
        total += len(out)

    print(f"  brz_yis_tahmin: {total} rows")


def _ingest_eus_tahmin(con, eus_dir: Path, muta_filter: set = None):
    """Ingest EUS prediction CSV → brz_eus_tahmin."""
    if not eus_dir.exists():
        print("  [SKIP] eus_tahmin_data not found")
        return

    total = 0
    for fpath in sorted(eus_dir.glob("*_pred_n_scor.csv")):
        parts = fpath.stem.split("_")
        donem = parts[0][2:] + parts[1]

        df = pd.read_csv(fpath, dtype={"MUTA": str})
        df["muta"] = df["MUTA"].astype(str).str.strip()
        df = _filter_mutas(df, muta_filter)
        df["donem"] = donem

        skor_col = _find_skor_col(df.columns)
        df["eus_skor"] = pd.to_numeric(df[skor_col], errors="coerce").round(2) if skor_col else np.nan

        ihtimal_col = _find_ihtimal_col(df.columns)
        df["eus_ihtimal"] = pd.to_numeric(df[ihtimal_col], errors="coerce") if ihtimal_col else np.nan

        out = df[["muta", "donem", "eus_skor", "eus_ihtimal"]].copy()
        con.execute("INSERT INTO brz_eus_tahmin SELECT * FROM out")
        total += len(out)

    print(f"  brz_eus_tahmin: {total} rows")


def _ingest_eus_hedef(con, hedef_dir: Path, muta_filter: set = None):
    """Ingest EUS hedef MUTA lists → brz_eus_hedef."""
    if not hedef_dir.exists():
        print("  [SKIP] eus_hedef_muta not found")
        return

    total = 0
    for fpath in sorted(hedef_dir.glob("eus_hedef_MUTA_*.csv")):
        m = re.search(r"(\d{4})\.csv$", fpath.name)
        if not m:
            continue
        donem = m.group(1)

        df = pd.read_csv(fpath, dtype=str, header=0)
        if df.empty:
            continue
        col = df.columns[0]
        df["muta"] = df[col].astype(str).str.strip()
        df = _filter_mutas(df, muta_filter)
        df["donem"] = donem
        df = df[df["muta"].notna() & (df["muta"] != "") & (df["muta"] != "nan")]
        out = df[["muta", "donem"]].copy()
        if not out.empty:
            con.execute("INSERT INTO brz_eus_hedef SELECT * FROM out")
            total += len(out)

    print(f"  brz_eus_hedef: {total} rows")


def _ingest_eus_kapsam(con, kapsam_dir: Path, muta_filter: set = None):
    """Ingest EUS kapsam MUTA lists → brz_eus_kapsam."""
    if not kapsam_dir.exists():
        print("  [SKIP] eus_sql_kapsam_muta not found")
        return

    total = 0
    for fpath in sorted(kapsam_dir.glob("eus_kapsam_MUTA_*.csv")):
        m = re.search(r"(\d{4})\.csv$", fpath.name)
        if not m:
            continue
        donem = m.group(1)

        df = pd.read_csv(fpath, dtype=str, header=0)
        if df.empty:
            continue
        col = df.columns[0]
        df["muta"] = df[col].astype(str).str.strip()
        df = _filter_mutas(df, muta_filter)
        df["donem"] = donem
        df = df[df["muta"].notna() & (df["muta"] != "") & (df["muta"] != "nan")]
        out = df[["muta", "donem"]].copy()
        if not out.empty:
            con.execute("INSERT INTO brz_eus_kapsam SELECT * FROM out")
            total += len(out)

    print(f"  brz_eus_kapsam: {total} rows")


def _ingest_statik(con, statik_dir: Path, muta_filter: set = None):
    """Ingest statik bilgiler → brz_statik."""
    if not statik_dir.exists():
        print("  [SKIP] statik_db not found")
        return

    for fpath in sorted(statik_dir.glob("statik_bilgiler_*.txt")):
        df = pd.read_csv(fpath, sep=";", encoding="cp1254", dtype=str, header=0)

        cols = df.columns.tolist()
        rename_map = {}
        pos_names = ["muta", "bolge_kodu", "bolge_adi", "sube_kodu", "sube_adi",
                      "must_tip_kodu", "grup_kodu", "grup_tanimi",
                      "firma_otorize_kodu", "aksiyon_sahibi", "kri_bolum"]
        for i, name in enumerate(pos_names):
            if i < len(cols):
                rename_map[cols[i]] = name
        df = df.rename(columns=rename_map)

        df["muta"] = _normalize_muta(df["muta"])
        df = df[df["muta"].notna()].copy()
        df = _filter_mutas(df, muta_filter)
        df = df.drop_duplicates(subset=["muta"])

        if "bolge_kodu" in df.columns:
            df["bolge_kodu"] = df["bolge_kodu"].astype(str).str.split(",").str[0]
            df["bolge_kodu"] = pd.to_numeric(df["bolge_kodu"], errors="coerce").astype("Int64")
        if "sube_kodu" in df.columns:
            df["sube_kodu"] = pd.to_numeric(df["sube_kodu"], errors="coerce").astype("Int64")

        out = df[pos_names].copy()
        con.execute("INSERT INTO brz_statik SELECT * FROM out")
        print(f"  brz_statik: {len(out)} rows")
        return


def _ingest_rkd_kriter(con, rkd_dir: Path, muta_filter: set = None):
    """Ingest RKD kriter parquet → brz_rkd_kriter (aggregated)."""
    if not rkd_dir.exists():
        print("  [SKIP] rkd_donem_data not found")
        return

    # Suffix classification
    UZAK_SUFFIXES = ("_PIGD", "_PSCD")
    SIFIR_SUFFIXES = ("_A", "_ASGD", "_AIGD")

    total = 0
    for fpath in sorted(rkd_dir.glob("rkd_data_*.parquet")):
        m = re.search(r"rkd_data_(\d{4})\.parquet$", fpath.name)
        if not m:
            continue
        donem = m.group(1)

        df = pd.read_parquet(fpath)
        muta_col = "MUTA" if "MUTA" in df.columns else "muta"
        df["muta"] = _normalize_muta(df[muta_col])
        df = df[df["muta"].notna()].copy()
        df = _filter_mutas(df, muta_filter)

        if df.empty:
            continue

        # Identify kriter columns
        kriter_cols = [c for c in df.columns if c != muta_col and c != "muta"]
        uzak_cols = [c for c in kriter_cols if any(c.endswith(s) for s in UZAK_SUFFIXES)]
        sifir_cols = [c for c in kriter_cols if any(c.endswith(s) for s in SIFIR_SUFFIXES)]

        # Aggregate: min_uzak_gun = MIN of uzak columns
        if uzak_cols:
            uzak_vals = df[uzak_cols].apply(pd.to_numeric, errors="coerce")
            df["min_uzak_gun"] = uzak_vals.min(axis=1).astype("Int64")
        else:
            df["min_uzak_gun"] = pd.array([pd.NA] * len(df), dtype="Int64")

        # Aggregate: sifir_flag = any sifir column != 0
        if sifir_cols:
            sifir_vals = df[sifir_cols].apply(pd.to_numeric, errors="coerce").fillna(0)
            df["sifir_flag"] = (sifir_vals.ne(0).any(axis=1)).astype(int)
        else:
            df["sifir_flag"] = 0

        df["donem"] = donem
        out = df[["muta", "donem", "min_uzak_gun", "sifir_flag"]].copy()
        con.execute("INSERT INTO brz_rkd_kriter SELECT * FROM out")
        total += len(out)

    print(f"  brz_rkd_kriter: {total} rows")


def _ingest_memzuc(con, memzuc_dir: Path, muta_filter: set = None):
    """Ingest memzuc parquet → brz_memzuc."""
    if not memzuc_dir.exists():
        print("  [SKIP] memzuc_data_donem not found")
        return

    total = 0
    for fpath in sorted(memzuc_dir.glob("memzuc_*.parquet")):
        m = re.search(r"memzuc_(\d{4})\.parquet$", fpath.name)
        if not m:
            continue
        donem = m.group(1)

        df = pd.read_parquet(fpath)
        muta_col = "MUTA" if "MUTA" in df.columns else "muta"
        df["muta"] = _normalize_muta(df[muta_col])
        df = df[df["muta"].notna()].copy()
        df = _filter_mutas(df, muta_filter)

        if df.empty:
            continue

        df["donem"] = donem

        # Find idari_kanuni_takip column
        ikt_col = None
        for c in df.columns:
            if "idari" in c.lower() and "takip" in c.lower():
                ikt_col = c
                break
        df["idari_kanuni_takip"] = pd.to_numeric(df[ikt_col], errors="coerce").fillna(0) if ikt_col else 0.0

        # Find ikt_6ay_ort column
        ort_col = None
        for c in df.columns:
            if "6ay" in c.lower() or "ort" in c.lower():
                ort_col = c
                break
        df["ikt_6ay_ort"] = pd.to_numeric(df[ort_col], errors="coerce").fillna(0) if ort_col else 0.0

        out = df[["muta", "donem", "idari_kanuni_takip", "ikt_6ay_ort"]].copy()
        con.execute("INSERT INTO brz_memzuc SELECT * FROM out")
        total += len(out)

    print(f"  brz_memzuc: {total} rows")


def _ingest_train_features(con, train_dir: Path, muta_filter: set = None):
    """Ingest training parquet → brz_train_features (segment extraction)."""
    if not train_dir.exists():
        print("  [SKIP] yis_train_data not found")
        return

    SGMNT_MAP = {
        "Sgmnt_Kod_ESKK": "ESKK",
        "Sgmnt_Kod_KOBI": "KOBI",
        "Sgmnt_Kod_KUR-TIC": "KUR-TIC",
        "Sgmnt_Kod_MIKRO": "MIKRO",
    }

    files = sorted(train_dir.glob("yis_21_v21_*.parquet"))
    if not files:
        print("  [SKIP] no training parquets")
        return

    last_file = files[-1]
    m = re.search(r"_(\d{4})\.parquet$", last_file.name)
    donem = m.group(1) if m else "0000"

    df = pd.read_parquet(last_file)
    df["muta"] = df["MUTA"].astype(str).str.strip()
    df = _filter_mutas(df, muta_filter)

    sgmnt_cols = [c for c in df.columns if c.startswith("Sgmnt_Kod_")]

    def get_segment(row):
        for col in sgmnt_cols:
            val = row.get(col)
            if val in (True, 1, "True", "1", "1.0"):
                return SGMNT_MAP.get(col, col)
        return None

    df["segment"] = df.apply(get_segment, axis=1) if sgmnt_cols else None
    df["donem"] = donem

    out = df[["muta", "donem", "segment"]].copy()
    con.execute("INSERT INTO brz_train_features SELECT * FROM out")
    print(f"  brz_train_features: {len(out)} rows (from {last_file.name})")


def _next_donem(d: str) -> str:
    """YYMM → next month. '2512' → '2601'."""
    yy, mm = int(d[:2]), int(d[2:])
    mm += 1
    if mm > 12:
        mm = 1
        yy += 1
    return f"{yy:02d}{mm:02d}"


def patch_eus_gaps(db_path: Path):
    """Patch single-period gaps in brz_eus_tahmin by interpolation.

    For each muta: if period N-1 and N+1 have eus_skor but N doesn't,
    insert a new row for N with eus_skor = avg(N-1, N+1).
    Does NOT modify existing rows — only inserts new ones.

    Uses calendar-based period sequence (YYMM), not just existing periods.
    This correctly handles entirely missing periods (e.g., 2507 doesn't
    exist at all in the table).
    """
    con = duckdb.connect(str(db_path))

    # Build full calendar from min to max period
    min_d = con.execute("SELECT MIN(donem) FROM brz_eus_tahmin").fetchone()[0]
    max_d = con.execute("SELECT MAX(donem) FROM brz_eus_tahmin").fetchone()[0]

    if not min_d or not max_d:
        print("  [SKIP] patch_eus_gaps: empty table")
        con.close()
        return

    # Generate full YYMM calendar
    calendar = []
    d = min_d
    while d <= max_d:
        calendar.append(d)
        d = _next_donem(d)

    if len(calendar) < 3:
        print("  [SKIP] patch_eus_gaps: <3 calendar periods")
        con.close()
        return

    # Load all EUS data into pandas (muta, donem, eus_skor, eus_ihtimal)
    eus = con.execute(
        "SELECT muta, donem, eus_skor, eus_ihtimal FROM brz_eus_tahmin"
    ).fetchdf()

    # Create lookup: (muta, donem) → (eus_skor, eus_ihtimal)
    eus_lookup = {}
    for _, row in eus.iterrows():
        eus_lookup[(row["muta"], row["donem"])] = (row["eus_skor"], row["eus_ihtimal"])

    # Find single-period gaps
    rows = []
    for i in range(1, len(calendar) - 1):
        prev_d = calendar[i - 1]
        gap_d = calendar[i]
        next_d = calendar[i + 1]

        # Find mutas that have prev and next but not gap
        prev_mutas = {m for (m, d) in eus_lookup if d == prev_d}
        next_mutas = {m for (m, d) in eus_lookup if d == next_d}
        gap_mutas = {m for (m, d) in eus_lookup if d == gap_d}

        candidates = (prev_mutas & next_mutas) - gap_mutas

        for muta in candidates:
            prev_skor, prev_iht = eus_lookup[(muta, prev_d)]
            next_skor, next_iht = eus_lookup[(muta, next_d)]

            avg_skor = round((prev_skor + next_skor) / 2, 2)
            avg_iht = None
            if pd.notna(prev_iht) and pd.notna(next_iht):
                avg_iht = round((prev_iht + next_iht) / 2, 4)

            rows.append({
                "muta": muta,
                "donem": gap_d,
                "eus_skor": avg_skor,
                "eus_ihtimal": avg_iht,
            })

    if not rows:
        print("  patch_eus_gaps: 0 single-period gaps found")
        con.close()
        return

    patch_df = pd.DataFrame(rows)
    con.register("_patch_df", patch_df)
    con.execute("INSERT INTO brz_eus_tahmin SELECT * FROM _patch_df")
    con.unregister("_patch_df")

    # Report per-period breakdown
    period_counts = patch_df.groupby("donem").size()
    print(f"  patch_eus_gaps: {len(patch_df)} rows inserted "
          f"({patch_df['donem'].nunique()} periods, "
          f"{patch_df['muta'].nunique()} firms)")
    for d, cnt in period_counts.items():
        print(f"    {d}: {cnt} firms patched")

    con.close()


def _resolve_dir(source_dir: Path, subdir: str, data_paths: dict) -> Path:
    """Resolve a data directory: use data_paths override if present, else source_dir/subdir."""
    if subdir in data_paths:
        return Path(data_paths[subdir])
    return source_dir / subdir


def run_ingest(source_dir: Path, db_path: Path, data_paths: dict = None,
               muta_filter: set = None):
    """Run full ingest pipeline.

    Args:
        source_dir: Default base directory for data subdirs.
        db_path: Path to DuckDB database file.
        data_paths: Optional dict mapping subdir names to actual paths,
                    e.g. {"kredi_db": "/mnt/z/ai/kredi", "statik_db": "/mnt/z/statik"}.
                    Keys not present fall back to source_dir/subdir.
        muta_filter: Optional set of MUTA strings to keep (test mode).
    """
    if data_paths is None:
        data_paths = {}

    if db_path.exists():
        db_path.unlink()

    con = duckdb.connect(str(db_path))
    _create_bronze_tables(con)

    mf = muta_filter
    dp = data_paths
    sd = source_dir
    _ingest_kik_izleme(con,      _resolve_dir(sd, "kik_data_ham_csv", dp), mf)
    _ingest_kredi_risk(con,      _resolve_dir(sd, "kredi_db", dp), mf)
    _ingest_yis_tahmin(con,      _resolve_dir(sd, "yis_tahmin_data", dp), mf)
    _ingest_eus_tahmin(con,      _resolve_dir(sd, "eus_tahmin_data", dp), mf)
    _ingest_eus_hedef(con,       _resolve_dir(sd, "eus_hedef_muta", dp), mf)
    _ingest_eus_kapsam(con,      _resolve_dir(sd, "eus_sql_kapsam_muta", dp), mf)
    _ingest_statik(con,          _resolve_dir(sd, "statik_db", dp), mf)
    _ingest_train_features(con,  _resolve_dir(sd, "yis_train_data", dp), mf)
    _ingest_rkd_kriter(con,      _resolve_dir(sd, "rkd_donem_data", dp), mf)
    _ingest_memzuc(con,          _resolve_dir(sd, "memzuc_data_donem", dp), mf)

    tables = con.execute("SHOW TABLES").fetchall()
    print(f"\n  Bronze tables: {len(tables)}")
    for (t,) in tables:
        cnt = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        if cnt > 0:
            print(f"    {t}: {cnt}")

    con.close()

    # Patch single-period gaps in EUS predictions
    patch_eus_gaps(db_path)
