from setuptools import setup, find_packages

setup(
    name="InvestimentosPy", # ESCOLHA UM NOME ÚNICO AQUI
    version="0.1.0",
    author="Pedro R Rogala",
    description="Uma biblioteca para cálculos financeiros básicos",
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    packages=find_packages(),
    python_requires=">=3.6",
)
