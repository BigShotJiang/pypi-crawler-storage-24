
import unittest
from investimentos.investimentos import calcular_juros_compostos

class TestInvestimentos(unittest.TestCase):
    def test_juros_compostos(self):
        # R$ 1000 a 10% por 2 anos deve dar 1210
        resultado = calcular_juros_compostos(1000, 0.10, 2)
        self.assertEqual(resultado, 1210.0)

if __name__ == '__main__':
    unittest.main()
