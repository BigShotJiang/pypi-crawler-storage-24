from pydantic import BaseModel


class Conversation(BaseModel, frozen=True):
    id: str
    name: str
    model: str
    latest_response_datetime_utc: str | None = None


class ConversationListResponse(BaseModel, frozen=True):
    conversations: list[Conversation]


class Message(BaseModel, frozen=True):
    id: str
    conversation_id: str
    content: str


class ToolCallItem(BaseModel, frozen=True):
    name: str
    arguments: str
    tool_call_id: str


class ToolResultItem(BaseModel, frozen=True):
    name: str
    output: str
    tool_call_id: str


class ResponseItem(BaseModel, frozen=True):
    id: str
    model: str
    prompt: str | None
    system: str | None
    response: str
    conversation_id: str
    datetime_utc: str
    duration_ms: int | None
    input_tokens: int | None
    output_tokens: int | None


class ResponseListResponse(BaseModel, frozen=True):
    responses: list[ResponseItem]


class ModelInfo(BaseModel, frozen=True):
    model_id: str


class ModelListResponse(BaseModel, frozen=True):
    models: list[ModelInfo]


class ToolInfo(BaseModel, frozen=True):
    tool_name: str


class ToolListResponse(BaseModel, frozen=True):
    tools: list[ToolInfo]


class CreateConversationRequest(BaseModel, frozen=True):
    name: str
    model: str


class CreateConversationResponse(BaseModel, frozen=True):
    id: str


class SendMessageRequest(BaseModel, frozen=True):
    message: str
    model: str
    system_prompt: str | None = None
    tools: list[str] = []


class SendMessageResponse(BaseModel, frozen=True):
    status: str


class ErrorResponse(BaseModel, frozen=True):
    detail: str
