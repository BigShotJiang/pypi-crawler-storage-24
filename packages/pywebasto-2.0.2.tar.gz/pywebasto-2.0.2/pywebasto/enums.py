"""Enum classes."""

from enum import Enum


class Request(Enum):
    """Requests options."""

    LOGIN = "/login"
    COMMAND = "/command"
    GET_DATA = "/get_service_data?poll=true"
    GET_DATA_NOPOLL = "/get_service_data?poll=false"
    POST_SETTING = "/post_settings"
    SAVE_TIMERS = "/save_timers"
    GET_SETTINGS = "/get_settings"
    CHANGE_DEVICE = "/change_device"


class Outputs(Enum):
    """Valid Webasto outputs."""

    HEATER = "OUTH"
    VENTILATION = "OUTV"
    AUX1 = "OUT1"
    AUX2 = "OUT2"
