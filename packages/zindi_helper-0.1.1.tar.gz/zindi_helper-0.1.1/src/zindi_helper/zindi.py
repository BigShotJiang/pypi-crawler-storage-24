from __future__ import annotations

from dataclasses import dataclass, field
from html import unescape
from pathlib import Path
import re
from typing import Any
import zipfile

import requests
from rich.console import Console
from rich.progress import track

from .config import load_credentials

BASE_URL = "https://api.zindi.africa/v1"


@dataclass
class ZindiClient:
    email: str
    password: str
    auth_token: str = ""
    _session: requests.Session = field(default_factory=requests.Session, repr=False)

    @classmethod
    def from_credentials(cls, config_path: Path | None = None) -> ZindiClient:
        email, password = load_credentials(config_path)
        return cls(email=email, password=password)

    def _auth_headers(self) -> dict[str, str]:
        return {"auth-token": self.auth_token}

    def login(self) -> str:
        resp = self._session.post(
            f"{BASE_URL}/auth/signin",
            json={"username": self.email, "password": self.password},
        )
        resp.raise_for_status()
        self.auth_token = resp.json()["data"]["auth_token"]
        return self.auth_token

    def get_competition(self, slug: str) -> dict[str, Any]:
        resp = self._session.get(f"{BASE_URL}/competitions/{slug}")
        resp.raise_for_status()
        return resp.json()["data"]

    def join_competition(self, slug: str) -> None:
        resp = self._session.post(
            f"{BASE_URL}/competitions/{slug}/participations",
            headers=self._auth_headers(),
        )
        if resp.status_code not in (200, 201, 422):
            resp.raise_for_status()

    def download_file(self, slug: str, filename: str, dest: Path) -> Path:
        resp = self._session.get(
            f"{BASE_URL}/competitions/{slug}/files/{filename}",
            headers=self._auth_headers(),
            stream=True,
        )
        resp.raise_for_status()
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "wb") as file_obj:
            for chunk in resp.iter_content(chunk_size=8192):
                file_obj.write(chunk)
        return dest


def extract_slug(url: str) -> str:
    """Extract competition slug from a Zindi URL or pass through if already a slug."""
    match = re.search(r"zindi\.africa/competitions/([^/?#]+)", url)
    return match.group(1) if match else url.strip("/").split("/")[-1]


def _strip_html(html: str) -> str:
    """Rough HTML-to-plaintext conversion."""
    text = re.sub(r"<br\s*/?>", "\n", html)
    text = re.sub(r"<li>", "- ", text)
    text = re.sub(r"</?(ul|ol|p|div|h[1-6]|span|pre|a|code)[^>]*>", "\n", text)
    text = re.sub(r"<[^>]+>", "", text)
    text = unescape(text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _blocks_to_text(blocks: list[dict[str, Any]]) -> str:
    """Convert Draft.js content blocks to plaintext."""
    lines: list[str] = []
    for block in blocks:
        text = block.get("text", "").strip()
        if not text:
            continue
        block_type = block.get("type", "")
        if block_type.startswith("header"):
            lines.append(f"## {text}")
        elif block_type == "unordered-list-item":
            lines.append(f"- {text}")
        else:
            lines.append(text)
    return "\n".join(lines).strip()


def build_raw_competition_markdown(comp: dict[str, Any]) -> str:
    """Render the competition metadata into markdown."""
    title = comp.get("title", "Competition")
    slug = comp.get("id", "")
    sections: list[str] = [f"# {title}"]

    summary_lines: list[str] = []
    if slug:
        summary_lines.append(f"- Slug: `{slug}`")
    if comp.get("error_metric"):
        summary_lines.append(f"- Evaluation metric: {comp['error_metric']}")
    if comp.get("benchmark_submission_public_score") is not None:
        summary_lines.append(
            f"- Benchmark public score: {comp['benchmark_submission_public_score']}"
        )
    if comp.get("end_time"):
        summary_lines.append(f"- Deadline: {comp['end_time']}")
    if comp.get("type_of_problem"):
        summary_lines.append(
            f"- Problem type: {', '.join(comp.get('type_of_problem', []))}"
        )
    if comp.get("skills"):
        summary_lines.append(f"- Skills: {', '.join(comp.get('skills', []))}")
    if summary_lines:
        sections.append("## Summary\n\n" + "\n".join(summary_lines))

    for page in comp.get("pages", []):
        page_title = (page.get("title") or "").strip()
        content_html = page.get("content_html") or ""
        if not page_title or not content_html:
            continue
        sections.append(f"## {page_title}\n\n{_strip_html(content_html)}")

    rules_blocks = comp.get("rules", {}).get("content", {}).get("blocks", [])
    rules_text = _blocks_to_text(rules_blocks)
    if rules_text:
        sections.append(f"## Rules\n\n{rules_text}")

    datafiles = comp.get("datafiles", [])
    if datafiles:
        file_lines: list[str] = []
        for datafile in datafiles:
            if datafile.get("zip_of_everything"):
                continue
            filename = datafile.get("filename", "unknown")
            size_bytes = datafile.get("filesize") or 0
            size_mb = size_bytes / (1024 * 1024) if size_bytes else 0
            description = (datafile.get("description") or "").strip()
            size_part = f" ({size_mb:.1f} MB)" if size_mb else ""
            if description:
                file_lines.append(f"- `{filename}`{size_part}: {description}")
            else:
                file_lines.append(f"- `{filename}`{size_part}")
        if file_lines:
            sections.append("## Data files\n\n" + "\n".join(file_lines))

    return "\n\n".join(sections).strip() + "\n"


def fetch_competition(client: ZindiClient, competition: str) -> tuple[str, dict[str, Any]]:
    """Fetch competition metadata by URL or slug."""
    slug = extract_slug(competition)
    return slug, client.get_competition(slug)


def download_competition_data(
    client: ZindiClient,
    slug: str,
    comp: dict[str, Any],
    output_dir: Path,
    console: Console,
) -> list[Path]:
    """Download all competition files into the target directory."""
    output_dir.mkdir(parents=True, exist_ok=True)
    downloaded_paths: list[Path] = []
    datafiles = [
        datafile
        for datafile in comp.get("datafiles", [])
        if datafile.get("filename") and not datafile.get("zip_of_everything")
    ]

    for datafile in track(datafiles, description="Downloading files..."):
        filename = datafile.get("filename", "")
        dest = output_dir / filename
        if dest.exists():
            console.print(f"[yellow]Skipping existing file:[/] {dest}")
            downloaded_paths.append(dest)
            continue

        console.print(f"[cyan]Downloading:[/] {filename}")
        client.download_file(slug, filename, dest)
        downloaded_paths.append(dest)

        if dest.suffix.lower() == ".zip":
            console.print(f"[magenta]Extracting:[/] {dest.name}")
            with zipfile.ZipFile(dest) as zip_file:
                zip_file.extractall(output_dir)

    return downloaded_paths
