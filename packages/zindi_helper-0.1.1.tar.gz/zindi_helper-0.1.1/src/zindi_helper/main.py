from __future__ import annotations

from pathlib import Path
from typing import Annotated, Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
import typer

from .config import CONFIG_PATH, load_workspace_config, save_config_updates
from .llm import summarize_competition_markdown
from .zindi import (
    ZindiClient,
    build_raw_competition_markdown,
    download_competition_data,
    fetch_competition,
)

console = Console()
app = typer.Typer(
    add_completion=False,
    no_args_is_help=True,
    help="Standalone tools for Zindi competition data and details.",
)


def write_text_file(path: Path, content: str) -> Path:
    """Write UTF-8 text to disk, creating parents if needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _prompt(
    label: str,
    *,
    default: str = "",
    secret: bool = False,
    required: bool = False,
) -> str:
    while True:
        value = typer.prompt(
            label,
            default=default if default else None,
            hide_input=secret,
            show_default=bool(default) and not secret,
        )
        value = value.strip()
        if value:
            return value
        if default:
            return default
        if not required:
            return ""
        console.print("[red]This value is required.[/]")


def setup_user_config(config_path: Path | None = None) -> Path:
    """Interactively collect and persist user-level credentials."""
    config = load_workspace_config(config_path)
    saved_path = config_path or CONFIG_PATH

    console.print(
        Panel.fit(
            f"Config file: [bold]{saved_path}[/bold]",
            title="Zindi Helper Setup",
        )
    )

    email = _prompt(
        "Zindi email",
        default=config.get("email", ""),
        required=True,
    )
    password = _prompt(
        "Zindi password",
        default=config.get("password", ""),
        secret=True,
        required=True,
    )

    llm_cfg = config.get("workspace_llm", {})
    api_base = _prompt(
        "Workspace LLM API base URL (optional)",
        default=llm_cfg.get("api_base") or llm_cfg.get("base_url", ""),
    )
    api_key = _prompt(
        "Workspace LLM API key (optional)",
        default=llm_cfg.get("api_key", ""),
        secret=True,
    )
    model = _prompt(
        "Workspace LLM model (LiteLLM format, e.g. anthropic/claude-sonnet-4-20250514)",
        default=llm_cfg.get("model", "anthropic/claude-sonnet-4-20250514"),
        required=True,
    )

    return save_config_updates(
        {
            "email": email,
            "password": password,
            "workspace_llm": {
                "api_key": api_key,
                "api_base": api_base,
                "model": model,
            },
        },
        config_path=saved_path,
    )


def _print_competition_summary(command_name: str, slug: str, comp: dict[str, Any]) -> None:
    """Render a short competition summary block."""
    table = Table.grid(padding=(0, 1))
    table.add_row("Command", command_name)
    table.add_row("Competition", comp.get("title", slug))
    table.add_row("Slug", slug)

    error_metric = comp.get("error_metric")
    if error_metric:
        table.add_row("Metric", error_metric)

    deadline = comp.get("end_time")
    if deadline:
        table.add_row("Deadline", deadline)

    console.print(Panel.fit(table, title="Competition", border_style="blue"))


def _load_authenticated_competition(competition: str) -> tuple[ZindiClient, str, dict[str, Any]]:
    """Authenticate and fetch competition details."""
    client = ZindiClient.from_credentials()
    console.print(f"[cyan]Logging in as[/] [bold]{client.email}[/]")
    with console.status("Authenticating with Zindi..."):
        client.login()
    with console.status("Fetching competition metadata..."):
        slug, comp = fetch_competition(client, competition)
    return client, slug, comp


def _write_competition_details(comp: dict[str, Any], output_path: Path, raw: bool) -> Path:
    """Persist competition details markdown to disk."""
    raw_markdown = build_raw_competition_markdown(comp)
    if raw:
        content = raw_markdown
    else:
        with console.status("Summarizing competition brief with LiteLLM..."):
            content = summarize_competition_markdown(raw_markdown)
    return write_text_file(output_path, content)


@app.command()
def setup(
    config_path: Annotated[
        Path | None,
        typer.Option(help=f"Override the config path (default: {CONFIG_PATH})"),
    ] = None,
) -> None:
    """Interactively create or update the user config."""
    path = setup_user_config(config_path)
    console.print(f"[green]Saved config to[/] {path}")


@app.command("download-data")
def download_data(
    competition: Annotated[str, typer.Argument(help="Competition URL or slug")],
    output_dir: Annotated[
        Path | None,
        typer.Option("--output-dir", "-o", help="Target data directory (default: ./data)"),
    ] = None,
) -> None:
    """Download competition files into a target folder."""
    client, slug, comp = _load_authenticated_competition(competition)
    _print_competition_summary("download-data", slug, comp)

    with console.status("Joining competition if needed..."):
        client.join_competition(slug)

    resolved_output_dir = (output_dir or (Path.cwd() / "data")).resolve()
    downloaded_paths = download_competition_data(
        client,
        slug,
        comp,
        resolved_output_dir,
        console,
    )
    console.print(
        f"[green]Data ready at[/] {resolved_output_dir} "
        f"([bold]{len(downloaded_paths)}[/] file(s) handled)"
    )


@app.command()
def details(
    competition: Annotated[str, typer.Argument(help="Competition URL or slug")],
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Target markdown path (default: ./challenge-info.md)"),
    ] = None,
    raw: Annotated[
        bool,
        typer.Option(help="Skip the LLM summarization step and save the raw competition info."),
    ] = False,
) -> None:
    """Save competition details as markdown."""
    client, slug, comp = _load_authenticated_competition(competition)
    _print_competition_summary("details", slug, comp)

    output_path = (output or (Path.cwd() / "challenge-info.md")).resolve()
    _write_competition_details(comp, output_path, raw)
    console.print(f"[green]Wrote[/] {output_path}")


@app.command("get-started")
def get_started(
    competition: Annotated[str, typer.Argument(help="Competition URL or slug")],
    output_dir: Annotated[
        Path | None,
        typer.Option("--output-dir", help="Target data directory (default: ./data)"),
    ] = None,
    output: Annotated[
        Path | None,
        typer.Option("--output", help="Target markdown path (default: ./challenge-info.md)"),
    ] = None,
    raw: Annotated[
        bool,
        typer.Option(help="Skip the LLM summarization step and save the raw competition info."),
    ] = False,
) -> None:
    """Download challenge data and save the competition brief."""
    client, slug, comp = _load_authenticated_competition(competition)
    _print_competition_summary("get-started", slug, comp)

    with console.status("Joining competition if needed..."):
        client.join_competition(slug)

    resolved_output_dir = (output_dir or (Path.cwd() / "data")).resolve()
    output_path = (output or (Path.cwd() / "challenge-info.md")).resolve()

    downloaded_paths = download_competition_data(
        client,
        slug,
        comp,
        resolved_output_dir,
        console,
    )
    _write_competition_details(comp, output_path, raw)

    console.print(
        f"[green]Starter files ready:[/] data at {resolved_output_dir} "
        f"([bold]{len(downloaded_paths)}[/] file(s) handled), brief at {output_path}"
    )


def main() -> None:
    app()


if __name__ == "__main__":
    main()
