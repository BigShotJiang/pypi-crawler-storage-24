from __future__ import annotations

from typing import Any

import litellm

from .config import CONFIG_PATH, WORKSPACE_LLM_DEFAULTS, load_workspace_config

DETAILS_SYSTEM_PROMPT = """\
You are preparing a competition brief for an ML engineer.

Summarize the raw Zindi competition information into a practical markdown document.
Focus on the information that matters when building a submission:
- the prediction goal
- the available data
- the evaluation metric
- important rules and constraints
- deliverable and submission expectations
- timeline or benchmark information

Rules:
- Return markdown only
- Do not invent facts
- Keep it concise but useful
- Prefer clear headings and short bullet lists
"""


def summarize_competition_markdown(
    raw_markdown: str,
    config: dict[str, Any] | None = None,
) -> str:
    """Summarize raw competition markdown with the configured LiteLLM model."""
    cfg = config or load_workspace_config()
    llm_cfg = cfg.get("workspace_llm", {})

    model = llm_cfg.get("model", WORKSPACE_LLM_DEFAULTS["model"])
    if not model:
        raise SystemExit(
            "No workspace LLM model configured. "
            f"Run `zindi-workspace setup` or use `--raw`. Config file: {CONFIG_PATH}"
        )

    completion_kwargs: dict[str, Any] = dict(llm_cfg.get("completion_kwargs", {}))
    completion_kwargs.update(
        {
            "model": model,
            "messages": [
                {"role": "system", "content": DETAILS_SYSTEM_PROMPT},
                {"role": "user", "content": raw_markdown},
            ],
        }
    )
    completion_kwargs.setdefault("max_tokens", llm_cfg.get("max_tokens", 2048))
    api_key = llm_cfg.get("api_key", "")
    if api_key:
        completion_kwargs["api_key"] = api_key

    api_base = llm_cfg.get("api_base") or llm_cfg.get("base_url")
    if api_base:
        completion_kwargs["api_base"] = api_base

    try:
        response = litellm.completion(**completion_kwargs)
    except Exception as exc:
        raise SystemExit(f"Workspace LLM request failed via LiteLLM: {exc}") from exc

    content = response.choices[0].message.content
    if isinstance(content, str) and content.strip():
        return content.strip() + "\n"

    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                text = item
            elif isinstance(item, dict):
                text = str(item.get("text", "")).strip()
            else:
                text = str(getattr(item, "text", "")).strip()
            if text:
                parts.append(text)
        if parts:
            return "\n".join(parts).strip() + "\n"

    raise ValueError("Workspace LLM returned no text content")
