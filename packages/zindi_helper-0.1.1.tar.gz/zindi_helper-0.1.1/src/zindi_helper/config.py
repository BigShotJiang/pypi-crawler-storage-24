from __future__ import annotations

import json
from pathlib import Path
from typing import Any

CONFIG_PATH = Path.home() / ".zindi-agent" / "config.json"
WORKSPACE_LLM_DEFAULTS: dict[str, Any] = {
    "model": "anthropic/claude-sonnet-4-20250514",
    "max_tokens": 2048,
}


def load_user_config(config_path: Path | None = None) -> dict[str, Any]:
    """Load raw user config from disk."""
    path = config_path or CONFIG_PATH
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def load_workspace_config(config_path: Path | None = None) -> dict[str, Any]:
    """Load workspace tool config with defaults."""
    user = load_user_config(config_path)
    llm_cfg = {
        **WORKSPACE_LLM_DEFAULTS,
        **user.get("workspace_llm", {}),
    }
    return {
        **user,
        "workspace_llm": llm_cfg,
    }


def save_config_updates(
    updates: dict[str, Any],
    config_path: Path | None = None,
) -> Path:
    """Merge updates into the user config and persist them."""
    path = config_path or CONFIG_PATH
    existing = load_user_config(path)

    merged = dict(existing)
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(existing.get(key), dict):
            merged[key] = {**existing[key], **value}
        else:
            merged[key] = value

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(merged, indent=2) + "\n", encoding="utf-8")
    return path


def load_credentials(config_path: Path | None = None) -> tuple[str, str]:
    """Load Zindi credentials from the user config."""
    path = config_path or CONFIG_PATH
    data = load_user_config(path)
    email = data.get("email", "")
    password = data.get("password", "")
    if email and password:
        return email, password

    raise SystemExit(
        f"No credentials found.\n"
        f"Add these fields to {path}:\n"
        f'  {{"email": "...", "password": "..."}}\n'
    )
