from typing import Any
from typing_extensions import TypedDict, NotRequired


LogContent = tuple[Any, ...]


class LogOptions(TypedDict):
    bookmark: NotRequired[bool]
    annotation: NotRequired[str]


class SourceLocation(TypedDict):
    file_name: str
    line_number: int


class LogbenchOptions(TypedDict):
    project_id: str
    url: NotRequired[str]
    capture_source: NotRequired[bool]
    cwd: NotRequired[str]
