import inspect
import json
import math
import base64
import traceback
from pathlib import Path
from datetime import datetime, date
from decimal import Decimal
from types import FunctionType
from typing import Any

from .types import SourceLocation

# Directory of this package — used to skip internal frames
_PACKAGE_DIR = str(Path(__file__).parent)


def get_caller_location() -> SourceLocation | None:
    """Walk the call stack and return the first frame outside the logbench package."""
    try:
        frame = inspect.currentframe()
        while frame is not None:
            filename = frame.f_code.co_filename
            if not filename.startswith(_PACKAGE_DIR):
                return SourceLocation(
                    file_name=filename,
                    line_number=frame.f_lineno,
                )
            frame = frame.f_back
        return None
    except Exception:
        return None
    finally:
        del frame


class LogbenchEncoder(json.JSONEncoder):
    """Custom JSON encoder that serialises Python-specific types into typed envelopes."""

    def default(self, obj: Any) -> Any:
        if isinstance(obj, set):
            return {"_type": "@py/set", "_value": list(obj)}
        if isinstance(obj, frozenset):
            return {"_type": "@py/frozenset", "_value": list(obj)}
        if isinstance(obj, tuple):
            return {"_type": "@py/tuple", "_value": list(obj)}
        if isinstance(obj, bytes):
            return {"_type": "@py/bytes", "_value": base64.b64encode(obj).decode()}
        if isinstance(obj, bytearray):
            return {"_type": "@py/bytearray", "_value": base64.b64encode(bytes(obj)).decode()}
        if isinstance(obj, Decimal):
            return {"_type": "@py/Decimal", "_value": str(obj)}
        if isinstance(obj, complex):
            return {"_type": "@py/complex", "_value": str(obj)}
        if isinstance(obj, range):
            return {"_type": "@py/range", "_value": [obj.start, obj.stop, obj.step]}
        if isinstance(obj, (datetime, date)):
            return obj.isoformat()
        if isinstance(obj, BaseException):
            return {
                "_type": "@py/Exception",
                "_value": {
                    "type": type(obj).__name__,
                    "message": str(obj),
                    "traceback": "".join(traceback.format_exception(type(obj), obj, obj.__traceback__)),
                },
            }
        if isinstance(obj, FunctionType):
            return {"_type": "@py/Function", "_value": obj.__qualname__}
        if isinstance(obj, type):
            return {"_type": "@py/Class", "_value": obj.__qualname__}
        # Fallback: try to serialise as dict of public attributes
        try:
            attrs = {k: v for k, v in vars(obj).items() if not k.startswith("_")}
            return {
                "_type": "@py/ClassInstance",
                "_value": {"__class__": type(obj).__qualname__, **attrs},
            }
        except TypeError:
            return repr(obj)

    def encode(self, obj: Any) -> str:
        # Handle top-level float edge cases (nan/inf) before encoding
        return super().encode(self._prepare(obj))

    def _prepare(self, obj: Any) -> Any:
        if isinstance(obj, float):
            if math.isnan(obj):
                return {"_type": "@py/NaN"}
            if math.isinf(obj):
                return {"_type": "@py/Infinity", "_value": 1 if obj > 0 else -1}
        if isinstance(obj, dict):
            return {k: self._prepare(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [self._prepare(v) for v in obj]
        return obj


def unpack_content(content: tuple) -> Any:
    """Unwrap a single-item tuple or return a list for multiple items."""
    return content[0] if len(content) == 1 else list(content)
