from enum import Enum


class LogLevel(str, Enum):
    Info = "INFO"
    Warn = "WARNING"
    Err = "ERROR"
