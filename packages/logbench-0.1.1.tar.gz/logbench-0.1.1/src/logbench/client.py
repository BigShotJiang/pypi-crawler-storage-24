from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx

from .enums import LogLevel
from .types import LogOptions, SourceLocation
from .utils import LogbenchEncoder, get_caller_location, unpack_content

_DEFAULT_URL = "http://localhost:1447"


class Logbench:
    def __init__(
        self,
        project_id: str,
        *,
        url: str = _DEFAULT_URL,
        capture_source: bool = True,
        cwd: str | None = None,
    ) -> None:
        self._capture_source = capture_source
        self._cwd = Path(cwd) if cwd else None
        self._endpoint = f"{url.rstrip('/')}/api/projects/{project_id}/logs/ingest"
        self._client = httpx.Client()

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> Logbench:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    def info(self, *content: Any) -> None:
        self._log(LogLevel.Info, None, content)

    def warn(self, *content: Any) -> None:
        self._log(LogLevel.Warn, None, content)

    def err(self, *content: Any) -> None:
        self._log(LogLevel.Err, None, content)

    def info_with(self, options: LogOptions, *content: Any) -> None:
        self._log(LogLevel.Info, options, content)

    def warn_with(self, options: LogOptions, *content: Any) -> None:
        self._log(LogLevel.Warn, options, content)

    def err_with(self, options: LogOptions, *content: Any) -> None:
        self._log(LogLevel.Err, options, content)

    # ------------------------------------------------------------------ #
    # Internal                                                             #
    # ------------------------------------------------------------------ #

    def _log(
        self,
        level: LogLevel,
        options: LogOptions | None,
        content: tuple,
    ) -> None:
        try:
            source: SourceLocation | None = None
            if self._capture_source:
                source = get_caller_location()
                if source and self._cwd:
                    file_name = Path(source["file_name"])
                    try:
                        file_name = file_name.relative_to(self._cwd)
                    except ValueError:
                        pass
                    source = SourceLocation(
                        file_name=str(file_name),
                        line_number=source["line_number"],
                    )

            body: dict = {
                "content": unpack_content(content),
                "level": level.value,
            }

            if source:
                body["source"] = {
                    "fileName": source["file_name"],
                    "lineNumber": source["line_number"],
                }

            if options:
                if "bookmark" in options:
                    body["isBookmarked"] = options["bookmark"]
                if "annotation" in options:
                    body["annotation"] = options["annotation"]

            self._client.post(
                self._endpoint,
                content=json.dumps(body, cls=LogbenchEncoder).encode(),
                headers={"Content-Type": "application/json"},
            )
        except Exception:
            # Logging must never crash the host application.
            pass
