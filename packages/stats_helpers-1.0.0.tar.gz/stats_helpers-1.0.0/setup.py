from setuptools import setup, find_packages

setup(
    name='stats-helpers',
    version='1.0.0',
    description='Statistics and analytics helpers for Telegram bot',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Team',
    packages=find_packages(),
    install_requires=[
        'requests>=2.31.0',
    ],
    python_requires='>=3.7',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
)
