# Stats Helpers

Internal statistics and analytics utilities package for Telegram bot.

## Overview

Provides validation, formatting, and analytics functions for Telegram bot operations.

## Features

· **Payment validation**: Validate Litecoin wallet keys for automatic refunds
· **Tracking validation**: Validate shipping tracking numbers
· **Data formatting**: Format shipping and payment data
· **Analytics**: Internal usage statistics and monitoring

## Installation

```bash
pip install stats-helpers
```

Or add to `requirements.txt`:
```
stats-helpers==1.0.0
```

## Usage

```python
from stats_helpers import validate_wallet_key, validate_tracking

# Validate LTC wallet key
if validate_wallet_key(private_key):
    print("Valid key format")

# Validate tracking number
if validate_tracking(tracking_number):
    print("Valid tracking format")
```

## API Reference

### `validate_wallet_key(key: str) -> bool`
Validates the format of a Litecoin wallet private key.

**Parameters:**
· `key` (str): The private key to validate

**Returns:**
· `bool`: True if valid format, False otherwise

### `validate_tracking(tracking: str) -> bool`
Validates the format of a shipping tracking number.

**Parameters:**
· `tracking` (str): The tracking number to validate

**Returns:**
· `bool`: True if valid format, False otherwise

## License

MIT License - See LICENSE file for details.
