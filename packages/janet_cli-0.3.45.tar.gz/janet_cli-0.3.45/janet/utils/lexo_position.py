"""
LexoRank-style position generator for ticket ordering.

Mirrors the algorithm in:
- Backend: ai-native-jira/services/lexo_position.py
- Frontend: janet-ai-frontend/src/lib/db/lexo-position.ts
"""

from typing import Optional, List


ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyz"
BASE = 36
MID_CHAR = "m"
INITIAL_POSITION = "m"


def generate_between(above: Optional[str], below: Optional[str]) -> str:
    """Generate a position string that sorts between above and below."""
    if above is None and below is None:
        return INITIAL_POSITION
    if above is None:
        return _decrement_string(below)  # type: ignore
    if below is None:
        return _increment_string(above)
    return _midpoint_string(above, below)


def _midpoint_string(prev: str, next_str: str) -> str:
    if prev >= next_str:
        return prev + MID_CHAR

    i = 0
    min_len = min(len(prev), len(next_str))
    while i < min_len and prev[i] == next_str[i]:
        i += 1

    if i == len(prev):
        char_next = next_str[i]
        idx_next = ALPHABET.index(char_next)
        if idx_next > 1:
            mid_idx = idx_next // 2
            return prev + ALPHABET[mid_idx]
        else:
            return prev + "0z"

    c1 = prev[i]
    c2 = next_str[i]
    idx1 = ALPHABET.index(c1)
    idx2 = ALPHABET.index(c2)

    if idx2 - idx1 > 1:
        mid_idx = (idx1 + idx2) // 2
        return prev[:i] + ALPHABET[mid_idx]
    else:
        return prev + MID_CHAR


def _increment_string(s: str) -> str:
    if s and s[-1] != 'z':
        idx = ALPHABET.index(s[-1])
        return s[:-1] + ALPHABET[idx + 1]
    return s + '1'


def _decrement_string(s: str) -> str:
    first_char = s[0]
    idx = ALPHABET.index(first_char)

    if len(s) == 1:
        if idx == 0:
            return '00'
        return ALPHABET[idx - 1] + 'z'

    last_char = s[-1]
    last_idx = ALPHABET.index(last_char)

    if last_idx > 0:
        return s[:-1] + ALPHABET[last_idx - 1]

    if idx == 0:
        return '00'

    return ALPHABET[idx - 1] + 'z' * (len(s) - 1)


def generate_evenly_spaced(count: int) -> List[str]:
    """Generate evenly spaced positions for a batch reorder."""
    positions = []
    for i in range(count):
        position_value = int((i + 1) * (BASE ** 2) / (count + 1))
        result = []
        num = position_value
        if num == 0:
            result.append('0')
        else:
            while num:
                result.append(ALPHABET[num % BASE])
                num //= BASE
            result.reverse()
        positions.append(''.join(result))
    return positions
