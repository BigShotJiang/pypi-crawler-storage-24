"""janet-mcp-setup — One-command MCP setup wizard.

Authenticates, generates an API key, and configures all detected MCP clients.
"""

import json
import os
import pathlib
import platform
import shutil
import socket
import subprocess
import sys

from janet.config.manager import ConfigManager
from janet.utils.console import console, print_success, print_error, print_info


def _get_hostname() -> str:
    """Get a friendly machine name."""
    import re
    name = None
    # Try macOS friendly name first
    if platform.system() == "Darwin":
        try:
            result = subprocess.run(
                ["scutil", "--get", "ComputerName"],
                capture_output=True, text=True, timeout=2,
            )
            if result.returncode == 0 and result.stdout.strip():
                name = result.stdout.strip()
        except Exception:
            pass
    if not name:
        name = socket.gethostname()
        for suffix in (".local", ".lan", ".home"):
            if name.endswith(suffix):
                name = name[: -len(suffix)]
    # Strip characters not allowed in API key names
    name = re.sub(r"[^a-zA-Z0-9\s._-]", "", name)
    return name or "MCP"


# ── Client detection ────────────────────────────────────────────────────────

def detect_clients() -> list[tuple[str, str]]:
    """Detect installed MCP-compatible clients.

    Returns list of (display_name, client_id) tuples.
    """
    system = platform.system()
    home = pathlib.Path.home()
    clients = []

    # Claude Code
    if shutil.which("claude"):
        clients.append(("Claude Code", "claude_code"))

    # Claude Desktop
    if system == "Darwin":
        p = home / "Library" / "Application Support" / "Claude"
    elif system == "Windows":
        p = pathlib.Path(os.environ.get("APPDATA", "")) / "Claude"
    else:
        p = home / ".config" / "Claude"
    if p.exists():
        clients.append(("Claude Desktop", "claude_desktop"))

    # Cursor
    if (home / ".cursor").exists():
        clients.append(("Cursor", "cursor"))

    # VS Code
    if shutil.which("code"):
        clients.append(("VS Code", "vscode"))

    # Windsurf
    if (home / ".codeium" / "windsurf").exists():
        clients.append(("Windsurf", "windsurf"))

    # Codex
    if shutil.which("codex"):
        clients.append(("Codex", "codex"))

    return clients


# ── Client configuration ────────────────────────────────────────────────────

def _merge_json(path: pathlib.Path, key: str, server_entry: dict):
    """Read a JSON file, merge server entry under key, write back."""
    config = {}
    if path.exists():
        try:
            config = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            config = {}
    config.setdefault(key, {})[  "janet-ai"] = server_entry
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2) + "\n")


def configure_client(client_id: str, api_key: str) -> bool:
    """Configure a single client. Returns True on success."""
    home = pathlib.Path.home()
    system = platform.system()

    server_entry = {
        "command": "janet-mcp",
        "env": {"JANET_API_KEY": api_key},
    }

    try:
        if client_id == "claude_code":
            # Remove existing first (ignore errors if not found)
            subprocess.run(
                ["claude", "mcp", "remove", "janet-ai", "--scope", "user"],
                capture_output=True,
            )
            subprocess.run(
                ["claude", "mcp", "add", "janet-ai",
                 "-e", f"JANET_API_KEY={api_key}",
                 "--scope", "user",
                 "--", "janet-mcp"],
                check=True, capture_output=True,
            )

        elif client_id == "claude_desktop":
            if system == "Darwin":
                p = home / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
            elif system == "Windows":
                p = pathlib.Path(os.environ.get("APPDATA", "")) / "Claude" / "claude_desktop_config.json"
            else:
                p = home / ".config" / "Claude" / "claude_desktop_config.json"
            _merge_json(p, "mcpServers", server_entry)

        elif client_id == "cursor":
            _merge_json(home / ".cursor" / "mcp.json", "mcpServers", server_entry)

        elif client_id == "vscode":
            vscode_dir = pathlib.Path.cwd() / ".vscode"
            vscode_dir.mkdir(exist_ok=True)
            vscode_entry = {"type": "stdio", **server_entry}
            _merge_json(vscode_dir / "mcp.json", "servers", vscode_entry)

        elif client_id == "windsurf":
            p = home / ".codeium" / "windsurf" / "mcp_config.json"
            config = {}
            if p.exists():
                try:
                    config = json.loads(p.read_text())
                except (json.JSONDecodeError, OSError):
                    config = {}
            servers = config.get("servers", [])
            servers = [s for s in servers if s.get("name") != "janet-ai"]
            servers.append({"name": "janet-ai", "type": "stdio", **server_entry})
            config["servers"] = servers
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(config, indent=2) + "\n")

        elif client_id == "codex":
            subprocess.run(
                ["codex", "mcp", "remove", "janet-ai"],
                capture_output=True,
            )
            subprocess.run(
                ["codex", "mcp", "add", "janet-ai",
                 "--", "janet-mcp",
                 "-e", f"JANET_API_KEY={api_key}"],
                check=True, capture_output=True,
            )

        return True
    except Exception:
        return False


# ── Main wizard ─────────────────────────────────────────────────────────────

def run_setup():
    """Run the full MCP setup wizard."""
    console.print()
    console.print("[bold]janet-mcp-setup[/bold]")
    console.print()

    config_manager = ConfigManager()


    # ── Step 1: Login ──
    if config_manager.is_authenticated():
        config = config_manager.get()
        email = config.auth.user_email or "unknown"
        print_success(f"Already logged in as {email}")
    else:
        print_info("Opening browser to log in...")
        try:
            from janet.auth.oauth_flow import OAuthFlow
            oauth_flow = OAuthFlow(config_manager)
            oauth_flow.start_login()
            print_success("Logged in")
        except Exception as e:
            print_error(f"Login failed: {e}")
            sys.exit(1)

    # ── Step 2: Org selection ──
    from janet.api.organizations import OrganizationAPI

    print_info("Fetching organizations...")
    org_api = OrganizationAPI(config_manager)
    organizations = org_api.list_organizations()

    if not organizations:
        print_error("No organizations found for your account")
        sys.exit(1)

    if len(organizations) == 1:
        selected_org = organizations[0]
        print_success(f"Organization: {selected_org['name']}")
    else:
        from InquirerPy import inquirer

        console.print()
        choices = [
            {"name": f"{org['name']} ({org.get('userRole', 'member')})", "value": org}
            for org in organizations
        ]
        selected_org = inquirer.select(
            message="Select organization:",
            choices=choices,
        ).execute()
        print_success(f"Organization: {selected_org['name']}")

    # Save selected org
    from janet.config.models import OrganizationInfo

    config = config_manager.get()
    config.selected_organization = OrganizationInfo(
        id=selected_org["id"], name=selected_org["name"], uuid=selected_org.get("uuid", selected_org["id"]),
    )
    config_manager.update(config)

    # ── Step 3: Generate API key ──
    hostname = _get_hostname()
    key_name = f"{hostname}"

    print_info(f"Generating API key \"{key_name}\"...")
    import httpx
    from janet.api.client import APIClient

    client = APIClient(config_manager)
    headers = client._get_headers(include_org=True)
    base_url = config_manager.get().api.base_url

    resp = httpx.post(
        f"{base_url}/api/v1/api-keys",
        headers=headers,
        json={"name": key_name},
        timeout=15,
    )
    data = resp.json()

    if not data.get("success"):
        print_error(f"Failed to generate API key: {data.get('error', 'unknown error')}")
        sys.exit(1)

    api_key = data["api_key"]["key"]
    key_prefix = data["api_key"]["key_prefix"]
    print_success(f"API key generated ({key_prefix})")

    # ── Step 4: Detect & configure clients ──
    console.print()
    clients = detect_clients()

    if not clients:
        console.print("[yellow]  No MCP clients detected.[/yellow]")
        console.print()
        console.print(f"  Add manually to Claude Code:")
        console.print(f"  [cyan]claude mcp add janet-ai -e JANET_API_KEY={api_key} -- janet-mcp[/cyan]")
        console.print()
        return

    all_clients = [
        ("Claude Code", "claude_code"),
        ("Claude Desktop", "claude_desktop"),
        ("Cursor", "cursor"),
        ("VS Code", "vscode"),
        ("Windsurf", "windsurf"),
        ("Codex", "codex"),
    ]

    detected_ids = {cid for _, cid in clients}

    for display_name, client_id in all_clients:
        if client_id in detected_ids:
            ok = configure_client(client_id, api_key)
            if ok:
                console.print(f"  [green]✓[/green] {display_name}")
            else:
                console.print(f"  [red]✗[/red] {display_name} — failed to configure")
        else:
            console.print(f"  [dim]○ {display_name} — not installed[/dim]")

    # ── Done ──
    console.print()
    console.print("[green]✓ Setup complete![/green]")
    console.print()
    console.print('  Try asking Claude: [cyan]"Show me my assigned tickets"[/cyan]')
    console.print()


def main():
    """Entry point for janet-mcp-setup command."""
    run_setup()
