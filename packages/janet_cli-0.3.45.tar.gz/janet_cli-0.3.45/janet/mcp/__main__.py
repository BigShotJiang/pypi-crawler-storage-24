"""Allow running setup via: python -m janet.mcp"""
from janet.mcp.setup import main

if __name__ == "__main__":
    main()
