"""Janet AI MCP Server - Model Context Protocol integration."""
