from setuptools import setup

setup(
    name='firefox-cookie',
    version='0.0.5',
    packages=['firefox_cookie'],
    # look for package contents in current directory
    package_dir={'firefox_cookie': 'firefox_cookie'},
    author='Ilya Rakhlin',
    author_email='i.rakhlin@gmail.com',
    description='Original author Boris Babic boris.ivan.babic@gmail.com',     # noqa: E501
    url='https://github.com/irakhlin/browser-cookie4',
    install_requires=[
        'lz4',
        'pycryptodomex',
        'urllib3',
        'requests',
        'websocket-client',
        'dbus-python; python_version < "3.7" and ("bsd" in sys_platform or sys_platform == "linux")',
        'jeepney; python_version >= "3.7" and ("bsd" in sys_platform or sys_platform == "linux")',
        'shadowcopy; python_version >= "3.7" and platform_system == "Windows"',
    ],
    entry_points={'console_scripts': ['browser-cookie=firefox_cookie.__main__:main']},
    license_files=('LICENSE')
)
