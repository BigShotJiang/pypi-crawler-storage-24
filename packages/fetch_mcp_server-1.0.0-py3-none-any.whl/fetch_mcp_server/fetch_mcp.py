from fastmcp import FastMCP
from fastmcp.exceptions import ToolError
from typing import Tuple
import readabilipy.simple_json
import markdownify


mcp = FastMCP(
    name="FetchMCP",
    instructions="""
        一个提供网页内容抓取功能的 MCP 服务，此服务能够从网页中获取原始 HTML 内容，
        并提供是否要转换为 Markdown 开发，如果需要转换，则将 HTML 转换为 Markdown 格式返回，以便更容易的被大语言模型阅读，
        否则以原始 HTML 返回。
    """,
    website_url="https://github.com/yourname/fetch-mcp",
    strict_input_validation=False,
    on_duplicate="warn"
)


@mcp.tool
def fetch_url(
    url: str,
    force_raw: bool = False
) -> Tuple[str, str]:
    """
    该工具会向目标 URL 发送 HTTP 请求并返回页面内容。默认情况下，会尝试提取网页的主要正文并转换为 Markdown 格式，
    以便模型更容易阅读和理解。如果 `force_raw` 为 True，则返回原始 HTML 内容而不进行正文提取和格式转换。
    """
    from httpx import Client, HTTPError

    with Client() as client:
        try:
            response = client.get(
                url,
                follow_redirects=True,
                headers={
                    "User-Agent": "ModelContextProtocol/1.0 (Autonomous; +https://github.com/modelcontextprotocol/servers)"
                },
                timeout=30,
            )
        except HTTPError as e:
            raise ToolError(f"提取 {url} 失败：{e!r}")

        if response.status_code >= 400:
            raise ToolError(
                f"获取 {url} 失败 - 状态码 {response.status_code}")

        page_raw = response.text

    content_type = response.headers.get("content-type", "")
    is_page_html = (
        "<html" in page_raw[:100] or "text/html" in content_type or not content_type
    )

    if is_page_html and not force_raw:
        return extract_content_from_html(page_raw), ""

    return (
        page_raw,
        f"内容类型 {content_type} 无法简化为 Markdown 格式，但以下是原始内容：\n",
    )


def extract_content_from_html(html: str) -> str:
    """
    提取HTML内容并将其转换为Markdown格式。
    Args:
        html：需要处理的原始HTML内容
    Returns:
        内容的简化Markdown版本
    """
    ret = readabilipy.simple_json.simple_json_from_html_string(
        html, use_readability=True
    )

    if not ret["content"]:
        return "<error>页面无法从 HTML 转换为 Markdown.</error>"
    content = markdownify.markdownify(
        ret["content"],
        heading_style=markdownify.ATX,
    )
    return content


# 运行 MCP 服务
if __name__ == "__main__":
    mcp.run(transport="sse", host="0.0.0.0", port=8010)
