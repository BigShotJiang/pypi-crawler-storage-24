import argparse
from .fetch_mcp import mcp

def main():
    parser = argparse.ArgumentParser(
        description="An MCP service that provides web content scraping functionality."
    )
    parser.add_argument("--transport", type=str, default="stdio", help="MCP Transport Protocol",)
    parser.add_argument("--port", type=int, default=8010, help="SSE and HTTP port numbers")
    args = parser.parse_args()

    if args.transport == "stdio":
        mcp.run()
    else:
        mcp.run(transport=args.transport, host="0.0.0.0", port=args.port)
