"""SkillMind CLI."""
