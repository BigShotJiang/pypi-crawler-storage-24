"""Quick test for the sanitizer — results to file."""
from skillmind.sanitizer import Sanitizer

s = Sanitizer(redact_names=["Max Mustermann", "Erika Muster"])

test = (
    "Email: secret@example.com. "
    "Phone: +49 163 000 1234. "
    "Max Mustermann called Erika Muster about the project."
)

result = s.sanitize(test)

with open("test_sanitizer_result.txt", "w", encoding="utf-8") as f:
    f.write("SANITIZED:\n")
    f.write(result.sanitized + "\n\n")
    f.write(f"Redactions: {result.redaction_count}\n")
    for r in result.redactions:
        f.write(f"  [{r['type']}] -> {r['replacement']}\n")
    f.write(f"\nModified: {result.was_modified}\n")

print("Result written to test_sanitizer_result.txt")
