"""Generate SkillMind Quick-Start PDF guides (EN + DE)."""

from fpdf import FPDF
import os

FONT_DIR = r'C:\Users\anton\OneDrive\Mabya\Dokumente\Claude\fonts'
OUT_DIR = r'C:\Users\anton\PycharmProjects\skillmind-website\static\downloads'

PRIMARY = (246, 87, 30)
DARK = (12, 17, 21)
WHITE = (255, 255, 255)
GRAY = (156, 163, 175)
TEAL = (26, 188, 156)
LIGHT_BG = (18, 20, 26)

MCP_CONFIG = """{
  "mcpServers": {
    "skillmind": {
      "command": "python",
      "args": ["-m", "skillmind.mcp.server"],
      "env": {
        "PINECONE_API_KEY": "your-api-key",
        "SKILLMIND_BACKEND": "pinecone"
      }
    }
  }
}"""


def generate_guide(lang="en"):
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=20)

    pdf.add_font("Montserrat", "", f"{FONT_DIR}/Montserrat-Regular.ttf", uni=True)
    pdf.add_font("Montserrat", "B", f"{FONT_DIR}/Montserrat-Bold.ttf", uni=True)
    pdf.add_font("Aptos", "", f"{FONT_DIR}/Aptos.ttf", uni=True)
    pdf.add_font("Aptos", "B", f"{FONT_DIR}/Aptos-Bold.ttf", uni=True)

    if lang == "de":
        subtitle = "Aktiver Skill-Listener & Trainer"
        guide_title = "Schnellstart-Anleitung"
        steps = [
            ("1. Installieren", "pip install skillmind[pinecone,mcp,youtube]",
             "Backend waehlen: pinecone, chroma, supabase, qdrant oder faiss."),
            ("2. Initialisieren", "skillmind init --backend pinecone",
             "Erstellt .skillmind/ Verzeichnis mit Konfiguration."),
            ("3. Zu Claude Code hinzufuegen", None,
             "MCP-Server zu ~/.claude/settings.json hinzufuegen:"),
            ("4. Erinnerungen importieren", "skillmind import ~/.claude/projects/*/memory/",
             "Bestehende Markdown-Memories werden mit Typen und Tags importiert."),
            ("5. Neustarten & nutzen", None,
             "Claude Code neustarten. 14 MCP-Tools verfuegbar: remember, recall, forget, context, learn_youtube, record_screen u.v.m."),
        ]
        backends = [
            ("ChromaDB", "Lokal, eingebettet, null Konfiguration"),
            ("Pinecone", "Cloud-synchronisiert, verwaltet, skalierbar"),
            ("Supabase", "SQL + Vektoren, Free Tier, Team-Sharing"),
            ("Qdrant", "Self-hosted oder Cloud, exzellentes Filtering"),
            ("FAISS", "Offline, air-gapped, schnellstes Backend"),
        ]
        backends_title = "5 Vektor-Store-Backends"
        footer = "Entwickelt von Antonio Blago | skill-mind.com | github.com/AntonioBlago/skillmind"
    else:
        subtitle = "Active Skill Listener & Trainer"
        guide_title = "Quick Installation Guide"
        steps = [
            ("1. Install", "pip install skillmind[pinecone,mcp,youtube]",
             "Choose your backend: pinecone, chroma, supabase, qdrant, or faiss."),
            ("2. Initialize", "skillmind init --backend pinecone",
             "Creates a .skillmind/ directory with your configuration."),
            ("3. Add to Claude Code", None,
             "Add the MCP server to ~/.claude/settings.json:"),
            ("4. Import Existing Memories", "skillmind import ~/.claude/projects/*/memory/",
             "All existing markdown memories imported with types and tags preserved."),
            ("5. Restart & Use", None,
             "Restart Claude Code. 14 MCP tools available: remember, recall, forget, context, learn_youtube, record_screen and more."),
        ]
        backends = [
            ("ChromaDB", "Local, embedded, zero config"),
            ("Pinecone", "Cloud-synced, managed, scalable"),
            ("Supabase", "SQL + vectors, free tier, team sharing"),
            ("Qdrant", "Self-hosted or cloud, excellent filtering"),
            ("FAISS", "Offline, air-gapped, fastest backend"),
        ]
        backends_title = "5 Vector Store Backends"
        footer = "Built by Antonio Blago | skill-mind.com | github.com/AntonioBlago/skillmind"

    # ── Cover Page ──
    pdf.add_page()
    pdf.set_fill_color(*DARK)
    pdf.rect(0, 0, 210, 297, "F")
    pdf.set_fill_color(*PRIMARY)
    pdf.rect(0, 0, 210, 6, "F")

    pdf.set_y(80)
    pdf.set_font("Montserrat", "B", 36)
    pdf.set_text_color(*WHITE)
    pdf.cell(0, 18, "SkillMind", ln=True, align="C")

    pdf.set_font("Aptos", "", 14)
    pdf.set_text_color(*GRAY)
    pdf.cell(0, 10, subtitle, ln=True, align="C")

    pdf.set_y(pdf.get_y() + 15)
    pdf.set_fill_color(*PRIMARY)
    pdf.rect(70, pdf.get_y(), 70, 3, "F")

    pdf.set_y(pdf.get_y() + 25)
    pdf.set_font("Montserrat", "B", 18)
    pdf.set_text_color(*WHITE)
    pdf.cell(0, 12, guide_title, ln=True, align="C")

    pdf.set_y(pdf.get_y() + 10)
    pdf.set_font("Aptos", "", 11)
    pdf.set_text_color(*GRAY)
    pdf.cell(0, 8, "v0.1.0 | MIT License | skill-mind.com", ln=True, align="C")

    pdf.set_fill_color(*PRIMARY)
    pdf.rect(0, 291, 210, 6, "F")

    # ── Steps Page ──
    pdf.add_page()
    pdf.set_fill_color(*DARK)
    pdf.rect(0, 0, 210, 297, "F")
    pdf.set_fill_color(*PRIMARY)
    pdf.rect(0, 0, 210, 2, "F")
    pdf.set_y(15)

    for i, (step_title, code, desc) in enumerate(steps):
        y = pdf.get_y()
        if y > 245:
            pdf.add_page()
            pdf.set_fill_color(*DARK)
            pdf.rect(0, 0, 210, 297, "F")
            pdf.set_fill_color(*PRIMARY)
            pdf.rect(0, 0, 210, 2, "F")
            pdf.set_y(15)

        # Title
        pdf.set_font("Montserrat", "B", 13)
        pdf.set_text_color(*WHITE)
        pdf.cell(0, 10, step_title, ln=True)

        # Description
        pdf.set_font("Aptos", "", 10)
        pdf.set_text_color(*GRAY)
        pdf.multi_cell(0, 6, desc)
        pdf.ln(3)

        # Code block
        if code:
            pdf.set_fill_color(*LIGHT_BG)
            pdf.set_draw_color(30, 33, 48)
            code_y = pdf.get_y()
            pdf.rect(15, code_y, 180, 10, "DF")
            pdf.set_xy(20, code_y + 2)
            pdf.set_font("Aptos", "B", 9)
            pdf.set_text_color(*TEAL)
            pdf.cell(0, 6, "$ " + code)
            pdf.set_y(code_y + 14)

        # MCP config for step 3
        if i == 2:
            pdf.set_fill_color(*LIGHT_BG)
            pdf.set_draw_color(30, 33, 48)
            config_y = pdf.get_y()
            lines = MCP_CONFIG.split("\n")
            block_h = len(lines) * 4.5 + 6
            pdf.rect(15, config_y, 180, block_h, "DF")
            pdf.set_xy(20, config_y + 3)
            pdf.set_font("Aptos", "", 8)
            pdf.set_text_color(*TEAL)
            for line in lines:
                pdf.cell(0, 4.5, line, ln=True)
                pdf.set_x(20)
            pdf.set_y(config_y + block_h + 4)

        pdf.ln(4)

    # ── Backends ──
    y = pdf.get_y()
    if y > 220:
        pdf.add_page()
        pdf.set_fill_color(*DARK)
        pdf.rect(0, 0, 210, 297, "F")
        pdf.set_fill_color(*PRIMARY)
        pdf.rect(0, 0, 210, 2, "F")
        pdf.set_y(15)

    pdf.ln(5)
    pdf.set_font("Montserrat", "B", 13)
    pdf.set_text_color(*PRIMARY)
    pdf.cell(0, 10, backends_title, ln=True)
    pdf.ln(3)

    for name, desc in backends:
        pdf.set_font("Aptos", "B", 10)
        pdf.set_text_color(*WHITE)
        pdf.cell(35, 7, name)
        pdf.set_font("Aptos", "", 9)
        pdf.set_text_color(*GRAY)
        pdf.cell(0, 7, desc, ln=True)

    # Footer
    pdf.set_y(-20)
    pdf.set_fill_color(*PRIMARY)
    pdf.rect(0, 289, 210, 8, "F")
    pdf.set_font("Aptos", "", 7)
    pdf.set_text_color(*GRAY)
    pdf.cell(0, 5, footer, align="C")

    out = os.path.join(OUT_DIR, f"skillmind-quickstart-{lang}.pdf")
    pdf.output(out)
    size_kb = os.path.getsize(out) / 1024
    print(f"Generated: {out} ({size_kb:.0f} KB)")


if __name__ == "__main__":
    os.makedirs(OUT_DIR, exist_ok=True)
    generate_guide("en")
    generate_guide("de")
    print("Done!")
