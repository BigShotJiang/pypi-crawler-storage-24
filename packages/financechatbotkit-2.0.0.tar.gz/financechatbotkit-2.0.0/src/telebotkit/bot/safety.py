"""Small helpers for safe handler execution."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TypeVar

ResultT = TypeVar("ResultT")


def safe_call(
    *,
    action: Callable[[], ResultT],
    default: ResultT,
    logger: logging.Logger,
    log_message: str,
    log_args: tuple[object, ...] = (),
) -> ResultT:
    """Run *action* and fall back with consistent exception logging."""

    try:
        return action()
    except Exception:
        logger.exception(log_message, *log_args)
        return default

__all__ = ["safe_call"]
