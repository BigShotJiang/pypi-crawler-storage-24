"""Telegram Bot API sending helpers."""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import httpx

from telebotkit.bot.reply import DEFAULT_PARSE_MODE, Reply

logger = logging.getLogger(__name__)


class TelegramSendError(RuntimeError):
    """Raised when a Telegram send request fails."""


class TelegramApiError(TelegramSendError):
    """Raised when Telegram responds with an error payload or status code."""

    def __init__(self, *, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"Telegram API error ({status_code}): {detail}")


@dataclass(frozen=True)
class SendResult:
    """Normalized result of a Telegram send request."""

    ok: bool
    chat_id: int
    payload: dict[str, Any]
    status_code: int
    data: dict[str, Any]


class TelegramBot:
    """Small async client for Telegram Bot API `sendMessage`."""

    def __init__(
        self,
        *,
        token: str,
        timeout: float = 10.0,
        base_url: str | None = None,
        client_factory: Callable[[], httpx.AsyncClient] | None = None,
    ) -> None:
        self._token = token
        self._timeout = timeout
        self._base_url = (base_url or f"https://api.telegram.org/bot{token}").rstrip("/")
        self._client_factory = client_factory or self._default_client_factory

    async def send(self, *, chat_id: int, reply: Reply) -> SendResult:
        payload = reply.to_payload(chat_id)
        response = await self._post("sendMessage", payload)
        data = self._parse_response_data(response)
        return SendResult(
            ok=True,
            chat_id=chat_id,
            payload=payload,
            status_code=response.status_code,
            data=data,
        )

    async def send_text(
        self,
        *,
        chat_id: int,
        text: str,
        parse_mode: str | None = None,
    ) -> SendResult:
        reply = Reply(text=text, parse_mode=parse_mode or DEFAULT_PARSE_MODE)
        return await self.send(chat_id=chat_id, reply=reply)

    async def send_plain_text(self, *, chat_id: int, text: str) -> SendResult:
        return await self.send(chat_id=chat_id, reply=Reply.plain(text))

    async def send_markdown(self, *, chat_id: int, text: str) -> SendResult:
        return await self.send(chat_id=chat_id, reply=Reply.md(text))

    async def send_payload(self, payload: dict[str, Any]) -> SendResult:
        chat_id = int(payload["chat_id"])
        reply = Reply(
            text=str(payload["text"]),
            parse_mode=payload.get("parse_mode"),
        )
        return await self.send(chat_id=chat_id, reply=reply)

    async def send_safe(
        self,
        *,
        chat_id: int,
        reply: Reply,
        logger: logging.Logger | None = None,
        success_log: str | None = None,
        success_args: tuple[object, ...] = (),
        failure_log: str | None = None,
        failure_args: tuple[object, ...] = (),
    ) -> SendResult | None:
        active_logger = logger or globals()["logger"]
        try:
            result = await self.send(chat_id=chat_id, reply=reply)
        except Exception:
            if failure_log:
                active_logger.exception(failure_log, *failure_args)
            else:
                active_logger.exception("Failed to send Telegram message to chat_id=%s", chat_id)
            return None

        if success_log:
            active_logger.info(success_log, *success_args)
        return result

    async def send_plain_text_safe(
        self,
        *,
        chat_id: int,
        text: str,
        logger: logging.Logger | None = None,
        success_log: str | None = None,
        success_args: tuple[object, ...] = (),
        failure_log: str | None = None,
        failure_args: tuple[object, ...] = (),
    ) -> SendResult | None:
        return await self.send_safe(
            chat_id=chat_id,
            reply=Reply.plain(text),
            logger=logger,
            success_log=success_log,
            success_args=success_args,
            failure_log=failure_log,
            failure_args=failure_args,
        )

    async def send_markdown_safe(
        self,
        *,
        chat_id: int,
        text: str,
        logger: logging.Logger | None = None,
        success_log: str | None = None,
        success_args: tuple[object, ...] = (),
        failure_log: str | None = None,
        failure_args: tuple[object, ...] = (),
    ) -> SendResult | None:
        return await self.send_safe(
            chat_id=chat_id,
            reply=Reply.md(text),
            logger=logger,
            success_log=success_log,
            success_args=success_args,
            failure_log=failure_log,
            failure_args=failure_args,
        )

    async def set_webhook(
        self,
        *,
        url: str,
        secret_token: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"url": url}
        if secret_token:
            payload["secret_token"] = secret_token
        response = await self._post("setWebhook", payload)
        return self._parse_response_data(response)

    async def delete_webhook(
        self,
        *,
        drop_pending_updates: bool = False,
    ) -> dict[str, Any]:
        response = await self._post(
            "deleteWebhook",
            {"drop_pending_updates": drop_pending_updates},
        )
        return self._parse_response_data(response)

    async def _post(self, method: str, payload: dict[str, Any] | None) -> httpx.Response:
        async with self._client_factory() as client:
            response = await client.post(f"{self._base_url}/{method}", json=payload)
        if response.is_error:
            raise TelegramApiError(
                status_code=response.status_code,
                detail=response.text,
            )
        return response

    def _default_client_factory(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(timeout=self._timeout)

    @staticmethod
    def _parse_response_data(response: httpx.Response) -> dict[str, Any]:
        try:
            data = response.json()
        except ValueError as exc:
            raise TelegramSendError("Telegram response was not valid JSON.") from exc
        if not isinstance(data, dict):
            raise TelegramSendError("Telegram response payload must be an object.")
        if data.get("ok") is False:
            raise TelegramApiError(
                status_code=response.status_code,
                detail=str(data.get("description") or "Telegram API returned ok=false."),
            )
        return data


    __all__ = [
    "SendResult",
    "TelegramApiError",
    "TelegramBot",
    "TelegramSendError",
]
