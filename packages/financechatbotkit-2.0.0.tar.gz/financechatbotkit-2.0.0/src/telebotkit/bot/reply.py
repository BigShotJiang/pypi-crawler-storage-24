"""Telegram reply payload helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

DEFAULT_PARSE_MODE = "MarkdownV2"


@dataclass(frozen=True)
class Reply:
    """Simple outbound Telegram reply."""

    text: str
    parse_mode: str | None = DEFAULT_PARSE_MODE

    @classmethod
    def md(cls, text: str) -> "Reply":
        return cls(text=text, parse_mode=DEFAULT_PARSE_MODE)

    @classmethod
    def plain(cls, text: str) -> "Reply":
        return cls(text=text, parse_mode=None)

    def to_payload(self, chat_id: int) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "text": self.text,
        }
        if self.parse_mode:
            payload["parse_mode"] = self.parse_mode
        return payload


__all__ = ["DEFAULT_PARSE_MODE", "Reply"]
