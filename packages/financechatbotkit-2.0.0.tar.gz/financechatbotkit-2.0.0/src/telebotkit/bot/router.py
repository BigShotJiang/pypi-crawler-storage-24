"""Command parsing and routing helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Generic, TypeVar

RequestT = TypeVar("RequestT")
ServicesT = TypeVar("ServicesT")
ResponseT = TypeVar("ResponseT")
CommandHandler = Callable[[RequestT, ServicesT], ResponseT]


@dataclass(frozen=True)
class CommandMatch:
    """Parsed slash-command payload."""

    name: str
    args: str
    invoked_name: str


@dataclass(frozen=True)
class CommandRoute(Generic[RequestT, ServicesT, ResponseT]):
    """Registered command route."""

    name: str
    aliases: tuple[str, ...]
    handler: CommandHandler[RequestT, ServicesT, ResponseT]


class Router(Generic[RequestT, ServicesT, ResponseT]):
    """Register slash commands once and reuse for parse + dispatch."""

    def __init__(self) -> None:
        self._routes_by_command: dict[str, CommandRoute[RequestT, ServicesT, ResponseT]] = {}

    def register(
        self,
        name: str,
        handler: CommandHandler[RequestT, ServicesT, ResponseT],
        *,
        aliases: tuple[str, ...] = (),
    ) -> None:
        route = CommandRoute(
            name=self._normalize_name(name),
            aliases=tuple(self._normalize_name(alias) for alias in aliases),
            handler=handler,
        )
        for command_name in (route.name, *route.aliases):
            self._routes_by_command[command_name] = route

    def add(
        self,
        name: str,
        handler: CommandHandler[RequestT, ServicesT, ResponseT],
        *,
        aliases: tuple[str, ...] = (),
    ) -> None:
        self.register(name, handler, aliases=aliases)

    def command(
        self,
        name: str,
        *,
        aliases: tuple[str, ...] = (),
    ) -> Callable[
        [CommandHandler[RequestT, ServicesT, ResponseT]],
        CommandHandler[RequestT, ServicesT, ResponseT],
    ]:
        def _decorator(
            handler: CommandHandler[RequestT, ServicesT, ResponseT],
        ) -> CommandHandler[RequestT, ServicesT, ResponseT]:
            self.register(name, handler, aliases=aliases)
            return handler

        return _decorator

    def route(
        self,
        name: str,
        *,
        aliases: tuple[str, ...] = (),
    ) -> Callable[
        [CommandHandler[RequestT, ServicesT, ResponseT]],
        CommandHandler[RequestT, ServicesT, ResponseT],
    ]:
        return self.command(name, aliases=aliases)

    def parse(self, text: str) -> CommandMatch | None:
        stripped = (text or "").strip()
        if not stripped or not stripped.startswith("/"):
            return None

        parts = stripped.split(maxsplit=1)
        command_text = parts[0][1:].lower()
        invoked_name = self._normalize_name(command_text.split("@", 1)[0])
        route = self._routes_by_command.get(invoked_name)
        if route is None:
            return None

        args = parts[1].strip() if len(parts) > 1 else ""
        return CommandMatch(name=route.name, args=args, invoked_name=invoked_name)

    def dispatch(
        self,
        command_name: str,
        request: RequestT,
        services: ServicesT,
    ) -> ResponseT | None:
        route = self._routes_by_command.get(self._normalize_name(command_name))
        if route is None:
            return None
        return route.handler(request, services)

    @staticmethod
    def _normalize_name(name: str) -> str:
        return str(name or "").strip().lower()

__all__ = [
    "CommandHandler",
    "CommandMatch",
    "CommandRoute",
    "Router",
]
