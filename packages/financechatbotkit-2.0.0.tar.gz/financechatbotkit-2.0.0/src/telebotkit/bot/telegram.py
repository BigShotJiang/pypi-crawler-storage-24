"""Telegram formatting helpers."""

from __future__ import annotations

SECTION_DIVIDER = "─" * 20
TELEGRAM_MARKDOWN_V2_SPECIAL_CHARS = "_*[]()~`>#+-=|{}.!"


def escape_markdown(text: str) -> str:
    """Escape special Telegram MarkdownV2 characters."""

    escaped = str(text)
    for char in TELEGRAM_MARKDOWN_V2_SPECIAL_CHARS:
        escaped = escaped.replace(char, f"\\{char}")
    return escaped


def format_krw_amount(amount: int) -> str:
    """Format a KRW amount into a compact Korean-readable string."""

    if amount < 0:
        return f"-{format_krw_amount(-amount)}"

    x_1t = 1_000_000_000_000
    x_100m = 100_000_000
    x_10k = 10_000

    if amount >= x_1t:
        return f"{amount / x_1t:,.2f}조"
    if amount >= x_100m:
        return f"{amount / x_100m:,.2f}억"
    if amount >= x_10k:
        return f"{amount / x_10k:,.2f}만"
    return f"{amount:,}"

__all__ = [
    "SECTION_DIVIDER",
    "TELEGRAM_MARKDOWN_V2_SPECIAL_CHARS",
    "escape_markdown",
    "format_krw_amount",
]
