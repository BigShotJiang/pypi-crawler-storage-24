"""Firestore-backed short-lived lease helpers."""

from __future__ import annotations

import logging
import time
from typing import Any

from telebotkit.firestore.client import get_client

logger = logging.getLogger(__name__)


class LeaseStore:
    """Acquire and renew short-lived Firestore document leases."""

    def __init__(
        self,
        *,
        collection_name: str,
        client_provider=get_client,
    ) -> None:
        self._collection_name = collection_name
        self._client_provider = client_provider

    def acquire(
        self,
        *,
        lease_name: str,
        owner_id: str,
        ttl_seconds: float,
    ) -> bool:
        from google.cloud import firestore  # type: ignore

        client = self._client_provider()
        document_reference = client.collection(self._collection_name).document(lease_name)
        transaction = client.transaction()
        now = time.time()
        expires_at = now + max(ttl_seconds, 1.0)

        @firestore.transactional
        def _acquire(transaction_context: Any) -> bool:
            snapshot = document_reference.get(transaction=transaction_context)
            if snapshot.exists:
                data = snapshot.to_dict() or {}
                current_owner = str(data.get("owner_id") or "")
                current_expires_at = float(data.get("expires_at") or 0.0)
                if current_owner and current_owner != owner_id and current_expires_at > now:
                    return False
            transaction_context.set(
                document_reference,
                {
                    "owner_id": owner_id,
                    "expires_at": expires_at,
                    "updated_at": now,
                },
            )
            return True

        return bool(_acquire(transaction))

    def try_acquire(
        self,
        *,
        lease_name: str,
        owner_id: str,
        ttl_seconds: float,
    ) -> bool:
        return self.acquire(
            lease_name=lease_name,
            owner_id=owner_id,
            ttl_seconds=ttl_seconds,
        )
__all__ = ["LeaseStore"]
