"""Shared Firestore client bootstrap and error helpers."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_SERVICE_ACCOUNT_BASE_FIELDS = {
    "type": "service_account",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
}


class FirestoreQuotaError(Exception):
    """Raised when a Firestore operation fails due to quota or write limits."""


def raise_if_quota_error(error: Exception) -> None:
    """Re-raise quota-related Google API exceptions in a stable app-level form."""

    try:
        from google.api_core import exceptions as google_api_exceptions  # type: ignore

        if isinstance(error, google_api_exceptions.ResourceExhausted):
            raise FirestoreQuotaError(str(error)) from error
    except ImportError:
        return


def load_service_account_info_from_env() -> dict[str, Any] | None:
    """Construct service-account credentials from discrete GOOGLE_* env vars."""

    client_email = os.environ.get("GOOGLE_CLIENT_EMAIL", "").strip()
    if not client_email:
        return None

    private_key = os.environ.get("GOOGLE_PRIVATE_KEY", "").strip()
    if "\\n" in private_key and "\n" not in private_key:
        private_key = private_key.replace("\\n", "\n")

    return {
        **_SERVICE_ACCOUNT_BASE_FIELDS,
        "project_id": os.environ.get("GOOGLE_PROJECT_ID", "").strip(),
        "private_key_id": os.environ.get("GOOGLE_PRIVATE_KEY_ID", "").strip(),
        "private_key": private_key,
        "client_email": client_email,
        "client_id": os.environ.get("GOOGLE_CLIENT_ID", "").strip(),
        "client_x509_cert_url": os.environ.get("GOOGLE_CLIENT_X509_CERT_URL", "").strip(),
    }


class FirestoreClientProvider:
    """Lazily create and cache a Firestore client."""

    def __init__(self) -> None:
        self._client = None

    def reset(self) -> None:
        self._client = None

    def get_client(self):
        if self._client is None:
            project_id = (
                os.environ.get("GOOGLE_PROJECT_ID")
                or os.environ.get("FIRESTORE_PROJECT_ID")
                or None
            )

            from google.cloud import firestore  # type: ignore

            service_account_info = load_service_account_info_from_env()
            if service_account_info:
                from google.oauth2 import service_account  # type: ignore

                credentials = service_account.Credentials.from_service_account_info(
                    service_account_info,
                    scopes=["https://www.googleapis.com/auth/datastore"],
                )
                self._client = firestore.Client(
                    project=project_id or service_account_info.get("project_id") or None,
                    credentials=credentials,
                )
                logger.info("Firestore client created from individual GOOGLE_* env vars.")
            else:
                credentials_json = os.environ.get(
                    "GOOGLE_APPLICATION_CREDENTIALS_JSON",
                    "",
                ).strip()
                if credentials_json:
                    from google.oauth2 import service_account  # type: ignore

                    info = json.loads(credentials_json)
                    credentials = service_account.Credentials.from_service_account_info(
                        info,
                        scopes=["https://www.googleapis.com/auth/datastore"],
                    )
                    self._client = firestore.Client(
                        project=project_id,
                        credentials=credentials,
                    )
                    logger.info(
                        "Firestore client created from GOOGLE_APPLICATION_CREDENTIALS_JSON."
                    )
                else:
                    self._client = firestore.Client(project=project_id)
                    logger.info(
                        "Firestore client created from Application Default Credentials."
                    )
        return self._client

FirestoreClientFactory = FirestoreClientProvider

_DEFAULT_CLIENT_PROVIDER = FirestoreClientProvider()


def get_client():
    """Return the shared cached Firestore client."""

    return _DEFAULT_CLIENT_PROVIDER.get_client()


def reset_client() -> None:
    """Reset the shared cached Firestore client."""

    _DEFAULT_CLIENT_PROVIDER.reset()

__all__ = [
    "FirestoreClientFactory",
    "FirestoreClientProvider",
    "FirestoreQuotaError",
    "get_client",
    "load_service_account_info_from_env",
    "raise_if_quota_error",
    "reset_client",
]
