"""Typed Firestore repository helpers."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, Generic, TypeVar

from telebotkit.firestore.client import get_client
from telebotkit.firestore.fetch import FetchResult, fetch_document, invalidate_document_cache

DocumentT = TypeVar("DocumentT")


class DocumentStore(Generic[DocumentT]):
    """Typed access to a Firestore collection with explicit document IDs."""

    def __init__(
        self,
        *,
        collection_name: str,
        from_dict: Callable[[dict[str, Any]], DocumentT],
        to_dict: Callable[[DocumentT], dict[str, Any]],
        client_provider: Callable[[], Any] = get_client,
        cache_ttl_seconds: float | None = None,
    ) -> None:
        self._collection_name = collection_name
        self._from_dict = from_dict
        self._to_dict = to_dict
        self._client_provider = client_provider
        self._cache_ttl_seconds = cache_ttl_seconds

    def get_result(
        self,
        document_id: str,
        *,
        force_refresh: bool = False,
    ) -> FetchResult[DocumentT]:
        return fetch_document(
            self._collection_name,
            document_id,
            parse=self._from_dict,
            client_provider=self._client_provider,
            cache_ttl_seconds=self._cache_ttl_seconds,
            force_refresh=force_refresh,
        )

    def get(
        self,
        document_id: str,
        *,
        force_refresh: bool = False,
    ) -> DocumentT | None:
        result = self.get_result(document_id, force_refresh=force_refresh)
        if result.error is not None:
            raise result.error
        return result.data

    def get_or_create(
        self,
        document_id: str,
        factory: Callable[[], DocumentT],
    ) -> DocumentT:
        document = self.get(document_id)
        return document if document is not None else factory()

    def save(
        self,
        document_id: str,
        value: DocumentT,
        *,
        merge: bool = False,
    ) -> None:
        self._collection().document(document_id).set(self._to_dict(value), merge=merge)
        invalidate_document_cache(self._collection_name, document_id)

    def update(
        self,
        document_id: str,
        fields: dict[str, Any],
        *,
        merge: bool = True,
    ) -> None:
        self._collection().document(document_id).set(fields, merge=merge)
        invalidate_document_cache(self._collection_name, document_id)

    def set_fields(
        self,
        document_id: str,
        payload: dict[str, Any],
        *,
        merge: bool = True,
    ) -> None:
        self.update(document_id, payload, merge=merge)

    def list_all(self) -> list[DocumentT]:
        return [
            self._from_dict(document.to_dict() or {})
            for document in self._collection().stream()
        ]

    def document(self, document_id: str):
        return self._collection().document(document_id)

    def _collection(self):
        return self._client_provider().collection(self._collection_name)


class SharedDocumentStore(Generic[DocumentT]):
    """Typed repository for a single shared Firestore document."""

    def __init__(
        self,
        *,
        collection_name: str,
        document_id: str,
        from_dict: Callable[[dict[str, Any]], DocumentT],
        to_dict: Callable[[DocumentT], dict[str, Any]],
        client_provider: Callable[[], Any] = get_client,
        cache_ttl_seconds: float | None = None,
    ) -> None:
        self._store = DocumentStore(
            collection_name=collection_name,
            from_dict=from_dict,
            to_dict=to_dict,
            client_provider=client_provider,
            cache_ttl_seconds=cache_ttl_seconds,
        )
        self._document_id = document_id

    def get_result(
        self,
        *,
        force_refresh: bool = False,
    ) -> FetchResult[DocumentT]:
        return self._store.get_result(
            self._document_id,
            force_refresh=force_refresh,
        )

    def get(self, *, force_refresh: bool = False) -> DocumentT | None:
        return self._store.get(
            self._document_id,
            force_refresh=force_refresh,
        )

    def get_or_create(self, factory: Callable[[], DocumentT]) -> DocumentT:
        return self._store.get_or_create(self._document_id, factory)

    def save(self, value: DocumentT, *, merge: bool = False) -> None:
        self._store.save(self._document_id, value, merge=merge)

    def update(self, fields: dict[str, Any], *, merge: bool = True) -> None:
        self._store.update(self._document_id, fields, merge=merge)

    def set_fields(self, payload: dict[str, Any], *, merge: bool = True) -> None:
        self.update(payload, merge=merge)

    def document(self):
        return self._store.document(self._document_id)

__all__ = [
    "DocumentStore",
    "SharedDocumentStore",
]
