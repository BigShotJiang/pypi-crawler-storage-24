"""Firestore upload helpers for prevalidated JSON payloads."""

from __future__ import annotations

from typing import Any

from telebotkit.firestore.client import get_client
from telebotkit.sheets import load_typed_rows_json, validate_typed_rows_payload


def upload_typed_rows_payload(
    *,
    payload: dict[str, Any],
    collection_name: str,
    document_id: str,
    document_type: str = "typed_rows",
    records_field: str = "records",
    metadata_field: str = "metadata",
    key_field_name: str = "key",
) -> str:
    validated = validate_typed_rows_payload(
        payload,
        document_type=document_type,
        records_field=records_field,
        metadata_field=metadata_field,
        key_field_name=key_field_name,
    )
    get_client().collection(collection_name).document(document_id).set(
        {
            "document_type": document_type,
            "schema_version": int(validated.get("schema_version", 1) or 1),
            records_field: validated.get(records_field) or {},
            metadata_field: validated.get(metadata_field) or {},
        },
        merge=True,
    )
    meta = validated.get(metadata_field) or {}
    return (
        "업로드 완료:\n"
        f"- Firestore: {collection_name}/{document_id}\n"
        f"- record_count: {meta.get('record_count')}\n"
        f"- size_bytes: {meta.get('size_bytes')}\n"
    )


def upload_typed_rows_json(
    *,
    json_path: str,
    collection_name: str,
    document_id: str,
    document_type: str = "typed_rows",
    records_field: str = "records",
    metadata_field: str = "metadata",
    key_field_name: str = "key",
) -> str:
    payload = load_typed_rows_json(
        json_path,
        document_type=document_type,
        records_field=records_field,
        metadata_field=metadata_field,
        key_field_name=key_field_name,
    )
    result = upload_typed_rows_payload(
        payload=payload,
        collection_name=collection_name,
        document_id=document_id,
        document_type=document_type,
        records_field=records_field,
        metadata_field=metadata_field,
        key_field_name=key_field_name,
    )
    return result.replace("업로드 완료:\n", f"업로드 완료:\n- JSON: {json_path}\n", 1)


__all__ = ["upload_typed_rows_json", "upload_typed_rows_payload"]
