"""Higher-level Firestore document fetch helpers with optional caching."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import time
from typing import Any, Callable, Generic, TypeVar

from telebotkit.firestore.client import FirestoreQuotaError, get_client, raise_if_quota_error

DocumentT = TypeVar("DocumentT")


@dataclass(frozen=True)
class FetchResult(Generic[DocumentT]):
    """Result of fetching one Firestore document."""

    collection_name: str
    document_id: str
    found: bool
    data: DocumentT | None = None
    raw_data: dict[str, Any] | None = None
    error: Exception | None = None
    from_cache: bool = False

    @property
    def ok(self) -> bool:
        return self.error is None

    @property
    def missing(self) -> bool:
        return self.error is None and not self.found

    @property
    def has_data(self) -> bool:
        return self.error is None and self.found and self.data is not None

    @property
    def is_quota_error(self) -> bool:
        return isinstance(self.error, FirestoreQuotaError)


@dataclass
class _CacheEntry:
    found: bool
    raw_data: dict[str, Any] | None
    expires_at: float


_DOCUMENT_CACHE: dict[tuple[str, str], _CacheEntry] = {}


def clear_document_cache() -> None:
    """Drop all cached document fetch entries."""

    _DOCUMENT_CACHE.clear()


def invalidate_document_cache(collection_name: str, document_id: str) -> None:
    """Drop one cached document fetch entry."""

    _DOCUMENT_CACHE.pop((collection_name, document_id), None)


def fetch_document(
    collection_name: str,
    document_id: str,
    *,
    parse: Callable[[dict[str, Any]], DocumentT] | None = None,
    client_provider: Callable[[], Any] = get_client,
    cache_ttl_seconds: float | None = None,
    force_refresh: bool = False,
) -> FetchResult[Any]:
    """Fetch one Firestore document as raw data or a parsed value."""

    cache_key = (collection_name, document_id)
    if not force_refresh and cache_ttl_seconds and cache_ttl_seconds > 0:
        cached_entry = _DOCUMENT_CACHE.get(cache_key)
        if cached_entry is not None:
            if cached_entry.expires_at > time.monotonic():
                return _result_from_entry(
                    collection_name=collection_name,
                    document_id=document_id,
                    entry=cached_entry,
                    parse=parse,
                    from_cache=True,
                )
            invalidate_document_cache(collection_name, document_id)

    try:
        document = client_provider().collection(collection_name).document(document_id).get()
        if not document.exists:
            _cache_entry(
                cache_key,
                found=False,
                raw_data=None,
                cache_ttl_seconds=cache_ttl_seconds,
            )
            return FetchResult(
                collection_name=collection_name,
                document_id=document_id,
                found=False,
            )

        raw_data = dict(document.to_dict() or {})
        _cache_entry(
            cache_key,
            found=True,
            raw_data=raw_data,
            cache_ttl_seconds=cache_ttl_seconds,
        )
        return _build_result(
            collection_name=collection_name,
            document_id=document_id,
            found=True,
            raw_data=raw_data,
            parse=parse,
            from_cache=False,
        )
    except Exception as error:
        normalized_error = _normalize_error(error)
        return FetchResult(
            collection_name=collection_name,
            document_id=document_id,
            found=False,
            error=normalized_error,
        )


def _result_from_entry(
    *,
    collection_name: str,
    document_id: str,
    entry: _CacheEntry,
    parse: Callable[[dict[str, Any]], DocumentT] | None,
    from_cache: bool,
) -> FetchResult[Any]:
    return _build_result(
        collection_name=collection_name,
        document_id=document_id,
        found=entry.found,
        raw_data=deepcopy(entry.raw_data),
        parse=parse,
        from_cache=from_cache,
    )


def _build_result(
    *,
    collection_name: str,
    document_id: str,
    found: bool,
    raw_data: dict[str, Any] | None,
    parse: Callable[[dict[str, Any]], DocumentT] | None,
    from_cache: bool,
) -> FetchResult[Any]:
    if not found:
        return FetchResult(
            collection_name=collection_name,
            document_id=document_id,
            found=False,
            from_cache=from_cache,
        )

    safe_raw = deepcopy(raw_data) if raw_data is not None else {}
    if parse is None:
        return FetchResult(
            collection_name=collection_name,
            document_id=document_id,
            found=True,
            data=safe_raw,
            raw_data=safe_raw,
            from_cache=from_cache,
        )

    try:
        parsed = parse(deepcopy(safe_raw))
    except Exception as error:
        return FetchResult(
            collection_name=collection_name,
            document_id=document_id,
            found=True,
            raw_data=safe_raw,
            error=error,
            from_cache=from_cache,
        )

    return FetchResult(
        collection_name=collection_name,
        document_id=document_id,
        found=True,
        data=parsed,
        raw_data=safe_raw,
        from_cache=from_cache,
    )


def _cache_entry(
    cache_key: tuple[str, str],
    *,
    found: bool,
    raw_data: dict[str, Any] | None,
    cache_ttl_seconds: float | None,
) -> None:
    if not cache_ttl_seconds or cache_ttl_seconds <= 0:
        return
    _DOCUMENT_CACHE[cache_key] = _CacheEntry(
        found=found,
        raw_data=deepcopy(raw_data),
        expires_at=time.monotonic() + cache_ttl_seconds,
    )


def _normalize_error(error: Exception) -> Exception:
    try:
        raise_if_quota_error(error)
    except Exception as normalized_error:
        return normalized_error
    return error


__all__ = [
    "FetchResult",
    "clear_document_cache",
    "fetch_document",
    "invalidate_document_cache",
]
