"""CLI utility for refreshing the bundled OpenDart corp-code JSON."""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Sequence

from ..exceptions import MappingWorkflowError
from .workflow import download_latest_raw_entries

_DEFAULT_OUTPUT_PATH = Path(__file__).resolve().parent / "data" / "corp_codes_raw.json"


def get_default_output_path() -> Path:
    return _DEFAULT_OUTPUT_PATH


def update_raw_corp_codes_file(
    *,
    api_key: str,
    output_path: str | Path | None = None,
) -> tuple[Path, int]:
    target_path = Path(output_path) if output_path is not None else get_default_output_path()
    raw_entries = download_latest_raw_entries(api_key)
    payload = [
        {
            "corp_code": row["corp_code"],
            "corp_name": row["stock_name"],
            "stock_code": row["stock_code"],
            "modify_date": row["modify_date"],
        }
        for row in raw_entries
    ]
    serialized = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"

    target_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            dir=target_path.parent,
            delete=False,
        ) as handle:
            handle.write(serialized)
            temp_path = Path(handle.name)
        temp_path.replace(target_path)
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()
    return target_path, len(payload)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Refresh the bundled OpenDart corp_codes_raw.json file.",
    )
    parser.add_argument(
        "--api-key",
        default=os.environ.get("DART_API_KEY"),
        help="OpenDart API key. Defaults to the DART_API_KEY environment variable.",
    )
    parser.add_argument(
        "--output",
        default=None,
        help=f"Output path. Defaults to {get_default_output_path()}",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.api_key:
        parser.error("--api-key is required unless DART_API_KEY is set.")

    try:
        output_path, entry_count = update_raw_corp_codes_file(
            api_key=args.api_key,
            output_path=args.output,
        )
    except (MappingWorkflowError, OSError) as exc:
        print(f"Failed to refresh corp codes: {exc}", file=sys.stderr)
        return 1

    print(f"Updated {output_path} with {entry_count} entries.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
