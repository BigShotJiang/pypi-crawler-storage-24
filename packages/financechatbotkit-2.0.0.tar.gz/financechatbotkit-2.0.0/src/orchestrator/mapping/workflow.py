"""Mapping workflow for OpenDart corp-code data."""

from __future__ import annotations

import io
import json
import ssl
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from collections import OrderedDict
from importlib.resources import files
from typing import Any

from ..exceptions import DownloadError, InvalidInputError, NotFoundError

_CORP_CODE_URL = "https://opendart.fss.or.kr/api/corpCode.xml"
_BUNDLED_DATA_KEY = "__bundled__"
_MISSING = object()


def _normalize_entry(item: Any) -> dict[str, Any]:
    if not isinstance(item, dict):
        raise InvalidInputError("Each corp-code entry must be a JSON object.")
    corp_code = _clean(item.get("corp_code"))
    stock_name = _clean(item.get("corp_name") or item.get("stock_name"))
    stock_code = _clean(item.get("stock_code"))
    modify_date = _clean(item.get("modify_date"))
    if corp_code is None or stock_name is None:
        raise InvalidInputError("Each corp-code entry must include corp_code and corp_name.")
    return {
        "corp_code": corp_code,
        "stock_name": stock_name,
        "stock_code": stock_code,
        "modify_date": modify_date,
    }



def _clean(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None



def _normalize_name(value: str) -> str:
    return " ".join(value.split()).casefold()



def _build_input_payload(
    *,
    stock_code: str | None,
    stock_name: str | None,
    corp_code: str | None,
    get_latest: bool,
    get_all: bool,
    include_nonlisted: bool,
) -> dict[str, Any]:
    return {
        "stock_code": _clean(stock_code),
        "stock_name": _clean(stock_name),
        "corp_code": _clean(corp_code),
        "get_latest": get_latest,
        "get_all": get_all,
        "include_nonlisted": include_nonlisted,
    }



def _detect_lookup_key(*, stock_code: str | None, stock_name: str | None, corp_code: str | None) -> tuple[str, str]:
    provided = [
        ("stock_code", _clean(stock_code)),
        ("stock_name", _clean(stock_name)),
        ("corp_code", _clean(corp_code)),
    ]
    provided = [(key, value) for key, value in provided if value is not None]
    if len(provided) != 1:
        raise InvalidInputError("Exactly one of stock_code, stock_name, or corp_code must be provided.")
    return provided[0]



def _filter_entries(entries: tuple[dict[str, Any], ...], lookup_key: str, lookup_value: str) -> list[dict[str, Any]]:
    if lookup_key == "stock_name":
        normalized = _normalize_name(lookup_value)
        return [entry for entry in entries if _normalize_name(entry["stock_name"]) == normalized]
    return [entry for entry in entries if entry[lookup_key] == lookup_value]



def download_latest_raw_entries(api_key: str) -> tuple[dict[str, Any], ...]:
    api_key = _clean(api_key)
    if api_key is None:
        raise InvalidInputError("api_key is required when get_latest=True.")

    query = urllib.parse.urlencode({"crtfc_key": api_key})
    request_url = f"{_CORP_CODE_URL}?{query}"
    try:
        with urllib.request.urlopen(request_url, timeout=60, context=ssl.create_default_context()) as response:
            content = response.read()
    except (urllib.error.URLError, TimeoutError) as exc:
        raise DownloadError("Failed to download OpenDart corpCode.xml.") from exc

    try:
        with zipfile.ZipFile(io.BytesIO(content)) as zipped:
            xml_name = next(name for name in zipped.namelist() if name.upper().endswith(".XML"))
            xml_bytes = zipped.read(xml_name)
    except (StopIteration, zipfile.BadZipFile, KeyError) as exc:
        raise DownloadError("Downloaded OpenDart corpCode.xml payload is invalid.") from exc

    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as exc:
        raise DownloadError("OpenDart corpCode.xml could not be parsed.") from exc

    rows: list[dict[str, Any]] = []
    for item in root.iter("list"):
        rows.append(
            {
                "corp_code": _clean(item.findtext("corp_code")),
                "corp_name": _clean(item.findtext("corp_name")),
                "stock_code": _clean(item.findtext("stock_code")),
                "modify_date": _clean(item.findtext("modify_date")),
            }
        )
    return tuple(_normalize_entry(row) for row in rows)


class MappingWorkflow:
    """Resolve stock_name, stock_code, and corp_code from OpenDart corp-code data."""

    def __init__(self, *, cache_size: int = 0, data_path: str | None = None) -> None:
        if cache_size < 0:
            raise InvalidInputError("cache_size must be >= 0.")
        self._cache_size = cache_size
        self._data_path = data_path
        self._raw_cache: OrderedDict[str, tuple[dict[str, Any], ...]] = OrderedDict()
        self._processed_cache: OrderedDict[tuple[str, bool], tuple[dict[str, Any], ...]] = OrderedDict()

    @property
    def cache_size(self) -> int:
        return self._cache_size

    def clear_cache(self) -> None:
        self._raw_cache.clear()
        self._processed_cache.clear()

    def run(
        self,
        *,
        stock_code: str | None = None,
        stock_name: str | None = None,
        corp_code: str | None = None,
        get_latest: bool = False,
        get_all: bool = False,
        include_nonlisted: bool = False,
        api_key: str | None = None,
        data_path: str | None = None,
    ) -> dict[str, Any]:
        input_payload = _build_input_payload(
            stock_code=stock_code,
            stock_name=stock_name,
            corp_code=corp_code,
            get_latest=get_latest,
            get_all=get_all,
            include_nonlisted=include_nonlisted,
        )

        if get_latest:
            raw_entries = download_latest_raw_entries(api_key or "")
            entries = tuple(
                {
                    "stock_name": row["stock_name"],
                    "stock_code": row["stock_code"],
                    "corp_code": row["corp_code"],
                }
                for row in raw_entries
                if include_nonlisted or row["stock_code"] is not None
            )
        else:
            entries = self._load_processed_entries(data_path, include_nonlisted)

        if get_all:
            return {
                "input": input_payload,
                "data": {"mappings": list(entries)},
            }

        lookup_key, lookup_value = _detect_lookup_key(
            stock_code=stock_code,
            stock_name=stock_name,
            corp_code=corp_code,
        )
        matches = _filter_entries(entries, lookup_key, lookup_value)
        if not matches:
            raise NotFoundError(f"No mapping found for {lookup_key}={lookup_value!r}.")
        return {
            "input": input_payload,
            "data": {"mappings": matches},
        }

    def _load_raw_entries(self, data_path: str | None) -> tuple[dict[str, Any], ...]:
        resolved_data_path = self._resolve_data_path(data_path)
        cache_key = resolved_data_path or _BUNDLED_DATA_KEY
        cached = self._cache_get(self._raw_cache, cache_key)
        if cached is not _MISSING:
            return cached

        if resolved_data_path is None:
            resource = files("orchestrator.mapping.data").joinpath("corp_codes_raw.json")
            text = resource.read_text(encoding="utf-8")
        else:
            with open(resolved_data_path, "r", encoding="utf-8") as handle:
                text = handle.read()

        data = json.loads(text)
        if not isinstance(data, list):
            raise InvalidInputError("Bundled corp-code JSON must contain a list of entries.")
        rows = tuple(_normalize_entry(item) for item in data)
        self._cache_set(self._raw_cache, cache_key, rows)
        return rows

    def _load_processed_entries(
        self,
        data_path: str | None,
        include_nonlisted: bool,
    ) -> tuple[dict[str, Any], ...]:
        resolved_data_path = self._resolve_data_path(data_path)
        cache_key = (resolved_data_path or _BUNDLED_DATA_KEY, include_nonlisted)
        cached = self._cache_get(self._processed_cache, cache_key)
        if cached is not _MISSING:
            return cached

        rows = self._load_raw_entries(resolved_data_path)
        processed: list[dict[str, Any]] = []
        for row in rows:
            stock_code = row["stock_code"]
            if not include_nonlisted and stock_code is None:
                continue
            processed.append(
                {
                    "stock_name": row["stock_name"],
                    "stock_code": stock_code,
                    "corp_code": row["corp_code"],
                }
            )
        result = tuple(processed)
        self._cache_set(self._processed_cache, cache_key, result)
        return result

    def _resolve_data_path(self, data_path: str | None) -> str | None:
        return data_path if data_path is not None else self._data_path

    def _cache_get(self, cache: OrderedDict[Any, Any], key: Any) -> Any:
        if self._cache_size == 0:
            return _MISSING
        try:
            value = cache.pop(key)
        except KeyError:
            return _MISSING
        cache[key] = value
        return value

    def _cache_set(self, cache: OrderedDict[Any, Any], key: Any, value: Any) -> None:
        if self._cache_size == 0:
            return
        if key in cache:
            cache.pop(key)
        cache[key] = value
        while len(cache) > self._cache_size:
            cache.popitem(last=False)


_DEFAULT_WORKFLOW = MappingWorkflow(cache_size=0)



def run_mapping_workflow(
    *,
    stock_code: str | None = None,
    stock_name: str | None = None,
    corp_code: str | None = None,
    get_latest: bool = False,
    get_all: bool = False,
    include_nonlisted: bool = False,
    api_key: str | None = None,
    data_path: str | None = None,
) -> dict[str, Any]:
    return _DEFAULT_WORKFLOW.run(
        stock_code=stock_code,
        stock_name=stock_name,
        corp_code=corp_code,
        get_latest=get_latest,
        get_all=get_all,
        include_nonlisted=include_nonlisted,
        api_key=api_key,
        data_path=data_path,
    )
