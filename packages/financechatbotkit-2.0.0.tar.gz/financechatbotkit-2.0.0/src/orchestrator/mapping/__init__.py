"""Mapping workflows for FinanceChatbot.

For development:
    run `orchestrator-update-corp-codes --api-key "$DART_API_KEY"` to update the raw corp codes file
"""

from .workflow import MappingWorkflow, download_latest_raw_entries, run_mapping_workflow

__all__ = [
    "MappingWorkflow",
    "download_latest_raw_entries",
    "run_mapping_workflow",
    "update_raw_corp_codes_file",
]


def __getattr__(name: str):
    if name == "update_raw_corp_codes_file":
        from .update_raw_data import update_raw_corp_codes_file

        return update_raw_corp_codes_file
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
