"""Bundled corp-code data for mapping workflows."""
