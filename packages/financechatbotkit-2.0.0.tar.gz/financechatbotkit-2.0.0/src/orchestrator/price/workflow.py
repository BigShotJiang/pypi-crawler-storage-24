"""Price workflows built on FinanceDataReader."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any

from ..exceptions import InvalidInputError, NotFoundError


@dataclass(frozen=True)
class PriceBar:
    """Normalized daily price bar."""

    trade_date: str
    open: int | None = None
    close: int | None = None
    low: int | None = None
    high: int | None = None
    volume: int | None = None

    def has_fields(self, field_names: tuple[str, ...]) -> bool:
        return all(getattr(self, field_name) is not None for field_name in field_names)

    def to_dict(self, *, field_names: tuple[str, ...]) -> dict[str, int | str]:
        payload: dict[str, int | str] = {"date": self.trade_date}
        for field_name in field_names:
            value = getattr(self, field_name)
            if value is None:
                raise InvalidInputError(f"Missing {field_name} value for trade_date={self.trade_date}.")
            payload[field_name] = value
        return payload


_PRICE_FIELD_PRESETS: dict[str, tuple[str, ...]] = {
    "close": ("close",),
    "oclh": ("open", "close", "low", "high"),
    "oclhv": ("open", "close", "low", "high", "volume"),
}

_PRICE_SOURCE_COLUMNS = {
    "open": "Open",
    "close": "Close",
    "low": "Low",
    "high": "High",
    "volume": "Volume",
}


class PriceSnapshotWorkflow:
    """Return the latest price and the closest previous price."""

    def __init__(self, *, lookback_days: int = 30) -> None:
        if lookback_days < 2:
            raise InvalidInputError("lookback_days must be >= 2.")
        self._lookback_days = lookback_days

    def run(
        self,
        *,
        stock_code: str,
        lookback_days: int | None = None,
        price_fields: str = "close",
    ) -> dict[str, Any]:
        stock_code = _normalize_stock_code(stock_code)
        window = lookback_days if lookback_days is not None else self._lookback_days
        if window < 2:
            raise InvalidInputError("lookback_days must be >= 2.")
        normalized_price_fields, field_names = _normalize_price_fields(price_fields)

        bars = _fetch_price_bars(
            stock_code=stock_code,
            start=(date.today() - timedelta(days=window)).isoformat(),
            end=date.today().isoformat(),
            field_names=field_names,
        )
        if len(bars) < 2:
            raise NotFoundError(f"Not enough price history found for stock_code={stock_code!r}.")

        latest = bars[-1]
        previous = bars[-2]
        response = {
            "input": {
                "stock_code": stock_code,
                "lookback_days": window,
                "price_fields": normalized_price_fields,
            },
            "data": {},
        }
        if normalized_price_fields == "close":
            response["data"] = {
                "lastClose": previous.close,
                "latestClose": latest.close,
            }
            return response

        response["data"] = {
            "lastPrice": previous.to_dict(field_names=field_names),
            "latestPrice": latest.to_dict(field_names=field_names),
        }
        return response


class PricePeriodWorkflow:
    """Return daily prices for a specific period."""

    def run(
        self,
        *,
        stock_code: str,
        start_date: str,
        end_date: str | None = None,
        price_fields: str = "close",
    ) -> dict[str, Any]:
        stock_code = _normalize_stock_code(stock_code)
        start_date = _normalize_date_string(start_date, field_name="start_date")
        end_date = _normalize_date_string(end_date, field_name="end_date") if end_date else date.today().isoformat()
        if start_date > end_date:
            raise InvalidInputError("start_date must be <= end_date.")
        normalized_price_fields, field_names = _normalize_price_fields(price_fields)

        bars = _fetch_price_bars(
            stock_code=stock_code,
            start=start_date,
            end=end_date,
            field_names=field_names,
        )
        if not bars:
            raise NotFoundError(
                f"No price data found for stock_code={stock_code!r} between {start_date} and {end_date}."
            )

        return {
            "input": {
                "stock_code": stock_code,
                "start_date": start_date,
                "end_date": end_date,
                "price_fields": normalized_price_fields,
            },
            "data": {
                "prices": [
                    bar.to_dict(field_names=field_names)
                    for bar in bars
                ]
            },
        }


_DEFAULT_SNAPSHOT_WORKFLOW = PriceSnapshotWorkflow()
_DEFAULT_PERIOD_WORKFLOW = PricePeriodWorkflow()


def run_price_snapshot_workflow(
    *,
    stock_code: str,
    lookback_days: int = 30,
    price_fields: str = "close",
) -> dict[str, Any]:
    return _DEFAULT_SNAPSHOT_WORKFLOW.run(
        stock_code=stock_code,
        lookback_days=lookback_days,
        price_fields=price_fields,
    )


def run_price_period_workflow(
    *,
    stock_code: str,
    start_date: str,
    end_date: str | None = None,
    price_fields: str = "close",
) -> dict[str, Any]:
    return _DEFAULT_PERIOD_WORKFLOW.run(
        stock_code=stock_code,
        start_date=start_date,
        end_date=end_date,
        price_fields=price_fields,
    )



def _fetch_price_bars(
    *,
    stock_code: str,
    start: str,
    end: str,
    field_names: tuple[str, ...],
) -> list[PriceBar]:
    df = _load_price_frame(stock_code=stock_code, start=start, end=end)
    if df is None or df.empty:
        return []

    bars: list[PriceBar] = []
    for idx, row in df.iterrows():
        bar = _build_price_bar(idx=idx, row=row)
        if bar.has_fields(field_names):
            bars.append(bar)
    return bars



def _load_price_frame(*, stock_code: str, start: str, end: str):
    try:
        import FinanceDataReader as fdr  # noqa: PLC0415
    except ImportError as exc:
        raise InvalidInputError("FinanceDataReader is required for price workflows.") from exc
    return fdr.DataReader(stock_code, start, end)



def _normalize_stock_code(stock_code: str) -> str:
    normalized = str(stock_code or "").strip()
    if not normalized:
        raise InvalidInputError("stock_code is required.")
    return normalized



def _normalize_date_string(value: str | None, *, field_name: str) -> str:
    normalized = str(value or "").strip()
    if not normalized:
        raise InvalidInputError(f"{field_name} is required.")
    try:
        return date.fromisoformat(normalized).isoformat()
    except ValueError as exc:
        raise InvalidInputError(f"{field_name} must be YYYY-MM-DD.") from exc


def _normalize_price_fields(price_fields: str | None) -> tuple[str, tuple[str, ...]]:
    normalized = str(price_fields or "close").strip().lower()
    field_names = _PRICE_FIELD_PRESETS.get(normalized)
    if field_names is None:
        raise InvalidInputError("price_fields must be one of: close, oclh, oclhv.")
    return normalized, field_names


def _build_price_bar(*, idx: Any, row: Any) -> PriceBar:
    values: dict[str, int] = {}
    for field_name, column_name in _PRICE_SOURCE_COLUMNS.items():
        value = row.get(column_name)
        if _is_missing(value):
            continue
        values[field_name] = int(value)
    trade_date = idx.date().isoformat() if hasattr(idx, "date") else str(idx)[:10]
    return PriceBar(trade_date=trade_date, **values)


def _is_missing(value: Any) -> bool:
    return value is None or value != value
