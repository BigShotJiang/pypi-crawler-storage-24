"""Exceptions for the mapping workflow library."""


class MappingWorkflowError(Exception):
    """Base exception for mapping workflow failures."""


class InvalidInputError(MappingWorkflowError):
    """Raised when the workflow input contract is violated."""


class NotFoundError(MappingWorkflowError):
    """Raised when no mapping matches the requested lookup."""


class DownloadError(MappingWorkflowError):
    """Raised when latest OpenDart corp-code data cannot be downloaded."""
