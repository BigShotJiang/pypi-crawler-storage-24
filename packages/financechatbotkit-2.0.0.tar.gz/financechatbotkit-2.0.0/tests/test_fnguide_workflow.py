from unittest.mock import patch

import pytest

from orchestrator import DownloadError, InvalidInputError
from orchestrator.fnguide import FnGuideWorkflow, run_fnguide_workflow


def _sample_html(*, report_gb: str, title: str, row_label: str) -> str:
    return f"""
    <html>
      <head><title>{title}</title></head>
      <body>
        <input id="gicode" value="A005930" />
        <input id="ReportGb" value="{report_gb}" />
        <input id="NewMenuID" value="103" />
        <div class="ul_col2wrap pd_t25">
          <h2>{title}</h2>
          <span class="stxt">연간</span>
          <span class="txt1">억원</span>
          <table>
            <caption>{title}</caption>
            <thead>
              <tr>
                <th>IFRS(연결)</th>
                <th>2023/12</th>
                <th>2024/12</th>
              </tr>
            </thead>
            <tbody>
              <tr id="p_main">
                <th>{row_label}</th>
                <td title="100">100</td>
                <td title="120">120</td>
              </tr>
            </tbody>
          </table>
        </div>
      </body>
    </html>
    """


def test_run_fnguide_workflow_returns_financials_and_ratios() -> None:
    ratio_html = _sample_html(report_gb="D", title="재무비율", row_label="영업이익률")
    statement_html = _sample_html(report_gb="D", title="손익계산서", row_label="매출액")

    with patch(
        "orchestrator.fnguide.workflow.fetch_fnguide_page",
        side_effect=[ratio_html, statement_html],
    ):
        result = run_fnguide_workflow(stock_code="005930", statement_type="consolidated")

    assert result["input"] == {
        "stock_code": "005930",
        "statement_type": "consolidated",
        "timeout": 30.0,
    }
    assert result["data"]["financials"]["tables"][0]["sections"][0]["rows"][0]["label"] == "매출액"
    assert result["data"]["ratios"]["tables"][0]["sections"][0]["rows"][0]["label"] == "영업이익률"


def test_workflow_uses_separate_report_gb() -> None:
    workflow = FnGuideWorkflow()
    ratio_html = _sample_html(report_gb="B", title="재무비율", row_label="영업이익률")
    statement_html = _sample_html(report_gb="B", title="손익계산서", row_label="매출액")

    with patch(
        "orchestrator.fnguide.workflow.fetch_fnguide_page",
        side_effect=[ratio_html, statement_html],
    ) as fetch_mock:
        workflow.run(stock_code="005930", statement_type="separate", timeout=10.0)

    assert fetch_mock.call_args_list[0].kwargs["params"]["ReportGB"] == "B"
    assert fetch_mock.call_args_list[1].kwargs["params"]["ReportGB"] == "B"


def test_workflow_passes_custom_user_agent() -> None:
    workflow = FnGuideWorkflow()
    ratio_html = _sample_html(report_gb="D", title="재무비율", row_label="영업이익률")
    statement_html = _sample_html(report_gb="D", title="손익계산서", row_label="매출액")

    with patch(
        "orchestrator.fnguide.workflow.fetch_fnguide_page",
        side_effect=[ratio_html, statement_html],
    ) as fetch_mock:
        workflow.run(
            stock_code="005930",
            statement_type="consolidated",
            user_agent="custom-agent/1.0",
        )

    assert fetch_mock.call_args_list[0].kwargs["user_agent"] == "custom-agent/1.0"
    assert fetch_mock.call_args_list[1].kwargs["user_agent"] == "custom-agent/1.0"


def test_invalid_statement_type_raises() -> None:
    with pytest.raises(InvalidInputError):
        run_fnguide_workflow(stock_code="005930", statement_type="weird")


def test_fetch_errors_raise_download_error() -> None:
    import httpx

    request = httpx.Request("GET", "https://example.com")
    with patch(
        "orchestrator.fnguide.workflow.httpx.get",
        side_effect=httpx.HTTPStatusError("bad", request=request, response=httpx.Response(500, request=request)),
    ):
        with pytest.raises(DownloadError):
            from orchestrator.fnguide.workflow import fetch_fnguide_page

            fetch_fnguide_page(
                url="https://example.com",
                params={"gicode": "A005930"},
            )


def test_fetch_fnguide_page_uses_custom_user_agent() -> None:
    import httpx

    response = httpx.Response(200, text="ok", request=httpx.Request("GET", "https://example.com"))
    with patch("orchestrator.fnguide.workflow.httpx.get", return_value=response) as get_mock:
        from orchestrator.fnguide.workflow import fetch_fnguide_page

        fetch_fnguide_page(
            url="https://example.com",
            params={"gicode": "A005930"},
            user_agent="custom-agent/2.0",
        )

    assert get_mock.call_args.kwargs["headers"]["User-Agent"] == "custom-agent/2.0"
