import json

import pytest

from orchestrator import InvalidInputError
from orchestrator.bond.workflow import MarketBondWorkflow, _orchestrate_bond_api_flow


def test_orchestrates_datagokr_calls_and_normalizes_payload():
    calls: list[tuple[str, dict[str, str]]] = []

    def _record(name: str, return_value):
        def _inner(**kwargs):
            calls.append((name, kwargs))
            return return_value

        return _inner

    payload = _orchestrate_bond_api_flow(
        api_key="test-key",
        query="선익시스템1CB(사모/전환/풋)",
        parse_issue=_record(
            "issue",
            {
                "isinCd": "KR0000000001",
                "기준일자": "20260318",
                "isinCdNm": "선익시스템1CB",
            },
        ),
        parse_redemptions=_record("redemptions", [{"옵션분류": "Put"}]),
        parse_exercises=_record("exercises", [{"행사일": "20260312"}]),
        parse_adjustments=_record("adjustments", [{"변경일": "20250121"}]),
        parse_schedules=_record("schedules", [{"옵션분류": "Put"}]),
        parse_basic_info=_record("basic_info", [{"발행잔액": "17200000000"}]),
        issuer_name_from_bond_name=lambda bond_name: "선익시스템",
        normalize_name=lambda name: "선익시스템1cb",
    )

    assert payload == {
        "issue": {
            "isinCdNm": "선익시스템1CB",
            "isinCd": "KR0000000001",
            "basDt": "20260318",
        },
        "optionRedemptions": [{"optnTcdNm": "Put"}],
        "optionExercises": [{"rgtOccrBasDt": "20260312"}],
        "priceAdjustments": [{"rgtExertPricAdjDt": "20250121"}],
        "optionSchedules": [{"type": "Put"}],
        "bondBasicInfo": [{"bondBal": "17200000000"}],
    }
    assert calls[0][0] == "issue"


def test_market_bond_workflow_returns_input_and_data(tmp_path):
    expected_payload = {
        "issue": {"isinCdNm": "공공데이터포털1EB"},
        "optionRedemptions": [],
        "optionExercises": [],
        "priceAdjustments": [],
        "optionSchedules": [],
        "bondBasicInfo": [],
    }
    workflow = MarketBondWorkflow(
        workflow_runner=lambda api_key, query: (
            expected_payload
            if api_key == "test-key" and query == "공공데이터포털1EB"
            else {}
        )
    )

    result = workflow.run(
        query="공공데이터포털1EB",
        api_key="test-key",
        save_path=str(tmp_path / "market_bond.json"),
    )

    assert result["input"] == {
        "query": "공공데이터포털1EB",
        "save_path": str(tmp_path / "market_bond.json"),
    }
    assert result["data"] == expected_payload
    saved_payload = json.loads((tmp_path / "market_bond.json").read_text(encoding="utf-8"))
    assert saved_payload == expected_payload


def test_market_bond_workflow_requires_query_and_api_key():
    workflow = MarketBondWorkflow(workflow_runner=lambda *_args: {})

    with pytest.raises(InvalidInputError):
        workflow.run(query="", api_key="test-key")

    with pytest.raises(InvalidInputError):
        workflow.run(query="공공데이터포털1EB", api_key="")
