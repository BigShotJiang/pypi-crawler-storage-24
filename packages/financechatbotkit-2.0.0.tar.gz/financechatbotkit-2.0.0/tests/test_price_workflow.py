from unittest.mock import patch

import pytest

from orchestrator import InvalidInputError, NotFoundError
from orchestrator.price import (
    PricePeriodWorkflow,
    PriceSnapshotWorkflow,
    run_price_period_workflow,
    run_price_snapshot_workflow,
)


def _make_df(rows: list[dict[str, int | str]]):
    import pandas as pd

    dates = pd.to_datetime([str(row["date"]) for row in rows])
    data = {
        "Open": [row.get("open") for row in rows],
        "Close": [row.get("close") for row in rows],
        "Low": [row.get("low") for row in rows],
        "High": [row.get("high") for row in rows],
        "Volume": [row.get("volume") for row in rows],
    }
    return pd.DataFrame(data, index=dates)


class TestPriceSnapshotWorkflow:
    def test_returns_last_and_latest_close(self):
        df = _make_df([
            {"date": "2026-03-14", "close": 70000},
            {"date": "2026-03-17", "close": 71000},
            {"date": "2026-03-18", "close": 72000},
        ])
        workflow = PriceSnapshotWorkflow(lookback_days=30)

        with patch("orchestrator.price.workflow._load_price_frame", return_value=df):
            result = workflow.run(stock_code="005930")

        assert result["data"] == {"lastClose": 71000, "latestClose": 72000}
        assert result["input"]["price_fields"] == "close"

    def test_returns_last_and_latest_oclh(self):
        df = _make_df([
            {"date": "2026-03-14", "open": 69500, "close": 70000, "low": 69000, "high": 70100},
            {"date": "2026-03-17", "open": 70500, "close": 71000, "low": 70000, "high": 71200},
            {"date": "2026-03-18", "open": 71500, "close": 72000, "low": 71000, "high": 72500},
        ])
        workflow = PriceSnapshotWorkflow(lookback_days=30)

        with patch("orchestrator.price.workflow._load_price_frame", return_value=df):
            result = workflow.run(stock_code="005930", price_fields="oclh")

        assert result["data"] == {
            "lastPrice": {
                "date": "2026-03-17",
                "open": 70500,
                "close": 71000,
                "low": 70000,
                "high": 71200,
            },
            "latestPrice": {
                "date": "2026-03-18",
                "open": 71500,
                "close": 72000,
                "low": 71000,
                "high": 72500,
            },
        }
        assert result["input"]["price_fields"] == "oclh"

    def test_requires_at_least_two_rows(self):
        df = _make_df([{"date": "2026-03-18", "close": 72000}])
        with patch("orchestrator.price.workflow._load_price_frame", return_value=df):
            with pytest.raises(NotFoundError):
                run_price_snapshot_workflow(stock_code="005930")

    def test_invalid_lookback_raises(self):
        with pytest.raises(InvalidInputError):
            PriceSnapshotWorkflow(lookback_days=1)


class TestPricePeriodWorkflow:
    def test_returns_period_prices(self):
        df = _make_df([
            {"date": "2026-03-14", "close": 70000},
            {"date": "2026-03-17", "close": 71000},
        ])
        workflow = PricePeriodWorkflow()

        with patch("orchestrator.price.workflow._load_price_frame", return_value=df):
            result = workflow.run(stock_code="005930", start_date="2026-03-14", end_date="2026-03-17")

        assert result["data"]["prices"] == [
            {"date": "2026-03-14", "close": 70000},
            {"date": "2026-03-17", "close": 71000},
        ]
        assert result["input"]["price_fields"] == "close"

    def test_returns_period_prices_with_oclh(self):
        df = _make_df([
            {"date": "2026-03-14", "open": 69500, "close": 70000, "low": 69000, "high": 70100},
            {"date": "2026-03-17", "open": 70500, "close": 71000, "low": 70000, "high": 71200},
        ])
        workflow = PricePeriodWorkflow()

        with patch("orchestrator.price.workflow._load_price_frame", return_value=df):
            result = workflow.run(
                stock_code="005930",
                start_date="2026-03-14",
                end_date="2026-03-17",
                price_fields="oclh",
            )

        assert result["data"]["prices"] == [
            {"date": "2026-03-14", "open": 69500, "close": 70000, "low": 69000, "high": 70100},
            {"date": "2026-03-17", "open": 70500, "close": 71000, "low": 70000, "high": 71200},
        ]
        assert result["input"]["price_fields"] == "oclh"

    def test_returns_period_prices_with_oclhv(self):
        df = _make_df([
            {"date": "2026-03-14", "open": 69500, "close": 70000, "low": 69000, "high": 70100, "volume": 123456},
            {"date": "2026-03-17", "open": 70500, "close": 71000, "low": 70000, "high": 71200, "volume": 234567},
        ])

        with patch("orchestrator.price.workflow._load_price_frame", return_value=df):
            result = run_price_period_workflow(
                stock_code="005930",
                start_date="2026-03-14",
                end_date="2026-03-17",
                price_fields="oclhv",
            )

        assert result["data"]["prices"] == [
            {
                "date": "2026-03-14",
                "open": 69500,
                "close": 70000,
                "low": 69000,
                "high": 70100,
                "volume": 123456,
            },
            {
                "date": "2026-03-17",
                "open": 70500,
                "close": 71000,
                "low": 70000,
                "high": 71200,
                "volume": 234567,
            },
        ]

    def test_empty_period_raises(self):
        import pandas as pd

        df = pd.DataFrame(columns=["Open", "Close", "Low", "High", "Volume"])
        with patch("orchestrator.price.workflow._load_price_frame", return_value=df):
            with pytest.raises(NotFoundError):
                run_price_period_workflow(stock_code="005930", start_date="2026-03-01", end_date="2026-03-10")

    def test_invalid_date_order_raises(self):
        workflow = PricePeriodWorkflow()
        with pytest.raises(InvalidInputError):
            workflow.run(stock_code="005930", start_date="2026-03-18", end_date="2026-03-14")

    def test_invalid_price_fields_raises(self):
        workflow = PricePeriodWorkflow()
        with pytest.raises(InvalidInputError):
            workflow.run(stock_code="005930", start_date="2026-03-14", end_date="2026-03-17", price_fields="ohlcv")
