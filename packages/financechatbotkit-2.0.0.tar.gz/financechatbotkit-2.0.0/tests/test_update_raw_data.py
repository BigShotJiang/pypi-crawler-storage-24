import json
from pathlib import Path

import orchestrator.mapping.update_raw_data as update_raw_data


def test_update_raw_corp_codes_file_writes_downloaded_entries(monkeypatch, tmp_path: Path):
    output_path = tmp_path / "corp_codes_raw.json"

    def fake_download(api_key: str):
        assert api_key == "test-key"
        return (
            {
                "corp_code": "00126380",
                "stock_name": "삼성전자",
                "stock_code": "005930",
                "modify_date": "20250314",
            },
            {
                "corp_code": "00987654",
                "stock_name": "비상장테스트",
                "stock_code": None,
                "modify_date": "20250314",
            },
        )

    monkeypatch.setattr(update_raw_data, "download_latest_raw_entries", fake_download)

    written_path, entry_count = update_raw_data.update_raw_corp_codes_file(
        api_key="test-key",
        output_path=output_path,
    )

    assert written_path == output_path
    assert entry_count == 2
    assert json.loads(output_path.read_text(encoding="utf-8")) == [
        {
            "corp_code": "00126380",
            "corp_name": "삼성전자",
            "stock_code": "005930",
            "modify_date": "20250314",
        },
        {
            "corp_code": "00987654",
            "corp_name": "비상장테스트",
            "stock_code": None,
            "modify_date": "20250314",
        },
    ]


def test_main_reads_api_key_from_environment(monkeypatch, tmp_path: Path, capsys):
    output_path = tmp_path / "corp_codes_raw.json"
    calls: list[tuple[str, str | None]] = []

    def fake_update(*, api_key: str, output_path: str | None = None):
        calls.append((api_key, output_path))
        return Path(output_path or ""), 123

    monkeypatch.setattr(update_raw_data, "update_raw_corp_codes_file", fake_update)
    monkeypatch.setenv("DART_API_KEY", "env-key")

    exit_code = update_raw_data.main(["--output", str(output_path)])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert calls == [("env-key", str(output_path))]
    assert "Updated" in captured.out


def test_main_returns_error_code_when_update_fails(monkeypatch, capsys):
    def fake_update(*, api_key: str, output_path: str | None = None):
        raise update_raw_data.MappingWorkflowError("boom")

    monkeypatch.setattr(update_raw_data, "update_raw_corp_codes_file", fake_update)

    exit_code = update_raw_data.main(["--api-key", "test-key"])

    captured = capsys.readouterr()
    assert exit_code == 1
    assert "Failed to refresh corp codes: boom" in captured.err
