import json
from pathlib import Path

import pytest

from orchestrator import InvalidInputError, NotFoundError
from orchestrator.mapping import MappingWorkflow, run_mapping_workflow
import orchestrator.mapping.workflow as workflow


@pytest.fixture()
def sample_data_path(tmp_path: Path) -> Path:
    rows = [
        {
            "corp_code": "00126380",
            "corp_name": "삼성전자",
            "stock_code": "005930",
            "modify_date": "20250314",
        },
        {
            "corp_code": "00987654",
            "corp_name": "비상장테스트",
            "stock_code": None,
            "modify_date": "20250314",
        },
    ]
    path = tmp_path / "corp_codes_raw.json"
    path.write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
    return path


def test_lookup_by_stock_code(sample_data_path: Path):
    result = run_mapping_workflow(stock_code="005930", data_path=str(sample_data_path))

    assert result["input"]["stock_code"] == "005930"
    assert result["data"]["mappings"] == [
        {
            "stock_name": "삼성전자",
            "stock_code": "005930",
            "corp_code": "00126380",
        }
    ]


def test_lookup_by_corp_code_include_nonlisted(sample_data_path: Path):
    result = run_mapping_workflow(
        corp_code="00987654",
        include_nonlisted=True,
        data_path=str(sample_data_path),
    )

    assert result["data"]["mappings"] == [
        {
            "stock_name": "비상장테스트",
            "stock_code": None,
            "corp_code": "00987654",
        }
    ]


def test_lookup_nonlisted_without_flag_raises_not_found(sample_data_path: Path):
    with pytest.raises(NotFoundError):
        run_mapping_workflow(corp_code="00987654", data_path=str(sample_data_path))



def test_get_all_returns_filtered_entries(sample_data_path: Path):
    result = run_mapping_workflow(get_all=True, data_path=str(sample_data_path))
    assert result["data"]["mappings"] == [
        {
            "stock_name": "삼성전자",
            "stock_code": "005930",
            "corp_code": "00126380",
        }
    ]



def test_get_all_include_nonlisted_returns_everything(sample_data_path: Path):
    result = run_mapping_workflow(
        get_all=True,
        include_nonlisted=True,
        data_path=str(sample_data_path),
    )
    assert len(result["data"]["mappings"]) == 2



def test_get_latest_uses_download_path(monkeypatch):
    def fake_download(api_key: str):
        assert api_key == "test-key"
        return (
            {
                "stock_name": "삼성전자",
                "stock_code": "005930",
                "corp_code": "00126380",
                "modify_date": "20250314",
            },
            {
                "stock_name": "비상장테스트",
                "stock_code": None,
                "corp_code": "00987654",
                "modify_date": "20250314",
            },
        )

    monkeypatch.setattr(workflow, "download_latest_raw_entries", fake_download)

    result = run_mapping_workflow(
        stock_name="비상장테스트",
        include_nonlisted=True,
        get_latest=True,
        api_key="test-key",
    )
    assert result["data"]["mappings"][0]["corp_code"] == "00987654"



def test_lookup_requires_exactly_one_key(sample_data_path: Path):
    with pytest.raises(InvalidInputError):
        run_mapping_workflow(stock_code="005930", corp_code="00126380", data_path=str(sample_data_path))



def test_none_fields_do_not_trigger_extra_lookup(sample_data_path: Path):
    result = run_mapping_workflow(
        stock_code="005930",
        stock_name=None,
        corp_code=None,
        data_path=str(sample_data_path),
    )
    assert result["data"]["mappings"][0]["stock_name"] == "삼성전자"


def test_mapping_workflow_exposes_cache_size(sample_data_path: Path):
    mapping_workflow = MappingWorkflow(cache_size=0, data_path=str(sample_data_path))
    assert mapping_workflow.cache_size == 0
    result = mapping_workflow.run(stock_code="005930")
    assert result["data"]["mappings"][0]["corp_code"] == "00126380"


def test_mapping_workflow_cache_size_one_reuses_loaded_data(monkeypatch, sample_data_path: Path):
    mapping_workflow = MappingWorkflow(cache_size=1, data_path=str(sample_data_path))
    call_count = 0
    original_json_loads = workflow.json.loads

    def counting_loads(text):
        nonlocal call_count
        call_count += 1
        return original_json_loads(text)

    monkeypatch.setattr(workflow.json, "loads", counting_loads)

    first = mapping_workflow.run(stock_code="005930")
    second = mapping_workflow.run(stock_code="005930")

    assert first["data"]["mappings"] == second["data"]["mappings"]
    assert call_count == 1
