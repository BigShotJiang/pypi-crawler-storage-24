## FinanceChatbot

Unified finance workflow library (orchestrator) for:

- `mapping`
- `price`
- `fnguide`
- `bond`

### Public API

Each feature lives at the same level:

```python
from orchestrator.mapping import MappingWorkflow
from orchestrator.price import PricePeriodWorkflow
from orchestrator.fnguide import FnGuideWorkflow
from orchestrator.bond import MarketBondWorkflow
```

All workflows return:

```python
{
    "input": {...},
    "data": {...},
}
```

`price` workflows support `price_fields="close"` (default), `price_fields="oclh"`, and `price_fields="oclhv"` to control which price columns are returned.

---

## TeleBotKit

`TeleBotKit` is a shared utility library that lives under `src/telebotkit` and is packaged together with this project.

It provides helpers for:

- Telegram bot command parsing, routing, MarkdownV2 escaping, and reply payload generation (`telebotkit.bot`)
- Firestore client bootstrap, typed repositories, shared document access, and lease/lock helpers (`telebotkit.firestore`)
- Excel row parsing and typed JSON payload generation for Firestore imports (`telebotkit.sheets`)

### Example usage

```python
from telebotkit.bot import Reply, Router
from telebotkit.firestore import DocumentStore, get_client
from telebotkit.sheets import build_typed_rows_payload_from_xlsx
```

See `src/telebotkit/README.md` for full API documentation and examples.
