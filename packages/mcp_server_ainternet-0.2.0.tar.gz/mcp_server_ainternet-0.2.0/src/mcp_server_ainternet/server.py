"""
DEPRECATED — This package has been replaced by tibet-ainternet-mcp.

Install the new package:
    pip install tibet-ainternet-mcp

tibet-ainternet-mcp has 32 tools (vs 7 here) covering:
- AINS domains (.aint)
- I-Poll messaging
- Claims & registration
- File sharing
- Network monitoring & analytics
- Cortex permission gates

This wrapper redirects to tibet-ainternet-mcp for backwards compatibility.
"""

import sys
import warnings

warnings.warn(
    "mcp-server-ainternet is DEPRECATED. Use tibet-ainternet-mcp instead.\n"
    "  pip install tibet-ainternet-mcp\n"
    "  Command: tibet-ainternet-mcp (instead of mcp-server-ainternet)",
    DeprecationWarning,
    stacklevel=2,
)


def main():
    """Redirect to tibet-ainternet-mcp."""
    print(
        "=" * 60 + "\n"
        "  DEPRECATED: mcp-server-ainternet\n"
        "  \n"
        "  This package has moved to: tibet-ainternet-mcp\n"
        "  \n"
        "  It was installed as a dependency, so you can just run:\n"
        "  \n"
        "    tibet-ainternet-mcp\n"
        "  \n"
        "  Or update your MCP config:\n"
        "    \"command\": \"tibet-ainternet-mcp\"\n"
        "  \n"
        "  Starting tibet-ainternet-mcp for you...\n"
        "=" * 60,
        file=sys.stderr,
    )

    # Forward to the real server
    from tibet_ainternet_mcp.server import main as real_main
    real_main()


if __name__ == "__main__":
    main()
