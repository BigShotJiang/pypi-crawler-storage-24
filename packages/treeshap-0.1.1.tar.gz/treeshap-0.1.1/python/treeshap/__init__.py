"""TreeSHAP — Exact SHAP values for tree ensemble models.

This package provides fast, exact TreeSHAP computation powered by a Rust
backend. It supports XGBoost, LightGBM, and ONNX model formats.

Quick start::

    import numpy as np
    from treeshap import TreeEnsemble, ShapExplainer

    model = TreeEnsemble.from_file("model.json", "xgboost")
    explainer = ShapExplainer(model)
    explanation = explainer.explain(X)
    print(explanation.shap_values)
"""

from treeshap._treeshap import TreeEnsemble, ShapExplainer, ShapExplanation

__all__ = ["TreeEnsemble", "ShapExplainer", "ShapExplanation"]
__version__ = "0.1.1"
