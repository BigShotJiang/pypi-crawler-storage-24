'''High-level Python bindings for the Velr runtime.

This module provides a small, Pythonic wrapper around the Velr runtime.

Examples
--------
Open an in-memory database, create some data, and query one result table::

    from velr.driver import Velr

    MOVIES_CREATE = r"""
    CREATE
      (keanu:Person:Actor {name:'Keanu Reeves', born:1964}),
      (nolan:Person:Director {name:'Christopher Nolan'}),
      (matrix:Movie {title:'The Matrix', released:1999, genres:['Sci-Fi','Action']}),
      (inception:Movie {title:'Inception', released:2010, genres:['Sci-Fi','Heist']}),
      (keanu)-[:ACTED_IN {roles:['Neo']}]->(matrix),
      (nolan)-[:DIRECTED]->(inception);
    """

    with Velr.open(None) as db:
        db.run(MOVIES_CREATE)

        with db.exec_one(
            "MATCH (m:Movie {title:'Inception'}) "
            "RETURN m.title AS title, m.released AS y, m.genres AS g"
        ) as table:
            print(table.column_names())
            with table.rows() as rows:
                row = next(rows)

        title, year, genres = row
        assert title.as_python() == "Inception"
        assert year.as_python() == 2010
        assert genres.as_python() == '["Sci-Fi","Heist"]'

Return the last result table as pandas::

    with Velr.open(None) as db:
        db.run(MOVIES_CREATE)
        df = db.to_pandas(
            "MATCH (m:Movie) "
            "RETURN m.title AS title, m.released AS released "
            "ORDER BY released"
        )
        print(df)

Use a transaction::

    with Velr.open(None) as db:
        with db.begin_tx() as tx:
            tx.run("CREATE (:Movie {title:'Interstellar', released:2014})")
            tx.commit()

Thread safety
-------------
Velr connections and active result handles are not safe for concurrent use
from multiple threads.

If you need parallelism, open one connection per thread and avoid sharing
active connections, transactions, streams, tables, or row iterators across
threads.

Results and tables
------------------
A query may produce zero or more result tables:

- ``Velr.exec()`` and ``VelrTx.exec()`` return a stream of tables.
- ``Velr.exec_one()`` and ``VelrTx.exec_one()`` expect exactly one table.
- ``Velr.run()`` and ``VelrTx.run()`` execute and drain all result tables.

Table lifetime depends on how the table was obtained:

- Tables pulled from ``exec()`` are stream-scoped. They remain valid while the
  producing stream remains open, and closing the stream closes any still-open
  tables produced by that stream.
- Tables returned by ``exec_one()`` are parent-scoped rather than stream-scoped.
  ``Velr.exec_one()`` returns a table parented to the connection, and
  ``VelrTx.exec_one()`` returns a table parented to the transaction, so the
  returned table remains usable after the internal stream logic has finished.

In all cases, tables should be closed when no longer needed, ideally by using
them as context managers.

Rows and cells
--------------
Rows are exposed through ``Rows``. Each yielded row is a tuple of ``Cell``
objects.

For convenience and safety, TEXT and JSON payloads are copied into Python
``bytes`` as rows are read, so row contents remain valid after the next fetch.

Arrow and dataframe interop
---------------------------
Velr can both:

- bind Arrow-backed input data under a logical table name, and
- export result tables as Arrow IPC for conversion to PyArrow, pandas, or Polars.

The public bind path accepts PyArrow arrays, chunked arrays, record batches,
tables, pandas DataFrames, Polars DataFrames, NumPy arrays, and list-of-dicts
via helper methods.

Explain support
---------------
``Velr.explain()``, ``Velr.explain_analyze()``, ``VelrTx.explain()``, and
``VelrTx.explain_analyze()`` return ``ExplainTrace``, which can be navigated
incrementally or fully materialized with ``ExplainTrace.snapshot()``.

Transactions and savepoints
---------------------------
``Velr.begin_tx()`` returns ``VelrTx``.

After ``commit()`` or ``rollback()``, a transaction can no longer be used.

Velr supports two savepoint styles:

- Scoped savepoints from ``savepoint()`` are handle-owned.
  Dropping the handle closes the savepoint. ``release()`` releases it, and
  ``rollback()`` rolls back to it and releases it.

- Named savepoints from ``savepoint_named(name)`` are transaction-owned.
  Dropping the returned Python handle does not remove the named savepoint.
  ``rollback_to(name)`` rolls back to the named savepoint, discards any newer
  named savepoints, and keeps the target named savepoint active.
  ``release_savepoint(name)`` releases a named savepoint by name.
  ``release()`` or ``rollback()`` on a named savepoint handle consume that
  named savepoint.

Active named savepoints are released automatically during ``commit()`` so that
changes made after ``rollback_to(name)`` are preserved in the committed
transaction.

Errors
------
Runtime errors are raised as ``VelrError``.
'''

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, TYPE_CHECKING
import sys
import weakref

from ._ffi import ffi, lib

if TYPE_CHECKING:
    import pyarrow as pa  # type: ignore[import-not-found]
    import pandas as pd  # type: ignore[import-not-found]
    import polars as pl  # type: ignore[import-not-found]


def _normalize_arrow_columns(cols_like):
    """Normalize supported Arrow-like inputs into ``[(name, column), ...]``.

    Accepted inputs are:

    - ``Mapping[str, pyarrow.Array | pyarrow.ChunkedArray]``
    - ``Sequence[tuple[str, pyarrow.Array | pyarrow.ChunkedArray]]``
    - ``pyarrow.RecordBatch``
    - ``pyarrow.Table``

    Returns
    -------
    list[tuple[str, pyarrow.Array | pyarrow.ChunkedArray]]
        Normalized column name/value pairs.

    Raises
    ------
    VelrError
        If the input shape is not supported.
    """
    import pyarrow as pa  # type: ignore

    if hasattr(cols_like, "items"):
        items = list(cols_like.items())
        for k, v in items:
            if not isinstance(v, (pa.Array, pa.ChunkedArray)):
                raise VelrError(f"Column '{k}' must be a pyarrow.Array or ChunkedArray")
        return items

    if isinstance(cols_like, (list, tuple)) and cols_like and isinstance(cols_like[0], (list, tuple)):
        out = []
        for k, v in cols_like:
            if not isinstance(v, (pa.Array, pa.ChunkedArray)):
                raise VelrError(f"Column '{k}' must be a pyarrow.Array or ChunkedArray")
            out.append((k, v))
        return out

    if isinstance(cols_like, pa.RecordBatch):
        return [(f.name, cols_like.column(i)) for i, f in enumerate(cols_like.schema)]

    if isinstance(cols_like, pa.Table):
        return [(n, cols_like[n]) for n in cols_like.schema.names]

    raise VelrError(
        "Unsupported columns object; pass {name: pa.Array|pa.ChunkedArray}, "
        "list[(name, pa.Array|pa.ChunkedArray)], pyarrow.RecordBatch, or pyarrow.Table"
    )


def _pandas_to_arrow_table(
    df: "pd.DataFrame",
    *,
    index: bool = False,
    jsonify_objects: bool = True,
    schema: "Optional[pa.Schema]" = None,
):
    """Convert a pandas DataFrame to a PyArrow table.

    This helper applies defaults that work well with the Velr Arrow binder.

    Parameters
    ----------
    df:
        Input pandas DataFrame.
    index:
        Whether to include the pandas index as a column.
    jsonify_objects:
        When true, object-dtype cells containing ``dict``, ``list``, ``tuple``,
        or ``set`` are serialized as JSON strings. Other non-JSONable values are
        stringified. ``None`` and ``NaN`` remain null-like.
    schema:
        Optional explicit PyArrow schema.

    Returns
    -------
    pyarrow.Table
        Converted Arrow table.
    """
    import math
    import json
    import pandas as pd  # type: ignore
    import pyarrow as pa  # type: ignore

    work = df.copy(deep=False)

    if any(not isinstance(c, str) for c in work.columns):
        work.columns = [str(c) for c in work.columns]

    if jsonify_objects:
        from pandas.api import types as ptypes

        def _jsonify_series(s: "pd.Series") -> "pd.Series":
            def _coerce(x):
                if x is None or (isinstance(x, float) and math.isnan(x)):
                    return None
                if isinstance(x, (dict, list, tuple, set)):
                    if isinstance(x, set):
                        x = list(x)
                    return json.dumps(x, ensure_ascii=False)
                if isinstance(x, str):
                    return x
                if isinstance(x, (bool, int, float)):
                    return x
                return str(x)

            return s.map(_coerce)

        for name in work.columns:
            s = work[name]
            if ptypes.is_object_dtype(s.dtype):
                work[name] = _jsonify_series(s)

        for name in work.columns:
            s = work[name]
            if ptypes.is_bool_dtype(s.dtype):
                continue
            if ptypes.is_integer_dtype(s.dtype):
                try:
                    work[name] = s.astype("Int64")
                except Exception:
                    pass
            elif ptypes.is_float_dtype(s.dtype):
                work[name] = s.astype("float64")
            elif ptypes.is_string_dtype(s.dtype):
                try:
                    work[name] = s.astype("string[python]")
                except Exception:
                    pass

    return pa.Table.from_pandas(work, schema=schema, preserve_index=index)


def _polars_to_arrow_table(df: "pl.DataFrame", *, rechunk: bool = False):
    """Convert a Polars DataFrame to a PyArrow table.

    Parameters
    ----------
    df:
        Input Polars DataFrame.
    rechunk:
        When true, rechunk before conversion.

    Returns
    -------
    pyarrow.Table
        Converted Arrow table.
    """
    import polars as pl  # type: ignore

    if rechunk:
        df = df.rechunk()
    return df.to_arrow()


def _numpy_to_arrow_table(data, *, names: list[str] | None = None, types: dict | None = None):
    """Convert NumPy data to a PyArrow table.

    Accepted inputs are:

    - ``dict[str, np.ndarray]``
    - ``2D np.ndarray`` together with ``names=[...]``

    Parameters
    ----------
    data:
        NumPy input data.
    names:
        Required when passing a bare 2D ndarray.
    types:
        Optional mapping from column name to Arrow type.

    Returns
    -------
    pyarrow.Table
        Converted Arrow table.

    Raises
    ------
    VelrError
        If the input shape is not supported.
    """
    import numpy as np  # type: ignore
    import pyarrow as pa  # type: ignore

    if isinstance(data, dict):
        cols = {}
        for name, arr in data.items():
            dt = types.get(name) if types else None
            cols[name] = pa.array(arr, type=dt) if dt is not None else pa.array(arr)
        return pa.table(cols)

    if isinstance(data, np.ndarray):
        if data.ndim != 2:
            raise VelrError("2D numpy.ndarray expected when passing a bare array")
        if not names:
            raise VelrError("You must supply 'names=[...]' for a 2D numpy array")
        if data.shape[1] != len(names):
            raise VelrError("len(names) must equal array.shape[1]")
        cols = {}
        for i, name in enumerate(names):
            col = data[:, i]
            dt = types.get(name) if types else None
            cols[name] = pa.array(col, type=dt) if dt is not None else pa.array(col)
        return pa.table(cols)

    raise VelrError("Unsupported NumPy input; pass dict[str, ndarray] or a 2D ndarray with names=[]")


def _records_to_arrow_table(rows, *, types: dict | None = None):
    """Convert a list of dict records to a PyArrow table."""
    import pyarrow as pa  # type: ignore

    schema = pa.schema([pa.field(n, t) for n, t in types.items()]) if types else None
    return pa.Table.from_pylist(rows, schema=schema)


def _export_arrow_columns_for_bind(pairs):
    """Export plain Arrow arrays to C Data Interface structures."""
    import pyarrow as pa  # type: ignore
    from pyarrow.cffi import ffi as paffi

    n = len(pairs)
    c_schemas = [paffi.new("struct ArrowSchema*") for _ in range(n)]
    c_arrays = [paffi.new("struct ArrowArray*") for _ in range(n)]

    for i, (name, arr) in enumerate(pairs):
        if not isinstance(arr, pa.Array):
            raise VelrError(f"Column '{name}' is not a pyarrow.Array")
        ptr_schema = int(paffi.cast("uintptr_t", c_schemas[i]))
        ptr_array = int(paffi.cast("uintptr_t", c_arrays[i]))
        arr._export_to_c(ptr_array, ptr_schema)

    schemas_pp = ffi.new("const struct ArrowSchema * []", n)
    arrays_pp = ffi.new("const struct ArrowArray  * []", n)
    for i in range(n):
        schemas_pp[i] = ffi.cast(
            "const struct ArrowSchema *",
            int(paffi.cast("uintptr_t", c_schemas[i])),
        )
        arrays_pp[i] = ffi.cast(
            "const struct ArrowArray *",
            int(paffi.cast("uintptr_t", c_arrays[i])),
        )

    name_views = ffi.new("velr_strview[]", n)
    name_backing = []
    for i, (name, _) in enumerate(pairs):
        b = name.encode("utf-8", "strict")
        buf = ffi.new("unsigned char[]", b)
        name_backing.append(buf)
        name_views[i].ptr = buf
        name_views[i].len = len(b)

    return schemas_pp, arrays_pp, name_views, name_backing, c_schemas, c_arrays


def _export_arrow_columns_for_bind_chunked(pairs):
    """Export Arrow arrays or chunked arrays to chunked C Data structures."""
    import pyarrow as pa  # type: ignore
    from pyarrow.cffi import ffi as paffi

    col_count = len(pairs)

    per_col_chunks = []
    for _, arr in pairs:
        if isinstance(arr, pa.ChunkedArray):
            chunks = list(arr.chunks)
        elif isinstance(arr, pa.Array):
            chunks = [arr]
        else:
            raise VelrError("Expected pa.Array or pa.ChunkedArray")
        if not chunks:
            raise VelrError("ChunkedArray has zero chunks")
        per_col_chunks.append(chunks)

    keep_schemas_nested = []
    keep_arrays_nested = []
    schema_pp_per_col = []
    array_pp_per_col = []

    for chunks in per_col_chunks:
        n = len(chunks)

        ks = [paffi.new("struct ArrowSchema*") for _ in range(n)]
        ka = [paffi.new("struct ArrowArray*") for _ in range(n)]

        schemas_pp = ffi.new("const struct ArrowSchema * []", n)
        arrays_pp = ffi.new("const struct ArrowArray  * []", n)

        for j, ch in enumerate(chunks):
            ptr_schema = int(paffi.cast("uintptr_t", ks[j]))
            ptr_array = int(paffi.cast("uintptr_t", ka[j]))
            ch._export_to_c(ptr_array, ptr_schema)

            schemas_pp[j] = ffi.cast(
                "const struct ArrowSchema *",
                int(paffi.cast("uintptr_t", ks[j])),
            )
            arrays_pp[j] = ffi.cast(
                "const struct ArrowArray *",
                int(paffi.cast("uintptr_t", ka[j])),
            )

        keep_schemas_nested.append(ks)
        keep_arrays_nested.append(ka)
        schema_pp_per_col.append(schemas_pp)
        array_pp_per_col.append(arrays_pp)

    cols_c = ffi.new("struct velr_arrow_chunks[]", col_count)
    for i, chunks in enumerate(per_col_chunks):
        cols_c[i].schemas = schema_pp_per_col[i]
        cols_c[i].arrays = array_pp_per_col[i]
        cols_c[i].chunk_count = len(chunks)

    name_views = ffi.new("velr_strview[]", col_count)
    name_backing = []
    for i, (name, _) in enumerate(pairs):
        b = name.encode("utf-8", "strict")
        buf = ffi.new("unsigned char[]", b)
        name_backing.append(buf)
        name_views[i].ptr = buf
        name_views[i].len = len(b)

    return (
        cols_c,
        name_views,
        name_backing,
        keep_schemas_nested,
        keep_arrays_nested,
        schema_pp_per_col,
        array_pp_per_col,
    )


class _ForeignIPC:
    """Own an Arrow IPC buffer allocated by the runtime.

    The underlying memory is released automatically when this object is
    garbage-collected.
    """

    __slots__ = ("_cdata", "_len", "_mv")

    def __init__(self, ptr, length: int):
        n = int(length)
        self._len = n

        if ptr == ffi.NULL or n == 0:
            self._cdata = ffi.NULL
            self._mv = memoryview(b"")
            return

        raw = ffi.cast("unsigned char *", ptr)

        def _finalize(p):
            if p != ffi.NULL and n >= 0:
                lib.velr_free(p, n)

        self._cdata = ffi.gc(raw, _finalize)
        self._mv = memoryview(ffi.buffer(self._cdata, n))

    def memoryview(self) -> memoryview:
        """Return the IPC bytes as a Python memoryview."""
        return self._mv

    def to_buffer(self):
        """Return a zero-copy ``pyarrow.Buffer`` over the IPC bytes."""
        try:
            import pyarrow as pa  # type: ignore[import-not-found]
        except Exception as e:
            raise VelrError(f"pyarrow is required for zero-copy buffer: {e}") from e
        return pa.py_buffer(self._mv)

    def to_pyarrow(self):
        """Decode the IPC buffer to a ``pyarrow.Table``."""
        try:
            import pyarrow as pa  # type: ignore[import-not-found]
        except Exception as e:
            raise VelrError(f"pyarrow is required: {e}") from e
        buf = self.to_buffer()
        with pa.BufferReader(buf) as reader:
            return pa.ipc.open_file(reader).read_all()

    def to_pandas(self, *, dtype_backend: str = "numpy_nullable", **kwargs):
        """Decode the IPC buffer to a pandas DataFrame.

        Parameters
        ----------
        dtype_backend:
            Passed to ``DataFrame.convert_dtypes(...)`` when supported by the
            installed pandas version.
        """
        tbl = self.to_pyarrow()
        try:
            import pandas as pd  # type: ignore[import-not-found]
        except Exception as e:
            raise VelrError(f"pandas is required for to_pandas(): {e}") from e

        df = tbl.to_pandas()

        backend = kwargs.pop("dtype_backend", dtype_backend)
        if backend is not None:
            try:
                df = df.convert_dtypes(dtype_backend=backend)
            except TypeError:
                df = df.convert_dtypes()

        if kwargs:
            raise VelrError(f"Unsupported to_pandas() kwargs: {list(kwargs.keys())}")

        return df

    def to_polars(self):
        """Decode the IPC buffer to a Polars DataFrame."""
        try:
            import polars as pl  # type: ignore[import-not-found]
        except Exception as e:
            raise VelrError(f"polars is required for to_polars(): {e}") from e
        return pl.from_arrow(self.to_pyarrow())

    def raw_memoryview(self) -> memoryview:
        """Return the raw IPC bytes as a memoryview."""
        return self._mv

    def to_bytes(self) -> bytes:
        """Return the raw IPC bytes as ``bytes``."""
        return bytes(self._mv)

    def write_to(self, fileobj) -> int:
        """Write the raw IPC bytes to a file-like object."""
        return fileobj.write(self._mv)

    def save(self, path: str) -> None:
        """Save the raw IPC bytes to a file."""
        with open(path, "wb") as f:
            f.write(self._mv)


class VelrError(RuntimeError):
    """Base exception raised by the Velr Python driver."""


def _free_unexpected_err(errpp) -> None:
    """Free a stray error string returned on success."""
    if errpp[0] != ffi.NULL:
        lib.velr_string_free(errpp[0])
        errpp[0] = ffi.NULL


def _take_err(errpp) -> str:
    """Take, decode, free, and clear a runtime-owned error string."""
    if errpp[0] == ffi.NULL:
        return "(unknown)"
    s = ffi.string(errpp[0]).decode("utf-8", errors="replace")
    lib.velr_string_free(errpp[0])
    errpp[0] = ffi.NULL
    return s


def _check(rc: int, errpp) -> None:
    """Raise ``VelrError`` if a standard runtime call failed."""
    if int(rc) == int(lib.VELR_OK):
        _free_unexpected_err(errpp)
        return
    raise VelrError(_take_err(errpp))


def _check_noerr(rc: int, context: str) -> None:
    """Raise ``VelrError`` for calls that do not return ``out_err``."""
    if int(rc) != int(lib.VELR_OK):
        raise VelrError(f"{context} (code {int(rc)})")


def _strview_to_bytes(v, what: str) -> bytes:
    """Copy a borrowed string view into Python bytes."""
    n = int(v.len)
    if n == 0:
        return b""
    if v.ptr == ffi.NULL:
        raise VelrError(f"{what} is null with non-zero length")
    return bytes(ffi.buffer(v.ptr, n))


def _strview_to_string(v, what: str) -> str:
    """Copy and decode a borrowed string view as UTF-8."""
    try:
        return _strview_to_bytes(v, what).decode("utf-8", "strict")
    except UnicodeDecodeError as e:
        raise VelrError(f"{what} is not valid UTF-8: {e}") from e


def _opt_strview_to_string(v, what: str) -> str | None:
    """Decode an optional borrowed string view."""
    if v.ptr == ffi.NULL and int(v.len) == 0:
        return None
    return _strview_to_string(v, what)


def _cell_bytes(ptr, length: int, what: str) -> bytes:
    """Copy a runtime-owned byte buffer into Python bytes."""
    n = int(length)
    if n == 0:
        return b""
    if ptr == ffi.NULL:
        raise VelrError(f"{what} is null with non-zero length")
    return bytes(ffi.buffer(ptr, n))


@dataclass(frozen=True)
class Cell:
    """One cell value in a result row.

    Attributes
    ----------
    ty:
        Velr cell type code.
    i64:
        Integer payload used for BOOL and INT64 cells.
    f64:
        Floating-point payload used for DOUBLE cells.
    data:
        Raw bytes for TEXT and JSON cells.
    """

    ty: int
    i64: int
    f64: float
    data: bytes

    def as_python(
        self,
        *,
        decode_text: bool = True,
        parse_json: bool = False,
        encoding: str = "utf-8",
        errors: str = "strict",
    ):
        """Convert this cell to a plain Python value."""
        if self.ty == lib.VELR_NULL:
            return None
        if self.ty == lib.VELR_BOOL:
            return bool(self.i64)
        if self.ty == lib.VELR_INT64:
            return int(self.i64)
        if self.ty == lib.VELR_DOUBLE:
            return float(self.f64)
        if self.ty == lib.VELR_TEXT:
            return self.data.decode(encoding, errors) if decode_text else bytes(self.data)
        if self.ty == lib.VELR_JSON:
            if parse_json:
                import json

                return json.loads(self.data.decode(encoding, errors))
            return self.data.decode(encoding, errors) if decode_text else bytes(self.data)
        return bytes(self.data)


@dataclass(frozen=True)
class ExplainPlanMeta:
    """Metadata for one explain plan."""

    plan_id: str
    cypher: str
    step_count: int


@dataclass(frozen=True)
class ExplainStepMeta:
    """Metadata for one explain step."""

    step_no: int
    group_id: str
    op_index: str
    phase: str
    title: str
    source: str
    note: str | None
    statement_count: int


@dataclass(frozen=True)
class ExplainStatementMeta:
    """Metadata for one explain statement."""

    stmt_id: str
    kind: str
    sql: str
    note: str | None
    sqlite_plan_count: int


@dataclass(frozen=True)
class ExplainStatement:
    """One explain statement together with its SQLite plan lines."""

    meta: ExplainStatementMeta
    sqlite_plan: list[str]


@dataclass(frozen=True)
class ExplainStep:
    """One explain step together with its statements."""

    meta: ExplainStepMeta
    statements: list[ExplainStatement]


@dataclass(frozen=True)
class ExplainPlan:
    """One explain plan together with its steps."""

    meta: ExplainPlanMeta
    steps: list[ExplainStep]

class ExplainTrace:
    """An EXPLAIN or EXPLAIN ANALYZE trace.

    An explain trace can be traversed incrementally using the ``*_meta`` and
    ``*_count`` methods, or fully materialized with ``snapshot()``.

    The trace keeps its parent connection or transaction alive for as long as
    the trace itself is open.

    Use ``close()`` when you are done, or use the trace as a context manager.
    """

    __slots__ = ("_xp", "_parent", "__weakref__")

    def __init__(self, xp_cdata, parent):
        if xp_cdata == ffi.NULL:
            raise VelrError("runtime returned null explain trace")
        self._xp = xp_cdata
        self._parent = parent

    def _ensure_open(self):
        if self._xp == ffi.NULL:
            raise VelrError("explain trace is closed")
        
    def __del__(self):
        try:
            if getattr(sys, "is_finalizing", lambda: False)():
                return
            self.close()
        except Exception:
            pass

    def close(self) -> None:
        """Close the explain trace handle."""
        if self._xp != ffi.NULL:
            try:
                lib.velr_explain_trace_close(self._xp)
            finally:
                self._xp = ffi.NULL
                try:
                    self._parent._unregister_child(self)
                except Exception:
                    pass

    def __enter__(self) -> "ExplainTrace":
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def plan_count(self) -> int:
        """Return the number of top-level plans in the trace."""
        self._ensure_open()
        return int(lib.velr_explain_trace_plan_count(self._xp))

    def plan_meta(self, plan_idx: int) -> ExplainPlanMeta:
        """Return metadata for one plan."""
        self._ensure_open()
        out = ffi.new("velr_explain_plan_meta *")
        rc = lib.velr_explain_trace_plan_meta(self._xp, plan_idx, out)
        _check_noerr(rc, f"velr_explain_trace_plan_meta failed at plan_idx={plan_idx}")
        return ExplainPlanMeta(
            plan_id=_strview_to_string(out.plan_id, "plan_id"),
            cypher=_strview_to_string(out.cypher, "cypher"),
            step_count=int(out.step_count),
        )

    def step_count(self, plan_idx: int) -> int:
        """Return the number of steps in one plan."""
        return self.plan_meta(plan_idx).step_count

    def step_meta(self, plan_idx: int, step_idx: int) -> ExplainStepMeta:
        """Return metadata for one explain step."""
        self._ensure_open()
        out = ffi.new("velr_explain_step_meta *")
        rc = lib.velr_explain_trace_step_meta(self._xp, plan_idx, step_idx, out)
        _check_noerr(
            rc,
            f"velr_explain_trace_step_meta failed at plan_idx={plan_idx}, step_idx={step_idx}",
        )
        return ExplainStepMeta(
            step_no=int(out.step_no),
            group_id=_strview_to_string(out.group_id, "group_id"),
            op_index=_strview_to_string(out.op_index, "op_index"),
            phase=_strview_to_string(out.phase, "phase"),
            title=_strview_to_string(out.title, "title"),
            source=_strview_to_string(out.source, "source"),
            note=_opt_strview_to_string(out.note, "step.note"),
            statement_count=int(out.statement_count),
        )

    def statement_count(self, plan_idx: int, step_idx: int) -> int:
        """Return the number of statements in one explain step."""
        return self.step_meta(plan_idx, step_idx).statement_count

    def statement_meta(self, plan_idx: int, step_idx: int, stmt_idx: int) -> ExplainStatementMeta:
        """Return metadata for one explain statement."""
        self._ensure_open()
        out = ffi.new("velr_explain_stmt_meta *")
        rc = lib.velr_explain_trace_statement_meta(self._xp, plan_idx, step_idx, stmt_idx, out)
        _check_noerr(
            rc,
            "velr_explain_trace_statement_meta failed at "
            f"plan_idx={plan_idx}, step_idx={step_idx}, stmt_idx={stmt_idx}",
        )
        return ExplainStatementMeta(
            stmt_id=_strview_to_string(out.stmt_id, "stmt_id"),
            kind=_strview_to_string(out.kind, "kind"),
            sql=_strview_to_string(out.sql, "sql"),
            note=_opt_strview_to_string(out.note, "statement.note"),
            sqlite_plan_count=int(out.sqlite_plan_count),
        )

    def sqlite_plan_count(self, plan_idx: int, step_idx: int, stmt_idx: int) -> int:
        """Return the number of SQLite plan detail lines for one statement."""
        return self.statement_meta(plan_idx, step_idx, stmt_idx).sqlite_plan_count

    def sqlite_plan_detail(
        self,
        plan_idx: int,
        step_idx: int,
        stmt_idx: int,
        detail_idx: int,
    ) -> str:
        """Return one SQLite plan detail line."""
        self._ensure_open()
        out = ffi.new("velr_strview *")
        rc = lib.velr_explain_trace_sqlite_plan_detail(
            self._xp,
            plan_idx,
            step_idx,
            stmt_idx,
            detail_idx,
            out,
        )
        _check_noerr(
            rc,
            "velr_explain_trace_sqlite_plan_detail failed at "
            f"plan_idx={plan_idx}, step_idx={step_idx}, stmt_idx={stmt_idx}, detail_idx={detail_idx}",
        )
        return _strview_to_string(out[0], "sqlite_plan_detail")

    def sqlite_plan_details(self, plan_idx: int, step_idx: int, stmt_idx: int) -> list[str]:
        """Return all SQLite plan detail lines for one statement."""
        n = self.sqlite_plan_count(plan_idx, step_idx, stmt_idx)
        return [self.sqlite_plan_detail(plan_idx, step_idx, stmt_idx, i) for i in range(n)]

    def snapshot(self) -> list[ExplainPlan]:
        """Materialize the entire trace into owned Python dataclasses."""
        plans: list[ExplainPlan] = []
        for plan_idx in range(self.plan_count()):
            pmeta = self.plan_meta(plan_idx)
            steps: list[ExplainStep] = []
            for step_idx in range(pmeta.step_count):
                smeta = self.step_meta(plan_idx, step_idx)
                statements: list[ExplainStatement] = []
                for stmt_idx in range(smeta.statement_count):
                    stmeta = self.statement_meta(plan_idx, step_idx, stmt_idx)
                    statements.append(
                        ExplainStatement(
                            meta=stmeta,
                            sqlite_plan=self.sqlite_plan_details(plan_idx, step_idx, stmt_idx),
                        )
                    )
                steps.append(ExplainStep(meta=smeta, statements=statements))
            plans.append(ExplainPlan(meta=pmeta, steps=steps))
        return plans

    def compact_len(self) -> int:
        """Return the compact explain rendering length in bytes."""
        self._ensure_open()
        out_len = ffi.new("size_t *")
        out_err = ffi.new("char **")
        rc = lib.velr_explain_trace_compact_len(self._xp, out_len, out_err)
        _check(rc, out_err)
        return int(out_len[0])

    def to_compact_bytes(self) -> bytes:
        """Render the trace to owned UTF-8 bytes."""
        self._ensure_open()
        out_ptr = ffi.new("uint8_t **")
        out_len = ffi.new("size_t *")
        out_err = ffi.new("char **")
        rc = lib.velr_explain_trace_compact_malloc(self._xp, out_ptr, out_len, out_err)
        _check(rc, out_err)

        ptr = out_ptr[0]
        ln = int(out_len[0])

        if ptr == ffi.NULL:
            if ln == 0:
                return b""
            raise VelrError("velr_explain_trace_compact_malloc returned null with non-zero length")

        try:
            return bytes(ffi.buffer(ptr, ln))
        finally:
            lib.velr_free(ptr, ln)

    def to_compact_string(self) -> str:
        """Render the trace to a UTF-8 string."""
        try:
            return self.to_compact_bytes().decode("utf-8", "strict")
        except UnicodeDecodeError as e:
            raise VelrError(f"compact explain is not valid UTF-8: {e}") from e

    def write_compact(self, out) -> None:
        """Write the compact rendering to a file-like object."""
        out.write(self.to_compact_bytes())

class Velr:
    """A Velr database connection.

    Use ``open()`` to create a connection.

    A query may return zero or more result tables. Choose among:

    - ``exec()`` to stream tables
    - ``exec_one()`` when exactly one table is expected
    - ``run()`` when results can be ignored
    - ``to_pyarrow()``, ``to_pandas()``, or ``to_polars()`` for convenience
      conversion of the last result table

    Use ``begin_tx()`` to open a transaction.
    """

    __slots__ = ("_db", "_children", "__weakref__")

    def __init__(self, db_cdata):
        self._db = db_cdata
        self._children = weakref.WeakSet()

    def __del__(self):
        try:
            if getattr(sys, "is_finalizing", lambda: False)():
                return
            self.close()
        except Exception:
            pass

    def _ensure_open(self) -> None:
        if self._db == ffi.NULL:
            raise VelrError("connection already closed")

    def _register_child(self, child) -> None:
        self._children.add(child)

    def _unregister_child(self, child) -> None:
        try:
            self._children.discard(child)
        except Exception:
            pass

    def _close_children_first(self) -> None:
        for child in list(self._children):
            try:
                child.close()
            except Exception:
                pass
        self._children.clear()

    @classmethod
    def open(cls, path: Optional[str] = None) -> "Velr":
        """Open a Velr connection.

        Parameters
        ----------
        path:
            Filesystem path for a file-backed database, or ``None`` for an
            in-memory database.

        Returns
        -------
        Velr
            Open connection.
        """
        out_db = ffi.new("velr_db **")
        out_err = ffi.new("char **")
        rc = lib.velr_open(
            path.encode("utf-8") if path is not None else ffi.NULL,
            out_db,
            out_err,
        )
        _check(rc, out_err)
        if out_db[0] == ffi.NULL:
            raise VelrError("velr_open returned null db")
        return cls(out_db[0])

    def close(self) -> None:
        """Close the connection."""
        self._close_children_first()
        if self._db != ffi.NULL:
            lib.velr_close(self._db)
            self._db = ffi.NULL

    def __enter__(self) -> "Velr":
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def run(self, cypher: str) -> None:
        """Execute a query or script and discard all results."""
        with self.exec(cypher) as st:
            while True:
                t = st.next_table()
                if t is None:
                    break
                t.close()

    def execute(self, cypher: str) -> None:
        """Alias for ``run()``."""
        return self.run(cypher)

    def exec(self, cypher: str) -> "Stream":
        """Execute a query and return a stream of result tables.

        Tables produced by the returned stream are stream-scoped: they remain valid
        while the stream is open, and closing the stream closes any still-open
        tables produced by it.
        """
        self._ensure_open()

        out_st = ffi.new("velr_stream **")
        out_err = ffi.new("char **")
        rc = lib.velr_exec_start(self._db, cypher.encode("utf-8"), out_st, out_err)
        _check(rc, out_err)
        if out_st[0] == ffi.NULL:
            raise VelrError("velr_exec_start returned null stream")

        st = Stream(out_st[0], parent=self)
        self._register_child(st)
        return st

    def _exec_one_native(self, cypher: str) -> "Table":
        """Execute a query using the native one-table path."""
        self._ensure_open()

        out_tbl = ffi.new("velr_table **")
        out_err = ffi.new("char **")
        rc = lib.velr_exec_one(self._db, cypher.encode("utf-8"), out_tbl, out_err)
        _check(rc, out_err)
        if out_tbl[0] == ffi.NULL:
            raise VelrError("velr_exec_one returned null table")

        tbl = Table(out_tbl[0], parent=self)
        self._register_child(tbl)
        return tbl

    def exec_one(self, cypher: str) -> "Table":
        """Execute a query expected to return exactly one table.

        The returned table is parented to the connection rather than to a transient
        stream, so it remains usable after this method returns.

        The returned table should be closed when you are done with it. The easiest
        way is to use it as a context manager.
        """
        return self._exec_one_native(cypher)

    def explain(self, cypher: str) -> ExplainTrace:
        """Build an EXPLAIN trace for a query."""
        self._ensure_open()

        out_xp = ffi.new("velr_explain_trace **")
        out_err = ffi.new("char **")
        rc = lib.velr_explain(self._db, cypher.encode("utf-8"), out_xp, out_err)
        _check(rc, out_err)
        if out_xp[0] == ffi.NULL:
            raise VelrError("velr_explain returned null explain trace")

        xp = ExplainTrace(out_xp[0], parent=self)
        self._register_child(xp)
        return xp

    def explain_analyze(self, cypher: str) -> ExplainTrace:
        """Build an EXPLAIN ANALYZE trace for a query."""
        self._ensure_open()

        out_xp = ffi.new("velr_explain_trace **")
        out_err = ffi.new("char **")
        rc = lib.velr_explain_analyze(self._db, cypher.encode("utf-8"), out_xp, out_err)
        _check(rc, out_err)
        if out_xp[0] == ffi.NULL:
            raise VelrError("velr_explain_analyze returned null explain trace")

        xp = ExplainTrace(out_xp[0], parent=self)
        self._register_child(xp)
        return xp

    def to_pyarrow(self, cypher: str):
        """Execute a query and return the last result table as ``pyarrow.Table``.

        If the query produces no tables, an empty Arrow table is returned.
        """
        import pyarrow as pa  # type: ignore[import-not-found]

        with self.exec(cypher) as st:
            last: Table | None = None
            try:
                while True:
                    t = st.next_table()
                    if t is None:
                        break

                    # Re-parent the candidate table away from the stream so an EOF-driven
                    # stream close does not implicitly close it before we export it.
                    if getattr(t, "_parent", None) is st:
                        try:
                            st._unregister_child(t)
                        except Exception:
                            pass
                        t._parent = self
                        self._register_child(t)

                    if last is not None:
                        last.close()

                    last = t

                if last is None:
                    return pa.table({})

                try:
                    return last.to_pyarrow()
                finally:
                    last.close()

            except Exception:
                if last is not None:
                    try:
                        last.close()
                    except Exception:
                        pass
                raise

    def to_pandas(self, cypher: str, **kwargs):
        """Execute a query and return the last result table as pandas."""
        pa_tbl = self.to_pyarrow(cypher)
        df = pa_tbl.to_pandas()

        backend = kwargs.pop("dtype_backend", "numpy_nullable")
        if backend is not None:
            try:
                df = df.convert_dtypes(dtype_backend=backend)
            except TypeError:
                df = df.convert_dtypes()

        if kwargs:
            raise VelrError(f"Unsupported to_pandas() kwargs: {list(kwargs.keys())}")

        return df

    def to_polars(self, cypher: str):
        """Execute a query and return the last result table as Polars."""
        import polars as pl  # type: ignore[import-not-found]

        return pl.from_arrow(self.to_pyarrow(cypher))

    def bind_arrow(self, logical: str, columns) -> None:
        """Bind Arrow-backed columnar data under a logical table name.

        Parameters
        ----------
        logical:
            Logical table name visible to queries.
        columns:
            One of the accepted Arrow input shapes supported by
            ``_normalize_arrow_columns()``.

        Notes
        -----
        The Python implementation always uses the chunked Arrow bind path, which
        works for both plain arrays and chunked arrays.
        """
        self._ensure_open()

        pairs = _normalize_arrow_columns(columns)
        (
            cols_c,
            name_views,
            _name_backing,
            _keep_schemas_nested,
            _keep_arrays_nested,
            _schema_pp_per_col,
            _array_pp_per_col,
        ) = _export_arrow_columns_for_bind_chunked(pairs)

        out_err = ffi.new("char **")
        logical_c = ffi.new("char[]", logical.encode("utf-8"))
        rc = lib.velr_bind_arrow_chunks(
            self._db,
            logical_c,
            cols_c,
            name_views,
            len(pairs),
            out_err,
        )
        _check(rc, out_err)

    def bind_arrow_chunks(self, logical: str, columns) -> None:
        """Alias for ``bind_arrow()``."""
        self.bind_arrow(logical, columns)

    def bind_pandas(
        self,
        logical: str,
        df: "pd.DataFrame",
        *,
        index: bool = False,
        jsonify_objects: bool = True,
        schema: "Optional['pa.Schema']" = None,
    ) -> None:
        """Bind a pandas DataFrame under a logical table name."""
        tbl = _pandas_to_arrow_table(
            df,
            index=index,
            jsonify_objects=jsonify_objects,
            schema=schema,
        )
        self.bind_arrow(logical, tbl)

    def bind_polars(
        self,
        logical: str,
        df: "pl.DataFrame",
        *,
        rechunk: bool = False,
    ) -> None:
        """Bind a Polars DataFrame under a logical table name."""
        tbl = _polars_to_arrow_table(df, rechunk=rechunk)
        self.bind_arrow(logical, tbl)

    def bind_numpy(
        self,
        logical: str,
        data,
        *,
        names: list[str] | None = None,
        types: dict | None = None,
    ) -> None:
        """Bind NumPy data under a logical table name."""
        tbl = _numpy_to_arrow_table(data, names=names, types=types)
        self.bind_arrow(logical, tbl)

    def bind_records(
        self,
        logical: str,
        rows: list[dict],
        *,
        types: dict | None = None,
    ) -> None:
        """Bind a list of dict records under a logical table name."""
        tbl = _records_to_arrow_table(rows, types=types)
        self.bind_arrow(logical, tbl)

    def begin_tx(self) -> "VelrTx":
        """Begin a transaction."""
        self._ensure_open()

        out_tx = ffi.new("velr_tx **")
        out_err = ffi.new("char **")
        rc = lib.velr_tx_begin(self._db, out_tx, out_err)
        _check(rc, out_err)
        if out_tx[0] == ffi.NULL:
            raise VelrError("velr_tx_begin returned null tx")

        tx = VelrTx(out_tx[0], parent=self)
        self._register_child(tx)
        return tx

class Stream:
    """Stream of result tables produced by ``Velr.exec()``.

    Use ``next_table()`` to pull tables one by one, or ``iter_tables()`` to
    iterate over the remaining tables.

    Tables yielded by this stream are stream-scoped: they are parented to the
    stream unless explicitly re-parented elsewhere. Closing the stream closes
    any still-open child tables first.

    Use ``close()`` when done, or use the stream as a context manager.
    """

    __slots__ = ("_st", "_children", "_parent", "__weakref__")

    def __init__(self, st_cdata, parent: "Velr"):
        self._st = st_cdata
        self._children = weakref.WeakSet()
        self._parent = parent

    def _register_child(self, child) -> None:
        self._children.add(child)

    def _unregister_child(self, child) -> None:
        try:
            self._children.discard(child)
        except Exception:
            pass

    def _close_children_first(self) -> None:
        for child in list(self._children):
            try:
                child.close()
            except Exception:
                pass
        self._children.clear()

    def __del__(self):
        try:
            if getattr(sys, "is_finalizing", lambda: False)():
                return
            self.close()
        except Exception:
            pass

    def next_table(self) -> Optional["Table"]:
        """Return the next result table, or ``None`` at end-of-stream."""
        if self._st == ffi.NULL:
            return None

        out_tbl = ffi.new("velr_table **")
        out_has = ffi.new("int *")
        out_err = ffi.new("char **")
        rc = lib.velr_stream_next_table(self._st, out_tbl, out_has, out_err)
        _check(rc, out_err)

        if out_has[0] == 0:
            self.close()
            return None

        if out_tbl[0] == ffi.NULL:
            raise VelrError("velr_stream_next_table returned has=1 but null table")

        tbl = Table(out_tbl[0], parent=self)
        self._register_child(tbl)
        return tbl

    def iter_tables(self):
        """Iterate over remaining result tables.

        Each yielded table is closed automatically after the iteration step
        completes.
        """
        while True:
            t = self.next_table()
            if t is None:
                return
            try:
                yield t
            finally:
                t.close()

    def close(self) -> None:
        """Close the stream."""
        self._close_children_first()
        if self._st != ffi.NULL:
            try:
                lib.velr_exec_close(self._st)
            finally:
                self._st = ffi.NULL
                try:
                    self._parent._unregister_child(self)
                except Exception:
                    pass

    def __enter__(self) -> "Stream":
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class StreamTx:
    """Stream of result tables produced by ``VelrTx.exec()``.

    This is the transaction-scoped counterpart to ``Stream``.

    Tables yielded by this stream are stream-scoped: they are parented to the
    stream unless explicitly re-parented elsewhere. Closing the stream closes
    any still-open child tables first.

    The stream keeps its parent transaction alive for as long as the stream
    itself is open.
    """

    __slots__ = ("_st", "_children", "_parent", "__weakref__")

    def __init__(self, st_cdata, parent: "VelrTx"):
        self._st = st_cdata
        self._children = weakref.WeakSet()
        self._parent = parent

    def _register_child(self, child) -> None:
        self._children.add(child)

    def _unregister_child(self, child) -> None:
        try:
            self._children.discard(child)
        except Exception:
            pass

    def _close_children_first(self) -> None:
        for child in list(self._children):
            try:
                child.close()
            except Exception:
                pass
        self._children.clear()

    def __del__(self):
        try:
            if getattr(sys, "is_finalizing", lambda: False)():
                return
            self.close()
        except Exception:
            pass

    def next_table(self) -> Optional["Table"]:
        """Return the next result table, or ``None`` at end-of-stream."""
        if self._st == ffi.NULL:
            return None

        out_tbl = ffi.new("velr_table **")
        out_has = ffi.new("int *")
        out_err = ffi.new("char **")
        rc = lib.velr_stream_tx_next_table(self._st, out_tbl, out_has, out_err)
        _check(rc, out_err)

        if out_has[0] == 0:
            self.close()
            return None

        if out_tbl[0] == ffi.NULL:
            raise VelrError("velr_stream_tx_next_table returned has=1 but null table")

        tbl = Table(out_tbl[0], parent=self)
        self._register_child(tbl)
        return tbl

    def iter_tables(self):
        """Iterate over remaining transaction-scoped result tables.

        Each yielded table is closed automatically after the iteration step
        completes.
        """
        while True:
            t = self.next_table()
            if t is None:
                return
            try:
                yield t
            finally:
                t.close()

    def close(self) -> None:
        """Close the transaction-scoped stream."""
        self._close_children_first()
        if self._st != ffi.NULL:
            try:
                lib.velr_exec_tx_close(self._st)
            finally:
                self._st = ffi.NULL
                try:
                    self._parent._unregister_child(self)
                except Exception:
                    pass

    def __enter__(self) -> "StreamTx":
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class Table:
    """One result table.

    A table provides:

    - column metadata via ``column_count()`` and ``column_names()``
    - row access via ``rows()``
    - convenience export to Arrow, pandas, Polars, and IPC bytes

    The table keeps its parent handle alive for as long as the table itself is
    open.
    """

    __slots__ = ("_tbl", "_children", "_parent", "__weakref__")

    def __init__(self, tbl_cdata, parent):
        self._tbl = tbl_cdata
        self._children = weakref.WeakSet()
        self._parent = parent

    def _ensure_open(self) -> None:
        if self._tbl == ffi.NULL:
            raise VelrError("table already closed")

    def _register_child(self, child) -> None:
        self._children.add(child)

    def _unregister_child(self, child) -> None:
        try:
            self._children.discard(child)
        except Exception:
            pass

    def _close_children_first(self) -> None:
        for child in list(self._children):
            try:
                child.close()
            except Exception:
                pass
        self._children.clear()

    def __del__(self):
        try:
            if getattr(sys, "is_finalizing", lambda: False)():
                return
            self.close()
        except Exception:
            pass

    def _to_ipc_foreign(self) -> _ForeignIPC:
        """Export this table as a runtime-owned Arrow IPC buffer."""
        self._ensure_open()

        out_ptr = ffi.new("uint8_t **")
        out_len = ffi.new("size_t *")
        out_err = ffi.new("char **")
        rc = lib.velr_table_ipc_file_malloc(self._tbl, out_ptr, out_len, out_err)
        _check(rc, out_err)

        ptr = out_ptr[0]
        ln = int(out_len[0])
        return _ForeignIPC(ptr, ln)

    def to_pyarrow_zero_copy(self):
        """Return a zero-copy ``pyarrow.Buffer`` over the IPC bytes."""
        return self._to_ipc_foreign().to_buffer()

    def to_pyarrow(self):
        """Return the table as ``pyarrow.Table``."""
        return self._to_ipc_foreign().to_pyarrow()

    def to_pandas(self, **kwargs):
        """Return the table as a pandas DataFrame."""
        return self._to_ipc_foreign().to_pandas(**kwargs)

    def to_polars(self):
        """Return the table as a Polars DataFrame."""
        return self._to_ipc_foreign().to_polars()

    def to_ipc_memoryview(self) -> memoryview:
        """Return the raw Arrow IPC bytes as a memoryview."""
        return self._to_ipc_foreign().raw_memoryview()

    def to_ipc_bytes(self) -> bytes:
        """Return the raw Arrow IPC bytes as ``bytes``."""
        return self._to_ipc_foreign().to_bytes()

    def write_ipc_to(self, fileobj) -> int:
        """Write the raw Arrow IPC bytes to a file-like object."""
        return self._to_ipc_foreign().write_to(fileobj)

    def save_ipc(self, path: str) -> None:
        """Save the raw Arrow IPC bytes to a file."""
        self._to_ipc_foreign().save(path)

    def column_count(self) -> int:
        """Return the number of columns in the table."""
        self._ensure_open()
        return int(lib.velr_table_column_count(self._tbl))

    def column_names(self) -> List[str]:
        """Return decoded UTF-8 column names."""
        self._ensure_open()

        n = self.column_count()
        out_ptr = ffi.new("const uint8_t *[1]")
        out_len = ffi.new("size_t[1]")
        names: List[str] = []

        for i in range(n):
            rc = lib.velr_table_column_name(self._tbl, i, out_ptr, out_len)
            _check_noerr(rc, f"velr_table_column_name failed at idx={i}")
            b = ffi.string(out_ptr[0], out_len[0])
            names.append(b.decode("utf-8", errors="strict"))

        return names

    def rows(self) -> "Rows":
        """Open a row iterator for this table."""
        self._ensure_open()

        out_rows = ffi.new("velr_rows **")
        out_err = ffi.new("char **")
        rc = lib.velr_table_rows_open(self._tbl, out_rows, out_err)
        _check(rc, out_err)
        if out_rows[0] == ffi.NULL:
            raise VelrError("velr_table_rows_open returned null rows")

        rows = Rows(out_rows[0], self.column_count(), parent=self)
        self._register_child(rows)
        return rows

    def for_each_row(self, fn) -> None:
        """Call ``fn(row)`` for each row in the table."""
        with self.rows() as rows:
            for row in rows:
                fn(row)

    def collect(self, map_fn=None):
        """Collect rows into a list.

        Parameters
        ----------
        map_fn:
            Optional callable applied to each row before collecting.

        Returns
        -------
        list
            Collected rows or mapped row values.
        """
        out = []
        with self.rows() as rows:
            if map_fn is None:
                for row in rows:
                    out.append(row)
            else:
                for row in rows:
                    out.append(map_fn(row))
        return out

    def close(self) -> None:
        """Close the table."""
        self._close_children_first()
        if self._tbl != ffi.NULL:
            try:
                lib.velr_table_close(self._tbl)
            finally:
                self._tbl = ffi.NULL
                try:
                    self._parent._unregister_child(self)
                except Exception:
                    pass

    def __enter__(self) -> "Table":
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

class Rows:
    """Iterator over rows in a table.

    Iteration yields ``tuple[Cell, ...]``.

    Use ``close()`` when done, or use the iterator as a context manager.
    """

    __slots__ = ("_rows", "_ncols", "_buf", "_written", "_parent", "__weakref__")

    def __init__(self, rows_cdata, ncols: int, parent: "Table"):
        self._rows = rows_cdata
        self._ncols = ncols
        self._buf = ffi.new("velr_cell[]", ncols)
        self._written = ffi.new("size_t *")
        self._parent = parent

    def __del__(self):
        try:
            if getattr(sys, "is_finalizing", lambda: False)():
                return
            self.close()
        except Exception:
            pass

    def __iter__(self):
        """Return the iterator itself."""
        return self

    def __next__(self):
        """Fetch the next row."""
        if self._rows == ffi.NULL:
            raise StopIteration

        out_err = ffi.new("char **")
        rc = lib.velr_rows_next(self._rows, self._buf, self._ncols, self._written, out_err)

        if rc < 0:
            try:
                self.close()
            finally:
                raise VelrError(_take_err(out_err))

        if rc == 0:
            _free_unexpected_err(out_err)
            self.close()
            raise StopIteration

        _free_unexpected_err(out_err)

        n = int(self._written[0])
        if n > self._ncols:
            self.close()
            raise VelrError(
                f"velr_rows_next reported {n} cells, but the buffer holds {self._ncols}"
            )

        row = []
        for i in range(n):
            c = self._buf[i]
            data = b""
            if c.ty == lib.VELR_TEXT:
                data = _cell_bytes(c.ptr, c.len, "VELR_TEXT cell")
            elif c.ty == lib.VELR_JSON:
                data = _cell_bytes(c.ptr, c.len, "VELR_JSON cell")
            row.append(Cell(c.ty, int(c.i64_), float(c.f64_), data))
        return tuple(row)

    def close(self) -> None:
        """Close the row iterator."""
        if self._rows != ffi.NULL:
            try:
                lib.velr_rows_close(self._rows)
            finally:
                self._rows = ffi.NULL
                try:
                    self._parent._unregister_child(self)
                except Exception:
                    pass

    def __enter__(self) -> "Rows":
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

@dataclass
class _NamedSavepointEntry:
    """Transaction-owned named savepoint state."""
    name: str
    sp: object
    active: bool = True



class Savepoint:
    """A savepoint within a transaction.

    Scoped savepoints are handle-owned:
    - dropping the handle closes the savepoint
    - ``release()`` releases it
    - ``rollback()`` rolls back to it and releases it

    Named savepoints are transaction-owned:
    - dropping the returned Python handle does not remove the named savepoint
    - ``release()`` on a named handle releases that named savepoint
    - ``rollback()`` on a named handle rolls back to that named savepoint and
      releases it
    - ``VelrTx.rollback_to(name)`` rolls back to a named savepoint, discards any
      newer named savepoints, and keeps the target named savepoint active
    """

    __slots__ = ("_sp", "_closed", "_parent", "_named_entry", "__weakref__")

    def __init__(
        self,
        sp_cdata,
        parent: "VelrTx",
        *,
        named_entry: _NamedSavepointEntry | None = None,
    ):
        self._sp = sp_cdata if sp_cdata is not None else ffi.NULL
        self._closed = False
        self._parent = parent
        self._named_entry = named_entry

    def __del__(self):
        try:
            if getattr(sys, "is_finalizing", lambda: False)():
                return
            self.close()
        except Exception:
            pass

    def release(self) -> None:
        """Release this savepoint."""
        if self._closed:
            return

        # Named savepoint: transaction-owned marker.
        if self._named_entry is not None:
            try:
                self._parent._release_named_entry(self._named_entry)
            finally:
                if not self._named_entry.active:
                    self._closed = True
                    self._sp = ffi.NULL
            return

        # Scoped savepoint: handle-owned.
        if self._sp == ffi.NULL:
            self._closed = True
            return

        sp = self._sp
        self._sp = ffi.NULL
        self._closed = True

        try:
            out_err = ffi.new("char **")
            rc = lib.velr_sp_release(sp, out_err)
            _check(rc, out_err)
        finally:
            try:
                self._parent._unregister_child(self)
            except Exception:
                pass

    def rollback(self) -> None:
        """Roll back to this savepoint and release it."""
        if self._closed:
            return

        # Named savepoint: rollback-to + release target.
        if self._named_entry is not None:
            try:
                self._parent._rollback_named_entry(self._named_entry, release_target=True)
            finally:
                if not self._named_entry.active:
                    self._closed = True
                    self._sp = ffi.NULL
            return

        # Scoped savepoint: handle-owned.
        if self._sp == ffi.NULL:
            self._closed = True
            return

        sp = self._sp
        self._sp = ffi.NULL
        self._closed = True

        try:
            out_err = ffi.new("char **")
            rc = lib.velr_sp_rollback(sp, out_err)
            _check(rc, out_err)
        finally:
            try:
                self._parent._unregister_child(self)
            except Exception:
                pass

    def close(self) -> None:
        """Best-effort close of the savepoint handle.

        For scoped savepoints this closes the runtime handle.
        For named savepoints this only drops the Python handle; the named marker
        remains active in the transaction until released, rolled back to, or the
        transaction ends.
        """
        if self._closed:
            return

        # Named savepoint handles do not own the runtime marker.
        if self._named_entry is not None:
            self._closed = True
            self._sp = ffi.NULL
            return

        if self._sp != ffi.NULL:
            try:
                lib.velr_sp_close(self._sp)
            finally:
                self._sp = ffi.NULL
                self._closed = True
                try:
                    self._parent._unregister_child(self)
                except Exception:
                    pass
        else:
            self._closed = True

    def __enter__(self) -> "Savepoint":
        return self

    def __exit__(self, exc_type, exc, tb):
        """Release on normal exit, roll back on exceptional exit."""
        if exc_type is not None:
            self.rollback()
        else:
            self.release()

class VelrTx:
    """A transaction handle.

    Use ``commit()`` to commit or ``rollback()`` to roll back.

    If used as a context manager, a still-open transaction is rolled back on
    exit. Use ``savepoint()`` for scoped savepoints and ``savepoint_named()``
    for transaction-owned named savepoints.
    """

    __slots__ = (
        "_tx",
        "_closed",
        "_children",
        "_parent",
        "_named_savepoints",
        "__weakref__",
    )

    def __init__(self, tx_cdata, parent: "Velr"):
        self._tx = tx_cdata
        self._closed = False
        self._children = weakref.WeakSet()
        self._parent = parent
        self._named_savepoints: list[_NamedSavepointEntry] = []

    def _ensure_open(self):
        if self._tx == ffi.NULL or self._closed:
            raise VelrError("tx already closed")

    def _register_child(self, child) -> None:
        self._children.add(child)

    def _unregister_child(self, child) -> None:
        try:
            self._children.discard(child)
        except Exception:
            pass

    def _close_children_first(self) -> None:
        for child in list(self._children):
            try:
                child.close()
            except Exception:
                pass
        self._children.clear()

    def _find_named_index(self, name: str) -> int | None:
        for i in range(len(self._named_savepoints) - 1, -1, -1):
            entry = self._named_savepoints[i]
            if entry.active and entry.name == name:
                return i
        return None

    def _find_named_entry_index(self, wanted: _NamedSavepointEntry) -> int | None:
        for i in range(len(self._named_savepoints) - 1, -1, -1):
            if self._named_savepoints[i] is wanted and wanted.active:
                return i
        return None

    def _invalidate_named_savepoints(self) -> None:
        for entry in self._named_savepoints:
            entry.active = False
            entry.sp = ffi.NULL
        self._named_savepoints.clear()

    def _create_named_runtime_savepoint(self, name: str):
        """Create one runtime named savepoint and return the raw handle."""
        out_sp = ffi.new("velr_sp **")
        out_err = ffi.new("char **")
        rc = lib.velr_tx_savepoint_named(
            self._tx,
            name.encode("utf-8"),
            out_sp,
            out_err,
        )
        _check(rc, out_err)
        if out_sp[0] == ffi.NULL:
            raise VelrError("velr_tx_savepoint_named returned null savepoint")
        return out_sp[0]

    def _prune_named_after(self, idx: int) -> None:
        """Discard all active named savepoints newer than idx."""
        for newer in self._named_savepoints[idx + 1 :]:
            newer.active = False
            newer.sp = ffi.NULL
        del self._named_savepoints[idx + 1 :]

    def _retain_named_target_after_rollback(self, idx: int) -> None:
        """Recreate the rolled-back-to named savepoint so it remains active.

        This emulates retained-target semantics even if the underlying runtime
        consumes the target during rollback_to(name).
        """
        entry = self._named_savepoints[idx]

        try:
            new_sp = self._create_named_runtime_savepoint(entry.name)
        except Exception as e:
            # The rollback already happened in the runtime. Reflect the actual
            # post-rollback state honestly: target is gone, and newer savepoints
            # are also gone.
            entry.active = False
            entry.sp = ffi.NULL
            for newer in self._named_savepoints[idx + 1 :]:
                newer.active = False
                newer.sp = ffi.NULL
            del self._named_savepoints[idx:]
            raise VelrError(
                f"rollback_to({entry.name!r}) succeeded, but failed to recreate "
                f"the named savepoint to preserve retained-target semantics: {e}"
            ) from e

        entry.sp = new_sp
        entry.active = True
        self._prune_named_after(idx)

    def _release_named_entry(self, entry: _NamedSavepointEntry) -> None:
        self._ensure_open()

        if not entry.active or entry.sp == ffi.NULL:
            raise VelrError(f"no such savepoint '{entry.name}'")

        idx = self._find_named_entry_index(entry)
        if idx is None:
            raise VelrError(f"no such savepoint '{entry.name}'")

        if idx != len(self._named_savepoints) - 1:
            raise VelrError("named savepoint can only be released from the top of the stack")

        sp = entry.sp
        entry.sp = ffi.NULL
        entry.active = False
        self._named_savepoints.pop()

        out_err = ffi.new("char **")
        rc = lib.velr_sp_release(sp, out_err)
        _check(rc, out_err)

    def _rollback_named_entry(
        self,
        entry: _NamedSavepointEntry,
        *,
        release_target: bool,
    ) -> None:
        self._ensure_open()

        if not entry.active:
            raise VelrError(f"no such savepoint '{entry.name}'")

        idx = self._find_named_entry_index(entry)
        if idx is None:
            raise VelrError(f"no such savepoint '{entry.name}'")

        if release_target:
            # Handle semantics: rollback to this exact savepoint and consume it.
            sp = entry.sp
            for doomed in self._named_savepoints[idx:]:
                doomed.active = False
                doomed.sp = ffi.NULL
            del self._named_savepoints[idx:]

            out_err = ffi.new("char **")
            rc = lib.velr_sp_rollback(sp, out_err)
            _check(rc, out_err)
            return

        # Name-based transaction semantics: rollback to target, discard newer,
        # and keep the target logically active.
        out_err = ffi.new("char **")
        rc = lib.velr_tx_rollback_to(self._tx, entry.name.encode("utf-8"), out_err)
        _check(rc, out_err)

        self._retain_named_target_after_rollback(idx)

    def run(self, cypher: str) -> None:
        """Execute a query or script inside the transaction and discard results."""
        with self.exec(cypher) as st:
            while True:
                t = st.next_table()
                if t is None:
                    break
                t.close()

    execute = run

    def exec(self, cypher: str) -> "StreamTx":
        """Execute a query inside the transaction and return a stream of tables.

        Tables produced by the returned stream are stream-scoped: they remain valid
        while the stream is open, and closing the stream closes any still-open
        tables produced by it.
        """
        self._ensure_open()
        out_st = ffi.new("velr_stream_tx **")
        out_err = ffi.new("char **")
        rc = lib.velr_tx_exec_start(self._tx, cypher.encode("utf-8"), out_st, out_err)
        _check(rc, out_err)
        if out_st[0] == ffi.NULL:
            raise VelrError("velr_tx_exec_start returned null stream")

        st = StreamTx(out_st[0], parent=self)
        self._register_child(st)
        return st

    def exec_one(self, cypher: str) -> "Table":
        """Execute a query inside the transaction expecting exactly one table.

        The returned table is re-parented to the transaction rather than left owned
        by the temporary stream used internally, so it remains usable after this
        method returns.
        """
        self._ensure_open()

        st = self.exec(cypher)
        t: Table | None = None
        try:
            t = st.next_table()
            if t is None:
                raise VelrError("query produced no result tables")

            if getattr(t, "_parent", None) is st:
                try:
                    st._unregister_child(t)
                except Exception:
                    pass
                t._parent = self
                self._register_child(t)

            t2 = st.next_table()
            if t2 is not None:
                try:
                    t2.close()
                finally:
                    t.close()
                raise VelrError("query produced multiple tables; use exec() to stream them")

            st.close()
            return t

        except Exception:
            try:
                st.close()
            except Exception:
                pass

            if t is not None and getattr(t, "_parent", None) is self:
                try:
                    t.close()
                except Exception:
                    pass

            raise

    def explain(self, cypher: str) -> ExplainTrace:
        """Build a transaction-scoped EXPLAIN trace."""
        self._ensure_open()
        out_xp = ffi.new("velr_explain_trace **")
        out_err = ffi.new("char **")
        rc = lib.velr_tx_explain(self._tx, cypher.encode("utf-8"), out_xp, out_err)
        _check(rc, out_err)
        if out_xp[0] == ffi.NULL:
            raise VelrError("velr_tx_explain returned null explain trace")

        xp = ExplainTrace(out_xp[0], parent=self)
        self._register_child(xp)
        return xp

    def explain_analyze(self, cypher: str) -> ExplainTrace:
        """Build a transaction-scoped EXPLAIN ANALYZE trace."""
        self._ensure_open()
        out_xp = ffi.new("velr_explain_trace **")
        out_err = ffi.new("char **")
        rc = lib.velr_tx_explain_analyze(self._tx, cypher.encode("utf-8"), out_xp, out_err)
        _check(rc, out_err)
        if out_xp[0] == ffi.NULL:
            raise VelrError("velr_tx_explain_analyze returned null explain trace")

        xp = ExplainTrace(out_xp[0], parent=self)
        self._register_child(xp)
        return xp

    def savepoint(self) -> Savepoint:
        """Create an unnamed scoped savepoint."""
        self._ensure_open()
        out_sp = ffi.new("velr_sp **")
        out_err = ffi.new("char **")
        rc = lib.velr_tx_savepoint(self._tx, out_sp, out_err)
        _check(rc, out_err)
        if out_sp[0] == ffi.NULL:
            raise VelrError("velr_tx_savepoint returned null savepoint")

        sp = Savepoint(out_sp[0], parent=self)
        self._register_child(sp)
        return sp

    def savepoint_named(self, name: str) -> Savepoint:
        """Create a transaction-owned named savepoint.

        The named savepoint remains active in the transaction even if the returned
        Python handle is dropped. Use ``rollback_to(name)`` or
        ``release_savepoint(name)`` to act on it later by name.
        """
        self._ensure_open()

        sp_cdata = self._create_named_runtime_savepoint(name)
        entry = _NamedSavepointEntry(name=name, sp=sp_cdata, active=True)
        self._named_savepoints.append(entry)

        # Returned handle is a controller/view over the transaction-owned marker.
        return Savepoint(None, parent=self, named_entry=entry)

    def rollback_to(self, name: str) -> None:
        """Roll back to a named savepoint.

        On success, changes made after the target named savepoint are undone, newer
        named savepoints are discarded, and the target named savepoint remains
        active and may be used again.
        """
        self._ensure_open()

        idx = self._find_named_index(name)
        if idx is None:
            raise VelrError(f"no such savepoint '{name}'")

        self._rollback_named_entry(self._named_savepoints[idx], release_target=False)

    def release_savepoint(self, name: str) -> None:
        """Release a named savepoint.

        The named savepoint must be the most recent active named savepoint.
        """
        self._ensure_open()

        idx = self._find_named_index(name)
        if idx is None:
            raise VelrError(f"no such savepoint '{name}'")

        entry = self._named_savepoints[idx]
        self._release_named_entry(entry)

    def _release_all_named_savepoints_for_commit(self) -> None:
        """Release all active named savepoints in LIFO order.

        This preserves all changes made inside retained/recreated named savepoints
        before the outer transaction commit.
        """
        self._ensure_open()

        while self._named_savepoints:
            entry = self._named_savepoints[-1]
            if not entry.active or entry.sp == ffi.NULL:
                self._named_savepoints.pop()
                continue
            self._release_named_entry(entry)

    def commit(self) -> None:
        """Commit the transaction.

        Any still-active named savepoints are released first so that surviving
        changes inside the transaction are preserved.

        After this call, the transaction can no longer be used.
        """
        self._ensure_open()
        self._close_children_first()

        # Important: release any active named savepoints first so that changes
        # made after a retained/recreated rollback target are preserved.
        self._release_all_named_savepoints_for_commit()

        tx = self._tx
        self._tx = ffi.NULL
        self._closed = True

        try:
            out_err = ffi.new("char **")
            rc = lib.velr_tx_commit(tx, out_err)
            _check(rc, out_err)
        finally:
            self._invalidate_named_savepoints()
            try:
                self._parent._unregister_child(self)
            except Exception:
                pass

    def rollback(self) -> None:
        """Roll back the transaction.

        After this call, the transaction can no longer be used.
        """
        self._ensure_open()
        self._close_children_first()

        tx = self._tx
        self._tx = ffi.NULL
        self._closed = True

        try:
            out_err = ffi.new("char **")
            rc = lib.velr_tx_rollback(tx, out_err)
            _check(rc, out_err)
        finally:
            self._invalidate_named_savepoints()
            try:
                self._parent._unregister_child(self)
            except Exception:
                pass

    def close(self) -> None:
        """Best-effort close of the transaction."""
        self._close_children_first()
        if self._tx != ffi.NULL and not self._closed:
            try:
                lib.velr_tx_close(self._tx)
            finally:
                self._tx = ffi.NULL
                self._closed = True
                self._invalidate_named_savepoints()
                try:
                    self._parent._unregister_child(self)
                except Exception:
                    pass

    def bind_arrow(self, logical: str, columns) -> None:
        """Bind Arrow-backed columnar data within the transaction."""
        self._ensure_open()
        pairs = _normalize_arrow_columns(columns)
        (
            cols_c,
            name_views,
            _name_backing,
            _keep_schemas_nested,
            _keep_arrays_nested,
            _schema_pp_per_col,
            _array_pp_per_col,
        ) = _export_arrow_columns_for_bind_chunked(pairs)

        out_err = ffi.new("char **")
        logical_c = ffi.new("char[]", logical.encode("utf-8"))
        rc = lib.velr_tx_bind_arrow_chunks(
            self._tx,
            logical_c,
            cols_c,
            name_views,
            len(pairs),
            out_err,
        )
        _check(rc, out_err)

    def bind_arrow_chunks(self, logical: str, columns) -> None:
        """Alias for ``bind_arrow()``."""
        self.bind_arrow(logical, columns)

    def bind_pandas(
        self,
        logical: str,
        df: "pd.DataFrame",
        *,
        index: bool = False,
        jsonify_objects: bool = True,
        schema: "Optional['pa.Schema']" = None,
    ) -> None:
        """Bind a pandas DataFrame within the transaction."""
        tbl = _pandas_to_arrow_table(
            df,
            index=index,
            jsonify_objects=jsonify_objects,
            schema=schema,
        )
        self.bind_arrow(logical, tbl)

    def bind_polars(
        self,
        logical: str,
        df: "pl.DataFrame",
        *,
        rechunk: bool = False,
    ) -> None:
        """Bind a Polars DataFrame within the transaction."""
        tbl = _polars_to_arrow_table(df, rechunk=rechunk)
        self.bind_arrow(logical, tbl)

    def bind_numpy(
        self,
        logical: str,
        data,
        *,
        names: list[str] | None = None,
        types: dict | None = None,
    ) -> None:
        """Bind NumPy data within the transaction."""
        tbl = _numpy_to_arrow_table(data, names=names, types=types)
        self.bind_arrow(logical, tbl)

    def bind_records(
        self,
        logical: str,
        rows: list[dict],
        *,
        types: dict | None = None,
    ) -> None:
        """Bind a list of dict records within the transaction."""
        tbl = _records_to_arrow_table(rows, types=types)
        self.bind_arrow(logical, tbl)

    def __del__(self):
        try:
            if getattr(sys, "is_finalizing", lambda: False)():
                return
            self.close()
        except Exception:
            pass

    def __enter__(self) -> "VelrTx":
        return self

    def __exit__(self, exc_type, exc, tb):
        """Roll back an open transaction on context-manager exit."""
        try:
            if self._tx != ffi.NULL and not self._closed:
                self.rollback()
        finally:
            self.close()