"""stools — CLI to extract structured data from Steam."""
