"""stools — CLI to extract structured data from Steam.

Usage:
    stools search <query> [--limit <n>] [--fields <f1,f2,...>]
    stools reviews <app_id_or_url> [--language <code>] [--limit <n>] [--fields <f1,f2,...>] [--output <file>]
    stools install-skill <claude|hermes|codex>

All output is JSON on stdout. Errors go to stderr.
Exit codes: 0 = success, 1 = usage error, 2 = network/API error.
"""

import argparse
import json
import os
import re
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

VERSION = "0.2.0"


def pick_fields(items: list[dict], fields: list[str]) -> list[dict]:
    """Keep only the specified keys from each dict in a list."""
    picked = []
    for item in items:
        picked.append({k: item[k] for k in fields if k in item})
    return picked


def parse_app_id(value: str) -> int:
    """Extract a Steam app ID from a store URL or plain integer string."""
    match = re.search(r"store\.steampowered\.com/app/(\d+)", value)
    if match:
        return int(match.group(1))
    if value.isdigit():
        return int(value)
    print(
        json.dumps({"error": f"Cannot parse app ID from '{value}'. Provide a Steam store URL or numeric app ID."}),
        file=sys.stderr,
    )
    sys.exit(1)


def fetch_reviews(app_id: int, language: str = "all", limit: int = 0) -> dict:
    """Fetch reviews for a Steam app, paginating automatically."""
    all_reviews: list[dict] = []
    cursor = "*"
    query_summary = None
    per_page = 100

    while True:
        if limit and len(all_reviews) >= limit:
            break

        batch_size = min(per_page, limit - len(all_reviews)) if limit else per_page

        params = urllib.parse.urlencode({
            "json": 1,
            "num_per_page": batch_size,
            "cursor": cursor,
            "filter": "recent",
            "language": language,
            "review_type": "all",
            "purchase_type": "all",
        })
        url = f"https://store.steampowered.com/appreviews/{app_id}?{params}"

        try:
            req = urllib.request.Request(url, headers={"User-Agent": "stools/0.1.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode())
        except urllib.error.URLError as e:
            print(json.dumps({"error": f"Network error: {e}"}), file=sys.stderr)
            sys.exit(2)

        if data.get("success") != 1:
            print(json.dumps({"error": "Steam API error. Verify the app ID exists."}), file=sys.stderr)
            sys.exit(2)

        if query_summary is None:
            query_summary = data.get("query_summary", {})

        reviews = data.get("reviews", [])
        if not reviews:
            break

        all_reviews.extend(reviews)

        cursor = data.get("cursor")
        if not cursor:
            break

        time.sleep(0.5)

    if limit:
        all_reviews = all_reviews[:limit]

    return {
        "app_id": app_id,
        "query_summary": query_summary,
        "total_fetched": len(all_reviews),
        "reviews": all_reviews,
    }


def fetch_search(query: str, limit: int = 10) -> dict:
    """Search Steam for games matching a query."""
    params = urllib.parse.urlencode({
        "term": query,
        "l": "english",
        "cc": "US",
    })
    url = f"https://store.steampowered.com/api/storesearch/?{params}"

    try:
        req = urllib.request.Request(url, headers={"User-Agent": "stools/0.1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.URLError as e:
        print(json.dumps({"error": f"Network error: {e}"}), file=sys.stderr)
        sys.exit(2)

    items = data.get("items", [])[:limit]

    results = []
    for item in items:
        results.append({
            "app_id": item["id"],
            "name": item["name"],
            "price": item.get("price"),
            "platforms": item.get("platforms"),
            "metascore": item.get("metascore") or None,
        })

    return {
        "query": query,
        "total_results": data.get("total", 0),
        "results": results,
    }


SKILL_TARGETS = {
    "claude": Path.home() / ".claude" / "skills" / "stools",
    "hermes": Path.home() / ".hermes" / "skills" / "stools",
    "codex": Path.home() / ".agents" / "skills" / "stools",
}


def get_bundled_skill_dir() -> Path:
    """Return the path to the bundled skill directory inside the package."""
    return Path(__file__).parent / "skill"


def cmd_install_skill(args: argparse.Namespace) -> None:
    agent = args.agent
    target = SKILL_TARGETS[agent]
    source = get_bundled_skill_dir()
    skill_file = source / "SKILL.md"

    if not skill_file.exists():
        print(json.dumps({"error": "Bundled SKILL.md not found."}), file=sys.stderr)
        sys.exit(1)

    target.mkdir(parents=True, exist_ok=True)
    shutil.copy2(skill_file, target / "SKILL.md")
    print(json.dumps({"installed": str(target / "SKILL.md"), "agent": agent}))


def cmd_search(args: argparse.Namespace) -> None:
    result = fetch_search(args.query, limit=args.limit)
    if args.fields:
        result["results"] = pick_fields(result["results"], args.fields)
    print(json.dumps(result, indent=2, ensure_ascii=False))


def cmd_reviews(args: argparse.Namespace) -> None:
    app_id = parse_app_id(args.app)
    result = fetch_reviews(app_id, language=args.language, limit=args.limit)
    if args.fields:
        result["reviews"] = pick_fields(result["reviews"], args.fields)

    output = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output + "\n")
    else:
        print(output)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="stools",
        description="CLI to extract structured data from Steam. All output is JSON.",
    )
    parser.add_argument("--version", action="version", version=f"stools {VERSION}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # --- install-skill subcommand ---
    install_parser = subparsers.add_parser(
        "install-skill",
        help="Install the stools skill for an AI agent.",
        description="Copy the stools SKILL.md to the skills directory of the specified agent.",
    )
    install_parser.add_argument(
        "agent",
        choices=["claude", "hermes", "codex"],
        help="Target agent: claude (~/.claude/skills/stools), hermes (~/.hermes/skills/stools), codex (~/.agents/skills/stools)",
    )
    install_parser.set_defaults(func=cmd_install_skill)

    # --- search subcommand ---
    search_parser = subparsers.add_parser(
        "search",
        help="Search Steam for games matching a query.",
        description=(
            "Search for games on Steam by name. Returns a JSON object with fields: "
            "query, total_results, results. Each result has: app_id, name, price, platforms, metascore."
        ),
    )
    search_parser.add_argument(
        "query",
        help="Search term (e.g. 'megaman', 'dark souls', 'snake')",
    )
    search_parser.add_argument(
        "--limit",
        type=int,
        default=10,
        metavar="N",
        help="Max results to return (default: 10)",
    )
    search_parser.add_argument(
        "--fields",
        type=lambda s: s.split(","),
        metavar="f1,f2,...",
        help="Comma-separated list of fields to keep per result. Available: app_id, name, price, platforms, metascore",
    )
    search_parser.set_defaults(func=cmd_search)

    # --- reviews subcommand ---
    reviews_parser = subparsers.add_parser(
        "reviews",
        help="Fetch all reviews for a Steam game as JSON.",
        description=(
            "Fetch reviews for a Steam game. Accepts a numeric app ID or a full Steam store URL. "
            "Output is a JSON object with fields: app_id, query_summary, total_fetched, reviews."
        ),
    )
    reviews_parser.add_argument(
        "app",
        help="Steam app ID (e.g. 1005310) or store URL (e.g. https://store.steampowered.com/app/1005310/Snake_vs_Snake/)",
    )
    reviews_parser.add_argument(
        "--language",
        default="all",
        metavar="CODE",
        help="Filter by language: english, spanish, french, german, etc. (default: all)",
    )
    reviews_parser.add_argument(
        "--limit",
        type=int,
        default=0,
        metavar="N",
        help="Max number of reviews to fetch. 0 = all (default: 0)",
    )
    reviews_parser.add_argument(
        "--output",
        metavar="FILE",
        help="Write JSON to FILE instead of stdout.",
    )
    reviews_parser.add_argument(
        "--fields",
        type=lambda s: s.split(","),
        metavar="f1,f2,...",
        help="Comma-separated list of fields to keep per review. Available: recommendationid, author, language, review, timestamp_created, timestamp_updated, voted_up, votes_up, votes_funny, steam_purchase, received_for_free, written_during_early_access",
    )
    reviews_parser.set_defaults(func=cmd_reviews)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
