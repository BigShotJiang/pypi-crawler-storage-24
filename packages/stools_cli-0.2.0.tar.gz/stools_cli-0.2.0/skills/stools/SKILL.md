---
name: stools
description: Search Steam games and fetch reviews as structured JSON. Use when the user asks about Steam game reviews, ratings, or wants to look up a game on Steam.
license: MIT
compatibility: Requires Python 3.9+ and stools-cli installed via pip or pipx.
metadata:
  author: aotarola
  version: "0.1.0"
---

# stools — Steam data extraction CLI

You have access to `stools`, a CLI that fetches structured data from Steam. All output is JSON on stdout. Errors go to stderr.

## Typical Workflow

When a user asks about a Steam game by name (not by app ID or URL):

1. Run `stools search "<game name>" --fields app_id,name` to find matching games.
2. If multiple results match, present the options to the user and ask which one they mean.
3. Use the `app_id` from the chosen result to run `stools reviews <app_id>`.

When the user provides a Steam URL or app ID directly, skip to step 3.

Use `--fields` on both commands to request only the data you need and keep context small.

## Available Commands

### `stools search`

Search Steam for games by name.

```
stools search <query> [--limit N] [--fields f1,f2,...]
```

**Arguments:**

- `query` (required): Search term (e.g. `"megaman"`, `"dark souls"`, `"snake"`)
- `--limit N`: Max results to return. Default: `10`
- `--fields f1,f2,...`: Comma-separated fields to keep per result. Available: `app_id`, `name`, `price`, `platforms`, `metascore`

**Output:**

```json
{
  "query": "megaman",
  "total_results": 10,
  "results": [
    {
      "app_id": 742300,
      "name": "Mega Man 11"
    }
  ]
}
```

**Key fields:**

- `results[].app_id`: Use this to call `stools reviews`
- `results[].name`: Display name to show the user
- `results[].price.final`: Price in cents (divide by 100 for dollars)

### `stools reviews`

Fetch all reviews for a Steam game.

```
stools reviews <app_id_or_url> [--language CODE] [--limit N] [--fields f1,f2,...] [--output FILE]
```

**Arguments:**

- `app` (required): Steam app ID (e.g. `1005310`) or full store URL
- `--language CODE`: Filter by language — `english`, `spanish`, `french`, `german`, etc. Default: `all`
- `--limit N`: Max reviews to return. `0` = all. Default: `0`
- `--fields f1,f2,...`: Comma-separated fields to keep per review. Available: `recommendationid`, `author`, `language`, `review`, `timestamp_created`, `timestamp_updated`, `voted_up`, `votes_up`, `votes_funny`, `steam_purchase`, `received_for_free`, `written_during_early_access`
- `--output FILE`: Write JSON to a file instead of stdout

**Output:**

```json
{
  "app_id": 1005310,
  "query_summary": {
    "num_reviews": 33,
    "review_score": 7,
    "review_score_desc": "Positive",
    "total_positive": 33,
    "total_negative": 0,
    "total_reviews": 33
  },
  "total_fetched": 33,
  "reviews": [
    {
      "review": "The review text content.",
      "voted_up": true
    }
  ]
}
```

**Key fields:**

- `query_summary.review_score_desc`: Overall rating label (e.g. "Positive", "Mixed", "Overwhelmingly Positive")
- `query_summary.total_positive` / `total_negative`: Vote counts
- `reviews[].voted_up`: `true` = positive, `false` = negative
- `reviews[].review`: The full review text
- `reviews[].playtime_forever`: Total playtime in minutes
- `reviews[].playtime_at_review`: Playtime at time of review in minutes

## Exit Codes

`0` = success, `1` = input error, `2` = network/API error.

## Examples

```bash
# Search for a game (minimal output)
stools search "snake vs snake" --fields app_id,name

# Fetch reviews — just text and sentiment
stools reviews 1005310 --fields review,voted_up

# Get only English reviews
stools reviews 1005310 --language english --fields review,voted_up

# Get a sample of 10 reviews
stools reviews 1005310 --limit 10 --fields review,voted_up

# Save full reviews to file
stools reviews 1005310 --output reviews.json
```

## Tips

- Use `--fields` to reduce output size. For disambiguation, `--fields app_id,name` is usually enough.
- Use `--limit` to fetch a small sample before pulling all reviews for large games.
- The `reviews` command accepts full Steam URLs, so you can pass URLs directly from the user.
- Timestamps are Unix epoch seconds.
- Prices are in cents (e.g. `2999` = $29.99).
