"""GadgetBox UI components."""
