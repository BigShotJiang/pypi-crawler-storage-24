"""GadgetBox tools registry."""
