# TeLLMgramBot
The basic goal of this project is to create a bridge between a Telegram Bot and a Large Language Model (LLM), supporting both OpenAI's GPT models and Anthropic's Claude models.
* To use this library, you must have a Telegram account **with a user name**, not just a phone number. If you don't have one, [create one online](https://telegram.org/).
* If added to a Telegram group, the bot must be [administrator](https://www.alphr.com/add-admin-telegram/) in order to respond to a user calling out its name, initials, or nickname.
<img src="assets/TeLLMgramBot_Logo.png" width=200 align=center />

## Telegram Bot + LLM Encapsulation
* The Telegram interface handles special commands, especially on some basic "chatty" prompts and responses that don't require LLM, like "Hello".
* The more dynamic conversation gets handed off to the LLM to manage prompts and responses, and Telegram acts as the interaction broker.
* Pass the URL in [square brackets] and mention how the bot should interpret it.
  * Example: "What do you think of this article? [https://some_site/article]"
  * This uses a separate model (configurable via `url_model`) to support more URL content with its higher token limit.
* Tokens are used to measure the length of all conversation messages between the Telegram bot assistant and the user. This is useful to:
  * Ensure the length does not go over the model limit. If it does, prune oldest messages to fit within the limit.
  * Remember past conversations when restarting: loads the user's full history across all chats (private and groups) plus all other participants' messages in the current chat, up to 50% of the token budget. In private chats, shared group context (messages from groups where both user and bot are active) fills the remaining budget, enabling the bot to reference group conversations from a private context. This eliminates amnesia when users switch between contexts.
* Users can manage privacy via two commands:
  * `/forget` — In private chats, clears the full conversation (including bot replies) and resets all of your active sessions (any sessions where your context was merged). In group chats, removes your messages across all chat types and cleans up paired bot replies; other participants' messages and sessions remain.
  * `/private` — Toggles per-user private mode (private chats only). When ON, messages are excluded from group conversation contexts, enabling selective privacy even in shared groups.

## Why Telegram?
Using Telegram as the interface not only solves "exposing" the interface, but gives you boatloads of interactivity over a standard Command Line interface, or trying to create a website with input boxes and submit buttons to try to handle everything:
1. Telegram already lets you paste in verbose, multiline messages.
2. Telegram already lets you paste in pictures, videos, links, etc.
3. Telegram already lets you react with emojis, stickers, etc.

## Supported LLM Providers
TeLLMgramBot selects the LLM provider automatically based on the model name:

| Model prefix | Provider | Example models |
|---|---|---|
| `gpt-` | OpenAI | `gpt-4o`, `gpt-4o-mini`, `gpt-5-mini` |
| `claude-` | Anthropic | `claude-sonnet-4-6`, `claude-haiku-4-5` |

Simply set `chat_model` (and optionally `url_model`) in your `config.yaml` to any supported model and supply the corresponding API key — no other changes needed.

## Directories
When initializing TeLLMgramBot, the following directories get created:
* `configs` - Contains bot configuration files.
  * `config.yaml` (can be a different name)
    * This file sets main bot parameters like naming and the LLM models to use.
    * `chat_model` — the model used for normal conversation (e.g. `gpt-5-mini` or `claude-sonnet-4-6`).
    * `url_model` — the model used to read and summarize URL content, can differ from `chat_model`.
    * An empty `token_limit` will use the maximum tokens supported by the `chat_model`.
  * `models.yaml`
    * Contains token size parameters for all supported models.
    * On first run, GPT and Claude model families are pre-populated. Additional models can be added manually.
* `prompts` - Contains prompt files for how the bot interacts with any user.
    * `test_personality.prmpt` (can be a different name)
      * A sample prompt file defining the bot's personality: generic, helpful, and multi-provider-aware.
      * The prompt emphasizes the bot's ability to fetch and analyze URLs passed in square brackets `[]`.
      * The user can create more prompt files as needed for different personalities.
    * `system_appendix.prmpt`
      * Framework-owned behavioral guidance automatically appended to the persona prompt at runtime.
      * Teaches the LLM how cross-chat memory works (cross-pollination, private mode, shared group context) without requiring persona authors to include this guidance.
    * `url_analysis.prmpt`
      * Prompt template used to analyze URL content passed in brackets `[]`.
* `errorlogs`
   * Contains a `tellmgrambot_error.log` file to investigate if there are problems during the interaction.
   * User will also get notified to contact the owner.
* `data`
  * Contains `conversations.db` — a SQLite database storing all conversations between the bot and users across all chats.
  * When a user messages in any chat, their full history is available for context: private messages appear in group contexts, group messages appear in private contexts. This creates seamless cross-context awareness. The bot dynamically refreshes each user's context during a session to pick up messages sent between chats. In private chats, the bot also loads shared group context (messages from groups where both user and bot are active) to provide group awareness.
  * Users can manage their context via `/forget` (private chat: clears full conversation; group chat: removes only your messages) or `/private` (toggles per-user privacy for group contexts).

### Environment Variables
TeLLMgramBot also creates or utilizes the following environment variables that can be pre-loaded, especially in containerized environments like Home Assistant with different persistent storage locations:
1. `TELLMGRAMBOT_CONFIGS_PATH` — Directory containing `config.yaml` and `models.yaml`
2. `TELLMGRAMBOT_PROMPTS_PATH` — Directory containing prompt files
3. `TELLMGRAMBOT_ERRORLOGS_PATH` — Directory for error logs
4. `TELLMGRAMBOT_DATA_PATH` — Directory containing `conversations.db` (e.g. `/data`). Defaults to `data/` in the execution directory.

If none are defined, all paths default to subdirectories of the execution directory (the directory containing the entry-point script).

## API Keys
TeLLMgramBot supports the following API keys. Each can be supplied via environment variable or `.key` file:

* **[OpenAI](https://platform.openai.com/overview)** — required when using a `gpt-*` model. Missing: chat and URL analysis disabled.
* **[Anthropic](https://console.anthropic.com/)** — required when using a `claude-*` model. Missing: chat and URL analysis disabled.
* **[Telegram](https://core.telegram.org/api)** — always required; available through BotFather. Missing: bot will not start.
* **[VirusTotal](https://www.virustotal.com/gui/home/)** — optional; performs safety checks on URLs. Missing: URL analysis disabled.

If a provider API key matching your configured model is missing, the bot will start but disable chat and URL analysis features. A startup summary shows which features are enabled.

### Environment Variables
TeLLMgramBot uses the following environment variables for API keys:
1. `TELLMGRAMBOT_OPENAI_API_KEY` *(OpenAI models)*
2. `TELLMGRAMBOT_ANTHROPIC_API_KEY` *(Anthropic models)*
3. `TELLMGRAMBOT_TELEGRAM_API_KEY`
4. `TELLMGRAMBOT_VIRUSTOTAL_API_KEY`

During spin-up time, a user can call out `os.environ[env_var]` to set those variables, like the following example:
```
my_keys = Some_Vault_Fetch_Function()

os.environ['TELLMGRAMBOT_OPENAI_API_KEY']     = my_keys['OpenAIKey']
os.environ['TELLMGRAMBOT_ANTHROPIC_API_KEY']  = my_keys['AnthropicKey']
os.environ['TELLMGRAMBOT_TELEGRAM_API_KEY']   = my_keys['BotFatherToken']
os.environ['TELLMGRAMBOT_VIRUSTOTAL_API_KEY'] = my_keys['VirusTotalToken']
```

This means the user can implement whatever key vault they want to fetch the keys at runtime, without needing files stored in the directory.

### API Key Files
By default, API key files are created in the execution directory (or the directory specified by `TELLMGRAMBOT_KEYS_PATH` for legacy deployments):
1. `openai.key` — OpenAI API key for GPT models
2. `anthropic.key` — Anthropic API key for Claude models
3. `telegram.key` — Telegram Bot API key
4. `virustotal.key` — VirusTotal API key for URL safety checks

Each file with the associated API key will update its respective environment variable if not defined. Missing provider keys (OpenAI or Anthropic) will disable chat and URL analysis but allow the bot to start. Missing VirusTotal keys will disable URL analysis.

## Bot Setup
This library includes an example script `test_local.py`, which uses files from the folders `configs` and `prompts` for TeLLMgramBot to process.
1. Ensure the previous sections are followed with the proper API keys and your Telegram bot set.
2. Install this library via PIP (`pip install TeLLMgramBot`) and then import into your project.
3. Instantiate the bot by passing in various configuration pieces needed below.
   Note the Telegram bot's full name and username auto-populate before startup.
   ```
   telegram_bot = TeLLMgramBot.TelegramBot(
       bot_owner      = <Bot owner's Telegram username>,
       bot_nickname   = <Bot nickname like 'Botty'>,
       bot_initials   = <Bot initials like 'FB'>,
       chat_model     = <Conversation model like 'gpt-4o-mini' or 'claude-sonnet-4-6'>,
       url_model      = <URL analysis model like 'gpt-4o' or 'claude-haiku-4-5'>,
       token_limit    = <Maximum token count set, by default chat_model max>,
       persona_temp   = <LLM factual to creative value [0-2], by default 1.0>,
       persona_prompt = <System prompt summarizing bot personality>
   )
   ```
4. Turn on TeLLMgramBot by calling:
   ```
   telegram_bot.start_polling()
   ```
   Once you see `TeLLMgramBot polling...`, the bot is online in Telegram.
5. Converse! Type `/help` for all available commands.

## Resources
* GitHub repository [python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot) has guides to create a Telegram bot.
* For more information on OpenAI models and token limits:
  * [OpenAI model overview and maximum tokens](https://platform.openai.com/docs/models)
  * [OpenAI message conversion to tokens](https://github.com/openai/openai-python)
  * [OpenAI custom fine-tuning](https://platform.openai.com/docs/guides/model-optimization)
  * [OpenAI's tiktoken library](https://github.com/openai/tiktoken/tree/main)
* For more information on Anthropic Claude models:
  * [Anthropic model overview and context windows](https://docs.anthropic.com/en/docs/about-claude/models)
  * [Anthropic Python SDK](https://github.com/anthropic/anthropic-sdk-python)
