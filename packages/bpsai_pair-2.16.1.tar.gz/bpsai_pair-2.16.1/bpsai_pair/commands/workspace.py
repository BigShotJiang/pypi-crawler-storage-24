"""Workspace management CLI commands.

Part of Sprint 33 Workspace Foundation.
Commands: init, status, pull.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import typer
import yaml
from rich.console import Console

from ..core import ops
from ..licensing import require_feature
from ..workspace.parser import WorkspaceParser

console = Console()

_CONFIG_FILENAME = ".paircoder-workspace.yaml"


def print_json(data: dict) -> None:
    """Print JSON to stdout without Rich formatting."""
    sys.stdout.write(json.dumps(data, indent=2))
    sys.stdout.write("\n")
    sys.stdout.flush()


def repo_root() -> Path:
    """Get repo root with better error message."""
    p = ops.find_project_root()
    if not ops.GitOps.is_repo(p):
        console.print(
            "[red]Error: Not in a git repository.[/red]\n"
            "Please run from your project root directory (where .git exists)."
        )
        raise typer.Exit(1)
    return p


def _find_config() -> Path:
    """Find workspace config at repo root or in parent directories."""
    root = repo_root()
    config_path = WorkspaceParser().find_workspace_config(root)
    if config_path:
        return config_path
    console.print(
        "[red]Error: No workspace config found.[/red]\n"
        "Run 'bpsai-pair workspace init' first."
    )
    raise typer.Exit(1)


app = typer.Typer(
    help="Workspace management commands",
    context_settings={"help_option_names": ["-h", "--help"]},
)


@app.command("init")
@require_feature("workspace")
def workspace_init(
    name: str = typer.Option(None, "--name", help="Workspace name"),
    projects: str = typer.Option(None, "--projects", help="Projects as name:path,name:path"),
    scan: bool = typer.Option(False, "--scan", help="Scan for .paircoder directories"),
    no_scan: bool = typer.Option(False, "--no-scan", help="Disable scanning"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing config"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Initialize a new workspace configuration."""
    root = repo_root()
    config_path = root / _CONFIG_FILENAME

    _validate_init_args(config_path, name, force)
    project_dict = _resolve_projects(projects, scan, no_scan, root)
    _write_config(config_path, name, project_dict, json_out)


def _validate_init_args(config_path: Path, name: str | None, force: bool) -> None:
    """Validate init command arguments, exit on error."""
    if config_path.exists() and not force:
        console.print(
            f"[red]Error: {_CONFIG_FILENAME} already exists.[/red]\n"
            "Use --force to overwrite."
        )
        raise typer.Exit(1)
    if not name:
        console.print("[red]Error: --name is required.[/red]")
        raise typer.Exit(1)


def _resolve_projects(
    projects: str | None, scan: bool, no_scan: bool, root: Path,
) -> dict[str, dict[str, Any]]:
    """Resolve project dict from flags."""
    project_dict: dict[str, dict[str, Any]] = {}
    if projects:
        project_dict = _parse_projects_flag(projects)
    elif scan or not no_scan:
        project_dict = _scan_for_projects(root)
    if not project_dict and no_scan:
        console.print(
            "[red]Error: No projects specified.[/red]\n"
            "Use --projects name:path or --scan to discover."
        )
        raise typer.Exit(1)
    return project_dict


def _write_config(
    config_path: Path, name: str, project_dict: dict, json_out: bool,
) -> None:
    """Write workspace config file and display output."""
    config_data = {"name": name, "projects": project_dict}
    config_path.write_text(
        yaml.dump(config_data, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    if json_out:
        print_json({
            "name": name,
            "projects": project_dict,
            "config_path": str(config_path),
        })
    else:
        _print_init_output(name, project_dict, config_path)


def _parse_projects_flag(projects_str: str) -> dict[str, dict[str, Any]]:
    """Parse --projects flag value into project dict."""
    result: dict[str, dict[str, Any]] = {}
    for entry in projects_str.split(","):
        entry = entry.strip()
        if ":" not in entry:
            console.print(
                f"[red]Error: Invalid project format '{entry}'.[/red]\n"
                "Expected format: name:path (e.g., cli:./paircoder)"
            )
            raise typer.Exit(1)
        proj_name, proj_path = entry.split(":", 1)
        result[proj_name.strip()] = {"path": proj_path.strip()}
    return result


def _scan_for_projects(root: Path) -> dict[str, dict[str, Any]]:
    """Scan child directories for .paircoder projects."""
    result: dict[str, dict[str, Any]] = {}
    for child in sorted(root.iterdir()):
        if not child.is_dir():
            continue
        if child.name.startswith("."):
            continue
        if (child / ".paircoder").is_dir():
            result[child.name] = {"path": f"./{child.name}"}
    return result


def _print_init_output(
    name: str, projects: dict[str, dict], config_path: Path
) -> None:
    """Print workspace init result."""
    console.print("\n[bold]Workspace Created[/bold]")
    console.print("=" * 40)
    console.print(f"  Name: {name}")
    console.print(f"  Projects: {len(projects)}")

    if projects:
        console.print("\n[bold]Projects:[/bold]")
        for proj_name, proj_data in projects.items():
            console.print(f"  {proj_name}: {proj_data.get('path', '?')}")

    console.print(f"\n  Created: {config_path.name}")
    console.print(
        "\nNext: Run 'bpsai-pair workspace status' to verify configuration."
    )
    console.print()


# =============================================================================
# workspace status
# =============================================================================


@app.command("status")
@require_feature("workspace")
def workspace_status(
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Show workspace configuration and project states."""
    from .workspace_helpers import (
        gather_project_states, gather_dependencies,
        print_status_output, print_agent_teams_output,
    )
    from ..workspace.agent_teams import detect_agent_teams

    config_path = _find_config()
    ws = WorkspaceParser().parse(config_path)
    project_states = gather_project_states(ws)
    deps = gather_dependencies(ws)
    teams = detect_agent_teams()

    if json_out:
        data: dict[str, Any] = {
            "name": ws.name,
            "config_path": str(ws.config_path),
            "projects": {s["name"]: s for s in project_states},
            "dependencies": deps,
        }
        if teams:
            data["agent_teams"] = [t.to_dict() for t in teams]
        print_json(data)
    else:
        print_status_output(ws.name, config_path, project_states, deps)
        print_agent_teams_output(teams)


# =============================================================================
# workspace pull
# =============================================================================


@app.command("pull")
@require_feature("workspace")
def workspace_pull(
    project: str = typer.Argument(None, help="Project name (all if omitted)"),
    rebase: bool = typer.Option(False, "--rebase", help="Use git pull --rebase"),
    json_out: bool = typer.Option(False, "--json", help="Output in JSON format"),
):
    """Pull latest changes from remote for workspace projects."""
    from .workspace_helpers import pull_project, print_pull_output

    config_path = _find_config()
    ws = WorkspaceParser().parse(config_path)

    if project:
        proj = ws.get_project(project)
        if proj is None:
            console.print(f"[red]Error: Project '{project}' not found.[/red]")
            raise typer.Exit(1)
        targets = {project: proj}
    else:
        targets = ws.projects

    results = [
        pull_project(name, ws.root_path / p.path, rebase=rebase)
        for name, p in targets.items()
    ]

    if json_out:
        print_json({"results": {r["name"]: r for r in results}})
    else:
        print_pull_output(results)


# =============================================================================
# Register impact/audit commands from workspace_impact module
# =============================================================================

from .workspace_impact import register_impact_commands  # noqa: E402
from .workspace_index_cmd import register_index_command  # noqa: E402
from .workspace_init_project import register_init_project_commands  # noqa: E402

register_impact_commands(app)
register_index_command(app)
register_init_project_commands(app)
