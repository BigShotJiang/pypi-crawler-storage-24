"""Execute and display helpers for the upgrade command.

Extracted from upgrade_helpers.py for architecture compliance.
Contains: execute sub-functions, config defaults, and display helpers.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING
import shutil

from rich.console import Console

if TYPE_CHECKING:
    from .upgrade import UpgradePlan


# ---------------------------------------------------------------------------
# Execute sub-functions
# ---------------------------------------------------------------------------


def _execute_skills(
    results: dict,
    project_root: Path,
    bundled_skills: dict[str, dict],
    plan: UpgradePlan,
) -> None:
    """Copy all files per skill (file-by-file to preserve project-only files)."""
    for skill_name in plan.skills_to_add:
        if skill_name in bundled_skills:
            _copy_skill_files(project_root, skill_name, bundled_skills[skill_name])
            results["skills_added"] += 1

    for skill_name in plan.skills_to_update:
        if skill_name in bundled_skills:
            _copy_skill_files(project_root, skill_name, bundled_skills[skill_name])
            results["skills_updated"] += 1


def _copy_skill_files(
    project_root: Path,
    skill_name: str,
    skill_data: dict,
) -> None:
    """Copy individual skill files without removing project-only files."""
    dst_dir = project_root / ".claude" / "skills" / skill_name
    for rel_path, abs_path in skill_data["files"]:
        dst = dst_dir / rel_path
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(abs_path, dst)


def _execute_agents(
    results: dict,
    project_root: Path,
    bundled_agents: dict,
    plan: UpgradePlan,
) -> None:
    """Copy agent files."""
    dst_dir = project_root / ".claude" / "agents"
    for agent_name in plan.agents_to_add:
        if agent_name in bundled_agents:
            dst_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bundled_agents[agent_name], dst_dir / f"{agent_name}.md")
            results["agents_added"] += 1

    for agent_name in plan.agents_to_update:
        if agent_name in bundled_agents:
            dst_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bundled_agents[agent_name], dst_dir / f"{agent_name}.md")
            results["agents_updated"] += 1


def _execute_commands(
    results: dict,
    project_root: Path,
    bundled_commands: dict,
    plan: UpgradePlan,
) -> None:
    """Copy command files."""
    dst_dir = project_root / ".claude" / "commands"
    for cmd_name in plan.commands_to_add:
        if cmd_name in bundled_commands:
            dst_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bundled_commands[cmd_name], dst_dir / f"{cmd_name}.md")
            results["commands_added"] += 1

    for cmd_name in plan.commands_to_update:
        if cmd_name in bundled_commands:
            dst_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(bundled_commands[cmd_name], dst_dir / f"{cmd_name}.md")
            results["commands_updated"] += 1


def _execute_docs(
    results: dict,
    project_root: Path,
    template: Path,
    plan: UpgradePlan,
) -> None:
    """Copy doc files."""
    for doc_rel in plan.docs_to_update:
        src = template / doc_rel
        dst = project_root / doc_rel
        if src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            results["docs_updated"] += 1


_RUNTIME_DIRS = ["telemetry", "feedback", "history", "history/handoffs"]

_CALIBRATION_SEED = {
    "version": "1.0",
    "task_types": {},
    "global": {"count": 0, "mean": 0.0, "m2": 0.0},
}


def _execute_runtime_dirs(results: dict, project_root: Path) -> None:
    """Ensure runtime directories exist under .paircoder/."""
    paircoder_dir = project_root / ".paircoder"
    if not paircoder_dir.exists():
        return
    for dirname in _RUNTIME_DIRS:
        target = paircoder_dir / dirname
        if not target.exists():
            target.mkdir(parents=True, exist_ok=True)
            results["dirs_created"] += 1


def _execute_telemetry_bootstrap(results: dict, project_root: Path) -> None:
    """Bootstrap telemetry pipeline data files if missing."""
    import json

    paircoder_dir = project_root / ".paircoder"
    if not paircoder_dir.exists():
        return

    # Bootstrap telemetry.jsonl
    tel_file = paircoder_dir / "telemetry" / "telemetry.jsonl"
    if tel_file.parent.exists() and not tel_file.exists():
        tel_file.touch()
        results.setdefault("files_bootstrapped", 0)
        results["files_bootstrapped"] += 1

    # Bootstrap calibration.json with seed state
    cal_file = paircoder_dir / "feedback" / "calibration.json"
    if cal_file.parent.exists() and not cal_file.exists():
        cal_file.write_text(json.dumps(_CALIBRATION_SEED, indent=2))
        results.setdefault("files_bootstrapped", 0)
        results["files_bootstrapped"] += 1

    # Clean up dead metrics/ directory if empty
    dead_metrics = paircoder_dir / "metrics"
    if dead_metrics.is_dir() and not any(dead_metrics.iterdir()):
        dead_metrics.rmdir()
        results.setdefault("dirs_cleaned", 0)
        results["dirs_cleaned"] += 1


_FLEET_CACHE_TTL_DAYS = 7


def _is_cache_fresh(cache_path: Path) -> bool:
    """Return True if a cache file exists and was modified within the TTL."""
    if not cache_path.exists():
        return False
    age_seconds = time.time() - cache_path.stat().st_mtime
    return age_seconds < (_FLEET_CACHE_TTL_DAYS * 86400)


def _execute_fleet_calibration(results: dict, project_root: Path) -> None:
    """Pull fleet calibration from API and merge with local data."""
    import json
    import logging

    from bpsai_pair.feedback.fleet import FleetCalibrationClient, merge_fleet_data
    from bpsai_pair.feedback.schema import CalibrationData

    log = logging.getLogger(__name__)

    cal_file = project_root / ".paircoder" / "feedback" / "calibration.json"
    if not cal_file.exists():
        results["fleet_calibration"] = "skipped"
        return

    if _is_cache_fresh(cal_file):
        log.info("Fleet calibration cache is fresh, skipping fetch")
        results["fleet_calibration"] = "fresh"
        return

    client = FleetCalibrationClient()
    fleet_data = client.fetch()
    if fleet_data is None:
        log.info("Fleet calibration unavailable, skipping merge")
        results["fleet_calibration"] = "skipped"
        return

    try:
        raw = json.loads(cal_file.read_text(encoding="utf-8"))
        local_cal = CalibrationData.from_dict(raw)
    except Exception as e:
        log.warning("Could not parse local calibration data: %s", e)
        results["fleet_calibration"] = "skipped"
        return

    merge_fleet_data(local_cal, fleet_data, project_root)
    results["fleet_calibration"] = "merged"
    log.info("Fleet calibration merged successfully")


def _execute_fleet_demand(results: dict, project_root: Path) -> None:
    """Pull fleet demand signals from API and cache locally."""
    import logging

    from bpsai_pair.feedback.fleet import FleetCalibrationClient, cache_demand_signals

    log = logging.getLogger(__name__)

    demand_cache = project_root / ".paircoder" / "feedback" / "demand-signals.json"
    if _is_cache_fresh(demand_cache):
        log.info("Fleet demand cache is fresh, skipping fetch")
        results["fleet_demand"] = "fresh"
        return

    client = FleetCalibrationClient()
    demand_data = client.fetch_demand_signals()
    if demand_data is None:
        log.info("Fleet demand signals unavailable, skipping")
        results["fleet_demand"] = "skipped"
        return

    cache_demand_signals(demand_data, project_root)
    results["fleet_demand"] = "cached"
    log.info("Fleet demand signals cached successfully")


def _execute_statusline(results: dict, project_root: Path) -> None:
    """Merge statusLine key into .claude/settings.json if missing."""
    try:
        from bpsai_pair.statusline_install import install_statusline
        changed = install_statusline(project_root)
        results["statusline_installed"] = changed
    except Exception:
        results["statusline_installed"] = False


def _execute_config(
    results: dict,
    project_root: Path,
    plan: UpgradePlan,
    console: Console,
) -> None:
    """Add missing config sections and bump stale version via update_config."""
    if not plan.config_sections_to_add and not plan.config_version_stale and not plan.hooks_stale:
        return

    config_path = project_root / ".paircoder" / "config.yaml"
    if not config_path.exists():
        return

    try:
        import yaml
        from ..core.config_validator import update_config

        updated_config, changes = update_config(project_root)

        for change in changes:
            if change.startswith("Added section:"):
                results["config_sections_added"] += 1

        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(updated_config, f, default_flow_style=False, sort_keys=False)

        if changes:
            console.print(f"  [dim]Config: {len(changes)} change(s)[/dim]")
            for change in changes:
                console.print(f"    {change}")
    except Exception as e:
        console.print(f"[yellow]Warning: Could not update config: {e}[/yellow]")


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


def print_upgrade_plan(plan: UpgradePlan, console: Console) -> None:
    """Print the Rich output for the upgrade plan."""
    console.print("\n[bold]Upgrade Plan:[/bold]\n")

    _print_list(console, "Skills to add", plan.skills_to_add, "+")
    _print_list(console, "Skills to update", plan.skills_to_update, "~")
    _print_list(console, "Agents to add", plan.agents_to_add, "+")
    _print_list(console, "Agents to update", plan.agents_to_update, "~")
    _print_list(console, "Commands to add", plan.commands_to_add, "+")
    _print_list(console, "Commands to update", plan.commands_to_update, "~")
    _print_list(console, "Docs to update", plan.docs_to_update, "~")
    if plan.config_version_stale:
        from ..core.config_defaults import CONFIG_SCHEMA_VERSION
        console.print(f"  [cyan]Config version:[/cyan]")
        console.print(f"    ~ Bump to {CONFIG_SCHEMA_VERSION}")
    _print_list(console, "Config sections to add", plan.config_sections_to_add, "+")
    if plan.hooks_stale:
        console.print("  [cyan]Hooks:[/cyan]")
        console.print("    ~ Update hook lists (add missing, remove deprecated)")
    _print_list(console, "Runtime dirs to create", plan.dirs_to_create, "+")

    if plan.warnings:
        console.print("\n  [yellow]Warnings:[/yellow]")
        for w in plan.warnings:
            console.print(f"    ! {w}")


def _print_list(
    console: Console,
    label: str,
    items: list,
    prefix: str,
) -> None:
    """Print a labeled list of items if non-empty."""
    if not items:
        return
    console.print(f"  [cyan]{label}:[/cyan]")
    for item in items:
        console.print(f"    {prefix} {item}")


def print_upgrade_summary(
    results: dict,
    do_skills: bool,
    do_agents: bool,
    do_commands: bool,
    do_docs: bool,
    do_config: bool,
    console: Console,
) -> None:
    """Print the Rich output for upgrade results."""
    summary_parts: list[str] = []
    if do_skills and (results["skills_added"] or results["skills_updated"]):
        summary_parts.append(
            f"{results['skills_added']} skills added, "
            f"{results['skills_updated']} updated"
        )
    if do_agents and (results["agents_added"] or results["agents_updated"]):
        summary_parts.append(
            f"{results['agents_added']} agents added, "
            f"{results['agents_updated']} updated"
        )
    if do_commands and (results["commands_added"] or results["commands_updated"]):
        summary_parts.append(
            f"{results['commands_added']} commands added, "
            f"{results['commands_updated']} updated"
        )
    if do_docs and results["docs_updated"]:
        summary_parts.append(f"{results['docs_updated']} docs updated")
    if do_config and results["config_sections_added"]:
        summary_parts.append(
            f"{results['config_sections_added']} config sections added"
        )
    if results.get("dirs_created"):
        summary_parts.append(f"{results['dirs_created']} runtime dirs created")

    if summary_parts:
        console.print(f"  {', '.join(summary_parts)}")
