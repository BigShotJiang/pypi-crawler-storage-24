"""Query CLI command for structured state queries.

Exposes the QueryBuilder as `bpsai-pair query` with subcommands:
  - metrics <name> [--task-type TYPE] [--days N] [--json]
  - state <key> [--json]
  - tasks [--status STATUS] [--json]
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ..core import ops

console = Console()

app = typer.Typer(
    help="Query project state, metrics, and tasks.",
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _get_root() -> Path:
    return ops.find_project_root()


def _print_result(data: dict, as_json: bool) -> None:
    if as_json:
        sys.stdout.write(json.dumps(data, indent=2, default=str))
        sys.stdout.write("\n")
        sys.stdout.flush()
    else:
        _print_table(data)


def _print_table(data: dict) -> None:
    category = data.get("category", "result")
    table = Table(title=f"Query: {category}")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="white")
    for key, value in data.items():
        if key == "category":
            continue
        table.add_row(str(key), str(value))
    console.print(table)


@app.command()
def metrics(
    name: str = typer.Argument(..., help="Metric name: success_rate, estimation_accuracy, agent_performance"),
    task_type: Optional[str] = typer.Option(None, "--task-type", "-t", help="Filter by task type"),
    days: Optional[int] = typer.Option(None, "--days", "-d", help="Filter by recency (days)"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Query metrics (success rates, estimation accuracy, agent performance)."""
    from ..feedback.query_builder import QueryBuilder

    root = _get_root()
    q = QueryBuilder(root).metrics(name)
    if task_type:
        q = q.where(task_type=task_type)
    if days:
        q = q.where(days=days)

    try:
        result = q.execute()
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    _print_result(result, json_out)


@app.command()
def state(
    key: str = typer.Argument(..., help="State key: active-tasks, current-plan"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Query project state (active tasks, current plan)."""
    from ..feedback.query_builder import QueryBuilder

    root = _get_root()
    try:
        result = QueryBuilder(root).state(key).execute()
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    _print_result(result, json_out)


@app.command()
def tasks(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Query tasks with optional status filter."""
    from ..feedback.query_builder import QueryBuilder

    root = _get_root()
    q = QueryBuilder(root).tasks()
    if status:
        q = q.where(status=status)

    result = q.execute()
    _print_result(result, json_out)
