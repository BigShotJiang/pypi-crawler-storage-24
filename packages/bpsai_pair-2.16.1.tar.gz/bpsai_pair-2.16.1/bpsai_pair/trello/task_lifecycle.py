"""
Task lifecycle commands for Trello: start, done, block.

These commands manage the lifecycle state of tasks on Trello.
"""
import logging
from typing import Optional

import typer
from rich.console import Console

from ..licensing import require_feature
from .list_resolver import ListResolver
from .task_pm_routing import get_pm_lifecycle as _get_pm_lifecycle
from .task_helpers import (
    get_board_client,
    log_activity,
    get_task_id_from_card,
    check_task_budget,
)
from .task_done_pipeline import (
    _check_strict_enforcement,
    _verify_trello_ac,
    _run_post_completion,
    _post_start_actions,
)

logger = logging.getLogger(__name__)
console = Console()


def _move_to_in_progress(client, config, card, card_id):
    """Move card to In Progress via PM or legacy Trello. Returns list name."""
    lifecycle, in_progress_list = _get_pm_lifecycle(config, "in_progress")
    if lifecycle is not None:
        try:
            lifecycle.start_item(card_id)
        except Exception as e:
            console.print(f"[red]PM provider error: {e}[/red]")
            raise typer.Exit(1)
    else:
        resolver = ListResolver(client)
        target = resolver.find_list_for_status("in_progress")
        in_progress_list = target["name"] if target else "In Progress"
        client.move_card(card, in_progress_list)
        try:
            client.set_card_status(card, "In Progress")
        except Exception as e:
            logger.warning("Could not update Status field: %s", e)
    return in_progress_list


def _move_to_done(client, config, card, card_id, list_name, summary):
    """Move card to Done via PM or legacy Trello. Returns list name."""
    lifecycle, pm_dest = _get_pm_lifecycle(config, "done")
    if lifecycle is not None:
        try:
            lifecycle.complete_item(card_id, summary, strict_ac=False)
        except Exception as e:
            console.print(f"[red]PM provider error: {e}[/red]")
            raise typer.Exit(1)
        list_name = list_name or pm_dest
    else:
        if list_name is None:
            resolver = ListResolver(client)
            target = resolver.find_list_for_status("done")
            list_name = target["name"] if target else "Deployed/Done"
        client.move_card(card, list_name)
        try:
            client.set_card_status(card, "Done")
        except Exception as e:
            logger.warning("Could not update Status field: %s", e)
    return list_name


def _move_to_blocked(client, config, card, card_id, reason):
    """Move card to Blocked via PM or legacy Trello. Returns list name."""
    lifecycle, blocked_list = _get_pm_lifecycle(config, "blocked")
    if lifecycle is not None:
        try:
            lifecycle.block_item(card_id, reason)
        except Exception as e:
            console.print(f"[red]PM provider error: {e}[/red]")
            raise typer.Exit(1)
    else:
        resolver = ListResolver(client)
        target = resolver.find_list_for_status("blocked")
        blocked_list = target["name"] if target else "Issues/Tech Debt"
        client.move_card(card, blocked_list)
        try:
            client.set_card_status(card, "Blocked")
        except Exception as e:
            logger.warning("Could not update Status field: %s", e)
    return blocked_list


def _update_local_on_start(task_id, card_name):
    """Update local task status to in_progress and trigger post-start hooks."""
    try:
        from ..core.ops import find_paircoder_dir
        from ..planning.parser import TaskParser

        paircoder_dir = find_paircoder_dir()
        if paircoder_dir.exists():
            task_parser = TaskParser(paircoder_dir / "tasks")
            if task_parser.update_status(task_id, "in_progress"):
                console.print(f"[green]\u2713 Local task {task_id} updated to in_progress[/green]")
            task_obj = task_parser.get_task_by_id(task_id)
            _post_start_actions(paircoder_dir, task_id, task_obj, card_name)
    except Exception as e:
        console.print(f"[yellow]\u26a0 Could not update local task: {e}[/yellow]")


@require_feature("trello")
def task_start(
    card_id: str = typer.Argument(..., help="Card ID to start"),
    summary: str = typer.Option("Beginning work", "--summary", "-s", help="Start summary"),
    budget_override: bool = typer.Option(
        False, "--budget-override",
        help="Start despite budget warning (logged for audit)"
    ),
):
    """Start working on a task (moves to In Progress).

    Checks token budget before starting. Use --budget-override to bypass
    budget limits (logged for audit).
    """
    client, config = get_board_client()
    card, lst = client.find_card(card_id)

    if not card:
        console.print(f"[red]Card not found: {card_id}[/red]")
        raise typer.Exit(1)

    task_id = get_task_id_from_card(card)
    if task_id:
        if not check_task_budget(task_id, card_id, budget_override):
            raise typer.Exit(1)

    if client.is_card_blocked(card):
        console.print("[red]Cannot start - card has unchecked dependencies[/red]")
        raise typer.Exit(1)

    in_progress_list = _move_to_in_progress(client, config, card, card_id)
    log_activity(card, "started", summary)

    console.print(f"[green]\u2713 Started: {card.name}[/green]")
    console.print(f"  Moved to: {in_progress_list}")
    console.print(f"  URL: {card.url}")

    if task_id:
        _update_local_on_start(task_id, card.name)


@require_feature("trello")
def task_done(
    card_id: str = typer.Argument(..., help="Card ID to complete"),
    summary: str = typer.Option(..., "--summary", "-s", prompt=True, help="Completion summary"),
    list_name: Optional[str] = typer.Option(None, "--list", "-l", help="Target list (default: Deployed/Done)"),
    auto_check: bool = typer.Option(False, "--auto-check",
                                    help="Auto-check all acceptance criteria (use with caution)"),
    strict: bool = typer.Option(True, "--strict/--no-strict",
                                help="Block if acceptance criteria unchecked (default: strict)"),
    allow_dirty: bool = typer.Option(False, "--allow-dirty",
                                     help="Allow completion with uncommitted changes (logged for audit)"),
):
    """Complete a task (moves to Done list)."""

    # ENFORCEMENT: Block completion with uncommitted changes
    try:
        from ..core.ops import find_paircoder_dir
        from ..planning.task_update_enforcement import enforce_clean_git_tree
        enforce_clean_git_tree(find_paircoder_dir(), allow_dirty=allow_dirty, task_id=card_id)
    except ImportError:
        pass

    if not strict and _check_strict_enforcement(card_id):
        raise typer.Exit(1)

    client, config = get_board_client()
    card, lst = client.find_card(card_id)

    if not card:
        console.print(f"[red]Card not found: {card_id}[/red]")
        raise typer.Exit(1)

    try:
        card.fetch()
    except Exception:
        pass

    task_id = get_task_id_from_card(card)
    ac_status_msg, task_outcome = _verify_trello_ac(
        card, card_id, strict, auto_check, task_id, client,
    )

    list_name = _move_to_done(client, config, card, card_id, list_name, summary)

    completion_msg = f"{summary} | {ac_status_msg}"
    log_activity(card, "completed", completion_msg)

    console.print(f"[green]\u2713 Completed: {card.name}[/green]")
    console.print(f"  Moved to: {list_name}")
    console.print(f"  Summary: {summary}")

    _run_post_completion(card, task_id, summary, task_outcome)


@require_feature("trello")
def task_block(
    card_id: str = typer.Argument(..., help="Card ID to block"),
    reason: str = typer.Option(..., "--reason", "-r", prompt=True, help="Block reason"),
):
    """Mark a task as blocked."""
    client, config = get_board_client()
    card, lst = client.find_card(card_id)

    if not card:
        console.print(f"[red]Card not found: {card_id}[/red]")
        raise typer.Exit(1)

    blocked_list = _move_to_blocked(client, config, card, card_id, reason)
    log_activity(card, "blocked", reason)

    console.print(f"[yellow]Blocked: {card.name}[/yellow]")
    console.print(f"  Moved to: {blocked_list}")
    console.print(f"  Reason: {reason}")
