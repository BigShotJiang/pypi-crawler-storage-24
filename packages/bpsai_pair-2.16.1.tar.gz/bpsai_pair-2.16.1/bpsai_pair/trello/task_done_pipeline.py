"""Extracted sub-steps for task_done and task_start pipelines.

Keeps task_lifecycle.py focused on CLI entry points and routing.
"""
import logging

import typer
import yaml
from rich.console import Console

from ..core.ops import find_paircoder_dir
from .task_card_ops import (
    auto_check_acceptance_criteria,
    get_unchecked_ac_items,
    log_bypass,
)
from .task_completion import (
    _collect_task_telemetry,
    complete_task_with_state_machine,
    run_completion_hooks,
    sync_local_ac_for_completion,
)
from .task_handoff import create_start_handoff, create_completion_handoff
from .task_sync import update_local_task_status, update_plan_status_if_needed

logger = logging.getLogger(__name__)
console = Console()


def _check_strict_enforcement(card_id: str) -> bool:
    """Return True if --no-strict should be blocked by config enforcement."""
    try:
        config_path = find_paircoder_dir() / "config.yaml"
        if config_path.exists():
            with open(config_path, encoding='utf-8') as f:
                config = yaml.safe_load(f) or {}
            if config.get("enforcement", {}).get("strict_ac_verification", False):
                console.print(
                    "\n[red]\u274c BLOCKED: --no-strict is disabled when "
                    "strict_ac_verification is enabled.[/red]")
                console.print("")
                console.print("[yellow]You must verify acceptance criteria before completion:[/yellow]")
                console.print("  1. Check items manually on Trello card")
                console.print(f'  2. Use: [cyan]bpsai-pair ttask check {card_id} "<item text>"[/cyan]')
                console.print(f'  3. Then: [cyan]bpsai-pair ttask done {card_id} --summary "..."[/cyan]')
                console.print("")
                console.print("[dim]This ensures all acceptance criteria are verified before completion.[/dim]")
                return True
    except (ImportError, FileNotFoundError):
        pass
    return False


def _verify_trello_ac(card, card_id, strict, auto_check, task_id, client):
    """Verify acceptance criteria on Trello card.

    Returns (ac_status_msg, task_outcome).
    Raises typer.Exit(1) if strict mode and items are unchecked.
    """
    if auto_check:
        checked_count = auto_check_acceptance_criteria(card, client)
        if checked_count > 0:
            console.print(f"[green]\u2713 Auto-checked {checked_count} acceptance criteria item(s)[/green]")
            try:
                card.fetch()
            except Exception as e:
                logger.debug("Card re-fetch after auto-check failed: %s", e)

    if strict:
        return _verify_strict(card, card_id, auto_check, task_id)

    return _verify_non_strict(card, card_id)


def _verify_strict(card, card_id, auto_check, task_id):
    """Strict AC verification — block if items unchecked."""
    unchecked = get_unchecked_ac_items(card)
    if unchecked:
        console.print(f"[red]\u274c Cannot complete: {len(unchecked)} acceptance criteria item(s) unchecked[/red]")
        console.print("\n[dim]Unchecked items:[/dim]")
        for item in unchecked:
            console.print(f"  \u25cb {item.get('name', '')}")
        console.print("\n[dim]Options:[/dim]")
        console.print(f'  1. Check items: [cyan]bpsai-pair ttask check {card_id} "<item text>"[/cyan]')
        console.print("  2. Check on Trello directly")
        if auto_check:
            console.print("\n[yellow]Note: --auto-check ran but some items could not be checked.[/yellow]")
        if task_id:
            try:
                from ..telemetry.schema import Outcome as _O
                _collect_task_telemetry(
                    task_id, find_paircoder_dir(),
                    outcome=_O.FAIL,
                    error_context=f"AC verification failed: {len(unchecked)} unchecked items",
                )
            except Exception as e:
                logger.debug("Failed to record AC failure telemetry: %s", e)
        raise typer.Exit(1)

    console.print("[green]\u2713 All Trello acceptance criteria verified[/green]")

    # STATE MACHINE: Transition to AC_VERIFIED
    try:
        from ..core.task_state import TaskState, get_state_manager, is_state_machine_enabled
        if is_state_machine_enabled() and task_id:
            manager = get_state_manager()
            current = manager.get_state(task_id)
            if current == TaskState.IN_PROGRESS:
                manager.transition(task_id, TaskState.AC_VERIFIED, trigger="trello_ac_verified")
    except Exception as e:
        logger.warning("State machine transition failed: %s", e)

    return "All AC items verified", None


def _verify_non_strict(card, card_id):
    """Non-strict AC verification — warn but allow."""
    unchecked = get_unchecked_ac_items(card)
    if unchecked:
        console.print(f"[yellow]\u26a0 Completing with {len(unchecked)} unchecked AC item(s)[/yellow]")
        log_bypass("ttask done", card_id, f"--no-strict with {len(unchecked)} unchecked AC items")
        return f"Bypassed with {len(unchecked)} unchecked AC items (logged)", "partial"
    return "AC verification skipped (all items already complete)", None


def _run_post_completion(card, task_id, summary, task_outcome):
    """Run post-completion pipeline: local AC, task update, hooks, handoff, state machine.

    Raises typer.Exit(1) on blocking failures.
    """
    # Local AC sync (only when task_id is known)
    if task_id:
        local_ac_ok, local_ac_msg = sync_local_ac_for_completion(task_id, is_trello=True)
        if not local_ac_ok:
            console.print(f"[red]\u274c BLOCKED: {local_ac_msg}[/red]")
            console.print("\n[dim]The Trello card was moved to Done, but local AC verification failed.[/dim]")
            console.print("[dim]Please check and update local AC items before completing.[/dim]")
            _record_fail_telemetry(task_id, f"Local AC verification failed: {local_ac_msg}")
            raise typer.Exit(1)
        console.print("[green]\u2713 Local acceptance criteria verified[/green]")

    # Update local task file + run hooks
    try:
        success, task_id_result = update_local_task_status(card, "done", summary)
        if not task_id and task_id_result:
            task_id = task_id_result
        if success and task_id:
            _on_task_update_success(card, task_id, summary, task_outcome)
        elif task_id:
            console.print(f"[red]\u274c BLOCKED: Could not update local task file for {task_id}[/red]")
            console.print(f"[dim]The Trello card was moved to Done, but local task file could not be updated.[/dim]")
            console.print(f"[dim]Please manually update: .paircoder/tasks/{task_id}.task.md[/dim]")
            raise typer.Exit(1)
    except typer.Exit:
        raise
    except FileNotFoundError:
        from .task_card_ops import get_task_id_from_card
        tid = task_id or get_task_id_from_card(card)
        if tid:
            console.print(f"[yellow]\u26a0 Local task file not found for {tid}[/yellow]")
            console.print(f"[dim]Expected: .paircoder/tasks/{tid}.task.md[/dim]")
    except Exception as e:
        from .task_card_ops import get_task_id_from_card
        tid = task_id or get_task_id_from_card(card)
        if tid:
            console.print(f"[red]\u274c BLOCKED: Error syncing local task {tid}: {e}[/red]")
            raise typer.Exit(1)
        console.print(f"[yellow]\u26a0 Could not sync local task: {e}[/yellow]")


def _on_task_update_success(card, task_id, summary, task_outcome):
    """Run hooks, handoff, plan update, state machine after successful task update."""
    console.print(f"[green]\u2713 Local task {task_id} updated to done[/green]")
    from ..telemetry.schema import Outcome as _Outcome
    _outcome = _Outcome.PARTIAL if task_outcome == "partial" else None
    run_completion_hooks(task_id, outcome=_outcome)

    # Create driver→reviewer handoff (fire-and-forget)
    try:
        from ..planning.parser import TaskParser
        paircoder_dir = find_paircoder_dir()
        ac = []
        try:
            task_obj = TaskParser(paircoder_dir / "tasks").get_task_by_id(task_id)
            if task_obj and task_obj.acceptance_criteria:
                ac = task_obj.acceptance_criteria
        except Exception as e:
            logger.debug("Could not load AC for handoff: %s", e)
        create_completion_handoff(
            task_id=task_id,
            task_title=card.name,
            summary=summary,
            acceptance_criteria=ac,
            paircoder_dir=paircoder_dir,
        )
    except Exception as e:
        logger.debug("Completion handoff failed for %s: %s", task_id, e)

    update_plan_status_if_needed(task_id)

    complete_ok, complete_msg = complete_task_with_state_machine(task_id, trigger="ttask_done")
    if not complete_ok:
        console.print(f"[yellow]\u26a0 State machine: {complete_msg}[/yellow]")


def _record_fail_telemetry(task_id, error_context):
    """Record FAIL telemetry (fire-and-forget)."""
    try:
        from ..telemetry.schema import Outcome as _O
        _collect_task_telemetry(
            task_id, find_paircoder_dir(),
            outcome=_O.FAIL,
            error_context=error_context,
        )
    except Exception as e:
        logger.debug("Failed to record FAIL telemetry for %s: %s", task_id, e)


def _post_start_actions(paircoder_dir, task_id, task_obj, card_name):
    """Run hooks, plan update, and handoff after task start (fire-and-forget)."""
    update_plan_status_if_needed(task_id)

    try:
        from ..planning.status_hooks import run_status_hooks
        run_status_hooks(paircoder_dir, task_id, "in_progress", task_obj)
    except Exception as e:
        logger.debug("Status hooks failed for %s: %s", task_id, e)

    try:
        create_start_handoff(
            task_id=task_id,
            task_title=task_obj.title if task_obj else card_name,
            task_description=task_obj.description if task_obj else "",
            acceptance_criteria=task_obj.acceptance_criteria if task_obj else [],
            paircoder_dir=paircoder_dir,
        )
    except Exception as e:
        logger.debug("Start handoff failed for %s: %s", task_id, e)
