"""Label and board template operations for Trello.

Extracted from client.py for modular architecture.
"""

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class LabelMixin:
    """Mixin providing label operations on Trello boards/cards."""

    # These attributes are provided by TrelloService
    client: Any
    board: Any

    def get_labels(self) -> List[Dict[str, str]]:
        """Get all labels on the current board."""
        if not self.board:
            raise ValueError("Board not set. Call set_board() first.")

        labels = self.board.get_labels()
        return [
            {'id': lbl.id, 'name': lbl.name, 'color': lbl.color}
            for lbl in labels
        ]

    def get_label_by_name(self, name: str) -> Optional[Dict[str, str]]:
        """Find a label by name (case-insensitive)."""
        labels = self.get_labels()
        name_lower = name.lower()

        for label in labels:
            if label['name'] and label['name'].lower() == name_lower:
                return label

        return None

    def create_label(self, name: str, color: str) -> Optional[Dict[str, str]]:
        """Create a label on the board."""
        if not self.board:
            raise ValueError("Board not set. Call set_board() first.")

        try:
            label = self.board.add_label(name=name, color=color)
            return {'id': label.id, 'name': label.name, 'color': label.color}
        except Exception as e:
            logger.error(f"Failed to create label: {e}")
            return None

    def ensure_label_exists(self, name: str, color: str) -> Optional[Dict[str, str]]:
        """Ensure a label exists, creating it if necessary."""
        existing = self.get_label_by_name(name)
        if existing:
            return existing
        return self.create_label(name, color)

    def add_label_to_card(self, card: Any, label_name: str) -> bool:
        """Add a label to a card by name."""
        label = self.get_label_by_name(label_name)
        if not label:
            logger.warning(f"Label '{label_name}' not found")
            return False

        try:
            card.client.fetch_json(
                f'/cards/{card.id}/idLabels',
                http_method='POST',
                post_args={'value': label['id']}
            )
            return True
        except Exception as e:
            logger.error(f"Failed to add label: {e}")
            return False


class BoardTemplateMixin:
    """Mixin providing board template operations."""

    # These attributes are provided by TrelloService
    client: Any
    board: Any

    def find_board_by_name(self, name: str) -> Optional[Any]:
        """Find a board by name (case-insensitive)."""
        boards = self.list_boards()  # type: ignore[attr-defined]
        name_lower = name.lower()

        for board in boards:
            if board.name.lower() == name_lower and not board.closed:
                return board

        return None

    def copy_board_from_template(
        self,
        template_name: str,
        new_board_name: str,
        keep_cards: bool = False
    ) -> Optional[Any]:
        """Create a new board by copying from a template board."""
        template = self.find_board_by_name(template_name)
        if not template:
            raise ValueError(f"Template board '{template_name}' not found")

        try:
            keep_from_source = "customFields,labels"
            if keep_cards:
                keep_from_source = "cards,checklists,customFields,labels"

            result = self.client.fetch_json(
                '/boards',
                http_method='POST',
                post_args={
                    'name': new_board_name,
                    'idBoardSource': template.id,
                    'keepFromSource': keep_from_source,
                    'prefs_permissionLevel': 'private',
                }
            )

            new_board = self.client.get_board(result['id'])
            logger.info(f"Created board '{new_board_name}' from template '{template_name}'")
            return new_board

        except Exception as e:
            logger.error(f"Failed to copy board from template: {e}")
            return None

    def get_board_info(self, board: Any) -> Dict[str, Any]:
        """Get detailed information about a board."""
        try:
            self.set_board(board.id)  # type: ignore[attr-defined]
            structure = self.get_board_structure()  # type: ignore[attr-defined]

            return {
                'id': board.id,
                'name': board.name,
                'url': board.url,
                'lists': list(structure['lists'].keys()),
                'custom_fields': list(structure['custom_fields'].keys()),
                'labels': list(structure['labels'].keys()),
                'list_count': len(structure['lists']),
                'custom_field_count': len(structure['custom_fields']),
                'label_count': len(structure['labels']),
            }
        except Exception as e:
            logger.error(f"Failed to get board info: {e}")
            return {
                'id': board.id,
                'name': board.name,
                'url': board.url,
                'error': str(e),
            }
