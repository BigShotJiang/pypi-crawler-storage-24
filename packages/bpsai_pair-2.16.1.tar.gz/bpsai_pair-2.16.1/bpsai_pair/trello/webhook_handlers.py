"""Trello webhook callback handler factories.

Contains functions that create callbacks for handling card move events:
task status updates, agent assignment, and combined handlers.
"""

import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from .webhook_auth import CardMoveEvent
from .webhook_config import READY_LISTS, get_status_for_list

logger = logging.getLogger(__name__)


def create_task_updater(paircoder_dir: Path) -> Callable[[CardMoveEvent], None]:
    """Create a callback that updates task status based on card moves.

    Args:
        paircoder_dir: Path to .paircoder directory

    Returns:
        Callback function for card move events
    """
    from ..planning.parser import TaskParser

    def update_task(event: CardMoveEvent) -> None:
        """Update local task status based on card move."""
        task_id = event.task_id
        if not task_id:
            logger.warning(f"Could not extract task ID from card: {event.card_name}")
            return

        new_status = get_status_for_list(event.list_after)
        if not new_status:
            logger.info(f"No status mapping for list: {event.list_after}")
            return

        try:
            parser = TaskParser(paircoder_dir / "tasks")
            task = parser.get_task_by_id(task_id)

            if not task:
                logger.warning(f"Task not found: {task_id}")
                return

            old_status = task.status.value if hasattr(task.status, 'value') else str(task.status)

            if old_status == new_status:
                logger.debug(f"Task {task_id} already has status: {new_status}")
                return

            from ..planning.models import TaskStatus
            task.status = TaskStatus(new_status)
            parser.save(task)

            logger.info(f"Updated {task_id}: {old_status} -> {new_status}")

        except Exception as e:
            logger.error(f"Error updating task {task_id}: {e}")

    return update_task


def _is_ready_list(list_name: str) -> bool:
    """Check if list matches ready patterns with flexible matching."""
    normalized = re.sub(r'\s*/\s*', '/', list_name).strip()
    for ready in READY_LISTS:
        ready_normalized = re.sub(r'\s*/\s*', '/', ready).strip()
        if normalized == ready_normalized:
            return True
    return "ready" in list_name.lower()


def _add_assignment_comment(
    api_key: str, token: str, card_id: str, agent_name: str
) -> None:
    """Add agent assignment comment to a Trello card."""
    import requests

    comment = f"🤖 Agent '{agent_name}' assigned at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    comment_url = f"https://api.trello.com/1/cards/{card_id}/actions/comments"
    try:
        response = requests.post(
            comment_url,
            params={"key": api_key, "token": token, "text": comment}
        )
        if response.status_code == 200:
            logger.info(f"Added assignment comment to card {card_id}")
        else:
            logger.warning(f"Failed to add comment: {response.status_code}")
    except Exception as e:
        logger.error(f"Error adding comment: {e}")


def _manage_agent_label(
    api_key: str, token: str, board_id: str, card_id: str, agent_name: str
) -> None:
    """Find or create agent label and add it to card."""
    import requests

    try:
        board_url = f"https://api.trello.com/1/boards/{board_id}/labels"
        response = requests.get(
            board_url,
            params={"key": api_key, "token": token}
        )
        labels = response.json() if response.status_code == 200 else []

        agent_label_name = f"Agent: {agent_name}"
        agent_label = next(
            (l for l in labels if l.get("name") == agent_label_name), None
        )

        if not agent_label:
            create_url = f"https://api.trello.com/1/boards/{board_id}/labels"
            response = requests.post(
                create_url,
                params={
                    "key": api_key, "token": token,
                    "name": agent_label_name, "color": "purple"
                }
            )
            if response.status_code == 200:
                agent_label = response.json()
                logger.info(f"Created agent label: {agent_label_name}")

        if agent_label:
            add_url = f"https://api.trello.com/1/cards/{card_id}/idLabels"
            response = requests.post(
                add_url,
                params={"key": api_key, "token": token, "value": agent_label["id"]}
            )
            if response.status_code == 200:
                logger.info(f"Added agent label to card {card_id}")

    except Exception as e:
        logger.error(f"Error managing labels: {e}")


def _update_local_task_status(paircoder_dir: Path, task_id: str) -> None:
    """Update a local task to in_progress status."""
    from ..planning.parser import TaskParser
    from ..planning.models import TaskStatus

    parser = TaskParser(paircoder_dir / "tasks")
    task = parser.get_task_by_id(task_id)
    if task:
        task.status = TaskStatus.IN_PROGRESS
        parser.save(task)
        logger.info(f"Updated local task {task_id} to in_progress")


def _auto_start_card(
    api_key: str,
    token: str,
    event: CardMoveEvent,
    paircoder_dir: Optional[Path],
    task_id: Optional[str],
) -> None:
    """Move card to In Progress and update local task status."""
    import requests

    try:
        lists_url = f"https://api.trello.com/1/boards/{event.board_id}/lists"
        response = requests.get(
            lists_url,
            params={"key": api_key, "token": token}
        )
        if response.status_code != 200:
            return

        lists = response.json()
        in_progress_list = next(
            (lst for lst in lists if lst.get("name") == "In Progress"), None
        )
        if not in_progress_list:
            return

        move_url = f"https://api.trello.com/1/cards/{event.card_id}"
        response = requests.put(
            move_url,
            params={
                "key": api_key, "token": token,
                "idList": in_progress_list["id"]
            }
        )
        if response.status_code == 200:
            logger.info("Moved card to In Progress")
            if paircoder_dir and task_id:
                _update_local_task_status(paircoder_dir, task_id)

    except Exception as e:
        logger.error(f"Error auto-starting task: {e}")


def create_agent_assigner(
    api_key: str,
    token: str,
    agent_name: str = "claude",
    auto_start: bool = True,
    paircoder_dir: Optional[Path] = None,
) -> Callable[[CardMoveEvent], None]:
    """Create a callback that assigns agents when cards move to Ready.

    Args:
        api_key: Trello API key
        token: Trello API token
        agent_name: Name of the agent (default: "claude")
        auto_start: If True, automatically move card to In Progress
        paircoder_dir: Path to .paircoder directory (for task updates)

    Returns:
        Callback function for card move events
    """
    def assign_agent(event: CardMoveEvent) -> None:
        """Assign agent to card when it moves to Ready."""
        if not _is_ready_list(event.list_after):
            return

        task_id = event.task_id
        logger.info(f"Agent assignment triggered for {task_id or event.card_name}")

        _add_assignment_comment(api_key, token, event.card_id, agent_name)
        _manage_agent_label(api_key, token, event.board_id, event.card_id, agent_name)

        if auto_start:
            _auto_start_card(api_key, token, event, paircoder_dir, task_id)

    return assign_agent


def create_combined_handler(
    paircoder_dir: Path,
    api_key: Optional[str] = None,
    token: Optional[str] = None,
    agent_name: str = "claude",
    auto_assign: bool = True,
) -> Callable[[CardMoveEvent], None]:
    """Create a combined handler for status updates and agent assignment.

    Args:
        paircoder_dir: Path to .paircoder directory
        api_key: Trello API key (required for agent assignment)
        token: Trello API token (required for agent assignment)
        agent_name: Name of the agent
        auto_assign: Enable automatic agent assignment

    Returns:
        Combined callback function
    """
    status_updater = create_task_updater(paircoder_dir)

    agent_assigner = None
    if auto_assign and api_key and token:
        agent_assigner = create_agent_assigner(
            api_key=api_key,
            token=token,
            agent_name=agent_name,
            auto_start=True,
            paircoder_dir=paircoder_dir,
        )

    def combined_handler(event: CardMoveEvent) -> None:
        """Handle card move with both status update and agent assignment."""
        status_updater(event)
        if agent_assigner:
            agent_assigner(event)

    return combined_handler
