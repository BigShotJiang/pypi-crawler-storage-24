"""PM routing helper for task lifecycle commands."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from ..pm.registry import get_active_provider

if TYPE_CHECKING:
    from ..pm.lifecycle import PMLifecycleManager

logger = logging.getLogger(__name__)


def get_pm_lifecycle(
    config: dict, target_status: str,
) -> tuple[Optional[PMLifecycleManager], Optional[str]]:
    """Try to build a PMLifecycleManager from config.

    Returns (lifecycle, destination_name) when a PM provider is active,
    or (None, None) when the provider is "none" or unavailable.
    """
    try:
        provider = get_active_provider(config or {})
        if provider.name == "none":
            return None, None
        from ..pm.compat import load_pm_config
        from ..pm.lifecycle import PMLifecycleManager
        from ..pm.workflow import WorkflowEngine
        _, wf_config = load_pm_config(config or {})
        engine = WorkflowEngine(wf_config)
        destination = engine.get_destination_for_status(target_status)
        lifecycle = PMLifecycleManager(provider, engine)
        return lifecycle, destination
    except (KeyError, FileNotFoundError, ImportError, ValueError) as e:
        logger.warning("PM lifecycle unavailable: %s", e)
        return None, None
