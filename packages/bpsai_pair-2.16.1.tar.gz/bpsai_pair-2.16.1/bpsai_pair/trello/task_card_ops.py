"""Trello card utility operations.

Board client init, card formatting, activity logging, AC helpers.
"""
import logging
import re
from typing import Optional, Tuple, List, Dict, Any

import typer
import yaml
from rich.console import Console

logger = logging.getLogger(__name__)
console = Console()

AGENT_TYPE = "claude"  # Identifies this agent in comments


def get_board_client(board_id: Optional[str] = None) -> Tuple["TrelloService", Dict[str, Any]]:
    """Get client with board already set."""
    from . import task_helpers as _h  # lazy for mock compat
    creds = _h.load_token()
    if not creds:
        console.print("[red]Not connected to Trello. Run: bpsai-pair trello connect[/red]")
        raise typer.Exit(1)

    config: Dict[str, Any] = {}
    try:
        from ..core.ops import find_project_root
        config_file = find_project_root() / ".paircoder" / "config.yaml"
        if config_file.exists():
            with open(config_file, encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
    except Exception:
        pass

    if board_id is None:
        board_id = config.get("trello", {}).get("board_id")

    if not board_id:
        console.print("[red]No board configured. Run: bpsai-pair trello use-board <id>[/red]")
        raise typer.Exit(1)

    try:
        client = _h.TrelloService(api_key=creds["api_key"], token=creds["token"])
        client.set_board(board_id)
    except ImportError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    return client, config


def format_card_id(card: Any) -> str:
    """Format card ID for display (e.g., 'TRELLO-123')."""
    return f"TRELLO-{card.short_id}"


def log_activity(card: Any, action: str, summary: str) -> None:
    """Add activity comment to card."""
    comment = f"[{AGENT_TYPE}] {action}: {summary}"
    try:
        card.comment(comment)
    except Exception as e:
        console.print(f"[yellow]Warning: Could not add comment: {e}[/yellow]")


def get_unchecked_ac_items(card: Any, checklist_name: str = "Acceptance Criteria") -> List[Dict[str, Any]]:
    """Get all unchecked items in the Acceptance Criteria checklist."""
    if not card.checklists:
        return []

    unchecked = []
    for checklist in card.checklists:
        if checklist.name.lower() != checklist_name.lower():
            continue
        for item in checklist.items:
            if not item.get("checked"):
                unchecked.append(item)

    return unchecked


def log_bypass(command: str, task_id: str, reason: str = "forced") -> None:
    """Log bypass to audit file - delegates to core module."""
    from ..core.bypass_log import log_bypass as core_log_bypass
    core_log_bypass(command=command, target=task_id, reason=reason)


def get_task_id_from_card(card: Any) -> Optional[str]:
    """Extract local task ID from Trello card.

    Uses permissive matching for bracketed IDs (any ``[ID]`` format)
    and the legacy restrictive pattern for unbracketed names and
    descriptions to avoid false positives on plain English words.
    """
    name = card.name if hasattr(card, 'name') else ""
    if not isinstance(name, str):
        name = ""

    from ..core.constants import TASK_ID_PATTERN, TASK_ID_PATTERN_LEGACY
    permissive = TASK_ID_PATTERN[1:-1]  # Strip outer parens
    legacy = TASK_ID_PATTERN_LEGACY[1:-1]

    if name:
        # Priority 1: bracketed [ID] — permissive (any valid ID)
        match = re.search(rf'\[({permissive})]', name)
        if match:
            return match.group(1)

        # Priority 2: unbracketed at start — legacy (avoid false positives)
        match = re.match(rf'^({legacy})[\s:\-]', name, re.IGNORECASE)
        if match:
            return match.group(1)

    desc = card.description if hasattr(card, 'description') else ""
    if desc and isinstance(desc, str):
        # Priority 3: description "Task: ID" — legacy pattern
        match = re.search(rf'Task:\s*({legacy})', desc, re.IGNORECASE)
        if match:
            return match.group(1)

    return None


def auto_check_acceptance_criteria(
    card: Any, client: Any, checklist_name: str = "Acceptance Criteria",
) -> int:
    """Check off all items in the Acceptance Criteria checklist."""
    import requests

    if not card.checklists:
        return 0

    checked_count = 0

    for checklist in card.checklists:
        if checklist.name.lower() != checklist_name.lower():
            continue

        for item in checklist.items:
            if item.get("checked"):
                continue

            item_name = item.get("name", "")

            try:
                checklist.set_checklist_item(item_name, checked=True)
                checked_count += 1
            except AttributeError:
                try:
                    from . import task_helpers as _h  # lazy for mock compat
                    creds = _h.load_token()
                    check_item_id = item.get("id")
                    url = f"https://api.trello.com/1/cards/{card.id}/checkItem/{check_item_id}"

                    response = requests.put(
                        url,
                        params={
                            "key": creds["api_key"],
                            "token": creds["token"],
                            "state": "complete"
                        }
                    )

                    if response.status_code == 200:
                        checked_count += 1
                except Exception:
                    pass

    return checked_count
