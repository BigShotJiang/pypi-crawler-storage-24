"""Task completion pipeline.

Hooks, telemetry, AC sync, and state machine transitions for task completion.
"""
import logging
from typing import Any

from rich.console import Console

logger = logging.getLogger(__name__)
console = Console()


def run_completion_hooks(
    task_id: str, outcome=None, error_context: str | None = None,
) -> bool:
    """Run completion hooks to update state.md and other side effects."""
    try:
        from ..core.ops import find_paircoder_dir
        paircoder_dir = find_paircoder_dir()
        if not paircoder_dir.exists():
            return False

        try:
            from ..planning.cli_update_cache import get_cli_update_cache
            get_cli_update_cache(paircoder_dir).record_update(task_id, "done")
        except Exception:
            pass  # Best effort

        telemetry_record = _collect_task_telemetry(
            task_id, paircoder_dir, outcome=outcome, error_context=error_context,
        )
        return _fire_hooks(task_id, paircoder_dir, telemetry_record)
    except Exception:
        return False


def _fire_hooks(task_id: str, paircoder_dir, telemetry_record) -> bool:
    """Fire on_task_complete hooks with telemetry context."""
    try:
        from ..core.hooks import HookRunner, HookContext, load_config
        from ..planning.parser import TaskParser

        config = load_config(paircoder_dir)
        hook_runner = HookRunner(config, paircoder_dir)

        task = None
        try:
            task = TaskParser(paircoder_dir / "tasks").get_task_by_id(task_id)
        except Exception:
            pass

        extra: dict[str, Any] = {}
        if telemetry_record is not None:
            extra["telemetry_record"] = telemetry_record
        context = HookContext(
            task_id=task_id, task=task, event="on_task_complete", extra=extra,
        )
        hook_runner.run_hooks("on_task_complete", context)
        return True
    except ImportError:
        return False
    except Exception as e:
        console.print(f"[yellow]⚠ Could not run completion hooks: {e}[/yellow]")
        return False


def _task_exists(task_id: str, paircoder_dir) -> bool:
    """Check whether a task ID corresponds to a real task file.

    Returns False if the task cannot be found by the parser,
    preventing phantom telemetry records for non-existent tasks.
    """
    try:
        from ..planning.parser import TaskParser
        task = TaskParser(paircoder_dir / "tasks").get_task_by_id(task_id)
        return task is not None
    except Exception:
        return False


def _get_estimation_fields(task_id: str, paircoder_dir) -> dict:
    """Extract estimation metadata from task file and time cache."""
    fields = {"task_type": "unknown", "estimated_tokens": None,
              "estimated_hours": None, "actual_hours": None,
              "estimated_complexity": None,
              "sprint": None, "complexity": None}
    try:
        from ..planning.parser import TaskParser
        task = TaskParser(paircoder_dir / "tasks").get_task_by_id(task_id)
        if task:
            fields["task_type"] = task.type or "unknown"
            fields["estimated_tokens"] = task.estimated_tokens.total_tokens
            fields["estimated_complexity"] = task.complexity
            fields["estimated_hours"] = task.estimated_hours.expected_hours
            fields["sprint"] = task.sprint
            fields["complexity"] = task.complexity
    except Exception:
        pass
    try:
        from ..integrations.time_tracking import LocalTimeCache
        cache_path = paircoder_dir / "time-tracking-cache.json"
        if cache_path.exists():
            hrs = LocalTimeCache(cache_path).get_total(task_id).total_seconds() / 3600
            if hrs > 0:
                fields["actual_hours"] = hrs
    except Exception:
        pass
    return fields


def _collect_task_telemetry(
    task_id: str,
    paircoder_dir,
    outcome=None,
    error_context: str | None = None,
) -> dict | None:
    """Collect telemetry for a completed task (non-blocking).

    Returns None without recording if the task does not exist,
    preventing phantom telemetry entries (e.g., TASK-001).
    """
    try:
        if not _task_exists(task_id, paircoder_dir):
            logger.debug("Skipping telemetry for non-existent task %s", task_id)
            return None

        from ..telemetry.collector import TelemetryCollector
        from ..telemetry.schema import Outcome

        if outcome is None:
            outcome = Outcome.SUCCESS

        fields = _get_estimation_fields(task_id, paircoder_dir)
        project_root = paircoder_dir.parent
        collector = TelemetryCollector(project_root)
        result = collector.collect_for_task(
            task_id, fields["task_type"], outcome,
            estimated_tokens=fields["estimated_tokens"],
            error_context=error_context,
            estimated_hours=fields["estimated_hours"],
            actual_hours=fields["actual_hours"],
            estimated_complexity=fields["estimated_complexity"],
            sprint=fields["sprint"],
            complexity=fields["complexity"],
        )

        if result:
            logger.debug("Telemetry collected for task %s", task_id)
            return result.to_dict()
        return None
    except Exception as e:
        logger.debug("Telemetry collection skipped: %s", e)
        return None


def sync_local_ac_for_completion(task_id: str, is_trello: bool = True) -> tuple[bool, str]:
    """Sync local AC items and verify state machine transition for completion."""
    try:
        from ..core.task_state import (
            TaskState,
            get_state_manager,
            is_state_machine_enabled,
            verify_local_ac,
            sync_trello_ac_to_local,
        )

        # For Trello path: auto-check all local AC items
        if is_trello:
            sync_result = sync_trello_ac_to_local(task_id)
            if sync_result.get("error"):
                return False, f"Failed to sync local AC: {sync_result['error']}"
            if sync_result.get("checked_count", 0) > 0:
                console.print(f"[green]✓ Synced {sync_result['checked_count']} local AC item(s)[/green]")

        # Verify all local AC items are checked
        ac_result = verify_local_ac(task_id)
        if ac_result.get("error"):
            return False, f"AC verification error: {ac_result['error']}"

        if not ac_result["verified"]:
            unchecked = ac_result["unchecked_items"]
            unchecked_list = "\n".join(f"  ○ {item}" for item in unchecked[:5])
            if len(unchecked) > 5:
                unchecked_list += f"\n  ... and {len(unchecked) - 5} more"
            return False, (
                f"{len(unchecked)} local AC item(s) unchecked:\n{unchecked_list}\n"
                f"Check items: bpsai-pair task check {task_id}"
            )

        # Transition state machine if enabled
        if is_state_machine_enabled():
            manager = get_state_manager()
            current = manager.get_state(task_id)

            if is_trello and current == TaskState.AC_VERIFIED:
                manager.transition(task_id, TaskState.LOCAL_AC_VERIFIED, trigger="sync_local_ac")
            elif current == TaskState.IN_PROGRESS:
                manager.transition(task_id, TaskState.LOCAL_AC_VERIFIED, trigger="verify_local_ac")
            elif current == TaskState.LOCAL_AC_VERIFIED:
                pass  # Already in correct state

        return True, "Local AC verified"

    except Exception as e:
        return False, f"Error syncing local AC: {e}"


def complete_task_with_state_machine(task_id: str, trigger: str = "completion") -> tuple[bool, str]:
    """Transition task to COMPLETED state via state machine (if enabled)."""
    try:
        from ..core.task_state import (
            TaskState,
            get_state_manager,
            is_state_machine_enabled,
        )

        if not is_state_machine_enabled():
            return True, "State machine not enabled"

        manager = get_state_manager()
        current = manager.get_state(task_id)

        if current != TaskState.LOCAL_AC_VERIFIED:
            allowed, reason = manager.can_transition(task_id, TaskState.COMPLETED)
            if not allowed:
                return False, reason

        manager.transition(task_id, TaskState.COMPLETED, trigger=trigger)
        return True, "Task completed"

    except Exception as e:
        return False, f"Error completing task: {e}"
