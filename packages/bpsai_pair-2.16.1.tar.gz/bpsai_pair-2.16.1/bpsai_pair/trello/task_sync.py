"""Local task synchronization and budget checking.

Syncing Trello card status to local task files, plan status updates, and budget enforcement.
"""
from typing import Optional, Tuple

from rich.console import Console

console = Console()


def update_local_task_status(card, status: str, summary: str = "") -> Tuple[bool, Optional[str]]:
    """Update the corresponding local task file after ttask operation."""
    try:
        from .task_card_ops import get_task_id_from_card

        task_id = get_task_id_from_card(card)
        if not task_id:
            return False, None

        from ..core.ops import find_paircoder_dir
        paircoder_dir = find_paircoder_dir()
        if not paircoder_dir.exists():
            return False, task_id

        from ..planning.parser import TaskParser

        task_parser = TaskParser(paircoder_dir / "tasks")
        task = task_parser.get_task_by_id(task_id)
        if not task:
            raise FileNotFoundError(f"Task file not found for {task_id}")

        success = task_parser.update_status(task_id, status)
        return success, task_id
    except FileNotFoundError:
        raise  # Re-raise for caller to handle
    except Exception as e:
        console.print(f"[yellow]⚠ Could not update local task file: {e}[/yellow]")
        return False, None


def update_plan_status_if_needed(task_id: str) -> bool:
    """Update plan status based on task status change."""
    try:
        from ..core.ops import find_paircoder_dir
        from ..planning.parser import TaskParser, PlanParser

        paircoder_dir = find_paircoder_dir()
        if not paircoder_dir.exists():
            return False

        task_parser = TaskParser(paircoder_dir / "tasks")
        task = task_parser.get_task_by_id(task_id)
        if not task or not task.plan_id:
            return False

        plan_parser = PlanParser(paircoder_dir / "plans")
        plan_updated = plan_parser.check_and_update_plan_status(
            task.plan_id, paircoder_dir / "tasks"
        )

        if plan_updated:
            plan = plan_parser.get_plan_by_id(task.plan_id)
            if plan:
                console.print(f"  → Plan {plan.id} is now {plan.status.value}")

        return plan_updated
    except Exception as e:
        console.print(f"[yellow]⚠ Could not update plan status: {e}[/yellow]")
        return False


def check_task_budget(task_id: str, card_id: str, budget_override: bool = False) -> bool:
    """Check if task can proceed within token budget."""
    try:
        from ..core.ops import find_paircoder_dir
        from ..planning.parser import TaskParser
        from ..metrics.estimation import TokenEstimator
        from ..metrics.budget import BudgetEnforcer
        from ..metrics.collector import MetricsCollector

        paircoder_dir = find_paircoder_dir()
        if not paircoder_dir.exists():
            return True

        task = TaskParser(paircoder_dir / "tasks").get_task_by_id(task_id)
        if not task:
            return True

        estimated_tokens = TokenEstimator(
            project_root=paircoder_dir.parent
        ).estimate_for_task(task).total_tokens
        estimated_cost_usd = (estimated_tokens / 1000) * 0.015

        budget = BudgetEnforcer(MetricsCollector(paircoder_dir / "history"))
        can_proceed, reason = budget.can_proceed(estimated_cost_usd)

        if not can_proceed:
            if budget_override:
                from . import task_helpers as _h  # lazy for mock compat
                _h.log_bypass("budget_override", task_id, f"User override: {reason}")
                console.print(f"[yellow]⚠ Starting despite budget limit (logged): {reason}[/yellow]")
                return True
            _display_budget_blocked(estimated_tokens, estimated_cost_usd, budget, card_id)
            return False

        console.print(f"[dim]Budget check passed ({estimated_tokens:,} tokens, ~${estimated_cost_usd:.2f})[/dim]")
        return True
    except (ImportError, Exception) as e:
        console.print(f"[dim]Budget check skipped: {e}[/dim]")
        return True


def _display_budget_blocked(estimated_tokens: int, cost: float, budget, card_id: str) -> None:
    """Display budget blocked message with options."""
    status = budget.check_budget()
    console.print("[red]❌ BLOCKED: Task would exceed token budget[/red]")
    console.print("")
    console.print(f"[dim]Estimated tokens:[/dim] {estimated_tokens:,}")
    console.print(f"[dim]Estimated cost:[/dim]   ${cost:.2f}")
    console.print(f"[dim]Daily remaining:[/dim]  ${status.daily_remaining:.2f}")
    console.print(f"[dim]Daily limit:[/dim]      ${status.daily_limit:.2f}")
    console.print("")
    console.print("[yellow]Options:[/yellow]")
    console.print("  1. Wait until tomorrow (limit resets)")
    console.print(f"  2. Override: [cyan]bpsai-pair ttask start {card_id} --budget-override[/cyan]")
    console.print("  3. Check budget: [cyan]bpsai-pair budget status[/cyan]")
