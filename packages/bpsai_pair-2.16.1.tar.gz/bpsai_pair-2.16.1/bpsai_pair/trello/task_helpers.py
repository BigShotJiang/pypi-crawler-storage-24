"""Shared helpers for Trello task commands — re-export shim.

Card ops: task_card_ops.py
Completion pipeline: task_completion.py
Local sync + budget: task_sync.py
"""
from .auth import load_token  # noqa: F401 — re-exported for mock compat
from .client import TrelloService  # noqa: F401 — re-exported for mock compat

from .task_card_ops import (  # noqa: F401
    AGENT_TYPE,
    auto_check_acceptance_criteria,
    console,
    format_card_id,
    get_board_client,
    get_task_id_from_card,
    get_unchecked_ac_items,
    log_activity,
    log_bypass,
)
from .task_completion import (  # noqa: F401
    _collect_task_telemetry,
    _get_estimation_fields,
    complete_task_with_state_machine,
    run_completion_hooks,
    sync_local_ac_for_completion,
)
from .task_sync import (  # noqa: F401
    check_task_budget,
    update_local_task_status,
    update_plan_status_if_needed,
)

__all__ = [
    "AGENT_TYPE",
    "TrelloService",
    "auto_check_acceptance_criteria",
    "check_task_budget",
    "complete_task_with_state_machine",
    "console",
    "format_card_id",
    "get_board_client",
    "get_task_id_from_card",
    "get_unchecked_ac_items",
    "load_token",
    "log_activity",
    "log_bypass",
    "run_completion_hooks",
    "sync_local_ac_for_completion",
    "update_local_task_status",
    "update_plan_status_if_needed",
    "_collect_task_telemetry",
    "_get_estimation_fields",
]
