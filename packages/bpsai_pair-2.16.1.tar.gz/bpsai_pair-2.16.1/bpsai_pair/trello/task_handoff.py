"""Handoff integration for task lifecycle transitions.

Wires the handoff protocol (orchestration/handoff.py) into the
ttask start/done lifecycle so role transitions produce traceable
context packages.

Functions:
    create_start_handoff: Navigator→Driver handoff on task start
    create_completion_handoff: Driver→Reviewer handoff on task done
    get_modified_files: Git helper for changed file list
"""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Optional

from ..orchestration.handoff import prepare_handoff

logger = logging.getLogger(__name__)


def get_modified_files(project_root: Path) -> list[str]:
    """Get files modified since last commit (for handoff context).

    Args:
        project_root: Project root directory.

    Returns:
        List of relative file paths changed since HEAD~1.
    """
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD~1"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            return [f for f in result.stdout.strip().split("\n") if f]
    except (OSError, subprocess.TimeoutExpired):
        pass
    return []


def create_start_handoff(
    *,
    task_id: str,
    task_title: str,
    task_description: str = "",
    acceptance_criteria: Optional[list[str]] = None,
    paircoder_dir: Path,
) -> Optional[str]:
    """Create a navigator→driver handoff when a task starts.

    Fire-and-forget: returns None on any failure without blocking
    the task start flow.

    Args:
        task_id: Local task ID (e.g. "T35.2.1").
        task_title: Task title for context.
        task_description: Full task description.
        acceptance_criteria: List of AC strings.
        paircoder_dir: Path to .paircoder directory.

    Returns:
        Handoff ID string, or None if creation failed.
    """
    try:
        package = prepare_handoff(
            task_id=task_id,
            source_agent="navigator",
            target_agent="driver",
            task_description=task_description or task_title,
            acceptance_criteria=acceptance_criteria,
            files_touched=[],
            current_state="Task starting",
            work_completed="",
            remaining_work=task_description or task_title,
            working_dir=paircoder_dir.parent,
            save=True,
            handoffs_dir=paircoder_dir / "history" / "handoffs",
        )
        logger.info("Created start handoff %s for %s", package.handoff_id, task_id)
        return package.handoff_id
    except Exception as e:
        logger.warning("Failed to create start handoff for %s: %s", task_id, e)
        return None


def create_completion_handoff(
    *,
    task_id: str,
    task_title: str,
    summary: str = "",
    acceptance_criteria: Optional[list[str]] = None,
    paircoder_dir: Path,
) -> Optional[str]:
    """Create a driver→reviewer handoff when a task completes.

    Fire-and-forget: returns None on any failure without blocking
    the task completion flow.

    Args:
        task_id: Local task ID.
        task_title: Task title for context.
        summary: Completion summary from user.
        acceptance_criteria: List of AC strings for reviewer context.
        paircoder_dir: Path to .paircoder directory.

    Returns:
        Handoff ID string, or None if creation failed.
    """
    try:
        project_root = paircoder_dir.parent
        files = get_modified_files(project_root)
        package = prepare_handoff(
            task_id=task_id,
            source_agent="driver",
            target_agent="reviewer",
            task_description=task_title,
            acceptance_criteria=acceptance_criteria,
            files_touched=files,
            current_state="Task completed, ready for review",
            work_completed=summary or "Task completed",
            remaining_work="Code review",
            working_dir=project_root,
            save=True,
            handoffs_dir=paircoder_dir / "history" / "handoffs",
        )
        logger.info("Created completion handoff %s for %s", package.handoff_id, task_id)
        return package.handoff_id
    except Exception as e:
        logger.warning("Failed to create completion handoff for %s: %s", task_id, e)
        return None
