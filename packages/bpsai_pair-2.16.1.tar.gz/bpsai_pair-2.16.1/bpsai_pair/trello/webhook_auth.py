"""Trello webhook authentication and event models.

Contains signature verification and the CardMoveEvent dataclass.
"""

import base64
import hashlib
import hmac
import logging
import os
from dataclasses import dataclass
from typing import Optional

from ..core.constants import extract_task_id_from_card_name

logger = logging.getLogger(__name__)


def verify_trello_signature(
    request_body: bytes,
    signature: Optional[str],
    callback_url: str
) -> bool:
    """Verify Trello webhook signature.

    Trello creates signature by:
    1. Concatenating request body + callback URL
    2. Creating HMAC-SHA1 with API secret as key
    3. Base64 encoding the result

    Args:
        request_body: Raw request body bytes
        signature: X-Trello-Webhook header value
        callback_url: The registered webhook callback URL

    Returns:
        True if signature is valid, False otherwise.
        Returns True if TRELLO_API_SECRET is not set (graceful degradation for dev).
    """
    api_secret = os.environ.get("TRELLO_API_SECRET")

    if not api_secret:
        logger.warning(
            "TRELLO_API_SECRET not set, skipping signature verification. "
            "Set this environment variable in production for security."
        )
        return True  # Graceful degradation in dev

    if not signature:
        logger.warning("Missing X-Trello-Webhook signature header")
        return False

    try:
        content = request_body + callback_url.encode()
        expected = base64.b64encode(
            hmac.new(
                api_secret.encode(),
                content,
                hashlib.sha1
            ).digest()
        ).decode()

        # Use constant-time comparison to prevent timing attacks
        return hmac.compare_digest(signature, expected)
    except Exception as e:
        logger.error(f"Error verifying Trello signature: {e}")
        return False


@dataclass
class CardMoveEvent:
    """Represents a card move event from Trello."""
    card_id: str
    card_name: str
    list_before: str
    list_after: str
    board_id: str

    @property
    def task_id(self) -> Optional[str]:
        """Extract task ID from card name like '[TASK-066] Title' or '[T18.1] Title'."""
        return extract_task_id_from_card_name(self.card_name)
