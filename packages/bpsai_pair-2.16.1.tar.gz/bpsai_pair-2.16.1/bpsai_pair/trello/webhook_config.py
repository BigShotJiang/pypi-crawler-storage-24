"""Trello webhook configuration and list-to-status mapping.

Contains list status mappings and flexible matching logic.
"""

import re
from typing import Optional


# Default list-to-status mappings (fallback if board fetch fails)
# Uses flexible matching via get_status_for_list() function
DEFAULT_LIST_STATUS_MAP = {
    # Include both spaced and non-spaced variants for robustness
    "Intake/Backlog": "pending",
    "Intake / Backlog": "pending",
    "Planned/Ready": "pending",
    "Planned / Ready": "pending",
    "Backlog": "pending",
    "In Progress": "in_progress",
    "Review/Testing": "review",
    "Review / Testing": "review",
    "Deployed/Done": "done",
    "Deployed / Done": "done",
    "Done": "done",
    "Issues/Tech Debt": "blocked",
    "Issues / Tech Debt": "blocked",
    "Blocked": "blocked",
}


def get_status_for_list(list_name: str, list_status_map: dict = None) -> Optional[str]:
    """Get status for a list name with flexible matching.

    Args:
        list_name: Trello list name
        list_status_map: Optional custom mapping (uses DEFAULT if not provided)

    Returns:
        Status string or None if no match
    """
    if list_status_map is None:
        list_status_map = DEFAULT_LIST_STATUS_MAP

    # Try exact match first
    if list_name in list_status_map:
        return list_status_map[list_name]

    # Try normalized match (remove spaces around slashes)
    normalized = re.sub(r'\s*/\s*', '/', list_name).strip()
    if normalized in list_status_map:
        return list_status_map[normalized]

    # Try pattern matching on keywords
    list_lower = list_name.lower()
    if "done" in list_lower or "deployed" in list_lower:
        return "done"
    if "progress" in list_lower or "doing" in list_lower:
        return "in_progress"
    if "review" in list_lower or "testing" in list_lower:
        return "review"
    if "blocked" in list_lower or "issue" in list_lower:
        return "blocked"
    if "backlog" in list_lower or "intake" in list_lower or "ready" in list_lower:
        return "pending"

    return None


# Keep old name for backwards compatibility
LIST_STATUS_MAP = DEFAULT_LIST_STATUS_MAP

# Lists that trigger agent assignment (include both spacing variants)
READY_LISTS = ["Planned / Ready", "Planned/Ready", "Ready"]
