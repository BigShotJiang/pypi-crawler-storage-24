"""Trello webhook HTTP server.

Contains the HTTP request handler and server for receiving
Trello webhook callbacks.
"""

import json
import logging
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Callable, Optional

from .webhook_auth import CardMoveEvent, verify_trello_signature

logger = logging.getLogger(__name__)


class WebhookHandler(BaseHTTPRequestHandler):
    """HTTP handler for Trello webhooks.

    Security: Verifies X-Trello-Webhook signature when TRELLO_API_SECRET is set.
    """

    callback: Optional[Callable[[CardMoveEvent], None]] = None
    callback_url: Optional[str] = None  # Set by server for signature verification

    def log_message(self, format, *args):
        """Override to use logging instead of stderr."""
        logger.info(format % args)

    def do_HEAD(self):
        """Handle HEAD request - Trello uses this to verify webhook URL."""
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        """Handle GET request - also for webhook verification."""
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"PairCoder Trello Webhook Server")

    def do_POST(self):
        """Handle POST request - actual webhook callback."""
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        # Verify signature
        signature = self.headers.get("X-Trello-Webhook")
        callback_url = getattr(self.server, "callback_url", None) or ""

        if not verify_trello_signature(body, signature, callback_url):
            logger.warning("Webhook signature verification failed")
            self.send_response(401)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"Unauthorized: Invalid signature")
            return

        try:
            data = json.loads(body.decode("utf-8"))
            self._process_webhook(data)
            self.send_response(200)
            self.end_headers()
        except Exception as e:
            logger.error(f"Error processing webhook: {e}")
            self.send_response(500)
            self.end_headers()

    def _process_webhook(self, data: dict) -> None:
        """Process webhook payload."""
        action = data.get("action", {})
        action_type = action.get("type")

        if action_type != "updateCard":
            logger.debug(f"Ignoring action type: {action_type}")
            return

        action_data = action.get("data", {})
        list_before = action_data.get("listBefore", {}).get("name")
        list_after = action_data.get("listAfter", {}).get("name")

        if not list_before or not list_after:
            logger.debug("Not a list change, ignoring")
            return

        card = action_data.get("card", {})
        board = action_data.get("board", {})

        event = CardMoveEvent(
            card_id=card.get("id", ""),
            card_name=card.get("name", ""),
            list_before=list_before,
            list_after=list_after,
            board_id=board.get("id", ""),
        )

        logger.info(f"Card move: '{event.card_name}' from '{list_before}' to '{list_after}'")

        if self.callback:
            self.callback(event)


class TrelloWebhookServer:
    """Trello webhook server with configurable handlers."""

    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 8765,
        on_card_move: Optional[Callable[[CardMoveEvent], None]] = None,
        callback_url: Optional[str] = None,
    ):
        """Initialize webhook server.

        Args:
            host: Host to bind to
            port: Port to listen on
            on_card_move: Callback for card move events
            callback_url: The registered webhook callback URL
        """
        self.host = host
        self.port = port
        self.on_card_move = on_card_move
        self.callback_url = callback_url
        self._server: Optional[HTTPServer] = None

    def start(self) -> None:
        """Start the webhook server (blocking)."""
        handler = WebhookHandler
        handler.callback = self.on_card_move

        self._server = HTTPServer((self.host, self.port), handler)
        self._server.callback_url = self.callback_url

        if os.environ.get("TRELLO_API_SECRET"):
            logger.info(f"Webhook signature verification ENABLED")
        else:
            logger.warning(
                "TRELLO_API_SECRET not set - webhook signature verification DISABLED. "
                "Set this environment variable in production."
            )

        logger.info(f"Starting Trello webhook server on {self.host}:{self.port}")

        try:
            self._server.serve_forever()
        except KeyboardInterrupt:
            logger.info("Shutting down webhook server")
            self._server.shutdown()

    def stop(self) -> None:
        """Stop the webhook server."""
        if self._server:
            self._server.shutdown()
