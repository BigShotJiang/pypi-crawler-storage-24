"""Source code analysis components."""
