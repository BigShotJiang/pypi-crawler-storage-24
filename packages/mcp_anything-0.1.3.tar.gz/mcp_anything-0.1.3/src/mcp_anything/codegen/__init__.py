"""Code generation components."""
