"""Pipeline execution framework."""
