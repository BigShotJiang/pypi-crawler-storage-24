# github-scoped MCP Server

MCP server for github-scoped (with 1099 capabilities)

## Available Tools

Status meanings:
- `ready`: direct implementation was generated
- `proxy`: calls a supported upstream backend
- `scaffolded`: generated code needs manual wiring before production use
- `stubbed`: no implementation was generated

### security_advisories_list_global_advisories

GET /advisories - List global security advisories

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::security-advisories/list-global-advisories`

Parameters:
- `ghsa_id` (string, optional): If specified, only advisories with this GHSA (GitHub Security Advisory) identifier will be returned.
- `type` (string, optional): If specified, only advisories of this type will be returned. By default, a request with no other parameters defined will only return reviewed advisories that are not malware. (default: reviewed) — one of: reviewed, malware, unreviewed
- `cve_id` (string, optional): If specified, only advisories with this CVE (Common Vulnerabilities and Exposures) identifier will be returned.
- `ecosystem` (string, optional): If specified, only advisories for these ecosystems will be returned. — one of: rubygems, npm, pip, maven, nuget, composer, go, rust, erlang, actions, pub, other, swift
- `severity` (string, optional): If specified, only advisories with these severities will be returned. — one of: unknown, low, medium, high, critical
- `cwes` (object, optional): If specified, only advisories with these Common Weakness Enumerations (CWEs) will be returned.

Example: `cwes=79,284,22` or `cwes[]=79&cwes[]=284&cwes[]=22`
- `is_withdrawn` (boolean, optional): Whether to only return advisories that have been withdrawn.
- `affects` (object, optional): If specified, only return advisories that affect any of `package` or `package@version`. A maximum of 1000 packages can be specified.
If the query parameter causes the URL to exceed the maximum URL length supported by your client, you must specify fewer packages.

Example: `affects=package1,package2@1.0.0,package3@2.0.0` or `affects[]=package1&affects[]=package2@1.0.0`
- `published` (string, optional): If specified, only return advisories that were published on a date or date range.

For more information on the syntax of the date range, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
- `updated` (string, optional): If specified, only return advisories that were updated on a date or date range.

For more information on the syntax of the date range, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
- `modified` (string, optional): If specified, only show advisories that were updated or published on a date or date range.

For more information on the syntax of the date range, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
- `epss_percentage` (string, optional): If specified, only return advisories that have an EPSS percentage score that matches the provided value.
The EPSS percentage represents the likelihood of a CVE being exploited.
- `epss_percentile` (string, optional): If specified, only return advisories that have an EPSS percentile score that matches the provided value.
The EPSS percentile represents the relative rank of the CVE's likelihood of being exploited compared to other CVEs.
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `sort` (string, optional): The property to sort the results by. (default: published) — one of: updated, published, epss_percentage, epss_percentile
### security_advisories_get_global_advisory

GET /advisories/{ghsa_id} - Get a global security advisory

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::security-advisories/get-global-advisory`

Parameters:
- `ghsa_id` (string): The GHSA (GitHub Security Advisory) identifier of the advisory.
### gists_list

GET /gists - List gists for the authenticated user

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::gists/list`

Parameters:
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### gists_create

POST /gists - Create a gist

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::gists/create`

Parameters:
- `description` (string, optional): Description of the gist
- `files` (object): Names and content for the files that make up the gist
- `public` (object, optional): 
### gists_get

GET /gists/{gist_id} - Get a gist

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::gists/get`

Parameters:
- `gist_id` (string): The unique identifier of the gist.
### gists_update

PATCH /gists/{gist_id} - Update a gist

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::gists/update`

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `description` (string, optional): The description of the gist.
- `files` (object, optional): The gist files to be updated, renamed, or deleted. Each `key` must match the current filename
(including extension) of the targeted gist file. For example: `hello.py`.

To delete a file, set the whole file to null. For example: `hello.py : null`. The file will also be
deleted if the specified object does not contain at least one of `content` or `filename`.
### get_notifications

GET /notifications - List notifications for the authenticated user

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::activity/list-notifications-for-authenticated-user`

Parameters:
- `all` (boolean, optional): If `true`, show notifications marked as read. (default: False)
- `participating` (boolean, optional): If `true`, only shows notifications in which the user is directly participating or mentioned. (default: False)
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `before` (string, optional): Only show notifications updated before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 50). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 50)
### activity_mark_notifications_as_read

PUT /notifications - Mark notifications as read

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::activity/mark-notifications-as-read`

Parameters:
- `last_read_at` (string, optional): Describes the last point that notifications were checked. Anything updated since this time will not be marked as read. If you omit this parameter, all notifications are marked as read. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Default: The current timestamp.
- `read` (boolean, optional): Whether the notification has been read.
### activity_get_thread

GET /notifications/threads/{thread_id} - Get a thread

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::activity/get-thread`

Parameters:
- `thread_id` (integer): The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)).
### activity_mark_thread_as_done

DELETE /notifications/threads/{thread_id} - Mark a thread as done

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::activity/mark-thread-as-done`

Parameters:
- `thread_id` (integer): The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)).
### activity_set_thread_subscription

PUT /notifications/threads/{thread_id}/subscription - Set a thread subscription

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::activity/set-thread-subscription`

Parameters:
- `thread_id` (integer): The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)).
- `ignored` (boolean, optional): Whether to block all notifications from a thread. (default: False)
### orgs_list_issue_types

GET /orgs/{org}/issue-types - List issue types for an organization

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::orgs/list-issue-types`

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### teams_list

GET /orgs/{org}/teams - List teams

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::teams/list`

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `team_type` (string, optional): Filter team results by their type. For more information, see "[What kind of team should I use?](https://docs.github.com/enterprise-cloud@latest/admin/concepts/enterprise-fundamentals/teams-in-an-enterprise#what-kind-of-team-should-i-use)" (default: all) — one of: all, enterprise, organization
### teams_list_members_in_org

GET /orgs/{org}/teams/{team_slug}/members - List team members

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::teams/list-members-in-org`

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `role` (string, optional): Filters members returned by their role in the team. (default: all) — one of: member, maintainer, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_download_job_logs_for_workflow_run

GET /repos/{owner}/{repo}/actions/jobs/{job_id}/logs - Download job logs for a workflow run

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::actions/download-job-logs-for-workflow-run`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `job_id` (integer): The unique identifier of the job.
### actions_list_repo_workflows

GET /repos/{owner}/{repo}/actions/workflows - List repository workflows

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::actions/list-repo-workflows`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_get_workflow

GET /repos/{owner}/{repo}/actions/workflows/{workflow_id} - Get a workflow

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::actions/get-workflow`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `workflow_id` (object): The ID of the workflow. You can also pass the workflow file name as a string.
### actions_create_workflow_dispatch

POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches - Create a workflow dispatch event

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::actions/create-workflow-dispatch`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `workflow_id` (object): The ID of the workflow. You can also pass the workflow file name as a string.
- `ref` (string): The git reference for the workflow. The reference can be a branch or tag name.
- `inputs` (object, optional): Input keys and values configured in the workflow file. The maximum number of properties is 25. Any default properties configured in the workflow file will be used when `inputs` are omitted.
- `return_run_details` (boolean, optional): Whether the response should include the workflow run ID and URLs.
### repos_list_branches

GET /repos/{owner}/{repo}/branches - List branches

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/list-branches`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `protected` (boolean, optional): Setting to `true` returns only branches protected by branch protections or rulesets. When set to `false`, only unprotected branches are returned. Omitting this parameter returns all branches.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### code_scanning_list_alerts_for_repo

GET /repos/{owner}/{repo}/code-scanning/alerts - List code scanning alerts for a repository

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::code-scanning/list-alerts-for-repo`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tool_name` (string, optional): The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both.
- `tool_guid` (string, optional): The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `ref` (string, optional): The Git reference for the results you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
- `pr` (integer, optional): The number of the pull request for the results you want to list.
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `sort` (string, optional): The property by which to sort the results. (default: created) — one of: created, updated
- `state` (string, optional): If specified, only code scanning alerts with this state will be returned. — one of: open, closed, dismissed, fixed
- `severity` (string, optional): If specified, only code scanning alerts with this severity will be returned. — one of: critical, high, medium, low, warning, note, error
- `assignees` (string, optional): Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`).
Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees.

### code_scanning_get_alert

GET /repos/{owner}/{repo}/code-scanning/alerts/{alert_number} - Get a code scanning alert

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::code-scanning/get-alert`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
### repos_list_commits

GET /repos/{owner}/{repo}/commits - List commits

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/list-commits`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `sha` (string, optional): SHA or branch to start listing commits from. Default: the repository’s default branch (usually `main`).
- `path` (string, optional): Only commits containing this file path will be returned.
- `author` (string, optional): GitHub username or email address to use to filter by commit author.
- `committer` (string, optional): GitHub username or email address to use to filter by commit committer.
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Due to limitations of Git, timestamps must be between 1970-01-01 and 2099-12-31 (inclusive) or unexpected results may be returned.
- `until` (string, optional): Only commits before this date will be returned. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Due to limitations of Git, timestamps must be between 1970-01-01 and 2099-12-31 (inclusive) or unexpected results may be returned.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_commit

GET /repos/{owner}/{repo}/commits/{ref} - Get a commit

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/get-commit`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `ref` (string): The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
### repos_get_content

GET /repos/{owner}/{repo}/contents/{path} - Get repository content

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/get-content`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `path` (string): path parameter
- `ref` (string, optional): The name of the commit/branch/tag. Default: the repository’s default branch.
### repos_create_or_update_file_contents

PUT /repos/{owner}/{repo}/contents/{path} - Create or update file contents

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/create-or-update-file-contents`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `path` (string): path parameter
- `message` (string): The commit message.
- `content` (string): The new file content, using Base64 encoding.
- `sha` (string, optional): **Required if you are updating a file**. The blob SHA of the file being replaced.
- `branch` (string, optional): The branch name. Default: the repository’s default branch.
- `committer` (object, optional): The person that committed the file. Default: the authenticated user.
- `author` (object, optional): The author of the file. Default: The `committer` or the authenticated user if you omit `committer`.
### repos_delete_file

DELETE /repos/{owner}/{repo}/contents/{path} - Delete a file

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/delete-file`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `path` (string): path parameter
- `message` (string): The commit message.
- `sha` (string): The blob SHA of the file being deleted.
- `branch` (string, optional): The branch name. Default: the repository’s default branch
- `committer` (object, optional): object containing information about the committer.
- `author` (object, optional): object containing information about the author.
### dependabot_list_alerts_for_repo

GET /repos/{owner}/{repo}/dependabot/alerts - List Dependabot alerts for a repository

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::dependabot/list-alerts-for-repo`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `state` (string, optional): A comma-separated list of states. If specified, only alerts with these states will be returned.

Can be: `auto_dismissed`, `dismissed`, `fixed`, `open`
- `severity` (string, optional): A comma-separated list of severities. If specified, only alerts with these severities will be returned.

Can be: `low`, `medium`, `high`, `critical`
- `ecosystem` (string, optional): A comma-separated list of ecosystems. If specified, only alerts for these ecosystems will be returned.

Can be: `composer`, `go`, `maven`, `npm`, `nuget`, `pip`, `pub`, `rubygems`, `rust`
- `package` (string, optional): A comma-separated list of package names. If specified, only alerts for these packages will be returned.
- `manifest` (string, optional): A comma-separated list of full manifest paths. If specified, only alerts for these manifests will be returned.
- `epss_percentage` (string, optional): CVE Exploit Prediction Scoring System (EPSS) percentage. Can be specified as:
- An exact number (`n`)
- Comparators such as `>n`, `<n`, `>=n`, `<=n`
- A range like `n..n`, where `n` is a number from 0.0 to 1.0

Filters the list of alerts based on EPSS percentages. If specified, only alerts with the provided EPSS percentages will be returned.
- `has` (object, optional): Filters the list of alerts based on whether the alert has the given value. If specified, only alerts meeting this criterion will be returned.
Multiple `has` filters can be passed to filter for alerts that have all of the values. Currently, only `patch` is supported.
- `assignee` (string, optional): Filter alerts by assignees.
Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`) to return alerts assigned to any of the specified users.
Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees.
- `scope` (string, optional): The scope of the vulnerable dependency. If specified, only alerts with this scope will be returned. — one of: development, runtime
- `sort` (string, optional): The property by which to sort the results.
`created` means when the alert was created.
`updated` means when the alert's state last changed.
`epss_percentage` sorts alerts by the Exploit Prediction Scoring System (EPSS) percentage. (default: created) — one of: created, updated, epss_percentage
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### dependabot_get_alert

GET /repos/{owner}/{repo}/dependabot/alerts/{alert_number} - Get a Dependabot alert

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::dependabot/get-alert`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies a Dependabot alert in its repository.
You can find this at the end of the URL for a Dependabot alert within GitHub,
or in `number` fields in the response from the
`GET /repos/{owner}/{repo}/dependabot/alerts` operation.
### repos_create_fork

POST /repos/{owner}/{repo}/forks - Create a fork

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/create-fork`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `organization` (string, optional): Optional parameter to specify the organization name if forking into an organization.
- `name` (string, optional): When forking from an existing repository, a new name for the fork.
- `default_branch_only` (boolean, optional): When forking from an existing repository, fork with only the default branch.
### git_create_ref

POST /repos/{owner}/{repo}/git/refs - Create a reference

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::git/create-ref`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The name of the fully qualified reference (ie: `refs/heads/master`). If it doesn't start with 'refs' and have at least two slashes, it will be rejected.
- `sha` (string): The SHA1 value for this reference.
### git_get_tag

GET /repos/{owner}/{repo}/git/tags/{tag_sha} - Get a tag

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::git/get-tag`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tag_sha` (string): 
### git_get_tree

GET /repos/{owner}/{repo}/git/trees/{tree_sha} - Get a tree

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::git/get-tree`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tree_sha` (string): The SHA1 value or ref (branch or tag) name of the tree.
- `recursive` (string, optional): Setting this parameter to any value returns the objects or subtrees referenced by the tree specified in `:tree_sha`. For example, setting `recursive` to any of the following will enable returning objects or subtrees: `0`, `1`, `"true"`, and `"false"`. Omit this parameter to prevent recursively returning objects or subtrees.
### issues_list_for_repo

GET /repos/{owner}/{repo}/issues - List repository issues

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::issues/list-for-repo`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `milestone` (string, optional): If an `integer` is passed, it should refer to a milestone by its `number` field. If the string `*` is passed, issues with any milestone are accepted. If the string `none` is passed, issues without milestones are returned.
- `state` (string, optional): Indicates the state of the issues to return. (default: open) — one of: open, closed, all
- `assignee` (string, optional): Can be the name of a user. Pass in `none` for issues with no assigned user, and `*` for issues assigned to any user.
- `type` (string, optional): Can be the name of an issue type. If the string `*` is passed, issues with any type are accepted. If the string `none` is passed, issues without type are returned.
- `creator` (string, optional): The user that created the issue.
- `mentioned` (string, optional): A user that's mentioned in the issue.
- `labels` (string, optional): A list of comma separated label names. Example: `bug,ui,@high`
- `sort` (string, optional): What to sort results by. (default: created) — one of: created, updated, comments
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_create

POST /repos/{owner}/{repo}/issues - Create an issue

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::issues/create`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `title` (object): The title of the issue.
- `body` (string, optional): The contents of the issue.
- `assignee` (string, optional): Login for the user that this issue should be assigned to. _NOTE: Only users with push access can set the assignee for new issues. The assignee is silently dropped otherwise. **This field is closing down.**_
- `milestone` (object, optional): 
- `labels` (array, optional): Labels to associate with this issue. _NOTE: Only users with push access can set labels for new issues. Labels are silently dropped otherwise._
- `assignees` (array, optional): Logins for Users to assign to this issue. _NOTE: Only users with push access can set assignees for new issues. Assignees are silently dropped otherwise._
- `type` (string, optional): The name of the issue type to associate with this issue. _NOTE: Only users with push access can set the type for new issues. The type is silently dropped otherwise._
### issues_get

GET /repos/{owner}/{repo}/issues/{issue_number} - Get an issue

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::issues/get`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
### issues_update

PATCH /repos/{owner}/{repo}/issues/{issue_number} - Update an issue

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::issues/update`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `title` (object, optional): The title of the issue.
- `body` (string, optional): The contents of the issue.
- `assignee` (string, optional): Username to assign to this issue. **This field is closing down.**
- `state` (string, optional): The open or closed state of the issue.
- `state_reason` (string, optional): The reason for the state change. Ignored unless `state` is changed.
- `milestone` (object, optional): 
- `labels` (array, optional): Labels to associate with this issue. Pass one or more labels to _replace_ the set of labels on this issue. Send an empty array (`[]`) to clear all labels from the issue. Only users with push access can set labels for issues. Without push access to the repository, label changes are silently dropped.
- `assignees` (array, optional): Usernames to assign to this issue. Pass one or more user logins to _replace_ the set of assignees on this issue. Send an empty array (`[]`) to clear all assignees from the issue. Only users with push access can set assignees for new issues. Without push access to the repository, assignee changes are silently dropped.
- `issue_field_values` (array, optional): An array of issue field values to set on this issue. Each field value must include the field ID and the value to set. Only users with push access can set field values for issues
- `type` (string, optional): The name of the issue type to associate with this issue or use `null` to remove the current issue type. Only users with push access can set the type for issues. Without push access to the repository, type changes are silently dropped.
### issues_create_comment

POST /repos/{owner}/{repo}/issues/{issue_number}/comments - Create an issue comment

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::issues/create-comment`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `body` (string): The contents of the comment.
### issues_add_sub_issue

POST /repos/{owner}/{repo}/issues/{issue_number}/sub_issues - Add sub-issue

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::issues/add-sub-issue`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `sub_issue_id` (integer): The id of the sub-issue to add. The sub-issue must belong to the same repository owner as the parent issue
- `replace_parent` (boolean, optional): Option that, when true, instructs the operation to replace the sub-issues current parent issue
### issues_list_labels_for_repo

GET /repos/{owner}/{repo}/labels - List labels for a repository

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::issues/list-labels-for-repo`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_create_label

POST /repos/{owner}/{repo}/labels - Create a label

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::issues/create-label`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the label. Emoji can be added to label names, using either native emoji or colon-style markup. For example, typing `:strawberry:` will render the emoji ![:strawberry:](https://github.githubassets.com/images/icons/emoji/unicode/1f353.png ":strawberry:"). For a full list of available emoji and codes, see "[Emoji cheat sheet](https://github.com/ikatyang/emoji-cheat-sheet)."
- `color` (string, optional): The [hexadecimal color code](http://www.color-hex.com/) for the label, without the leading `#`.
- `description` (string, optional): A short description of the label. Must be 100 characters or fewer.
### issues_get_label

GET /repos/{owner}/{repo}/labels/{name} - Get a label

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::issues/get-label`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): 
### pulls_list

GET /repos/{owner}/{repo}/pulls - List pull requests

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::pulls/list`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `state` (string, optional): Either `open`, `closed`, or `all` to filter by state. (default: open) — one of: open, closed, all
- `head` (string, optional): Filter pulls by head user or head organization and branch name in the format of `user:ref-name` or `organization:ref-name`. For example: `github:new-script-format` or `octocat:test-branch`.
- `base` (string, optional): Filter pulls by base branch name. Example: `gh-pages`.
- `sort` (string, optional): What to sort results by. `popularity` will sort by the number of comments. `long-running` will sort by date created and will limit the results to pull requests that have been open for more than a month and have had activity within the past month. (default: created) — one of: created, updated, popularity, long-running
- `direction` (string, optional): The direction of the sort. Default: `desc` when sort is `created` or sort is not specified, otherwise `asc`. — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### pulls_create

POST /repos/{owner}/{repo}/pulls - Create a pull request

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::pulls/create`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `title` (string, optional): The title of the new pull request. Required unless `issue` is specified.
- `head` (string): The name of the branch where your changes are implemented. For cross-repository pull requests in the same network, namespace `head` with a user like this: `username:branch`.
- `head_repo` (string, optional): The name of the repository where the changes in the pull request were made. This field is required for cross-repository pull requests if both repositories are owned by the same organization.
- `base` (string): The name of the branch you want the changes pulled into. This should be an existing branch on the current repository. You cannot submit a pull request to one repository that requests a merge to a base of another repository.
- `body` (string, optional): The contents of the pull request.
- `maintainer_can_modify` (boolean, optional): Indicates whether [maintainers can modify](https://docs.github.com/articles/allowing-changes-to-a-pull-request-branch-created-from-a-fork/) the pull request.
- `draft` (boolean, optional): Indicates whether the pull request is a draft. See "[Draft Pull Requests](https://docs.github.com/articles/about-pull-requests#draft-pull-requests)" in the GitHub Help documentation to learn more.
- `issue` (integer, optional): An issue in the repository to convert to a pull request. The issue title, body, and comments will become the title, body, and comments on the new pull request. Required unless `title` is specified.
### pulls_get

GET /repos/{owner}/{repo}/pulls/{pull_number} - Get a pull request

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::pulls/get`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
### pulls_update

PATCH /repos/{owner}/{repo}/pulls/{pull_number} - Update a pull request

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::pulls/update`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `title` (string, optional): The title of the pull request.
- `body` (string, optional): The contents of the pull request.
- `state` (string, optional): State of this Pull Request. Either `open` or `closed`.
- `base` (string, optional): The name of the branch you want your changes pulled into. This should be an existing branch on the current repository. You cannot update the base branch on a pull request to point to another repository.
- `maintainer_can_modify` (boolean, optional): Indicates whether [maintainers can modify](https://docs.github.com/articles/allowing-changes-to-a-pull-request-branch-created-from-a-fork/) the pull request.
### pulls_create_review_comment

POST /repos/{owner}/{repo}/pulls/{pull_number}/comments - Create a review comment for a pull request

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::pulls/create-review-comment`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `body` (string): The text of the review comment.
- `commit_id` (string): The SHA of the commit needing a comment. Not using the latest commit SHA may render your comment outdated if a subsequent commit modifies the line you specify as the `position`.
- `path` (string): The relative path to the file that necessitates a comment.
- `position` (integer, optional): **This parameter is closing down. Use `line` instead**. The position in the diff where you want to add a review comment. Note this value is not the same as the line number in the file. The position value equals the number of lines down from the first "@@" hunk header in the file you want to add a comment. The line just below the "@@" line is position 1, the next line is position 2, and so on. The position in the diff continues to increase through lines of whitespace and additional hunks until the beginning of a new file.
- `side` (string, optional): In a split diff view, the side of the diff that the pull request's changes appear on. Can be `LEFT` or `RIGHT`. Use `LEFT` for deletions that appear in red. Use `RIGHT` for additions that appear in green or unchanged lines that appear in white and are shown for context. For a multi-line comment, side represents whether the last line of the comment range is a deletion or addition. For more information, see "[Diff view options](https://docs.github.com/articles/about-comparing-branches-in-pull-requests#diff-view-options)" in the GitHub Help documentation.
- `line` (integer, optional): **Required unless using `subject_type:file`**. The line of the blob in the pull request diff that the comment applies to. For a multi-line comment, the last line of the range that your comment applies to.
- `start_line` (integer, optional): **Required when using multi-line comments unless using `in_reply_to`**. The `start_line` is the first line in the pull request diff that your multi-line comment applies to. To learn more about multi-line comments, see "[Commenting on a pull request](https://docs.github.com/articles/commenting-on-a-pull-request#adding-line-comments-to-a-pull-request)" in the GitHub Help documentation.
- `start_side` (string, optional): **Required when using multi-line comments unless using `in_reply_to`**. The `start_side` is the starting side of the diff that the comment applies to. Can be `LEFT` or `RIGHT`. To learn more about multi-line comments, see "[Commenting on a pull request](https://docs.github.com/articles/commenting-on-a-pull-request#adding-line-comments-to-a-pull-request)" in the GitHub Help documentation. See `side` in this table for additional context.
- `in_reply_to` (integer, optional): The ID of the review comment to reply to. To find the ID of a review comment with ["List review comments on a pull request"](#list-review-comments-on-a-pull-request). When specified, all parameters other than `body` in the request body are ignored.
- `subject_type` (string, optional): The level at which the comment is targeted.
### pulls_create_reply_for_review_comment

POST /repos/{owner}/{repo}/pulls/{pull_number}/comments/{comment_id}/replies - Create a reply for a review comment

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::pulls/create-reply-for-review-comment`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `comment_id` (integer): The unique identifier of the comment.
- `body` (string): The text of the review comment.
### pulls_merge

PUT /repos/{owner}/{repo}/pulls/{pull_number}/merge - Merge a pull request

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::pulls/merge`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `commit_title` (string, optional): Title for the automatic commit message.
- `commit_message` (string, optional): Extra detail to append to automatic commit message.
- `sha` (string, optional): SHA that pull request head must match to allow merge.
- `merge_method` (string, optional): The merge method to use.
### pulls_submit_review

POST /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}/events - Submit a review for a pull request

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::pulls/submit-review`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `review_id` (integer): The unique identifier of the review.
- `body` (string, optional): The body text of the pull request review
- `event` (string): The review action you want to perform. The review actions include: `APPROVE`, `REQUEST_CHANGES`, or `COMMENT`. When you leave this blank, the API returns _HTTP 422 (Unrecognizable entity)_ and sets the review action state to `PENDING`, which means you will need to re-submit the pull request review using a review action.
### pulls_update_branch

PUT /repos/{owner}/{repo}/pulls/{pull_number}/update-branch - Update a pull request branch

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::pulls/update-branch`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `expected_head_sha` (string, optional): The expected SHA of the pull request's HEAD ref. This is the most recent commit on the pull request's branch. If the expected SHA does not match the pull request's HEAD, you will receive a `422 Unprocessable Entity` status. You can use the "[List commits](https://docs.github.com/rest/commits/commits#list-commits)" endpoint to find the most recent commit SHA. Default: SHA of the pull request's current HEAD ref.
### repos_list_releases

GET /repos/{owner}/{repo}/releases - List releases

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/list-releases`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_latest_release

GET /repos/{owner}/{repo}/releases/latest - Get the latest release

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/get-latest-release`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get_release_by_tag

GET /repos/{owner}/{repo}/releases/tags/{tag} - Get a release by tag name

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/get-release-by-tag`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tag` (string): tag parameter
### secret_scanning_list_alerts_for_repo

GET /repos/{owner}/{repo}/secret-scanning/alerts - List secret scanning alerts for a repository

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::secret-scanning/list-alerts-for-repo`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `state` (string, optional): Set to `open` or `resolved` to only list secret scanning alerts in a specific state. — one of: open, resolved
- `secret_type` (string, optional): A comma-separated list of secret types to return. All default secret patterns are returned. To return generic patterns, pass the token name(s) in the parameter. See "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)" for a complete list of secret types.
- `resolution` (string, optional): A comma-separated list of resolutions. Only secret scanning alerts with one of these resolutions are listed. Valid resolutions are `false_positive`, `wont_fix`, `revoked`, `pattern_edited`, `pattern_deleted` or `used_in_tests`.
- `assignee` (string, optional): Filters alerts by assignee. Use `*` to get all assigned alerts, `none` to get all unassigned alerts, or a GitHub username to get alerts assigned to a specific user.
- `sort` (string, optional): The property to sort the results by. `created` means when the alert was created. `updated` means when the alert was updated or resolved. (default: created) — one of: created, updated
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events before this cursor. To receive an initial cursor on your first request, include an empty "before" query string.
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events after this cursor.  To receive an initial cursor on your first request, include an empty "after" query string.
- `validity` (string, optional): A comma-separated list of validities that, when present, will return alerts that match the validities in this list. Valid options are `active`, `inactive`, and `unknown`.
- `is_publicly_leaked` (boolean, optional): A boolean value representing whether or not to filter alerts by the publicly-leaked tag being present. (default: False)
- `is_multi_repo` (boolean, optional): A boolean value representing whether or not to filter alerts by the multi-repo tag being present. (default: False)
- `hide_secret` (boolean, optional): A boolean value representing whether or not to hide literal secrets in the results. (default: False)
### secret_scanning_get_alert

GET /repos/{owner}/{repo}/secret-scanning/alerts/{alert_number} - Get a secret scanning alert

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::secret-scanning/get-alert`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
- `hide_secret` (boolean, optional): A boolean value representing whether or not to hide literal secrets in the results. (default: False)
### security_advisories_list_repository_advisories

GET /repos/{owner}/{repo}/security-advisories - List repository security advisories

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::security-advisories/list-repository-advisories`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `sort` (string, optional): The property to sort the results by. (default: created) — one of: created, updated, published
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of advisories to return per page. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `state` (string, optional): Filter by state of the repository advisories. Only advisories of this state will be returned. — one of: triage, draft, published, closed
### activity_set_repo_subscription

PUT /repos/{owner}/{repo}/subscription - Set a repository subscription

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::activity/set-repo-subscription`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `subscribed` (boolean, optional): Determines if notifications should be received from this repository.
- `ignored` (boolean, optional): Determines if all notifications should be blocked from this repository.
### repos_list_tags

GET /repos/{owner}/{repo}/tags - List repository tags

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/list-tags`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### search_code

GET /search/code - Search code

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::search/code`

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching code](https://docs.github.com/search-github/searching-on-github/searching-code)" for a detailed list of qualifiers.
- `sort` (string, optional): **This field is closing down.** Sorts the results of your query. Can only be `indexed`, which indicates how recently a file has been indexed by the GitHub search infrastructure. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: indexed
- `order` (string, optional): **This field is closing down.** Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`.  (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### search_issues_and_pull_requests

GET /search/issues - Search issues and pull requests

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::search/issues-and-pull-requests`

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching issues and pull requests](https://docs.github.com/search-github/searching-on-github/searching-issues-and-pull-requests)" for a detailed list of qualifiers.
- `sort` (string, optional): Sorts the results of your query by the number of `comments`, `reactions`, `reactions-+1`, `reactions--1`, `reactions-smile`, `reactions-thinking_face`, `reactions-heart`, `reactions-tada`, or `interactions`. You can also sort results by how recently the items were `created` or `updated`, Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: comments, reactions, reactions-+1, reactions--1, reactions-smile, reactions-thinking_face, reactions-heart, reactions-tada, interactions, created, updated
- `order` (string, optional): Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `advanced_search` (string, optional): Set to `true` to use advanced search.
Example: `http://api.github.com/search/issues?q={query}&advanced_search=true`
### search_repos

GET /search/repositories - Search repositories

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::search/repos`

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching for repositories](https://docs.github.com/articles/searching-for-repositories/)" for a detailed list of qualifiers.
- `sort` (string, optional): Sorts the results of your query by number of `stars`, `forks`, or `help-wanted-issues` or how recently the items were `updated`. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: stars, forks, help-wanted-issues, updated
- `order` (string, optional): Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### search_users

GET /search/users - Search users

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::search/users`

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching users](https://docs.github.com/search-github/searching-on-github/searching-users)" for a detailed list of qualifiers.
- `sort` (string, optional): Sorts the results of your query by number of `followers` or `repositories`, or when the person `joined` GitHub. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: followers, repositories, joined
- `order` (string, optional): Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_get_authenticated

GET /user - Get the authenticated user

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::users/get-authenticated`

### repos_create_for_authenticated_user

POST /user/repos - Create a repository for the authenticated user

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::repos/create-for-authenticated-user`

Parameters:
- `name` (string): The name of the repository.
- `description` (string, optional): A short description of the repository.
- `homepage` (string, optional): A URL with more information about the repository.
- `private` (boolean, optional): Whether the repository is private. (default: False)
- `has_issues` (boolean, optional): Whether issues are enabled. (default: True)
- `has_projects` (boolean, optional): Whether projects are enabled. (default: True)
- `has_wiki` (boolean, optional): Whether the wiki is enabled. (default: True)
- `has_discussions` (boolean, optional): Whether discussions are enabled. (default: False)
- `team_id` (integer, optional): The id of the team that will be granted access to this repository. This is only valid when creating a repository in an organization.
- `auto_init` (boolean, optional): Whether the repository is initialized with a minimal README. (default: False)
- `gitignore_template` (string, optional): The desired language or platform to apply to the .gitignore.
- `license_template` (string, optional): The license keyword of the open source license for this repository.
- `allow_squash_merge` (boolean, optional): Whether to allow squash merges for pull requests. (default: True)
- `allow_merge_commit` (boolean, optional): Whether to allow merge commits for pull requests. (default: True)
- `allow_rebase_merge` (boolean, optional): Whether to allow rebase merges for pull requests. (default: True)
- `allow_auto_merge` (boolean, optional): Whether to allow Auto-merge to be used on pull requests. (default: False)
- `delete_branch_on_merge` (boolean, optional): Whether to delete head branches when pull requests are merged (default: False)
- `squash_merge_commit_title` (string, optional): Required when using `squash_merge_commit_message`.

The default value for a squash merge commit title:

- `PR_TITLE` - default to the pull request's title.
- `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit).
- `squash_merge_commit_message` (string, optional): The default value for a squash merge commit message:

- `PR_BODY` - default to the pull request's body.
- `COMMIT_MESSAGES` - default to the branch's commit messages.
- `BLANK` - default to a blank commit message.
- `merge_commit_title` (string, optional): Required when using `merge_commit_message`.

The default value for a merge commit title.

- `PR_TITLE` - default to the pull request's title.
- `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name).
- `merge_commit_message` (string, optional): The default value for a merge commit message.

- `PR_TITLE` - default to the pull request's title.
- `PR_BODY` - default to the pull request's body.
- `BLANK` - default to a blank commit message.
- `has_downloads` (boolean, optional): Whether downloads are enabled. (default: True)
- `is_template` (boolean, optional): Whether this repository acts as a template that can be used to generate new repositories. (default: False)
### activity_list_repos_starred_by_authenticated_user

GET /user/starred - List repositories starred by the authenticated user

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::activity/list-repos-starred-by-authenticated-user`

Parameters:
- `sort` (string, optional): The property to sort the results by. `created` means when the repository was starred. `updated` means when the repository was last pushed to. (default: created) — one of: created, updated
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_star_repo_for_authenticated_user

PUT /user/starred/{owner}/{repo} - Star a repository for the authenticated user

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::activity/star-repo-for-authenticated-user`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### activity_unstar_repo_for_authenticated_user

DELETE /user/starred/{owner}/{repo} - Unstar a repository for the authenticated user

Implementation status: `proxy`
Notes: Proxies requests to the detected HTTP API.
Source hint: `Source: openapi.json::activity/unstar-repo-for-authenticated-user`

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.

## Available Resources

- `app://github-scoped/status` — Current status and version of github-scoped
- `app://github-scoped/commands` — Available commands and tools in github-scoped
- `docs://github-scoped/tool-index` — Complete index of all github-scoped tools with parameters and usage
- `docs://github-scoped/api` — Documentation for github-scoped api capabilities

## Available Prompts

- `use_github_scoped` — Guide for using github-scoped tools effectively
- `debug_github_scoped` — Diagnose issues with github-scoped operations

## Usage

This server runs over stdio. Add it to your MCP client config:

```json
{
  "mcpServers": {
    "github-scoped": {
      "command": "mcp-github-scoped"
    }
  }
}
```
