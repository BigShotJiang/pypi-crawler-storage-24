# github MCP Server

MCP server for github (with 1093 capabilities)

## Available Tools

### meta_root

GET / - GitHub API Root

### security_advisories_list_global_advisories

GET /advisories - List global security advisories

Parameters:
- `ghsa_id` (string, optional): If specified, only advisories with this GHSA (GitHub Security Advisory) identifier will be returned.
- `type` (string, optional): If specified, only advisories of this type will be returned. By default, a request with no other parameters defined will only return reviewed advisories that are not malware. (default: reviewed) — one of: reviewed, malware, unreviewed
- `cve_id` (string, optional): If specified, only advisories with this CVE (Common Vulnerabilities and Exposures) identifier will be returned.
- `ecosystem` (string, optional): If specified, only advisories for these ecosystems will be returned. — one of: rubygems, npm, pip, maven, nuget, composer, go, rust, erlang, actions, pub, other, swift
- `severity` (string, optional): If specified, only advisories with these severities will be returned. — one of: unknown, low, medium, high, critical
- `cwes` (object, optional): If specified, only advisories with these Common Weakness Enumerations (CWEs) will be returned.

Example: `cwes=79,284,22` or `cwes[]=79&cwes[]=284&cwes[]=22`
- `is_withdrawn` (boolean, optional): Whether to only return advisories that have been withdrawn.
- `affects` (object, optional): If specified, only return advisories that affect any of `package` or `package@version`. A maximum of 1000 packages can be specified.
If the query parameter causes the URL to exceed the maximum URL length supported by your client, you must specify fewer packages.

Example: `affects=package1,package2@1.0.0,package3@2.0.0` or `affects[]=package1&affects[]=package2@1.0.0`
- `published` (string, optional): If specified, only return advisories that were published on a date or date range.

For more information on the syntax of the date range, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
- `updated` (string, optional): If specified, only return advisories that were updated on a date or date range.

For more information on the syntax of the date range, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
- `modified` (string, optional): If specified, only show advisories that were updated or published on a date or date range.

For more information on the syntax of the date range, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
- `epss_percentage` (string, optional): If specified, only return advisories that have an EPSS percentage score that matches the provided value.
The EPSS percentage represents the likelihood of a CVE being exploited.
- `epss_percentile` (string, optional): If specified, only return advisories that have an EPSS percentile score that matches the provided value.
The EPSS percentile represents the relative rank of the CVE's likelihood of being exploited compared to other CVEs.
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `sort` (string, optional): The property to sort the results by. (default: published) — one of: updated, published, epss_percentage, epss_percentile
### security_advisories_get_global_advisory

GET /advisories/{ghsa_id} - Get a global security advisory

Parameters:
- `ghsa_id` (string): The GHSA (GitHub Security Advisory) identifier of the advisory.
### apps_get_authenticated

GET /app - Get the authenticated app

### apps_create_from_manifest

POST /app-manifests/{code}/conversions - Create a GitHub App from a manifest

Parameters:
- `code` (string): 
### apps_update_webhook_config_for_app

PATCH /app/hook/config - Update a webhook configuration for an app

Parameters:
- `url` (string, optional): 
- `content_type` (string, optional): 
- `secret` (string, optional): 
- `insecure_ssl` (object, optional): 
### apps_get_webhook_config_for_app

GET /app/hook/config - Get a webhook configuration for an app

### apps_list_webhook_deliveries

GET /app/hook/deliveries - List deliveries for an app webhook

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `cursor` (string, optional): Used for pagination: the starting delivery from which the page of deliveries is fetched. Refer to the `link` header for the next and previous page cursors.
### apps_get_webhook_delivery

GET /app/hook/deliveries/{delivery_id} - Get a delivery for an app webhook

Parameters:
- `delivery_id` (integer): 
### apps_redeliver_webhook_delivery

POST /app/hook/deliveries/{delivery_id}/attempts - Redeliver a delivery for an app webhook

Parameters:
- `delivery_id` (integer): 
### get_app_installation_requests

GET /app/installation-requests - List installation requests for the authenticated app

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### apps_list_installations

GET /app/installations - List installations for the authenticated app

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `outdated` (string, optional): 
### apps_delete_installation

DELETE /app/installations/{installation_id} - Delete an installation for the authenticated app

Parameters:
- `installation_id` (integer): The unique identifier of the installation.
### apps_get_installation

GET /app/installations/{installation_id} - Get an installation for the authenticated app

Parameters:
- `installation_id` (integer): The unique identifier of the installation.
### apps_create_installation_access_token

POST /app/installations/{installation_id}/access_tokens - Create an installation access token for an app

Parameters:
- `installation_id` (integer): The unique identifier of the installation.
- `repositories` (array, optional): List of repository names that the token should have access to
- `repository_ids` (array, optional): List of repository IDs that the token should have access to
- `permissions` (object, optional): 
### apps_unsuspend_installation

DELETE /app/installations/{installation_id}/suspended - Unsuspend an app installation

Parameters:
- `installation_id` (integer): The unique identifier of the installation.
### apps_suspend_installation

PUT /app/installations/{installation_id}/suspended - Suspend an app installation

Parameters:
- `installation_id` (integer): The unique identifier of the installation.
### apps_delete_authorization

DELETE /applications/{client_id}/grant - Delete an app authorization

Parameters:
- `client_id` (string): The client ID of the GitHub app.
- `access_token` (string): The OAuth access token used to authenticate to the GitHub API.
### apps_check_token

POST /applications/{client_id}/token - Check a token

Parameters:
- `client_id` (string): The client ID of the GitHub app.
- `access_token` (string): The access_token of the OAuth or GitHub application.
### apps_reset_token

PATCH /applications/{client_id}/token - Reset a token

Parameters:
- `client_id` (string): The client ID of the GitHub app.
- `access_token` (string): The access_token of the OAuth or GitHub application.
### apps_delete_token

DELETE /applications/{client_id}/token - Delete an app token

Parameters:
- `client_id` (string): The client ID of the GitHub app.
- `access_token` (string): The OAuth access token used to authenticate to the GitHub API.
### apps_scope_token

POST /applications/{client_id}/token/scoped - Create a scoped access token

Parameters:
- `client_id` (string): The client ID of the GitHub app.
- `access_token` (string): The access token used to authenticate to the GitHub API.
- `target` (string, optional): The name of the user or organization to scope the user access token to. **Required** unless `target_id` is specified.
- `target_id` (integer, optional): The ID of the user or organization to scope the user access token to. **Required** unless `target` is specified.
- `repositories` (array, optional): The list of repository names to scope the user access token to. `repositories` may not be specified if `repository_ids` is specified.
- `repository_ids` (array, optional): The list of repository IDs to scope the user access token to. `repository_ids` may not be specified if `repositories` is specified.
- `permissions` (object, optional): 
### apps_get_by_slug

GET /apps/{app_slug} - Get an app

Parameters:
- `app_slug` (string): 
### classroom_get_an_assignment

GET /assignments/{assignment_id} - Get an assignment

Parameters:
- `assignment_id` (integer): The unique identifier of the classroom assignment.
### get_assignments_by_assignment_id_accepted_assignments

GET /assignments/{assignment_id}/accepted_assignments - List accepted assignments for an assignment

Parameters:
- `assignment_id` (integer): The unique identifier of the classroom assignment.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### classroom_get_assignment_grades

GET /assignments/{assignment_id}/grades - Get assignment grades

Parameters:
- `assignment_id` (integer): The unique identifier of the classroom assignment.
### classroom_list_classrooms

GET /classrooms - List classrooms

Parameters:
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### classroom_get_a_classroom

GET /classrooms/{classroom_id} - Get a classroom

Parameters:
- `classroom_id` (integer): The unique identifier of the classroom.
### classroom_list_assignments_for_a_classroom

GET /classrooms/{classroom_id}/assignments - List assignments for a classroom

Parameters:
- `classroom_id` (integer): The unique identifier of the classroom.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### codes_of_conduct_get_all_codes_of_conduct

GET /codes_of_conduct - Get all codes of conduct

### codes_of_conduct_get_conduct_code

GET /codes_of_conduct/{key} - Get a code of conduct

Parameters:
- `key` (string): 
### credentials_revoke

POST /credentials/revoke - Revoke a list of credentials

Parameters:
- `credentials` (array): A list of credentials to be revoked, up to 1000 per request.
### emojis_get

GET /emojis - Get emojis

### put_enterprises_by_enterprise_actions_cache_retention_limit

PUT /enterprises/{enterprise}/actions/cache/retention-limit - Set GitHub Actions cache retention limit for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `max_cache_retention_days` (integer, optional): For repositories & organizations in an enterprise, the maximum duration, in days, for which caches in a repository may be retained.
### get_enterprises_by_enterprise_actions_cache_retention_limit

GET /enterprises/{enterprise}/actions/cache/retention-limit - Get GitHub Actions cache retention limit for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
### put_enterprises_by_enterprise_actions_cache_storage_limit

PUT /enterprises/{enterprise}/actions/cache/storage-limit - Set GitHub Actions cache storage limit for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `max_cache_size_gb` (integer, optional): For repositories & organizations in an enterprise, the maximum size limit for the sum of all caches in a repository, in gigabytes.
### get_enterprises_by_enterprise_actions_cache_storage_limit

GET /enterprises/{enterprise}/actions/cache/storage-limit - Get GitHub Actions cache storage limit for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
### post_enterprises_by_enterprise_actions_oidc_customization_properties_repo

POST /enterprises/{enterprise}/actions/oidc/customization/properties/repo - Create an OIDC custom property inclusion for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `custom_property_name` (string): The name of the custom property to include in the OIDC token
### get_enterprises_by_enterprise_actions_oidc_customization_properties_repo

GET /enterprises/{enterprise}/actions/oidc/customization/properties/repo - List OIDC custom property inclusions for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
### delete_enterprises_by_enterprise_actions_oidc_customization_properties_repo_by_custom_property_name

DELETE /enterprises/{enterprise}/actions/oidc/customization/properties/repo/{custom_property_name} - Delete an OIDC custom property inclusion for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `custom_property_name` (string): The name of the custom property to remove from OIDC token inclusion
### code_security_create_configuration_for_enterprise

POST /enterprises/{enterprise}/code-security/configurations - Create a code security configuration for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `name` (string): The name of the code security configuration. Must be unique within the enterprise.
- `description` (string): A description of the code security configuration
- `advanced_security` (string, optional): The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features.

> [!WARNING]
> `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features.
 (default: disabled)
- `code_security` (string, optional): The enablement status of GitHub Code Security features.
- `dependency_graph` (string, optional): The enablement status of Dependency Graph (default: enabled)
- `dependency_graph_autosubmit_action` (string, optional): The enablement status of Automatic dependency submission (default: disabled)
- `dependency_graph_autosubmit_action_options` (object, optional): Feature options for Automatic dependency submission
- `dependabot_alerts` (string, optional): The enablement status of Dependabot alerts (default: disabled)
- `dependabot_security_updates` (string, optional): The enablement status of Dependabot security updates (default: disabled)
- `code_scanning_options` (object, optional): 
- `code_scanning_default_setup` (string, optional): The enablement status of code scanning default setup (default: disabled)
- `code_scanning_default_setup_options` (object, optional): 
- `code_scanning_delegated_alert_dismissal` (string, optional): The enablement status of code scanning delegated alert dismissal (default: disabled)
- `secret_protection` (string, optional): The enablement status of GitHub Secret Protection features.
- `secret_scanning` (string, optional): The enablement status of secret scanning (default: disabled)
- `secret_scanning_push_protection` (string, optional): The enablement status of secret scanning push protection (default: disabled)
- `secret_scanning_validity_checks` (string, optional): The enablement status of secret scanning validity checks (default: disabled)
- `secret_scanning_non_provider_patterns` (string, optional): The enablement status of secret scanning non provider patterns (default: disabled)
- `secret_scanning_generic_secrets` (string, optional): The enablement status of Copilot secret scanning (default: disabled)
- `secret_scanning_delegated_alert_dismissal` (string, optional): The enablement status of secret scanning delegated alert dismissal (default: disabled)
- `secret_scanning_extended_metadata` (string, optional): The enablement status of secret scanning extended metadata (default: disabled)
- `private_vulnerability_reporting` (string, optional): The enablement status of private vulnerability reporting (default: disabled)
- `enforcement` (string, optional): The enforcement status for a security configuration (default: enforced)
### code_security_get_configurations_for_enterprise

GET /enterprises/{enterprise}/code-security/configurations - Get code security configurations for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
### get_enterprises_by_enterprise_code_security_configurations_defaults

GET /enterprises/{enterprise}/code-security/configurations/defaults - Get default code security configurations for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
### code_security_update_enterprise_configuration

PATCH /enterprises/{enterprise}/code-security/configurations/{configuration_id} - Update a custom code security configuration for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `configuration_id` (integer): The unique identifier of the code security configuration.
- `name` (string, optional): The name of the code security configuration. Must be unique across the enterprise.
- `description` (string, optional): A description of the code security configuration
- `advanced_security` (string, optional): The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features.

> [!WARNING]
> `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features.

- `code_security` (string, optional): The enablement status of GitHub Code Security features.
- `dependency_graph` (string, optional): The enablement status of Dependency Graph
- `dependency_graph_autosubmit_action` (string, optional): The enablement status of Automatic dependency submission
- `dependency_graph_autosubmit_action_options` (object, optional): Feature options for Automatic dependency submission
- `dependabot_alerts` (string, optional): The enablement status of Dependabot alerts
- `dependabot_security_updates` (string, optional): The enablement status of Dependabot security updates
- `code_scanning_default_setup` (string, optional): The enablement status of code scanning default setup
- `code_scanning_default_setup_options` (object, optional): 
- `code_scanning_options` (object, optional): 
- `code_scanning_delegated_alert_dismissal` (string, optional): The enablement status of code scanning delegated alert dismissal (default: disabled)
- `secret_protection` (string, optional): The enablement status of GitHub Secret Protection features.
- `secret_scanning` (string, optional): The enablement status of secret scanning
- `secret_scanning_push_protection` (string, optional): The enablement status of secret scanning push protection
- `secret_scanning_validity_checks` (string, optional): The enablement status of secret scanning validity checks
- `secret_scanning_non_provider_patterns` (string, optional): The enablement status of secret scanning non-provider patterns
- `secret_scanning_generic_secrets` (string, optional): The enablement status of Copilot secret scanning (default: disabled)
- `secret_scanning_delegated_alert_dismissal` (string, optional): The enablement status of secret scanning delegated alert dismissal (default: disabled)
- `secret_scanning_extended_metadata` (string, optional): The enablement status of secret scanning extended metadata (default: disabled)
- `private_vulnerability_reporting` (string, optional): The enablement status of private vulnerability reporting
- `enforcement` (string, optional): The enforcement status for a security configuration
### code_security_delete_configuration_for_enterprise

DELETE /enterprises/{enterprise}/code-security/configurations/{configuration_id} - Delete a code security configuration for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `configuration_id` (integer): The unique identifier of the code security configuration.
### get_enterprises_by_enterprise_code_security_configurations_by_configuration_id

GET /enterprises/{enterprise}/code-security/configurations/{configuration_id} - Retrieve a code security configuration of an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `configuration_id` (integer): The unique identifier of the code security configuration.
### code_security_attach_enterprise_configuration

POST /enterprises/{enterprise}/code-security/configurations/{configuration_id}/attach - Attach an enterprise configuration to repositories

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `configuration_id` (integer): The unique identifier of the code security configuration.
- `scope` (string): The type of repositories to attach the configuration to.
### put_enterprises_by_enterprise_code_security_configurations_by_configuration_id_defaults

PUT /enterprises/{enterprise}/code-security/configurations/{configuration_id}/defaults - Set a code security configuration as a default for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `configuration_id` (integer): The unique identifier of the code security configuration.
- `default_for_new_repos` (string, optional): Specify which types of repository this security configuration should be applied to by default.
### get_enterprises_by_enterprise_code_security_configurations_by_configuration_id_repositories

GET /enterprises/{enterprise}/code-security/configurations/{configuration_id}/repositories - Get repositories associated with an enterprise code security configuration

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `configuration_id` (integer): The unique identifier of the code security configuration.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `status` (string, optional): A comma-separated list of statuses. If specified, only repositories with these attachment statuses will be returned.

Can be: `all`, `attached`, `attaching`, `removed`, `enforced`, `failed`, `updating`, `removed_by_enterprise` (default: all)
### dependabot_list_alerts_for_enterprise

GET /enterprises/{enterprise}/dependabot/alerts - List Dependabot alerts for an enterprise

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `state` (string, optional): A comma-separated list of states. If specified, only alerts with these states will be returned.

Can be: `auto_dismissed`, `dismissed`, `fixed`, `open`
- `severity` (string, optional): A comma-separated list of severities. If specified, only alerts with these severities will be returned.

Can be: `low`, `medium`, `high`, `critical`
- `ecosystem` (string, optional): A comma-separated list of ecosystems. If specified, only alerts for these ecosystems will be returned.

Can be: `composer`, `go`, `maven`, `npm`, `nuget`, `pip`, `pub`, `rubygems`, `rust`
- `package` (string, optional): A comma-separated list of package names. If specified, only alerts for these packages will be returned.
- `epss_percentage` (string, optional): CVE Exploit Prediction Scoring System (EPSS) percentage. Can be specified as:
- An exact number (`n`)
- Comparators such as `>n`, `<n`, `>=n`, `<=n`
- A range like `n..n`, where `n` is a number from 0.0 to 1.0

Filters the list of alerts based on EPSS percentages. If specified, only alerts with the provided EPSS percentages will be returned.
- `has` (object, optional): Filters the list of alerts based on whether the alert has the given value. If specified, only alerts meeting this criterion will be returned.
Multiple `has` filters can be passed to filter for alerts that have all of the values. Currently, only `patch` is supported.
- `assignee` (string, optional): Filter alerts by assignees.
Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`) to return alerts assigned to any of the specified users.
Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees.
- `scope` (string, optional): The scope of the vulnerable dependency. If specified, only alerts with this scope will be returned. — one of: development, runtime
- `sort` (string, optional): The property by which to sort the results.
`created` means when the alert was created.
`updated` means when the alert's state last changed.
`epss_percentage` sorts alerts by the Exploit Prediction Scoring System (EPSS) percentage. (default: created) — one of: created, updated, epss_percentage
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### enterprise_teams_create

POST /enterprises/{enterprise}/teams - Create an enterprise team

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `name` (string): The name of the team.
- `description` (string, optional): A description of the team.
- `sync_to_organizations` (string, optional): Retired: this field is no longer supported.
Whether the enterprise team should be reflected in each organization.
This value cannot be set.
 (default: disabled)
- `organization_selection_type` (string, optional): Specifies which organizations in the enterprise should have access to this team. Can be one of `disabled`, `selected`, or `all`.
`disabled`: The team is not assigned to any organizations. This is the default when you create a new team.
`selected`: The team is assigned to specific organizations. You can then use the [add organization assignments API](https://docs.github.com/rest/enterprise-teams/enterprise-team-organizations#add-organization-assignments) endpoint.
`all`: The team is assigned to all current and future organizations in the enterprise.
 (default: disabled)
- `group_id` (string, optional): The ID of the IdP group to assign team membership with. You can get this value from the [REST API endpoints for SCIM](https://docs.github.com/rest/scim#list-provisioned-scim-groups-for-an-enterprise).
### enterprise_teams_list

GET /enterprises/{enterprise}/teams - List enterprise teams

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### enterprise_team_memberships_list

GET /enterprises/{enterprise}/teams/{enterprise-team}/memberships - List members in an enterprise team

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### enterprise_team_memberships_bulk_add

POST /enterprises/{enterprise}/teams/{enterprise-team}/memberships/add - Bulk add team members

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `usernames` (array): The GitHub user handles to add to the team.
### enterprise_team_memberships_bulk_remove

POST /enterprises/{enterprise}/teams/{enterprise-team}/memberships/remove - Bulk remove team members

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `usernames` (array): The GitHub user handles to be removed from the team.
### enterprise_team_memberships_remove

DELETE /enterprises/{enterprise}/teams/{enterprise-team}/memberships/{username} - Remove team membership

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `username` (string): The handle for the GitHub user account.
### enterprise_team_memberships_add

PUT /enterprises/{enterprise}/teams/{enterprise-team}/memberships/{username} - Add team member

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `username` (string): The handle for the GitHub user account.
### enterprise_team_memberships_get

GET /enterprises/{enterprise}/teams/{enterprise-team}/memberships/{username} - Get enterprise team membership

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `username` (string): The handle for the GitHub user account.
### enterprise_team_organizations_get_assignments

GET /enterprises/{enterprise}/teams/{enterprise-team}/organizations - Get organization assignments

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### enterprise_team_organizations_bulk_add

POST /enterprises/{enterprise}/teams/{enterprise-team}/organizations/add - Add organization assignments

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `organization_slugs` (array): Organization slug to assign the team to.
### enterprise_team_organizations_bulk_remove

POST /enterprises/{enterprise}/teams/{enterprise-team}/organizations/remove - Remove organization assignments

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `organization_slugs` (array): Organization slug to unassign the team from.
### enterprise_team_organizations_delete

DELETE /enterprises/{enterprise}/teams/{enterprise-team}/organizations/{org} - Delete an organization assignment

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `org` (string): The organization name. The name is not case sensitive.
### enterprise_team_organizations_add

PUT /enterprises/{enterprise}/teams/{enterprise-team}/organizations/{org} - Add an organization assignment

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `org` (string): The organization name. The name is not case sensitive.
### enterprise_team_organizations_get_assignment

GET /enterprises/{enterprise}/teams/{enterprise-team}/organizations/{org} - Get organization assignment

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `enterprise-team` (string): The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
- `org` (string): The organization name. The name is not case sensitive.
### enterprise_teams_update

PATCH /enterprises/{enterprise}/teams/{team_slug} - Update an enterprise team

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `team_slug` (string): The slug of the team name.
- `name` (string, optional): A new name for the team.
- `description` (string, optional): A new description for the team.
- `sync_to_organizations` (string, optional): Retired: this field is no longer supported.
Whether the enterprise team should be reflected in each organization.
This value cannot be changed.
 (default: disabled)
- `organization_selection_type` (string, optional): Specifies which organizations in the enterprise should have access to this team. Can be one of `disabled`, `selected`, or `all`.
`disabled`: The team is not assigned to any organizations. This is the default when you create a new team.
`selected`: The team is assigned to specific organizations. You can then use the [add organization assignments API](https://docs.github.com/rest/enterprise-teams/enterprise-team-organizations#add-organization-assignments).
`all`: The team is assigned to all current and future organizations in the enterprise.
 (default: disabled)
- `group_id` (string, optional): The ID of the IdP group to assign team membership with. The new IdP group will replace the existing one, or replace existing direct members if the team isn't currently linked to an IdP group.
### enterprise_teams_delete

DELETE /enterprises/{enterprise}/teams/{team_slug} - Delete an enterprise team

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `team_slug` (string): The slug of the team name.
### enterprise_teams_get

GET /enterprises/{enterprise}/teams/{team_slug} - Get an enterprise team

Parameters:
- `enterprise` (string): The slug version of the enterprise name.
- `team_slug` (string): The slug of the team name.
### activity_list_public_events

GET /events - List public events

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 15)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_get_feeds

GET /feeds - Get feeds

### gists_create

POST /gists - Create a gist

Parameters:
- `description` (string, optional): Description of the gist
- `files` (object): Names and content for the files that make up the gist
- `public` (object, optional): 
### gists_list

GET /gists - List gists for the authenticated user

Parameters:
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### gists_list_public

GET /gists/public - List public gists

Parameters:
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### gists_list_starred

GET /gists/starred - List starred gists

Parameters:
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### gists_update

PATCH /gists/{gist_id} - Update a gist

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `description` (string, optional): The description of the gist.
- `files` (object, optional): The gist files to be updated, renamed, or deleted. Each `key` must match the current filename
(including extension) of the targeted gist file. For example: `hello.py`.

To delete a file, set the whole file to null. For example: `hello.py : null`. The file will also be
deleted if the specified object does not contain at least one of `content` or `filename`.
### gists_delete

DELETE /gists/{gist_id} - Delete a gist

Parameters:
- `gist_id` (string): The unique identifier of the gist.
### gists_get

GET /gists/{gist_id} - Get a gist

Parameters:
- `gist_id` (string): The unique identifier of the gist.
### gists_create_comment

POST /gists/{gist_id}/comments - Create a gist comment

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `body` (string): The comment text.
### gists_list_comments

GET /gists/{gist_id}/comments - List gist comments

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### gists_update_comment

PATCH /gists/{gist_id}/comments/{comment_id} - Update a gist comment

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `comment_id` (integer): The unique identifier of the comment.
- `body` (string): The comment text.
### gists_delete_comment

DELETE /gists/{gist_id}/comments/{comment_id} - Delete a gist comment

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `comment_id` (integer): The unique identifier of the comment.
### gists_get_comment

GET /gists/{gist_id}/comments/{comment_id} - Get a gist comment

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `comment_id` (integer): The unique identifier of the comment.
### gists_list_commits

GET /gists/{gist_id}/commits - List gist commits

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### gists_fork

POST /gists/{gist_id}/forks - Fork a gist

Parameters:
- `gist_id` (string): The unique identifier of the gist.
### gists_list_forks

GET /gists/{gist_id}/forks - List gist forks

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### gists_unstar

DELETE /gists/{gist_id}/star - Unstar a gist

Parameters:
- `gist_id` (string): The unique identifier of the gist.
### gists_star

PUT /gists/{gist_id}/star - Star a gist

Parameters:
- `gist_id` (string): The unique identifier of the gist.
### gists_check_is_starred

GET /gists/{gist_id}/star - Check if a gist is starred

Parameters:
- `gist_id` (string): The unique identifier of the gist.
### gists_get_revision

GET /gists/{gist_id}/{sha} - Get a gist revision

Parameters:
- `gist_id` (string): The unique identifier of the gist.
- `sha` (string): 
### gitignore_get_all_templates

GET /gitignore/templates - Get all gitignore templates

### gitignore_get_template

GET /gitignore/templates/{name} - Get a gitignore template

Parameters:
- `name` (string): 
### apps_list_repos_accessible_to_installation

GET /installation/repositories - List repositories accessible to the app installation

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### apps_revoke_installation_access_token

DELETE /installation/token - Revoke an installation access token

### issues_list

GET /issues - List issues assigned to the authenticated user

Parameters:
- `filter` (string, optional): Indicates which sorts of issues to return. `assigned` means issues assigned to you. `created` means issues created by you. `mentioned` means issues mentioning you. `subscribed` means issues you're subscribed to updates for. `all` or `repos` means all issues you can see, regardless of participation or creation. (default: assigned) — one of: assigned, created, mentioned, subscribed, repos, all
- `state` (string, optional): Indicates the state of the issues to return. (default: open) — one of: open, closed, all
- `labels` (string, optional): A list of comma separated label names. Example: `bug,ui,@high`
- `sort` (string, optional): What to sort results by. (default: created) — one of: created, updated, comments
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `collab` (boolean, optional): 
- `orgs` (boolean, optional): 
- `owned` (boolean, optional): 
- `pulls` (boolean, optional): 
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### licenses_get_all_commonly_used

GET /licenses - Get all commonly used licenses

Parameters:
- `featured` (boolean, optional): 
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### licenses_get

GET /licenses/{license} - Get a license

Parameters:
- `license` (string): 
### markdown_render

POST /markdown - Render a Markdown document

Parameters:
- `text` (string): The Markdown text to render in HTML.
- `mode` (string, optional): The rendering mode. (default: markdown)
- `context` (string, optional): The repository context to use when creating references in `gfm` mode.  For example, setting `context` to `octo-org/octo-repo` will change the text `#42` into an HTML link to issue 42 in the `octo-org/octo-repo` repository.
### markdown_render_raw

POST /markdown/raw - Render a Markdown document in raw mode

### apps_get_subscription_plan_for_account

GET /marketplace_listing/accounts/{account_id} - Get a subscription plan for an account

Parameters:
- `account_id` (integer): account_id parameter
### apps_list_plans

GET /marketplace_listing/plans - List plans

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### apps_list_accounts_for_plan

GET /marketplace_listing/plans/{plan_id}/accounts - List accounts for a plan

Parameters:
- `plan_id` (integer): The unique identifier of the plan.
- `sort` (string, optional): The property to sort the results by. (default: created) — one of: created, updated
- `direction` (string, optional): To return the oldest accounts first, set to `asc`. Ignored without the `sort` parameter. — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### apps_get_subscription_plan_for_account_stubbed

GET /marketplace_listing/stubbed/accounts/{account_id} - Get a subscription plan for an account (stubbed)

Parameters:
- `account_id` (integer): account_id parameter
### apps_list_plans_stubbed

GET /marketplace_listing/stubbed/plans - List plans (stubbed)

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### apps_list_accounts_for_plan_stubbed

GET /marketplace_listing/stubbed/plans/{plan_id}/accounts - List accounts for a plan (stubbed)

Parameters:
- `plan_id` (integer): The unique identifier of the plan.
- `sort` (string, optional): The property to sort the results by. (default: created) — one of: created, updated
- `direction` (string, optional): To return the oldest accounts first, set to `asc`. Ignored without the `sort` parameter. — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### meta_get

GET /meta - Get GitHub meta information

### activity_list_public_events_for_repo_network

GET /networks/{owner}/{repo}/events - List public events for a network of repositories

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_mark_notifications_as_read

PUT /notifications - Mark notifications as read

Parameters:
- `last_read_at` (string, optional): Describes the last point that notifications were checked. Anything updated since this time will not be marked as read. If you omit this parameter, all notifications are marked as read. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Default: The current timestamp.
- `read` (boolean, optional): Whether the notification has been read.
### get_notifications

GET /notifications - List notifications for the authenticated user

Parameters:
- `all` (boolean, optional): If `true`, show notifications marked as read. (default: False)
- `participating` (boolean, optional): If `true`, only shows notifications in which the user is directly participating or mentioned. (default: False)
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `before` (string, optional): Only show notifications updated before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 50). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 50)
### activity_mark_thread_as_read

PATCH /notifications/threads/{thread_id} - Mark a thread as read

Parameters:
- `thread_id` (integer): The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)).
### activity_mark_thread_as_done

DELETE /notifications/threads/{thread_id} - Mark a thread as done

Parameters:
- `thread_id` (integer): The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)).
### activity_get_thread

GET /notifications/threads/{thread_id} - Get a thread

Parameters:
- `thread_id` (integer): The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)).
### activity_delete_thread_subscription

DELETE /notifications/threads/{thread_id}/subscription - Delete a thread subscription

Parameters:
- `thread_id` (integer): The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)).
### activity_set_thread_subscription

PUT /notifications/threads/{thread_id}/subscription - Set a thread subscription

Parameters:
- `thread_id` (integer): The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)).
- `ignored` (boolean, optional): Whether to block all notifications from a thread. (default: False)
### get_notifications_threads_by_thread_id_subscription

GET /notifications/threads/{thread_id}/subscription - Get a thread subscription for the authenticated user

Parameters:
- `thread_id` (integer): The unique identifier of the notification thread. This corresponds to the value returned in the `id` field when you retrieve notifications (for example with the [`GET /notifications` operation](https://docs.github.com/rest/activity/notifications#list-notifications-for-the-authenticated-user)).
### meta_get_octocat

GET /octocat - Get Octocat

Parameters:
- `s` (string, optional): The words to show in Octocat's speech bubble
### orgs_list

GET /organizations - List organizations

Parameters:
- `since` (integer, optional): An organization ID. Only return organizations with an ID greater than this ID.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### put_organizations_by_org_actions_cache_retention_limit

PUT /organizations/{org}/actions/cache/retention-limit - Set GitHub Actions cache retention limit for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `max_cache_retention_days` (integer, optional): For repositories in this organization, the maximum duration, in days, for which caches in a repository may be retained.
### get_organizations_by_org_actions_cache_retention_limit

GET /organizations/{org}/actions/cache/retention-limit - Get GitHub Actions cache retention limit for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### put_organizations_by_org_actions_cache_storage_limit

PUT /organizations/{org}/actions/cache/storage-limit - Set GitHub Actions cache storage limit for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `max_cache_size_gb` (integer, optional): For repositories in the organization, the maximum size limit for the sum of all caches in a repository, in gigabytes.
### get_organizations_by_org_actions_cache_storage_limit

GET /organizations/{org}/actions/cache/storage-limit - Get GitHub Actions cache storage limit for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### dependabot_update_repository_access_for_org

PATCH /organizations/{org}/dependabot/repository-access - Updates Dependabot's repository access list for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `repository_ids_to_add` (array, optional): List of repository IDs to add.
- `repository_ids_to_remove` (array, optional): List of repository IDs to remove.
### dependabot_repository_access_for_org

GET /organizations/{org}/dependabot/repository-access - Lists the repositories Dependabot can access in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `page` (integer, optional): The page number of results to fetch. (default: 1)
- `per_page` (integer, optional): Number of results per page. (default: 30)
### dependabot_set_repository_access_default_level

PUT /organizations/{org}/dependabot/repository-access/default-level - Set the default repository access level for Dependabot

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `default_level` (string): The default repository access level for Dependabot updates.
### billing_get_all_budgets_org

GET /organizations/{org}/settings/billing/budgets - Get all budgets for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. (default: 1)
- `per_page` (integer, optional): The number of results per page (max 10). (default: 10)
- `scope` (string, optional): Filter budgets by scope type. — one of: enterprise, organization, repository, cost_center
### billing_update_budget_org

PATCH /organizations/{org}/settings/billing/budgets/{budget_id} - Update a budget for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `budget_id` (string): The ID corresponding to the budget.
- `budget_amount` (integer, optional): The budget amount in whole dollars. For license-based products, this represents the number of licenses.
- `prevent_further_usage` (boolean, optional): Whether to prevent additional spending once the budget is exceeded
- `budget_alerting` (object, optional): 
- `budget_scope` (string, optional): The scope of the budget
- `budget_entity_name` (string, optional): The name of the entity to apply the budget to
- `budget_type` (object, optional): The type of pricing for the budget
- `budget_product_sku` (string, optional): A single product or SKU that will be covered in the budget
### billing_delete_budget_org

DELETE /organizations/{org}/settings/billing/budgets/{budget_id} - Delete a budget for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `budget_id` (string): The ID corresponding to the budget.
### billing_get_budget_org

GET /organizations/{org}/settings/billing/budgets/{budget_id} - Get a budget by ID for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `budget_id` (string): The ID corresponding to the budget.
### get_organizations_by_org_settings_billing_premium_request_usage

GET /organizations/{org}/settings/billing/premium_request/usage - Get billing premium request usage report for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `year` (integer, optional): If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
- `month` (integer, optional): If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used.
- `day` (integer, optional): If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
- `user` (string, optional): The user name to query usage for. The name is not case sensitive.
- `model` (string, optional): The model name to query usage for. The name is not case sensitive.
- `product` (string, optional): The product name to query usage for. The name is not case sensitive.
### billing_get_github_billing_usage_report_org

GET /organizations/{org}/settings/billing/usage - Get billing usage report for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `year` (integer, optional): If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
- `month` (integer, optional): If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. If no year is specified the default `year` is used.
- `day` (integer, optional): If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
### get_organizations_by_org_settings_billing_usage_summary

GET /organizations/{org}/settings/billing/usage/summary - Get billing usage summary for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `year` (integer, optional): If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
- `month` (integer, optional): If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used.
- `day` (integer, optional): If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
- `repository` (string, optional): The repository name to query for usage in the format owner/repository.
- `product` (string, optional): The product name to query usage for. The name is not case sensitive.
- `sku` (string, optional): The SKU to query for usage.
### orgs_update

PATCH /orgs/{org} - Update an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `billing_email` (string, optional): Billing email address. This address is not publicized.
- `company` (string, optional): The company name.
- `email` (string, optional): The publicly visible email address.
- `twitter_username` (string, optional): The Twitter username of the company.
- `location` (string, optional): The location.
- `name` (string, optional): The shorthand name of the company.
- `description` (string, optional): The description of the company. The maximum size is 160 characters.
- `has_organization_projects` (boolean, optional): Whether an organization can use organization projects.
- `has_repository_projects` (boolean, optional): Whether repositories that belong to the organization can use repository projects.
- `default_repository_permission` (string, optional): Default permission level members have for organization repositories. (default: read)
- `members_can_create_repositories` (boolean, optional): Whether of non-admin organization members can create repositories. **Note:** A parameter can override this parameter. See `members_allowed_repository_creation_type` in this table for details. (default: True)
- `members_can_create_internal_repositories` (boolean, optional): Whether organization members can create internal repositories, which are visible to all enterprise members. You can only allow members to create internal repositories if your organization is associated with an enterprise account using GitHub Enterprise Cloud or GitHub Enterprise Server 2.20+. For more information, see "[Restricting repository creation in your organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/restricting-repository-creation-in-your-organization)" in the GitHub Help documentation.
- `members_can_create_private_repositories` (boolean, optional): Whether organization members can create private repositories, which are visible to organization members with permission. For more information, see "[Restricting repository creation in your organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/restricting-repository-creation-in-your-organization)" in the GitHub Help documentation.
- `members_can_create_public_repositories` (boolean, optional): Whether organization members can create public repositories, which are visible to anyone. For more information, see "[Restricting repository creation in your organization](https://docs.github.com/github/setting-up-and-managing-organizations-and-teams/restricting-repository-creation-in-your-organization)" in the GitHub Help documentation.
- `members_allowed_repository_creation_type` (string, optional): Specifies which types of repositories non-admin organization members can create. `private` is only available to repositories that are part of an organization on GitHub Enterprise Cloud. 
**Note:** This parameter is closing down and will be removed in the future. Its return value ignores internal repositories. Using this parameter overrides values set in `members_can_create_repositories`. See the parameter deprecation notice in the operation description for details.
- `members_can_create_pages` (boolean, optional): Whether organization members can create GitHub Pages sites. Existing published sites will not be impacted. (default: True)
- `members_can_create_public_pages` (boolean, optional): Whether organization members can create public GitHub Pages sites. Existing published sites will not be impacted. (default: True)
- `members_can_create_private_pages` (boolean, optional): Whether organization members can create private GitHub Pages sites. Existing published sites will not be impacted. (default: True)
- `members_can_fork_private_repositories` (boolean, optional): Whether organization members can fork private organization repositories. (default: False)
- `web_commit_signoff_required` (boolean, optional): Whether contributors to organization repositories are required to sign off on commits they make through GitHub's web interface. (default: False)
- `blog` (string, optional): 
- `advanced_security_enabled_for_new_repositories` (boolean, optional): **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead.

Whether GitHub Advanced Security is automatically enabled for new repositories and repositories transferred to this organization.

To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."

You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
- `dependabot_alerts_enabled_for_new_repositories` (boolean, optional): **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead.

Whether Dependabot alerts are automatically enabled for new repositories and repositories transferred to this organization.

To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."

You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
- `dependabot_security_updates_enabled_for_new_repositories` (boolean, optional): **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead.

Whether Dependabot security updates are automatically enabled for new repositories and repositories transferred to this organization.

To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."

You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
- `dependency_graph_enabled_for_new_repositories` (boolean, optional): **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead.

Whether dependency graph is automatically enabled for new repositories and repositories transferred to this organization.

To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."

You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
- `secret_scanning_enabled_for_new_repositories` (boolean, optional): **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead.

Whether secret scanning is automatically enabled for new repositories and repositories transferred to this organization.

To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."

You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
- `secret_scanning_push_protection_enabled_for_new_repositories` (boolean, optional): **Endpoint closing down notice.** Please use [code security configurations](https://docs.github.com/rest/code-security/configurations) instead.

Whether secret scanning push protection is automatically enabled for new repositories and repositories transferred to this organization.

To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."

You can check which security and analysis features are currently enabled by using a `GET /orgs/{org}` request.
- `secret_scanning_push_protection_custom_link_enabled` (boolean, optional): Whether a custom link is shown to contributors who are blocked from pushing a secret by push protection.
- `secret_scanning_push_protection_custom_link` (string, optional): If `secret_scanning_push_protection_custom_link_enabled` is true, the URL that will be displayed to contributors who are blocked from pushing a secret.
- `deploy_keys_enabled_for_repositories` (boolean, optional): Controls whether or not deploy keys may be added and used for repositories in the organization.
### orgs_delete

DELETE /orgs/{org} - Delete an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### orgs_get

GET /orgs/{org} - Get an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_get_actions_cache_usage_for_org

GET /orgs/{org}/actions/cache/usage - Get GitHub Actions cache usage for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_get_actions_cache_usage_by_repo_for_org

GET /orgs/{org}/actions/cache/usage-by-repository - List repositories with GitHub Actions cache usage for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_create_hosted_runner_for_org

POST /orgs/{org}/actions/hosted-runners - Create a GitHub-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): Name of the runner. Must be between 1 and 64 characters and may only contain upper and lowercase letters a-z, numbers 0-9, '.', '-', and '_'.
- `image` (object): The image of runner. To list all available images, use `GET /actions/hosted-runners/images/github-owned` or `GET /actions/hosted-runners/images/partner`.
- `size` (string): The machine size of the runner. To list available sizes, use `GET actions/hosted-runners/machine-sizes`
- `runner_group_id` (integer): The existing runner group to add this runner to.
- `maximum_runners` (integer, optional): The maximum amount of runners to scale up to. Runners will not auto-scale above this number. Use this setting to limit your cost.
- `enable_static_ip` (boolean, optional): Whether this runner should be created with a static public IP. Note limit on account. To list limits on account, use `GET actions/hosted-runners/limits`
- `image_gen` (boolean, optional): Whether this runner should be used to generate custom images. (default: False)
### actions_list_hosted_runners_for_org

GET /orgs/{org}/actions/hosted-runners - List GitHub-hosted runners for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_list_custom_images_for_org

GET /orgs/{org}/actions/hosted-runners/images/custom - List custom images for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_delete_custom_image_from_org

DELETE /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id} - Delete a custom image from the organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `image_definition_id` (integer): Image definition ID of custom image
### actions_get_custom_image_for_org

GET /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id} - Get a custom image definition for GitHub Actions Hosted Runners

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `image_definition_id` (integer): Image definition ID of custom image
### actions_list_custom_image_versions_for_org

GET /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id}/versions - List image versions of a custom image for an organization

Parameters:
- `image_definition_id` (integer): Image definition ID of custom image
- `org` (string): The organization name. The name is not case sensitive.
### actions_delete_custom_image_version_from_org

DELETE /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id}/versions/{version} - Delete an image version of custom image from the organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `image_definition_id` (integer): Image definition ID of custom image
- `version` (string): Version of a custom image
### actions_get_custom_image_version_for_org

GET /orgs/{org}/actions/hosted-runners/images/custom/{image_definition_id}/versions/{version} - Get an image version of a custom image for GitHub Actions Hosted Runners

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `image_definition_id` (integer): Image definition ID of custom image
- `version` (string): Version of a custom image
### get_orgs_by_org_actions_hosted_runners_images_github_owned

GET /orgs/{org}/actions/hosted-runners/images/github-owned - Get GitHub-owned images for GitHub-hosted runners in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_get_hosted_runners_partner_images_for_org

GET /orgs/{org}/actions/hosted-runners/images/partner - Get partner images for GitHub-hosted runners in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_get_hosted_runners_limits_for_org

GET /orgs/{org}/actions/hosted-runners/limits - Get limits on GitHub-hosted runners for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_get_hosted_runners_machine_specs_for_org

GET /orgs/{org}/actions/hosted-runners/machine-sizes - Get GitHub-hosted runners machine specs for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_get_hosted_runners_platforms_for_org

GET /orgs/{org}/actions/hosted-runners/platforms - Get platforms for GitHub-hosted runners in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_update_hosted_runner_for_org

PATCH /orgs/{org}/actions/hosted-runners/{hosted_runner_id} - Update a GitHub-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hosted_runner_id` (integer): Unique identifier of the GitHub-hosted runner.
- `name` (string, optional): Name of the runner. Must be between 1 and 64 characters and may only contain upper and lowercase letters a-z, numbers 0-9, '.', '-', and '_'.
- `runner_group_id` (integer, optional): The existing runner group to add this runner to.
- `maximum_runners` (integer, optional): The maximum amount of runners to scale up to. Runners will not auto-scale above this number. Use this setting to limit your cost.
- `enable_static_ip` (boolean, optional): Whether this runner should be updated with a static public IP. Note limit on account. To list limits on account, use `GET actions/hosted-runners/limits`
- `size` (string, optional): The machine size of the runner. To list available sizes, use `GET actions/hosted-runners/machine-sizes`
- `image_id` (string, optional): The unique identifier of the runner image. To list available images, use `GET /actions/hosted-runners/images/github-owned`, `GET /actions/hosted-runners/images/partner`, or `GET /actions/hosted-runners/images/custom`.
- `image_version` (string, optional): The version of the runner image to deploy. This is relevant only for runners using custom images.
### actions_delete_hosted_runner_for_org

DELETE /orgs/{org}/actions/hosted-runners/{hosted_runner_id} - Delete a GitHub-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hosted_runner_id` (integer): Unique identifier of the GitHub-hosted runner.
### actions_get_hosted_runner_for_org

GET /orgs/{org}/actions/hosted-runners/{hosted_runner_id} - Get a GitHub-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hosted_runner_id` (integer): Unique identifier of the GitHub-hosted runner.
### post_orgs_by_org_actions_oidc_customization_properties_repo

POST /orgs/{org}/actions/oidc/customization/properties/repo - Create an OIDC custom property inclusion for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `custom_property_name` (string): The name of the custom property to include in the OIDC token
### oidc_list_oidc_custom_property_inclusions_for_org

GET /orgs/{org}/actions/oidc/customization/properties/repo - List OIDC custom property inclusions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### delete_orgs_by_org_actions_oidc_customization_properties_repo_by_custom_property_name

DELETE /orgs/{org}/actions/oidc/customization/properties/repo/{custom_property_name} - Delete an OIDC custom property inclusion for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `custom_property_name` (string): The name of the custom property to remove from OIDC token inclusion
### oidc_update_oidc_custom_sub_template_for_org

PUT /orgs/{org}/actions/oidc/customization/sub - Set the customization template for an OIDC subject claim for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `include_claim_keys` (array): Array of unique strings. Each claim key can only contain alphanumeric characters and underscores.
### oidc_get_oidc_custom_sub_template_for_org

GET /orgs/{org}/actions/oidc/customization/sub - Get the customization template for an OIDC subject claim for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### put_orgs_by_org_actions_permissions

PUT /orgs/{org}/actions/permissions - Set GitHub Actions permissions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `enabled_repositories` (string): 
- `allowed_actions` (string, optional): 
- `sha_pinning_required` (boolean, optional): 
### get_orgs_by_org_actions_permissions

GET /orgs/{org}/actions/permissions - Get GitHub Actions permissions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### put_orgs_by_org_actions_permissions_artifact_and_log_retention

PUT /orgs/{org}/actions/permissions/artifact-and-log-retention - Set artifact and log retention settings for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `days` (integer): The number of days to retain artifacts and logs
### get_orgs_by_org_actions_permissions_artifact_and_log_retention

GET /orgs/{org}/actions/permissions/artifact-and-log-retention - Get artifact and log retention settings for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### put_orgs_by_org_actions_permissions_fork_pr_contributor_approval

PUT /orgs/{org}/actions/permissions/fork-pr-contributor-approval - Set fork PR contributor approval permissions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `approval_policy` (string): The policy that controls when fork PR workflows require approval from a maintainer.
### get_orgs_by_org_actions_permissions_fork_pr_contributor_approval

GET /orgs/{org}/actions/permissions/fork-pr-contributor-approval - Get fork PR contributor approval permissions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### put_orgs_by_org_actions_permissions_fork_pr_workflows_private_repos

PUT /orgs/{org}/actions/permissions/fork-pr-workflows-private-repos - Set private repo fork PR workflow settings for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `run_workflows_from_fork_pull_requests` (boolean): Whether workflows triggered by pull requests from forks are allowed to run on private repositories.
- `send_write_tokens_to_workflows` (boolean, optional): Whether GitHub Actions can create pull requests or submit approving pull request reviews from a workflow triggered by a fork pull request.
- `send_secrets_and_variables` (boolean, optional): Whether to make secrets and variables available to workflows triggered by pull requests from forks.
- `require_approval_for_fork_pr_workflows` (boolean, optional): Whether workflows triggered by pull requests from forks require approval from a repository administrator to run.
### get_orgs_by_org_actions_permissions_fork_pr_workflows_private_repos

GET /orgs/{org}/actions/permissions/fork-pr-workflows-private-repos - Get private repo fork PR workflow settings for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### put_orgs_by_org_actions_permissions_repositories

PUT /orgs/{org}/actions/permissions/repositories - Set selected repositories enabled for GitHub Actions in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_repository_ids` (array): List of repository IDs to enable for GitHub Actions.
### get_orgs_by_org_actions_permissions_repositories

GET /orgs/{org}/actions/permissions/repositories - List selected repositories enabled for GitHub Actions in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### delete_orgs_by_org_actions_permissions_repositories_by_repository_id

DELETE /orgs/{org}/actions/permissions/repositories/{repository_id} - Disable a selected repository for GitHub Actions in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `repository_id` (integer): The unique identifier of the repository.
### put_orgs_by_org_actions_permissions_repositories_by_repository_id

PUT /orgs/{org}/actions/permissions/repositories/{repository_id} - Enable a selected repository for GitHub Actions in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `repository_id` (integer): The unique identifier of the repository.
### actions_set_allowed_actions_organization

PUT /orgs/{org}/actions/permissions/selected-actions - Set allowed actions and reusable workflows for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `github_owned_allowed` (boolean, optional): Whether GitHub-owned actions are allowed. For example, this includes the actions in the `actions` organization.
- `verified_allowed` (boolean, optional): Whether actions from GitHub Marketplace verified creators are allowed. Set to `true` to allow all actions by GitHub Marketplace verified creators.
- `patterns_allowed` (array, optional): Specifies a list of string-matching patterns to allow specific action(s) and reusable workflow(s). Wildcards, tags, and SHAs are allowed. For example, `monalisa/octocat@*`, `monalisa/octocat@v2`, `monalisa/*`.

> [!NOTE]
> The `patterns_allowed` setting only applies to public repositories.
### actions_get_allowed_actions_organization

GET /orgs/{org}/actions/permissions/selected-actions - Get allowed actions and reusable workflows for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### put_orgs_by_org_actions_permissions_self_hosted_runners

PUT /orgs/{org}/actions/permissions/self-hosted-runners - Set self-hosted runners settings for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `enabled_repositories` (string): The policy that controls whether self-hosted runners can be used in the organization
### get_orgs_by_org_actions_permissions_self_hosted_runners

GET /orgs/{org}/actions/permissions/self-hosted-runners - Get self-hosted runners settings for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### put_orgs_by_org_actions_permissions_self_hosted_runners_repositories

PUT /orgs/{org}/actions/permissions/self-hosted-runners/repositories - Set repositories allowed to use self-hosted runners in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_repository_ids` (array): IDs of repositories that can use repository-level self-hosted runners
### get_orgs_by_org_actions_permissions_self_hosted_runners_repositories

GET /orgs/{org}/actions/permissions/self-hosted-runners/repositories - List repositories allowed to use self-hosted runners in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### delete_orgs_by_org_actions_permissions_self_hosted_runners_repositories_by_repository_id

DELETE /orgs/{org}/actions/permissions/self-hosted-runners/repositories/{repository_id} - Remove a repository from the list of repositories allowed to use self-hosted runners in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `repository_id` (integer): The unique identifier of the repository.
### put_orgs_by_org_actions_permissions_self_hosted_runners_repositories_by_repository_id

PUT /orgs/{org}/actions/permissions/self-hosted-runners/repositories/{repository_id} - Add a repository to the list of repositories allowed to use self-hosted runners in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `repository_id` (integer): The unique identifier of the repository.
### put_orgs_by_org_actions_permissions_workflow

PUT /orgs/{org}/actions/permissions/workflow - Set default workflow permissions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `default_workflow_permissions` (string, optional): 
- `can_approve_pull_request_reviews` (boolean, optional): 
### get_orgs_by_org_actions_permissions_workflow

GET /orgs/{org}/actions/permissions/workflow - Get default workflow permissions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_create_self_hosted_runner_group_for_org

POST /orgs/{org}/actions/runner-groups - Create a self-hosted runner group for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): Name of the runner group.
- `visibility` (string, optional): Visibility of a runner group. You can select all repositories, select individual repositories, or limit access to private repositories. (default: all)
- `selected_repository_ids` (array, optional): List of repository IDs that can access the runner group.
- `runners` (array, optional): List of runner IDs to add to the runner group.
- `allows_public_repositories` (boolean, optional): Whether the runner group can be used by `public` repositories. (default: False)
- `restricted_to_workflows` (boolean, optional): If `true`, the runner group will be restricted to running only the workflows specified in the `selected_workflows` array. (default: False)
- `selected_workflows` (array, optional): List of workflows the runner group should be allowed to run. This setting will be ignored unless `restricted_to_workflows` is set to `true`.
- `network_configuration_id` (string, optional): The identifier of a hosted compute network configuration.
### actions_list_self_hosted_runner_groups_for_org

GET /orgs/{org}/actions/runner-groups - List self-hosted runner groups for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `visible_to_repository` (string, optional): Only return runner groups that are allowed to be used by this repository.
### actions_update_self_hosted_runner_group_for_org

PATCH /orgs/{org}/actions/runner-groups/{runner_group_id} - Update a self-hosted runner group for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `name` (string): Name of the runner group.
- `visibility` (string, optional): Visibility of a runner group. You can select all repositories, select individual repositories, or all private repositories.
- `allows_public_repositories` (boolean, optional): Whether the runner group can be used by `public` repositories. (default: False)
- `restricted_to_workflows` (boolean, optional): If `true`, the runner group will be restricted to running only the workflows specified in the `selected_workflows` array. (default: False)
- `selected_workflows` (array, optional): List of workflows the runner group should be allowed to run. This setting will be ignored unless `restricted_to_workflows` is set to `true`.
- `network_configuration_id` (string, optional): The identifier of a hosted compute network configuration.
### actions_delete_self_hosted_runner_group_from_org

DELETE /orgs/{org}/actions/runner-groups/{runner_group_id} - Delete a self-hosted runner group from an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
### actions_get_self_hosted_runner_group_for_org

GET /orgs/{org}/actions/runner-groups/{runner_group_id} - Get a self-hosted runner group for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
### get_orgs_by_org_actions_runner_groups_by_runner_group_id_hosted_runners

GET /orgs/{org}/actions/runner-groups/{runner_group_id}/hosted-runners - List GitHub-hosted runners in a group for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### put_orgs_by_org_actions_runner_groups_by_runner_group_id_repositories

PUT /orgs/{org}/actions/runner-groups/{runner_group_id}/repositories - Set repository access for a self-hosted runner group in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `selected_repository_ids` (array): List of repository IDs that can access the runner group.
### get_orgs_by_org_actions_runner_groups_by_runner_group_id_repositories

GET /orgs/{org}/actions/runner-groups/{runner_group_id}/repositories - List repository access to a self-hosted runner group in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### delete_orgs_by_org_actions_runner_groups_by_runner_group_id_repositories_by_repository_id

DELETE /orgs/{org}/actions/runner-groups/{runner_group_id}/repositories/{repository_id} - Remove repository access to a self-hosted runner group in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `repository_id` (integer): The unique identifier of the repository.
### put_orgs_by_org_actions_runner_groups_by_runner_group_id_repositories_by_repository_id

PUT /orgs/{org}/actions/runner-groups/{runner_group_id}/repositories/{repository_id} - Add repository access to a self-hosted runner group in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `repository_id` (integer): The unique identifier of the repository.
### actions_set_self_hosted_runners_in_group_for_org

PUT /orgs/{org}/actions/runner-groups/{runner_group_id}/runners - Set self-hosted runners in a group for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `runners` (array): List of runner IDs to add to the runner group.
### actions_list_self_hosted_runners_in_group_for_org

GET /orgs/{org}/actions/runner-groups/{runner_group_id}/runners - List self-hosted runners in a group for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### delete_orgs_by_org_actions_runner_groups_by_runner_group_id_runners_by_runner_id

DELETE /orgs/{org}/actions/runner-groups/{runner_group_id}/runners/{runner_id} - Remove a self-hosted runner from a group for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### actions_add_self_hosted_runner_to_group_for_org

PUT /orgs/{org}/actions/runner-groups/{runner_group_id}/runners/{runner_id} - Add a self-hosted runner to a group for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_group_id` (integer): Unique identifier of the self-hosted runner group.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### actions_list_self_hosted_runners_for_org

GET /orgs/{org}/actions/runners - List self-hosted runners for an organization

Parameters:
- `name` (string, optional): The name of a self-hosted runner.
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_list_runner_applications_for_org

GET /orgs/{org}/actions/runners/downloads - List runner applications for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_generate_runner_jitconfig_for_org

POST /orgs/{org}/actions/runners/generate-jitconfig - Create configuration for a just-in-time runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the new runner.
- `runner_group_id` (integer): The ID of the runner group to register the runner to.
- `labels` (array): The names of the custom labels to add to the runner. **Minimum items**: 1. **Maximum items**: 100.
- `work_folder` (string, optional): The working directory to be used for job execution, relative to the runner install directory. (default: _work)
### actions_create_registration_token_for_org

POST /orgs/{org}/actions/runners/registration-token - Create a registration token for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_create_remove_token_for_org

POST /orgs/{org}/actions/runners/remove-token - Create a remove token for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_delete_self_hosted_runner_from_org

DELETE /orgs/{org}/actions/runners/{runner_id} - Delete a self-hosted runner from an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### actions_get_self_hosted_runner_for_org

GET /orgs/{org}/actions/runners/{runner_id} - Get a self-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### post_orgs_by_org_actions_runners_by_runner_id_labels

POST /orgs/{org}/actions/runners/{runner_id}/labels - Add custom labels to a self-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
- `labels` (array): The names of the custom labels to add to the runner.
### delete_orgs_by_org_actions_runners_by_runner_id_labels

DELETE /orgs/{org}/actions/runners/{runner_id}/labels - Remove all custom labels from a self-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### put_orgs_by_org_actions_runners_by_runner_id_labels

PUT /orgs/{org}/actions/runners/{runner_id}/labels - Set custom labels for a self-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
- `labels` (array): The names of the custom labels to set for the runner. You can pass an empty array to remove all custom labels.
### get_orgs_by_org_actions_runners_by_runner_id_labels

GET /orgs/{org}/actions/runners/{runner_id}/labels - List labels for a self-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### delete_orgs_by_org_actions_runners_by_runner_id_labels_by_name

DELETE /orgs/{org}/actions/runners/{runner_id}/labels/{name} - Remove a custom label from a self-hosted runner for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
- `name` (string): The name of a self-hosted runner's custom label.
### actions_list_org_secrets

GET /orgs/{org}/actions/secrets - List organization secrets

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_get_org_public_key

GET /orgs/{org}/actions/secrets/public-key - Get an organization public key

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### actions_delete_org_secret

DELETE /orgs/{org}/actions/secrets/{secret_name} - Delete an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### actions_create_or_update_org_secret

PUT /orgs/{org}/actions/secrets/{secret_name} - Create or update an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `encrypted_value` (string): Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get an organization public key](https://docs.github.com/rest/actions/secrets#get-an-organization-public-key) endpoint.
- `key_id` (string): ID of the key you used to encrypt the secret.
- `visibility` (string): Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret.
- `selected_repository_ids` (array, optional): An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/actions/secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/actions/secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/actions/secrets#remove-selected-repository-from-an-organization-secret) endpoints.
### actions_get_org_secret

GET /orgs/{org}/actions/secrets/{secret_name} - Get an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### actions_set_selected_repos_for_org_secret

PUT /orgs/{org}/actions/secrets/{secret_name}/repositories - Set selected repositories for an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `selected_repository_ids` (array): An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Add selected repository to an organization secret](https://docs.github.com/rest/actions/secrets#add-selected-repository-to-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/actions/secrets#remove-selected-repository-from-an-organization-secret) endpoints.
### actions_list_selected_repos_for_org_secret

GET /orgs/{org}/actions/secrets/{secret_name}/repositories - List selected repositories for an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### actions_remove_selected_repo_from_org_secret

DELETE /orgs/{org}/actions/secrets/{secret_name}/repositories/{repository_id} - Remove selected repository from an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `repository_id` (integer): 
### actions_add_selected_repo_to_org_secret

PUT /orgs/{org}/actions/secrets/{secret_name}/repositories/{repository_id} - Add selected repository to an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `repository_id` (integer): 
### actions_create_org_variable

POST /orgs/{org}/actions/variables - Create an organization variable

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the variable.
- `value` (string): The value of the variable.
- `visibility` (string): The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable.
- `selected_repository_ids` (array, optional): An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`.
### actions_list_org_variables

GET /orgs/{org}/actions/variables - List organization variables

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 10)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_update_org_variable

PATCH /orgs/{org}/actions/variables/{name} - Update an organization variable

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the variable.
- `value` (string, optional): The value of the variable.
- `visibility` (string, optional): The type of repositories in the organization that can access the variable. `selected` means only the repositories specified by `selected_repository_ids` can access the variable.
- `selected_repository_ids` (array, optional): An array of repository ids that can access the organization variable. You can only provide a list of repository ids when the `visibility` is set to `selected`.
### actions_delete_org_variable

DELETE /orgs/{org}/actions/variables/{name} - Delete an organization variable

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the variable.
### actions_get_org_variable

GET /orgs/{org}/actions/variables/{name} - Get an organization variable

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the variable.
### actions_set_selected_repos_for_org_variable

PUT /orgs/{org}/actions/variables/{name}/repositories - Set selected repositories for an organization variable

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the variable.
- `selected_repository_ids` (array): The IDs of the repositories that can access the organization variable.
### actions_list_selected_repos_for_org_variable

GET /orgs/{org}/actions/variables/{name}/repositories - List selected repositories for an organization variable

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the variable.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### actions_remove_selected_repo_from_org_variable

DELETE /orgs/{org}/actions/variables/{name}/repositories/{repository_id} - Remove selected repository from an organization variable

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the variable.
- `repository_id` (integer): 
### actions_add_selected_repo_to_org_variable

PUT /orgs/{org}/actions/variables/{name}/repositories/{repository_id} - Add selected repository to an organization variable

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the variable.
- `repository_id` (integer): 
### orgs_create_artifact_deployment_record

POST /orgs/{org}/artifacts/metadata/deployment-record - Create an artifact deployment record

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the artifact.
- `digest` (string): The hex encoded digest of the artifact.
- `version` (string, optional): The artifact version.
- `status` (string): The status of the artifact. Can be either deployed or decommissioned.
- `logical_environment` (string): The stage of the deployment.
- `physical_environment` (string, optional): The physical region of the deployment.
- `cluster` (string, optional): The deployment cluster.
- `deployment_name` (string): The unique identifier for the deployment represented by the new record. To accommodate differing
containers and namespaces within a cluster, the following format is recommended:
{namespaceName}-{deploymentName}-{containerName}.

- `tags` (object, optional): The tags associated with the deployment.
- `runtime_risks` (array, optional): A list of runtime risks associated with the deployment.
- `github_repository` (string, optional): The name of the GitHub repository associated with the artifact. This should be used
when there are no provenance attestations available for the artifact. The repository
must belong to the organization specified in the path parameter.

If a provenance attestation is available for the artifact, the API will use
the repository information from the attestation instead of this parameter.
### orgs_set_cluster_deployment_records

POST /orgs/{org}/artifacts/metadata/deployment-record/cluster/{cluster} - Set cluster deployment records

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `cluster` (string): The cluster name.
- `logical_environment` (string): The stage of the deployment.
- `physical_environment` (string, optional): The physical region of the deployment.
- `deployments` (array): The list of deployments to record.
### orgs_create_artifact_storage_record

POST /orgs/{org}/artifacts/metadata/storage-record - Create artifact metadata storage record

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the artifact.
- `digest` (string): The digest of the artifact (algorithm:hex-encoded-digest).
- `version` (string, optional): The artifact version.
- `artifact_url` (string, optional): The URL where the artifact is stored.
- `path` (string, optional): The path of the artifact.
- `registry_url` (string): The base URL of the artifact registry.
- `repository` (string, optional): The repository name within the registry.
- `status` (string, optional): The status of the artifact (e.g., active, inactive). (default: active)
- `github_repository` (string, optional): The name of the GitHub repository associated with the artifact. This should be used
when there are no provenance attestations available for the artifact. The repository
must belong to the organization specified in the path parameter.

If a provenance attestation is available for the artifact, the API will use
the repository information from the attestation instead of this parameter.
### orgs_list_artifact_deployment_records

GET /orgs/{org}/artifacts/{subject_digest}/metadata/deployment-records - List artifact deployment records

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `subject_digest` (string): The SHA256 digest of the artifact, in the form `sha256:HEX_DIGEST`.
### orgs_list_artifact_storage_records

GET /orgs/{org}/artifacts/{subject_digest}/metadata/storage-records - List artifact storage records

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `subject_digest` (string): The parameter should be set to the attestation's subject's SHA256 digest, in the form `sha256:HEX_DIGEST`.
### orgs_list_attestations_bulk

POST /orgs/{org}/attestations/bulk-list - List attestations by bulk subject digests

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `org` (string): The organization name. The name is not case sensitive.
- `subject_digests` (array): List of subject digests to fetch attestations for.
- `predicate_type` (string, optional): Optional filter for fetching attestations with a given predicate type.
This option accepts `provenance`, `sbom`, `release`, or freeform text
for custom predicate types.
### orgs_delete_attestations_bulk

POST /orgs/{org}/attestations/delete-request - Delete attestations in bulk

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `body` (object): Request body
### orgs_delete_attestations_by_subject_digest

DELETE /orgs/{org}/attestations/digest/{subject_digest} - Delete attestations by subject digest

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `subject_digest` (string): Subject Digest
### orgs_list_attestation_repositories

GET /orgs/{org}/attestations/repositories - List attestation repositories

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `org` (string): The organization name. The name is not case sensitive.
- `predicate_type` (string, optional): Optional filter for fetching attestations with a given predicate type.
This option accepts `provenance`, `sbom`, `release`, or freeform text
for custom predicate types.
### orgs_delete_attestations_by_id

DELETE /orgs/{org}/attestations/{attestation_id} - Delete attestations by ID

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `attestation_id` (integer): Attestation ID
### orgs_list_attestations

GET /orgs/{org}/attestations/{subject_digest} - List attestations

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `org` (string): The organization name. The name is not case sensitive.
- `subject_digest` (string): The parameter should be set to the attestation's subject's SHA256 digest, in the form `sha256:HEX_DIGEST`.
- `predicate_type` (string, optional): Optional filter for fetching attestations with a given predicate type.
This option accepts `provenance`, `sbom`, `release`, or freeform text
for custom predicate types.
### orgs_list_blocked_users

GET /orgs/{org}/blocks - List users blocked by an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_unblock_user

DELETE /orgs/{org}/blocks/{username} - Unblock a user from an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### orgs_block_user

PUT /orgs/{org}/blocks/{username} - Block a user from an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### orgs_check_blocked_user

GET /orgs/{org}/blocks/{username} - Check if a user is blocked by an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### campaigns_create_campaign

POST /orgs/{org}/campaigns - Create a campaign for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the campaign
- `description` (string): A description for the campaign
- `managers` (array, optional): The logins of the users to set as the campaign managers. At this time, only a single manager can be supplied.
- `team_managers` (array, optional): The slugs of the teams to set as the campaign managers.
- `ends_at` (string): The end date and time of the campaign. The date must be in the future.
- `contact_link` (string, optional): The contact link of the campaign. Must be a URI.
- `code_scanning_alerts` (array, optional): The code scanning alerts to include in this campaign
- `generate_issues` (boolean, optional): If true, will automatically generate issues for the campaign. The default is false. (default: False)
### campaigns_list_org_campaigns

GET /orgs/{org}/campaigns - List campaigns for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `state` (string, optional): If specified, only campaigns with this state will be returned. — one of: open, closed
- `sort` (string, optional): The property by which to sort the results. (default: created) — one of: created, updated, ends_at, published
### campaigns_update_campaign

PATCH /orgs/{org}/campaigns/{campaign_number} - Update a campaign

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `campaign_number` (integer): The campaign number.
- `name` (string, optional): The name of the campaign
- `description` (string, optional): A description for the campaign
- `managers` (array, optional): The logins of the users to set as the campaign managers. At this time, only a single manager can be supplied.
- `team_managers` (array, optional): The slugs of the teams to set as the campaign managers.
- `ends_at` (string, optional): The end date and time of the campaign, in ISO 8601 format':' YYYY-MM-DDTHH:MM:SSZ.
- `contact_link` (string, optional): The contact link of the campaign. Must be a URI.
- `state` (string, optional): 
### campaigns_delete_campaign

DELETE /orgs/{org}/campaigns/{campaign_number} - Delete a campaign for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `campaign_number` (integer): The campaign number.
### campaigns_get_campaign_summary

GET /orgs/{org}/campaigns/{campaign_number} - Get a campaign for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `campaign_number` (integer): The campaign number.
### code_scanning_list_alerts_for_org

GET /orgs/{org}/code-scanning/alerts - List code scanning alerts for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `tool_name` (string, optional): The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both.
- `tool_guid` (string, optional): The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both.
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `state` (string, optional): If specified, only code scanning alerts with this state will be returned. — one of: open, closed, dismissed, fixed
- `sort` (string, optional): The property by which to sort the results. (default: created) — one of: created, updated
- `severity` (string, optional): If specified, only code scanning alerts with this severity will be returned. — one of: critical, high, medium, low, warning, note, error
- `assignees` (string, optional): Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`).
Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees.

### code_security_create_configuration

POST /orgs/{org}/code-security/configurations - Create a code security configuration

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the code security configuration. Must be unique within the organization.
- `description` (string): A description of the code security configuration
- `advanced_security` (string, optional): The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features.

> [!WARNING]
> `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features.
 (default: disabled)
- `code_security` (string, optional): The enablement status of GitHub Code Security features.
- `dependency_graph` (string, optional): The enablement status of Dependency Graph (default: enabled)
- `dependency_graph_autosubmit_action` (string, optional): The enablement status of Automatic dependency submission (default: disabled)
- `dependency_graph_autosubmit_action_options` (object, optional): Feature options for Automatic dependency submission
- `dependabot_alerts` (string, optional): The enablement status of Dependabot alerts (default: disabled)
- `dependabot_security_updates` (string, optional): The enablement status of Dependabot security updates (default: disabled)
- `dependabot_delegated_alert_dismissal` (string, optional): The enablement status of Dependabot delegated alert dismissal. Requires Dependabot alerts to be enabled. (default: disabled)
- `code_scanning_options` (object, optional): 
- `code_scanning_default_setup` (string, optional): The enablement status of code scanning default setup (default: disabled)
- `code_scanning_default_setup_options` (object, optional): 
- `code_scanning_delegated_alert_dismissal` (string, optional): The enablement status of code scanning delegated alert dismissal (default: not_set)
- `secret_protection` (string, optional): The enablement status of GitHub Secret Protection features.
- `secret_scanning` (string, optional): The enablement status of secret scanning (default: disabled)
- `secret_scanning_push_protection` (string, optional): The enablement status of secret scanning push protection (default: disabled)
- `secret_scanning_delegated_bypass` (string, optional): The enablement status of secret scanning delegated bypass (default: disabled)
- `secret_scanning_delegated_bypass_options` (object, optional): Feature options for secret scanning delegated bypass
- `secret_scanning_validity_checks` (string, optional): The enablement status of secret scanning validity checks (default: disabled)
- `secret_scanning_non_provider_patterns` (string, optional): The enablement status of secret scanning non provider patterns (default: disabled)
- `secret_scanning_generic_secrets` (string, optional): The enablement status of Copilot secret scanning (default: disabled)
- `secret_scanning_delegated_alert_dismissal` (string, optional): The enablement status of secret scanning delegated alert dismissal
- `secret_scanning_extended_metadata` (string, optional): The enablement status of secret scanning extended metadata
- `private_vulnerability_reporting` (string, optional): The enablement status of private vulnerability reporting (default: disabled)
- `enforcement` (string, optional): The enforcement status for a security configuration (default: enforced)
### code_security_get_configurations_for_org

GET /orgs/{org}/code-security/configurations - Get code security configurations for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `target_type` (string, optional): The target type of the code security configuration (default: all) — one of: global, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
### code_security_get_default_configurations

GET /orgs/{org}/code-security/configurations/defaults - Get default code security configurations

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### code_security_detach_configuration

DELETE /orgs/{org}/code-security/configurations/detach - Detach configurations from repositories

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_repository_ids` (array, optional): An array of repository IDs to detach from configurations. Up to 250 IDs can be provided.
### code_security_update_configuration

PATCH /orgs/{org}/code-security/configurations/{configuration_id} - Update a code security configuration

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `configuration_id` (integer): The unique identifier of the code security configuration.
- `name` (string, optional): The name of the code security configuration. Must be unique within the organization.
- `description` (string, optional): A description of the code security configuration
- `advanced_security` (string, optional): The enablement status of GitHub Advanced Security features. `enabled` will enable both Code Security and Secret Protection features.

> [!WARNING]
> `code_security` and `secret_protection` are deprecated values for this field. Prefer the individual `code_security` and `secret_protection` fields to set the status of these features.

- `code_security` (string, optional): The enablement status of GitHub Code Security features.
- `dependency_graph` (string, optional): The enablement status of Dependency Graph
- `dependency_graph_autosubmit_action` (string, optional): The enablement status of Automatic dependency submission
- `dependency_graph_autosubmit_action_options` (object, optional): Feature options for Automatic dependency submission
- `dependabot_alerts` (string, optional): The enablement status of Dependabot alerts
- `dependabot_security_updates` (string, optional): The enablement status of Dependabot security updates
- `dependabot_delegated_alert_dismissal` (string, optional): The enablement status of Dependabot delegated alert dismissal. Requires Dependabot alerts to be enabled.
- `code_scanning_default_setup` (string, optional): The enablement status of code scanning default setup
- `code_scanning_default_setup_options` (object, optional): 
- `code_scanning_options` (object, optional): 
- `code_scanning_delegated_alert_dismissal` (string, optional): The enablement status of code scanning delegated alert dismissal (default: disabled)
- `secret_protection` (string, optional): The enablement status of GitHub Secret Protection features.
- `secret_scanning` (string, optional): The enablement status of secret scanning
- `secret_scanning_push_protection` (string, optional): The enablement status of secret scanning push protection
- `secret_scanning_delegated_bypass` (string, optional): The enablement status of secret scanning delegated bypass
- `secret_scanning_delegated_bypass_options` (object, optional): Feature options for secret scanning delegated bypass
- `secret_scanning_validity_checks` (string, optional): The enablement status of secret scanning validity checks
- `secret_scanning_non_provider_patterns` (string, optional): The enablement status of secret scanning non-provider patterns
- `secret_scanning_generic_secrets` (string, optional): The enablement status of Copilot secret scanning
- `secret_scanning_delegated_alert_dismissal` (string, optional): The enablement status of secret scanning delegated alert dismissal
- `secret_scanning_extended_metadata` (string, optional): The enablement status of secret scanning extended metadata
- `private_vulnerability_reporting` (string, optional): The enablement status of private vulnerability reporting
- `enforcement` (string, optional): The enforcement status for a security configuration
### code_security_delete_configuration

DELETE /orgs/{org}/code-security/configurations/{configuration_id} - Delete a code security configuration

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `configuration_id` (integer): The unique identifier of the code security configuration.
### code_security_get_configuration

GET /orgs/{org}/code-security/configurations/{configuration_id} - Get a code security configuration

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `configuration_id` (integer): The unique identifier of the code security configuration.
### code_security_attach_configuration

POST /orgs/{org}/code-security/configurations/{configuration_id}/attach - Attach a configuration to repositories

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `configuration_id` (integer): The unique identifier of the code security configuration.
- `scope` (string): The type of repositories to attach the configuration to. `selected` means the configuration will be attached to only the repositories specified by `selected_repository_ids`
- `selected_repository_ids` (array, optional): An array of repository IDs to attach the configuration to. You can only provide a list of repository ids when the `scope` is set to `selected`.
### code_security_set_configuration_as_default

PUT /orgs/{org}/code-security/configurations/{configuration_id}/defaults - Set a code security configuration as a default for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `configuration_id` (integer): The unique identifier of the code security configuration.
- `default_for_new_repos` (string, optional): Specify which types of repository this security configuration should be applied to by default.
### code_security_get_repositories_for_configuration

GET /orgs/{org}/code-security/configurations/{configuration_id}/repositories - Get repositories associated with a code security configuration

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `configuration_id` (integer): The unique identifier of the code security configuration.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `status` (string, optional): A comma-separated list of statuses. If specified, only repositories with these attachment statuses will be returned.

Can be: `all`, `attached`, `attaching`, `detached`, `removed`, `enforced`, `failed`, `updating`, `removed_by_enterprise` (default: all)
### codespaces_list_in_organization

GET /orgs/{org}/codespaces - List codespaces for the organization

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `org` (string): The organization name. The name is not case sensitive.
### codespaces_set_codespaces_access

PUT /orgs/{org}/codespaces/access - Manage access control for organization codespaces

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `visibility` (string): Which users can access codespaces in the organization. `disabled` means that no users can access codespaces in the organization.
- `selected_usernames` (array, optional): The usernames of the organization members who should have access to codespaces in the organization. Required when `visibility` is `selected_members`. The provided list of usernames will replace any existing value.
### codespaces_set_codespaces_access_users

POST /orgs/{org}/codespaces/access/selected_users - Add users to Codespaces access for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_usernames` (array): The usernames of the organization members and outside collaborators whose codespaces should be billed to the organization.
### codespaces_delete_codespaces_access_users

DELETE /orgs/{org}/codespaces/access/selected_users - Remove users from Codespaces access for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_usernames` (array): The usernames of the organization members and outside collaborators whose codespaces should not be billed to the organization.
### codespaces_list_org_secrets

GET /orgs/{org}/codespaces/secrets - List organization secrets

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### codespaces_get_org_public_key

GET /orgs/{org}/codespaces/secrets/public-key - Get an organization public key

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### codespaces_delete_org_secret

DELETE /orgs/{org}/codespaces/secrets/{secret_name} - Delete an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### codespaces_create_or_update_org_secret

PUT /orgs/{org}/codespaces/secrets/{secret_name} - Create or update an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `encrypted_value` (string, optional): The value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get an organization public key](https://docs.github.com/rest/codespaces/organization-secrets#get-an-organization-public-key) endpoint.
- `key_id` (string, optional): The ID of the key you used to encrypt the secret.
- `visibility` (string): Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret.
- `selected_repository_ids` (array, optional): An array of repository IDs that can access the organization secret. You can only provide a list of repository IDs when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#remove-selected-repository-from-an-organization-secret) endpoints.
### codespaces_get_org_secret

GET /orgs/{org}/codespaces/secrets/{secret_name} - Get an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### codespaces_set_selected_repos_for_org_secret

PUT /orgs/{org}/codespaces/secrets/{secret_name}/repositories - Set selected repositories for an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `selected_repository_ids` (array): An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Set selected repositories for an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#set-selected-repositories-for-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/codespaces/organization-secrets#remove-selected-repository-from-an-organization-secret) endpoints.
### codespaces_list_selected_repos_for_org_secret

GET /orgs/{org}/codespaces/secrets/{secret_name}/repositories - List selected repositories for an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### codespaces_remove_selected_repo_from_org_secret

DELETE /orgs/{org}/codespaces/secrets/{secret_name}/repositories/{repository_id} - Remove selected repository from an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `repository_id` (integer): 
### codespaces_add_selected_repo_to_org_secret

PUT /orgs/{org}/codespaces/secrets/{secret_name}/repositories/{repository_id} - Add selected repository to an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `repository_id` (integer): 
### copilot_get_copilot_organization_details

GET /orgs/{org}/copilot/billing - Get Copilot seat information and settings for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### copilot_list_copilot_seats

GET /orgs/{org}/copilot/billing/seats - List all Copilot seat assignments for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 50)
### copilot_add_copilot_seats_for_teams

POST /orgs/{org}/copilot/billing/selected_teams - Add teams to the Copilot subscription for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_teams` (array): List of team names within the organization to which to grant access to GitHub Copilot.
### copilot_cancel_copilot_seat_assignment_for_teams

DELETE /orgs/{org}/copilot/billing/selected_teams - Remove teams from the Copilot subscription for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_teams` (array): The names of teams from which to revoke access to GitHub Copilot.
### copilot_add_copilot_seats_for_users

POST /orgs/{org}/copilot/billing/selected_users - Add users to the Copilot subscription for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_usernames` (array): The usernames of the organization members to be granted access to GitHub Copilot.
### copilot_cancel_copilot_seat_assignment_for_users

DELETE /orgs/{org}/copilot/billing/selected_users - Remove users from the Copilot subscription for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_usernames` (array): The usernames of the organization members for which to revoke access to GitHub Copilot.
### put_orgs_by_org_copilot_content_exclusion

PUT /orgs/{org}/copilot/content_exclusion - Set Copilot content exclusion rules for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `body` (object): The content exclusion rules to set
### get_orgs_by_org_copilot_content_exclusion

GET /orgs/{org}/copilot/content_exclusion - Get Copilot content exclusion rules for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### copilot_copilot_metrics_for_organization

GET /orgs/{org}/copilot/metrics - Get Copilot metrics for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `since` (string, optional): Show usage metrics since this date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format (`YYYY-MM-DDTHH:MM:SSZ`). Maximum value is 100 days ago.
- `until` (string, optional): Show usage metrics until this date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format (`YYYY-MM-DDTHH:MM:SSZ`) and should not preceed the `since` date if it is passed.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of days of metrics to display per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 100)
### dependabot_list_alerts_for_org

GET /orgs/{org}/dependabot/alerts - List Dependabot alerts for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `state` (string, optional): A comma-separated list of states. If specified, only alerts with these states will be returned.

Can be: `auto_dismissed`, `dismissed`, `fixed`, `open`
- `severity` (string, optional): A comma-separated list of severities. If specified, only alerts with these severities will be returned.

Can be: `low`, `medium`, `high`, `critical`
- `ecosystem` (string, optional): A comma-separated list of ecosystems. If specified, only alerts for these ecosystems will be returned.

Can be: `composer`, `go`, `maven`, `npm`, `nuget`, `pip`, `pub`, `rubygems`, `rust`
- `package` (string, optional): A comma-separated list of package names. If specified, only alerts for these packages will be returned.
- `epss_percentage` (string, optional): CVE Exploit Prediction Scoring System (EPSS) percentage. Can be specified as:
- An exact number (`n`)
- Comparators such as `>n`, `<n`, `>=n`, `<=n`
- A range like `n..n`, where `n` is a number from 0.0 to 1.0

Filters the list of alerts based on EPSS percentages. If specified, only alerts with the provided EPSS percentages will be returned.
- `artifact_registry_url` (string, optional): A comma-separated list of artifact registry URLs. If specified, only alerts for repositories with storage records matching these URLs will be returned.
- `artifact_registry` (string, optional): A comma-separated list of Artifact Registry name strings. If specified, only alerts for repositories with storage records matching these registries will be returned.

Can be: `jfrog-artifactory`
- `has` (object, optional): Filters the list of alerts based on whether the alert has the given value. If specified, only alerts meeting this criterion will be returned.
Multiple `has` filters can be passed to filter for alerts that have all of the values.
- `assignee` (string, optional): Filter alerts by assignees.
Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`) to return alerts assigned to any of the specified users.
Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees.
- `runtime_risk` (string, optional): A comma-separated list of runtime risk strings. If specified, only alerts for repositories with deployment records matching these risks will be returned.

Can be: `critical-resource`, `internet-exposed`, `sensitive-data`, `lateral-movement`
- `scope` (string, optional): The scope of the vulnerable dependency. If specified, only alerts with this scope will be returned. — one of: development, runtime
- `sort` (string, optional): The property by which to sort the results.
`created` means when the alert was created.
`updated` means when the alert's state last changed.
`epss_percentage` sorts alerts by the Exploit Prediction Scoring System (EPSS) percentage. (default: created) — one of: created, updated, epss_percentage
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### dependabot_list_org_secrets

GET /orgs/{org}/dependabot/secrets - List organization secrets

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### dependabot_get_org_public_key

GET /orgs/{org}/dependabot/secrets/public-key - Get an organization public key

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### dependabot_delete_org_secret

DELETE /orgs/{org}/dependabot/secrets/{secret_name} - Delete an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### dependabot_create_or_update_org_secret

PUT /orgs/{org}/dependabot/secrets/{secret_name} - Create or update an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `encrypted_value` (string, optional): Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get an organization public key](https://docs.github.com/rest/dependabot/secrets#get-an-organization-public-key) endpoint.
- `key_id` (string, optional): ID of the key you used to encrypt the secret.
- `visibility` (string): Which type of organization repositories have access to the organization secret. `selected` means only the repositories specified by `selected_repository_ids` can access the secret.
- `selected_repository_ids` (array, optional): An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can manage the list of selected repositories using the [List selected repositories for an organization secret](https://docs.github.com/rest/dependabot/secrets#list-selected-repositories-for-an-organization-secret), [Set selected repositories for an organization secret](https://docs.github.com/rest/dependabot/secrets#set-selected-repositories-for-an-organization-secret), and [Remove selected repository from an organization secret](https://docs.github.com/rest/dependabot/secrets#remove-selected-repository-from-an-organization-secret) endpoints.
### dependabot_get_org_secret

GET /orgs/{org}/dependabot/secrets/{secret_name} - Get an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### dependabot_set_selected_repos_for_org_secret

PUT /orgs/{org}/dependabot/secrets/{secret_name}/repositories - Set selected repositories for an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `selected_repository_ids` (array): An array of repository ids that can access the organization secret. You can only provide a list of repository ids when the `visibility` is set to `selected`. You can add and remove individual repositories using the [Set selected repositories for an organization secret](https://docs.github.com/rest/dependabot/secrets#set-selected-repositories-for-an-organization-secret) and [Remove selected repository from an organization secret](https://docs.github.com/rest/dependabot/secrets#remove-selected-repository-from-an-organization-secret) endpoints.
### dependabot_list_selected_repos_for_org_secret

GET /orgs/{org}/dependabot/secrets/{secret_name}/repositories - List selected repositories for an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### dependabot_remove_selected_repo_from_org_secret

DELETE /orgs/{org}/dependabot/secrets/{secret_name}/repositories/{repository_id} - Remove selected repository from an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `repository_id` (integer): 
### dependabot_add_selected_repo_to_org_secret

PUT /orgs/{org}/dependabot/secrets/{secret_name}/repositories/{repository_id} - Add selected repository to an organization secret

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `repository_id` (integer): 
### get_orgs_by_org_docker_conflicts

GET /orgs/{org}/docker/conflicts - Get list of conflicting packages during Docker migration for organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### activity_list_public_org_events

GET /orgs/{org}/events - List public organization events

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_list_failed_invitations

GET /orgs/{org}/failed_invitations - List failed organization invitations

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_create_webhook

POST /orgs/{org}/hooks - Create an organization webhook

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): Must be passed as "web".
- `config` (object): Key/value pairs to provide settings for this webhook.
- `events` (array, optional): Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. Set to `["*"]` to receive all possible events. (default: ['push'])
- `active` (boolean, optional): Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. (default: True)
### orgs_list_webhooks

GET /orgs/{org}/hooks - List organization webhooks

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_update_webhook

PATCH /orgs/{org}/hooks/{hook_id} - Update an organization webhook

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `config` (object, optional): Key/value pairs to provide settings for this webhook.
- `events` (array, optional): Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. (default: ['push'])
- `active` (boolean, optional): Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. (default: True)
- `name` (string, optional): 
### orgs_delete_webhook

DELETE /orgs/{org}/hooks/{hook_id} - Delete an organization webhook

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### orgs_get_webhook

GET /orgs/{org}/hooks/{hook_id} - Get an organization webhook

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### orgs_update_webhook_config_for_org

PATCH /orgs/{org}/hooks/{hook_id}/config - Update a webhook configuration for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `url` (string, optional): 
- `content_type` (string, optional): 
- `secret` (string, optional): 
- `insecure_ssl` (object, optional): 
### orgs_get_webhook_config_for_org

GET /orgs/{org}/hooks/{hook_id}/config - Get a webhook configuration for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### orgs_list_webhook_deliveries

GET /orgs/{org}/hooks/{hook_id}/deliveries - List deliveries for an organization webhook

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `cursor` (string, optional): Used for pagination: the starting delivery from which the page of deliveries is fetched. Refer to the `link` header for the next and previous page cursors.
### orgs_get_webhook_delivery

GET /orgs/{org}/hooks/{hook_id}/deliveries/{delivery_id} - Get a webhook delivery for an organization webhook

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `delivery_id` (integer): 
### orgs_redeliver_webhook_delivery

POST /orgs/{org}/hooks/{hook_id}/deliveries/{delivery_id}/attempts - Redeliver a delivery for an organization webhook

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `delivery_id` (integer): 
### orgs_ping_webhook

POST /orgs/{org}/hooks/{hook_id}/pings - Ping an organization webhook

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### api_insights_get_route_stats_by_actor

GET /orgs/{org}/insights/api/route-stats/{actor_type}/{actor_id} - Get route stats by actor

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `actor_type` (string): The type of the actor — one of: installation, classic_pat, fine_grained_pat, oauth_app, github_app_user_to_server
- `actor_id` (integer): The ID of the actor
- `min_timestamp` (string): The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `max_timestamp` (string, optional): The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `sort` (array, optional): The property to sort the results by.
- `api_route_substring` (string, optional): Providing a substring will filter results where the API route contains the substring. This is a case-insensitive search.
### api_insights_get_subject_stats

GET /orgs/{org}/insights/api/subject-stats - Get subject stats

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `min_timestamp` (string): The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `max_timestamp` (string, optional): The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `sort` (array, optional): The property to sort the results by.
- `subject_name_substring` (string, optional): Providing a substring will filter results where the subject name contains the substring. This is a case-insensitive search.
### api_insights_get_summary_stats

GET /orgs/{org}/insights/api/summary-stats - Get summary stats

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `min_timestamp` (string): The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `max_timestamp` (string, optional): The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
### api_insights_get_summary_stats_by_user

GET /orgs/{org}/insights/api/summary-stats/users/{user_id} - Get summary stats by user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `user_id` (string): The ID of the user to query for stats
- `min_timestamp` (string): The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `max_timestamp` (string, optional): The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
### api_insights_get_summary_stats_by_actor

GET /orgs/{org}/insights/api/summary-stats/{actor_type}/{actor_id} - Get summary stats by actor

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `min_timestamp` (string): The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `max_timestamp` (string, optional): The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `actor_type` (string): The type of the actor — one of: installation, classic_pat, fine_grained_pat, oauth_app, github_app_user_to_server
- `actor_id` (integer): The ID of the actor
### api_insights_get_time_stats

GET /orgs/{org}/insights/api/time-stats - Get time stats

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `min_timestamp` (string): The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `max_timestamp` (string, optional): The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `timestamp_increment` (string): The increment of time used to breakdown the query results (5m, 10m, 1h, etc.)
### api_insights_get_time_stats_by_user

GET /orgs/{org}/insights/api/time-stats/users/{user_id} - Get time stats by user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `user_id` (string): The ID of the user to query for stats
- `min_timestamp` (string): The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `max_timestamp` (string, optional): The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `timestamp_increment` (string): The increment of time used to breakdown the query results (5m, 10m, 1h, etc.)
### api_insights_get_time_stats_by_actor

GET /orgs/{org}/insights/api/time-stats/{actor_type}/{actor_id} - Get time stats by actor

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `actor_type` (string): The type of the actor — one of: installation, classic_pat, fine_grained_pat, oauth_app, github_app_user_to_server
- `actor_id` (integer): The ID of the actor
- `min_timestamp` (string): The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `max_timestamp` (string, optional): The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `timestamp_increment` (string): The increment of time used to breakdown the query results (5m, 10m, 1h, etc.)
### api_insights_get_user_stats

GET /orgs/{org}/insights/api/user-stats/{user_id} - Get user stats

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `user_id` (string): The ID of the user to query for stats
- `min_timestamp` (string): The minimum timestamp to query for stats. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `max_timestamp` (string, optional): The maximum timestamp to query for stats. Defaults to the time 30 days ago. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `sort` (array, optional): The property to sort the results by.
- `actor_name_substring` (string, optional): Providing a substring will filter results where the actor name contains the substring. This is a case-insensitive search.
### apps_get_org_installation

GET /orgs/{org}/installation - Get an organization installation for the authenticated app

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### orgs_list_app_installations

GET /orgs/{org}/installations - List app installations for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### interactions_remove_restrictions_for_org

DELETE /orgs/{org}/interaction-limits - Remove interaction restrictions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### interactions_set_restrictions_for_org

PUT /orgs/{org}/interaction-limits - Set interaction restrictions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `limit` (string): 
- `expiry` (string, optional): 
### interactions_get_restrictions_for_org

GET /orgs/{org}/interaction-limits - Get interaction restrictions for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### orgs_create_invitation

POST /orgs/{org}/invitations - Create an organization invitation

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `invitee_id` (integer, optional): **Required unless you provide `email`**. GitHub user ID for the person you are inviting.
- `email` (string, optional): **Required unless you provide `invitee_id`**. Email address of the person you are inviting, which can be an existing GitHub user.
- `role` (string, optional): The role for the new member. 
 * `admin` - Organization owners with full administrative rights to the organization and complete access to all repositories and teams.  
 * `direct_member` - Non-owner organization members with ability to see other members and join teams by invitation.  
 * `billing_manager` - Non-owner organization members with ability to manage the billing settings of your organization. 
 * `reinstate` - The previous role assigned to the invitee before they were removed from your organization. Can be one of the roles listed above. Only works if the invitee was previously part of your organization. (default: direct_member)
- `team_ids` (array, optional): Specify IDs for the teams you want to invite new members to.
### orgs_list_pending_invitations

GET /orgs/{org}/invitations - List pending organization invitations

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `role` (string, optional): Filter invitations by their member role. (default: all) — one of: all, admin, direct_member, billing_manager, hiring_manager
- `invitation_source` (string, optional): Filter invitations by their invitation source. (default: all) — one of: all, member, scim
### orgs_cancel_invitation

DELETE /orgs/{org}/invitations/{invitation_id} - Cancel an organization invitation

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `invitation_id` (integer): The unique identifier of the invitation.
### orgs_list_invitation_teams

GET /orgs/{org}/invitations/{invitation_id}/teams - List organization invitation teams

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `invitation_id` (integer): The unique identifier of the invitation.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_create_issue_field

POST /orgs/{org}/issue-fields - Create issue field for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): Name of the issue field.
- `description` (string, optional): Description of the issue field.
- `data_type` (string): The data type of the issue field.
- `visibility` (string, optional): The visibility of the issue field. Can be `organization_members_only` (visible only within the organization) or `all` (visible to all users who can see issues). Only used when the visibility settings feature is enabled. Defaults to `organization_members_only`.
- `options` (array, optional): Options for single select fields. Required when data_type is 'single_select'.
### orgs_list_issue_fields

GET /orgs/{org}/issue-fields - List issue fields for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### orgs_update_issue_field

PATCH /orgs/{org}/issue-fields/{issue_field_id} - Update issue field for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `issue_field_id` (integer): The unique identifier of the issue field.
- `name` (string, optional): Name of the issue field.
- `description` (string, optional): Description of the issue field.
- `visibility` (string, optional): The visibility of the issue field. Can be `organization_members_only` (visible only within the organization) or `all` (visible to all users who can see issues). Only used when the visibility settings feature is enabled.
- `options` (array, optional): Options for single select fields. Only applicable when updating single_select fields.
### orgs_delete_issue_field

DELETE /orgs/{org}/issue-fields/{issue_field_id} - Delete issue field for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `issue_field_id` (integer): The unique identifier of the issue field.
### orgs_create_issue_type

POST /orgs/{org}/issue-types - Create issue type for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): Name of the issue type.
- `is_enabled` (boolean): Whether or not the issue type is enabled at the organization level.
- `description` (string, optional): Description of the issue type.
- `color` (string, optional): Color for the issue type.
### orgs_list_issue_types

GET /orgs/{org}/issue-types - List issue types for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### orgs_delete_issue_type

DELETE /orgs/{org}/issue-types/{issue_type_id} - Delete issue type for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `issue_type_id` (integer): The unique identifier of the issue type.
### orgs_update_issue_type

PUT /orgs/{org}/issue-types/{issue_type_id} - Update issue type for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `issue_type_id` (integer): The unique identifier of the issue type.
- `name` (string): Name of the issue type.
- `is_enabled` (boolean): Whether or not the issue type is enabled at the organization level.
- `description` (string, optional): Description of the issue type.
- `color` (string, optional): Color for the issue type.
### issues_list_for_org

GET /orgs/{org}/issues - List organization issues assigned to the authenticated user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `filter` (string, optional): Indicates which sorts of issues to return. `assigned` means issues assigned to you. `created` means issues created by you. `mentioned` means issues mentioning you. `subscribed` means issues you're subscribed to updates for. `all` or `repos` means all issues you can see, regardless of participation or creation. (default: assigned) — one of: assigned, created, mentioned, subscribed, repos, all
- `state` (string, optional): Indicates the state of the issues to return. (default: open) — one of: open, closed, all
- `labels` (string, optional): A list of comma separated label names. Example: `bug,ui,@high`
- `type` (string, optional): Can be the name of an issue type.
- `sort` (string, optional): What to sort results by. (default: created) — one of: created, updated, comments
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_list_members

GET /orgs/{org}/members - List organization members

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `filter` (string, optional): Filter members returned in the list. `2fa_disabled` means that only members without [two-factor authentication](https://github.com/blog/1614-two-factor-authentication) enabled will be returned. `2fa_insecure` means that only members with [insecure 2FA methods](https://docs.github.com/organizations/keeping-your-organization-secure/managing-two-factor-authentication-for-your-organization/requiring-two-factor-authentication-in-your-organization#requiring-secure-methods-of-two-factor-authentication-in-your-organization) will be returned. These options are only available for organization owners. (default: all) — one of: 2fa_disabled, 2fa_insecure, all
- `role` (string, optional): Filter members returned by their role. (default: all) — one of: all, admin, member
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_remove_member

DELETE /orgs/{org}/members/{username} - Remove an organization member

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### orgs_check_membership_for_user

GET /orgs/{org}/members/{username} - Check organization membership for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### codespaces_get_codespaces_for_user_in_org

GET /orgs/{org}/members/{username}/codespaces - List codespaces for a user in organization

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### codespaces_delete_from_organization

DELETE /orgs/{org}/members/{username}/codespaces/{codespace_name} - Delete a codespace from the organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
- `codespace_name` (string): The name of the codespace.
### codespaces_stop_in_organization

POST /orgs/{org}/members/{username}/codespaces/{codespace_name}/stop - Stop a codespace for an organization user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
- `codespace_name` (string): The name of the codespace.
### copilot_get_copilot_seat_details_for_user

GET /orgs/{org}/members/{username}/copilot - Get Copilot seat assignment details for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### orgs_remove_membership_for_user

DELETE /orgs/{org}/memberships/{username} - Remove organization membership for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### orgs_set_membership_for_user

PUT /orgs/{org}/memberships/{username} - Set organization membership for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
- `role` (string, optional): The role to give the user in the organization. Can be one of:  
 * `admin` - The user will become an owner of the organization.  
 * `member` - The user will become a non-owner member of the organization. (default: member)
### orgs_get_membership_for_user

GET /orgs/{org}/memberships/{username} - Get organization membership for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### migrations_start_for_org

POST /orgs/{org}/migrations - Start an organization migration

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `repositories` (array): A list of arrays indicating which repositories should be migrated.
- `lock_repositories` (boolean, optional): Indicates whether repositories should be locked (to prevent manipulation) while migrating data. (default: False)
- `exclude_metadata` (boolean, optional): Indicates whether metadata should be excluded and only git source should be included for the migration. (default: False)
- `exclude_git_data` (boolean, optional): Indicates whether the repository git data should be excluded from the migration. (default: False)
- `exclude_attachments` (boolean, optional): Indicates whether attachments should be excluded from the migration (to reduce migration archive file size). (default: False)
- `exclude_releases` (boolean, optional): Indicates whether releases should be excluded from the migration (to reduce migration archive file size). (default: False)
- `exclude_owner_projects` (boolean, optional): Indicates whether projects owned by the organization or users should be excluded. from the migration. (default: False)
- `org_metadata_only` (boolean, optional): Indicates whether this should only include organization metadata (repositories array should be empty and will ignore other flags). (default: False)
- `exclude` (array, optional): Exclude related items from being returned in the response in order to improve performance of the request.
### migrations_list_for_org

GET /orgs/{org}/migrations - List organization migrations

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `exclude` (array, optional): Exclude attributes from the API response to improve performance
### migrations_get_status_for_org

GET /orgs/{org}/migrations/{migration_id} - Get an organization migration status

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `migration_id` (integer): The unique identifier of the migration.
- `exclude` (array, optional): Exclude attributes from the API response to improve performance
### migrations_delete_archive_for_org

DELETE /orgs/{org}/migrations/{migration_id}/archive - Delete an organization migration archive

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `migration_id` (integer): The unique identifier of the migration.
### migrations_download_archive_for_org

GET /orgs/{org}/migrations/{migration_id}/archive - Download an organization migration archive

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `migration_id` (integer): The unique identifier of the migration.
### migrations_unlock_repo_for_org

DELETE /orgs/{org}/migrations/{migration_id}/repos/{repo_name}/lock - Unlock an organization repository

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `migration_id` (integer): The unique identifier of the migration.
- `repo_name` (string): repo_name parameter
### migrations_list_repos_for_org

GET /orgs/{org}/migrations/{migration_id}/repositories - List repositories in an organization migration

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `migration_id` (integer): The unique identifier of the migration.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_list_org_roles

GET /orgs/{org}/organization-roles - Get all organization roles for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### orgs_revoke_all_org_roles_team

DELETE /orgs/{org}/organization-roles/teams/{team_slug} - Remove all organization roles for a team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
### orgs_revoke_org_role_team

DELETE /orgs/{org}/organization-roles/teams/{team_slug}/{role_id} - Remove an organization role from a team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `role_id` (integer): The unique identifier of the role.
### orgs_assign_team_to_org_role

PUT /orgs/{org}/organization-roles/teams/{team_slug}/{role_id} - Assign an organization role to a team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `role_id` (integer): The unique identifier of the role.
### orgs_revoke_all_org_roles_user

DELETE /orgs/{org}/organization-roles/users/{username} - Remove all organization roles for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### orgs_revoke_org_role_user

DELETE /orgs/{org}/organization-roles/users/{username}/{role_id} - Remove an organization role from a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
- `role_id` (integer): The unique identifier of the role.
### orgs_assign_user_to_org_role

PUT /orgs/{org}/organization-roles/users/{username}/{role_id} - Assign an organization role to a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
- `role_id` (integer): The unique identifier of the role.
### orgs_get_org_role

GET /orgs/{org}/organization-roles/{role_id} - Get an organization role

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `role_id` (integer): The unique identifier of the role.
### orgs_list_org_role_teams

GET /orgs/{org}/organization-roles/{role_id}/teams - List teams that are assigned to an organization role

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `role_id` (integer): The unique identifier of the role.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_list_org_role_users

GET /orgs/{org}/organization-roles/{role_id}/users - List users that are assigned to an organization role

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `role_id` (integer): The unique identifier of the role.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_list_outside_collaborators

GET /orgs/{org}/outside_collaborators - List outside collaborators for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `filter` (string, optional): Filter the list of outside collaborators. `2fa_disabled` means that only outside collaborators without [two-factor authentication](https://github.com/blog/1614-two-factor-authentication) enabled will be returned. `2fa_insecure` means that only outside collaborators with [insecure 2FA methods](https://docs.github.com/organizations/keeping-your-organization-secure/managing-two-factor-authentication-for-your-organization/requiring-two-factor-authentication-in-your-organization#requiring-secure-methods-of-two-factor-authentication-in-your-organization) will be returned. (default: all) — one of: 2fa_disabled, 2fa_insecure, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_remove_outside_collaborator

DELETE /orgs/{org}/outside_collaborators/{username} - Remove outside collaborator from an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### orgs_convert_member_to_outside_collaborator

PUT /orgs/{org}/outside_collaborators/{username} - Convert an organization member to outside collaborator

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
- `async` (boolean, optional): When set to `true`, the request will be performed asynchronously. Returns a 202 status code when the job is successfully queued. (default: False)
### packages_list_packages_for_organization

GET /orgs/{org}/packages - List packages for an organization

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `org` (string): The organization name. The name is not case sensitive.
- `visibility` (string, optional): The selected visibility of the packages.  This parameter is optional and only filters an existing result set.

The `internal` visibility is only supported for GitHub Packages registries that allow for granular permissions. For other ecosystems `internal` is synonymous with `private`.
For the list of GitHub Packages registries that support granular permissions, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." — one of: public, private, internal
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### packages_delete_package_for_org

DELETE /orgs/{org}/packages/{package_type}/{package_name} - Delete a package for an organization

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `org` (string): The organization name. The name is not case sensitive.
### packages_get_package_for_organization

GET /orgs/{org}/packages/{package_type}/{package_name} - Get a package for an organization

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `org` (string): The organization name. The name is not case sensitive.
### packages_restore_package_for_org

POST /orgs/{org}/packages/{package_type}/{package_name}/restore - Restore a package for an organization

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `org` (string): The organization name. The name is not case sensitive.
- `token` (string, optional): package token
### get_orgs_by_org_packages_by_package_type_by_package_name_versions

GET /orgs/{org}/packages/{package_type}/{package_name}/versions - List package versions for a package owned by an organization

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `org` (string): The organization name. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `state` (string, optional): The state of the package, either active or deleted. (default: active) — one of: active, deleted
### packages_delete_package_version_for_org

DELETE /orgs/{org}/packages/{package_type}/{package_name}/versions/{package_version_id} - Delete package version for an organization

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `org` (string): The organization name. The name is not case sensitive.
- `package_version_id` (integer): Unique identifier of the package version.
### packages_get_package_version_for_organization

GET /orgs/{org}/packages/{package_type}/{package_name}/versions/{package_version_id} - Get a package version for an organization

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `org` (string): The organization name. The name is not case sensitive.
- `package_version_id` (integer): Unique identifier of the package version.
### packages_restore_package_version_for_org

POST /orgs/{org}/packages/{package_type}/{package_name}/versions/{package_version_id}/restore - Restore package version for an organization

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `org` (string): The organization name. The name is not case sensitive.
- `package_version_id` (integer): Unique identifier of the package version.
### orgs_review_pat_grant_requests_in_bulk

POST /orgs/{org}/personal-access-token-requests - Review requests to access organization resources with fine-grained personal access tokens

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `pat_request_ids` (array, optional): Unique identifiers of the requests for access via fine-grained personal access token. Must be formed of between 1 and 100 `pat_request_id` values.
- `action` (string): Action to apply to the requests.
- `reason` (string, optional): Reason for approving or denying the requests. Max 1024 characters.
### orgs_list_pat_grant_requests

GET /orgs/{org}/personal-access-token-requests - List requests to access organization resources with fine-grained personal access tokens

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `sort` (string, optional): The property by which to sort the results. (default: created_at) — one of: created_at
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `owner` (array, optional): A list of owner usernames to use to filter the results.
- `repository` (string, optional): The name of the repository to use to filter the results.
- `permission` (string, optional): The permission to use to filter the results.
- `last_used_before` (string, optional): Only show fine-grained personal access tokens used before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `last_used_after` (string, optional): Only show fine-grained personal access tokens used after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `token_id` (array, optional): The ID of the token
### orgs_review_pat_grant_request

POST /orgs/{org}/personal-access-token-requests/{pat_request_id} - Review a request to access organization resources with a fine-grained personal access token

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `pat_request_id` (integer): Unique identifier of the request for access via fine-grained personal access token.
- `action` (string): Action to apply to the request.
- `reason` (string, optional): Reason for approving or denying the request. Max 1024 characters.
### orgs_list_pat_grant_request_repositories

GET /orgs/{org}/personal-access-token-requests/{pat_request_id}/repositories - List repositories requested to be accessed by a fine-grained personal access token

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `pat_request_id` (integer): Unique identifier of the request for access via fine-grained personal access token.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_update_pat_accesses

POST /orgs/{org}/personal-access-tokens - Update the access to organization resources via fine-grained personal access tokens

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `action` (string): Action to apply to the fine-grained personal access token.
- `pat_ids` (array): The IDs of the fine-grained personal access tokens.
### orgs_list_pat_grants

GET /orgs/{org}/personal-access-tokens - List fine-grained personal access tokens with access to organization resources

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `sort` (string, optional): The property by which to sort the results. (default: created_at) — one of: created_at
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `owner` (array, optional): A list of owner usernames to use to filter the results.
- `repository` (string, optional): The name of the repository to use to filter the results.
- `permission` (string, optional): The permission to use to filter the results.
- `last_used_before` (string, optional): Only show fine-grained personal access tokens used before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `last_used_after` (string, optional): Only show fine-grained personal access tokens used after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `token_id` (array, optional): The ID of the token
### orgs_update_pat_access

POST /orgs/{org}/personal-access-tokens/{pat_id} - Update the access a fine-grained personal access token has to organization resources

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `pat_id` (integer): The unique identifier of the fine-grained personal access token.
- `action` (string): Action to apply to the fine-grained personal access token.
### orgs_list_pat_grant_repositories

GET /orgs/{org}/personal-access-tokens/{pat_id}/repositories - List repositories a fine-grained personal access token has access to

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `pat_id` (integer): Unique identifier of the fine-grained personal access token.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### private_registries_create_org_private_registry

POST /orgs/{org}/private-registries - Create a private registry for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `registry_type` (string): The registry type.
- `url` (string): The URL of the private registry.
- `username` (string, optional): The username to use when authenticating with the private registry. This field should be omitted if the private registry does not require a username for authentication.
- `replaces_base` (boolean, optional): Whether this private registry should replace the base registry (e.g., npmjs.org for npm, rubygems.org for rubygems). When set to `true`, Dependabot will only use this registry and will not fall back to the public registry. When set to `false` (default), Dependabot will use this registry for scoped packages but may fall back to the public registry for other packages. (default: False)
- `encrypted_value` (string): The value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get private registries public key for an organization](https://docs.github.com/rest/private-registries/organization-configurations#get-private-registries-public-key-for-an-organization) endpoint.
- `key_id` (string): The ID of the key you used to encrypt the secret.
- `visibility` (string): Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry.
- `selected_repository_ids` (array, optional): An array of repository IDs that can access the organization private registry. You can only provide a list of repository IDs when `visibility` is set to `selected`. You can manage the list of selected repositories using the [Update a private registry for an organization](https://docs.github.com/rest/private-registries/organization-configurations#update-a-private-registry-for-an-organization) endpoint. This field should be omitted if `visibility` is set to `all` or `private`.
### private_registries_list_org_private_registries

GET /orgs/{org}/private-registries - List private registries for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### private_registries_get_org_public_key

GET /orgs/{org}/private-registries/public-key - Get private registries public key for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### private_registries_update_org_private_registry

PATCH /orgs/{org}/private-registries/{secret_name} - Update a private registry for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `registry_type` (string, optional): The registry type.
- `url` (string, optional): The URL of the private registry.
- `username` (string, optional): The username to use when authenticating with the private registry. This field should be omitted if the private registry does not require a username for authentication.
- `replaces_base` (boolean, optional): Whether this private registry should replace the base registry (e.g., npmjs.org for npm, rubygems.org for rubygems). When set to `true`, Dependabot will only use this registry and will not fall back to the public registry. When set to `false` (default), Dependabot will use this registry for scoped packages but may fall back to the public registry for other packages. (default: False)
- `encrypted_value` (string, optional): The value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get private registries public key for an organization](https://docs.github.com/rest/private-registries/organization-configurations#get-private-registries-public-key-for-an-organization) endpoint.
- `key_id` (string, optional): The ID of the key you used to encrypt the secret.
- `visibility` (string, optional): Which type of organization repositories have access to the private registry. `selected` means only the repositories specified by `selected_repository_ids` can access the private registry.
- `selected_repository_ids` (array, optional): An array of repository IDs that can access the organization private registry. You can only provide a list of repository IDs when `visibility` is set to `selected`. This field should be omitted if `visibility` is set to `all` or `private`.
### private_registries_delete_org_private_registry

DELETE /orgs/{org}/private-registries/{secret_name} - Delete a private registry for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### private_registries_get_org_private_registry

GET /orgs/{org}/private-registries/{secret_name} - Get a private registry for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### projects_list_for_org

GET /orgs/{org}/projectsV2 - List projects for organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `q` (string, optional): Limit results to projects of the specified type.
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### projects_get_for_org

GET /orgs/{org}/projectsV2/{project_number} - Get project for organization

Parameters:
- `project_number` (integer): The project's number.
- `org` (string): The organization name. The name is not case sensitive.
### projects_create_draft_item_for_org

POST /orgs/{org}/projectsV2/{project_number}/drafts - Create draft item for organization owned project

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `project_number` (integer): The project's number.
- `title` (string): The title of the draft issue item to create in the project.
- `body` (string, optional): The body content of the draft issue item to create in the project.
### projects_add_field_for_org

POST /orgs/{org}/projectsV2/{project_number}/fields - Add a field to an organization-owned project.

Parameters:
- `project_number` (integer): The project's number.
- `org` (string): The organization name. The name is not case sensitive.
- `body` (object): Request body
### projects_list_fields_for_org

GET /orgs/{org}/projectsV2/{project_number}/fields - List project fields for organization

Parameters:
- `project_number` (integer): The project's number.
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
### projects_get_field_for_org

GET /orgs/{org}/projectsV2/{project_number}/fields/{field_id} - Get project field for organization

Parameters:
- `project_number` (integer): The project's number.
- `field_id` (integer): The unique identifier of the field.
- `org` (string): The organization name. The name is not case sensitive.
### projects_add_item_for_org

POST /orgs/{org}/projectsV2/{project_number}/items - Add item to organization owned project

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `project_number` (integer): The project's number.
- `type` (string): The type of item to add to the project. Must be either Issue or PullRequest.
- `id` (integer, optional): The unique identifier of the issue or pull request to add to the project.
- `owner` (string, optional): The repository owner login.
- `repo` (string, optional): The repository name.
- `number` (integer, optional): The issue or pull request number.
### projects_list_items_for_org

GET /orgs/{org}/projectsV2/{project_number}/items - List items for an organization owned project

Parameters:
- `project_number` (integer): The project's number.
- `org` (string): The organization name. The name is not case sensitive.
- `q` (string, optional): Search query to filter items, see [Filtering projects](https://docs.github.com/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/filtering-projects) for more information.
- `fields` (object, optional): Limit results to specific fields, by their IDs. If not specified, the title field will be returned.

Example: `fields[]=123&fields[]=456&fields[]=789` or `fields=123,456,789`
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### projects_update_item_for_org

PATCH /orgs/{org}/projectsV2/{project_number}/items/{item_id} - Update project item for organization

Parameters:
- `project_number` (integer): The project's number.
- `org` (string): The organization name. The name is not case sensitive.
- `item_id` (integer): The unique identifier of the project item.
- `fields` (array): A list of field updates to apply.
### projects_delete_item_for_org

DELETE /orgs/{org}/projectsV2/{project_number}/items/{item_id} - Delete project item for organization

Parameters:
- `project_number` (integer): The project's number.
- `org` (string): The organization name. The name is not case sensitive.
- `item_id` (integer): The unique identifier of the project item.
### projects_get_org_item

GET /orgs/{org}/projectsV2/{project_number}/items/{item_id} - Get an item for an organization owned project

Parameters:
- `project_number` (integer): The project's number.
- `org` (string): The organization name. The name is not case sensitive.
- `item_id` (integer): The unique identifier of the project item.
- `fields` (object, optional): Limit results to specific fields, by their IDs. If not specified, the title field will be returned.

Example: fields[]=123&fields[]=456&fields[]=789 or fields=123,456,789
### projects_create_view_for_org

POST /orgs/{org}/projectsV2/{project_number}/views - Create a view for an organization-owned project

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `project_number` (integer): The project's number.
- `name` (string): The name of the view.
- `layout` (string): The layout of the view.
- `filter` (string, optional): The filter query for the view. See [Filtering projects](https://docs.github.com/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/filtering-projects) for more information.
- `visible_fields` (array, optional): `visible_fields` is not applicable to `roadmap` layout views.
For `table` and `board` layouts, this represents the field IDs that should be visible in the view. If not provided, the default visible fields will be used.
### projects_list_view_items_for_org

GET /orgs/{org}/projectsV2/{project_number}/views/{view_number}/items - List items for an organization project view

Parameters:
- `project_number` (integer): The project's number.
- `org` (string): The organization name. The name is not case sensitive.
- `view_number` (integer): The number that identifies the project view.
- `fields` (object, optional): Limit results to specific fields, by their IDs. If not specified, the
title field will be returned.

Example: `fields[]=123&fields[]=456&fields[]=789` or `fields=123,456,789`
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### patch_orgs_by_org_properties_schema

PATCH /orgs/{org}/properties/schema - Create or update custom properties for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `properties` (array): The array of custom properties to create or update.
### get_orgs_by_org_properties_schema

GET /orgs/{org}/properties/schema - Get all custom properties for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### delete_orgs_by_org_properties_schema_by_custom_property_name

DELETE /orgs/{org}/properties/schema/{custom_property_name} - Remove a custom property for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `custom_property_name` (string): The custom property name
### put_orgs_by_org_properties_schema_by_custom_property_name

PUT /orgs/{org}/properties/schema/{custom_property_name} - Create or update a custom property for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `custom_property_name` (string): The custom property name
- `value_type` (string): The type of the value for the property
- `required` (boolean, optional): Whether the property is required.
- `default_value` (object, optional): Default value of the property
- `description` (string, optional): Short description of the property
- `allowed_values` (array, optional): An ordered list of the allowed values of the property.
The property can have up to 200 allowed values.
- `values_editable_by` (string, optional): Who can edit the values of the property
- `require_explicit_values` (boolean, optional): Whether setting properties values is mandatory
### get_orgs_by_org_properties_schema_by_custom_property_name

GET /orgs/{org}/properties/schema/{custom_property_name} - Get a custom property for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `custom_property_name` (string): The custom property name
### patch_orgs_by_org_properties_values

PATCH /orgs/{org}/properties/values - Create or update custom property values for organization repositories

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `repository_names` (array): The names of repositories that the custom property values will be applied to.
- `properties` (array): List of custom property names and associated values to apply to the repositories.
### get_orgs_by_org_properties_values

GET /orgs/{org}/properties/values - List custom property values for organization repositories

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `repository_query` (string, optional): Finds repositories in the organization with a query containing one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching for repositories](https://docs.github.com/articles/searching-for-repositories/)" for a detailed list of qualifiers.
### orgs_list_public_members

GET /orgs/{org}/public_members - List public organization members

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### delete_orgs_by_org_public_members_by_username

DELETE /orgs/{org}/public_members/{username} - Remove public organization membership for the authenticated user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### orgs_set_public_membership_for_authenticated_user

PUT /orgs/{org}/public_members/{username} - Set public organization membership for the authenticated user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### orgs_check_public_membership_for_user

GET /orgs/{org}/public_members/{username} - Check public organization membership for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### repos_create_in_org

POST /orgs/{org}/repos - Create an organization repository

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the repository.
- `description` (string, optional): A short description of the repository.
- `homepage` (string, optional): A URL with more information about the repository.
- `private` (boolean, optional): Whether the repository is private. (default: False)
- `visibility` (string, optional): The visibility of the repository.
- `has_issues` (boolean, optional): Either `true` to enable issues for this repository or `false` to disable them. (default: True)
- `has_projects` (boolean, optional): Either `true` to enable projects for this repository or `false` to disable them. **Note:** If you're creating a repository in an organization that has disabled repository projects, the default is `false`, and if you pass `true`, the API returns an error. (default: True)
- `has_wiki` (boolean, optional): Either `true` to enable the wiki for this repository or `false` to disable it. (default: True)
- `has_downloads` (boolean, optional): Whether downloads are enabled. (default: True)
- `is_template` (boolean, optional): Either `true` to make this repo available as a template repository or `false` to prevent it. (default: False)
- `team_id` (integer, optional): The id of the team that will be granted access to this repository. This is only valid when creating a repository in an organization.
- `auto_init` (boolean, optional): Pass `true` to create an initial commit with empty README. (default: False)
- `gitignore_template` (string, optional): Desired language or platform [.gitignore template](https://github.com/github/gitignore) to apply. Use the name of the template without the extension. For example, "Haskell".
- `license_template` (string, optional): Choose an [open source license template](https://choosealicense.com/) that best suits your needs, and then use the [license keyword](https://docs.github.com/articles/licensing-a-repository/#searching-github-by-license-type) as the `license_template` string. For example, "mit" or "mpl-2.0".
- `allow_squash_merge` (boolean, optional): Either `true` to allow squash-merging pull requests, or `false` to prevent squash-merging. (default: True)
- `allow_merge_commit` (boolean, optional): Either `true` to allow merging pull requests with a merge commit, or `false` to prevent merging pull requests with merge commits. (default: True)
- `allow_rebase_merge` (boolean, optional): Either `true` to allow rebase-merging pull requests, or `false` to prevent rebase-merging. (default: True)
- `allow_auto_merge` (boolean, optional): Either `true` to allow auto-merge on pull requests, or `false` to disallow auto-merge. (default: False)
- `delete_branch_on_merge` (boolean, optional): Either `true` to allow automatically deleting head branches when pull requests are merged, or `false` to prevent automatic deletion. **The authenticated user must be an organization owner to set this property to `true`.** (default: False)
- `use_squash_pr_title_as_default` (boolean, optional): Either `true` to allow squash-merge commits to use pull request title, or `false` to use commit message. **This property is closing down. Please use `squash_merge_commit_title` instead. (default: False)
- `squash_merge_commit_title` (string, optional): Required when using `squash_merge_commit_message`.

The default value for a squash merge commit title:

- `PR_TITLE` - default to the pull request's title.
- `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit).
- `squash_merge_commit_message` (string, optional): The default value for a squash merge commit message:

- `PR_BODY` - default to the pull request's body.
- `COMMIT_MESSAGES` - default to the branch's commit messages.
- `BLANK` - default to a blank commit message.
- `merge_commit_title` (string, optional): Required when using `merge_commit_message`.

The default value for a merge commit title.

- `PR_TITLE` - default to the pull request's title.
- `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name).
- `merge_commit_message` (string, optional): The default value for a merge commit message.

- `PR_TITLE` - default to the pull request's title.
- `PR_BODY` - default to the pull request's body.
- `BLANK` - default to a blank commit message.
- `custom_properties` (object, optional): The custom properties for the new repository. The keys are the custom property names, and the values are the corresponding custom property values.
### repos_list_for_org

GET /orgs/{org}/repos - List organization repositories

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `type` (string, optional): Specifies the types of repositories you want returned. (default: all) — one of: all, public, private, forks, sources, member
- `sort` (string, optional): The property to sort the results by. (default: created) — one of: created, updated, pushed, full_name
- `direction` (string, optional): The order to sort by. Default: `asc` when using `full_name`, otherwise `desc`. — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_create_org_ruleset

POST /orgs/{org}/rulesets - Create an organization repository ruleset

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the ruleset.
- `target` (string, optional): The target of the ruleset (default: branch)
- `enforcement` (string): 
- `bypass_actors` (array, optional): The actors that can bypass the rules in this ruleset
- `conditions` (object, optional): 
- `rules` (array, optional): An array of rules within the ruleset.
### repos_get_org_rulesets

GET /orgs/{org}/rulesets - Get all organization repository rulesets

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `targets` (string, optional): A comma-separated list of rule targets to filter by.
If provided, only rulesets that apply to the specified targets will be returned.
For example, `branch,tag,push`.

### repos_get_org_rule_suites

GET /orgs/{org}/rulesets/rule-suites - List organization rule suites

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `ref` (string, optional): The name of the ref. Cannot contain wildcard characters. Optionally prefix with `refs/heads/` to limit to branches or `refs/tags/` to limit to tags. Omit the prefix to search across all refs. When specified, only rule evaluations triggered for this ref will be returned.
- `repository_name` (string, optional): The name of the repository to filter on.
- `time_period` (string, optional): The time period to filter by.

For example, `day` will filter for rule suites that occurred in the past 24 hours, and `week` will filter for rule suites that occurred in the past 7 days (168 hours). (default: day) — one of: hour, day, week, month
- `actor_name` (string, optional): The handle for the GitHub user account to filter on. When specified, only rule evaluations triggered by this actor will be returned.
- `rule_suite_result` (string, optional): The rule suite results to filter on. When specified, only suites with this result will be returned. (default: all) — one of: pass, fail, bypass, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_org_rule_suite

GET /orgs/{org}/rulesets/rule-suites/{rule_suite_id} - Get an organization rule suite

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `rule_suite_id` (integer): The unique identifier of the rule suite result.
To get this ID, you can use [GET /repos/{owner}/{repo}/rulesets/rule-suites](https://docs.github.com/rest/repos/rule-suites#list-repository-rule-suites)
for repositories and [GET /orgs/{org}/rulesets/rule-suites](https://docs.github.com/rest/orgs/rule-suites#list-organization-rule-suites)
for organizations.
### repos_delete_org_ruleset

DELETE /orgs/{org}/rulesets/{ruleset_id} - Delete an organization repository ruleset

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `ruleset_id` (integer): The ID of the ruleset.
### repos_update_org_ruleset

PUT /orgs/{org}/rulesets/{ruleset_id} - Update an organization repository ruleset

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `ruleset_id` (integer): The ID of the ruleset.
- `name` (string, optional): The name of the ruleset.
- `target` (string, optional): The target of the ruleset
- `enforcement` (string, optional): 
- `bypass_actors` (array, optional): The actors that can bypass the rules in this ruleset
- `conditions` (object, optional): 
- `rules` (array, optional): An array of rules within the ruleset.
### repos_get_org_ruleset

GET /orgs/{org}/rulesets/{ruleset_id} - Get an organization repository ruleset

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `ruleset_id` (integer): The ID of the ruleset.
### orgs_get_org_ruleset_history

GET /orgs/{org}/rulesets/{ruleset_id}/history - Get organization ruleset history

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `ruleset_id` (integer): The ID of the ruleset.
### orgs_get_org_ruleset_version

GET /orgs/{org}/rulesets/{ruleset_id}/history/{version_id} - Get organization ruleset version

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `ruleset_id` (integer): The ID of the ruleset.
- `version_id` (integer): The ID of the version
### secret_scanning_list_alerts_for_org

GET /orgs/{org}/secret-scanning/alerts - List secret scanning alerts for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `state` (string, optional): Set to `open` or `resolved` to only list secret scanning alerts in a specific state. — one of: open, resolved
- `secret_type` (string, optional): A comma-separated list of secret types to return. All default secret patterns are returned. To return generic patterns, pass the token name(s) in the parameter. See "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)" for a complete list of secret types.
- `resolution` (string, optional): A comma-separated list of resolutions. Only secret scanning alerts with one of these resolutions are listed. Valid resolutions are `false_positive`, `wont_fix`, `revoked`, `pattern_edited`, `pattern_deleted` or `used_in_tests`.
- `assignee` (string, optional): Filters alerts by assignee. Use `*` to get all assigned alerts, `none` to get all unassigned alerts, or a GitHub username to get alerts assigned to a specific user.
- `sort` (string, optional): The property to sort the results by. `created` means when the alert was created. `updated` means when the alert was updated or resolved. (default: created) — one of: created, updated
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events before this cursor. To receive an initial cursor on your first request, include an empty "before" query string.
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events after this cursor.  To receive an initial cursor on your first request, include an empty "after" query string.
- `validity` (string, optional): A comma-separated list of validities that, when present, will return alerts that match the validities in this list. Valid options are `active`, `inactive`, and `unknown`.
- `is_publicly_leaked` (boolean, optional): A boolean value representing whether or not to filter alerts by the publicly-leaked tag being present. (default: False)
- `is_multi_repo` (boolean, optional): A boolean value representing whether or not to filter alerts by the multi-repo tag being present. (default: False)
- `hide_secret` (boolean, optional): A boolean value representing whether or not to hide literal secrets in the results. (default: False)
### secret_scanning_update_org_pattern_configs

PATCH /orgs/{org}/secret-scanning/pattern-configurations - Update organization pattern configurations

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `pattern_config_version` (string, optional): 
- `provider_pattern_settings` (array, optional): Pattern settings for provider patterns.
- `custom_pattern_settings` (array, optional): Pattern settings for custom patterns.
### secret_scanning_list_org_pattern_configs

GET /orgs/{org}/secret-scanning/pattern-configurations - List organization pattern configurations

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### get_orgs_by_org_security_advisories

GET /orgs/{org}/security-advisories - List repository security advisories for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `sort` (string, optional): The property to sort the results by. (default: created) — one of: created, updated, published
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of advisories to return per page. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `state` (string, optional): Filter by the state of the repository advisories. Only advisories of this state will be returned. — one of: triage, draft, published, closed
### orgs_list_security_manager_teams

GET /orgs/{org}/security-managers - List security manager teams

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### orgs_remove_security_manager_team

DELETE /orgs/{org}/security-managers/teams/{team_slug} - Remove a security manager team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
### orgs_add_security_manager_team

PUT /orgs/{org}/security-managers/teams/{team_slug} - Add a security manager team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
### orgs_set_immutable_releases_settings

PUT /orgs/{org}/settings/immutable-releases - Set immutable releases settings for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `enforced_repositories` (string): The policy that controls how immutable releases are enforced in the organization.
- `selected_repository_ids` (array, optional): An array of repository ids for which immutable releases enforcement should be applied. You can only provide a list of repository ids when the `enforced_repositories` is set to `selected`. You can add and remove individual repositories using the [Enable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization) and [Disable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization) endpoints.
### orgs_get_immutable_releases_settings

GET /orgs/{org}/settings/immutable-releases - Get immutable releases settings for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### orgs_set_immutable_releases_settings_repositories

PUT /orgs/{org}/settings/immutable-releases/repositories - Set selected repositories for immutable releases enforcement

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `selected_repository_ids` (array): An array of repository ids for which immutable releases enforcement should be applied. You can only provide a list of repository ids when the `enforced_repositories` is set to `selected`. You can add and remove individual repositories using the [Enable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization) and [Disable a selected repository for immutable releases in an organization](https://docs.github.com/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization) endpoints.
### orgs_get_immutable_releases_settings_repositories

GET /orgs/{org}/settings/immutable-releases/repositories - List selected repositories for immutable releases enforcement

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### delete_orgs_by_org_settings_immutable_releases_repositories_by_repository_id

DELETE /orgs/{org}/settings/immutable-releases/repositories/{repository_id} - Disable a selected repository for immutable releases in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `repository_id` (integer): The unique identifier of the repository.
### put_orgs_by_org_settings_immutable_releases_repositories_by_repository_id

PUT /orgs/{org}/settings/immutable-releases/repositories/{repository_id} - Enable a selected repository for immutable releases in an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `repository_id` (integer): The unique identifier of the repository.
### post_orgs_by_org_settings_network_configurations

POST /orgs/{org}/settings/network-configurations - Create a hosted compute network configuration for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): Name of the network configuration. Must be between 1 and 100 characters and may only contain upper and lowercase letters a-z, numbers 0-9, '.', '-', and '_'.
- `compute_service` (string, optional): The hosted compute service to use for the network configuration.
- `network_settings_ids` (array): A list of identifiers of the network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list.
### get_orgs_by_org_settings_network_configurations

GET /orgs/{org}/settings/network-configurations - List hosted compute network configurations for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### patch_orgs_by_org_settings_network_configurations_by_network_configuration_id

PATCH /orgs/{org}/settings/network-configurations/{network_configuration_id} - Update a hosted compute network configuration for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `network_configuration_id` (string): Unique identifier of the hosted compute network configuration.
- `name` (string, optional): Name of the network configuration. Must be between 1 and 100 characters and may only contain upper and lowercase letters a-z, numbers 0-9, '.', '-', and '_'.
- `compute_service` (string, optional): The hosted compute service to use for the network configuration.
- `network_settings_ids` (array, optional): A list of identifiers of the network settings resources to use for the network configuration. Exactly one resource identifier must be specified in the list.
### delete_orgs_by_org_settings_network_configurations_by_network_configuration_id

DELETE /orgs/{org}/settings/network-configurations/{network_configuration_id} - Delete a hosted compute network configuration from an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `network_configuration_id` (string): Unique identifier of the hosted compute network configuration.
### hosted_compute_get_network_configuration_for_org

GET /orgs/{org}/settings/network-configurations/{network_configuration_id} - Get a hosted compute network configuration for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `network_configuration_id` (string): Unique identifier of the hosted compute network configuration.
### hosted_compute_get_network_settings_for_org

GET /orgs/{org}/settings/network-settings/{network_settings_id} - Get a hosted compute network settings resource for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `network_settings_id` (string): Unique identifier of the hosted compute network settings.
### copilot_copilot_metrics_for_team

GET /orgs/{org}/team/{team_slug}/copilot/metrics - Get Copilot metrics for a team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `since` (string, optional): Show usage metrics since this date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format (`YYYY-MM-DDTHH:MM:SSZ`). Maximum value is 100 days ago.
- `until` (string, optional): Show usage metrics until this date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format (`YYYY-MM-DDTHH:MM:SSZ`) and should not preceed the `since` date if it is passed.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of days of metrics to display per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 100)
### teams_create

POST /orgs/{org}/teams - Create a team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `name` (string): The name of the team.
- `description` (string, optional): The description of the team.
- `maintainers` (array, optional): List GitHub usernames for organization members who will become team maintainers.
- `repo_names` (array, optional): The full name (e.g., "organization-name/repository-name") of repositories to add the team to.
- `privacy` (string, optional): The level of privacy this team should have. The options are:  
**For a non-nested team:**  
 * `secret` - only visible to organization owners and members of this team.  
 * `closed` - visible to all members of this organization.  
Default: `secret`  
**For a parent or child team:**  
 * `closed` - visible to all members of this organization.  
Default for child team: `closed`
- `notification_setting` (string, optional): The notification setting the team has chosen. The options are:  
 * `notifications_enabled` - team members receive notifications when the team is @mentioned.  
 * `notifications_disabled` - no one receives notifications.  
Default: `notifications_enabled`
- `permission` (string, optional): **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. (default: pull)
- `parent_team_id` (integer, optional): The ID of a team to set as the parent team.
### teams_list

GET /orgs/{org}/teams - List teams

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `team_type` (string, optional): Filter team results by their type. For more information, see "[What kind of team should I use?](https://docs.github.com/enterprise-cloud@latest/admin/concepts/enterprise-fundamentals/teams-in-an-enterprise#what-kind-of-team-should-i-use)" (default: all) — one of: all, enterprise, organization
### teams_update_in_org

PATCH /orgs/{org}/teams/{team_slug} - Update a team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `name` (string, optional): The name of the team.
- `description` (string, optional): The description of the team.
- `privacy` (string, optional): The level of privacy this team should have. Editing teams without specifying this parameter leaves `privacy` intact. When a team is nested, the `privacy` for parent teams cannot be `secret`. The options are:  
**For a non-nested team:**  
 * `secret` - only visible to organization owners and members of this team.  
 * `closed` - visible to all members of this organization.  
**For a parent or child team:**  
 * `closed` - visible to all members of this organization.
- `notification_setting` (string, optional): The notification setting the team has chosen. Editing teams without specifying this parameter leaves `notification_setting` intact. The options are: 
 * `notifications_enabled` - team members receive notifications when the team is @mentioned.  
 * `notifications_disabled` - no one receives notifications.
- `permission` (string, optional): **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. (default: pull)
- `parent_team_id` (integer, optional): The ID of a team to set as the parent team.
### teams_delete_in_org

DELETE /orgs/{org}/teams/{team_slug} - Delete a team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
### teams_get_by_name

GET /orgs/{org}/teams/{team_slug} - Get a team by name

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
### teams_list_pending_invitations_in_org

GET /orgs/{org}/teams/{team_slug}/invitations - List pending team invitations

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### teams_list_members_in_org

GET /orgs/{org}/teams/{team_slug}/members - List team members

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `role` (string, optional): Filters members returned by their role in the team. (default: all) — one of: member, maintainer, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### teams_remove_membership_for_user_in_org

DELETE /orgs/{org}/teams/{team_slug}/memberships/{username} - Remove team membership for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `username` (string): The handle for the GitHub user account.
### teams_add_or_update_membership_for_user_in_org

PUT /orgs/{org}/teams/{team_slug}/memberships/{username} - Add or update team membership for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `username` (string): The handle for the GitHub user account.
- `role` (string, optional): The role that this user should have in the team. (default: member)
### teams_get_membership_for_user_in_org

GET /orgs/{org}/teams/{team_slug}/memberships/{username} - Get team membership for a user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `username` (string): The handle for the GitHub user account.
### teams_list_repos_in_org

GET /orgs/{org}/teams/{team_slug}/repos - List team repositories

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### teams_remove_repo_in_org

DELETE /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo} - Remove a repository from a team

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### teams_add_or_update_repo_permissions_in_org

PUT /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo} - Add or update team repository permissions

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `permission` (string, optional): The permission to grant the team on this repository. We accept the following permissions to be set: `pull`, `triage`, `push`, `maintain`, `admin` and you can also specify a custom repository role name, if the owning organization has defined any. If no permission is specified, the team's `permission` attribute will be used to determine what permission to grant the team on this repository.
### teams_check_permissions_for_repo_in_org

GET /orgs/{org}/teams/{team_slug}/repos/{owner}/{repo} - Check team permissions for a repository

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### teams_list_child_in_org

GET /orgs/{org}/teams/{team_slug}/teams - List child teams

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `team_slug` (string): The slug of the team name.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### post_orgs_by_org_by_security_product_by_enablement

POST /orgs/{org}/{security_product}/{enablement} - Enable or disable a security feature for an organization

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `security_product` (string): The security feature to enable or disable. — one of: dependency_graph, dependabot_alerts, dependabot_security_updates, advanced_security, code_scanning_default_setup, secret_scanning, secret_scanning_push_protection
- `enablement` (string): The action to take.

`enable_all` means to enable the specified security feature for all repositories in the organization.
`disable_all` means to disable the specified security feature for all repositories in the organization. — one of: enable_all, disable_all
- `body` (object, optional): Request body
### rate_limit_get

GET /rate_limit - Get rate limit status for the authenticated user

### repos_update

PATCH /repos/{owner}/{repo} - Update a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string, optional): The name of the repository.
- `description` (string, optional): A short description of the repository.
- `homepage` (string, optional): A URL with more information about the repository.
- `private` (boolean, optional): Either `true` to make the repository private or `false` to make it public. Default: `false`.  
**Note**: You will get a `422` error if the organization restricts [changing repository visibility](https://docs.github.com/articles/repository-permission-levels-for-an-organization#changing-the-visibility-of-repositories) to organization owners and a non-owner tries to change the value of private. (default: False)
- `visibility` (string, optional): The visibility of the repository.
- `security_and_analysis` (object, optional): Specify which security and analysis features to enable or disable for the repository.

To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."

For example, to enable GitHub Advanced Security, use this data in the body of the `PATCH` request:
`{ "security_and_analysis": {"advanced_security": { "status": "enabled" } } }`.

You can check which security and analysis features are currently enabled by using a `GET /repos/{owner}/{repo}` request.
- `has_issues` (boolean, optional): Either `true` to enable issues for this repository or `false` to disable them. (default: True)
- `has_projects` (boolean, optional): Either `true` to enable projects for this repository or `false` to disable them. **Note:** If you're creating a repository in an organization that has disabled repository projects, the default is `false`, and if you pass `true`, the API returns an error. (default: True)
- `has_wiki` (boolean, optional): Either `true` to enable the wiki for this repository or `false` to disable it. (default: True)
- `is_template` (boolean, optional): Either `true` to make this repo available as a template repository or `false` to prevent it. (default: False)
- `default_branch` (string, optional): Updates the default branch for this repository.
- `allow_squash_merge` (boolean, optional): Either `true` to allow squash-merging pull requests, or `false` to prevent squash-merging. (default: True)
- `allow_merge_commit` (boolean, optional): Either `true` to allow merging pull requests with a merge commit, or `false` to prevent merging pull requests with merge commits. (default: True)
- `allow_rebase_merge` (boolean, optional): Either `true` to allow rebase-merging pull requests, or `false` to prevent rebase-merging. (default: True)
- `allow_auto_merge` (boolean, optional): Either `true` to allow auto-merge on pull requests, or `false` to disallow auto-merge. (default: False)
- `delete_branch_on_merge` (boolean, optional): Either `true` to allow automatically deleting head branches when pull requests are merged, or `false` to prevent automatic deletion. (default: False)
- `allow_update_branch` (boolean, optional): Either `true` to always allow a pull request head branch that is behind its base branch to be updated even if it is not required to be up to date before merging, or false otherwise. (default: False)
- `use_squash_pr_title_as_default` (boolean, optional): Either `true` to allow squash-merge commits to use pull request title, or `false` to use commit message. **This property is closing down. Please use `squash_merge_commit_title` instead. (default: False)
- `squash_merge_commit_title` (string, optional): Required when using `squash_merge_commit_message`.

The default value for a squash merge commit title:

- `PR_TITLE` - default to the pull request's title.
- `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit).
- `squash_merge_commit_message` (string, optional): The default value for a squash merge commit message:

- `PR_BODY` - default to the pull request's body.
- `COMMIT_MESSAGES` - default to the branch's commit messages.
- `BLANK` - default to a blank commit message.
- `merge_commit_title` (string, optional): Required when using `merge_commit_message`.

The default value for a merge commit title.

- `PR_TITLE` - default to the pull request's title.
- `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name).
- `merge_commit_message` (string, optional): The default value for a merge commit message.

- `PR_TITLE` - default to the pull request's title.
- `PR_BODY` - default to the pull request's body.
- `BLANK` - default to a blank commit message.
- `archived` (boolean, optional): Whether to archive this repository. `false` will unarchive a previously archived repository. (default: False)
- `allow_forking` (boolean, optional): Either `true` to allow private forks, or `false` to prevent private forks. (default: False)
- `web_commit_signoff_required` (boolean, optional): Either `true` to require contributors to sign off on web-based commits, or `false` to not require contributors to sign off on web-based commits. (default: False)
### repos_delete

DELETE /repos/{owner}/{repo} - Delete a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get

GET /repos/{owner}/{repo} - Get a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_list_artifacts_for_repo

GET /repos/{owner}/{repo}/actions/artifacts - List artifacts for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `name` (string, optional): The name field of an artifact. When specified, only artifacts with this name will be returned.
### actions_delete_artifact

DELETE /repos/{owner}/{repo}/actions/artifacts/{artifact_id} - Delete an artifact

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `artifact_id` (integer): The unique identifier of the artifact.
### actions_get_artifact

GET /repos/{owner}/{repo}/actions/artifacts/{artifact_id} - Get an artifact

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `artifact_id` (integer): The unique identifier of the artifact.
### actions_download_artifact

GET /repos/{owner}/{repo}/actions/artifacts/{artifact_id}/{archive_format} - Download an artifact

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `artifact_id` (integer): The unique identifier of the artifact.
- `archive_format` (string): 
### put_repos_by_owner_by_repo_actions_cache_retention_limit

PUT /repos/{owner}/{repo}/actions/cache/retention-limit - Set GitHub Actions cache retention limit for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `max_cache_retention_days` (integer, optional): The maximum number of days to keep caches in this repository.
### get_repos_by_owner_by_repo_actions_cache_retention_limit

GET /repos/{owner}/{repo}/actions/cache/retention-limit - Get GitHub Actions cache retention limit for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### put_repos_by_owner_by_repo_actions_cache_storage_limit

PUT /repos/{owner}/{repo}/actions/cache/storage-limit - Set GitHub Actions cache storage limit for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `max_cache_size_gb` (integer, optional): The maximum total cache size for this repository, in gigabytes.
### get_repos_by_owner_by_repo_actions_cache_storage_limit

GET /repos/{owner}/{repo}/actions/cache/storage-limit - Get GitHub Actions cache storage limit for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_get_actions_cache_usage

GET /repos/{owner}/{repo}/actions/cache/usage - Get GitHub Actions cache usage for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_delete_actions_cache_by_key

DELETE /repos/{owner}/{repo}/actions/caches - Delete GitHub Actions caches for a repository (using a cache key)

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `key` (string): A key for identifying the cache.
- `ref` (string, optional): The full Git reference for narrowing down the cache. The `ref` for a branch should be formatted as `refs/heads/<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
### actions_get_actions_cache_list

GET /repos/{owner}/{repo}/actions/caches - List GitHub Actions caches for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `ref` (string, optional): The full Git reference for narrowing down the cache. The `ref` for a branch should be formatted as `refs/heads/<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
- `key` (string, optional): An explicit key or prefix for identifying the cache
- `sort` (string, optional): The property to sort the results by. `created_at` means when the cache was created. `last_accessed_at` means when the cache was last accessed. `size_in_bytes` is the size of the cache in bytes. (default: last_accessed_at) — one of: created_at, last_accessed_at, size_in_bytes
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
### actions_delete_actions_cache_by_id

DELETE /repos/{owner}/{repo}/actions/caches/{cache_id} - Delete a GitHub Actions cache for a repository (using a cache ID)

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `cache_id` (integer): The unique identifier of the GitHub Actions cache.
### actions_get_job_for_workflow_run

GET /repos/{owner}/{repo}/actions/jobs/{job_id} - Get a job for a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `job_id` (integer): The unique identifier of the job.
### actions_download_job_logs_for_workflow_run

GET /repos/{owner}/{repo}/actions/jobs/{job_id}/logs - Download job logs for a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `job_id` (integer): The unique identifier of the job.
### actions_re_run_job_for_workflow_run

POST /repos/{owner}/{repo}/actions/jobs/{job_id}/rerun - Re-run a job from a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `job_id` (integer): The unique identifier of the job.
- `enable_debug_logging` (boolean, optional): Whether to enable debug logging for the re-run. (default: False)
### actions_set_custom_oidc_sub_claim_for_repo

PUT /repos/{owner}/{repo}/actions/oidc/customization/sub - Set the customization template for an OIDC subject claim for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `use_default` (boolean): Whether to use the default template or not. If `true`, the `include_claim_keys` field is ignored.
- `include_claim_keys` (array, optional): Array of unique strings. Each claim key can only contain alphanumeric characters and underscores.
### actions_get_custom_oidc_sub_claim_for_repo

GET /repos/{owner}/{repo}/actions/oidc/customization/sub - Get the customization template for an OIDC subject claim for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_list_repo_organization_secrets

GET /repos/{owner}/{repo}/actions/organization-secrets - List repository organization secrets

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_list_repo_organization_variables

GET /repos/{owner}/{repo}/actions/organization-variables - List repository organization variables

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 10)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_set_github_actions_permissions_repository

PUT /repos/{owner}/{repo}/actions/permissions - Set GitHub Actions permissions for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `enabled` (boolean): 
- `allowed_actions` (string, optional): 
- `sha_pinning_required` (boolean, optional): 
### actions_get_github_actions_permissions_repository

GET /repos/{owner}/{repo}/actions/permissions - Get GitHub Actions permissions for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_set_workflow_access_to_repository

PUT /repos/{owner}/{repo}/actions/permissions/access - Set the level of access for workflows outside of the repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `access_level` (string): Defines the level of access that workflows outside of the repository have to actions and reusable workflows within the
repository.

`none` means the access is only possible from workflows in this repository. `user` level access allows sharing across user owned private repositories only. `organization` level access allows sharing across the organization.
### actions_get_workflow_access_to_repository

GET /repos/{owner}/{repo}/actions/permissions/access - Get the level of access for workflows outside of the repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### put_repos_by_owner_by_repo_actions_permissions_artifact_and_log_retention

PUT /repos/{owner}/{repo}/actions/permissions/artifact-and-log-retention - Set artifact and log retention settings for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `days` (integer): The number of days to retain artifacts and logs
### get_repos_by_owner_by_repo_actions_permissions_artifact_and_log_retention

GET /repos/{owner}/{repo}/actions/permissions/artifact-and-log-retention - Get artifact and log retention settings for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### put_repos_by_owner_by_repo_actions_permissions_fork_pr_contributor_approval

PUT /repos/{owner}/{repo}/actions/permissions/fork-pr-contributor-approval - Set fork PR contributor approval permissions for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `approval_policy` (string): The policy that controls when fork PR workflows require approval from a maintainer.
### get_repos_by_owner_by_repo_actions_permissions_fork_pr_contributor_approval

GET /repos/{owner}/{repo}/actions/permissions/fork-pr-contributor-approval - Get fork PR contributor approval permissions for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### put_repos_by_owner_by_repo_actions_permissions_fork_pr_workflows_private_repos

PUT /repos/{owner}/{repo}/actions/permissions/fork-pr-workflows-private-repos - Set private repo fork PR workflow settings for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_workflows_from_fork_pull_requests` (boolean): Whether workflows triggered by pull requests from forks are allowed to run on private repositories.
- `send_write_tokens_to_workflows` (boolean, optional): Whether GitHub Actions can create pull requests or submit approving pull request reviews from a workflow triggered by a fork pull request.
- `send_secrets_and_variables` (boolean, optional): Whether to make secrets and variables available to workflows triggered by pull requests from forks.
- `require_approval_for_fork_pr_workflows` (boolean, optional): Whether workflows triggered by pull requests from forks require approval from a repository administrator to run.
### get_repos_by_owner_by_repo_actions_permissions_fork_pr_workflows_private_repos

GET /repos/{owner}/{repo}/actions/permissions/fork-pr-workflows-private-repos - Get private repo fork PR workflow settings for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_set_allowed_actions_repository

PUT /repos/{owner}/{repo}/actions/permissions/selected-actions - Set allowed actions and reusable workflows for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `github_owned_allowed` (boolean, optional): Whether GitHub-owned actions are allowed. For example, this includes the actions in the `actions` organization.
- `verified_allowed` (boolean, optional): Whether actions from GitHub Marketplace verified creators are allowed. Set to `true` to allow all actions by GitHub Marketplace verified creators.
- `patterns_allowed` (array, optional): Specifies a list of string-matching patterns to allow specific action(s) and reusable workflow(s). Wildcards, tags, and SHAs are allowed. For example, `monalisa/octocat@*`, `monalisa/octocat@v2`, `monalisa/*`.

> [!NOTE]
> The `patterns_allowed` setting only applies to public repositories.
### actions_get_allowed_actions_repository

GET /repos/{owner}/{repo}/actions/permissions/selected-actions - Get allowed actions and reusable workflows for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### put_repos_by_owner_by_repo_actions_permissions_workflow

PUT /repos/{owner}/{repo}/actions/permissions/workflow - Set default workflow permissions for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `default_workflow_permissions` (string, optional): 
- `can_approve_pull_request_reviews` (boolean, optional): 
### get_repos_by_owner_by_repo_actions_permissions_workflow

GET /repos/{owner}/{repo}/actions/permissions/workflow - Get default workflow permissions for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_list_self_hosted_runners_for_repo

GET /repos/{owner}/{repo}/actions/runners - List self-hosted runners for a repository

Parameters:
- `name` (string, optional): The name of a self-hosted runner.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_list_runner_applications_for_repo

GET /repos/{owner}/{repo}/actions/runners/downloads - List runner applications for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_generate_runner_jitconfig_for_repo

POST /repos/{owner}/{repo}/actions/runners/generate-jitconfig - Create configuration for a just-in-time runner for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the new runner.
- `runner_group_id` (integer): The ID of the runner group to register the runner to.
- `labels` (array): The names of the custom labels to add to the runner. **Minimum items**: 1. **Maximum items**: 100.
- `work_folder` (string, optional): The working directory to be used for job execution, relative to the runner install directory. (default: _work)
### actions_create_registration_token_for_repo

POST /repos/{owner}/{repo}/actions/runners/registration-token - Create a registration token for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_create_remove_token_for_repo

POST /repos/{owner}/{repo}/actions/runners/remove-token - Create a remove token for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_delete_self_hosted_runner_from_repo

DELETE /repos/{owner}/{repo}/actions/runners/{runner_id} - Delete a self-hosted runner from a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### actions_get_self_hosted_runner_for_repo

GET /repos/{owner}/{repo}/actions/runners/{runner_id} - Get a self-hosted runner for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### post_repos_by_owner_by_repo_actions_runners_by_runner_id_labels

POST /repos/{owner}/{repo}/actions/runners/{runner_id}/labels - Add custom labels to a self-hosted runner for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
- `labels` (array): The names of the custom labels to add to the runner.
### delete_repos_by_owner_by_repo_actions_runners_by_runner_id_labels

DELETE /repos/{owner}/{repo}/actions/runners/{runner_id}/labels - Remove all custom labels from a self-hosted runner for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### put_repos_by_owner_by_repo_actions_runners_by_runner_id_labels

PUT /repos/{owner}/{repo}/actions/runners/{runner_id}/labels - Set custom labels for a self-hosted runner for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
- `labels` (array): The names of the custom labels to set for the runner. You can pass an empty array to remove all custom labels.
### get_repos_by_owner_by_repo_actions_runners_by_runner_id_labels

GET /repos/{owner}/{repo}/actions/runners/{runner_id}/labels - List labels for a self-hosted runner for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
### delete_repos_by_owner_by_repo_actions_runners_by_runner_id_labels_by_name

DELETE /repos/{owner}/{repo}/actions/runners/{runner_id}/labels/{name} - Remove a custom label from a self-hosted runner for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `runner_id` (integer): Unique identifier of the self-hosted runner.
- `name` (string): The name of a self-hosted runner's custom label.
### actions_list_workflow_runs_for_repo

GET /repos/{owner}/{repo}/actions/runs - List workflow runs for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `actor` (string, optional): Returns someone's workflow runs. Use the login for the user who created the `push` associated with the check suite or workflow run.
- `branch` (string, optional): Returns workflow runs associated with a branch. Use the name of the branch of the `push`.
- `event` (string, optional): Returns workflow run triggered by the event you specify. For example, `push`, `pull_request` or `issue`. For more information, see "[Events that trigger workflows](https://docs.github.com/actions/automating-your-workflow-with-github-actions/events-that-trigger-workflows)."
- `status` (string, optional): Returns workflow runs with the check run `status` or `conclusion` that you specify. For example, a conclusion can be `success` or a status can be `in_progress`. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. — one of: completed, action_required, cancelled, failure, neutral, skipped, stale, success, timed_out, in_progress, queued, requested, waiting, pending
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `created` (string, optional): Returns workflow runs created within the given date-time range. For more information on the syntax, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
- `exclude_pull_requests` (boolean, optional): If `true` pull requests are omitted from the response (empty array). (default: False)
- `check_suite_id` (integer, optional): Returns workflow runs with the `check_suite_id` that you specify.
- `head_sha` (string, optional): Only returns workflow runs that are associated with the specified `head_sha`.
### actions_delete_workflow_run

DELETE /repos/{owner}/{repo}/actions/runs/{run_id} - Delete a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
### actions_get_workflow_run

GET /repos/{owner}/{repo}/actions/runs/{run_id} - Get a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `exclude_pull_requests` (boolean, optional): If `true` pull requests are omitted from the response (empty array). (default: False)
### actions_get_reviews_for_run

GET /repos/{owner}/{repo}/actions/runs/{run_id}/approvals - Get the review history for a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
### actions_approve_workflow_run

POST /repos/{owner}/{repo}/actions/runs/{run_id}/approve - Approve a workflow run for a fork pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
### actions_list_workflow_run_artifacts

GET /repos/{owner}/{repo}/actions/runs/{run_id}/artifacts - List workflow run artifacts

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `name` (string, optional): The name field of an artifact. When specified, only artifacts with this name will be returned.
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
### actions_get_workflow_run_attempt

GET /repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number} - Get a workflow run attempt

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `attempt_number` (integer): The attempt number of the workflow run.
- `exclude_pull_requests` (boolean, optional): If `true` pull requests are omitted from the response (empty array). (default: False)
### actions_list_jobs_for_workflow_run_attempt

GET /repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}/jobs - List jobs for a workflow run attempt

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `attempt_number` (integer): The attempt number of the workflow run.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_download_workflow_run_attempt_logs

GET /repos/{owner}/{repo}/actions/runs/{run_id}/attempts/{attempt_number}/logs - Download workflow run attempt logs

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `attempt_number` (integer): The attempt number of the workflow run.
### actions_cancel_workflow_run

POST /repos/{owner}/{repo}/actions/runs/{run_id}/cancel - Cancel a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
### actions_review_custom_gates_for_run

POST /repos/{owner}/{repo}/actions/runs/{run_id}/deployment_protection_rule - Review custom deployment protection rules for a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `body` (object): Request body
### actions_force_cancel_workflow_run

POST /repos/{owner}/{repo}/actions/runs/{run_id}/force-cancel - Force cancel a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
### actions_list_jobs_for_workflow_run

GET /repos/{owner}/{repo}/actions/runs/{run_id}/jobs - List jobs for a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `filter` (string, optional): Filters jobs by their `completed_at` timestamp. `latest` returns jobs from the most recent execution of the workflow run. `all` returns all jobs for a workflow run, including from old executions of the workflow run. (default: latest) — one of: latest, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_delete_workflow_run_logs

DELETE /repos/{owner}/{repo}/actions/runs/{run_id}/logs - Delete workflow run logs

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
### actions_download_workflow_run_logs

GET /repos/{owner}/{repo}/actions/runs/{run_id}/logs - Download workflow run logs

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
### actions_review_pending_deployments_for_run

POST /repos/{owner}/{repo}/actions/runs/{run_id}/pending_deployments - Review pending deployments for a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `environment_ids` (array): The list of environment ids to approve or reject
- `state` (string): Whether to approve or reject deployment to the specified environments.
- `comment` (string): A comment to accompany the deployment review
### actions_get_pending_deployments_for_run

GET /repos/{owner}/{repo}/actions/runs/{run_id}/pending_deployments - Get pending deployments for a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
### actions_re_run_workflow

POST /repos/{owner}/{repo}/actions/runs/{run_id}/rerun - Re-run a workflow

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `enable_debug_logging` (boolean, optional): Whether to enable debug logging for the re-run. (default: False)
### actions_re_run_workflow_failed_jobs

POST /repos/{owner}/{repo}/actions/runs/{run_id}/rerun-failed-jobs - Re-run failed jobs from a workflow run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
- `enable_debug_logging` (boolean, optional): Whether to enable debug logging for the re-run. (default: False)
### actions_get_workflow_run_usage

GET /repos/{owner}/{repo}/actions/runs/{run_id}/timing - Get workflow run usage

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `run_id` (integer): The unique identifier of the workflow run.
### actions_list_repo_secrets

GET /repos/{owner}/{repo}/actions/secrets - List repository secrets

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_get_repo_public_key

GET /repos/{owner}/{repo}/actions/secrets/public-key - Get a repository public key

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### actions_delete_repo_secret

DELETE /repos/{owner}/{repo}/actions/secrets/{secret_name} - Delete a repository secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### actions_create_or_update_repo_secret

PUT /repos/{owner}/{repo}/actions/secrets/{secret_name} - Create or update a repository secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `encrypted_value` (string): Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get a repository public key](https://docs.github.com/rest/actions/secrets#get-a-repository-public-key) endpoint.
- `key_id` (string): ID of the key you used to encrypt the secret.
### actions_get_repo_secret

GET /repos/{owner}/{repo}/actions/secrets/{secret_name} - Get a repository secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### actions_create_repo_variable

POST /repos/{owner}/{repo}/actions/variables - Create a repository variable

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the variable.
- `value` (string): The value of the variable.
### actions_list_repo_variables

GET /repos/{owner}/{repo}/actions/variables - List repository variables

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 10)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_update_repo_variable

PATCH /repos/{owner}/{repo}/actions/variables/{name} - Update a repository variable

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the variable.
- `value` (string, optional): The value of the variable.
### actions_delete_repo_variable

DELETE /repos/{owner}/{repo}/actions/variables/{name} - Delete a repository variable

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the variable.
### actions_get_repo_variable

GET /repos/{owner}/{repo}/actions/variables/{name} - Get a repository variable

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the variable.
### actions_list_repo_workflows

GET /repos/{owner}/{repo}/actions/workflows - List repository workflows

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_get_workflow

GET /repos/{owner}/{repo}/actions/workflows/{workflow_id} - Get a workflow

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `workflow_id` (object): The ID of the workflow. You can also pass the workflow file name as a string.
### actions_disable_workflow

PUT /repos/{owner}/{repo}/actions/workflows/{workflow_id}/disable - Disable a workflow

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `workflow_id` (object): The ID of the workflow. You can also pass the workflow file name as a string.
### actions_create_workflow_dispatch

POST /repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches - Create a workflow dispatch event

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `workflow_id` (object): The ID of the workflow. You can also pass the workflow file name as a string.
- `ref` (string): The git reference for the workflow. The reference can be a branch or tag name.
- `inputs` (object, optional): Input keys and values configured in the workflow file. The maximum number of properties is 25. Any default properties configured in the workflow file will be used when `inputs` are omitted.
- `return_run_details` (boolean, optional): Whether the response should include the workflow run ID and URLs.
### actions_enable_workflow

PUT /repos/{owner}/{repo}/actions/workflows/{workflow_id}/enable - Enable a workflow

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `workflow_id` (object): The ID of the workflow. You can also pass the workflow file name as a string.
### actions_list_workflow_runs

GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/runs - List workflow runs for a workflow

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `workflow_id` (object): The ID of the workflow. You can also pass the workflow file name as a string.
- `actor` (string, optional): Returns someone's workflow runs. Use the login for the user who created the `push` associated with the check suite or workflow run.
- `branch` (string, optional): Returns workflow runs associated with a branch. Use the name of the branch of the `push`.
- `event` (string, optional): Returns workflow run triggered by the event you specify. For example, `push`, `pull_request` or `issue`. For more information, see "[Events that trigger workflows](https://docs.github.com/actions/automating-your-workflow-with-github-actions/events-that-trigger-workflows)."
- `status` (string, optional): Returns workflow runs with the check run `status` or `conclusion` that you specify. For example, a conclusion can be `success` or a status can be `in_progress`. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. — one of: completed, action_required, cancelled, failure, neutral, skipped, stale, success, timed_out, in_progress, queued, requested, waiting, pending
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `created` (string, optional): Returns workflow runs created within the given date-time range. For more information on the syntax, see "[Understanding the search syntax](https://docs.github.com/search-github/getting-started-with-searching-on-github/understanding-the-search-syntax#query-for-dates)."
- `exclude_pull_requests` (boolean, optional): If `true` pull requests are omitted from the response (empty array). (default: False)
- `check_suite_id` (integer, optional): Returns workflow runs with the `check_suite_id` that you specify.
- `head_sha` (string, optional): Only returns workflow runs that are associated with the specified `head_sha`.
### actions_get_workflow_usage

GET /repos/{owner}/{repo}/actions/workflows/{workflow_id}/timing - Get workflow usage

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `workflow_id` (object): The ID of the workflow. You can also pass the workflow file name as a string.
### repos_list_activities

GET /repos/{owner}/{repo}/activity - List repository activities

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `ref` (string, optional): The Git reference for the activities you want to list.

The `ref` for a branch can be formatted either as `refs/heads/BRANCH_NAME` or `BRANCH_NAME`, where `BRANCH_NAME` is the name of your branch.
- `actor` (string, optional): The GitHub username to use to filter by the actor who performed the activity.
- `time_period` (string, optional): The time period to filter by.

For example, `day` will filter for activity that occurred in the past 24 hours, and `week` will filter for activity that occurred in the past 7 days (168 hours). — one of: day, week, month, quarter, year
- `activity_type` (string, optional): The activity type to filter by.

For example, you can choose to filter by "force_push", to see all force pushes to the repository. — one of: push, force_push, branch_creation, branch_deletion, pr_merge, merge_queue_merge
### issues_list_assignees

GET /repos/{owner}/{repo}/assignees - List assignees

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_check_user_can_be_assigned

GET /repos/{owner}/{repo}/assignees/{assignee} - Check if a user can be assigned

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `assignee` (string): 
### repos_create_attestation

POST /repos/{owner}/{repo}/attestations - Create an attestation

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `bundle` (object): The attestation's Sigstore Bundle.
Refer to the [Sigstore Bundle Specification](https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto) for more information.
### repos_list_attestations

GET /repos/{owner}/{repo}/attestations/{subject_digest} - List attestations

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `subject_digest` (string): The parameter should be set to the attestation's subject's SHA256 digest, in the form `sha256:HEX_DIGEST`.
- `predicate_type` (string, optional): Optional filter for fetching attestations with a given predicate type.
This option accepts `provenance`, `sbom`, `release`, or freeform text
for custom predicate types.
### repos_create_autolink

POST /repos/{owner}/{repo}/autolinks - Create an autolink reference for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `key_prefix` (string): This prefix appended by certain characters will generate a link any time it is found in an issue, pull request, or commit.
- `url_template` (string): The URL must contain `<num>` for the reference number. `<num>` matches different characters depending on the value of `is_alphanumeric`.
- `is_alphanumeric` (boolean, optional): Whether this autolink reference matches alphanumeric characters. If true, the `<num>` parameter of the `url_template` matches alphanumeric characters `A-Z` (case insensitive), `0-9`, and `-`. If false, this autolink reference only matches numeric characters. (default: True)
### repos_list_autolinks

GET /repos/{owner}/{repo}/autolinks - Get all autolinks of a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_delete_autolink

DELETE /repos/{owner}/{repo}/autolinks/{autolink_id} - Delete an autolink reference from a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `autolink_id` (integer): The unique identifier of the autolink.
### repos_get_autolink

GET /repos/{owner}/{repo}/autolinks/{autolink_id} - Get an autolink reference of a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `autolink_id` (integer): The unique identifier of the autolink.
### repos_disable_automated_security_fixes

DELETE /repos/{owner}/{repo}/automated-security-fixes - Disable Dependabot security updates

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_enable_automated_security_fixes

PUT /repos/{owner}/{repo}/automated-security-fixes - Enable Dependabot security updates

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_check_automated_security_fixes

GET /repos/{owner}/{repo}/automated-security-fixes - Check if Dependabot security updates are enabled for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_list_branches

GET /repos/{owner}/{repo}/branches - List branches

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `protected` (boolean, optional): Setting to `true` returns only branches protected by branch protections or rulesets. When set to `false`, only unprotected branches are returned. Omitting this parameter returns all branches.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_branch

GET /repos/{owner}/{repo}/branches/{branch} - Get a branch

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_delete_branch_protection

DELETE /repos/{owner}/{repo}/branches/{branch}/protection - Delete branch protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_update_branch_protection

PUT /repos/{owner}/{repo}/branches/{branch}/protection - Update branch protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `required_status_checks` (object): Require status checks to pass before merging. Set to `null` to disable.
- `enforce_admins` (boolean): Enforce all configured restrictions for administrators. Set to `true` to enforce required status checks for repository administrators. Set to `null` to disable.
- `required_pull_request_reviews` (object): Require at least one approving review on a pull request, before merging. Set to `null` to disable.
- `restrictions` (object): Restrict who can push to the protected branch. User, app, and team `restrictions` are only available for organization-owned repositories. Set to `null` to disable.
- `required_linear_history` (boolean, optional): Enforces a linear commit Git history, which prevents anyone from pushing merge commits to a branch. Set to `true` to enforce a linear commit history. Set to `false` to disable a linear commit Git history. Your repository must allow squash merging or rebase merging before you can enable a linear commit history. Default: `false`. For more information, see "[Requiring a linear commit history](https://docs.github.com/github/administering-a-repository/requiring-a-linear-commit-history)" in the GitHub Help documentation.
- `allow_force_pushes` (boolean, optional): Permits force pushes to the protected branch by anyone with write access to the repository. Set to `true` to allow force pushes. Set to `false` or `null` to block force pushes. Default: `false`. For more information, see "[Enabling force pushes to a protected branch](https://docs.github.com/github/administering-a-repository/enabling-force-pushes-to-a-protected-branch)" in the GitHub Help documentation."
- `allow_deletions` (boolean, optional): Allows deletion of the protected branch by anyone with write access to the repository. Set to `false` to prevent deletion of the protected branch. Default: `false`. For more information, see "[Enabling force pushes to a protected branch](https://docs.github.com/github/administering-a-repository/enabling-force-pushes-to-a-protected-branch)" in the GitHub Help documentation.
- `block_creations` (boolean, optional): If set to `true`, the `restrictions` branch protection settings which limits who can push will also block pushes which create new branches, unless the push is initiated by a user, team, or app which has the ability to push. Set to `true` to restrict new branch creation. Default: `false`.
- `required_conversation_resolution` (boolean, optional): Requires all conversations on code to be resolved before a pull request can be merged into a branch that matches this rule. Set to `false` to disable. Default: `false`.
- `lock_branch` (boolean, optional): Whether to set the branch as read-only. If this is true, users will not be able to push to the branch. Default: `false`. (default: False)
- `allow_fork_syncing` (boolean, optional): Whether users can pull changes from upstream when the branch is locked. Set to `true` to allow fork syncing. Set to `false` to prevent fork syncing. Default: `false`. (default: False)
### repos_get_branch_protection

GET /repos/{owner}/{repo}/branches/{branch}/protection - Get branch protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_set_admin_branch_protection

POST /repos/{owner}/{repo}/branches/{branch}/protection/enforce_admins - Set admin branch protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_delete_admin_branch_protection

DELETE /repos/{owner}/{repo}/branches/{branch}/protection/enforce_admins - Delete admin branch protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_get_admin_branch_protection

GET /repos/{owner}/{repo}/branches/{branch}/protection/enforce_admins - Get admin branch protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_update_pull_request_review_protection

PATCH /repos/{owner}/{repo}/branches/{branch}/protection/required_pull_request_reviews - Update pull request review protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `dismissal_restrictions` (object, optional): Specify which users, teams, and apps can dismiss pull request reviews. Pass an empty `dismissal_restrictions` object to disable. User and team `dismissal_restrictions` are only available for organization-owned repositories. Omit this parameter for personal repositories.
- `dismiss_stale_reviews` (boolean, optional): Set to `true` if you want to automatically dismiss approving reviews when someone pushes a new commit.
- `require_code_owner_reviews` (boolean, optional): Blocks merging pull requests until [code owners](https://docs.github.com/articles/about-code-owners/) have reviewed.
- `required_approving_review_count` (integer, optional): Specifies the number of reviewers required to approve pull requests. Use a number between 1 and 6 or 0 to not require reviewers.
- `require_last_push_approval` (boolean, optional): Whether the most recent push must be approved by someone other than the person who pushed it. Default: `false` (default: False)
- `bypass_pull_request_allowances` (object, optional): Allow specific users, teams, or apps to bypass pull request requirements.
### repos_delete_pull_request_review_protection

DELETE /repos/{owner}/{repo}/branches/{branch}/protection/required_pull_request_reviews - Delete pull request review protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_get_pull_request_review_protection

GET /repos/{owner}/{repo}/branches/{branch}/protection/required_pull_request_reviews - Get pull request review protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_create_commit_signature_protection

POST /repos/{owner}/{repo}/branches/{branch}/protection/required_signatures - Create commit signature protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_delete_commit_signature_protection

DELETE /repos/{owner}/{repo}/branches/{branch}/protection/required_signatures - Delete commit signature protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_get_commit_signature_protection

GET /repos/{owner}/{repo}/branches/{branch}/protection/required_signatures - Get commit signature protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_update_status_check_protection

PATCH /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks - Update status check protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `strict` (boolean, optional): Require branches to be up to date before merging.
- `contexts` (array, optional): **Closing down notice**: The list of status checks to require in order to merge into this branch. If any of these checks have recently been set by a particular GitHub App, they will be required to come from that app in future for the branch to merge. Use `checks` instead of `contexts` for more fine-grained control.
- `checks` (array, optional): The list of status checks to require in order to merge into this branch.
### repos_remove_status_check_protection

DELETE /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks - Remove status check protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_get_status_checks_protection

GET /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks - Get status checks protection

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_add_status_check_contexts

POST /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts - Add status check contexts

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `body` (object, optional): Request body
### repos_remove_status_check_contexts

DELETE /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts - Remove status check contexts

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `body` (object): Request body
### repos_set_status_check_contexts

PUT /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts - Set status check contexts

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `body` (object, optional): Request body
### repos_get_all_status_check_contexts

GET /repos/{owner}/{repo}/branches/{branch}/protection/required_status_checks/contexts - Get all status check contexts

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_delete_access_restrictions

DELETE /repos/{owner}/{repo}/branches/{branch}/protection/restrictions - Delete access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_get_access_restrictions

GET /repos/{owner}/{repo}/branches/{branch}/protection/restrictions - Get access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_add_app_access_restrictions

POST /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps - Add app access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `apps` (array): The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note**: The list of users, apps, and teams in total is limited to 100 items.
### repos_remove_app_access_restrictions

DELETE /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps - Remove app access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `apps` (array): The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note**: The list of users, apps, and teams in total is limited to 100 items.
### repos_set_app_access_restrictions

PUT /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps - Set app access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `apps` (array): The GitHub Apps that have push access to this branch. Use the slugified version of the app name. **Note**: The list of users, apps, and teams in total is limited to 100 items.
### repos_get_apps_with_access_to_protected_branch

GET /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/apps - Get apps with access to the protected branch

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_add_team_access_restrictions

POST /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams - Add team access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `body` (object, optional): Request body
### repos_remove_team_access_restrictions

DELETE /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams - Remove team access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `body` (object): Request body
### repos_set_team_access_restrictions

PUT /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams - Set team access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `body` (object, optional): Request body
### repos_get_teams_with_access_to_protected_branch

GET /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/teams - Get teams with access to the protected branch

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_add_user_access_restrictions

POST /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users - Add user access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `users` (array): The username for users
### repos_remove_user_access_restrictions

DELETE /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users - Remove user access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `users` (array): The username for users
### repos_set_user_access_restrictions

PUT /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users - Set user access restrictions

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `users` (array): The username for users
### repos_get_users_with_access_to_protected_branch

GET /repos/{owner}/{repo}/branches/{branch}/protection/restrictions/users - Get users with access to the protected branch

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
### repos_rename_branch

POST /repos/{owner}/{repo}/branches/{branch}/rename - Rename a branch

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `new_name` (string): The new name of the branch.
### checks_create

POST /repos/{owner}/{repo}/check-runs - Create a check run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the check. For example, "code-coverage".
- `head_sha` (string): The SHA of the commit.
- `details_url` (string, optional): The URL of the integrator's site that has the full details of the check. If the integrator does not provide this, then the homepage of the GitHub app is used.
- `external_id` (string, optional): A reference for the run on the integrator's system.
- `status` (string, optional): The current status of the check run. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`. (default: queued)
- `started_at` (string, optional): The time that the check run began. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `conclusion` (string, optional): **Required if you provide `completed_at` or a `status` of `completed`**. The final conclusion of the check. 
**Note:** Providing `conclusion` will automatically set the `status` parameter to `completed`. You cannot change a check run conclusion to `stale`, only GitHub can set this.
- `completed_at` (string, optional): The time the check completed. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `output` (object, optional): Check runs can accept a variety of data in the `output` object, including a `title` and `summary` and can optionally provide descriptive details about the run.
- `actions` (array, optional): Displays a button on GitHub that can be clicked to alert your app to do additional tasks. For example, a code linting app can display a button that automatically fixes detected errors. The button created in this object is displayed after the check run completes. When a user clicks the button, GitHub sends the [`check_run.requested_action` webhook](https://docs.github.com/webhooks/event-payloads/#check_run) to your app. Each action includes a `label`, `identifier` and `description`. A maximum of three actions are accepted. To learn more about check runs and requested actions, see "[Check runs and requested actions](https://docs.github.com/rest/guides/using-the-rest-api-to-interact-with-checks#check-runs-and-requested-actions)."
### checks_update

PATCH /repos/{owner}/{repo}/check-runs/{check_run_id} - Update a check run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `check_run_id` (integer): The unique identifier of the check run.
- `name` (string, optional): The name of the check. For example, "code-coverage".
- `details_url` (string, optional): The URL of the integrator's site that has the full details of the check.
- `external_id` (string, optional): A reference for the run on the integrator's system.
- `started_at` (string, optional): This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `status` (string, optional): The current status of the check run. Only GitHub Actions can set a status of `waiting`, `pending`, or `requested`.
- `conclusion` (string, optional): **Required if you provide `completed_at` or a `status` of `completed`**. The final conclusion of the check. 
**Note:** Providing `conclusion` will automatically set the `status` parameter to `completed`. You cannot change a check run conclusion to `stale`, only GitHub can set this.
- `completed_at` (string, optional): The time the check completed. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `output` (object, optional): Check runs can accept a variety of data in the `output` object, including a `title` and `summary` and can optionally provide descriptive details about the run.
- `actions` (array, optional): Possible further actions the integrator can perform, which a user may trigger. Each action includes a `label`, `identifier` and `description`. A maximum of three actions are accepted. To learn more about check runs and requested actions, see "[Check runs and requested actions](https://docs.github.com/rest/guides/using-the-rest-api-to-interact-with-checks#check-runs-and-requested-actions)."
### checks_get

GET /repos/{owner}/{repo}/check-runs/{check_run_id} - Get a check run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `check_run_id` (integer): The unique identifier of the check run.
### checks_list_annotations

GET /repos/{owner}/{repo}/check-runs/{check_run_id}/annotations - List check run annotations

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `check_run_id` (integer): The unique identifier of the check run.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### checks_rerequest_run

POST /repos/{owner}/{repo}/check-runs/{check_run_id}/rerequest - Rerequest a check run

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `check_run_id` (integer): The unique identifier of the check run.
### checks_create_suite

POST /repos/{owner}/{repo}/check-suites - Create a check suite

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `head_sha` (string): The sha of the head commit.
### checks_set_suites_preferences

PATCH /repos/{owner}/{repo}/check-suites/preferences - Update repository preferences for check suites

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `auto_trigger_checks` (array, optional): Enables or disables automatic creation of CheckSuite events upon pushes to the repository. Enabled by default.
### checks_get_suite

GET /repos/{owner}/{repo}/check-suites/{check_suite_id} - Get a check suite

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `check_suite_id` (integer): The unique identifier of the check suite.
### checks_list_for_suite

GET /repos/{owner}/{repo}/check-suites/{check_suite_id}/check-runs - List check runs in a check suite

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `check_suite_id` (integer): The unique identifier of the check suite.
- `check_name` (string, optional): Returns check runs with the specified `name`.
- `status` (string, optional): Returns check runs with the specified `status`. — one of: queued, in_progress, completed
- `filter` (string, optional): Filters check runs by their `completed_at` timestamp. `latest` returns the most recent check runs. (default: latest) — one of: latest, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### checks_rerequest_suite

POST /repos/{owner}/{repo}/check-suites/{check_suite_id}/rerequest - Rerequest a check suite

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `check_suite_id` (integer): The unique identifier of the check suite.
### code_scanning_list_alerts_for_repo

GET /repos/{owner}/{repo}/code-scanning/alerts - List code scanning alerts for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tool_name` (string, optional): The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both.
- `tool_guid` (string, optional): The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `ref` (string, optional): The Git reference for the results you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
- `pr` (integer, optional): The number of the pull request for the results you want to list.
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `sort` (string, optional): The property by which to sort the results. (default: created) — one of: created, updated
- `state` (string, optional): If specified, only code scanning alerts with this state will be returned. — one of: open, closed, dismissed, fixed
- `severity` (string, optional): If specified, only code scanning alerts with this severity will be returned. — one of: critical, high, medium, low, warning, note, error
- `assignees` (string, optional): Filter alerts by assignees. Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`).
Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees.

### code_scanning_update_alert

PATCH /repos/{owner}/{repo}/code-scanning/alerts/{alert_number} - Update a code scanning alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
- `state` (string, optional): 
- `dismissed_reason` (string, optional): 
- `dismissed_comment` (string, optional): 
- `create_request` (boolean, optional): 
- `assignees` (array, optional): 
### code_scanning_get_alert

GET /repos/{owner}/{repo}/code-scanning/alerts/{alert_number} - Get a code scanning alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
### code_scanning_create_autofix

POST /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/autofix - Create an autofix for a code scanning alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
### code_scanning_get_autofix

GET /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/autofix - Get the status of an autofix for a code scanning alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
### code_scanning_commit_autofix

POST /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/autofix/commits - Commit an autofix for a code scanning alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
- `target_ref` (string, optional): The Git reference of target branch for the commit. Branch needs to already exist.  For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
- `message` (string, optional): Commit message to be used.
### code_scanning_list_alert_instances

GET /repos/{owner}/{repo}/code-scanning/alerts/{alert_number}/instances - List instances of a code scanning alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `ref` (string, optional): The Git reference for the results you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
- `pr` (integer, optional): The number of the pull request for the results you want to list.
### code_scanning_list_recent_analyses

GET /repos/{owner}/{repo}/code-scanning/analyses - List code scanning analyses for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tool_name` (string, optional): The name of a code scanning tool. Only results by this tool will be listed. You can specify the tool by using either `tool_name` or `tool_guid`, but not both.
- `tool_guid` (string, optional): The GUID of a code scanning tool. Only results by this tool will be listed. Note that some code scanning tools may not include a GUID in their analysis data. You can specify the tool by using either `tool_guid` or `tool_name`, but not both.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `pr` (integer, optional): The number of the pull request for the results you want to list.
- `ref` (string, optional): The Git reference for the analyses you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
- `sarif_id` (string, optional): Filter analyses belonging to the same SARIF upload.
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `sort` (string, optional): The property by which to sort the results. (default: created) — one of: created
### code_scanning_delete_analysis

DELETE /repos/{owner}/{repo}/code-scanning/analyses/{analysis_id} - Delete a code scanning analysis from a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `analysis_id` (integer): The ID of the analysis, as returned from the `GET /repos/{owner}/{repo}/code-scanning/analyses` operation.
- `confirm_delete` (string, optional): Allow deletion if the specified analysis is the last in a set. If you attempt to delete the final analysis in a set without setting this parameter to `true`, you'll get a 400 response with the message: `Analysis is last of its type and deletion may result in the loss of historical alert data. Please specify confirm_delete.`
### code_scanning_get_analysis

GET /repos/{owner}/{repo}/code-scanning/analyses/{analysis_id} - Get a code scanning analysis for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `analysis_id` (integer): The ID of the analysis, as returned from the `GET /repos/{owner}/{repo}/code-scanning/analyses` operation.
### code_scanning_list_codeql_databases

GET /repos/{owner}/{repo}/code-scanning/codeql/databases - List CodeQL databases for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### code_scanning_delete_codeql_database

DELETE /repos/{owner}/{repo}/code-scanning/codeql/databases/{language} - Delete a CodeQL database

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `language` (string): The language of the CodeQL database.
### code_scanning_get_codeql_database

GET /repos/{owner}/{repo}/code-scanning/codeql/databases/{language} - Get a CodeQL database for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `language` (string): The language of the CodeQL database.
### code_scanning_create_variant_analysis

POST /repos/{owner}/{repo}/code-scanning/codeql/variant-analyses - Create a CodeQL variant analysis

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `language` (string): 
- `query_pack` (string): A Base64-encoded tarball containing a CodeQL query and all its dependencies
- `repositories` (array, optional): List of repository names (in the form `owner/repo-name`) to run the query against. Precisely one property from `repositories`, `repository_lists` and `repository_owners` is required.
- `repository_lists` (array, optional): List of repository lists to run the query against. Precisely one property from `repositories`, `repository_lists` and `repository_owners` is required.
- `repository_owners` (array, optional): List of organization or user names whose repositories the query should be run against. Precisely one property from `repositories`, `repository_lists` and `repository_owners` is required.
### code_scanning_get_variant_analysis

GET /repos/{owner}/{repo}/code-scanning/codeql/variant-analyses/{codeql_variant_analysis_id} - Get the summary of a CodeQL variant analysis

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `codeql_variant_analysis_id` (integer): The unique identifier of the variant analysis.
### code_scanning_get_variant_analysis_repo_task

GET /repos/{owner}/{repo}/code-scanning/codeql/variant-analyses/{codeql_variant_analysis_id}/repos/{repo_owner}/{repo_name} - Get the analysis status of a repository in a CodeQL variant analysis

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the controller repository.
- `codeql_variant_analysis_id` (integer): The ID of the variant analysis.
- `repo_owner` (string): The account owner of the variant analysis repository. The name is not case sensitive.
- `repo_name` (string): The name of the variant analysis repository.
### code_scanning_update_default_setup

PATCH /repos/{owner}/{repo}/code-scanning/default-setup - Update a code scanning default setup configuration

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `state` (string, optional): The desired state of code scanning default setup.
- `runner_type` (string, optional): Runner type to be used.
- `runner_label` (string, optional): Runner label to be used if the runner type is labeled.
- `query_suite` (string, optional): CodeQL query suite to be used.
- `threat_model` (string, optional): Threat model to be used for code scanning analysis. Use `remote` to analyze only network sources and `remote_and_local` to include local sources like filesystem access, command-line arguments, database reads, environment variable and standard input.
- `languages` (array, optional): CodeQL languages to be analyzed.
### code_scanning_get_default_setup

GET /repos/{owner}/{repo}/code-scanning/default-setup - Get a code scanning default setup configuration

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### code_scanning_upload_sarif

POST /repos/{owner}/{repo}/code-scanning/sarifs - Upload an analysis as SARIF data

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `commit_sha` (string): 
- `ref` (string): 
- `sarif` (string): 
- `checkout_uri` (string, optional): The base directory used in the analysis, as it appears in the SARIF file.
This property is used to convert file paths from absolute to relative, so that alerts can be mapped to their correct location in the repository.
- `started_at` (string, optional): The time that the analysis run began. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `tool_name` (string, optional): The name of the tool used to generate the code scanning analysis. If this parameter is not used, the tool name defaults to "API". If the uploaded SARIF contains a tool GUID, this will be available for filtering using the `tool_guid` parameter of operations such as `GET /repos/{owner}/{repo}/code-scanning/alerts`.
- `validate` (boolean, optional): Whether the SARIF file will be validated according to the code scanning specifications.
This parameter is intended to help integrators ensure that the uploaded SARIF files are correctly rendered by code scanning.
### code_scanning_get_sarif

GET /repos/{owner}/{repo}/code-scanning/sarifs/{sarif_id} - Get information about a SARIF upload

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `sarif_id` (string): The SARIF ID obtained after uploading.
### code_security_get_configuration_for_repository

GET /repos/{owner}/{repo}/code-security-configuration - Get the code security configuration associated with a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_codeowners_errors

GET /repos/{owner}/{repo}/codeowners/errors - List CODEOWNERS errors

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string, optional): A branch, tag or commit name used to determine which version of the CODEOWNERS file to use. Default: the repository's default branch (e.g. `main`)
### post_repos_by_owner_by_repo_codespaces

POST /repos/{owner}/{repo}/codespaces - Create a codespace in a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string, optional): Git ref (typically a branch name) for this codespace
- `location` (string, optional): The requested location for a new codespace. Best efforts are made to respect this upon creation. Assigned by IP if not provided.
- `geo` (string, optional): The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down.
- `client_ip` (string, optional): IP for location auto-detection when proxying a request
- `machine` (string, optional): Machine type to use for this codespace
- `devcontainer_path` (string, optional): Path to devcontainer.json config to use for this codespace
- `multi_repo_permissions_opt_out` (boolean, optional): Whether to authorize requested permissions from devcontainer.json
- `working_directory` (string, optional): Working directory for this codespace
- `idle_timeout_minutes` (integer, optional): Time in minutes before codespace stops from inactivity
- `display_name` (string, optional): Display name for this codespace
- `retention_period_minutes` (integer, optional): Duration in minutes after codespace has gone idle in which it will be deleted. Must be integer minutes between 0 and 43200 (30 days).
### get_repos_by_owner_by_repo_codespaces

GET /repos/{owner}/{repo}/codespaces - List codespaces in a repository for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### get_repos_by_owner_by_repo_codespaces_devcontainers

GET /repos/{owner}/{repo}/codespaces/devcontainers - List devcontainer configurations in a repository for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### codespaces_repo_machines_for_authenticated_user

GET /repos/{owner}/{repo}/codespaces/machines - List available machine types for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `location` (string, optional): The location to check for available machines. Assigned by IP if not provided.
- `client_ip` (string, optional): IP for location auto-detection when proxying a request
- `ref` (string, optional): The branch or commit to check for prebuild availability and devcontainer restrictions.
### get_repos_by_owner_by_repo_codespaces_new

GET /repos/{owner}/{repo}/codespaces/new - Get default attributes for a codespace

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string, optional): The branch or commit to check for a default devcontainer path. If not specified, the default branch will be checked.
- `client_ip` (string, optional): An alternative IP for default location auto-detection, such as when proxying a request.
### codespaces_check_permissions_for_devcontainer

GET /repos/{owner}/{repo}/codespaces/permissions_check - Check if permissions defined by a devcontainer have been accepted by the authenticated user

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The git reference that points to the location of the devcontainer configuration to use for the permission check. The value of `ref` will typically be a branch name (`heads/BRANCH_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
- `devcontainer_path` (string): Path to the devcontainer.json configuration to use for the permission check.
### codespaces_list_repo_secrets

GET /repos/{owner}/{repo}/codespaces/secrets - List repository secrets

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### codespaces_get_repo_public_key

GET /repos/{owner}/{repo}/codespaces/secrets/public-key - Get a repository public key

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### codespaces_delete_repo_secret

DELETE /repos/{owner}/{repo}/codespaces/secrets/{secret_name} - Delete a repository secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### codespaces_create_or_update_repo_secret

PUT /repos/{owner}/{repo}/codespaces/secrets/{secret_name} - Create or update a repository secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `encrypted_value` (string, optional): Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get a repository public key](https://docs.github.com/rest/codespaces/repository-secrets#get-a-repository-public-key) endpoint.
- `key_id` (string, optional): ID of the key you used to encrypt the secret.
### codespaces_get_repo_secret

GET /repos/{owner}/{repo}/codespaces/secrets/{secret_name} - Get a repository secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### repos_list_collaborators

GET /repos/{owner}/{repo}/collaborators - List repository collaborators

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `affiliation` (string, optional): Filter collaborators returned by their affiliation. `outside` means all outside collaborators of an organization-owned repository. `direct` means all collaborators with permissions to an organization-owned repository, regardless of organization membership status. `all` means all collaborators the authenticated user can see. (default: all) — one of: outside, direct, all
- `permission` (string, optional): Filter collaborators by the permissions they have on the repository. If not specified, all collaborators will be returned. — one of: pull, triage, push, maintain, admin
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_remove_collaborator

DELETE /repos/{owner}/{repo}/collaborators/{username} - Remove a repository collaborator

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### repos_add_collaborator

PUT /repos/{owner}/{repo}/collaborators/{username} - Add a repository collaborator

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
- `permission` (string, optional): The permission to grant the collaborator. **Only valid on organization-owned repositories.** We accept the following permissions to be set: `pull`, `triage`, `push`, `maintain`, `admin` and you can also specify a custom repository role name, if the owning organization has defined any. (default: push)
### repos_check_collaborator

GET /repos/{owner}/{repo}/collaborators/{username} - Check if a user is a repository collaborator

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### repos_get_collaborator_permission_level

GET /repos/{owner}/{repo}/collaborators/{username}/permission - Get repository permissions for a user

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `username` (string): The handle for the GitHub user account.
### repos_list_commit_comments_for_repo

GET /repos/{owner}/{repo}/comments - List commit comments for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_update_commit_comment

PATCH /repos/{owner}/{repo}/comments/{comment_id} - Update a commit comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `body` (string): The contents of the comment
### repos_delete_commit_comment

DELETE /repos/{owner}/{repo}/comments/{comment_id} - Delete a commit comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
### repos_get_commit_comment

GET /repos/{owner}/{repo}/comments/{comment_id} - Get a commit comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
### reactions_create_for_commit_comment

POST /repos/{owner}/{repo}/comments/{comment_id}/reactions - Create reaction for a commit comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `content` (string): The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the commit comment.
### reactions_list_for_commit_comment

GET /repos/{owner}/{repo}/comments/{comment_id}/reactions - List reactions for a commit comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `content` (string, optional): Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to a commit comment. — one of: +1, -1, laugh, confused, heart, hooray, rocket, eyes
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### reactions_delete_for_commit_comment

DELETE /repos/{owner}/{repo}/comments/{comment_id}/reactions/{reaction_id} - Delete a commit comment reaction

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `reaction_id` (integer): The unique identifier of the reaction.
### repos_list_commits

GET /repos/{owner}/{repo}/commits - List commits

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `sha` (string, optional): SHA or branch to start listing commits from. Default: the repository’s default branch (usually `main`).
- `path` (string, optional): Only commits containing this file path will be returned.
- `author` (string, optional): GitHub username or email address to use to filter by commit author.
- `committer` (string, optional): GitHub username or email address to use to filter by commit committer.
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Due to limitations of Git, timestamps must be between 1970-01-01 and 2099-12-31 (inclusive) or unexpected results may be returned.
- `until` (string, optional): Only commits before this date will be returned. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Due to limitations of Git, timestamps must be between 1970-01-01 and 2099-12-31 (inclusive) or unexpected results may be returned.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_list_branches_for_head_commit

GET /repos/{owner}/{repo}/commits/{commit_sha}/branches-where-head - List branches for HEAD commit

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `commit_sha` (string): The SHA of the commit.
### repos_create_commit_comment

POST /repos/{owner}/{repo}/commits/{commit_sha}/comments - Create a commit comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `commit_sha` (string): The SHA of the commit.
- `body` (string): The contents of the comment.
- `path` (string, optional): Relative path of the file to comment on.
- `position` (integer, optional): Line index in the diff to comment on.
- `line` (integer, optional): **Closing down notice**. Use **position** parameter instead. Line number in the file to comment on.
### repos_list_comments_for_commit

GET /repos/{owner}/{repo}/commits/{commit_sha}/comments - List commit comments

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `commit_sha` (string): The SHA of the commit.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_list_pull_requests_associated_with_commit

GET /repos/{owner}/{repo}/commits/{commit_sha}/pulls - List pull requests associated with a commit

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `commit_sha` (string): The SHA of the commit.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_commit

GET /repos/{owner}/{repo}/commits/{ref} - Get a commit

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `ref` (string): The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
### checks_list_for_ref

GET /repos/{owner}/{repo}/commits/{ref}/check-runs - List check runs for a Git reference

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
- `check_name` (string, optional): Returns check runs with the specified `name`.
- `status` (string, optional): Returns check runs with the specified `status`. — one of: queued, in_progress, completed
- `filter` (string, optional): Filters check runs by their `completed_at` timestamp. `latest` returns the most recent check runs. (default: latest) — one of: latest, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `app_id` (integer, optional): 
### checks_list_suites_for_ref

GET /repos/{owner}/{repo}/commits/{ref}/check-suites - List check suites for a Git reference

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
- `app_id` (integer, optional): Filters check suites by GitHub App `id`.
- `check_name` (string, optional): Returns check runs with the specified `name`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_combined_status_for_ref

GET /repos/{owner}/{repo}/commits/{ref}/status - Get the combined status for a specific reference

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_list_commit_statuses_for_ref

GET /repos/{owner}/{repo}/commits/{ref}/statuses - List commit statuses for a reference

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_community_profile_metrics

GET /repos/{owner}/{repo}/community/profile - Get community profile metrics

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_compare_commits

GET /repos/{owner}/{repo}/compare/{basehead} - Compare two commits

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `basehead` (string): The base branch and head branch to compare. This parameter expects the format `BASE...HEAD`. Both must be branch names in `repo`. To compare with a branch that exists in a different repository in the same network as `repo`, the `basehead` parameter expects the format `USERNAME:BASE...USERNAME:HEAD`.
### repos_delete_file

DELETE /repos/{owner}/{repo}/contents/{path} - Delete a file

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `path` (string): path parameter
- `message` (string): The commit message.
- `sha` (string): The blob SHA of the file being deleted.
- `branch` (string, optional): The branch name. Default: the repository’s default branch
- `committer` (object, optional): object containing information about the committer.
- `author` (object, optional): object containing information about the author.
### repos_create_or_update_file_contents

PUT /repos/{owner}/{repo}/contents/{path} - Create or update file contents

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `path` (string): path parameter
- `message` (string): The commit message.
- `content` (string): The new file content, using Base64 encoding.
- `sha` (string, optional): **Required if you are updating a file**. The blob SHA of the file being replaced.
- `branch` (string, optional): The branch name. Default: the repository’s default branch.
- `committer` (object, optional): The person that committed the file. Default: the authenticated user.
- `author` (object, optional): The author of the file. Default: The `committer` or the authenticated user if you omit `committer`.
### repos_get_content

GET /repos/{owner}/{repo}/contents/{path} - Get repository content

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `path` (string): path parameter
- `ref` (string, optional): The name of the commit/branch/tag. Default: the repository’s default branch.
### repos_list_contributors

GET /repos/{owner}/{repo}/contributors - List repository contributors

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `anon` (string, optional): Set to `1` or `true` to include anonymous contributors in results.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### dependabot_list_alerts_for_repo

GET /repos/{owner}/{repo}/dependabot/alerts - List Dependabot alerts for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `state` (string, optional): A comma-separated list of states. If specified, only alerts with these states will be returned.

Can be: `auto_dismissed`, `dismissed`, `fixed`, `open`
- `severity` (string, optional): A comma-separated list of severities. If specified, only alerts with these severities will be returned.

Can be: `low`, `medium`, `high`, `critical`
- `ecosystem` (string, optional): A comma-separated list of ecosystems. If specified, only alerts for these ecosystems will be returned.

Can be: `composer`, `go`, `maven`, `npm`, `nuget`, `pip`, `pub`, `rubygems`, `rust`
- `package` (string, optional): A comma-separated list of package names. If specified, only alerts for these packages will be returned.
- `manifest` (string, optional): A comma-separated list of full manifest paths. If specified, only alerts for these manifests will be returned.
- `epss_percentage` (string, optional): CVE Exploit Prediction Scoring System (EPSS) percentage. Can be specified as:
- An exact number (`n`)
- Comparators such as `>n`, `<n`, `>=n`, `<=n`
- A range like `n..n`, where `n` is a number from 0.0 to 1.0

Filters the list of alerts based on EPSS percentages. If specified, only alerts with the provided EPSS percentages will be returned.
- `has` (object, optional): Filters the list of alerts based on whether the alert has the given value. If specified, only alerts meeting this criterion will be returned.
Multiple `has` filters can be passed to filter for alerts that have all of the values. Currently, only `patch` is supported.
- `assignee` (string, optional): Filter alerts by assignees.
Provide a comma-separated list of user handles (e.g., `octocat` or `octocat,hubot`) to return alerts assigned to any of the specified users.
Use `*` to list alerts with at least one assignee or `none` to list alerts with no assignees.
- `scope` (string, optional): The scope of the vulnerable dependency. If specified, only alerts with this scope will be returned. — one of: development, runtime
- `sort` (string, optional): The property by which to sort the results.
`created` means when the alert was created.
`updated` means when the alert's state last changed.
`epss_percentage` sorts alerts by the Exploit Prediction Scoring System (EPSS) percentage. (default: created) — one of: created, updated, epss_percentage
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### dependabot_update_alert

PATCH /repos/{owner}/{repo}/dependabot/alerts/{alert_number} - Update a Dependabot alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies a Dependabot alert in its repository.
You can find this at the end of the URL for a Dependabot alert within GitHub,
or in `number` fields in the response from the
`GET /repos/{owner}/{repo}/dependabot/alerts` operation.
- `state` (string, optional): The state of the Dependabot alert.
A `dismissed_reason` must be provided when setting the state to `dismissed`.
- `dismissed_reason` (string, optional): **Required when `state` is `dismissed`.** A reason for dismissing the alert.
- `dismissed_comment` (string, optional): An optional comment associated with dismissing the alert.
- `assignees` (array, optional): Usernames to assign to this Dependabot Alert.
Pass one or more user logins to _replace_ the set of assignees on this alert.
Send an empty array (`[]`) to clear all assignees from the alert.
### dependabot_get_alert

GET /repos/{owner}/{repo}/dependabot/alerts/{alert_number} - Get a Dependabot alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies a Dependabot alert in its repository.
You can find this at the end of the URL for a Dependabot alert within GitHub,
or in `number` fields in the response from the
`GET /repos/{owner}/{repo}/dependabot/alerts` operation.
### dependabot_list_repo_secrets

GET /repos/{owner}/{repo}/dependabot/secrets - List repository secrets

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### dependabot_get_repo_public_key

GET /repos/{owner}/{repo}/dependabot/secrets/public-key - Get a repository public key

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### dependabot_delete_repo_secret

DELETE /repos/{owner}/{repo}/dependabot/secrets/{secret_name} - Delete a repository secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### dependabot_create_or_update_repo_secret

PUT /repos/{owner}/{repo}/dependabot/secrets/{secret_name} - Create or update a repository secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
- `encrypted_value` (string, optional): Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get a repository public key](https://docs.github.com/rest/dependabot/secrets#get-a-repository-public-key) endpoint.
- `key_id` (string, optional): ID of the key you used to encrypt the secret.
### dependabot_get_repo_secret

GET /repos/{owner}/{repo}/dependabot/secrets/{secret_name} - Get a repository secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `secret_name` (string): The name of the secret.
### dependency_graph_diff_range

GET /repos/{owner}/{repo}/dependency-graph/compare/{basehead} - Get a diff of the dependencies between commits

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `basehead` (string): The base and head Git revisions to compare. The Git revisions will be resolved to commit SHAs. Named revisions will be resolved to their corresponding HEAD commits, and an appropriate merge base will be determined. This parameter expects the format `{base}...{head}`.
- `name` (string, optional): The full path, relative to the repository root, of the dependency manifest file.
### dependency_graph_export_sbom

GET /repos/{owner}/{repo}/dependency-graph/sbom - Export a software bill of materials (SBOM) for a repository.

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### dependency_graph_create_repository_snapshot

POST /repos/{owner}/{repo}/dependency-graph/snapshots - Create a snapshot of dependencies for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `version` (integer): The version of the repository snapshot submission.
- `job` (object): 
- `sha` (string): The commit SHA associated with this dependency snapshot. Maximum length: 40 characters.
- `ref` (string): The repository branch that triggered this snapshot.
- `detector` (object): A description of the detector used.
- `metadata` (object, optional): 
- `manifests` (object, optional): A collection of package manifests, which are a collection of related dependencies declared in a file or representing a logical group of dependencies.
- `scanned` (string): The time at which the snapshot was scanned.
### repos_create_deployment

POST /repos/{owner}/{repo}/deployments - Create a deployment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The ref to deploy. This can be a branch, tag, or SHA.
- `task` (string, optional): Specifies a task to execute (e.g., `deploy` or `deploy:migrations`). (default: deploy)
- `auto_merge` (boolean, optional): Attempts to automatically merge the default branch into the requested ref, if it's behind the default branch. (default: True)
- `required_contexts` (array, optional): The [status](https://docs.github.com/rest/commits/statuses) contexts to verify against commit status checks. If you omit this parameter, GitHub verifies all unique contexts before creating a deployment. To bypass checking entirely, pass an empty array. Defaults to all unique contexts.
- `payload` (object, optional): 
- `environment` (string, optional): Name for the target deployment environment (e.g., `production`, `staging`, `qa`). (default: production)
- `description` (string, optional): Short description of the deployment.
- `transient_environment` (boolean, optional): Specifies if the given environment is specific to the deployment and will no longer exist at some point in the future. Default: `false` (default: False)
- `production_environment` (boolean, optional): Specifies if the given environment is one that end-users directly interact with. Default: `true` when `environment` is `production` and `false` otherwise.
### repos_list_deployments

GET /repos/{owner}/{repo}/deployments - List deployments

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `sha` (string, optional): The SHA recorded at creation time. (default: none)
- `ref` (string, optional): The name of the ref. This can be a branch, tag, or SHA. (default: none)
- `task` (string, optional): The name of the task for the deployment (e.g., `deploy` or `deploy:migrations`). (default: none)
- `environment` (string, optional): The name of the environment that was deployed to (e.g., `staging` or `production`). (default: none)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_delete_deployment

DELETE /repos/{owner}/{repo}/deployments/{deployment_id} - Delete a deployment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `deployment_id` (integer): deployment_id parameter
### repos_get_deployment

GET /repos/{owner}/{repo}/deployments/{deployment_id} - Get a deployment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `deployment_id` (integer): deployment_id parameter
### repos_create_deployment_status

POST /repos/{owner}/{repo}/deployments/{deployment_id}/statuses - Create a deployment status

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `deployment_id` (integer): deployment_id parameter
- `state` (string): The state of the status. When you set a transient deployment to `inactive`, the deployment will be shown as `destroyed` in GitHub.
- `target_url` (string, optional): The target URL to associate with this status. This URL should contain output to keep the user updated while the task is running or serve as historical information for what happened in the deployment.

> [!NOTE]
> It's recommended to use the `log_url` parameter, which replaces `target_url`.
- `log_url` (string, optional): The full URL of the deployment's output. This parameter replaces `target_url`. We will continue to accept `target_url` to support legacy uses, but we recommend replacing `target_url` with `log_url`. Setting `log_url` will automatically set `target_url` to the same value. Default: `""`
- `description` (string, optional): A short description of the status. The maximum description length is 140 characters.
- `environment` (string, optional): Name for the target deployment environment, which can be changed when setting a deploy status. For example, `production`, `staging`, or `qa`. If not defined, the environment of the previous status on the deployment will be used, if it exists. Otherwise, the environment of the deployment will be used.
- `environment_url` (string, optional): Sets the URL for accessing your environment. Default: `""`
- `auto_inactive` (boolean, optional): Adds a new `inactive` status to all prior non-transient, non-production environment deployments with the same repository and `environment` name as the created status's deployment. An `inactive` status is only added to deployments that had a `success` state. Default: `true`
### repos_list_deployment_statuses

GET /repos/{owner}/{repo}/deployments/{deployment_id}/statuses - List deployment statuses

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `deployment_id` (integer): deployment_id parameter
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_deployment_status

GET /repos/{owner}/{repo}/deployments/{deployment_id}/statuses/{status_id} - Get a deployment status

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `deployment_id` (integer): deployment_id parameter
- `status_id` (integer): 
### repos_create_dispatch_event

POST /repos/{owner}/{repo}/dispatches - Create a repository dispatch event

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `event_type` (string): A custom webhook event name. Must be 100 characters or fewer.
- `client_payload` (object, optional): JSON payload with extra information about the webhook event that your action or workflow may use. The maximum number of top-level properties is 10. The total size of the JSON payload must be less than 64KB.
### repos_get_all_environments

GET /repos/{owner}/{repo}/environments - List environments

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_delete_an_environment

DELETE /repos/{owner}/{repo}/environments/{environment_name} - Delete an environment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
### repos_create_or_update_environment

PUT /repos/{owner}/{repo}/environments/{environment_name} - Create or update an environment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `wait_timer` (integer, optional): 
- `prevent_self_review` (boolean, optional): 
- `reviewers` (array, optional): The people or teams that may review jobs that reference the environment. You can list up to six users or teams as reviewers. The reviewers must have at least read access to the repository. Only one of the required reviewers needs to approve the job for it to proceed.
- `deployment_branch_policy` (object, optional): 
### repos_get_environment

GET /repos/{owner}/{repo}/environments/{environment_name} - Get an environment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
### repos_create_deployment_branch_policy

POST /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies - Create a deployment branch policy

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `name` (string): The name pattern that branches or tags must match in order to deploy to the environment.

Wildcard characters will not match `/`. For example, to match branches that begin with `release/` and contain an additional single slash, use `release/*/*`.
For more information about pattern matching syntax, see the [Ruby File.fnmatch documentation](https://ruby-doc.org/core-2.5.1/File.html#method-c-fnmatch).
- `type` (string, optional): Whether this rule targets a branch or tag
### repos_list_deployment_branch_policies

GET /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies - List deployment branch policies

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_delete_deployment_branch_policy

DELETE /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies/{branch_policy_id} - Delete a deployment branch policy

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `branch_policy_id` (integer): The unique identifier of the branch policy.
### repos_update_deployment_branch_policy

PUT /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies/{branch_policy_id} - Update a deployment branch policy

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `branch_policy_id` (integer): The unique identifier of the branch policy.
- `name` (string): The name pattern that branches must match in order to deploy to the environment.

Wildcard characters will not match `/`. For example, to match branches that begin with `release/` and contain an additional single slash, use `release/*/*`.
For more information about pattern matching syntax, see the [Ruby File.fnmatch documentation](https://ruby-doc.org/core-2.5.1/File.html#method-c-fnmatch).
### repos_get_deployment_branch_policy

GET /repos/{owner}/{repo}/environments/{environment_name}/deployment-branch-policies/{branch_policy_id} - Get a deployment branch policy

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `branch_policy_id` (integer): The unique identifier of the branch policy.
### repos_create_deployment_protection_rule

POST /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules - Create a custom deployment protection rule on an environment

Parameters:
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `integration_id` (integer, optional): The ID of the custom app that will be enabled on the environment.
### repos_get_all_deployment_protection_rules

GET /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules - Get all deployment protection rules for an environment

Parameters:
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
### repos_list_custom_deployment_rule_integrations

GET /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules/apps - List custom deployment rule integrations available for an environment

Parameters:
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### repos_disable_deployment_protection_rule

DELETE /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules/{protection_rule_id} - Disable a custom protection rule for an environment

Parameters:
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `protection_rule_id` (integer): The unique identifier of the protection rule.
### repos_get_custom_deployment_protection_rule

GET /repos/{owner}/{repo}/environments/{environment_name}/deployment_protection_rules/{protection_rule_id} - Get a custom deployment protection rule

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `protection_rule_id` (integer): The unique identifier of the protection rule.
### actions_list_environment_secrets

GET /repos/{owner}/{repo}/environments/{environment_name}/secrets - List environment secrets

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_get_environment_public_key

GET /repos/{owner}/{repo}/environments/{environment_name}/secrets/public-key - Get an environment public key

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
### actions_delete_environment_secret

DELETE /repos/{owner}/{repo}/environments/{environment_name}/secrets/{secret_name} - Delete an environment secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `secret_name` (string): The name of the secret.
### actions_create_or_update_environment_secret

PUT /repos/{owner}/{repo}/environments/{environment_name}/secrets/{secret_name} - Create or update an environment secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `secret_name` (string): The name of the secret.
- `encrypted_value` (string): Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get an environment public key](https://docs.github.com/rest/actions/secrets#get-an-environment-public-key) endpoint.
- `key_id` (string): ID of the key you used to encrypt the secret.
### actions_get_environment_secret

GET /repos/{owner}/{repo}/environments/{environment_name}/secrets/{secret_name} - Get an environment secret

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `secret_name` (string): The name of the secret.
### actions_create_environment_variable

POST /repos/{owner}/{repo}/environments/{environment_name}/variables - Create an environment variable

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `name` (string): The name of the variable.
- `value` (string): The value of the variable.
### actions_list_environment_variables

GET /repos/{owner}/{repo}/environments/{environment_name}/variables - List environment variables

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `per_page` (integer, optional): The number of results per page (max 30). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 10)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### actions_update_environment_variable

PATCH /repos/{owner}/{repo}/environments/{environment_name}/variables/{name} - Update an environment variable

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the variable.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `value` (string, optional): The value of the variable.
### actions_delete_environment_variable

DELETE /repos/{owner}/{repo}/environments/{environment_name}/variables/{name} - Delete an environment variable

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the variable.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
### actions_get_environment_variable

GET /repos/{owner}/{repo}/environments/{environment_name}/variables/{name} - Get an environment variable

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `environment_name` (string): The name of the environment. The name must be URL encoded. For example, any slashes in the name must be replaced with `%2F`.
- `name` (string): The name of the variable.
### activity_list_repo_events

GET /repos/{owner}/{repo}/events - List repository events

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_create_fork

POST /repos/{owner}/{repo}/forks - Create a fork

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `organization` (string, optional): Optional parameter to specify the organization name if forking into an organization.
- `name` (string, optional): When forking from an existing repository, a new name for the fork.
- `default_branch_only` (boolean, optional): When forking from an existing repository, fork with only the default branch.
### repos_list_forks

GET /repos/{owner}/{repo}/forks - List forks

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `sort` (string, optional): The sort order. `stargazers` will sort by star count. (default: newest) — one of: newest, oldest, stargazers, watchers
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### git_create_blob

POST /repos/{owner}/{repo}/git/blobs - Create a blob

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `content` (string): The new blob's content.
- `encoding` (string, optional): The encoding used for `content`. Currently, `"utf-8"` and `"base64"` are supported. (default: utf-8)
### git_get_blob

GET /repos/{owner}/{repo}/git/blobs/{file_sha} - Get a blob

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `file_sha` (string): 
### git_create_commit

POST /repos/{owner}/{repo}/git/commits - Create a commit

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `message` (string): The commit message
- `tree` (string): The SHA of the tree object this commit points to
- `parents` (array, optional): The full SHAs of the commits that were the parents of this commit. If omitted or empty, the commit will be written as a root commit. For a single parent, an array of one SHA should be provided; for a merge commit, an array of more than one should be provided.
- `author` (object, optional): Information about the author of the commit. By default, the `author` will be the authenticated user and the current date. See the `author` and `committer` object below for details.
- `committer` (object, optional): Information about the person who is making the commit. By default, `committer` will use the information set in `author`. See the `author` and `committer` object below for details.
- `signature` (string, optional): The [PGP signature](https://en.wikipedia.org/wiki/Pretty_Good_Privacy) of the commit. GitHub adds the signature to the `gpgsig` header of the created commit. For a commit signature to be verifiable by Git or GitHub, it must be an ASCII-armored detached PGP signature over the string commit as it would be written to the object database. To pass a `signature` parameter, you need to first manually create a valid PGP signature, which can be complicated. You may find it easier to [use the command line](https://git-scm.com/book/id/v2/Git-Tools-Signing-Your-Work) to create signed commits.
### git_get_commit

GET /repos/{owner}/{repo}/git/commits/{commit_sha} - Get a commit object

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `commit_sha` (string): The SHA of the commit.
### git_list_matching_refs

GET /repos/{owner}/{repo}/git/matching-refs/{ref} - List matching references

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The Git reference. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
### git_get_ref

GET /repos/{owner}/{repo}/git/ref/{ref} - Get a reference

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The Git reference. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
### git_create_ref

POST /repos/{owner}/{repo}/git/refs - Create a reference

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The name of the fully qualified reference (ie: `refs/heads/master`). If it doesn't start with 'refs' and have at least two slashes, it will be rejected.
- `sha` (string): The SHA1 value for this reference.
### git_update_ref

PATCH /repos/{owner}/{repo}/git/refs/{ref} - Update a reference

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The Git reference. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
- `sha` (string): The SHA1 value to set this reference to
- `force` (boolean, optional): Indicates whether to force the update or to make sure the update is a fast-forward update. Leaving this out or setting it to `false` will make sure you're not overwriting work. (default: False)
### git_delete_ref

DELETE /repos/{owner}/{repo}/git/refs/{ref} - Delete a reference

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): The Git reference. For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
### git_create_tag

POST /repos/{owner}/{repo}/git/tags - Create a tag object

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tag` (string): The tag's name. This is typically a version (e.g., "v0.0.1").
- `message` (string): The tag message.
- `object` (string): The SHA of the git object this is tagging.
- `type` (string): The type of the object we're tagging. Normally this is a `commit` but it can also be a `tree` or a `blob`.
- `tagger` (object, optional): An object with information about the individual creating the tag.
### git_get_tag

GET /repos/{owner}/{repo}/git/tags/{tag_sha} - Get a tag

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tag_sha` (string): 
### git_create_tree

POST /repos/{owner}/{repo}/git/trees - Create a tree

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tree` (array): Objects (of `path`, `mode`, `type`, and `sha`) specifying a tree structure.
- `base_tree` (string, optional): The SHA1 of an existing Git tree object which will be used as the base for the new tree. If provided, a new Git tree object will be created from entries in the Git tree object pointed to by `base_tree` and entries defined in the `tree` parameter. Entries defined in the `tree` parameter will overwrite items from `base_tree` with the same `path`. If you're creating new changes on a branch, then normally you'd set `base_tree` to the SHA1 of the Git tree object of the current latest commit on the branch you're working on.
If not provided, GitHub will create a new Git tree object from only the entries defined in the `tree` parameter. If you create a new commit pointing to such a tree, then all files which were a part of the parent commit's tree and were not defined in the `tree` parameter will be listed as deleted by the new commit.
### git_get_tree

GET /repos/{owner}/{repo}/git/trees/{tree_sha} - Get a tree

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tree_sha` (string): The SHA1 value or ref (branch or tag) name of the tree.
- `recursive` (string, optional): Setting this parameter to any value returns the objects or subtrees referenced by the tree specified in `:tree_sha`. For example, setting `recursive` to any of the following will enable returning objects or subtrees: `0`, `1`, `"true"`, and `"false"`. Omit this parameter to prevent recursively returning objects or subtrees.
### repos_create_webhook

POST /repos/{owner}/{repo}/hooks - Create a repository webhook

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string, optional): Use `web` to create a webhook. Default: `web`. This parameter only accepts the value `web`.
- `config` (object, optional): Key/value pairs to provide settings for this webhook.
- `events` (array, optional): Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. (default: ['push'])
- `active` (boolean, optional): Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. (default: True)
### repos_list_webhooks

GET /repos/{owner}/{repo}/hooks - List repository webhooks

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_update_webhook

PATCH /repos/{owner}/{repo}/hooks/{hook_id} - Update a repository webhook

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `config` (object, optional): 
- `events` (array, optional): Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. This replaces the entire array of events. (default: ['push'])
- `add_events` (array, optional): Determines a list of events to be added to the list of events that the Hook triggers for.
- `remove_events` (array, optional): Determines a list of events to be removed from the list of events that the Hook triggers for.
- `active` (boolean, optional): Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. (default: True)
### repos_delete_webhook

DELETE /repos/{owner}/{repo}/hooks/{hook_id} - Delete a repository webhook

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### repos_get_webhook

GET /repos/{owner}/{repo}/hooks/{hook_id} - Get a repository webhook

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### repos_update_webhook_config_for_repo

PATCH /repos/{owner}/{repo}/hooks/{hook_id}/config - Update a webhook configuration for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `url` (string, optional): 
- `content_type` (string, optional): 
- `secret` (string, optional): 
- `insecure_ssl` (object, optional): 
### repos_get_webhook_config_for_repo

GET /repos/{owner}/{repo}/hooks/{hook_id}/config - Get a webhook configuration for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### repos_list_webhook_deliveries

GET /repos/{owner}/{repo}/hooks/{hook_id}/deliveries - List deliveries for a repository webhook

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `cursor` (string, optional): Used for pagination: the starting delivery from which the page of deliveries is fetched. Refer to the `link` header for the next and previous page cursors.
### repos_get_webhook_delivery

GET /repos/{owner}/{repo}/hooks/{hook_id}/deliveries/{delivery_id} - Get a delivery for a repository webhook

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `delivery_id` (integer): 
### repos_redeliver_webhook_delivery

POST /repos/{owner}/{repo}/hooks/{hook_id}/deliveries/{delivery_id}/attempts - Redeliver a delivery for a repository webhook

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
- `delivery_id` (integer): 
### repos_ping_webhook

POST /repos/{owner}/{repo}/hooks/{hook_id}/pings - Ping a repository webhook

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### repos_test_push_webhook

POST /repos/{owner}/{repo}/hooks/{hook_id}/tests - Test the push repository webhook

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `hook_id` (integer): The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### repos_disable_immutable_releases

DELETE /repos/{owner}/{repo}/immutable-releases - Disable immutable releases

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_enable_immutable_releases

PUT /repos/{owner}/{repo}/immutable-releases - Enable immutable releases

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_check_immutable_releases

GET /repos/{owner}/{repo}/immutable-releases - Check if immutable releases are enabled for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### migrations_update_import

PATCH /repos/{owner}/{repo}/import - Update an import

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `vcs_username` (string, optional): The username to provide to the originating repository.
- `vcs_password` (string, optional): The password to provide to the originating repository.
- `vcs` (string, optional): The type of version control system you are migrating from.
- `tfvc_project` (string, optional): For a tfvc import, the name of the project that is being imported.
### migrations_cancel_import

DELETE /repos/{owner}/{repo}/import - Cancel an import

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### migrations_start_import

PUT /repos/{owner}/{repo}/import - Start an import

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `vcs_url` (string): The URL of the originating repository.
- `vcs` (string, optional): The originating VCS type. Without this parameter, the import job will take additional time to detect the VCS type before beginning the import. This detection step will be reflected in the response.
- `vcs_username` (string, optional): If authentication is required, the username to provide to `vcs_url`.
- `vcs_password` (string, optional): If authentication is required, the password to provide to `vcs_url`.
- `tfvc_project` (string, optional): For a tfvc import, the name of the project that is being imported.
### migrations_get_import_status

GET /repos/{owner}/{repo}/import - Get an import status

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### migrations_get_commit_authors

GET /repos/{owner}/{repo}/import/authors - Get commit authors

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `since` (integer, optional): A user ID. Only return users with an ID greater than this ID.
### migrations_map_commit_author

PATCH /repos/{owner}/{repo}/import/authors/{author_id} - Map a commit author

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `author_id` (integer): 
- `email` (string, optional): The new Git author email.
- `name` (string, optional): The new Git author name.
### migrations_get_large_files

GET /repos/{owner}/{repo}/import/large_files - Get large files

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### migrations_set_lfs_preference

PATCH /repos/{owner}/{repo}/import/lfs - Update Git LFS preference

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `use_lfs` (string): Whether to store large files during the import. `opt_in` means large files will be stored using Git LFS. `opt_out` means large files will be removed during the import.
### apps_get_repo_installation

GET /repos/{owner}/{repo}/installation - Get a repository installation for the authenticated app

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### interactions_remove_restrictions_for_repo

DELETE /repos/{owner}/{repo}/interaction-limits - Remove interaction restrictions for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### interactions_set_restrictions_for_repo

PUT /repos/{owner}/{repo}/interaction-limits - Set interaction restrictions for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `limit` (string): 
- `expiry` (string, optional): 
### interactions_get_restrictions_for_repo

GET /repos/{owner}/{repo}/interaction-limits - Get interaction restrictions for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_list_invitations

GET /repos/{owner}/{repo}/invitations - List repository invitations

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_update_invitation

PATCH /repos/{owner}/{repo}/invitations/{invitation_id} - Update a repository invitation

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `invitation_id` (integer): The unique identifier of the invitation.
- `permissions` (string, optional): The permissions that the associated user will have on the repository. Valid values are `read`, `write`, `maintain`, `triage`, and `admin`.
### repos_delete_invitation

DELETE /repos/{owner}/{repo}/invitations/{invitation_id} - Delete a repository invitation

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `invitation_id` (integer): The unique identifier of the invitation.
### issues_create

POST /repos/{owner}/{repo}/issues - Create an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `title` (object): The title of the issue.
- `body` (string, optional): The contents of the issue.
- `assignee` (string, optional): Login for the user that this issue should be assigned to. _NOTE: Only users with push access can set the assignee for new issues. The assignee is silently dropped otherwise. **This field is closing down.**_
- `milestone` (object, optional): 
- `labels` (array, optional): Labels to associate with this issue. _NOTE: Only users with push access can set labels for new issues. Labels are silently dropped otherwise._
- `assignees` (array, optional): Logins for Users to assign to this issue. _NOTE: Only users with push access can set assignees for new issues. Assignees are silently dropped otherwise._
- `type` (string, optional): The name of the issue type to associate with this issue. _NOTE: Only users with push access can set the type for new issues. The type is silently dropped otherwise._
### issues_list_for_repo

GET /repos/{owner}/{repo}/issues - List repository issues

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `milestone` (string, optional): If an `integer` is passed, it should refer to a milestone by its `number` field. If the string `*` is passed, issues with any milestone are accepted. If the string `none` is passed, issues without milestones are returned.
- `state` (string, optional): Indicates the state of the issues to return. (default: open) — one of: open, closed, all
- `assignee` (string, optional): Can be the name of a user. Pass in `none` for issues with no assigned user, and `*` for issues assigned to any user.
- `type` (string, optional): Can be the name of an issue type. If the string `*` is passed, issues with any type are accepted. If the string `none` is passed, issues without type are returned.
- `creator` (string, optional): The user that created the issue.
- `mentioned` (string, optional): A user that's mentioned in the issue.
- `labels` (string, optional): A list of comma separated label names. Example: `bug,ui,@high`
- `sort` (string, optional): What to sort results by. (default: created) — one of: created, updated, comments
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_list_comments_for_repo

GET /repos/{owner}/{repo}/issues/comments - List issue comments for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `sort` (string, optional): The property to sort the results by. (default: created) — one of: created, updated
- `direction` (string, optional): Either `asc` or `desc`. Ignored without the `sort` parameter. — one of: asc, desc
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_update_comment

PATCH /repos/{owner}/{repo}/issues/comments/{comment_id} - Update an issue comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `body` (string): The contents of the comment.
### issues_delete_comment

DELETE /repos/{owner}/{repo}/issues/comments/{comment_id} - Delete an issue comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
### issues_get_comment

GET /repos/{owner}/{repo}/issues/comments/{comment_id} - Get an issue comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
### issues_unpin_comment

DELETE /repos/{owner}/{repo}/issues/comments/{comment_id}/pin - Unpin an issue comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
### issues_pin_comment

PUT /repos/{owner}/{repo}/issues/comments/{comment_id}/pin - Pin an issue comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
### reactions_create_for_issue_comment

POST /repos/{owner}/{repo}/issues/comments/{comment_id}/reactions - Create reaction for an issue comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `content` (string): The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the issue comment.
### reactions_list_for_issue_comment

GET /repos/{owner}/{repo}/issues/comments/{comment_id}/reactions - List reactions for an issue comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `content` (string, optional): Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to an issue comment. — one of: +1, -1, laugh, confused, heart, hooray, rocket, eyes
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### reactions_delete_for_issue_comment

DELETE /repos/{owner}/{repo}/issues/comments/{comment_id}/reactions/{reaction_id} - Delete an issue comment reaction

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `reaction_id` (integer): The unique identifier of the reaction.
### issues_list_events_for_repo

GET /repos/{owner}/{repo}/issues/events - List issue events for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_get_event

GET /repos/{owner}/{repo}/issues/events/{event_id} - Get an issue event

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `event_id` (integer): 
### issues_update

PATCH /repos/{owner}/{repo}/issues/{issue_number} - Update an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `title` (object, optional): The title of the issue.
- `body` (string, optional): The contents of the issue.
- `assignee` (string, optional): Username to assign to this issue. **This field is closing down.**
- `state` (string, optional): The open or closed state of the issue.
- `state_reason` (string, optional): The reason for the state change. Ignored unless `state` is changed.
- `milestone` (object, optional): 
- `labels` (array, optional): Labels to associate with this issue. Pass one or more labels to _replace_ the set of labels on this issue. Send an empty array (`[]`) to clear all labels from the issue. Only users with push access can set labels for issues. Without push access to the repository, label changes are silently dropped.
- `assignees` (array, optional): Usernames to assign to this issue. Pass one or more user logins to _replace_ the set of assignees on this issue. Send an empty array (`[]`) to clear all assignees from the issue. Only users with push access can set assignees for new issues. Without push access to the repository, assignee changes are silently dropped.
- `issue_field_values` (array, optional): An array of issue field values to set on this issue. Each field value must include the field ID and the value to set. Only users with push access can set field values for issues
- `type` (string, optional): The name of the issue type to associate with this issue or use `null` to remove the current issue type. Only users with push access can set the type for issues. Without push access to the repository, type changes are silently dropped.
### issues_get

GET /repos/{owner}/{repo}/issues/{issue_number} - Get an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
### issues_add_assignees

POST /repos/{owner}/{repo}/issues/{issue_number}/assignees - Add assignees to an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `assignees` (array, optional): Usernames of people to assign this issue to. _NOTE: Only users with push access can add assignees to an issue. Assignees are silently ignored otherwise._
### issues_remove_assignees

DELETE /repos/{owner}/{repo}/issues/{issue_number}/assignees - Remove assignees from an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `assignees` (array, optional): Usernames of assignees to remove from an issue. _NOTE: Only users with push access can remove assignees from an issue. Assignees are silently ignored otherwise._
### issues_check_user_can_be_assigned_to_issue

GET /repos/{owner}/{repo}/issues/{issue_number}/assignees/{assignee} - Check if a user can be assigned to a issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `assignee` (string): 
### issues_create_comment

POST /repos/{owner}/{repo}/issues/{issue_number}/comments - Create an issue comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `body` (string): The contents of the comment.
### issues_list_comments

GET /repos/{owner}/{repo}/issues/{issue_number}/comments - List issue comments

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_add_blocked_by_dependency

POST /repos/{owner}/{repo}/issues/{issue_number}/dependencies/blocked_by - Add a dependency an issue is blocked by

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `issue_id` (integer): The id of the issue that blocks the current issue
### issues_list_dependencies_blocked_by

GET /repos/{owner}/{repo}/issues/{issue_number}/dependencies/blocked_by - List dependencies an issue is blocked by

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_remove_dependency_blocked_by

DELETE /repos/{owner}/{repo}/issues/{issue_number}/dependencies/blocked_by/{issue_id} - Remove dependency an issue is blocked by

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `issue_id` (integer): The id of the blocking issue to remove as a dependency
### issues_list_dependencies_blocking

GET /repos/{owner}/{repo}/issues/{issue_number}/dependencies/blocking - List dependencies an issue is blocking

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_list_events

GET /repos/{owner}/{repo}/issues/{issue_number}/events - List issue events

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_list_issue_field_values_for_issue

GET /repos/{owner}/{repo}/issues/{issue_number}/issue-field-values - List issue field values for an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_add_labels

POST /repos/{owner}/{repo}/issues/{issue_number}/labels - Add labels to an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `body` (object, optional): Request body
### issues_remove_all_labels

DELETE /repos/{owner}/{repo}/issues/{issue_number}/labels - Remove all labels from an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
### issues_set_labels

PUT /repos/{owner}/{repo}/issues/{issue_number}/labels - Set labels for an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `body` (object, optional): Request body
### issues_list_labels_on_issue

GET /repos/{owner}/{repo}/issues/{issue_number}/labels - List labels for an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_remove_label

DELETE /repos/{owner}/{repo}/issues/{issue_number}/labels/{name} - Remove a label from an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `name` (string): 
### issues_unlock

DELETE /repos/{owner}/{repo}/issues/{issue_number}/lock - Unlock an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
### issues_lock

PUT /repos/{owner}/{repo}/issues/{issue_number}/lock - Lock an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `lock_reason` (string, optional): The reason for locking the issue or pull request conversation. Lock will fail if you don't use one of these reasons:  
 * `off-topic`  
 * `too heated`  
 * `resolved`  
 * `spam`
### issues_get_parent

GET /repos/{owner}/{repo}/issues/{issue_number}/parent - Get parent issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
### reactions_create_for_issue

POST /repos/{owner}/{repo}/issues/{issue_number}/reactions - Create reaction for an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `content` (string): The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the issue.
### reactions_list_for_issue

GET /repos/{owner}/{repo}/issues/{issue_number}/reactions - List reactions for an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `content` (string, optional): Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to an issue. — one of: +1, -1, laugh, confused, heart, hooray, rocket, eyes
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### reactions_delete_for_issue

DELETE /repos/{owner}/{repo}/issues/{issue_number}/reactions/{reaction_id} - Delete an issue reaction

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `reaction_id` (integer): The unique identifier of the reaction.
### issues_remove_sub_issue

DELETE /repos/{owner}/{repo}/issues/{issue_number}/sub_issue - Remove sub-issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `sub_issue_id` (integer): The id of the sub-issue to remove
### issues_add_sub_issue

POST /repos/{owner}/{repo}/issues/{issue_number}/sub_issues - Add sub-issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `sub_issue_id` (integer): The id of the sub-issue to add. The sub-issue must belong to the same repository owner as the parent issue
- `replace_parent` (boolean, optional): Option that, when true, instructs the operation to replace the sub-issues current parent issue
### issues_list_sub_issues

GET /repos/{owner}/{repo}/issues/{issue_number}/sub_issues - List sub-issues

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_reprioritize_sub_issue

PATCH /repos/{owner}/{repo}/issues/{issue_number}/sub_issues/priority - Reprioritize sub-issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `sub_issue_id` (integer): The id of the sub-issue to reprioritize
- `after_id` (integer, optional): The id of the sub-issue to be prioritized after (either positional argument after OR before should be specified).
- `before_id` (integer, optional): The id of the sub-issue to be prioritized before (either positional argument after OR before should be specified).
### issues_list_events_for_timeline

GET /repos/{owner}/{repo}/issues/{issue_number}/timeline - List timeline events for an issue

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `issue_number` (integer): The number that identifies the issue.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_create_deploy_key

POST /repos/{owner}/{repo}/keys - Create a deploy key

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `title` (string, optional): A name for the key.
- `key` (string): The contents of the key.
- `read_only` (boolean, optional): If `true`, the key will only be able to read repository contents. Otherwise, the key will be able to read and write.  
  
Deploy keys with write access can perform the same actions as an organization member with admin access, or a collaborator on a personal repository. For more information, see "[Repository permission levels for an organization](https://docs.github.com/articles/repository-permission-levels-for-an-organization/)" and "[Permission levels for a user account repository](https://docs.github.com/articles/permission-levels-for-a-user-account-repository/)."
### repos_list_deploy_keys

GET /repos/{owner}/{repo}/keys - List deploy keys

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_delete_deploy_key

DELETE /repos/{owner}/{repo}/keys/{key_id} - Delete a deploy key

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `key_id` (integer): The unique identifier of the key.
### repos_get_deploy_key

GET /repos/{owner}/{repo}/keys/{key_id} - Get a deploy key

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `key_id` (integer): The unique identifier of the key.
### issues_create_label

POST /repos/{owner}/{repo}/labels - Create a label

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the label. Emoji can be added to label names, using either native emoji or colon-style markup. For example, typing `:strawberry:` will render the emoji ![:strawberry:](https://github.githubassets.com/images/icons/emoji/unicode/1f353.png ":strawberry:"). For a full list of available emoji and codes, see "[Emoji cheat sheet](https://github.com/ikatyang/emoji-cheat-sheet)."
- `color` (string, optional): The [hexadecimal color code](http://www.color-hex.com/) for the label, without the leading `#`.
- `description` (string, optional): A short description of the label. Must be 100 characters or fewer.
### issues_list_labels_for_repo

GET /repos/{owner}/{repo}/labels - List labels for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_update_label

PATCH /repos/{owner}/{repo}/labels/{name} - Update a label

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): 
- `new_name` (string, optional): The new name of the label. Emoji can be added to label names, using either native emoji or colon-style markup. For example, typing `:strawberry:` will render the emoji ![:strawberry:](https://github.githubassets.com/images/icons/emoji/unicode/1f353.png ":strawberry:"). For a full list of available emoji and codes, see "[Emoji cheat sheet](https://github.com/ikatyang/emoji-cheat-sheet)."
- `color` (string, optional): The [hexadecimal color code](http://www.color-hex.com/) for the label, without the leading `#`.
- `description` (string, optional): A short description of the label. Must be 100 characters or fewer.
### issues_delete_label

DELETE /repos/{owner}/{repo}/labels/{name} - Delete a label

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): 
### issues_get_label

GET /repos/{owner}/{repo}/labels/{name} - Get a label

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): 
### repos_list_languages

GET /repos/{owner}/{repo}/languages - List repository languages

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### licenses_get_for_repo

GET /repos/{owner}/{repo}/license - Get the license for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string, optional): The Git reference for the results you want to list. The `ref` for a branch can be formatted either as `refs/heads/<branch name>` or simply `<branch name>`. To reference a pull request use `refs/pull/<number>/merge`.
### repos_merge_upstream

POST /repos/{owner}/{repo}/merge-upstream - Sync a fork branch with the upstream repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch which should be updated to match upstream.
### repos_merge

POST /repos/{owner}/{repo}/merges - Merge a branch

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `base` (string): The name of the base branch that the head will be merged into.
- `head` (string): The head to merge. This can be a branch name or a commit SHA1.
- `commit_message` (string, optional): Commit message to use for the merge commit. If omitted, a default message will be used.
### issues_create_milestone

POST /repos/{owner}/{repo}/milestones - Create a milestone

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `title` (string): The title of the milestone.
- `state` (string, optional): The state of the milestone. Either `open` or `closed`. (default: open)
- `description` (string, optional): A description of the milestone.
- `due_on` (string, optional): The milestone due date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
### issues_list_milestones

GET /repos/{owner}/{repo}/milestones - List milestones

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `state` (string, optional): The state of the milestone. Either `open`, `closed`, or `all`. (default: open) — one of: open, closed, all
- `sort` (string, optional): What to sort results by. Either `due_on` or `completeness`. (default: due_on) — one of: due_on, completeness
- `direction` (string, optional): The direction of the sort. Either `asc` or `desc`. (default: asc) — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### issues_update_milestone

PATCH /repos/{owner}/{repo}/milestones/{milestone_number} - Update a milestone

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `milestone_number` (integer): The number that identifies the milestone.
- `title` (string, optional): The title of the milestone.
- `state` (string, optional): The state of the milestone. Either `open` or `closed`. (default: open)
- `description` (string, optional): A description of the milestone.
- `due_on` (string, optional): The milestone due date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
### issues_delete_milestone

DELETE /repos/{owner}/{repo}/milestones/{milestone_number} - Delete a milestone

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `milestone_number` (integer): The number that identifies the milestone.
### issues_get_milestone

GET /repos/{owner}/{repo}/milestones/{milestone_number} - Get a milestone

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `milestone_number` (integer): The number that identifies the milestone.
### issues_list_labels_for_milestone

GET /repos/{owner}/{repo}/milestones/{milestone_number}/labels - List labels for issues in a milestone

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `milestone_number` (integer): The number that identifies the milestone.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_mark_repo_notifications_as_read

PUT /repos/{owner}/{repo}/notifications - Mark repository notifications as read

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `last_read_at` (string, optional): Describes the last point that notifications were checked. Anything updated since this time will not be marked as read. If you omit this parameter, all notifications are marked as read. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Default: The current timestamp.
### get_repos_by_owner_by_repo_notifications

GET /repos/{owner}/{repo}/notifications - List repository notifications for the authenticated user

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `all` (boolean, optional): If `true`, show notifications marked as read. (default: False)
- `participating` (boolean, optional): If `true`, only shows notifications in which the user is directly participating or mentioned. (default: False)
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `before` (string, optional): Only show notifications updated before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_create_pages_site

POST /repos/{owner}/{repo}/pages - Create a GitHub Pages site

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `build_type` (string, optional): The process in which the Page will be built. Possible values are `"legacy"` and `"workflow"`.
- `source` (object, optional): The source branch and directory used to publish your Pages site.
### repos_delete_pages_site

DELETE /repos/{owner}/{repo}/pages - Delete a GitHub Pages site

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_update_information_about_pages_site

PUT /repos/{owner}/{repo}/pages - Update information about a GitHub Pages site

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `cname` (string, optional): Specify a custom domain for the repository. Sending a `null` value will remove the custom domain. For more about custom domains, see "[Using a custom domain with GitHub Pages](https://docs.github.com/pages/configuring-a-custom-domain-for-your-github-pages-site)."
- `https_enforced` (boolean, optional): Specify whether HTTPS should be enforced for the repository.
- `build_type` (string, optional): The process by which the GitHub Pages site will be built. `workflow` means that the site is built by a custom GitHub Actions workflow. `legacy` means that the site is built by GitHub when changes are pushed to a specific branch.
- `source` (object, optional): 
### repos_get_pages

GET /repos/{owner}/{repo}/pages - Get a GitHub Pages site

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_request_pages_build

POST /repos/{owner}/{repo}/pages/builds - Request a GitHub Pages build

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_list_pages_builds

GET /repos/{owner}/{repo}/pages/builds - List GitHub Pages builds

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_latest_pages_build

GET /repos/{owner}/{repo}/pages/builds/latest - Get latest Pages build

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get_pages_build

GET /repos/{owner}/{repo}/pages/builds/{build_id} - Get GitHub Pages build

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `build_id` (integer): 
### repos_create_pages_deployment

POST /repos/{owner}/{repo}/pages/deployments - Create a GitHub Pages deployment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `artifact_id` (float, optional): The ID of an artifact that contains the .zip or .tar of static assets to deploy. The artifact belongs to the repository. Either `artifact_id` or `artifact_url` are required.
- `artifact_url` (string, optional): The URL of an artifact that contains the .zip or .tar of static assets to deploy. The artifact belongs to the repository. Either `artifact_id` or `artifact_url` are required.
- `environment` (string, optional): The target environment for this GitHub Pages deployment. (default: github-pages)
- `pages_build_version` (string): A unique string that represents the version of the build for this deployment. (default: GITHUB_SHA)
- `oidc_token` (string): The OIDC token issued by GitHub Actions certifying the origin of the deployment.
### repos_get_pages_deployment

GET /repos/{owner}/{repo}/pages/deployments/{pages_deployment_id} - Get the status of a GitHub Pages deployment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pages_deployment_id` (object): The ID of the Pages deployment. You can also give the commit SHA of the deployment.
### repos_cancel_pages_deployment

POST /repos/{owner}/{repo}/pages/deployments/{pages_deployment_id}/cancel - Cancel a GitHub Pages deployment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pages_deployment_id` (object): The ID of the Pages deployment. You can also give the commit SHA of the deployment.
### repos_get_pages_health_check

GET /repos/{owner}/{repo}/pages/health - Get a DNS health check for GitHub Pages

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_disable_private_vulnerability_reporting

DELETE /repos/{owner}/{repo}/private-vulnerability-reporting - Disable private vulnerability reporting for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_enable_private_vulnerability_reporting

PUT /repos/{owner}/{repo}/private-vulnerability-reporting - Enable private vulnerability reporting for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_check_private_vulnerability_reporting

GET /repos/{owner}/{repo}/private-vulnerability-reporting - Check if private vulnerability reporting is enabled for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### patch_repos_by_owner_by_repo_properties_values

PATCH /repos/{owner}/{repo}/properties/values - Create or update custom property values for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `properties` (array): A list of custom property names and associated values to apply to the repositories.
### get_repos_by_owner_by_repo_properties_values

GET /repos/{owner}/{repo}/properties/values - Get all custom property values for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### pulls_create

POST /repos/{owner}/{repo}/pulls - Create a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `title` (string, optional): The title of the new pull request. Required unless `issue` is specified.
- `head` (string): The name of the branch where your changes are implemented. For cross-repository pull requests in the same network, namespace `head` with a user like this: `username:branch`.
- `head_repo` (string, optional): The name of the repository where the changes in the pull request were made. This field is required for cross-repository pull requests if both repositories are owned by the same organization.
- `base` (string): The name of the branch you want the changes pulled into. This should be an existing branch on the current repository. You cannot submit a pull request to one repository that requests a merge to a base of another repository.
- `body` (string, optional): The contents of the pull request.
- `maintainer_can_modify` (boolean, optional): Indicates whether [maintainers can modify](https://docs.github.com/articles/allowing-changes-to-a-pull-request-branch-created-from-a-fork/) the pull request.
- `draft` (boolean, optional): Indicates whether the pull request is a draft. See "[Draft Pull Requests](https://docs.github.com/articles/about-pull-requests#draft-pull-requests)" in the GitHub Help documentation to learn more.
- `issue` (integer, optional): An issue in the repository to convert to a pull request. The issue title, body, and comments will become the title, body, and comments on the new pull request. Required unless `title` is specified.
### pulls_list

GET /repos/{owner}/{repo}/pulls - List pull requests

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `state` (string, optional): Either `open`, `closed`, or `all` to filter by state. (default: open) — one of: open, closed, all
- `head` (string, optional): Filter pulls by head user or head organization and branch name in the format of `user:ref-name` or `organization:ref-name`. For example: `github:new-script-format` or `octocat:test-branch`.
- `base` (string, optional): Filter pulls by base branch name. Example: `gh-pages`.
- `sort` (string, optional): What to sort results by. `popularity` will sort by the number of comments. `long-running` will sort by date created and will limit the results to pull requests that have been open for more than a month and have had activity within the past month. (default: created) — one of: created, updated, popularity, long-running
- `direction` (string, optional): The direction of the sort. Default: `desc` when sort is `created` or sort is not specified, otherwise `asc`. — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### pulls_list_review_comments_for_repo

GET /repos/{owner}/{repo}/pulls/comments - List review comments in a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `sort` (string, optional):  — one of: created, updated, created_at
- `direction` (string, optional): The direction to sort results. Ignored without `sort` parameter. — one of: asc, desc
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### pulls_update_review_comment

PATCH /repos/{owner}/{repo}/pulls/comments/{comment_id} - Update a review comment for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `body` (string): The text of the reply to the review comment.
### pulls_delete_review_comment

DELETE /repos/{owner}/{repo}/pulls/comments/{comment_id} - Delete a review comment for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
### pulls_get_review_comment

GET /repos/{owner}/{repo}/pulls/comments/{comment_id} - Get a review comment for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
### reactions_create_for_pull_request_review_comment

POST /repos/{owner}/{repo}/pulls/comments/{comment_id}/reactions - Create reaction for a pull request review comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `content` (string): The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the pull request review comment.
### reactions_list_for_pull_request_review_comment

GET /repos/{owner}/{repo}/pulls/comments/{comment_id}/reactions - List reactions for a pull request review comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `content` (string, optional): Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to a pull request review comment. — one of: +1, -1, laugh, confused, heart, hooray, rocket, eyes
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### reactions_delete_for_pull_request_comment

DELETE /repos/{owner}/{repo}/pulls/comments/{comment_id}/reactions/{reaction_id} - Delete a pull request comment reaction

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `comment_id` (integer): The unique identifier of the comment.
- `reaction_id` (integer): The unique identifier of the reaction.
### pulls_update

PATCH /repos/{owner}/{repo}/pulls/{pull_number} - Update a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `title` (string, optional): The title of the pull request.
- `body` (string, optional): The contents of the pull request.
- `state` (string, optional): State of this Pull Request. Either `open` or `closed`.
- `base` (string, optional): The name of the branch you want your changes pulled into. This should be an existing branch on the current repository. You cannot update the base branch on a pull request to point to another repository.
- `maintainer_can_modify` (boolean, optional): Indicates whether [maintainers can modify](https://docs.github.com/articles/allowing-changes-to-a-pull-request-branch-created-from-a-fork/) the pull request.
### pulls_get

GET /repos/{owner}/{repo}/pulls/{pull_number} - Get a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
### codespaces_create_with_pr_for_authenticated_user

POST /repos/{owner}/{repo}/pulls/{pull_number}/codespaces - Create a codespace from a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `location` (string, optional): The requested location for a new codespace. Best efforts are made to respect this upon creation. Assigned by IP if not provided.
- `geo` (string, optional): The geographic area for this codespace. If not specified, the value is assigned by IP. This property replaces `location`, which is closing down.
- `client_ip` (string, optional): IP for location auto-detection when proxying a request
- `machine` (string, optional): Machine type to use for this codespace
- `devcontainer_path` (string, optional): Path to devcontainer.json config to use for this codespace
- `multi_repo_permissions_opt_out` (boolean, optional): Whether to authorize requested permissions from devcontainer.json
- `working_directory` (string, optional): Working directory for this codespace
- `idle_timeout_minutes` (integer, optional): Time in minutes before codespace stops from inactivity
- `display_name` (string, optional): Display name for this codespace
- `retention_period_minutes` (integer, optional): Duration in minutes after codespace has gone idle in which it will be deleted. Must be integer minutes between 0 and 43200 (30 days).
### pulls_create_review_comment

POST /repos/{owner}/{repo}/pulls/{pull_number}/comments - Create a review comment for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `body` (string): The text of the review comment.
- `commit_id` (string): The SHA of the commit needing a comment. Not using the latest commit SHA may render your comment outdated if a subsequent commit modifies the line you specify as the `position`.
- `path` (string): The relative path to the file that necessitates a comment.
- `position` (integer, optional): **This parameter is closing down. Use `line` instead**. The position in the diff where you want to add a review comment. Note this value is not the same as the line number in the file. The position value equals the number of lines down from the first "@@" hunk header in the file you want to add a comment. The line just below the "@@" line is position 1, the next line is position 2, and so on. The position in the diff continues to increase through lines of whitespace and additional hunks until the beginning of a new file.
- `side` (string, optional): In a split diff view, the side of the diff that the pull request's changes appear on. Can be `LEFT` or `RIGHT`. Use `LEFT` for deletions that appear in red. Use `RIGHT` for additions that appear in green or unchanged lines that appear in white and are shown for context. For a multi-line comment, side represents whether the last line of the comment range is a deletion or addition. For more information, see "[Diff view options](https://docs.github.com/articles/about-comparing-branches-in-pull-requests#diff-view-options)" in the GitHub Help documentation.
- `line` (integer, optional): **Required unless using `subject_type:file`**. The line of the blob in the pull request diff that the comment applies to. For a multi-line comment, the last line of the range that your comment applies to.
- `start_line` (integer, optional): **Required when using multi-line comments unless using `in_reply_to`**. The `start_line` is the first line in the pull request diff that your multi-line comment applies to. To learn more about multi-line comments, see "[Commenting on a pull request](https://docs.github.com/articles/commenting-on-a-pull-request#adding-line-comments-to-a-pull-request)" in the GitHub Help documentation.
- `start_side` (string, optional): **Required when using multi-line comments unless using `in_reply_to`**. The `start_side` is the starting side of the diff that the comment applies to. Can be `LEFT` or `RIGHT`. To learn more about multi-line comments, see "[Commenting on a pull request](https://docs.github.com/articles/commenting-on-a-pull-request#adding-line-comments-to-a-pull-request)" in the GitHub Help documentation. See `side` in this table for additional context.
- `in_reply_to` (integer, optional): The ID of the review comment to reply to. To find the ID of a review comment with ["List review comments on a pull request"](#list-review-comments-on-a-pull-request). When specified, all parameters other than `body` in the request body are ignored.
- `subject_type` (string, optional): The level at which the comment is targeted.
### pulls_list_review_comments

GET /repos/{owner}/{repo}/pulls/{pull_number}/comments - List review comments on a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `sort` (string, optional): The property to sort the results by. (default: created) — one of: created, updated
- `direction` (string, optional): The direction to sort results. Ignored without `sort` parameter. — one of: asc, desc
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### pulls_create_reply_for_review_comment

POST /repos/{owner}/{repo}/pulls/{pull_number}/comments/{comment_id}/replies - Create a reply for a review comment

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `comment_id` (integer): The unique identifier of the comment.
- `body` (string): The text of the review comment.
### pulls_list_commits

GET /repos/{owner}/{repo}/pulls/{pull_number}/commits - List commits on a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### pulls_list_files

GET /repos/{owner}/{repo}/pulls/{pull_number}/files - List pull requests files

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### pulls_merge

PUT /repos/{owner}/{repo}/pulls/{pull_number}/merge - Merge a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `commit_title` (string, optional): Title for the automatic commit message.
- `commit_message` (string, optional): Extra detail to append to automatic commit message.
- `sha` (string, optional): SHA that pull request head must match to allow merge.
- `merge_method` (string, optional): The merge method to use.
### pulls_check_if_merged

GET /repos/{owner}/{repo}/pulls/{pull_number}/merge - Check if a pull request has been merged

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
### pulls_request_reviewers

POST /repos/{owner}/{repo}/pulls/{pull_number}/requested_reviewers - Request reviewers for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `reviewers` (array, optional): An array of user `login`s that will be requested.
- `team_reviewers` (array, optional): An array of team `slug`s that will be requested.
### pulls_remove_requested_reviewers

DELETE /repos/{owner}/{repo}/pulls/{pull_number}/requested_reviewers - Remove requested reviewers from a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `reviewers` (array): An array of user `login`s that will be removed.
- `team_reviewers` (array, optional): An array of team `slug`s that will be removed.
### pulls_list_requested_reviewers

GET /repos/{owner}/{repo}/pulls/{pull_number}/requested_reviewers - Get all requested reviewers for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
### pulls_create_review

POST /repos/{owner}/{repo}/pulls/{pull_number}/reviews - Create a review for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `commit_id` (string, optional): The SHA of the commit that needs a review. Not using the latest commit SHA may render your review comment outdated if a subsequent commit modifies the line you specify as the `position`. Defaults to the most recent commit in the pull request when you do not specify a value.
- `body` (string, optional): **Required** when using `REQUEST_CHANGES` or `COMMENT` for the `event` parameter. The body text of the pull request review.
- `event` (string, optional): The review action you want to perform. The review actions include: `APPROVE`, `REQUEST_CHANGES`, or `COMMENT`. By leaving this blank, you set the review action state to `PENDING`, which means you will need to [submit the pull request review](https://docs.github.com/rest/pulls/reviews#submit-a-review-for-a-pull-request) when you are ready.
- `comments` (array, optional): Use the following table to specify the location, destination, and contents of the draft review comment.
### pulls_list_reviews

GET /repos/{owner}/{repo}/pulls/{pull_number}/reviews - List reviews for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### pulls_delete_pending_review

DELETE /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id} - Delete a pending review for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `review_id` (integer): The unique identifier of the review.
### pulls_update_review

PUT /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id} - Update a review for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `review_id` (integer): The unique identifier of the review.
- `body` (string): The body text of the pull request review.
### pulls_get_review

GET /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id} - Get a review for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `review_id` (integer): The unique identifier of the review.
### pulls_list_comments_for_review

GET /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}/comments - List comments for a pull request review

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `review_id` (integer): The unique identifier of the review.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### pulls_dismiss_review

PUT /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}/dismissals - Dismiss a review for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `review_id` (integer): The unique identifier of the review.
- `message` (string): The message for the pull request review dismissal
- `event` (string, optional): 
### pulls_submit_review

POST /repos/{owner}/{repo}/pulls/{pull_number}/reviews/{review_id}/events - Submit a review for a pull request

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `review_id` (integer): The unique identifier of the review.
- `body` (string, optional): The body text of the pull request review
- `event` (string): The review action you want to perform. The review actions include: `APPROVE`, `REQUEST_CHANGES`, or `COMMENT`. When you leave this blank, the API returns _HTTP 422 (Unrecognizable entity)_ and sets the review action state to `PENDING`, which means you will need to re-submit the pull request review using a review action.
### pulls_update_branch

PUT /repos/{owner}/{repo}/pulls/{pull_number}/update-branch - Update a pull request branch

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `pull_number` (integer): The number that identifies the pull request.
- `expected_head_sha` (string, optional): The expected SHA of the pull request's HEAD ref. This is the most recent commit on the pull request's branch. If the expected SHA does not match the pull request's HEAD, you will receive a `422 Unprocessable Entity` status. You can use the "[List commits](https://docs.github.com/rest/commits/commits#list-commits)" endpoint to find the most recent commit SHA. Default: SHA of the pull request's current HEAD ref.
### repos_get_readme

GET /repos/{owner}/{repo}/readme - Get a repository README

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string, optional): The name of the commit/branch/tag. Default: the repository’s default branch.
### repos_get_readme_in_directory

GET /repos/{owner}/{repo}/readme/{dir} - Get a repository README for a directory

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `dir` (string): The alternate path to look for a README file
- `ref` (string, optional): The name of the commit/branch/tag. Default: the repository’s default branch.
### repos_create_release

POST /repos/{owner}/{repo}/releases - Create a release

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tag_name` (string): The name of the tag.
- `target_commitish` (string, optional): Specifies the commitish value that determines where the Git tag is created from. Can be any branch or commit SHA. Unused if the Git tag already exists. Default: the repository's default branch.
- `name` (string, optional): The name of the release.
- `body` (string, optional): Text describing the contents of the tag.
- `draft` (boolean, optional): `true` to create a draft (unpublished) release, `false` to create a published one. (default: False)
- `prerelease` (boolean, optional): `true` to identify the release as a prerelease. `false` to identify the release as a full release. (default: False)
- `discussion_category_name` (string, optional): If specified, a discussion of the specified category is created and linked to the release. The value must be a category that already exists in the repository. For more information, see "[Managing categories for discussions in your repository](https://docs.github.com/discussions/managing-discussions-for-your-community/managing-categories-for-discussions-in-your-repository)."
- `generate_release_notes` (boolean, optional): Whether to automatically generate the name and body for this release. If `name` is specified, the specified name will be used; otherwise, a name will be automatically generated. If `body` is specified, the body will be pre-pended to the automatically generated notes. (default: False)
- `make_latest` (string, optional): Specifies whether this release should be set as the latest release for the repository. Drafts and prereleases cannot be set as latest. Defaults to `true` for newly published releases. `legacy` specifies that the latest release should be determined based on the release creation date and higher semantic version. (default: true)
### repos_list_releases

GET /repos/{owner}/{repo}/releases - List releases

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_update_release_asset

PATCH /repos/{owner}/{repo}/releases/assets/{asset_id} - Update a release asset

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `asset_id` (integer): The unique identifier of the asset.
- `name` (string, optional): The file name of the asset.
- `label` (string, optional): An alternate short description of the asset. Used in place of the filename.
- `state` (string, optional): 
### repos_delete_release_asset

DELETE /repos/{owner}/{repo}/releases/assets/{asset_id} - Delete a release asset

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `asset_id` (integer): The unique identifier of the asset.
### repos_get_release_asset

GET /repos/{owner}/{repo}/releases/assets/{asset_id} - Get a release asset

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `asset_id` (integer): The unique identifier of the asset.
### repos_generate_release_notes

POST /repos/{owner}/{repo}/releases/generate-notes - Generate release notes content for a release

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tag_name` (string): The tag name for the release. This can be an existing tag or a new one.
- `target_commitish` (string, optional): Specifies the commitish value that will be the target for the release's tag. Required if the supplied tag_name does not reference an existing tag. Ignored if the tag_name already exists.
- `previous_tag_name` (string, optional): The name of the previous tag to use as the starting point for the release notes. Use to manually specify the range for the set of changes considered as part this release.
- `configuration_file_path` (string, optional): Specifies a path to a file in the repository containing configuration settings used for generating the release notes. If unspecified, the configuration file located in the repository at '.github/release.yml' or '.github/release.yaml' will be used. If that is not present, the default configuration will be used.
### repos_get_latest_release

GET /repos/{owner}/{repo}/releases/latest - Get the latest release

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get_release_by_tag

GET /repos/{owner}/{repo}/releases/tags/{tag} - Get a release by tag name

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `tag` (string): tag parameter
### repos_update_release

PATCH /repos/{owner}/{repo}/releases/{release_id} - Update a release

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `release_id` (integer): The unique identifier of the release.
- `tag_name` (string, optional): The name of the tag.
- `target_commitish` (string, optional): Specifies the commitish value that determines where the Git tag is created from. Can be any branch or commit SHA. Unused if the Git tag already exists. Default: the repository's default branch.
- `name` (string, optional): The name of the release.
- `body` (string, optional): Text describing the contents of the tag.
- `draft` (boolean, optional): `true` makes the release a draft, and `false` publishes the release.
- `prerelease` (boolean, optional): `true` to identify the release as a prerelease, `false` to identify the release as a full release.
- `make_latest` (string, optional): Specifies whether this release should be set as the latest release for the repository. Drafts and prereleases cannot be set as latest. Defaults to `true` for newly published releases. `legacy` specifies that the latest release should be determined based on the release creation date and higher semantic version. (default: True)
- `discussion_category_name` (string, optional): If specified, a discussion of the specified category is created and linked to the release. The value must be a category that already exists in the repository. If there is already a discussion linked to the release, this parameter is ignored. For more information, see "[Managing categories for discussions in your repository](https://docs.github.com/discussions/managing-discussions-for-your-community/managing-categories-for-discussions-in-your-repository)."
### repos_delete_release

DELETE /repos/{owner}/{repo}/releases/{release_id} - Delete a release

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `release_id` (integer): The unique identifier of the release.
### repos_get_release

GET /repos/{owner}/{repo}/releases/{release_id} - Get a release

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `release_id` (integer): The unique identifier of the release.
### repos_upload_release_asset

POST /repos/{owner}/{repo}/releases/{release_id}/assets - Upload a release asset

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `release_id` (integer): The unique identifier of the release.
- `name` (string): 
- `label` (string, optional): 
### repos_list_release_assets

GET /repos/{owner}/{repo}/releases/{release_id}/assets - List release assets

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `release_id` (integer): The unique identifier of the release.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### reactions_create_for_release

POST /repos/{owner}/{repo}/releases/{release_id}/reactions - Create reaction for a release

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `release_id` (integer): The unique identifier of the release.
- `content` (string): The [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions) to add to the release.
### reactions_list_for_release

GET /repos/{owner}/{repo}/releases/{release_id}/reactions - List reactions for a release

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `release_id` (integer): The unique identifier of the release.
- `content` (string, optional): Returns a single [reaction type](https://docs.github.com/rest/reactions/reactions#about-reactions). Omit this parameter to list all reactions to a release. — one of: +1, laugh, heart, hooray, rocket, eyes
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### reactions_delete_for_release

DELETE /repos/{owner}/{repo}/releases/{release_id}/reactions/{reaction_id} - Delete a release reaction

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `release_id` (integer): The unique identifier of the release.
- `reaction_id` (integer): The unique identifier of the reaction.
### repos_get_branch_rules

GET /repos/{owner}/{repo}/rules/branches/{branch} - Get rules for a branch

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `branch` (string): The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_create_repo_ruleset

POST /repos/{owner}/{repo}/rulesets - Create a repository ruleset

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `name` (string): The name of the ruleset.
- `target` (string, optional): The target of the ruleset (default: branch)
- `enforcement` (string): 
- `bypass_actors` (array, optional): The actors that can bypass the rules in this ruleset
- `conditions` (object, optional): 
- `rules` (array, optional): An array of rules within the ruleset.
### repos_get_repo_rulesets

GET /repos/{owner}/{repo}/rulesets - Get all repository rulesets

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `includes_parents` (boolean, optional): Include rulesets configured at higher levels that apply to this repository (default: True)
- `targets` (string, optional): A comma-separated list of rule targets to filter by.
If provided, only rulesets that apply to the specified targets will be returned.
For example, `branch,tag,push`.

### repos_get_repo_rule_suites

GET /repos/{owner}/{repo}/rulesets/rule-suites - List repository rule suites

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string, optional): The name of the ref. Cannot contain wildcard characters. Optionally prefix with `refs/heads/` to limit to branches or `refs/tags/` to limit to tags. Omit the prefix to search across all refs. When specified, only rule evaluations triggered for this ref will be returned.
- `time_period` (string, optional): The time period to filter by.

For example, `day` will filter for rule suites that occurred in the past 24 hours, and `week` will filter for rule suites that occurred in the past 7 days (168 hours). (default: day) — one of: hour, day, week, month
- `actor_name` (string, optional): The handle for the GitHub user account to filter on. When specified, only rule evaluations triggered by this actor will be returned.
- `rule_suite_result` (string, optional): The rule suite results to filter on. When specified, only suites with this result will be returned. (default: all) — one of: pass, fail, bypass, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_repo_rule_suite

GET /repos/{owner}/{repo}/rulesets/rule-suites/{rule_suite_id} - Get a repository rule suite

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `rule_suite_id` (integer): The unique identifier of the rule suite result.
To get this ID, you can use [GET /repos/{owner}/{repo}/rulesets/rule-suites](https://docs.github.com/rest/repos/rule-suites#list-repository-rule-suites)
for repositories and [GET /orgs/{org}/rulesets/rule-suites](https://docs.github.com/rest/orgs/rule-suites#list-organization-rule-suites)
for organizations.
### repos_delete_repo_ruleset

DELETE /repos/{owner}/{repo}/rulesets/{ruleset_id} - Delete a repository ruleset

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ruleset_id` (integer): The ID of the ruleset.
### repos_update_repo_ruleset

PUT /repos/{owner}/{repo}/rulesets/{ruleset_id} - Update a repository ruleset

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ruleset_id` (integer): The ID of the ruleset.
- `name` (string, optional): The name of the ruleset.
- `target` (string, optional): The target of the ruleset
- `enforcement` (string, optional): 
- `bypass_actors` (array, optional): The actors that can bypass the rules in this ruleset
- `conditions` (object, optional): 
- `rules` (array, optional): An array of rules within the ruleset.
### repos_get_repo_ruleset

GET /repos/{owner}/{repo}/rulesets/{ruleset_id} - Get a repository ruleset

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ruleset_id` (integer): The ID of the ruleset.
- `includes_parents` (boolean, optional): Include rulesets configured at higher levels that apply to this repository (default: True)
### repos_get_repo_ruleset_history

GET /repos/{owner}/{repo}/rulesets/{ruleset_id}/history - Get repository ruleset history

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `ruleset_id` (integer): The ID of the ruleset.
### repos_get_repo_ruleset_version

GET /repos/{owner}/{repo}/rulesets/{ruleset_id}/history/{version_id} - Get repository ruleset version

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ruleset_id` (integer): The ID of the ruleset.
- `version_id` (integer): The ID of the version
### secret_scanning_list_alerts_for_repo

GET /repos/{owner}/{repo}/secret-scanning/alerts - List secret scanning alerts for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `state` (string, optional): Set to `open` or `resolved` to only list secret scanning alerts in a specific state. — one of: open, resolved
- `secret_type` (string, optional): A comma-separated list of secret types to return. All default secret patterns are returned. To return generic patterns, pass the token name(s) in the parameter. See "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)" for a complete list of secret types.
- `resolution` (string, optional): A comma-separated list of resolutions. Only secret scanning alerts with one of these resolutions are listed. Valid resolutions are `false_positive`, `wont_fix`, `revoked`, `pattern_edited`, `pattern_deleted` or `used_in_tests`.
- `assignee` (string, optional): Filters alerts by assignee. Use `*` to get all assigned alerts, `none` to get all unassigned alerts, or a GitHub username to get alerts assigned to a specific user.
- `sort` (string, optional): The property to sort the results by. `created` means when the alert was created. `updated` means when the alert was updated or resolved. (default: created) — one of: created, updated
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events before this cursor. To receive an initial cursor on your first request, include an empty "before" query string.
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for events after this cursor.  To receive an initial cursor on your first request, include an empty "after" query string.
- `validity` (string, optional): A comma-separated list of validities that, when present, will return alerts that match the validities in this list. Valid options are `active`, `inactive`, and `unknown`.
- `is_publicly_leaked` (boolean, optional): A boolean value representing whether or not to filter alerts by the publicly-leaked tag being present. (default: False)
- `is_multi_repo` (boolean, optional): A boolean value representing whether or not to filter alerts by the multi-repo tag being present. (default: False)
- `hide_secret` (boolean, optional): A boolean value representing whether or not to hide literal secrets in the results. (default: False)
### secret_scanning_update_alert

PATCH /repos/{owner}/{repo}/secret-scanning/alerts/{alert_number} - Update a secret scanning alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
- `state` (string, optional): 
- `resolution` (string, optional): 
- `resolution_comment` (string, optional): 
- `assignee` (string, optional): 
### secret_scanning_get_alert

GET /repos/{owner}/{repo}/secret-scanning/alerts/{alert_number} - Get a secret scanning alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
- `hide_secret` (boolean, optional): A boolean value representing whether or not to hide literal secrets in the results. (default: False)
### secret_scanning_list_locations_for_alert

GET /repos/{owner}/{repo}/secret-scanning/alerts/{alert_number}/locations - List locations for a secret scanning alert

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `alert_number` (integer): The number that identifies an alert. You can find this at the end of the URL for a code scanning alert within GitHub, and in the `number` field in the response from the `GET /repos/{owner}/{repo}/code-scanning/alerts` operation.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### secret_scanning_create_push_protection_bypass

POST /repos/{owner}/{repo}/secret-scanning/push-protection-bypasses - Create a push protection bypass

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `reason` (string): 
- `placeholder_id` (string): 
### secret_scanning_get_scan_history

GET /repos/{owner}/{repo}/secret-scanning/scan-history - Get secret scanning scan history for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### security_advisories_create_repository_advisory

POST /repos/{owner}/{repo}/security-advisories - Create a repository security advisory

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `summary` (string): A short summary of the advisory.
- `description` (string): A detailed description of what the advisory impacts.
- `cve_id` (string, optional): The Common Vulnerabilities and Exposures (CVE) ID.
- `vulnerabilities` (array): A product affected by the vulnerability detailed in a repository security advisory.
- `cwe_ids` (array, optional): A list of Common Weakness Enumeration (CWE) IDs.
- `credits` (array, optional): A list of users receiving credit for their participation in the security advisory.
- `severity` (string, optional): The severity of the advisory. You must choose between setting this field or `cvss_vector_string`.
- `cvss_vector_string` (string, optional): The CVSS vector that calculates the severity of the advisory. You must choose between setting this field or `severity`.
- `start_private_fork` (boolean, optional): Whether to create a temporary private fork of the repository to collaborate on a fix. (default: False)
### security_advisories_list_repository_advisories

GET /repos/{owner}/{repo}/security-advisories - List repository security advisories

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `sort` (string, optional): The property to sort the results by. (default: created) — one of: created, updated, published
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of advisories to return per page. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `state` (string, optional): Filter by state of the repository advisories. Only advisories of this state will be returned. — one of: triage, draft, published, closed
### post_repos_by_owner_by_repo_security_advisories_reports

POST /repos/{owner}/{repo}/security-advisories/reports - Privately report a security vulnerability

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `summary` (string): A short summary of the advisory.
- `description` (string): A detailed description of what the advisory impacts.
- `vulnerabilities` (array, optional): An array of products affected by the vulnerability detailed in a repository security advisory.
- `cwe_ids` (array, optional): A list of Common Weakness Enumeration (CWE) IDs.
- `severity` (string, optional): The severity of the advisory. You must choose between setting this field or `cvss_vector_string`.
- `cvss_vector_string` (string, optional): The CVSS vector that calculates the severity of the advisory. You must choose between setting this field or `severity`.
- `start_private_fork` (boolean, optional): Whether to create a temporary private fork of the repository to collaborate on a fix. (default: False)
### security_advisories_update_repository_advisory

PATCH /repos/{owner}/{repo}/security-advisories/{ghsa_id} - Update a repository security advisory

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ghsa_id` (string): The GHSA (GitHub Security Advisory) identifier of the advisory.
- `summary` (string, optional): A short summary of the advisory.
- `description` (string, optional): A detailed description of what the advisory impacts.
- `cve_id` (string, optional): The Common Vulnerabilities and Exposures (CVE) ID.
- `vulnerabilities` (array, optional): A product affected by the vulnerability detailed in a repository security advisory.
- `cwe_ids` (array, optional): A list of Common Weakness Enumeration (CWE) IDs.
- `credits` (array, optional): A list of users receiving credit for their participation in the security advisory.
- `severity` (string, optional): The severity of the advisory. You must choose between setting this field or `cvss_vector_string`.
- `cvss_vector_string` (string, optional): The CVSS vector that calculates the severity of the advisory. You must choose between setting this field or `severity`.
- `state` (string, optional): The state of the advisory.
- `collaborating_users` (array, optional): A list of usernames who have been granted write access to the advisory.
- `collaborating_teams` (array, optional): A list of team slugs which have been granted write access to the advisory.
### security_advisories_get_repository_advisory

GET /repos/{owner}/{repo}/security-advisories/{ghsa_id} - Get a repository security advisory

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ghsa_id` (string): The GHSA (GitHub Security Advisory) identifier of the advisory.
### post_repos_by_owner_by_repo_security_advisories_by_ghsa_id_cve

POST /repos/{owner}/{repo}/security-advisories/{ghsa_id}/cve - Request a CVE for a repository security advisory

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ghsa_id` (string): The GHSA (GitHub Security Advisory) identifier of the advisory.
### security_advisories_create_fork

POST /repos/{owner}/{repo}/security-advisories/{ghsa_id}/forks - Create a temporary private fork

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ghsa_id` (string): The GHSA (GitHub Security Advisory) identifier of the advisory.
### activity_list_stargazers_for_repo

GET /repos/{owner}/{repo}/stargazers - List stargazers

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_get_code_frequency_stats

GET /repos/{owner}/{repo}/stats/code_frequency - Get the weekly commit activity

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get_commit_activity_stats

GET /repos/{owner}/{repo}/stats/commit_activity - Get the last year of commit activity

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get_contributors_stats

GET /repos/{owner}/{repo}/stats/contributors - Get all contributor commit activity

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get_participation_stats

GET /repos/{owner}/{repo}/stats/participation - Get the weekly commit count

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get_punch_card_stats

GET /repos/{owner}/{repo}/stats/punch_card - Get the hourly commit count for each day

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_create_commit_status

POST /repos/{owner}/{repo}/statuses/{sha} - Create a commit status

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `sha` (string): 
- `state` (string): The state of the status.
- `target_url` (string, optional): The target URL to associate with this status. This URL will be linked from the GitHub UI to allow users to easily see the source of the status.  
For example, if your continuous integration system is posting build status, you would want to provide the deep link for the build output for this specific SHA:  
`http://ci.example.com/user/repo/build/sha`
- `description` (string, optional): A short description of the status.
- `context` (string, optional): A string label to differentiate this status from the status of other systems. This field is case-insensitive. (default: default)
### activity_list_watchers_for_repo

GET /repos/{owner}/{repo}/subscribers - List watchers

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_delete_repo_subscription

DELETE /repos/{owner}/{repo}/subscription - Delete a repository subscription

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### activity_set_repo_subscription

PUT /repos/{owner}/{repo}/subscription - Set a repository subscription

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `subscribed` (boolean, optional): Determines if notifications should be received from this repository.
- `ignored` (boolean, optional): Determines if all notifications should be blocked from this repository.
### activity_get_repo_subscription

GET /repos/{owner}/{repo}/subscription - Get a repository subscription

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_list_tags

GET /repos/{owner}/{repo}/tags - List repository tags

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_download_tarball_archive

GET /repos/{owner}/{repo}/tarball/{ref} - Download a repository archive (tar)

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): 
### repos_list_teams

GET /repos/{owner}/{repo}/teams - List repository teams

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_replace_all_topics

PUT /repos/{owner}/{repo}/topics - Replace all repository topics

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `names` (array): An array of topics to add to the repository. Pass one or more topics to _replace_ the set of existing topics. Send an empty array (`[]`) to clear all topics from the repository. **Note:** Topic `names` will be saved as lowercase.
### repos_get_all_topics

GET /repos/{owner}/{repo}/topics - Get all repository topics

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### repos_get_clones

GET /repos/{owner}/{repo}/traffic/clones - Get repository clones

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per` (string, optional): The time frame to display results for. (default: day) — one of: day, week
### repos_get_top_paths

GET /repos/{owner}/{repo}/traffic/popular/paths - Get top referral paths

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get_top_referrers

GET /repos/{owner}/{repo}/traffic/popular/referrers - Get top referral sources

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_get_views

GET /repos/{owner}/{repo}/traffic/views - Get page views

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `per` (string, optional): The time frame to display results for. (default: day) — one of: day, week
### repos_transfer

POST /repos/{owner}/{repo}/transfer - Transfer a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `new_owner` (string): The username or organization name the repository will be transferred to.
- `new_name` (string, optional): The new name to be given to the repository.
- `team_ids` (array, optional): ID of the team or teams to add to the repository. Teams can only be added to organization-owned repositories.
### repos_disable_vulnerability_alerts

DELETE /repos/{owner}/{repo}/vulnerability-alerts - Disable vulnerability alerts

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_enable_vulnerability_alerts

PUT /repos/{owner}/{repo}/vulnerability-alerts - Enable vulnerability alerts

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_check_vulnerability_alerts

GET /repos/{owner}/{repo}/vulnerability-alerts - Check if vulnerability alerts are enabled for a repository

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### repos_download_zipball_archive

GET /repos/{owner}/{repo}/zipball/{ref} - Download a repository archive (zip)

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `ref` (string): 
### repos_create_using_template

POST /repos/{template_owner}/{template_repo}/generate - Create a repository using a template

Parameters:
- `template_owner` (string): The account owner of the template repository. The name is not case sensitive.
- `template_repo` (string): The name of the template repository without the `.git` extension. The name is not case sensitive.
- `owner` (string, optional): The organization or person who will own the new repository. To create a new repository in an organization, the authenticated user must be a member of the specified organization.
- `name` (string): The name of the new repository.
- `description` (string, optional): A short description of the new repository.
- `include_all_branches` (boolean, optional): Set to `true` to include the directory structure and files from all branches in the template repository, and not just the default branch. Default: `false`. (default: False)
- `private` (boolean, optional): Either `true` to create a new private repository or `false` to create a new public one. (default: False)
### repos_list_public

GET /repositories - List public repositories

Parameters:
- `since` (integer, optional): A repository ID. Only return repositories with an ID greater than this ID.
### issues_add_issue_field_values

POST /repositories/{repository_id}/issues/{issue_number}/issue-field-values - Add issue field values to an issue

Parameters:
- `repository_id` (integer): The unique identifier of the repository.
- `issue_number` (integer): The number that identifies the issue.
- `issue_field_values` (array, optional): An array of issue field values to add to this issue. Each field value must include the field ID and the value to set.
### issues_set_issue_field_values

PUT /repositories/{repository_id}/issues/{issue_number}/issue-field-values - Set issue field values for an issue

Parameters:
- `repository_id` (integer): The unique identifier of the repository.
- `issue_number` (integer): The number that identifies the issue.
- `issue_field_values` (array, optional): An array of issue field values to set for this issue. Each field value must include the field ID and the value to set. All existing field values will be replaced.
### issues_delete_issue_field_value

DELETE /repositories/{repository_id}/issues/{issue_number}/issue-field-values/{issue_field_id} - Delete an issue field value from an issue

Parameters:
- `repository_id` (integer): The unique identifier of the repository.
- `issue_number` (integer): The number that identifies the issue.
- `issue_field_id` (integer): The unique identifier of the issue field.
### search_code

GET /search/code - Search code

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching code](https://docs.github.com/search-github/searching-on-github/searching-code)" for a detailed list of qualifiers.
- `sort` (string, optional): **This field is closing down.** Sorts the results of your query. Can only be `indexed`, which indicates how recently a file has been indexed by the GitHub search infrastructure. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: indexed
- `order` (string, optional): **This field is closing down.** Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`.  (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### search_commits

GET /search/commits - Search commits

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching commits](https://docs.github.com/search-github/searching-on-github/searching-commits)" for a detailed list of qualifiers.
- `sort` (string, optional): Sorts the results of your query by `author-date` or `committer-date`. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: author-date, committer-date
- `order` (string, optional): Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### search_issues_and_pull_requests

GET /search/issues - Search issues and pull requests

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching issues and pull requests](https://docs.github.com/search-github/searching-on-github/searching-issues-and-pull-requests)" for a detailed list of qualifiers.
- `sort` (string, optional): Sorts the results of your query by the number of `comments`, `reactions`, `reactions-+1`, `reactions--1`, `reactions-smile`, `reactions-thinking_face`, `reactions-heart`, `reactions-tada`, or `interactions`. You can also sort results by how recently the items were `created` or `updated`, Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: comments, reactions, reactions-+1, reactions--1, reactions-smile, reactions-thinking_face, reactions-heart, reactions-tada, interactions, created, updated
- `order` (string, optional): Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `advanced_search` (string, optional): Set to `true` to use advanced search.
Example: `http://api.github.com/search/issues?q={query}&advanced_search=true`
### search_labels

GET /search/labels - Search labels

Parameters:
- `repository_id` (integer): The id of the repository.
- `q` (string): The search keywords. This endpoint does not accept qualifiers in the query. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query).
- `sort` (string, optional): Sorts the results of your query by when the label was `created` or `updated`. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: created, updated
- `order` (string, optional): Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### search_repos

GET /search/repositories - Search repositories

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching for repositories](https://docs.github.com/articles/searching-for-repositories/)" for a detailed list of qualifiers.
- `sort` (string, optional): Sorts the results of your query by number of `stars`, `forks`, or `help-wanted-issues` or how recently the items were `updated`. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: stars, forks, help-wanted-issues, updated
- `order` (string, optional): Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### search_topics

GET /search/topics - Search topics

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query).
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### search_users

GET /search/users - Search users

Parameters:
- `q` (string): The query contains one or more search keywords and qualifiers. Qualifiers allow you to limit your search to specific areas of GitHub. The REST API supports the same qualifiers as the web interface for GitHub. To learn more about the format of the query, see [Constructing a search query](https://docs.github.com/rest/search/search#constructing-a-search-query). See "[Searching users](https://docs.github.com/search-github/searching-on-github/searching-users)" for a detailed list of qualifiers.
- `sort` (string, optional): Sorts the results of your query by number of `followers` or `repositories`, or when the person `joined` GitHub. Default: [best match](https://docs.github.com/rest/search/search#ranking-search-results) — one of: followers, repositories, joined
- `order` (string, optional): Determines whether the first search result returned is the highest number of matches (`desc`) or lowest number of matches (`asc`). This parameter is ignored unless you provide `sort`. (default: desc) — one of: desc, asc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### teams_update_legacy

PATCH /teams/{team_id} - Update a team (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `name` (string): The name of the team.
- `description` (string, optional): The description of the team.
- `privacy` (string, optional): The level of privacy this team should have. Editing teams without specifying this parameter leaves `privacy` intact. The options are:  
**For a non-nested team:**  
 * `secret` - only visible to organization owners and members of this team.  
 * `closed` - visible to all members of this organization.  
**For a parent or child team:**  
 * `closed` - visible to all members of this organization.
- `notification_setting` (string, optional): The notification setting the team has chosen. Editing teams without specifying this parameter leaves `notification_setting` intact. The options are: 
 * `notifications_enabled` - team members receive notifications when the team is @mentioned.  
 * `notifications_disabled` - no one receives notifications.
- `permission` (string, optional): **Closing down notice**. The permission that new repositories will be added to the team with when none is specified. (default: pull)
- `parent_team_id` (integer, optional): The ID of a team to set as the parent team.
### teams_delete_legacy

DELETE /teams/{team_id} - Delete a team (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
### teams_get_legacy

GET /teams/{team_id} - Get a team (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
### teams_list_pending_invitations_legacy

GET /teams/{team_id}/invitations - List pending team invitations (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### teams_list_members_legacy

GET /teams/{team_id}/members - List team members (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `role` (string, optional): Filters members returned by their role in the team. (default: all) — one of: member, maintainer, all
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### teams_remove_member_legacy

DELETE /teams/{team_id}/members/{username} - Remove team member (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `username` (string): The handle for the GitHub user account.
### teams_add_member_legacy

PUT /teams/{team_id}/members/{username} - Add team member (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `username` (string): The handle for the GitHub user account.
### teams_get_member_legacy

GET /teams/{team_id}/members/{username} - Get team member (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `username` (string): The handle for the GitHub user account.
### teams_remove_membership_for_user_legacy

DELETE /teams/{team_id}/memberships/{username} - Remove team membership for a user (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `username` (string): The handle for the GitHub user account.
### teams_add_or_update_membership_for_user_legacy

PUT /teams/{team_id}/memberships/{username} - Add or update team membership for a user (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `username` (string): The handle for the GitHub user account.
- `role` (string, optional): The role that this user should have in the team. (default: member)
### teams_get_membership_for_user_legacy

GET /teams/{team_id}/memberships/{username} - Get team membership for a user (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `username` (string): The handle for the GitHub user account.
### teams_list_repos_legacy

GET /teams/{team_id}/repos - List team repositories (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### teams_remove_repo_legacy

DELETE /teams/{team_id}/repos/{owner}/{repo} - Remove a repository from a team (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### teams_add_or_update_repo_permissions_legacy

PUT /teams/{team_id}/repos/{owner}/{repo} - Add or update team repository permissions (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
- `permission` (string, optional): The permission to grant the team on this repository. If no permission is specified, the team's `permission` attribute will be used to determine what permission to grant the team on this repository.
### teams_check_permissions_for_repo_legacy

GET /teams/{team_id}/repos/{owner}/{repo} - Check team permissions for a repository (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### teams_list_child_legacy

GET /teams/{team_id}/teams - List child teams (Legacy)

Parameters:
- `team_id` (integer): The unique identifier of the team.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_update_authenticated

PATCH /user - Update the authenticated user

Parameters:
- `name` (string, optional): The new name of the user.
- `email` (string, optional): The publicly visible email address of the user.
- `blog` (string, optional): The new blog URL of the user.
- `twitter_username` (string, optional): The new Twitter username of the user.
- `company` (string, optional): The new company of the user.
- `location` (string, optional): The new location of the user.
- `hireable` (boolean, optional): The new hiring availability of the user.
- `bio` (string, optional): The new short biography of the user.
### users_get_authenticated

GET /user - Get the authenticated user

### users_list_blocked_by_authenticated_user

GET /user/blocks - List users blocked by the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_unblock

DELETE /user/blocks/{username} - Unblock a user

Parameters:
- `username` (string): The handle for the GitHub user account.
### users_block

PUT /user/blocks/{username} - Block a user

Parameters:
- `username` (string): The handle for the GitHub user account.
### users_check_blocked

GET /user/blocks/{username} - Check if a user is blocked by the authenticated user

Parameters:
- `username` (string): The handle for the GitHub user account.
### codespaces_create_for_authenticated_user

POST /user/codespaces - Create a codespace for the authenticated user

Parameters:
- `body` (object): Request body
### codespaces_list_for_authenticated_user

GET /user/codespaces - List codespaces for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `repository_id` (integer, optional): ID of the Repository to filter on
### codespaces_list_secrets_for_authenticated_user

GET /user/codespaces/secrets - List secrets for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### codespaces_get_public_key_for_authenticated_user

GET /user/codespaces/secrets/public-key - Get public key for the authenticated user

### codespaces_delete_secret_for_authenticated_user

DELETE /user/codespaces/secrets/{secret_name} - Delete a secret for the authenticated user

Parameters:
- `secret_name` (string): The name of the secret.
### put_user_codespaces_secrets_by_secret_name

PUT /user/codespaces/secrets/{secret_name} - Create or update a secret for the authenticated user

Parameters:
- `secret_name` (string): The name of the secret.
- `encrypted_value` (string, optional): Value for your secret, encrypted with [LibSodium](https://libsodium.gitbook.io/doc/bindings_for_other_languages) using the public key retrieved from the [Get the public key for the authenticated user](https://docs.github.com/rest/codespaces/secrets#get-public-key-for-the-authenticated-user) endpoint.
- `key_id` (string): ID of the key you used to encrypt the secret.
- `selected_repository_ids` (array, optional): An array of repository ids that can access the user secret. You can manage the list of selected repositories using the [List selected repositories for a user secret](https://docs.github.com/rest/codespaces/secrets#list-selected-repositories-for-a-user-secret), [Set selected repositories for a user secret](https://docs.github.com/rest/codespaces/secrets#set-selected-repositories-for-a-user-secret), and [Remove a selected repository from a user secret](https://docs.github.com/rest/codespaces/secrets#remove-a-selected-repository-from-a-user-secret) endpoints.
### codespaces_get_secret_for_authenticated_user

GET /user/codespaces/secrets/{secret_name} - Get a secret for the authenticated user

Parameters:
- `secret_name` (string): The name of the secret.
### put_user_codespaces_secrets_by_secret_name_repositories

PUT /user/codespaces/secrets/{secret_name}/repositories - Set selected repositories for a user secret

Parameters:
- `secret_name` (string): The name of the secret.
- `selected_repository_ids` (array): An array of repository ids for which a codespace can access the secret. You can manage the list of selected repositories using the [List selected repositories for a user secret](https://docs.github.com/rest/codespaces/secrets#list-selected-repositories-for-a-user-secret), [Add a selected repository to a user secret](https://docs.github.com/rest/codespaces/secrets#add-a-selected-repository-to-a-user-secret), and [Remove a selected repository from a user secret](https://docs.github.com/rest/codespaces/secrets#remove-a-selected-repository-from-a-user-secret) endpoints.
### get_user_codespaces_secrets_by_secret_name_repositories

GET /user/codespaces/secrets/{secret_name}/repositories - List selected repositories for a user secret

Parameters:
- `secret_name` (string): The name of the secret.
### delete_user_codespaces_secrets_by_secret_name_repositories_by_repository_id

DELETE /user/codespaces/secrets/{secret_name}/repositories/{repository_id} - Remove a selected repository from a user secret

Parameters:
- `secret_name` (string): The name of the secret.
- `repository_id` (integer): 
### put_user_codespaces_secrets_by_secret_name_repositories_by_repository_id

PUT /user/codespaces/secrets/{secret_name}/repositories/{repository_id} - Add a selected repository to a user secret

Parameters:
- `secret_name` (string): The name of the secret.
- `repository_id` (integer): 
### codespaces_update_for_authenticated_user

PATCH /user/codespaces/{codespace_name} - Update a codespace for the authenticated user

Parameters:
- `codespace_name` (string): The name of the codespace.
- `machine` (string, optional): A valid machine to transition this codespace to.
- `display_name` (string, optional): Display name for this codespace
- `recent_folders` (array, optional): Recently opened folders inside the codespace. It is currently used by the clients to determine the folder path to load the codespace in.
### codespaces_delete_for_authenticated_user

DELETE /user/codespaces/{codespace_name} - Delete a codespace for the authenticated user

Parameters:
- `codespace_name` (string): The name of the codespace.
### codespaces_get_for_authenticated_user

GET /user/codespaces/{codespace_name} - Get a codespace for the authenticated user

Parameters:
- `codespace_name` (string): The name of the codespace.
### codespaces_export_for_authenticated_user

POST /user/codespaces/{codespace_name}/exports - Export a codespace for the authenticated user

Parameters:
- `codespace_name` (string): The name of the codespace.
### get_user_codespaces_by_codespace_name_exports_by_export_id

GET /user/codespaces/{codespace_name}/exports/{export_id} - Get details about a codespace export

Parameters:
- `codespace_name` (string): The name of the codespace.
- `export_id` (string): The ID of the export operation, or `latest`. Currently only `latest` is currently supported.
### get_user_codespaces_by_codespace_name_machines

GET /user/codespaces/{codespace_name}/machines - List machine types for a codespace

Parameters:
- `codespace_name` (string): The name of the codespace.
### codespaces_publish_for_authenticated_user

POST /user/codespaces/{codespace_name}/publish - Create a repository from an unpublished codespace

Parameters:
- `codespace_name` (string): The name of the codespace.
- `name` (string, optional): A name for the new repository.
- `private` (boolean, optional): Whether the new repository should be private. (default: False)
### codespaces_start_for_authenticated_user

POST /user/codespaces/{codespace_name}/start - Start a codespace for the authenticated user

Parameters:
- `codespace_name` (string): The name of the codespace.
### codespaces_stop_for_authenticated_user

POST /user/codespaces/{codespace_name}/stop - Stop a codespace for the authenticated user

Parameters:
- `codespace_name` (string): The name of the codespace.
### get_user_docker_conflicts

GET /user/docker/conflicts - Get list of conflicting packages during Docker migration for authenticated-user

### patch_user_email_visibility

PATCH /user/email/visibility - Set primary email visibility for the authenticated user

Parameters:
- `visibility` (string): Denotes whether an email is publicly visible.
### users_add_email_for_authenticated_user

POST /user/emails - Add an email address for the authenticated user

Parameters:
- `body` (object, optional): Request body
### users_delete_email_for_authenticated_user

DELETE /user/emails - Delete an email address for the authenticated user

Parameters:
- `body` (object): Request body
### users_list_emails_for_authenticated_user

GET /user/emails - List email addresses for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_list_followers_for_authenticated_user

GET /user/followers - List followers of the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_list_followed_by_authenticated_user

GET /user/following - List the people the authenticated user follows

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_unfollow

DELETE /user/following/{username} - Unfollow a user

Parameters:
- `username` (string): The handle for the GitHub user account.
### users_follow

PUT /user/following/{username} - Follow a user

Parameters:
- `username` (string): The handle for the GitHub user account.
### users_check_person_is_followed_by_authenticated

GET /user/following/{username} - Check if a person is followed by the authenticated user

Parameters:
- `username` (string): The handle for the GitHub user account.
### users_create_gpg_key_for_authenticated_user

POST /user/gpg_keys - Create a GPG key for the authenticated user

Parameters:
- `name` (string, optional): A descriptive name for the new key.
- `armored_public_key` (string): A GPG key in ASCII-armored format.
### users_list_gpg_keys_for_authenticated_user

GET /user/gpg_keys - List GPG keys for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_delete_gpg_key_for_authenticated_user

DELETE /user/gpg_keys/{gpg_key_id} - Delete a GPG key for the authenticated user

Parameters:
- `gpg_key_id` (integer): The unique identifier of the GPG key.
### users_get_gpg_key_for_authenticated_user

GET /user/gpg_keys/{gpg_key_id} - Get a GPG key for the authenticated user

Parameters:
- `gpg_key_id` (integer): The unique identifier of the GPG key.
### apps_list_installations_for_authenticated_user

GET /user/installations - List app installations accessible to the user access token

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### get_user_installations_by_installation_id_repositories

GET /user/installations/{installation_id}/repositories - List repositories accessible to the user access token

Parameters:
- `installation_id` (integer): The unique identifier of the installation.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### delete_user_installations_by_installation_id_repositories_by_repository_id

DELETE /user/installations/{installation_id}/repositories/{repository_id} - Remove a repository from an app installation

Parameters:
- `installation_id` (integer): The unique identifier of the installation.
- `repository_id` (integer): The unique identifier of the repository.
### put_user_installations_by_installation_id_repositories_by_repository_id

PUT /user/installations/{installation_id}/repositories/{repository_id} - Add a repository to an app installation

Parameters:
- `installation_id` (integer): The unique identifier of the installation.
- `repository_id` (integer): The unique identifier of the repository.
### delete_user_interaction_limits

DELETE /user/interaction-limits - Remove interaction restrictions from your public repositories

### put_user_interaction_limits

PUT /user/interaction-limits - Set interaction restrictions for your public repositories

Parameters:
- `limit` (string): 
- `expiry` (string, optional): 
### get_user_interaction_limits

GET /user/interaction-limits - Get interaction restrictions for your public repositories

### issues_list_for_authenticated_user

GET /user/issues - List user account issues assigned to the authenticated user

Parameters:
- `filter` (string, optional): Indicates which sorts of issues to return. `assigned` means issues assigned to you. `created` means issues created by you. `mentioned` means issues mentioning you. `subscribed` means issues you're subscribed to updates for. `all` or `repos` means all issues you can see, regardless of participation or creation. (default: assigned) — one of: assigned, created, mentioned, subscribed, repos, all
- `state` (string, optional): Indicates the state of the issues to return. (default: open) — one of: open, closed, all
- `labels` (string, optional): A list of comma separated label names. Example: `bug,ui,@high`
- `sort` (string, optional): What to sort results by. (default: created) — one of: created, updated, comments
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### post_user_keys

POST /user/keys - Create a public SSH key for the authenticated user

Parameters:
- `title` (string, optional): A descriptive name for the new key.
- `key` (string): The public SSH key to add to your GitHub account.
### users_list_public_ssh_keys_for_authenticated_user

GET /user/keys - List public SSH keys for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### delete_user_keys_by_key_id

DELETE /user/keys/{key_id} - Delete a public SSH key for the authenticated user

Parameters:
- `key_id` (integer): The unique identifier of the key.
### users_get_public_ssh_key_for_authenticated_user

GET /user/keys/{key_id} - Get a public SSH key for the authenticated user

Parameters:
- `key_id` (integer): The unique identifier of the key.
### apps_list_subscriptions_for_authenticated_user

GET /user/marketplace_purchases - List subscriptions for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### get_user_marketplace_purchases_stubbed

GET /user/marketplace_purchases/stubbed - List subscriptions for the authenticated user (stubbed)

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_list_memberships_for_authenticated_user

GET /user/memberships/orgs - List organization memberships for the authenticated user

Parameters:
- `state` (string, optional): Indicates the state of the memberships to return. If not specified, the API returns both active and pending memberships. — one of: active, pending
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_update_membership_for_authenticated_user

PATCH /user/memberships/orgs/{org} - Update an organization membership for the authenticated user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
- `state` (string): The state that the membership should be in. Only `"active"` will be accepted.
### orgs_get_membership_for_authenticated_user

GET /user/memberships/orgs/{org} - Get an organization membership for the authenticated user

Parameters:
- `org` (string): The organization name. The name is not case sensitive.
### migrations_start_for_authenticated_user

POST /user/migrations - Start a user migration

Parameters:
- `lock_repositories` (boolean, optional): Lock the repositories being migrated at the start of the migration
- `exclude_metadata` (boolean, optional): Indicates whether metadata should be excluded and only git source should be included for the migration.
- `exclude_git_data` (boolean, optional): Indicates whether the repository git data should be excluded from the migration.
- `exclude_attachments` (boolean, optional): Do not include attachments in the migration
- `exclude_releases` (boolean, optional): Do not include releases in the migration
- `exclude_owner_projects` (boolean, optional): Indicates whether projects owned by the organization or users should be excluded.
- `org_metadata_only` (boolean, optional): Indicates whether this should only include organization metadata (repositories array should be empty and will ignore other flags). (default: False)
- `exclude` (array, optional): Exclude attributes from the API response to improve performance
- `repositories` (array): 
### migrations_list_for_authenticated_user

GET /user/migrations - List user migrations

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### migrations_get_status_for_authenticated_user

GET /user/migrations/{migration_id} - Get a user migration status

Parameters:
- `migration_id` (integer): The unique identifier of the migration.
- `exclude` (array, optional): 
### migrations_delete_archive_for_authenticated_user

DELETE /user/migrations/{migration_id}/archive - Delete a user migration archive

Parameters:
- `migration_id` (integer): The unique identifier of the migration.
### migrations_get_archive_for_authenticated_user

GET /user/migrations/{migration_id}/archive - Download a user migration archive

Parameters:
- `migration_id` (integer): The unique identifier of the migration.
### migrations_unlock_repo_for_authenticated_user

DELETE /user/migrations/{migration_id}/repos/{repo_name}/lock - Unlock a user repository

Parameters:
- `migration_id` (integer): The unique identifier of the migration.
- `repo_name` (string): repo_name parameter
### migrations_list_repos_for_authenticated_user

GET /user/migrations/{migration_id}/repositories - List repositories for a user migration

Parameters:
- `migration_id` (integer): The unique identifier of the migration.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_list_for_authenticated_user

GET /user/orgs - List organizations for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### packages_list_packages_for_authenticated_user

GET /user/packages - List packages for the authenticated user's namespace

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `visibility` (string, optional): The selected visibility of the packages.  This parameter is optional and only filters an existing result set.

The `internal` visibility is only supported for GitHub Packages registries that allow for granular permissions. For other ecosystems `internal` is synonymous with `private`.
For the list of GitHub Packages registries that support granular permissions, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." — one of: public, private, internal
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### packages_delete_package_for_authenticated_user

DELETE /user/packages/{package_type}/{package_name} - Delete a package for the authenticated user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
### packages_get_package_for_authenticated_user

GET /user/packages/{package_type}/{package_name} - Get a package for the authenticated user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
### packages_restore_package_for_authenticated_user

POST /user/packages/{package_type}/{package_name}/restore - Restore a package for the authenticated user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `token` (string, optional): package token
### get_user_packages_by_package_type_by_package_name_versions

GET /user/packages/{package_type}/{package_name}/versions - List package versions for a package owned by the authenticated user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `state` (string, optional): The state of the package, either active or deleted. (default: active) — one of: active, deleted
### delete_user_packages_by_package_type_by_package_name_versions_by_package_version_id

DELETE /user/packages/{package_type}/{package_name}/versions/{package_version_id} - Delete a package version for the authenticated user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `package_version_id` (integer): Unique identifier of the package version.
### get_user_packages_by_package_type_by_package_name_versions_by_package_version_id

GET /user/packages/{package_type}/{package_name}/versions/{package_version_id} - Get a package version for the authenticated user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `package_version_id` (integer): Unique identifier of the package version.
### post_user_packages_by_package_type_by_package_name_versions_by_package_version_id_restore

POST /user/packages/{package_type}/{package_name}/versions/{package_version_id}/restore - Restore a package version for the authenticated user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `package_version_id` (integer): Unique identifier of the package version.
### users_list_public_emails_for_authenticated_user

GET /user/public_emails - List public email addresses for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_create_for_authenticated_user

POST /user/repos - Create a repository for the authenticated user

Parameters:
- `name` (string): The name of the repository.
- `description` (string, optional): A short description of the repository.
- `homepage` (string, optional): A URL with more information about the repository.
- `private` (boolean, optional): Whether the repository is private. (default: False)
- `has_issues` (boolean, optional): Whether issues are enabled. (default: True)
- `has_projects` (boolean, optional): Whether projects are enabled. (default: True)
- `has_wiki` (boolean, optional): Whether the wiki is enabled. (default: True)
- `has_discussions` (boolean, optional): Whether discussions are enabled. (default: False)
- `team_id` (integer, optional): The id of the team that will be granted access to this repository. This is only valid when creating a repository in an organization.
- `auto_init` (boolean, optional): Whether the repository is initialized with a minimal README. (default: False)
- `gitignore_template` (string, optional): The desired language or platform to apply to the .gitignore.
- `license_template` (string, optional): The license keyword of the open source license for this repository.
- `allow_squash_merge` (boolean, optional): Whether to allow squash merges for pull requests. (default: True)
- `allow_merge_commit` (boolean, optional): Whether to allow merge commits for pull requests. (default: True)
- `allow_rebase_merge` (boolean, optional): Whether to allow rebase merges for pull requests. (default: True)
- `allow_auto_merge` (boolean, optional): Whether to allow Auto-merge to be used on pull requests. (default: False)
- `delete_branch_on_merge` (boolean, optional): Whether to delete head branches when pull requests are merged (default: False)
- `squash_merge_commit_title` (string, optional): Required when using `squash_merge_commit_message`.

The default value for a squash merge commit title:

- `PR_TITLE` - default to the pull request's title.
- `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit).
- `squash_merge_commit_message` (string, optional): The default value for a squash merge commit message:

- `PR_BODY` - default to the pull request's body.
- `COMMIT_MESSAGES` - default to the branch's commit messages.
- `BLANK` - default to a blank commit message.
- `merge_commit_title` (string, optional): Required when using `merge_commit_message`.

The default value for a merge commit title.

- `PR_TITLE` - default to the pull request's title.
- `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name).
- `merge_commit_message` (string, optional): The default value for a merge commit message.

- `PR_TITLE` - default to the pull request's title.
- `PR_BODY` - default to the pull request's body.
- `BLANK` - default to a blank commit message.
- `has_downloads` (boolean, optional): Whether downloads are enabled. (default: True)
- `is_template` (boolean, optional): Whether this repository acts as a template that can be used to generate new repositories. (default: False)
### repos_list_for_authenticated_user

GET /user/repos - List repositories for the authenticated user

Parameters:
- `visibility` (string, optional): Limit results to repositories with the specified visibility. (default: all) — one of: all, public, private
- `affiliation` (string, optional): Comma-separated list of values. Can include:  
 * `owner`: Repositories that are owned by the authenticated user.  
 * `collaborator`: Repositories that the user has been added to as a collaborator.  
 * `organization_member`: Repositories that the user has access to through being a member of an organization. This includes every repository on every team that the user is on. (default: owner,collaborator,organization_member)
- `type` (string, optional): Limit results to repositories of the specified type. Will cause a `422` error if used in the same request as **visibility** or **affiliation**. (default: all) — one of: all, owner, public, private, member
- `sort` (string, optional): The property to sort the results by. (default: full_name) — one of: created, updated, pushed, full_name
- `direction` (string, optional): The order to sort by. Default: `asc` when using `full_name`, otherwise `desc`. — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `since` (string, optional): Only show repositories updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `before` (string, optional): Only show repositories updated before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
### repos_list_invitations_for_authenticated_user

GET /user/repository_invitations - List repository invitations for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_accept_invitation_for_authenticated_user

PATCH /user/repository_invitations/{invitation_id} - Accept a repository invitation

Parameters:
- `invitation_id` (integer): The unique identifier of the invitation.
### repos_decline_invitation_for_authenticated_user

DELETE /user/repository_invitations/{invitation_id} - Decline a repository invitation

Parameters:
- `invitation_id` (integer): The unique identifier of the invitation.
### users_add_social_account_for_authenticated_user

POST /user/social_accounts - Add social accounts for the authenticated user

Parameters:
- `account_urls` (array): Full URLs for the social media profiles to add.
### delete_user_social_accounts

DELETE /user/social_accounts - Delete social accounts for the authenticated user

Parameters:
- `account_urls` (array): Full URLs for the social media profiles to delete.
### users_list_social_accounts_for_authenticated_user

GET /user/social_accounts - List social accounts for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### post_user_ssh_signing_keys

POST /user/ssh_signing_keys - Create a SSH signing key for the authenticated user

Parameters:
- `title` (string, optional): A descriptive name for the new key.
- `key` (string): The public SSH key to add to your GitHub account. For more information, see "[Checking for existing SSH keys](https://docs.github.com/authentication/connecting-to-github-with-ssh/checking-for-existing-ssh-keys)."
### get_user_ssh_signing_keys

GET /user/ssh_signing_keys - List SSH signing keys for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### delete_user_ssh_signing_keys_by_ssh_signing_key_id

DELETE /user/ssh_signing_keys/{ssh_signing_key_id} - Delete an SSH signing key for the authenticated user

Parameters:
- `ssh_signing_key_id` (integer): The unique identifier of the SSH signing key.
### users_get_ssh_signing_key_for_authenticated_user

GET /user/ssh_signing_keys/{ssh_signing_key_id} - Get an SSH signing key for the authenticated user

Parameters:
- `ssh_signing_key_id` (integer): The unique identifier of the SSH signing key.
### activity_list_repos_starred_by_authenticated_user

GET /user/starred - List repositories starred by the authenticated user

Parameters:
- `sort` (string, optional): The property to sort the results by. `created` means when the repository was starred. `updated` means when the repository was last pushed to. (default: created) — one of: created, updated
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_unstar_repo_for_authenticated_user

DELETE /user/starred/{owner}/{repo} - Unstar a repository for the authenticated user

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### activity_star_repo_for_authenticated_user

PUT /user/starred/{owner}/{repo} - Star a repository for the authenticated user

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### get_user_starred_by_owner_by_repo

GET /user/starred/{owner}/{repo} - Check if a repository is starred by the authenticated user

Parameters:
- `owner` (string): The account owner of the repository. The name is not case sensitive.
- `repo` (string): The name of the repository without the `.git` extension. The name is not case sensitive.
### get_user_subscriptions

GET /user/subscriptions - List repositories watched by the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### teams_list_for_authenticated_user

GET /user/teams - List teams for the authenticated user

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_get_by_id

GET /user/{account_id} - Get a user using their ID

Parameters:
- `account_id` (integer): account_id parameter
### projects_create_draft_item_for_authenticated_user

POST /user/{user_id}/projectsV2/{project_number}/drafts - Create draft item for user owned project

Parameters:
- `user_id` (string): The unique identifier of the user.
- `project_number` (integer): The project's number.
- `title` (string): The title of the draft issue item to create in the project.
- `body` (string, optional): The body content of the draft issue item to create in the project.
### users_list

GET /users - List users

Parameters:
- `since` (integer, optional): A user ID. Only return users with an ID greater than this ID.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### projects_create_view_for_user

POST /users/{user_id}/projectsV2/{project_number}/views - Create a view for a user-owned project

Parameters:
- `user_id` (string): The unique identifier of the user.
- `project_number` (integer): The project's number.
- `name` (string): The name of the view.
- `layout` (string): The layout of the view.
- `filter` (string, optional): The filter query for the view. See [Filtering projects](https://docs.github.com/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/filtering-projects) for more information.
- `visible_fields` (array, optional): `visible_fields` is not applicable to `roadmap` layout views.
For `table` and `board` layouts, this represents the field IDs that should be visible in the view. If not provided, the default visible fields will be used.
### users_get_by_username

GET /users/{username} - Get a user

Parameters:
- `username` (string): The handle for the GitHub user account.
### users_list_attestations_bulk

POST /users/{username}/attestations/bulk-list - List attestations by bulk subject digests

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `username` (string): The handle for the GitHub user account.
- `subject_digests` (array): List of subject digests to fetch attestations for.
- `predicate_type` (string, optional): Optional filter for fetching attestations with a given predicate type.
This option accepts `provenance`, `sbom`, `release`, or freeform text
for custom predicate types.
### users_delete_attestations_bulk

POST /users/{username}/attestations/delete-request - Delete attestations in bulk

Parameters:
- `username` (string): The handle for the GitHub user account.
- `body` (object): Request body
### users_delete_attestations_by_subject_digest

DELETE /users/{username}/attestations/digest/{subject_digest} - Delete attestations by subject digest

Parameters:
- `username` (string): The handle for the GitHub user account.
- `subject_digest` (string): Subject Digest
### users_delete_attestations_by_id

DELETE /users/{username}/attestations/{attestation_id} - Delete attestations by ID

Parameters:
- `username` (string): The handle for the GitHub user account.
- `attestation_id` (integer): Attestation ID
### users_list_attestations

GET /users/{username}/attestations/{subject_digest} - List attestations

Parameters:
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `username` (string): The handle for the GitHub user account.
- `subject_digest` (string): Subject Digest
- `predicate_type` (string, optional): Optional filter for fetching attestations with a given predicate type.
This option accepts `provenance`, `sbom`, `release`, or freeform text
for custom predicate types.
### get_users_by_username_docker_conflicts

GET /users/{username}/docker/conflicts - Get list of conflicting packages during Docker migration for user

Parameters:
- `username` (string): The handle for the GitHub user account.
### activity_list_events_for_authenticated_user

GET /users/{username}/events - List events for the authenticated user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_list_org_events_for_authenticated_user

GET /users/{username}/events/orgs/{org} - List organization events for the authenticated user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `org` (string): The organization name. The name is not case sensitive.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_list_public_events_for_user

GET /users/{username}/events/public - List public events for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_list_followers_for_user

GET /users/{username}/followers - List followers of a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_list_following_for_user

GET /users/{username}/following - List the people a user follows

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_check_following_for_user

GET /users/{username}/following/{target_user} - Check if a user follows another user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `target_user` (string): 
### gists_list_for_user

GET /users/{username}/gists - List gists for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `since` (string, optional): Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_list_gpg_keys_for_user

GET /users/{username}/gpg_keys - List GPG keys for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_get_context_for_user

GET /users/{username}/hovercard - Get contextual information for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `subject_type` (string, optional): Identifies which additional information you'd like to receive about the person's hovercard. Can be `organization`, `repository`, `issue`, `pull_request`. **Required** when using `subject_id`. — one of: organization, repository, issue, pull_request
- `subject_id` (string, optional): Uses the ID for the `subject_type` you specified. **Required** when using `subject_type`.
### apps_get_user_installation

GET /users/{username}/installation - Get a user installation for the authenticated app

Parameters:
- `username` (string): The handle for the GitHub user account.
### users_list_public_keys_for_user

GET /users/{username}/keys - List public keys for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### orgs_list_for_user

GET /users/{username}/orgs - List organizations for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### packages_list_packages_for_user

GET /users/{username}/packages - List packages for a user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `visibility` (string, optional): The selected visibility of the packages.  This parameter is optional and only filters an existing result set.

The `internal` visibility is only supported for GitHub Packages registries that allow for granular permissions. For other ecosystems `internal` is synonymous with `private`.
For the list of GitHub Packages registries that support granular permissions, see "[About permissions for GitHub Packages](https://docs.github.com/packages/learn-github-packages/about-permissions-for-github-packages#granular-permissions-for-userorganization-scoped-packages)." — one of: public, private, internal
- `username` (string): The handle for the GitHub user account.
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### packages_delete_package_for_user

DELETE /users/{username}/packages/{package_type}/{package_name} - Delete a package for a user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `username` (string): The handle for the GitHub user account.
### packages_get_package_for_user

GET /users/{username}/packages/{package_type}/{package_name} - Get a package for a user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `username` (string): The handle for the GitHub user account.
### packages_restore_package_for_user

POST /users/{username}/packages/{package_type}/{package_name}/restore - Restore a package for a user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `username` (string): The handle for the GitHub user account.
- `token` (string, optional): package token
### get_users_by_username_packages_by_package_type_by_package_name_versions

GET /users/{username}/packages/{package_type}/{package_name}/versions - List package versions for a package owned by a user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `username` (string): The handle for the GitHub user account.
### packages_delete_package_version_for_user

DELETE /users/{username}/packages/{package_type}/{package_name}/versions/{package_version_id} - Delete package version for a user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `username` (string): The handle for the GitHub user account.
- `package_version_id` (integer): Unique identifier of the package version.
### packages_get_package_version_for_user

GET /users/{username}/packages/{package_type}/{package_name}/versions/{package_version_id} - Get a package version for a user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `package_version_id` (integer): Unique identifier of the package version.
- `username` (string): The handle for the GitHub user account.
### packages_restore_package_version_for_user

POST /users/{username}/packages/{package_type}/{package_name}/versions/{package_version_id}/restore - Restore package version for a user

Parameters:
- `package_type` (string): The type of supported package. Packages in GitHub's Gradle registry have the type `maven`. Docker images pushed to GitHub's Container registry (`ghcr.io`) have the type `container`. You can use the type `docker` to find images that were pushed to GitHub's Docker registry (`docker.pkg.github.com`), even if these have now been migrated to the Container registry. — one of: npm, maven, rubygems, docker, nuget, container
- `package_name` (string): The name of the package.
- `username` (string): The handle for the GitHub user account.
- `package_version_id` (integer): Unique identifier of the package version.
### projects_list_for_user

GET /users/{username}/projectsV2 - List projects for user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `q` (string, optional): Limit results to projects of the specified type.
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### projects_get_for_user

GET /users/{username}/projectsV2/{project_number} - Get project for user

Parameters:
- `project_number` (integer): The project's number.
- `username` (string): The handle for the GitHub user account.
### projects_add_field_for_user

POST /users/{username}/projectsV2/{project_number}/fields - Add field to user owned project

Parameters:
- `username` (string): The handle for the GitHub user account.
- `project_number` (integer): The project's number.
- `body` (object): Request body
### projects_list_fields_for_user

GET /users/{username}/projectsV2/{project_number}/fields - List project fields for user

Parameters:
- `project_number` (integer): The project's number.
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
### projects_get_field_for_user

GET /users/{username}/projectsV2/{project_number}/fields/{field_id} - Get project field for user

Parameters:
- `project_number` (integer): The project's number.
- `field_id` (integer): The unique identifier of the field.
- `username` (string): The handle for the GitHub user account.
### projects_add_item_for_user

POST /users/{username}/projectsV2/{project_number}/items - Add item to user owned project

Parameters:
- `username` (string): The handle for the GitHub user account.
- `project_number` (integer): The project's number.
- `type` (string): The type of item to add to the project. Must be either Issue or PullRequest.
- `id` (integer, optional): The unique identifier of the issue or pull request to add to the project.
- `owner` (string, optional): The repository owner login.
- `repo` (string, optional): The repository name.
- `number` (integer, optional): The issue or pull request number.
### projects_list_items_for_user

GET /users/{username}/projectsV2/{project_number}/items - List items for a user owned project

Parameters:
- `project_number` (integer): The project's number.
- `username` (string): The handle for the GitHub user account.
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `q` (string, optional): Search query to filter items, see [Filtering projects](https://docs.github.com/issues/planning-and-tracking-with-projects/customizing-views-in-your-project/filtering-projects) for more information.
- `fields` (object, optional): Limit results to specific fields, by their IDs. If not specified, the title field will be returned.

Example: `fields[]=123&fields[]=456&fields[]=789` or `fields=123,456,789`
### projects_update_item_for_user

PATCH /users/{username}/projectsV2/{project_number}/items/{item_id} - Update project item for user

Parameters:
- `project_number` (integer): The project's number.
- `username` (string): The handle for the GitHub user account.
- `item_id` (integer): The unique identifier of the project item.
- `fields` (array): A list of field updates to apply.
### projects_delete_item_for_user

DELETE /users/{username}/projectsV2/{project_number}/items/{item_id} - Delete project item for user

Parameters:
- `project_number` (integer): The project's number.
- `username` (string): The handle for the GitHub user account.
- `item_id` (integer): The unique identifier of the project item.
### projects_get_user_item

GET /users/{username}/projectsV2/{project_number}/items/{item_id} - Get an item for a user owned project

Parameters:
- `project_number` (integer): The project's number.
- `username` (string): The handle for the GitHub user account.
- `item_id` (integer): The unique identifier of the project item.
- `fields` (object, optional): Limit results to specific fields, by their IDs. If not specified, the title field will be returned.

Example: fields[]=123&fields[]=456&fields[]=789 or fields=123,456,789
### projects_list_view_items_for_user

GET /users/{username}/projectsV2/{project_number}/views/{view_number}/items - List items for a user project view

Parameters:
- `project_number` (integer): The project's number.
- `username` (string): The handle for the GitHub user account.
- `view_number` (integer): The number that identifies the project view.
- `fields` (object, optional): Limit results to specific fields, by their IDs. If not specified, the
title field will be returned.

Example: `fields[]=123&fields[]=456&fields[]=789` or `fields=123,456,789`
- `before` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `after` (string, optional): A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
### activity_list_received_events_for_user

GET /users/{username}/received_events - List events received by the authenticated user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_list_received_public_events_for_user

GET /users/{username}/received_events/public - List public events received by a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### repos_list_for_user

GET /users/{username}/repos - List repositories for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `type` (string, optional): Limit results to repositories of the specified type. (default: owner) — one of: all, owner, member
- `sort` (string, optional): The property to sort the results by. (default: full_name) — one of: created, updated, pushed, full_name
- `direction` (string, optional): The order to sort by. Default: `asc` when using `full_name`, otherwise `desc`. — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### get_users_by_username_settings_billing_premium_request_usage

GET /users/{username}/settings/billing/premium_request/usage - Get billing premium request usage report for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `year` (integer, optional): If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
- `month` (integer, optional): If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used.
- `day` (integer, optional): If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
- `model` (string, optional): The model name to query usage for. The name is not case sensitive.
- `product` (string, optional): The product name to query usage for. The name is not case sensitive.
### billing_get_github_billing_usage_report_user

GET /users/{username}/settings/billing/usage - Get billing usage report for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `year` (integer, optional): If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
- `month` (integer, optional): If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. If no year is specified the default `year` is used.
- `day` (integer, optional): If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
### get_users_by_username_settings_billing_usage_summary

GET /users/{username}/settings/billing/usage/summary - Get billing usage summary for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `year` (integer, optional): If specified, only return results for a single year. The value of `year` is an integer with four digits representing a year. For example, `2025`. Default value is the current year.
- `month` (integer, optional): If specified, only return results for a single month. The value of `month` is an integer between `1` and `12`. Default value is the current month. If no year is specified the default `year` is used.
- `day` (integer, optional): If specified, only return results for a single day. The value of `day` is an integer between `1` and `31`. If no `year` or `month` is specified, the default `year` and `month` are used.
- `repository` (string, optional): The repository name to query for usage in the format owner/repository.
- `product` (string, optional): The product name to query usage for. The name is not case sensitive.
- `sku` (string, optional): The SKU to query for usage.
### users_list_social_accounts_for_user

GET /users/{username}/social_accounts - List social accounts for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### users_list_ssh_signing_keys_for_user

GET /users/{username}/ssh_signing_keys - List SSH signing keys for a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_list_repos_starred_by_user

GET /users/{username}/starred - List repositories starred by a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `sort` (string, optional): The property to sort the results by. `created` means when the repository was starred. `updated` means when the repository was last pushed to. (default: created) — one of: created, updated
- `direction` (string, optional): The direction to sort the results by. (default: desc) — one of: asc, desc
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### activity_list_repos_watched_by_user

GET /users/{username}/subscriptions - List repositories watched by a user

Parameters:
- `username` (string): The handle for the GitHub user account.
- `per_page` (integer, optional): The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 30)
- `page` (integer, optional): The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." (default: 1)
### meta_get_all_versions

GET /versions - Get all API versions

### meta_get_zen

GET /zen - Get the Zen of GitHub


## Available Resources

- `app://github/status` — Current status and version of github
- `app://github/commands` — Available commands and tools in github
- `app://github/config` — Current configuration of github
- `docs://github/tool-index` — Complete index of all github tools with parameters and usage
- `docs://github/api` — Documentation for github api capabilities

## Available Prompts

- `use_github` — Guide for using github tools effectively
- `debug_github` — Diagnose issues with github operations

## Usage

This server runs over stdio. Add it to your MCP client config:

```json
{
  "mcpServers": {
    "github": {
      "command": "mcp-github"
    }
  }
}
```
