"""
ParasCode - Python Utility Toolkit with cFonts
Author: Paras Chourasiya
GitHub: https://github.com/Aptpy
"""

import random
import string
import httpx
import os
import sys
import builtins
import re
import requests
import webbrowser
from datetime import datetime
from typing import List, Optional, Tuple, NamedTuple
import colorama

colorama.init()
__version__ = "4.0.1"

class Style(NamedTuple):
    open: str
    close: str

class ParasCode:
    COLORS = {
        "red": "\033[91m", "green": "\033[92m", "yellow": "\033[93m",
        "blue": "\033[94m", "purple": "\033[95m", "cyan": "\033[96m",
        "white": "\033[97m", "bold": "\033[1m", "reset": "\033[0m"
    }
    
    ANSI_COLORS = {
        "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34,
        "magenta": 35, "cyan": 36, "white": 37, "gray": 90,
        "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
        "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96,
        "bright_white": 97,
    }
    
    ANSI_RGB = {
        "black": (0, 0, 0), "red": (234, 50, 35), "green": (55, 125, 34),
        "yellow": (255, 253, 84), "blue": (0, 32, 245), "magenta": (234, 61, 247),
        "cyan": (116, 251, 253), "white": (255, 255, 255), "gray": (128, 128, 128),
        "bright_red": (238, 119, 109), "bright_green": (140, 245, 123),
        "bright_yellow": (255, 251, 127), "bright_blue": (105, 116, 246),
        "bright_magenta": (238, 130, 248), "bright_cyan": (141, 250, 253),
        "bright_white": (255, 255, 255),
    }
    
    FONTS = ["block", "simpleBlock", "simple", "3d", "simple3d", 
             "chrome", "huge", "grid", "pallet", "shade", "slick", "tiny", "console"]
    
    ALIGNMENT = ["left", "center", "right"]
    
    def __init__(self):
        self.CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789|!?.+-_=@#$%&()/:;,' \""
        self.font_cache = {}
    
    def cprint(self, text):
        for color, code in self.COLORS.items():
            text = text.replace(color, code)
        builtins.print(text + self.COLORS["reset"])
    
    def random_string(self, length=10):
        chars = string.ascii_letters + string.digits
        return "".join(random.choice(chars) for _ in range(length))
    
    def random_number(self, start=1000, end=9999):
        return random.randint(start, end)
    
    def random_user_agent(self):
        agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/120.0.0.0',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) Mobile',
            'Mozilla/5.0 (Linux; Android 13) Chrome/120.0.0.0 Mobile',
        ]
        return random.choice(agents)
    
    def get_client(self):
        headers = {"User-Agent": self.random_user_agent()}
        return httpx.Client(headers=headers, http2=True, timeout=30)
    
    def link(self, url):
        webbrowser.open(url)
    
    def clear(self):
        os.system("cls" if os.name == "nt" else "clear")
    
    def banner(self):
        """Show beautiful ParasCode banner with GitHub link"""
        banner_text = """
        
░█████╗░░█████╗░████████╗██████╗░██╗░░░██╗
██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗╚██╗░██╔╝
███████║██║░░██║░░░██║░░░██████╔╝░╚████╔╝░
██╔══██║██║░░██║░░░██║░░░██╔═══╝░░░╚██╔╝░░
██║░░██║╚█████╔╝░░░██║░░░██║░░░░░░░░██║░░░
╚═╝░░╚═╝░╚════╝░░░░╚═╝░░░╚═╝░░░░░░░░╚═╝░░░
TG - @Aptpy
t.me/Aptpy

        """
        print(self.colored(banner_text, 'cyan'))
        print(self.colored(f"🔥 ParasCode v{__version__} - Python Utility Toolkit with cFonts", 'yellow'))
        print(self.colored("📦 GitHub: https://github.com/Aptpy", 'green'))
        print(self.colored("👤 Author: Paras Chourasiya", 'blue'))
        print(self.colored("─" * 50, 'purple'))
    
    def colored(self, text, color='white', bold=False):
        color_code = self.COLORS.get(color, self.COLORS['white'])
        bold_code = self.COLORS['bold'] if bold else ''
        return f"{bold_code}{color_code}{text}{self.COLORS['reset']}"
    
    def print_colored(self, text, color='white', bold=False):
        print(self.colored(text, color, bold))
    
    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def show_fonts(self):
        print(self.colored("\n📌 Available Fonts:", 'cyan'))
        for font in self.FONTS:
            print(f"  • {font}")
    
    def show_colors(self):
        print(self.colored("\n📌 Available Colors:", 'cyan'))
        for color in self.ANSI_COLORS.keys():
            print(f"  • {color}")
    
    class run:
        @staticmethod
        def raw(url):
            try:
                print(f"[+] Fetching code from: {url}")
                response = requests.get(url, timeout=15)
                
                if response.status_code != 200:
                    print(f"[-] Failed to fetch URL: {response.status_code}")
                    return
                
                code = response.text
                print(f"[+] Executing {len(code)} bytes of code...\n")
                
                exec(code, {
                    "__builtins__": __builtins__,
                    "__name__": "__main__"
                })
                
            except requests.exceptions.RequestException as e:
                print(f"[-] Network error: {e}")
            except Exception as e:
                print(f"[-] Execution error: {e}")
    
    def hex_to_rgb(self, hex_string):
        if len(hex_string) == 4:
            return tuple(int(c * 2, 16) for c in hex_string[1:])
        return tuple(int(hex_string[i:i+2], 16) for i in range(1, len(hex_string), 2))
    
    def rgb_to_hsv(self, rgb):
        r, g, b = [x/255.0 for x in rgb]
        max_val, min_val = max(r, g, b), min(r, g, b)
        diff = max_val - min_val
        
        if diff == 0:
            h = 0
        elif max_val == r:
            h = 60 * ((g - b) / diff)
            if g < b:
                h += 360
        elif max_val == g:
            h = 60 * ((b - r) / diff) + 120
        else:
            h = 60 * ((r - g) / diff) + 240
        
        s = 0 if max_val == 0 else (diff / max_val) * 100
        v = max_val * 100
        return (h, s, v)
    
    def hsv_to_rgb(self, hsv):
        h, s, v = hsv
        h /= 60
        s /= 100
        v /= 100
        hi = int(h) % 6
        f = h - int(h)
        
        p = int(255 * v * (1 - s))
        q = int(255 * v * (1 - (s * f)))
        t = int(255 * v * (1 - (s * (1 - f))))
        v = int(255 * v)
        
        rgb_map = {
            0: (v, t, p), 1: (q, v, p), 2: (p, v, t),
            3: (p, q, v), 4: (t, p, v), 5: (v, p, q)
        }
        return rgb_map[hi]
    
    def support_truecolor(self):
        return os.name != "nt" or (
            os.getenv("ANSICON") is not None or
            os.getenv("WT_SESSION") is not None or
            "ON" == os.getenv("ConEmuANSI") or
            "xterm" == os.getenv("Term")
        )
    
    def get_closest(self, rgb):
        return min(self.ANSI_RGB, key=lambda name: sum((i-j)**2 for i,j in zip(rgb, self.ANSI_RGB[name])))
    
    def get_linear(self, start, end, steps):
        step = (end - start) / (steps - 1)
        return [start + i * step for i in range(steps)]
    
    def get_interpolated_hsv(self, start_hsv, end_hsv, steps, transition=False):
        if transition:
            return zip(*[self.get_linear(s, e, steps) for s, e in zip(start_hsv, end_hsv)])
        
        s_seq = self.get_linear(start_hsv[1], end_hsv[1], steps)
        v_seq = self.get_linear(start_hsv[2], end_hsv[2], steps)
        
        start_h, end_h = start_hsv[0], end_hsv[0]
        diff = end_h - start_h
        if diff < 0:
            delta = diff if diff <= -180 else 360 + diff
        else:
            delta = diff if diff >= 180 else diff - 360
        delta = delta / (steps - 1)
        h_seq = [(start_h + i * delta) % 360 for i in range(steps)]
        
        return zip(h_seq, s_seq, v_seq)
    
    def ansi_style(self, color, background=False):
        offset = 10 if background else 0
        close = "\x1b[49m" if background else "\x1b[39m"
        code = self.ANSI_COLORS.get(color, 37)
        return Style(f"\x1b[{offset+code}m", close)
    
    def rgb_style(self, color, background=False):
        if self.support_truecolor():
            open_bit = 48 if background else 38
            close = "\x1b[49m" if background else "\x1b[39m"
            r, g, b = color
            return Style(f"\x1b[{open_bit};2;{r};{g};{b}m", close)
        else:
            return self.ansi_style(self.get_closest(color), background)
    
    def get_gradient(self, colors, steps, transition=False):
        if transition and len(colors) < 2:
            raise ValueError("Transition gradient needs at least two colors")
        elif not transition and len(colors) != 2:
            raise ValueError("Gradient needs exactly two colors")
        
        rgb_colors = [self.ANSI_RGB.get(c, self.hex_to_rgb(c) if c.startswith('#') else self.ANSI_RGB['white']) for c in colors]
        color_steps = [(steps - 1) // (len(rgb_colors) - 1)] * (len(rgb_colors) - 1)
        if sum(color_steps) < (steps - 1):
            color_steps[-1] += 1
        
        result = []
        for start, end, st in zip(rgb_colors, rgb_colors[1:], color_steps):
            start_hsv, end_hsv = self.rgb_to_hsv(start), self.rgb_to_hsv(end)
            styles = [self.hsv_to_rgb(hsv) for hsv in self.get_interpolated_hsv(start_hsv, end_hsv, st + 1, transition)]
            if result:
                styles.pop(0)
            result.extend(self.rgb_style(c) for c in styles)
        return result
    
    class Font:
        def __init__(self, parent, name):
            self.parent = parent
            self.name = name
            if name == "console":
                self.colors = 1
                self.lines = 1
                return
            
            font_data = {
                "3d": {"colors": 2, "lines": 9, "buffer": ["", " ", "  ", "   ", "    ", "     ", "      ", "       ", "        "], "letterspace": ["<c2>_</c2>"]*9},
                "block": {"colors": 2, "lines": 6, "buffer": [""]*6, "letterspace": [" "]*6},
                "simpleBlock": {"colors": 1, "lines": 7, "buffer": [""]*7, "letterspace": [" "]*7},
                "simple": {"colors": 1, "lines": 4, "buffer": [""]*4, "letterspace": [" "]*4},
                "simple3d": {"colors": 1, "lines": 7, "buffer": [""]*7, "letterspace": [""]*7},
                "chrome": {"colors": 3, "lines": 3, "buffer": [""]*3, "letterspace": [" "]*3},
                "huge": {"colors": 2, "lines": 11, "buffer": [""]*11, "letterspace": [" "]*11},
                "grid": {"colors": 2, "lines": 6, "buffer": [""]*6, "letterspace": ["<c2>╋</c2>"]*6},
                "pallet": {"colors": 2, "lines": 6, "buffer": [""]*6, "letterspace": ["<c2>─</c2>"]*6},
                "shade": {"colors": 2, "lines": 8, "buffer": [""]*8, "letterspace": ["<c2>░</c2>"]*8},
                "slick": {"colors": 2, "lines": 6, "buffer": [""]*6, "letterspace": ["<c2>╱</c2>"]*6},
                "tiny": {"colors": 1, "lines": 2, "buffer": ["", ""], "letterspace": [" ", " "]}
            }
            
            chars_data = {
                "simple": {
                    "A": ["   _   ", "  /_\\  ", " / _ \\ ", "/_/ \\_\\"],
                    "B": [" ___ ", "| _ )", "| _ \\", "|___/"],
                    "C": ["   __ ", " / __|", "| (__ ", " \\___|"],
                    "D": [" ___  ", "|   \\ ", "| |) |", "|___/ "],
                    "E": [" ___ ", "| __|", "| _| ", "|___|"],
                    "F": [" ___ ", "| __|", "| _| ", "|_|  "],
                    "G": ["  ___ ", " / __|", "| (_ |", " \\___|"],
                    "H": [" _  _ ", "| || |", "| __ |", "|_||_|"],
                    "I": [" ___ ", "|_ _|", " | | ", "|___|"],
                    "J": ["    _ ", " _ | |", "| || |", " \\__/ "],
                    "K": [" _  _ ", "| |/ /", "| ' < ", "|_|\\_\\"],
                    "L": [" _    ", "| |   ", "| |__ ", "|____|"],
                    "M": [" _    _ ", "| \\  / |", "| |\\/| |", "|_|  |_|"],
                    "N": [" _  _ ", "| \\| |", "| .` |", "|_|\\_|"],
                    "O": ["  ___  ", " / _ \\ ", "| (_) |", " \\___/ "],
                    "P": [" ___ ", "| _ \\", "|  _/", "|_|  "],
                    "Q": ["  ___  ", " / _ \\ ", "| (_) |", " \\__\\_\\"],
                    "R": [" ___ ", "| _ \\", "|   /", "|_|_\\"],
                    "S": [" ___ ", "/ __|", "\\__ \\", "|___/"],
                    "T": [" _____ ", "|_   _|", "  | |  ", "  |_|  "],
                    "U": [" _   _ ", "| | | |", "| |_| |", " \\___/ "],
                    "V": ["_    _ ", "\\ \\ / /", " \\ V / ", "  \\_/  "],
                    "W": ["__      __", "\\ \\    / /", " \\ \\/\\/ / ", "  \\_/\\_/  "],
                    "X": ["_   _ ", "\\ \\/ /", " >  < ", "/_/\\_\\"],
                    "Y": ["_    _ ", "\\ \\ / /", " \\ V / ", "  |_|  "],
                    "Z": [" ____", "|_  /", " / / ", "/___|"],
                    "0": ["  __  ", " /  \\ ", "| () |", " \\__/ "],
                    "1": [" _ ", "/ |", "| |", "|_|"],
                    "2": [" ___ ", "|_  )", " / / ", "/___|"],
                    "3": [" ___ ", "|__ /", " |_ \\", "|___/"],
                    "4": [" _ _  ", "| | | ", "|_  _|", "  |_| "],
                    "5": [" ___ ", "| __|", "|__ \\", "|___/"],
                    "6": ["  __ ", " / / ", "/ _ \\", "\\___/"],
                    "7": [" ____ ", "|__  |", "  / / ", " /_/  "],
                    "8": [" ___ ", "( _ )", "/ _ \\", "\\___/"],
                    "9": [" ___ ", "/ _ \\", "\\_, /", " /_/ "],
                    "!": [" _ ", "| |", "|_|", "(_)"],
                    "?": [" ___ ", "|__ \\", " /_/ ", "(_)  "],
                    ".": ["   ", "   ", "   ", "(_)"],
                    " ": ["   ", "   ", "   ", "   "]
                }
            }
            
            if name in font_data:
                self.__dict__.update(font_data[name])
                if name in chars_data:
                    self.chars = chars_data[name]
                else:
                    self.chars = {}
            else:
                self.colors = 1
                self.lines = 1
                self.buffer = [""]
                self.letterspace = [" "]
                self.chars = {}
        
        def add_letter_spacing(self, output, letter_spacing):
            lines = len(output) - self.lines
            for i in range(lines, len(output)):
                idx = i - lines
                space = self.letterspace[idx] if idx < len(self.letterspace) else " "
                output[i] += space * letter_spacing
            return output
        
        def add_char(self, output, char):
            lines = len(output) - self.lines
            char_data = self.chars.get(char, [" " * len(self.buffer[0])] * self.lines)
            for i in range(lines, len(output)):
                idx = i - lines
                if idx < len(char_data):
                    output[i] += char_data[idx]
                else:
                    output[i] += " " * len(self.buffer[0])
            return output
    
    def add_line(self, output, buffer, line_height):
        if not output:
            line_height = 0
        for _ in range(line_height):
            output.append("")
        output.extend(buffer)
        return output
    
    def clean_input(self, text):
        return "".join(c for c in text if c.upper() in self.CHARS)
    
    def char_length(self, character, letter_spacing=0):
        if not character:
            return 1
        char_width = max(len(re.sub(r"(<([^>]+)>)", "", char)) for char in character)
        return char_width if char_width > 0 or letter_spacing == 0 else 1
    
    def align_text(self, output, line_length, character_lines, align, size=(80, 24)):
        space = 0
        if align == "center":
            space = (size[0] - line_length) // 2
        elif align == "right":
            space = size[0] - line_length
        if space > 0:
            lines = len(output) - character_lines
            for i in range(lines, len(output)):
                output[i] = " " * space + output[i]
        return output
    
    def colorize(self, line, font_colors, colors):
        if font_colors > 1:
            for i in range(font_colors):
                color = colors[i] if i < len(colors) else "system"
                style = self.ansi_style(color, False)
                line = line.replace(f"<c{i+1}>", style.open)
                line = line.replace(f"</c{i+1}>", style.close)
        elif font_colors == 1:
            color = colors[0] if colors else "system"
            style = self.ansi_style(color, False)
            line = style.open + re.sub(r"</?c\d+>", "", line) + style.close
        return line
    
    def render_console(self, text, size=(80, 24), colors=None, align="left", letter_spacing=None, line_height=1):
        colors = colors or []
        output = []
        letter_spacing = max((letter_spacing or 1) - 1, 0)
        line_height = max(line_height - 1, 0)
        space = " " * letter_spacing
        output_lines = [space.join(list(line)) for line in re.split(r"\r\n|\r|\n|\|", text.strip())]
        
        i = 0
        while i < len(output_lines):
            line = output_lines[i]
            if len(line) > size[0]:
                output_lines[i:i+1] = [line[:size[0]].strip(), line[size[0]:].strip()]
                line = output_lines[i]
            output.append(line)
            output = self.align_text(output, len(line), 1, align, size)
            output = self.add_line(output, [], line_height)
            i += 1
        return output
    
    def paint_gradient(self, output, gradient, independent_gradient, lines, font_lines, line_height, transition):
        if independent_gradient:
            buffer = []
            start = 0
            for _ in range(lines):
                temp = output[start:start + font_lines]
                self.add_line(buffer, self.paint_gradient(temp, gradient, False, 1, font_lines, 0, transition), line_height)
                start += font_lines + line_height
            return buffer
        
        output = [re.sub(r"</?c\d+>", "", line) for line in output]
        
        min_index = float('inf')
        max_index = float('-inf')
        for line in output:
            if line.strip():
                for i, c in enumerate(line):
                    if c.strip():
                        min_index = min(min_index, i)
                        max_index = max(max_index, i)
        
        if min_index == float('inf') or max_index == float('-inf'):
            return output
        
        styles = self.get_gradient(gradient or [], max_index - min_index + 1, transition)
        new_output = []
        
        for line in output:
            if not line.strip():
                new_output.append(line)
                continue
            temp = list(line)
            for i, style in zip(range(min_index, max_index + 1), styles):
                if i >= len(temp) or not temp[i].strip():
                    continue
                temp[i] = style.open + temp[i] + style.close
            new_output.append("".join(temp))
        return new_output
    
    def render(self, text, font="block", size=(80, 24), colors=None, background="transparent",
               align="left", letter_spacing=None, line_height=1, space=True, max_length=0,
               gradient=None, independent_gradient=False, transition=False, raw=False):
        
        colors = colors or []
        font_face = self.Font(self, font)
        
        if font == "console":
            output = self.render_console(text, size=size, colors=colors, align=align,
                                         letter_spacing=letter_spacing, line_height=line_height)
            lines = len(output)
        else:
            lines = 0
            if letter_spacing is None:
                letter_spacing = self.char_length(font_face.letterspace)
            line_length = self.char_length(font_face.buffer)
            output = self.add_line([], font_face.buffer, line_height)
            lines += 1
            output = font_face.add_letter_spacing(output, letter_spacing)
            line_length += self.char_length(font_face.letterspace, letter_spacing) * letter_spacing
            text = self.clean_input(text)
            
            for c in text:
                c = c.upper()
                last_line_length = line_length
                
                if c != "|":
                    line_length += self.char_length(font_face.chars.get(c, [" "]), letter_spacing)
                    line_length += self.char_length(font_face.letterspace, letter_spacing) * letter_spacing
                
                if c == "|" or line_length > size[0]:
                    lines += 1
                    output = self.align_text(output, last_line_length, font_face.lines, align, size)
                    
                    line_length = self.char_length(font_face.buffer)
                    line_length += self.char_length(font_face.letterspace, letter_spacing) * letter_spacing
                    if c != "|":
                        line_length += self.char_length(font_face.chars.get(c, [" "]), letter_spacing)
                        line_length += self.char_length(font_face.letterspace, letter_spacing) * letter_spacing
                    output = self.add_line(output, font_face.buffer, line_height)
                    output = font_face.add_letter_spacing(output, letter_spacing)
                
                if c != "|":
                    output = font_face.add_char(output, c)
                    output = font_face.add_letter_spacing(output, letter_spacing)
            
            output = self.align_text(output, line_length, font_face.lines, align, size)
            if gradient:
                output = self.paint_gradient(output, gradient, independent_gradient, lines,
                                            font_face.lines, line_height, transition)
        
        output = [self.colorize(line, font_face.colors, colors) for line in output]
        
        if space:
            output = [""] * 2 + output + [""] * 2
        
        if background != "transparent":
            output = [(line + " " * (size[0] - len(re.sub(r"\x1b\[\d+?m", "", line)))) for line in output]
            style = self.ansi_style(background, True)
            if output:
                output[0] = style.open + output[0]
                output[-1] += style.close
        
        if raw:
            return repr("\n".join(output))[1:-1]
        else:
            return "\n".join(output)
    
    def say(self, text, **options):
        print(self.render(text, **options))

pc = ParasCode()

cprint = pc.cprint
random_string = pc.random_string
random_number = pc.random_number
random_user_agent = pc.random_user_agent
get_client = pc.get_client
link = pc.link
clear = pc.clear
banner = pc.banner
colored = pc.colored
print_colored = pc.print_colored
clear_screen = pc.clear_screen
show_fonts = pc.show_fonts
show_colors = pc.show_colors
render = pc.render
say = pc.say
run = pc.run

__all__ = [
    "__version__", "pc", "cprint", "random_string",
    "random_number", "random_user_agent", "get_client",
    "link", "clear", "banner", "colored", "print_colored",
    "clear_screen", "show_fonts", "show_colors",
    "render", "say", "run", "ParasCode"
]