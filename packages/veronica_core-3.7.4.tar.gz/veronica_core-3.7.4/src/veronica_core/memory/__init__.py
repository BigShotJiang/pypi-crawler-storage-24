"""Memory Governance ABI for VERONICA Core.

Exports the complete public surface for memory governance:
- Type vocabulary (MemoryAction, MemoryProvenance, GovernanceVerdict)
- Operation and context dataclasses
- Hook protocol and built-in implementations
- MemoryGovernor orchestrator
"""

from __future__ import annotations

from veronica_core.memory.governor import MemoryGovernor
from veronica_core.memory.hooks import (
    DefaultMemoryGovernanceHook,
    DenyAllMemoryGovernanceHook,
    MemoryGovernanceHook,
)
from veronica_core.memory.message_governance import (
    DefaultMessageGovernanceHook,
    DenyOversizedMessageHook,
    MessageBridgeHook,
    MessageGovernanceHook,
)
from veronica_core.memory.types import (
    BridgePolicy,
    CompactnessConstraints,
    DegradeDirective,
    ExecutionMode,
    GovernanceVerdict,
    MemoryAction,
    MemoryGovernanceDecision,
    MemoryOperation,
    MemoryPolicyContext,
    MemoryProvenance,
    MemoryView,
    MessageContext,
    ThreatContext,
    scoped_execution_mode,
)
from veronica_core.memory.lifecycle import (
    ProvenanceLifecycle,
    TransitionResult,
)

__all__ = [
    "MemoryAction",
    "MemoryProvenance",
    "MemoryOperation",
    "MemoryPolicyContext",
    "GovernanceVerdict",
    "MemoryGovernanceDecision",
    "MemoryGovernanceHook",
    "DefaultMemoryGovernanceHook",
    "DenyAllMemoryGovernanceHook",
    "MemoryGovernor",
    # v3.6.0
    "MemoryView",
    "ExecutionMode",
    "DegradeDirective",
    "CompactnessConstraints",
    "MessageContext",
    "BridgePolicy",
    "ThreatContext",
    # v3.7.0: lifecycle
    "ProvenanceLifecycle",
    "TransitionResult",
    # v3.7.0: message governance
    "MessageGovernanceHook",
    "DefaultMessageGovernanceHook",
    "DenyOversizedMessageHook",
    "MessageBridgeHook",
    "scoped_execution_mode",
]
