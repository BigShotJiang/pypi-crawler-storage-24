
:orphan:

.. _sphx_glr_sg_execution_times:


Computation times
=================
**00:31.903** total execution time for 4 files **from all galleries**:

.. container::

  .. raw:: html

    <style scoped>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
    </style>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script type="text/javascript" class="init">
    $(document).ready( function () {
        $('table.sg-datatable').DataTable({order: [[1, 'desc']]});
    } );
    </script>

  .. list-table::
   :header-rows: 1
   :class: table table-striped sg-datatable

   * - Example
     - Time
     - Mem (MB)
   * - :ref:`sphx_glr__gallery_optimize_parameters.py` (``../../gallery/optimize_parameters.py``)
     - 00:14.539
     - 0.0
   * - :ref:`sphx_glr__gallery_optical_flow.py` (``../../gallery/optical_flow.py``)
     - 00:09.346
     - 0.0
   * - :ref:`sphx_glr__gallery_distorting_image.py` (``../../gallery/distorting_image.py``)
     - 00:07.400
     - 0.0
   * - :ref:`sphx_glr__gallery_project_points.py` (``../../gallery/project_points.py``)
     - 00:00.617
     - 0.0
