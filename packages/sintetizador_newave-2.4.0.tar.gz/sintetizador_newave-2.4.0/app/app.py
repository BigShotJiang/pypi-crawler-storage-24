import os
import time
from multiprocessing import Manager
from typing import Any, Tuple

import click

import app.domain.commands as commands
import app.services.handlers as handlers
from app.services.unitofwork import factory
from app.utils.log import Log


@click.group()
def app() -> None:
    """
    Aplicação para realizar a síntese de informações em
    um modelo unificado de dados para o NEWAVE.
    """
    pass


@click.command("sistema")
@click.argument(
    "variaveis",
    nargs=-1,
)
@click.option(
    "--formato", default="PARQUET", help="formato para escrita da síntese"
)
def sistema(variaveis: Tuple[str, ...], formato: str) -> None:
    """
    Realiza a síntese dos dados do sistema do NEWAVE.
    """
    os.environ["FORMATO_SINTESE"] = formato

    m = Manager()
    q: Any = m.Queue(-1)
    Log.start_logging_process(q)

    logger = Log.configure_main_logger(q)
    logger.info("# Realizando síntese do SISTEMA #")

    uow = factory("FS", os.curdir, q)
    command = commands.SynthetizeSystem(list(variaveis))
    handlers.synthetize_system(command, uow)

    logger.info("# Fim da síntese #")
    time.sleep(1.0)
    Log.terminate_logging_process()


@click.command("execucao")
@click.argument(
    "variaveis",
    nargs=-1,
)
@click.option(
    "--formato", default="PARQUET", help="formato para escrita da síntese"
)
def execucao(variaveis: Tuple[str, ...], formato: str) -> None:
    """
    Realiza a síntese dos dados da execução do NEWAVE.
    """

    m = Manager()
    q: Any = m.Queue(-1)
    Log.start_logging_process(q)

    logger = Log.configure_main_logger(q)

    os.environ["FORMATO_SINTESE"] = formato
    logger.info("# Realizando síntese da EXECUÇÃO #")

    uow = factory("FS", os.curdir, q)
    command = commands.SynthetizeExecution(list(variaveis))
    handlers.synthetize_execution(command, uow)

    logger.info("# Fim da síntese #")
    time.sleep(1.0)
    Log.terminate_logging_process()


@click.command("cenarios")
@click.argument(
    "variaveis",
    nargs=-1,
)
@click.option(
    "--formato", default="PARQUET", help="formato para escrita da síntese"
)
@click.option(
    "--processadores",
    default=1,
    help="numero de processadores para paralelizar",
)
def cenarios(
    variaveis: Tuple[str, ...], formato: str, processadores: int
) -> None:
    """
    Realiza a síntese dos dados de cenários do NEWAVE.
    """

    m = Manager()
    q: Any = m.Queue(-1)
    Log.start_logging_process(q)

    logger = Log.configure_main_logger(q)

    os.environ["FORMATO_SINTESE"] = formato
    os.environ["PROCESSADORES"] = str(processadores)
    logger.info("# Realizando síntese de CENÁRIOS #")

    uow = factory("FS", os.curdir, q)
    command = commands.SynthetizeScenarios(list(variaveis))
    handlers.synthetize_scenarios(command, uow)

    logger.info("# Fim da síntese #")
    time.sleep(1.0)
    Log.terminate_logging_process()


@click.command("operacao")
@click.argument(
    "variaveis",
    nargs=-1,
)
@click.option(
    "--formato", default="PARQUET", help="formato para escrita da síntese"
)
@click.option(
    "--processadores",
    default=1,
    help="numero de processadores para paralelizar",
)
def operacao(
    variaveis: Tuple[str, ...], formato: str, processadores: int
) -> None:
    """
    Realiza a síntese dos dados da operação do NEWAVE (NWLISTOP).
    """

    m = Manager()
    q: Any = m.Queue(-1)
    Log.start_logging_process(q)

    logger = Log.configure_main_logger(q)

    os.environ["FORMATO_SINTESE"] = formato
    os.environ["PROCESSADORES"] = str(processadores)
    logger.info("# Realizando síntese da OPERACAO #")

    uow = factory("FS", os.curdir, q)
    command = commands.SynthetizeOperation(list(variaveis))
    handlers.synthetize_operation(command, uow)

    logger.info("# Fim da síntese #")
    time.sleep(1.0)
    Log.terminate_logging_process()


@click.command("politica")
@click.argument(
    "variaveis",
    nargs=-1,
)
@click.option(
    "--formato", default="PARQUET", help="formato para escrita da síntese"
)
def politica(variaveis: Tuple[str, ...], formato: str) -> None:
    """
    Realiza a síntese dos dados da política do NEWAVE (NWLISTCF).
    """

    m = Manager()
    q: Any = m.Queue(-1)
    Log.start_logging_process(q)

    logger = Log.configure_main_logger(q)
    os.environ["FORMATO_SINTESE"] = formato
    logger.info("# Realizando síntese da POLITICA #")

    uow = factory("FS", os.curdir, q)
    command = commands.SynthetizePolicy(list(variaveis))
    handlers.synthetize_policy(command, uow)

    logger.info("# Fim da síntese #")
    time.sleep(1.0)
    Log.terminate_logging_process()


@click.command("limpeza")
def limpeza() -> None:
    """
    Realiza a limpeza dos dados resultantes de uma síntese.
    """
    handlers.clean()


@click.command("completa")
@click.option(
    "--sistema", multiple=True, help="variável do sistema para síntese"
)
@click.option(
    "--execucao", multiple=True, help="variável da execução para síntese"
)
@click.option(
    "--operacao", multiple=True, help="variável da operação para síntese"
)
@click.option(
    "--politica", multiple=True, help="variável da política para síntese"
)
@click.option(
    "--formato", default="PARQUET", help="formato para escrita da síntese"
)
@click.option(
    "--processadores",
    default=1,
    help="numero de processadores para paralelizar",
)
def completa(
    sistema: Tuple[str, ...],
    execucao: Tuple[str, ...],
    operacao: Tuple[str, ...],
    politica: Tuple[str, ...],
    formato: str,
    processadores: int,
) -> None:
    """
    Realiza a síntese completa do NEWAVE.
    """

    m = Manager()
    q: Any = m.Queue(-1)
    Log.start_logging_process(q)

    logger = Log.configure_main_logger(q)
    os.environ["FORMATO_SINTESE"] = formato
    os.environ["PROCESSADORES"] = str(processadores)
    logger.info("# Realizando síntese COMPLETA #")

    uow = factory("FS", os.curdir, q)
    cmd_sistema = commands.SynthetizeSystem(list(sistema))
    handlers.synthetize_system(cmd_sistema, uow)
    cmd_execucao = commands.SynthetizeExecution(list(execucao))
    handlers.synthetize_execution(cmd_execucao, uow)
    cmd_operacao = commands.SynthetizeOperation(list(operacao))
    handlers.synthetize_operation(cmd_operacao, uow)
    cmd_politica = commands.SynthetizePolicy(list(politica))
    handlers.synthetize_policy(cmd_politica, uow)

    logger.info("# Fim da síntese #")
    time.sleep(1.0)
    Log.terminate_logging_process()


app.add_command(completa)
app.add_command(sistema)
app.add_command(execucao)
app.add_command(cenarios)
app.add_command(operacao)
app.add_command(politica)
app.add_command(limpeza)
