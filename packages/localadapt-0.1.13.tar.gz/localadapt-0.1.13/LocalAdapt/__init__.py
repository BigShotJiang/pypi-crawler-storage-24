import os
import sys

log = os.getenv("LOCALADAPT_LOG_LVL")

def _ensure_runtime():
    try:
        from . import adapters, test
        return True
    except ImportError:
        return False

if not _ensure_runtime():
    try:
        from . import install
        install.main()

        # Nach Installation nochmal versuchen
        from . import adapters, test

    except Exception as e:
        print("LocalAdapt initialization failed:", e)