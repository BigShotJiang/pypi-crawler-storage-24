class ToolSchema:
    def __init__(self, name, description, parameters):
        self.name = name
        self.description = description
        self.parameters = parameters

class ToolRegistry:
    def __init__(self):
        self.tools = {}

    def register(self, name, func, schema):
        self.tools[name] = {
            "func": func,
            "schema": schema
        }

    def execute(self, name, params):
        if name not in self.tools:
            raise ValueError(f"Tool {name} not found")

        return self.tools[name]["func"](**params)

registry = ToolRegistry()