import ast
import operator as op


_OPS = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.USub: op.neg,
    ast.UAdd: op.pos,
}


def _eval_node(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        return _OPS[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval_node(node.operand))
    raise ValueError("Only numbers and + - * / ( ) are allowed.")


def calculator(expression: str):
    if not isinstance(expression, str) or not expression.strip():
        return "Invalid expression: empty input."
    try:
        tree = ast.parse(expression, mode="eval")
        value = _eval_node(tree.body)
        return str(value)
    except ZeroDivisionError:
        return "Math error: division by zero."
    except Exception as e:
        return f"Invalid expression: {e}"
