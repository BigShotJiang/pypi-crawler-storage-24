from .registry import registry, ToolSchema
from .math_tools import calculator

registry.register("calculator", calculator, ToolSchema("calculator", "Tool for calculating math", {
    "expression": {
        "type": "string",
        "description": "Mathematical expression to evaluate"
    }
}))