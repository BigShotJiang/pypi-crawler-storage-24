try:
    from .adapters import router
except ImportError:
    from LocalAdapt.adapters import router
import os
import time

def main():
    print("Start")

    os.environ["HF_HOME"] = "D:/AnyAI/models"

    model_path = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
    max_length = 200

    request = {
        "type": "llm",
        "max_length": max_length,
        "do_sample": True,
        "temperature": 0.8,
        "stream": True,
        "history": [],
        "model_kwargs": {
            "model_path": model_path
        }
    }
    router.adapters[0].load(router.adapters[0].register_model(**request["model_kwargs"]))
    os.system("cls")
    # Repl-artige Schleife
    history = [{"role": "system", "content": """You are a helpful and concise assistant. 
    Answer the user questions factually and briefly.
    Do not provide examples, do not speculate, do not invent code or explanations unless explicitly asked.
    Stop after giving a direct answer."""}]
    while True:
        prompt = input(">>> ")
        request["prompt"] = prompt
        history.append({"role": "user", "content": prompt})
        request["history"] = history
        result = router.route(request)

        last_len = 0
        while True:
            if len(result.text) > last_len:
                print(result.text[last_len:], end="", flush=True)
                last_len = len(result.text)

            # Check if stream finished
            if getattr(result, "done", False):
                print()  # Neue Zeile am Ende
                break

            time.sleep(0.05)
        history.append({"role": "assistant", "content": result.text})

if __name__ == '__main__':
    main()