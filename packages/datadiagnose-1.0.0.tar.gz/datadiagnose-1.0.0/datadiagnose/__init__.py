"""
datadiagnose
============
Dataset Auto-Diagnosis Python Library.

A lightweight, zero-dependency Python library that analyses
any tabular dataset and tells you exactly what is wrong with it,
how serious each problem is, and how to fix it.

Zero external dependencies — uses only Python's standard library.

Quick Start
-----------
    from datadiagnose import diagnose

    dataset = {
        "age":    [25, 30, None, 22, 900],
        "income": [50000, 60000, None, 48000, 52000],
        "target": [1, 0, 1, 0, 1],
    }

    report = diagnose(dataset, target_col="target")
    print(report)

Public API
----------
    diagnose(dataset, target_col, dataset_name)  → DiagnosisReport
    quick_scan(dataset, target_col)              → prints + returns report
    health_score(dataset, target_col)            → int 0-100
    list_issues(dataset, target_col)             → list of (severity, title)
    get_suggestions(dataset, target_col)         → list of fix strings
    column_summary(dataset, col_name)            → ColumnReport

Author  : Nilotpal Dhar
Version : 1.0.0
License : MIT
GitHub  : https://github.com/nilotpaldhar2004/datadiagnose
"""

# ── Version info ──────────────────────────────────────────────
__version__ = '1.0.0'
__author__  = 'Nilotpal Dhar'
__license__ = 'MIT'
__all__     = [
    'diagnose',
    'quick_scan',
    'health_score',
    'list_issues',
    'get_suggestions',
    'column_summary',
    'DiagnosisReport',
    'Issue',
    'ColumnReport',
]

# ── Public API imports ────────────────────────────────────────
# These are the only names a user ever needs to import.
# All internal helpers stay private inside their modules.

from .core   import (
    diagnose,
    quick_scan,
    health_score,
    list_issues,
    get_suggestions,
    column_summary,
)
from .models import DiagnosisReport, Issue, ColumnReport
