"""
detectors.py
============
All 8 individual detector functions.

Each detector follows the same contract:
    - Receives the raw column data, column name, a ColumnReport
      to write stats into, and the DiagnosisReport to write
      issues and suggestions into.
    - Returns nothing — it mutates the report objects directly.

The detectors are:
    1. detect_missing_values        — None / "" / NaN
    2. detect_outliers              — IQR + Z-score dual method
    3. detect_skewness              — Pearson moment coefficient
    4. detect_class_imbalance       — majority/minority ratio
    5. detect_data_leakage          — name heuristic + correlation
    6. detect_duplicate_rows        — exact row matching
    7. detect_constant_columns      — zero variance
    8. detect_high_cardinality      — too many unique text values

Author  : Nilotpal Dhar
License : MIT
"""

from .models import Issue
from .utils  import (
    is_missing, to_numeric_list, is_categorical, non_null_values,
    mean, median, std, skewness, iqr_bounds, zscore_outliers,
    pearson_correlation, matches_any_keyword,
    LEAKY_KEYWORDS, DATETIME_KEYWORDS, TEXT_KEYWORDS, GEO_KEYWORDS,
)
from collections import Counter


# ──────────────────────────────────────────────────────────────
# 1. MISSING VALUE DETECTOR
# ──────────────────────────────────────────────────────────────

def detect_missing_values(data, col_name, col_report, diagnosis):
    """
    Detect and report missing values in a column.

    A missing value is any of: None, empty string "", or float NaN.

    Severity is determined by the percentage of missing values:
        ≥ 60%  → CRITICAL  (column is mostly empty — drop it)
        ≥ 30%  → HIGH      (needs model-based imputation)
        ≥ 10%  → MEDIUM    (median/mode imputation appropriate)
        > 0%   → LOW       (simple fill is fine)
    """
    total   = len(data)
    missing = sum(1 for v in data if is_missing(v))
    pct     = round(missing / total * 100, 2) if total else 0.0

    col_report.add('missing_count', missing)
    col_report.add('missing_pct',   f'{pct:.1f}%')

    if missing == 0:
        return   # nothing to do

    if pct >= 60:
        severity = 'critical'
        desc     = f'{pct:.1f}% of values are missing — column is mostly empty.'
        fix      = f"Drop column '{col_name}': df.drop(columns=['{col_name}'])"
    elif pct >= 30:
        severity = 'high'
        desc     = f'{pct:.1f}% of values are missing — significant gap.'
        fix      = (f"Use IterativeImputer or KNNImputer from sklearn "
                    f"for column '{col_name}'.")
    elif pct >= 10:
        severity = 'medium'
        desc     = f'{pct:.1f}% of values are missing.'
        fix      = (f"Fill '{col_name}' with median (numeric) "
                    f"or mode (categorical).")
    else:
        severity = 'low'
        desc     = f'{pct:.1f}% of values are missing — small gap, easy to fix.'
        fix      = f"df['{col_name}'].fillna(df['{col_name}'].median())"

    diagnosis.add_issue(Issue(
        title       = f"Missing Values in '{col_name}'",
        description = desc,
        severity    = severity,
        column      = col_name,
        fix         = fix,
    ))
    diagnosis.add_suggestion(fix)


# ──────────────────────────────────────────────────────────────
# 2. OUTLIER DETECTOR
# ──────────────────────────────────────────────────────────────

def detect_outliers(data, col_name, col_report, diagnosis):
    """
    Detect outliers in a numeric column using two methods:

    Method 1 — IQR (Interquartile Range):
        Any value outside [Q1 - 1.5*IQR, Q3 + 1.5*IQR] is an outlier.
        This is Tukey's classic fence method (1977).

    Method 2 — Z-score:
        Any value with |Z| > 3.0 is an outlier.
        Z = (value - mean) / std

    Both results are reported so the user can compare.
    IQR drives the severity because it is more robust to skewed data.

    Only runs on numeric columns with at least 10 non-null values
    (too few values makes outlier detection unreliable).
    """
    nums = to_numeric_list(data)
    if nums is None or len(nums) < 10:
        return

    # IQR method
    lower, upper, q1, q3, iqr = iqr_bounds(nums)
    iqr_out  = [x for x in nums if x < lower or x > upper]
    iqr_pct  = round(len(iqr_out) / len(nums) * 100, 2)

    # Z-score method
    z_out    = zscore_outliers(nums)

    # Write stats to column report
    col_report.add('outliers_iqr',    f'{len(iqr_out)} ({iqr_pct:.1f}%)')
    col_report.add('outliers_zscore', len(z_out))
    col_report.add('iqr_fence',       f'[{lower:.3f}, {upper:.3f}]')
    col_report.add('q1',              f'{q1:.3f}')
    col_report.add('q3',              f'{q3:.3f}')

    if len(iqr_out) == 0:
        return

    if iqr_pct >= 15:
        severity = 'high'
        fix = (f"Apply RobustScaler or np.log1p() to '{col_name}'. "
               f"Or cap with: df['{col_name}'].clip(lower={lower:.1f}, upper={upper:.1f})")
    elif iqr_pct >= 5:
        severity = 'medium'
        fix = (f"Winsorise '{col_name}': "
               f"df['{col_name}'].clip(df['{col_name}'].quantile(0.01), "
               f"df['{col_name}'].quantile(0.99))")
    else:
        severity = 'low'
        fix = f"Investigate {len(iqr_out)} potential outliers in '{col_name}' manually."

    diagnosis.add_issue(Issue(
        title       = f"Outliers Detected in '{col_name}'",
        description = (f"{len(iqr_out)} outliers ({iqr_pct:.1f}%) detected using IQR method. "
                       f"Fence: [{lower:.3f}, {upper:.3f}]. "
                       f"Z-score method found {len(z_out)} outlier(s)."),
        severity    = severity,
        column      = col_name,
        fix         = fix,
    ))
    diagnosis.add_suggestion(fix)


# ──────────────────────────────────────────────────────────────
# 3. SKEWNESS DETECTOR
# ──────────────────────────────────────────────────────────────

def detect_skewness(data, col_name, col_report, diagnosis):
    """
    Detect skewed distributions in numeric columns.

    Uses Pearson's moment coefficient of skewness (G1).
    A symmetric distribution has skewness near 0.
    Positive skew = long tail to the right (e.g. income).
    Negative skew = long tail to the left.

    Why it matters:
        Many ML algorithms (linear models, neural networks) assume
        that features are roughly normally distributed. Heavy skewness
        violates this assumption and hurts model performance.

    Thresholds:
        |skew| < 0.5  → symmetric — no action needed
        |skew| < 1.0  → mildly skewed → sqrt transform
        |skew| < 2.0  → highly skewed → log1p transform
        |skew| ≥ 2.0  → extremely skewed → log1p or Yeo-Johnson
    """
    nums = to_numeric_list(data)
    if nums is None or len(nums) < 10:
        return

    skew     = skewness(nums)
    abs_skew = abs(skew)
    direction = 'right-skewed' if skew > 0 else 'left-skewed'

    col_report.add('skewness', f'{skew:.4f}')

    if abs_skew < 0.5:
        col_report.add('skew_status', 'symmetric ')
        return

    if abs_skew < 1.0:
        severity = 'low'
        label    = 'mildly skewed'
        fix      = f"Consider np.sqrt(df['{col_name}']) for mild right skew."
    elif abs_skew < 2.0:
        severity = 'medium'
        label    = 'highly skewed'
        fix      = f"Apply np.log1p(df['{col_name}']) to reduce skewness."
    else:
        severity = 'high'
        label    = 'extremely skewed'
        fix      = (f"Apply PowerTransformer(method='yeo-johnson') "
                    f"to '{col_name}' (skew={skew:.2f}).")

    col_report.add('skew_status', f'{label} ({direction})')

    diagnosis.add_issue(Issue(
        title       = f"Skewed Distribution in '{col_name}'",
        description = (f"'{col_name}' is {label} (skewness = {skew:.4f}, {direction}). "
                       f"This can hurt linear models and neural networks."),
        severity    = severity,
        column      = col_name,
        fix         = fix,
    ))
    diagnosis.add_suggestion(fix)


# ──────────────────────────────────────────────────────────────
# 4. CLASS IMBALANCE DETECTOR
# ──────────────────────────────────────────────────────────────

def detect_class_imbalance(data, col_name, col_report, diagnosis,
                           is_target=False):
    """
    Detect class imbalance in categorical or binary columns.

    Computes the ratio of the most common class to the least common
    class. A ratio of 10:1 means the majority class appears 10 times
    more often than the minority class.

    This is most important when applied to the TARGET column —
    a severely imbalanced target causes the model to ignore the
    minority class entirely (the model learns to always predict
    the majority class because it gets high accuracy that way).

    Severity thresholds:
        ratio ≥ 10:1 → CRITICAL
        ratio ≥  5:1 → HIGH
        ratio ≥  3:1 → MEDIUM

    Parameters
    ----------
    is_target : bool — set True when checking the target column
                       (gives more specific suggestions)
    """
    nn = non_null_values(data)
    if not nn:
        return

    counts  = Counter(str(v) for v in nn)
    n_class = len(counts)

    # Only check columns with 2-20 classes
    # (1 class = constant column, >20 = probably not categorical)
    if n_class < 2 or n_class > 20:
        return

    most_common_n  = counts.most_common(1)[0][1]
    least_common_n = counts.most_common()[-1][1]
    ratio          = round(most_common_n / max(least_common_n, 1), 2)

    majority_pct   = round(most_common_n  / len(nn) * 100, 1)
    minority_pct   = round(least_common_n / len(nn) * 100, 1)

    col_report.add('n_classes',     n_class)
    col_report.add('majority_pct',  f'{majority_pct:.1f}%')
    col_report.add('minority_pct',  f'{minority_pct:.1f}%')
    col_report.add('imbalance_ratio', f'{ratio:.1f}:1')

    label = 'target column' if is_target else f"column '{col_name}'"

    if ratio >= 10:
        severity = 'critical'
        fix = (f"Use SMOTE: from imblearn.over_sampling import SMOTE  "
               f"OR set class_weight='balanced' in your model.  "
               f"NEVER use accuracy as your metric — use F1 or ROC-AUC.")
    elif ratio >= 5:
        severity = 'high'
        fix = (f"Oversample minority class in '{col_name}' or use "
               f"class_weight='balanced' in LogisticRegression / RandomForest.")
    elif ratio >= 3:
        severity = 'medium'
        fix = (f"Use stratified k-fold CV: StratifiedKFold(n_splits=5). "
               f"Monitor F1-score, not accuracy.")
    else:
        return   # ratio < 3 is acceptable — no issue raised

    diagnosis.add_issue(Issue(
        title       = f"Class Imbalance in '{col_name}'",
        description = (f"In {label}: majority class = {majority_pct:.1f}%, "
                       f"minority class = {minority_pct:.1f}%, "
                       f"ratio = {ratio:.1f}:1."),
        severity    = severity,
        column      = col_name,
        fix         = fix,
    ))
    diagnosis.add_suggestion(fix)


# ──────────────────────────────────────────────────────────────
# 5. DATA LEAKAGE DETECTOR
# ──────────────────────────────────────────────────────────────

def detect_data_leakage(dataset, col_names, target_col, diagnosis):
    """
    Detect potential data leakage across the entire dataset.

    Data leakage occurs when a feature column contains information
    that is derived from or directly related to the target — giving
    the model an unfair advantage during training that won't exist
    in production.

    Two detection strategies:

    1. Name-based heuristic
       Scans column names for keywords like 'result', 'outcome',
       'label', 'prediction'. These strongly suggest the column
       may contain target-derived information.

    2. Correlation-based detection
       For each numeric column (except the target itself), compute
       the Pearson correlation with the target. A correlation above
       0.98 is essentially impossible for a legitimate independent
       feature — it almost certainly indicates leakage.

    Parameters
    ----------
    dataset    : dict          — {col_name: [values]}
    col_names  : list[str]     — all column names
    target_col : str or None   — name of the target column
    diagnosis  : DiagnosisReport
    """
    for col in col_names:
        if col == target_col:
            continue

        # ── Strategy 1: Name heuristic ──────────────────────
        if matches_any_keyword(col, LEAKY_KEYWORDS):
            diagnosis.add_issue(Issue(
                title       = f"Possible Data Leakage (name): '{col}'",
                description = (f"Column '{col}' has a name that suggests it may "
                               f"contain target-derived information. Verify manually."),
                severity    = 'high',
                column      = col,
                fix         = (f"Investigate '{col}'. If it is derived from the target "
                               f"or only available after the event, remove it."),
            ))
            diagnosis.add_suggestion(
                f"Investigate '{col}' — name suggests possible target leakage.")

        # ── Strategy 2: Correlation check ───────────────────
        if target_col and target_col in col_names:
            col_nums    = to_numeric_list(dataset[col])
            target_nums = to_numeric_list(dataset[target_col])

            if col_nums and target_nums:
                # Align lengths (skip rows where either is missing)
                pairs = [
                    (c, t) for c, t in zip(dataset[col], dataset[target_col])
                    if not (is_missing(c) or is_missing(t))
                ]
                if len(pairs) >= 5:
                    xs   = [float(p[0]) for p in pairs]
                    ys   = [float(p[1]) for p in pairs]
                    corr = pearson_correlation(xs, ys)

                    if corr is not None and abs(corr) > 0.98:
                        diagnosis.add_issue(Issue(
                            title       = f"Near-Perfect Correlation: '{col}' ↔ '{target_col}'",
                            description = (f"'{col}' has a Pearson correlation of {corr:.4f} "
                                           f"with the target — almost certainly a leaked feature."),
                            severity    = 'critical',
                            column      = col,
                            fix         = (f"Remove '{col}' immediately. "
                                           f"A legitimate feature should never correlate "
                                           f"this perfectly with the target."),
                        ))
                        diagnosis.add_suggestion(
                            f"Remove '{col}' — correlation {corr:.4f} with target = data leakage!")


# ──────────────────────────────────────────────────────────────
# 6. DUPLICATE ROW DETECTOR
# ──────────────────────────────────────────────────────────────

def detect_duplicate_rows(dataset, col_names, diagnosis):
    """
    Detect exact duplicate rows in the dataset.

    Two rows are duplicates if ALL their values are identical.

    Why duplicates matter:
        The model sees the same record multiple times during training,
        effectively giving it more weight than it deserves. This
        biases the model toward patterns that appear in duplicate rows.

    Detection method:
        Convert each row to a string tuple.
        Put all tuples in a Python set (sets cannot have duplicates).
        Duplicates = total rows - unique rows.

    Parameters
    ----------
    dataset   : dict       — {col_name: [values]}
    col_names : list[str]  — all column names
    diagnosis : DiagnosisReport
    """
    n_rows = len(dataset[col_names[0]])

    # Convert each row to a tuple of string representations
    row_tuples = [
        tuple(str(dataset[col][i]) for col in col_names)
        for i in range(n_rows)
    ]

    n_unique    = len(set(row_tuples))
    n_duplicate = n_rows - n_unique

    if n_duplicate == 0:
        return

    dup_pct  = round(n_duplicate / n_rows * 100, 2)
    severity = 'high' if dup_pct > 5 else 'medium' if dup_pct > 1 else 'low'
    fix      = f"df.drop_duplicates(inplace=True)  # removes {n_duplicate} duplicate rows"

    diagnosis.add_issue(Issue(
        title       = 'Duplicate Rows Detected',
        description = (f"{n_duplicate} duplicate rows found "
                       f"({dup_pct:.1f}% of {n_rows} total rows)."),
        severity    = severity,
        fix         = fix,
    ))
    diagnosis.add_suggestion(fix)


# ──────────────────────────────────────────────────────────────
# 7. CONSTANT COLUMN DETECTOR
# ──────────────────────────────────────────────────────────────

def detect_constant_columns(dataset, col_names, diagnosis):
    """
    Detect columns where every non-null value is identical.

    A constant column carries zero information — every row has
    the same value, so the model cannot learn anything from it.
    It just wastes memory and computation time.

    Common causes:
        - Exporting from a database where a filter column has
          only one value (e.g. country = 'India' for all rows)
        - A data pipeline bug that filled an entire column with
          the same default value
        - A feature that was once variable but became fixed

    Parameters
    ----------
    dataset   : dict       — {col_name: [values]}
    col_names : list[str]  — all column names
    diagnosis : DiagnosisReport
    """
    for col in col_names:
        nn = non_null_values(dataset[col])
        if not nn:
            continue
        unique_vals = set(str(v) for v in nn)
        if len(unique_vals) == 1:
            constant_val = nn[0]
            fix = f"df.drop(columns=['{col}'], inplace=True)  # constant = {constant_val}"
            diagnosis.add_issue(Issue(
                title       = f"Constant Column: '{col}'",
                description = (f"Every non-null value in '{col}' is '{constant_val}'. "
                               f"Zero variance — zero information for the model."),
                severity    = 'medium',
                column      = col,
                fix         = fix,
            ))
            diagnosis.add_suggestion(fix)


# ──────────────────────────────────────────────────────────────
# 8. HIGH CARDINALITY DETECTOR
# ──────────────────────────────────────────────────────────────

def detect_high_cardinality(dataset, col_names, diagnosis,
                             unique_ratio_threshold=0.9):
    """
    Detect text columns where almost every value is unique.

    High cardinality columns (like user IDs, email addresses,
    or full names) are problematic because:

        1. The model cannot generalise from them — if every row
           has a unique value, there is no pattern to learn.
        2. One-hot encoding them creates an explosion of columns
           (one per unique value), causing memory issues.
        3. They can act as a proxy for row identity, which may
           leak ordering information into the model.

    Detection:
        If (unique non-null values / total non-null values) ≥ 0.9
        AND the column is not numeric → flag as high cardinality.

    We skip numeric columns because a column like 'price' can
    legitimately have many unique values without being an ID column.

    Parameters
    ----------
    dataset                : dict
    col_names              : list[str]
    diagnosis              : DiagnosisReport
    unique_ratio_threshold : float — default 0.9 (90%)
    """
    for col in col_names:
        data = dataset[col]

        # Only check non-numeric columns
        nums = to_numeric_list(data)
        if nums is not None:
            continue   # numeric column — skip

        nn      = non_null_values(data)
        if len(nn) < 10:
            continue   # too few values to judge

        unique        = set(str(v) for v in nn)
        unique_ratio  = len(unique) / len(nn)

        if unique_ratio >= unique_ratio_threshold:
            fix = (f"Drop '{col}' if it is an ID column, or apply "
                   f"TargetEncoder / frequency encoding instead of one-hot encoding.")
            diagnosis.add_issue(Issue(
                title       = f"High Cardinality Column: '{col}'",
                description = (f"'{col}' has {len(unique)} unique values out of "
                               f"{len(nn)} non-null rows ({unique_ratio*100:.1f}% unique). "
                               f"Likely an ID or free-text column."),
                severity    = 'medium',
                column      = col,
                fix         = fix,
            ))
            diagnosis.add_suggestion(fix)


# ──────────────────────────────────────────────────────────────
# FEATURE ENGINEERING HINTS
# ──────────────────────────────────────────────────────────────

def suggest_feature_engineering(col_names, diagnosis):
    """
    Scan column names for patterns that suggest feature engineering
    opportunities. This does not detect problems — it proactively
    suggests ways to extract more information from existing columns.

    Three patterns detected:
        DateTime columns  → extract year, month, day, weekday, hour
        Text columns      → apply TF-IDF, word count, sentiment score
        Geo columns       → compute distance, cluster regions

    Parameters
    ----------
    col_names : list[str]  — all column names
    diagnosis : DiagnosisReport
    """
    for col in col_names:
        if matches_any_keyword(col, DATETIME_KEYWORDS):
            diagnosis.add_suggestion(
                f"Feature Eng: Extract year/month/day/weekday/hour from "
                f"datetime column '{col}' using pd.to_datetime()."
            )
        elif matches_any_keyword(col, TEXT_KEYWORDS):
            diagnosis.add_suggestion(
                f"Feature Eng: Apply TF-IDF, word count, or sentiment "
                f"analysis to free-text column '{col}'."
            )
        elif matches_any_keyword(col, GEO_KEYWORDS):
            diagnosis.add_suggestion(
                f"Feature Eng: Compute distance to reference point or "
                f"cluster regions from geographic column '{col}'."
            )


# ──────────────────────────────────────────────────────────────
# MODEL RECOMMENDATION ENGINE
# ──────────────────────────────────────────────────────────────

def suggest_models(dataset, col_names, target_col, diagnosis):
    """
    Recommend appropriate ML model types based on dataset characteristics.

    Decision logic:
        No target column   → unsupervised learning
        Numeric target with many unique values → regression
        Target with 2 unique values → binary classification
        Target with 3-20 unique values → multiclass classification

    Also adds size-based suggestions:
        < 500 rows  → use simple models + cross-validation
        < 5000 rows → Random Forest / Gradient Boosting
        ≥ 5000 rows → LightGBM / Neural Networks are justified

    Parameters
    ----------
    dataset    : dict
    col_names  : list[str]
    target_col : str or None
    diagnosis  : DiagnosisReport
    """
    n_rows = len(dataset[col_names[0]])
    n_cols = len(col_names)

    # ── No target → unsupervised ─────────────────────────────
    if not target_col or target_col not in col_names:
        diagnosis.model_types.append('K-Means Clustering (sklearn.cluster.KMeans)')
        diagnosis.model_types.append('DBSCAN — density-based clustering')
        diagnosis.model_types.append('PCA — dimensionality reduction')
        return

    # ── Determine task type ──────────────────────────────────
    target_data   = dataset[target_col]
    target_nn     = non_null_values(target_data)
    target_unique = set(str(v) for v in target_nn)
    target_nums   = to_numeric_list(target_data)
    n_unique      = len(target_unique)

    if target_nums and n_unique > 20:
        task = 'regression'
    elif n_unique == 2:
        task = 'binary_classification'
    elif 2 < n_unique <= 20:
        task = 'multiclass_classification'
    else:
        task = 'unknown'

    # ── Model recommendations ────────────────────────────────
    if task == 'regression':
        diagnosis.model_types += [
            'LinearRegression — start simple, establish baseline',
            'Ridge / Lasso — with L2/L1 regularisation',
            'RandomForestRegressor — robust, handles non-linearity',
            'GradientBoostingRegressor / XGBoost / LightGBM — best performance',
        ]
    elif task == 'binary_classification':
        diagnosis.model_types += [
            'LogisticRegression — always start here, fast and interpretable',
            'RandomForestClassifier — strong general-purpose model',
            'XGBoostClassifier / LGBMClassifier — state-of-the-art performance',
            'SVC — strong for small/medium datasets',
        ]
    elif task == 'multiclass_classification':
        diagnosis.model_types += [
            'LogisticRegression(multi_class="ovr") — baseline',
            'RandomForestClassifier — handles multiple classes natively',
            'GradientBoostingClassifier / LightGBM — best performance',
        ]
    else:
        diagnosis.model_types.append(
            'Could not determine task type — check target column values.')

    # ── Size-based advice ────────────────────────────────────
    if n_rows < 500:
        diagnosis.add_suggestion(
            f'Small dataset ({n_rows} rows): use cross-validation '
            f'(StratifiedKFold) and simple models to avoid overfitting.')
    elif n_rows < 5000:
        diagnosis.add_suggestion(
            f'Medium dataset ({n_rows} rows): Random Forest or '
            f'Gradient Boosting will work well here.')
    else:
        diagnosis.add_suggestion(
            f'Large dataset ({n_rows} rows): LightGBM or XGBoost '
            f'will give you the best speed-accuracy trade-off.')

    # ── High dimensionality ──────────────────────────────────
    if n_cols > 50:
        diagnosis.add_suggestion(
            f'High dimensionality ({n_cols} features): run PCA or '
            f'SelectKBest feature selection before training.')
