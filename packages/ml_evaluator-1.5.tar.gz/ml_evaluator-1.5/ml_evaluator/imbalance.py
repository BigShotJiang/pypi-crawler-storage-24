"""
ml_evaluator.imbalance
=======================
Class imbalance detection and visualisation.

    ml_evaluator.is_imbalanced(y)
    ml_evaluator.is_imbalanced(y, threshold=0.20, class_labels=["No","Yes"])
"""

from __future__ import annotations

import warnings
from typing import List, Optional

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

from ._utils import DEFAULT_COLORS, get_colors, _Result, add_panel_label

warnings.filterwarnings("ignore")

__all__ = ["is_imbalanced"]


def is_imbalanced(
    y,
    *,
    threshold:    float          = 0.20,
    class_labels: Optional[List[str]] = None,
    show_interpretation: bool    = True,
    figsize:      tuple          = (10, 4),
    save_path:    Optional[str]  = None,
) -> None:
    """
    Detect and visualise class imbalance in a label array.

    Prints a class distribution table and diagnosis to the terminal,
    then draws a side-by-side bar chart and pie chart.

    A dataset is flagged as imbalanced when the smallest class makes up
    less than `threshold` × 100% of the largest class.

    Parameters
    ----------
    y            : array-like — target labels (y_train or y_test)
    threshold    : minority/majority ratio below which → imbalanced.
                   Default 0.20 (20 %).
    class_labels : display names for each class. Auto-inferred if None.
    show_interpretation : if False, skips the interpretation text. Default True.
    figsize      : figure size. Default (10, 4).
    save_path    : optional path to save the figure.

    Returns
    -------
    None

    Examples
    --------
    >>> ev.is_imbalanced(y_train)
    >>> ev.is_imbalanced(y_train, threshold=0.15,
    ...                  class_labels=["Not Churned", "Churned"])
    """
    y = np.asarray(y)
    classes, counts = np.unique(y, return_counts=True)
    n_total   = len(y)
    n_classes = len(classes)

    if class_labels is None:
        class_labels = [str(c) for c in classes]
    else:
        class_labels = list(class_labels)[:n_classes]

    pcts        = counts / n_total * 100
    ratio       = counts.min() / counts.max()
    imbalanced  = ratio < threshold
    colors      = get_colors(n_classes)

    # ── Terminal output ────────────────────────────────────────────
    status_icon  = "🔴" if imbalanced else "✅"
    status_label = "Imbalanced" if imbalanced else "Balanced"

    print("\n" + "=" * 55)
    print(f"  Class Distribution")
    print("=" * 55)
    print(f"  {'Class':<20} {'Count':>8} {'%':>8}")
    print("  " + "─" * 38)
    for lbl, cnt, pct in zip(class_labels, counts, pcts):
        bar = "█" * int(pct / 2)
        print(f"  {lbl:<20} {cnt:>8,} {pct:>7.1f}%  {bar}")
    print("  " + "─" * 38)
    print(f"  {'Total':<20} {n_total:>8,} {'100.0%':>8}")
    print()
    print(f"  Min / Max ratio : {ratio:.3f}  (threshold: {threshold:.2f})")
    print(f"  {status_icon}  Dataset is {status_label.upper()}")
    print()

    if show_interpretation:
        _print_interpretation(imbalanced, ratio, threshold,
                              class_labels, counts, pcts)

    # ── Figure ─────────────────────────────────────────────────────
    fig = plt.figure(figsize=figsize)
    fig.suptitle(
        f"Class Distribution  —  {status_icon} {status_label}",
        fontsize=13, fontweight="bold",
        color="#C0392B" if imbalanced else "#1A6B3A",
    )

    gs     = gridspec.GridSpec(1, 2, figure=fig, wspace=0.35,
                               left=0.07, right=0.97,
                               top=0.82,  bottom=0.14)
    ax_bar = fig.add_subplot(gs[0, 0])
    ax_pie = fig.add_subplot(gs[0, 1])

    # Bar chart
    bar_colors_display = [
        "#E74C3C" if (imbalanced and cnt == counts.min()) else c
        for cnt, c in zip(counts, colors)
    ]
    bars = ax_bar.bar(class_labels, counts,
                      color=bar_colors_display, alpha=0.85,
                      edgecolor="white", linewidth=1.2)
    for bar, cnt, pct in zip(bars, counts, pcts):
        ax_bar.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + n_total * 0.005,
            f"{cnt:,}\n({pct:.1f}%)",
            ha="center", va="bottom", fontsize=8.5, fontweight="bold",
        )
    ax_bar.set_ylabel("Count", fontsize=9)
    ax_bar.set_title("Class Counts", fontsize=10, fontweight="bold", pad=8)
    ax_bar.set_xticklabels(class_labels, rotation=15 if n_classes > 4 else 0,
                            ha="right" if n_classes > 4 else "center", fontsize=9)
    ax_bar.grid(axis="y", linestyle="--", alpha=0.4)

    if imbalanced:
        ax_bar.axhline(counts.max() * threshold, color="#E74C3C",
                       linestyle="--", lw=1.5, alpha=0.7,
                       label=f"Imbalance threshold ({threshold:.0%})")
        ax_bar.legend(fontsize=7)

    add_panel_label(ax_bar, "A · Count")

    # Pie chart
    wedge_colors = [
        "#E74C3C" if (imbalanced and cnt == counts.min()) else c
        for cnt, c in zip(counts, colors)
    ]
    wedges, texts, autotexts = ax_pie.pie(
        counts,
        labels=class_labels,
        colors=wedge_colors,
        autopct="%1.1f%%",
        startangle=90,
        pctdistance=0.75,
        wedgeprops=dict(edgecolor="white", linewidth=1.5),
    )
    for t in texts:
        t.set_fontsize(8.5)
    for at in autotexts:
        at.set_fontsize(8)
        at.set_fontweight("bold")
        at.set_color("white")

    ax_pie.set_title("Class Proportions", fontsize=10, fontweight="bold", pad=8)
    add_panel_label(ax_pie, "B · Proportion")

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  Saved → {save_path}")
    plt.show()


# ── Internal helpers ──────────────────────────────────────────────

def _print_interpretation(imbalanced, ratio, threshold,
                           class_labels, counts, pcts):
    print("  Interpretation")
    print("  " + "─" * 50)

    if not imbalanced:
        print("  ✅  Classes are balanced.")
        print(f"      Min/Max ratio is {ratio:.2f} — above the {threshold:.0%} threshold.")
        print("      Standard metrics (Accuracy, F1) are reliable.")
    else:
        minority_idx = int(np.argmin(counts))
        majority_idx = int(np.argmax(counts))
        print(f"  🔴  Dataset is imbalanced.")
        print(f"      '{class_labels[minority_idx]}' is the minority class "
              f"({pcts[minority_idx]:.1f}% of data).")
        print(f"      '{class_labels[majority_idx]}' is the majority class "
              f"({pcts[majority_idx]:.1f}% of data).")
        print(f"      Min/Max ratio is {ratio:.2f} — below the {threshold:.0%} threshold.")
        print()
        print("  ⚠️   Accuracy can be misleading on imbalanced data.")
        print("       → Use F1, Precision, Recall, or ROC-AUC instead.")
        print("       → Consider: class_weight='balanced' in your model,")
        print("                   SMOTE or other resampling techniques,")
        print("                   or adjusting the decision threshold.")
    print()
