"""
ml_evaluator._utils
====================
Internal shared helpers — not part of the public API.
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import (
    accuracy_score, roc_auc_score, f1_score,
    precision_score, recall_score, classification_report,
)

# ── Default palette ────────────────────────────────────────────────────────────
DEFAULT_COLORS = [
    "#2E75B6", "#2ECC71", "#E67E22", "#E74C3C",
    "#9B59B6", "#1ABC9C", "#F39C12", "#3498DB",
]

# ── Diagnosis thresholds ───────────────────────────────────────────────────────
OVERFIT_THRESHOLD   = 0.10
HIGH_BIAS_THRESHOLD = 0.15


# ── Silent result containers ──────────────────────────────────────────────────

class _Result:
    """Dict-like container with silent __repr__ — no auto-display in Jupyter."""
    def __init__(self, data: dict):        self._data = data
    def __getitem__(self, key):            return self._data[key]
    def __setitem__(self, key, value):     self._data[key] = value
    def __contains__(self, key):           return key in self._data
    def __iter__(self):                    return iter(self._data)
    def __len__(self):                     return len(self._data)
    def keys(self):                        return self._data.keys()
    def values(self):                      return self._data.values()
    def items(self):                       return self._data.items()
    def get(self, key, default=None):      return self._data.get(key, default)
    def __repr__(self):                    return ""
    def __str__(self):                     return ""
    def to_dict(self):                     return dict(self._data)


class _ResultDF:
    """DataFrame wrapper with silent __repr__ — no auto-display in Jupyter."""
    def __init__(self, df):               self._df = df
    def __getitem__(self, key):           return self._df[key]
    def __setitem__(self, key, val):      self._df[key] = val
    def __len__(self):                    return len(self._df)
    def __iter__(self):                   return iter(self._df)
    def __contains__(self, key):          return key in self._df
    @property
    def columns(self):                    return self._df.columns
    @property
    def index(self):                      return self._df.index
    @property
    def values(self):                     return self._df.values
    @property
    def shape(self):                      return self._df.shape
    def idxmax(self, *a, **kw):           return self._df.idxmax(*a, **kw)
    def idxmin(self, *a, **kw):           return self._df.idxmin(*a, **kw)
    def iterrows(self):                   return self._df.iterrows()
    def get(self, key, default=None):     return self._df.get(key, default)
    def items(self):                      return self._df.items()
    def __repr__(self):                   return ""
    def __str__(self):                    return ""
    def to_dataframe(self):               return self._df


# ── Task detection ─────────────────────────────────────────────────────────────

def is_multiclass(y) -> bool:
    """Return True if y has more than 2 unique classes."""
    return len(np.unique(y)) > 2


# ── Core metrics computation ──────────────────────────────────────────────────

def compute_metrics(model, X_test, y_test) -> dict:
    """
    Compute classification metrics for one model.
    Automatically handles binary and multiclass problems.

    For binary   → f1/precision/recall use average='binary'
                   roc_auc from predict_proba[:, 1]
    For multiclass → f1/precision/recall use average='macro'
                     roc_auc from predict_proba (OvR, macro)
                     also stores per-class probabilities in y_prob_multi
    """
    y_pred  = model.predict(X_test)
    y_proba = (model.predict_proba(X_test)
               if hasattr(model, "predict_proba") else None)

    multi   = is_multiclass(y_test)
    classes = sorted(np.unique(y_test))

    # ── F1 / Precision / Recall ──────────────────────────────────
    avg = "macro" if multi else "binary"
    f1_val  = round(f1_score(y_test, y_pred, average=avg, zero_division=0), 4)
    prec_val= round(precision_score(y_test, y_pred, average=avg, zero_division=0), 4)
    rec_val = round(recall_score(y_test, y_pred, average=avg, zero_division=0), 4)

    # ── ROC-AUC ───────────────────────────────────────────────────
    roc_auc_val = None
    y_prob      = None       # binary: 1-D prob of positive class
    y_prob_multi= None       # multiclass: 2-D prob matrix

    if y_proba is not None:
        try:
            if multi:
                roc_auc_val  = round(
                    roc_auc_score(y_test, y_proba,
                                  multi_class="ovr", average="macro"), 4
                )
                y_prob_multi = y_proba
            else:
                y_prob       = y_proba[:, 1]
                roc_auc_val  = round(roc_auc_score(y_test, y_prob), 4)
        except Exception:
            pass

    return {
        "y_pred":       y_pred,
        "y_prob":       y_prob,           # None for multiclass (use y_prob_multi)
        "y_prob_multi": y_prob_multi,      # None for binary
        "classes":      classes,
        "multiclass":   multi,
        "accuracy":     round(accuracy_score(y_test, y_pred), 4),
        "f1":           f1_val,
        "precision":    prec_val,
        "recall":       rec_val,
        "roc_auc":      roc_auc_val,
        "report":       classification_report(y_test, y_pred, output_dict=True),
        "averaging":    avg,
    }


# ── Bias-Variance diagnosis ────────────────────────────────────────────────────

def diagnose_bv(gap, bias_proxy,
                overfit_threshold=OVERFIT_THRESHOLD,
                high_bias_threshold=HIGH_BIAS_THRESHOLD):
    if gap > overfit_threshold:
        return (
            "Overfit", "#E74C3C",
            f"Train–val gap is {gap:.3f} (>{overfit_threshold}). "
            "The model memorises training data but fails to generalise.\n"
            "→ Try: regularisation, reduce model complexity, more training data.",
        )
    if bias_proxy > high_bias_threshold:
        return (
            "Underfit", "#E67E22",
            f"Val error rate is {bias_proxy:.3f} (>{high_bias_threshold}). "
            "The model is too simple to capture the pattern.\n"
            "→ Try: more complex model, add features, reduce regularisation.",
        )
    return (
        "Good Fit", "#2ECC71",
        f"Train–val gap is {gap:.3f} and val error is {bias_proxy:.3f}. "
        "The model generalises well — no strong signs of overfit or underfit.\n"
        "→ Next step: evaluate on the held-out test set.",
    )


# ── Plot helpers ───────────────────────────────────────────────────────────────

def styled_box(ax, text: str, color: str, fontsize: int = 9):
    ax.text(
        0.01, -0.32, text,
        transform=ax.transAxes, fontsize=fontsize,
        verticalalignment="top",
        bbox=dict(boxstyle="round,pad=0.5",
                  facecolor=color + "22",
                  edgecolor=color, linewidth=1.4),
        wrap=True,
    )


def add_panel_label(ax, label: str, color="#2E75B6"):
    ax.text(0.0, 1.04, label,
            transform=ax.transAxes,
            fontsize=9, fontweight="bold",
            color=color, va="bottom")


def get_colors(n: int):
    return [DEFAULT_COLORS[i % len(DEFAULT_COLORS)] for i in range(n)]
