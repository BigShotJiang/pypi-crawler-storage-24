"""
ml_evaluator.evaluation
========================
Single-model evaluation — binary and multiclass.
"""

from __future__ import annotations
import warnings
from typing import List, Optional

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from sklearn.metrics import (
    confusion_matrix, ConfusionMatrixDisplay,
    roc_curve, auc,
)
from sklearn.preprocessing import label_binarize

from ._utils import (
    DEFAULT_COLORS, compute_metrics, is_multiclass,
    styled_box, add_panel_label, _Result,
)

warnings.filterwarnings("ignore")

__all__ = [
    "metrics", "interpret",
    "plot_confusion_matrix", "plot_roc_curve",
    "plot_metrics_bar", "classification_report",
    "model_summary",
]


# ── 1. metrics() ──────────────────────────────────────────────────────────────

def metrics(model, X_test, y_test, *, model_name="Model", verbose=True, show_interpretation=False):
    """
    Compute and print classification metrics.
    Works for binary and multiclass problems.
    Returns a Result object.
    """
    m = compute_metrics(model, X_test, y_test)
    if verbose:
        _print_metrics(model_name, m)
    if show_interpretation:
        text = _build_interpretation(m)
        print(f"  Interpretation — {model_name}")
        print("  " + "─" * 53)
        for line in text.splitlines():
            print(f"  {line}")
        print()
    return _Result(m)


# ── 2. interpret() ────────────────────────────────────────────────────────────

def interpret(model, X_test, y_test, *, model_name="Model", verbose=True):
    """
    Print plain-English interpretation of model performance.
    Works for binary and multiclass. Returns a Result object.
    """
    m    = compute_metrics(model, X_test, y_test)
    text = _build_interpretation(m)
    if verbose:
        print(f"\n  Interpretation — {model_name}")
        print("  " + "─" * 53)
        for line in text.splitlines():
            print(f"  {line}")
        print()
    return _Result({"text": text})


# ── 3. plot_confusion_matrix() ────────────────────────────────────────────────

def plot_confusion_matrix(
    model, X_test, y_test, *,
    model_name="Model", class_labels=None,
    color=DEFAULT_COLORS[0], figsize=None,
    show_interpretation=False, save_path=None,
) -> None:
    """
    Plot confusion matrix. Scales figure size automatically for multiclass.
    Returns None.
    """
    m = compute_metrics(model, X_test, y_test)
    n_classes = len(m["classes"])

    if class_labels is None:
        class_labels = [str(c) for c in m["classes"]]

    # auto-scale figure for many classes
    if figsize is None:
        side = max(4.5, n_classes * 1.1)
        figsize = (side, side * 0.9)

    fig, ax = plt.subplots(figsize=figsize)

    disp = ConfusionMatrixDisplay(
        confusion_matrix(y_test, m["y_pred"]),
        display_labels=class_labels,
    )
    disp.plot(ax=ax, cmap="Blues", colorbar=n_classes > 4)

    auc_str = f"  AUC={m['roc_auc']:.3f}" if m["roc_auc"] else ""
    ax.set_title(
        f"{model_name}\nAcc={m['accuracy']:.3f}  "
        f"F1={m['f1']:.3f} ({m['averaging']}){auc_str}",
        fontsize=10, fontweight="bold", color=color, pad=12,
    )
    if n_classes > 6:
        ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right", fontsize=7)
        ax.set_yticklabels(ax.get_yticklabels(), fontsize=7)

    plt.tight_layout()
    if show_interpretation:
        m2 = compute_metrics(model, X_test, y_test)
        text = _build_interpretation(m2)
        print(f"\n  Interpretation — {model_name}")
        print("  " + "─" * 53)
        for line in text.splitlines():
            print(f"  {line}")
        print()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  Saved → {save_path}")
    plt.show()


# ── 4. plot_roc_curve() ───────────────────────────────────────────────────────

def plot_roc_curve(
    model, X_test, y_test, *,
    model_name="Model", color=DEFAULT_COLORS[0],
    figsize=(6, 5), show_interpretation=True, save_path=None,
) -> None:
    """
    Plot ROC curve.
    Binary   → single curve.
    Multiclass → one curve per class (One-vs-Rest) + macro average.
    Returns None.
    """
    m = compute_metrics(model, X_test, y_test)

    if m["y_prob"] is None and m["y_prob_multi"] is None:
        print("  ⚠️  predict_proba not available — ROC curve cannot be plotted.")
        return

    multi = m["multiclass"]

    if not multi:
        # ── Binary ────────────────────────────────────────────────
        fpr, tpr, _ = roc_curve(y_test, m["y_prob"])
        roc_val     = auc(fpr, tpr)
        interp      = _interpret_auc(roc_val)

        print(f"\n  ROC-AUC ({model_name}): {roc_val:.4f}")
        print(f"  {interp}\n")

        fig, ax = plt.subplots(figsize=figsize)
        fig.subplots_adjust(bottom=0.28)
        ax.plot(fpr, tpr, color=color, lw=2.5,
                label=f"{model_name}  (AUC = {roc_val:.3f})")
        ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random")
        ax.fill_between(fpr, tpr, alpha=0.08, color=color)
        ax.legend(loc="lower right", fontsize=9)
        styled_box(ax, interp, color, fontsize=9)

    else:
        # ── Multiclass (One-vs-Rest) ───────────────────────────────
        classes  = m["classes"]
        y_bin    = label_binarize(y_test, classes=classes)
        y_proba  = m["y_prob_multi"]
        colors   = [DEFAULT_COLORS[i % len(DEFAULT_COLORS)]
                    for i in range(len(classes))]

        print(f"\n  ROC-AUC ({model_name}) — One-vs-Rest:")
        print(f"  {'Class':<20} AUC")
        print("  " + "─" * 30)

        fig, ax = plt.subplots(figsize=figsize)

        all_fpr = np.unique(np.concatenate([
            roc_curve(y_bin[:, i], y_proba[:, i])[0]
            for i in range(len(classes))
        ]))
        mean_tpr = np.zeros_like(all_fpr)

        for i, (cls, c) in enumerate(zip(classes, colors)):
            fpr_i, tpr_i, _ = roc_curve(y_bin[:, i], y_proba[:, i])
            auc_i = auc(fpr_i, tpr_i)
            label = str(cls)
            print(f"  {label:<20} {auc_i:.4f}")
            ax.plot(fpr_i, tpr_i, color=c, lw=1.8,
                    label=f"Class {label}  (AUC={auc_i:.3f})")
            mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)

        # macro average
        mean_tpr /= len(classes)
        macro_auc = auc(all_fpr, mean_tpr)
        print(f"  {'Macro average':<20} {macro_auc:.4f}")
        ax.plot(all_fpr, mean_tpr, "k-", lw=2.5,
                label=f"Macro avg  (AUC={macro_auc:.3f})")

        ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random")
        ax.legend(loc="lower right", fontsize=8,
                  ncol=1 + len(classes) // 6)
        print()

    ax.set_xlabel("False Positive Rate", fontsize=10)
    ax.set_ylabel("True Positive Rate", fontsize=10)
    ax.set_title(f"ROC Curve — {model_name}", fontweight="bold", fontsize=11)
    ax.grid(True, linestyle="--", alpha=0.4)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  Saved → {save_path}")
    plt.show()


# ── 5. plot_metrics_bar() ─────────────────────────────────────────────────────

def plot_metrics_bar(
    model, X_test, y_test, *,
    model_name="Model", color=DEFAULT_COLORS[0],
    figsize=(7, 4), show_interpretation=False, save_path=None,
) -> None:
    """
    Bar chart of Accuracy, F1, Precision, Recall, ROC-AUC.
    For multiclass, F1/Precision/Recall are macro-averaged.
    Returns None.
    """
    m = compute_metrics(model, X_test, y_test)
    avg_label = " (macro)" if m["multiclass"] else ""

    labels = ["Accuracy",
              f"F1{avg_label}",
              f"Precision{avg_label}",
              f"Recall{avg_label}",
              "ROC-AUC"]
    values = [m["accuracy"], m["f1"], m["precision"],
              m["recall"],   m["roc_auc"] or 0]

    fig, ax = plt.subplots(figsize=figsize)
    bars = ax.bar(labels, values, color=color, alpha=0.82,
                  edgecolor="white", linewidth=1.2)
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.012,
                f"{val:.3f}",
                ha="center", va="bottom", fontsize=10, fontweight="bold")

    ax.set_ylim(0, 1.18)
    ax.set_title(f"Performance Metrics — {model_name}",
                 fontweight="bold", fontsize=11)
    ax.set_xticklabels(labels, rotation=15, ha="right", fontsize=9)
    ax.axhline(0.5, color="#E74C3C", linestyle="--",
               lw=1.2, alpha=0.5, label="Random baseline (0.5)")
    ax.legend(fontsize=8)
    ax.grid(axis="y", linestyle="--", alpha=0.4)

    plt.tight_layout()
    if show_interpretation:
        m2 = compute_metrics(model, X_test, y_test)
        text = _build_interpretation(m2)
        print(f"\n  Interpretation — {model_name}")
        print("  " + "─" * 53)
        for line in text.splitlines():
            print(f"  {line}")
        print()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  Saved → {save_path}")
    plt.show()


# ── 6. classification_report() ───────────────────────────────────────────────

def classification_report(
    model, X_test, y_test, *,
    model_name="Model", class_labels=None,
) -> None:
    """
    Print classification report as a clean terminal table.
    Works for binary and multiclass. Returns None.
    """
    m = compute_metrics(model, X_test, y_test)

    if class_labels is None:
        class_labels = [str(c) for c in m["classes"]]

    rep  = m["report"]
    keys = [k for k in rep if k not in ("accuracy", "macro avg", "weighted avg")]

    print(f"\n  Classification Report — {model_name}")
    print("  " + "─" * 56)
    print(f"  {'Class':<16} {'Precision':>9} {'Recall':>8} {'F1-Score':>9} {'Support':>8}")
    print("  " + "─" * 56)

    for k in keys:
        label = (class_labels[int(k)]
                 if k.isdigit() and int(k) < len(class_labels) else k)
        row = rep[k]
        print(f"  {label:<16} {row['precision']:>9.3f} {row['recall']:>8.3f} "
              f"{row['f1-score']:>9.3f} {int(row['support']):>8}")

    total = int(sum(rep[k]["support"] for k in keys))
    print("  " + "─" * 56)
    print(f"  {'Accuracy':<16} {'':>9} {'':>8} {m['accuracy']:>9.3f} {total:>8}")
    for avg in ("macro avg", "weighted avg"):
        row = rep[avg]
        print(f"  {avg:<16} {row['precision']:>9.3f} {row['recall']:>8.3f} "
              f"{row['f1-score']:>9.3f}")
    print()


# ── 7. model_summary() ───────────────────────────────────────────────────────

def model_summary(
    model, X_test, y_test, *,
    model_name="Model", class_labels=None,
    color=DEFAULT_COLORS[0], figsize=(14, 10),
    show_interpretation=True, save_path=None,
) -> None:
    """
    Full 2×2 dashboard: Confusion Matrix + ROC + Metrics Bar + Classification Report.
    Works for binary and multiclass. Returns None.
    """
    m = compute_metrics(model, X_test, y_test)
    n_classes = len(m["classes"])
    multi     = m["multiclass"]

    if class_labels is None:
        class_labels = [str(c) for c in m["classes"]]

    # Terminal
    _print_metrics(model_name, m)
    if show_interpretation:
        text = _build_interpretation(m)
        print(f"  Interpretation — {model_name}")
        print("  " + "─" * 53)
        for line in text.splitlines():
            print(f"  {line}")
        print()

    # Figure
    fig = plt.figure(figsize=figsize)
    fig.suptitle(f"Model Summary — {model_name}",
                 fontsize=14, fontweight="bold", y=0.99)

    gs     = gridspec.GridSpec(2, 2, figure=fig, hspace=0.55, wspace=0.38)
    ax_cm  = fig.add_subplot(gs[0, 0])
    ax_roc = fig.add_subplot(gs[0, 1])
    ax_bar = fig.add_subplot(gs[1, 0])
    ax_rep = fig.add_subplot(gs[1, 1])

    # A — Confusion Matrix
    disp = ConfusionMatrixDisplay(
        confusion_matrix(y_test, m["y_pred"]),
        display_labels=class_labels,
    )
    disp.plot(ax=ax_cm, cmap="Blues", colorbar=n_classes > 4)
    ax_cm.set_title(
        f"Acc={m['accuracy']:.3f}  F1={m['f1']:.3f} ({m['averaging']})",
        fontsize=9, color="#555555", pad=8,
    )
    if n_classes > 6:
        ax_cm.set_xticklabels(ax_cm.get_xticklabels(),
                               rotation=45, ha="right", fontsize=7)
        ax_cm.set_yticklabels(ax_cm.get_yticklabels(), fontsize=7)
    add_panel_label(ax_cm, "A · Confusion Matrix")

    # B — ROC Curve
    if not multi and m["y_prob"] is not None:
        # Binary ROC
        fpr, tpr, _ = roc_curve(y_test, m["y_prob"])
        roc_val     = auc(fpr, tpr)
        ax_roc.plot(fpr, tpr, color=color, lw=2,
                    label=f"AUC = {roc_val:.3f}")
        ax_roc.fill_between(fpr, tpr, alpha=0.08, color=color)
        ax_roc.legend(fontsize=8, loc="lower right")

    elif multi and m["y_prob_multi"] is not None:
        # Multiclass One-vs-Rest
        classes = m["classes"]
        y_bin   = label_binarize(y_test, classes=classes)
        y_proba = m["y_prob_multi"]
        colors  = [DEFAULT_COLORS[i % len(DEFAULT_COLORS)]
                   for i in range(len(classes))]

        all_fpr  = np.unique(np.concatenate([
            roc_curve(y_bin[:, i], y_proba[:, i])[0]
            for i in range(len(classes))
        ]))
        mean_tpr = np.zeros_like(all_fpr)

        for i, (cls, c) in enumerate(zip(classes, colors)):
            fpr_i, tpr_i, _ = roc_curve(y_bin[:, i], y_proba[:, i])
            auc_i = auc(fpr_i, tpr_i)
            ax_roc.plot(fpr_i, tpr_i, color=c, lw=1.5,
                        label=f"{cls} ({auc_i:.2f})", alpha=0.75)
            mean_tpr += np.interp(all_fpr, fpr_i, tpr_i)

        mean_tpr /= len(classes)
        macro_auc = auc(all_fpr, mean_tpr)
        ax_roc.plot(all_fpr, mean_tpr, "k-", lw=2.2,
                    label=f"Macro ({macro_auc:.2f})")
        ax_roc.legend(fontsize=7, loc="lower right",
                      ncol=max(1, len(classes) // 5))
    else:
        ax_roc.text(0.5, 0.5, "predict_proba\nnot available",
                    ha="center", va="center", transform=ax_roc.transAxes)

    ax_roc.plot([0, 1], [0, 1], "k--", lw=1)
    ax_roc.set_xlabel("FPR", fontsize=8)
    ax_roc.set_ylabel("TPR", fontsize=8)
    title_roc = "ROC Curves (OvR)" if multi else "ROC Curve"
    ax_roc.set_title(title_roc, fontsize=9, pad=8)
    ax_roc.grid(True, linestyle="--", alpha=0.4)
    add_panel_label(ax_roc, "B · ROC Curve")

    # C — Metrics bar
    avg_label   = " (macro)" if multi else ""
    bar_labels  = ["Accuracy",
                   f"F1{avg_label}",
                   f"Precision{avg_label}",
                   f"Recall{avg_label}",
                   "ROC-AUC"]
    bar_values  = [m["accuracy"], m["f1"], m["precision"],
                   m["recall"],   m["roc_auc"] or 0]
    bars = ax_bar.bar(bar_labels, bar_values,
                      color=color, alpha=0.82, edgecolor="white")
    for bar, val in zip(bars, bar_values):
        ax_bar.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.012,
                    f"{val:.3f}",
                    ha="center", va="bottom", fontsize=8, fontweight="bold")
    ax_bar.set_ylim(0, 1.18)
    ax_bar.set_xticklabels(bar_labels, rotation=15, ha="right", fontsize=8)
    ax_bar.axhline(0.5, color="#E74C3C", linestyle="--", lw=1, alpha=0.4)
    ax_bar.grid(axis="y", linestyle="--", alpha=0.4)
    ax_bar.set_title("Metrics", fontsize=9, pad=8)
    add_panel_label(ax_bar, "C · Metrics")

    # D — Classification report text panel
    rep  = m["report"]
    keys = [k for k in rep if k not in ("accuracy", "macro avg", "weighted avg")]
    lines = [f"{'Class':<14} {'Prec':>6} {'Recall':>7} {'F1':>6} {'Sup':>6}",
             "─" * 43]
    for k in keys:
        lbl = (class_labels[int(k)]
               if k.isdigit() and int(k) < len(class_labels) else k)
        r = rep[k]
        lines.append(f"{lbl:<14} {r['precision']:>6.3f} {r['recall']:>7.3f} "
                     f"{r['f1-score']:>6.3f} {int(r['support']):>6}")
    lines += ["─" * 43,
              f"{'Accuracy':<14} {'':>6} {'':>7} {m['accuracy']:>6.3f}"]
    for avg in ("macro avg", "weighted avg"):
        r = rep[avg]
        lines.append(f"{avg:<14} {r['precision']:>6.3f} {r['recall']:>7.3f} "
                     f"{r['f1-score']:>6.3f}")

    ax_rep.text(0.04, 0.92, "\n".join(lines),
                transform=ax_rep.transAxes,
                fontsize=8.5, va="top", fontfamily="monospace",
                bbox=dict(boxstyle="round,pad=0.5",
                          facecolor="#F8F9FA", edgecolor="#CCCCCC"))
    ax_rep.axis("off")
    ax_rep.set_title("Classification Report", fontsize=9, pad=8)
    add_panel_label(ax_rep, "D · Classification Report")

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  Saved → {save_path}")
    plt.show()


# ── Internal helpers ──────────────────────────────────────────────────────────

def _print_metrics(model_name, m):
    avg_note = " (macro avg)" if m["multiclass"] else ""
    print("\n" + "=" * 55)
    print(f"  Model Summary — {model_name}")
    if m["multiclass"]:
        n = len(m["classes"])
        print(f"  Task: Multiclass ({n} classes: {', '.join(str(c) for c in m['classes'])})")
    print("=" * 55)
    print(f"  Accuracy  : {m['accuracy']:.4f}")
    print(f"  F1        : {m['f1']:.4f}{avg_note}")
    print(f"  Precision : {m['precision']:.4f}{avg_note}")
    print(f"  Recall    : {m['recall']:.4f}{avg_note}")
    if m["roc_auc"]:
        ovr = " (macro OvR)" if m["multiclass"] else ""
        print(f"  ROC-AUC   : {m['roc_auc']:.4f}{ovr}")
    print()


def _build_interpretation(m):
    multi = m["multiclass"]
    lines = []

    acc = m["accuracy"]
    lines.append(
        f"✅  Accuracy {acc:.3f} — high overall correctness." if acc >= 0.90 else
        f"⚠️   Accuracy {acc:.3f} — acceptable but worth improving." if acc >= 0.75 else
        f"🔴  Accuracy {acc:.3f} — low. Check for class imbalance or weak features."
    )

    f1  = m["f1"]
    avg = "macro F1" if multi else "F1"
    lines.append(
        f"✅  {avg} {f1:.3f} — strong balance between precision and recall." if f1 >= 0.85 else
        f"⚠️   {avg} {f1:.3f} — moderate. Review per-class scores." if f1 >= 0.65 else
        f"🔴  {avg} {f1:.3f} — low. Some classes may be hard to distinguish."
    )

    if not multi:
        p, r = m["precision"], m["recall"]
        if abs(p - r) > 0.15:
            lines.append(
                f"⚠️   Precision ({p:.3f}) >> Recall ({r:.3f}) — "
                "model is conservative: misses positives to avoid false alarms."
                if p > r else
                f"⚠️   Recall ({r:.3f}) >> Precision ({p:.3f}) — "
                "model catches most positives but raises many false alarms."
            )
        else:
            lines.append(f"✅  Precision ({p:.3f}) ≈ Recall ({r:.3f}) — well balanced.")
    else:
        # For multiclass, flag any class with low F1 in the report
        rep  = m["report"]
        keys = [k for k in rep if k not in ("accuracy", "macro avg", "weighted avg")]
        low  = [k for k in keys if rep[k]["f1-score"] < 0.60]
        if low:
            cls_str = ", ".join(str(c) for c in low)
            lines.append(f"⚠️   Low F1 on class(es): {cls_str} — "
                         "consider class weighting or more data for these classes.")
        else:
            lines.append("✅  All classes have acceptable F1 scores.")

    if m["roc_auc"] is not None:
        ovr = " (macro OvR)" if multi else ""
        lines.append(f"     {_interpret_auc(m['roc_auc'])}{ovr}")

    return "\n".join(lines)


def _interpret_auc(val):
    if val >= 0.95:
        return f"AUC = {val:.3f} — Excellent. The model clearly separates the classes."
    if val >= 0.85:
        return f"AUC = {val:.3f} — Good. Works well but there is room to improve."
    if val >= 0.70:
        return f"AUC = {val:.3f} — Fair. Better than random but may struggle on hard cases."
    return f"AUC = {val:.3f} — Poor. Barely better than random. Consider feature engineering."
