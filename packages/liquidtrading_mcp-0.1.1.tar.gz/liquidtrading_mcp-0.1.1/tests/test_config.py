"""Tests for config module."""

from __future__ import annotations

import logging

import pytest

from liquid_mcp.config import Config


class TestConfig:
    def test_defaults(self, monkeypatch):
        monkeypatch.delenv("LIQUID_API_KEY", raising=False)
        monkeypatch.delenv("LIQUID_API_SECRET", raising=False)
        monkeypatch.delenv("LIQUID_BASE_URL", raising=False)
        monkeypatch.delenv("MAX_ORDER_USD", raising=False)
        monkeypatch.delenv("DAILY_LOSS_LIMIT", raising=False)
        monkeypatch.delenv("LIQUID_MCP_AUDIT_PATH", raising=False)

        cfg = Config.from_env()
        assert cfg.api_key is None
        assert cfg.api_secret is None
        assert cfg.base_url is None
        assert cfg.max_order_usd == 1000.0
        assert cfg.daily_loss_limit == 5000.0
        assert cfg.audit_path.endswith("trades.jsonl")

    def test_with_credentials(self, monkeypatch):
        monkeypatch.setenv("LIQUID_API_KEY", "lq_test")
        monkeypatch.setenv("LIQUID_API_SECRET", "sk_test")
        cfg = Config.from_env()
        assert cfg.api_key == "lq_test"
        assert cfg.api_secret == "sk_test"

    def test_key_without_secret_raises(self, monkeypatch):
        monkeypatch.setenv("LIQUID_API_KEY", "lq_test")
        monkeypatch.delenv("LIQUID_API_SECRET", raising=False)
        with pytest.raises(ValueError, match="both be set"):
            Config.from_env()

    def test_secret_without_key_raises(self, monkeypatch):
        monkeypatch.delenv("LIQUID_API_KEY", raising=False)
        monkeypatch.setenv("LIQUID_API_SECRET", "sk_test")
        with pytest.raises(ValueError, match="both be set"):
            Config.from_env()

    def test_negative_max_order_raises(self, monkeypatch):
        monkeypatch.delenv("LIQUID_API_KEY", raising=False)
        monkeypatch.delenv("LIQUID_API_SECRET", raising=False)
        monkeypatch.setenv("MAX_ORDER_USD", "-1")
        with pytest.raises(ValueError, match="MAX_ORDER_USD"):
            Config.from_env()

    def test_negative_daily_loss_raises(self, monkeypatch):
        monkeypatch.delenv("LIQUID_API_KEY", raising=False)
        monkeypatch.delenv("LIQUID_API_SECRET", raising=False)
        monkeypatch.setenv("DAILY_LOSS_LIMIT", "0")
        with pytest.raises(ValueError, match="DAILY_LOSS_LIMIT"):
            Config.from_env()

    def test_custom_values(self, monkeypatch):
        monkeypatch.delenv("LIQUID_API_KEY", raising=False)
        monkeypatch.delenv("LIQUID_API_SECRET", raising=False)
        monkeypatch.setenv("MAX_ORDER_USD", "500")
        monkeypatch.setenv("DAILY_LOSS_LIMIT", "2000")
        monkeypatch.setenv("LIQUID_BASE_URL", "https://test.api")
        cfg = Config.from_env()
        assert cfg.max_order_usd == 500.0
        assert cfg.daily_loss_limit == 2000.0
        assert cfg.base_url == "https://test.api"

    def test_frozen(self, config):
        with pytest.raises(AttributeError):
            config.api_key = "changed"

    def test_invalid_base_url_raises(self, monkeypatch):
        monkeypatch.delenv("LIQUID_API_KEY", raising=False)
        monkeypatch.delenv("LIQUID_API_SECRET", raising=False)
        monkeypatch.setenv("LIQUID_BASE_URL", "not-a-url")
        with pytest.raises(ValueError, match="valid HTTP"):
            Config.from_env()

    def test_ftp_base_url_raises(self, monkeypatch):
        monkeypatch.delenv("LIQUID_API_KEY", raising=False)
        monkeypatch.delenv("LIQUID_API_SECRET", raising=False)
        monkeypatch.setenv("LIQUID_BASE_URL", "ftp://example.com")
        with pytest.raises(ValueError, match="valid HTTP"):
            Config.from_env()

    def test_max_order_exceeds_daily_loss_warns(self, monkeypatch, caplog):
        monkeypatch.delenv("LIQUID_API_KEY", raising=False)
        monkeypatch.delenv("LIQUID_API_SECRET", raising=False)
        monkeypatch.setenv("MAX_ORDER_USD", "10000")
        monkeypatch.setenv("DAILY_LOSS_LIMIT", "1000")
        with caplog.at_level(logging.WARNING):
            cfg = Config.from_env()
        assert cfg.max_order_usd == 10000.0
        assert "MAX_ORDER_USD" in caplog.text

    def test_audit_path_with_tmpdir(self, monkeypatch, tmp_path):
        monkeypatch.delenv("LIQUID_API_KEY", raising=False)
        monkeypatch.delenv("LIQUID_API_SECRET", raising=False)
        audit_path = str(tmp_path / "subdir" / "trades.jsonl")
        monkeypatch.setenv("LIQUID_MCP_AUDIT_PATH", audit_path)
        cfg = Config.from_env()
        assert cfg.audit_path == audit_path
        assert (tmp_path / "subdir").is_dir()
