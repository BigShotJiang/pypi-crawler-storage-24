"""Canonical Cadis package version."""

__version__ = "0.3.5"
