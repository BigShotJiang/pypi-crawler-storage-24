import asyncio
import base64
import json
import pathlib
import sys
import threading
import unittest
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, unquote, urlparse

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))

from mcp_apollo_config.server import (
    DEFAULT_LOGIN_SUBMIT,
    ApolloPortalSessionClient,
    Defaults,
    RuntimeConfig,
    build_tools,
    configure_logging,
    create_fastmcp_server,
    handle_tool_call,
)


@dataclass
class MockApolloState:
    username: str = "test-user"
    password: str = "test-pass"
    session_cookie: str = "mock-session-id"
    session_cookie_name: str = "SESSION"
    app_id: str = "demo-app"
    env: str = "DEV"
    cluster: str = "default"
    namespace: str = "application"
    items: list | None = None

    def __post_init__(self) -> None:
        if self.items is None:
            self.items = [
                {
                    "id": 1,
                    "namespaceId": 10,
                    "key": "demo.key",
                    "value": "demo-value",
                    "comment": "for unit test",
                    "lineNum": 1,
                },
                {
                    "id": 2,
                    "namespaceId": 10,
                    "key": "another.key",
                    "value": "another-value",
                    "lineNum": 2,
                },
                {
                    "id": 3,
                    "namespaceId": 10,
                    "key": "third.key",
                    "value": "third-value",
                    "lineNum": 3,
                },
            ]


class MockApolloHandler(BaseHTTPRequestHandler):
    state: MockApolloState = MockApolloState()

    def log_message(self, format, *args):  # noqa: A003
        return

    def _json_response(self, status: int, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _html_login_page(self):
        body = b"<html><body><form action='/signin'>signin</form></body></html>"
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _has_valid_session(self) -> bool:
        cookie_header = self.headers.get("Cookie", "")
        expected = f"{self.state.session_cookie_name}={self.state.session_cookie}"
        return expected in cookie_header

    def _parse_path(self):
        parsed = urlparse(self.path)
        parts = [part for part in parsed.path.split("/") if part]
        return parsed, parts

    def do_POST(self):  # noqa: N802
        parsed, parts = self._parse_path()
        if parsed.path != "/signin":
            self._json_response(404, {"message": "not found"})
            return

        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8", errors="replace")
        form = parse_qs(body)

        username = form.get("username", [""])[0]
        password = form.get("password", [""])[0]
        login_submit = form.get("login-submit", [""])[0]

        if (
            username == self.state.username
            and password == self.state.password
            and login_submit == DEFAULT_LOGIN_SUBMIT
        ):
            self.send_response(302)
            self.send_header(
                "Set-Cookie",
                f"{self.state.session_cookie_name}={self.state.session_cookie}; Path=/; HttpOnly",
            )
            self.send_header("Location", "/")
            self.end_headers()
            return

        self._json_response(401, {"message": "invalid credentials"})

    def do_GET(self):  # noqa: N802
        parsed, parts = self._parse_path()
        if parsed.path == "/":
            body = b"ok"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if parsed.path == "/signin":
            self._html_login_page()
            return

        if not self._has_valid_session():
            self._html_login_page()
            return

        if len(parts) >= 7 and parts[:7] == [
            "apps",
            self.state.app_id,
            "envs",
            self.state.env,
            "clusters",
            self.state.cluster,
            "namespaces",
        ]:
            # GET /apps/{app}/envs/{env}/clusters/{cluster}/namespaces
            if len(parts) == 7:
                self._json_response(
                    200,
                    [
                        {
                            "baseInfo": {
                                "id": 10,
                                "appId": self.state.app_id,
                                "clusterName": self.state.cluster,
                                "namespaceName": self.state.namespace,
                            },
                            "items": self.state.items,
                            "itemModifiedCnt": len(self.state.items),
                        }
                    ],
                )
                return

            # GET /apps/{app}/envs/{env}/clusters/{cluster}/namespaces/{ns}/items
            if len(parts) == 9 and parts[7] == self.state.namespace and parts[8] == "items":
                self._json_response(200, self.state.items)
                return

        self._json_response(404, {"message": "not found"})

    def do_PUT(self):  # noqa: N802
        parsed, parts = self._parse_path()
        if not self._has_valid_session():
            self._html_login_page()
            return

        prefix = [
            "apps",
            self.state.app_id,
            "envs",
            self.state.env,
            "clusters",
            self.state.cluster,
            "namespaces",
            self.state.namespace,
            "items",
        ]
        if parts[:9] != prefix:
            self._json_response(404, {"message": "not found"})
            return

        key = None
        if len(parts) == 10:
            key = unquote(parts[9])
        elif len(parts) == 11 and parts[9] == "encodedItems":
            encoded = unquote(parts[10])
            key = base64.b64decode(encoded).decode("utf-8")

        if not key:
            self._json_response(400, {"message": "invalid key path"})
            return

        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8", errors="replace")
        payload = json.loads(body) if body else {}
        value = payload.get("value", "")
        comment = payload.get("comment", "")

        existing = None
        for item in self.state.items:
            if item.get("key") == key:
                existing = item
                break

        if existing is None:
            existing = {
                "id": len(self.state.items) + 1,
                "namespaceId": 10,
                "key": key,
                "lineNum": len(self.state.items) + 1,
            }
            self.state.items.append(existing)

        existing["value"] = value
        if comment is not None:
            existing["comment"] = comment

        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()


class MockApolloServer:
    def __init__(self) -> None:
        self.state = MockApolloState()
        self.httpd: HTTPServer | None = None
        self.thread: threading.Thread | None = None
        self.url = ""

    def __enter__(self):
        MockApolloHandler.state = self.state
        self.httpd = HTTPServer(("127.0.0.1", 0), MockApolloHandler)
        self.url = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.httpd is not None:
            self.httpd.shutdown()
            self.httpd.server_close()
        if self.thread is not None:
            self.thread.join(timeout=2)


def _extract_tool_text(call_result) -> str:
    blocks = call_result[0] if isinstance(call_result, tuple) else call_result
    if not blocks:
        return ""
    first = blocks[0]
    text = getattr(first, "text", None)
    if isinstance(text, str):
        return text
    if isinstance(first, dict):
        value = first.get("text")
        if isinstance(value, str):
            return value
    return str(first)


def _build_config(base_url: str, governance_mode: str = "readonly") -> RuntimeConfig:
    return RuntimeConfig(
        portal_url=base_url,
        username="test-user",
        password="test-pass",
        login_submit=DEFAULT_LOGIN_SUBMIT,
        governance_mode=governance_mode,
        operator="tester" if governance_mode == "editable" else None,
        timeout_ms=5000,
        defaults=Defaults(
            app_id="demo-app",
            env="DEV",
            cluster_name="default",
            namespace_name="application",
        ),
        auth_mode="portal_session",
        log_level="ERROR",
        debug_http=False,
    )


class ApolloMcpToolTests(unittest.TestCase):
    def setUp(self):
        configure_logging("ERROR", False)

    def test_build_tools_readonly(self):
        config = _build_config("http://127.0.0.1:1", "readonly")
        tools = build_tools(config)
        names = [tool["name"] for tool in tools]
        self.assertIn("apollo_get_namespace_configs", names)
        self.assertIn("apollo_get_key", names)
        self.assertNotIn("apollo_edit_key", names)

    def test_build_tools_editable(self):
        config = _build_config("http://127.0.0.1:1", "editable")
        tools = build_tools(config)
        names = [tool["name"] for tool in tools]
        self.assertIn("apollo_edit_key", names)

    def test_get_key_tool(self):
        with MockApolloServer() as mock_server:
            config = _build_config(mock_server.url, "readonly")
            client = ApolloPortalSessionClient(config)
            result = handle_tool_call(
                {"name": "apollo_get_key", "arguments": {"key": "demo.key"}},
                config,
                client,
            )
            payload = json.loads(result["content"][0]["text"])
            self.assertEqual(payload["item"]["value"], "demo-value")

    def test_get_namespace_configs_tool(self):
        with MockApolloServer() as mock_server:
            config = _build_config(mock_server.url, "readonly")
            client = ApolloPortalSessionClient(config)
            result = handle_tool_call(
                {
                    "name": "apollo_get_namespace_configs",
                    "arguments": {"pageSize": 2, "maxItems": 5},
                },
                config,
                client,
            )
            payload = json.loads(result["content"][0]["text"])
            self.assertEqual(payload["stats"]["fetched"], 3)
            self.assertFalse(payload["stats"]["truncated"])

    def test_edit_key_tool(self):
        with MockApolloServer() as mock_server:
            config = _build_config(mock_server.url, "editable")
            client = ApolloPortalSessionClient(config)
            result = handle_tool_call(
                {
                    "name": "apollo_edit_key",
                    "arguments": {"key": "new.key", "value": {"a": 1}},
                },
                config,
                client,
            )
            payload = json.loads(result["content"][0]["text"])
            self.assertEqual(payload["item"]["key"], "new.key")
            self.assertEqual(payload["item"]["value"], "{\"a\": 1}")

    def test_login_with_jsessionid_cookie(self):
        with MockApolloServer() as mock_server:
            mock_server.state.session_cookie_name = "JSESSIONID"
            config = _build_config(mock_server.url, "readonly")
            client = ApolloPortalSessionClient(config)
            result = handle_tool_call(
                {"name": "apollo_get_key", "arguments": {"key": "demo.key"}},
                config,
                client,
            )
            payload = json.loads(result["content"][0]["text"])
            self.assertEqual(payload["item"]["value"], "demo-value")


class FastMcpServerTests(unittest.TestCase):
    def setUp(self):
        configure_logging("ERROR", False)

    def test_fastmcp_list_tools_readonly(self):
        with MockApolloServer() as mock_server:
            config = _build_config(mock_server.url, "readonly")
            client = ApolloPortalSessionClient(config)
            mcp = create_fastmcp_server(config, client)
            tools = asyncio.run(mcp.list_tools())
            names = [tool.name for tool in tools]
            self.assertIn("apollo_get_namespace_configs", names)
            self.assertIn("apollo_get_key", names)
            self.assertNotIn("apollo_edit_key", names)

    def test_fastmcp_tool_call_get_namespace(self):
        with MockApolloServer() as mock_server:
            config = _build_config(mock_server.url, "readonly")
            client = ApolloPortalSessionClient(config)
            mcp = create_fastmcp_server(config, client)
            result = asyncio.run(
                mcp.call_tool(
                    "apollo_get_namespace_configs",
                    {"pageSize": 2, "maxItems": 3},
                )
            )
            text = _extract_tool_text(result)
            payload = json.loads(text)
            self.assertEqual(payload["stats"]["fetched"], 3)
            self.assertEqual(payload["scope"]["appId"], "demo-app")


if __name__ == "__main__":
    unittest.main()
