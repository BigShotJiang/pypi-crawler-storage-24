from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from http.cookiejar import CookieJar
from typing import Any, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urljoin, urlparse
from urllib.request import HTTPCookieProcessor, Request, build_opener

from mcp.server.fastmcp import FastMCP


SERVER_INFO = {"name": "mcp-apollo-config", "version": "0.1.1"}
LOG_LEVEL_ORDER = {"DEBUG": 10, "INFO": 20, "WARN": 30, "ERROR": 40}
CURRENT_LOG_LEVEL = LOG_LEVEL_ORDER["WARN"]
CURRENT_DEBUG_HTTP = False
DEFAULT_LOGIN_SUBMIT = "\u767b\u5f55"  # Default login button label in Chinese.
SUPPORTED_SESSION_COOKIE_NAMES = {"SESSION", "JSESSIONID"}


class ApolloHttpError(Exception):
    def __init__(self, status: int, status_text: str, payload: Any) -> None:
        super().__init__(f"Apollo API error: {status} {status_text}")
        self.status = status
        self.status_text = status_text
        self.payload = payload


@dataclass
class Defaults:
    app_id: str | None
    env: str | None
    cluster_name: str
    namespace_name: str | None


@dataclass
class RuntimeConfig:
    portal_url: str
    username: str
    password: str
    login_submit: str
    governance_mode: str
    operator: str | None
    timeout_ms: int
    defaults: Defaults
    auth_mode: str
    log_level: str
    debug_http: bool


@dataclass
class Scope:
    app_id: str
    env: str
    cluster_name: str
    namespace_name: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "appId": self.app_id,
            "env": self.env,
            "clusterName": self.cluster_name,
            "namespaceName": self.namespace_name,
        }


class ApolloClientProtocol(Protocol):
    def get_namespace(self, scope: Scope, fill_item_detail: bool) -> Any: ...

    def list_namespace_items(self, scope: Scope, page: int, size: int) -> Any: ...

    def get_item(self, scope: Scope, key: str) -> Any: ...

    def upsert_item(
        self,
        scope: Scope,
        key: str,
        value: str,
        operator: str,
        comment: str | None,
        create_if_not_exists: bool,
    ) -> Any: ...


class PortalSessionHttpClient:
    def __init__(
        self,
        base_url: str,
        username: str,
        password: str,
        login_submit: str,
        timeout_ms: int,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.username = username
        self.password = password
        self.login_submit = login_submit
        self.timeout_ms = timeout_ms
        self.cookie_jar = CookieJar()
        self.opener = build_opener(HTTPCookieProcessor(self.cookie_jar))

    def _build_url(self, path: str, query: dict[str, Any] | None = None) -> str:
        full_url = urljoin(f"{self.base_url}/", path.lstrip("/"))
        if query:
            normalized = {key: value for key, value in query.items() if value is not None}
            if normalized:
                full_url = f"{full_url}?{urlencode(normalized)}"
        return full_url

    def _session_cookie(self) -> tuple[str, str] | None:
        for cookie in self.cookie_jar:
            cookie_name = cookie.name.upper()
            if cookie_name in SUPPORTED_SESSION_COOKIE_NAMES and cookie.value:
                return cookie_name, cookie.value
        return None

    def _has_session_cookie(self) -> bool:
        return self._session_cookie() is not None

    def _looks_like_login_page(self, content_type: str, raw: bytes) -> bool:
        if "text/html" not in content_type.lower():
            return False
        text = raw[:2048].decode("utf-8", errors="ignore").lower()
        return "signin" in text or "login-submit" in text

    def login(self, force: bool = False) -> None:
        if not force and self._has_session_cookie():
            return

        body = urlencode(
            {
                "username": self.username,
                "password": self.password,
                "login-submit": self.login_submit,
            }
        ).encode("utf-8")
        url = self._build_url("/signin")
        request = Request(
            url=url,
            method="POST",
            data=body,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "text/html,application/json",
            },
        )

        start_time = time.monotonic()
        if CURRENT_DEBUG_HTTP:
            log_event("DEBUG", "Portal login request", url=url)

        try:
            with self.opener.open(request, timeout=self.timeout_ms / 1000.0) as response:
                _ = response.read()
                duration_ms = int((time.monotonic() - start_time) * 1000)
                if CURRENT_DEBUG_HTTP:
                    log_event("DEBUG", "Portal login response", status=response.status, durationMs=duration_ms)
        except HTTPError as error:
            duration_ms = int((time.monotonic() - start_time) * 1000)
            payload = error.read().decode("utf-8", errors="replace")
            log_event("ERROR", "Portal login HTTP error", status=error.code, durationMs=duration_ms)
            raise RuntimeError(f"Portal login failed: HTTP {error.code} {error.reason} | {payload[:200]}") from error
        except URLError as error:
            duration_ms = int((time.monotonic() - start_time) * 1000)
            log_event("ERROR", "Portal login connection error", durationMs=duration_ms, reason=str(error.reason))
            raise RuntimeError(f"Portal login failed: {error.reason}") from error

        session_cookie = self._session_cookie()
        if not session_cookie:
            expected = "/".join(sorted(SUPPORTED_SESSION_COOKIE_NAMES))
            raise RuntimeError(f"Portal login failed: session cookie not found. Expected one of: {expected}.")

        cookie_name, cookie_value = session_cookie
        log_event(
            "INFO",
            "Portal login succeeded",
            sessionCookieName=cookie_name,
            sessionCookieLength=len(cookie_value),
        )

    def request(
        self,
        method: str,
        path: str,
        query: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        allow_relogin: bool = True,
    ) -> Any:
        self.login(force=False)

        full_url = self._build_url(path, query=query)
        headers = {"Accept": "application/json"}
        payload = None
        if body is not None:
            payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json;charset=UTF-8"

        request = Request(full_url, method=method, data=payload, headers=headers)
        start_time = time.monotonic()

        if CURRENT_DEBUG_HTTP:
            log_event(
                "DEBUG",
                "HTTP request",
                method=method,
                url=sanitize_url(full_url),
                timeoutMs=self.timeout_ms,
                hasBody=body is not None,
            )

        try:
            with self.opener.open(request, timeout=self.timeout_ms / 1000.0) as response:
                content_type = response.headers.get("Content-Type", "")
                raw = response.read()
                duration_ms = int((time.monotonic() - start_time) * 1000)

                if CURRENT_DEBUG_HTTP:
                    log_event(
                        "DEBUG",
                        "HTTP response",
                        method=method,
                        url=sanitize_url(full_url),
                        status=response.status,
                        durationMs=duration_ms,
                    )

                if self._looks_like_login_page(content_type, raw) and allow_relogin:
                    log_event("WARN", "Session may have expired (HTML login page detected), relogin and retry")
                    self.login(force=True)
                    return self.request(method, path, query=query, body=body, allow_relogin=False)

                if response.status == 204 or raw == b"":
                    return None

                text = raw.decode("utf-8", errors="replace")
                if "application/json" in content_type.lower():
                    try:
                        return json.loads(text)
                    except json.JSONDecodeError:
                        return text
                return text

        except HTTPError as error:
            duration_ms = int((time.monotonic() - start_time) * 1000)
            payload_text = error.read().decode("utf-8", errors="replace")
            payload_obj: Any = payload_text
            if payload_text:
                try:
                    payload_obj = json.loads(payload_text)
                except json.JSONDecodeError:
                    payload_obj = payload_text

            if error.code in {401, 403} and allow_relogin:
                log_event("WARN", "HTTP auth error, relogin and retry", status=error.code, durationMs=duration_ms)
                self.login(force=True)
                return self.request(method, path, query=query, body=body, allow_relogin=False)

            log_event(
                "WARN",
                "HTTP error",
                method=method,
                url=sanitize_url(full_url),
                status=error.code,
                durationMs=duration_ms,
            )
            raise ApolloHttpError(error.code, error.reason, payload_obj) from error

        except URLError as error:
            duration_ms = int((time.monotonic() - start_time) * 1000)
            log_event(
                "ERROR",
                "HTTP connection error",
                method=method,
                url=sanitize_url(full_url),
                durationMs=duration_ms,
                reason=str(error.reason),
            )
            raise RuntimeError(f"Apollo request failed: {error.reason}") from error

        except TimeoutError as error:
            duration_ms = int((time.monotonic() - start_time) * 1000)
            log_event(
                "ERROR",
                "HTTP timeout",
                method=method,
                url=sanitize_url(full_url),
                durationMs=duration_ms,
            )
            raise RuntimeError(f"Apollo request timed out after {self.timeout_ms} ms") from error


class ApolloPortalSessionClient(ApolloClientProtocol):
    def __init__(self, config: RuntimeConfig) -> None:
        self.http = PortalSessionHttpClient(
            base_url=config.portal_url,
            username=config.username,
            password=config.password,
            login_submit=config.login_submit,
            timeout_ms=config.timeout_ms,
        )

    def _namespace_list_path(self, scope: Scope) -> str:
        return (
            f"/apps/{encode_path_segment(scope.app_id)}"
            f"/envs/{encode_path_segment(scope.env)}"
            f"/clusters/{encode_path_segment(scope.cluster_name)}"
            "/namespaces"
        )

    def _namespace_items_path(self, scope: Scope) -> str:
        return (
            f"{self._namespace_list_path(scope)}"
            f"/{encode_path_segment(scope.namespace_name)}/items"
        )

    def _namespace_item_put_path(self, scope: Scope, key: str, encoded: bool) -> str:
        base = self._namespace_items_path(scope)
        if encoded:
            encoded_key = base64.b64encode(key.encode("utf-8")).decode("ascii")
            return f"{base}/encodedItems/{encode_path_segment(encoded_key)}"
        return f"{base}/{encode_path_segment(key)}"

    def _extract_namespace_name(self, namespace_obj: dict[str, Any]) -> str | None:
        base_info = namespace_obj.get("baseInfo")
        if isinstance(base_info, dict) and isinstance(base_info.get("namespaceName"), str):
            return base_info.get("namespaceName")
        if isinstance(namespace_obj.get("namespaceName"), str):
            return namespace_obj.get("namespaceName")
        if isinstance(namespace_obj.get("name"), str):
            return namespace_obj.get("name")
        return None

    def _find_namespace(self, scope: Scope, namespaces: list[Any]) -> dict[str, Any] | None:
        for namespace_obj in namespaces:
            if not isinstance(namespace_obj, dict):
                continue
            namespace_name = self._extract_namespace_name(namespace_obj)
            if namespace_name == scope.namespace_name:
                return namespace_obj
        return None

    def get_namespace(self, scope: Scope, fill_item_detail: bool) -> Any:
        payload = self.http.request("GET", self._namespace_list_path(scope))
        if not isinstance(payload, list):
            raise ApolloHttpError(500, "Invalid namespace payload", payload)

        namespace_obj = self._find_namespace(scope, payload)
        if namespace_obj is None:
            raise ApolloHttpError(
                404,
                "Not Found",
                {
                    "message": (
                        f"namespace not found for appId={scope.app_id}, env={scope.env}, "
                        f"cluster={scope.cluster_name}, namespace={scope.namespace_name}"
                    )
                },
            )

        if fill_item_detail:
            items_page = self.list_namespace_items(scope, page=0, size=10000)
            copied = dict(namespace_obj)
            copied["items"] = items_page.get("content", [])
            return copied

        return namespace_obj

    def list_namespace_items(self, scope: Scope, page: int, size: int) -> Any:
        payload = self.http.request("GET", self._namespace_items_path(scope))
        items: list[Any]
        if isinstance(payload, list):
            items = payload
        elif isinstance(payload, dict) and isinstance(payload.get("content"), list):
            items = payload.get("content", [])
        else:
            items = []

        normalized_page = max(0, page)
        normalized_size = max(1, size)
        start = normalized_page * normalized_size
        end = start + normalized_size
        return {
            "content": items[start:end],
            "total": len(items),
            "number": normalized_page,
            "size": normalized_size,
        }

    def get_item(self, scope: Scope, key: str) -> Any:
        result = self.list_namespace_items(scope, page=0, size=100000)
        items = result.get("content") if isinstance(result, dict) else None
        if isinstance(items, list):
            for item in items:
                if isinstance(item, dict) and item.get("key") == key:
                    return item

        raise ApolloHttpError(404, "Not Found", {"message": f'key "{key}" not found'})

    def upsert_item(
        self,
        scope: Scope,
        key: str,
        value: str,
        operator: str,
        comment: str | None,
        create_if_not_exists: bool,
    ) -> Any:
        body: dict[str, Any] = {
            "key": key,
            "value": value,
            "dataChangeLastModifiedBy": operator,
        }
        if comment is not None:
            body["comment"] = comment
        if create_if_not_exists:
            body["dataChangeCreatedBy"] = operator

        encoded_key = has_illegal_key_chars(key)
        try:
            self.http.request(
                "PUT",
                self._namespace_item_put_path(scope, key, encoded=encoded_key),
                query={"createIfNotExists": str(create_if_not_exists).lower()},
                body=body,
            )
        except ApolloHttpError as error:
            if encoded_key and error.status in {400, 404, 405}:
                self.http.request(
                    "PUT",
                    self._namespace_item_put_path(scope, key, encoded=False),
                    query={"createIfNotExists": str(create_if_not_exists).lower()},
                    body=body,
                )
            else:
                raise

        return self.get_item(scope, key)


def normalize_log_level(value: str | None) -> str:
    normalized = (value or "WARN").strip().upper()
    if normalized not in LOG_LEVEL_ORDER:
        raise ValueError("Invalid log level. Expected one of: DEBUG, INFO, WARN, ERROR.")
    return normalized


def configure_logging(level: str, debug_http: bool) -> None:
    global CURRENT_LOG_LEVEL
    global CURRENT_DEBUG_HTTP
    CURRENT_LOG_LEVEL = LOG_LEVEL_ORDER[level]
    CURRENT_DEBUG_HTTP = debug_http


def should_log(level: str) -> bool:
    return LOG_LEVEL_ORDER[level] >= CURRENT_LOG_LEVEL


def log_event(level: str, message: str, **fields: Any) -> None:
    if not should_log(level):
        return

    timestamp = datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")
    line = f"[mcp-apollo-config] {timestamp} {level} {message}"
    if fields:
        line += " | " + json.dumps(fields, ensure_ascii=False, separators=(",", ":"))
    sys.stderr.write(f"{line}\n")
    sys.stderr.flush()


def sanitize_url(url: str) -> str:
    parsed = urlparse(url)
    if not parsed.path:
        return "<unknown>"
    if parsed.query:
        return f"{parsed.path}?<redacted>"
    return parsed.path


def parse_bool(value: Any, fallback: bool) -> bool:
    if value is None:
        return fallback
    normalized = str(value).strip().lower()
    if normalized in {"1", "true", "yes", "y", "on"}:
        return True
    if normalized in {"0", "false", "no", "n", "off"}:
        return False
    return fallback


def parse_int(value: Any, fallback: int, min_value: int, max_value: int) -> int:
    try:
        parsed = int(str(value))
    except (TypeError, ValueError):
        parsed = fallback
    if parsed < min_value:
        return min_value
    if parsed > max_value:
        return max_value
    return parsed


def normalize_governance_mode(value: str | None) -> str:
    normalized = (value or "readonly").strip().lower()
    if normalized in {"readonly", "read-only", "query-only", "ro"}:
        return "readonly"
    if normalized in {"editable", "readwrite", "read-write", "rw"}:
        return "editable"
    raise ValueError(f'Invalid governance mode "{value}". Expected readonly or editable.')


def get_required_string(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or value.strip() == "":
        raise ValueError(f'Missing required field "{field_name}".')
    return value.strip()


def get_required_key(value: Any) -> str:
    return get_required_string(value, "key")


def normalize_item_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    if value is None:
        return ""
    try:
        return json.dumps(value, ensure_ascii=False)
    except (TypeError, ValueError):
        return str(value)


def has_illegal_key_chars(key: str) -> bool:
    return "/" in key or "\\" in key


def encode_path_segment(value: Any) -> str:
    return quote(str(value), safe="")


def omit_items_field(namespace_detail: Any) -> Any:
    if not isinstance(namespace_detail, dict):
        return namespace_detail
    copied = dict(namespace_detail)
    copied.pop("items", None)
    return copied


def build_runtime_config(args: argparse.Namespace, env: dict[str, str]) -> RuntimeConfig:
    portal_url = (args.portal_url or env.get("APOLLO_PORTAL_URL") or "").strip()
    username = (args.username or env.get("APOLLO_USERNAME") or "").strip()
    password = (args.password or env.get("APOLLO_PASSWORD") or "").strip()
    login_submit = (args.login_submit or env.get("APOLLO_LOGIN_SUBMIT") or DEFAULT_LOGIN_SUBMIT).strip()
    governance_mode = normalize_governance_mode(
        args.governance_mode or env.get("APOLLO_GOVERNANCE_MODE") or "readonly"
    )
    operator = (args.operator or env.get("APOLLO_OPERATOR") or "").strip() or None
    timeout_ms = parse_int(
        args.timeout_ms or env.get("APOLLO_TIMEOUT_MS") or 10000,
        fallback=10000,
        min_value=1000,
        max_value=120000,
    )
    log_level = normalize_log_level(args.log_level or env.get("MCP_APOLLO_LOG_LEVEL") or "WARN")
    debug_http = parse_bool(
        (args.debug_http if args.debug_http else None) or env.get("MCP_APOLLO_DEBUG_HTTP"),
        False,
    )

    configure_logging(log_level, debug_http)

    if not portal_url:
        raise ValueError("Missing Apollo portal URL. Use --portal-url or APOLLO_PORTAL_URL.")
    if not username:
        raise ValueError("Missing Apollo username. Use --username or APOLLO_USERNAME.")
    if not password:
        raise ValueError("Missing Apollo password. Use --password or APOLLO_PASSWORD.")
    if governance_mode == "editable" and not operator:
        raise ValueError("Editable mode requires --operator (or APOLLO_OPERATOR).")

    defaults = Defaults(
        app_id=(args.default_app_id or env.get("APOLLO_DEFAULT_APP_ID") or "").strip() or None,
        env=(args.default_env or env.get("APOLLO_DEFAULT_ENV") or "").strip() or None,
        cluster_name=(args.default_cluster or env.get("APOLLO_DEFAULT_CLUSTER") or "default").strip() or "default",
        namespace_name=(args.default_namespace or env.get("APOLLO_DEFAULT_NAMESPACE") or "").strip() or None,
    )

    config = RuntimeConfig(
        portal_url=portal_url,
        username=username,
        password=password,
        login_submit=login_submit,
        governance_mode=governance_mode,
        operator=operator,
        timeout_ms=timeout_ms,
        defaults=defaults,
        auth_mode="portal_session",
        log_level=log_level,
        debug_http=debug_http,
    )

    log_event(
        "INFO",
        "Runtime config prepared",
        governanceMode=config.governance_mode,
        authMode=config.auth_mode,
        portalConfigured=bool(config.portal_url),
        usernameConfigured=bool(config.username),
        hasOperator=config.operator is not None,
        defaultAppId=config.defaults.app_id,
        defaultEnv=config.defaults.env,
        defaultCluster=config.defaults.cluster_name,
        defaultNamespace=config.defaults.namespace_name,
    )
    return config


def resolve_scope(input_args: dict[str, Any], defaults: Defaults) -> Scope:
    return Scope(
        app_id=get_required_string(input_args.get("appId") or defaults.app_id, "appId"),
        env=get_required_string(input_args.get("env") or defaults.env, "env"),
        cluster_name=get_required_string(input_args.get("clusterName") or defaults.cluster_name, "clusterName"),
        namespace_name=get_required_string(
            input_args.get("namespaceName") or defaults.namespace_name,
            "namespaceName",
        ),
    )


def to_tool_text(payload: Any) -> dict[str, Any]:
    return {"content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False, indent=2)}]}


def format_error(error: Exception) -> str:
    if isinstance(error, ApolloHttpError):
        if error.payload is None:
            return str(error)
        return f"{error} | payload={json.dumps(error.payload, ensure_ascii=False)}"
    return str(error)


def build_tools(config: RuntimeConfig) -> list[dict[str, Any]]:
    tools: list[dict[str, Any]] = [
        {
            "name": "apollo_get_namespace_configs",
            "description": "Query all configs under a namespace/environment/cluster in Apollo Portal management API.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "appId": {"type": "string", "description": "Apollo appId. Falls back to startup default."},
                    "env": {"type": "string", "description": "Apollo env (required if no startup default-env)."},
                    "clusterName": {
                        "type": "string",
                        "description": "Apollo cluster name. Falls back to startup default cluster.",
                    },
                    "namespaceName": {
                        "type": "string",
                        "description": "Apollo namespace name. Falls back to startup default namespace.",
                    },
                    "pageSize": {"type": "integer", "description": "Page size (1-500). Default 200."},
                    "maxItems": {"type": "integer", "description": "Maximum items to return (1-10000). Default 1000."},
                },
            },
        },
        {
            "name": "apollo_get_key",
            "description": "Query a single key in Apollo namespace/environment/cluster.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "appId": {"type": "string", "description": "Apollo appId. Falls back to startup default."},
                    "env": {"type": "string", "description": "Apollo env (required if no startup default-env)."},
                    "clusterName": {
                        "type": "string",
                        "description": "Apollo cluster name. Falls back to startup default cluster.",
                    },
                    "namespaceName": {
                        "type": "string",
                        "description": "Apollo namespace name. Falls back to startup default namespace.",
                    },
                    "key": {"type": "string", "description": "Config key to query."},
                },
                "required": ["key"],
            },
        },
    ]

    if config.governance_mode == "editable":
        tools.append(
            {
                "name": "apollo_edit_key",
                "description": "Edit or create a key in Apollo Portal management API.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "appId": {"type": "string", "description": "Apollo appId. Falls back to startup default."},
                        "env": {"type": "string", "description": "Apollo env (required if no startup default-env)."},
                        "clusterName": {
                            "type": "string",
                            "description": "Apollo cluster name. Falls back to startup default cluster.",
                        },
                        "namespaceName": {
                            "type": "string",
                            "description": "Apollo namespace name. Falls back to startup default namespace.",
                        },
                        "key": {"type": "string", "description": "Config key to edit."},
                        "value": {"description": "Config value. Non-string values are JSON serialized."},
                        "comment": {"type": "string", "description": "Optional change comment."},
                        "createIfNotExists": {
                            "type": "boolean",
                            "description": "Create key when not exists. Default true.",
                        },
                    },
                    "required": ["key", "value"],
                },
            }
        )

    return tools


def handle_tool_call(
    params: dict[str, Any],
    config: RuntimeConfig,
    apollo: ApolloClientProtocol,
) -> dict[str, Any]:
    name = params.get("name")
    arguments = params.get("arguments")
    if not isinstance(name, str) or name == "":
        raise ValueError('tools/call missing "name".')
    if not isinstance(arguments, dict):
        arguments = {}

    log_event("INFO", "Tool call", tool=name)

    if name == "apollo_get_namespace_configs":
        scope = resolve_scope(arguments, config.defaults)
        page_size = parse_int(arguments.get("pageSize", 200), 200, 1, 500)
        max_items = parse_int(arguments.get("maxItems", 1000), 1000, 1, 10000)

        namespace_detail = apollo.get_namespace(scope, fill_item_detail=False)

        items: list[Any] = []
        page = 0
        total: int | None = None
        truncated = False

        while len(items) < max_items:
            page_result = apollo.list_namespace_items(scope, page=page, size=page_size)
            content = page_result.get("content") if isinstance(page_result, dict) else None
            page_items = content if isinstance(content, list) else []

            if isinstance(page_result, dict) and isinstance(page_result.get("total"), int):
                total = page_result["total"]

            if not page_items:
                break

            items.extend(page_items)
            if len(items) >= max_items:
                items = items[:max_items]
                truncated = True
                break

            if total is not None and len(items) >= total:
                break
            if len(page_items) < page_size:
                break

            page += 1
            if CURRENT_DEBUG_HTTP:
                log_event("DEBUG", "Namespace pagination", tool=name, page=page, fetched=len(items))

        if total is not None and total > len(items):
            truncated = True

        return to_tool_text(
            {
                "scope": scope.to_dict(),
                "governanceMode": config.governance_mode,
                "authMode": config.auth_mode,
                "namespace": omit_items_field(namespace_detail),
                "stats": {
                    "total": total if total is not None else len(items),
                    "fetched": len(items),
                    "pageSize": page_size,
                    "maxItems": max_items,
                    "truncated": truncated,
                },
                "items": items,
            }
        )

    if name == "apollo_get_key":
        scope = resolve_scope(arguments, config.defaults)
        key = get_required_key(arguments.get("key"))
        log_event(
            "DEBUG",
            "Get key",
            appId=scope.app_id,
            env=scope.env,
            cluster=scope.cluster_name,
            namespace=scope.namespace_name,
            key=key,
        )
        item = apollo.get_item(scope, key)
        return to_tool_text(
            {
                "scope": scope.to_dict(),
                "authMode": config.auth_mode,
                "key": key,
                "item": item,
            }
        )

    if name == "apollo_edit_key":
        if config.governance_mode != "editable":
            raise ValueError("governance-mode is readonly; editing is blocked.")

        scope = resolve_scope(arguments, config.defaults)
        key = get_required_key(arguments.get("key"))
        if "value" not in arguments:
            raise ValueError('Missing required field "value".')

        operator = config.operator
        if not operator:
            raise ValueError("operator is required in editable mode.")

        value = normalize_item_value(arguments["value"])
        comment = None
        if "comment" in arguments and arguments["comment"] is not None:
            comment = str(arguments["comment"])
        create_if_not_exists = parse_bool(arguments.get("createIfNotExists"), True)

        log_event(
            "WARN",
            "Edit key request",
            appId=scope.app_id,
            env=scope.env,
            cluster=scope.cluster_name,
            namespace=scope.namespace_name,
            key=key,
            operator=operator,
        )

        item = apollo.upsert_item(
            scope=scope,
            key=key,
            value=value,
            operator=operator,
            comment=comment,
            create_if_not_exists=create_if_not_exists,
        )

        return to_tool_text(
            {
                "scope": scope.to_dict(),
                "authMode": config.auth_mode,
                "key": key,
                "operator": operator,
                "createIfNotExists": create_if_not_exists,
                "item": item,
                "note": "Change saved to namespace. Release may still be required in Apollo.",
            }
        )

    raise ValueError(f'Unknown tool "{name}".')


def to_fastmcp_log_level(level: str) -> str:
    if level == "WARN":
        return "WARNING"
    return level


def extract_tool_text(result: dict[str, Any]) -> str:
    content = result.get("content")
    if isinstance(content, list) and content:
        first = content[0]
        if isinstance(first, dict):
            text = first.get("text")
            if isinstance(text, str):
                return text
    return json.dumps(result, ensure_ascii=False, indent=2)


def create_fastmcp_server(config: RuntimeConfig, apollo: ApolloClientProtocol) -> FastMCP:
    mode_label = "read-only" if config.governance_mode == "readonly" else "read-write"
    mcp = FastMCP(
        "mcp-apollo-config",
        instructions=(
            "MCP server for Apollo Config Center using portal username/password session login. "
            f"Current mode: {mode_label}. Use tools to query namespace configs, query a key, "
            "and optionally edit a key in editable mode."
        ),
        log_level=to_fastmcp_log_level(config.log_level),
    )

    def call_tool(name: str, arguments: dict[str, Any]) -> str:
        try:
            result = handle_tool_call(
                {"name": name, "arguments": arguments},
                config=config,
                apollo=apollo,
            )
            return extract_tool_text(result)
        except Exception as error:
            return f"Error: {format_error(error)}"

    @mcp.tool(
        name="apollo_get_namespace_configs",
        description="Query all configs under a namespace/environment/cluster in Apollo.",
    )
    def apollo_get_namespace_configs(
        appId: str | None = None,
        env: str | None = None,
        clusterName: str | None = None,
        namespaceName: str | None = None,
        pageSize: int = 200,
        maxItems: int = 1000,
    ) -> str:
        """Query namespace configs.

        Args:
            appId: Apollo appId. Falls back to startup default when omitted.
            env: Apollo environment, for example DEV or TEST.
            clusterName: Apollo cluster name.
            namespaceName: Apollo namespace name.
            pageSize: Page size for paging.
            maxItems: Maximum number of items returned.
        """
        return call_tool(
            "apollo_get_namespace_configs",
            {
                "appId": appId,
                "env": env,
                "clusterName": clusterName,
                "namespaceName": namespaceName,
                "pageSize": pageSize,
                "maxItems": maxItems,
            },
        )

    @mcp.tool(
        name="apollo_get_key",
        description="Query a single key in a namespace/environment/cluster in Apollo.",
    )
    def apollo_get_key(
        key: str,
        appId: str | None = None,
        env: str | None = None,
        clusterName: str | None = None,
        namespaceName: str | None = None,
    ) -> str:
        """Query one Apollo key.

        Args:
            key: Config key to query.
            appId: Apollo appId. Falls back to startup default when omitted.
            env: Apollo environment, for example DEV or TEST.
            clusterName: Apollo cluster name.
            namespaceName: Apollo namespace name.
        """
        return call_tool(
            "apollo_get_key",
            {
                "appId": appId,
                "env": env,
                "clusterName": clusterName,
                "namespaceName": namespaceName,
                "key": key,
            },
        )

    if config.governance_mode == "editable":

        @mcp.tool(
            name="apollo_edit_key",
            description="Edit or create a key in Apollo. Available only in editable mode.",
        )
        def apollo_edit_key(
            key: str,
            value: Any,
            appId: str | None = None,
            env: str | None = None,
            clusterName: str | None = None,
            namespaceName: str | None = None,
            comment: str | None = None,
            createIfNotExists: bool = True,
        ) -> str:
            """Edit one Apollo key.

            Args:
                key: Config key to edit.
                value: Config value to write.
                appId: Apollo appId. Falls back to startup default when omitted.
                env: Apollo environment, for example DEV or TEST.
                clusterName: Apollo cluster name.
                namespaceName: Apollo namespace name.
                comment: Optional change comment.
                createIfNotExists: Create key if it does not exist.
            """
            return call_tool(
                "apollo_edit_key",
                {
                    "appId": appId,
                    "env": env,
                    "clusterName": clusterName,
                    "namespaceName": namespaceName,
                    "key": key,
                    "value": value,
                    "comment": comment,
                    "createIfNotExists": createIfNotExists,
                },
            )

    return mcp


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mcp-apollo-config",
        description="MCP server for Apollo Config Center (portal session auth)",
    )
    parser.add_argument("--portal-url", help="Apollo portal URL")
    parser.add_argument("--username", help="Apollo login username")
    parser.add_argument("--password", help="Apollo login password")
    parser.add_argument(
        "--login-submit",
        default=None,
        help="Login submit field value (default: Chinese login label)",
    )
    parser.add_argument(
        "--governance-mode",
        default=None,
        help="readonly|editable (default: readonly)",
    )
    parser.add_argument("--operator", default=None, help="Required in editable mode")
    parser.add_argument("--default-app-id", default=None, help="Default appId")
    parser.add_argument("--default-env", default=None, help="Default env (e.g. DEV, TEST)")
    parser.add_argument(
        "--default-cluster",
        default=None,
        help="Default cluster name (default: default)",
    )
    parser.add_argument("--default-namespace", default=None, help="Default namespace")
    parser.add_argument(
        "--timeout-ms",
        default=None,
        help="HTTP timeout in milliseconds (default: 10000)",
    )
    parser.add_argument(
        "--log-level",
        default=None,
        help="Log level: DEBUG|INFO|WARN|ERROR (default: WARN)",
    )
    parser.add_argument(
        "--debug-http",
        action="store_true",
        help="Enable detailed HTTP request/response debug logs",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    try:
        config = build_runtime_config(args, dict(os.environ))
    except Exception as error:
        parser.exit(1, f"{error}\n")
        return

    configure_logging(config.log_level, config.debug_http)

    apollo: ApolloClientProtocol = ApolloPortalSessionClient(config)
    mcp = create_fastmcp_server(config, apollo)

    log_event(
        "INFO",
        "Started with governance-mode="
        f"{config.governance_mode}, auth={config.auth_mode}, "
        f"defaults(appId={config.defaults.app_id or '-'}, env={config.defaults.env or '-'}, "
        f"cluster={config.defaults.cluster_name}, namespace={config.defaults.namespace_name or '-'})",
    )
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
