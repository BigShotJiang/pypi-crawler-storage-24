"""finasys metadata."""

__version__ = "0.1.2"
