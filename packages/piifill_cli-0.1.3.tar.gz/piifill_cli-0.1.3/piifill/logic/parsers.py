import io
import json
import multiprocessing
from pathlib import Path
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from concurrent.futures import ProcessPoolExecutor

from ..engine.manager import FiltrationManager

def _parallel_worker(lines: List[str], mode: str):
    """Picklable worker for line-based parallel processing."""
    from ..engine.manager import FiltrationManager
    service = FiltrationManager()
    processed = []
    for line in lines:
        if not line.strip():
            processed.append(line)
            continue
        # Generic line sanitization
        processed.append(service.sanitize(line, mode) + "\n")
    return processed, service.get_session_report()

class PIIFILLParallel:
    """Utility for multi-core file processing."""
    @staticmethod
    def process_line_based(input_path: Path, output_path: Path, engine: FiltrationManager, mode: str, progress_callback=None):
        chunk_size = 5000 
        file_size = input_path.stat().st_size
        processed_bytes = 0
        
        with open(input_path, "r", encoding="utf-8", errors="replace") as fin, \
             open(output_path, "w", encoding="utf-8") as fout, \
             ProcessPoolExecutor(max_workers=multiprocessing.cpu_count()) as executor:
            
            lines_buffer = []
            futures = []
            
            for line in fin:
                lines_buffer.append(line)
                processed_bytes += len(line.encode('utf-8'))
                
                if len(lines_buffer) >= chunk_size:
                    futures.append(executor.submit(_parallel_worker, lines_buffer, mode))
                    lines_buffer = []
                    if len(futures) > multiprocessing.cpu_count() * 2:
                        PIIFILLParallel._drain(futures, fout, engine, progress_callback, processed_bytes, file_size)
            
            if lines_buffer:
                futures.append(executor.submit(_parallel_worker, lines_buffer, mode))
            PIIFILLParallel._drain(futures, fout, engine, progress_callback, processed_bytes, file_size, finalize=True)

    @staticmethod
    def _drain(futures, fout, engine, progress_callback, processed_bytes, file_size, finalize=False):
        to_drain = futures if finalize else futures[:len(futures)//2]
        for fut in to_drain:
            res_lines, report = fut.result()
            fout.writelines(res_lines)
            engine.last_detection_count += report['pii_count']
            for k, v in report['pii_breakdown'].items():
                engine.last_detection_breakdown[k] = engine.last_detection_breakdown.get(k, 0) + v
        if not finalize:
            del futures[:len(futures)//2]
        else:
            futures.clear()
        if progress_callback:
            progress_callback(processed_bytes / file_size)

class IParser(ABC):
    @abstractmethod
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        pass

    def parse_file(self, input_path: Path, output_path: Path, engine: FiltrationManager, mode: str, progress_callback=None):
        """Streaming-capable file processing. Default implementation uses memory."""
        with open(input_path, "rb") as f:
            content = f.read()
        sanitized = self.parse_and_sanitize(content, engine, mode, progress_callback)
        with open(output_path, "wb") as f:
            f.write(sanitized)

class TextParser(IParser):
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        try:
            text = content.decode('utf-8')
        except UnicodeDecodeError:
            text = content.decode('utf-8', errors='replace')
        sanitized = engine.sanitize(text, mode)
        return sanitized.encode('utf-8')

    def parse_file(self, input_path: Path, output_path: Path, engine: FiltrationManager, mode: str, progress_callback=None):
        """Streaming sanitization for giant text files with PIIFILL Parallel."""
        file_size = input_path.stat().st_size
        if file_size > 20 * 1024 * 1024:
            PIIFILLParallel.process_line_based(input_path, output_path, engine, mode, progress_callback)
            return
        
        # High-performance streaming fallback
        MAX_PII_LEN = 4096 
        CHUNK_SIZE = 256 * 1024 # 256KB chunks
        
        file_size = input_path.stat().st_size
        processed = 0
        overlap = ""
        
        with open(input_path, "rb") as fin, open(output_path, "wb") as fout:
            while True:
                chunk_bytes = fin.read(CHUNK_SIZE)
                if not chunk_bytes:
                    # Final flush of remaining overlap
                    if overlap:
                        fout.write(engine.sanitize(overlap, mode).encode('utf-8'))
                    break
                
                try:
                    chunk_text = chunk_bytes.decode('utf-8', errors='replace')
                except:
                    chunk_text = chunk_bytes.decode('latin1', errors='replace')
                
                # Combine tail of last chunk with current chunk
                combined = overlap + chunk_text
                entities = engine.detect(combined)
                
                # Determine safe boundary to split 
                # We only sanitize what is definitely NOT part of a truncated entity
                boundary = len(combined) - MAX_PII_LEN
                
                if boundary <= 0:
                    overlap = combined
                    processed += len(chunk_bytes)
                    continue

                # Filter entities that start before our safe boundary
                maskable = [e for e in entities if e.start < boundary]
                
                # Sanitize the safe segment
                prefix = combined[:boundary]
                sanitized_prefix = engine.mask_entities(prefix, maskable, mode)
                fout.write(sanitized_prefix.encode('utf-8'))
                
                # The rest becomes overlap for next read
                overlap = combined[boundary:]
                processed += len(chunk_bytes)
                
                if progress_callback:
                    progress_callback(processed / file_size)

class JSONParser(IParser):
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        data = json.loads(content.decode('utf-8'))
        
        def sanitize_node(node):
            if isinstance(node, str):
                return engine.sanitize(node, mode)
            elif isinstance(node, list):
                return [sanitize_node(item) for item in node]
            elif isinstance(node, dict):
                return {k: sanitize_node(v) for k, v in node.items()}
            return node
            
        sanitized_data = sanitize_node(data)
        return json.dumps(sanitized_data, indent=2).encode('utf-8')

class CSVParser(IParser):
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        import pandas as pd
        try:
            text = content.decode('utf-8')
        except UnicodeDecodeError:
            try:
                text = content.decode('latin1')
            except Exception:
                text = content.decode('utf-8', errors='replace')
                
        # Force all columns to strings to prevent numerical PII skips
        df = pd.read_csv(io.StringIO(text), dtype=str)
        
        # Sanitize headers
        df.columns = [engine.sanitize(str(col), mode) for col in df.columns]
        
        for col in df.columns:
            df[col] = df[col].apply(lambda x: engine.sanitize(str(x), mode) if pd.notnull(x) else x)
        
        output = io.BytesIO()
        df.to_csv(output, index=False)
        return output.getvalue()

    def parse_file(self, input_path: Path, output_path: Path, engine: FiltrationManager, mode: str, progress_callback=None):
        """Streaming sanitization for giant CSV files."""
        import pandas as pd
        chunk_size = 10000 
        file_size = input_path.stat().st_size
        processed_bytes = 0
        
        first_chunk = True
        with open(output_path, "wb") as fout:
            # Enforce dtype=str for all columns to catch numerical PII
            reader = pd.read_csv(input_path, chunksize=chunk_size, dtype=str)
            
            for chunk in reader:
                # Sanitize headers for the first chunk
                if first_chunk:
                    chunk.columns = [engine.sanitize(str(col), mode) for col in chunk.columns]
                
                for col in chunk.columns:
                    chunk[col] = chunk[col].apply(lambda x: engine.sanitize(str(x), mode) if pd.notnull(x) else x)
                
                chunk.to_csv(fout, index=False, header=first_chunk)
                first_chunk = False
                
                if progress_callback:
                    # Rough estimate since reader doesn't give byte offset easily
                    progress_callback(0.5)

class XLSXParser(IParser):
    """
    Optimized Excel Parser with sampling-based column identification.
    """
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        import pandas as pd
        try:
            df_dict = pd.read_excel(io.BytesIO(content), sheet_name=None, engine='openpyxl')
        except Exception:
            df_dict = pd.read_excel(io.BytesIO(content), sheet_name=None)
            
        total_sheets = len(df_dict)
        processed_sheets = 0
        
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
                # Sanitize sheet name
                sheet_name_sanitized = engine.sanitize(sheet_name, mode)
                
                # Sanitize headers
                df.columns = [engine.sanitize(str(col), mode) for col in df.columns]
                
                # Process all columns to catch numeric PII
                total_cols = len(df.columns)
                for i, col in enumerate(df.columns):
                    # Continue using sampling for object-like columns for speed
                    # But also check numeric-like columns if they might be PII
                    sample = df[col].dropna().head(10)
                    dominant_type = None
                    
                    if not sample.empty:
                        detections = [engine.detect(str(x)) for x in sample]
                        type_counts = {}
                        for entities in detections:
                            if entities:
                                etype = entities[0].entity_type
                                type_counts[etype] = type_counts.get(etype, 0) + 1
                        
                        for etype, count in type_counts.items():
                            if count >= 7: # High confidence
                                dominant_type = etype
                                break
                    
                    if dominant_type:
                        df[col] = df[col].apply(lambda x: engine.fast_sanitize(str(x), dominant_type, mode) if pd.notnull(x) else x)
                        engine.last_detection_count += len(df)
                    else:
                        df[col] = df[col].apply(lambda x: engine.sanitize(str(x), mode) if pd.notnull(x) else x)
                    
                    if progress_callback:
                        col_progress = (i + 1) / total_cols if total_cols > 0 else 1
                        total_progress = (processed_sheets + col_progress) / total_sheets
                        progress_callback(total_progress)

                df.to_excel(writer, sheet_name=sheet_name_sanitized, index=False)
                processed_sheets += 1
                
        return output.getvalue()

class SQLParser(IParser):
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        try:
            sql = content.decode('utf-8')
        except UnicodeDecodeError:
            sql = content.decode('latin1', errors='replace')
            
        lines = sql.splitlines()
        sanitized_lines = []
        for line in lines:
            if line.strip().upper().startswith("INSERT INTO"):
                sanitized_lines.append(engine.sanitize(line, mode))
            else:
                sanitized_lines.append(line)
        return "\n".join(sanitized_lines).encode('utf-8')

    def parse_file(self, input_path: Path, output_path: Path, engine: FiltrationManager, mode: str, progress_callback=None):
        """Streaming sanitization for giant SQL dumps with PIIFILL Parallel."""
        file_size = input_path.stat().st_size
        if file_size > 20 * 1024 * 1024:
            PIIFILLParallel.process_line_based(input_path, output_path, engine, mode, progress_callback)
            return

        processed = 0

class JSONLParser(IParser):
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        lines = content.decode('utf-8', errors='replace').splitlines()
        sanitized_lines = []
        for line in lines:
            if not line.strip():
                sanitized_lines.append("")
                continue
            try:
                data = json.loads(line)
                def sanitize_node(node):
                    if isinstance(node, str): return engine.sanitize(node, mode)
                    elif isinstance(node, list): return [sanitize_node(item) for item in node]
                    elif isinstance(node, dict): return {k: sanitize_node(v) for k, v in node.items()}
                    return node
                sanitized_lines.append(json.dumps(sanitize_node(data)))
            except:
                sanitized_lines.append(engine.sanitize(line, mode))
        return "\n".join(sanitized_lines).encode('utf-8')

    def parse_file(self, input_path: Path, output_path: Path, engine: FiltrationManager, mode: str, progress_callback=None):
        """Streaming sanitization for giant JSONL files with PIIFILL Parallel."""
        file_size = input_path.stat().st_size
        if file_size > 20 * 1024 * 1024:
            PIIFILLParallel.process_line_based(input_path, output_path, engine, mode, progress_callback)
            return

        processed = 0
        with open(input_path, "r", encoding="utf-8", errors="replace") as fin, \
             open(output_path, "w", encoding="utf-8") as fout:
            for line in fin:
                if line.strip():
                    try:
                        data = json.loads(line)
                        def sanitize_node(node):
                            if isinstance(node, str): return engine.sanitize(node, mode)
                            elif isinstance(node, list): return [sanitize_node(item) for item in node]
                            elif isinstance(node, dict): return {k: sanitize_node(v) for k, v in node.items()}
                            return node
                        sanitized_data = sanitize_node(data)
                        fout.write(json.dumps(sanitized_data) + "\n")
                    except Exception:
                        fout.write(engine.sanitize(line, mode) + "\n")
                else:
                    fout.write("\n")
                processed += len(line.encode('utf-8'))
                if progress_callback: progress_callback(processed / file_size)

class PDFParser(IParser):
    """
    Advanced PDF Parser using PyMuPDF (fitz) for high-performance visual redaction.
    """
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        import fitz  # PyMuPDF
        
        doc = fitz.open(stream=content, filetype="pdf")
        pii_count = 0
        mode = mode.upper()
        
        for page in doc:
            text = page.get_text()
            entities = engine.detect(text)
            
            # Optimization: collect all unique values to search for them once per page
            unique_values = {}
            for ent in entities:
                if ent.value not in unique_values:
                    unique_values[ent.value] = ent.entity_type
            
            for val, etype in unique_values.items():
                areas = page.search_for(val)
                for rect in areas:
                    pii_count += 1
                    if mode == "REDACT":
                        page.add_redact_annot(rect, fill=(0, 0, 0))
                    elif mode in ["MASK", "TOKENIZE"]:
                        replacement = engine.masker.apply_masking(val, etype) if mode == "MASK" else engine.masker.get_token(val, etype)
                        page.add_redact_annot(rect, text=replacement, fill=(0, 0, 0), fontname="helv", fontsize=7)
                    else:
                        page.add_redact_annot(rect, fill=(0, 0, 0))
            
            page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_NONE)
            
        engine.last_detection_count += pii_count
        
        output = io.BytesIO()
        doc.save(output, garbage=4, deflate=True)
        doc.close()
        return output.getvalue()

class DocxParser(IParser):
    def parse_and_sanitize(self, content: bytes, engine: FiltrationManager, mode: str, progress_callback=None) -> bytes:
        import docx
        doc = docx.Document(io.BytesIO(content))
        for para in doc.paragraphs:
            para.text = engine.sanitize(para.text, mode)
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    cell.text = engine.sanitize(cell.text, mode)
                    
        output = io.BytesIO()
        doc.save(output)
        return output.getvalue()
