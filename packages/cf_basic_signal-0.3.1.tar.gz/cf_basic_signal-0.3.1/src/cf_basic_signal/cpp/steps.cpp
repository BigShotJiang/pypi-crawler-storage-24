﻿#include <cmath>
#include <cstdint>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "cf_step_abi.h"
#include "cf_step_utils.h"
#include "cf_plugin_table.h"
#include "cf_vector_f64.h"
#include "cf_basic_signal_signature_hashes.h"

namespace
{

  [[maybe_unused]] static const char *kEmitAll = "all";
  [[maybe_unused]] static const char *kEmitFirst = "first";
  [[maybe_unused]] static const char *kEmitLatest = "latest";
  [[maybe_unused]] static const char *kEmitLast = "last";
  static std::unordered_map<std::string, std::vector<double>> g_fifo_state;
  static std::mutex g_fifo_mutex;

  static CfStatusCode call_fifo_window_buffer(
      CfCallContext *ctx,
      const CfValueHandle *params,
      size_t n_params,
      const CfValueHandle *inputs,
      size_t n_inputs,
      CfValueHandle *outputs,
      size_t n_outputs)
  {
    (void)n_params;
    (void)n_inputs;
    (void)n_outputs;
    using S = cf_sig::FifoWindowBufferStep;

    std::string emit_mode = cf_handle_to_string(&params[S::P_emitMode]);

    int64_t stride = 0;
    (void)cf_read_i64(&params[S::P_stride], stride);

    int64_t window_size = 0;
    (void)cf_read_i64(&params[S::P_windowSize], window_size);

    std::vector<double> values;
    if (inputs[S::I_value_port].storage_type == CF_STORAGE_F64 &&
        inputs[S::I_value_port].data &&
        inputs[S::I_value_port].size >= sizeof(double))
    {
      values.push_back(*reinterpret_cast<const double *>(inputs[S::I_value_port].data));
    }
    else if (inputs[S::I_value_port].storage_type == CF_STORAGE_VECTOR_F64)
    {
      const CfVectorF64 *vector = cf_as_vector_f64(&inputs[S::I_value_port]);
      if (vector && vector->data && vector->length > 0)
      {
        values.assign(vector->data, vector->data + vector->length);
      }
    }
    std::string state_key = cf_handle_to_string(&params[S::P_stateKey]);
    int64_t max_history = 0;
    (void)cf_read_i64(&params[S::P_maxHistory], max_history);
    if (!state_key.empty())
    {
      {
        std::lock_guard<std::mutex> lock(g_fifo_mutex);
        auto &buffer = g_fifo_state[state_key];
        if (!values.empty())
        {
          buffer.insert(buffer.end(), values.begin(), values.end());
        }
        if (max_history > 0 && buffer.size() > static_cast<size_t>(max_history))
        {
          size_t trim = buffer.size() - static_cast<size_t>(max_history);
          buffer.erase(buffer.begin(), buffer.begin() + static_cast<std::vector<double>::difference_type>(trim));
        }
        values = buffer;
      }
    }

    if (values.empty())
    {
      return CF_STATUS_INVALID;
    }

    size_t window_len = static_cast<size_t>(window_size);
    if (values.size() < window_len)
    {
      return CF_STATUS_INVALID;
    }
    if (values.size() == window_len)
    {
      return cf_out_vector_f64(ctx, &outputs[S::O_values], values.data(), values.size());
    }

    size_t max_start = values.size() - window_len;
    size_t start = max_start;
    if (emit_mode == kEmitFirst)
    {
      start = 0;
    }
    else
    {
      size_t stride_sz = static_cast<size_t>(stride);
      if (stride_sz > 1)
      {
        start = (max_start / stride_sz) * stride_sz;
      }
    }

    using diff_t = std::vector<double>::difference_type;
    std::vector<double> window(values.begin() + static_cast<diff_t>(start),
                               values.begin() + static_cast<diff_t>(start + window_len));
    return cf_out_vector_f64(ctx, &outputs[S::O_values], window.data(), window.size());
  }

  static CfStatusCode call_fifo_state_reset(
      CfCallContext *ctx,
      const CfValueHandle *params,
      size_t n_params,
      const CfValueHandle *,
      size_t,
      CfValueHandle *outputs,
      size_t n_outputs)
  {
    (void)n_params;
    (void)n_outputs;
    using S = cf_sig::FifoStateResetStep;
    std::string state_key = cf_handle_to_string(&params[S::P_stateKey]);
    {
      std::lock_guard<std::mutex> lock(g_fifo_mutex);
      if (state_key.empty())
      {
        g_fifo_state.clear();
      }
      else
      {
        g_fifo_state.erase(state_key);
      }
    }
    const char *status = state_key.empty() ? "fifo state cleared" : "fifo state cleared for key";
    return cf_out_string(ctx, &outputs[S::O_status_port], status);
  }

  static CfStatusCode call_average(
      CfCallContext *ctx,
      const CfValueHandle *params,
      size_t n_params,
      const CfValueHandle *inputs,
      size_t n_inputs,
      CfValueHandle *outputs,
      size_t n_outputs)
  {
    (void)n_params;
    (void)n_inputs;
    (void)n_outputs;
    using S = cf_sig::AverageStep;

    const CfVectorF64 *vector = cf_as_vector_f64(&inputs[S::I_values]);
    if (!vector || !vector->data || vector->length == 0)
    {
      return CF_STATUS_INVALID;
    }

    double mean = 0.0;
    const CfValueHandle *method = &params[S::P_averageMethod];
    if (cf_handle_equals(method, "geometric"))
    {
      double sum_log = 0.0;
      for (size_t i = 0; i < vector->length; ++i)
      {
        double v = vector->data[i];
        if (v <= 0.0)
          return CF_STATUS_INVALID;
        sum_log += std::log(v);
      }
      mean = std::exp(sum_log / static_cast<double>(vector->length));
    }
    else if (cf_handle_equals(method, "harmonic"))
    {
      double sum_inv = 0.0;
      for (size_t i = 0; i < vector->length; ++i)
      {
        double v = vector->data[i];
        if (v == 0.0)
          return CF_STATUS_INVALID;
        sum_inv += 1.0 / v;
      }
      mean = static_cast<double>(vector->length) / sum_inv;
    }
    else
    {
      double sum = 0.0;
      for (size_t i = 0; i < vector->length; ++i)
        sum += vector->data[i];
      mean = sum / static_cast<double>(vector->length);
    }

    double variance = 0.0;
    for (size_t i = 0; i < vector->length; ++i)
    {
      double diff = vector->data[i] - mean;
      variance += diff * diff;
    }
    variance /= static_cast<double>(vector->length);
    double std_err = std::sqrt(variance) / std::sqrt(static_cast<double>(vector->length));

    if (cf_out_f64(ctx, &outputs[S::O_mean], mean) != CF_STATUS_OK)
      return CF_STATUS_ERROR;
    if (cf_out_f64(ctx, &outputs[S::O_standard_error], std_err) != CF_STATUS_OK)
      return CF_STATUS_ERROR;
    return CF_STATUS_OK;
  }

#define CF_BASIC_SIGNAL_STEPS(X) \
  X(cf_generated::kFifoWindowBufferStepIri, cf_generated::kFifoWindowBufferStepSigHash, call_fifo_window_buffer, nullptr) \
  X(cf_generated::kAverageStepIri, cf_generated::kAverageStepSigHash, call_average, nullptr) \
  X(cf_generated::kFifoStateResetStepIri, cf_generated::kFifoStateResetStepSigHash, call_fifo_state_reset, nullptr)

} // namespace

CF_DEFINE_STEP_TABLE(CF_BASIC_SIGNAL_STEPS)

