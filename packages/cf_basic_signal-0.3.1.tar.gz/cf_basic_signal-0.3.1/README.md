# cf.basic.signal StepPackage

Signal-processing steps packaged for Cogniflow (FIFO buffer and statistical averages).

> **Note:** Dev/demo/benchmark steps (`InlineSource`, `OpcuaPhSource`, `OmpReductionStep`, `BudgetAwareStep`) have moved to [`cf-basic-dev`](../cf_basic_dev/README.md). This package now contains only core signal-processing steps.

## Steps

| Step | Description |
|------|-------------|
| `cfbs:FifoWindowBufferStep` | Sliding FIFO window buffer |
| `cfbs:AverageStep` | Arithmetic / geometric / harmonic mean with standard error |

## Files

- `steps.nq` - single manifest (package metadata + ontology + implementation bindings)
- `src/cf_basic_signal/cpp/steps.cpp` - C++ implementations (plugin backend)
- `examples/golden_fifo_avg.json` - minimal signal pipeline (`InlineSource` from `cf-basic-dev` -> FIFO -> Average) **(legacy)**

## Pipeline backend plugin

The package registers a C++ plugin artifact described in `steps.nq`:

- C++ ops (impl="cpp"): `fifo_window_buffer`, `average` (registered via capsule `register_cpp_op`)
- No Python fallbacks; the C++ extension is required for pipeline_backend usage

Plugin metadata (artifact path, list/resolve symbols, certification) is stored under the `cf:PluginArtifact` node in `steps.nq`.

## Quick check

1) Install package (editable or wheel) so the `cogniflow.steps` entry point exposes `steps.nq`.

2) Ingest step packages via `cf_ontology` and verify:
```python
import os
from cf_ontology import ingest_installed_step_packages, OntologyManager

os.environ["CF_ENABLE_STEP_PACKAGES"] = "1"
ingest_installed_step_packages()
om = OntologyManager()
assert om.get_step_info("cfbs:FifoWindowBufferStep")
assert om.get_step_info("cfbs:AverageStep")
```

3) (Legacy) Run the example pipeline via your runner. Expected output:
   - golden_fifo_avg: window `[4,5,6]`, mean `5.0`, small SE.

Published distribution name:

```bash
pip install cf-basic-signal
```

## Native build prerequisites

`cf_basic_signal` is built with `scikit-build-core` and CMake and requires the published SDK package at build time:

- CPython 3.13
- CMake on `PATH`
- a Windows C++ toolchain compatible with that CMake installation
- access to `cf-pipeline-sdk` from the package index

The package-local CMake currently generates the signature header through `python -m cogniflow_pipeline_sdk.siggen` and copies the built plugin artifact into the installed package's `bin/` directory.

## Publishing

`cf_basic_signal` is published with the dedicated Windows workflow:

- Workflow: `.github/workflows/cf_basic_signal_windows_publish.yml`
- Package directory: `sandcastle/cf_basic_steps/cf_basic_signal`
- PyPI tag: `cf-basic-signal-v<version>`
- TestPyPI tag: `cf-basic-signal-v<version>-test`

Local preflight:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/mimic_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_basic_signal_windows_publish.yml `
  -PackageDir sandcastle/cf_basic_steps/cf_basic_signal `
  -PythonExe py `
  -PythonVersion 3.13
```

Queue a dry-run dispatch:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/queue_windows_python_publish_workflow.ps1 `
  -WorkflowFile .github/workflows/cf_basic_signal_windows_publish.yml `
  -PackageDir sandcastle/cf_basic_steps/cf_basic_signal `
  -PublishTarget testpypi `
  -Ref main `
  -RequireLocalPass `
  -DryRun
```

Watch queued runs:

```powershell
gh run list --workflow cf_basic_signal_windows_publish.yml --limit 10
gh run watch --exit-status
```
