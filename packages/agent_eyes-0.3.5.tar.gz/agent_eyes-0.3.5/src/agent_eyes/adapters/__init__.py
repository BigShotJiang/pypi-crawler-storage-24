"""Platform-specific accessibility adapters."""
