# Changelog

## [0.5.0](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.4.2...v0.5.0) (2026-03-10)


### Features

* containerization support ([abf96d1](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/abf96d1b1f719b879f40d295b7f5c3b051de8064))

## [0.4.2](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.4.1...v0.4.2) (2026-03-10)


### Bug Fixes

* handle defaults channel ([a314b71](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/a314b7138ff104a34b9424360ccd3162cdb0294f))
* pass absolute path to rattler activation function ([3b4288d](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/3b4288dc9c67081db654b9048452361da9403186))
* use latest container plugin ([e1dd5b7](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/e1dd5b7ede7a90210fa70a99651cc1ec2d829cd6))

## [0.4.1](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.4.0...v0.4.1) (2026-03-09)


### Bug Fixes

* handle defaults channel ([a314b71](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/a314b7138ff104a34b9424360ccd3162cdb0294f))
* return list of external env directories instead of iterable (for caching) ([602530d](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/602530d8a58a282726edb4fb4ccf4277895a0407))

## [0.4.0](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.3.5...v0.4.0) (2026-03-09)


### Features

* implement test for executable to be contained in env ([b584db7](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/b584db72b51f618ff5cb6aa3f7ce68cb8f345f18))


### Bug Fixes

* adapt to latest interface ([a971374](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/a97137463bb3dfec6a9f14f48f9ccdb1072d835b))
* assert tipe for cache_asset ([bb1d560](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/bb1d560f1edbe8c7ccc5a438a384a6fc01096b8f))
* use pypi-only dependencies ([20f8c4a](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/20f8c4af484720c263ab86af789a840c98dde947))
* various small fixes ([d55d381](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/d55d381970f94abd5198221a130ba69342670f76))

## [0.3.5](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.3.4...v0.3.5) (2026-02-19)


### Bug Fixes

* improved error message ([4ff53da](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/4ff53da903cd84750507c568e0f858898f530308))

## [0.3.4](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.3.3...v0.3.4) (2026-02-18)


### Bug Fixes

* further fixes to deployment and caching in combination with enclosing environments ([8bf2448](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/8bf24484c77661a179ddc240dc5c55f3a1988c45))

## [0.3.3](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.3.2...v0.3.3) (2026-02-18)


### Bug Fixes

* enable deployment within a surrounding environment (e.g. a container) ([#11](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/issues/11)) ([f230e07](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/f230e079b3eebc6bb1162486e1ce923a16e1c4e3))

## [0.3.2](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.3.1...v0.3.2) (2025-09-19)


### Bug Fixes

* update to latest interface ([72f4ca9](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/72f4ca90971f594bb1a86428063d74b00c7c89c1))
* update to latest interface ([e806317](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/e806317efc9ebe1660cfb01425f97075e0eb66aa))

## [0.3.1](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.3.0...v0.3.1) (2025-09-15)


### Bug Fixes

* capture STDOUT of conda info commands ([314e43a](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/314e43a02b8ce0c546d08144bab7660043fa38dc))
* use latest interface ([c6b2217](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/c6b22178b4ee6b6a15b2e82839d7ea2d681db0a3))
* use proper env prefix ([7893471](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/7893471eee3379fc5dcebf3e74b594b7317d23b1))

## [0.3.0](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.2.0...v0.3.0) (2025-09-12)


### Features

* complete support for named environments ([#7](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/issues/7)) ([b38aecd](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/b38aecdc93e3058d219e2b7fe8bdfcee9d59a690))

## [0.2.0](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/compare/v0.1.0...v0.2.0) (2025-05-16)


### Features

* add pypi support via uv ([#2](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/issues/2)) ([728c71a](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/728c71a8d4d62334ddb516acb23c992b5bcb656e))
* support pinfiles ([#5](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/issues/5)) ([58faba4](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/58faba47e8bb782dea27427f8419e4e5b47a6b20))

## 0.1.0 (2025-03-08)


### Bug Fixes

* update to latest interface ([0159285](https://github.com/snakemake/snakemake-software-deployment-plugin-conda/commit/015928520a4d87bb545cd2c1ab21f45f36466738))
