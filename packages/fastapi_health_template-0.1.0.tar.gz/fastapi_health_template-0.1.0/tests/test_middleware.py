"""Tests for middleware (disclaimer, rate limiting, device auth)."""
import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_disclaimer_header_present(client: AsyncClient):
    """Every response should include the medical disclaimer header."""
    response = await client.get("/health")
    assert response.status_code == 200
    assert "X-Medical-Disclaimer" in response.headers
    assert "reference only" in response.headers["X-Medical-Disclaimer"].lower()


@pytest.mark.asyncio
async def test_rate_limit_headers(client: AsyncClient):
    """Responses should include rate limit headers."""
    response = await client.get("/api/v1/drugs/search", params={"q": "test"})
    assert "X-RateLimit-Limit" in response.headers
    assert "X-RateLimit-Remaining" in response.headers


@pytest.mark.asyncio
async def test_health_check(client: AsyncClient):
    response = await client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}


@pytest.mark.asyncio
async def test_device_id_short_rejected(client: AsyncClient):
    """A device ID shorter than 8 characters should be rejected."""
    response = await client.get("/api/v1/cabinet", headers={"X-Device-ID": "short"})
    assert response.status_code == 422


@pytest.mark.asyncio
async def test_device_id_missing_rejected(client: AsyncClient):
    """Cabinet endpoints require X-Device-ID."""
    response = await client.get("/api/v1/cabinet")
    assert response.status_code == 401
