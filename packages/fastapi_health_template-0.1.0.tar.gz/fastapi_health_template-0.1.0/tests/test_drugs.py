"""Tests for drug endpoints."""
import pytest
from httpx import AsyncClient

from app.models.drug import Drug


@pytest.mark.asyncio
async def test_search_drugs_returns_results(client: AsyncClient, sample_drugs: list[Drug]):
    response = await client.get("/api/v1/drugs/search", params={"q": "Aspirin"})
    assert response.status_code == 200
    data = response.json()
    assert data["total"] == 1
    assert data["items"][0]["item_name"] == "Aspirin 100mg"


@pytest.mark.asyncio
async def test_search_drugs_empty(client: AsyncClient, sample_drugs: list[Drug]):
    response = await client.get("/api/v1/drugs/search", params={"q": "Nonexistent"})
    assert response.status_code == 200
    assert response.json()["total"] == 0
    assert response.json()["items"] == []


@pytest.mark.asyncio
async def test_search_drugs_requires_query(client: AsyncClient):
    response = await client.get("/api/v1/drugs/search")
    assert response.status_code == 422


@pytest.mark.asyncio
async def test_get_drug_by_id(client: AsyncClient, sample_drugs: list[Drug]):
    drug = sample_drugs[0]
    response = await client.get(f"/api/v1/drugs/{drug.id}")
    assert response.status_code == 200
    assert response.json()["item_seq"] == "200001234"


@pytest.mark.asyncio
async def test_get_drug_not_found(client: AsyncClient):
    response = await client.get("/api/v1/drugs/99999")
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_get_drug_by_slug(client: AsyncClient, sample_drugs: list[Drug]):
    response = await client.get("/api/v1/drugs/by-slug/aspirin-100mg")
    assert response.status_code == 200
    assert response.json()["item_name"] == "Aspirin 100mg"
