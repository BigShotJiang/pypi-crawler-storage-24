"""Tests for interaction check endpoint."""
import pytest
from httpx import AsyncClient

from app.models.drug import Drug
from app.models.interaction import Interaction


@pytest.mark.asyncio
async def test_check_interactions_finds_known(
    client: AsyncClient, sample_drugs: list[Drug], sample_interaction: Interaction
):
    response = await client.post(
        "/api/v1/interactions/check",
        json={"item_ids": ["200001234", "200005678"]},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["total_checked"] == 1
    assert len(data["interactions"]) == 1
    assert data["interactions"][0]["severity"] == "high"
    assert "disclaimer" in data


@pytest.mark.asyncio
async def test_check_interactions_no_match(
    client: AsyncClient, sample_drugs: list[Drug]
):
    response = await client.post(
        "/api/v1/interactions/check",
        json={"item_ids": ["200001234", "UNKNOWN99"]},
    )
    assert response.status_code == 200
    data = response.json()
    assert len(data["interactions"]) == 0


@pytest.mark.asyncio
async def test_check_interactions_minimum_items(client: AsyncClient):
    response = await client.post(
        "/api/v1/interactions/check",
        json={"item_ids": ["ONLY_ONE"]},
    )
    assert response.status_code == 422


@pytest.mark.asyncio
async def test_check_interactions_reverse_order(
    client: AsyncClient, sample_drugs: list[Drug], sample_interaction: Interaction
):
    """Interaction should be found regardless of item order."""
    response = await client.post(
        "/api/v1/interactions/check",
        json={"item_ids": ["200005678", "200001234"]},
    )
    assert response.status_code == 200
    assert len(response.json()["interactions"]) == 1
