# Deployment Guide

## Quick Start (Docker)

```bash
# 1. Clone and configure
git clone https://github.com/your-org/fastapi-health-template.git
cd fastapi-health-template
cp .env.example .env
# Edit .env with your production values

# 2. Start all services
docker-compose up -d

# 3. Run database migrations
docker-compose exec app alembic upgrade head

# 4. Visit the API docs
open http://localhost:8000/docs
```

## Production Deployment

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | Yes | PostgreSQL connection string |
| `REDIS_URL` | Yes | Redis connection string |
| `SECRET_KEY` | Yes | Random secret for signing (min 32 chars) |
| `CORS_ORIGINS` | Yes | JSON array of allowed origins |
| `OPENAI_API_KEY` | No | For AI-powered interaction explanations |
| `RATE_LIMIT_PER_MINUTE` | No | Default: 60 |
| `APP_ENV` | No | `production`, `staging`, or `development` |

### Infrastructure Requirements

- **Python:** 3.11+
- **PostgreSQL:** 16+ with `pg_trgm` extension (for fuzzy search)
- **Redis:** 7+
- **Memory:** Minimum 512MB for the app container
- **CPU:** 1 vCPU minimum, 2+ recommended

### Database Setup

```sql
-- Enable required PostgreSQL extensions
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Create the database
CREATE DATABASE health_db;
```

Then run migrations:

```bash
alembic upgrade head
```

### Reverse Proxy (Nginx)

```nginx
server {
    listen 443 ssl http2;
    server_name api.yourdomain.com;

    ssl_certificate /etc/ssl/certs/your-cert.pem;
    ssl_certificate_key /etc/ssl/private/your-key.pem;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Health Check

The `/health` endpoint returns `{"status": "healthy"}` and can be used for load balancer health checks.

### Scaling

- **Horizontal:** Run multiple app containers behind a load balancer. Switch rate limiting to Redis-backed when running multiple instances.
- **Database:** Use connection pooling (PgBouncer) for 50+ concurrent connections.
- **Redis:** Use Redis Cluster for high-availability caching.

### Monitoring

Recommended monitoring stack:

- **Metrics:** Prometheus + Grafana
- **Logging:** Structured JSON logs -> ELK or Loki
- **Uptime:** Health check endpoint with alerting
- **APM:** Sentry or Datadog for error tracking

### Security Checklist

- [ ] HTTPS only (redirect HTTP)
- [ ] Set `SECRET_KEY` to a strong random value
- [ ] Restrict `CORS_ORIGINS` to your domains only
- [ ] Database credentials rotated regularly
- [ ] Redis password set in production
- [ ] Rate limiting configured appropriately
- [ ] Review `docs/HIPAA_CHECKLIST.md` for healthcare compliance
