# HIPAA Compliance Checklist

> A practical checklist for healthcare application developers. This is a starting point, not a substitute for professional compliance review.

## Data Encryption

- [ ] **At rest:** Database encryption enabled (PostgreSQL TDE or volume-level encryption)
- [ ] **In transit:** All API traffic over HTTPS/TLS 1.2+
- [ ] **Backups:** Database backups encrypted at rest
- [ ] **Redis:** TLS enabled for Redis connections in production
- [ ] **Secrets:** API keys and credentials stored in secret manager (not env files in production)

## Access Controls

- [ ] **Authentication:** Device-based auth with UUID validation
- [ ] **Authorization:** Users can only access their own cabinet/reminder data
- [ ] **Admin access:** Separate admin authentication with MFA
- [ ] **API keys:** Rotate AI service API keys on a regular schedule
- [ ] **Network:** Database and Redis not exposed to public internet
- [ ] **CORS:** Restricted to known domains only

## Audit Logging

- [ ] **API access logs:** All requests logged with timestamp, device ID, endpoint, status
- [ ] **Data access logs:** Read/write operations on health data logged
- [ ] **Admin actions:** All administrative actions logged with operator identity
- [ ] **Log retention:** Logs retained for minimum 6 years
- [ ] **Log protection:** Logs stored in append-only storage, tamper-evident

## Data Backup & Recovery

- [ ] **Automated backups:** Daily database backups with point-in-time recovery
- [ ] **Backup testing:** Monthly restoration tests documented
- [ ] **Disaster recovery plan:** Documented RTO/RPO targets
- [ ] **Geographic redundancy:** Backups stored in separate region/zone

## Business Associate Agreements (BAAs)

- [ ] **Cloud provider:** BAA signed with hosting provider (AWS/GCP/Azure)
- [ ] **AI service:** BAA or DPA with OpenAI/Anthropic if PHI is sent
- [ ] **Analytics:** Ensure no PHI flows to analytics services
- [ ] **Monitoring:** BAA with monitoring/logging SaaS providers

## Minimum Necessary Standard

- [ ] **API responses:** Only return fields necessary for the requesting feature
- [ ] **Logging:** Exclude PHI from application logs (no drug names in logs)
- [ ] **Error messages:** Generic error messages, no PHI in error responses
- [ ] **AI prompts:** Minimize PHI sent to AI services; prefer anonymized queries

## Device-Level Data Storage

- [ ] **Local-first:** User cabinet data stored on device when possible
- [ ] **Sync optional:** Server storage is opt-in, not required
- [ ] **Data deletion:** Users can delete all their server-side data
- [ ] **Data export:** Users can export their data in a standard format

## De-identification Guidelines

- [ ] **Device IDs:** UUIDs are pseudonymous, not linked to personal identity
- [ ] **Analytics:** Aggregate metrics only, no individual tracking
- [ ] **AI training:** No user data used for AI model training
- [ ] **Research:** Any data analysis uses de-identified datasets only

## Incident Response

- [ ] **Response plan:** Documented breach notification procedure
- [ ] **Contact list:** Security team contact information maintained
- [ ] **Timeline:** 60-day breach notification compliance (HIPAA requirement)
- [ ] **Testing:** Annual tabletop exercise for incident response

## Regular Review

- [ ] **Risk assessment:** Annual security risk assessment
- [ ] **Policy review:** Annual review of all security policies
- [ ] **Training:** Annual HIPAA training for all team members
- [ ] **Penetration testing:** Annual third-party security assessment

---

**Note:** This checklist covers common HIPAA Security Rule requirements. Consult a healthcare compliance attorney for a complete assessment specific to your application and data handling practices.
