"""FastAPI Health Template - A boilerplate for medical and healthcare applications."""
