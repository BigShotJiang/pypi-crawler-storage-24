"""Pydantic schemas for interaction check endpoints."""
from pydantic import BaseModel, ConfigDict, Field


class InteractionCheckRequest(BaseModel):
    item_ids: list[str] = Field(
        ...,
        min_length=2,
        max_length=20,
        description="List of item identifiers (item_seq for drugs, ID for supplements) to check",
    )


class InteractionDetail(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    item_a: str
    item_b: str
    severity: str
    description: str
    mechanism: str | None = None
    recommendation: str | None = None
    source: str | None = None


class InteractionCheckResponse(BaseModel):
    interactions: list[InteractionDetail]
    total_checked: int
    disclaimer: str = (
        "This information is for reference only and does not replace "
        "professional medical advice. Always consult your doctor or pharmacist."
    )
