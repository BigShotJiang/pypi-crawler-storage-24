"""Pydantic schemas for drug endpoints."""
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class DrugBase(BaseModel):
    item_seq: str
    item_name: str
    company_name: str | None = None
    ingredients: dict | None = None


class DrugCreate(DrugBase):
    efficacy: str | None = None
    dosage: str | None = None
    precautions: str | None = None


class DrugResponse(DrugBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    slug: str | None = None
    efficacy: str | None = None
    dosage: str | None = None
    precautions: str | None = None
    image_url: str | None = None
    created_at: datetime
    updated_at: datetime


class DrugSearchResponse(BaseModel):
    items: list[DrugResponse]
    total: int
    page: int
    size: int
