"""Pydantic schemas for supplement endpoints."""
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class SupplementBase(BaseModel):
    product_name: str
    company_name: str | None = None
    ingredients: dict | None = None


class SupplementCreate(SupplementBase):
    functionality: str | None = None
    precautions: str | None = None
    daily_intake: str | None = None


class SupplementResponse(SupplementBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    slug: str | None = None
    functionality: str | None = None
    precautions: str | None = None
    daily_intake: str | None = None
    created_at: datetime
    updated_at: datetime


class SupplementSearchResponse(BaseModel):
    items: list[SupplementResponse]
    total: int
    page: int
    size: int
