"""Pydantic schemas for user cabinet endpoints."""
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class CabinetItemCreate(BaseModel):
    item_type: str = Field(..., pattern="^(drug|supplement)$")
    item_id: int
    nickname: str | None = None


class CabinetItemResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    device_id: str
    item_type: str
    item_id: int
    nickname: str | None = None
    created_at: datetime


class CabinetListResponse(BaseModel):
    items: list[CabinetItemResponse]
    total: int
