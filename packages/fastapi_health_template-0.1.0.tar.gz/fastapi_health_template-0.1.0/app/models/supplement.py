"""Supplement (health functional food) model."""
from sqlalchemy import Index, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Supplement(Base):
    __tablename__ = "supplements"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    product_name: Mapped[str] = mapped_column(String(500), nullable=False, comment="Product name")
    slug: Mapped[str | None] = mapped_column(String(600), unique=True, index=True, comment="URL-safe slug for SEO")
    company_name: Mapped[str | None] = mapped_column(String(300), comment="Manufacturer name")
    ingredients: Mapped[dict | None] = mapped_column(JSONB, comment="Active ingredients as structured JSON")
    functionality: Mapped[str | None] = mapped_column(Text, comment="Health claims / functionality")
    precautions: Mapped[str | None] = mapped_column(Text, comment="Intake precautions")
    daily_intake: Mapped[str | None] = mapped_column(String(500), comment="Recommended daily intake")

    __table_args__ = (
        Index("ix_supplements_product_name_trgm", "product_name", postgresql_using="gin",
              postgresql_ops={"product_name": "gin_trgm_ops"}),
    )

    def __repr__(self) -> str:
        return f"<Supplement {self.product_name}>"
