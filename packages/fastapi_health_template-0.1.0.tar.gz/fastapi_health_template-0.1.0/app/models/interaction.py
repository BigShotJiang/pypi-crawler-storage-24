"""Drug/supplement interaction model."""
from sqlalchemy import Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Interaction(Base):
    __tablename__ = "interactions"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    item_a: Mapped[str] = mapped_column(String(50), nullable=False, index=True, comment="First item identifier (item_seq or supplement ID)")
    item_b: Mapped[str] = mapped_column(String(50), nullable=False, index=True, comment="Second item identifier")
    severity: Mapped[str] = mapped_column(
        String(20),
        nullable=False,
        comment="Severity level: critical, high, moderate, low, info",
    )
    description: Mapped[str] = mapped_column(Text, nullable=False, comment="Interaction description")
    mechanism: Mapped[str | None] = mapped_column(Text, comment="Pharmacological mechanism")
    recommendation: Mapped[str | None] = mapped_column(Text, comment="Clinical recommendation")
    source: Mapped[str | None] = mapped_column(String(500), comment="Data source or reference")

    __table_args__ = (
        Index("ix_interactions_pair", "item_a", "item_b", unique=True),
    )

    def __repr__(self) -> str:
        return f"<Interaction {self.item_a} x {self.item_b} [{self.severity}]>"
