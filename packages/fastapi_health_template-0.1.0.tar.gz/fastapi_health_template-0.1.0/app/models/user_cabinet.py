"""User medication cabinet model."""
from sqlalchemy import Index, String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class UserCabinet(Base):
    __tablename__ = "user_cabinets"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    device_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True, comment="Device UUID")
    item_type: Mapped[str] = mapped_column(String(20), nullable=False, comment="'drug' or 'supplement'")
    item_id: Mapped[int] = mapped_column(nullable=False, comment="FK to drugs.id or supplements.id")
    nickname: Mapped[str | None] = mapped_column(String(100), comment="User-defined nickname for this item")

    __table_args__ = (
        Index("ix_user_cabinets_device_item", "device_id", "item_type", "item_id", unique=True),
    )

    def __repr__(self) -> str:
        return f"<UserCabinet {self.device_id} {self.item_type}:{self.item_id}>"
