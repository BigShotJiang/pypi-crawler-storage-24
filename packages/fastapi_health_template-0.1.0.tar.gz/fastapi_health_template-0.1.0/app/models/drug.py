"""Drug (medication) model."""
from sqlalchemy import Index, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Drug(Base):
    __tablename__ = "drugs"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    item_seq: Mapped[str] = mapped_column(String(50), unique=True, index=True, comment="Official drug item sequence code")
    item_name: Mapped[str] = mapped_column(String(500), nullable=False, comment="Drug product name")
    slug: Mapped[str | None] = mapped_column(String(600), unique=True, index=True, comment="URL-safe slug for SEO")
    company_name: Mapped[str | None] = mapped_column(String(300), comment="Manufacturer name")
    ingredients: Mapped[dict | None] = mapped_column(JSONB, comment="Active ingredients as structured JSON")
    efficacy: Mapped[str | None] = mapped_column(Text, comment="Indications / efficacy description")
    dosage: Mapped[str | None] = mapped_column(Text, comment="Dosage and administration")
    precautions: Mapped[str | None] = mapped_column(Text, comment="Warnings and precautions")
    image_url: Mapped[str | None] = mapped_column(String(1000), comment="Product image URL")

    __table_args__ = (
        Index("ix_drugs_item_name_trgm", "item_name", postgresql_using="gin",
              postgresql_ops={"item_name": "gin_trgm_ops"}),
    )

    def __repr__(self) -> str:
        return f"<Drug {self.item_seq} {self.item_name}>"
