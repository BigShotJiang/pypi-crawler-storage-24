"""Medical disclaimer middleware.

Automatically adds a disclaimer header to every API response, ensuring
consumers always receive the required legal notice alongside health data.
"""
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response


class DisclaimerMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, disclaimer_text: str = ""):
        super().__init__(app)
        self.disclaimer_text = disclaimer_text or (
            "This information is for reference only and does not replace "
            "professional medical advice."
        )

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)
        response.headers["X-Medical-Disclaimer"] = self.disclaimer_text
        return response
