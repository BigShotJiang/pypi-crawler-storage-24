"""Common FastAPI dependencies."""
from fastapi import Header, HTTPException, status


async def require_device_id(
    x_device_id: str | None = Header(None, alias="X-Device-ID"),
) -> str:
    """Extract and validate the device ID from the request header.

    Healthcare apps benefit from frictionless auth -- no signup,
    just a device UUID sent in every request.
    """
    if not x_device_id or len(x_device_id.strip()) == 0:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="X-Device-ID header is required",
        )
    device_id = x_device_id.strip()
    if len(device_id) < 8 or len(device_id) > 128:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="X-Device-ID must be between 8 and 128 characters",
        )
    return device_id
