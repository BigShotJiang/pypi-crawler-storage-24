"""Application settings loaded from environment variables."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Application
    app_name: str = "fastapi-health-template"
    app_env: str = "development"
    debug: bool = False
    secret_key: str = "change-me-in-production"

    # Database
    database_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/health_db"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # CORS
    cors_origins: list[str] = ["http://localhost:3000", "http://localhost:8000"]

    # AI Service
    openai_api_key: str = ""
    ai_model: str = "gpt-4o"
    ai_max_concurrent: int = 3

    # Rate Limiting
    rate_limit_per_minute: int = 60

    # Medical Disclaimer
    disclaimer_text: str = (
        "This information is for reference only and does not replace "
        "professional medical advice. Always consult your doctor or pharmacist."
    )

    # Cache TTL (seconds)
    cache_ttl_search: int = 86400       # 24 hours
    cache_ttl_detail: int = 259200      # 3 days
    cache_ttl_interaction: int = 604800  # 7 days
    cache_ttl_ai: int = 2592000         # 30 days

    @property
    def is_testing(self) -> bool:
        return self.app_env == "testing"


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
