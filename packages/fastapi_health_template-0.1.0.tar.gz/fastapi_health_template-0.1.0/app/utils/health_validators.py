"""Validators for medical and health-related content."""
import re

# Phrases that imply diagnosis or treatment (should be flagged in user-facing text)
PROHIBITED_CLAIMS = [
    r"\bcures?\b",
    r"\btreat(s|ment)?\b",
    r"\bdiagnos(e|is|tic)\b",
    r"\bprevent(s|ion)?\b.*disease",
    r"\bguarantee[ds]?\b",
]

SEVERITY_LEVELS = frozenset({"critical", "high", "moderate", "low", "info"})


def validate_severity(severity: str) -> bool:
    """Check that a severity value is one of the allowed levels."""
    return severity.lower() in SEVERITY_LEVELS


def check_prohibited_claims(text: str) -> list[str]:
    """Return any prohibited medical claim patterns found in the text.

    Healthcare apps must not make claims that a product cures, treats,
    or prevents disease (regulatory requirement for supplements).
    """
    found = []
    for pattern in PROHIBITED_CLAIMS:
        if re.search(pattern, text, re.IGNORECASE):
            found.append(pattern)
    return found


def sanitize_html(text: str) -> str:
    """Strip HTML tags from text to prevent XSS in health content."""
    return re.sub(r"<[^>]+>", "", text)


def normalize_ingredient_name(name: str) -> str:
    """Normalize ingredient names for consistent matching.

    Strips whitespace, lowercases, and removes common suffixes
    like dosage forms.
    """
    normalized = name.strip().lower()
    # Remove trailing dosage info in parentheses
    normalized = re.sub(r"\s*\([^)]*\)\s*$", "", normalized)
    return normalized
