"""Main v1 API router."""
from fastapi import APIRouter

from app.api.v1 import cabinet, drugs, interactions, supplements

v1_router = APIRouter(tags=["v1"])

v1_router.include_router(drugs.router, prefix="/drugs", tags=["drugs"])
v1_router.include_router(supplements.router, prefix="/supplements", tags=["supplements"])
v1_router.include_router(interactions.router, prefix="/interactions", tags=["interactions"])
v1_router.include_router(cabinet.router, prefix="/cabinet", tags=["cabinet"])
