"""Interaction check endpoint."""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.interaction import InteractionCheckRequest, InteractionCheckResponse
from app.services.interaction_service import InteractionService

router = APIRouter()


@router.post("/check", response_model=InteractionCheckResponse)
async def check_interactions(
    payload: InteractionCheckRequest,
    db: AsyncSession = Depends(get_db),
):
    """Check for known interactions between a list of drugs/supplements.

    Accepts 2-20 item identifiers and returns all known pairwise interactions
    with severity levels and recommendations.
    """
    service = InteractionService(db)
    return await service.check(payload.item_ids)
