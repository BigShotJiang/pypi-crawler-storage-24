import argparse
import os
import json
import logging
import questionary
import sys
from typing import Optional, List, Dict, Any
from ledgermind.server.server import MCPServer
from ledgermind.core.utils.logging import setup_logging

def export_schemas():
    """Outputs the formal industrial-grade API specification."""
    from ledgermind.server.specification import MCPApiSpecification
    spec = MCPApiSpecification.generate_full_spec()
    print(json.dumps(spec, indent=2))

from ledgermind.core.utils.gemini_config import GeminiConfigManager

def init_project(path: str):
    """Interactive initialization of Ledgermind."""
    from rich.console import Console
    from rich.panel import Panel
    from ledgermind.core.api.memory import Memory
    from ledgermind.server.installers import install_client, ClaudeInstaller, GeminiInstaller

    console = Console()
    console.print(Panel("[bold cyan]Welcome to LedgerMind Setup[/bold cyan]", expand=False))

    # 1. Project Path
    console.print("\n[bold yellow]Step 1: Project Location[/bold yellow]")
    console.print("Where is the codebase for this agent? (Hooks will be installed here)")
    project_path = questionary.text("Project Path:", default=os.getcwd()).ask()
    if project_path is None: return
    project_path = os.path.abspath(project_path)

    # 2. Memory Path
    console.print("\n[bold yellow]Step 2: Knowledge Core Location[/bold yellow]")
    console.print("Where should the memory database be stored?")
    console.print("We recommend placing it outside the project root (e.g., ../.ledgermind)")
    default_mem_path = os.path.abspath(os.path.join(project_path, "..", ".ledgermind"))
    custom_path = questionary.text("Memory Path:", default=default_mem_path).ask()
    if custom_path is None: return
    
    # 3. Embedder
    console.print("\n[bold yellow]Step 3: Embedding Model[/bold yellow]")
    console.print("LedgerMind uses a vector engine to semantically search your memory.")
    console.print("By default, we recommend the lightweight Jina v5 4-bit model (~60MB).")
    embedder = questionary.select(
        "Choose embedder:",
        choices=["jina-v5-4bit", "custom"],
        default="jina-v5-4bit"
    ).ask()
    if embedder is None: return
    
    model_name = "v5-small-text-matching-Q4_K_M.gguf"
    custom_url = None
    
    if embedder == "custom":
        console.print("You can provide a direct URL to a .gguf file to download it now,")
        console.print("OR provide an absolute path to an already downloaded .gguf file.")
        user_input = questionary.text("Enter URL or absolute path:").ask()
        if user_input is None: return
        
        if user_input.startswith("http://") or user_input.startswith("https://"):
            custom_url = user_input
            model_name = os.path.basename(custom_url.split("?")[0])
            if not model_name.endswith(".gguf"):
                model_name += ".gguf"
        else:
            model_name = user_input # Treat as absolute path or standard HF name

    # 4. Client
    console.print("\n[bold yellow]Step 4: Client Hooks[/bold yellow]")
    console.print(f"We can install hooks to seamlessly capture context for your preferred client in {project_path}.")
    client = questionary.select(
        "Which client do you use?",
        choices=["cursor", "claude", "gemini", "vscode", "none"],
        default="none"
    ).ask()
    if client is None: return

    # 4.5. Enrichment Provider (NEW)
    console.print("\n[bold yellow]Step 4.5: Enrichment Provider[/bold yellow]")
    console.print("Which LLM provider should LedgerMind use for enrichment?")
    console.print("  [bold]cli[/bold]       - Use Gemini/Claude CLI (existing behavior)")
    console.print("  [bold]openrouter[/bold] - Use OpenRouter API (100+ models, pay-per-use)")
    provider = questionary.select(
        "Select provider:",
        choices=["cli", "openrouter"],
        default="cli"
    ).ask()
    if provider is None: return

    # 5. Enrichment Mode
    console.print("\n[bold yellow]Step 5: Enrichment Mode[/bold yellow]")
    console.print("How should LedgerMind resolve memory conflicts and summarize knowledge?")
    console.print("  [bold]optimal[/bold] - Local LLM via Ollama/DeepSeek (Private, medium speed)")
    console.print("  [bold]rich[/bold]    - Cloud LLM via client (Highest quality, uses API)")
    mode = questionary.select(
        "Select mode:",
        choices=["optimal", "rich"],
        default="optimal"
    ).ask()
    if mode is None: return

    # 6. Language Preference
    console.print("\n[bold yellow]Step 6: Language Preference[/bold yellow]")
    console.print("Enter preferred language for records (e.g., 'russian', 'english', 'german'):")
    language = questionary.text(
        "Preferred language:",
        default="russian"
    ).ask()
    if language is None: return
    language = language.strip().lower()

    # 7. OpenRouter Specific Setup
    openrouter_api_key = None

    if provider == "openrouter":
        console.print("\n[bold yellow]Step 7: OpenRouter Configuration[/bold yellow]")
        
        # Check if API key is set in environment
        env_api_key = os.environ.get("OPENROUTER_API_KEY")
        
        if not env_api_key:
            console.print("[bold red]✗ OPENROUTER_API_KEY is not set in environment.[/bold red]")
            console.print("\nTo set it, run one of these commands:")
            console.print("  [cyan]export OPENROUTER_API_KEY=sk-or-v1-xxxxx[/cyan]")
            console.print("\nGet your API key from: [underline]https://openrouter.ai/keys[/underline]")
            console.print("\n[bold yellow]Waiting for you to set the API key...[/bold yellow]")
            
            # Give user a chance to export and retry
            retry_count = 0
            while retry_count < 3:
                retry = questionary.confirm(
                    f"Have you exported OPENROUTER_API_KEY? (Attempt {retry_count + 1}/3)",
                    default=False
                ).ask()
                
                if retry is None:
                    return  # User cancelled
                
                if retry:
                    # Re-check environment
                    env_api_key = os.environ.get("OPENROUTER_API_KEY")
                    if env_api_key:
                        openrouter_api_key = env_api_key
                        console.print(f"[green]✓ OPENROUTER_API_KEY found![/green]")
                        break
                    else:
                        console.print("[yellow]! Still not found. Please export the variable and try again.[/yellow]")
                
                retry_count += 1
            
            if not openrouter_api_key:
                console.print("\n[bold red]✗ OpenRouter setup cancelled. API key required.[/bold red]")
                console.print("You can re-run 'ledgermind init' after setting OPENROUTER_API_KEY")
                return
        else:
            openrouter_api_key = env_api_key
            console.print(f"[green]✓ OPENROUTER_API_KEY found in environment.[/green]")

    # 8. Gemini Specific Setup (only for CLI provider)
    gemini_binary = None
    gemini_config_mode = "global"

    if provider == "cli" and client == "gemini":
        console.print("\n[bold yellow]Step 8: Gemini Configuration[/bold yellow]")
        gemini_binary = GeminiConfigManager.discover_binary()
        if gemini_binary:
            console.print(f"[green]✓ Found gemini binary at: {gemini_binary}[/green]")
        else:
            console.print("[yellow]! Gemini binary not found in standard paths. Falling back to 'gemini' in PATH.[/yellow]")
            gemini_binary = "gemini"

        gemini_config_mode = questionary.select(
            "Select Gemini configuration mode:",
            choices=[
                questionary.Choice(title="Global (~/.gemini/settings.json) - simple setup", value="global"),
                questionary.Choice(title="Project (.gemini/settings.json) - isolate this agent", value="project")
            ],
            default="global"
        ).ask()
        if gemini_config_mode is None: return

        config_path = GeminiConfigManager.get_config_path(mode=gemini_config_mode, project_path=project_path)
        GeminiConfigManager.ensure_config_exists(config_path)
        console.print(f"[green]✓ Gemini config ensured at: {config_path}[/green]")

    enrichment_model = None

    # Model selection for OpenRouter provider
    if provider == "openrouter" and mode == "rich":
        console.print(f"\n[bold yellow]Step 7.5: OpenRouter Model Selection[/bold yellow]")
        console.print("Choose a model from OpenRouter (https://openrouter.ai/models):")
        console.print("Popular options: stepfun/step-3.5-flash:free, minimax/minimax-m2.5:free")

        while True:
            enrichment_model = questionary.text(
                "Model Name:",
                default=""
            ).ask()

            if enrichment_model is None: break
            if not enrichment_model.strip():
                enrichment_model = "openrouter/free"
                break

            # Basic validation
            if "/" not in enrichment_model:
                console.print("[yellow]! Model name should be in format 'provider/model-name' (e.g., 'openai/gpt-4')[/yellow]")
                retry = questionary.confirm("Continue anyway?").ask()
                if retry is None or not retry:
                    continue

            # Test model availability via API call
            console.print(f"Validating model [bold cyan]{enrichment_model}[/bold cyan] via OpenRouter API...")
            try:
                import httpx
                
                # Simple test: make a minimal completion request
                test_payload = {
                    "model": enrichment_model,
                    "messages": [{"role": "user", "content": "Hi, respond with 'OK' if you can hear me."}],
                    "max_tokens": 10
                }
                
                response = httpx.post(
                    "https://openrouter.ai/api/v1/chat/completions",
                    headers={
                        "Authorization": f"Bearer {openrouter_api_key}",
                        "Content-Type": "application/json",
                        "HTTP-Referer": "https://github.com/sl4m3/ledgermind",
                        "X-Title": "LedgerMind Setup"
                    },
                    json=test_payload,
                    timeout=60
                )
                
                if response.status_code == 200:
                    result = response.json()
                    if result.get("choices") and len(result["choices"]) > 0:
                        console.print(f"[green]✓ Model {enrichment_model} is available and responsive.[/green]")
                        break
                    else:
                        console.print(f"[yellow]! Model returned empty response.[/yellow]")
                elif response.status_code == 401:
                    console.print(f"[bold red]✗ Authentication failed. Check your OPENROUTER_API_KEY.[/bold red]")
                    retry = questionary.confirm("Try another model name?").ask()
                    if not retry:
                        enrichment_model = None
                        break
                elif response.status_code == 404:
                    console.print(f"[bold red]✗ Model {enrichment_model} not found on OpenRouter.[/bold red]")
                    retry = questionary.confirm("Try another model name?").ask()
                    if not retry:
                        enrichment_model = None
                        break
                else:
                    console.print(f"[bold red]✗ API returned status {response.status_code}[/bold red]")
                    if response.text:
                        console.print(f"[red]Error: {response.text[:200]}[/red]")
                    retry = questionary.confirm("Try another model name?").ask()
                    if not retry:
                        enrichment_model = None
                        break
                        
            except httpx.TimeoutException:
                console.print(f"[bold red]✗ Request timeout. The model might be unavailable or slow.[/bold red]")
                retry = questionary.confirm("Try another model name?").ask()
                if not retry:
                    enrichment_model = None
                    break
            except Exception as e:
                console.print(f"[bold red]✗ Error during validation: {e}[/bold red]")
                retry = questionary.confirm("Try another model name?").ask()
                if not retry:
                    enrichment_model = None
                    break

    # Model selection for CLI provider
    if mode == "rich" and provider == "cli" and client in ["gemini", "claude"]:
        console.print(f"\n[bold yellow]Step 5b: Specific Model for {client.capitalize()}[/bold yellow]")
        console.print("You can specify a model name to override the default client model.")
        if client == "claude":
            console.print("Examples: claude-sonnet-4-6, claude-haiku-4-5")
        else:
            console.print("Examples: gemini-2.5-flash-lite, gemini-2.0-flash")
        
        while True:
            enrichment_model = questionary.text(
                "Model Name (leave empty for default):",
                default=""
            ).ask()
            
            if enrichment_model is None: break
            if not enrichment_model.strip():
                enrichment_model = None
                break
            
            # Validation
            console.print(f"Validating model [bold cyan]{enrichment_model}[/bold cyan] via {client}...")
            try:
                import subprocess
                test_prompt = "Hi, respond with 'OK' if you can hear me."
                if client == "gemini":
                    cmd = ["gemini", "--model", enrichment_model, "--prompt", test_prompt]
                else: # claude
                    # V7.10: Use flags to disable tools, MCP, session persistence, and slash commands
                    cmd = [
                        "claude",
                        "--model", enrichment_model,
                        "-p",  # Print response and exit (non-interactive mode)
                        "--tools", "",  # Disable tool calls
                        "--strict-mcp-config", "--mcp-config", '{"mcpServers":{}}',  # Disable MCP connections
                        "--no-session-persistence",  # Don't save to memory
                        "--disable-slash-commands",  # Disable slash commands
                        test_prompt
                    ]

                # We use a longer timeout for validation because APIs can be slow
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
                if result.returncode == 0:
                    console.print(f"[green]✓ Model {enrichment_model} is available and responsive.[/green]")
                    break
                else:
                    console.print(f"[bold red]✗ Model validation failed.[/bold red]")
                    if result.stderr:
                        console.print(f"[red]Error: {result.stderr.strip()}[/red]")
                    
                    retry = questionary.confirm("Try another model name?").ask()
                    if not retry:
                        enrichment_model = None
                        break
            except Exception as e:
                console.print(f"[bold red]✗ Error during validation:[/bold red] {e}")
                retry = questionary.confirm("Try another model name?").ask()
                if not retry:
                    enrichment_model = None
                    break

    # Initialize
    console.print("\n[bold green]Initializing system...[/bold green]")
    try:
        if os.path.isabs(model_name):
            model_path = model_name
            if not os.path.exists(model_path):
                 console.print(f"[yellow]Warning: Custom model path does not exist yet: {model_path}[/yellow]")
        else:
            model_path = os.path.join(custom_path, "models", model_name) if model_name.endswith(".gguf") else model_name
        
        # Ensure memory directory exists first
        os.makedirs(custom_path, exist_ok=True)
        os.makedirs(os.path.join(custom_path, "models"), exist_ok=True)

        if custom_url:
            console.print(f"Downloading custom model from {custom_url}...")
            import httpx
            import time
            try:
                with open(model_path, "wb") as f:
                    with httpx.stream("GET", custom_url, follow_redirects=True, timeout=60.0) as response:
                        response.raise_for_status()

                        total = int(response.headers.get("Content-Length", 0))
                        downloaded = 0
                        last_log = time.time()
                        for chunk in response.iter_bytes(chunk_size=1024*1024):
                            f.write(chunk)
                            downloaded += len(chunk)
                            if time.time() - last_log > 2.0:
                                pct = (downloaded / total * 100) if total > 0 else 0
                                console.print(f"  Downloading... {pct:.1f}% ({downloaded/(1024*1024):.1f}MB)")
                                last_log = time.time()
                console.print(f"[green]✓ Downloaded to {model_path}[/green]")
            except Exception as e:
                console.print(f"[bold red]✗ Failed to download custom model: {e}[/bold red]")
                if os.path.exists(model_path): os.remove(model_path)
                return

        if embedder == "jina-v5-4bit" or model_name.endswith(".gguf"):
            try:
                from ledgermind.core.stores.vector import _is_llama_available
                if not _is_llama_available():
                    console.print("[red]Warning: llama-cpp-python is not installed. GGUF model might not work optimally until it's installed.[/red]")
            except ImportError:
                pass

        # Create memory structure. VectorStore init will auto-download GGUF if missing and URL is known.
        memory = Memory(storage_path=custom_path, vector_model=model_path)

        # V7.7: Save enrichment_* settings (legacy settings removed)
        memory.semantic.meta.set_config("enrichment_mode", mode)
        memory.semantic.meta.set_config("enrichment_language", language)
        memory.semantic.meta.set_config("client", client)
        memory.semantic.meta.set_config("enrichment_provider", provider)  # V7.9: New provider setting
        
        # V7.10: Save client-specific enrichment model
        if enrichment_model:
            # Save for specific client (claude, gemini, cursor, vscode)
            memory.semantic.meta.set_config(f"enrichment_model_{client}", enrichment_model)
            # Also save as default for backward compatibility
            memory.semantic.meta.set_config("enrichment_model", enrichment_model)

        if client == "gemini":
            memory.semantic.meta.set_config("gemini_binary_path", gemini_binary)
            memory.semantic.meta.set_config("gemini_config_mode", gemini_config_mode)
            # Paths are derived automatically in V5.0 from the mode

        # V7.9: Save OpenRouter settings (API key only - loaded from env)
        if provider == "openrouter":
            memory.semantic.meta.set_config("openrouter_api_key", openrouter_api_key)
            # Note: site_url and site_name removed in v3.3.1 - use env vars if needed

        console.print(f"[green]✓ Created memory structure at {custom_path}[/green]")
        console.print(f"[green]✓ Configured vector model: {model_name}[/green]")
        console.print(f"[green]✓ Set enrichment mode: {mode}[/green]")
        console.print(f"[green]✓ Set enrichment language: {language}[/green]")
        console.print(f"[green]✓ Set enrichment provider: {provider}[/green]")
        console.print(f"[green]✓ Registered client: {client}[/green]")
        if enrichment_model:
            console.print(f"[green]✓ Configured enrichment model for {client}: {enrichment_model}[/green]")

        if client != "none":
            console.print(f"\nInstalling hooks for {client} in {project_path}...")
            try:
                success = install_client(client, project_path, memory_path=custom_path, gemini_config_mode=gemini_config_mode)
                if success:
                    console.print(f"[green]✓ Hooks installed for {client}[/green]")
                else:
                    console.print(f"[bold red]✗ Failed to install hooks for {client}[/bold red]")
            except Exception as e:
                console.print(f"[yellow]Hook installer for '{client}' failed: {e}[/yellow]")

        # Install MCP server (mandatory for supported clients)
        if client in ["claude", "gemini"]:
            console.print(f"\n[bold yellow]Installing MCP server for {client}...[/bold yellow]")
            try:
                if client == "claude":
                    claude_installer = ClaudeInstaller()
                    mcp_success = claude_installer.install_mcp_server(project_path, custom_path, client=client)
                elif client == "gemini":
                    gemini_installer = GeminiInstaller(config_mode=gemini_config_mode)
                    mcp_success = gemini_installer.install_mcp_server(project_path, custom_path, client=client)
                if mcp_success:
                    console.print(f"[green]✓ MCP server configured for {client}[/green]")
                else:
                    console.print(f"[yellow]! MCP server configuration failed for {client}[/yellow]")
            except Exception as e:
                console.print(f"[yellow]! Error installing MCP server for {client}: {e}[/yellow]")

    except Exception as e:
        console.print(f"[bold red]✗ Error during initialization:[/bold red] {e}")
        import traceback
        console.print(traceback.format_exc())
        return

    console.print("\n[bold cyan]Initialization complete![/bold cyan]")
    console.print("You can now start the server with:")
    console.print(f"  ledgermind run --path {custom_path}")


def check_project(path: str):
    """Runs diagnostics on an existing project."""
    from ledgermind.core.api.bridge import IntegrationBridge
    print(f"Running diagnostics for project at {path}...")
    try:
        bridge = IntegrationBridge(memory_path=path)
        health = bridge.check_health()
        
        print(f"Git Available: {'✓' if health['git_available'] else '✗'}")
        print(f"Storage Writable: {'✓' if health['storage_writable'] else '✗'}")
        print(f"Repo Healthy: {'✓' if health['repo_healthy'] else '✗'}")
        print(f"Vector Search: {'✓' if health['vector_available'] else '(!) Disabled'}")
        
        if health["errors"]:
            print("\nErrors Found:")
            for err in health["errors"]:
                print(f"  - {err}")
        
        if health["warnings"]:
            print("\nWarnings:")
            for warn in health["warnings"]:
                print(f"  - {warn}")
                
        if not health["errors"]:
             print("\n✓ Environment is healthy.")
    except Exception as e:
        print(f"✗ Fatal error during check: {e}")

def show_stats(path: str):
    """Displays memory statistics."""
    from ledgermind.core.api.bridge import IntegrationBridge
    try:
        bridge = IntegrationBridge(memory_path=path)
        stats = bridge.get_stats()
        print(f"Memory Statistics for {path}:")
        print(f"  Episodic Events: {stats['episodic_count']}")
        print(f"  Semantic Decisions: {stats['semantic_count']}")
        print(f"  Vector Embeddings: {stats['vector_count']}")
    except Exception as e:
        print(f"✗ Error fetching stats: {e}")

def sync_transcript_history(bridge, transcript_path: str) -> set:
    """Synchronizes history from a transcript file, returning the set of newly synced user prompts."""
    synced_content_this_turn = set()
    if not transcript_path or not os.path.exists(transcript_path):
        return synced_content_this_turn

    sys.stderr.write(f"* Syncing history from {transcript_path}...\n")
    try:
        # Pre-fetch recent events to build a deduplication map
        recent_events = bridge.memory.episodic.query(limit=1000)
        processed_ids = set()
        processed_signatures = set() # (norm_ts, content_prefix)
        
        for ev in recent_events:
            # 1. ID check
            ctx = ev.get('context', {})
            if isinstance(ctx, str):
                try: ctx = json.loads(ctx)
                except: ctx = {}
            if isinstance(ctx, dict) and 'transcript_id' in ctx:
                processed_ids.add(ctx['transcript_id'])
            
            # 2. Content + Timestamp signature check
            ts = ev.get('timestamp', '')
            if '.' in ts: ts = ts.split('.')[0] + ts[ts.find('+') if '+' in ts else len(ts):]
            processed_signatures.add((ts, ev.get('content', '')[:100].strip()))

        with open(transcript_path, 'r', encoding='utf-8') as f:
            sync_count = 0
            for line in f:
                if not line.strip(): continue
                try: entry = json.loads(line)
                except: continue
                
                msg_id = entry.get("uuid") or entry.get("messageId") or entry.get("id")
                if not msg_id: continue
                
                msg_type = entry.get("type")
                timestamp = entry.get("timestamp")
                norm_ts = timestamp.replace('Z', '+00:00') if timestamp else ""
                if '.' in norm_ts: norm_ts = norm_ts.split('.')[0] + norm_ts[norm_ts.find('+') if '+' in norm_ts else len(norm_ts):]

                content = ""
                kind = ""
                source = ""
                
                if msg_type == "user":
                    raw_content = entry.get("message", {}).get("content", "")
                    if isinstance(raw_content, list):
                        content = "\n".join([p.get("text", "") for p in raw_content if isinstance(p, dict) and p.get("type") == "text"]).strip()
                    else:
                        content = str(raw_content).strip()
                    kind = "prompt"
                    source = "user"
                elif msg_type == "assistant":
                    message = entry.get("message", {})
                    content_parts = message.get("content", [])
                    if isinstance(content_parts, list):
                        texts = [p.get("text", "") for p in content_parts if isinstance(p, dict) and p.get("type") == "text"]
                        content = "\n".join(texts).strip()
                        kind = "result"
                        source = "agent"
                        
                        for idx, p in enumerate(content_parts):
                            if isinstance(p, dict) and p.get("type") == "tool_use":
                                tool_name = p.get("name")
                                tool_input = json.dumps(p.get("input", {}), ensure_ascii=False)
                                tc_content = f"Tool: {tool_name}\nInput: {tool_input}"
                                tc_id = f"{msg_id}_tool_{idx}"
                                if tc_id not in processed_ids and (norm_ts, tc_content[:100].strip()) not in processed_signatures:
                                    bridge.memory.process_event(
                                        source="agent", kind="call", content=tc_content, 
                                        context={"transcript_id": tc_id}, timestamp=timestamp
                                    )
                                    sync_count += 1
                                    processed_ids.add(tc_id)
                    elif isinstance(content_parts, str):
                        content = content_parts.strip()
                        kind = "result"
                        source = "agent"

                if content:
                    c_strip = content.strip()
                    content_prefix = c_strip[:100]
                    if msg_id not in processed_ids and (norm_ts, content_prefix) not in processed_signatures:
                        res = bridge.memory.process_event(
                            source=source, kind=kind, content=c_strip, 
                            context={"transcript_id": msg_id}, timestamp=timestamp
                        )
                        if res: 
                            sync_count += 1
                            processed_ids.add(msg_id)
                            processed_signatures.add((norm_ts, content_prefix))
                            if source == "user": synced_content_this_turn.add(c_strip)
            
            if sync_count > 0:
                sys.stderr.write(f"* Successfully synced {sync_count} new events from history.\n")
    except Exception as e:
        sys.stderr.write(f"Transcript sync error: {e}\n")

    return synced_content_this_turn

def bridge_context(path: str, prompt: str, cli: Optional[str] = None, threshold: Optional[float] = None, read_stdin: bool = False):
    """Bridge API: Returns context for a prompt without starting MCP server."""
    from ledgermind.core.api.bridge import IntegrationBridge
    import sys
    import json
    import os
    try:
        real_prompt = prompt
        transcript_path = None

        # 1. Handle stdin if requested
        if read_stdin or prompt == "-":
            if not sys.stdin.isatty():
                raw_input = sys.stdin.read()
                if raw_input:
                    try:
                        data = json.loads(raw_input)
                        if isinstance(data, dict):
                            real_prompt = data.get("prompt", data.get("userInput", raw_input))
                            # Crucial: Get the ACTUAL transcript path from Claude Code
                            transcript_path = data.get("transcript_path")
                        else:
                            real_prompt = raw_input
                    except json.JSONDecodeError:
                        real_prompt = raw_input
        # 2. Handle JSON in prompt argument
        else:
            try:
                data = json.loads(prompt)
                if isinstance(data, dict):
                    real_prompt = data.get("prompt", data.get("userInput", prompt))
                    transcript_path = data.get("transcript_path")
            except json.JSONDecodeError:
                pass

        default_cli = [cli] if cli else None
        # Use cli as namespace for isolation between clients
        bridge = IntegrationBridge(memory_path=path, default_cli=default_cli, relevance_threshold=threshold if threshold is not None else 0.7, namespace=cli)

        # 4. Robust History Sync (Hybrid Deduplication)
        # We only sync if transcript_path is a FILE
        synced_content_this_turn = set()
        if transcript_path and os.path.isfile(transcript_path):
            synced_content_this_turn = sync_transcript_history(bridge, transcript_path)
        elif transcript_path:
            sys.stderr.write(f"* Skipping sync: {transcript_path} is not a file\n")

        # 5. Record the CURRENT prompt (REMOVED - handled by Stop hook transcript sync)
        # Manual recording here causes duplicates with Stop hook sync due to TZ/precision diffs.
        # We rely on Stop hook to record everything robustly.
        
        ctx = bridge.get_context_for_prompt(real_prompt)
        sys.stdout.write(ctx)
    except Exception as e:
        sys.stderr.write(f"✗ Error: {e}\n")

def bridge_sync(path: str, cli: Optional[str] = None):
    """Bridge API: Dedicated sync command for the Stop hook."""
    from ledgermind.core.api.bridge import IntegrationBridge
    import sys
    import json
    import os
    try:
        transcript_path = None
        if not sys.stdin.isatty():
            raw_input = sys.stdin.read()
            if raw_input:
                try:
                    data = json.loads(raw_input)
                    if isinstance(data, dict):
                        transcript_path = data.get("transcript_path")
                except json.JSONDecodeError:
                    pass

        default_cli = [cli] if cli else None
        # Use cli as namespace for isolation between clients
        bridge = IntegrationBridge(memory_path=path, default_cli=default_cli, namespace=cli)
        sync_transcript_history(bridge, transcript_path)
    except Exception as e:
        sys.stderr.write(f"✗ Sync Error: {e}\n")

def bridge_record(path: str, prompt: str, response: str, success: bool, metadata: str, cli: Optional[str] = None, read_stdin: bool = False):
    """Bridge API: Records interaction into episodic memory."""
    from ledgermind.core.api.bridge import IntegrationBridge
    import json
    import sys
    try:
        real_prompt = prompt
        real_response = response
        real_meta = json.loads(metadata) if metadata else {}
        real_success = success

        # Read from stdin if requested or if prompt/response are placeholders
        if read_stdin or (prompt == "Automated tool execution" and response == "-"):
            if not sys.stdin.isatty():
                try:
                    raw_input = sys.stdin.read()
                    if raw_input:
                        data = json.loads(raw_input)
                        if isinstance(data, dict):
                            # Try to extract from Claude Code PostToolUse format
                            if "toolUse" in data:
                                tool_name = data["toolUse"].get("name", "unknown")
                                tool_input = json.dumps(data["toolUse"].get("input", {}), ensure_ascii=False)
                                real_prompt = f"Tool Execution: {tool_name}"
                                real_response = f"Args: {tool_input}"
                                if "toolResult" in data:
                                    res = data["toolResult"].get("result", "")
                                    if not isinstance(res, str): res = json.dumps(res, ensure_ascii=False)
                                    real_response += f"\nResult: {res}"
                            
                            # Try to extract from general transcript/response format
                            elif "response" in data:
                                real_response = data["response"]
                                if "prompt" in data: real_prompt = data["prompt"]
                except Exception:
                    pass

        default_cli = [cli] if cli else None
        # Use cli as namespace for isolation between clients
        bridge = IntegrationBridge(memory_path=path, default_cli=default_cli, namespace=cli)
        bridge.record_interaction(prompt=real_prompt, response=real_response, success=real_success, metadata=real_meta)
    except Exception as e:
        print(f"✗ Error: {e}")

def cleanup_orphans():
    """Finds and terminates all Ledgermind processes that are orphaned (PPID=1)."""
    import psutil
    import os
    import signal
    
    current_pid = os.getpid()
    count = 0
    for proc in psutil.process_iter(['pid', 'ppid', 'cmdline', 'name']):
        try:
            pinfo = proc.info
            # Filter for Ledgermind processes that are orphaned
            if pinfo['ppid'] == 1 and pinfo['pid'] != current_pid:
                cmd = " ".join(pinfo['cmdline'] or [])
                # Identify if it's our process (by name or command line)
                if 'ledgermind' in cmd.lower() or 'python' in pinfo['name'].lower():
                    if 'ledgermind.server' in cmd or 'mcp' in cmd:
                        try:
                            os.kill(pinfo['pid'], signal.SIGTERM)
                            count += 1
                        except (OSError, ProcessLookupError):
                            pass
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
            
    if count > 0:
        sys.stderr.write(f"* Cleaned up {count} orphaned Ledgermind processes.\n")

def main():
    parser = argparse.ArgumentParser(description="Ledgermind MCP Server Launcher")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run the MCP server")
    run_parser.add_argument("--path", default="../.ledgermind", help="Path to memory storage")
    run_parser.add_argument("--name", default="Ledgermind", help="MCP Server Name")
    run_parser.add_argument("--capabilities", help="JSON string of capabilities")
    run_parser.add_argument("--metrics-port", type=int, help="Port for Prometheus metrics")
    run_parser.add_argument("--rest-port", type=int, help="Port for REST Gateway")
    run_parser.add_argument("--vector-workers", type=int, default=0, help="Number of workers for multi-process encoding (0=auto)")
    run_parser.add_argument("--client", choices=["claude", "gemini", "cursor", "vscode", "none"], help="Client that started this MCP server")
    
    # Init command
    init_parser = subparsers.add_parser("init", help="Initialize a new memory project")
    init_parser.add_argument("--path", default="../.ledgermind", help="Path to create memory storage")

    # Check command
    check_parser = subparsers.add_parser("check", help="Check project health")
    check_parser.add_argument("--path", default="../.ledgermind", help="Path to memory storage")

    # Stats command
    stats_parser = subparsers.add_parser("stats", help="Show memory statistics")
    stats_parser.add_argument("--path", default="../.ledgermind", help="Path to memory storage")

    # Settings command
    from ledgermind.server.settings import create_settings_parser, handle_settings_command
    create_settings_parser(subparsers)

    # Bridge commands
    bc_parser = subparsers.add_parser("bridge-context", help="Internal: get context")
    bc_parser.add_argument("--path", default="../.ledgermind", help="Path to memory storage")
    bc_parser.add_argument("--prompt", required=True, help="User prompt")
    bc_parser.add_argument("--cli", help="Default CLI for enrichment")
    bc_parser.add_argument("--threshold", type=float, help="Relevance threshold")
    bc_parser.add_argument("--stdin", action="store_true", help="Read from stdin")

    bs_parser = subparsers.add_parser("bridge-sync", help="Internal: sync transcript history (Stop hook)")
    bs_parser.add_argument("--path", default="../.ledgermind", help="Path to memory storage")
    bs_parser.add_argument("--cli", help="Default CLI for enrichment")
    bs_parser.add_argument("--stdin", action="store_true", help="Read from stdin")

    br_parser = subparsers.add_parser("bridge-record", help="Internal: record interaction")
    br_parser.add_argument("--path", default="../.ledgermind", help="Path to memory storage")
    br_parser.add_argument("--prompt", required=True, help="User prompt")
    br_parser.add_argument("--response", required=True, help="Agent response")
    br_parser.add_argument("--success", action="store_true", default=True, help="Was successful")
    br_parser.add_argument("--metadata", default=None, help="JSON metadata")
    br_parser.add_argument("--cli", help="Default CLI for enrichment")
    br_parser.add_argument("--stdin", action="store_true", help="Read from stdin")

    # Global options
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging")
    parser.add_argument("--log-file", help="Path to log file")

    # Export schema command
    subparsers.add_parser("export-schema", help="Export JSON schemas for API contracts")

    # Default to 'run' if no command is provided
    import sys
    known_commands = ["run", "init", "check", "stats", "settings", "export-schema", "bridge-context", "bridge-record", "bridge-sync", "-h", "--help", "--verbose", "-v", "--log-file"]
    if len(sys.argv) > 1 and sys.argv[1] not in known_commands:
        sys.argv.insert(1, "run")

    args = parser.parse_args()
    
    # Initialize logging
    # Skip global setup for 'run' command as it handles its own logging with overwrite mode
    if args.command != "run":
        log_level = logging.DEBUG if args.verbose else logging.INFO
        setup_logging(level=log_level, log_file=args.log_file)
    
    if args.command == "export-schema":
        export_schemas()
    elif args.command == "bridge-context":
        bridge_context(args.path, args.prompt, args.cli, args.threshold, args.stdin)
    elif args.command == "bridge-sync":
        bridge_sync(args.path, args.cli)
    elif args.command == "bridge-record":
        bridge_record(args.path, args.prompt, args.response, args.success, args.metadata, args.cli, args.stdin)
    elif args.command == "init":
        init_project(args.path)
    elif args.command == "check":
        check_project(args.path)
    elif args.command == "stats":
        show_stats(args.path)
    elif args.command == "settings":
        handle_settings_command(args)
    elif args.command == "run":
        # Cleanup any previous orphaned processes before starting
        cleanup_orphans()
        
        # Setup automatic server logging
        if not args.log_file:
            log_dir = os.path.join(os.getcwd(), "logs")
            if not os.path.exists(log_dir):
                os.makedirs(log_dir, exist_ok=True)
            log_file = os.path.join(log_dir, "server.log")
        else:
            log_file = args.log_file

        setup_logging(level=logging.DEBUG if args.verbose else logging.INFO, log_file=log_file, mode='w')

        # Create server.pid to help background processes detect server status
        pid_file = os.path.join(os.path.abspath(args.path), "server.pid")
        try:
            with open(pid_file, 'w') as f:
                f.write(str(os.getpid()))
            import atexit
            def cleanup_pid():
                if os.path.exists(pid_file): os.remove(pid_file)
            atexit.register(cleanup_pid)
        except Exception as e:
            print(f"Warning: Could not create server.pid: {e}")

        capabilities = None
        if args.capabilities:
            try:
                capabilities = json.loads(args.capabilities)
            except json.JSONDecodeError:
                print(f"Error: Invalid JSON for capabilities: {args.capabilities}")
                return

        from ledgermind.core.core.schemas import TrustBoundary
        from ledgermind.core.api.memory import Memory
        import signal
        
        memory = MCPServer.memory_instance_for_cli = None # Placeholder for signal handler access

        def signal_handler(sig, frame):
            print("\nSignal received, shutting down...")
            if MCPServer.current_instance:
                MCPServer.current_instance.stop()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        # SIGHUP is sent when the terminal session is closed (common in Termux)
        if hasattr(signal, "SIGHUP"):
            signal.signal(signal.SIGHUP, signal_handler)

        try:
            memory = Memory(storage_path=args.path, trust_boundary=TrustBoundary.AGENT_WITH_INTENT, vector_workers=args.vector_workers)
            server = MCPServer(
                memory,
                server_name=args.name,
                storage_path=args.path,
                capabilities=capabilities,
                metrics_port=args.metrics_port,
                rest_port=args.rest_port,
                client=args.client
            )
            MCPServer.current_instance = server
            server.run()
        except Exception as e:
            sys.stderr.write(f"✗ Server Critical Failure: {e}\n")
            sys.exit(1)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
