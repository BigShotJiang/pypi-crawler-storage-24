#!/usr/bin/env python3
"""
wire-mcp: MCP server for WireGuard mesh network management

Tools:
- wire_status: WireGuard interface and peer status
- wire_peers: List all connected peers with handshake info
- wire_add_node: Add a new peer to the mesh
- wire_remove_node: Remove a peer from the mesh
- wire_diagnose: Diagnose connectivity issues
- wire_install: Install/setup WireGuard on this machine
- wire_connect: Connect to mesh network
- wire_watchdog: Check mesh health and auto-heal

Run: python3 wire_mcp_server.py
"""

import json
import subprocess
import sys
import os
import time

CONFIG_PATH = os.path.expanduser("~/.mpop/config.json")

def load_config():
    try:
        with open(CONFIG_PATH) as f:
            return json.load(f)
    except:
        return {}

def send_response(response):
    msg = json.dumps(response)
    sys.stdout.write(f"Content-Length: {len(msg)}\r\n\r\n{msg}")
    sys.stdout.flush()

def read_request():
    headers = {}
    while True:
        line = sys.stdin.readline()
        if not line or line.strip() == "":
            break
        if ":" in line:
            key, val = line.split(":", 1)
            headers[key.strip()] = val.strip()
    length = int(headers.get("Content-Length", 0))
    if length == 0:
        return None
    body = sys.stdin.read(length)
    return json.loads(body)

def run_cmd(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip() if r.returncode == 0 else r.stderr.strip()
    except subprocess.TimeoutExpired:
        return "Command timed out"
    except Exception as e:
        return str(e)


def tool_wire_status():
    output = run_cmd("wg show all 2>/dev/null || echo 'WireGuard not active'")
    ifaces = run_cmd("ip -br addr show type wireguard 2>/dev/null || ifconfig | grep -A1 wire 2>/dev/null || echo 'No WireGuard interfaces'")
    config = load_config()
    servers = config.get("servers", {})
    wire_peers = {name: s.get("wire_ip", "-") for name, s in servers.items() if s.get("wire_ip")}
    return {"wireguard": output, "interfaces": ifaces, "configured_peers": wire_peers}


def tool_wire_peers():
    output = run_cmd("wg show all dump 2>/dev/null")
    if not output or "not active" in output.lower():
        return {"peers": [], "message": "WireGuard not active"}
    peers = []
    config = load_config()
    servers = config.get("servers", {})
    key_to_name = {}
    for name, s in servers.items():
        pk = s.get("wire_pubkey", "")
        if pk:
            key_to_name[pk] = name
    for line in output.strip().split("\n"):
        parts = line.split("\t")
        if len(parts) >= 8:
            pubkey = parts[1]
            endpoint = parts[3] if parts[3] != "(none)" else "-"
            allowed = parts[4]
            handshake = parts[5]
            rx = int(parts[6]) if parts[6].isdigit() else 0
            tx = int(parts[7]) if parts[7].isdigit() else 0
            hs_ago = "-"
            if handshake.isdigit() and int(handshake) > 0:
                hs_ago = f"{int(time.time()) - int(handshake)}s ago"
            name = key_to_name.get(pubkey, "unknown")
            peers.append({"name": name, "interface": parts[0], "public_key": pubkey[:16] + "...", "endpoint": endpoint, "allowed_ips": allowed, "last_handshake": hs_ago, "rx": f"{rx/1048576:.1f} MB", "tx": f"{tx/1048576:.1f} MB"})
    return {"peers": peers, "count": len(peers)}


def tool_wire_add_node(name, endpoint, public_key, allowed_ips="10.99.0.0/16"):
    if not name or not public_key:
        return {"error": "name and public_key are required"}
    cmd = f"wg set wire0 peer {public_key}"
    if endpoint:
        cmd += f" endpoint {endpoint}"
    cmd += f" allowed-ips {allowed_ips} persistent-keepalive 25"
    result = run_cmd(cmd)
    save_result = run_cmd("wg-quick save wire0 2>/dev/null || echo 'save skipped'")
    return {"status": "added" if not result else result, "name": name, "public_key": public_key[:16] + "...", "endpoint": endpoint or "dynamic", "allowed_ips": allowed_ips, "config_saved": save_result}


def tool_wire_remove_node(name_or_key):
    if not name_or_key:
        return {"error": "name or public_key required"}
    pubkey = name_or_key
    config = load_config()
    servers = config.get("servers", {})
    if name_or_key in servers:
        pubkey = servers[name_or_key].get("wire_pubkey", name_or_key)
    result = run_cmd(f"wg set wire0 peer {pubkey} remove")
    save_result = run_cmd("wg-quick save wire0 2>/dev/null || echo 'save skipped'")
    return {"status": "removed" if not result else result, "peer": name_or_key, "config_saved": save_result}


def tool_wire_diagnose(target=None):
    checks = {}
    checks["kernel_module"] = run_cmd("lsmod | grep wireguard || modinfo wireguard 2>/dev/null | head -1 || echo 'not loaded'")
    checks["interface"] = run_cmd("ip link show wire0 2>/dev/null || echo 'wire0 not found'")
    checks["listen_port"] = run_cmd("wg show wire0 listen-port 2>/dev/null || echo 'not listening'")
    checks["peer_count"] = run_cmd("wg show wire0 peers 2>/dev/null | wc -l || echo '0'").strip()
    checks["handshakes"] = run_cmd("wg show wire0 latest-handshakes 2>/dev/null || echo 'none'")
    checks["routes"] = run_cmd("ip route show dev wire0 2>/dev/null || echo 'no routes'")
    if target:
        checks["ping"] = run_cmd(f"ping -c 2 -W 2 {target} 2>&1 | tail -2")
    checks["firewall_udp"] = run_cmd("ss -ulnp | grep 51820 || echo 'port 51820 not listening'")
    return checks


def tool_wire_install():
    installed = run_cmd("which wg && wg --version 2>/dev/null || echo 'not installed'")
    if "not installed" in installed:
        os_info = run_cmd("cat /etc/os-release 2>/dev/null | head -2")
        if "ubuntu" in os_info.lower() or "debian" in os_info.lower():
            result = run_cmd("apt-get update -qq && apt-get install -y wireguard 2>&1 | tail -3", timeout=60)
        elif "centos" in os_info.lower() or "rhel" in os_info.lower():
            result = run_cmd("yum install -y wireguard-tools 2>&1 | tail -3", timeout=60)
        else:
            result = f"Manual install needed. OS: {os_info}"
        return {"installed": False, "install_result": result}
    return {"installed": True, "version": installed}


def tool_wire_connect(server_url=None, listen_port=51820):
    status = run_cmd("wg show wire0 2>/dev/null")
    if status and "interface" not in status.lower():
        return {"status": "already connected", "details": status}
    privkey_path = os.path.expanduser("~/.mpop/wire_private.key")
    if not os.path.exists(privkey_path):
        os.makedirs(os.path.dirname(privkey_path), exist_ok=True)
        privkey = run_cmd("wg genkey")
        with open(privkey_path, "w") as f:
            f.write(privkey)
        os.chmod(privkey_path, 0o600)
        pubkey = run_cmd(f"echo '{privkey}' | wg pubkey")
        return {"status": "keys_generated", "public_key": pubkey, "message": "Keys generated. Share your public key with the mesh admin, then use wire_add_node to add peers."}
    with open(privkey_path) as f:
        privkey = f.read().strip()
    pubkey = run_cmd(f"echo '{privkey}' | wg pubkey")
    return {"status": "ready", "public_key": pubkey, "private_key_path": privkey_path, "message": "Keys exist. Use wire_add_node to add peers, or wire_status to check connections."}


def tool_wire_watchdog():
    issues = []
    iface = run_cmd("ip link show wire0 2>/dev/null")
    if "wire0" not in iface:
        return {"healthy": False, "issues": ["wire0 interface not found"]}
    if "DOWN" in iface:
        issues.append("wire0 interface is DOWN")
    handshakes = run_cmd("wg show wire0 latest-handshakes 2>/dev/null")
    stale_peers = []
    for line in handshakes.strip().split("\n"):
        if "\t" in line:
            parts = line.split("\t")
            if len(parts) == 2 and parts[1].isdigit():
                age = int(time.time()) - int(parts[1])
                if age > 180:
                    stale_peers.append({"key": parts[0][:16] + "...", "last_seen": f"{age}s ago"})
    if stale_peers:
        issues.append(f"{len(stale_peers)} stale peers")
    transfer = run_cmd("wg show wire0 transfer 2>/dev/null")
    return {"healthy": len(issues) == 0, "issues": issues if issues else ["All checks passed"], "stale_peers": stale_peers, "transfer": transfer}


TOOLS = [
    {"name": "wire_status", "description": "[WireGuard] Show WireGuard interface status, configured peers, and VPN IPs", "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "wire_peers", "description": "[WireGuard] List all connected peers with handshake times, transfer stats, and endpoints", "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "wire_add_node", "description": "[WireGuard] Add a new peer to the WireGuard mesh network", "inputSchema": {"type": "object", "properties": {"name": {"type": "string", "description": "Node name (e.g., v5, m1)"}, "endpoint": {"type": "string", "description": "Peer endpoint IP:port (e.g., 1.2.3.4:51820). Empty for dynamic."}, "public_key": {"type": "string", "description": "Peer WireGuard public key"}, "allowed_ips": {"type": "string", "description": "Allowed IP range (default: 10.99.0.0/16)", "default": "10.99.0.0/16"}}, "required": ["name", "public_key"]}},
    {"name": "wire_remove_node", "description": "[WireGuard] Remove a peer from the WireGuard mesh", "inputSchema": {"type": "object", "properties": {"name_or_key": {"type": "string", "description": "Node name or WireGuard public key"}}, "required": ["name_or_key"]}},
    {"name": "wire_diagnose", "description": "[WireGuard] Diagnose WireGuard connectivity — kernel module, interface, ports, handshakes, routing", "inputSchema": {"type": "object", "properties": {"target": {"type": "string", "description": "Optional IP to ping-test (e.g., 10.99.0.1)"}}, "required": []}},
    {"name": "wire_install", "description": "[WireGuard] Check if WireGuard is installed, install if missing", "inputSchema": {"type": "object", "properties": {}, "required": []}},
    {"name": "wire_connect", "description": "[WireGuard] Initialize WireGuard connection — generate keys and prepare to join mesh", "inputSchema": {"type": "object", "properties": {"server_url": {"type": "string", "description": "Mesh server URL (optional)"}, "listen_port": {"type": "integer", "description": "WireGuard listen port (default: 51820)", "default": 51820}}, "required": []}},
    {"name": "wire_watchdog", "description": "[WireGuard] Health check — detect stale peers, down interfaces, and connectivity issues", "inputSchema": {"type": "object", "properties": {}, "required": []}}
]


def handle_request(request):
    method = request.get("method", "")
    params = request.get("params", {})
    req_id = request.get("id")

    if method == "initialize":
        return {"jsonrpc": "2.0", "id": req_id, "result": {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}}, "serverInfo": {"name": "wire-mcp", "version": "1.0.0"}}}
    elif method == "tools/list":
        return {"jsonrpc": "2.0", "id": req_id, "result": {"tools": TOOLS}}
    elif method == "tools/call":
        tool_name = params.get("name", "")
        args = params.get("arguments", {})
        result = None
        if tool_name == "wire_status":
            result = tool_wire_status()
        elif tool_name == "wire_peers":
            result = tool_wire_peers()
        elif tool_name == "wire_add_node":
            result = tool_wire_add_node(args.get("name"), args.get("endpoint", ""), args.get("public_key"), args.get("allowed_ips", "10.99.0.0/16"))
        elif tool_name == "wire_remove_node":
            result = tool_wire_remove_node(args.get("name_or_key"))
        elif tool_name == "wire_diagnose":
            result = tool_wire_diagnose(args.get("target"))
        elif tool_name == "wire_install":
            result = tool_wire_install()
        elif tool_name == "wire_connect":
            result = tool_wire_connect(args.get("server_url"), args.get("listen_port", 51820))
        elif tool_name == "wire_watchdog":
            result = tool_wire_watchdog()
        else:
            result = {"error": f"Unknown tool: {tool_name}"}
        return {"jsonrpc": "2.0", "id": req_id, "result": {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}}
    elif method == "notifications/initialized":
        return None
    else:
        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": f"Method not found: {method}"}}


def main():
    while True:
        try:
            request = read_request()
            if request is None:
                break
            response = handle_request(request)
            if response:
                send_response(response)
        except Exception as e:
            sys.stderr.write(f"Error: {e}\n")
            break

if __name__ == "__main__":
    main()
