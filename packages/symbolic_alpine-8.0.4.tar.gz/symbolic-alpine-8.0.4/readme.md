# Symbolic for Alpine Linux
--------

Symbolic is a Alpine Linux version of Python library that can work with debug symbol files.

Web:
- https://github.com/tekintian/symbolic-alpine
- https://ai.tekin.cn

## Installation

### For Python 3.x (Recommended)

Install directly using pip:

```bash
pip install symbolic-alpine
```

### For Python 2.7

**Important**: Python 2.7 uses pip 20.3.4, which does not support the `musllinux_1_1_x86_64` platform tag (introduced in PEP 656, requires pip >= 21.0).

To install on Python 2.7:

1. Download the `musllinux_1_1_x86_64` wheel file from PyPI:
   - Visit: https://pypi.org/project/symbolic-alpine/#files
   - Download: `symbolic_alpine-8.0.4-cp27-cp27mu-musllinux_1_1_x86_64.whl`

2. Use the `pip-musl` script to install:

```bash
# Make the script executable
chmod +x python2_assets/pip-musl

# Install the downloaded wheel file
./python2_assets/pip-musl install symbolic_alpine-8.0.4-cp27-cp27mu-musllinux_1_1_x86_64.whl
```

### Why the special handling for Python 2.7?

The `musllinux_1_1_x86_64` platform tag was introduced in PEP 656 and requires pip >= 21.0. Python 2.7 reached end-of-life in 2020, and pip 20.3.4 was the last version to support Python 2.7. Therefore, pip 20.3.4 cannot install wheels with `musllinux` platform tags.

The `pip-musl` script works around this limitation by manually extracting and installing the wheel file when it detects a `musllinux` wheel on an older pip version.

## Usage

```python
import symbolic

# Demangle C++ symbols
from symbolic import demangle
result = demangle('_ZN4base8internal12CheckedCastINS_6subtle11PrecheckedEdEEEPNS0_13CheckedNumericEdE')
print('Demangle result:', result)

# Check if architecture is known
from symbolic import arch_is_known
print('x86_64 known:', arch_is_known('x86_64'))
```

## Building

See [t.sh](t.sh) for build instructions.