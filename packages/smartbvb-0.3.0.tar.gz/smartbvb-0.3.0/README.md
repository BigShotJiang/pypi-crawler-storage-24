# smartbvb

A fast, beautifully styled terminal application for viewing KLE Tech attendance and results natively from your command line!

## Installation

Navigate to this folder in your terminal and run:

```bash
pip install .
```

*Note: Playwright requires a browser to be installed to work in the background. If you haven't installed it before, run:*
```bash
playwright install chromium
```

## Usage

Once installed, you can launch the app from anywhere on your terminal just by typing:

```bash
smartbvb
```

### Features
- **Global `smartbvb` Command:** Run it from any directory on your computer.
- **Credential Caching:** First-time setup asks for your USN and DOB and securely caches it in `~/.smartbvb_config.json`. You won't be asked again unless you log out!
- **Persistent Session Manager:** The CLI uses a single, persistent browser session in the background. It will not restart the browser when switching between "View Attendance" and "View Results".
- **Dynamic Site Status Check:** It validates if the server is up *synchronously* during the "Welcome" loading screen. If the site is down, the viewing options will be grayed out to save you time.
