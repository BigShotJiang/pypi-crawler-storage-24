# elemem-vector-sdk

提供向量的增删改查

## 安装

```bash
pip install elemem-vector-sdk
```

## 使用

```python
from elemem_sdk import cosmosx_client

client = cosmosx_client.CosmosXClient("127.0.0.1:7000")
res = client.query_all_index()
if res.success:
    print(res.data)
else:
    print(res.code, res.message)
```

SDK 接口统一返回 `CosmosXResult`：

```python
@dataclass
class CosmosXResult:
    code: int
    message: str
    data: Any = None
```

## 发布

```bash
bash upload.sh
```
