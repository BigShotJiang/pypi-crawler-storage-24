import logging
import numpy as np
import h5py
import argparse
from .cosmosx_client import CosmosXClient, CosmosXResult, get_data_from_hdf5

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger('CosmosXDemo')
logger.setLevel(logging.DEBUG)

def require_success(result: CosmosXResult, operation: str) -> CosmosXResult:
    if result.code != 0:
        raise RuntimeError(f"{operation} failed: code={result.code}, message={result.message}")
    logger.info(f"{operation} success: code={result.code}, message={result.message}")
    return result

def run_demo(server, hdf5_path, index_name="sift"):
    client = CosmosXClient(server, debug=True)
    try:
        # 1. 清理旧索引
        logger.info(f"尝试删除旧索引: {index_name}")
        delete_result = client.delete_index(index_name)
        if delete_result.code != 0:
            logger.warning(f"删除索引失败: code={delete_result.code}, message={delete_result.message} (可能索引不存在)")

        # 2. 准备数据
        data, nb, dim = get_data_from_hdf5(hdf5_path)

        # 3. 创建新索引
        logger.info("\n" + "="*50 + "\nStarting CREATE INDEX\n" + "="*50)
        require_success(client.create_index(index_name, dim, 1, 1, 1), "create_index")

        # 4. 查询所有索引
        logger.info("\n" + "="*50 + "\nStarting QUERY ALL INDEXES\n" + "="*50)
        indices_result = require_success(client.query_all_index(), "query_all_index")
        indices = indices_result.data
        logger.info(f"当前索引列表数量: {len(indices)}")
        logger.info(f"当前索引列表: {indices}")

        # 5. 训练索引
        logger.info("\n" + "="*50 + "\nStarting TRAIN\n" + "="*50)
        train_result = require_success(client.train(
                name=index_name,
                data=data,
                nlist=128
        ), "train")
        logger.info(f"训练结果: code={train_result.code}, message={train_result.message}")

        # 6. 添加向量
        logger.info("\n" + "="*50 + "\nStarting ADD\n" + "="*50)
        add_result = require_success(client.add(
                name=index_name,
                data=data
        ), "add")
        ids = add_result.data["ids"]
        logger.info(f"添加向量数量: {len(ids)}")

        # 7. 查询向量
        logger.info("\n" + "="*50 + "\nStarting QUERY VECTOR\n" + "="*50)
        if ids:
            vector_id = ids[0]
            query_result = require_success(client.query_vector(index_name, vector_id), "query_vector")
            raw_dim = len(query_result.data)
            logger.info(f"查询到向量元数据: ID={vector_id}, 维度={raw_dim}, data={query_result.data}")

        # 8. 搜索测试
        logger.info("\n" + "="*50 + "\n执行搜索测试\n" + "="*50)
        nq = 1000
        with h5py.File(hdf5_path, 'r') as f:
            base = f['train'][:nq]
        actual_nq = base.shape[0]
        search_result = require_success(client.search(index_name, base, k=1, nprob=5), "search_recall")
        distances = search_result.data["distances"]
        labels = search_result.data["labels"]
        top1 = labels[:, 0]
        truth = np.arange(actual_nq, dtype=top1.dtype)
        recall1 = np.mean(top1 == truth)
        logger.info(f"Recall@1 over {actual_nq} queries: {recall1 * 100:.2f}%")

        # 9. 更新向量
        logger.info("\n" + "="*50 + "\nStarting UPDATE VECTOR\n" + "="*50)
        if ids:
            new_data = np.random.rand(dim).astype(np.float32).tolist()
            require_success(client.update_vector(index_name, vector_id, new_data), "update_vector")

        # 10. 搜索随机查询
        logger.info("\n" + "="*50 + "\nStarting SEARCH\n" + "="*50)
        nq = 10
        test_queries = np.random.rand(nq, dim).astype(np.float32)
        random_search_result = require_success(client.search(index_name, test_queries, k=3), "search_random")
        distances = random_search_result.data["distances"]
        labels = random_search_result.data["labels"]
        logger.info("\nSearch Results:")
        for i in range(nq):
            logger.info(f"查询 {i+1}: 距离={distances[i]}, 标签={labels[i]}")

        # 11. 删除向量
        logger.info("\n" + "="*50 + "\nStarting DELETE VECTOR\n" + "="*50)
        if ids:
            require_success(client.delete_vector(index_name, vector_id), "delete_vector")

        # 12. 删除索引
        logger.info("\n" + "="*50 + "\nStarting DELETE INDEX\n" + "="*50)
        require_success(client.delete_index(index_name), "delete_index")

        logger.info("\n" + "="*50 + "\nALL OPERATIONS COMPLETED SUCCESSFULLY\n" + "="*50)

    except Exception:
        logger.exception("Operation failed")
        logger.error("\n" + "="*50 + "\nOPERATION FAILED\n" + "="*50)
        raise

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='CosmosX Client Demo')
    parser.add_argument('--server', default='localhost:7000', help='Server address')
    parser.add_argument('--hdf5', required=True, default='.data/SIFT_1M.hdf5', help='HDF5 data path')
    parser.add_argument('--index', default='sift', help='name of index')
    args = parser.parse_args()

    logger.info(f"启动 CosmosX 客户端演示")
    logger.info(f"服务器: {args.server}")
    logger.info(f"HDF5 文件: {args.hdf5}")
    logger.info(f"索引名称: {args.index}")

    run_demo(args.server, args.hdf5, args.index)
