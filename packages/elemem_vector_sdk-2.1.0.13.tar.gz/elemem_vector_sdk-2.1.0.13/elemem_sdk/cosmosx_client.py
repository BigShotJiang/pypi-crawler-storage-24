import os
import grpc
import logging
import re
import numpy as np
import h5py
import json
import concurrent.futures
import threading
import hashlib
from tqdm import tqdm
from google.protobuf.json_format import MessageToDict
from dataclasses import dataclass
from typing import Any, List
from .proto import sdk_pb2, sdk_pb2_grpc

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger('CosmosXClient')
logger.setLevel(logging.INFO)

SUCCESS = 0
SDK_COMMON_ERROR = 2100
SDK_READ_FILE_FAILED = 2112
SDK_INDEX_NAME_INVALID = 2113
SDK_INDEX_INVALID_PARAM = 2115
SDK_RPC_FAILED = 2126
SDK_NO_RETURN_CODE = 2127

G_MAX_DIM = 8192
G_MIN_DIM = 1
G_MAX_CARD_NUM = 8
G_MIN_CARD_NUM = 1
G_MAX_NLIST = 262144
G_MAX_NB_PER_CARD = 50000000
G_MAX_NB = G_MAX_NB_PER_CARD * G_MAX_CARD_NUM
G_MEMORY_CAPACITY_PER_CARD = 256 * 1024 * 1024 * 26
G_MEMORY_CAPACITY = G_MAX_CARD_NUM * G_MEMORY_CAPACITY_PER_CARD
G_MAX_TOPK = 16384
G_MAX_BATCH_SIZE = 1000
G_INDEX_NAME_MAX_LEN = 50

ERROR_MESSAGES = {
    SUCCESS: "success",
    SDK_COMMON_ERROR: "SDK common error",
    SDK_READ_FILE_FAILED: "Failed to read file",
    SDK_INDEX_NAME_INVALID: "Invalid index name",
    SDK_INDEX_INVALID_PARAM: "Invalid parameter",
    SDK_RPC_FAILED: "rpc failed",
    SDK_NO_RETURN_CODE: "no return_code",
}


@dataclass
class CosmosXResult:
    code: int
    message: str
    data: Any = None

    @property
    def success(self) -> bool:
        return self.code == SUCCESS

def get_data_from_hdf5(hdf5_path: str, dataset_name: str = 'train') -> tuple:

    if not os.path.exists(hdf5_path):
        logger.error(f"HDF5文件不存在: {hdf5_path}")
        raise FileNotFoundError(f"HDF5文件不存在: {hdf5_path}")

    with h5py.File(hdf5_path, 'r') as f:
        data = f[dataset_name][()]

    num, dim = data.shape
    return data, num, dim

class CosmosXClient:
    def __init__(self, server_address, debug=False):
        options = [
                ('grpc.max_receive_message_length', 200 * 1024 * 1024),
                ('grpc.max_send_message_length',    200 * 1024 * 1024),
                ]
        self.channel = grpc.insecure_channel(server_address, options=options)
        self.stub = sdk_pb2_grpc.SdkServiceStub(self.channel)
        self.debug = debug
        self._thread_local = threading.local()
        logger.info(f"Client initialized for server {server_address}")

    def _success_result(self, data=None, message=None):
        return CosmosXResult(SUCCESS, message or ERROR_MESSAGES[SUCCESS], data)

    def _error_result(self, code, message=None, data=None):
        final_message = message or ERROR_MESSAGES.get(code, "operation failed")
        logger.error(f"operation failed: {final_message} (code={code})")
        return CosmosXResult(code, final_message, data)

    def _log_full_response(self, response, method_name):
        if self.debug:
            try:
                response_dict = MessageToDict(
                        response,
                        preserving_proto_field_name=True,
                        always_print_fields_with_no_presence=True
                )
                formatted = json.dumps(
                        response_dict,
                        indent=2,
                        ensure_ascii=False,
                        default=lambda x: str(x)
                        )
                logger.debug(f"FULL RESPONSE FOR {method_name}:\n{formatted}")
            except Exception as exc:
                logger.error(f"Failed to log full response: {str(exc)}")

    def _normalize_message(self, code, message, method_name):
        base_message = message or ERROR_MESSAGES.get(code, "operation failed")
        return f"{method_name} failed: {base_message}"

    def _check_response(self, response, method_name):
        if not response.HasField("code"):
            return self._error_result(
                SDK_NO_RETURN_CODE,
                self._normalize_message(SDK_NO_RETURN_CODE, ERROR_MESSAGES[SDK_NO_RETURN_CODE], method_name),
            )

        code = response.code.code
        if code != SUCCESS:
            return self._error_result(
                code,
                self._normalize_message(code, response.code.message, method_name),
            )

        return self._success_result(response)

    def _call_rpc(self, method_name, rpc_func, request):
        try:
            response = rpc_func(request)
        except grpc.RpcError as exc:
            details = exc.details() if hasattr(exc, 'details') else str(exc)
            return self._error_result(
                SDK_RPC_FAILED,
                self._normalize_message(SDK_RPC_FAILED, details or ERROR_MESSAGES[SDK_RPC_FAILED], method_name),
            )
        except Exception as exc:
            return self._error_result(
                SDK_COMMON_ERROR,
                self._normalize_message(SDK_COMMON_ERROR, str(exc), method_name),
            )

        self._log_full_response(response, method_name)
        return self._check_response(response, method_name)

    def _validate_index_name(self, name, method_name):
        if not isinstance(name, str):
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, "index name must be a string", method_name))
        if not name:
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, "index name is empty", method_name))
        if len(name) > G_INDEX_NAME_MAX_LEN or re.search(r'\W', name):
            return self._error_result(SDK_INDEX_NAME_INVALID, self._normalize_message(SDK_INDEX_NAME_INVALID, ERROR_MESSAGES[SDK_INDEX_NAME_INVALID], method_name))
        return None

    def _validate_dim(self, dim, method_name):
        if dim < G_MIN_DIM or dim > G_MAX_DIM:
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, f"invalid dim: {dim}", method_name))
        return None

    def _validate_card_num(self, card_num, method_name):
        if card_num < G_MIN_CARD_NUM or card_num > G_MAX_CARD_NUM:
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, f"invalid card_num: {card_num}", method_name))
        return None

    def _normalize_matrix_data(self, data, method_name):
        if not isinstance(data, np.ndarray):
            return None, self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, "data must be a numpy array", method_name))
        if len(data.shape) != 2:
            return None, self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, "data must be 2D array [num_vectors, dim]", method_name))

        normalized = data.astype(np.float32, copy=False)
        nb, dim = normalized.shape
        dim_result = self._validate_dim(dim, method_name)
        if dim_result is not None:
            return None, dim_result
        if nb > G_MAX_NB:
            return None, self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, f"invalid nb: {nb}", method_name))
        if normalized.size * np.dtype(np.float16).itemsize > G_MEMORY_CAPACITY:
            return None, self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, f"requested capacity is too large, nb={nb}, dim={dim}", method_name))
        return normalized, None

    def _create_stub(self):
        return sdk_pb2_grpc.SdkServiceStub(self.channel)

    def create_index(self, name, dim, replica_num=1, index_type=1, card_num=1):
        logger.info(f"Creating index: {name}, dim={dim}, replicas={replica_num}")
        name_result = self._validate_index_name(name, "create_index")
        if name_result is not None:
            return name_result
        dim_result = self._validate_dim(dim, "create_index")
        if dim_result is not None:
            return dim_result
        card_num_result = self._validate_card_num(card_num, "create_index")
        if card_num_result is not None:
            return card_num_result

        request = sdk_pb2.CreateIndexRequest(
                name=name,
                dim=dim,
                replica_num=replica_num,
                index_type=index_type,
                card_num=card_num
        )
        result = self._call_rpc("create_index", self.stub.create_index, request)
        if not result.success:
            return result

        logger.info(f"Index {name} created successfully")
        return self._success_result(message="create_index success")

    def create_index_on_cardids(self, name: str, dim: int, index_type: int, cardids: List[int]):
        logger.info(f"Creating index on cardids: {name}, dim={dim}, index_type={index_type}, cardids={cardids}")
        name_result = self._validate_index_name(name, "create_index")
        if name_result is not None:
            return name_result
        dim_result = self._validate_dim(dim, "create_index")
        if dim_result is not None:
            return dim_result
        if len(cardids) < G_MIN_CARD_NUM or len(cardids) > G_MAX_CARD_NUM:
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, f"invalid card_ids size: {len(cardids)}", "create_index"))

        request = sdk_pb2.CreateIndexRequest(
                name=name,
                dim=dim,
                index_type=index_type,
        )
        request.card_ids.extend(cardids)
        result = self._call_rpc("create_index", self.stub.create_index, request)
        if not result.success:
            return result

        logger.info(f"Index {name} created successfully")
        return self._success_result(message="create_index success")

    def delete_index(self, name):
        logger.info(f"Deleting index: {name}")
        name_result = self._validate_index_name(name, "delete_index")
        if name_result is not None:
            return name_result

        request = sdk_pb2.DeleteIndexRequest(name=name)
        result = self._call_rpc("delete_index", self.stub.delete_index, request)
        if not result.success:
            return result

        logger.info(f"Index {name} deleted successfully")
        return self._success_result(message="delete_index success")

    def query_all_index(self):
        logger.info("Querying all indexes")
        request = sdk_pb2.QueryAllIndexRequest()
        result = self._call_rpc("query_all_index", self.stub.query_all_index, request)
        if not result.success:
            return result

        response = result.data
        indexes = []
        for idx in response.indices:
            card_ids = list(getattr(idx, 'card_ids', []))
            indexes.append({
                'name': idx.name,
                'nlist': idx.nlist,
                'dim': idx.dim,
                'nb': idx.nb,
                'replica_num': idx.replica_num,
                'index_type': idx.index_type,
                'card_ids': card_ids
            })
        logger.info(f"Found {len(indexes)} indices")
        logger.debug(f"Indices details: {json.dumps(indexes, indent=2)}")
        return self._success_result(data=indexes, message="query_all_index success")

    def calculate_file_md5(self, file_path: str) -> str:
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as file_handle:
            for chunk in iter(lambda: file_handle.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()

    def upload_file(self, file_path: str, file_md5: str, chunk_size: int = 8192):
        if not os.path.exists(file_path):
            return self._error_result(SDK_READ_FILE_FAILED, self._normalize_message(SDK_READ_FILE_FAILED, f"file not found: {file_path}", "upload_file"))

        try:
            file_size = os.path.getsize(file_path)
        except OSError as exc:
            return self._error_result(SDK_READ_FILE_FAILED, self._normalize_message(SDK_READ_FILE_FAILED, str(exc), "upload_file"))

        file_name = os.path.basename(file_path)
        start_upload_request = sdk_pb2.StartUploadRequest(
            file_name=file_name,
            file_md5=file_md5,
            file_size=file_size,
        )

        start_result = self._call_rpc("start_upload", self.stub.start_upload, start_upload_request)
        if not start_result.success:
            return start_result

        start_upload_response = start_result.data
        try:
            with open(file_path, 'rb') as file_handle:
                if start_upload_response.received_size > 0:
                    file_handle.seek(start_upload_response.received_size)
                current_offset = start_upload_response.received_size
                while current_offset < file_size:
                    chunk_data = file_handle.read(chunk_size)
                    if not chunk_data:
                        return self._error_result(
                            SDK_READ_FILE_FAILED,
                            self._normalize_message(
                                SDK_READ_FILE_FAILED,
                                f"unexpected EOF while reading upload file at offset {current_offset}",
                                "upload_file",
                            ),
                        )
                    is_last_chunk = current_offset + len(chunk_data) >= file_size
                    upload_request = sdk_pb2.UploadChunkRequest(
                        server_file_id=start_upload_response.server_file_id,
                        chunk_data=chunk_data,
                        chunk_offset=current_offset,
                        chunk_size=len(chunk_data),
                        is_last_chunk=is_last_chunk
                    )
                    upload_result = self._call_rpc("upload_chunk", self.stub.upload_chunk, upload_request)
                    if not upload_result.success:
                        return upload_result
                    current_offset += len(chunk_data)
        except OSError as exc:
            return self._error_result(SDK_READ_FILE_FAILED, self._normalize_message(SDK_READ_FILE_FAILED, str(exc), "upload_file"))

        finish_upload_request = sdk_pb2.FinishUploadRequest(
            server_file_id=start_upload_response.server_file_id,
            expected_md5=file_md5
        )
        finish_result = self._call_rpc("finish_upload", self.stub.finish_upload, finish_upload_request)
        if not finish_result.success:
            return finish_result

        return self._success_result(
            data={'server_file_id': start_upload_response.server_file_id, 'file_md5': file_md5},
            message="upload_file success"
        )

    def train(self, name, data, nlist=128):
        name_result = self._validate_index_name(name, "train")
        if name_result is not None:
            return name_result

        normalized, data_result = self._normalize_matrix_data(data, "train")
        if data_result is not None:
            return data_result

        nb, dim = normalized.shape
        if nlist > nb or nlist > G_MAX_NLIST or nlist < 1:
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, f"invalid nlist: {nlist}, nb: {nb}", "train"))

        logger.info(f"Starting training: {name}, vector={nb}, dim={dim}, nlist={nlist}")

        import tempfile
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(suffix='.bin', delete=False) as temp_file:
                temp_path = temp_file.name
                temp_file.write(normalized.tobytes())
                temp_file.flush()

            file_md5 = self.calculate_file_md5(temp_path)
            upload_result = self.upload_file(temp_path, file_md5, 10240)
            if not upload_result.success:
                return upload_result

            request = sdk_pb2.TrainDataRequest(
                index_name=name,
                file_md5=file_md5,
                server_file_id=upload_result.data['server_file_id'],
                nb=nb,
                nlist=nlist,
                dim=dim
            )
            result = self._call_rpc("train_by_upload_file", self.stub.train_by_upload_file, request)
            if not result.success:
                return result
        finally:
            if temp_path and os.path.exists(temp_path):
                os.remove(temp_path)

        logger.info(f"Training completed for index {name}")
        return self._success_result(
            data=None,
            message="train success"
        )

    def add(self, name, data, mode_flag=0):
        del mode_flag
        name_result = self._validate_index_name(name, "add")
        if name_result is not None:
            return name_result

        normalized, data_result = self._normalize_matrix_data(data, "add")
        if data_result is not None:
            return data_result

        nb, dim = normalized.shape
        logger.info(f"Starting add: {name}, vectors={nb}, dim={dim}")

        import tempfile
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(suffix='.bin', delete=False) as temp_file:
                temp_path = temp_file.name
                temp_file.write(normalized.tobytes())
                temp_file.flush()

            file_md5 = self.calculate_file_md5(temp_path)
            upload_result = self.upload_file(temp_path, file_md5, 10240)
            if not upload_result.success:
                return upload_result

            request = sdk_pb2.AddDataRequest(
                index_name=name,
                file_md5=file_md5,
                server_file_id=upload_result.data['server_file_id'],
                nb=nb,
                dim=dim
            )

            result = self._call_rpc("add_by_upload_file", self.stub.add_by_upload_file, request)
            if not result.success:
                return result

            response = result.data
            ids = list(range(response.start_id, response.start_id + response.nb))
        finally:
            if temp_path and os.path.exists(temp_path):
                os.remove(temp_path)

        logger.info(f"Add {nb} vectors to index {name}")
        return self._success_result(
            data={'ids': ids},
            message="add success"
        )

    def search(self, name, queries, k=10, nprob=32, batch_size=100, max_workers=8):
        name_result = self._validate_index_name(name, "search")
        if name_result is not None:
            return name_result

        if k <= 0:
            return self._error_result(
                SDK_INDEX_INVALID_PARAM,
                self._normalize_message(SDK_INDEX_INVALID_PARAM, f"k must be > 0, got {k}", "search"),
            )
        if nprob <= 0:
            return self._error_result(
                SDK_INDEX_INVALID_PARAM,
                self._normalize_message(SDK_INDEX_INVALID_PARAM, f"nprobe must be > 0, got {nprob}", "search"),
            )
        if batch_size <= 0:
            return self._error_result(
                SDK_INDEX_INVALID_PARAM,
                self._normalize_message(SDK_INDEX_INVALID_PARAM, f"batch_size must be > 0, got {batch_size}", "search"),
            )
        if max_workers <= 0:
            return self._error_result(
                SDK_INDEX_INVALID_PARAM,
                self._normalize_message(SDK_INDEX_INVALID_PARAM, f"max_workers must be > 0, got {max_workers}", "search"),
            )

        normalized, data_result = self._normalize_matrix_data(queries, "search")
        if data_result is not None:
            return data_result

        nq, dim = normalized.shape
        if nprob > G_MAX_NLIST:
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, f"nprobe: {nprob} is greater than {G_MAX_NLIST}", "search"))
        if k > G_MAX_TOPK:
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, f"k: {k} is greater than {G_MAX_TOPK}", "search"))
        if nq > G_MAX_BATCH_SIZE:
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, f"nq: {nq} is greater than {G_MAX_BATCH_SIZE}", "search"))

        logger.info(f"Searching: {name}, queries={nq}, k={k}, nprob={nprob}")
        all_distances = np.empty((nq, k), dtype=np.float32)
        all_labels = np.empty((nq, k), dtype=np.int64)

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {}
            for start_idx in range(0, nq, batch_size):
                end_idx = min(start_idx + batch_size, nq)
                batch_queries = normalized[start_idx:end_idx]
                future = executor.submit(
                    self._process_batch,
                    name=name,
                    queries=batch_queries,
                    nprob=nprob,
                    k=k,
                    start_idx=start_idx,
                    end_idx=end_idx
                )
                futures[future] = (start_idx, end_idx)

            for future in concurrent.futures.as_completed(futures):
                start_idx, end_idx = futures[future]
                batch_result = future.result()
                if not batch_result.success:
                    return batch_result
                batch_data = batch_result.data
                all_distances[start_idx:end_idx] = batch_data['distances']
                all_labels[start_idx:end_idx] = batch_data['labels']
                logger.debug(f"Batch {start_idx}-{end_idx - 1} completed")

        logger.info(f"Search completed. Top{k} results per query")
        return self._success_result(
            data={'distances': all_distances, 'labels': all_labels},
            message="search success"
        )

    def _process_batch(self, name, queries, nprob, k, start_idx, end_idx):
        del start_idx, end_idx
        batch_nq = queries.shape[0]
        flat_queries = queries.flatten().tolist()
        request = sdk_pb2.SearchRequest(
            name=name,
            nq=batch_nq,
            query=flat_queries,
            nprobe=nprob,
            k=k
        )

        if not hasattr(self._thread_local, "stub"):
            self._thread_local.stub = self._create_stub()

        result = self._call_rpc("search", self._thread_local.stub.search, request)
        if not result.success:
            return result

        response = result.data
        batch_distances = np.array(response.distances).reshape(batch_nq, k)
        batch_labels = np.array(response.labels).reshape(batch_nq, k)
        return self._success_result(
            data={'distances': batch_distances, 'labels': batch_labels},
            message="search batch success"
        )

    def query_vector(self, name, vector_id, out_flag=0):
        logger.info(f"Querying vector: index={name}, id={vector_id}")
        name_result = self._validate_index_name(name, "query")
        if name_result is not None:
            return name_result

        request = sdk_pb2.QueryRequest(
                name=name,
                id=vector_id,
                out_flag=out_flag
        )
        result = self._call_rpc("query", self.stub.query, request)
        if not result.success:
            return result

        response = result.data
        logger.info(f"Vector {vector_id} queried successfully")
        logger.debug(f"Vector data length: {len(response.data)} floats")
        logger.debug(f"Digital data length: {len(response.digital_data)} floats")
        logger.debug(f"ReRAM data length: {len(response.reram_data)} ints")
        payload = list(response.data)
        return self._success_result(data=payload, message="query success")

    def update_vector(self, name, vector_id, data):
        logger.info(f"Updating vector: index={name}, id={vector_id}")
        name_result = self._validate_index_name(name, "update")
        if name_result is not None:
            return name_result
        if data is None:
            return self._error_result(SDK_INDEX_INVALID_PARAM, self._normalize_message(SDK_INDEX_INVALID_PARAM, "input data is null", "update"))

        request = sdk_pb2.UpdateRequest(
                name=name,
                id=vector_id,
                data=data
        )
        result = self._call_rpc("update", self.stub.update, request)
        if not result.success:
            return result

        logger.info(f"Vector {vector_id} updated successfully")
        return self._success_result(message="update success")

    def save_index(self, file_path: str, index_name: str):
        logger.info(f"Save index: file_path={file_path}, index_name={index_name}")
        name_result = self._validate_index_name(index_name, "save_index")
        if name_result is not None:
            return name_result

        request = sdk_pb2.SaveIndexRequest(
                index_name=index_name,
                file_path=file_path
        )
        result = self._call_rpc("save_index", self.stub.save_index, request)
        if not result.success:
            return result

        logger.info(f"Index {index_name} saved successfully")
        return self._success_result(data={'file_name': result.data.file_name}, message="save_index success")

    def load_index(self, file_path: str, index_name: str, card_num: int = 1):
        logger.info(f"Load index: file_path={file_path}, index_name={index_name}, card_num={card_num}")
        name_result = self._validate_index_name(index_name, "load_index")
        if name_result is not None:
            return name_result
        card_num_result = self._validate_card_num(card_num, "load_index")
        if card_num_result is not None:
            return card_num_result

        request = sdk_pb2.LoadIndexRequest(
                index_name=index_name,
                file_path=file_path,
                card_num=card_num
        )
        result = self._call_rpc("load_index", self.stub.load_index, request)
        if not result.success:
            return result

        logger.info(f"Index {index_name} loaded successfully")
        return self._success_result(message="load_index success")

    def delete_vector(self, name, vector_id):
        logger.info(f"Deleting vector: index={name}, id={vector_id}")
        name_result = self._validate_index_name(name, "remove")
        if name_result is not None:
            return name_result

        request = sdk_pb2.RemoveRequest(
                name=name,
                id=vector_id
        )
        result = self._call_rpc("remove", self.stub.remove, request)
        if not result.success:
            return result

        logger.info(f"Vector {vector_id} deleted successfully")
        return self._success_result(message="remove success")

def float32_generator(total_size, chunk_size):
    remaining = total_size
    while remaining > 0:
        size = min(remaining, chunk_size)
        yield np.random.rand(size // 4).astype(np.float32).tobytes()
        remaining -= size

