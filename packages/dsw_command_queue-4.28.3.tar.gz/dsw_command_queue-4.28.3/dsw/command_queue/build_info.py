# Generated file
# - do not overwrite
# - do not include in git
from collections import namedtuple

BuildInfo = namedtuple(
    'BuildInfo',
    ['version', 'built_at', 'sha', 'branch', 'tag'],
)

BUILD_INFO = BuildInfo(
    version='v4.28.3~4fb8cb6',
    built_at='2026-03-25 11:06:27Z',
    sha='4fb8cb614ff2841f73ab00ef7efe8c415af5da7a',
    branch='HEAD',
    tag='v4.28.3',
)
