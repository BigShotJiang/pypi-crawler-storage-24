from dr_llm.cli import app


if __name__ == "__main__":
    app()
