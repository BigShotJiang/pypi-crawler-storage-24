"""Validation endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from fiberpath.config import WindFileError, load_wind_definition

from ..path_policy import enforce_input_path_policy
from ..schemas import FilePathRequest, ValidateResponse

router = APIRouter()


@router.post("/from-file", response_model=ValidateResponse)
def validate_from_file(payload: FilePathRequest) -> ValidateResponse:
    try:
        load_wind_definition(enforce_input_path_policy(payload.path))
    except WindFileError as exc:  # pragma: no cover - HTTP glue
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return ValidateResponse(status="ok", path=payload.path)
