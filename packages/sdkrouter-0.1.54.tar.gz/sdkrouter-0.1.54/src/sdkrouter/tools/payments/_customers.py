"""Payments customers domain — sync and async mixins.

Customer endpoints use JWT auth — the customer is identified by the auth token,
not by customer_id parameter. These are for the customer-facing pay app.
"""

from __future__ import annotations

from typing import Any

from ...exceptions import api_error_handler, async_api_error_handler
from ..._api.generated.payments.payments__api__payments.models import (
    CustomerBalanceResponse,
    PaginatedCustomerInvoiceDetailList,
    PaginatedCustomerTransactionResponseList,
    PaginatedCustomerWithdrawalResponseList,
)


class _CustomersMixin:
    """Sync customer methods (JWT-authenticated)."""

    _api: Any

    @api_error_handler
    def customer_balance(self) -> CustomerBalanceResponse:
        """Get authenticated customer's balance."""
        return self._api.customer_balance_retrieve()

    @api_error_handler
    def customer_invoices(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerInvoiceDetailList:
        """List authenticated customer's invoices (payment history)."""
        return self._api.customer_invoices_list(page=page, page_size=page_size)

    @api_error_handler
    def customer_transactions(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerTransactionResponseList:
        """List authenticated customer's transactions."""
        return self._api.customer_transactions_list(page=page, page_size=page_size)

    @api_error_handler
    def customer_withdrawals(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerWithdrawalResponseList:
        """List authenticated customer's withdrawal requests."""
        return self._api.customer_withdrawals_list(page=page, page_size=page_size)


class _AsyncCustomersMixin:
    """Async customer methods (JWT-authenticated)."""

    _api: Any

    @async_api_error_handler
    async def customer_balance(self) -> CustomerBalanceResponse:
        """Get authenticated customer's balance."""
        return await self._api.customer_balance_retrieve()

    @async_api_error_handler
    async def customer_invoices(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerInvoiceDetailList:
        """List authenticated customer's invoices."""
        return await self._api.customer_invoices_list(page=page, page_size=page_size)

    @async_api_error_handler
    async def customer_transactions(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerTransactionResponseList:
        """List authenticated customer's transactions."""
        return await self._api.customer_transactions_list(page=page, page_size=page_size)

    @async_api_error_handler
    async def customer_withdrawals(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerWithdrawalResponseList:
        """List authenticated customer's withdrawal requests."""
        return await self._api.customer_withdrawals_list(page=page, page_size=page_size)
