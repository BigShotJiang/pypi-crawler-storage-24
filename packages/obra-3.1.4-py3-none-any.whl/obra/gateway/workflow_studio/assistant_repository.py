"""In-memory assistant thread and turn repository for Phase A."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal
from uuid import uuid4

from fastapi import Request

_UNSET = object()


@dataclass
class AssistantThread:
    """A named conversation thread in the assistant."""

    thread_id: str
    project_id: str
    name: str
    created_at: str
    updated_at: str
    archived: bool = False
    safety_mode: str = "advisory"
    turn_count: int = 0
    model_id: str | None = None


@dataclass
class AssistantTurn:
    """A single turn (user or assistant) within a thread."""

    turn_id: str
    thread_id: str
    role: Literal["user", "assistant"]
    message: str
    context: dict[str, Any] | None = None
    outcome: Literal["advice", "proposal", "applied", "conflict", "rejected", "reverted"] | None = None
    action_records: list[dict[str, Any]] | None = None
    created_at: str = ""


class AssistantRepository:
    """In-memory thread and turn storage for Phase A.

    The interface is designed so Phase B can swap in Firestore or local JSON
    persistence without changing callers.
    """

    def __init__(self) -> None:
        self._threads: dict[str, AssistantThread] = {}
        self._turns: dict[str, list[AssistantTurn]] = {}

    @classmethod
    def from_request(cls, request: Request) -> AssistantRepository:
        """Extract or lazily create the repository from app state."""
        repo = getattr(request.app.state, "assistant_repository", None)
        if repo is None:
            repo = cls()
            request.app.state.assistant_repository = repo
        return repo

    def create_thread(
        self,
        project_id: str,
        name: str,
        safety_mode: str = "advisory",
        thread_id: str | None = None,
    ) -> AssistantThread:
        """Create a new conversation thread."""
        now = datetime.now(tz=timezone.utc).isoformat()
        thread = AssistantThread(
            thread_id=thread_id or str(uuid4()),
            project_id=project_id,
            name=name,
            created_at=now,
            updated_at=now,
            safety_mode=safety_mode,
        )
        self._threads[thread.thread_id] = thread
        self._turns[thread.thread_id] = []
        return thread

    def list_threads(
        self,
        project_id: str,
        archived: bool = False,
    ) -> list[AssistantThread]:
        """List threads for a project, optionally filtering by archived status."""
        return [
            t
            for t in self._threads.values()
            if t.project_id == project_id and t.archived == archived
        ]

    def get_thread(self, thread_id: str) -> AssistantThread | None:
        """Return a thread by ID, or None if not found."""
        return self._threads.get(thread_id)

    def update_thread(
        self,
        thread_id: str,
        name: str | None = None,
        archived: bool | None = None,
        safety_mode: str | None = None,
        model_id: str | None | object = _UNSET,
    ) -> AssistantThread | None:
        """Update mutable thread fields. Returns None if not found."""
        thread = self._threads.get(thread_id)
        if thread is None:
            return None
        if name is not None:
            thread.name = name
        if archived is not None:
            thread.archived = archived
        if safety_mode is not None:
            thread.safety_mode = safety_mode
        if model_id is not _UNSET:
            thread.model_id = model_id
        thread.updated_at = datetime.now(tz=timezone.utc).isoformat()
        return thread

    def list_turns(self, thread_id: str) -> list[AssistantTurn]:
        """Return all turns for a thread (empty list if thread not found)."""
        return list(self._turns.get(thread_id, []))

    def get_turn(self, thread_id: str, turn_id: str) -> AssistantTurn | None:
        """Return one turn by id."""
        for turn in self._turns.get(thread_id, []):
            if turn.turn_id == turn_id:
                return turn
        return None

    def update_turn(
        self,
        thread_id: str,
        turn_id: str,
        *,
        message: str | None = None,
        outcome: str | None = None,
        action_records: list[dict[str, Any]] | None = None,
    ) -> AssistantTurn | None:
        """Update mutable fields on an existing turn."""
        turn = self.get_turn(thread_id, turn_id)
        if turn is None:
            return None
        if message is not None:
            turn.message = message
        if outcome is not None:
            turn.outcome = outcome  # type: ignore[assignment]
        if action_records is not None:
            turn.action_records = action_records
        thread = self._threads.get(thread_id)
        if thread is not None:
            thread.updated_at = datetime.now(tz=timezone.utc).isoformat()
        return turn

    def append_turn(
        self,
        thread_id: str,
        role: str,
        message: str,
        context: dict[str, Any] | None = None,
        outcome: str | None = None,
        action_records: list[dict[str, Any]] | None = None,
    ) -> AssistantTurn:
        """Append a turn to a thread and increment turn_count."""
        now = datetime.now(tz=timezone.utc).isoformat()
        turn = AssistantTurn(
            turn_id=str(uuid4()),
            thread_id=thread_id,
            role=role,  # type: ignore[arg-type]
            message=message,
            context=context,
            outcome=outcome,  # type: ignore[arg-type]
            action_records=action_records,
            created_at=now,
        )
        if thread_id not in self._turns:
            self._turns[thread_id] = []
        self._turns[thread_id].append(turn)
        thread = self._threads.get(thread_id)
        if thread is not None:
            thread.turn_count += 1
            thread.updated_at = now
        return turn
