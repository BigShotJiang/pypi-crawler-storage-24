import os

def get_env(key):
  value = os.getenv(key)
  if not value:
    raise ValueError(f"Missing environment variable: {key}")
  return value