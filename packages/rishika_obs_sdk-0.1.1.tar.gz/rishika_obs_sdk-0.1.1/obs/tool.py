from .manager import ToolManager
from .context import TraceContext

class Tool:
  def __init__(self):
    self.manager = ToolManager()

  def init(self, tools):
    for t in tools:
      t.init()
      self.manager.register(t)

  def trace(self, name, input=None):
    return TraceContext(self.manager, name, input)