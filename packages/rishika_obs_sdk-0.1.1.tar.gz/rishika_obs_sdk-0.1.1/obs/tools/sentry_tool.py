import sentry_sdk

class SentryTool(BaseTool):
  def init(self):
    sentry_sdk.init()

  def push(self, trace_id, name, input, output, start_time, end_time, error):
    with sentry_sdk.start_transaction(name=name):
      if error:
        sentry_sdk.capture_exception(Exception(error))