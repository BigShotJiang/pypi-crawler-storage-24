from obs.tools.base import BaseTool
from obs.utils.config import get_env
from obs.utils.otel import init_tracer

from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
import base64


class LangfuseTool(BaseTool):

  def init(self):

    provider = init_tracer()

    public = get_env("LANGFUSE_PUBLIC_KEY")
    secret = get_env("LANGFUSE_SECRET_KEY")
    host = get_env("LANGFUSE_HOST")

    auth = base64.b64encode(f"{public}:{secret}".encode()).decode()

    exporter = OTLPSpanExporter(
      endpoint=f"{host}/api/public/otel/v1/traces",   # ✅ FIXED
      headers={
        "Authorization": f"Basic {auth}"
      }
    )

    provider.add_span_processor(SimpleSpanProcessor(exporter))


  def push(self, trace_id, name, input=None, output=None):
    pass