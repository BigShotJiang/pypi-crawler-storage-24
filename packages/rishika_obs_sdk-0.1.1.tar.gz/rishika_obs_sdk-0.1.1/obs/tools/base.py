class BaseTool:
  def init(self):
    pass

  def push(self, trace_id, name, input, output, start_time, end_time, error):
    raise NotImplementedError