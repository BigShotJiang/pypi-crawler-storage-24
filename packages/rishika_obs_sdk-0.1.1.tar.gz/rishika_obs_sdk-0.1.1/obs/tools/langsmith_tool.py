from langsmith import Client

class LangSmithTool(BaseTool):
  def __init__(self):
    self.client = None

  def init(self):
    self.client = Client()

  def push(self, trace_id, name, input, output, start_time, end_time, error):
    self.client.create_run(
      name=name,
      inputs={"input": input},
      outputs={"output": output},
      error=error,
      run_type="chain"
    )