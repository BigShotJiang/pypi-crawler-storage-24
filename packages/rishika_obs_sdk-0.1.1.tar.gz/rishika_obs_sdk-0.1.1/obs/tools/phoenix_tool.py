from obs.tools.base import BaseTool
from obs.utils.config import get_env
from obs.utils.otel import init_tracer

from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry import trace
from opentelemetry.sdk.trace.export import BatchSpanProcessor

class PhoenixTool(BaseTool):

  def init(self):

    provider = init_tracer()

    exporter = OTLPSpanExporter(
      endpoint=get_env("PHOENIX_ENDPOINT")
    )

    provider.add_span_processor(SimpleSpanProcessor(exporter))

    self.tracer = trace.get_tracer("obs")


  def push(self, trace_id, name, input=None, output=None):

    with self.tracer.start_as_current_span(name) as span:

      span.set_attribute("trace_id", trace_id)

      if input:
        span.set_attribute("input", str(input))

      if output:
        span.set_attribute("output", str(output))