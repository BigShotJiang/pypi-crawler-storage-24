from opentelemetry.sdk.trace import TracerProvider
from opentelemetry import trace

_initialized = False

def init_tracer():

  global _initialized

  if _initialized:
    return trace.get_tracer_provider()

  provider = TracerProvider()
  trace.set_tracer_provider(provider)

  _initialized = True

  return provider