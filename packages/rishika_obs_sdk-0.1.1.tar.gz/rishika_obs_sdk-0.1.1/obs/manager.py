class ToolManager:
  def __init__(self):
    self.tools = []

  def register(self, tool):
    self.tools.append(tool)

  def push_all(self, **kwargs):
    for tool in self.tools:
      try:
        tool.push(**kwargs)
      except Exception as e:
        print(f"[OBS ERROR] {tool.__class__.__name__}: {e}")