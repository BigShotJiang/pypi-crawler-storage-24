![visfem logo](./docs/images/favicon/visfem-100x100-300dpi.png)

# visfem: python utilities for metadata and COMBINE archives
[![GitHub Actions CI/CD Status](https://github.com/matthiaskoenig/visfem/workflows/CI-CD/badge.svg)](https://github.com/matthiaskoenig/visfem/actions/workflows/main.yml)
[![Version](https://img.shields.io/pypi/v/visfem.svg)](https://pypi.org/project/visfem/)
[![Python Versions](https://img.shields.io/pypi/pyversions/visfem.svg)](https://pypi.org/project/visfem/)
[![MIT License](https://img.shields.io/pypi/l/visfem.svg)](https://opensource.org/licenses/MIT)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.5308801.svg)](https://doi.org/10.5281/zenodo.5308801)

VisFEM is a collection of python utilities for visualization of FEM models with code available from
[https://github.com/matthiaskoenig/visfem](https://github.com/matthiaskoenig/visfem).


# Installation
`visfem` is available from [pypi](https://pypi.python.org/pypi/visfem) and
can be installed via

```bash
pip install visfem
```

## How to cite
To cite the software repository

> Nemitz, N., Elias, M. & König, M. (2025).
> *VisFEM: Web visualization of FEM models.*
> Zenodo. [https://doi.org/10.5281/zenodo.13987865](https://doi.org/10.5281/zenodo.13987865)


## License

* Source Code: [MIT](https://opensource.org/license/MIT)
* Documentation: [CC BY-SA 4.0](http://creativecommons.org/licenses/by-sa/4.0/)
* Models: [CC BY-SA 4.0](http://creativecommons.org/licenses/by-sa/4.0/)

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.

# Funding
Matthias König is supported and by the German Research Foundation (DFG) within the Research Unit Programme FOR 5151
"QuaLiPerF (Quantifying Liver Perfusion-Function Relationship in Complex Resection -
A Systems Medicine Approach)" by grant number 436883643 and by grant number
465194077 (Priority Programme SPP 2311, Subproject SimLivA).

Matthias König was supported by the Federal Ministry of Education and Research (BMBF, Germany)
within the research network Systems Medicine of the Liver (LiSyM, grant number 031L0054).

© 2026 Michelle Elias & Matthias König
