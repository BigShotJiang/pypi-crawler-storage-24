"""dopeTask package assets."""
