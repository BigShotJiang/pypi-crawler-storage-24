from dataclasses import dataclass
from typing import Optional


@dataclass
class TraceContext:
    trace_id: str
    session_id: str
    parent_span_id: Optional[str] = None

