from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path
from typing import List, Tuple

INSTRUMENTATION_PREAMBLE = '''\
# ── PUVINoise SDK instrumentation (auto-injected by sidecar) ──────────────
import os as _puvi_os
from pathlib import Path as _PuviPath
try:
    from dotenv import load_dotenv as _puvi_load_dotenv
    _puvi_load_dotenv(_PuviPath(__file__).resolve().parent / ".env")
except ImportError:
    pass
try:
    import puvinoise
    puvinoise.bootstrap()
except Exception:
    pass
# ── End PUVINoise SDK instrumentation ─────────────────────────────────────
'''

INSTRUMENTATION_MARKER = "PUVINoise SDK instrumentation (auto-injected by sidecar)"


def validate_python_syntax(path: Path) -> Tuple[bool, str]:
    if not path.exists():
        return False, f"file not found: {path}"
    try:
        result = subprocess.run(
            [sys.executable, "-m", "py_compile", str(path)],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode == 0:
            return True, ""
        return False, (result.stderr or result.stdout or "unknown compile error").strip()[:500]
    except Exception as exc:
        return False, str(exc)


def find_instrumentation_insert_index(lines: List[str]) -> int:
    i = 0
    n = len(lines)
    if i < n and lines[i].startswith("#!"):
        i += 1
    while i < n and lines[i].strip() == "":
        i += 1
    if i < n and lines[i].strip().startswith("#") and "coding" in lines[i]:
        i += 1
        while i < n and lines[i].strip() == "":
            i += 1
    if i < n:
        raw = lines[i].lstrip()
        if raw.startswith('"""') or raw.startswith("'''"):
            q = '"""' if raw.startswith('"""') else "'''"
            body = raw[3:]
            if body.rstrip().endswith(q) and body.count(q) >= 1:
                i += 1
            else:
                i += 1
                while i < n:
                    if q in lines[i]:
                        i += 1
                        break
                    i += 1
            while i < n and lines[i].strip() == "":
                i += 1
    while i < n:
        st = lines[i].strip()
        if st == "" or st.startswith("#"):
            i += 1
            continue
        if not st.startswith("from __future__"):
            break
        start = i
        i += 1
        while i < n and lines[i - 1].rstrip().endswith("\\"):
            i += 1
        paren = 0
        for k in range(start, i):
            paren += lines[k].count("(") - lines[k].count(")")
        while paren > 0 and i < n:
            paren += lines[i].count("(") - lines[i].count(")")
            i += 1
    return i


def build_python_wrapper_with_rollback(agent_file: Path) -> Tuple[bool, str]:
    if not agent_file.exists():
        return False, f"file not found: {agent_file}"
    content = agent_file.read_text(encoding="utf-8")
    if INSTRUMENTATION_MARKER in content:
        return True, "already instrumented"

    syntax_ok, syntax_err = validate_python_syntax(agent_file)
    if not syntax_ok:
        return False, f"pre-check compile failed: {syntax_err}"

    backup = agent_file.parent / "run_original.py"
    if not backup.exists():
        shutil.copy2(str(agent_file), str(backup))

    lines = content.split("\n")
    insert_at = find_instrumentation_insert_index(lines)
    new_lines = lines[:insert_at] + INSTRUMENTATION_PREAMBLE.rstrip("\n").split("\n") + [""] + lines[insert_at:]
    patched = "\n".join(new_lines)
    agent_file.write_text(patched, encoding="utf-8")

    post_ok, post_err = validate_python_syntax(agent_file)
    if post_ok:
        return True, "instrumentation injected"

    shutil.copy2(str(backup), str(agent_file))
    return False, f"post-check compile failed, rolled back: {post_err}"

