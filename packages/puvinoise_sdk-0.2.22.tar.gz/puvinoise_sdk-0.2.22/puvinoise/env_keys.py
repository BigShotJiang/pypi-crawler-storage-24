import os


def get_agent_id():
    return os.environ.get("PUVI_AGENT_ID") or os.environ.get("PUVINOISE_AGENT_ID")


def get_access_key():
    return os.environ.get("PUVINOISE_AGENTACCESSKEY") or os.environ.get("PUVI_API_KEY")


def get_tenant_id():
    return os.environ.get("PUVINOISE_TENANTID")


def get_platform_url():
    return os.environ.get("PUVINOISE_PLATFORM_URL")


def get_deploy_env():
    return os.environ.get("PUVI_DEPLOY_ENV") or os.environ.get("PUVINOISE_DEPLOY_ENV")
