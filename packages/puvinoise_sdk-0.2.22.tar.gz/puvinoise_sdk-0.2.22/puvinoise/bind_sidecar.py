#!/usr/bin/env python3 -u
"""
PUVINoise bind sidecar (standalone).

Purpose:
- Handle bind probe, token registration, runtime metadata report, and heartbeat loop.
- After registration: pull bootstrap config (.env, wrapper, SDK install) from the platform.
- Validate wrapper application with syntax check before enabling.

After the bind probe, POST /api/register returns 409 until an admin approves the bind in
Register Agent → Step 3. This script polls until approval (use --loop for an unbounded wait on the agent host).

Required env:
- PUVINOISE_PLATFORM_URL
- PUVINOISE_REGISTRATION_TOKEN
- PUVI_AGENT_NAME
- PUVI_DEPLOY_ENV (recommended)
- PUVI_DEPLOY_VERSION (recommended)
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from puvinoise.wrapper_builder import (
    INSTRUMENTATION_MARKER,
    build_python_wrapper_with_rollback,
)

SIDECAR_VERSION = "2"
STATE_FILE = Path(tempfile.gettempdir()) / "puvi_bind_state.json"
SIDEAR_SDK_VERSION = f"bind-sidecar-standalone-{SIDECAR_VERSION}"
SIDEAR_WRAPPER_VERSION = f"proxy-stub-{SIDECAR_VERSION}"
MIN_SDK_VERSION = (0, 2, 16)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing required env var: {name}")
    return value


def _post_json(url: str, payload: Dict[str, Any], bearer: Optional[str] = None, timeout: int = 15) -> Dict[str, Any]:
    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), method="POST")
    req.add_header("Content-Type", "application/json")
    if bearer:
        req.add_header("Authorization", f"Bearer {bearer}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} {url}: {body or e.reason}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Network error {url}: {e.reason}") from e


def _load_state() -> Dict[str, Any]:
    if not STATE_FILE.exists():
        return {}
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_state(state: Dict[str, Any]) -> None:
    STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")


def _clear_state() -> None:
    try:
        if STATE_FILE.exists():
            STATE_FILE.unlink()
    except Exception:
        pass


def emit_probe(platform_url: str, registration_token: str, agent_name: str, deploy_env: str, deploy_version: str) -> None:
    try:
        _post_json(
            f"{platform_url.rstrip('/')}/api/register/probe",
            {
                "registration_token": registration_token,
                "agent_name": agent_name,
                "metadata": {"deploy_env": deploy_env, "deploy_version": deploy_version},
            },
            timeout=10,
        )
    except Exception as exc:
        msg = str(exc)
        # Token may already be USED by a prior /api/register call; probe is advisory.
        if (
            "Registration token is not active" in msg
            or "token is not active" in msg
            or "Registration token expired" in msg
            or "token expired" in msg
        ):
            print("[puvi-bind-sidecar] probe skipped: token already consumed or expired")
            return
        raise


def _is_bind_pending_approval_error(err: Exception) -> bool:
    msg = str(err)
    return "409" in msg and ("BIND_NOT_APPROVED" in msg or "PENDING_APPROVAL" in msg)


def _register_once(
    platform_url: str,
    registration_token: str,
    agent_name: str,
    deploy_env: str,
    deploy_version: str,
) -> Dict[str, Any]:
    resp = _post_json(
        f"{platform_url.rstrip('/')}/api/register",
        {
            "registration_token": registration_token,
            "agent_name": agent_name,
            "metadata": {"deploy_env": deploy_env, "deploy_version": deploy_version},
        },
        timeout=20,
    )
    next_state = {
        "agent_id": str(resp.get("agent_id", "")).strip(),
        "agent_access_key": str(resp.get("agent_access_key", "")).strip(),
        "platform_url": platform_url.rstrip("/"),
        "registration_token": registration_token,
        "agent_name": agent_name,
        "deploy_env": deploy_env,
        "registered_at": _now_iso(),
    }
    if not next_state["agent_id"] or not next_state["agent_access_key"]:
        raise RuntimeError("Registration succeeded but missing agent_id or agent_access_key")
    _save_state(next_state)
    return next_state


def ensure_registered(
    platform_url: str,
    registration_token: str,
    agent_name: str,
    deploy_env: str,
    deploy_version: str,
    *,
    approval_max_wait_s: Optional[float] = 240.0,
    approval_poll_interval_s: float = 5.0,
) -> Dict[str, Any]:
    """
    Complete POST /api/register. If the bind intent exists but is not approved yet, the API returns 409
    (BIND_NOT_APPROVED). Poll until approved or until approval_max_wait_s elapses.

    approval_max_wait_s:
      - None  → wait indefinitely (use with --loop on the agent host).
      - float → seconds, then raise with instructions to approve in UI and retry (default 240).
    """
    state = _load_state()
    same_context = (
        str(state.get("platform_url", "")).strip() == platform_url.rstrip("/")
        and str(state.get("registration_token", "")).strip() == registration_token
        and str(state.get("agent_name", "")).strip() == agent_name
        and str(state.get("deploy_env", "")).strip() == deploy_env
    )
    if same_context and state.get("agent_access_key") and state.get("agent_id"):
        return state

    start = time.time()
    attempt = 0
    while True:
        attempt += 1
        try:
            return _register_once(
                platform_url,
                registration_token,
                agent_name,
                deploy_env,
                deploy_version,
            )
        except RuntimeError as e:
            if not _is_bind_pending_approval_error(e):
                raise
            elapsed = time.time() - start
            if approval_max_wait_s is not None and elapsed >= approval_max_wait_s:
                raise RuntimeError(
                    "Binding is still waiting for administrator approval in PUVINoise "
                    "(Register Agent → Step 3 Registration → Approve binding). "
                    "After you approve, run this command again, or use --loop to wait automatically."
                ) from e
            if attempt == 1 or attempt % 6 == 0:
                print(
                    "[puvi-bind-sidecar] Bind intent recorded; waiting for approval in PUVINoise UI… "
                    f"(poll #{attempt}, {int(elapsed)}s elapsed)"
                )
            time.sleep(max(2.0, approval_poll_interval_s))


def report_runtime_metadata(
    platform_url: str,
    access_key: str,
    agent_id: str,
    agent_name: str,
    deploy_env: str,
    deploy_version: str,
    installed_sdk_version: str = "",
    readiness_ok: Optional[bool] = None,
    readiness_issues: Optional[List[str]] = None,
    trace_probe_status: str = "",
    trace_probe_details: Optional[List[str]] = None,
) -> None:
    """Report agent registration metadata to the platform.
    installed_sdk_version: the real puvinoise-sdk version from PyPI (e.g. "0.2.16"),
    as returned by ensure_sdk_installed(). Falls back to SIDEAR_SDK_VERSION only if
    the real version is not yet known.
    """
    sdk_ver = installed_sdk_version.strip() if installed_sdk_version.strip() else SIDEAR_SDK_VERSION
    _post_json(
        f"{platform_url.rstrip('/')}/api/agent-register",
        {
            "agentId": agent_id,
            "agentName": agent_name,
            "framework": "customer-runtime",
            "llmProvider": "unknown",
            "model": "n/a",
            "tools": [],
            "environment": deploy_env,
            "version": deploy_version,
            "runtime_metadata": {
                "agent_name": agent_name,
                "sdk_language": "python",
                "sdk_version": sdk_ver,
                "wrapper_version": SIDEAR_WRAPPER_VERSION,
                "deploy_env": deploy_env,
                "deploy_version": deploy_version,
                "runtime": "bind-sidecar-standalone",
                "host": socket.gethostname(),
                "instance_id": f"bind-{int(time.time())}",
                "bootstrap_readiness_status": (
                    "PASS" if readiness_ok is True else "FAIL" if readiness_ok is False else ""
                ),
                "bootstrap_readiness_issues": readiness_issues or [],
                "bootstrap_readiness_checked_at": _now_iso() if readiness_ok is not None else "",
                "trace_probe_status": str(trace_probe_status or "").strip(),
                "trace_probe_details": trace_probe_details or [],
            },
        },
        bearer=access_key,
        timeout=45,
    )


def send_heartbeat(platform_url: str, access_key: str, agent_id: str, deploy_env: str, installed_sdk_version: str = "") -> None:
    sdk_ver = installed_sdk_version.strip() if installed_sdk_version.strip() else SIDEAR_SDK_VERSION
    _post_json(
        f"{platform_url.rstrip('/')}/api/agent-heartbeat",
        {
            "agentId": agent_id,
            "status": "running",
            "timestamp": _now_iso(),
            "environment": deploy_env,
            "ready": True,
            "pending_update": False,
            "sdk_version": sdk_ver,
            "wrapper_version": SIDEAR_WRAPPER_VERSION,
            "runtime": {
                "runtimeId": f"bind-{agent_id}",
                "hostName": socket.gethostname(),
                "runtimeType": "bind-sidecar-standalone",
            },
        },
        bearer=access_key,
        timeout=20,
    )


def _get_json(url: str, bearer: Optional[str] = None, timeout: int = 15) -> Dict[str, Any]:
    req = urllib.request.Request(url, method="GET")
    req.add_header("Accept", "application/json")
    if bearer:
        req.add_header("Authorization", f"Bearer {bearer}")
        req.add_header("X-Api-Key", bearer)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} {url}: {body or e.reason}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Network error {url}: {e.reason}") from e


# ─────────────────────────────────────────────────────────────────────────────
# GAP 1: Bootstrap config pull — .env, wrapper, SDK install command
# ─────────────────────────────────────────────────────────────────────────────

def pull_bootstrap_config(
    platform_url: str,
    access_key: str,
    agent_id: str,
    agent_name: str,
    workdir: Path,
) -> Dict[str, Any]:
    """
    Fetch the full bootstrap config from GET /api/agent/config/:agentId
    and write .env + wrapper script to the agent working directory.
    Returns the parsed config body.
    """
    url = f"{platform_url.rstrip('/')}/api/agent/config/{agent_id}"
    print(f"[puvi-bind-sidecar] pulling bootstrap config from {url}")
    try:
        cfg = _get_json(url, bearer=access_key, timeout=20)
    except Exception as exc:
        # Retry with agent name if agent_id lookup failed
        try:
            url2 = f"{platform_url.rstrip('/')}/api/agent/config/{agent_name}"
            cfg = _get_json(url2, bearer=access_key, timeout=20)
        except Exception:
            print(f"[puvi-bind-sidecar] bootstrap config pull failed: {exc}")
            return {}

    # Write .env file
    env_content = str(cfg.get("envFile") or cfg.get("envTemplate") or "").strip()
    if env_content:
        env_path = workdir / ".env"
        # Preserve customer OPENAI_API_KEY if already set
        existing_openai_key = ""
        if env_path.exists():
            for line in env_path.read_text(encoding="utf-8").splitlines():
                if line.startswith("OPENAI_API_KEY=") and line.split("=", 1)[1].strip():
                    existing_openai_key = line.split("=", 1)[1].strip()
                    break
        # Backup existing .env
        if env_path.exists():
            backup = workdir / ".env.bak"
            shutil.copy2(str(env_path), str(backup))
        env_path.write_text(env_content + "\n", encoding="utf-8")
        # Restore customer API key if the new env has it empty
        if existing_openai_key:
            text = env_path.read_text(encoding="utf-8")
            if "OPENAI_API_KEY=\n" in text or text.endswith("OPENAI_API_KEY="):
                text = text.replace("OPENAI_API_KEY=", f"OPENAI_API_KEY={existing_openai_key}", 1)
                env_path.write_text(text, encoding="utf-8")
        print(f"[puvi-bind-sidecar] .env written ({len(env_content)} bytes) → {env_path}")
    else:
        print("[puvi-bind-sidecar] warning: no envFile in bootstrap config response")

    # Write wrapper script
    wrapper_content = str(cfg.get("wrapperScript") or "").strip()
    if wrapper_content:
        wrapper_path = workdir / "puvinoise-wrapper.sh"
        wrapper_path.write_text(wrapper_content + "\n", encoding="utf-8")
        wrapper_path.chmod(0o755)
        print(f"[puvi-bind-sidecar] wrapper script written → {wrapper_path}")

    # Write restart script
    restart_content = str(cfg.get("restartScript") or "").strip()
    if restart_content:
        restart_path = workdir / "puvinoise-agent-restart.sh"
        restart_path.write_text(restart_content + "\n", encoding="utf-8")
        restart_path.chmod(0o755)

    return cfg


# ─────────────────────────────────────────────────────────────────────────────
# GAP 2: SDK version ↔ wrapper compatibility check
# ─────────────────────────────────────────────────────────────────────────────

def _parse_semver(v: str) -> Tuple[int, ...]:
    parts: List[int] = []
    for p in str(v or "").split("."):
        digits = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts) if parts else (0,)


def check_sdk_version_compatibility(min_required: Tuple[int, ...] = MIN_SDK_VERSION) -> Tuple[bool, str]:
    """
    Check if installed puvinoise SDK meets the minimum version required by this sidecar.
    Returns (compatible: bool, installed_version: str).
    """
    try:
        result = subprocess.run(
            [sys.executable, "-c", "from importlib.metadata import version; print(version('puvinoise'))"],
            capture_output=True, text=True, timeout=10,
        )
        installed = result.stdout.strip()
        if not installed and result.returncode != 0:
            # Try alternate package name
            result2 = subprocess.run(
                [sys.executable, "-c", "from importlib.metadata import version; print(version('puvinoise-sdk'))"],
                capture_output=True, text=True, timeout=10,
            )
            installed = result2.stdout.strip()
        if not installed:
            return False, "not installed"
        parsed = _parse_semver(installed)
        if parsed >= min_required:
            return True, installed
        min_str = ".".join(str(x) for x in min_required)
        print(f"[puvi-bind-sidecar] SDK version {installed} < required {min_str}")
        return False, installed
    except Exception as exc:
        print(f"[puvi-bind-sidecar] SDK version check error: {exc}")
        return False, "check failed"


# ─────────────────────────────────────────────────────────────────────────────
# GAP 3: SDK installation
# ─────────────────────────────────────────────────────────────────────────────

def ensure_sdk_installed(sdk_install_command: str = "") -> Tuple[bool, str]:
    """
    Install or upgrade the PUVINoise SDK if not present or below minimum version.
    Returns (success: bool, version: str).
    """
    compatible, version = check_sdk_version_compatibility()
    if compatible:
        print(f"[puvi-bind-sidecar] SDK {version} is compatible (>= {'.'.join(str(x) for x in MIN_SDK_VERSION)})")
        return True, version

    cmd = sdk_install_command.strip() if sdk_install_command else ""
    if not cmd:
        # Try local wheel first (common in dev/on-prem)
        workdir = Path.cwd()
        local_wheels = sorted(workdir.glob("puvinoise_sdk-*.whl")) + sorted(
            Path(__file__).resolve().parent.glob("puvinoise_sdk-*.whl")
        )
        if local_wheels:
            cmd = f"{sys.executable} -m pip install -U '{local_wheels[-1]}'"
        else:
            # Try downloading the wheel from the platform
            platform_url = os.environ.get("PUVINOISE_PLATFORM_URL", "").rstrip("/")
            if platform_url:
                wheel_url = f"{platform_url}/api/registration/sdk-wheel"
                try:
                    print(f"[puvi-bind-sidecar] downloading SDK wheel from {wheel_url}")
                    req = urllib.request.Request(wheel_url)
                    with urllib.request.urlopen(req, timeout=30) as resp:
                        # Extract original filename from Content-Disposition or URL
                        cd = resp.headers.get("Content-Disposition", "")
                        fname = ""
                        if "filename=" in cd:
                            fname = cd.split("filename=")[-1].strip().strip('"').strip("'")
                        if not fname or not fname.endswith(".whl"):
                            fname = "puvinoise_sdk-0.0.0-py3-none-any.whl"
                        wheel_path = workdir / fname
                        wheel_path.write_bytes(resp.read())
                    cmd = f"{sys.executable} -m pip install -U '{wheel_path}'"
                    print(f"[puvi-bind-sidecar] SDK wheel downloaded → {wheel_path}")
                except Exception as dl_exc:
                    print(f"[puvi-bind-sidecar] SDK wheel download failed: {dl_exc}")
                    cmd = f"{sys.executable} -m pip install -U puvinoise-sdk"
            else:
                cmd = f"{sys.executable} -m pip install -U puvinoise-sdk"

    print(f"[puvi-bind-sidecar] installing/upgrading SDK: {cmd}")
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            print(f"[puvi-bind-sidecar] SDK install failed (exit {result.returncode}): {result.stderr[:500]}")
            return False, version
        # Re-check version after install
        compatible_after, version_after = check_sdk_version_compatibility()
        if compatible_after:
            print(f"[puvi-bind-sidecar] SDK installed successfully: {version_after}")
            return True, version_after
        print(f"[puvi-bind-sidecar] SDK installed but version {version_after} still below minimum")
        return False, version_after
    except subprocess.TimeoutExpired:
        print("[puvi-bind-sidecar] SDK install timed out (120s)")
        return False, version
    except Exception as exc:
        print(f"[puvi-bind-sidecar] SDK install error: {exc}")
        return False, version


# ─────────────────────────────────────────────────────────────────────────────
# GAP 5: Inject PUVINoise SDK instrumentation into run.py
# ─────────────────────────────────────────────────────────────────────────────

INSTRUMENTATION_PREAMBLE = '''\
# ── PUVINoise SDK instrumentation (auto-injected by sidecar) ──────────────
import os as _puvi_os
from pathlib import Path as _PuviPath
try:
    from dotenv import load_dotenv as _puvi_load_dotenv
    _puvi_load_dotenv(_PuviPath(__file__).resolve().parent / ".env")
except ImportError:
    pass
try:
    import puvinoise
    puvinoise.bootstrap()
except Exception:
    pass
# ── End PUVINoise SDK instrumentation ─────────────────────────────────────
'''

INSTRUMENTATION_MARKER = "PUVINoise SDK instrumentation (auto-injected by sidecar)"


def find_instrumentation_insert_index(lines: list[str]) -> int:
    """
    Line index where instrumentation may be inserted. Python requires `from __future__`
    before any other imports; injecting after shebang only breaks files that use a
    module docstring then __future__ (common pattern).
    """
    i = 0
    n = len(lines)
    if i < n and lines[i].startswith("#!"):
        i += 1
    while i < n and lines[i].strip() == "":
        i += 1
    if i < n and lines[i].strip().startswith("#") and "coding" in lines[i]:
        i += 1
        while i < n and lines[i].strip() == "":
            i += 1
    # Optional module docstring
    if i < n:
        raw = lines[i].lstrip()
        if raw.startswith('"""') or raw.startswith("'''"):
            q = '"""' if raw.startswith('"""') else "'''"
            body = raw[3:]
            if body.rstrip().endswith(q) and body.count(q) >= 1:
                i += 1
            else:
                i += 1
                while i < n:
                    if q in lines[i]:
                        i += 1
                        break
                    i += 1
            while i < n and lines[i].strip() == "":
                i += 1
    # All from __future__ ... statements (may span lines with \\ or parentheses)
    while i < n:
        st = lines[i].strip()
        if st == "":
            i += 1
            continue
        if st.startswith("#"):
            i += 1
            continue
        if not st.startswith("from __future__"):
            break
        start = i
        i += 1
        while i < n and lines[i - 1].rstrip().endswith("\\"):
            i += 1
        paren = 0
        for k in range(start, i):
            paren += lines[k].count("(") - lines[k].count(")")
        while paren > 0 and i < n:
            paren += lines[i].count("(") - lines[i].count(")")
            i += 1
    return i


def inject_instrumentation(agent_file: Path) -> Tuple[bool, str]:
    ok, msg = build_python_wrapper_with_rollback(agent_file)
    if ok and msg == "already instrumented":
        print(f"[puvi-bind-sidecar] run.py already instrumented — skipping injection")
    elif ok:
        print(f"[puvi-bind-sidecar] instrumentation injected into {agent_file.name}")
    else:
        print(f"[puvi-bind-sidecar] instrumentation builder failed: {msg}")
    return ok, msg


# ─────────────────────────────────────────────────────────────────────────────
# GAP 4: Wrapper syntax validation
# ─────────────────────────────────────────────────────────────────────────────

def validate_agent_syntax(agent_file: Path) -> Tuple[bool, str]:
    """
    Run py_compile on the agent file to verify it has no syntax errors.
    Returns (valid: bool, error_message: str).
    """
    if not agent_file.exists():
        return False, f"file not found: {agent_file}"
    try:
        result = subprocess.run(
            [sys.executable, "-m", "py_compile", str(agent_file)],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0:
            print(f"[puvi-bind-sidecar] syntax check PASS: {agent_file.name}")
            return True, ""
        err = (result.stderr or result.stdout or "unknown compile error").strip()
        print(f"[puvi-bind-sidecar] syntax check FAIL: {agent_file.name}: {err[:300]}")
        return False, err[:500]
    except Exception as exc:
        msg = f"syntax check error: {exc}"
        print(f"[puvi-bind-sidecar] {msg}")
        return False, msg


def validate_agent_imports(agent_file: Path) -> Tuple[bool, str]:
    """
    Dry-run import to catch missing modules (e.g. puvinoise not installed).
    Does NOT execute the agent — only verifies imports resolve.
    """
    if not agent_file.exists():
        return False, f"file not found: {agent_file}"
    try:
        check_code = (
            "import sys, importlib.util; "
            f"spec = importlib.util.spec_from_file_location('_check', '{agent_file}'); "
            "loader = importlib.util.LazyLoader(spec.loader); "
            "spec.loader = loader; "
            "mod = importlib.util.module_from_spec(spec); "
            "print('imports_ok')"
        )
        result = subprocess.run(
            [sys.executable, "-c", check_code],
            capture_output=True, text=True, timeout=15,
            env={**os.environ, "PUVINOISE_BOOTSTRAP_DRY_RUN": "1"},
        )
        if "imports_ok" in (result.stdout or ""):
            print(f"[puvi-bind-sidecar] import check PASS: {agent_file.name}")
            return True, ""
        err = (result.stderr or result.stdout or "import check failed").strip()
        print(f"[puvi-bind-sidecar] import check WARNING: {agent_file.name}: {err[:300]}")
        return False, err[:500]
    except Exception as exc:
        return False, str(exc)


def _parse_env_file_map(env_file: Path) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not env_file.exists():
        return out
    try:
        for raw in env_file.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            out[k.strip()] = v.strip()
    except Exception:
        return out
    return out


def _write_env_file_map(env_file: Path, env_map: Dict[str, str]) -> None:
    lines = [f"{k}={v}" for k, v in sorted(env_map.items(), key=lambda kv: kv[0])]
    env_file.write_text("\n".join(lines) + "\n", encoding="utf-8")


def auto_repair_bootstrap_env(workdir: Path, platform_url: str, agent_id: str, agent_name: str) -> List[str]:
    env_file = workdir / ".env"
    env_map = _parse_env_file_map(env_file)
    repairs: List[str] = []

    expected_platform = platform_url.rstrip("/")
    if (env_map.get("PUVINOISE_PLATFORM_URL", "") or "").strip() != expected_platform:
        env_map["PUVINOISE_PLATFORM_URL"] = expected_platform
        repairs.append("set PUVINOISE_PLATFORM_URL")
    if ":4318" in (env_map.get("PUVINOISE_PLATFORM_URL", "") or "").strip():
        env_map["PUVINOISE_PLATFORM_URL"] = expected_platform
        repairs.append("fixed malformed PUVINOISE_PLATFORM_URL (removed OTLP :4318)")

    if not (env_map.get("PUVI_AGENT_ID", "") or "").strip():
        env_map["PUVI_AGENT_ID"] = agent_id
        repairs.append("set PUVI_AGENT_ID")
    if not (env_map.get("PUVI_AGENT_NAME", "") or "").strip():
        env_map["PUVI_AGENT_NAME"] = agent_name
        repairs.append("set PUVI_AGENT_NAME")

    if not (env_map.get("PUVINOISE_AGENTACCESSKEY", "") or "").strip() and (env_map.get("PUVI_API_KEY", "") or "").strip():
        env_map["PUVINOISE_AGENTACCESSKEY"] = env_map.get("PUVI_API_KEY", "")
        repairs.append("copied PUVI_API_KEY to PUVINOISE_AGENTACCESSKEY")
    if not (env_map.get("PUVI_API_KEY", "") or "").strip() and (env_map.get("PUVINOISE_AGENTACCESSKEY", "") or "").strip():
        env_map["PUVI_API_KEY"] = env_map.get("PUVINOISE_AGENTACCESSKEY", "")
        repairs.append("copied PUVINOISE_AGENTACCESSKEY to PUVI_API_KEY")

    env_map.setdefault("PUVINOISE_WRAPPER_FILE", "./puvinoise-wrapper.sh")
    env_map.setdefault("PUVINOISE_AGENT_PID_FILE", ".puvinoise_agent.pid")
    if "PUVINOISE_WRAPPER_FILE" not in _parse_env_file_map(env_file):
        repairs.append("set PUVINOISE_WRAPPER_FILE")
    if "PUVINOISE_AGENT_PID_FILE" not in _parse_env_file_map(env_file):
        repairs.append("set PUVINOISE_AGENT_PID_FILE")

    if repairs:
        _write_env_file_map(env_file, env_map)
    return repairs


def evaluate_bootstrap_readiness(
    workdir: Path,
    *,
    sdk_ok: bool,
    sdk_ver: str,
    agent_id: str,
) -> Tuple[bool, List[str]]:
    """
    Strict pre-run readiness gate:
    validates env + wrapper + instrumentation + metadata hints before customer run.
    """
    issues: List[str] = []
    env_file = workdir / ".env"
    wrapper_file = workdir / "puvinoise-wrapper.sh"
    run_file = workdir / "run.py"

    if not env_file.exists():
        issues.append("missing .env file")
        env_map = {}
    else:
        env_map = _parse_env_file_map(env_file)

    # Required env contract
    required_env = [
        "PUVINOISE_PLATFORM_URL",
        "PUVI_AGENT_NAME",
    ]
    for key in required_env:
        if not (env_map.get(key, "") or "").strip():
            issues.append(f"missing env key: {key}")

    if not ((env_map.get("PUVINOISE_AGENTACCESSKEY", "") or "").strip() or (env_map.get("PUVI_API_KEY", "") or "").strip()):
        issues.append("missing env key: PUVINOISE_AGENTACCESSKEY / PUVI_API_KEY")

    platform_url = (env_map.get("PUVINOISE_PLATFORM_URL", "") or "").strip().lower()
    if platform_url and ":4318" in platform_url:
        issues.append("invalid PUVINOISE_PLATFORM_URL uses OTLP port :4318")

    # Agent identity consistency
    env_agent_id = (env_map.get("PUVI_AGENT_ID", "") or env_map.get("PUVINOISE_AGENT_ID", "")).strip()
    if agent_id.strip() and env_agent_id and agent_id.strip() != env_agent_id:
        issues.append(f"agent id mismatch: registered={agent_id.strip()} env={env_agent_id}")

    # Wrapper checks
    if not wrapper_file.exists():
        issues.append("missing wrapper file: puvinoise-wrapper.sh")
    else:
        try:
            wrapper_text = wrapper_file.read_text(encoding="utf-8")
            if "exec python3 run.py" not in wrapper_text:
                issues.append("wrapper missing final exec python3 run.py")
            if "PUVINOISE_CONTROL_RUNTIME_EXEC" not in wrapper_text:
                issues.append("wrapper missing control runtime export")
        except Exception as exc:
            issues.append(f"cannot read wrapper file: {exc}")

    # Agent entry checks
    if not run_file.exists():
        issues.append("missing run.py")
    else:
        syntax_ok, syntax_err = validate_agent_syntax(run_file)
        if not syntax_ok:
            issues.append(f"run.py syntax invalid: {syntax_err[:160]}")
        if sdk_ok:
            content = run_file.read_text(encoding="utf-8")
            if INSTRUMENTATION_MARKER not in content:
                issues.append("run.py missing PUVINoise instrumentation marker")
            # SDK signature compatibility check (known pitfall)
            if re.search(r"with\s+puvinoise\.run_with_trace\s*\(", content):
                issues.append("run.py uses context-manager run_with_trace; SDK expects fn wrapper style")
            if "intent=" not in content or "goal=" not in content:
                issues.append("run.py trace calls missing intent/goal metadata hints")

    if not sdk_ok:
        issues.append(f"sdk not ready: {sdk_ver}")

    return (len(issues) == 0), issues


def run_trace_emission_probe(workdir: Path, sdk_ok: bool) -> Dict[str, Any]:
    run_file = workdir / "run.py"
    result: Dict[str, Any] = {
        "status": "FAIL",
        "details": [],
        "checkedAt": _now_iso(),
        "instrumentationPath": "none",
    }
    details: List[str] = []
    if not sdk_ok:
        details.append("sdk_not_ready")
        result["details"] = details
        return result
    if not run_file.exists():
        details.append("run.py_missing")
        result["details"] = details
        return result
    try:
        content = run_file.read_text(encoding="utf-8")
    except Exception as exc:
        details.append(f"run_read_error:{exc}")
        result["details"] = details
        return result

    if INSTRUMENTATION_MARKER in content:
        result["instrumentationPath"] = "sidecar_injected"
    elif "puvinoise.bootstrap(" in content:
        result["instrumentationPath"] = "customer_bootstrap"

    if "run_with_trace(" in content:
        details.append("run_with_trace_present")
    if "intent=" in content:
        details.append("intent_present")
    if "goal=" in content:
        details.append("goal_present")
    if "success=" in content:
        details.append("success_present")

    has_min = "run_with_trace_present" in details and "intent_present" in details and "goal_present" in details
    result["status"] = "PASS" if has_min else "WARNING"
    result["details"] = details
    return result


def write_bootstrap_readiness_report(
    workdir: Path,
    ok: bool,
    issues: List[str],
    trace_probe: Optional[Dict[str, Any]] = None,
) -> None:
    report = {
        "ready": bool(ok),
        "checkedAt": _now_iso(),
        "issues": issues,
        "traceProbe": trace_probe or {},
    }
    try:
        (workdir / ".puvinoise_bootstrap_readiness.json").write_text(
            json.dumps(report, indent=2),
            encoding="utf-8",
        )
    except Exception:
        pass


def _access_key_prefix_masked(key: str) -> str:
    k = (key or "").strip()
    if not k:
        return "(empty)"
    return k[:8] + ("…" if len(k) > 8 else "")


def _maybe_reregister_on_401(
    err: Exception,
    platform_url: str,
    registration_token: str,
    agent_name: str,
    deploy_env: str,
    deploy_version: str,
    *,
    approval_max_wait_s: Optional[float],
) -> Optional[Dict[str, Any]]:
    msg = str(err)
    if "401" not in msg and "Invalid or expired agent access key" not in msg:
        return None
    if not str(registration_token or "").strip():
        print("[puvi-bind-sidecar] access key rejected and no registration token available for re-registration")
        return None
    print("[puvi-bind-sidecar] access key rejected; clearing stale state and re-registering")
    _clear_state()
    try:
        return ensure_registered(
            platform_url,
            registration_token,
            agent_name,
            deploy_env,
            deploy_version,
            approval_max_wait_s=approval_max_wait_s,
        )
    except Exception as rereg_exc:
        rereg_msg = str(rereg_exc)
        if "already been used" in rereg_msg or "400" in rereg_msg:
            print("[puvi-bind-sidecar] re-registration failed (token already used). Heartbeats will continue with current key.")
            print("[puvi-bind-sidecar] If this persists, generate a new token and restart the sidecar.")
            return None
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description="PUVINoise bind sidecar (standalone)")
    parser.add_argument("--loop", action="store_true", help="keep sending heartbeat")
    parser.add_argument("--interval", type=int, default=10, help="heartbeat interval seconds")
    parser.add_argument(
        "--allow-noncompliant",
        action="store_true",
        help="do not block startup when bootstrap readiness checks fail",
    )
    args = parser.parse_args()

    platform_url = _required_env("PUVINOISE_PLATFORM_URL")
    registration_token = os.getenv("PUVINOISE_REGISTRATION_TOKEN", "").strip()
    agent_name = _required_env("PUVI_AGENT_NAME")
    deploy_env = os.getenv("PUVI_DEPLOY_ENV", "Development").strip() or "Development"
    deploy_version = os.getenv("PUVI_DEPLOY_VERSION", "0.1.0").strip() or "0.1.0"

    # Until an admin approves the bind in the UI, /api/register returns 409. --loop waits forever; one-shot waits ~4 min.
    reg_approval_max: Optional[float] = None if args.loop else 240.0

    cached = _load_state()
    cached_matches = (
        str(cached.get("platform_url", "")).strip() == platform_url.rstrip("/")
        and str(cached.get("agent_name", "")).strip() == agent_name
        and str(cached.get("agent_id", "")).strip()
        and str(cached.get("agent_access_key", "")).strip()
    )
    if cached_matches:
        state = cached
        print("[puvi-bind-sidecar] using cached registration state (token not required for restart)")
    else:
        if not registration_token:
            raise RuntimeError(
                "Missing PUVINOISE_REGISTRATION_TOKEN and no cached registration state found. "
                "Generate a new registration token from Register Agent Step 3."
            )
        emit_probe(platform_url, registration_token, agent_name, deploy_env, deploy_version)
        state = ensure_registered(
            platform_url,
            registration_token,
            agent_name,
            deploy_env,
            deploy_version,
            approval_max_wait_s=reg_approval_max,
        )
    aid = str(state["agent_id"])
    key = str(state["agent_access_key"])
    if not key.strip():
        print("[puvi-bind-sidecar] missing access key after load; re-registering")
        _clear_state()
        state = ensure_registered(
            platform_url,
            registration_token,
            agent_name,
            deploy_env,
            deploy_version,
            approval_max_wait_s=reg_approval_max,
        )
        aid = str(state["agent_id"])
        key = str(state["agent_access_key"])

    print(f"[puvi-bind-sidecar] access key prefix={_access_key_prefix_masked(key)}")

    # ── Post-registration bootstrap: pull config, install SDK, validate ──
    workdir = Path.cwd()
    print(f"[puvi-bind-sidecar] agent workdir: {workdir}")

    agent_entry = workdir / "run.py"
    if not agent_entry.exists():
        print(f"[puvi-bind-sidecar] ⚠ WARNING: run.py not found in {workdir}")
        print(f"[puvi-bind-sidecar] The sidecar writes .env, installs SDK, and validates the wrapper")
        print(f"[puvi-bind-sidecar] relative to the current working directory.")
        print(f"[puvi-bind-sidecar] Make sure you run the sidecar FROM your agent directory that")
        print(f"[puvi-bind-sidecar] contains run.py (your agent entry file).")
        print(f"[puvi-bind-sidecar] Example: cd /path/to/{agent_name} && python3 -u puvi_bind_sidecar.py --loop")
        print(f"[puvi-bind-sidecar] Continuing with bootstrap anyway — .env and SDK will be written here.")

    # GAP 1: Pull bootstrap config (.env, wrapper, restart scripts)
    sdk_install_cmd = ""
    try:
        cfg = pull_bootstrap_config(platform_url, key, aid, agent_name, workdir)
        sdk_install_cmd = str(cfg.get("sdkInstallLatestCommand") or "").strip()
    except Exception as exc:
        print(f"[puvi-bind-sidecar] bootstrap config pull non-fatal: {exc}")

    # GAP 3: Install/upgrade PUVINoise SDK
    sdk_ok, sdk_ver = ensure_sdk_installed(sdk_install_cmd)
    if sdk_ok:
        print(f"[puvi-bind-sidecar] SDK ready: {sdk_ver}")
    else:
        print(f"[puvi-bind-sidecar] WARNING: SDK not available or below minimum ({sdk_ver})")
        print(f"[puvi-bind-sidecar] The agent may fail to emit telemetry. Install manually:")
        print(f"[puvi-bind-sidecar]   {sdk_install_cmd or 'pip install -U puvinoise-sdk'}")

    # GAP 5: Inject PUVINoise SDK instrumentation into run.py
    agent_file = workdir / "run.py"
    if agent_file.exists() and sdk_ok:
        inj_ok, inj_msg = inject_instrumentation(agent_file)
        if inj_ok:
            print(f"[puvi-bind-sidecar] instrumentation: {inj_msg}")
        else:
            print(f"[puvi-bind-sidecar] instrumentation injection failed: {inj_msg}")

    # GAP 4: Validate agent file syntax if run.py exists
    if agent_file.exists():
        syntax_ok, syntax_err = validate_agent_syntax(agent_file)
        if not syntax_ok:
            print(f"[puvi-bind-sidecar] CRITICAL: run.py has syntax errors — agent will not start!")
            print(f"[puvi-bind-sidecar] Error: {syntax_err}")
            broken_backup = workdir / "run.py.broken"
            shutil.copy2(str(agent_file), str(broken_backup))
            print(f"[puvi-bind-sidecar] Broken file backed up to {broken_backup}")
            # Restore from backup
            original_file = workdir / "run_original.py"
            if original_file.exists():
                shutil.copy2(str(original_file), str(agent_file))
                print(f"[puvi-bind-sidecar] Restored run.py from run_original.py")
        else:
            if sdk_ok:
                import_ok, import_err = validate_agent_imports(agent_file)
                if not import_ok:
                    print(f"[puvi-bind-sidecar] WARNING: run.py import check failed: {import_err[:200]}")
                    print(f"[puvi-bind-sidecar] The wrapper may be incompatible with SDK {sdk_ver}")

    # Auto-repair common bootstrap defects before readiness gate
    repairs = auto_repair_bootstrap_env(workdir, platform_url, aid, agent_name)
    if repairs:
        print("[puvi-bind-sidecar] auto-repair applied:")
        for item in repairs:
            print(f"[puvi-bind-sidecar]   - {item}")

    # Bootstrap readiness gate (after pull + install + injection, before runtime handoff)
    ready_ok, ready_issues = evaluate_bootstrap_readiness(
        workdir,
        sdk_ok=sdk_ok,
        sdk_ver=sdk_ver,
        agent_id=aid,
    )
    trace_probe = run_trace_emission_probe(workdir, sdk_ok=sdk_ok)
    print(f"[puvi-bind-sidecar] trace probe {trace_probe.get('status', 'UNKNOWN')}")
    write_bootstrap_readiness_report(workdir, ready_ok, ready_issues, trace_probe=trace_probe)
    if ready_ok:
        print("[puvi-bind-sidecar] readiness gate PASS")
    else:
        print("[puvi-bind-sidecar] readiness gate FAIL")
        for issue in ready_issues:
            print(f"[puvi-bind-sidecar]   - {issue}")
        if not args.allow_noncompliant:
            raise RuntimeError(
                "Bootstrap readiness checks failed. "
                "Fix issues above and re-run sidecar (or use --allow-noncompliant to continue)."
            )

    # Report runtime metadata — pass the real installed SDK version so the platform
    # stores the actual puvinoise-sdk PyPI version, not the sidecar placeholder.
    try:
        report_runtime_metadata(platform_url, key, aid, agent_name, deploy_env, deploy_version,
                                installed_sdk_version=sdk_ver if sdk_ok else "",
                                readiness_ok=ready_ok,
                                readiness_issues=ready_issues,
                                trace_probe_status=str(trace_probe.get("status", "")),
                                trace_probe_details=[str(x) for x in (trace_probe.get("details") or [])])
    except Exception as exc:
        print(f"[puvi-bind-sidecar] metadata report non-fatal: {exc}")

    # First heartbeat
    try:
        send_heartbeat(platform_url, key, aid, deploy_env, installed_sdk_version=sdk_ver if sdk_ok else "")
    except Exception as exc:
        refreshed = _maybe_reregister_on_401(
            exc, platform_url, registration_token, agent_name, deploy_env, deploy_version,
            approval_max_wait_s=reg_approval_max,
        )
        if refreshed:
            aid = str(refreshed.get("agent_id", aid))
            key = str(refreshed.get("agent_access_key", key))
            print(f"[puvi-bind-sidecar] access key prefix={_access_key_prefix_masked(key)}")
            try:
                send_heartbeat(platform_url, key, aid, deploy_env, installed_sdk_version=sdk_ver if sdk_ok else "")
            except Exception as hb2:
                print(f"[puvi-bind-sidecar] first heartbeat still failing: {hb2}")
        elif "401" in str(exc) or "Invalid or expired" in str(exc):
            print(f"[puvi-bind-sidecar] first heartbeat 401 but re-registration skipped (token may be reused). Continuing with loop.")
        else:
            print(f"[puvi-bind-sidecar] first heartbeat error (non-fatal): {exc}")

    print(f"[puvi-bind-sidecar] ready agent_id={aid}")
    print(f"[puvi-bind-sidecar] bootstrap summary:")
    print(f"  .env:    {'OK' if (workdir / '.env').exists() else 'MISSING'}")
    print(f"  SDK:     {sdk_ver} ({'OK' if sdk_ok else 'NEEDS INSTALL'})")
    print(f"  run.py:  {'exists' if (workdir / 'run.py').exists() else 'MISSING'}")
    print(f"  wrapper: {'exists' if (workdir / 'puvinoise-wrapper.sh').exists() else 'MISSING'}")

    if not args.loop:
        return
    print(f"[puvi-bind-sidecar] heartbeat loop interval={args.interval}s")
    while True:
        if not str(key).strip():
            print("[puvi-bind-sidecar] missing access key in heartbeat loop; re-registering")
            _clear_state()
            state = ensure_registered(
                platform_url,
                registration_token,
                agent_name,
                deploy_env,
                deploy_version,
                approval_max_wait_s=reg_approval_max,
            )
            aid = str(state["agent_id"])
            key = str(state["agent_access_key"])
        try:
            send_heartbeat(platform_url, key, aid, deploy_env, installed_sdk_version=sdk_ver if sdk_ok else "")
        except Exception as exc:
            refreshed = _maybe_reregister_on_401(
                exc,
                platform_url,
                registration_token,
                agent_name,
                deploy_env,
                deploy_version,
                approval_max_wait_s=reg_approval_max,
            )
            if refreshed:
                aid = str(refreshed.get("agent_id", aid))
                key = str(refreshed.get("agent_access_key", key))
                try:
                    report_runtime_metadata(platform_url, key, aid, agent_name, deploy_env, deploy_version,
                                            installed_sdk_version=sdk_ver if sdk_ok else "",
                                            readiness_ok=ready_ok,
                                            readiness_issues=ready_issues,
                                            trace_probe_status=str(trace_probe.get("status", "")),
                                            trace_probe_details=[str(x) for x in (trace_probe.get("details") or [])])
                except Exception as meta_exc:
                    print(f"[puvi-bind-sidecar] metadata report non-fatal after re-register: {meta_exc}")
                try:
                    send_heartbeat(platform_url, key, aid, deploy_env, installed_sdk_version=sdk_ver if sdk_ok else "")
                except Exception as hb_exc:
                    print(f"[puvi-bind-sidecar] heartbeat error after re-register: {hb_exc}")
            else:
                print(f"[puvi-bind-sidecar] heartbeat error: {exc}")
        time.sleep(max(3, args.interval))


if __name__ == "__main__":
    main()
