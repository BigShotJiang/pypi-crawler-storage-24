"""
Compatibility alias for agent integration: re-exports ``wrapAgent`` and ``PuviClient``.

Prefer ``from puvinoise import wrapAgent, PuviClient`` in new code.
"""

from puvinoise.agent_wrapper import wrapAgent
from puvinoise.client import PuviClient, ScenarioTraceHandle

__all__ = ["wrapAgent", "PuviClient", "ScenarioTraceHandle"]
