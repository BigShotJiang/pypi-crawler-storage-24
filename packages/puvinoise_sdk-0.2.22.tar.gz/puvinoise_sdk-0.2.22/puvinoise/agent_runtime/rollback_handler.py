"""Rollback to a previous version via script, artifact, or git."""

from __future__ import annotations

import os
from typing import Any, Dict, Optional

from puvinoise.agent_runtime.deploy_handler import download_and_extract_artifact, git_checkout
from puvinoise.agent_runtime.process_manager import ProcessManager
from puvinoise.agent_runtime.runtime_flags import require_runtime_exec


def run_rollback(
    version: str,
    payload: Optional[Dict[str, Any]],
    *,
    process_manager: ProcessManager,
    workdir: str,
    artifact_template: str,
    checkout_mode: str,
    git_remote: str,
    restart_after: bool = True,
) -> None:
    v = (version or "").strip()
    if not v:
        raise RuntimeError("rollback: version is required")
    require_runtime_exec()

    rs = (os.environ.get("PUVINOISE_ROLLBACK_SCRIPT") or "").strip()
    if rs:
        process_manager.run_script(rs, ["rollback", v], cwd=None)
        if restart_after:
            process_manager.restart()
        return

    artifact_url = None
    if payload and isinstance(payload.get("artifactUrl"), str):
        artifact_url = payload["artifactUrl"].strip()
    if not artifact_url and artifact_template and "{version}" in artifact_template:
        artifact_url = artifact_template.replace("{version}", v)

    if artifact_url:
        download_and_extract_artifact(artifact_url, workdir, v)
        if restart_after:
            process_manager.restart()
        return

    if workdir and os.path.isdir(os.path.join(workdir, ".git")):
        git_checkout(v, workdir, git_remote, checkout_mode)
        if restart_after:
            process_manager.restart()
        return

    raise RuntimeError(
        "rollback: configure PUVINOISE_ROLLBACK_SCRIPT, or git/artifact same as deploy"
    )
