"""
Write the agent process PID for host control scripts (restart/stop/start).

Used when PUVINOISE_CONTROL_RUNTIME_EXEC=1 so PUVINOISE_RESTART_SCRIPT can signal
this process without customer application code changes.
"""

from __future__ import annotations

import logging
import os

from puvinoise.agent_runtime.runtime_flags import runtime_exec_enabled

logger = logging.getLogger(__name__)


def write_control_plane_pidfile() -> None:
    """Write os.getpid() to PUVINOISE_AGENT_PID_FILE (default under PUVINOISE_AGENT_WORKDIR)."""
    if not runtime_exec_enabled():
        return
    wd = (os.environ.get("PUVINOISE_AGENT_WORKDIR") or "").strip() or os.getcwd()
    try:
        wd = os.path.abspath(wd)
    except OSError:
        wd = os.getcwd()
    rel = (os.environ.get("PUVINOISE_AGENT_PID_FILE") or ".puvinoise_agent.pid").strip()
    # Use os.path.join directly — do NOT lstrip("./") as that would strip the leading dot
    # from hidden files like ".puvinoise_agent.pid", causing the restart script to miss it.
    path = rel if os.path.isabs(rel) else os.path.join(wd, rel)
    try:
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
        logger.debug("pidfile: wrote %s", path)
    except OSError as e:
        logger.warning("pidfile: could not write %s: %s", path, e)
