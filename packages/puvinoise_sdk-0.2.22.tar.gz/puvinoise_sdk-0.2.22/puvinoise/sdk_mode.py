"""
PUVINoise SDK vs Agent separation.

Default: SDK is telemetry-only (no local persistence, no control/config polling).
The Agent process (wrapper / supervisor) handles .env, installs, deploy, restart,
and polls GET /api/agent/config with PUVINOISE_AGENTACCESSKEY.

Set PUVINOISE_SDK_TELEMETRY_ONLY=0 to restore legacy embedded automation in-process.
"""

from __future__ import annotations

import os


def sdk_telemetry_only() -> bool:
    """
    When True (default): SDK does not write span/telemetry queues to disk and does not
    auto-start control/config pollers unless explicitly enabled via env or control_config.
    """
    v = os.environ.get("PUVINOISE_SDK_TELEMETRY_ONLY", "1").strip().lower()
    return v not in ("0", "false", "no")
