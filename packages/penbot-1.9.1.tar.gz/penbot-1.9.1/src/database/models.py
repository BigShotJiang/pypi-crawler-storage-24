"""SQLAlchemy ORM models for PenBot persistence."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
)
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class DBTestSession(Base):
    """Persisted penetration-test session."""

    __tablename__ = "test_sessions"

    id = Column(String(64), primary_key=True)
    target_name = Column(String(256), nullable=False)
    target_type = Column(String(32), nullable=False, default="api")
    target_config = Column(JSON, nullable=True)
    attack_group = Column(String(64), nullable=True)
    max_attempts = Column(Integer, default=10)
    current_attempt = Column(Integer, default=0)
    vulnerability_score = Column(Float, default=0.0)
    test_status = Column(String(32), default="running")
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    extra = Column(JSON, nullable=True)

    attacks = relationship(
        "DBAttackAttempt",
        back_populates="session",
        cascade="all, delete-orphan",
        order_by="DBAttackAttempt.created_at",
    )
    responses = relationship(
        "DBTargetResponse",
        back_populates="session",
        cascade="all, delete-orphan",
        order_by="DBTargetResponse.created_at",
    )
    findings = relationship(
        "DBSecurityFinding",
        back_populates="session",
        cascade="all, delete-orphan",
        order_by="DBSecurityFinding.created_at",
    )


class DBAttackAttempt(Base):
    """Single attack attempt."""

    __tablename__ = "attack_attempts"

    id = Column(String(64), primary_key=True)
    session_id = Column(
        String(64), ForeignKey("test_sessions.id", ondelete="CASCADE"), nullable=False
    )
    agent_name = Column(String(64), nullable=False)
    attack_type = Column(String(64), nullable=False)
    query = Column(Text, nullable=False)
    pattern = Column(String(128), nullable=True)
    parent_attack_id = Column(String(64), nullable=True)
    metadata_ = Column("metadata", JSON, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    session = relationship("DBTestSession", back_populates="attacks")


class DBTargetResponse(Base):
    """Response received from a target chatbot."""

    __tablename__ = "target_responses"

    id = Column(String(64), primary_key=True)
    session_id = Column(
        String(64), ForeignKey("test_sessions.id", ondelete="CASCADE"), nullable=False
    )
    attack_id = Column(String(64), nullable=False)
    content = Column(Text, nullable=False)
    response_time_ms = Column(Integer, nullable=True)
    metadata_ = Column("metadata", JSON, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    session = relationship("DBTestSession", back_populates="responses")


class DBSecurityFinding(Base):
    """Security vulnerability discovered during testing."""

    __tablename__ = "security_findings"

    id = Column(String(64), primary_key=True)
    session_id = Column(
        String(64), ForeignKey("test_sessions.id", ondelete="CASCADE"), nullable=False
    )
    attack_id = Column(String(64), nullable=True)
    severity = Column(String(16), nullable=False)
    category = Column(String(64), nullable=False)
    description = Column(Text, nullable=False)
    evidence = Column(Text, nullable=True)
    confidence = Column(Float, default=0.0)
    owasp_category = Column(String(16), nullable=True)
    metadata_ = Column("metadata", JSON, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    session = relationship("DBTestSession", back_populates="findings")
