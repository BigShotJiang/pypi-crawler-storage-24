"""Shell command validation for sandboxed recon execution.

All shell commands issued by agent-generated code pass through the parent
process.  Before execution, ``ShellCommandValidator`` checks every command
(and every pipe/chain segment) against:

1. A binary allowlist (only recon tools).
2. A blocked-pattern denylist (destructive ops, credential files, etc.).
3. Target-host scoping for network-facing tools.
"""

from __future__ import annotations

import re
import shlex

from .logging import get_logger

logger = get_logger(__name__)

ALLOWED_BINARIES: set[str] = {
    # HTTP / download
    "curl",
    "wget",
    # Scanning
    "nmap",
    # DNS / WHOIS
    "dig",
    "nslookup",
    "host",
    "whois",
    # TLS / crypto
    "openssl",
    # Networking
    "nc",
    "ncat",
    "traceroute",
    "ping",
    # Web vuln scanners
    "nikto",
    "ffuf",
    "gobuster",
    "sqlmap",
    # Text processing (piped output)
    "echo",
    "cat",
    "grep",
    "awk",
    "sed",
    "head",
    "tail",
    "wc",
    "sort",
    "uniq",
    "tr",
    "cut",
    "tee",
    # Encoding / hex
    "base64",
    "xxd",
    "od",
    # JSON
    "jq",
    # Misc safe
    "printf",
    "date",
    "sleep",
}

_NETWORK_BINARIES: set[str] = {
    "curl",
    "wget",
    "nmap",
    "dig",
    "nslookup",
    "host",
    "whois",
    "openssl",
    "nc",
    "ncat",
    "traceroute",
    "ping",
    "nikto",
    "ffuf",
    "gobuster",
    "sqlmap",
}

BLOCKED_PATTERNS: list[str] = [
    "rm ",
    "rm\t",
    "rmdir",
    "mkfs",
    "dd ",
    "chmod",
    "chown",
    "chgrp",
    "sudo",
    "su ",
    "apt ",
    "apt-get",
    "yum ",
    "dnf ",
    "brew ",
    "pip ",
    "pip3 ",
    "npm ",
    "shutdown",
    "reboot",
    "halt",
    "poweroff",
    "kill ",
    "killall",
    "pkill",
    "> /dev/",
    ">> /dev/",
    "/etc/passwd",
    "/etc/shadow",
    "~/.ssh",
    ".env",
    "eval ",
    "exec ",
]

_CHAIN_SPLITTER = re.compile(r"\s*(?:\|\||&&|;)\s*")
_PIPE_SPLITTER = re.compile(r"\s*\|\s*")


class ShellCommandValidator:
    """Validate shell commands before execution in the sandbox."""

    def __init__(
        self,
        target_host: str | None = None,
        allowed_binaries: set[str] | None = None,
        extra_binaries: set[str] | None = None,
        blocked_patterns: list[str] | None = None,
    ):
        self.target_host = target_host
        self.allowed_binaries = allowed_binaries or ALLOWED_BINARIES
        if extra_binaries:
            self.allowed_binaries = self.allowed_binaries | extra_binaries
        self.blocked_patterns = blocked_patterns or BLOCKED_PATTERNS

    def validate(self, command: str) -> tuple[bool, str | None]:
        """Check whether *command* is safe to execute.

        Returns:
            ``(True, None)`` if allowed, ``(False, reason)`` if rejected.
        """
        if not command or not command.strip():
            return False, "Empty command"

        segments = self._split_command(command)
        if not segments:
            return False, "Empty command after splitting"

        for segment in segments:
            ok, reason = self._validate_segment(segment)
            if not ok:
                return False, reason

        return True, None

    def _split_command(self, command: str) -> list[str]:
        """Split on ``|``, ``||``, ``&&``, and ``;`` to get individual segments."""
        chain_parts = _CHAIN_SPLITTER.split(command)
        segments: list[str] = []
        for part in chain_parts:
            pipe_parts = _PIPE_SPLITTER.split(part)
            segments.extend(p.strip() for p in pipe_parts if p.strip())
        return segments

    def _validate_segment(self, segment: str) -> tuple[bool, str | None]:
        binary = self._parse_binary(segment)
        if not binary:
            return False, f"Could not parse binary from: {segment[:80]}"

        if binary not in self.allowed_binaries:
            return False, f"Binary not allowed: {binary}"

        lower_seg = segment.lower()
        for pattern in self.blocked_patterns:
            if pattern.lower() in lower_seg:
                return False, f"Blocked pattern detected: {pattern.strip()}"

        if self.target_host and binary in _NETWORK_BINARIES:
            if not self._segment_targets_host(segment, self.target_host):
                return (
                    False,
                    f"Network command must reference target host "
                    f"({self.target_host}): {segment[:80]}",
                )

        return True, None

    @staticmethod
    def _segment_targets_host(segment: str, target_host: str) -> bool:
        """Check that *segment* genuinely references *target_host*.

        Uses token-level matching: the target hostname must appear as a
        standalone argument or as the registered host in a URL argument.
        A naive substring check would allow bypasses like
        ``curl https://evil.com/target.example.com``.
        """
        from urllib.parse import urlparse

        target_lower = target_host.lower()

        try:
            tokens = shlex.split(segment)
        except ValueError:
            tokens = segment.split()

        for token in tokens:
            if token.startswith("-"):
                continue

            tok_lower = token.lower()

            if tok_lower == target_lower:
                return True

            if target_lower in tok_lower and (":" in token or "/" in token):
                try:
                    parsed = urlparse(token if "://" in token else f"https://{token}")
                    hostname = (parsed.hostname or "").lower()
                    if hostname == target_lower or hostname.endswith("." + target_lower):
                        return True
                except Exception:
                    pass

            if tok_lower.endswith(target_lower) or tok_lower.startswith(target_lower):
                bare = tok_lower.replace(target_lower, "", 1)
                if not bare or bare in (":", "/", ":443", ":80", ":8080", ":8443"):
                    return True

        return False

    @staticmethod
    def _parse_binary(segment: str) -> str | None:
        """Extract the binary name from a command segment.

        Handles common prefixes like env vars (``VAR=val cmd``) and
        path prefixes (``/usr/bin/curl``).
        """
        stripped = segment.strip()
        if not stripped:
            return None

        try:
            tokens = shlex.split(stripped)
        except ValueError:
            tokens = stripped.split()

        for token in tokens:
            if "=" in token and not token.startswith("-"):
                continue
            basename = token.rsplit("/", 1)[-1]
            return basename

        return None
