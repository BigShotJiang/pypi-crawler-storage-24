"""Thread-safe in-memory LLM response cache with TTL expiry.

Keyed on a SHA-256 hash of the serialised prompt messages so that
identical calls within the TTL window return cached results without
an API round-trip.  Attack-generation calls should bypass the cache
(temperature > 0 and novelty matters).
"""

from __future__ import annotations

import hashlib
import json
import threading
import time
from collections import OrderedDict
from typing import Any

from .config import settings
from .logging import get_logger

logger = get_logger(__name__)


class LLMResponseCache:
    """LRU cache with per-entry TTL for LLM responses."""

    def __init__(
        self,
        max_size: int | None = None,
        ttl_seconds: int | None = None,
    ):
        self._max_size = max_size or settings.llm_response_cache_max_size
        self._ttl = ttl_seconds or settings.llm_response_cache_ttl
        self._store: OrderedDict[str, tuple[float, Any]] = OrderedDict()
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0

    @staticmethod
    def _make_key(messages: list[dict[str, Any]], model: str = "") -> str:
        """Deterministic hash of the prompt messages and model name."""
        blob = json.dumps({"model": model, "messages": messages}, sort_keys=True)
        return hashlib.sha256(blob.encode()).hexdigest()

    def get(self, key: str) -> Any | None:
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                self._misses += 1
                return None
            ts, value = entry
            if time.monotonic() - ts >= self._ttl:
                del self._store[key]
                self._misses += 1
                return None
            self._store.move_to_end(key)
            self._hits += 1
            return value

    def put(self, key: str, value: Any) -> None:
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
            self._store[key] = (time.monotonic(), value)
            while len(self._store) > self._max_size:
                self._store.popitem(last=False)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()

    @property
    def stats(self) -> dict[str, Any]:
        total = self._hits + self._misses
        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": round(self._hits / total, 3) if total else 0.0,
            "size": len(self._store),
            "max_size": self._max_size,
            "ttl_seconds": self._ttl,
        }


# Module-level singleton
_cache = LLMResponseCache()


def get_llm_cache() -> LLMResponseCache:
    """Return the global LLM response cache."""
    return _cache
