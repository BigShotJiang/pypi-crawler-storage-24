"""Factory for creating target connectors."""

from typing import Any, Literal

from .base import BaseConnector

TargetType = Literal[
    "api",
    "rest",
    "web_ui",
    "playwright",
    "dialogflow",
    "rasa",
    "azure-bot",
    "directline",
    "aws-lex",
    "lex",
]


def create_connector(
    target_type: TargetType,
    config: dict[str, Any],
) -> BaseConnector:
    """
    Create appropriate connector based on target type.

    Unified factory that returns connectors inheriting from BaseConnector.

    Args:
        target_type: Type of target
            - "api", "rest"              -> GenericRestConnector
            - "dialogflow", "rasa"       -> GenericRestConnector (config-driven)
            - "web_ui", "playwright"     -> PlaywrightConnector
            - "azure-bot", "directline"  -> AzureDirectLineConnector
            - "aws-lex", "lex"           -> LexConnector

        config: The full 'target' section from YAML config.

    Returns:
        Initialized connector instance (BaseConnector subclass)

    Raises:
        ValueError: If target_type is unknown

    Example:
        >>> connector = create_connector("api", {
        ...     "name": "My Chatbot",
        ...     "connection": {"endpoint": "http://localhost:5000/chat"},
        ...     "format": {"request": {"message_field": "message"}},
        ... })
    """
    if target_type in ("api", "rest", "dialogflow", "rasa"):
        from .rest_connector import GenericRestConnector

        return GenericRestConnector(config)

    elif target_type in ("web_ui", "playwright"):
        from .playwright_connector import PlaywrightConnector

        return PlaywrightConnector(config)

    elif target_type in ("azure-bot", "directline"):
        from .azure_directline_connector import AzureDirectLineConnector

        return AzureDirectLineConnector(config)

    elif target_type in ("aws-lex", "lex"):
        from .lex_connector import LexConnector

        return LexConnector(config)

    else:
        raise ValueError(
            f"Unknown target type: {target_type}. "
            f"Supported types: api, rest, dialogflow, rasa, "
            f"web_ui, playwright, azure-bot, directline, aws-lex, lex"
        )
