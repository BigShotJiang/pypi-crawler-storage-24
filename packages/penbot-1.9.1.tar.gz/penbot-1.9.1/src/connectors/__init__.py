"""Target chatbot connectors for API, Web UI, and platform-specific protocols."""

# Backward compatibility: APITargetConnector is still importable
# but GenericRestConnector is the preferred unified connector.
from .api_connector import APITargetConnector
from .azure_directline_connector import AzureDirectLineConnector
from .base import BaseConnector, TargetConnector
from .factory import create_connector
from .lex_connector import LexConnector
from .rest_connector import GenericRestConnector

__all__ = [
    "BaseConnector",
    "TargetConnector",
    "GenericRestConnector",
    "AzureDirectLineConnector",
    "LexConnector",
    "APITargetConnector",
    "create_connector",
]
