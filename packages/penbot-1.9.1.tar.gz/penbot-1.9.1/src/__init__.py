"""AI Chatbot Penetration Testing Framework.

A multi-agent adversarial testing framework for identifying vulnerabilities
in AI chatbots through coordinated security testing.
"""

__version__ = "1.9.1"
__author__ = "Security Research Team"
