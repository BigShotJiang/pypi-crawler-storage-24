"""``penbot baseline`` and ``penbot regression`` CLI handlers."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import Any

from src.utils.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# penbot baseline
# ---------------------------------------------------------------------------


def run_baseline(args: Any) -> None:
    """Entry-point for ``penbot baseline``."""
    action = getattr(args, "baseline_action", "create") or "create"

    if action == "list":
        _list_baselines(args)
    elif action == "create":
        _create_baseline(args)


def _create_baseline(args: Any) -> None:
    from src.regression.baseline import BaselineManager

    session_path = _resolve_session(args)
    if not session_path:
        return

    with open(session_path) as f:
        session = json.load(f)

    manager = BaselineManager()
    name = getattr(args, "name", None)
    record = manager.create_from_session(session, name=name)

    print(f"\nBaseline created: {record.name}")
    print(f"  Target: {record.target_name}")
    print(f"  Attacks: {record.total_attacks}")
    print(f"  Successful: {record.successful_attacks}")
    print(f"  Vuln score: {record.vulnerability_score:.1f}")
    print(f"  Saved to: baselines/{record.name}.json\n")


def _list_baselines(args: Any) -> None:
    from src.regression.baseline import BaselineManager

    manager = BaselineManager()
    baselines = manager.list_baselines()

    if not baselines:
        print("\nNo baselines found. Create one with: penbot baseline create --latest\n")
        return

    machine = getattr(args, "machine", False)
    if machine:
        print(json.dumps(baselines, indent=2))
        return

    print(f"\n{'Name':<30} {'Target':<20} {'Score':<8} {'Attacks':<10} {'Created'}")
    print("-" * 90)
    for bl in baselines:
        print(
            f"{bl['name']:<30} {bl['target_name']:<20} "
            f"{bl['vulnerability_score']:<8.1f} "
            f"{bl['successful_attacks']}/{bl['total_attacks']:<7} "
            f"{bl['created_at'][:19]}"
        )
    print()


# ---------------------------------------------------------------------------
# penbot regression
# ---------------------------------------------------------------------------


def run_regression(args: Any) -> None:
    """Entry-point for ``penbot regression``."""
    asyncio.run(_run_regression_async(args))


async def _run_regression_async(args: Any) -> None:
    from src.regression.baseline import BaselineManager

    manager = BaselineManager()

    baseline_name = getattr(args, "baseline", None)
    if baseline_name:
        baseline = manager.load(baseline_name)
    else:
        baseline = manager.load_latest()

    if not baseline:
        print("\nNo baseline found. Create one first with: penbot baseline create --latest\n")
        sys.exit(1)

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"\nConfig file not found: {config_path}\n")
        sys.exit(1)

    print(f"\n{'='*60}")
    print("  REGRESSION TEST (attack replay)")
    print(f"{'='*60}")
    print(f"  Baseline: {baseline.name}")
    print(f"  Baseline score: {baseline.vulnerability_score:.1f}")
    print(f"  Baseline attacks: {baseline.total_attacks}")
    print(f"  Config: {config_path}")
    print(f"{'='*60}\n")

    print("  Replaying baseline attacks against target...\n")

    try:
        session = await _replay_baseline(config_path, baseline)
    except Exception as exc:
        print(f"\n  Replay failed: {exc}\n")
        logger.error("regression_replay_failed", error=str(exc))
        sys.exit(1)

    result = manager.compare(baseline, session)
    result.skipped = session.get("skipped", 0)

    _print_regression_report(result)

    fail_on_regression = getattr(args, "fail_on_regression", False)
    if fail_on_regression and result.has_regressions:
        print("  CI/CD: Exiting with code 1 due to regressions.\n")
        sys.exit(1)


async def _replay_baseline(config_path: Path, baseline: Any) -> dict:
    """Replay the exact baseline attacks against the target and collect results.

    Instead of running a full LLM-driven workflow (which generates different
    queries each time), this sends the *same* queries that were recorded in the
    baseline so the comparison is meaningful.
    """
    from src.cli.config_loader import load_config
    from src.connectors.factory import create_connector

    config = load_config(str(config_path))

    target_cfg = config.get("target", config)
    target_type = target_cfg.get("connection", {}).get("type", target_cfg.get("type", "api"))

    connector = create_connector(target_type, target_cfg)
    if hasattr(connector, "initialize"):
        await connector.initialize()

    attacks: list[dict[str, Any]] = []
    findings: list[dict[str, Any]] = []
    skipped = 0

    total = len(baseline.outcomes)
    for idx, outcome in enumerate(baseline.outcomes, 1):
        attack_record = {
            "attack_id": outcome.attack_id,
            "agent_name": outcome.agent_name,
            "attack_type": outcome.attack_type,
            "query": outcome.query_hash,
        }

        original_query = getattr(outcome, "query_text", "") or _recover_query(outcome)
        if not original_query:
            logger.debug("regression_skip_no_query", attack_id=outcome.attack_id)
            skipped += 1
            continue

        attack_record["query"] = original_query

        print(f"  [{idx}/{total}] {outcome.agent_name}: {original_query[:60]}...")

        try:
            response = await connector.send_message(original_query, context={})
            content = response.get("content", "") if isinstance(response, dict) else str(response)
        except Exception as exc:
            logger.warning("regression_replay_error", attack_id=outcome.attack_id, error=str(exc))
            skipped += 1
            continue

        attacks.append(attack_record)

        refused = not content or _looks_like_refusal(content)
        if not refused:
            findings.append(
                {
                    "finding_id": f"reg-{outcome.attack_id}",
                    "attack_id": outcome.attack_id,
                    "severity": outcome.finding_severity or "medium",
                    "category": outcome.finding_category or "regression_check",
                }
            )

    if hasattr(connector, "close"):
        await connector.close()

    from src.reporting.scoring import calculate_vulnerability_score

    return {
        "attack_attempts": attacks,
        "security_findings": findings,
        "vulnerability_score": calculate_vulnerability_score(findings),
        "skipped": skipped,
    }


def _recover_query(outcome: Any) -> str | None:
    """Try to recover the original query text from the session file.

    The baseline stores ``query_hash`` but the original text is in the
    session JSON that was used to create it.
    """
    sessions_dir = Path("sessions")
    if not sessions_dir.exists():
        return None

    for session_file in sessions_dir.glob("*.json"):
        try:
            data = json.loads(session_file.read_text())
            for attack in data.get("attack_attempts", []):
                if attack.get("attack_id") == outcome.attack_id:
                    return attack.get("query")
        except Exception:
            continue
    return None


def _looks_like_refusal(text: str) -> bool:
    from src.utils.helpers import looks_like_refusal

    return looks_like_refusal(text)


def _print_regression_report(result: Any) -> None:
    delta_symbol = "+" if result.score_delta >= 0 else ""
    print(f"  Baseline score: {result.baseline_score:.1f}")
    print(f"  Current score:  {result.current_score:.1f} ({delta_symbol}{result.score_delta:.1f})")
    print()

    if result.regressions:
        print(f"  REGRESSIONS ({len(result.regressions)}):")
        for r in result.regressions:
            print(f"    [REGRESSION] {r.agent_name} ({r.attack_type})")
            print(f"      Was: {r.baseline_outcome} → Now: {r.current_outcome}")
            print(f"      Query: {r.query_preview}")
        print()

    if result.improvements:
        print(f"  IMPROVEMENTS ({len(result.improvements)}):")
        for imp in result.improvements:
            print(f"    [IMPROVED] {imp.agent_name} ({imp.attack_type})")
            print(f"      Was: {imp.baseline_outcome} → Now: {imp.current_outcome}")
        print()

    print(f"  Matched attacks:     {result.matched}")
    print(f"  Unchanged blocked:   {result.unchanged_blocked}")
    print(f"  Unchanged succeeded: {result.unchanged_succeeded}")
    if result.unmatched_baseline:
        print(
            f"  Unmatched (baseline): {result.unmatched_baseline} (no matching query in current run)"
        )
    if result.unmatched_current:
        print(f"  Unmatched (current):  {result.unmatched_current} (new queries not in baseline)")
    if result.skipped:
        print(f"  Skipped:             {result.skipped}")
    print()

    if result.has_regressions:
        print("  VERDICT: REGRESSIONS DETECTED\n")
    else:
        print("  VERDICT: NO REGRESSIONS\n")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _resolve_session(args: Any) -> Path | None:
    session_id = getattr(args, "session", None)
    use_latest = getattr(args, "latest", False)

    sessions_dir = Path("sessions")
    if not sessions_dir.exists():
        print("No sessions directory found.")
        return None

    if use_latest or not session_id:
        files = sorted(sessions_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not files:
            print("No sessions found.")
            return None
        return files[0]

    direct = sessions_dir / f"{session_id}.json"
    if direct.exists():
        return direct

    for p in sessions_dir.glob("*.json"):
        if session_id in p.stem:
            return p

    print(f"Session '{session_id}' not found.")
    return None
