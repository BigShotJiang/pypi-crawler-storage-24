# langchain-pdfmux

LangChain document loader for [pdfmux](https://pdfmux.com) — self-healing PDF extraction.

## Install

```bash
pip install langchain-pdfmux
```

## Usage

```python
from langchain_pdfmux import PDFMuxLoader

docs = PDFMuxLoader("report.pdf").load()
```

Each `Document` includes metadata: `source`, `title`, `page_start`, `page_end`, `tokens`, `confidence`.

### Options

```python
# High-quality extraction
loader = PDFMuxLoader("report.pdf", quality="high")

# Load all PDFs in a directory
loader = PDFMuxLoader("./papers/")

# Streaming with lazy_load
for doc in PDFMuxLoader("large.pdf").lazy_load():
    process(doc)
```

## License

MIT
