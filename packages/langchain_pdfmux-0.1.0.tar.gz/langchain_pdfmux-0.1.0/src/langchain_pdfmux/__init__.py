"""LangChain document loader for pdfmux."""

from langchain_pdfmux.document_loader import PDFMuxLoader

__all__ = ["PDFMuxLoader"]
