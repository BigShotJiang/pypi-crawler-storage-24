"""LangChain document loader for pdfmux.

Usage:
    from langchain_pdfmux import PDFMuxLoader

    loader = PDFMuxLoader("report.pdf")
    docs = loader.load()
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterator

from langchain_core.document_loaders import BaseLoader
from langchain_core.documents import Document


class PDFMuxLoader(BaseLoader):
    """LangChain document loader powered by pdfmux.

    Extracts text from PDFs using pdfmux's self-healing multi-pass pipeline
    and returns LangChain Document objects with rich metadata.

    Supports single files and directories (all .pdf files in the directory).

    Args:
        file_path: Path to a PDF file or directory containing PDFs.
        quality: Extraction quality — "fast", "standard" (default), or "high".

    Example::

        from langchain_pdfmux import PDFMuxLoader

        loader = PDFMuxLoader("report.pdf", quality="high")
        docs = loader.load()
        for doc in docs:
            print(doc.metadata["source"], doc.metadata["confidence"])
    """

    def __init__(
        self,
        file_path: str | Path,
        *,
        quality: str = "standard",
    ) -> None:
        self.file_path = Path(file_path)
        self.quality = quality

    def lazy_load(self) -> Iterator[Document]:
        """Lazily load documents from the PDF(s).

        Yields:
            Document objects with page_content and metadata.
        """
        import pdfmux

        if self.file_path.is_dir():
            paths = sorted(self.file_path.glob("*.pdf"))
        else:
            paths = [self.file_path]

        for path in paths:
            chunks = pdfmux.load_llm_context(path, quality=self.quality)
            for chunk in chunks:
                yield Document(
                    page_content=chunk["text"],
                    metadata={
                        "source": str(path),
                        "title": chunk["title"],
                        "page_start": chunk["page_start"],
                        "page_end": chunk["page_end"],
                        "tokens": chunk["tokens"],
                        "confidence": chunk["confidence"],
                    },
                )
