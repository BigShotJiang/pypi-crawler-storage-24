"""
Shopify App Home Request Verification

This module provides functions to verify requests from Shopify App Home.
"""

from __future__ import annotations

import re
from urllib.parse import ParseResult, parse_qs, quote, urlparse

import jwt
from jwt.exceptions import PyJWTError

from ..types import (
    AppConfig,
    IdTokenDetails,
    LogWithReq,
    RequestInput,
    Res,
    ResultWithExchangeableIdToken,
)
from ..utils import redact_http_log
from ..utils.headers import _normalize_headers


def _remove_query_param(query: str, param: str) -> str:
    """
    Remove a query parameter from a raw query string.

    Operates on the raw query string with a regex rather than parsing into
    native data structures. This avoids the destructive transformations that
    parse_qs() applies (e.g. URL-decoding values) and preserves the original
    encoding exactly.

    Args:
        query: Raw query string without leading '?'
        param: Parameter name to remove

    Returns:
        Query string with the parameter removed
    """
    cleaned = re.sub(r"(?:^|&)" + re.escape(param) + r"=[^&]*", "", query)
    return cleaned.lstrip("&")


def _build_patch_id_token_redirect(
    parsed_url: ParseResult,
    path: str,
    raw_query: str,
    app_home_patch_id_token_path: str,
    request: RequestInput,
) -> ResultWithExchangeableIdToken:
    """
    Helper to build a response redirecting to the patch id token URL.

    Args:
        parsed_url: Parsed URL object from urlparse
        path: Request path
        raw_query: Raw query string (without leading '?')
        app_home_patch_id_token_path: Path to the patch id token page
        request: The original request object

    Returns:
        ResultWithExchangeableIdToken: Redirect response with 302 status and Location header
    """
    req = redact_http_log(request)
    clean_query = _remove_query_param(raw_query, "id_token")
    reload_path = path + ("?" + clean_query if clean_query else "")

    # Build patch id token URL with shopify-reload parameter
    shopify_reload = f"shopify-reload={quote(reload_path, safe='')}"
    patch_id_token_query = (
        f"{clean_query}&{shopify_reload}" if clean_query else shopify_reload
    )

    patch_id_token_location = f"{parsed_url.scheme}://{parsed_url.netloc}{app_home_patch_id_token_path}?{patch_id_token_query}"

    return ResultWithExchangeableIdToken(
        ok=False,
        shop=None,
        log=LogWithReq(
            code="redirect_to_patch_id_token_page",
            detail="Embedded app without id_token. Redirect to the patch ID token page to obtain a new token using the provided response.",
            req=req,
        ),
        response=Res(
            status=302,
            body="",
            headers={"Location": patch_id_token_location},
        ),
        user_id=None,
        id_token=None,
        new_id_token_response=None,
    )


def verify_app_home_req(
    request: RequestInput,
    config: AppConfig,
    app_home_patch_id_token_path: str,
) -> ResultWithExchangeableIdToken:
    """
    Verifies requests coming from Shopify App Home.

    Args:
        request (dict): The request object containing method, headers, url, and body
        config (dict): The app configuration with client_id, client_secret and optional old_client_secret
        app_home_patch_id_token_path (str): Path to the patch ID token page

    Returns:
        ResultWithExchangeableIdToken: Verification result with exchangeable ID token
    """
    req = redact_http_log(request)
    # Validate app_home_patch_id_token_path
    if not isinstance(app_home_patch_id_token_path, str):
        return ResultWithExchangeableIdToken(
            ok=False,
            shop=None,
            log=LogWithReq(
                code="configuration_error",
                detail="Expected appHomePatchIdTokenPath to be a non-empty string",
                req=req,
            ),
            response=Res(
                status=500,
                body="",
                headers={},
            ),
            user_id=None,
            id_token=None,
            new_id_token_response=None,
        )

    if app_home_patch_id_token_path == "":
        return ResultWithExchangeableIdToken(
            ok=False,
            shop=None,
            log=LogWithReq(
                code="configuration_error",
                detail="Expected appHomePatchIdTokenPath to be a non-empty string, but got ''",
                req=req,
            ),
            response=Res(
                status=500,
                body="",
                headers={},
            ),
            user_id=None,
            id_token=None,
            new_id_token_response=None,
        )

    # Validate request object
    url = request.get("url")
    if not isinstance(url, str) or url == "":
        return ResultWithExchangeableIdToken(
            ok=False,
            shop=None,
            log=LogWithReq(
                code="configuration_error",
                detail="Expected request.url to be a non-empty string",
                req=req,
            ),
            response=Res(
                status=500,
                body="",
                headers={},
            ),
            user_id=None,
            id_token=None,
            new_id_token_response=None,
        )

    headers = request.get("headers")
    if not isinstance(headers, dict):
        return ResultWithExchangeableIdToken(
            ok=False,
            shop=None,
            log=LogWithReq(
                code="configuration_error",
                detail="Expected request.headers to be an object",
                req=req,
            ),
            response=Res(
                status=500,
                body="",
                headers={},
            ),
            user_id=None,
            id_token=None,
            new_id_token_response=None,
        )

    client_secret = config.get("client_secret", "")
    old_client_secret = config.get("old_client_secret")
    client_id = config.get("client_id", "")

    # Normalize headers for case-insensitive comparison
    normalized_headers = _normalize_headers(headers)

    # Parse URL for query parameters
    parsed_url = urlparse(url)
    path = parsed_url.path
    query_dict = parse_qs(parsed_url.query, keep_blank_values=True)

    # Flatten query params (parse_qs returns lists)
    query_params = {}
    for key, value_list in query_dict.items():
        query_params[key] = value_list[0] if value_list else ""

    # Check for Authorization header to determine request type
    auth_header = normalized_headers.get("authorization", "")
    has_authorization_header = bool(auth_header)

    id_token = None

    # If no Authorization header, check if this is a document request
    if not has_authorization_header:
        id_token_param = query_params.get("id_token", "")

        # If no id_token, redirect to patch ID token page
        if not id_token_param:
            return _build_patch_id_token_redirect(
                parsed_url,
                path,
                parsed_url.query,
                app_home_patch_id_token_path,
                request,
            )

        id_token = id_token_param
    else:
        if not auth_header.startswith("Bearer "):
            return ResultWithExchangeableIdToken(
                ok=False,
                shop=None,
                log=LogWithReq(
                    code="invalid_id_token",
                    detail="ID token verification failed. Respond 401 Unauthorized using the provided response.",
                    req=req,
                ),
                response=Res(
                    status=401,
                    body="Unauthorized",
                    headers={
                        "X-Shopify-Retry-Invalid-Session-Request": "1",
                    },
                ),
                user_id=None,
                id_token=None,
                new_id_token_response=None,
            )
        id_token = auth_header[7:]  # Remove "Bearer " prefix

    if not id_token:
        return ResultWithExchangeableIdToken(
            ok=False,
            shop=None,
            log=LogWithReq(
                code="missing_authorization_and_id_token",
                detail="Neither Authorization header nor id_token query parameter present. Respond 401 Unauthorized using the provided response.",
                req=req,
            ),
            response=Res(
                status=401,
                body="Unauthorized",
                headers={},
            ),
            user_id=None,
            id_token=None,
            new_id_token_response=None,
        )

    payload = None
    verification_error = None

    secrets_to_try = []
    if old_client_secret:
        secrets_to_try.append(old_client_secret)
    secrets_to_try.append(client_secret)

    for secret in secrets_to_try:
        try:
            payload = jwt.decode(
                id_token,
                secret,
                algorithms=["HS256"],
                leeway=10,  # Clock tolerance of 10 seconds
                options={
                    "verify_aud": False,
                },
            )
            break
        except PyJWTError as e:
            verification_error = e
            continue  # Try next secret

    if payload is None:
        # For document requests with invalid/stale tokens, redirect to patch ID token page
        if not has_authorization_header:
            return _build_patch_id_token_redirect(
                parsed_url,
                path,
                parsed_url.query,
                app_home_patch_id_token_path,
                request,
            )

        # For fetch requests, return 401 with retry header
        error_code = "invalid_id_token"
        if verification_error and "expired" in str(verification_error).lower():
            error_code = "expired_id_token"
            detail_msg = "ID token has expired. Respond 401 Unauthorized using the provided response."
        else:
            detail_msg = "ID token verification failed. Respond 401 Unauthorized using the provided response."

        return ResultWithExchangeableIdToken(
            ok=False,
            shop=None,
            log=LogWithReq(
                code=error_code,
                detail=detail_msg,
                req=req,
            ),
            response=Res(
                status=401,
                body="Unauthorized",
                headers={
                    "X-Shopify-Retry-Invalid-Session-Request": "1",
                },
            ),
            user_id=None,
            id_token=None,
            new_id_token_response=None,
        )

    # Verify the audience (aud) matches the clientId
    token_aud = payload.get("aud", "")
    if token_aud != client_id:
        # For Authorization header requests, include retry header
        response_headers = {}
        if has_authorization_header:
            response_headers = {
                "X-Shopify-Retry-Invalid-Session-Request": "1",
            }

        return ResultWithExchangeableIdToken(
            ok=False,
            shop=None,
            log=LogWithReq(
                code="invalid_aud",
                detail="ID token audience (aud) claim does not match clientId. Respond 401 Unauthorized using the provided response.",
                req=req,
            ),
            response=Res(
                status=401,
                body="Unauthorized",
                headers=response_headers,
            ),
            user_id=None,
            id_token=None,
            new_id_token_response=None,
        )

    # Extract shop from dest claim (parse as URL and get hostname)
    dest = payload.get("dest", "")
    dest_parts = urlparse(dest)
    shop_hostname = dest_parts.hostname if dest_parts.hostname else dest
    shop = shop_hostname.replace(".myshopify.com", "")

    # Extract user_id from sub claim
    user_id = payload.get("sub")

    # For document requests, add security and preload headers
    response_headers = {}
    if not has_authorization_header:
        response_headers = {
            "Content-Security-Policy": f"frame-ancestors https://{shop_hostname} https://admin.shopify.com;",
            "Link": '<https://cdn.shopify.com>; rel="preconnect", <https://cdn.shopify.com/shopifycloud/app-bridge.js>; rel="preload"; as="script", <https://cdn.shopify.com/shopifycloud/polaris.js>; rel="preload"; as="script"',
        }

    # Build new_id_token_response
    new_id_token_response = None
    if not has_authorization_header:
        # Document request - build patch ID token URL
        clean_query = _remove_query_param(parsed_url.query, "id_token")
        reload_path = path + ("?" + clean_query if clean_query else "")

        shopify_reload = f"shopify-reload={quote(reload_path, safe='')}"
        patch_id_token_query = (
            f"{clean_query}&{shopify_reload}" if clean_query else shopify_reload
        )

        patch_id_token_location = f"{parsed_url.scheme}://{parsed_url.netloc}{app_home_patch_id_token_path}?{patch_id_token_query}"

        new_id_token_response = Res(
            status=302,
            body="",
            headers={
                "Location": patch_id_token_location,
            },
        )
    else:
        # Fetch request
        new_id_token_response = Res(
            status=401,
            body="",
            headers={
                "X-Shopify-Retry-Invalid-Session-Request": "1",
            },
        )

    # Build log detail message
    log_detail = "App Home request verified. Proceed with business logic."
    if not has_authorization_header:
        log_detail += "  Include the headers in the provided response."

    return ResultWithExchangeableIdToken(
        ok=True,
        shop=shop,
        log=LogWithReq(
            code="verified",
            detail=log_detail,
            req=req,
        ),
        response=Res(
            status=200,
            body="",
            headers=response_headers,
        ),
        user_id=user_id,
        id_token=IdTokenDetails(
            exchangeable=True,
            token=id_token,
            claims=payload,
        ),
        new_id_token_response=new_id_token_response,
    )
