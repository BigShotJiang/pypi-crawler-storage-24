.. _install:

Install and configure
~~~~~~~~~~~~~~~~~~~~~

This section describes how to install and configure the Infrastructure
Optimization service, code-named watcher, on the controller node.

This section assumes that you already have a working OpenStack
environment with at least the following components installed:
Identity Service, Compute Service, Telemetry data collection service.

Note that installation and configuration vary by distribution.

.. toctree::
   :maxdepth: 2

   install-rdo.rst
   install-ubuntu.rst
