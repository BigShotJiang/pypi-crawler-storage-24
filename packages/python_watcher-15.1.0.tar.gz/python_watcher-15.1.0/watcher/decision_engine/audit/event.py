# -*- encoding: utf-8 -*-
# Copyright (c) 2019 ZTE Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from watcher.decision_engine.audit import base
from watcher import objects


class EventAuditHandler(base.AuditHandler):

    def post_execute(self, audit, solution, request_context):
        super(EventAuditHandler, self).post_execute(audit, solution,
                                                    request_context)
        # change state of the audit to SUCCEEDED
        self.update_audit_state(audit, objects.audit.State.SUCCEEDED)
