"""
Conciliate - AI context synchronization and propagation between dev environments.
"""

__version__ = "0.7.0"
