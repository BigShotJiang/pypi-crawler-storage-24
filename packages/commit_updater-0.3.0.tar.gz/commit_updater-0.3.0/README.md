# CommitUpdater

用于在主工程中批量更新 `Podfile.lock` 里的组件 commit，并自动提交推送主工程仓库。

## 功能概述

- 拉取主工程最新代码
- 获取组件仓库最新 commit
- 更新 `Podfile.lock` 中对应组件的 `:commit:`
- 自动提交并推送主工程改动

## 安装

### 本地安装

```bash
cd CommitUpdater
pip install -e .
```

安装后会提供命令：`bbcu`

### 外网安装

发布到 PyPI 后，可直接安装：

```bash
pip install commit-updater
# pip命令没有找到，使用 python3 -m pip  命令安装
python3 -m pip install commit-updater
# 已安装更新
python3 -m pip install -U commit-updater
```

## 使用方式

进入包含 `Podfile.lock` 的主工程目录后执行：

```bash
bbcu BBUnlock BBEngine
# 如果命令没有找到，查询安装位置，把安装路径中lib文件夹平级的bin文件夹添加到PATH中重新试下
python3 -m pip show commit-updater
```

也可以更新单个组件：

```bash
bbcu BBUnlock
```

## 适用场景

适用于基于 CocoaPods 管理组件依赖、并使用 `Podfile.lock` 锁定 commit 的工程。

## 更多说明

实现细节、PyCharm 运行说明、提交规则、发布流程和维护注意事项见：`DEVELOPMENT.md`
