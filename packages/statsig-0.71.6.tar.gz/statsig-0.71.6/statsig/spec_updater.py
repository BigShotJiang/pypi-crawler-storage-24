import json
import threading
import time
from typing import Optional, Callable, List, Tuple
from urllib.parse import urlparse

from . import globals
from .diagnostics import Diagnostics, Marker, Context, Key
from .evaluation_details import DataSource
from .http_worker import RequestResult
from .interface_data_store import IDataStore
from .interface_network import IStreamingListeners
from .statsig_context import InitContext
from .statsig_error_boundary import _StatsigErrorBoundary
from .statsig_errors import StatsigValueError, StatsigNameError
from .statsig_network import _StatsigNetwork
from .statsig_options import StatsigOptions
from .statsig_telemetry_logger import NetworkRequestContext
from .thread_util import spawn_background_thread, THREAD_JOIN_TIMEOUT
from .utils import djb2_hash

RULESETS_SYNC_INTERVAL = 10
IDLISTS_SYNC_INTERVAL = 60
SYNC_OUTDATED_MAX_S = 120
STORAGE_ADAPTER_KEY = "statsig.cache"
DOWNLOAD_ID_LIST_FILE_DATASTORE_PATH_PREFIX = "/v1/download_id_list_file/"


class SpecUpdater:
    STATSIG_NETWORK_FALLBACK_THRESHOLD = 5

    def __init__(
            self,
            network: _StatsigNetwork,
            data_adapter: Optional[IDataStore],
            options: StatsigOptions,
            diagnostics: Diagnostics,
            sdk_key: str,
            error_boundary: _StatsigErrorBoundary,
            statsig_metadata: dict,
            shutdown_event: threading.Event,
            context: InitContext
    ):
        self._shutdown_event = shutdown_event
        self._sync_failure_count = 0
        self._network = network
        self._options = options
        self._diagnostics = diagnostics
        self._sdk_key = sdk_key
        self._error_boundary = error_boundary
        self._statsig_metadata = statsig_metadata
        self._background_download_configs = None
        self._background_download_id_lists = None
        # DCS polling: set => polling enabled, clear => paused
        self._dcs_polling_enabled_event = threading.Event()
        self._dcs_polling_enabled_event.set()
        self._config_sync_strategies = self._get_sync_dcs_strategies()
        self._dcs_process_lock = threading.Lock()
        if options.out_of_sync_threshold_in_s is not None:
            self._enforce_sync_fallback_threshold_in_ms: Optional[float] = options.out_of_sync_threshold_in_s * 1000
        else:
            self._enforce_sync_fallback_threshold_in_ms = None

        self.initialized = False
        self.last_update_time = 0
        self.initial_update_time = 0
        self.dcs_listener: Optional[Callable] = None
        self.id_lists_listener: Optional[Callable] = None
        self._succeed_single_id_list_number = 0
        self._dcs_source_success = False
        self._dcs_process_success = False
        self._dcs_response_format = "unknown"
        self._dcs_final_error = ""
        self.data_adapter = data_adapter
        self.context = context

    def get_config_spec(self, source: DataSource, for_initialize=False):
        start_time_ms = time.time() * 1000
        try:
            self._log_process(f"Loading specs from {source.value}...",
                              "Initialize" if for_initialize else "Config Sync")
            init_timeout = None
            if for_initialize:
                init_timeout = self._options.init_timeout
            if source is DataSource.DATASTORE:
                self.context.source_api = DataSource.DATASTORE.value
                self.load_config_specs_from_storage_adapter()
            elif source is DataSource.BOOTSTRAP:
                self.context.source_api = DataSource.BOOTSTRAP.value
                self.bootstrap_config_specs()
            elif source is DataSource.NETWORK:
                self._network.get_dcs(
                    self._on_dcs_complete,
                    self.last_update_time,
                    True,
                    init_timeout,
                    NetworkRequestContext.INITIALIZE.value if for_initialize else NetworkRequestContext.BACKGROUND_SYNC.value,
                )
            elif source is DataSource.STATSIG_NETWORK:
                self._network.get_dcs_fallback(
                    self._on_dcs_complete,
                    self.last_update_time,
                    True,
                    init_timeout,
                    NetworkRequestContext.INITIALIZE.value if for_initialize else NetworkRequestContext.BACKGROUND_SYNC.value,
                )
        except Exception as e:
            if not for_initialize:
                self._sync_failure_count += 1
            self._dcs_final_error = str(e)
            self._error_boundary.log_exception(f"get_config_spec:{source}", e)
        finally:
            if not for_initialize:
                globals.logger.log_background_config_overall(
                    source_api=self.context.source_api,
                    error=self._dcs_final_error,
                    source_success=self._dcs_source_success,
                    process_success=self._dcs_process_success,
                    duration_ms=time.time() * 1000 - start_time_ms,
                    response_format=self._dcs_response_format,
                )

    def register_process_network_id_lists_listener(self, listener: Callable):
        self.id_lists_listener = listener

    def register_process_dcs_listener(self, listener: Callable):
        def dcs_listener_with_lock(spec_json, source: DataSource) -> bool:
            with self._dcs_process_lock:
                return listener(spec_json, source)

        self.dcs_listener = dcs_listener_with_lock

    def record_succeed_single_id_list_number(self, count: int) -> None:
        self._succeed_single_id_list_number = count

    def _reset_dcs_sync_metrics(self) -> None:
        self._dcs_source_success = False
        self._dcs_process_success = False
        self._dcs_response_format = "unknown"
        self._dcs_final_error = ""

    def _mark_dcs_source_failure(
        self,
        response_format: str = "unknown",
        final_error: str = "source_failure",
    ) -> None:
        self._dcs_source_success = False
        self._dcs_process_success = False
        self._dcs_response_format = response_format
        self._dcs_final_error = final_error

    def load_config_specs_from_storage_adapter(self) -> bool:
        def load():
            try:
                if self._options.data_store is None:
                    return False

                self._diagnostics.add_marker(
                    Marker().data_store_config_specs().process().start()
                )

                cache_string = self._options.data_store.get(STORAGE_ADAPTER_KEY)
                if not isinstance(cache_string, str):
                    self._mark_dcs_source_failure(final_error="invalid_cache_type")
                    return False

                cache = json.loads(cache_string)
                if not isinstance(cache, dict):
                    self._mark_dcs_source_failure("invalid_json", "invalid_json")
                    globals.logger.warning(
                        "Invalid type returned from StatsigOptions.data_store"
                    )
                    return False
                self._dcs_source_success = True
                self._dcs_response_format = "json"
                adapter_time = cache.get("time", None)
                if not isinstance(adapter_time, int) or adapter_time < self.last_update_time:
                    self._dcs_process_success = False
                    self._dcs_final_error = "stale_or_invalid_cache_time"
                    return False

                self._log_process("Done loading specs")
                _, parse_success = False, False
                if self.dcs_listener is not None:
                    _, parse_success = self.dcs_listener(cache, DataSource.DATASTORE)
                self._dcs_process_success = parse_success
                self._dcs_final_error = "" if parse_success else "dcs_listener_failed"
                self._diagnostics.add_marker(
                    Marker()
                    .data_store_config_specs()
                    .process()
                    .end({"success": parse_success})
                )
                return parse_success

            except Exception as err:
                self._mark_dcs_source_failure(final_error=str(err))
                self._diagnostics.add_marker(
                    Marker()
                    .data_store_config_specs()
                    .process()
                    .end(
                        {"success": False, "error": err.__dict__},
                    )
                )
                return False
            finally:
                self._diagnostics.log_diagnostics(
                    Context.CONFIG_SYNC, Key.DATA_STORE_CONFIG_SPECS
                )

        success = load()
        if success is False:
            self._sync_failure_count += 1
        return success

    def _on_dcs_complete(self, data_source: DataSource, specs: Optional[dict], error: Optional[Exception]):
        def process() -> Tuple[bool, Optional[Exception]]:
            if error is not None:
                self._mark_dcs_source_failure(final_error=str(error))
                return False, error

            if specs is None:
                self._mark_dcs_source_failure(final_error="download_failed")
                return False, StatsigValueError("Failed to download specs from network")
            if not isinstance(specs, dict):
                self._mark_dcs_source_failure("invalid_json", "invalid_json")
                return False, StatsigValueError("Failed to parse specs response as JSON object")
            self._dcs_source_success = True
            self._dcs_response_format = "json"
            err = None
            try:
                self._diagnostics.add_marker(
                    Marker().download_config_specs().process().start()
                )
                self._log_process("Done loading specs")
                has_update, parse_success = False, False  # parce success can be true even if there is no update
                if self.dcs_listener is not None:
                    has_update, parse_success = self.dcs_listener(specs, data_source)
                if has_update:
                    self._save_to_storage_adapter(specs)
                self._dcs_process_success = parse_success
                self._dcs_final_error = "" if parse_success else "dcs_listener_failed"
                return parse_success, None
            except Exception as e:
                self._dcs_process_success = False
                self._dcs_final_error = str(e)
                return False, e
            finally:
                self._diagnostics.add_marker(
                    Marker()
                    .download_config_specs()
                    .process()
                    .end(
                        {"success": err is None, "error": Diagnostics.format_error(err)}
                    )
                )

        parse_success, error = process()
        if parse_success is False:
            self._sync_failure_count += 1  # increment sync failure to trigger fallback behavior

    def _log_process(self, msg, process=None):
        if process is None:
            process = "Initialize" if not self.initialized else "Config Sync"
        globals.logger.log_process(process, msg)

    def _save_to_storage_adapter(self, specs):
        if not self.is_specs_json_valid(specs):
            return

        if self._options.data_store is None:
            return

        if self.last_update_time == 0:
            return

        self._options.data_store.set(STORAGE_ADAPTER_KEY, json.dumps(specs))

    def _get_id_list_file_data_store_key(
            self,
            url: str,
            id_list_file_id: Optional[str],
    ) -> Optional[str]:
        parsed_path = urlparse(url).path
        if parsed_path.startswith(DOWNLOAD_ID_LIST_FILE_DATASTORE_PATH_PREFIX):
            return parsed_path
        if id_list_file_id:
            return f"{DOWNLOAD_ID_LIST_FILE_DATASTORE_PATH_PREFIX}{id_list_file_id}"
        return None

    def _normalize_data_store_value(self, value) -> Optional[str]:
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeDecodeError:
                return None
        return None

    def _apply_downloaded_id_list_content(
            self,
            list_name: str,
            local_list: dict,
            all_lists: dict,
            start_index: int,
            content: str,
            content_length: int,
    ) -> None:
        if not content:
            raise StatsigValueError("ID list content is empty.")

        first_char = content[0]
        if first_char not in ("+", "-"):
            raise StatsigNameError("Seek range invalid.")

        ids = local_list.get("ids")
        if not isinstance(ids, set):
            ids = set(ids or [])
            local_list["ids"] = ids

        for line in content.splitlines():
            if len(line) <= 1:
                continue
            op = line[0]
            id_value = line[1:].strip()
            if op == "+":
                ids.add(id_value)
            elif op == "-":
                ids.discard(id_value)

        local_list["readBytes"] = start_index + content_length
        all_lists[list_name] = local_list

    def _load_id_list_file_from_data_store(
            self,
            data_store_key: Optional[str],
            list_name: str,
            local_list: dict,
            all_lists: dict,
            start_index: int,
    ) -> bool:
        if self._options.data_store is None:
            return False

        if data_store_key is None:
            return False

        try:
            cached_value = self._options.data_store.get(data_store_key)
            cached_content = self._normalize_data_store_value(cached_value)
            if cached_content is None:
                return False

            cached_bytes = cached_content.encode("utf-8")
            expected_size = local_list.get("size")
            if expected_size is not None:
                if len(cached_bytes) < expected_size:
                    return False
                cached_bytes = cached_bytes[:expected_size]

            if start_index > len(cached_bytes):
                return False

            remaining_bytes = cached_bytes[start_index:]
            remaining_content = remaining_bytes.decode("utf-8")
            self._apply_downloaded_id_list_content(
                list_name,
                local_list,
                all_lists,
                start_index,
                remaining_content,
                len(remaining_bytes),
            )
            return True
        except Exception as e:
            self._error_boundary.log_exception(
                "_download_single_id_list_from_data_store",
                e,
            )
            return False

    def _save_id_list_file_to_data_store(
            self,
            data_store_key: Optional[str],
            content: str,
            start_index: int,
    ) -> None:
        if self._options.data_store is None:
            return

        if data_store_key is None:
            return

        try:
            if start_index == 0:
                self._options.data_store.set(data_store_key, content)
                return

            cached_value = self._options.data_store.get(data_store_key)
            cached_content = self._normalize_data_store_value(cached_value)
            if cached_content is None:
                return

            cached_bytes = cached_content.encode("utf-8")
            if len(cached_bytes) < start_index:
                return

            updated_bytes = cached_bytes[:start_index] + content.encode("utf-8")
            self._options.data_store.set(data_store_key, updated_bytes.decode("utf-8"))
        except Exception as e:
            self._error_boundary.log_exception("_save_id_list_file_to_data_store", e)

    def is_specs_json_valid(self, specs_json):
        if specs_json is None or specs_json.get("time") is None:
            return False
        hashed_sdk_key_used = specs_json.get("hashed_sdk_key_used", None)
        if hashed_sdk_key_used is not None and hashed_sdk_key_used != djb2_hash(
                self._sdk_key
        ):
            return False
        return True

    def bootstrap_config_specs(self):
        self._diagnostics.add_marker(Marker().bootstrap().process().start())
        if self._options.bootstrap_values is None:
            self._mark_dcs_source_failure(final_error="missing_bootstrap_values")
            return

        _, success = False, False

        try:
            specs = json.loads(self._options.bootstrap_values)
            if not isinstance(specs, dict):
                self._mark_dcs_source_failure("invalid_json", "invalid_json")
                return
            self._dcs_source_success = True
            self._dcs_response_format = "json"
            if specs is None or not self.is_specs_json_valid(specs):
                self._dcs_process_success = False
                self._dcs_final_error = "invalid_bootstrap_specs"
                return
            if self.dcs_listener is not None:
                _, success = self.dcs_listener(specs, DataSource.BOOTSTRAP)
            self._dcs_process_success = success
            self._dcs_final_error = "" if success else "dcs_listener_failed"

        except ValueError as e:
            # JSON decoding failed, just let background thread update rulesets
            self._mark_dcs_source_failure("invalid_json", str(e))
            globals.logger.error("Failed to parse bootstrap_values")
        finally:
            self._diagnostics.add_marker(
                Marker().bootstrap().process().end({"success": success})
            )

    def download_id_lists(self, for_initialize=False):
        self.record_succeed_single_id_list_number(0)

        def on_complete(id_lists: list, error: Exception):
            if error is not None:
                self._error_boundary.log_exception("_download_id_lists", error)
                return
            if id_lists is None:
                return
            result[0] = True
            if self.id_lists_listener is not None:
                self.id_lists_listener(id_lists)

        result: List[bool] = [False]

        try:
            init_timeout: Optional[int] = None
            if for_initialize:
                init_timeout = self._options.init_timeout

            start_time_ms = time.time() * 1000
            request_context = (
                NetworkRequestContext.INITIALIZE.value
                if for_initialize
                else NetworkRequestContext.BACKGROUND_SYNC.value
            )
            self._network.get_id_lists(on_complete, False, init_timeout, request_context)
            if not for_initialize:
                globals.logger.log_background_id_lists_overall(
                    duration_ms=time.time() * 1000 - start_time_ms,
                    id_list_manifest_success=result[0],
                    succeed_single_id_list_number=(
                        self._succeed_single_id_list_number if result[0] else 0
                    ),
                )
            if result[0] is False and self._options.fallback_to_statsig_api:
                self.record_succeed_single_id_list_number(0)
                start_time_ms = time.time() * 1000
                self._network.get_id_lists_fallback(
                    on_complete,
                    False,
                    init_timeout,
                    request_context,
                )
                if not for_initialize:
                    globals.logger.log_background_id_lists_overall(
                        duration_ms=time.time() * 1000 - start_time_ms,
                        id_list_manifest_success=result[0],
                        succeed_single_id_list_number=(
                            self._succeed_single_id_list_number if result[0] else 0
                        ),
                    )

        except Exception as e:
            raise e
        finally:
            self._diagnostics.log_diagnostics(Context.CONFIG_SYNC, Key.GET_ID_LIST)

    def download_single_id_list(
            self, url, list_name, local_list, all_lists, start_index
    ):
        result = [False]
        data_store_key = self._get_id_list_file_data_store_key(
            url,
            local_list.get("fileID"),
        )

        if self._load_id_list_file_from_data_store(
                data_store_key,
                list_name,
                local_list,
                all_lists,
                start_index,
        ):
            return True

        def on_complete(resp: RequestResult):
            if resp is None:
                return
            threw_error = False
            try:
                self._diagnostics.add_marker(
                    Marker().get_id_list().process().start({"url": url})
                )
                content_length_str = resp.headers.get("content-length") if resp.headers else None
                if content_length_str is None:
                    raise StatsigValueError("Content length invalid.")
                content_length = int(content_length_str)
                content = resp.text
                if content is None:
                    return
                self._apply_downloaded_id_list_content(
                    list_name,
                    local_list,
                    all_lists,
                    start_index,
                    content,
                    content_length,
                )
                self._save_id_list_file_to_data_store(
                    data_store_key,
                    content,
                    start_index,
                )
                result[0] = True
            except Exception as e:
                threw_error = True
                self._error_boundary.log_exception("_download_single_id_list", e)
            finally:
                self._diagnostics.add_marker(
                    Marker()
                    .get_id_list()
                    .process()
                    .end(
                        {
                            "url": url,
                            "success": not threw_error,
                        }
                    )
                )

        headers = {"Range": f"bytes={start_index}-"}
        file_size = local_list.get("size")
        if file_size is not None:
            headers["statsig-id-list-file-size"] = str(file_size)

        self._network.get_id_list(
            on_complete,
            url,
            headers=headers,
            id_list_file_id=local_list.get("fileID"),
            request_context=(
                NetworkRequestContext.BACKGROUND_SYNC.value
                if self.initialized
                else NetworkRequestContext.INITIALIZE.value
            ),
        )
        return result[0]

    def start_background_threads(self):
        if self._options.local_mode:
            return
        self._diagnostics.set_context(Context.CONFIG_SYNC)
        if self._network.is_pull_worker("download_config_specs"):
            if (
                    self._background_download_configs is None
                    or not self._background_download_configs.is_alive()
            ):
                self._spawn_bg_poll_dcs()
        else:

            def on_update_dcs(specs: dict, lcut: int):
                if self.last_update_time > lcut:
                    return
                if self.dcs_listener is not None:
                    self.dcs_listener(specs, DataSource.NETWORK)

            def on_error_dcs(e: Exception):
                # pylint: disable=unused-argument
                pass

            self._network.listen_for_dcs(
                IStreamingListeners(on_error=on_error_dcs, on_update=on_update_dcs),
                lambda: self._network.get_dcs_fallback(
                    self._on_dcs_complete, since_time=self.last_update_time, log_on_exception=True
                ),
            )

        if self._network.is_pull_worker("download_id_lists"):
            if (
                    self._background_download_id_lists is None
                    or not self._background_download_id_lists.is_alive()
            ):
                self._spawn_bg_poll_id_lists()
        else:

            def on_update_id_list(id_lists: list, lcut: int):
                if self.last_update_time > lcut:
                    return
                if self.id_lists_listener is not None:
                    self.id_lists_listener(id_lists)

            def on_error_id_list(e: Exception):
                self._error_boundary.log_exception("_listen_for_id_list", e)

            self._network.listen_for_id_lists(
                IStreamingListeners(
                    on_error=on_error_id_list, on_update=on_update_id_list
                )
            )

    def _spawn_bg_poll_dcs(self):
        interval = self._options.rulesets_sync_interval or RULESETS_SYNC_INTERVAL
        fast_start = self._sync_failure_count > 0
        globals.logger.info(
            f"Starting polling for downloading config specs with an interval "
            f"of {interval}s")

        def sync_config_spec():
            for i, strategy in enumerate(self._config_sync_strategies):
                prev_failure_count = self._sync_failure_count

                if (
                    strategy is DataSource.STATSIG_NETWORK
                    and self._sync_failure_count > 0
                    and self._sync_failure_count % self.STATSIG_NETWORK_FALLBACK_THRESHOLD != 0
                ):
                    continue

                self._reset_dcs_sync_metrics()
                self.get_config_spec(strategy)
                outof_sync = False
                time_elapsed = time.time() * 1000 - self.last_update_time
                if self._enforce_sync_fallback_threshold_in_ms is not None and time_elapsed > self._enforce_sync_fallback_threshold_in_ms:
                    outof_sync = True
                attempt_success = (
                    prev_failure_count == self._sync_failure_count and not outof_sync
                )
                source_api = self.context.source_api
                if attempt_success:
                    globals.logger.log_process(
                        "Config Sync",
                        f"Syncing config values with {strategy.value}"
                        + (f"[{source_api}]" if source_api else "")
                        + " successful",
                    )
                    break
                if i < len(self._config_sync_strategies) - 1:
                    globals.logger.log_process(
                        "Config Sync",
                        f"Syncing config values failed with {strategy.value}"
                        + (f"[{source_api}]" if source_api else "")
                        + ", falling back to next available configured config sync method",
                    )

                else:
                    globals.logger.log_process(
                        "Config Sync",
                        f"Syncing config values failed with {strategy.value}"
                        + (f"[{source_api}]" if source_api else "")
                        + f". No more strategies left. The next sync will be in {interval} seconds.",
                    )

        self._background_download_configs = spawn_background_thread(
            "bg_download_config_specs",
            self._sync,
            (sync_config_spec, interval, fast_start, self._dcs_polling_enabled_event),
            self._error_boundary,
        )

    def _spawn_bg_poll_id_lists(self):
        interval = self._options.idlists_sync_interval or IDLISTS_SYNC_INTERVAL
        self._background_download_id_lists = spawn_background_thread(
            "bg_download_id_lists",
            self._sync,
            (self.download_id_lists, interval),
            self._error_boundary,
        )

    def _sync(
        self,
        sync_func,
        interval,
        fast_start=False,
        enabled_event: Optional[threading.Event] = None,
    ):
        if fast_start and (enabled_event is None or enabled_event.is_set()):
            sync_func()

        while True:
            try:
                # Wait until next interval, unless shutdown is requested.
                if self._shutdown_event.wait(timeout=interval):
                    return
                if enabled_event is not None and not enabled_event.is_set():
                    continue
                sync_func()
            except Exception as e:
                self._error_boundary.log_exception("_sync", e)

    def pause_polling_dcs(self):
        self._dcs_polling_enabled_event.clear()

    def start_polling_dcs(self):
        self._dcs_polling_enabled_event.set()

    def _get_sync_dcs_strategies(self) -> List[DataSource]:
        try:
            if self._options.config_sync_sources is not None:
                return self._options.config_sync_sources
            strategies = [DataSource.NETWORK]
            if (
                    self._options.data_store is not None
                    and self._options.data_store.should_be_used_for_querying_updates(
                STORAGE_ADAPTER_KEY
            )
            ):
                strategies.insert(0, DataSource.DATASTORE)
            if self._options.fallback_to_statsig_api:
                strategies.append(DataSource.STATSIG_NETWORK)
            return strategies
        except Exception:
            globals.logger.warning(
                "Failed to get sync sources, fallling back to always sync from statsig network "
            )
            return [DataSource.STATSIG_NETWORK]

    def shutdown(self):
        if self._background_download_configs is not None:
            self._background_download_configs.join(THREAD_JOIN_TIMEOUT)

        if self._background_download_id_lists is not None:
            self._background_download_id_lists.join(THREAD_JOIN_TIMEOUT)
