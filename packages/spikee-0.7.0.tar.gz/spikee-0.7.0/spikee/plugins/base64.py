"""
Base64 Encoding Plugin

This plugin transforms the input text into Base64 encoding.

Usage:
    spikee generate --plugins base64

Parameters:
    text (str): The input text to be transformed.

Returns:
    str: The transformed text in Base64 encoding.
"""

import base64
from typing import List, Tuple

from spikee.templates.plugin import Plugin
from spikee.utilities.enums import ModuleTag


class Base64(Plugin):
    def get_description(self) -> Tuple[List[ModuleTag], str]:
        return [], "Transforms text into Base64 encoding."

    def get_available_option_values(self) -> Tuple[List[str], bool]:
        """Return supported attack options; Tuple[options (default is first), llm_required]"""
        return [], False

    def transform(self, text: str, exclude_patterns: List[str] = []) -> str:
        """
        Transforms the input text into Base64 encoding.

        Args:
            text (str): The input text.

        Returns:
            str: The transformed text in Base64 encoding.
        """
        return base64.b64encode(text.encode()).decode()
