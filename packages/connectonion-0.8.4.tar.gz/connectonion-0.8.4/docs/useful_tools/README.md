# Built-in Tools

Pre-built tools for common agent tasks.

## Quick Reference

| Tool | Purpose | Import |
|------|---------|--------|
| [bash](bash.md) | Execute bash commands (Unix/Mac) | `from connectonion import bash` |
| [Shell](shell.md) | Execute shell commands (cross-platform) | `from connectonion import Shell` |
| [FileTools](file_tools.md) | Read/edit files with safety tracking | `from connectonion.useful_tools import FileTools` |
| [BrowserAutomation](browser_tools.md) | Natural language browser automation | `from connectonion.useful_tools.browser_tools import BrowserAutomation` |
| [DiffWriter](diff_writer.md) | Edit files with diffs | `from connectonion import DiffWriter` |
| [TodoList](todo_list.md) | Track task progress | `from connectonion import TodoList` |
| [WebFetch](web_fetch.md) | Fetch web content | `from connectonion import WebFetch` |
| [Gmail](gmail.md) | Gmail integration | `from connectonion import Gmail` |
| [get_emails](get_emails.md) | Email parsing utilities | `from connectonion import get_emails` |
| [send_email](send_email.md) | Send emails via API | `from connectonion import send_email` |
| [Outlook](outlook.md) | Outlook integration | `from connectonion import Outlook` |
| [GoogleCalendar](google_calendar.md) | Google Calendar | `from connectonion import GoogleCalendar` |
| [MicrosoftCalendar](microsoft_calendar.md) | Microsoft Calendar | `from connectonion import MicrosoftCalendar` |
| [Memory](memory.md) | Persistent memory | `from connectonion import Memory` |
| [Terminal](terminal.md) | Interactive terminal | `from connectonion import Terminal` |
| [SlashCommand](slash_command.md) | Custom commands | `from connectonion import SlashCommand` |

## Usage Pattern

```python
from connectonion import Agent, Shell
from connectonion.useful_tools import FileTools

# Create tool instances
shell = Shell()
file_tools = FileTools()  # Full access with read-before-edit tracking

# Pass to agent
agent = Agent("coder", tools=[shell, file_tools])

agent.input("Create a hello.py file that prints 'Hello World'")
```

## Customizing Tools

Need to modify a built-in tool? Copy it to your project:

```bash
# Copy tool source to ./tools/
co copy Gmail

# Copy multiple tools
co copy Gmail Shell memory
```

Then import from your local copy:

```python
# Before (from package)
from connectonion import Gmail

# After (from your copy)
from tools.gmail import Gmail  # Customize freely!
```

See [co copy](../cli/copy.md) for full details.

## Categories

### File Operations
- **bash** - Run bash commands, return output (Unix/Mac)
- **Shell** - Run commands, scripts, git (cross-platform)
- **FileTools** - Read/edit files with safety tracking (read-before-edit, stale-read detection)
- **DiffWriter** - Edit files with visual diffs (legacy)

### Browser
- **BrowserAutomation** - Natural language browser automation with persistent sessions

### Communication
- **Gmail** - Send/read Gmail
- **Outlook** - Send/read Outlook

### Calendar
- **GoogleCalendar** - Google Calendar events
- **MicrosoftCalendar** - Microsoft Calendar events

### Utilities
- **WebFetch** - Fetch and parse web pages
- **Memory** - Store/retrieve persistent data
- **TodoList** - Track tasks and progress
- **Terminal** - Interactive terminal UI
- **SlashCommand** - Define custom commands
