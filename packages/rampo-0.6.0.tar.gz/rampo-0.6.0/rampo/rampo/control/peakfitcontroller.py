import os
import traceback
import numpy as np
from qtpy import QtWidgets
from .mplcontroller import MplController
from .peakfittablecontroller import PeakfitTableController
from ..utils import make_filename, get_temp_dir
from ..model.param_session_io import load_section_from_param, is_new_param_folder


class PeakFitController(object):

    def __init__(self, model, widget):
        self.model = model
        self.widget = widget
        self.plot_ctrl = MplController(self.model, self.widget)
        self.peakfit_table_ctrl = PeakfitTableController(
            self.model, self.widget)
        self.connect_channel()

    def connect_channel(self):
        self.widget.pushButton_SetFitSection.clicked.connect(
            self.set_fit_section)
        self.widget.pushButton_ConductFitting.clicked.connect(
            self.conduct_fitting)
        self.widget.pushButton_PkSave.clicked.connect(
            self.save_to_section)
        self.widget.pushButton_ClearSection.clicked.connect(
            self.clear_this_section)
        self.widget.pushButton_PkFtSectionRemove.clicked.connect(
            self.remove_section)
        self.widget.pushButton_PkFtSectionClear.clicked.connect(
            self.clear_section_list)
        self.widget.pushButton_PkFtSectionSetToCurrent.clicked.\
            connect(self.set_section_to_current)
        self.widget.pushButton_ZoomToSection.clicked.connect(
            self.zoom_to_section)
        self.widget.pushButton_PkFtSectionSavetoXLS.clicked.\
            connect(self.save_to_xls)
        self.widget.pushButton_PkFtSectionImport.clicked.connect(
            self.import_section_from_param)
        # The line below exist in session_ctrl
        # self.widget.pushButton_PkFtSectionSavetoDPP.clicked.coonect

    def _toolbar_mode_text(self):
        toolbar = getattr(getattr(self.widget, "mpl", None), "ntb", None)
        if toolbar is None:
            return ""
        mode = getattr(toolbar, "mode", "")
        if not mode:
            mode = getattr(toolbar, "_active", "")
        return str(mode or "").strip().lower()

    def import_section_from_param(self):
        if not self.model.base_ptn_exist():
            QtWidgets.QMessageBox.warning(
                self.widget, "Warning", "Open a base spectrum first.")
            return
        idx, ok = QtWidgets.QInputDialog.getInt(
            self.widget,
            "Import Section",
            "Section index:",
            0,
            0,
            max(0, len(self.model.section_lst) + 1000),
            1,
        )
        if not ok:
            return
        try:
            section = load_section_from_param(
                self.model.get_base_ptn_filename(), int(idx))
        except Exception as inst:
            err = traceback.format_exc()
            print(err)
            QtWidgets.QMessageBox.warning(
                self.widget, "Warning", str(inst) + "\n\n" + err)
            return
        if section is None:
            QtWidgets.QMessageBox.warning(
                self.widget, "Warning",
                "No saved section was found for that index in the current session folder.")
            return
        self.model.section_lst.append(section)
        self.peakfit_table_ctrl.update_sections()

    def import_section_from_dpp(self):
        return self.import_section_from_param()

    def zoom_to_section(self):
        if not self.model.current_section_exist():
            return
        x_range = self.model.current_section.get_xrange()
        y_range = self.model.current_section.get_yrange(
            bgsub=self.widget.checkBox_BgSub.isChecked())
        margin = 0.1 * (y_range[1] - y_range[0])
        self.plot_ctrl.update(
            limits=(x_range[0], x_range[1],
                    y_range[0] - margin, y_range[1] + margin))

    def get_style_for_unsaved(self):
        return (
            "QTableWidget {"
            "background-color: rgb(255, 228, 242);"
            "alternate-background-color: rgb(255, 239, 247);"
            "color: rgb(17, 24, 39);"
            "gridline-color: rgb(156, 163, 175);"
            "}"
            "QTableWidget::item {"
            "background-color: rgb(255, 228, 242);"
            "color: rgb(17, 24, 39);"
            "}"
            "QTableWidget::item:selected {"
            "background-color: rgb(30, 64, 175);"
            "color: rgb(248, 250, 252);"
            "}"
            "QHeaderView::section {"
            "background-color: rgb(107, 114, 128);"
            "color: rgb(249, 250, 251);"
            "border: 1px solid rgb(75, 85, 99);"
            "padding: 2px 4px;"
            "}"
        )

    def get_style_for_saved(self):
        return (
            "QTableWidget {"
            "background-color: rgb(229, 231, 235);"
            "alternate-background-color: rgb(243, 244, 246);"
            "color: rgb(17, 24, 39);"
            "gridline-color: rgb(156, 163, 175);"
            "}"
            "QTableWidget::item {"
            "background-color: rgb(229, 231, 235);"
            "color: rgb(17, 24, 39);"
            "}"
            "QTableWidget::item:selected {"
            "background-color: rgb(30, 64, 175);"
            "color: rgb(248, 250, 252);"
            "}"
            "QHeaderView::section {"
            "background-color: rgb(107, 114, 128);"
            "color: rgb(249, 250, 251);"
            "border: 1px solid rgb(75, 85, 99);"
            "padding: 2px 4px;"
            "}"
        )

    def set_tableWidget_PkParams_saved(self):
        self.widget.tableWidget_PkParams.setStyleSheet(
            self.get_style_for_saved())

    def set_tableWidget_PkParams_unsaved(self):
        self.widget.tableWidget_PkParams.setStyleSheet(
            self.get_style_for_unsaved())

    def set_tableWidget_PkFtSections_saved(self):
        self.widget.tableWidget_PkFtSections.setStyleSheet(
            self.get_style_for_saved())

    def set_tableWidget_PkFtSections_unsaved(self):
        self.widget.tableWidget_PkFtSections.setStyleSheet(
            self.get_style_for_unsaved())

    def set_section_to_current(self):
        if self.widget.tableWidget_PkFtSections.selectionModel().\
                selectedRows().__len__() != 1:
            QtWidgets.QMessageBox.warning(
                self.widget, 'Warning',
                'Select a row to make current.')
            return
        if self.model.current_section_exist():
            if not self.model.current_section_saved():
                reply = QtWidgets.QMessageBox.question(
                    self.widget, 'Message',
                    'Are you OK to loose current section information?',
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.Yes)
                if reply == QtWidgets.QMessageBox.No:
                    return
                else:
                    pass
            else:
                pass
        else:
            pass
        idx = self.widget.tableWidget_PkFtSections.selectionModel().\
            selectedRows()[0].row()
        # Reload selected section from PARAM CSV on demand so graph updates
        # reflect persisted section data (not stale in-memory copies).
        if self.model.base_ptn_exist():
            param_dir = get_temp_dir(self.model.get_base_ptn_filename(), branch='-rampo')
            if not is_new_param_folder(param_dir):
                reply = QtWidgets.QMessageBox.question(
                    self.widget, 'Save First',
                    'No Rampo session folder exists for this spectrum.\n'
                    'Save the result first, then continue with Set to current?',
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.Yes)
                if reply == QtWidgets.QMessageBox.No:
                    return
                main_ctrl = getattr(self.widget, "_main_controller", None)
                session_ctrl = getattr(main_ctrl, "session_ctrl", None)
                if session_ctrl is None:
                    QtWidgets.QMessageBox.warning(
                        self.widget, "Warning",
                        "Cannot save the result because the session controller is unavailable.")
                    return
                try:
                    session_ctrl.save_dpp(quiet=True)
                except Exception as inst:
                    QtWidgets.QMessageBox.warning(
                        self.widget, "Warning",
                        "Saving the result failed:\n" + str(inst))
                    return
                if not is_new_param_folder(param_dir):
                    QtWidgets.QMessageBox.warning(
                        self.widget, "Warning",
                        "The Rampo session folder was not created. Save the result first.")
                    return
            try:
                section_disk = load_section_from_param(
                    self.model.get_base_ptn_filename(), idx)
            except Exception:
                section_disk = None
            if section_disk is not None:
                self.model.section_lst[idx] = section_disk
            else:
                QtWidgets.QMessageBox.warning(
                    self.widget, "Missing Section CSV",
                    "Saved section CSV for the selected row was not found.\n"
                    "Using in-memory section data instead."
                )
        self.model.set_this_section_current(idx)
        self.peakfit_table_ctrl.update_peak_parameters()
        self.peakfit_table_ctrl.update_sections()
        self.peakfit_table_ctrl.update_peak_constraints()
        """
        self._list_peaks()
        self._list_localbg()
        self._update_config
        """
        self.zoom_to_section()

    def clear_section_list(self):
        reply = QtWidgets.QMessageBox.question(
            self.widget, 'Message',
            'Any unsaved sections will be erased. Proceed?',
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.Yes)
        if reply == QtWidgets.QMessageBox.No:
            return
        self._clear_all_sections()

    def _clear_all_sections(self):
        '''clean both sections and currentSection'''
        self.model.clear_section_list()
        self.peakfit_table_ctrl.update_sections()
        self._clear_current_section()

    def remove_section(self):
        reply = QtWidgets.QMessageBox.question(
            self.widget, 'Message',
            'Are you sure you want to delete the selected sections?',
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.Yes)
        if reply == QtWidgets.QMessageBox.No:
            return
        idx_checked = []
        for item in \
                self.widget.tableWidget_PkFtSections.selectionModel().\
                selectedRows():
            idx_checked.append(item.row())
        # remove checked ones
        if idx_checked != []:
            idx_checked.reverse()
            for idx in idx_checked:
                self.model.section_lst.pop(idx)
                self.widget.tableWidget_PkFtSections.removeRow(idx)

    def clear_this_section(self):
        reply = QtWidgets.QMessageBox.question(
            self.widget, 'Message',
            'Any unsaved fitting result will be discarded.  Proceed?',
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.Yes)
        limits = self.widget.mpl.canvas.ax_pattern.axis()
        if reply == QtWidgets.QMessageBox.No:
            return
        else:
            self._clear_current_section()
            # self.plot_ctrl.update(limits, False)
            self.plot_ctrl.update()

    def _clear_current_section(self):
        '''erase only current section'''
        self.widget.tableWidget_PeakConstraints.clearContents()
        self.widget.tableWidget_PkParams.clearContents()
        self.model.initialize_current_section()

    def save_to_section(self):
        if not self.model.current_section_exist():
            return
        self.model.save_current_section()
        self.set_tableWidget_PkParams_saved()
        self.set_tableWidget_PkFtSections_unsaved()
        # self._list_sections()
        self.model.initialize_current_section()
        self.widget.tableWidget_PkParams.clearContents()
        self.widget.tableWidget_PeakConstraints.clearContents()
        self.peakfit_table_ctrl.update_sections()
        self.plot_ctrl.update()

    def set_fit_section(self):
        # if there is unsaved section, ask if it needs to be saved,
        # this can be checked by looking at timestamp
        if self.model.current_section_exist():
            if not self.model.current_section_saved():
                reply = QtWidgets.QMessageBox.question(
                    self.widget, 'Message',
                    'Do you want to save the unsaved section?',
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.Yes)
                if reply == QtWidgets.QMessageBox.Yes:
                    self.model.save_current_section()
        self.model.initialize_current_section()
        # Warn the users about what is going to happen
        reply = QtWidgets.QMessageBox.question(
            self.widget, 'Message',
            'I will set current plot range as current section. OK?',
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.Yes)
        if reply == QtWidgets.QMessageBox.No:
            return
        # get X range from the current view
        axisrange = self.widget.mpl.canvas.ax_pattern.axis()
        self.model.set_current_section([axisrange[0], axisrange[1]])
        # This button itself should activate the mouse for peak picking model
        self.widget.pushButton_AddRemoveFromMouse.setChecked(True)
        self.set_tableWidget_PkParams_unsaved()

    def set_mouse_for_peak_input(self):
        if self.widget.pushButton_AddRemoveFromMouse.isChecked():
            self.release_mouse_from_peak_input()
        else:
            self.widget.pushButton_AddRemoveFromMouse.setChecked(True)

    def release_mouse_from_peak_input(self):
        mode = self._toolbar_mode_text()
        if mode in ('pan/zoom', 'pan'):
            self.widget.mpl.ntb.pan()
        if mode in ('zoom rect', 'zoom'):
            self.widget.mpl.ntb.zoom()
        self.widget.pushButton_AddRemoveFromMouse.setChecked(False)
        return
    '''
    def pick_peak(self, mouse_button, xdata, ydata):
        """
        """
        if mouse_button == 'left':  # left click
            success = self.model.current_section.set_single_peak(
                float(xdata),
                self.widget.doubleSpinBox_InitialFWHM.value())
            if not success:
                QtWidgets.QMessageBox.warning(
                    self.widget, "Warning",
                    "You picked outside of the current section.")
                return
        elif mouse_button == 'right':  # right button for removal
            if not self.model.current_section.peaks_exist():
                return
            self.model.current_section.remove_single_peak_nearby(xdata)
        else:
            return
        self.set_tableWidget_PkParams_unsaved()
        self.peakfit_table_ctrl.update_peak_parameters()
        self.peakfit_table_ctrl.update_peak_constraints()
        self.plot_ctrl.update()
    '''

    def conduct_fitting(self):
        self.release_mouse_from_peak_input()
        if not self.model.current_section_exist():
            QtWidgets.QMessageBox.warning(
                self.widget, "Warning", "No section is defined")
            return
        if self.model.current_section.get_number_of_peaks_in_queue() == 0:
            QtWidgets.QMessageBox.warning(
                self.widget, "Warning", "No pick exists in the section.")
            return
        width = self.widget.doubleSpinBox_InitialFWHM.value()
        order = self.widget.spinBox_BGPolyOrder.value()
        maxwidth = self.widget.doubleSpinBox_MaxFWHM.value()
        centerrange = self.widget.doubleSpinBox_PeakCenterRange.value()
        self.model.current_section.prepare_for_fitting(order,
                                                       maxwidth, centerrange)
        success = self.model.current_section.conduct_fitting()
        if success:
            QtWidgets.QMessageBox.warning(self.widget, "Information",
                                          'Fitting finished.')
            self.plot_ctrl.update(limits=self._fit_result_limits())
            self.peakfit_table_ctrl.update_peak_parameters()
            self.peakfit_table_ctrl.update_peak_constraints()
            self.set_tableWidget_PkParams_unsaved()
        else:
            QtWidgets.QMessageBox.warning(self.widget, "Information",
                                          'Fitting failed.')

    def _fit_result_limits(self):
        if not self.model.current_section_exist():
            return None
        section = self.model.current_section
        bgsub = self.widget.checkBox_BgSub.isChecked()
        x_range = section.get_xrange()
        try:
            current_limits = self.widget.mpl.canvas.ax_pattern.axis()
            x_min = max(float(current_limits[0]), float(x_range[0]))
            x_max = min(float(current_limits[1]), float(x_range[1]))
            if x_max <= x_min:
                x_min, x_max = float(x_range[0]), float(x_range[1])
        except Exception:
            x_min, x_max = float(x_range[0]), float(x_range[1])

        y_min, y_max = section.get_yrange(bgsub=bgsub)
        residue = section.get_fit_residue(bgsub=bgsub)
        y_shift = y_min - (y_max - y_min) * 0.05
        residue_plot = np.asarray(residue, dtype=float) + y_shift
        if residue_plot.size > 0:
            y_min = min(float(y_min), float(np.min(residue_plot)))
            y_max = max(float(y_max), float(np.max(residue_plot)))
        if y_max <= y_min:
            span = max(abs(y_max), 1.0) * 1.0e-6
        else:
            span = y_max - y_min
        margin = span * 0.05
        return (x_min, x_max, y_min - margin, y_max + margin)

    def save_to_xls(self):
        temp_dir = get_temp_dir(self.model.get_base_ptn_filename())
        filen_xls = make_filename(self.model.get_base_ptn_filename(),
                      'peakfit.xls', temp_dir=temp_dir)
        reply = QtWidgets.QMessageBox.question(
            self.widget, 'Question',
            'Do you want to save in default filename, %s ?' % filen_xls,
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.Yes)
        if reply == QtWidgets.QMessageBox.No:
            filen_xls = QtWidgets.QFileDialog.getSaveFileName(
                self.widget, "Save an Excel File", filen_xls, "(*.xls)")
        else:
            if os.path.exists(filen_xls):
                reply = QtWidgets.QMessageBox.question(
                    self.widget, 'Question',
                    'The file already exist.  Overwrite?',
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No)
                if reply == QtWidgets.QMessageBox.No:
                    return
        self.model.save_peak_fit_results_to_xls(filen_xls)
