#Chu ID v1.5, Pecacheu 2026. GNU GPL v3

import base64, os, struct, threading, time
from datetime import datetime, timezone

#64-bit UUID Format
#<U8 Uptime><U8 Magic><U8 CryptoRand><U8 Counter><U32 Date>

ID_File = os.path.dirname(__file__)+'/uuid'
Fmt = "<BBBBL"

_cnt = _lt = _ld = _clt = None
_lck = threading.Lock()
_ut = False

def _loadId():
	global _cnt
	try:
		with open(ID_File, encoding='ascii') as f:
			_cnt = int(f.read())
	except:
		_cnt = -1
	if _cnt < 0 or _cnt > 255:
		print("[ChuID] IDCount error, resetting")
		_cnt = 0

def _saveId():
	global _ut
	time.sleep(UUID.ID_Delay)
	with _lck:
		with open(ID_File, mode='w', encoding='ascii') as f:
			f.write(str(_cnt))
	_ut = False

class UUID:
	LEN = 11
	BYTES = 8
	ID_Delay = 10

	def __init__(self, id: bytes|str):
		if isinstance(id, bytes) and len(id) == UUID.BYTES:
			pass
		elif isinstance(id, str) and len(id) == UUID.LEN:
			id = base64.b64decode(id+'=', altchars=b'-_', validate=True)
		else:
			raise ValueError(f"Unknown UUID format {id}")
		self.id = id

	def __str__(self):
		return base64.b64encode(self.id, altchars=b'-_').decode('ascii').rstrip('=')

	def hex(self):
		return self.id[::-1].hex()

	def magic(self):
		return self.id[1]

	def date(self):
		d = self.unpacked()[4]*10
		return datetime.fromtimestamp(d, timezone.utc)

	def unpacked(self):
		return struct.unpack(Fmt, self.id)

	@staticmethod
	def genUUID(date: datetime|None = None, magic: int|None = None):
		global _cnt, _clt, _lt, _ld, _ut
		if date is None: date = datetime.now(timezone.utc)
		rb = os.urandom(2 if magic is None else 1)

		with _lck:
			if _cnt is None: _loadId()
			ts = int(time.monotonic()*10)&255
			ds = int(date.timestamp()//10)&4294967295
			cnt = _cnt

			#Prevent collision
			if _lt == ts and _ld == ds:
				if _clt == cnt:
					time.sleep(.05)
					_lt = ts = (ts+1)&255
			else:
				_lt = ts
				_ld = ds
				_clt = cnt

			_cnt += 1
			if _cnt > 255: _cnt = 0
			if not _ut:
				_ut = True
				threading.Thread(target=_saveId).start()

		return UUID(struct.pack(Fmt,
			ts,
			rb[1] if magic is None else magic&255,
			rb[0],
			cnt,
			ds))