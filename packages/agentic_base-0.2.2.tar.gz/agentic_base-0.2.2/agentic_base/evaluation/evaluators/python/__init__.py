import logging
from abc import ABC, abstractmethod
from typing import Any, Coroutine, Dict, Generic, Iterator, List, Tuple

import numpy as np
from agentic_base.evaluation import VectorStore
from agentic_base.evaluation.evaluators import Evaluator
from agentic_base.mixins import FromConfigMixin
from agentic_base.types import TCPythonEvaluator, TCScore
from agentic_base.utils import load_class
from pydantic import BaseModel
from tqdm.asyncio import tqdm_asyncio

_logger = logging.getLogger(__name__)


class Score(FromConfigMixin[TCScore], ABC, Generic[TCScore]):

    class ScoreResult(BaseModel):
        name: str
        value: float

    def __init__(self, config: TCScore) -> None:
        self.config = config
        _logger.info(f"Initialized Score | class={self.__class__.__name__} | config={config}")

    @abstractmethod
    def __call__(self, hits: List[bool]) -> ScoreResult:
        raise NotImplementedError()


class PythonEvaluator(Evaluator[TCPythonEvaluator], ABC, Generic[TCPythonEvaluator]):

    NB_LOGS_PER_QUERIES = 100
    BATCH_SIZE = 96

    def __init__(self, config: TCPythonEvaluator) -> None:
        super().__init__(config)
        self.scores: List[Score[Any]] = [load_class(s.module_path)(s) for s in self.config.scores]
        _logger.info(
            f"Evaluator ready | dataset_size={len(self.dataset)} | " f"scores={[type(s).__name__ for s in self.scores]}"
        )

    def batch_iter(self) -> Iterator[List[Dict[str, Any]]]:
        batch: List[Dict[str, Any]] = []
        for row in self.dataset.iter_rows(named=True):
            batch.append(row)
            if len(batch) == self.BATCH_SIZE:
                yield batch
                batch = []
        if batch:
            yield batch

    def _get_max_k(self) -> int:
        return max(getattr(score.config, "k", 0) for score in self.scores)

    def _build_retrieval_tasks(
        self, max_k: int
    ) -> Tuple[List[List[Dict[str, Any]]], List[Coroutine[Any, Any, List[VectorStore.QueryResponse]]]]:
        tasks: List[Coroutine[Any, Any, List[VectorStore.QueryResponse]]] = []
        batches: List[List[Dict[str, Any]]] = []

        for batch in self.batch_iter():
            queries = [sample["metadata"]["query"] for sample in batch]
            task = self.retriever.retrieve_batch(queries, limit=self.config.limit, final_limit=max_k)
            tasks.append(task)
            batches.append(batch)

        return batches, tasks

    async def _collect_responses(self, tasks: List[Coroutine[Any, Any, List[VectorStore.QueryResponse]]]) -> List[Any]:
        return await tqdm_asyncio.gather(
            *tasks,
            desc="Evaluating batches",
        )

    def _score_batches(
        self,
        batches: List[List[Dict[str, Any]]],
        responses: List[Any],
    ) -> List[List[float]]:
        scores_all: List[List[float]] = []
        processed = 0
        for batch, batch_responses in zip(batches, responses):
            for sample, response in zip(batch, batch_responses):
                hits = [p.document.page_content == sample["page_content"] for p in response.points]
                scores_all.append([score(hits).value for score in self.scores])
                processed += 1
                if processed % self.NB_LOGS_PER_QUERIES == 0:
                    _logger.info(f"Progress {processed}/{len(self.dataset)}")
        return scores_all

    def _aggregate_scores(
        self,
        scores_all: List[List[float]],
    ) -> Dict[str, float]:
        if not scores_all:
            return {}
        scores_array = np.array(scores_all, dtype=float)
        scores_mean = scores_array.mean(axis=0)
        results: Dict[str, float] = {}
        for idx, score in enumerate(self.scores):
            results[score.__class__.__name__] = float(scores_mean[idx])

        return results

    async def eval(self) -> Dict[str, float]:
        max_k = self._get_max_k()
        _logger.info(f"Starting Dense evaluation | max_k={max_k}")
        batches, tasks = self._build_retrieval_tasks(max_k)
        responses = await self._collect_responses(tasks)
        scores_all = self._score_batches(batches, responses)
        return self._aggregate_scores(scores_all)
