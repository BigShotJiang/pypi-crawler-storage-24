import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Any, Generic, List, Optional

from agentic_base.dataset import TextDataset
from agentic_base.evaluation import Reranker, VectorStore
from agentic_base.evaluation.settings import BM25RetrieverSettings
from agentic_base.mixins import FromConfigMixin
from agentic_base.types import TCRetriever
from agentic_base.utils import load_class
from langchain_core.documents import (
    Document,  # or: from langchain.schema import Document
)
from rank_bm25 import BM25Okapi  # type: ignore[import-untyped]

_logger = logging.getLogger(__name__)


class Retriever(FromConfigMixin[TCRetriever], ABC, Generic[TCRetriever]):

    def __init__(self, config: TCRetriever) -> None:
        self.config = config
        self.reranker: Optional[Reranker[Any]] = (
            load_class(self.config.reranker.module_path).from_config(self.config.reranker)
            if self.config.reranker is not None
            else None
        )
        _logger.info(f"Initializing Retriever | class={self.__class__.__name__}")

    @abstractmethod
    async def _retrieve(
        self,
        query: str,
        limit: int,
    ) -> VectorStore.QueryResponse:
        pass

    async def retrieve(
        self,
        query: str,
        retrieve_limit: int,
        final_limit: Optional[int] = None,
    ) -> VectorStore.QueryResponse:
        response = await self._retrieve(query, limit=retrieve_limit)
        if self.reranker:
            if final_limit is None:
                raise ValueError("final_limit must be provided when a reranker is configured.")
            response = await self.reranker.rerank(query, response, final_limit)
        else:
            if final_limit is not None:
                raise ValueError("final_limit cannot be used without a reranker.")
        return response

    async def retrieve_batch(
        self, queries: List[str], limit: int, final_limit: Optional[int] = None
    ) -> List[VectorStore.QueryResponse]:
        return [await self.retrieve(query, limit, final_limit=final_limit) for query in queries]

    async def aclose(self) -> None:
        return None


class BM25Retriever(Retriever[BM25RetrieverSettings]):

    def __init__(self, config: BM25RetrieverSettings) -> None:
        super().__init__(config)
        # ---- load dataset ----
        dataset: TextDataset[Any] = (
            load_class(self.config.dataset_connector.module_path).from_config(config.dataset_connector).load_text()
        )
        self.documents: List[Document] = [
            Document(
                page_content=row["page_content"],
                metadata=row.get("metadata"),
            )
            for row in dataset.iter_rows(named=True)
        ]
        # ---- tokenize corpus ----
        self.corpus_tokens = [doc.page_content.lower().split() for doc in self.documents]
        # ---- build BM25 index ----
        self.bm25 = BM25Okapi(self.corpus_tokens)
        _logger.info(f"BM25Retriever initialized | documents={len(self.documents)}")

    async def _retrieve(
        self,
        query: str,
        limit: int,
    ) -> VectorStore.QueryResponse:
        return await asyncio.to_thread(self._retrieve_sync, query, limit)

    def _retrieve_sync(self, query: str, limit: int) -> VectorStore.QueryResponse:
        query_tokens = query.lower().split()
        scores = self.bm25.get_scores(query_tokens)
        top_indices = sorted(
            range(len(scores)),
            key=lambda i: scores[i],
            reverse=True,
        )[:limit]
        return self._build_response(scores, top_indices)

    def _build_response(self, scores: List[float], indices: List[int]) -> VectorStore.QueryResponse:
        return VectorStore.QueryResponse(
            points=[
                VectorStore.ScoredPoint(
                    score=float(scores[i]),
                    document=self.documents[i],
                )
                for i in indices
            ]
        )
