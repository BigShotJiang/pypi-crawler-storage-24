"""MCP resource handler.

Serves the RenderDeck reference document via the ``renderdeck://reference``
MCP resource.  By default the bundled ``resources/renderdeck_reference.md``
is used; set ``RENDERDECK_REFERENCE_PATH`` to override with a custom file.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from renderdeck_mcp.server import mcp

logger = logging.getLogger(__name__)

# Bundled reference doc: <project_root>/resources/renderdeck_reference.md
_BUNDLED_PATH = (
    Path(__file__).resolve().parent.parent.parent.parent / "resources" / "renderdeck_reference.md"
)


def _load_reference() -> str:
    """Load the reference document, respecting custom path override."""
    custom = os.environ.get("RENDERDECK_REFERENCE_PATH")
    if custom:
        custom_path = Path(custom)
        if custom_path.is_file():
            return custom_path.read_text(encoding="utf-8")
        logger.warning(
            "RENDERDECK_REFERENCE_PATH=%s not found, falling back to bundled",
            custom,
        )

    if _BUNDLED_PATH.is_file():
        return _BUNDLED_PATH.read_text(encoding="utf-8")

    msg = f"Bundled reference document not found at {_BUNDLED_PATH}"
    raise FileNotFoundError(msg)


@mcp.resource(
    "renderdeck://reference",
    name="renderdeck_reference",
    description="Complete reference document for writing RenderDeck slide prompt files",
    mime_type="text/markdown",
)
def get_reference() -> str:
    """Return the full RenderDeck reference document."""
    return _load_reference()
