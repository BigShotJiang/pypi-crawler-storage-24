"""PowerPoint deck builder.

Assembles generated slide images into a .pptx file using python-pptx.
Each slide receives a full-slide PNG background image and speaker notes on the
notes page. Slides without images get speaker notes only. Large PNGs (>5 MB)
are compressed to JPEG before embedding via Pillow.
"""

from __future__ import annotations

import io
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from PIL import Image
from pptx import Presentation
from pptx.util import Emu

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

IMAGE_COMPRESS_THRESHOLD: int = 5 * 1024 * 1024  # 5 MB

# Matches **bold**, *italic*, and ***bold-italic*** inline markdown.
# Order matters: bold-italic (***) must be matched before bold (**) and italic (*).
_MD_INLINE_RE = re.compile(
    r"(\*\*\*(.+?)\*\*\*"  # ***bold-italic***
    r"|\*\*(.+?)\*\*"  # **bold**
    r"|\*(.+?)\*)"  # *italic*
)

PAGE_SIZE_EMU: dict[str, dict[str, int]] = {
    "WIDE": {"width": 9144000, "height": 5143500},  # 16:9
    "STANDARD": {"width": 9144000, "height": 6858000},  # 4:3
}

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class SlideData:
    """Data for a single slide to be assembled into the .pptx."""

    slide_number: int
    title: str
    speaker_notes: str
    image_bytes: bytes | None


@dataclass
class DeckData:
    """Complete parsed deck ready for .pptx assembly."""

    title: str
    slides: list[SlideData]


# ---------------------------------------------------------------------------
# Image compression
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _TextSpan:
    """A span of text with optional bold/italic formatting."""

    text: str
    bold: bool = False
    italic: bool = False


def _parse_markdown_line(line: str) -> list[_TextSpan]:
    """Parse a single line of markdown into formatted text spans.

    Recognises ``***bold-italic***``, ``**bold**``, and ``*italic*``.
    Everything else is returned as plain text spans.
    """
    spans: list[_TextSpan] = []
    pos = 0
    for m in _MD_INLINE_RE.finditer(line):
        # Plain text before this match
        if m.start() > pos:
            spans.append(_TextSpan(text=line[pos : m.start()]))
        if m.group(2) is not None:
            # ***bold-italic***
            spans.append(_TextSpan(text=m.group(2), bold=True, italic=True))
        elif m.group(3) is not None:
            # **bold**
            spans.append(_TextSpan(text=m.group(3), bold=True))
        elif m.group(4) is not None:
            # *italic*
            spans.append(_TextSpan(text=m.group(4), italic=True))
        pos = m.end()
    # Trailing plain text
    if pos < len(line):
        spans.append(_TextSpan(text=line[pos:]))
    if not spans:
        spans.append(_TextSpan(text=""))
    return spans


def _set_rich_notes(notes_text_frame: object, markdown_text: str) -> None:
    """Populate a notes text frame with markdown-formatted rich text.

    Splits the markdown into paragraphs (on newlines) and within each
    paragraph creates runs with bold/italic applied via python-pptx.
    """
    from pptx.util import Pt

    tf = notes_text_frame  # type: ignore[assignment]

    lines = markdown_text.split("\n")
    for line_idx, line in enumerate(lines):
        if line_idx == 0:
            para = tf.paragraphs[0]
            para.clear()
        else:
            para = tf.add_paragraph()

        spans = _parse_markdown_line(line)
        for span_idx, span in enumerate(spans):
            if span_idx == 0:
                run = para.add_run()
            else:
                run = para.add_run()
            run.text = span.text
            run.font.size = Pt(10)
            run.font.bold = span.bold
            run.font.italic = span.italic


def compress_png(
    png_bytes: bytes,
    max_bytes: int = IMAGE_COMPRESS_THRESHOLD,
) -> bytes:
    """Return png_bytes unchanged if under max_bytes; otherwise JPEG-compress it.

    Args:
        png_bytes: Raw image bytes (PNG expected, but any Pillow-readable format works).
        max_bytes: Byte threshold above which JPEG compression is applied.

    Returns:
        Original bytes if under threshold, otherwise JPEG bytes at quality=85.
    """
    if len(png_bytes) <= max_bytes:
        return png_bytes
    logger.debug("compress_png: %d bytes exceeds threshold, converting to JPEG", len(png_bytes))
    img = Image.open(io.BytesIO(png_bytes))
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=85)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Main builder
# ---------------------------------------------------------------------------


def build_pptx(
    deck: DeckData,
    output_path: str | Path,
    aspect_ratio: Literal["WIDE", "STANDARD"] = "WIDE",
) -> Path:
    """Assemble a .pptx presentation from DeckData and write it to output_path.

    Args:
        deck: The parsed deck data containing slides with images and notes.
        output_path: Destination path for the .pptx file. Parent directories
            are created automatically if they do not exist.
        aspect_ratio: Slide dimensions. "WIDE" = 16:9, "STANDARD" = 4:3.

    Returns:
        Resolved Path to the written .pptx file.

    Raises:
        KeyError: If aspect_ratio is not "WIDE" or "STANDARD".
        OSError: If the file cannot be written.
    """
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    dims = PAGE_SIZE_EMU[aspect_ratio]
    prs = Presentation()
    prs.slide_width = Emu(dims["width"])
    prs.slide_height = Emu(dims["height"])

    blank_layout = prs.slide_layouts[6]  # index 6 = blank layout

    logger.info(
        "Building .pptx: %d slides, aspect_ratio=%s",
        len(deck.slides),
        aspect_ratio,
    )

    for slide_data in deck.slides:
        slide = prs.slides.add_slide(blank_layout)

        if slide_data.image_bytes is not None:
            compressed = compress_png(slide_data.image_bytes)
            logger.debug(
                "Slide %d: adding picture (%d bytes)",
                slide_data.slide_number,
                len(compressed),
            )
            slide.shapes.add_picture(
                io.BytesIO(compressed),
                0,
                0,
                prs.slide_width,
                prs.slide_height,
            )
        else:
            logger.debug("Slide %d: no image, notes-only slide", slide_data.slide_number)

        notes_slide = slide.notes_slide
        _set_rich_notes(notes_slide.notes_text_frame, slide_data.speaker_notes)

    prs.save(str(out))
    logger.info("Saved .pptx to %s", out)
    return out
