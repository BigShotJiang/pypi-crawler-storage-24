# Copyright (c) 2004-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# This file randomly randomly passes/fails in linting on line with 'ec2_client._endpoint.host'.
# - Sometimes mypy requires 'type: ignore ...' in there,
# - sometimes mypy requires this 'type: ignore ...' to be removed,
# I can't make it run reliably, so I'm excluding the whole file to make CI stable.
# mypy: ignore-errors

from __future__ import annotations

import logging
from functools import cache
from typing import Any

from boto3.session import Session
from botocore.exceptions import ClientError, EndpointConnectionError, ProfileNotFound, TokenRetrievalError
from clusterondemand.exceptions import CODException
from clusterondemandconfig import config

log = logging.getLogger("cluster-on-demand")


@cache
def _establish_connection_to_aws() -> Session:
    def _session_with_profile(profile_name: str) -> Session:
        try:
            return Session(
                profile_name=profile_name,
                region_name=config["aws_region"],
            )
        except ProfileNotFound as e:
            msg = f"{e}. Please check the profile name and try again."
            raise CODException(msg) from e

    log.debug(f"Establish session with AWS region '{config['aws_region']}'")

    if not (config["aws_access_key_id"] and config["aws_secret_key"]) and not config["aws_profile"]:
        log.debug("AWS access keys not found, trying to use AWS CLI profile 'default'")
        # When no access keys or profile are provided, let's try using the default AWS cli profile.
        return _session_with_profile("default")

    if config["aws_profile"]:
        log.debug(f"Using AWS profile name '{config['aws_profile']}', ignoring other credentials")

        return _session_with_profile(config["aws_profile"])

    return Session(
        config["aws_access_key_id"],
        config["aws_secret_key"],
        config["aws_session_token"],
        region_name=config["aws_region"],
    )


@cache
def create_aws_service_resource(service_name: str, api_version: str = "2016-11-15", **kwargs: Any) -> Any:
    """Create an AWS service resource.

    Note: Returns Any due to boto3's dynamic service type system with a lot of overloads.
    Callers should annotate the return type at the call site when needed.
    """
    # TODO: api_version is set to 2016-11-15, for backwards compatibility.
    # Need to investigate if we need to hardcode it, or if we can use the latest one.
    session = _establish_connection_to_aws()
    _validate_credentials_and_region(session=session)

    return session.resource(  # type: ignore[call-overload]
        **kwargs, service_name=service_name, api_version=api_version
    )


@cache
def create_aws_service_client(service_name: str, **kwargs: Any) -> Any:
    """Create an AWS service client.

    Note: Returns Any due to boto3's dynamic service type system with a lot of overloads.
    Callers should annotate the return type at the call site when needed.
    """
    session = _establish_connection_to_aws()
    _validate_credentials_and_region(session=session)

    return session.client(**kwargs, service_name=service_name)  # type: ignore[call-overload]


def _validate_credentials_and_region(session: Session) -> None:
    # We make a lightweight API call to validate the credentials.
    # Since region is mandatory for various service clients, we validate it in the same functions
    ec2_client = session.client(
        service_name="ec2",
    )
    try:
        ec2_client.describe_regions()
    except ClientError as e:
        if e.response["Error"]["Code"] == "AuthFailure":
            raise CODException("The provided AWS credentials are invalid.")
        msg = f"Unable to connect to AWS, check your credentials or region configuration. {e}"
        raise CODException(msg)
    except EndpointConnectionError:
        msg = (
            f"Could not connect to the endpoint {ec2_client._endpoint.host}. "  # noqa: SLF001
            "Please check the configured AWS region name"
        )
        raise CODException(msg)
    except TokenRetrievalError as e:
        msg = (
            f"{e}. If authenticating via an SSO-enabled AWS profile, please log in with "
            "`aws sso login --profile <profile_name>` and retry."
        )
        raise CODException(msg) from e
