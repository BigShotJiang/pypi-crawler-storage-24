"""
Shared custom code execution tool factory.

Creates agent-specific execute_custom_code tools with unified signature
and optional post-processing hooks. Follows workspace_tool.py pattern.

Architecture:
    Factory Pattern: create_execute_custom_code_tool() returns @tool function
    Post-Processor: Optional callback for agent-specific behavior
    Single Source: Eliminates duplication across data_expert and metadata_assistant

Usage:
    # data_expert (no post-processing)
    tool = create_execute_custom_code_tool(data_manager, service, "data_expert")

    # metadata_assistant (with metadata_store persistence)
    tool = create_execute_custom_code_tool(
        data_manager, service, "metadata_assistant",
        post_processor=metadata_store_post_processor
    )

See Also:
    - workspace_tool.py: Established factory pattern for shared tools
    - CustomCodeExecutionService: Underlying execution service
    - CLAUDE.md section 4.5: Patterns & Abstractions
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable, Dict, Optional

from langchain_core.tools import tool

from lobster.utils.logger import get_logger

# TYPE_CHECKING imports - only evaluated by type checkers, not at runtime
# This prevents circular imports when component_registry loads entry points
if TYPE_CHECKING:
    from lobster.core.data_manager_v2 import DataManagerV2
    from lobster.services.execution.custom_code_execution_service import (
        CustomCodeExecutionService,
    )

logger = get_logger(__name__)


# =============================================================================
# Type Aliases
# =============================================================================

# Post-processor callback signature
# Args: (result, stats, data_manager, workspace_key, modality_name)
# Returns: Optional message to append to response
# Note: Using string annotation to avoid runtime import of DataManagerV2
PostProcessor = Callable[
    [Any, Dict[str, Any], "DataManagerV2", Optional[str], Optional[str]],
    Optional[str],
]


# =============================================================================
# Deferred Help Text (returned on empty code or errors, NOT in tool schema)
# =============================================================================

_EXECUTE_CUSTOM_CODE_HELP = """EXECUTE_CUSTOM_CODE — Detailed Usage Guide

PARAMETER SELECTION (choose ONE):
- modality_name: Load AnnData as `adata` variable
- workspace_key: Load specific JSON/CSV file (token-efficient)
- Neither: Auto-load all workspace files

NAMESPACE AVAILABLE:
- WORKSPACE: Path to workspace directory (pathlib.Path)
- OUTPUT_DIR: Recommended export path (workspace/exports/)
- adata: Loaded modality (if modality_name provided)
- Auto-loaded CSV/JSON files as variables (if load_workspace_files=True)
- publication_queue, download_queue (if they exist in workspace)

RETURNING RESULTS:
Assign to `result` variable: `result = my_computation()`

LARGE OUTPUT HANDLING:
stdout capped at 500 chars. result capped at 8,000 chars.
Save large data to file instead:
    import json
    output_path = OUTPUT_DIR / 'my_results.json'
    with open(output_path, 'w') as f:
        json.dump(large_data, f)
    result = {"saved_to": str(output_path), "count": len(large_data), "preview": large_data[:5]}

DEFENSIVE CODING:
- Use data.get('key', default) instead of data['key']
- Check `if value is not None` before .lower()/.upper()
- Convert numpy types: int(val), float(val), list(arr)
- Check isinstance(data, dict) before dict operations

PERSIST PARAMETER:
- persist=False (default): Ephemeral — logged but NOT in /notebook export
- persist=True: Reproducible — included in exported Jupyter notebook

STATE PERSISTENCE:
Modified adata is saved as NEW modality with _custom suffix.
Example: modality_name="geo_gse12345_clustered" → "geo_gse12345_clustered_custom"

METADATA PERSISTENCE:
Return dict with samples and output_key to persist:
  result = {'samples': [...], 'output_key': 'filtered_samples'}
"""


# =============================================================================
# Factory Function
# =============================================================================


def create_execute_custom_code_tool(
    data_manager: DataManagerV2,
    custom_code_service: CustomCodeExecutionService,
    agent_name: str = "generic",
    post_processor: Optional[PostProcessor] = None,
):
    """
    Factory function to create execute_custom_code tool with configurable behavior.

    Follows workspace_tool.py pattern for shared tools across agents.
    The underlying CustomCodeExecutionService already supports both modality_name
    (for AnnData) and workspace_keys (for metadata), so NO service changes needed.

    Args:
        data_manager: DataManagerV2 instance for provenance logging
        custom_code_service: Service instance for code execution
        agent_name: Agent identifier for logging (default: "generic")
        post_processor: Optional callback for agent-specific post-processing.
                       Signature: (result, stats, data_manager, workspace_key, modality_name) -> Optional[str]
                       Return value (if any) is appended to response.

    Returns:
        LangChain tool for executing custom Python code

    Example:
        # data_expert (no post-processing)
        execute_custom_code = create_execute_custom_code_tool(
            data_manager=data_manager,
            custom_code_service=custom_code_service,
            agent_name="data_expert",
        )

        # metadata_assistant (with metadata_store persistence)
        execute_custom_code = create_execute_custom_code_tool(
            data_manager=data_manager,
            custom_code_service=custom_code_service,
            agent_name="metadata_assistant",
            post_processor=metadata_store_post_processor,
        )
    """

    @tool
    def execute_custom_code(
        python_code: str,
        modality_name: Optional[str] = None,
        workspace_key: Optional[str] = None,
        load_workspace_files: bool = True,
        persist: bool = False,
        description: str = "Custom code execution",
    ) -> str:
        """Execute custom Python code with workspace context.

        Use ONLY when existing specialized tools don't cover your need.

        Choose ONE data source: modality_name (AnnData as `adata`), workspace_key
        (JSON/CSV file), or neither (all workspace files auto-loaded).

        Namespace: WORKSPACE, OUTPUT_DIR, adata (if modality_name), auto-loaded files.
        Assign results to `result` variable. Large output (>8K chars) is truncated
        — save to OUTPUT_DIR instead.

        Args:
            python_code: Python code to execute (multi-line supported)
            modality_name: AnnData modality to load as 'adata'
            workspace_key: Specific workspace JSON/CSV file to load
            load_workspace_files: Auto-inject workspace files (default: True)
            persist: False=ephemeral (default), True=included in /notebook export
            description: Human-readable description of the operation
        """
        # Lazy import to prevent circular imports when component_registry loads entry points
        # These exceptions are needed at runtime for except clauses, but importing the
        # service module at module level triggers DataManagerV2 → component_registry → agents
        from lobster.services.execution.custom_code_execution_service import (
            CodeExecutionError,
            CodeValidationError,
        )

        # Validation: mutual exclusivity
        if modality_name and workspace_key:
            return (
                "Error: Cannot specify both `modality_name` and `workspace_key`. "
                "Choose ONE based on your data type:\n"
                "- `modality_name`: For AnnData/H5AD operations\n"
                "- `workspace_key`: For JSON/CSV metadata operations"
            )

        # Empty code guard
        if not python_code or not python_code.strip():
            return _EXECUTE_CUSTOM_CODE_HELP

        try:
            # Convert workspace_key to list (service expects Optional[List[str]])
            workspace_keys_list = [workspace_key] if workspace_key else None

            # Execute via service (single source of truth)
            result, stats, ir = custom_code_service.execute(
                code=python_code,
                modality_name=modality_name,
                load_workspace_files=load_workspace_files,
                workspace_keys=workspace_keys_list,
                persist=persist,
                description=description,
            )

            # Log provenance
            data_manager.log_tool_usage(
                tool_name="execute_custom_code",
                parameters={
                    "description": description,
                    "modality_name": modality_name,
                    "workspace_key": workspace_key,
                    "persist": persist,
                    "agent": agent_name,
                    "duration_seconds": stats.get("duration_seconds", 0),
                    "success": stats.get("success", False),
                },
                description=f"{description} ({'success' if stats['success'] else 'failed'})",
                ir=ir,
            )

            # Agent-specific post-processing (only on success)
            post_processor_msg = None
            if post_processor and stats.get("success", False):
                try:
                    post_processor_msg = post_processor(
                        result, stats, data_manager, workspace_key, modality_name
                    )
                except Exception as e:
                    logger.warning(f"Post-processor error (non-fatal): {e}")
                    post_processor_msg = f"Warning: Post-processing failed: {e}"

            # Format response
            return _format_response(result, stats, persist, post_processor_msg)

        except CodeValidationError as e:
            logger.error(f"Code validation failed: {e}")
            import json

            return json.dumps(
                {
                    "success": False,
                    "error": str(e),
                    "error_type": "validation_error",
                    "stderr": str(e),
                },
                indent=2,
            )
        except CodeExecutionError as e:
            logger.error(f"Code execution failed: {e}")
            import json

            # Include defensive coding hints on runtime errors (just-in-time guidance)
            error_str = str(e)
            hints = ""
            if "KeyError" in error_str or "'NoneType'" in error_str:
                hints = (
                    "\n\nHINT — Defensive coding required:\n"
                    "- Use data.get('key', default) instead of data['key']\n"
                    "- Check `if value is not None` before .lower()/.upper()\n"
                    "- Check isinstance(data, dict) before dict operations"
                )
            elif (
                "numpy" in error_str.lower()
                or "int64" in error_str
                or "float64" in error_str
            ):
                hints = (
                    "\n\nHINT — Convert numpy types:\n"
                    "- int(val), float(val), list(arr), str(val)"
                )
            elif "truncat" in error_str.lower() or len(error_str) > 2000:
                hints = (
                    "\n\nHINT — Large output handling:\n"
                    "- Save to OUTPUT_DIR / 'results.json' instead of returning large data\n"
                    "- result = {'saved_to': str(path), 'count': N, 'preview': data[:5]}"
                )

            return json.dumps(
                {
                    "success": False,
                    "error": error_str + hints,
                    "error_type": "execution_error",
                    "stderr": error_str,
                },
                indent=2,
            )
        except Exception as e:
            logger.error(f"Unexpected error in execute_custom_code: {e}", exc_info=True)
            import json

            return json.dumps(
                {
                    "success": False,
                    "error": str(e),
                    "error_type": "unexpected_error",
                    "stderr": str(e),
                },
                indent=2,
            )

    return execute_custom_code


# =============================================================================
# Response Formatting
# =============================================================================

# Maximum characters for result field to prevent LLM context overflow
# Large results (e.g., DataFrames, sample lists) can exceed 100K+ chars
MAX_RESULT_LENGTH = 8000


def _truncate_result(result: Any, max_length: int = MAX_RESULT_LENGTH) -> tuple:
    """
    Truncate result to prevent LLM context overflow.

    Handles various result types (dict, list, str, primitives) by converting
    to JSON string, checking length, and truncating if needed.

    Args:
        result: Execution result (any JSON-serializable type)
        max_length: Maximum character length for serialized result

    Returns:
        Tuple of (truncated_result, was_truncated, original_length)
        - truncated_result: Original or truncated value
        - was_truncated: Boolean indicating if truncation occurred
        - original_length: Character count of original serialized result
    """
    import json

    if result is None:
        return None, False, 0

    # Serialize to check length
    try:
        serialized = json.dumps(result, default=str)
    except (TypeError, ValueError):
        # Fallback for non-serializable objects
        serialized = str(result)

    original_length = len(serialized)

    if original_length <= max_length:
        return result, False, original_length

    # Truncation needed - strategy depends on type
    if isinstance(result, str):
        # Simple string truncation
        truncated = result[: max_length - 100]  # Leave room for suffix
        return (
            f"{truncated}\n\n... [TRUNCATED: {original_length:,} chars total, "
            f"showing first {len(truncated):,}. "
            f"Save large data to OUTPUT_DIR instead of returning it. Do NOT re-execute.]",
            True,
            original_length,
        )

    elif isinstance(result, list):
        # For lists (e.g., samples), truncate items and show count
        truncated_list = []
        current_length = 2  # Account for []
        for item in result:
            item_str = json.dumps(item, default=str)
            if current_length + len(item_str) + 2 > max_length - 200:
                break
            truncated_list.append(item)
            current_length += len(item_str) + 2  # +2 for comma and space

        return (
            {
                "_truncated": True,
                "_total_items": len(result),
                "_shown_items": len(truncated_list),
                "_original_chars": original_length,
                "_action": "Result too large for context. Save to OUTPUT_DIR / 'results.json' and assign a summary dict to result instead. Do NOT re-execute.",
                "items": truncated_list,
            },
            True,
            original_length,
        )

    elif isinstance(result, dict):
        # For dicts, try to preserve structure but truncate large values
        truncated_dict = {
            "_truncated": True,
            "_original_chars": original_length,
            "_action": "Dict too large for context. Save full dict to OUTPUT_DIR / 'results.json' and return summary. Do NOT re-execute.",
        }
        current_length = 50  # Account for metadata

        for key, value in result.items():
            value_str = json.dumps(value, default=str)
            if current_length + len(key) + len(value_str) + 10 > max_length - 200:
                truncated_dict["_remaining_keys"] = list(
                    set(result.keys()) - set(truncated_dict.keys())
                )
                break

            # Recursively truncate large nested values
            if len(value_str) > max_length // 4:
                if isinstance(value, list) and len(value) > 5:
                    truncated_dict[key] = {
                        "_list_preview": value[:5],
                        "_total_items": len(value),
                    }
                elif isinstance(value, str) and len(value) > 500:
                    truncated_dict[key] = value[:500] + f"... [{len(value)} chars]"
                else:
                    truncated_dict[key] = value
            else:
                truncated_dict[key] = value

            current_length += len(key) + len(
                json.dumps(truncated_dict[key], default=str)
            )

        return truncated_dict, True, original_length

    else:
        # Primitives or other types - convert to string and truncate
        str_result = str(result)
        if len(str_result) > max_length:
            return (
                f"{str_result[: max_length - 100]}\n\n... [TRUNCATED: {original_length:,} chars. "
                f"Save large data to OUTPUT_DIR instead of returning it. Do NOT re-execute.]",
                True,
                original_length,
            )
        return result, False, original_length


def _format_response(
    result: Any,
    stats: Dict[str, Any],
    persist: bool,
    post_processor_msg: Optional[str] = None,
) -> str:
    """
    Format unified JSON response for all agents (DeepAgents pattern).

    Returns structured JSON instead of markdown for programmatic parsing by LLMs.
    Enables retry logic, error pattern matching, and conditional branching.

    Includes automatic result truncation to prevent LLM context overflow.
    Large results (>8000 chars) are intelligently truncated while preserving
    structure and indicating total size.

    Args:
        result: Execution result value
        stats: Execution statistics from service
        persist: Whether execution was persisted to provenance
        post_processor_msg: Optional message from agent-specific post-processor

    Returns:
        JSON string with structured execution result
    """
    import json

    # Truncate result to prevent context overflow
    truncated_result, was_truncated, original_length = _truncate_result(result)

    # Build typed response object
    response_obj = {
        "success": True,
        "duration_seconds": stats.get("duration_seconds", 0),
        "result": truncated_result,
        "result_type": stats.get(
            "result_type", type(result).__name__ if result is not None else None
        ),
        "result_truncated": was_truncated,
        "result_original_chars": original_length if was_truncated else None,
        "stdout": stats.get("stdout_preview", ""),
        "stderr": stats.get("stderr_preview", ""),
        "stdout_full_path": stats.get("stdout_full_path"),
        "stderr_full_path": stats.get("stderr_full_path"),
        "warnings": stats.get("warnings", []),
        "persisted": persist,
        "new_modality_name": stats.get("new_modality_name"),
        "write_back_error": stats.get("write_back_error"),
        "captured_plots": stats.get("captured_plots", 0),
        "post_processor_message": post_processor_msg,
    }

    return json.dumps(response_obj, indent=2)


# =============================================================================
# Pre-built Post-Processors
# =============================================================================


def metadata_store_post_processor(
    result: Any,
    stats: Dict[str, Any],
    data_manager: DataManagerV2,
    workspace_key: Optional[str],
    modality_name: Optional[str],
) -> Optional[str]:
    """
    Post-processor for metadata_assistant: Persist results to metadata_store.

    Handles two patterns:
    1. In-place update: If workspace_key exists in metadata_store, update its 'samples'
    2. New key creation: If result contains {'samples': [...], 'output_key': 'name'}

    This enables the metadata_assistant workflow where users filter/transform samples
    and persist them for later export via write_to_workspace.

    Args:
        result: Execution result (should be dict with 'samples' key for persistence)
        stats: Execution statistics (unused, but required by signature)
        data_manager: DataManagerV2 instance with metadata_store
        workspace_key: Original workspace key that was loaded (for in-place updates)
        modality_name: Modality name (unused for metadata operations)

    Returns:
        Message describing what was persisted, or None if nothing persisted

    Example Result Formats:
        # Pattern 1: In-place update (workspace_key="existing_key")
        result = {"samples": [{"id": 1}, {"id": 2}]}

        # Pattern 2: New key creation
        result = {"samples": [...], "output_key": "filtered_samples"}
    """
    if not isinstance(result, dict):
        return None

    # Pattern 1: In-place update of existing workspace_key
    if workspace_key and workspace_key in data_manager.metadata_store:
        if "samples" in result:
            data_manager.metadata_store[workspace_key]["samples"] = result["samples"]
            count = len(result["samples"])
            logger.debug(
                f"Persisted {count} samples to metadata_store['{workspace_key}']"
            )
            return f"Persisted {count} samples to metadata_store['{workspace_key}']"

    # Pattern 2: Create new key with output_key
    elif "samples" in result and "output_key" in result:
        output_key = result["output_key"]
        data_manager.metadata_store[output_key] = {
            "samples": result["samples"],
            "filter_criteria": result.get("filter_criteria", "custom"),
            "stats": result.get("stats", {}),
        }
        count = len(result["samples"])
        logger.debug(f"Created metadata_store['{output_key}'] with {count} samples")
        return (
            f"Created metadata_store['{output_key}'] with {count} samples\n"
            f"Export with: write_to_workspace(identifier='{output_key}', "
            f"workspace='metadata', output_format='csv')"
        )

    return None


# =============================================================================
# Module Exports
# =============================================================================

__all__ = [
    "create_execute_custom_code_tool",
    "metadata_store_post_processor",
    "PostProcessor",
    "MAX_RESULT_LENGTH",
    "_truncate_result",
]
