from setuptools import setup, find_packages

setup(
    name="make_mp3",
    version="2.0.0",
    author="翟梓豪",
    author_email="ax05145@xxx.com",
    description="基于 edge-tts 的中文古诗词音频生成工具包",
    # 注释掉这两行，不再读取 README.md
    # long_description=long_description,
    # long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "edge-tts>=6.1.9"
    ],
    entry_points={
        "console_scripts": [
            "show-voices = make_mp3.cli:show_voices",
        ]
    }
)