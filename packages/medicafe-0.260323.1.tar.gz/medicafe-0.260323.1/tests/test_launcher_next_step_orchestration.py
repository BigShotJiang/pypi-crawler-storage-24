#!/usr/bin/env python
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


class LauncherNextStepOrchestrationTests(unittest.TestCase):

    def _make_orchestrator(self, non_interactive=False):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        args = MagicMock()
        args.skip_csv = False
        args.direct_action = None
        args.debug_mode = False
        args.auto_choice = None
        session = SessionConfig(args)
        session.non_interactive = non_interactive
        orch = MediCafeOrchestrator(session)
        orch._next_step_assistant_enabled = True
        return orch

    def test_assistant_disallowed_for_non_interactive(self):
        orch = self._make_orchestrator(non_interactive=True)
        self.assertFalse(orch._assistant_interaction_allowed())

    def test_signal_provider_submission_attempts_counts_retry_candidates(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            orch.environment['local_storage_path'] = temp_root
            attempts_path = os.path.join(temp_root, 'submission_attempts.jsonl')
            rows = [
                {'claim_key': 'a', 'status': 'submitted', 'custody': 'out_of_custody', 'attempt_at': 1},
                {'claim_key': 'b', 'status': 'conversion_failed', 'custody': 'in_custody', 'attempt_at': 2},
                {'claim_key': 'c', 'status': 'rejected_277', 'custody': 'returned_to_custody', 'attempt_at': 3},
            ]
            with open(attempts_path, 'w') as handle:
                for row in rows:
                    handle.write(json.dumps(row) + '\n')
            payload = orch._signal_provider_submission_attempts()
            self.assertEqual(payload.get('retry_queue_pending_count'), 2)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


    def test_signal_provider_submission_attempts_uses_latest_claim_attempt(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            orch.environment['local_storage_path'] = temp_root
            attempts_path = os.path.join(temp_root, 'submission_attempts.jsonl')
            rows = [
                {'claim_key': 'x', 'status': 'conversion_failed', 'custody': 'in_custody', 'attempt_at': 1},
                {'claim_key': 'x', 'status': 'submitted', 'custody': 'out_of_custody', 'attempt_at': 2},
                {'claim_key': 'y', 'status': 'rejected_277', 'custody': 'returned_to_custody', 'attempt_at': 3},
            ]
            with open(attempts_path, 'w') as handle:
                for row in rows:
                    handle.write(json.dumps(row) + '\n')
            payload = orch._signal_provider_submission_attempts()
            self.assertEqual(payload.get('retry_queue_pending_count'), 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_signal_provider_submission_attempts_respects_local_claims_path(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            claims_root = os.path.join(temp_root, 'claims')
            storage_root = os.path.join(temp_root, 'storage')
            os.makedirs(claims_root)
            os.makedirs(storage_root)
            config_path = os.path.join(temp_root, 'config.json')
            with open(config_path, 'w') as handle:
                json.dump({'MediLink_Config': {'local_claims_path': claims_root}}, handle)

            attempts_path = os.path.join(claims_root, 'submission_attempts.jsonl')
            with open(attempts_path, 'w') as handle:
                handle.write(json.dumps({'claim_key': 'z', 'status': 'conversion_failed', 'custody': 'in_custody', 'attempt_at': 1}) + '\n')

            orch.environment['config_file'] = config_path
            orch.environment['local_storage_path'] = storage_root
            payload = orch._signal_provider_submission_attempts()
            self.assertEqual(payload.get('retry_queue_pending_count'), 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)


    def test_signal_provider_remittance_ledger_requires_recent_entries(self):
        orch = self._make_orchestrator(non_interactive=False)
        temp_root = tempfile.mkdtemp(prefix='mc_assistant_')
        try:
            orch.environment['local_storage_path'] = temp_root
            ledger_path = os.path.join(temp_root, 'remittance_file_ledger.jsonl')
            old_ts = 1000000000
            with open(ledger_path, 'w') as handle:
                handle.write(json.dumps({'mtime': old_ts}) + '\n')
            payload = orch._signal_provider_remittance_ledger()
            self.assertFalse(payload.get('zdat_pending', False))

            recent_ts = 2000000000
            with patch('MediCafe.launcher.time.time', return_value=recent_ts + 5):
                with open(ledger_path, 'a') as handle:
                    handle.write(json.dumps({'mtime': recent_ts}) + '\n')
                payload2 = orch._signal_provider_remittance_ledger()
            self.assertTrue(payload2.get('zdat_pending'))
            self.assertGreaterEqual(payload2.get('intake_artifacts_new_count', 0), 1)
        finally:
            shutil.rmtree(temp_root, ignore_errors=True)

    def test_collect_startup_signals_uses_canonical_providers(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_assistant_signal_providers') as provider_builder:
            provider_builder.return_value = [
                lambda: {'zdat_pending': True},
                lambda: {'retry_queue_pending_count': 3},
            ]
            signals = orch._collect_startup_assistant_signals()
            self.assertTrue(signals.get('zdat_pending'))
            self.assertEqual(signals.get('retry_queue_pending_count'), 3)

    def test_maybe_offer_next_step_skips_when_non_interactive(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=True)
        with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
            orch._maybe_offer_next_step_assistant('medibot', 0)
            prompt_mock.assert_not_called()


    def test_startup_assistant_skips_without_actionable_signals(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        orch._startup_assistant_presented = False
        with patch.object(orch, '_assistant_interaction_allowed', return_value=True):
            with patch.object(orch, '_collect_startup_assistant_signals', return_value={}):
                with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
                    result = orch._maybe_offer_startup_assistant()
                    self.assertFalse(result)
                    prompt_mock.assert_not_called()




    def test_assistant_mode_env_auto_contextual_enables_without_legacy_flag(self):
        from MediCafe.launcher import MediCafeOrchestrator, SessionConfig
        args = MagicMock()
        args.skip_csv = False
        args.direct_action = None
        args.debug_mode = False
        args.auto_choice = None
        session = SessionConfig(args)
        with patch.dict(os.environ, {'MEDICAFE_NEXT_STEP_ASSISTANT_MODE': 'auto_contextual'}, clear=False):
            orch = MediCafeOrchestrator(session)
        self.assertEqual(orch._assistant_mode_or_default(), 'auto_contextual')
        self.assertTrue(orch._next_step_assistant_enabled)

    def test_auto_contextual_skips_prompt_for_safe_high_confidence_recommendation(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        orch._assistant_mode = 'auto_contextual'
        orch._next_step_assistant_enabled = True
        with patch.object(orch, '_assistant_interaction_allowed', return_value=True):
            with patch.object(orch, '_refresh_transition_assistant_signals', return_value={'retry_queue_pending_count': 1}):
                with patch.object(orch, '_execute_assistant_action', return_value=0) as exec_mock:
                    with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation') as prompt_mock:
                        orch._maybe_offer_next_step_assistant('claims_status', 0)
        prompt_mock.assert_not_called()
        exec_mock.assert_called()

    def test_transition_path_refreshes_signals_each_time(self):
        from MediCafe import launcher as launcher_mod
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_assistant_interaction_allowed', return_value=True):
            with patch.object(orch, '_refresh_transition_assistant_signals', return_value={}) as refresh_mock:
                with patch.object(launcher_mod.next_step_assistant, 'prompt_for_recommendation', return_value={'action_id': 'main_menu'}):
                    orch._maybe_offer_next_step_assistant('medibot', 0)
        refresh_mock.assert_called_once()

    def test_main_menu_loop_startup_assistant_checked_when_header_skipped(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_print_welcome_block'):
            with patch.object(orch, '_print_main_menu_options'):
                with patch.object(orch, '_maybe_offer_startup_assistant', side_effect=[False, False]) as startup_mock:
                    with patch.object(orch, '_get_menu_choice', return_value='0'):
                        with patch.object(orch, '_mark_clean_exit'):
                            with patch.object(orch, '_join_payer_list_thread'):
                                orch.main_menu_loop(show_header_on_first=False)
        startup_mock.assert_called()


    def test_run_startup_tasks_skips_passive_gmail_queue_resolution(self):
        from MediCafe import error_reporter
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, '_run_download_migration'):
            with patch.object(orch, '_launch_startup_csv'):
                with patch('MediCafe.launcher.cloud_readiness', None):
                    with patch.object(error_reporter, 'maybe_auto_resolve_queued_bundles_passive') as auto_mock:
                        orch._run_startup_tasks()
        auto_mock.assert_not_called()

    def test_download_emails_runs_legacy_queue_followup_before_csv(self):
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(orch, 'run_medicafe_command', return_value=0):
            with patch.object(orch, '_maybe_resolve_queued_reports_after_legacy_gmail_download') as follow_mock:
                with patch.object(orch, 'process_csvs', return_value=0):
                    rc = orch.download_emails()
        self.assertEqual(rc, 0)
        follow_mock.assert_called_once_with(0)

    def test_legacy_queue_followup_records_notice_when_attempted(self):
        from MediCafe import error_reporter
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(error_reporter, 'maybe_auto_resolve_queued_bundles_passive', return_value={'attempted': True, 'sent': 2, 'failed': 1}) as auto_mock:
            orch._maybe_resolve_queued_reports_after_legacy_gmail_download(0)
        auto_mock.assert_called_once_with()
        self.assertTrue(any('after legacy Gmail download' in message for _level, message in orch.startup_notices))

    def test_legacy_queue_followup_skips_failed_download(self):
        from MediCafe import error_reporter
        orch = self._make_orchestrator(non_interactive=False)
        with patch.object(error_reporter, 'maybe_auto_resolve_queued_bundles_passive') as auto_mock:
            orch._maybe_resolve_queued_reports_after_legacy_gmail_download(1)
        auto_mock.assert_not_called()


if __name__ == '__main__':
    unittest.main()
