#!/usr/bin/env python
"""
High-level MediCafe launcher implemented in Python so that the legacy
MediBot.bat wrapper can remain tiny while all meaningful logic is handled
in one place.

The implementation focuses on:
  - Parsing the same flags that MediBot.bat understands today
  - Detecting XP production (F:\\ based) versus Win11/dev environments
  - Handling the debug gates, migrations, CSV bootstrap, and menu routing
  - Delegating work to existing MediCafe/MediBot/MediLink modules
  - Providing a single failure wrapper that can trigger error bundles
    and rollback without duplicating the work already done inside the
    deeper scripts such as MediBot.py

Only Python 3.4 compatible language features are used so that the exact
same file can run on both XP SP3 and the Win11 dev workstation.
"""
from __future__ import print_function

import argparse
import hashlib
import json
import re
import os
import sys
import sqlite3
import subprocess
import tempfile
import shutil
import time
import threading
import traceback
from MediCafe.launcher_cloud_readiness_mixin import LauncherCloudReadinessMixin

# Set minimal import flags BEFORE any MediCafe imports to prevent module-load warnings
# This ensures that when MediCafe modules are imported, they won't trigger legacy import warnings
os.environ.setdefault('MEDICAFE_MINIMAL_IMPORT', '1')
os.environ.setdefault('MEDICAFE_SKIP_SMART_IMPORT_VALIDATE', '1')


_TRUE_ENV_VALUES = ("1", "true", "yes", "on", "y")
_EXIT_SENTINEL_ENV = 'MEDICAFE_LAUNCHER_EXIT_SENTINEL'
_ASSISTANT_SIGNAL_RECENCY_SECONDS = 24 * 3600
_ASSISTANT_SIGNAL_MAX_JSONL_LINES = 500


def _env_flag(name, default=False):
    """Parse MEDICAFE boolean env flags with tolerant truthy values."""
    raw = os.environ.get(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in _TRUE_ENV_VALUES


# Windows-specific console closing helper
def _exit_and_close_console():
    """Exit the process and attempt to close console window on Windows."""
    if os.name == 'nt':  # Windows
        # Use os._exit() to immediately terminate the process
        # This bypasses Python cleanup but ensures immediate exit
        # The console window should close when the process terminates
        os._exit(0)
    else:
        # On non-Windows, use normal exit
        sys.exit(0)

try:
    from collections import OrderedDict, deque
except ImportError:
    OrderedDict = dict
    deque = None

try:
    # These helpers already exist inside MediCafe and should be reused
    from MediCafe.error_reporter import collect_support_bundle, submit_support_bundle_email
except Exception:
    collect_support_bundle = None
    submit_support_bundle_email = None

try:
    from MediCafe.core_utils import check_internet_connection
except Exception:
    check_internet_connection = None

try:
    from MediCafe.timing_utils import (
        start_run, stage_timer, record_stage, is_timing_enabled,
        get_storage_path, load_recent_events, compute_summary,
        compute_regression, format_summary_for_display,
    )
except Exception:
    start_run = None
    stage_timer = None
    record_stage = None
    is_timing_enabled = None
    get_storage_path = None
    load_recent_events = None
    compute_summary = None
    compute_regression = None
    format_summary_for_display = None

try:
    from MediCafe.gmail_token_service import clear_gmail_token_cache, resolve_token_path
except Exception:
    clear_gmail_token_cache = None
    resolve_token_path = None

cloud_readiness = None
_cloud_readiness_import_error = None

try:
    from MediCafe import launcher_next_step_assistant as next_step_assistant
except Exception:
    next_step_assistant = None


def _handle_cloud_readiness_import_failure(exc):
    """
    On cloud_readiness import failure: log telemetry, attempt error report (dedup, non-blocking),
    print user message. Per plan: no inline legacy execution.
    """
    global _cloud_readiness_import_error
    _cloud_readiness_import_error = exc
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        repo_root = os.path.dirname(current_dir)
    except Exception:
        repo_root = '.'
    meta = {
        'exception_type': type(exc).__name__,
        'exception_message': str(exc),
        'traceback': traceback.format_exc(),
        'python_version': sys.version,
        'platform': getattr(sys, 'platform', 'unknown'),
        'launcher_version': 'unknown',
        'repo_path': repo_root,
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    }
    try:
        import platform as plat
        meta['platform'] = plat.platform()
    except Exception:
        pass
    try:
        from MediCafe.MediLink_ConfigLoader import log as config_log
        config_log(
            'Cloud Readiness import failed: {0}'.format(exc),
            level='ERROR',
            console_output=False,
        )
    except Exception:
        pass
    dedup_key = 'cloud_readiness_import_failure'
    dedup_window_sec = 6 * 3600
    state_path = os.path.join(os.environ.get('TEMP', os.path.expanduser('~')), 'medicafe_cloud_readiness_import_failure.json')
    should_send = True
    try:
        if collect_support_bundle and submit_support_bundle_email:
            from MediCafe.error_reporter import check_report_dedup
            should_send, _ = check_report_dedup(state_path, dedup_key, dedup_window_sec)
    except Exception:
        pass
    if should_send and collect_support_bundle and submit_support_bundle_email:

        def _do_report():
            try:
                zip_path = collect_support_bundle(
                    include_traceback=True,
                    extra_meta=dict(meta, cloud_readiness_import_failure=True),
                )
                if zip_path:
                    ok = submit_support_bundle_email(zip_path, skip_interactive_reauth=True)
                    if ok:
                        try:
                            state = {}
                            if os.path.exists(state_path):
                                with open(state_path, 'r', encoding='utf-8') as f:
                                    state = json.load(f)
                            state['last_report_dedup_key'] = dedup_key
                            state['last_report_sent_at_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
                            folder = os.path.dirname(state_path)
                            if folder and not os.path.exists(folder):
                                os.makedirs(folder)
                            with open(state_path, 'w', encoding='utf-8') as f:
                                json.dump(state, f, indent=2)
                        except (IOError, OSError, ValueError):
                            pass
            except Exception:
                pass

        t = threading.Thread(target=_do_report, daemon=True)
        t.start()
        t.join(timeout=8)
    print('Cloud Readiness unavailable this session.')


try:
    from MediCafe import cloud_readiness as _cr_mod
    cloud_readiness = _cr_mod
except Exception as exc:
    _handle_cloud_readiness_import_failure(exc)
    cloud_readiness = None


class LauncherError(Exception):
    """Base class for launcher-specific failures."""


class LauncherArgumentError(LauncherError):
    """Raised when CLI arguments cannot be parsed."""


class LauncherConfigError(LauncherError):
    """Raised when configuration validation fails."""


class LauncherArgumentParser(argparse.ArgumentParser):
    """Argument parser that raises instead of exiting so we can handle errors."""

    def error(self, message):
        raise LauncherArgumentError(message)


class SessionConfig(object):
    """Container for CLI + environment derived options."""

    def __init__(self, args):
        self.skip_startup_csv = args.skip_csv
        self.direct_action = args.direct_action
        self.debug_mode = args.debug_mode
        self.auto_menu_choice = args.auto_choice
        self.auto_menu_source = None
        self.non_interactive = bool(args.auto_choice or args.direct_action)

        allow_auto = os.environ.get('MEDICAFE_ALLOW_AUTO')
        env_choice = os.environ.get('MEDICAFE_AUTO_CHOICE')
        if (not self.auto_menu_choice) and _env_flag('MEDICAFE_ALLOW_AUTO', False) and env_choice:
            self.auto_menu_choice = env_choice.strip()
            self.auto_menu_source = 'ENV'
        elif self.auto_menu_choice:
            self.auto_menu_source = 'CLI'


class ErrorBundleCoordinator(object):
    """Centralize bundle creation to avoid duplicates and capture context."""

    def __init__(self):
        self.bundle_path = None
        self.bundle_signature = None

    def collect_once(self, context):
        if collect_support_bundle is None:
            return None
        signature = self._compute_signature(context)
        if signature and self.bundle_path and self.bundle_signature == signature and os.path.exists(self.bundle_path):
            return self.bundle_path
        if signature:
            last_sig = os.environ.get('MEDICAFE_LAST_ERROR_SIGNATURE')
            last_path = os.environ.get('MEDICAFE_LAST_BUNDLE_PATH')
            if last_sig == signature and last_path and os.path.exists(last_path):
                self.bundle_signature = signature
                self.bundle_path = last_path
                return last_path
        try:
            bundle = collect_support_bundle(include_traceback=True, extra_meta=context or {})
        except Exception as err:
            print('Failed to build support bundle: {0}'.format(err))
            return None
        if bundle:
            self.bundle_path = bundle
            self.bundle_signature = signature
            if signature:
                os.environ['MEDICAFE_LAST_ERROR_SIGNATURE'] = signature
            os.environ['MEDICAFE_LAST_BUNDLE_PATH'] = bundle
        return bundle

    def _compute_signature(self, context):
        if not context:
            return None
        try:
            serialized = json.dumps(context, sort_keys=True, default=str)
        except Exception:
            serialized = repr(context)
        return hashlib.sha1(serialized.encode('utf-8', 'ignore')).hexdigest()


def build_arg_parser():
    parser = LauncherArgumentParser(
        description='Python MediCafe UI orchestrator',
        prefix_chars='-/'  # Support both legacy /switch and modern --switch styles
    )
    parser.add_argument('--skip-csv', '/skip-csv', dest='skip_csv', action='store_true',
                        help='Skip automatic CSV processing on startup')
    parser.add_argument('--no-csv', '/no-csv', dest='skip_csv', action='store_true',
                        help='Alias for --skip-csv')
    parser.add_argument('--rollback', '/rollback', dest='direct_action', action='store_const',
                        const='rollback', help='Jump directly to rollback flow')
    parser.add_argument('--troubleshooting', '/troubleshooting', dest='direct_action',
                        action='store_const', const='troubleshooting',
                        help='Jump directly to troubleshooting menu')
    parser.add_argument('--auto-choice', '/auto-choice', dest='auto_choice', default=None,
                        help='Provide a menu choice non-interactively (single use)')
    parser.add_argument('--debug', '/debug', dest='debug_mode', action='store_true',
                        help='Open the debug gate immediately')
    parser.set_defaults(skip_csv=False, debug_mode=False, direct_action=None)
    return parser


_LOCAL_WORKFLOW_COMMANDS = frozenset(['download_emails', 'medilink', 'claims_status', 'deductible', 'medibot'])
_ASSISTANT_MODES = frozenset(['off', 'advisory', 'auto_contextual'])
_ASSISTANT_AUTO_SAFE_ACTIONS = frozenset(['download_emails', 'medilink', 'claims_status', 'deductible', 'medibot'])


class MediCafeOrchestrator(LauncherCloudReadinessMixin, object):
    """Encapsulates startup, menu routing, and failure handling."""

    def __init__(self, session_config):
        self.session = session_config
        # New path calculation (file is now in MediCafe/)
        current_dir = os.path.dirname(os.path.abspath(__file__))
        self.repo_root = os.path.dirname(current_dir)
        self.medibot_dir = os.path.join(self.repo_root, 'MediBot')
        self.cmd_exe = os.environ.get('COMSPEC', 'cmd.exe')
        self.python_exe = os.environ.get('MEDICAFE_PYTHON', sys.executable)
        self.startup_notices = []
        self.bundle_coordinator = ErrorBundleCoordinator()
        self._cloud_readiness_resolver = lambda: cloud_readiness
        self._env_flag_fn = _env_flag
        
        # Log error bundling system status
        if collect_support_bundle is not None:
            self._record_notice('INFO', 'Error bundling system active')
        else:
            self._record_notice('WARNING', 'Error bundling system unavailable (error_reporter import failed)')
        
        # Concern #1: Set working directory for consistent relative paths
        # This ensures all relative paths resolve correctly regardless of where
        # the script was invoked from (matches batch file behavior)
        os.chdir(self.repo_root)

        self.environment = self._resolve_environment()
        self._preflight_state = {
            'first_local_workflow': True,
            'last_preflight_ok': None,
            'last_preflight_fail_count': 0,
            'config_mtime': None,
            'crosswalk_mtime': None,
        }
        self.update_script = self.environment.get('upgrade_medicafe')
        self.update_available_version = None
        self.medicafe_version = None
        self.prepared = False
        self.failure_bundle_path = None
        self._update_check_thread = None
        self._payer_list_thread = None
        self._startup_tasks_deferred = False
        self._update_notification_shown = False
        self._assistant_mode = self._resolve_assistant_mode()
        self._next_step_assistant_enabled = bool(next_step_assistant) and self._assistant_mode != 'off'
        self._startup_assistant_presented = False
        self._startup_assistant_signals = {}

    # ------------------------------------------------------------------ #
    # Bootstrap helpers
    # ------------------------------------------------------------------ #
    def _resolve_environment(self):
        """Determine directory layout based on legacy F: drive availability.
        
        Two architectures are supported:
        1. Production (XP SP3): Uses F: drive and C:\\MEDIANSI paths
        2. Development: Uses relative paths from repo_root
        
        Key paths on dev machine (relative to repo_root):
        - json/config.json, json/crosswalk.json
        - MediBot/DOWNLOADS/ for local storage
        - MediBot/update_json.py for scripts
        """
        env = {}
        env['medicafe_package'] = 'medicafe'

        # Production XP paths (absolute)
        env['source_folder_production'] = r'C:\MEDIANSI\MediCare'
        env['target_folder_production'] = r'C:\MEDIANSI\MediCare\CSV'
        env['python_script_production'] = r'C:\Python34\Lib\site-packages\MediBot\update_json.py'
        env['python_script2_production'] = r'C:\Python34\Lib\site-packages\MediBot\MediBot.py'

        # Development paths (relative to repo_root)
        # Note: json/ is at repo root, not inside MediBot/
        env['source_folder_dev'] = os.path.join(self.repo_root, 'MediBot', 'DOWNLOADS')
        env['target_folder_dev'] = os.path.join(self.repo_root, 'MediBot', 'DOWNLOADS', 'CSV')
        env['python_script_dev'] = os.path.join(self.medibot_dir, 'update_json.py')
        env['python_script2_dev'] = os.path.join(self.medibot_dir, 'MediBot.py')

        # Path resolution: F: preferred on XP (update script lives there after updates to avoid
        # file lock; cannot run updater from install dir while overwriting it). Local is fallback.
        local_upgrade = os.path.join(self.medibot_dir, 'update_medicafe.py')
        legacy_upgrade = r'F:\Medibot\update_medicafe.py'
        env['upgrade_medicafe_local'] = local_upgrade
        env['upgrade_medicafe_legacy'] = legacy_upgrade
        env['upgrade_medicafe'] = None

        env['local_storage_legacy'] = r'F:\Medibot\DOWNLOADS'
        env['local_storage_local'] = os.path.join('MediBot', 'DOWNLOADS')
        env['config_file_legacy'] = r'F:\Medibot\json\config.json'
        # Config files are at repo_root/json/, not MediBot/json/
        env['config_file_local'] = os.path.join('json', 'config.json')
        env['temp_file_legacy'] = r'F:\Medibot\last_update_timestamp.txt'
        env['temp_file_local'] = os.path.join('MediBot', 'last_update_timestamp.txt')

        # Detect environment: Check for F: drive (production) vs dev machine
        f_drive_exists = os.path.exists(r'F:\\')
        legacy_folder_exists = os.path.exists(r'F:\Medibot')
        production_source_exists = os.path.exists(env['source_folder_production'])
        
        # Production environment detection
        is_production = legacy_folder_exists or production_source_exists
        
        if f_drive_exists and not legacy_folder_exists:
            try:
                os.makedirs(r'F:\Medibot')
                legacy_folder_exists = True
                is_production = True
            except OSError:
                pass  # Might not have permission, continue with local paths

        if is_production and legacy_folder_exists:
            # Production XP environment with F: drive
            env['local_storage_path'] = env['local_storage_legacy']
            env['config_file'] = env['config_file_legacy']
            env['temp_file'] = env['temp_file_legacy']
            env['source_folder'] = env['source_folder_production']
            env['target_folder'] = env['target_folder_production']
            env['python_script'] = env['python_script_production']
            env['python_script2'] = env['python_script2_production']
            
            # Only use legacy updater if it exists
            if os.path.exists(legacy_upgrade):
                env['upgrade_medicafe'] = legacy_upgrade
            elif os.path.exists(local_upgrade):
                env['upgrade_medicafe'] = local_upgrade
            else:
                env['upgrade_medicafe'] = None
        else:
            # Development environment - use relative paths from repo_root
            env['local_storage_path'] = env['local_storage_local']
            env['config_file'] = env['config_file_local']
            env['temp_file'] = env['temp_file_local']
            env['source_folder'] = env['source_folder_dev']
            env['target_folder'] = env['target_folder_dev']
            env['python_script'] = env['python_script_dev']
            env['python_script2'] = env['python_script2_dev']
            env['upgrade_medicafe'] = local_upgrade if os.path.exists(local_upgrade) else None
            
            # Ensure dev directories exist
            try:
                if not os.path.exists(env['source_folder']):
                    os.makedirs(env['source_folder'])
                if not os.path.exists(env['target_folder']):
                    os.makedirs(env['target_folder'])
            except OSError:
                pass  # Will be created by _ensure_directories if needed

        return env

    def _ensure_directories(self):
        """Make sure relative fallback directories exist."""
        # json/ is at repo root, not inside MediBot/
        json_dir = os.path.join(self.repo_root, 'json')
        dl_dir = os.path.join(self.repo_root, 'MediBot', 'DOWNLOADS')
        csv_dir = os.path.join(dl_dir, 'CSV')
        try:
            if not os.path.exists(json_dir):
                os.makedirs(json_dir)
            if not os.path.exists(dl_dir):
                os.makedirs(dl_dir)
            if not os.path.exists(csv_dir):
                os.makedirs(csv_dir)
        except Exception as exc:
            self._record_notice('WARNING', 'Failed to create fallback directories: {0}'.format(exc))

    def _record_notice(self, level, message):
        """Record a notice to log file, and console for WARNING/ERROR only."""
        self.startup_notices.append((level, message))
        
        # Only print to console for WARNING and ERROR levels
        # INFO messages are logged to file but not displayed on console
        if level in ('WARNING', 'ERROR'):
            print('[{0}] {1}'.format(level, message))
        
        # Always write to the actual log file for persistence (no console output)
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            # Log to file only - don't print to console (console_output=False)
            config_log(message, level=level, console_output=False)
        except Exception:
            # Fallback: try to write directly to log file if ConfigLoader unavailable
            try:
                import logging
                logger = logging.getLogger('MediCafe.launcher')
                log_method = getattr(logger, level.lower(), logger.info)
                log_method(message)
            except Exception:
                # Only print to console as last resort if logging completely fails
                if level in ('WARNING', 'ERROR'):
                    print('[{0}] {1}'.format(level, message))

    def _copy_update_script_to_legacy(self):
        """Copy update script to F: drive if available. Skip if identical; else run copy in background subprocess."""
        local_path = self.environment.get('upgrade_medicafe_local')
        legacy_path = self.environment.get('upgrade_medicafe_legacy')
        if not local_path or not os.path.exists(local_path):
            return
        
        # Check if F: drive exists
        if not os.path.exists(r'F:\\'):
            return
        
        # Performance optimization: Check if copy is needed
        try:
            if os.path.exists(legacy_path):
                local_stat = os.stat(local_path)
                legacy_stat = os.stat(legacy_path)
                if (local_stat.st_size == legacy_stat.st_size and
                    abs(local_stat.st_mtime - legacy_stat.st_mtime) < 1.0):
                    self.environment['upgrade_medicafe'] = legacy_path
                    return
        except Exception:
            pass
        
        # Copy needed: use local path for this session; run copy in background subprocess
        self.environment['upgrade_medicafe'] = local_path
        helper_path = os.path.join(self.repo_root, 'tools', 'copy_update_script.py')
        if not os.path.exists(helper_path):
            return
        try:
            subprocess.Popen(
                [self.python_exe, helper_path, '--source', local_path, '--dest', legacy_path],
                cwd=self.repo_root,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log("Copying update script to legacy location (background)", level="INFO", console_output=False)
            except Exception:
                pass
        except Exception:
            pass

    def _validate_config(self):
        """Concern #5: Validate config file exists, prompt if missing."""
        config_file = self.environment.get('config_file')
        if not config_file:
            raise LauncherConfigError('Configuration file path could not be resolved.')
            
        if os.path.exists(config_file):
            return
            
        # Config file missing - prompt user
        print('')
        print('Configuration file missing.')
        print('')
        print('Expected configuration file path: {0}'.format(config_file))
        print('')
        print('Would you like to provide an alternate path for the configuration file?')
        choice = self._prompt("Enter 'Y' to provide alternate path, or any other key to exit: ")
        
        if choice and choice.strip().upper() == 'Y':
            while True:
                print('')
                print('Please enter the full path to your configuration file.')
                print('Example: C:\\MediBot\\config\\config.json')
                print('Example with spaces: "G:\\My Drive\\MediBot\\config\\config.json"')
                print('')
                print('Note: If your path contains spaces, please include quotes around the entire path.')
                print('')
                alt_path = self._prompt('Enter configuration file path: ')
                # Remove any surrounding quotes from user input
                alt_path = alt_path.strip().strip('"').strip("'")
                
                if os.path.exists(alt_path):
                    print('Configuration file found at: {0}'.format(alt_path))
                    self.environment['config_file'] = alt_path
                    return True
                else:
                    print('Configuration file not found at: {0}'.format(alt_path))
                    retry = self._prompt('Would you like to try another path? (Y/N): ')
                    if not retry or retry.strip().upper() != 'Y':
                        break
        raise LauncherConfigError('Configuration file is required but was not located: {0}'.format(config_file))

    def _determine_medicafe_version(self):
        """Determine MediCafe version. Optimized to avoid blocking startup."""
        try:
            # Performance optimization: Try to get version from package metadata first (fastest, no subprocess)
            try:
                import pkg_resources
                self.medicafe_version = pkg_resources.get_distribution("medicafe").version
                return
            except Exception:
                pass
            
            # Fallback: try to read from package __init__ (fast, no subprocess)
            try:
                from MediCafe import __version__
                self.medicafe_version = __version__
                return
            except Exception:
                pass
            
            # Last resort: subprocess (slower, but more reliable)
            # Use polling with timeout to avoid blocking too long (Python 3.4 compatible)
            cmd = [sys.executable, '-c',
                   'import pkg_resources; '
                   'print("MediCafe=="+pkg_resources.get_distribution("medicafe").version)']
            temp = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=self.repo_root)
            
            # Poll with timeout (Python 3.4 compatible approach)
            start_time = time.time()
            timeout = 2.0
            while temp.poll() is None:
                if time.time() - start_time > timeout:
                    temp.kill()
                    break
                time.sleep(0.05)
            
            stdout, _ = temp.communicate()
            
            # Ensure subprocess is properly closed
            try:
                if temp.poll() is None:
                    temp.terminate()
                    time.sleep(0.1)
                    if temp.poll() is None:
                        temp.kill()
            except Exception:
                pass
            
            if stdout:
                decoded = stdout.decode('ascii', 'ignore').strip()
                parts = decoded.split('==')
                if len(parts) == 2:
                    self.medicafe_version = parts[1]
        except Exception:
            self.medicafe_version = 'unknown'

    def _check_for_updates(self, defer=True):
        """Check PyPI for available package updates. Can be deferred to background thread for faster startup."""
        script_path = self.environment.get('upgrade_medicafe')
        if not script_path or not os.path.exists(script_path):
            return
        
        # If deferring, run in background thread
        if defer:
            def _update_check_worker():
                self._check_for_updates_sync()
            
            self._update_check_thread = threading.Thread(target=_update_check_worker, daemon=True)
            self._update_check_thread.start()
            # Log that check is happening in background
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log("Checking PyPI for package updates (background, this may take a few seconds)", level="INFO", console_output=False)
            except Exception:
                pass
        else:
            # Synchronous check (for backward compatibility)
            self._check_for_updates_sync()
    
    def _check_for_updates_sync(self):
        """Synchronous PyPI update check implementation."""
        script_path = self.environment.get('upgrade_medicafe')
        if not script_path or not os.path.exists(script_path):
            return

        check_start_time = time.time()
        _storage = get_storage_path(env_local_storage=self.environment.get('local_storage_path'), repo_root=self.repo_root) if get_storage_path else None
        _run_id = start_run('launcher', storage_path=_storage) if (start_run and is_timing_enabled and is_timing_enabled()) else None
        temp_file = None
        try:
            temp_file = tempfile.NamedTemporaryFile(delete=False)
            temp_file.close()
            cmd = [self.python_exe, script_path, '--check-only']
            with open(temp_file.name, 'w+b') as handle:
                proc = subprocess.Popen(cmd, stdout=handle, stderr=subprocess.PIPE, cwd=self.repo_root)
                _, stderr = proc.communicate()
                # Ensure subprocess is properly closed
                try:
                    if proc.poll() is None:
                        proc.terminate()
                        proc.wait(timeout=1)
                except Exception:
                    try:
                        proc.kill()
                        proc.wait()
                    except Exception:
                        pass
                if proc.returncode != 0 and stderr:
                    try:
                        from MediCafe.MediLink_ConfigLoader import log as config_log
                        config_log("Update check failed: {0}".format(stderr.decode('utf-8', errors='replace')[:200]), level="WARNING", console_output=False)
                    except Exception:
                        pass
            with open(temp_file.name, 'r') as reader:
                for line in reader:
                    line = line.strip()
                    if line.startswith('UPDATE_AVAILABLE:'):
                        self.update_available_version = line.split(':', 1)[1].strip()
                        # Log if update is available
                        try:
                            from MediCafe.MediLink_ConfigLoader import log as config_log
                            config_log("Update available: {0}".format(self.update_available_version), level="INFO", console_output=False)
                        except Exception:
                            pass
                    elif line == 'UP_TO_DATE':
                        # Log that we're up to date
                        try:
                            from MediCafe.MediLink_ConfigLoader import log as config_log
                            config_log("Package is up to date", level="INFO", console_output=False)
                        except Exception:
                            pass
            
            check_elapsed = time.time() - check_start_time
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log("Update check completed (took {:.2f}s)".format(check_elapsed), level="INFO", console_output=False)
            except Exception:
                pass
        except Exception as exc:
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log("Unable to perform update check: {0}".format(str(exc)), level="WARNING", console_output=False)
            except Exception:
                pass
        finally:
            check_elapsed = time.time() - check_start_time
            if _run_id and record_stage:
                record_stage(_run_id, 'launcher', 'update_check', int(check_elapsed * 1000))
            if temp_file and os.path.exists(temp_file.name):
                try:
                    os.unlink(temp_file.name)
                except Exception:
                    pass

    def _check_payer_list_update(self):
        """Phase 3: Check and update OPTUMAI payer list (non-blocking, deferred to background)."""
        def _payer_list_update_worker():
            try:
                from MediCafe.payer_list_updater import update_optumai_payer_ids
                from MediBot.MediBot_Crosswalk_Utils import ensure_full_config_loaded
                
                # Load config and crosswalk
                config, crosswalk = ensure_full_config_loaded(None, None)
                if not config or not crosswalk:
                    return
                
                # Use factory-backed shared client for token caching benefits
                try:
                    from MediCafe.api_factory import APIClient
                    client = APIClient()
                except ImportError:
                    # Fallback to direct api_core if factory unavailable
                    from MediCafe.api_core import APIClient
                    client = APIClient(config)
                
                # Attempt update (non-blocking, errors are logged but don't fail startup)
                success, payer_count, error = update_optumai_payer_ids(client, config, crosswalk, force=False)
                if success:
                    try:
                        from MediCafe.MediLink_ConfigLoader import log as config_log
                        config_log("OPTUMAI payer list updated: {} payers".format(payer_count), level="INFO", console_output=False)
                    except Exception:
                        pass
                elif error and "not needed" not in error.lower():
                    # Log errors (except "not needed" which is expected)
                    try:
                        from MediCafe.MediLink_ConfigLoader import log as config_log
                        config_log("OPTUMAI payer list update check: {}".format(error), level="DEBUG", console_output=False)
                    except Exception:
                        pass
            except ImportError:
                # payer_list_updater not available - silently skip
                pass
            except Exception as e:
                # Don't fail startup on payer list update errors
                try:
                    from MediCafe.MediLink_ConfigLoader import log as config_log
                    config_log("Payer list update check failed (non-blocking): {}".format(str(e)), level="DEBUG", console_output=False)
                except Exception:
                    pass
        
        # Run in background thread to avoid blocking startup
        self._payer_list_thread = threading.Thread(target=_payer_list_update_worker, daemon=True)
        self._payer_list_thread.start()

    def _exit_after_payer_list_join(self):
        """Join payer-list thread with timeout (if alive), then exit. Reduces chance of exiting mid-save."""
        t = getattr(self, '_payer_list_thread', None)
        if t is not None and t.is_alive():
            try:
                t.join(timeout=8)
            except Exception:
                pass
        try:
            sys.stdout.flush()
            sys.stderr.flush()
        except Exception:
            pass
        _exit_and_close_console()

    def _join_payer_list_thread(self):
        """Join payer-list thread with timeout (if alive)."""
        t = getattr(self, '_payer_list_thread', None)
        if t is not None and t.is_alive():
            try:
                t.join(timeout=8)
            except Exception:
                pass

    def _mark_clean_exit(self):
        """
        Persist an explicit clean-exit marker for the wrapper batch script.
        This avoids false recovery prompts when process exit status is misreported.
        """
        sentinel = os.environ.get(_EXIT_SENTINEL_ENV, '').strip()
        if not sentinel:
            return
        try:
            folder = os.path.dirname(sentinel)
            if folder and not os.path.exists(folder):
                os.makedirs(folder)
            with open(sentinel, 'w') as f:
                f.write('exit=clean\n')
        except (IOError, OSError):
            pass

    def prepare(self):
        """Run one-time bootstrap steps. Optimized for fast startup."""
        if self.prepared:
            return

        startup_start = time.time()
        _storage = get_storage_path(env_local_storage=self.environment.get('local_storage_path'), repo_root=self.repo_root) if get_storage_path else None
        run_id = start_run('launcher', storage_path=_storage) if (start_run and is_timing_enabled and is_timing_enabled()) else None

        # Log initialization steps for visibility (file only, no console)
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            config_log("Initializing MediCafe launcher", level="INFO", console_output=False)
            config_log("Ensuring required directories exist", level="INFO", console_output=False)
        except Exception:
            pass
        
        if os.name != 'nt':
            self._record_notice('WARNING', 'This launcher expects Windows. Some features are disabled.')
        
        self._ensure_directories()
        
        try:
            config_log("Copying update script to legacy location", level="INFO", console_output=False)
        except Exception:
            pass
        self._copy_update_script_to_legacy()
        
        # Concern #5: Validate config before proceeding
        try:
            config_log("Validating configuration", level="INFO", console_output=False)
        except Exception:
            pass
        self._validate_config()
        
        # Pass resolved config path to subprocesses (medilink, claims_status, etc.) via env
        config_file = self.environment.get('config_file')
        if config_file:
            os.environ['MEDICAFE_CONFIG_FILE'] = self._make_absolute(config_file)
        
        try:
            config_log("Determining MediCafe version", level="INFO", console_output=False)
        except Exception:
            pass
        self._determine_medicafe_version()
        
        # Performance optimization: Defer update check to background thread
        # This allows menu to appear immediately while check happens in background
        self._check_for_updates(defer=True)
        
        # Phase 3: Check and update OPTUMAI payer list (non-blocking, already deferred)
        # This is already non-blocking, but we can defer it further if needed
        self._check_payer_list_update()
        
        startup_elapsed = time.time() - startup_start
        if run_id and record_stage:
            record_stage(run_id, 'launcher', 'startup_total', int(startup_elapsed * 1000))
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            config_log("MediCafe launcher initialization complete (took {:.2f}s)".format(startup_elapsed), level="INFO", console_output=False)
        except Exception:
            pass
        self.prepared = True

    # ------------------------------------------------------------------ #
    # Main entry routing
    # ------------------------------------------------------------------ #
    def run(self):
        try:
            # Clear console and show header immediately, before any preparation steps
            self._clear_console()
            self._print_legacy_banner('MediCafe Launcher')
            
            # Now run preparation steps (they'll log to file, not console for INFO level)
            self.prepare()
            
            if self.session.direct_action == 'rollback':
                self.forced_version_rollback()
                return 0
            if self.session.direct_action == 'troubleshooting':
                self.troubleshooting_menu()
                return 0
            if self.session.debug_mode:
                self.debug_menu()
                return 0
            self.start_normal_mode()
            return 0
        except KeyboardInterrupt:
            print('\nUser interrupted execution.')
            return 130
        except Exception as exc:
            # Concern #9: Only bundle on orchestrator exceptions, not subprocess failures
            self.handle_fatal_error(exc)
            return 1

    def start_normal_mode(self):
        # Clear console right before version display to remove any preparation output (e.g. "Checking for updates...")
        self._clear_console()
        
        # No wait for update check; menu appears immediately. Update notification surfaced on menu re-display when ready.
        # Now print version details (Version only; update line shown in main_menu_loop when check completes)
        self._print_version_details()
        # Track if we've shown the update notification (in case it completes later)
        if self.update_available_version:
            self._update_notification_shown = True
        else:
            self._update_notification_shown = False
        
        # Performance optimization: Show menu immediately, defer startup tasks to background
        # This improves perceived startup time significantly
        if not self._startup_tasks_deferred:
            # Launch startup tasks in background thread so menu appears immediately
            def _deferred_startup_tasks():
                self._run_startup_tasks()
            
            startup_thread = threading.Thread(target=_deferred_startup_tasks, daemon=True)
            startup_thread.start()
            self._startup_tasks_deferred = True
        else:
            # If already deferred, run synchronously (shouldn't happen, but safe fallback)
            self._run_startup_tasks()
        
        # Now show the full menu immediately (header already displayed, so skip it on first iteration)
        self.main_menu_loop(show_header_on_first=False)

    def _run_startup_tasks(self):
        self._run_download_migration()
        if cloud_readiness and hasattr(cloud_readiness, 'run_pipeline'):
            ok, msg, _ = cloud_readiness.run_pipeline(
                self.repo_root,
                self.python_exe,
                self.environment,
                _env_flag,
            )
            if not ok and msg:
                self._record_notice('WARNING', msg)
        else:
            pass
        if not self.session.skip_startup_csv:
            self._launch_startup_csv()
        else:
            self._record_notice('INFO', 'Startup CSV processing skipped by flag.')

    # ------------------------------------------------------------------ #
    # Debug / Troubleshooting
    # ------------------------------------------------------------------ #
    def debug_menu(self):
        print('')
        print('========================================')
        print('       MEDICAFE DEBUG OPTIONS          ')
        print('========================================')
        print('1. Normal Mode (continue)')
        print('2. Run interactive debug suite')
        print('3. Run non-interactive debug suite')
        print('4. Emergency rollback')
        print('5. Troubleshooting toolkit')
        choice = (self._prompt('Choose an option (1-5): ') or '').strip()
        if choice == '2':
            self._call_batch('full_debug_suite.bat', ['/interactive'], interactive=True)
        elif choice == '3':
            self._call_batch('full_debug_suite.bat', [])
        elif choice == '4':
            self.forced_version_rollback()
            return
        elif choice == '5':
            self.troubleshooting_menu()
            return
        self.start_normal_mode()

    def troubleshooting_menu(self):
        while True:
            self._clear_console()
            self._print_legacy_banner('MediCafe Troubleshooting Toolkit', width=40)
            self._print_troubleshooting_group('Reporting & Logs', [
                '1)  Submit error report (email)',
                '2)  Resolve queued error reports',
                '3)  View latest run log',
                '4)  View WinSCP transfer logs',
            ])
            self._print_troubleshooting_group('Logging Controls', [
                '5)  Toggle performance logging (session)',
                '6)  Toggle verbose logging (session)',
            ])
            self._print_troubleshooting_group('Cache & Token Maintenance', [
                '7)  Manage Python cache',
                '8)  Reset Gmail OAuth token',
            ])
            self._print_troubleshooting_group('Data Intake', [
                '9)  Force CSV intake (includes deductible cache build)',
                '10) Rebuild DOCX schedule index (force full parse)',
            ])
            self._print_troubleshooting_group('Safety & Recovery', [
                '11) Emergency MediCafe rollback',
            ])
            self._print_troubleshooting_group('Advanced Tools', [
                '12) Launch config editor',
                '13) Update API client secret',
                'T)  Run API token self-test (manual)',
            ])
            self._print_troubleshooting_group('Cloud Readiness & Advanced', [
                '15) Cloud Readiness & Advanced Tools...',
            ])
            print('Navigation')
            print(' 0) Return to Main Menu')
            print('')
            choice = (self._prompt('Enter your choice: ') or '').strip()
            if choice == '1':
                print('Submitting error report...')
                self.run_medicafe_command('send_error_report')
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '2':
                print('Resolving queued error reports...')
                self.run_medicafe_command('send_queued_error_reports')
                try:
                    self._prompt('Press Enter to return to menu...')
                except Exception:
                    pass
            elif choice == '3':
                print('Opening latest MediCafe run log...')
                self.open_latest_log()
            elif choice == '4':
                print('Opening WinSCP transfer logs...')
                self.open_winscp_logs()
            elif choice == '5':
                self.toggle_session_flag('MEDICAFE_PERFORMANCE_LOGGING')
            elif choice == '6':
                self.toggle_verbose_logging()
            elif choice == '7':
                self.clear_cache_menu()
            elif choice == '8':
                self.force_gmail_reauth()
            elif choice == '9':
                print('Starting CSV intake and deductible cache build...')
                self.process_csvs()
            elif choice == '10':
                print('Rebuilding DOCX schedule index (full parse)...')
                self._run_docx_index_rebuild()
            elif choice == '11':
                self.forced_version_rollback()
            elif choice == '12':
                print('Launching config editor...')
                self._run_config_editor()
            elif choice == '13':
                print('Launching client secret updater...')
                self._run_client_secret_update()
            elif choice.lower() == 't':
                print('Launching API token self-test...')
                self._run_token_self_test()
            elif choice == '15':
                self._cloud_readiness_advanced_menu()
            elif choice in ('0', '14'):
                return
            else:
                print('Invalid choice.')

    # ------------------------------------------------------------------ #
    # Menu + options
    # ------------------------------------------------------------------ #
    def main_menu_loop(self, show_header_on_first=True):
        first_iteration = True
        while True:
            # Surface update notification when background check completes (before welcome/menu)
            if self.update_available_version and not self._update_notification_shown:
                print("[UPDATE AVAILABLE] {0}".format(self.update_available_version))
                self._update_notification_shown = True
            if first_iteration and not show_header_on_first:
                # Header already displayed, just show menu content
                self._print_welcome_block()
                self._print_main_menu_options()
                if self._maybe_offer_startup_assistant():
                    first_iteration = False
                    continue
                first_iteration = False
            else:
                # Menu refresh after operation - clear and re-establish clean menu view
                self._clear_console()
                self._print_version_details()
                self._print_welcome_block()
                self._print_main_menu_options()
                if first_iteration and self._maybe_offer_startup_assistant():
                    first_iteration = False
                    continue
                first_iteration = False

            choice = self._get_menu_choice()

            if choice == '1':
                self.run_update_flow()
            elif choice == '2':
                rc = self.download_emails()
                self._maybe_offer_next_step_assistant('download_emails', rc)
            elif choice == '3':
                rc = self.run_medicafe_command('medilink')
                self._maybe_offer_next_step_assistant('medilink', rc)
            elif choice == '4':
                rc = self.run_medicafe_command('claims_status')
                self._maybe_offer_next_step_assistant('claims_status', rc)
            elif choice == '5':
                rc = self.run_medicafe_command('deductible')
                self._maybe_offer_next_step_assistant('deductible', rc)
            elif choice == '6':
                rc = self.run_medicafe_command('medibot')
                self._maybe_offer_next_step_assistant('medibot', rc)
            elif choice == '7':
                self.troubleshooting_menu()
            elif choice in ('0', '8'):
                #print('Exiting MediCafe UI.')
                self._mark_clean_exit()
                self._join_payer_list_thread()
                return
            else:
                print('Invalid choice.')
                time.sleep(1.5)

    def _resolve_assistant_mode(self):
        """Resolve assistant mode from env with backward-compatible flag behavior."""
        if not next_step_assistant:
            return 'off'

        explicit_mode = str(os.environ.get('MEDICAFE_NEXT_STEP_ASSISTANT_MODE', '') or '').strip().lower()
        if explicit_mode in _ASSISTANT_MODES:
            return explicit_mode

        if explicit_mode:
            return 'advisory'

        if _env_flag('MEDICAFE_NEXT_STEP_ASSISTANT', False):
            return 'advisory'
        return 'off'

    def _assistant_mode_or_default(self):
        mode = str(getattr(self, '_assistant_mode', 'off') or 'off').strip().lower()
        if mode in _ASSISTANT_MODES:
            return mode
        return 'off'

    def _assistant_should_auto_select(self, recommendation):
        if self._assistant_mode_or_default() != 'auto_contextual':
            return False
        if not isinstance(recommendation, dict):
            return False
        action_id = str(recommendation.get('action_id') or '').strip()
        if action_id not in _ASSISTANT_AUTO_SAFE_ACTIONS:
            return False
        reason_code = str(recommendation.get('reason_code') or '').strip().lower()
        signal_source = str(recommendation.get('signal_source') or '').strip().lower()
        if reason_code in ('no_actionable_work', 'manual_navigation', 'invalid_input_fallback'):
            return False
        if signal_source in ('ui', 'derived', ''):
            return False
        return True

    def _refresh_transition_assistant_signals(self):
        if not self._next_step_assistant_enabled or not next_step_assistant:
            return dict(self._startup_assistant_signals or {})
        try:
            refreshed = next_step_assistant.collect_startup_signals(
                startup_notices=self.startup_notices,
                signal_providers=self._assistant_signal_providers()
            )
            if isinstance(refreshed, dict):
                self._startup_assistant_signals = refreshed
        except Exception as signal_exc:
            self._record_assistant_event(
                'assistant_fallback_legacy',
                action_key='signal_refresh',
                details={
                    'stage': 'signal_refresh',
                    'exception_class': signal_exc.__class__.__name__,
                    'reason_code': 'signal_refresh_exception',
                    'mode': self._assistant_mode_or_default(),
                    'interactive_state': 'interactive' if self._assistant_interaction_allowed() else 'non_interactive',
                    'action_key': 'signal_refresh',
                },
            )
        return dict(self._startup_assistant_signals or {})

    def _assistant_interaction_allowed(self):
        if not self._next_step_assistant_enabled:
            return False
        if getattr(self.session, 'non_interactive', False):
            return False
        try:
            if sys.stdin is None or not sys.stdin.isatty():
                return False
        except Exception:
            return False
        return True

    def _read_jsonl_tail(self, path, max_lines=300):
        try:
            if not path or not os.path.exists(path):
                return []
            if deque:
                lines = deque(maxlen=max_lines)
            else:
                lines = []
            with open(path, 'r') as handle:
                for raw in handle:
                    raw = raw.strip()
                    if not raw:
                        continue
                    if deque:
                        lines.append(raw)
                    else:
                        lines.append(raw)
            if deque:
                return list(lines)
            if len(lines) > max_lines:
                return lines[-max_lines:]
            return lines
        except Exception:
            return []

    def _signal_provider_remittance_ledger(self):
        payload = {}
        storage = self.environment.get('local_storage_path', '')
        if storage and not os.path.isabs(storage):
            storage = os.path.abspath(os.path.join(self.repo_root, storage))
        ledger = os.path.join(storage, 'remittance_file_ledger.jsonl') if storage else ''
        rows = self._read_jsonl_tail(ledger, max_lines=_ASSISTANT_SIGNAL_MAX_JSONL_LINES)
        if not rows:
            return payload

        now_ts = int(time.time())
        recent_rows = 0
        latest_mtime = 0
        for raw in rows:
            try:
                rec = json.loads(raw)
            except Exception:
                continue
            try:
                mtime = int(rec.get('mtime') or 0)
            except Exception:
                mtime = 0
            if mtime > latest_mtime:
                latest_mtime = mtime
            if mtime > 0 and (now_ts - mtime) <= _ASSISTANT_SIGNAL_RECENCY_SECONDS:
                recent_rows += 1

        if recent_rows > 0:
            payload['zdat_pending'] = True
            payload['intake_artifacts_new_count'] = recent_rows
        elif latest_mtime > 0 and (now_ts - latest_mtime) <= _ASSISTANT_SIGNAL_RECENCY_SECONDS:
            payload['zdat_pending'] = True
        return payload

    def _is_retryable_submission_attempt(self, rec):
        custody = str(rec.get('custody', '') or '').strip().lower()
        status = str(rec.get('status', '') or '').strip().lower()
        return custody in ('in_custody', 'returned_to_custody') or status in (
            'conversion_failed',
            'upload_failed',
            'api_error',
            'rejected_277',
            'rejected_999',
        )

    def _resolve_submission_attempts_path(self):
        config_file = self.environment.get('config_file', '')
        if config_file and not os.path.isabs(config_file):
            config_file = os.path.abspath(os.path.join(self.repo_root, config_file))

        config_data = {}
        if config_file and os.path.exists(config_file):
            try:
                with open(config_file, 'r') as handle:
                    config_data = json.load(handle)
            except Exception:
                config_data = {}

        try:
            from MediCafe.submission_attempts import get_attempts_path
            path = get_attempts_path(config_data or {})
            if path and not os.path.isabs(path):
                path = os.path.abspath(os.path.join(self.repo_root, path))
            if path:
                if os.path.exists(path):
                    return path
                # Keep explicit configured claim-root target even if file is not created yet.
                if config_data and isinstance(config_data.get('MediLink_Config'), dict) and config_data.get('MediLink_Config', {}).get('local_claims_path'):
                    return path
        except Exception:
            pass

        storage = self.environment.get('local_storage_path', '')
        if storage and not os.path.isabs(storage):
            storage = os.path.abspath(os.path.join(self.repo_root, storage))
        return os.path.join(storage, 'submission_attempts.jsonl') if storage else ''

    def _signal_provider_submission_attempts(self):
        payload = {}
        attempts_path = self._resolve_submission_attempts_path()
        rows = self._read_jsonl_tail(attempts_path, max_lines=_ASSISTANT_SIGNAL_MAX_JSONL_LINES)

        latest_by_claim_key = {}
        non_key_retryable_count = 0
        for idx, raw in enumerate(rows):
            try:
                rec = json.loads(raw)
            except Exception:
                continue
            if not isinstance(rec, dict):
                continue
            claim_key = str(rec.get('claim_key') or '').strip()
            if not claim_key:
                if self._is_retryable_submission_attempt(rec):
                    non_key_retryable_count += 1
                continue
            try:
                attempt_at = int(rec.get('attempt_at') or 0)
            except Exception:
                attempt_at = 0
            sort_key = attempt_at if attempt_at > 0 else idx
            existing = latest_by_claim_key.get(claim_key)
            if not existing or sort_key >= existing[0]:
                latest_by_claim_key[claim_key] = (sort_key, rec)

        retry_candidates = non_key_retryable_count
        for _, rec in latest_by_claim_key.values():
            if self._is_retryable_submission_attempt(rec):
                retry_candidates += 1

        if retry_candidates > 0:
            payload['retry_queue_pending_count'] = retry_candidates
        return payload

    def _assistant_signal_providers(self):
        return [
            self._signal_provider_remittance_ledger,
            self._signal_provider_submission_attempts,
        ]


    def _serialize_assistant_recommendations(self, recommendations):
        serialized = []
        for rec in (recommendations or []):
            if not isinstance(rec, dict):
                continue
            serialized.append({
                'action_id': rec.get('action_id'),
                'reason_code': rec.get('reason_code') or '',
                'signal_source': rec.get('signal_source') or '',
            })
        return serialized

    def _log_assistant_event_info(self, event_name, action_key=None, details=None, level='INFO'):
        """Best-effort centralized logging for assistant diagnostics."""
        try:
            from MediCafe.MediLink_ConfigLoader import log as config_log
            summary = ''
            if isinstance(details, dict):
                selected = details.get('selected_action')
                status = details.get('status')
                options = details.get('options')
                if selected:
                    summary = ' selected={0}'.format(selected)
                elif status:
                    summary = ' status={0}'.format(status)
                elif isinstance(options, list):
                    summary = ' options={0}'.format(len(options))
            config_log(
                'Launcher assistant {0} action={1}{2}'.format(
                    str(event_name or ''),
                    str(action_key or ''),
                    summary,
                ),
                level=level,
                console_output=False,
            )
        except Exception:
            pass

    def _record_assistant_event(self, event_name, action_key=None, details=None):
        details = details or {}
        payload = {
            'event': str(event_name or ''),
            'action_key': str(action_key or ''),
            'details': details,
            'timestamp': int(time.time()),
        }
        self._log_assistant_event_info(event_name, action_key=action_key, details=details, level='INFO')
        try:
            storage = self.environment.get('local_storage_path', '')
            if storage and not os.path.isabs(storage):
                storage = os.path.abspath(os.path.join(self.repo_root, storage))
            if storage and not os.path.exists(storage):
                os.makedirs(storage)
            if storage:
                out_path = os.path.join(storage, 'launcher_next_step_events.jsonl')
                with open(out_path, 'a') as handle:
                    handle.write(json.dumps(payload))
                    handle.write('\n')
        except Exception:
            pass

    def _build_action_outcome(self, action_key, rc, extra_signals=None):
        # Normalize action completion for assistant recommendations.
        status = 'ok' if rc == 0 else 'failed'
        severity = 'info' if rc == 0 else 'warning'
        signals = dict(extra_signals or {})
        if action_key == 'download_emails' and rc == 0:
            signals.setdefault('intake_artifacts_new_count', 1)
        if not next_step_assistant:
            return {'action_key': action_key, 'status': status, 'severity': severity, 'signals': signals}
        return next_step_assistant.build_action_outcome(
            action_key=action_key,
            status=status,
            severity=severity,
            signals=signals,
            reason_codes=[]
        )

    def _collect_startup_assistant_signals(self):
        if not self._next_step_assistant_enabled or not next_step_assistant:
            return {}
        try:
            self._startup_assistant_signals = next_step_assistant.collect_startup_signals(
                startup_notices=self.startup_notices,
                signal_providers=self._assistant_signal_providers()
            )
        except Exception as startup_signal_exc:
            self._startup_assistant_signals = {}
            self._log_assistant_event_info('assistant_signal_collection_error', action_key='startup', details=None, level='WARNING')
            try:
                from MediCafe.MediLink_ConfigLoader import log as config_log
                config_log('Launcher assistant signal collection failure: {0}'.format(startup_signal_exc), level='WARNING', console_output=False)
            except Exception:
                pass
        return dict(self._startup_assistant_signals)

    def _execute_assistant_action(self, action_id):
        # Route assistant action id to existing launcher actions (DRY).
        if action_id == 'download_emails':
            return self.download_emails()
        if action_id == 'medilink':
            return self.run_medicafe_command('medilink')
        if action_id == 'claims_status':
            return self.run_medicafe_command('claims_status')
        if action_id == 'deductible':
            return self.run_medicafe_command('deductible')
        if action_id == 'medibot':
            return self.run_medicafe_command('medibot')
        if action_id == 'troubleshooting':
            self.troubleshooting_menu()
            return 0
        return 0

    def _maybe_offer_startup_assistant(self):
        if self._startup_assistant_presented:
            return False
        if not next_step_assistant or not self._next_step_assistant_enabled:
            self._startup_assistant_presented = True
            self._record_assistant_event('assistant_bypassed', action_key='startup', details={'reason_code': 'mode_off', 'mode': self._assistant_mode_or_default()})
            return False
        if not self._assistant_interaction_allowed():
            self._startup_assistant_presented = True
            self._record_assistant_event('assistant_startup_skipped', action_key='startup', details={'reason_code': 'non_interactive', 'mode': self._assistant_mode_or_default()})
            return False
        self._startup_assistant_presented = True
        startup_signals = self._collect_startup_assistant_signals()
        if not next_step_assistant.has_actionable_signals(startup_signals):
            self._record_assistant_event('assistant_startup_skipped', action_key='startup', details={'reason_code': 'no_actionable_signal', 'mode': self._assistant_mode_or_default()})
            return False
        outcome = next_step_assistant.build_action_outcome(
            action_key='startup',
            status='ok',
            severity='info',
            signals={},
            reason_codes=[]
        )
        try:
            recommendations = next_step_assistant.recommend_next_steps(outcome, startup_signals=startup_signals)
            self._record_assistant_event('suggestion_shown', action_key='startup', details={'options': self._serialize_assistant_recommendations(recommendations), 'mode': self._assistant_mode_or_default()})
            selected = None
            if recommendations and self._assistant_should_auto_select(recommendations[0]):
                selected = recommendations[0]
                self._record_assistant_event('assistant_auto_selected', action_key='startup', details={'selected_action': selected.get('action_id') or '', 'selected_reason_code': selected.get('reason_code') or '', 'selected_signal_source': selected.get('signal_source') or '', 'mode': self._assistant_mode_or_default()})
            else:
                selected = next_step_assistant.prompt_for_recommendation(recommendations, self._prompt, print)
        except Exception as rec_exc:
            self._record_assistant_event('assistant_fallback_legacy', action_key='startup', details={'stage': 'startup_prompt', 'exception_class': rec_exc.__class__.__name__, 'reason_code': 'recommendation_exception', 'mode': self._assistant_mode_or_default(), 'interactive_state': 'interactive', 'action_key': 'startup'})
            return False
        if not selected:
            return False
        action_id = selected.get('action_id')
        if action_id and action_id != 'main_menu':
            self._record_assistant_event('suggestion_selected', action_key='startup', details={'selected_action': action_id, 'selected_reason_code': selected.get('reason_code') or '', 'selected_signal_source': selected.get('signal_source') or ''})
            self._execute_assistant_action(action_id)
            return True
        self._record_assistant_event('suggestion_skipped', action_key='startup', details={'selected_action': action_id or 'none', 'selected_reason_code': selected.get('reason_code') if isinstance(selected, dict) else ''})
        return False

    def _maybe_offer_next_step_assistant(self, action_key, rc, extra_signals=None):
        if action_key not in ('download_emails', 'medilink', 'claims_status', 'deductible', 'medibot'):
            return
        if not next_step_assistant or not self._next_step_assistant_enabled:
            self._record_assistant_event('assistant_bypassed', action_key=action_key, details={'reason_code': 'mode_off', 'mode': self._assistant_mode_or_default()})
            return
        if not self._assistant_interaction_allowed():
            self._record_assistant_event('assistant_fallback_legacy', action_key=action_key, details={'stage': 'transition_prompt', 'exception_class': '', 'reason_code': 'non_interactive', 'mode': self._assistant_mode_or_default(), 'interactive_state': 'non_interactive', 'action_key': action_key})
            return
        outcome = self._build_action_outcome(action_key, rc, extra_signals=extra_signals)
        startup_signals = self._refresh_transition_assistant_signals()
        try:
            recommendations = next_step_assistant.recommend_next_steps(outcome, startup_signals=startup_signals)
            self._record_assistant_event('suggestion_shown', action_key=action_key, details={'options': self._serialize_assistant_recommendations(recommendations), 'status': outcome.get('status'), 'mode': self._assistant_mode_or_default()})
            selected = None
            if recommendations and self._assistant_should_auto_select(recommendations[0]):
                selected = recommendations[0]
                self._record_assistant_event('assistant_auto_selected', action_key=action_key, details={'selected_action': selected.get('action_id') or '', 'selected_reason_code': selected.get('reason_code') or '', 'selected_signal_source': selected.get('signal_source') or '', 'mode': self._assistant_mode_or_default()})
            else:
                selected = next_step_assistant.prompt_for_recommendation(recommendations, self._prompt, print)
        except Exception as rec_exc:
            self._record_assistant_event('assistant_fallback_legacy', action_key=action_key, details={'stage': 'transition_prompt', 'exception_class': rec_exc.__class__.__name__, 'reason_code': 'recommendation_exception', 'mode': self._assistant_mode_or_default(), 'interactive_state': 'interactive', 'action_key': action_key})
            self._log_assistant_event_info('assistant_error', action_key=action_key, details={'status': outcome.get('status') if isinstance(outcome, dict) else ''}, level='WARNING')
            return
        if not selected:
            return
        action_id = selected.get('action_id')
        if action_id and action_id != 'main_menu':
            self._record_assistant_event('suggestion_selected', action_key=action_key, details={'selected_action': action_id, 'selected_reason_code': selected.get('reason_code') or '', 'selected_signal_source': selected.get('signal_source') or ''})
            self._execute_assistant_action(action_id)
            return
        self._record_assistant_event('suggestion_skipped', action_key=action_key, details={'selected_action': action_id or 'none', 'selected_reason_code': selected.get('reason_code') if isinstance(selected, dict) else ''})

    def _prompt(self, message):
        if sys.version_info[0] < 3:
            return raw_input(message)
        return input(message)

    def _clear_console(self):
        command = 'cls' if os.name == 'nt' else 'clear'
        try:
            os.system(command)
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # Feature actions
    # ------------------------------------------------------------------ #
    def run_update_flow(self):
        script_path = self.environment.get('upgrade_medicafe')
        if not script_path or not os.path.exists(script_path):
            self._record_notice('ERROR', 'Update script not found.')
            return
        runner_path = self._build_update_runner(script_path)
        if not runner_path:
            self._record_notice('ERROR', 'Unable to create update runner.')
            return
        print('Launching MediCafe updater in new window...')
        # Use start command to open new console window, similar to CSV processing
        # Format: start "Window Title" cmd /c "runner_path"
        runner_path_quoted = '"{0}"'.format(runner_path)
        cmd_string = 'start "MediCafe Updater" cmd /c {0}'.format(runner_path_quoted)
        subprocess.Popen(cmd_string, shell=True, cwd=self.repo_root)
        time.sleep(0.5)
        self._exit_after_payer_list_join()

    def _build_update_runner(self, script_path):
        """Build temporary batch script to run updater in new window from script's directory."""
        temp_dir = os.environ.get('TEMP') or self.repo_root
        if not os.path.exists(temp_dir):
            try:
                os.makedirs(temp_dir)
            except Exception:
                temp_dir = self.repo_root
        runner = os.path.join(temp_dir, 'medicafe_update_runner_{0}.cmd'.format(os.getpid()))
        try:
            # Quote python_exe to handle paths with spaces
            python_exe_quoted = '"{0}"'.format(self.python_exe)
            script_path_quoted = '"{0}"'.format(script_path)
            batch_path_quoted = '"{0}"'.format(self._batch_path())
            
            # Get script's directory - this is where we'll run from to avoid file locking
            script_dir = os.path.dirname(os.path.abspath(script_path))
            script_dir_quoted = '"{0}"'.format(script_dir)
            
            with open(runner, 'w') as handle:
                handle.write('@echo off\n')
                handle.write('setlocal enabledelayedexpansion\n')
                handle.write('set "MEDIBOT_PATH={0}"\n'.format(batch_path_quoted))
                # Change to script's directory to avoid locking files in package directory
                handle.write('cd /d {0}\n'.format(script_dir_quoted))
                handle.write('ping 127.0.0.1 -n 3 >nul\n')
                # Concern #4: Use resolved python path, not literal 'python'
                handle.write('{0} {1}\n'.format(python_exe_quoted, script_path_quoted))
                handle.write('if errorlevel 1 goto failure\n')
                handle.write('if exist !MEDIBOT_PATH! start "" !MEDIBOT_PATH!\n')
                handle.write('exit /b 0\n')
                handle.write(':failure\n')
                handle.write('echo Update failed. Press any key to close...\n')
                handle.write('pause >nul\n')
                handle.write('exit /b 1\n')
            return runner
        except Exception as exc:
            self._record_notice('ERROR', 'Failed to write runner script: {0}'.format(exc))
            return None

    def download_emails(self):
        rc_download = self.run_medicafe_command('download_emails')
        self._maybe_resolve_queued_reports_after_legacy_gmail_download(rc_download)
        rc_csv = self.process_csvs(silent=True)
        if rc_csv is None:
            rc_csv = 0
        if rc_download != 0:
            return rc_download
        return rc_csv

    def _maybe_resolve_queued_reports_after_legacy_gmail_download(self, rc_download):
        """Only reuse Gmail auth after an explicit legacy MediLink_Gmail/GAS run."""
        if rc_download != 0:
            return
        try:
            from MediCafe.error_reporter import maybe_resolve_queued_bundles_opportunistically
            auto_outcome = maybe_resolve_queued_bundles_opportunistically(
                source='legacy_gmail_download',
            )
        except Exception:
            return
        if isinstance(auto_outcome, dict) and auto_outcome.get('attempted'):
            self._record_notice(
                'INFO',
                'Queued report follow-up attempted after legacy Gmail download (sent={0}, failed={1}).'.format(
                    auto_outcome.get('sent', 0),
                    auto_outcome.get('failed', 0),
                )
            )

    def _run_preflight_if_needed(self, command):
        """Run preflight before local workflows when needed. Returns True to proceed, False to abort."""
        if command not in _LOCAL_WORKFLOW_COMMANDS:
            return True
        cfg = self.environment.get('config_file', '')
        config_path = (os.path.abspath(os.path.join(self.repo_root, cfg)) if cfg and not os.path.isabs(cfg)
                       else (os.path.abspath(cfg) if cfg else ''))
        crosswalk_path = os.path.join(os.path.dirname(config_path), 'crosswalk.json') if config_path else ''
        try:
            config_mtime = os.path.getmtime(config_path) if config_path and os.path.exists(config_path) else None
            crosswalk_mtime = os.path.getmtime(crosswalk_path) if crosswalk_path and os.path.exists(crosswalk_path) else None
        except (OSError, TypeError):
            config_mtime = None
            crosswalk_mtime = None
        inputs = {'config_path': config_path, 'crosswalk_path': crosswalk_path, 'command': command}
        try:
            from MediCafe.preflight import run_preflight, format_preflight_report, should_run_preflight
        except ImportError:
            return True
        if not should_run_preflight(self._preflight_state, inputs):
            return True
        local_storage = self.environment.get('local_storage_path', '')
        source_folder = self.environment.get('source_folder', '')
        target_folder = self.environment.get('target_folder', '')
        if local_storage and not os.path.isabs(local_storage):
            local_storage = os.path.abspath(os.path.join(self.repo_root, local_storage))
        if source_folder and not os.path.isabs(source_folder):
            source_folder = os.path.abspath(os.path.join(self.repo_root, source_folder))
        if target_folder and not os.path.isabs(target_folder):
            target_folder = os.path.abspath(os.path.join(self.repo_root, target_folder))
        context = {
            'config_path': config_path,
            'crosswalk_path': crosswalk_path,
            'local_storage_path': local_storage,
            'source_folder': source_folder,
            'target_folder': target_folder,
        }
        exit_code, report = run_preflight(context)
        self._preflight_state['first_local_workflow'] = False
        self._preflight_state['last_preflight_ok'] = (report['counts']['fail'] == 0)
        self._preflight_state['last_preflight_fail_count'] = report['counts']['fail']
        if self._preflight_state['last_preflight_ok']:
            self._preflight_state['config_mtime'] = config_mtime
            self._preflight_state['crosswalk_mtime'] = crosswalk_mtime
        format_preflight_report(report, compact=True)
        nfail = report['counts']['fail']
        if nfail > 0:
            try:
                is_tty = sys.stdin.isatty() if sys.stdin else False
            except Exception:
                is_tty = False
            non_interactive = getattr(self.session, 'non_interactive', False) or not is_tty
            if non_interactive:
                print('Preflight failed ({0} failure(s)); aborting (non-interactive mode).'.format(nfail))
                return False
            try:
                resp = (self._prompt('Preflight found {0} failure(s). Continue anyway? [y/N]: '.format(nfail)) or 'n').strip().lower()
            except Exception:
                return False
            if resp != 'y' and resp != 'yes':
                return False
        elif report['counts']['warn'] > 0:
            print('Preflight completed with warnings. Proceeding.')
        return True

    def run_medicafe_command(self, command, extra_args=None):
        """Run a MediCafe CLI command. Concern #9: Don't bundle on subprocess failures.

        NOTE FOR NEXT AGENT (2026-01-25): This must use subprocess.call (or Popen without
        capturing streams), not subprocess.run — Python 3.4.x compatibility. If you capture
        stderr (e.g. stderr=PIPE) to log failures, the MediLink subprocess menu can appear
        but the "Enter your choice:" prompt may not show (stdout buffering / TTY). Revert
        to plain subprocess.call for full interactivity if that happens.
        """
        if not self._run_preflight_if_needed(command):
            return 1
        args = [self.python_exe, '-m', 'MediCafe', command]
        if extra_args:
            args.extend(extra_args)
        env = os.environ.copy()
        rc = subprocess.call(args, cwd=self.repo_root, env=env)
        if rc != 0:
            self._record_notice('ERROR', 'Command {0} failed with code {1}'.format(command, rc))
        return rc

    def process_csvs(self, silent=False):
        """Run CSV processing using Python script directly."""
        self._record_notice('INFO', 'Starting CSV processing')
        
        script = os.path.join(self.medibot_dir, 'process_csvs.py')
        if not os.path.exists(script):
            self._record_notice('WARNING', 'process_csvs.py not found at: {0}'.format(script))
            return
        
        config_file = self.environment.get('config_file', '')
        source_folder = self.environment.get('source_folder', '')
        target_folder = self.environment.get('target_folder', '')
        local_storage_path = self.environment.get('local_storage_path', '')
        python_script = self.environment.get('python_script', '')
        
        if not config_file:
            self._record_notice('WARNING', 'CSV processing skipped: config_file not set')
            return
        
        if not source_folder:
            self._record_notice('WARNING', 'CSV processing skipped: source_folder not set')
            return
        
        if not target_folder:
            self._record_notice('WARNING', 'CSV processing skipped: target_folder not set')
            return
        
        self._record_notice('INFO', 'CSV processing config_file: {0}'.format(config_file))
        self._record_notice('INFO', 'CSV processing source_folder: {0}'.format(source_folder))
        self._record_notice('INFO', 'CSV processing target_folder: {0}'.format(target_folder))
        
        # Build command with required arguments
        command = [
            self.python_exe,
            script,
            '--config', config_file,
            '--source-folder', source_folder,
            '--target-folder', target_folder,
        ]
        
        # Add optional arguments if provided
        if local_storage_path:
            command.extend(['--local-storage-path', local_storage_path])
        if python_script:
            command.extend(['--python-script', python_script])
        if silent:
            command.append('--silent')
        
        try:
            proc_env = os.environ.copy()
            if silent:
                proc = subprocess.Popen(
                    command,
                    cwd=self.repo_root,
                    env=proc_env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                stdout, stderr = proc.communicate()
                rc = proc.returncode
                # Ensure subprocess is properly closed
                try:
                    if proc.poll() is None:
                        proc.terminate()
                        proc.wait(timeout=1)
                except Exception:
                    try:
                        proc.kill()
                        proc.wait()
                    except Exception:
                        pass
            else:
                print('CSV processing started...')
                rc = subprocess.call(command, cwd=self.repo_root, env=proc_env)
                stdout = None
                stderr = None
        except Exception as e:
            self._record_notice('WARNING', 'Failed to run CSV processing: {0}'.format(e))
            return 1

        if rc == 0:
            self._record_notice('INFO', 'CSV processing completed successfully')
            if not silent:
                print('CSV processing complete.')
        else:
            self._record_notice('WARNING', 'CSV processing exited with code {0}'.format(rc))
            if not silent:
                print('CSV processing failed. Check logs for details.')
            if stderr:
                stderr_text = stderr.decode('utf-8', errors='replace').strip()
                if stderr_text:
                    # Log error lines
                    stderr_lines = stderr_text.split('\n')
                    for line in stderr_lines[:5]:  # Log first 5 lines of stderr
                        if line.strip() and ('ERROR' in line.upper() or 'WARNING' in line.upper()):
                            self._record_notice('WARNING', 'CSV processing stderr: {0}'.format(line.strip()[:200]))
        return rc

    def _open_phase_b_summary(self):
        """View latest artifact discovery summary (txt or json)."""
        if cloud_readiness is None:
            return
        ok, msg, path = cloud_readiness.open_phase_b_summary(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _open_phase_b_manifest_location(self):
        """Open latest manifest location in explorer or print path."""
        if cloud_readiness is None:
            return
        ok, msg, path = cloud_readiness.open_manifest_location(self.repo_root)
        if ok and path:
            print('Manifest location: {0}'.format(os.path.dirname(path)))
            if os.name == 'nt':
                try:
                    subprocess.Popen(['explorer.exe', '/select,' + path])
                except Exception:
                    subprocess.Popen(['explorer.exe', os.path.dirname(path)])
        elif msg:
            print(msg)

    def _run_phase_b_discovery_manual(self):
        """Trigger manual discovery run (non-blocking subprocess)."""
        if cloud_readiness is None:
            return False
        ok, msg, _ = cloud_readiness.run_phase_b_manual(
            self.repo_root, self.python_exe, self.environment)
        if ok:
            print('Discovery started in background.')
            return True
        if msg:
            print(msg)
        return False

    def _send_phase_b_evidence(self):
        """Send latest discovery evidence via support bundle."""
        if cloud_readiness is None:
            return
        ok, msg, _ = cloud_readiness.send_phase_b_evidence(self.repo_root)
        if msg:
            print(msg)

    def _open_phase_c_summary(self):
        """View latest Phase C ingest summary (txt or json)."""
        if cloud_readiness is None:
            return
        ok, msg, path = cloud_readiness.open_phase_c_summary(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _run_phase_c_ingest_manual(self):
        """Trigger manual Phase C ingest run (non-blocking subprocess)."""
        if cloud_readiness is None:
            return False
        ok, msg, _ = cloud_readiness.run_phase_c_manual(
            self.repo_root, self.python_exe, self.environment)
        if ok:
            print('Phase C ingest started in background.')
            return True
        if msg:
            print(msg)
        return False

    def _send_phase_c_evidence(self):
        """Send latest Phase C evidence via support bundle."""
        if cloud_readiness is None:
            return
        ok, msg, _ = cloud_readiness.send_phase_c_evidence(self.repo_root)
        if msg:
            print(msg)

    def _run_shadow_pipeline(self):
        """Run XP shadow pipeline (A->B->C->D->E->F) in background."""
        if cloud_readiness is None:
            return False
        ok, msg, _ = cloud_readiness.run_shadow_pipeline(
            self.repo_root, self.python_exe, self.environment)
        if not ok and msg:
            self._record_notice('WARNING', msg)
            return False
        if ok:
            print('Shadow pipeline orchestration accepted.')
            return True
        return False

    def _open_phase_d_summary(self):
        """View latest Phase D QA summary (txt or json)."""
        if cloud_readiness is None:
            return
        ok, msg, path = cloud_readiness.open_phase_d_summary(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _run_phase_d_manual(self):
        """Trigger manual Phase D run (non-blocking subprocess)."""
        if cloud_readiness is None:
            return False
        ok, msg, _ = cloud_readiness.run_phase_d_manual(
            self.repo_root, self.python_exe, self.environment)
        if ok:
            print('Phase D QA started in background.')
            return True
        if msg:
            print(msg)
        return False

    def _open_phase_d_reject_sample(self):
        """View latest Phase D reject sample file."""
        if cloud_readiness is None:
            return
        ok, msg, path = cloud_readiness.open_phase_d_reject_sample(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _send_phase_d_evidence(self):
        """Send latest Phase D evidence via support bundle."""
        if cloud_readiness is None:
            return
        ok, msg, _ = cloud_readiness.send_phase_d_evidence(self.repo_root)
        if msg:
            print(msg)

    def _open_phase_e_summary(self):
        """View latest Phase E projection/parity summary (txt or json)."""
        if cloud_readiness is None:
            return
        ok, msg, path = cloud_readiness.open_phase_e_summary(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _run_phase_e_manual(self):
        """Trigger manual Phase E run (non-blocking subprocess)."""
        if cloud_readiness is None:
            return False
        ok, msg, _ = cloud_readiness.run_phase_e_manual(
            self.repo_root, self.python_exe, self.environment)
        if ok:
            print('Phase E projection/parity started in background.')
            return True
        if msg:
            print(msg)
        return False

    def _open_phase_e_deviation_samples(self):
        """View latest Phase E deviation sample file."""
        if cloud_readiness is None:
            return
        ok, msg, path = cloud_readiness.open_phase_e_deviation_samples(self.repo_root)
        if ok and path:
            print('Opening: {0}'.format(path))
            self._launch_viewer(path)
        elif msg:
            print(msg)

    def _send_phase_e_evidence(self):
        """Send latest Phase E evidence via support bundle."""
        if cloud_readiness is None:
            return
        ok, msg, _ = cloud_readiness.send_phase_e_evidence(self.repo_root)
        if msg:
            print(msg)

    # Cloud Readiness menu/actions moved to LauncherCloudReadinessMixin.

    def _run_download_migration(self):
        """Run browser downloads migration using Python script directly."""
        self._record_notice('INFO', 'Starting browser downloads migration')
        
        script = os.path.join(self.medibot_dir, 'migrate_browser_downloads.py')
        if not os.path.exists(script):
            self._record_notice('WARNING', 'migrate_browser_downloads.py not found at: {0}'.format(script))
            return
        
        config_file = self.environment.get('config_file', '')
        source_folder = self.environment.get('source_folder', '')
        
        if not config_file:
            self._record_notice('WARNING', 'Migration skipped: config_file not set')
            return
        
        if not source_folder:
            self._record_notice('WARNING', 'Migration skipped: source_folder not set')
            return
        
        self._record_notice('INFO', 'Migration config_file: {0}'.format(config_file))
        self._record_notice('INFO', 'Migration source_folder: {0}'.format(source_folder))
        
        # Call Python script directly with --execute and --silent flags
        command = [
            self.python_exe,
            script,
            '--config', config_file,
            '--source-folder', source_folder,
            '--execute',
            '--silent'
        ]
        
        try:
            proc_env = os.environ.copy()
            proc = subprocess.Popen(
                command,
                cwd=self.repo_root,
                env=proc_env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout, stderr = proc.communicate()
            rc = proc.returncode
            # Ensure subprocess is properly closed
            try:
                if proc.poll() is None:
                    proc.terminate()
                    proc.wait(timeout=1)
            except Exception:
                try:
                    proc.kill()
                    proc.wait()
                except Exception:
                    pass
            
            if rc == 0:
                # Log success - check stdout for summary if available
                if stdout:
                    stdout_text = stdout.decode('utf-8', errors='replace').strip()
                    # Look for summary line in silent mode output
                    found_summary = False
                    for line in stdout_text.split('\n'):
                        if '[INFO] Browser downloads:' in line:
                            self._record_notice('INFO', line.strip())
                            found_summary = True
                            break
                    if not found_summary:
                        self._record_notice('INFO', 'Browser downloads migration completed successfully (no files processed)')
                else:
                    self._record_notice('INFO', 'Browser downloads migration completed successfully')
            else:
                self._record_notice('WARNING', 'Browser downloads migration exited with code {0}'.format(rc))
                if stderr:
                    stderr_text = stderr.decode('utf-8', errors='replace').strip()
                    if stderr_text:
                        # Log error lines
                        stderr_lines = stderr_text.split('\n')
                        for line in stderr_lines[:5]:  # Log first 5 lines of stderr
                            if line.strip() and ('ERROR' in line.upper() or 'WARNING' in line.upper()):
                                self._record_notice('WARNING', 'Migration stderr: {0}'.format(line.strip()[:200]))
        except Exception as e:
            self._record_notice('WARNING', 'Failed to run browser downloads migration: {0}'.format(e))

    def _launch_startup_csv(self):
        """Launch CSV processing in background. Concern #7: Visibility is acceptable parity."""
        script = os.path.join(self.medibot_dir, 'process_csvs.py')
        if not os.path.exists(script):
            self._record_notice('WARNING', 'process_csvs.py not found.')
            return
        if os.name != 'nt':
            self._record_notice('INFO', 'Non-Windows platform: running CSV inline.')
            self.process_csvs(silent=True)
            return
        try:
            config_file = self.environment.get('config_file', '')
            source_folder = self.environment.get('source_folder', '')
            target_folder = self.environment.get('target_folder', '')
            local_storage_path = self.environment.get('local_storage_path', '')
            python_script = self.environment.get('python_script', '')
            
            # Validate required variables
            if not config_file or not source_folder or not target_folder:
                self._record_notice('WARNING', 'Background CSV: Missing required environment variables')
                return
            
            self._record_notice('INFO', 'Launching background CSV processing')
            
            # Build command with required arguments
            command = [
                self.python_exe,
                script,
                '--config', config_file,
                '--source-folder', source_folder,
                '--target-folder', target_folder,
                '--silent'
            ]
            
            # Add optional arguments if provided
            if local_storage_path:
                command.extend(['--local-storage-path', local_storage_path])
            if python_script:
                command.extend(['--python-script', python_script])
            
            # Launch as background process in a separate minimized console window
            # This allows users to observe CSV processing progress by opening the window
            # Use start /MIN to create a minimized window that doesn't interfere with main menu
            proc_env = os.environ.copy()
            if os.name == 'nt':
                # Build properly quoted command string for start /MIN
                # For start command: start "Window Title" /MIN executable args...
                # We need to quote all paths/arguments to handle spaces properly
                quoted_command_parts = []
                for arg in command:
                    # Escape any existing quotes and wrap in quotes
                    # This ensures paths with spaces work correctly
                    escaped_arg = arg.replace('"', '""')
                    quoted_command_parts.append('"{0}"'.format(escaped_arg))
                
                # Use start /MIN to create a separate minimized console window
                # Format: start "Window Title" /MIN "python.exe" "script.py" "arg1" "arg2" ...
                cmd_string = 'start "CSV Processing" /MIN {0}'.format(' '.join(quoted_command_parts))
                
                subprocess.Popen(
                    cmd_string,
                    shell=True,
                    cwd=self.repo_root,
                    env=proc_env
                )
            else:
                # Non-Windows: run in background without window
                subprocess.Popen(
                    command,
                    cwd=self.repo_root,
                    env=proc_env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
        except Exception as e:
            self._record_notice('WARNING', 'Failed to start CSV background process: {0}. Running inline.'.format(e))
            self.process_csvs(silent=True)

    def _show_timing_summary(self):
        """Display timing summary to console. No-op if no data or helpers unavailable."""
        if not get_storage_path or not load_recent_events or not compute_summary:
            return
        storage_dir = get_storage_path(env_local_storage=self.environment.get('local_storage_path'), repo_root=self.repo_root)
        path = os.path.join(storage_dir, 'timing_history.jsonl')
        if not os.path.exists(path):
            print('(No timing data. Enable performance logging (option 5) and run MediLink/MediBot to collect.)')
            return
        events = load_recent_events(storage_path=storage_dir, limit=200)
        if not events:
            print('(Timing history empty.)')
            return
        summary = compute_summary(events)
        regression = {}
        for wf in ['medilink', 'launcher', 'medibot']:
            if compute_regression:
                delta, baseline = compute_regression(summary, wf, baseline_runs=5)
                if delta is not None:
                    regression[wf] = (delta, baseline)
        if format_summary_for_display:
            for line in format_summary_for_display(summary, regression):
                print(line)

    def open_latest_log(self):
        self._show_timing_summary()
        logs_dir = self.environment.get('local_storage_path')
        if not logs_dir:
            print('Log directory unknown.')
            return
        logs_dir = self._make_absolute(logs_dir)
        if not os.path.exists(logs_dir):
            print('Log directory missing: {0}'.format(logs_dir))
            return
        log_files = []
        for item in os.listdir(logs_dir):
            if item.startswith('Log_') and item.lower().endswith('.log'):
                log_files.append(os.path.join(logs_dir, item))
        if not log_files:
            # Fallback: use any .log file if MediCafe log naming not found
            for item in os.listdir(logs_dir):
                if item.lower().endswith('.log'):
                    log_files.append(os.path.join(logs_dir, item))
            if log_files:
                print('No Log_*.log files found; using most recent .log file instead.')
        latest = None
        if log_files:
            latest = max(log_files, key=os.path.getmtime)
        if not latest:
            print('No log files found in {0}'.format(logs_dir))
            return
        print('Opening log: {0}'.format(latest))
        self._launch_viewer(latest)

    def open_winscp_logs(self):
        base = self.environment.get('local_storage_path')
        if not base:
            return
        base = self._make_absolute(base)
        download = os.path.join(base, 'winscp_download.log')
        upload = os.path.join(base, 'winscp_upload.log')
        opened = False
        for path in [download, upload]:
            if os.path.exists(path):
                self._launch_viewer(path)
                opened = True
        if not opened:
            print('No WinSCP logs found at {0}'.format(base))

    def clear_cache_menu(self):
        print('')
        print('1. Quick clear (compileall + delete __pycache__)')
        print('2. Deep clear (update_medicafe.py)')
        print('0. Back')
        choice = (self._prompt('Choice: ') or '').strip()
        if choice == '1':
            self._run_cache_clear_quick()
        elif choice == '2':
            self._run_cache_clear_deep()
        elif choice in ('0', '3'):
            return
        else:
            print('Invalid choice.')

    def force_gmail_reauth(self):
        if clear_gmail_token_cache and resolve_token_path:
            try:
                token_path = resolve_token_path()
                clear_gmail_token_cache()
                if token_path and os.path.exists(token_path):
                    print('[WARN] Token file still present: {0}'.format(token_path))
                else:
                    print('[OK] Gmail token cache cleared.')
                return
            except Exception as exc:
                print('[WARN] Gmail token clear failed: {0}'.format(exc))
        candidates = [
            os.path.join(self.repo_root, 'MediLink', 'token.json'),
            os.path.join(self.repo_root, 'token.json')
        ]
        cleared = False
        for path in candidates:
            if os.path.exists(path):
                try:
                    os.remove(path)
                    print('[OK] Removed {0}'.format(path))
                    cleared = True
                except Exception as exc:
                    print('[WARN] Could not remove {0}: {1}'.format(path, exc))
        if not cleared:
            print('No Gmail tokens found to remove.')

    def toggle_session_flag(self, env_var):
        current = os.environ.get(env_var, '0')
        new_value = '0' if current == '1' else '1'
        os.environ[env_var] = new_value
        print('{0} set to {1} for this session.'.format(env_var, new_value))
        self._reload_logging_config()

    def toggle_verbose_logging(self):
        current = os.environ.get('MEDICAFE_DEBUG', '0')
        new_value = '0' if current == '1' else '1'
        os.environ['MEDICAFE_DEBUG'] = new_value
        os.environ['MEDICAFE_CONSOLE_LOGGING'] = new_value
        print('Verbose logging set to {0} for this session.'.format(new_value))
        self._reload_logging_config()

    def _reload_logging_config(self):
        try:
            from MediCafe import logging_config
            if hasattr(logging_config, 'reload_logging_config'):
                logging_config.reload_logging_config()
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    # Rollback + error handling
    # ------------------------------------------------------------------ #
    def forced_version_rollback(self, version='0.251120.0'):
        package = self.environment.get('medicafe_package', 'medicafe')
        target = '{0}=={1}'.format(package, version)
        print('Forcing reinstall of {0}'.format(target))
        rc = subprocess.call([self.python_exe, '-m', 'pip', 'install',
                              '--no-deps', '--force-reinstall', target], cwd=self.repo_root)
        if rc != 0:
            print('force-reinstall not supported, attempting uninstall/install fallback.')
            subprocess.call([self.python_exe, '-m', 'pip', 'uninstall', '-y', package], cwd=self.repo_root)
            rc = subprocess.call([self.python_exe, '-m', 'pip', 'install', '--no-deps', target], cwd=self.repo_root)
        if rc == 0:
            print('Rollback complete.')
        else:
            print('Rollback failed. Check logs for details.')

    def handle_fatal_error(self, exc):
        """Handle fatal orchestrator errors. Concern #9: Only bundle orchestrator exceptions."""
        print('=' * 60)
        print('MEDICAFE ORCHESTRATOR FAILURE')
        print('=' * 60)
        if isinstance(exc, LauncherConfigError):
            print('Configuration error: {0}'.format(exc))
            print('Please update your config file path or restore the expected file.')
        else:
            print('Error: {0}'.format(exc))
        print('=' * 60)
        context = self._build_bundle_context(exc)
        self.failure_bundle_path = self._collect_error_bundle(context)
        print('Choose how to proceed:')
        print('1. Attempt rollback')
        print('0. Exit without changes')
        choice = (self._prompt('Selection: ') or '').strip()
        if choice == '1':
            self.forced_version_rollback()
        else:
            print('Exiting without rollback.')

    def _collect_error_bundle(self, context):
        """Collect error bundle for orchestrator failures only."""
        bundle = self.bundle_coordinator.collect_once(context)
        if not bundle:
            return None
        print('Error bundle available at {0}'.format(bundle))
        if submit_support_bundle_email and check_internet_connection:
            try:
                if check_internet_connection():
                    sent = submit_support_bundle_email(bundle)
                    if sent:
                        os.remove(bundle)
                    else:
                        print('Bundle send failed; file retained.')
            except Exception:
                print('Bundle transmission error; file retained.')
        return bundle

    def _build_bundle_context(self, exc):
        """Assemble structured metadata for the error bundle."""
        try:
            session_info = {
                'skip_startup_csv': bool(self.session.skip_startup_csv),
                'direct_action': self.session.direct_action,
                'debug_mode': bool(self.session.debug_mode),
                'auto_choice_source': self.session.auto_menu_source,
            }
        except Exception:
            session_info = {}
        env_snapshot = {
            'config_file': self.environment.get('config_file'),
            'local_storage_path': self.environment.get('local_storage_path'),
            'temp_file': self.environment.get('temp_file'),
            'upgrade_script': self.environment.get('upgrade_medicafe'),
            'repo_root': self.repo_root,
        }
        launcher_state = {
            'medicafe_version': self.medicafe_version,
            'update_available_version': self.update_available_version,
            'python_executable': sys.executable,
            'cwd': os.getcwd(),
            'time': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        }
        notices = ['[{0}] {1}'.format(level, msg) for level, msg in self.startup_notices]
        context = {
            'exception_type': exc.__class__.__name__,
            'exception_message': str(exc),
            'session': session_info,
            'environment': env_snapshot,
            'launcher_state': launcher_state,
            'startup_notices': notices
        }
        return context

    # ------------------------------------------------------------------ #
    # Utility helpers
    # ------------------------------------------------------------------ #
    def _batch_path(self):
        """Get path to MediBot.bat file."""
        return os.path.join(self.medibot_dir, 'MediBot.bat')

    def _call_batch(self, script_name, args, interactive=False):
        """Call a batch script. Concern #2: Quote paths for spaces."""
        script = os.path.join(self.medibot_dir, script_name)
        if not os.path.exists(script):
            self._record_notice('WARNING', '{0} not found.'.format(script_name))
            return
        # Quote script path so cmd.exe treats it as a single argument even with spaces.
        script_quoted = '"{0}"'.format(script)
        command = [self.cmd_exe, '/c', 'call', script_quoted]
        if args:
            command.extend(args)
        
        # Build environment with required variables for batch scripts
        # These variables are expected by process_csvs.py
        env = os.environ.copy()
        config_file = self.environment.get('config_file', '')
        batch_env_vars = {
            'source_folder': self.environment.get('source_folder', ''),
            'target_folder': self.environment.get('target_folder', ''),
            'config_file': config_file,
            'python_script': self.environment.get('python_script', ''),
            'local_storage_path': self.environment.get('local_storage_path', ''),
            'MEDICAFE_PYTHON': self.python_exe,
        }
        if config_file:
            batch_env_vars['MEDICAFE_CONFIG_FILE'] = self._make_absolute(config_file)
        env.update(batch_env_vars)
        
        # Log batch script invocation for debugging (INFO level)
        self._log_batch_invocation(script_name, batch_env_vars, args)
        
        try:
            if interactive:
                rc = subprocess.call(
                    command,
                    cwd=self.repo_root,
                    env=env
                )
                if rc != 0:
                    self._record_notice('WARNING', 'Batch script {0} exited with code {1}'.format(script_name, rc))
            else:
                proc = subprocess.Popen(
                    command,
                    cwd=self.repo_root,
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                stdout, stderr = proc.communicate()
                rc = proc.returncode
                # Ensure subprocess is properly closed
                try:
                    if proc.poll() is None:
                        proc.terminate()
                        proc.wait(timeout=1)
                except Exception:
                    try:
                        proc.kill()
                        proc.wait()
                    except Exception:
                        pass
                
                # Log results based on exit code
                if rc != 0:
                    self._record_notice('WARNING', 'Batch script {0} exited with code {1}'.format(script_name, rc))
                    if stderr:
                        stderr_text = stderr.decode('utf-8', errors='replace').strip()
                        if stderr_text:
                            # Log full stderr for debugging (split into multiple notices if needed)
                            stderr_lines = stderr_text.split('\n')
                            for line in stderr_lines[:10]:  # Log first 10 lines of stderr
                                if line.strip():
                                    self._record_notice('WARNING', 'Batch stderr: {0}'.format(line.strip()[:200]))
                            if len(stderr_lines) > 10:
                                self._record_notice('WARNING', 'Batch stderr: ... ({0} more lines)'.format(len(stderr_lines) - 10))
                    if stdout:
                        stdout_text = stdout.decode('utf-8', errors='replace').strip()
                        # Check for common error patterns in stdout
                        if 'cannot find' in stdout_text.lower() or 'error' in stdout_text.lower() or '[error]' in stdout_text.lower() or '[debug]' in stdout_text.lower():
                            stdout_lines = stdout_text.split('\n')
                            for line in stdout_lines[:10]:  # Log first 10 lines of relevant stdout
                                line_lower = line.lower()
                                if 'cannot find' in line_lower or 'error' in line_lower or '[error]' in line_lower or '[debug]' in line_lower:
                                    self._record_notice('WARNING', 'Batch stdout: {0}'.format(line.strip()[:200]))
        except Exception as e:
            self._record_notice('ERROR', 'Failed to execute batch script {0}: {1}'.format(script_name, e))
    
    def _log_batch_invocation(self, script_name, env_vars, args):
        """Log batch script invocation details for debugging."""
        # Check for potentially problematic empty variables
        empty_vars = [k for k, v in env_vars.items() if not v]
        if empty_vars:
            self._record_notice('WARNING', 'Batch {0}: Empty environment variables: {1}'.format(
                script_name, ', '.join(empty_vars)))
        
        # Log at INFO level for normal operation tracking
        self._record_notice('INFO', 'Invoking batch: {0} with args: {1}'.format(
            script_name, args if args else '(none)'))

    def _make_absolute(self, path_value):
        """Convert relative path to absolute using repo_root."""
        if os.path.isabs(path_value):
            return path_value
        return os.path.abspath(os.path.join(self.repo_root, path_value))

    def _run_python_script_with_config(self, script_basename, notice_label):
        """Run a MediBot Python script that takes config path. Bypasses batch for troubleshooting."""
        config_path = self._make_absolute(
            self.environment.get('config_file', os.path.join('json', 'config.json')))
        script = os.path.join(self.medibot_dir, script_basename)
        if not os.path.exists(script):
            self._record_notice('WARNING', '{0} not found.'.format(script_basename))
            return
        try:
            rc = subprocess.call(
                [self.python_exe, script, config_path],
                cwd=self.repo_root
            )
            if rc != 0:
                self._record_notice('WARNING', '{0} exited with code {1}'.format(notice_label, rc))
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass
        except Exception as e:
            self._record_notice('ERROR', 'Failed to run {0}: {1}'.format(notice_label.lower(), e))
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _run_config_editor(self):
        """Run the config editor via Python directly (bypass batch)."""
        self._run_python_script_with_config('config_editor.py', 'Config editor')

    def _run_client_secret_update(self):
        """Run the client secret updater via Python directly (bypass batch)."""
        self._run_python_script_with_config('client_secret_update.py', 'Client secret updater')

    def _run_token_self_test(self):
        """Run the API token self-test via Python directly (manual troubleshooting utility)."""
        self._run_python_script_with_config('token_self_test.py', 'Token self-test')

    def _run_docx_index_rebuild(self):
        """Force rebuild the DOCX schedule index via MediCafe CLI."""
        try:
            rc = self.run_medicafe_command('docx_index_rebuild')
            if rc != 0:
                self._record_notice('WARNING', 'DOCX index rebuild exited with code {0}'.format(rc))
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass
        except Exception as e:
            self._record_notice('ERROR', 'Failed to rebuild DOCX index: {0}'.format(e))
            try:
                self._prompt('Press Enter to return to menu...')
            except Exception:
                pass

    def _run_cache_clear_quick(self):
        """Quick clear: compileall + delete __pycache__. Bypasses clear_cache.bat."""
        print('Quick clearing Python cache...')
        try:
            rc = subprocess.call(
                [self.python_exe, '-Bc', 'import compileall; compileall.compile_dir(".", force=True)'],
                cwd=self.repo_root
            )
            if rc != 0:
                self._record_notice('WARNING', 'compileall returned {0}'.format(rc))
            removed = 0
            for root, dirs, _ in os.walk(self.repo_root, topdown=False):
                for d in dirs:
                    if d == '__pycache__':
                        path = os.path.join(root, d)
                        if not os.path.exists(path):
                            continue
                        try:
                            shutil.rmtree(path)
                            removed += 1
                        except Exception as e:
                            self._record_notice('WARNING', 'Could not remove {0}: {1}'.format(path, e))
            print('[OK] Quick cache clear complete.')
        except Exception as e:
            self._record_notice('ERROR', 'Quick cache clear failed: {0}'.format(e))

    def _run_cache_clear_deep(self):
        """Deep clear: run update_medicafe.py --clear-cache. Bypasses clear_cache.bat."""
        upgrade = self.environment.get('upgrade_medicafe')
        if not upgrade or not os.path.exists(upgrade):
            print('ERROR: update_medicafe.py not found (F: or local).')
            return
        print('Deep cache clear (via update_medicafe.py)...')
        print('Workspace root: {0}'.format(self.repo_root))
        print('')
        try:
            rc = subprocess.call(
                [self.python_exe, upgrade, '--clear-cache', self.repo_root],
                cwd=self.repo_root
            )
            if rc != 0:
                self._record_notice('WARNING', 'Deep cache clear exited with code {0}'.format(rc))
        except Exception as e:
            self._record_notice('ERROR', 'Deep cache clear failed: {0}'.format(e))

    def _launch_viewer(self, path):
        """Launch default text viewer for a file."""
        if os.name != 'nt':
            print('File: {0}'.format(path))
            return
        try:
            subprocess.Popen(['notepad.exe', path])
        except Exception:
            subprocess.Popen(['write.exe', path])

    # ------------------------------------------------------------------ #
    # Console rendering helpers (legacy ASCII parity)
    # ------------------------------------------------------------------ #
    def _print_legacy_banner(self, title, width=39):
        line = '=' * width
        print(line)
        print(title.center(width))
        print(line)
        print('')

    def _print_welcome_block(self):
        width = 62
        separator = '-' * width
        welcome = './/*  Welcome to MediCafe  *\\\\.'
        print(separator)
        print(welcome.center(width))
        print(separator)
        print('')

    def _print_version_details(self):
        print('Version: {0}'.format(self.medicafe_version or 'unknown'))
        if self.update_available_version:
            print('[UPDATE AVAILABLE] {0}'.format(self.update_available_version))
        # Only show WARNING and ERROR notices - INFO messages go to log file only
        warning_notices = [(level, msg) for level, msg in self.startup_notices if level in ('WARNING', 'ERROR')]
        if warning_notices:
            print('')
            for level, msg in warning_notices:
                print('[{0}] {1}'.format(level, msg))
            print('-' * 60)
        print('')

    def _print_main_menu_options(self):
        options = [
            ('1', 'Update MediCafe'),
            ('2', 'Download Email de Carol'),
            ('3', 'MediLink Claims'),
            ('4', '[United] Claims Status'),
            ('5', '[United] Deductible'),
            ('6', 'Run MediBot'),
            ('7', 'Troubleshooting'),
            ('0', 'Exit'),
        ]
        print('Please select an option:')
        print('')
        for number, label in options:
            print(' {0}. {1}'.format(number, label))
            print('')

    def _get_menu_choice(self):
        if self.session.auto_menu_choice:
            choice = self.session.auto_menu_choice
            source = self.session.auto_menu_source or 'CLI'
            print('[AUTO source={0}] Using menu choice {1}'.format(source, choice))
            self.session.auto_menu_choice = None
            self.session.auto_menu_source = None
            return (choice or '').strip()
        return (self._prompt('Enter your choice: ') or '').strip()

    def _print_troubleshooting_group(self, heading, lines):
        print(heading)
        for entry in lines:
            print('  {0}'.format(entry))
        print('')


def main():
    """Main entry point for launcher."""
    # Minimal early feedback before any heavy imports or orchestrator.
    # This line is cleared by run()/_clear_console() before the legacy banner, so default UX is unchanged.
    print('Starting MediCafe Launcher...')

    # Log launcher initiation as early as possible (centralized logger; may be slow)
    try:
        from MediCafe.MediLink_ConfigLoader import log as config_log
        config_log("MediCafe launcher starting", level="INFO")
    except Exception:
        # If logging initialization fails, continue anyway
        pass

    parser = build_arg_parser()
    try:
        args, unknown = parser.parse_known_args(sys.argv[1:])
    except LauncherArgumentError as err:
        print('')
        print('[LAUNCHER] Invalid option: {0}'.format(err))
        print('Please review the supported flags below and try again.')
        print('')
        parser.print_help()
        return 2
    if unknown:
        print('')
        print('[LAUNCHER] Ignoring unsupported option(s): {0}'.format(', '.join(unknown)))
        print('         Use --help for the list of accepted flags.')
        print('')
    session = SessionConfig(args)
    orchestrator = MediCafeOrchestrator(session)
    return orchestrator.run()


if __name__ == '__main__':
    sys.exit(main())
