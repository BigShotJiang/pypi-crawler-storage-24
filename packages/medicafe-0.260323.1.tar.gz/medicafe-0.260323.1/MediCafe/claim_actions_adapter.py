# MediCafe/claim_actions_adapter.py
"""
Claim Actions Adapter for OPTUMAI

Thin orchestrator that uses GraphQL builders from graphql_utils.py and
centralized headers from api_core.py to submit claims via OPTUMAI Claim Actions API.

Compatible with Python 3.4.4 and Windows XP environments.
"""

import os
import sys
import json

# Set project directory
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Import configuration loader
try:
    from MediCafe.core_utils import get_shared_config_loader
    MediLink_ConfigLoader = get_shared_config_loader()
except ImportError:
    try:
        from MediCafe.MediLink_ConfigLoader import MediLink_ConfigLoader
    except ImportError:
        # Fallback - create minimal logger
        class MinimalLogger:
            def log(self, msg, level="INFO", console_output=False):
                if console_output:
                    print("[{}] {}".format(level, msg))
        MediLink_ConfigLoader = MinimalLogger()

# Import GraphQL utilities
try:
    from MediCafe import graphql_utils as MediLink_GraphQL
except ImportError:
    MediLink_GraphQL = None

# Import header builder and routing
try:
    from MediCafe.api_core import build_optumai_headers, resolve_operation_route
except ImportError:
    build_optumai_headers = None
    resolve_operation_route = None

# Import core utilities
try:
    from MediCafe.core_utils import extract_medilink_config
except ImportError:
    extract_medilink_config = None

# OPTUMAI success status codes (shared with api_core for retry and 277CA success checks)
OPTUMAI_SUCCESS_STATUS_CODES = ('000', '200')


def has_optumai_accepted_999_ack(response):
    """
    Return True when the submission payload contains a syntactically accepted 999 ACK.

    We treat IK5*A + AK9*A as an accepted 999 envelope, even if no transactionId was
    returned by the gateway.
    """
    if not isinstance(response, dict):
        return False

    x12 = str(response.get('x12ResponseData') or '')
    if not x12:
        return False

    x12_upper = x12.upper()
    return ('~IK5*A~' in x12_upper) and ('~AK9*A' in x12_upper)


def is_optumai_submit_pending_ack(response):
    """
    Return True for asynchronous accepted submissions awaiting ACK.

    Policy:
    - statusCode/statuscode == 202

    Note: API partners confirmed some 202 responses can be emitted by a gateway
    glitch even after the claim is already accepted for processing. To avoid
    duplicate submissions, we conservatively treat all 202 responses as
    pending/accepted submission state regardless of transactionId presence.
    """
    if not isinstance(response, dict):
        return False

    statuscode = str(response.get('statuscode') or response.get('statusCode') or '').strip()
    if statuscode != '202':
        return False
    return True


def is_optumai_submit_retriable_failure(response):
    """
    Return True when an OPTUMAI claim-submission response should be retried/fallback-eligible.

    Current policy:
    - Always retriable: 930, 500, 502, 503, 504
    - Never retriable for 202: partner confirmed these may still be accepted
      submissions despite inconsistent gateway messaging.
    """
    if not isinstance(response, dict):
        return False

    statuscode = str(response.get('statuscode') or response.get('statusCode') or '').strip()
    if statuscode in ('930', '500', '502', '503', '504'):
        return True

    if statuscode == '202':
        return False

    return False


def is_optumai_submit_duplicate_signal(response):
    """
    Return True when the submit response indicates duplicate/already-submitted claim semantics.

    This is used as a guardrail to prevent unnecessary re-submission via fallback endpoints
    when OPTUMAI indicates the claim may already be in-flight or accepted.
    """
    if not isinstance(response, dict):
        return False

    statuscode = str(response.get('statuscode') or response.get('statusCode') or '').strip()
    message = str(response.get('message') or '').strip().lower()

    duplicate_tokens = (
        'duplicate',
        'already submitted',
        'already exists',
        'previously submitted',
        'claim already',
    )

    if any(token in message for token in duplicate_tokens):
        return True

    # Some gateways surface duplicate semantics with provider-specific 6xx-style statuses.
    if statuscode.startswith('6') and ('duplicate' in message or 'already' in message):
        return True

    return False


def _normalize_optumai_path(path):
    """
    Normalize OPTUMAI API path to ensure consistent format.
    
    Ensures the path matches the successful configuration format:
    - Strips whitespace
    - Ensures leading '/'
    - Removes trailing '/'
    
    Args:
        path (str): Raw path from configuration
    
    Returns:
        str: Normalized path (e.g., '/oihub/claim/actions/v1')
    """
    if not path:
        return path
    
    # Strip whitespace
    normalized = path.strip()
    
    # Ensure leading slash
    if not normalized.startswith('/'):
        normalized = '/' + normalized
    
    # Remove trailing slash (CRITICAL for OPTUMAI gateway routing)
    normalized = normalized.rstrip('/')
    
    return normalized


def _validate_optumai_config(optumai_cfg, required_endpoint=None):
    """
    Validate OPTUMAI configuration matches the successful format.
    
    Checks:
    - api_url is set and matches expected base URL
    - submission_method is set to "api"
    - Required endpoint path exists and normalizes to expected format
    - claim_actions path normalizes to '/oihub/claim/actions/v1'
    - claims_inquiry path normalizes to '/oihub/claim/inquiry/v1'
    
    Args:
        optumai_cfg (dict): OPTUMAI endpoint configuration
        required_endpoint (str, optional): 'claim_actions' or 'claims_inquiry' to validate specific endpoint
    
    Returns:
        tuple: (is_valid: bool, error_message: str or None, normalized_paths: dict or None)
            normalized_paths dict includes:
            - 'api_url': normalized base URL (trailing slash removed)
            - 'claim_actions': normalized claim_actions path (if configured)
            - 'claims_inquiry': normalized claims_inquiry path (if configured)
    """
    if not optumai_cfg or not isinstance(optumai_cfg, dict):
        return False, "OPTUMAI configuration is missing or invalid", None
    
    # Check api_url
    api_url = optumai_cfg.get('api_url')
    if not api_url:
        return False, "OPTUMAI api_url is not configured", None
    
    # Normalize api_url for comparison (remove trailing slash)
    api_url_normalized = api_url.rstrip('/')
    expected_base_url = 'https://apigw.optum.com'
    if api_url_normalized != expected_base_url:
        return False, "OPTUMAI api_url '{}' does not match expected '{}'".format(api_url, expected_base_url), None
    
    # Check submission_method
    submission_method = optumai_cfg.get('submission_method')
    if submission_method != 'api':
        return False, "OPTUMAI submission_method must be 'api' (found: '{}')".format(submission_method), None
    
    # Get additional_endpoints
    optumai_additional = optumai_cfg.get('additional_endpoints', {})
    if not isinstance(optumai_additional, dict):
        return False, "OPTUMAI additional_endpoints is missing or invalid", None
    
    # Normalize and validate paths
    normalized_paths = {}
    
    # Validate claim_actions path
    claim_actions_path = optumai_additional.get('claim_actions')
    if claim_actions_path:
        normalized_claim_actions = _normalize_optumai_path(claim_actions_path)
        normalized_paths['claim_actions'] = normalized_claim_actions
        if normalized_claim_actions != '/oihub/claim/actions/v1':
            return False, "OPTUMAI claim_actions path '{}' does not normalize to expected '/oihub/claim/actions/v1'".format(claim_actions_path), None
    elif required_endpoint == 'claim_actions':
        return False, "OPTUMAI claim_actions endpoint not configured", None
    
    # Validate claims_inquiry path
    claims_inquiry_path = optumai_additional.get('claims_inquiry')
    if claims_inquiry_path:
        normalized_claims_inquiry = _normalize_optumai_path(claims_inquiry_path)
        normalized_paths['claims_inquiry'] = normalized_claims_inquiry
        if normalized_claims_inquiry != '/oihub/claim/inquiry/v1':
            return False, "OPTUMAI claims_inquiry path '{}' does not normalize to expected '/oihub/claim/inquiry/v1'".format(claims_inquiry_path), None
    elif required_endpoint == 'claims_inquiry':
        return False, "OPTUMAI claims_inquiry endpoint not configured", None
    
    # If specific endpoint required, check it exists
    if required_endpoint and required_endpoint not in normalized_paths:
        return False, "OPTUMAI {} endpoint not configured".format(required_endpoint), None
    
    # Include normalized api_url in the returned paths dict to eliminate duplication
    normalized_paths['api_url'] = api_url_normalized
    
    return True, None, normalized_paths


def _optumai_validation_error_response(validation_error, operation_name='claim submission', include_transaction_id=True):
    """Return the shared error dict for OPTUMAI configuration validation failure."""
    out = {
        'x12ResponseData': None,
        'responseType': None,
        'statuscode': '500',
        'message': 'OPTUMAI configuration error: {}'.format(validation_error)
    }
    if include_transaction_id:
        out['transactionId'] = None
    return out


def _get_validated_optumai_urls(client, required_endpoint):
    """
    Resolve and validate OPTUMAI config; return (api_url, path, full_url, None) or (None, None, None, error_dict).
    required_endpoint must be 'claim_actions' or 'claims_inquiry'.
    """
    if required_endpoint not in ('claim_actions', 'claims_inquiry'):
        return (None, None, None, _optumai_validation_error_response(
            "required_endpoint must be 'claim_actions' or 'claims_inquiry'", include_transaction_id=(required_endpoint == 'claim_actions')))
    if not extract_medilink_config:
        return (None, None, None, _optumai_validation_error_response(
            "extract_medilink_config not available", include_transaction_id=(required_endpoint == 'claim_actions')))
    medi = extract_medilink_config(client.config)
    optumai_cfg = medi.get('endpoints', {}).get('OPTUMAI', {})
    is_valid, validation_error, normalized_paths = _validate_optumai_config(optumai_cfg, required_endpoint=required_endpoint)
    if not is_valid:
        error_dict = _optumai_validation_error_response(
            validation_error,
            operation_name='277CA search' if required_endpoint == 'claims_inquiry' else 'claim submission',
            include_transaction_id=(required_endpoint == 'claim_actions'))
        operation_label = '277CA search' if required_endpoint == 'claims_inquiry' else 'claim submission'
        MediLink_ConfigLoader.log(
            "OPTUMAI configuration validation failed: {}. Cannot proceed with {}.".format(validation_error, operation_label),
            level="ERROR"
        )
        return (None, None, None, error_dict)
    api_url = normalized_paths['api_url']
    path = normalized_paths[required_endpoint]
    full_url = api_url + path
    MediLink_ConfigLoader.log(
        "Using validated OPTUMAI configuration: base_url='{}', {}='{}'".format(api_url, required_endpoint, path),
        level="DEBUG"
    )
    return (api_url, path, full_url, None)


def extract_payer_id_from_x12(x12_data):
    """
    Extract payer ID from X12 837 data (NM1 PR segment).
    
    Args:
        x12_data (str): X12 837 formatted claim data
    
    Returns:
        str or None: Payer ID if found, None otherwise
    """
    if not x12_data:
        return None
    
    try:
        # X12 format: segments separated by ~
        segments = x12_data.split('~')
        for segment in segments:
            if segment.startswith('NM1*PR'):
                # NM1*PR*2*PAYER NAME*****PI*PAYER_ID
                # Format: NM1*PR*2*{payer_name}*****PI*{payer_id}
                # After split by '*': [0]NM1, [1]PR, [2]2, [3]payer_name, [4-7]empty, [8]PI, [9]payer_id
                fields = segment.split('*')
                if len(fields) >= 10:
                    payer_id = fields[9]  # Payer ID is at index 9 (index 8 is "PI" qualifier)
                    if payer_id:
                        return payer_id.strip()
    except Exception:
        pass
    
    return None


def submit_claim_via_optumai(client, x12_request_data, payer_id=None):
    """
    Submit claim via OPTUMAI Claim Actions API using GraphQL mutation.
    
    Args:
        client (APIClient): API client instance
        x12_request_data (str): EDI837 X12 formatted claim data
        payer_id (str, optional): Payer ID (extracted from X12 if not provided)
    
    Returns:
        dict: Legacy format response with transactionId, x12ResponseData, responseType, statuscode, message
    """
    if not MediLink_GraphQL:
        raise ImportError("graphql_utils module not available")
    
    if not build_optumai_headers:
        raise ImportError("build_optumai_headers function not available")
    
    try:
        # Extract payer ID from X12 if not provided
        if not payer_id:
            payer_id = extract_payer_id_from_x12(x12_request_data)
        
        if not payer_id:
            return {
                'transactionId': None,
                'x12ResponseData': None,
                'responseType': None,
                'statuscode': '400',
                'message': 'Payer ID not found in X12 data and not provided'
            }
        
        optumai_api_url, claim_actions_url, _full_url, error_dict = _get_validated_optumai_urls(client, 'claim_actions')
        if error_dict is not None:
            return error_dict
        
        # Build GraphQL request
        input_dict = {
            'payerId': payer_id,
            'x12RequestData': x12_request_data
        }
        graphql_body = MediLink_GraphQL.build_optumai_claim_submission_request(input_dict)
        
        
        # Build headers using centralized helper
        headers = build_optumai_headers(client.config, api_url=optumai_api_url)
        
        # Phase 1 Fix: Explicit JSON serialization per OpenAPI spec requirements
        # Use json.dumps() to ensure exact format matching spec
        try:
            graphql_body_json = json.dumps(graphql_body)
        except Exception as json_err:
            MediLink_ConfigLoader.log(
                "Error serializing GraphQL request body: {}".format(str(json_err)),
                level="ERROR"
            )
            raise
        
        # Make API call
        MediLink_ConfigLoader.log(
            "Submitting claim via OPTUMAI Claim Actions (payer: {}, URL: {})".format(payer_id, claim_actions_url),
            level="INFO"
        )
        
        # Phase 1 Fix: Pass serialized JSON string instead of dict
        # This ensures exact format matching OpenAPI spec requirements
        response = client.make_api_call('OPTUMAI', 'POST', claim_actions_url, data=graphql_body_json, headers=headers)
        
        # Transform response to legacy format
        transformed = MediLink_GraphQL.transform_claim_submission_response_to_legacy(response)
        statuscode = str(transformed.get('statuscode') or '')
        response_type = transformed.get('responseType')
        if statuscode not in OPTUMAI_SUCCESS_STATUS_CODES:
            try:
                full_response = json.dumps(response, indent=2)
            except Exception:
                full_response = str(response)
            MediLink_ConfigLoader.log(
                "OPTUMAI claim submission non-success response (statuscode={}, responseType={}): {}".format(
                    statuscode, response_type, full_response
                ),
                level="ERROR"
            )
        
        # Log transaction ID if available
        if transformed.get('transactionId'):
            MediLink_ConfigLoader.log(
                "OPTUMAI claim submission transactionId: {}".format(transformed.get('transactionId')),
                level="INFO"
            )
            MediLink_ConfigLoader.log(
                "OPTUMAI Claim Actions submission SUCCESS (URL: {})".format(optumai_api_url + claim_actions_url),
                level="DEBUG"
            )
        
        return transformed
    except Exception as e:
        # Log full exception details including traceback for debugging
        import traceback
        error_details = traceback.format_exc()
        MediLink_ConfigLoader.log(
            "Error submitting claim via OPTUMAI: {}\nTraceback:\n{}".format(str(e), error_details),
            level="ERROR"
        )
        # Preserve original error message for user-facing response
        error_message = str(e)
        return {
            'transactionId': None,
            'x12ResponseData': None,
            'responseType': None,
            'statuscode': '500',
            'message': 'Error submitting claim: {}'.format(error_message)
        }


def search_277ca_via_optumai(client, transaction_id, payer_id):
    """
    Search for 277CA claim acknowledgment via OPTUMAI Claims Inquiry API.
    
    Args:
        client (APIClient): API client instance
        transaction_id (str): Transaction ID from claim submission
        payer_id (str): Payer ID
    
    Returns:
        dict: Legacy format response with x12ResponseData, responseType, statuscode, message
    """
    if not MediLink_GraphQL:
        raise ImportError("graphql_utils module not available")
    
    if not build_optumai_headers:
        raise ImportError("build_optumai_headers function not available")
    
    # Single routing layer: do not call OPTUMAI if payer does not support search_277ca
    if resolve_operation_route:
        route_endpoint, route_reason = resolve_operation_route(client, payer_id, 'search_277ca')
        if route_endpoint != 'OPTUMAI':
            msg = "277CA not supported for this payer via OPTUMAI" + (" ({})".format(route_reason) if route_reason else "")
            MediLink_ConfigLoader.log(msg, level="WARNING")
            return {
                'statuscode': '404',
                'message': msg,
                'responseType': None,
                'x12ResponseData': None,
            }
    else:
        MediLink_ConfigLoader.log(
            "277CA routing check skipped (resolve_operation_route unavailable); proceeding with OPTUMAI call.",
            level="WARNING"
        )
    
    try:
        optumai_api_url, claims_inquiry_url, full_url, error_dict = _get_validated_optumai_urls(client, 'claims_inquiry')
        if error_dict is not None:
            return error_dict
        
        # Build GraphQL request
        input_dict = {
            'transactionId': transaction_id,
            'payerId': payer_id
        }
        
        # Log input parameters for debugging
        MediLink_ConfigLoader.log(
            "Building 277CA search request - transactionId: '{}' (type: {}, length: {}), payerId: '{}'".format(
                transaction_id, type(transaction_id).__name__, len(str(transaction_id)) if transaction_id else 0, payer_id
            ),
            level="DEBUG"
        )
        
        graphql_body = MediLink_GraphQL.build_optumai_search277ca_request(input_dict)
        
        # Log request body structure (without full X12 data)
        try:
            request_structure = {
                'has_query': 'query' in graphql_body,
                'has_variables': 'variables' in graphql_body,
                'has_operationName': 'operationName' in graphql_body,
                'operationName': graphql_body.get('operationName'),
                'variables_keys': list(graphql_body.get('variables', {}).keys()) if isinstance(graphql_body.get('variables'), dict) else None,
                'search277CAInput_keys': list(graphql_body.get('variables', {}).get('search277CAInput', {}).keys()) if isinstance(graphql_body.get('variables', {}).get('search277CAInput'), dict) else None,
                'transactionId_in_vars': graphql_body.get('variables', {}).get('search277CAInput', {}).get('transactionId') if isinstance(graphql_body.get('variables', {}).get('search277CAInput'), dict) else None,
                'payerId_in_vars': graphql_body.get('variables', {}).get('search277CAInput', {}).get('payerId') if isinstance(graphql_body.get('variables', {}).get('search277CAInput'), dict) else None,
                'query_preview': graphql_body.get('query', '')[:150] if graphql_body.get('query') else None
            }
            MediLink_ConfigLoader.log(
                "277CA search request body structure: {}".format(json.dumps(request_structure, indent=2)),
                level="DEBUG"
            )
        except Exception:
            pass  # Don't fail on logging errors
        
        # Phase 1 Fix: Explicit JSON serialization per OpenAPI spec requirements
        try:
            graphql_body_json = json.dumps(graphql_body)
            MediLink_ConfigLoader.log(
                "277CA search request JSON length: {} bytes".format(len(graphql_body_json)),
                level="DEBUG"
            )
        except Exception as json_err:
            MediLink_ConfigLoader.log(
                "Error serializing GraphQL request body for 277CA search: {}".format(str(json_err)),
                level="ERROR"
            )
            raise
        
        # Build headers using centralized helper
        headers = build_optumai_headers(client.config, api_url=optumai_api_url)
        
        # Make API call
        MediLink_ConfigLoader.log(
            "Searching 277CA via OPTUMAI (transactionId: '{}', payer: {}, URL: {})".format(transaction_id, payer_id, claims_inquiry_url),
            level="INFO"
        )
        
        # Phase 1 Fix: Pass serialized JSON string instead of dict
        response = client.make_api_call('OPTUMAI', 'POST', claims_inquiry_url, data=graphql_body_json, headers=headers)
        
        MediLink_ConfigLoader.log(
            "277CA search URL: {}".format(full_url),
            level="DEBUG"
        )
        
        # Log response structure for debugging
        try:
            if isinstance(response, dict):
                response_structure = {
                    'has_data': 'data' in response,
                    'has_errors': 'errors' in response,
                    'data_keys': list(response.get('data', {}).keys()) if isinstance(response.get('data'), dict) else None,
                    'errors_count': len(response.get('errors', [])) if isinstance(response.get('errors'), list) else 0,
                    'search277CA_keys': list(response.get('data', {}).get('search277CA', {}).keys()) if isinstance(response.get('data', {}).get('search277CA'), dict) else None
                }
                MediLink_ConfigLoader.log(
                    "277CA search response structure: {}".format(json.dumps(response_structure, indent=2)),
                    level="DEBUG"
                )
                if 'errors' in response and response['errors']:
                    # Enhanced error logging with sanitized details
                    MediLink_ConfigLoader.log(
                        "277CA search FAILED - Full error response: {}".format(json.dumps(response['errors'], indent=2)),
                        level="ERROR"
                    )
                    # Log sanitized request details (no PHI, just structure)
                    sanitized_request = {
                        'transactionId_length': len(str(transaction_id)) if transaction_id else 0,
                        'transactionId_type': type(transaction_id).__name__,
                        'payerId': payer_id,
                        'operationName': graphql_body.get('operationName'),
                        'variables_structure': {
                            'has_search277CAInput': 'search277CAInput' in graphql_body.get('variables', {}),
                            'input_keys': list(graphql_body.get('variables', {}).get('search277CAInput', {}).keys()) if isinstance(graphql_body.get('variables', {}).get('search277CAInput'), dict) else None
                        },
                        'url': full_url
                    }
                    MediLink_ConfigLoader.log(
                        "277CA search FAILED - Sanitized request details: {}".format(json.dumps(sanitized_request, indent=2)),
                        level="ERROR"
                    )
        except Exception:
            pass  # Don't fail on logging errors
        
        # Transform response to legacy format
        transformed = MediLink_GraphQL.transform_search277ca_response_to_legacy(response)
        statuscode = str(transformed.get('statuscode') or '')
        response_type = transformed.get('responseType')
        if statuscode not in OPTUMAI_SUCCESS_STATUS_CODES:
            try:
                full_response = json.dumps(response, indent=2)
            except Exception:
                full_response = str(response)
            MediLink_ConfigLoader.log(
                "OPTUMAI 277CA search non-success response (statuscode={}, responseType={}): {}".format(
                    statuscode, response_type, full_response
                ),
                level="ERROR"
            )
        
        # Log final status after transformation
        if transformed.get('statuscode') not in OPTUMAI_SUCCESS_STATUS_CODES:
            MediLink_ConfigLoader.log(
                "277CA search completed with failure - statuscode: {}, message: {}".format(
                    transformed.get('statuscode'), transformed.get('message')
                ),
                level="WARNING"
            )
        else:
            MediLink_ConfigLoader.log("277CA search SUCCESS", level="DEBUG")
        
        return transformed
    except Exception as e:
        MediLink_ConfigLoader.log(
            "Error searching 277CA via OPTUMAI: {}".format(str(e)),
            level="ERROR"
        )
        return {
            'x12ResponseData': None,
            'responseType': None,
            'statuscode': '500',
            'message': 'Error searching 277CA: {}'.format(str(e))
        }
