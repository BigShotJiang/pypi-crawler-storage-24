#!/usr/bin/env python
"""Lightweight next-step assistant helpers for MediCafe launcher.

Design goals:
- Keep recommendation logic pure and deterministic.
- Reuse existing launcher/domain outcomes; avoid duplicate domain scans.
- Keep Python 3.4 compatibility.
"""
from __future__ import print_function


def build_action_outcome(action_key, status='unknown', severity='info', signals=None,
                         recommended_next=None, reason_codes=None):
    """Build normalized action outcome payload."""
    return {
        'action_key': action_key,
        'status': status,
        'severity': severity,
        'signals': dict(signals or {}),
        'recommended_next': recommended_next,
        'reason_codes': list(reason_codes or []),
    }


def collect_startup_signals(startup_notices=None, signal_providers=None):
    """Collect lightweight startup signals without domain-heavy checks.

    signal_providers: optional iterable of callables returning dict-like signals.
    """
    signals = {
        'zdat_pending': False,
        'retry_queue_pending_count': 0,
        'intake_artifacts_new_count': 0,
    }

    notices = startup_notices or []
    for level, message in notices:
        text = str(message or '').lower()
        if ('z.dat' in text and ('pending' in text or 'new' in text)) or ('new records were found during startup scan' in text):
            signals['zdat_pending'] = True
        if 'retry' in text and 'pending' in text:
            signals['retry_queue_pending_count'] = max(signals['retry_queue_pending_count'], 1)

    if signal_providers:
        for provider in signal_providers:
            try:
                payload = provider()
            except Exception:
                payload = None
            if not isinstance(payload, dict):
                continue
            if payload.get('zdat_pending') is True:
                signals['zdat_pending'] = True
            try:
                retry_count = int(payload.get('retry_queue_pending_count') or 0)
            except Exception:
                retry_count = 0
            signals['retry_queue_pending_count'] = max(signals['retry_queue_pending_count'], retry_count)
            try:
                new_count = int(payload.get('intake_artifacts_new_count') or 0)
            except Exception:
                new_count = 0
            signals['intake_artifacts_new_count'] = max(signals['intake_artifacts_new_count'], new_count)

    return signals


def has_actionable_signals(signals):
    """Return True when startup signals indicate actionable work."""
    if not isinstance(signals, dict):
        return False
    if bool(signals.get('zdat_pending')):
        return True
    try:
        if int(signals.get('retry_queue_pending_count') or 0) > 0:
            return True
    except Exception:
        pass
    try:
        if int(signals.get('intake_artifacts_new_count') or 0) > 0:
            return True
    except Exception:
        pass
    return False


def _option(action_id, label, reason, reason_code=None, signal_source=None):
    return {
        'action_id': action_id,
        'label': label,
        'reason': reason,
        'reason_code': reason_code or '',
        'signal_source': signal_source or '',
    }


def recommend_next_steps(outcome, startup_signals=None, max_options=3):
    """Pure recommendation function (no filesystem/network IO)."""
    startup_signals = startup_signals or {}
    signals = {}
    if isinstance(startup_signals, dict):
        signals.update(startup_signals)
    if isinstance((outcome or {}).get('signals'), dict):
        signals.update((outcome or {}).get('signals') or {})

    action_key = (outcome or {}).get('action_key')
    status = (outcome or {}).get('status')
    recs = []

    retry_pending_count = int(signals.get('retry_queue_pending_count') or 0)
    zdat_pending = bool(signals.get('zdat_pending'))
    intake_artifacts_new_count = int(signals.get('intake_artifacts_new_count') or 0)

    if status == 'failed':
        recs.append(_option('troubleshooting', 'Open Troubleshooting Toolkit', 'last action failed', reason_code='action_failed', signal_source='action_outcome'))

    if retry_pending_count > 0:
        recs.append(_option('medilink', 'Open MediLink Claims (Retry Queue)', 'retry queue has pending work', reason_code='retry_pending', signal_source='submission_attempts_ledger'))

    if zdat_pending:
        recs.append(_option('medilink', 'Open MediLink Claims', 'pending Z.dat/remittance work detected', reason_code='zdat_pending', signal_source='remittance_file_ledger'))

    if action_key == 'download_emails' and status == 'ok':
        recs.append(_option('medibot', 'Run MediBot extraction', 'email intake completed successfully', reason_code='post_download_flow', signal_source='action_outcome'))

    if intake_artifacts_new_count > 0:
        recs.append(_option('medibot', 'Run MediBot extraction', 'new intake artifacts detected', reason_code='new_intake_artifacts', signal_source='startup_or_action_signals'))

    if not recs:
        recs.append(_option('download_emails', 'Check Gmail intake', 'no actionable workload detected', reason_code='no_actionable_work', signal_source='derived'))
        recs.append(_option('troubleshooting', 'Open Troubleshooting Toolkit', 'no actionable workload detected', reason_code='no_actionable_work', signal_source='derived'))

    # Ensure stable de-dup by action_id then label
    deduped = []
    seen = set()
    for rec in recs:
        key = (rec.get('action_id'), rec.get('label'))
        if key in seen:
            continue
        seen.add(key)
        deduped.append(rec)

    # Always provide explicit back-to-menu path
    deduped.append(_option('main_menu', 'Return to main menu', 'manual navigation', reason_code='manual_navigation', signal_source='ui'))

    trimmed = deduped[:max_options]
    if not any(r.get('action_id') == 'main_menu' for r in trimmed):
        if len(trimmed) >= max_options:
            trimmed[-1] = _option('main_menu', 'Return to main menu', 'manual navigation', reason_code='manual_navigation', signal_source='ui')
        else:
            trimmed.append(_option('main_menu', 'Return to main menu', 'manual navigation', reason_code='manual_navigation', signal_source='ui'))
    return trimmed


def prompt_for_recommendation(recommendations, prompt_fn, print_fn=print, default_index=1):
    """Render recommendations and return selected recommendation dict or None."""
    if not recommendations:
        return None

    print_fn('')
    print_fn('Recommended next steps:')
    for idx, rec in enumerate(recommendations, 1):
        reason = rec.get('reason')
        suffix = '' if idx != default_index else ' (recommended, default)'
        if reason:
            print_fn(' {0}. {1}{2} — {3}'.format(idx, rec.get('label', 'Unknown'), suffix, reason))
        else:
            print_fn(' {0}. {1}{2}'.format(idx, rec.get('label', 'Unknown'), suffix))

    for _ in range(2):
        raw = (prompt_fn('Select next action [{0}] (Enter = recommended): '.format(default_index)) or '').strip()
        if raw == '':
            return recommendations[default_index - 1]
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(recommendations):
                return recommendations[idx - 1]
        print_fn('Invalid choice. Enter a number from the list, or press Enter for the recommendation.')

    return {'action_id': 'main_menu', 'label': 'Return to main menu', 'reason': 'invalid input fallback', 'reason_code': 'invalid_input_fallback', 'signal_source': 'ui'}
