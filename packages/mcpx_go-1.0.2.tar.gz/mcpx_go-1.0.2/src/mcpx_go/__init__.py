"""mcpx-go distribution package."""

__version__ = "1.0.2"
