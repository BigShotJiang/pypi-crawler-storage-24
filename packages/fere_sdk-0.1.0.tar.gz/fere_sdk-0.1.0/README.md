# fere-sdk

Python SDK for the FereAI Gateway API.

## Install

```bash
pip install fere-sdk
```

## Usage

```python
from fere_sdk import FereClient

client = FereClient(api_key="your-api-key", base_url="https://api.fere.ai")
```

See the [FereAI docs](https://api.fere.ai) for full API reference.
