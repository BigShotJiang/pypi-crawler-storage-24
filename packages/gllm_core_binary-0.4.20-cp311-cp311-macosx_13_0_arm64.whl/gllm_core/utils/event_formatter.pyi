from gllm_core.schema.chunk import Chunk as Chunk
from gllm_core.utils.imports import deprecated as deprecated
from gllm_core.utils.repr import MAX_PREVIEW_LENGTH as MAX_PREVIEW_LENGTH

def format_chunk_for_logging(chunk: Chunk, rank: int | None = None, include_score: bool = True, include_metadata: bool = True) -> str:
    """Formats a log to display a single chunk.

    Args:
        chunk (Chunk): The chunk to be formatted.
        rank (int | None, optional): The optional rank of the formatted chunk. Defaults to None.
        include_score (bool, optional): Whether to include the score in the formatted message. Defaults to True.
        include_metadata (bool, optional): Whether to include the metadata in the formatted message. Defaults to True.

    Returns:
        str: A formatted log message that displays information about the logged chunk.
    """
def format_chunk_message(chunk: Chunk, rank: int | None = None, include_score: bool = True, include_metadata: bool = True) -> str:
    """Formats a log to display a single chunk.

    Args:
        chunk (Chunk): The chunk to be formatted.
        rank (int | None, optional): The optional rank of the formatted chunk. Defaults to None.
        include_score (bool, optional): Whether to include the score in the formatted message. Defaults to True.
        include_metadata (bool, optional): Whether to include the metadata in the formatted message. Defaults to True.

    Returns:
        str: A formatted log message that displays information about the logged chunk.
    """
