from datetime import datetime
from gllm_core.constants import EventLevel as EventLevel, EventType as EventType, EventValueType as EventValueType
from pydantic import BaseModel
from typing import Any

PAYLOAD_TYPE_MAP: list[tuple[type, set[EventValueType], EventValueType]]

class Event(BaseModel):
    """A data class to store an event attributes.

    Attributes:
        id (str): The ID of the event. Defaults to None.
        value (str | bytes | dict[str, Any]): The value of the event. Defaults to an empty string.
        value_type (EventValueType | None): The type of the value of the event. Defaults to None.
        level (EventLevel): The severity level of the event. Defaults to EventLevel.INFO.
        type (str): The type of the event. Defaults to EventType.RESPONSE.
        timestamp (datetime): The timestamp of the event. Defaults to the current timestamp.
        metadata (dict[str, Any]): The metadata of the event. Defaults to an empty dictionary.
    """
    id: str | None
    value: str | bytes | dict[str, Any]
    value_type: EventValueType | None
    level: EventLevel
    type: str
    timestamp: datetime
    metadata: dict[str, Any]
    def serialize_value(self, value: str | bytes | dict[str, Any]) -> str | dict[str, Any]:
        """Serializes the value of the event.

        This method is used to serialize the value of the event to a string or dictionary.
        If the value is a bytes object, it will be encoded to a base64 string.
        Otherwise, the value is returned as is.

        Args:
            value (str | bytes | dict[str, Any]): The value of the event.

        Returns:
            str | dict[str, Any]: The serialized value of the event.
        """
    def serialize_level(self, level: EventLevel) -> str:
        """Serializes an EventLevel object into its string representation.

        This method serializes the given EventLevel object by returning its name as a string.

        Args:
            level (EventLevel): The EventLevel object to be serialized.

        Returns:
            str: The name of the EventLevel object.
        """
    def infer_or_validate_value_type(self) -> Event:
        """Infers or validates the value type of the event.

        This method infers or validates the value type of the event based on the payload type.
        If the value type is not specified, it will be inferred from the payload type.
        If the value type is specified, it will be validated against the compatible value types.

        Returns:
            Event: The event with the inferred or validated value type.
        """
