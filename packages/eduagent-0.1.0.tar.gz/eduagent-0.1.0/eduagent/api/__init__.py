"""EDUagent web API package."""
