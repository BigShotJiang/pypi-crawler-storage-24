"""Unified LLM client supporting Anthropic, OpenAI, and Ollama backends."""

from __future__ import annotations

import json
import os
from typing import Any, Optional

import httpx

from eduagent.models import AppConfig, LLMProvider


class LLMClient:
    """Unified async LLM client for all supported backends."""

    def __init__(self, config: Optional[AppConfig] = None):
        self.config = config or AppConfig.load()

    async def generate(
        self,
        prompt: str,
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Generate text from the configured LLM backend."""
        if self.config.provider == LLMProvider.ANTHROPIC:
            return await self._anthropic(prompt, system, temperature, max_tokens)
        elif self.config.provider == LLMProvider.OPENAI:
            return await self._openai(prompt, system, temperature, max_tokens)
        elif self.config.provider == LLMProvider.OLLAMA:
            return await self._ollama(prompt, system, temperature, max_tokens)
        raise ValueError(f"Unknown provider: {self.config.provider}")

    async def generate_json(
        self,
        prompt: str,
        system: str = "",
        temperature: float = 0.4,
        max_tokens: int = 8192,
    ) -> dict[str, Any]:
        """Generate and parse a JSON response from the LLM."""
        raw = await self.generate(prompt, system, temperature, max_tokens)
        # Extract JSON from markdown code fences if present
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            # Drop first line (```json or ```) and last line (```)
            lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            cleaned = "\n".join(lines)
        # Handle truncated JSON: try to repair by finding the last valid content
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            # Try to repair truncated JSON
            stripped = cleaned.lstrip()
            if stripped.startswith("["):
                # JSON array: find last complete object, close the array
                last_brace = cleaned.rfind("}")
                if last_brace != -1:
                    repaired = cleaned[:last_brace + 1].rstrip().rstrip(",") + "\n]"
                    try:
                        return json.loads(repaired)
                    except json.JSONDecodeError:
                        pass
            elif stripped.startswith("{"):
                # JSON object: find last complete key-value pair by scanning backwards
                # Strategy: close all unclosed strings/brackets/braces
                last_comma = cleaned.rfind(",\n")
                if last_comma != -1:
                    # Truncate at last full field and close the object
                    repaired = cleaned[:last_comma] + "\n}"
                    try:
                        return json.loads(repaired)
                    except json.JSONDecodeError:
                        pass
                # If that doesn't work, try just closing the object
                last_value = cleaned.rfind('"')
                if last_value != -1:
                    # Slice to last string end and close
                    repaired = cleaned[:last_value + 1] + "\n}"
                    try:
                        return json.loads(repaired)
                    except json.JSONDecodeError:
                        pass
            # Re-raise original error if we can't repair
            raise

    # ── Anthropic ────────────────────────────────────────────────────────

    async def _anthropic(
        self, prompt: str, system: str, temperature: float, max_tokens: int
    ) -> str:
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise EnvironmentError(
                "ANTHROPIC_API_KEY not set. Export it or run: eduagent config set-model ollama"
            )
        async with httpx.AsyncClient(timeout=120.0) as client:
            body: dict[str, Any] = {
                "model": self.config.anthropic_model,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "messages": [{"role": "user", "content": prompt}],
            }
            if system:
                body["system"] = system
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json=body,
            )
            resp.raise_for_status()
            data = resp.json()
            return data["content"][0]["text"]

    # ── OpenAI ───────────────────────────────────────────────────────────

    async def _openai(
        self, prompt: str, system: str, temperature: float, max_tokens: int
    ) -> str:
        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise EnvironmentError(
                "OPENAI_API_KEY not set. Export it or run: eduagent config set-model ollama"
            )
        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-type": "application/json",
                },
                json={
                    "model": self.config.openai_model,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]

    # ── Ollama ───────────────────────────────────────────────────────────

    async def _ollama(
        self, prompt: str, system: str, temperature: float, max_tokens: int
    ) -> str:
        # Support both local Ollama (no auth) and Ollama Cloud (Bearer token)
        api_key = getattr(self.config, "ollama_api_key", None) or os.environ.get("OLLAMA_API_KEY")
        headers = {}
        if api_key and api_key != "ollama":
            headers["Authorization"] = f"Bearer {api_key}"

        # Ollama Cloud uses OpenAI-compatible API; local uses /api/generate
        base = self.config.ollama_base_url.rstrip("/")
        is_cloud = "api.ollama.com" in base or "ollama.com" in base

        if is_cloud:
            # Use OpenAI-compatible endpoint for cloud
            messages = []
            if system:
                messages.append({"role": "system", "content": system})
            messages.append({"role": "user", "content": prompt})
            async with httpx.AsyncClient(timeout=300.0) as client:
                resp = await client.post(
                    f"{base}/v1/chat/completions",
                    headers=headers,
                    json={
                        "model": self.config.ollama_model,
                        "messages": messages,
                        "temperature": temperature,
                        "max_tokens": max_tokens,
                        "stream": False,
                    },
                )
                resp.raise_for_status()
                data = resp.json()
                return data["choices"][0]["message"]["content"]
        else:
            # Local Ollama
            full_prompt = f"{system}\n\n{prompt}" if system else prompt
            async with httpx.AsyncClient(timeout=300.0) as client:
                resp = await client.post(
                    f"{base}/api/generate",
                    headers=headers,
                    json={
                        "model": self.config.ollama_model,
                        "prompt": full_prompt,
                        "stream": False,
                        "options": {
                            "temperature": temperature,
                            "num_predict": max_tokens,
                        },
                    },
                )
                resp.raise_for_status()
                data = resp.json()
                return data["response"]
