from setuptools import setup, find_packages

setup(
    name="matplotliblib",
    version="0.1",
    packages=find_packages(),

    author=".",
    description="Collection of machine learning tools",
    
    python_requires=">=3.7",

    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)