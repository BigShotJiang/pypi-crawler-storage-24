#!/usr/bin/env python3
"""
Kiwi AI CLI Agent — connects to the server via WebSocket and executes
terminal commands on behalf of the LLM agent.

Authenticates with email and password.

Usage:
    kiwi connect --server local
    kiwi connect --server dev
    kiwi connect --server wss://custom.server.com
"""

import argparse
import asyncio
import fcntl
import getpass
import json
import os
import pty
import signal
import struct
import sys
import termios

import httpx
import websockets

MAX_OUTPUT_BYTES = 50 * 1024  # 50KB cap on command output

SERVER_PRESETS = {
    "local": {"ws": "ws://localhost:8000", "http": "http://localhost:8000"},
    "dev": {"ws": "wss://dev.api.myautobots.com", "http": "https://dev.api.myautobots.com"},
}

# ---------------------------------------------------------------------------
# ANSI colors
# ---------------------------------------------------------------------------

RESET = "\033[0m"
BOLD = "\033[1m"

# Brand color — ANSI cyan (works reliably across all terminals)
C = "\033[36m"
CB = "\033[1;36m"
GREY = "\033[90m"
RED = "\033[91m"
YELLOW = "\033[93m"
GREEN = "\033[92m"


# ---------------------------------------------------------------------------
# Banner — Kiwi logo (from SVG) + KIWI AI text side by side
# ---------------------------------------------------------------------------

# Logo: 32 wide x 16 tall (half-block, perfectly symmetric from SVG)
LOGO = [
    "              ▄██▄              ",
    "              ████              ",
    "    ▄██▄▄     ████     ▄▄██▄    ",
    "    ▀█████▄   █▀▀█   ▄█████▀   ",
    "     ▀███▀▀█  ████  █▀▀███▀    ",
    "       ▀█▄  █ ████ █  ▄█▀      ",
    "          ▀▀▄██████▄▀▀         ",
    "▄██████▀▀█▄██████████▄█▀▀██████▄",
    "▀██████▄▄█▀██████████▀█▄▄██████▀",
    "          ▄▄▀██████▀▄▄         ",
    "       ▄█▀  █ ████ █  ▀█▄      ",
    "     ▄███▄▄█  ████  █▄▄███▄    ",
    "    ▄█████▀   █▄▄█   ▀█████▄   ",
    "    ▀██▀▀     ████     ▀▀██▀   ",
    "              ████              ",
    "              ▀██▀              ",
]

# Text: 6 tall
TEXT = [
    "██╗  ██╗██╗██╗    ██╗██╗     █████╗ ██╗",
    "██║ ██╔╝██║██║    ██║██║    ██╔══██╗██║",
    "█████╔╝ ██║██║ █╗ ██║██║    ███████║██║",
    "██╔═██╗ ██║██║███╗██║██║    ██╔══██║██║",
    "██║  ██╗██║╚███╔███╔╝██║    ██║  ██║██║",
    "╚═╝  ╚═╝╚═╝ ╚══╝╚══╝ ╚═╝    ╚═╝  ╚═╝╚═╝",
]

TAGLINE = "Terminal Agent for AI-Powered Automation"


def print_banner():
    """Print the Kiwi AI startup banner."""
    print()

    # Side-by-side: logo (16 lines) with text (6 lines) vertically centered
    gap = "  "
    text_start = 5
    logo_w = 33

    for i, logo_line in enumerate(LOGO):
        padded_logo = logo_line.ljust(logo_w)
        text_idx = i - text_start
        if 0 <= text_idx < len(TEXT):
            row = f"{padded_logo}{gap}{TEXT[text_idx]}"
        elif text_idx == len(TEXT) + 1:
            row = f"{padded_logo}{gap}{TAGLINE}"
        else:
            row = padded_logo

        print(f"  {CB}{row}{RESET}")

    print(f"  {GREY}{'━' * 72}{RESET}")
    print()


def print_status(icon: str, message: str, color: str = C):
    """Print a styled status line."""
    print(f"  {color}{icon}{RESET}  {message}")


def print_section(title: str):
    """Print a section header."""
    print(f"\n  {CB}{title}{RESET}")
    print(f"  {GREY}{'─' * 40}{RESET}")


def print_cmd_log(request_id: str, message: str, success: bool | None = None):
    """Print a command execution log line."""
    tag = f"{GREY}[{request_id[:8]}]{RESET}"
    if success is True:
        icon = f"{GREEN}>{RESET}"
    elif success is False:
        icon = f"{RED}x{RESET}"
    else:
        icon = f"{C}>{RESET}"
    print(f"  {icon} {tag} {message}")


def print_pty_log(session_id: str, message: str, level: str = "info"):
    """Print a PTY session log line."""
    tag = f"{GREY}[PTY {session_id[:8]}]{RESET}"
    if level == "error":
        icon = f"{RED}x{RESET}"
    elif level == "success":
        icon = f"{GREEN}>{RESET}"
    else:
        icon = f"{C}~{RESET}"
    print(f"  {icon} {tag} {message}")


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------

async def login(http_base_url: str, email: str, password: str) -> str:
    """Authenticate with email/password and return the JWT access token."""
    url = f"{http_base_url}/v1/auth/token"
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            url,
            data={"username": email, "password": password},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        if resp.status_code != 200:
            detail = resp.text
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                pass
            raise Exception(f"Login failed (HTTP {resp.status_code}): {detail}")

        body = resp.json()
        token = body.get("access_token")
        if not token:
            raise Exception(f"No access_token in response: {body}")
        return token


async def run_command(command: str, timeout: int = 120) -> dict:
    """Execute a shell command and return stdout, stderr, exit_code."""
    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(), timeout=timeout
        )
        stdout = stdout_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_BYTES]
        stderr = stderr_bytes.decode("utf-8", errors="replace")[:MAX_OUTPUT_BYTES]
        return {"stdout": stdout, "stderr": stderr, "exit_code": proc.returncode}
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        return {"stdout": "", "stderr": f"Command timed out after {timeout}s", "exit_code": -1}
    except Exception as e:
        return {"stdout": "", "stderr": str(e), "exit_code": -1}


class PTYProcess:
    """Manages a single interactive PTY session."""

    def __init__(self, session_id: str, command: str, cols: int = 120, rows: int = 40):
        self.session_id = session_id
        self.command = command
        self.cols = cols
        self.rows = rows
        self.master_fd = None
        self.slave_fd = None
        self.proc = None
        self._read_task = None

    async def start(self, ws):
        """Spawn the PTY process and begin reading output."""
        self.master_fd, self.slave_fd = pty.openpty()

        winsize = struct.pack("HHHH", self.rows, self.cols, 0, 0)
        fcntl.ioctl(self.slave_fd, termios.TIOCSWINSZ, winsize)

        self.proc = await asyncio.create_subprocess_exec(
            "/bin/sh", "-c", self.command,
            stdin=self.slave_fd,
            stdout=self.slave_fd,
            stderr=self.slave_fd,
            preexec_fn=os.setsid,
        )

        os.close(self.slave_fd)
        self.slave_fd = None

        flags = fcntl.fcntl(self.master_fd, fcntl.F_GETFL)
        fcntl.fcntl(self.master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

        self._read_task = asyncio.create_task(self._read_loop(ws))

    async def _read_loop(self, ws):
        """Read output from master fd and send over WebSocket."""
        loop = asyncio.get_event_loop()
        try:
            while True:
                try:
                    data = await loop.run_in_executor(None, self._blocking_read)
                    if data is None:
                        break
                    await ws.send(json.dumps({
                        "type": "pty_output",
                        "session_id": self.session_id,
                        "data": data,
                    }))
                except OSError:
                    break
                except Exception as e:
                    print_pty_log(self.session_id, f"Read error: {e}", "error")
                    break

            if self.proc:
                try:
                    exit_code = await asyncio.wait_for(self.proc.wait(), timeout=5.0)
                except asyncio.TimeoutError:
                    self.proc.kill()
                    exit_code = -1
            else:
                exit_code = -1

            await ws.send(json.dumps({
                "type": "pty_exited",
                "session_id": self.session_id,
                "exit_code": exit_code,
            }))
        except Exception as e:
            try:
                await ws.send(json.dumps({
                    "type": "pty_error",
                    "session_id": self.session_id,
                    "error": str(e),
                }))
            except Exception:
                pass

    def _blocking_read(self) -> str | None:
        """Blocking read from master fd. Returns None on EOF."""
        import select
        while True:
            ready, _, _ = select.select([self.master_fd], [], [], 0.5)
            if ready:
                try:
                    data = os.read(self.master_fd, 4096)
                    if not data:
                        return None
                    return data.decode("utf-8", errors="replace")
                except OSError:
                    return None
            if self.proc and self.proc.returncode is not None:
                try:
                    data = os.read(self.master_fd, 4096)
                    if data:
                        return data.decode("utf-8", errors="replace")
                except OSError:
                    pass
                return None

    async def send_input(self, data: str) -> None:
        """Write data to the PTY master fd."""
        if self.master_fd is not None:
            os.write(self.master_fd, data.encode("utf-8"))

    async def close(self) -> None:
        """Terminate the process and clean up fds."""
        if self._read_task and not self._read_task.done():
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass

        if self.proc and self.proc.returncode is None:
            try:
                self.proc.terminate()
                await asyncio.wait_for(self.proc.wait(), timeout=3.0)
            except (asyncio.TimeoutError, ProcessLookupError):
                try:
                    self.proc.kill()
                except ProcessLookupError:
                    pass

        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
            self.master_fd = None

        if self.slave_fd is not None:
            try:
                os.close(self.slave_fd)
            except OSError:
                pass
            self.slave_fd = None


async def connect(ws_url: str, token: str):
    """Connect to the server WebSocket and process commands."""
    ws_endpoint = f"{ws_url}/v1/terminal/ws/connect"
    print_status("~", f"Connecting to {BOLD}{ws_endpoint}{RESET}", C)

    try:
        async with websockets.connect(ws_endpoint) as ws:
            await ws.send(json.dumps({"type": "auth", "token": token}))
            auth_resp = json.loads(await ws.recv())

            if auth_resp.get("type") == "error":
                print_status("x", f"Auth failed: {auth_resp.get('message')}", RED)
                return

            if auth_resp.get("type") == "auth_ok":
                user_id = auth_resp.get('user_id', 'unknown')
                print_status(">", f"Connected as {BOLD}{user_id}{RESET}", GREEN)
            else:
                print_status("x", f"Unexpected response: {auth_resp}", RED)
                return

            print()
            print(f"  {C}Ready{RESET} {GREY}| Waiting for commands | Ctrl+C to disconnect{RESET}")
            print(f"  {GREY}{'─' * 50}{RESET}")
            print()

            active_pty_sessions: dict[str, PTYProcess] = {}

            async for message in ws:
                msg = json.loads(message)
                msg_type = msg.get("type")

                if msg_type == "command":
                    request_id = msg.get("request_id", "")
                    command = msg.get("command", "")
                    print_cmd_log(request_id, f"$ {BOLD}{command}{RESET}")

                    result = await run_command(command)
                    exit_code = result["exit_code"]
                    success = exit_code == 0
                    status_text = (
                        f"{GREEN}OK{RESET}" if success
                        else f"{RED}FAILED (exit {exit_code}){RESET}"
                    )
                    print_cmd_log(request_id, status_text, success)

                    await ws.send(json.dumps({
                        "type": "result",
                        "request_id": request_id,
                        **result,
                    }))

                elif msg_type == "pty_start":
                    session_id = msg.get("session_id", "")
                    command = msg.get("command", "bash")
                    cols = msg.get("cols", 120)
                    rows = msg.get("rows", 40)
                    print_pty_log(session_id, f"Starting: {BOLD}{command}{RESET}")

                    try:
                        pty_proc = PTYProcess(session_id, command, cols, rows)
                        await pty_proc.start(ws)
                        active_pty_sessions[session_id] = pty_proc
                        await ws.send(json.dumps({
                            "type": "pty_started",
                            "session_id": session_id,
                        }))
                        print_pty_log(session_id, "Started", "success")
                    except Exception as e:
                        print_pty_log(session_id, f"Failed: {e}", "error")
                        await ws.send(json.dumps({
                            "type": "pty_error",
                            "session_id": session_id,
                            "error": str(e),
                        }))

                elif msg_type == "pty_input":
                    session_id = msg.get("session_id", "")
                    data = msg.get("data", "")
                    pty_proc = active_pty_sessions.get(session_id)
                    if pty_proc:
                        try:
                            await pty_proc.send_input(data)
                        except Exception as e:
                            print_pty_log(session_id, f"Input error: {e}", "error")
                    else:
                        print_pty_log(session_id, "Input for unknown session", "error")

                elif msg_type == "pty_close":
                    session_id = msg.get("session_id", "")
                    pty_proc = active_pty_sessions.pop(session_id, None)
                    if pty_proc:
                        print_pty_log(session_id, "Closing")
                        await pty_proc.close()
                    else:
                        print_pty_log(session_id, "Close for unknown session", "error")

                elif msg_type == "ping":
                    await ws.send(json.dumps({"type": "pong"}))

                else:
                    print_status("?", f"Unknown message: {msg_type}", YELLOW)

            for sid, pty_proc in active_pty_sessions.items():
                print_pty_log(sid, "Cleaning up on disconnect")
                await pty_proc.close()

    except websockets.exceptions.ConnectionClosed as e:
        print()
        print_status("!", f"Connection closed: {e}", YELLOW)
    except ConnectionRefusedError:
        print()
        print_status("x", f"Could not connect to {ws_endpoint}. Is the server running?", RED)
    except Exception as e:
        print()
        print_status("x", f"Error: {e}", RED)


def main():
    parser = argparse.ArgumentParser(
        description="Kiwi AI CLI Agent — execute terminal commands for LLM agents"
    )
    subparsers = parser.add_subparsers(dest="command")

    connect_parser = subparsers.add_parser("connect", help="Connect to the server")
    connect_parser.add_argument(
        "--server",
        default="local",
        help=(
            "Server to connect to. Use a preset name (local, dev) "
            "or a full URL (e.g. https://custom.server.com). "
            "Presets: local=localhost:8000, dev=dev.api.myautobots.com "
            "(default: local)"
        ),
    )
    connect_parser.add_argument(
        "--email",
        default=None,
        help="Email address (will prompt if not provided)",
    )

    args = parser.parse_args()

    if args.command == "connect":
        print_banner()

        preset = SERVER_PRESETS.get(args.server)
        if preset:
            ws_url = preset["ws"]
            http_url = preset["http"]
        else:
            url = args.server.rstrip("/")
            if url.startswith("wss://"):
                ws_url = url
                http_url = url.replace("wss://", "https://", 1)
            elif url.startswith("ws://"):
                ws_url = url
                http_url = url.replace("ws://", "http://", 1)
            elif url.startswith("https://"):
                http_url = url
                ws_url = url.replace("https://", "wss://", 1)
            elif url.startswith("http://"):
                http_url = url
                ws_url = url.replace("http://", "ws://", 1)
            else:
                http_url = f"https://{url}"
                ws_url = f"wss://{url}"

        server_label = args.server if args.server in SERVER_PRESETS else "custom"
        print_status(">", f"Server: {BOLD}{server_label}{RESET} ({http_url})", C)
        print()

        print_section("Authentication")
        email = args.email
        if email:
            print_status(">", f"Email: {email}", GREY)
        else:
            email = input(f"  {C}>{RESET}  Email: ")
        password = getpass.getpass(f"  {C}>{RESET}  Password: ")
        print()

        loop = asyncio.new_event_loop()

        print_status("~", f"Authenticating with {BOLD}{http_url}{RESET}...", C)
        try:
            token = loop.run_until_complete(login(http_url, email, password))
            print_status(">", "Login successful!", GREEN)
        except Exception as e:
            print_status("x", f"Login failed: {e}", RED)
            loop.close()
            sys.exit(1)

        print_section("Connection")

        def shutdown():
            print()
            print_status("!", "Disconnecting...", YELLOW)
            for task in asyncio.all_tasks(loop):
                task.cancel()

        signal.signal(signal.SIGINT, lambda *_: shutdown())

        try:
            loop.run_until_complete(connect(ws_url, token))
        except asyncio.CancelledError:
            pass
        finally:
            loop.close()
            print()
            print(f"  {GREY}{'─' * 50}{RESET}")
            print_status(">", "Disconnected. Goodbye!", C)
            print()
    else:
        print_banner()
        parser.print_help()


if __name__ == "__main__":
    main()
