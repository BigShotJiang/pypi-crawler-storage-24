# Kiwi AI CLI

Connect your local machine to AI-powered automation.

## Installation

```bash
pip install kiwi-ai-cli
```

## Usage

```bash
# Connect to Kiwi AI
kiwi connect --server dev

# With custom credentials
kiwi connect --email you@example.com --server dev
```

## Requirements

- Python 3.10+
- A Kiwi AI account
