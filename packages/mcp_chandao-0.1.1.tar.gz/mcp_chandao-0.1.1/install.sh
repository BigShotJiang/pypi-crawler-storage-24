#!/bin/bash
set -e

echo "=== mcp-chandao 安装脚本 ==="
echo ""

# 读取配置
read -p "禅道地址 (如 https://zentao.example.com): " ZENTAO_HOST
read -p "禅道账号: " ZENTAO_ACCOUNT
read -sp "禅道密码: " ZENTAO_PASSWORD
echo ""
read -p "默认执行名称 (如 运维): " ZENTAO_EXECUTION
read -p "默认指派人 (默认同账号，直接回车跳过): " ZENTAO_ASSIGNEE

ZENTAO_ASSIGNEE=${ZENTAO_ASSIGNEE:-$ZENTAO_ACCOUNT}

# 配置文件路径
CONFIG_FILE=~/.openclaw/openclaw.json

# 创建配置目录
mkdir -p ~/.openclaw

# 备份原配置
if [ -f "$CONFIG_FILE" ]; then
    echo "备份原配置为 openclaw.json.bak"
    cp "$CONFIG_FILE" "$CONFIG_FILE.bak"
    
    # 读取现有配置并添加 mcpServers
    python3 -c "
import json
import sys

try:
    with open('$CONFIG_FILE', 'r') as f:
        config = json.load(f)
except:
    config = {}

if 'mcpServers' not in config:
    config['mcpServers'] = {}

config['mcpServers']['chandao'] = {
    'command': 'uvx',
    'args': ['mcp-chandao'],
    'env': {
        'ZENTAO_HOST': '$ZENTAO_HOST',
        'ZENTAO_ACCOUNT': '$ZENTAO_ACCOUNT',
        'ZENTAO_PASSWORD': '$ZENTAO_PASSWORD',
        'ZENTAO_DEFAULT_EXECUTION_NAME': '$ZENTAO_EXECUTION',
        'ZENTAO_DEFAULT_ASSIGNEE': '$ZENTAO_ASSIGNEE'
    }
}

with open('$CONFIG_FILE', 'w') as f:
    json.dump(config, f, indent=2, ensure_ascii=False)
" || {
    # Python 失败，直接创建新配置
    cat > "$CONFIG_FILE" <<EOF
{
  "mcpServers": {
    "chandao": {
      "command": "uvx",
      "args": ["mcp-chandao"],
      "env": {
        "ZENTAO_HOST": "$ZENTAO_HOST",
        "ZENTAO_ACCOUNT": "$ZENTAO_ACCOUNT",
        "ZENTAO_PASSWORD": "$ZENTAO_PASSWORD",
        "ZENTAO_DEFAULT_EXECUTION_NAME": "$ZENTAO_EXECUTION",
        "ZENTAO_DEFAULT_ASSIGNEE": "$ZENTAO_ASSIGNEE"
      }
    }
  }
}
EOF
}
else
    # 新建配置
    cat > "$CONFIG_FILE" <<EOF
{
  "mcpServers": {
    "chandao": {
      "command": "uvx",
      "args": ["mcp-chandao"],
      "env": {
        "ZENTAO_HOST": "$ZENTAO_HOST",
        "ZENTAO_ACCOUNT": "$ZENTAO_ACCOUNT",
        "ZENTAO_PASSWORD": "$ZENTAO_PASSWORD",
        "ZENTAO_DEFAULT_EXECUTION_NAME": "$ZENTAO_EXECUTION",
        "ZENTAO_DEFAULT_ASSIGNEE": "$ZENTAO_ASSIGNEE"
      }
    }
  }
}
EOF
fi

echo ""
echo "✓ 配置已写入 $CONFIG_FILE"
echo "✓ 请重启 OpenClaw Gateway 生效"
echo ""
echo "使用方式：在 OpenClaw 中直接说 '创建禅道任务' 即可"
