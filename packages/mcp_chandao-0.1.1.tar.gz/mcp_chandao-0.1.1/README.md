# mcp-chandao

禅道项目管理 MCP Server，支持通过 AI 助手直接管理禅道任务。

## 功能

- 创建任务（支持自动完成）
- 编辑/更新任务
- 删除任务
- 查询任务列表
- 查看任务详情
- 记录工时
- 生成 6R 报表

## 快速安装（OpenClaw）

一键安装脚本：

```bash
curl -fsSL https://raw.githubusercontent.com/your-repo/main/mcp-servers/zentao/install.sh | bash
```

## 手动配置

在 `~/.openclaw/openclaw.json` 中添加 `mcpServers` 字段：

```json
{
  "mcpServers": {
    "chandao": {
      "command": "uvx",
      "args": ["mcp-chandao"],
      "env": {
        "ZENTAO_HOST": "https://zentao.example.com",
        "ZENTAO_ACCOUNT": "admin",
        "ZENTAO_PASSWORD": "your-password",
        "ZENTAO_DEFAULT_EXECUTION_NAME": "运维",
        "ZENTAO_DEFAULT_ASSIGNEE": "admin"
      }
    }
  }
}
```

重启 OpenClaw Gateway 生效。

## 环境变量

| 变量 | 必填 | 说明 |
|------|------|------|
| `ZENTAO_HOST` | 是 | 禅道地址，如 `https://zentao.example.com` |
| `ZENTAO_ACCOUNT` | 是 | 登录账号 |
| `ZENTAO_PASSWORD` | 是 | 登录密码 |
| `ZENTAO_DEFAULT_EXECUTION_NAME` | 是 | 默认执行名称 |
| `ZENTAO_DEFAULT_ASSIGNEE` | 否 | 默认指派人，不填则使用登录账号 |
| `ZENTAO_DEFAULT_TASK_TYPE` | 否 | 默认任务类型，默认 `devel` |
