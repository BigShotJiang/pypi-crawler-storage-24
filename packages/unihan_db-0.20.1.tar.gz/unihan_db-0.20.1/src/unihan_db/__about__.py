"""Metadata for unihan-db."""

from __future__ import annotations

__title__ = "unihan-db"
__package_name__ = "unihan_db"
__description__ = "SQLAlchemy models for UNIHAN CJK database"
__version__ = "0.20.1"
__author__ = "Tony Narlock"
__github__ = "https://github.com/cihai/unihan-db"
__docs__ = "https://unihan-db.git-pull.com"
__tracker__ = "https://github.com/cihai/unihan-db/issues"
__pypi__ = "https://pypi.org/project/unihan-db/"
__email__ = "cihai@git-pull.com"
__license__ = "MIT"
__copyright__ = "Copyright 2017- cihai software foundation (Tony Narlock)"
