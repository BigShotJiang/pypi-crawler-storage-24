"""
Salim Database Layer — SQLite backend replacing all JSON/JSONL files.

Single database: ~/.salim/salim.db
Tables:
  - memory          : persistent user profile key-value store
  - history         : conversation turns with rolling summary
  - agent_runs      : autonomous task run logs with steps
  - agent_tasks     : named persistent task chains
  - schedules       : natural-language scheduled jobs
  - file_index      : file intelligence semantic index
  - webhooks        : registered webhook endpoints
  - proactive_rules : rules for proactive intelligence
  - code_sessions   : iterative coding REPL sessions
  - guard_queue     : offline intrusion alert queue
  - collab_docs     : collaborative documents (replacing JSON files)
  - skills          : loaded skill registry

All access is async via aiosqlite with a synchronous fallback.
Connection pool with WAL journal for concurrent reads.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("salim.db")

DB_PATH = Path.home() / ".salim" / "salim.db"
_local = threading.local()


# ═══════════════════════════════════════════════════════════════════════════════
#  CONNECTION MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════════

def _get_conn() -> sqlite3.Connection:
    """Thread-local SQLite connection with WAL mode and busy timeout."""
    if not hasattr(_local, "conn") or _local.conn is None:
        DB_PATH.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
        conn = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=5000")
        _local.conn = conn
    return _local.conn


@contextmanager
def _tx():
    """Context manager for a transactional database operation."""
    conn = _get_conn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def init_db():
    """Create all tables if they don't exist. Idempotent."""
    with _tx() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS memory (
            user_id     INTEGER NOT NULL,
            key         TEXT    NOT NULL,
            value       TEXT    NOT NULL,
            updated_at  TEXT    NOT NULL DEFAULT (datetime('now')),
            PRIMARY KEY (user_id, key)
        );

        CREATE TABLE IF NOT EXISTS history (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            role        TEXT    NOT NULL,
            content     TEXT    NOT NULL,
            ts          REAL    NOT NULL DEFAULT (unixepoch('now', 'subsec')),
            tokens_est  INTEGER DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS history_user_ts ON history(user_id, ts DESC);

        CREATE TABLE IF NOT EXISTS history_summaries (
            user_id     INTEGER PRIMARY KEY,
            summary     TEXT    NOT NULL,
            up_to_ts    REAL    NOT NULL,
            updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS agent_runs (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            goal        TEXT    NOT NULL,
            status      TEXT    NOT NULL DEFAULT 'running',
            steps_json  TEXT    NOT NULL DEFAULT '[]',
            summary     TEXT,
            started_at  TEXT    NOT NULL DEFAULT (datetime('now')),
            finished_at TEXT,
            chain_id    TEXT
        );
        CREATE INDEX IF NOT EXISTS agent_runs_user ON agent_runs(user_id, started_at DESC);

        CREATE TABLE IF NOT EXISTS agent_task_chains (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            name        TEXT    NOT NULL,
            description TEXT,
            tasks_json  TEXT    NOT NULL DEFAULT '[]',
            trigger     TEXT,
            last_run    TEXT,
            enabled     INTEGER NOT NULL DEFAULT 1,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS schedules (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            chat_id     INTEGER NOT NULL,
            raw_expr    TEXT    NOT NULL,
            cron_spec   TEXT,
            command     TEXT    NOT NULL,
            next_run    REAL    NOT NULL,
            interval_s  REAL,
            enabled     INTEGER NOT NULL DEFAULT 1,
            last_run    TEXT,
            run_count   INTEGER NOT NULL DEFAULT 0,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS schedules_next ON schedules(next_run, enabled);

        CREATE TABLE IF NOT EXISTS file_index (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            path        TEXT    NOT NULL UNIQUE,
            name        TEXT    NOT NULL,
            extension   TEXT,
            size_bytes  INTEGER DEFAULT 0,
            mtime       REAL    DEFAULT 0,
            content_preview TEXT,
            tags        TEXT    DEFAULT '[]',
            indexed_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );
        CREATE INDEX IF NOT EXISTS file_index_name ON file_index(name COLLATE NOCASE);
        CREATE INDEX IF NOT EXISTS file_index_ext  ON file_index(extension);

        CREATE VIRTUAL TABLE IF NOT EXISTS file_fts
        USING fts5(path, name, content_preview, tags);

        CREATE TRIGGER IF NOT EXISTS file_index_ai AFTER INSERT ON file_index BEGIN
          INSERT INTO file_fts(rowid, path, name, content_preview, tags)
          VALUES (new.id, new.path, new.name, new.content_preview, new.tags);
        END;
        CREATE TRIGGER IF NOT EXISTS file_index_au AFTER UPDATE ON file_index BEGIN
          DELETE FROM file_fts WHERE rowid=old.id;
          INSERT INTO file_fts(rowid, path, name, content_preview, tags)
          VALUES (new.id, new.path, new.name, new.content_preview, new.tags);
        END;
        CREATE TRIGGER IF NOT EXISTS file_index_ad AFTER DELETE ON file_index BEGIN
          DELETE FROM file_fts WHERE rowid=old.id;
        END;

        CREATE TABLE IF NOT EXISTS webhooks (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            token       TEXT    NOT NULL UNIQUE,
            name        TEXT    NOT NULL,
            chat_id     INTEGER NOT NULL,
            transform   TEXT,
            enabled     INTEGER NOT NULL DEFAULT 1,
            hit_count   INTEGER NOT NULL DEFAULT 0,
            last_hit    TEXT,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS proactive_rules (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            chat_id     INTEGER NOT NULL,
            rule_type   TEXT    NOT NULL,
            condition   TEXT    NOT NULL,
            action      TEXT    NOT NULL,
            cooldown_s  INTEGER NOT NULL DEFAULT 3600,
            last_fired  TEXT,
            enabled     INTEGER NOT NULL DEFAULT 1,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS code_sessions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            session_id  TEXT    NOT NULL UNIQUE,
            description TEXT,
            language    TEXT    NOT NULL DEFAULT 'python',
            code        TEXT    NOT NULL DEFAULT '',
            iterations  TEXT    NOT NULL DEFAULT '[]',
            status      TEXT    NOT NULL DEFAULT 'active',
            created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
            updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS guard_queue (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            reason      TEXT    NOT NULL,
            ts          TEXT    NOT NULL,
            screenshot  BLOB,
            webcam      BLOB,
            queued_at   TEXT    NOT NULL DEFAULT (datetime('now')),
            sent        INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS collab_docs (
            id          TEXT    PRIMARY KEY,
            title       TEXT    NOT NULL,
            owner_id    INTEGER NOT NULL,
            owner_name  TEXT    NOT NULL,
            content     TEXT    NOT NULL DEFAULT '',
            collaborators TEXT  NOT NULL DEFAULT '[]',
            collaborator_names TEXT NOT NULL DEFAULT '{}',
            comments    TEXT    NOT NULL DEFAULT '[]',
            revision_count INTEGER NOT NULL DEFAULT 0,
            archived    INTEGER NOT NULL DEFAULT 0,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
            updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS collab_revisions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_id      TEXT    NOT NULL,
            rev         INTEGER NOT NULL,
            user_id     INTEGER NOT NULL,
            user_name   TEXT    NOT NULL,
            summary     TEXT,
            snapshot    TEXT    NOT NULL,
            created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
            UNIQUE(doc_id, rev)
        );
        CREATE INDEX IF NOT EXISTS collab_rev_doc ON collab_revisions(doc_id, rev DESC);

        CREATE TABLE IF NOT EXISTS skills (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL UNIQUE,
            path        TEXT    NOT NULL,
            description TEXT,
            commands    TEXT    NOT NULL DEFAULT '{}',
            instructions TEXT,
            version     TEXT,
            loaded_at   TEXT    NOT NULL DEFAULT (datetime('now'))
        );
        """)
    logger.info(f"DB initialized: {DB_PATH}")


# ═══════════════════════════════════════════════════════════════════════════════
#  MEMORY TABLE  (replaces memory/<user_id>.json)
# ═══════════════════════════════════════════════════════════════════════════════

def memory_get(user_id: int, key: str, default: str = "") -> str:
    conn = _get_conn()
    row = conn.execute(
        "SELECT value FROM memory WHERE user_id=? AND key=?", (user_id, key)
    ).fetchone()
    return row["value"] if row else default


def memory_set(user_id: int, key: str, value: str):
    with _tx() as conn:
        conn.execute(
            "INSERT INTO memory(user_id,key,value,updated_at) VALUES(?,?,?,datetime('now')) "
            "ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (user_id, key, value),
        )


def memory_delete(user_id: int, key: str):
    with _tx() as conn:
        conn.execute("DELETE FROM memory WHERE user_id=? AND key=?", (user_id, key))


def memory_all(user_id: int) -> dict[str, str]:
    conn = _get_conn()
    rows = conn.execute("SELECT key,value FROM memory WHERE user_id=?", (user_id,)).fetchall()
    return {r["key"]: r["value"] for r in rows}


def memory_clear(user_id: int):
    with _tx() as conn:
        conn.execute("DELETE FROM memory WHERE user_id=?", (user_id,))


# ═══════════════════════════════════════════════════════════════════════════════
#  HISTORY TABLE  (replaces history/<user_id>.jsonl)
# ═══════════════════════════════════════════════════════════════════════════════

def history_append(user_id: int, role: str, content: str):
    tokens_est = len(content) // 4
    with _tx() as conn:
        conn.execute(
            "INSERT INTO history(user_id,role,content,ts,tokens_est) VALUES(?,?,?,?,?)",
            (user_id, role, content, time.time(), tokens_est),
        )
        # Keep only last 200 rows per user
        conn.execute(
            "DELETE FROM history WHERE user_id=? AND id NOT IN "
            "(SELECT id FROM history WHERE user_id=? ORDER BY ts DESC LIMIT 200)",
            (user_id, user_id),
        )


def history_load(user_id: int, limit: int = 20) -> list[dict]:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT role,content,ts FROM history WHERE user_id=? ORDER BY ts DESC LIMIT ?",
        (user_id, limit),
    ).fetchall()
    return [{"role": r["role"], "content": r["content"], "ts": r["ts"]} for r in reversed(rows)]


def history_clear(user_id: int):
    with _tx() as conn:
        conn.execute("DELETE FROM history WHERE user_id=?", (user_id,))
        conn.execute("DELETE FROM history_summaries WHERE user_id=?", (user_id,))


def history_get_summary(user_id: int) -> str:
    conn = _get_conn()
    row = conn.execute(
        "SELECT summary FROM history_summaries WHERE user_id=?", (user_id,)
    ).fetchone()
    return row["summary"] if row else ""


def history_set_summary(user_id: int, summary: str, up_to_ts: float):
    with _tx() as conn:
        conn.execute(
            "INSERT INTO history_summaries(user_id,summary,up_to_ts,updated_at) VALUES(?,?,?,datetime('now')) "
            "ON CONFLICT(user_id) DO UPDATE SET summary=excluded.summary, up_to_ts=excluded.up_to_ts, updated_at=excluded.updated_at",
            (user_id, summary, up_to_ts),
        )


def history_total_tokens(user_id: int) -> int:
    conn = _get_conn()
    row = conn.execute(
        "SELECT COALESCE(SUM(tokens_est),0) as total FROM history WHERE user_id=?", (user_id,)
    ).fetchone()
    return int(row["total"])


# ═══════════════════════════════════════════════════════════════════════════════
#  AGENT TABLE  (replaces agent/<user_id>_last.json)
# ═══════════════════════════════════════════════════════════════════════════════

def agent_run_start(user_id: int, goal: str, chain_id: Optional[str] = None) -> int:
    with _tx() as conn:
        cur = conn.execute(
            "INSERT INTO agent_runs(user_id,goal,status,steps_json,chain_id) VALUES(?,?,'running','[]',?)",
            (user_id, goal, chain_id),
        )
        return cur.lastrowid


def agent_run_update(run_id: int, steps: list, status: str = "running", summary: str = ""):
    with _tx() as conn:
        conn.execute(
            "UPDATE agent_runs SET steps_json=?, status=?, summary=?, finished_at=? WHERE id=?",
            (json.dumps(steps), status, summary,
             datetime.now().isoformat() if status != "running" else None, run_id),
        )


def agent_run_last(user_id: int) -> Optional[dict]:
    conn = _get_conn()
    row = conn.execute(
        "SELECT * FROM agent_runs WHERE user_id=? ORDER BY started_at DESC LIMIT 1", (user_id,)
    ).fetchone()
    if not row:
        return None
    d = dict(row)
    d["steps"] = json.loads(d.pop("steps_json", "[]"))
    return d


# ═══════════════════════════════════════════════════════════════════════════════
#  SCHEDULES TABLE  (replaces scheduler_jobs.json)
# ═══════════════════════════════════════════════════════════════════════════════

def schedule_create(user_id: int, chat_id: int, raw_expr: str, command: str,
                    next_run: float, interval_s: Optional[float] = None,
                    cron_spec: str = "") -> int:
    with _tx() as conn:
        cur = conn.execute(
            "INSERT INTO schedules(user_id,chat_id,raw_expr,cron_spec,command,next_run,interval_s) "
            "VALUES(?,?,?,?,?,?,?)",
            (user_id, chat_id, raw_expr, cron_spec, command, next_run, interval_s),
        )
        return cur.lastrowid


def schedule_list(user_id: int) -> list[dict]:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM schedules WHERE user_id=? AND enabled=1 ORDER BY next_run", (user_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def schedule_due() -> list[dict]:
    """Return all enabled schedules that are due to run right now."""
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM schedules WHERE enabled=1 AND next_run <= ?", (time.time(),)
    ).fetchall()
    return [dict(r) for r in rows]


def schedule_update_next(sched_id: int, next_run: float):
    with _tx() as conn:
        conn.execute(
            "UPDATE schedules SET next_run=?, last_run=datetime('now'), run_count=run_count+1 WHERE id=?",
            (next_run, sched_id),
        )


def schedule_delete(sched_id: int, user_id: int):
    with _tx() as conn:
        conn.execute("UPDATE schedules SET enabled=0 WHERE id=? AND user_id=?", (sched_id, user_id))


# ═══════════════════════════════════════════════════════════════════════════════
#  FILE INDEX TABLE  (for file intelligence)
# ═══════════════════════════════════════════════════════════════════════════════

def file_index_upsert(path: str, name: str, extension: str, size: int,
                      mtime: float, preview: str, tags: list[str]):
    with _tx() as conn:
        conn.execute(
            "INSERT INTO file_index(path,name,extension,size_bytes,mtime,content_preview,tags) "
            "VALUES(?,?,?,?,?,?,?) "
            "ON CONFLICT(path) DO UPDATE SET name=excluded.name, extension=excluded.extension, "
            "size_bytes=excluded.size_bytes, mtime=excluded.mtime, "
            "content_preview=excluded.content_preview, tags=excluded.tags, "
            "indexed_at=datetime('now')",
            (path, name, extension, size, mtime, preview, json.dumps(tags)),
        )


def file_search(query: str, limit: int = 20) -> list[dict]:
    """Full-text search across file names, previews, and tags."""
    conn = _get_conn()
    try:
        rows = conn.execute(
            "SELECT fi.* FROM file_fts fts JOIN file_index fi ON fts.rowid=fi.id "
            "WHERE file_fts MATCH ? ORDER BY rank LIMIT ?",
            (query, limit),
        ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        # Fallback to LIKE search
        pattern = f"%{query}%"
        rows = conn.execute(
            "SELECT * FROM file_index WHERE name LIKE ? OR content_preview LIKE ? LIMIT ?",
            (pattern, pattern, limit),
        ).fetchall()
        return [dict(r) for r in rows]


def file_index_count() -> int:
    conn = _get_conn()
    return conn.execute("SELECT COUNT(*) as c FROM file_index").fetchone()["c"]


# ═══════════════════════════════════════════════════════════════════════════════
#  WEBHOOK TABLE
# ═══════════════════════════════════════════════════════════════════════════════

def webhook_create(user_id: int, chat_id: int, name: str, token: str,
                   transform: str = "") -> int:
    with _tx() as conn:
        cur = conn.execute(
            "INSERT INTO webhooks(user_id,chat_id,name,token,transform) VALUES(?,?,?,?,?)",
            (user_id, chat_id, name, token, transform),
        )
        return cur.lastrowid


def webhook_get_by_token(token: str) -> Optional[dict]:
    conn = _get_conn()
    row = conn.execute(
        "SELECT * FROM webhooks WHERE token=? AND enabled=1", (token,)
    ).fetchone()
    return dict(row) if row else None


def webhook_list(user_id: int) -> list[dict]:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM webhooks WHERE user_id=? ORDER BY created_at DESC", (user_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def webhook_hit(token: str):
    with _tx() as conn:
        conn.execute(
            "UPDATE webhooks SET hit_count=hit_count+1, last_hit=datetime('now') WHERE token=?",
            (token,),
        )


def webhook_delete(wh_id: int, user_id: int):
    with _tx() as conn:
        conn.execute("UPDATE webhooks SET enabled=0 WHERE id=? AND user_id=?", (wh_id, user_id))


# ═══════════════════════════════════════════════════════════════════════════════
#  PROACTIVE RULES TABLE
# ═══════════════════════════════════════════════════════════════════════════════

def proactive_rule_create(user_id: int, chat_id: int, rule_type: str,
                          condition: str, action: str, cooldown_s: int = 3600) -> int:
    with _tx() as conn:
        cur = conn.execute(
            "INSERT INTO proactive_rules(user_id,chat_id,rule_type,condition,action,cooldown_s) "
            "VALUES(?,?,?,?,?,?)",
            (user_id, chat_id, rule_type, condition, action, cooldown_s),
        )
        return cur.lastrowid


def proactive_rules_get(user_id: int) -> list[dict]:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM proactive_rules WHERE user_id=? AND enabled=1", (user_id,)
    ).fetchall()
    return [dict(r) for r in rows]


def proactive_rule_fired(rule_id: int):
    with _tx() as conn:
        conn.execute(
            "UPDATE proactive_rules SET last_fired=datetime('now') WHERE id=?", (rule_id,)
        )


def proactive_rule_delete(rule_id: int, user_id: int):
    with _tx() as conn:
        conn.execute(
            "UPDATE proactive_rules SET enabled=0 WHERE id=? AND user_id=?", (rule_id, user_id)
        )


# ═══════════════════════════════════════════════════════════════════════════════
#  CODE SESSIONS TABLE  (for iterative self-healing code runs)
# ═══════════════════════════════════════════════════════════════════════════════

def code_session_create(user_id: int, session_id: str, description: str, language: str) -> int:
    with _tx() as conn:
        cur = conn.execute(
            "INSERT INTO code_sessions(user_id,session_id,description,language) VALUES(?,?,?,?)",
            (user_id, session_id, description, language),
        )
        return cur.lastrowid


def code_session_get(session_id: str) -> Optional[dict]:
    conn = _get_conn()
    row = conn.execute(
        "SELECT * FROM code_sessions WHERE session_id=?", (session_id,)
    ).fetchone()
    if not row:
        return None
    d = dict(row)
    d["iterations"] = json.loads(d.get("iterations", "[]"))
    return d


def code_session_update(session_id: str, code: str, iteration: dict):
    conn = _get_conn()
    row = conn.execute(
        "SELECT iterations FROM code_sessions WHERE session_id=?", (session_id,)
    ).fetchone()
    iterations = json.loads(row["iterations"]) if row else []
    iterations.append(iteration)
    with _tx() as conn2:
        conn2.execute(
            "UPDATE code_sessions SET code=?, iterations=?, updated_at=datetime('now') WHERE session_id=?",
            (code, json.dumps(iterations), session_id),
        )


def code_session_last(user_id: int) -> Optional[dict]:
    conn = _get_conn()
    row = conn.execute(
        "SELECT * FROM code_sessions WHERE user_id=? ORDER BY updated_at DESC LIMIT 1",
        (user_id,),
    ).fetchone()
    if not row:
        return None
    d = dict(row)
    d["iterations"] = json.loads(d.get("iterations", "[]"))
    return d


# ═══════════════════════════════════════════════════════════════════════════════
#  GUARD QUEUE TABLE  (replaces guard_queue.jsonl)
# ═══════════════════════════════════════════════════════════════════════════════

def guard_enqueue(reason: str, ts: str, screenshot: Optional[bytes], webcam: Optional[bytes]):
    with _tx() as conn:
        conn.execute(
            "INSERT INTO guard_queue(reason,ts,screenshot,webcam) VALUES(?,?,?,?)",
            (reason, ts, screenshot, webcam),
        )


def guard_pending() -> list[dict]:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM guard_queue WHERE sent=0 ORDER BY queued_at", ()
    ).fetchall()
    return [dict(r) for r in rows]


def guard_mark_sent(alert_id: int):
    with _tx() as conn:
        conn.execute("UPDATE guard_queue SET sent=1 WHERE id=?", (alert_id,))


def guard_clear_sent():
    with _tx() as conn:
        conn.execute("DELETE FROM guard_queue WHERE sent=1")


# ═══════════════════════════════════════════════════════════════════════════════
#  COLLAB DOCS TABLE  (replaces collab_docs/*.json)
# ═══════════════════════════════════════════════════════════════════════════════

def collab_doc_save(doc: dict):
    with _tx() as conn:
        conn.execute(
            "INSERT INTO collab_docs(id,title,owner_id,owner_name,content,collaborators,"
            "collaborator_names,comments,revision_count,archived,created_at,updated_at) "
            "VALUES(:id,:title,:owner_id,:owner_name,:content,:collaborators,"
            ":collaborator_names,:comments,:revision_count,:archived,:created_at,:updated_at) "
            "ON CONFLICT(id) DO UPDATE SET title=excluded.title, content=excluded.content, "
            "collaborators=excluded.collaborators, collaborator_names=excluded.collaborator_names, "
            "comments=excluded.comments, revision_count=excluded.revision_count, "
            "archived=excluded.archived, updated_at=excluded.updated_at",
            {
                "id": doc["id"],
                "title": doc["title"],
                "owner_id": doc["owner"],
                "owner_name": doc.get("owner_name", ""),
                "content": doc.get("content", ""),
                "collaborators": json.dumps(doc.get("collaborators", [])),
                "collaborator_names": json.dumps(doc.get("collaborator_names", {})),
                "comments": json.dumps(doc.get("comments", [])),
                "revision_count": doc.get("revision_count", 0),
                "archived": 1 if doc.get("archived") else 0,
                "created_at": doc.get("created_at", datetime.now().isoformat()),
                "updated_at": doc.get("updated_at", datetime.now().isoformat()),
            },
        )


def collab_doc_load(doc_id: str) -> Optional[dict]:
    conn = _get_conn()
    row = conn.execute("SELECT * FROM collab_docs WHERE id=?", (doc_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["owner"] = d.pop("owner_id")
    d["collaborators"] = json.loads(d.get("collaborators", "[]"))
    d["collaborator_names"] = json.loads(d.get("collaborator_names", "{}"))
    d["comments"] = json.loads(d.get("comments", "[]"))
    d["archived"] = bool(d.get("archived", 0))
    # Load revisions
    revs = conn.execute(
        "SELECT * FROM collab_revisions WHERE doc_id=? ORDER BY rev", (doc_id,)
    ).fetchall()
    d["revisions"] = [dict(r) for r in revs]
    return d


def collab_doc_list(user_id: int) -> list[dict]:
    conn = _get_conn()
    rows = conn.execute(
        "SELECT * FROM collab_docs ORDER BY updated_at DESC", ()
    ).fetchall()
    result = []
    for row in rows:
        collabs = json.loads(row["collaborators"] or "[]")
        if row["owner_id"] == user_id or user_id in collabs:
            d = dict(row)
            d["owner"] = d.pop("owner_id")
            d["collaborators"] = collabs
            d["collaborator_names"] = json.loads(d.get("collaborator_names", "{}"))
            d["comments"] = json.loads(d.get("comments", "[]"))
            d["archived"] = bool(d.get("archived", 0))
            result.append(d)
    return result


def collab_revision_add(doc_id: str, rev: int, user_id: int, user_name: str,
                        summary: str, snapshot: str):
    with _tx() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO collab_revisions(doc_id,rev,user_id,user_name,summary,snapshot) "
            "VALUES(?,?,?,?,?,?)",
            (doc_id, rev, user_id, user_name, summary, snapshot),
        )
        # Keep only last 50 revisions
        conn.execute(
            "DELETE FROM collab_revisions WHERE doc_id=? AND rev NOT IN "
            "(SELECT rev FROM collab_revisions WHERE doc_id=? ORDER BY rev DESC LIMIT 50)",
            (doc_id, doc_id),
        )


def collab_doc_delete(doc_id: str):
    with _tx() as conn:
        conn.execute("DELETE FROM collab_docs WHERE id=?", (doc_id,))
        conn.execute("DELETE FROM collab_revisions WHERE doc_id=?", (doc_id,))
