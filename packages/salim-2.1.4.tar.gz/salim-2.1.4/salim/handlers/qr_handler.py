"""
salim.handlers.qr_handler — QR Code Generator + Reader
/qr <text>       — generate a QR code image
/qrread          — read QR code from a photo you send
"""
from __future__ import annotations
import io
import logging
from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger(__name__)


def _ensure_qrcode():
    from salim.auto_install import ensure_one
    return ensure_one("qrcode", "qrcode[pil]>=7.4")

def _ensure_pyzbar():
    from salim.auto_install import ensure_one
    return ensure_one("pyzbar", "pyzbar>=0.1.9")


class QRHandlers:

    @require_auth
    async def cmd_qr(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Generate a QR code. Usage: /qr <text or URL>"""
        text = " ".join(ctx.args) if ctx.args else ""
        if not text:
            await update.effective_message.reply_text("Usage: /qr <text or URL>")
            return

        if not _ensure_qrcode():
            await update.effective_message.reply_text("❌ qrcode library could not be installed.")
            return

        try:
            import qrcode
            from PIL import Image

            qr = qrcode.QRCode(
                version=None,
                error_correction=qrcode.constants.ERROR_CORRECT_H,
                box_size=10,
                border=4,
            )
            qr.add_data(text)
            qr.make(fit=True)
            img: Image.Image = qr.make_image(fill_color="black", back_color="white")

            buf = io.BytesIO()
            img.save(buf, format="PNG")
            buf.seek(0)

            await update.effective_message.reply_photo(
                photo=buf,
                caption=f"📱 QR code for:\n<code>{text[:200]}</code>",
                parse_mode="HTML"
            )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ QR generation failed: {e}")

    @require_auth
    async def cmd_qrread(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Read a QR code from a photo. Send the photo with caption /qrread"""
        msg = update.effective_message
        photo = msg.photo
        if not photo:
            # Check reply
            if msg.reply_to_message and msg.reply_to_message.photo:
                photo = msg.reply_to_message.photo
            else:
                await msg.reply_text("📷 Send a photo with /qrread as the caption, or reply to a photo.")
                return

        if not _ensure_pyzbar():
            await msg.reply_text(
                "❌ pyzbar could not be installed. Also ensure libzbar is installed:\n"
                "  Linux: sudo apt install libzbar0\n"
                "  Mac: brew install zbar"
            )
            return

        try:
            from pyzbar.pyzbar import decode as pyzbar_decode
            from PIL import Image

            file = await ctx.bot.get_file(photo[-1].file_id)
            buf = io.BytesIO()
            await file.download_to_memory(buf)
            buf.seek(0)

            img = Image.open(buf)
            codes = pyzbar_decode(img)

            if not codes:
                await msg.reply_text("🔍 No QR code found in the image.")
                return

            lines = []
            for c in codes:
                data = c.data.decode("utf-8", errors="replace")
                lines.append(f"✅ <code>{data}</code>")

            await msg.reply_text(
                f"📱 <b>QR Code(s) found:</b>\n\n" + "\n\n".join(lines),
                parse_mode="HTML"
            )
        except Exception as e:
            await msg.reply_text(f"❌ QR read failed: {e}")
