"""
Salim Browser Automation v2 — Production-grade Playwright-powered browser control.

Features over v1:
  • Full JavaScript SPA support (waits for network idle, not just page load)
  • Smart element interaction: CSS, XPath, text content, ARIA labels
  • Form filling, file upload, drag-and-drop
  • Cookie/session persistence across commands
  • Request interception (block ads, capture API responses)
  • Multi-tab support
  • AI-assisted selectors: describe what you want in plain English
  • DOM snapshot + structured data extraction
  • Screenshot with element highlighting
  • Browser console log capture

Commands:
  /browse <url>                      — navigate and screenshot
  /browse_click <selector|text>      — click an element
  /browse_type <selector> <text>     — type into input
  /browse_fill <desc> <value>        — AI finds field and fills it
  /browse_submit                     — submit current form
  /browse_get <selector>             — get element text/value
  /browse_wait <selector>            — wait for element to appear
  /browse_scroll <up|down|px>        — scroll page
  /browse_back                       — navigate back
  /browse_forward                    — navigate forward
  /browse_reload                     — reload page
  /browse_js <js code>               — execute JavaScript
  /browse_extract <what>             — AI extracts structured data
  /browse_screenshot                 — take screenshot of current page
  /browse_close                      — close session
  /browse_status                     — show current URL, title, tabs
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.browser2")

H = "HTML"
esc = lambda v: html.escape(str(v), quote=False)

# Per-chat Playwright session
_sessions: dict[int, "BrowserSession"] = {}

PAGE_TIMEOUT_MS   = 30_000
SCREENSHOT_QUALITY = 80


# ═══════════════════════════════════════════════════════════════════════════════
#  DEPENDENCY MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════════

_playwright_ok: Optional[bool] = None

async def _ensure_playwright() -> tuple[bool, str]:
    """Install playwright + Chromium if not present. Cached after first check."""
    global _playwright_ok
    if _playwright_ok is True:
        return True, ""
    if _playwright_ok is False:
        return False, "Playwright unavailable (install failed earlier)"

    # Try importing
    try:
        from playwright.async_api import async_playwright
        # Quick check that chromium is usable
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True, args=["--no-sandbox"])
            await browser.close()
        _playwright_ok = True
        return True, ""
    except ImportError:
        pass
    except Exception as e:
        # Browser not downloaded yet
        if "Executable doesn't exist" in str(e) or "not found" in str(e).lower():
            ok, msg = await _install_chromium()
            if ok:
                _playwright_ok = True
            else:
                _playwright_ok = False
            return ok, msg
        _playwright_ok = False
        return False, str(e)

    # Install pip package
    logger.info("Installing playwright package…")
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "pip", "install", "playwright", "--quiet",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await asyncio.wait_for(proc.communicate(), timeout=120)
    if proc.returncode != 0:
        _playwright_ok = False
        return False, f"pip install playwright failed: {stderr.decode()[:300]}"

    return await _install_chromium()


async def _install_chromium() -> tuple[bool, str]:
    logger.info("Installing Chromium via playwright…")
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "playwright", "install", "chromium", "--with-deps",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
    )
    try:
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=300)
        if proc.returncode != 0:
            return False, f"playwright install chromium failed: {stderr.decode()[:300]}"
        return True, ""
    except asyncio.TimeoutError:
        return False, "Chromium download timed out (>5 min)"


# ═══════════════════════════════════════════════════════════════════════════════
#  BROWSER SESSION
# ═══════════════════════════════════════════════════════════════════════════════

class BrowserSession:
    """Persistent Playwright browser session for one chat."""

    def __init__(self):
        self._pw       = None
        self._browser  = None
        self._context  = None
        self.pages: list = []          # list of Page objects
        self._current  = 0             # active tab index
        self._console_logs: list[str] = []
        self._network_log: list[dict] = []

    @property
    def page(self):
        if self.pages and self._current < len(self.pages):
            return self.pages[self._current]
        return None

    async def start(self) -> tuple[bool, str]:
        try:
            from playwright.async_api import async_playwright
            self._pw = await async_playwright().start()
            self._browser = await self._pw.chromium.launch(
                headless=True,
                args=[
                    "--no-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-gpu",
                    "--disable-extensions",
                    "--disable-background-timer-throttling",
                ],
            )
            self._context = await self._browser.new_context(
                viewport={"width": 1280, "height": 900},
                user_agent=(
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                ),
                ignore_https_errors=True,
            )
            page = await self._context.new_page()
            # Capture console logs
            page.on("console", lambda msg: self._console_logs.append(
                f"[{msg.type}] {msg.text}"
            ))
            # Capture network responses for API monitoring
            page.on("response", lambda resp: self._network_log.append(
                {"url": resp.url, "status": resp.status, "type": resp.request.resource_type}
            ) if resp.request.resource_type in ("fetch", "xhr") else None)
            self.pages = [page]
            self._current = 0
            return True, ""
        except Exception as e:
            return False, str(e)

    async def navigate(self, url: str) -> tuple[bool, str]:
        """Navigate to URL, wait for network idle."""
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        try:
            resp = await self.page.goto(
                url,
                wait_until="networkidle",
                timeout=PAGE_TIMEOUT_MS,
            )
            title = await self.page.title()
            status = resp.status if resp else "?"
            return True, f"✅ Loaded: {title} [{status}] — {self.page.url}"
        except Exception as e:
            # Try with domcontentloaded fallback
            try:
                resp = await self.page.goto(url, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT_MS)
                title = await self.page.title()
                return True, f"⚠️ Partial load: {title} — {self.page.url}"
            except Exception as e2:
                return False, f"Navigation failed: {e2}"

    async def screenshot(self, full_page: bool = True) -> Optional[bytes]:
        """Take a screenshot, returns PNG bytes."""
        try:
            data = await self.page.screenshot(
                full_page=full_page,
                type="jpeg",
                quality=SCREENSHOT_QUALITY,
            )
            # If >3MB, take viewport-only screenshot
            if len(data) > 3_000_000:
                data = await self.page.screenshot(
                    full_page=False,
                    type="jpeg",
                    quality=70,
                )
            return data
        except Exception as e:
            logger.error(f"Screenshot failed: {e}")
            return None

    async def find_element(self, selector_or_text: str, ai=None):
        """
        Find an element by CSS, XPath, text content, or ARIA.
        Falls back to AI-generated selector if simple methods fail.
        """
        page = self.page
        strategies = [
            # Direct CSS selector
            lambda s: page.locator(s).first,
            # Text content
            lambda s: page.get_by_text(s, exact=False).first,
            # ARIA label
            lambda s: page.get_by_label(s).first,
            # Placeholder
            lambda s: page.get_by_placeholder(s).first,
            # Role button
            lambda s: page.get_by_role("button", name=s).first,
            # Role link
            lambda s: page.get_by_role("link", name=s).first,
        ]

        for strategy in strategies:
            try:
                el = strategy(selector_or_text)
                await el.wait_for(timeout=3000, state="attached")
                return el
            except Exception:
                continue

        # AI-assisted: get page DOM and ask AI for selector
        if ai:
            try:
                dom = await page.evaluate(
                    "() => document.body.innerHTML.slice(0, 8000)"
                )
                prompt = (
                    f"Find a CSS selector for: '{selector_or_text}'\n\n"
                    f"Page DOM (truncated):\n{dom[:3000]}\n\n"
                    f"Return ONLY the CSS selector string, nothing else."
                )
                sel, _ = await ai._call_with_fallback(
                    [{"role": "user", "content": prompt}],
                    system="You output only valid CSS selectors. No explanation.",
                    max_tokens=100,
                )
                sel = sel.strip().strip("'\"")
                el = page.locator(sel).first
                await el.wait_for(timeout=3000, state="attached")
                return el
            except Exception:
                pass

        return None

    async def click(self, selector_or_text: str, ai=None) -> tuple[bool, str]:
        el = await self.find_element(selector_or_text, ai)
        if not el:
            return False, f"Element not found: '{selector_or_text}'"
        try:
            await el.scroll_into_view_if_needed()
            await el.click(timeout=5000)
            await self.page.wait_for_load_state("networkidle", timeout=5000)
            return True, f"Clicked: {selector_or_text}"
        except Exception as e:
            return False, f"Click failed: {e}"

    async def type_text(self, selector_or_text: str, text: str, ai=None) -> tuple[bool, str]:
        el = await self.find_element(selector_or_text, ai)
        if not el:
            return False, f"Input field not found: '{selector_or_text}'"
        try:
            await el.scroll_into_view_if_needed()
            await el.triple_click()      # select all existing
            await el.type(text, delay=30)  # realistic typing speed
            return True, f"Typed '{text[:50]}' into {selector_or_text}"
        except Exception as e:
            return False, f"Type failed: {e}"

    async def fill(self, selector_or_text: str, value: str, ai=None) -> tuple[bool, str]:
        """Fill a form field (faster than type — no delay)."""
        el = await self.find_element(selector_or_text, ai)
        if not el:
            return False, f"Field not found: '{selector_or_text}'"
        try:
            await el.fill(value, timeout=5000)
            return True, f"Filled '{selector_or_text}' with '{value[:50]}'"
        except Exception as e:
            return False, f"Fill failed: {e}"

    async def get_text(self, selector: str, ai=None) -> tuple[bool, str]:
        el = await self.find_element(selector, ai)
        if not el:
            return False, f"Element not found: '{selector}'"
        try:
            text = await el.inner_text(timeout=3000)
            return True, text.strip()[:2000]
        except Exception as e:
            return False, f"Get text failed: {e}"

    async def wait_for(self, selector: str) -> tuple[bool, str]:
        try:
            await self.page.wait_for_selector(selector, timeout=PAGE_TIMEOUT_MS)
            return True, f"Element appeared: {selector}"
        except Exception as e:
            return False, f"Timeout waiting for: {selector}"

    async def execute_js(self, code: str) -> tuple[bool, str]:
        try:
            result = await self.page.evaluate(code)
            return True, str(result)[:2000]
        except Exception as e:
            return False, f"JS error: {e}"

    async def extract_data(self, description: str, ai) -> tuple[bool, str]:
        """Use AI to extract structured data from the current page."""
        try:
            # Get page text content
            text = await self.page.evaluate(
                "() => document.body.innerText.slice(0, 8000)"
            )
            url = self.page.url
            title = await self.page.title()

            prompt = (
                f"Extract the following from this web page:\n{description}\n\n"
                f"Page URL: {url}\nTitle: {title}\n\nContent:\n{text[:5000]}\n\n"
                f"Return the extracted data as structured JSON. If nothing found, return {{\"result\":\"not found\"}}."
            )
            result, _ = await ai._call_with_fallback(
                [{"role": "user", "content": prompt}],
                system="You extract structured data from web pages. Return only JSON.",
                max_tokens=1000,
            )
            return True, result
        except Exception as e:
            return False, f"Extraction failed: {e}"

    async def scroll(self, direction: str) -> tuple[bool, str]:
        try:
            if direction in ("down", "d"):
                await self.page.keyboard.press("PageDown")
            elif direction in ("up", "u"):
                await self.page.keyboard.press("PageUp")
            elif direction.lstrip("-").isdigit():
                px = int(direction)
                await self.page.evaluate(f"window.scrollBy(0, {px})")
            elif direction == "top":
                await self.page.keyboard.press("Home")
            elif direction == "bottom":
                await self.page.keyboard.press("End")
            return True, f"Scrolled {direction}"
        except Exception as e:
            return False, str(e)

    async def get_page_info(self) -> dict:
        try:
            url   = self.page.url
            title = await self.page.title()
            h1s   = await self.page.evaluate(
                "() => Array.from(document.querySelectorAll('h1,h2')).slice(0,5).map(e=>e.innerText)"
            )
            links = await self.page.evaluate(
                "() => Array.from(document.querySelectorAll('a[href]')).slice(0,10)"
                ".map(a=>({text:a.innerText.trim().slice(0,50),href:a.href}))"
            )
            return {"url": url, "title": title, "headings": h1s, "links": links}
        except Exception:
            return {"url": str(self.page.url) if self.page else "?", "title": "?"}

    async def close(self):
        try:
            if self._browser:
                await self._browser.close()
            if self._pw:
                await self._pw.stop()
        except Exception:
            pass
        finally:
            self._pw = self._browser = self._context = None
            self.pages = []


# ═══════════════════════════════════════════════════════════════════════════════
#  SESSION HELPER
# ═══════════════════════════════════════════════════════════════════════════════

async def _get_or_create_session(chat_id: int) -> tuple["BrowserSession", str]:
    """Return existing or create new browser session."""
    if chat_id in _sessions:
        sess = _sessions[chat_id]
        if sess.page is not None:
            return sess, ""
        # Session exists but browser died — restart
        await sess.close()
        del _sessions[chat_id]

    ok, err = await _ensure_playwright()
    if not ok:
        return None, f"Playwright unavailable: {err}"

    sess = BrowserSession()
    started, err = await sess.start()
    if not started:
        return None, f"Could not start browser: {err}"

    _sessions[chat_id] = sess
    return sess, ""


# ═══════════════════════════════════════════════════════════════════════════════
#  BOT HANDLER MIXIN
# ═══════════════════════════════════════════════════════════════════════════════

class BrowserHandlers:

    @require_auth
    async def cmd_browse(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /browse <url>  — navigate to URL, screenshot, send to Telegram
        """
        msg = update.effective_message
        chat_id = update.effective_chat.id
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "🌐 <b>Browser Automation</b>\n\n"
                "<code>/browse https://news.ycombinator.com</code>\n"
                "<code>/browse_click Login</code>\n"
                "<code>/browse_type email user@example.com</code>\n"
                "<code>/browse_fill password mypass123</code>\n"
                "<code>/browse_extract top 5 headlines</code>\n"
                "<code>/browse_js document.title</code>\n"
                "<code>/browse_screenshot</code>\n"
                "<code>/browse_close</code>",
                parse_mode=H,
            )
            return

        url = args[0]
        status = await msg.reply_text(f"🌐 <i>Opening {esc(url)}…</i>", parse_mode=H)

        sess, err = await _get_or_create_session(chat_id)
        if not sess:
            await status.edit_text(
                f"❌ <b>Browser unavailable</b>\n<code>{esc(err)}</code>\n\n"
                "<i>Install playwright: <code>pip install playwright && playwright install chromium</code></i>",
                parse_mode=H,
            )
            return

        nav_ok, nav_msg = await sess.navigate(url)

        info = await sess.get_page_info()
        screenshot = await sess.screenshot()

        summary = (
            f"{'✅' if nav_ok else '⚠️'} <b>{esc(info.get('title','?'))}</b>\n"
            f"🔗 <code>{esc(info.get('url','?')[:80])}</code>"
        )
        headings = info.get("headings", [])
        if headings:
            summary += "\n<b>Headings:</b> " + " · ".join(esc(h[:40]) for h in headings[:3])

        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("🔄 Reload",    callback_data=f"br_reload:{chat_id}"),
            InlineKeyboardButton("⬅️ Back",      callback_data=f"br_back:{chat_id}"),
            InlineKeyboardButton("📸 Screenshot", callback_data=f"br_ss:{chat_id}"),
        ]])

        if screenshot:
            await status.delete()
            await msg.reply_photo(
                photo=io.BytesIO(screenshot),
                caption=summary,
                parse_mode=H,
                reply_markup=keyboard,
            )
        else:
            await status.edit_text(summary, parse_mode=H, reply_markup=keyboard)

    @require_auth
    async def cmd_browse_click(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        chat_id = update.effective_chat.id
        selector = " ".join(ctx.args or [])
        if not selector:
            await msg.reply_text("Usage: <code>/browse_click &lt;selector or text&gt;</code>", parse_mode=H)
            return

        sess, err = await _get_or_create_session(chat_id)
        if not sess:
            await msg.reply_text(f"❌ No browser session. Use /browse first.", parse_mode=H)
            return

        ai = getattr(self, "_ai", None)
        ok, result = await sess.click(selector, ai=ai)
        screenshot = await sess.screenshot() if ok else None
        info = await sess.get_page_info()

        if screenshot:
            await msg.reply_photo(
                photo=io.BytesIO(screenshot),
                caption=f"{'✅' if ok else '❌'} {esc(result)}\n🔗 {esc(info.get('url','')[:60])}",
                parse_mode=H,
            )
        else:
            await msg.reply_text(
                f"{'✅' if ok else '❌'} {esc(result)}", parse_mode=H
            )

    @require_auth
    async def cmd_browse_type(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        chat_id = update.effective_chat.id
        args = ctx.args or []
        if len(args) < 2:
            await msg.reply_text("Usage: <code>/browse_type &lt;selector&gt; &lt;text&gt;</code>", parse_mode=H)
            return

        selector = args[0]
        text = " ".join(args[1:])

        sess, err = await _get_or_create_session(chat_id)
        if not sess:
            await msg.reply_text("❌ No browser session.", parse_mode=H)
            return

        ai = getattr(self, "_ai", None)
        ok, result = await sess.type_text(selector, text, ai=ai)
        await msg.reply_text(f"{'✅' if ok else '❌'} {esc(result)}", parse_mode=H)

    @require_auth
    async def cmd_browse_fill(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """AI-assisted form field filling. /browse_fill <field description> <value>"""
        msg = update.effective_message
        chat_id = update.effective_chat.id
        args = ctx.args or []
        if len(args) < 2:
            await msg.reply_text("Usage: <code>/browse_fill &lt;field desc&gt; &lt;value&gt;</code>", parse_mode=H)
            return

        selector = args[0]
        value = " ".join(args[1:])
        sess, err = await _get_or_create_session(chat_id)
        if not sess:
            await msg.reply_text("❌ No browser session.", parse_mode=H)
            return

        ai = getattr(self, "_ai", None)
        ok, result = await sess.fill(selector, value, ai=ai)
        await msg.reply_text(f"{'✅' if ok else '❌'} {esc(result)}", parse_mode=H)

    @require_auth
    async def cmd_browse_get(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        chat_id = update.effective_chat.id
        selector = " ".join(ctx.args or [])
        if not selector:
            await msg.reply_text("Usage: <code>/browse_get &lt;selector or text&gt;</code>", parse_mode=H)
            return

        sess, err = await _get_or_create_session(chat_id)
        if not sess:
            await msg.reply_text("❌ No browser session.", parse_mode=H)
            return

        ai = getattr(self, "_ai", None)
        ok, result = await sess.get_text(selector, ai=ai)
        await msg.reply_text(
            f"{'✅' if ok else '❌'} <b>{esc(selector)}</b>:\n<pre>{esc(result[:1000])}</pre>",
            parse_mode=H,
        )

    @require_auth
    async def cmd_browse_js(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        chat_id = update.effective_chat.id
        code = " ".join(ctx.args or [])
        if not code:
            await msg.reply_text("Usage: <code>/browse_js &lt;javascript code&gt;</code>", parse_mode=H)
            return

        sess, err = await _get_or_create_session(chat_id)
        if not sess:
            await msg.reply_text("❌ No browser session.", parse_mode=H)
            return

        ok, result = await sess.execute_js(code)
        await msg.reply_text(
            f"{'✅' if ok else '❌'} <b>JS Result:</b>\n<pre>{esc(str(result)[:2000])}</pre>",
            parse_mode=H,
        )

    @require_auth
    async def cmd_browse_extract(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """AI-powered structured data extraction from current page."""
        msg = update.effective_message
        chat_id = update.effective_chat.id
        description = " ".join(ctx.args or [])
        if not description:
            await msg.reply_text(
                "Usage: <code>/browse_extract &lt;what to extract&gt;</code>\n\n"
                "Examples:\n"
                "<code>/browse_extract top 10 article titles and URLs</code>\n"
                "<code>/browse_extract product names and prices</code>\n"
                "<code>/browse_extract all form field names</code>",
                parse_mode=H,
            )
            return

        sess, err = await _get_or_create_session(chat_id)
        if not sess:
            await msg.reply_text("❌ No browser session. Use /browse first.", parse_mode=H)
            return

        status = await msg.reply_text("🤖 <i>Extracting data…</i>", parse_mode=H)
        ai = getattr(self, "_ai", None)
        if not ai:
            await status.edit_text("❌ AI not configured.", parse_mode=H)
            return

        ok, result = await sess.extract_data(description, ai)
        # Try to pretty-print if JSON
        try:
            parsed = json.loads(result)
            result = json.dumps(parsed, indent=2, ensure_ascii=False)
        except Exception:
            pass

        if len(result) > 3500:
            buf = io.BytesIO(result.encode())
            buf.name = "extracted_data.json"
            await status.delete()
            await msg.reply_document(document=buf, filename="extracted_data.json",
                                     caption=f"✅ Extracted: {description[:80]}")
        else:
            await status.edit_text(
                f"✅ <b>Extracted:</b> {esc(description[:60])}\n\n<pre>{esc(result[:3000])}</pre>",
                parse_mode=H,
            )

    @require_auth
    async def cmd_browse_scroll(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        chat_id = update.effective_chat.id
        direction = (ctx.args or ["down"])[0].lower()

        sess, err = await _get_or_create_session(chat_id)
        if not sess:
            await msg.reply_text("❌ No browser session.", parse_mode=H)
            return

        ok, result = await sess.scroll(direction)
        screenshot = await sess.screenshot(full_page=False)
        if screenshot:
            await msg.reply_photo(
                photo=io.BytesIO(screenshot),
                caption=f"{'✅' if ok else '❌'} {esc(result)}",
                parse_mode=H,
            )
        else:
            await msg.reply_text(f"{'✅' if ok else '❌'} {esc(result)}", parse_mode=H)

    @require_auth
    async def cmd_browse_back(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        chat_id = update.effective_chat.id
        sess, _ = await _get_or_create_session(chat_id)
        if not sess:
            await update.effective_message.reply_text("❌ No browser session.", parse_mode=H)
            return
        try:
            await sess.page.go_back(timeout=PAGE_TIMEOUT_MS)
            info = await sess.get_page_info()
            ss = await sess.screenshot(full_page=False)
            if ss:
                await update.effective_message.reply_photo(
                    photo=io.BytesIO(ss),
                    caption=f"⬅️ Back: {esc(info.get('title','?'))}\n{esc(info.get('url','')[:60])}",
                    parse_mode=H,
                )
            else:
                await update.effective_message.reply_text(
                    f"⬅️ Back: {esc(info.get('url','')[:80])}", parse_mode=H
                )
        except Exception as e:
            await update.effective_message.reply_text(f"❌ {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_browse_reload(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        chat_id = update.effective_chat.id
        sess, _ = await _get_or_create_session(chat_id)
        if not sess:
            await update.effective_message.reply_text("❌ No browser session.", parse_mode=H)
            return
        await sess.page.reload(wait_until="networkidle", timeout=PAGE_TIMEOUT_MS)
        ss = await sess.screenshot(full_page=False)
        info = await sess.get_page_info()
        if ss:
            await update.effective_message.reply_photo(
                photo=io.BytesIO(ss),
                caption=f"🔄 Reloaded: {esc(info.get('title','?'))}",
                parse_mode=H,
            )

    @require_auth
    async def cmd_browse_screenshot(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        chat_id = update.effective_chat.id
        sess, err = await _get_or_create_session(chat_id)
        if not sess:
            await update.effective_message.reply_text(f"❌ No browser session: {esc(err)}", parse_mode=H)
            return
        info = await sess.get_page_info()
        ss = await sess.screenshot()
        if ss:
            await update.effective_message.reply_photo(
                photo=io.BytesIO(ss),
                caption=f"📸 {esc(info.get('title','?'))}\n{esc(info.get('url','?')[:80])}",
                parse_mode=H,
            )
        else:
            await update.effective_message.reply_text("❌ Screenshot failed.", parse_mode=H)

    @require_auth
    async def cmd_browse_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        chat_id = update.effective_chat.id
        if chat_id not in _sessions:
            await update.effective_message.reply_text("🌐 No active browser session. Use /browse <url>", parse_mode=H)
            return
        sess = _sessions[chat_id]
        info = await sess.get_page_info()
        log_excerpt = "\n".join(sess._console_logs[-5:]) if sess._console_logs else "(none)"
        await update.effective_message.reply_text(
            f"🌐 <b>Browser Status</b>\n\n"
            f"📍 <b>URL:</b> <code>{esc(info.get('url','?')[:100])}</code>\n"
            f"📄 <b>Title:</b> {esc(info.get('title','?'))}\n"
            f"📑 <b>Tabs:</b> {len(sess.pages)}\n\n"
            f"<b>Console (last 5):</b>\n<pre>{esc(log_excerpt[:400])}</pre>",
            parse_mode=H,
        )

    @require_auth
    async def cmd_browse_close(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        chat_id = update.effective_chat.id
        if chat_id in _sessions:
            await _sessions[chat_id].close()
            del _sessions[chat_id]
            await update.effective_message.reply_text("🔒 Browser session closed.")
        else:
            await update.effective_message.reply_text("ℹ️ No browser session to close.")

    async def handle_browser_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data or ""

        if data.startswith("br_reload:"):
            chat_id = int(data.split(":")[1])
            ctx.args = []
            await self.cmd_browse_reload(update, ctx)

        elif data.startswith("br_back:"):
            chat_id = int(data.split(":")[1])
            ctx.args = []
            await self.cmd_browse_back(update, ctx)

        elif data.startswith("br_ss:"):
            chat_id = int(data.split(":")[1])
            ctx.args = []
            await self.cmd_browse_screenshot(update, ctx)
