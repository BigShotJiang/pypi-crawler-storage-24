"""
Salim Intelligence Suite — 6 production-grade features in one module:

1. FILE INTELLIGENCE  — semantic search, content indexing, duplicate detection
2. SMART CONVERSATION CONTEXT — rolling summary, token-aware injection
3. NATURAL LANGUAGE SCHEDULING — parse "every Monday at 8am" into real schedules
4. CODE REPL  — iterative coding with self-healing: AI writes → runs → fixes → reports
5. PROACTIVE INTELLIGENCE — user-defined condition/action rules, fired autonomously
6. WEBHOOK RECEIVER — HTTP endpoints that forward payloads to Telegram
"""
from __future__ import annotations

import asyncio
import hashlib
import html
import io
import json
import logging
import os
import re
import secrets
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, ContextTypes

from salim.auth import require_auth
from salim.db import (
    init_db,
    file_index_upsert, file_search, file_index_count,
    history_load, history_append, history_get_summary, history_set_summary, history_total_tokens,
    schedule_create, schedule_list, schedule_due, schedule_update_next, schedule_delete,
    webhook_create, webhook_get_by_token, webhook_list, webhook_hit, webhook_delete,
    proactive_rule_create, proactive_rules_get, proactive_rule_fired, proactive_rule_delete,
    code_session_create, code_session_get, code_session_update, code_session_last,
    memory_get, memory_set,
    _get_conn,
)

logger = logging.getLogger("salim.intelligence")

esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"


# ═══════════════════════════════════════════════════════════════════════════════
#  1. FILE INTELLIGENCE
# ═══════════════════════════════════════════════════════════════════════════════

# File types to index with content preview extraction
INDEXABLE_EXTENSIONS = {
    ".txt", ".md", ".py", ".js", ".ts", ".json", ".yaml", ".yml",
    ".html", ".css", ".sh", ".csv", ".xml", ".conf", ".cfg", ".env",
    ".log", ".rst", ".toml", ".ini",
}
BINARY_EXTENSIONS = {".pdf", ".docx", ".xlsx", ".pptx"}
SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv", "venv", ".cache", ".npm"}

INDEX_LOCK = asyncio.Lock()


async def index_directory(
    directory: Path,
    progress_cb=None,   # async callable(n_done, n_total, current_path)
    max_files: int = 10_000,
) -> dict:
    """
    Walk a directory and index all files into the SQLite file_index table.
    Extracts content previews for text files.
    Returns {"indexed": n, "skipped": m, "errors": k}.
    """
    async with INDEX_LOCK:
        stats = {"indexed": 0, "skipped": 0, "errors": 0}
        files_to_process = []

        for root, dirs, files in os.walk(directory):
            # Skip hidden and blacklisted directories
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
            for fname in files:
                if len(files_to_process) >= max_files:
                    break
                fp = Path(root) / fname
                files_to_process.append(fp)

        total = len(files_to_process)
        for i, fp in enumerate(files_to_process):
            if progress_cb and i % 100 == 0:
                await progress_cb(i, total, str(fp))
            try:
                stat = fp.stat()
                ext = fp.suffix.lower()
                preview = ""
                tags = []

                # Extract content preview
                if ext in INDEXABLE_EXTENSIONS and stat.st_size < 500_000:
                    try:
                        text = fp.read_text(errors="replace")
                        preview = text[:500].strip()
                        # Extract keywords as tags
                        words = re.findall(r"\b[a-zA-Z]{4,15}\b", text[:2000])
                        freq = {}
                        for w in words:
                            freq[w.lower()] = freq.get(w.lower(), 0) + 1
                        tags = sorted(freq, key=freq.get, reverse=True)[:10]
                    except Exception:
                        pass

                file_index_upsert(
                    path=str(fp),
                    name=fp.name,
                    extension=ext,
                    size=stat.st_size,
                    mtime=stat.st_mtime,
                    preview=preview,
                    tags=tags,
                )
                stats["indexed"] += 1
            except Exception:
                stats["errors"] += 1

        return stats


async def find_duplicates(directory: Path, min_size: int = 1024) -> list[list[str]]:
    """Find duplicate files by content hash. Returns list of groups."""
    hash_map: dict[str, list[str]] = {}
    for fp in directory.rglob("*"):
        if not fp.is_file():
            continue
        try:
            if fp.stat().st_size < min_size:
                continue
            h = hashlib.md5(fp.read_bytes()).hexdigest()
            hash_map.setdefault(h, []).append(str(fp))
        except Exception:
            pass
    return [paths for paths in hash_map.values() if len(paths) > 1]


class FileIntelligenceHandlers:

    @require_auth
    async def cmd_fileidx(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /fileidx [path]     — index a directory for semantic search
        /fileidx search <q> — search indexed files
        /fileidx dupes [path] — find duplicate files
        /fileidx stats      — show index statistics
        """
        msg = update.effective_message
        args = ctx.args or []

        if not args:
            n = file_index_count()
            await msg.reply_text(
                f"📂 <b>File Intelligence</b>\n\n"
                f"📊 Index: <b>{n:,}</b> files\n\n"
                f"<code>/fileidx ~/Documents</code> — index a directory\n"
                f"<code>/fileidx search resume</code> — semantic file search\n"
                f"<code>/fileidx search python project</code> — content search\n"
                f"<code>/fileidx dupes ~/Downloads</code> — find duplicates\n"
                f"<code>/fileidx stats</code> — index statistics",
                parse_mode=H,
            )
            return

        sub = args[0].lower()

        if sub == "search":
            query = " ".join(args[1:])
            if not query:
                await msg.reply_text("Usage: <code>/fileidx search &lt;query&gt;</code>", parse_mode=H)
                return
            results = file_search(query, limit=15)
            if not results:
                await msg.reply_text(
                    f"🔍 No files found matching: <b>{esc(query)}</b>\n\n"
                    "<i>Try /fileidx ~/home to index your files first.</i>",
                    parse_mode=H,
                )
                return

            lines = [f"🔍 <b>Results for:</b> {esc(query)}\n"]
            for r in results[:10]:
                sz = r.get("size_bytes", 0)
                sz_str = f"{sz:,}b" if sz < 1024 else f"{sz//1024}KB" if sz < 1024**2 else f"{sz//1024//1024}MB"
                lines.append(f"📄 <code>{esc(r['path'][-60:])}</code>  <i>{sz_str}</i>")
                if r.get("content_preview"):
                    lines.append(f"   <i>{esc(r['content_preview'][:80])}…</i>")
            await msg.reply_text("\n".join(lines), parse_mode=H)

        elif sub == "dupes":
            directory = Path(args[1]).expanduser() if len(args) > 1 else Path.home() / "Downloads"
            status = await msg.reply_text(f"🔍 <i>Scanning {esc(str(directory))} for duplicates…</i>", parse_mode=H)
            groups = await asyncio.get_event_loop().run_in_executor(
                None, lambda: asyncio.run(find_duplicates(directory))
            )
            if not groups:
                await status.edit_text(f"✅ No duplicate files found in {esc(str(directory))}", parse_mode=H)
                return
            total_wasted = 0
            lines = [f"🔍 <b>Duplicates in {esc(str(directory))}</b>\n"]
            for g in groups[:15]:
                try:
                    size = Path(g[0]).stat().st_size
                    wasted = size * (len(g) - 1)
                    total_wasted += wasted
                    lines.append(f"📄 <b>{esc(Path(g[0]).name)}</b> ({size//1024}KB × {len(g)})")
                    for p in g:
                        lines.append(f"   <code>{esc(p[-50:])}</code>")
                except Exception:
                    pass
            lines.append(f"\n💾 Wasted: ~{total_wasted//1024//1024}MB")
            await status.edit_text("\n".join(lines), parse_mode=H)

        elif sub == "stats":
            conn = _get_conn()
            row = conn.execute(
                "SELECT COUNT(*) as total, "
                "SUM(size_bytes) as total_size, "
                "COUNT(DISTINCT extension) as ext_count "
                "FROM file_index"
            ).fetchone()
            top_exts = conn.execute(
                "SELECT extension, COUNT(*) as c FROM file_index GROUP BY extension ORDER BY c DESC LIMIT 10"
            ).fetchall()
            total_gb = (row["total_size"] or 0) / 1024**3
            lines = [
                f"📊 <b>File Index Stats</b>\n",
                f"Files: <b>{row['total']:,}</b>",
                f"Total size: <b>{total_gb:.2f} GB</b>",
                f"Extensions: <b>{row['ext_count']}</b>\n",
                "<b>Top extensions:</b>",
            ]
            for r in top_exts:
                lines.append(f"  {esc(r['extension'] or 'none')}: {r['c']:,} files")
            await msg.reply_text("\n".join(lines), parse_mode=H)

        else:
            # Treat first arg as directory path
            directory = Path(args[0]).expanduser()
            if not directory.is_dir():
                await msg.reply_text(f"❌ Not a directory: <code>{esc(str(directory))}</code>", parse_mode=H)
                return

            status = await msg.reply_text(
                f"📂 <i>Indexing {esc(str(directory))}…</i>\n<i>This may take a moment for large directories.</i>",
                parse_mode=H,
            )
            count = [0]

            async def progress(done, total, path):
                if done % 500 == 0:
                    try:
                        await status.edit_text(
                            f"📂 <i>Indexing…</i> {done}/{total} files\n<code>{esc(path[-60:])}</code>",
                            parse_mode=H,
                        )
                    except Exception:
                        pass

            stats = await index_directory(directory, progress_cb=progress)
            await status.edit_text(
                f"✅ <b>Indexed {esc(str(directory))}</b>\n\n"
                f"📄 Indexed: <b>{stats['indexed']:,}</b>\n"
                f"⏭ Skipped: {stats['skipped']}\n"
                f"❌ Errors: {stats['errors']}\n\n"
                f"<i>Use <code>/fileidx search &lt;query&gt;</code> to search.</i>",
                parse_mode=H,
            )


# ═══════════════════════════════════════════════════════════════════════════════
#  2. SMART CONVERSATION CONTEXT
# ═══════════════════════════════════════════════════════════════════════════════

SUMMARY_TRIGGER_TOKENS = 3000   # summarize when history exceeds this
MAX_INJECT_TURNS = 12           # max turns to inject into AI call


async def get_smart_context(user_id: int, ai=None) -> tuple[list[dict], str]:
    """
    Build context-aware conversation history for AI calls.
    - If total tokens > SUMMARY_TRIGGER_TOKENS, existing messages get summarized
    - Returns (messages_list, system_addendum)
    """
    total_tokens = history_total_tokens(user_id)
    existing_summary = history_get_summary(user_id)

    messages = history_load(user_id, limit=MAX_INJECT_TURNS)

    # Trigger summarization if over token limit
    if total_tokens > SUMMARY_TRIGGER_TOKENS and ai and len(messages) > 8:
        # Summarize oldest half
        old_messages = history_load(user_id, limit=40)[:-8]
        if old_messages:
            old_text = "\n".join(
                f"{m['role'].upper()}: {m['content'][:200]}" for m in old_messages
            )
            prompt = (
                f"Summarize this conversation history in 5-8 bullet points, "
                f"preserving key facts, decisions, and user preferences:\n\n{old_text}"
            )
            try:
                new_summary, _ = await ai._call_with_fallback(
                    [{"role": "user", "content": prompt}],
                    system="You summarize conversation history concisely, preserving important context.",
                    max_tokens=400,
                )
                # Combine with existing summary
                if existing_summary:
                    new_summary = f"[Earlier context]\n{existing_summary}\n\n[Recent context]\n{new_summary}"
                if old_messages:
                    history_set_summary(user_id, new_summary, old_messages[-1]["ts"])
                existing_summary = new_summary
                logger.info(f"Conversation summary updated for user {user_id}")
            except Exception as e:
                logger.warning(f"Summarization failed: {e}")

    system_addendum = ""
    if existing_summary:
        system_addendum = f"\n\n[CONVERSATION HISTORY SUMMARY]\n{existing_summary}\n"

    # Return recent messages for direct injection
    return [{"role": m["role"], "content": m["content"]} for m in messages], system_addendum


async def save_exchange(user_id: int, user_text: str, ai_response: str):
    """Save a conversation turn to history."""
    history_append(user_id, "user", user_text)
    history_append(user_id, "assistant", ai_response)


# ═══════════════════════════════════════════════════════════════════════════════
#  3. NATURAL LANGUAGE SCHEDULING
# ═══════════════════════════════════════════════════════════════════════════════

NL_SCHEDULE_SYSTEM = """You parse natural language scheduling expressions into structured schedule specs.

Parse the user's request and return ONLY valid JSON:

{
  "next_run_offset_s": 3600,      // seconds until first run from now
  "interval_s": null,             // null = run once, number = repeat interval in seconds
  "description": "Every Monday at 9am",
  "cron_spec": "0 9 * * 1"       // standard cron spec (optional, for display)
}

Examples:
- "in 30 minutes" → next_run_offset_s: 1800, interval_s: null
- "every hour" → next_run_offset_s: 3600, interval_s: 3600
- "every day at 8am" → next_run_offset_s: (seconds until 8am), interval_s: 86400
- "every Monday at 9am" → next_run_offset_s: (seconds until next Monday 9am), interval_s: 604800
- "in 2 hours repeat every 4 hours" → next_run_offset_s: 7200, interval_s: 14400
- "tomorrow at noon" → next_run_offset_s: (seconds until tomorrow 12:00)
- "every weekday at 7pm" → approximate to every 24 hours at 19:00

Use the current time to compute offsets accurately.
Always return valid JSON only."""


async def parse_nl_schedule(expression: str, ai) -> Optional[dict]:
    """Parse a natural language schedule expression using AI."""
    now = datetime.now()
    prompt = (
        f"Current time: {now.strftime('%Y-%m-%d %H:%M:%S %A')}\n\n"
        f"Parse this schedule: '{expression}'"
    )
    try:
        raw, _ = await ai._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system=NL_SCHEDULE_SYSTEM,
            max_tokens=300,
            temperature=0.1,
        )
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        data = json.loads(raw)
        return data
    except Exception as e:
        logger.error(f"NL schedule parse failed: {e}")
        return None


class SchedulerHandlers:

    @require_auth
    async def cmd_schedule(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /schedule <when> | <command>
        /schedule list
        /schedule del <id>

        Examples:
          /schedule every morning at 8am | df -h
          /schedule in 30 minutes | python3 ~/backup.py
          /schedule every Monday | /agent check disk usage and clean temp files
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "⏰ <b>Natural Language Scheduler</b>\n\n"
                "Syntax: <code>/schedule &lt;when&gt; | &lt;command or goal&gt;</code>\n\n"
                "<b>Examples:</b>\n"
                "<code>/schedule every day at 8am | df -h</code>\n"
                "<code>/schedule in 1 hour | python3 ~/backup.py</code>\n"
                "<code>/schedule every Monday at 9am | /agent check system health</code>\n"
                "<code>/schedule tomorrow at noon | notify Battery check</code>\n\n"
                "<code>/schedule list</code> — active schedules\n"
                "<code>/schedule del &lt;id&gt;</code> — cancel a schedule",
                parse_mode=H,
            )
            return

        full = " ".join(args)

        if full.strip().lower() == "list":
            schedules = schedule_list(user_id)
            if not schedules:
                await msg.reply_text(
                    "📋 No active schedules.\n\n"
                    "<code>/schedule every day at 9am | df -h</code>",
                    parse_mode=H,
                )
                return
            lines = ["⏰ <b>Active Schedules</b>\n"]
            for s in schedules:
                next_dt = datetime.fromtimestamp(s["next_run"]).strftime("%Y-%m-%d %H:%M")
                interval = f" · every {s['interval_s']//60}m" if s.get("interval_s") else " · once"
                lines.append(
                    f"<b>#{s['id']}</b> {interval}\n"
                    f"  ⏭ Next: {next_dt}\n"
                    f"  💬 <code>{esc(s['command'][:80])}</code>\n"
                    f"  📝 <i>{esc(s['raw_expr'][:50])}</i>"
                )
            await msg.reply_text("\n".join(lines), parse_mode=H)
            return

        if full.lower().startswith("del "):
            try:
                sid = int(full.split(" ", 1)[1].strip())
                schedule_delete(sid, user_id)
                await msg.reply_text(f"🗑 Schedule #{sid} deleted.", parse_mode=H)
            except ValueError:
                await msg.reply_text("Usage: <code>/schedule del &lt;id&gt;</code>", parse_mode=H)
            return

        # Parse "when | command" format
        if "|" not in full:
            await msg.reply_text(
                "❌ Use <code>|</code> to separate schedule from command.\n"
                "Example: <code>/schedule every hour | df -h</code>",
                parse_mode=H,
            )
            return

        when_part, cmd_part = full.split("|", 1)
        when_part = when_part.strip()
        cmd_part = cmd_part.strip()

        if not cmd_part:
            await msg.reply_text("❌ Command cannot be empty.", parse_mode=H)
            return

        ai = getattr(self, "_ai", None)
        if not ai:
            await msg.reply_text("❌ AI not configured for schedule parsing.", parse_mode=H)
            return

        status = await msg.reply_text(f"⏰ <i>Parsing schedule: '{esc(when_part)}'…</i>", parse_mode=H)

        parsed = await parse_nl_schedule(when_part, ai)
        if not parsed:
            await status.edit_text("❌ Could not parse schedule expression. Try: 'every day at 8am'", parse_mode=H)
            return

        offset_s = parsed.get("next_run_offset_s", 0)
        interval_s = parsed.get("interval_s")
        description = parsed.get("description", when_part)

        next_run = time.time() + max(0, float(offset_s))
        sched_id = schedule_create(
            user_id=user_id,
            chat_id=chat_id,
            raw_expr=when_part,
            command=cmd_part,
            next_run=next_run,
            interval_s=float(interval_s) if interval_s else None,
            cron_spec=parsed.get("cron_spec", ""),
        )

        next_dt = datetime.fromtimestamp(next_run).strftime("%Y-%m-%d %H:%M:%S")
        repeat_str = f"\n🔁 Repeats every {interval_s//60:.0f} minutes" if interval_s else "\n▶️ Runs once"

        await status.edit_text(
            f"✅ <b>Schedule #{sched_id} created</b>\n\n"
            f"📅 <i>{esc(description)}</i>\n"
            f"⏭ <b>First run:</b> {next_dt}{repeat_str}\n"
            f"💬 <b>Command:</b> <code>{esc(cmd_part[:100])}</code>\n\n"
            f"<code>/schedule list</code> · <code>/schedule del {sched_id}</code>",
            parse_mode=H,
        )

    @require_auth
    async def cmd_jobs(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Alias for /schedule list"""
        ctx.args = ["list"]
        await self.cmd_schedule(update, ctx)

    @require_auth
    async def cmd_jobcancel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Alias for /schedule del <id>"""
        if ctx.args:
            ctx.args = ["del", ctx.args[0]]
        await self.cmd_schedule(update, ctx)


async def run_scheduler_loop(app: Application):
    """
    Background task: every 15s check for due schedules and execute them.
    Runs all schedule commands as shell or Telegram commands.
    """
    logger.info("Scheduler loop started")
    while True:
        try:
            due = schedule_due()
            for sched in due:
                asyncio.create_task(_run_schedule(app, sched))
        except Exception as e:
            logger.error(f"Scheduler loop error: {e}")
        await asyncio.sleep(15)


async def _run_schedule(app: Application, sched: dict):
    """Execute a scheduled command and notify the user."""
    cmd = sched["command"]
    chat_id = sched["chat_id"]
    sched_id = sched["id"]

    # Update next run time (or disable if one-shot)
    interval = sched.get("interval_s")
    if interval:
        schedule_update_next(sched_id, time.time() + float(interval))
    else:
        schedule_delete(sched_id, sched["user_id"])

    try:
        # Telegram command → dispatch via bot
        if cmd.startswith("/"):
            text = f"⏰ <b>Scheduled task running</b>\n<code>{esc(cmd[:100])}</code>"
            await app.bot.send_message(chat_id, text, parse_mode="HTML")
        else:
            # Shell command
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True,
                timeout=60, cwd=str(Path.home()),
            )
            out = (result.stdout or "").strip()[:1500]
            err = (result.stderr or "").strip()[:500]
            icon = "✅" if result.returncode == 0 else "❌"
            await app.bot.send_message(
                chat_id,
                f"⏰ <b>Scheduled task complete</b>\n"
                f"<code>{esc(cmd[:80])}</code>\n\n"
                f"{icon} <pre>{esc(out or err or '(no output)')}</pre>",
                parse_mode="HTML",
            )
    except Exception as e:
        logger.error(f"Schedule run failed [{sched_id}]: {e}")
        try:
            await app.bot.send_message(
                chat_id,
                f"❌ <b>Scheduled task failed</b>\n<code>{esc(cmd[:80])}</code>\n{esc(str(e))}",
                parse_mode="HTML",
            )
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════════════════
#  4. CODE REPL — Iterative self-healing code runner
# ═══════════════════════════════════════════════════════════════════════════════

CODE_REPL_SYSTEM = """You are an expert programmer writing production-quality Python.

TASK: Write complete, working Python code for the given description.
If you're fixing an error, analyze it carefully and fix the root cause.

RULES:
1. Write COMPLETE runnable scripts — no placeholders, no TODOs
2. Handle ALL errors with try/except
3. Print meaningful output showing what was done
4. Auto-install packages with pip if needed (use subprocess.run(['pip','install',pkg]))
5. Save output files to ~/Desktop/ when creating files
6. For data tasks: include sample data if no real source

OUTPUT FORMAT — return ONLY valid JSON:
{
  "code": "full Python script as string",
  "description": "one-line description",
  "install": ["pkg1", "pkg2"],
  "explanation": "brief explanation of approach"
}"""

MAX_HEAL_ITERATIONS = 3


class CodeReplHandlers:

    @require_auth
    async def cmd_repl(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /repl <description>    — AI writes + runs, auto-fixes errors
        /repl fix              — fix errors in last code
        /repl improve <desc>   — improve last code
        /repl show             — show current code
        /repl save             — save to Desktop
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []

        if not args:
            sess = code_session_last(user_id)
            if sess:
                await msg.reply_text(
                    f"🖥 <b>Code REPL</b>\n\n"
                    f"Last: <i>{esc(sess.get('description','?'))}</i>\n"
                    f"Status: {sess.get('status','?')} · {len(sess.get('iterations',[]))} iterations\n\n"
                    f"<code>/repl show</code> — view code\n"
                    f"<code>/repl fix</code> — fix last error\n"
                    f"<code>/repl improve &lt;desc&gt;</code> — enhance code\n"
                    f"<code>/repl save</code> — save to Desktop",
                    parse_mode=H,
                )
            else:
                await msg.reply_text(
                    "🖥 <b>Code REPL</b> — AI writes and auto-fixes code\n\n"
                    "<code>/repl scrape HN top stories as CSV</code>\n"
                    "<code>/repl analyze disk usage and chart largest dirs</code>\n"
                    "<code>/repl find all large files and show top 20</code>",
                    parse_mode=H,
                )
            return

        sub = args[0].lower()

        if sub == "show":
            sess = code_session_last(user_id)
            if not sess:
                await msg.reply_text("❌ No active session.", parse_mode=H)
                return
            code = sess["code"][:3000]
            await msg.reply_text(
                f"📄 <b>{esc(sess.get('description','Code'))}</b>\n"
                f"<pre><code>{esc(code)}</code></pre>",
                parse_mode=H,
            )
            return

        if sub == "save":
            sess = code_session_last(user_id)
            if not sess or not sess["code"]:
                await msg.reply_text("❌ No code to save.", parse_mode=H)
                return
            desktop = Path.home() / "Desktop"
            desktop.mkdir(exist_ok=True)
            fname = f"salim_repl_{int(time.time())}.py"
            (desktop / fname).write_text(sess["code"])
            await msg.reply_text(f"💾 Saved: <code>~/Desktop/{fname}</code>", parse_mode=H)
            return

        ai = getattr(self, "_ai", None)
        if not ai:
            await msg.reply_text("❌ AI not configured.", parse_mode=H)
            return

        # Build prompt based on sub-command
        if sub == "fix":
            sess = code_session_last(user_id)
            if not sess:
                await msg.reply_text("❌ No session to fix.", parse_mode=H)
                return
            iters = sess.get("iterations", [])
            last_iter = iters[-1] if iters else {}
            last_error = last_iter.get("error", "")
            if not last_error:
                await msg.reply_text("✅ No errors to fix in last run.", parse_mode=H)
                return
            description = f"Fix this Python code. Error was:\n{last_error[:500]}\n\nCode:\n{sess['code'][:2000]}"
            session_id = sess["session_id"]

        elif sub == "improve":
            sess = code_session_last(user_id)
            if not sess:
                await msg.reply_text("❌ No session to improve.", parse_mode=H)
                return
            improvement = " ".join(args[1:]) or "make it better"
            description = f"Improve this code: {improvement}\n\nCurrent code:\n{sess['code'][:2000]}"
            session_id = sess["session_id"]

        else:
            # New request
            description = " ".join(args)
            session_id = secrets.token_hex(8)
            code_session_create(user_id, session_id, description, "python")

        status = await msg.reply_text(
            f"🤖 <i>Writing code…</i>\n<i>{esc(description[:80])}</i>",
            parse_mode=H,
        )

        for iteration in range(MAX_HEAL_ITERATIONS + 1):
            # Generate/fix code
            prompt = description if iteration == 0 else (
                f"Fix this Python code that failed.\n\nError:\n{last_error}\n\nCode:\n{current_code}"
            )
            try:
                raw, provider = await ai._call_with_fallback(
                    [{"role": "user", "content": prompt}],
                    system=CODE_REPL_SYSTEM,
                    max_tokens=4096,
                    temperature=0.1,
                )
                raw = re.sub(r"```(?:json)?|```", "", raw).strip()
                m = re.search(r"\{.*\}", raw, re.DOTALL)
                if m:
                    raw = m.group(0)
                code_data = json.loads(raw)
            except Exception as e:
                await status.edit_text(f"❌ Code generation failed: {esc(str(e))}", parse_mode=H)
                return

            current_code = code_data.get("code", "")
            install_pkgs = code_data.get("install", [])
            code_desc = code_data.get("description", description[:60])

            if not current_code:
                await status.edit_text("❌ AI returned empty code.", parse_mode=H)
                return

            # Auto-install packages
            for pkg in install_pkgs:
                try:
                    subprocess.run(
                        [sys.executable, "-m", "pip", "install", pkg, "-q"],
                        capture_output=True, timeout=60,
                    )
                except Exception:
                    pass

            # Run the code
            await status.edit_text(
                f"{'🤖' if iteration == 0 else '🔧'} "
                f"<i>{'Running' if iteration == 0 else f'Self-healing attempt {iteration}'}</i>…\n"
                f"<pre>{esc(current_code[:500])}</pre>",
                parse_mode=H,
            )

            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
                f.write(current_code)
                fp = f.name

            try:
                proc = await asyncio.create_subprocess_exec(
                    sys.executable, fp,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=str(Path.home()),
                )
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=60)
                out = stdout.decode(errors="replace").strip()
                err = stderr.decode(errors="replace").strip()
                exit_code = proc.returncode
            except asyncio.TimeoutError:
                out, err, exit_code = "", "Execution timed out after 60s", -1
            finally:
                try: os.unlink(fp)
                except Exception: pass

            iter_record = {
                "iteration": iteration + 1,
                "code_snippet": current_code[:300],
                "output": out[:500],
                "error": err[:500] if exit_code != 0 else "",
                "exit_code": exit_code,
                "healed": iteration > 0,
            }
            code_session_update(session_id, current_code, iter_record)

            if exit_code == 0:
                # Success
                output_display = out[:2000] or "(no output)"
                heal_note = f" (fixed in {iteration} attempt{'s' if iteration != 1 else ''})" if iteration > 0 else ""
                await status.edit_text(
                    f"✅ <b>Code ran successfully{heal_note}</b>\n"
                    f"<i>{esc(code_desc)}</i>\n\n"
                    f"<b>Output:</b>\n<pre>{esc(output_display)}</pre>",
                    parse_mode=H,
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("📄 Show code", callback_data=f"repl_show:{user_id}"),
                        InlineKeyboardButton("💾 Save", callback_data=f"repl_save:{user_id}"),
                        InlineKeyboardButton("🔧 Improve", callback_data=f"repl_improve:{user_id}"),
                    ]]),
                )
                return

            last_error = err or f"Exit code {exit_code}"

            if iteration >= MAX_HEAL_ITERATIONS:
                await status.edit_text(
                    f"❌ <b>Failed after {iteration + 1} attempts</b>\n"
                    f"<b>Last error:</b>\n<pre>{esc(last_error[:800])}</pre>\n\n"
                    f"<code>/repl fix</code> — try manual fix",
                    parse_mode=H,
                )
                return

            description = f"Fix this Python code that failed.\nError:\n{last_error}\n\nCode:\n{current_code}"

    async def handle_repl_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data or ""
        user_id = update.effective_user.id

        if data.startswith("repl_show:"):
            sess = code_session_last(user_id)
            if sess:
                await query.message.reply_text(
                    f"<pre><code>{esc(sess['code'][:3500])}</code></pre>", parse_mode=H
                )
        elif data.startswith("repl_save:"):
            sess = code_session_last(user_id)
            if sess:
                desktop = Path.home() / "Desktop"
                desktop.mkdir(exist_ok=True)
                fname = f"salim_repl_{int(time.time())}.py"
                (desktop / fname).write_text(sess["code"])
                await query.edit_message_reply_markup(None)
                await query.message.reply_text(f"💾 Saved: <code>~/Desktop/{fname}</code>", parse_mode=H)
        elif data.startswith("repl_improve:"):
            ctx.args = ["improve", "make it more robust and add better output"]
            await self.cmd_repl(update, ctx)


# ═══════════════════════════════════════════════════════════════════════════════
#  5. PROACTIVE INTELLIGENCE
# ═══════════════════════════════════════════════════════════════════════════════

RULE_CHECKERS = {
    "cpu_high":    lambda: _check_cpu() > 90,
    "disk_low":    lambda: _check_disk_free_pct() < 10,
    "memory_high": lambda: _check_memory() > 90,
    "battery_low": lambda: _check_battery() is not None and _check_battery() < 15,
    "file_exists": lambda path: Path(path).expanduser().exists(),
    "process_dead": lambda name: not _process_running(name),
    "always":      lambda: True,
}


def _check_cpu() -> float:
    try:
        import psutil; return psutil.cpu_percent(interval=0.5)
    except Exception: return 0.0

def _check_memory() -> float:
    try:
        import psutil; return psutil.virtual_memory().percent
    except Exception: return 0.0

def _check_disk_free_pct() -> float:
    try:
        import psutil; u = psutil.disk_usage("/"); return 100 - u.percent
    except Exception: return 100.0

def _check_battery() -> Optional[float]:
    try:
        import psutil; b = psutil.sensors_battery()
        return b.percent if b else None
    except Exception: return None

def _process_running(name: str) -> bool:
    try:
        import psutil
        return any(name.lower() in (p.name() or "").lower() for p in psutil.process_iter())
    except Exception: return True


class ProactiveHandlers:

    @require_auth
    async def cmd_watch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /watch cpu_high | send alert: CPU is overloaded!
        /watch disk_low | /agent clean temp files
        /watch battery_low | notify Battery: plug in charger!
        /watch list
        /watch del <id>

        Rule types: cpu_high, disk_low, memory_high, battery_low,
                    file_exists:<path>, process_dead:<name>, always
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "👁 <b>Proactive Intelligence</b>\n\n"
                "Define rules: when condition fires, take action.\n\n"
                "<b>Syntax:</b> <code>/watch &lt;rule&gt; | &lt;action&gt;</code>\n\n"
                "<b>Rules:</b>\n"
                "  <code>cpu_high</code> — CPU &gt; 90%\n"
                "  <code>disk_low</code> — disk &lt; 10% free\n"
                "  <code>memory_high</code> — RAM &gt; 90%\n"
                "  <code>battery_low</code> — battery &lt; 15%\n"
                "  <code>file_exists:/path/file</code> — file appears\n"
                "  <code>process_dead:nginx</code> — process dies\n\n"
                "<b>Actions:</b>\n"
                "  <code>notify: &lt;message&gt;</code> — Telegram alert\n"
                "  <code>shell: &lt;command&gt;</code> — run shell command\n"
                "  <code>/agent &lt;goal&gt;</code> — trigger agent\n\n"
                "<b>Examples:</b>\n"
                "<code>/watch cpu_high | notify: CPU is overloaded! Check /top</code>\n"
                "<code>/watch disk_low | shell: rm -rf /tmp/*</code>\n"
                "<code>/watch battery_low | notify: Plug in charger!</code>",
                parse_mode=H,
            )
            return

        full = " ".join(args)

        if full.strip().lower() == "list":
            rules = proactive_rules_get(user_id)
            if not rules:
                await msg.reply_text("📋 No proactive rules. Use <code>/watch</code> to create one.", parse_mode=H)
                return
            lines = ["👁 <b>Active Rules</b>\n"]
            for r in rules:
                last = r.get("last_fired", "never")[:16] if r.get("last_fired") else "never"
                lines.append(
                    f"<b>#{r['id']}</b> <code>{esc(r['rule_type'])}</code> → {esc(r['action'][:60])}\n"
                    f"   Cooldown: {r['cooldown_s']//60}min · Last fired: {last}"
                )
            await msg.reply_text("\n".join(lines), parse_mode=H)
            return

        if full.lower().startswith("del "):
            try:
                rid = int(full.split(" ", 1)[1].strip())
                proactive_rule_delete(rid, user_id)
                await msg.reply_text(f"🗑 Rule #{rid} deleted.", parse_mode=H)
            except ValueError:
                await msg.reply_text("Usage: <code>/watch del &lt;id&gt;</code>", parse_mode=H)
            return

        if "|" not in full:
            await msg.reply_text(
                "❌ Use <code>|</code> to separate condition from action.\n"
                "Example: <code>/watch cpu_high | notify: CPU overloaded!</code>",
                parse_mode=H,
            )
            return

        cond_part, action_part = full.split("|", 1)
        cond_part = cond_part.strip()
        action_part = action_part.strip()

        # Validate rule type
        rule_type = cond_part.split(":")[0].strip()
        if rule_type not in RULE_CHECKERS:
            await msg.reply_text(
                f"❌ Unknown rule type: <code>{esc(rule_type)}</code>\n"
                f"Available: {', '.join(RULE_CHECKERS.keys())}",
                parse_mode=H,
            )
            return

        rule_id = proactive_rule_create(
            user_id=user_id, chat_id=chat_id,
            rule_type=cond_part, condition=cond_part,
            action=action_part, cooldown_s=3600,
        )
        await msg.reply_text(
            f"✅ <b>Proactive rule #{rule_id} created</b>\n\n"
            f"👁 <b>Watch:</b> <code>{esc(cond_part)}</code>\n"
            f"⚡ <b>Action:</b> <code>{esc(action_part[:80])}</code>\n"
            f"🔁 Cooldown: 60 minutes\n\n"
            f"<i>Checked every 60 seconds. Fires when condition is true.</i>",
            parse_mode=H,
        )


async def run_proactive_loop(app: Application, all_user_ids: list[int] = None):
    """
    Background loop: check all proactive rules every 60s.
    Fires actions when conditions are met (with cooldown).
    """
    logger.info("Proactive intelligence loop started")
    while True:
        try:
            conn = _get_conn()
            rules = conn.execute(
                "SELECT * FROM proactive_rules WHERE enabled=1", ()
            ).fetchall()

            for rule in rules:
                rule = dict(rule)
                # Check cooldown
                if rule.get("last_fired"):
                    try:
                        last = datetime.fromisoformat(rule["last_fired"])
                        if (datetime.now() - last).total_seconds() < rule["cooldown_s"]:
                            continue
                    except Exception:
                        pass

                # Evaluate condition
                cond = rule["condition"]
                rule_type = cond.split(":")[0].strip()
                param = cond[len(rule_type)+1:].strip() if ":" in cond else ""

                fired = False
                try:
                    checker = RULE_CHECKERS.get(rule_type)
                    if checker:
                        fired = checker(param) if param else checker()
                except Exception:
                    pass

                if not fired:
                    continue

                # Fire the action
                proactive_rule_fired(rule["id"])
                action = rule["action"]
                chat_id = rule["chat_id"]
                asyncio.create_task(_fire_proactive_action(app, chat_id, action, cond))

        except Exception as e:
            logger.error(f"Proactive loop error: {e}")

        await asyncio.sleep(60)


async def _fire_proactive_action(app: Application, chat_id: int, action: str, condition: str):
    """Execute a proactive rule's action."""
    try:
        if action.lower().startswith("notify:"):
            text = action[7:].strip()
            await app.bot.send_message(
                chat_id,
                f"🔔 <b>Proactive Alert</b>\n"
                f"<i>Condition: {esc(condition)}</i>\n\n"
                f"{esc(text)}",
                parse_mode="HTML",
            )
        elif action.lower().startswith("shell:"):
            cmd = action[6:].strip()
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
            out = (result.stdout or result.stderr or "done").strip()[:500]
            await app.bot.send_message(
                chat_id,
                f"🔔 <b>Proactive Action</b> — <code>{esc(condition)}</code>\n\n"
                f"<pre>{esc(out)}</pre>",
                parse_mode="HTML",
            )
        else:
            # Telegram command or plain message
            await app.bot.send_message(
                chat_id,
                f"🔔 <b>Proactive Trigger</b>: {esc(condition)}\n\n"
                f"<i>Action:</i> <code>{esc(action[:100])}</code>",
                parse_mode="HTML",
            )
    except Exception as e:
        logger.error(f"Proactive action failed: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
#  6. WEBHOOK RECEIVER
# ═══════════════════════════════════════════════════════════════════════════════

class WebhookHandlers:

    @require_auth
    async def cmd_webhook(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /webhook create <name>          — create a webhook endpoint
        /webhook list                   — list your webhooks
        /webhook del <id>               — delete a webhook
        /webhook test <token>           — send test payload
        /webhook transform <id> <jq>   — set response transform expression

        When the webhook URL is called (POST), the payload is forwarded to your chat.
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "🪝 <b>Webhook Receiver</b>\n\n"
                "Get an HTTP endpoint that forwards POSTs to this chat.\n\n"
                "<code>/webhook create github_alerts</code>\n"
                "<code>/webhook create server_monitor</code>\n"
                "<code>/webhook list</code>\n"
                "<code>/webhook del &lt;id&gt;</code>\n\n"
                "<b>POST to:</b>\n"
                "<code>POST /webhook/&lt;token&gt;</code>\n"
                "<b>Body:</b> any JSON — forwarded to your chat\n\n"
                "<i>Start Salim with --webhook-port 8765 to enable HTTP server</i>",
                parse_mode=H,
            )
            return

        sub = args[0].lower()

        if sub == "create":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/webhook create &lt;name&gt;</code>", parse_mode=H)
                return
            name = " ".join(args[1:])
            token = secrets.token_urlsafe(24)
            wh_id = webhook_create(user_id, chat_id, name, token)
            webhook_port = getattr(self.config, "webhook_port", None) or \
                           os.environ.get("SALIM_WEBHOOK_PORT", "8765")
            host = os.environ.get("SALIM_WEBHOOK_HOST", "your-server.com")
            await msg.reply_text(
                f"✅ <b>Webhook #{wh_id} created: {esc(name)}</b>\n\n"
                f"🔗 <b>URL:</b>\n"
                f"<code>http://{host}:{webhook_port}/webhook/{token}</code>\n\n"
                f"<b>Test with curl:</b>\n"
                f"<pre>curl -X POST http://{host}:{webhook_port}/webhook/{token} \\\n"
                f"  -H 'Content-Type: application/json' \\\n"
                f"  -d '{{\"event\":\"test\",\"message\":\"Hello Salim!\"}}'</pre>\n\n"
                f"<i>Any JSON POST to this URL will be forwarded to this chat.</i>",
                parse_mode=H,
            )

        elif sub == "list":
            webhooks = webhook_list(user_id)
            if not webhooks:
                await msg.reply_text("📋 No webhooks. Use <code>/webhook create &lt;name&gt;</code>", parse_mode=H)
                return
            webhook_port = os.environ.get("SALIM_WEBHOOK_PORT", "8765")
            host = os.environ.get("SALIM_WEBHOOK_HOST", "localhost")
            lines = ["🪝 <b>Your Webhooks</b>\n"]
            for w in webhooks:
                enabled = "✅" if w.get("enabled") else "❌"
                lines.append(
                    f"{enabled} <b>#{w['id']}</b> {esc(w['name'])}\n"
                    f"   Hits: {w.get('hit_count',0)} · Last: {(w.get('last_hit') or 'never')[:16]}\n"
                    f"   <code>http://{host}:{webhook_port}/webhook/{w['token']}</code>"
                )
            await msg.reply_text("\n".join(lines), parse_mode=H)

        elif sub == "del":
            try:
                wh_id = int(args[1])
                webhook_delete(wh_id, user_id)
                await msg.reply_text(f"🗑 Webhook #{wh_id} deleted.", parse_mode=H)
            except (IndexError, ValueError):
                await msg.reply_text("Usage: <code>/webhook del &lt;id&gt;</code>", parse_mode=H)

        elif sub == "test":
            token = args[1] if len(args) > 1 else ""
            if not token:
                await msg.reply_text("Usage: <code>/webhook test &lt;token&gt;</code>", parse_mode=H)
                return
            wh = webhook_get_by_token(token)
            if not wh:
                await msg.reply_text("❌ Webhook not found.", parse_mode=H)
                return
            # Simulate a payload
            payload = {"event": "test", "source": "salim", "ts": datetime.now().isoformat()}
            await self._dispatch_webhook(app=None, wh=wh, payload=payload)
            await msg.reply_text("✅ Test payload dispatched to chat.", parse_mode=H)

        else:
            await msg.reply_text("Sub-commands: create, list, del, test", parse_mode=H)

    async def _dispatch_webhook(self, app, wh: dict, payload: dict):
        """Format and send webhook payload to user's chat."""
        chat_id = wh["chat_id"]
        name = wh.get("name", "Webhook")
        webhook_hit(wh["token"])

        # Format payload
        try:
            payload_str = json.dumps(payload, indent=2, ensure_ascii=False)
        except Exception:
            payload_str = str(payload)

        # Truncate large payloads
        if len(payload_str) > 3000:
            payload_str = payload_str[:3000] + "\n…[truncated]"

        text = (
            f"🪝 <b>{esc(name)}</b>\n"
            f"<i>{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</i>\n\n"
            f"<pre>{esc(payload_str)}</pre>"
        )

        try:
            if app:
                await app.bot.send_message(chat_id, text, parse_mode="HTML")
        except Exception as e:
            logger.error(f"Webhook dispatch to chat {chat_id} failed: {e}")


async def run_webhook_server(app: Application, port: int = 8765):
    """
    Embedded HTTP server for receiving webhook POSTs.
    Runs as asyncio server on the configured port.
    Route: POST /webhook/<token>
    """
    import asyncio
    from http.server import BaseHTTPRequestHandler
    from urllib.parse import urlparse

    async def handle_request(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        try:
            # Read request line
            request_line = await asyncio.wait_for(reader.readline(), timeout=5)
            method, path, *_ = request_line.decode().split()

            # Read headers
            headers = {}
            while True:
                line = await asyncio.wait_for(reader.readline(), timeout=5)
                if line in (b"\r\n", b"\n", b""):
                    break
                if b":" in line:
                    k, v = line.decode().split(":", 1)
                    headers[k.strip().lower()] = v.strip()

            # Read body
            body = b""
            content_length = int(headers.get("content-length", 0))
            if content_length:
                body = await asyncio.wait_for(reader.read(content_length), timeout=10)

            # Parse route: /webhook/<token>
            parsed = urlparse(path)
            parts = parsed.path.strip("/").split("/")

            if len(parts) == 2 and parts[0] == "webhook":
                token = parts[1]
                wh = webhook_get_by_token(token)

                if wh:
                    try:
                        payload = json.loads(body.decode("utf-8", errors="replace")) if body else {}
                    except Exception:
                        payload = {"raw": body.decode("utf-8", errors="replace")[:500]}

                    # Dispatch to chat
                    handler = WebhookHandlers()
                    asyncio.create_task(handler._dispatch_webhook(app, wh, payload))

                    response_body = json.dumps({"ok": True, "webhook": wh["name"]}).encode()
                    writer.write(
                        f"HTTP/1.1 200 OK\r\n"
                        f"Content-Type: application/json\r\n"
                        f"Content-Length: {len(response_body)}\r\n"
                        f"\r\n".encode() + response_body
                    )
                else:
                    writer.write(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n")
            else:
                # Health check
                body = b'{"status":"ok","service":"salim-webhook"}'
                writer.write(
                    f"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {len(body)}\r\n\r\n".encode()
                    + body
                )

        except Exception as e:
            logger.error(f"Webhook server error: {e}")
            try:
                writer.write(b"HTTP/1.1 500 Internal Server Error\r\nContent-Length: 0\r\n\r\n")
            except Exception:
                pass
        finally:
            try:
                await writer.drain()
                writer.close()
            except Exception:
                pass

    server = await asyncio.start_server(handle_request, "0.0.0.0", port)
    logger.info(f"Webhook server listening on port {port}")
    async with server:
        await server.serve_forever()


# ═══════════════════════════════════════════════════════════════════════════════
#  COMBINED MIXIN CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class IntelligenceHandlers(
    FileIntelligenceHandlers,
    SchedulerHandlers,
    CodeReplHandlers,
    ProactiveHandlers,
    WebhookHandlers,
):
    """Combined mixin for all 6 intelligence features."""
    pass
