"""Background ingestion system for long transcripts.

Allows store_memory to return immediately with a time estimate while
processing happens in a background thread. Completed results are attached
as notifications to the next tool call response.
"""

from __future__ import annotations

import threading
import uuid as _uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable

from coppermind_cmo.log import ToolLogger

logger = ToolLogger("background")


@dataclass
class BackgroundResult:
    """Result from a completed background ingestion."""

    task_id: str
    mind_name: str
    started_at: datetime
    completed_at: datetime | None = None
    memories_created: int = 0
    by_type: dict = field(default_factory=dict)
    error: str | None = None
    shown_to_user: bool = False


# Module-level storage for background results
_background_results: list[BackgroundResult] = []
_background_lock = threading.Lock()


def attach_notifications(result: dict | list) -> dict | list:
    """Attach any pending background ingestion notifications to a dict result.

    Call this from any tool's registered function before returning.
    List results are returned unchanged (notifications only attach to dicts).
    """
    if isinstance(result, dict):
        notifications = get_completed_notifications()
        if notifications:
            result["notifications"] = notifications
    return result


def start_background_ingestion(
    text: str,
    mind_id: str,
    mind_name: str,
    db_factory: Callable,
    config: Any,
    source_type: str = "meeting",
    source_ref: str | None = None,
) -> dict:
    """Start ingestion in a background thread. Returns immediately with estimate."""
    from coppermind_cmo.ingest import estimate_ingestion_time

    task_id = str(_uuid.uuid4())[:8]
    estimate = estimate_ingestion_time(text)

    def _run():
        result = BackgroundResult(
            task_id=task_id,
            mind_name=mind_name,
            started_at=datetime.now(),
        )
        db = None
        try:
            from coppermind_cmo.ingest import IngestEngine
            from coppermind_cmo.db import Database
            from coppermind_cmo.config import Config

            db = db_factory()
            engine = IngestEngine(
                db, config,
                active_mind=(mind_id, mind_name),
                memory_source_type="transcript",
            )
            ref = source_ref or f"background-{task_id}"
            ingest_result = engine.process_source(
                source_type=source_type,
                source_ref=ref,
                content=text,
            )
            result.memories_created = ingest_result.get("new", 0) + ingest_result.get("updated", 0)
            result.by_type = ingest_result.get("by_type", {})
            result.completed_at = datetime.now()
            elapsed_ms = int((result.completed_at - result.started_at).total_seconds() * 1000)
            logger.info(
                "Background ingestion complete",
                task_id=task_id,
                mind_name=mind_name,
                memories_created=result.memories_created,
                duration_ms=elapsed_ms,
            )
        except Exception as e:
            result.error = f"Ingestion failed — check server logs (task_id: {task_id})"
            result.completed_at = datetime.now()
            elapsed_ms = int((result.completed_at - result.started_at).total_seconds() * 1000)
            logger.error(
                "Background ingestion failed",
                task_id=task_id,
                mind_name=mind_name,
                error=str(e),
                duration_ms=elapsed_ms,
            )
        finally:
            # Close DB if we created a dedicated instance for this thread
            if db is not None and hasattr(db, 'close'):
                try:
                    db.close()
                except Exception:
                    pass

        with _background_lock:
            _background_results.append(result)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    return {
        "status": "processing",
        "task_id": task_id,
        "estimate": estimate,
        "message": (
            f"Processing ~{estimate['word_count']} words in the background "
            f"(~{estimate['estimated_seconds']}s). "
            "Keep working — I'll let you know when it's done."
        ),
    }


def get_completed_notifications() -> list[dict]:
    """Get any completed background ingestion results not yet shown to the user."""
    with _background_lock:
        results = []
        for r in _background_results:
            if r.completed_at and not r.shown_to_user:
                r.shown_to_user = True
                if r.error:
                    results.append({
                        "type": "ingestion_error",
                        "mind_name": r.mind_name,
                        "error": r.error,
                    })
                else:
                    elapsed = int((r.completed_at - r.started_at).total_seconds())
                    type_str = (
                        ", ".join(f"{v} {k}s" for k, v in sorted(r.by_type.items()))
                        if r.by_type else ""
                    )
                    results.append({
                        "type": "ingestion_complete",
                        "mind_name": r.mind_name,
                        "memories_created": r.memories_created,
                        "by_type": r.by_type,
                        "elapsed_seconds": elapsed,
                        "message": (
                            f"Your {r.mind_name} transcript finished processing — "
                            f"{r.memories_created} new memories extracted"
                            f"{' (' + type_str + ')' if type_str else ''}. "
                            f"Took {elapsed}s."
                        ),
                    })
        # Clean up: keep all in-progress/unshown items, cap shown history at 10
        _background_results[:] = (
            [r for r in _background_results if not r.shown_to_user]
            + [r for r in _background_results if r.shown_to_user][-10:]
        )
        return results
