"""Coppermind CMO MCP Server.

Registers all 12 tools via FastMCP. Manages server state (active mind).
Performs startup validation per SERVER_SPEC.md.
Auto-starts session watcher as a subprocess.

Supports two modes:
  - Hosted: COPPERMIND_API_KEY set → provisions via gateway, connects to Supabase
  - Self-hosted: COPPERMIND_PG_* env vars → direct PostgreSQL, local services
"""

import atexit
import os
import signal
import subprocess
import sys
import time as _time_mod
import uuid as _uuid
from pathlib import Path

import httpx
from mcp.server.fastmcp import FastMCP

from coppermind_cmo.config import Config, fetch_server_config
from coppermind_cmo.db import Database
from coppermind_cmo.log import ToolLogger
from coppermind_cmo import embedding_client

mcp = FastMCP("coppermind-cmo")
logger = ToolLogger("server")

# Server state
_config: Config | None = None
_db: Database | None = None
_active_mind_id: str | None = None
_active_mind_name: str | None = None
_initialized: bool = False
_watcher_process: subprocess.Popen | None = None

# Session tracking
SESSION_ID: str = str(_uuid.uuid4())
_last_tool_call: str | None = None

# PID files for single-instance enforcement
PID_FILE = Path.home() / ".coppermind" / "server.pid"
WATCHER_PID_FILE = Path.home() / ".coppermind" / "watcher.pid"


def get_session_id() -> str:
    return SESSION_ID


def get_last_tool_call() -> str | None:
    return _last_tool_call


def set_last_tool_call(tool_name: str):
    global _last_tool_call
    _last_tool_call = tool_name


def _kill_stale_pid(pid_file: Path) -> None:
    """Read a PID file and kill the process if alive."""
    if not pid_file.exists():
        return
    try:
        old_pid = int(pid_file.read_text().strip())
        os.kill(old_pid, 0)  # Check alive
        os.kill(old_pid, signal.SIGTERM)
        for _ in range(20):  # 2 seconds
            _time_mod.sleep(0.1)
            try:
                os.kill(old_pid, 0)
            except ProcessLookupError:
                break
        else:
            try:
                sig = signal.SIGKILL if hasattr(signal, "SIGKILL") else signal.SIGTERM
                os.kill(old_pid, sig)
            except ProcessLookupError:
                pass
    except (ProcessLookupError, ValueError, PermissionError, OSError):
        pass


def _ensure_single_instance() -> None:
    """Claim PID file and kill orphaned watcher (but NOT other server instances).

    Multiple Claude Code sessions can run concurrently, each with its own MCP
    server. We don't kill other servers — Claude Code manages their lifecycle.
    We only kill orphaned watchers (there should be at most one).
    """
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    _kill_stale_pid(WATCHER_PID_FILE)
    PID_FILE.write_text(str(os.getpid()))


def _cleanup() -> None:
    """Remove PID files and kill watcher on shutdown."""
    _stop_watcher()
    try:
        if WATCHER_PID_FILE.exists():
            WATCHER_PID_FILE.unlink()
    except OSError:
        pass
    try:
        if PID_FILE.exists() and int(PID_FILE.read_text().strip()) == os.getpid():
            PID_FILE.unlink()
    except (OSError, ValueError):
        pass


def _handle_sigterm(signum, frame):
    """Graceful shutdown on SIGTERM."""
    _cleanup()
    try:
        if _db is not None:
            _db.close()
    except Exception:
        pass
    raise SystemExit(0)


def _ensure_initialized():
    """Run startup checks lazily on first tool call, not during MCP handshake."""
    global _initialized
    if not _initialized:
        _initialized = True  # Set BEFORE checks to prevent recursive re-entry
        _startup_checks()


def get_config() -> Config:
    global _config
    if _config is None:
        _config = Config()
    return _config


def get_db() -> Database:
    global _db
    _ensure_initialized()
    if _db is None:
        _db = Database(get_config())
    return _db


def get_active_mind() -> tuple[str, str] | None:
    """Returns (mind_id, mind_name) or None."""
    if _active_mind_id is None:
        return None
    return (_active_mind_id, _active_mind_name)


def get_customer_id() -> str | None:
    """Return the authenticated customer_id, or None for self-hosted mode."""
    config = get_config()
    cid = getattr(config, 'customer_id', None)
    if not cid and getattr(config, 'api_key', None):
        logger.warn("customer_id is empty in hosted mode — isolation checks disabled")
    return cid if cid else None


def set_active_mind(mind_id: str, mind_name: str):
    global _active_mind_id, _active_mind_name
    _active_mind_id = mind_id
    _active_mind_name = mind_name


def _provision_from_gateway(config: Config):
    """Call gateway /v1/provision to get database config for hosted mode.

    Retries up to 2 times with 1s backoff for transient errors.
    """
    import time as _time
    url = f"{config.gateway_url.rstrip('/')}/v1/provision"
    max_retries = 2
    for attempt in range(max_retries):
        try:
            resp = httpx.post(
                url,
                headers={"Authorization": f"Bearer {config.api_key}"},
                timeout=5,
            )
            resp.raise_for_status()
            data = resp.json()

            # Parse DATABASE_URL into PG connection params
            db_url = data.get("database_url", "")
            if db_url:
                _parse_database_url(config, db_url)

            # Update embedding dims if provided
            if "embedding_dims" in data:
                config.embedding_dims = data["embedding_dims"]

            config.customer_id = data.get("customer_id", "")

            logger.info(
                "Provisioned from gateway",
                customer_id=config.customer_id,
                embedding_dims=config.embedding_dims,
            )
            return
        except Exception as e:
            if attempt < max_retries - 1:
                logger.warn(f"Gateway provisioning attempt {attempt + 1} failed: {e}. Retrying...")
                _time.sleep(1)
            else:
                logger.error(f"Gateway provisioning failed after {max_retries} attempts: {e}")
                sys.exit(1)


def _parse_database_url(config: Config, url: str):
    """Parse a PostgreSQL URL into config PG fields.

    Format: postgres://user:password@host:port/dbname
    """
    from urllib.parse import urlparse
    parsed = urlparse(url)
    if parsed.hostname:
        config.pg_host = parsed.hostname
    if parsed.port:
        config.pg_port = parsed.port
    if parsed.path and parsed.path != "/":
        config.pg_db = parsed.path.lstrip("/")
    if parsed.username:
        config.pg_user = parsed.username
    if parsed.password:
        config.pg_password = parsed.password


def _startup_checks():
    """Validate configuration and service dependencies per SERVER_SPEC.md."""
    config = get_config()

    # Hosted mode: provision from gateway first
    if config.api_key:
        _provision_from_gateway(config)
    else:
        # Self-hosted: require PG env vars
        import os
        pg_vars = {
            "COPPERMIND_PG_HOST": config.pg_host,
            "COPPERMIND_PG_PORT": str(config.pg_port),
            "COPPERMIND_PG_DB": config.pg_db,
            "COPPERMIND_PG_USER": config.pg_user,
            "COPPERMIND_PG_PASSWORD": config.pg_password,
        }
        missing = [k for k in pg_vars if not os.environ.get(k)]
        if missing:
            logger.error(f"Missing required environment variables: {', '.join(missing)}")
            sys.exit(1)

        # Required: PG password is non-empty
        if not config.pg_password:
            logger.error("COPPERMIND_PG_PASSWORD is required")
            sys.exit(1)

    # Required: PostgreSQL connection
    try:
        db = get_db()
        row = db.fetch_one("SELECT 1")
        if not row:
            raise Exception("Empty response")
    except Exception as e:
        logger.error(f"Cannot connect to PostgreSQL at {config.pg_host}:{config.pg_port}: {type(e).__name__}")
        sys.exit(1)

    # Required: pgvector extension
    try:
        db = get_db()
        row = db.fetch_one("SELECT 1 FROM pg_extension WHERE extname = 'vector'")
        if not row:
            raise Exception("not found")
    except Exception as e:
        logger.error("pgvector extension not found — run CREATE EXTENSION vector")
        sys.exit(1)

    # Optional: Embedding service
    if not embedding_client.check_health(config):
        logger.warn(
            "Embedding service not reachable — store_memory, search_memory, "
            "and quick_note will operate in degraded mode"
        )

    # Optional: LLM service (only check Ollama in self-hosted mode)
    if config.llm_provider == "ollama":
        try:
            import urllib.request
            req = urllib.request.Request(f"{config.ollama_url}/api/tags")
            with urllib.request.urlopen(req, timeout=5):
                pass
        except Exception as e:
            logger.warn(
                f"Ollama not reachable ({e}) — store_memory will default to type 'fact', "
                "prep_meeting will return raw data"
            )
    elif config.llm_provider == "gateway":
        # Gateway health is already verified by successful provisioning
        pass

    logger.info(
        "Startup checks complete",
        pg_host=config.pg_host,
        pg_port=config.pg_port,
        pg_db=config.pg_db,
        pg_user=config.pg_user,
        pg_password="***",
        llm_provider=config.llm_provider or "none",
        embedding_provider=config.embedding_provider or "none",
        embedding_dims=config.embedding_dims,
    )

    # Fetch server config (non-blocking, cached)
    server_cfg = fetch_server_config(config)
    if server_cfg.fetched and server_cfg.min_client_version:
        try:
            from importlib.metadata import version as pkg_version
            from packaging.version import Version
            current = Version(pkg_version("coppermind-cmo"))
            minimum = Version(server_cfg.min_client_version)
            if current < minimum:
                logger.warn(
                    f"Client version {current} is below minimum {minimum}. "
                    f"{server_cfg.upgrade_message}"
                )
        except Exception:
            pass  # Don't crash on version parsing

    # Install statusline script if it doesn't exist
    _install_statusline()

    # Install bundled skills
    _install_skills()

    # Optional: auto-start session watcher
    _start_watcher()


def _install_skills():
    """Copy bundled skill files to ~/.claude/skills/ if newer or missing."""
    import hashlib
    from pathlib import Path
    from importlib import resources

    skills_dir = Path.home() / ".claude" / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)

    try:
        skills_package = resources.files("coppermind_cmo") / "skills"
        if not skills_package.is_dir():
            return

        for skill_file in skills_package.iterdir():
            if not skill_file.name.endswith(".md"):
                continue

            dest = skills_dir / skill_file.name
            source_content = skill_file.read_text(encoding="utf-8")
            source_hash = hashlib.md5(source_content.encode()).hexdigest()

            if dest.exists():
                dest_hash = hashlib.md5(dest.read_text(encoding="utf-8").encode()).hexdigest()
                if source_hash == dest_hash:
                    continue

            dest.write_text(source_content, encoding="utf-8")
            logger.info(f"Installed skill: {skill_file.name}")
    except Exception as e:
        logger.warn(f"Failed to install skills: {e}")


def _install_statusline():
    """Copy statusline.sh to ~/.coppermind/ on first run (skipped on Windows)."""
    if sys.platform == "win32":
        return  # statusline.sh is bash-only; Windows users use python -m coppermind_cmo.statusline
    import shutil
    dest = os.path.expanduser("~/.coppermind/statusline.sh")
    if os.path.exists(dest):
        return
    try:
        src = os.path.join(os.path.dirname(__file__), "statusline.sh")
        if os.path.exists(src):
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(src, dest)
            os.chmod(dest, 0o755)
            logger.info("Installed statusline script", path=dest)
    except Exception as e:
        logger.warn(f"Could not install statusline script: {e}")


def _start_watcher():
    """Spawn the session watcher as a subprocess if enabled."""
    global _watcher_process

    if _watcher_process is not None:
        return  # already running

    enabled = os.environ.get("COPPERMIND_WATCHER_ENABLED", "true").lower()
    if enabled not in ("true", "1", "yes"):
        logger.info("Session watcher disabled via COPPERMIND_WATCHER_ENABLED")
        return

    try:
        popen_kwargs = {
            "stdout": subprocess.DEVNULL,
            "stderr": None,  # inherit parent's stderr for log visibility
        }
        if sys.platform == "win32":
            popen_kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
        _watcher_process = subprocess.Popen(
            [sys.executable, "-m", "coppermind_cmo.watch", "--interval", "30"],
            **popen_kwargs,
        )
        # Write watcher PID for stale process detection
        try:
            WATCHER_PID_FILE.parent.mkdir(parents=True, exist_ok=True)
            WATCHER_PID_FILE.write_text(str(_watcher_process.pid))
        except OSError:
            pass
        logger.info("Session watcher started", pid=_watcher_process.pid)
    except Exception as e:
        logger.warn(f"Could not start session watcher: {e}")


def _stop_watcher():
    """Kill the watcher subprocess on server shutdown."""
    global _watcher_process
    if _watcher_process is not None:
        try:
            _watcher_process.terminate()
            _watcher_process.wait(timeout=5)
        except Exception:
            try:
                _watcher_process.kill()
                _watcher_process.wait(timeout=2)
            except Exception:
                pass
        _watcher_process = None


def _register_tools():
    """Import and register all tool modules."""
    from coppermind_cmo.tools import minds, memories, brand, intelligence
    minds.register(mcp)
    memories.register(mcp)
    brand.register(mcp)
    intelligence.register(mcp)


def main():
    _ensure_single_instance()
    atexit.register(_cleanup)
    try:
        if hasattr(signal, "SIGTERM"):
            signal.signal(signal.SIGTERM, _handle_sigterm)
    except (OSError, ValueError):
        pass
    _register_tools()
    # Eager startup: run checks now so the first tool call is fast
    _ensure_initialized()
    mcp.run()
