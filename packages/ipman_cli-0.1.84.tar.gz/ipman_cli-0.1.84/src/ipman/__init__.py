"""IpMan - Intelligence Package Manager."""

from importlib.metadata import version as _version

__version__ = _version("ipman-cli")
