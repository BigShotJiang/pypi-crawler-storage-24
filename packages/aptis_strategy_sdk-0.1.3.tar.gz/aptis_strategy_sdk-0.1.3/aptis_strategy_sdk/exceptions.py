"""SDK exceptions"""

class AptisAPIError(Exception):
    """Base exception for Aptis API errors"""
    pass

class AuthenticationError(AptisAPIError):
    """Authentication failed"""
    pass

class ValidationError(AptisAPIError):
    """Request validation failed"""
    pass

class RateLimitError(AptisAPIError):
    """API rate limit exceeded"""
    pass
