"""Base strategy class"""
from abc import ABC, abstractmethod
from typing import List, Dict, Any
from datetime import date
from aptis_strategy_sdk.client import AptisClient
from aptis_strategy_sdk.models import Signal

class Strategy(ABC):
    """Base class for trading strategies"""
    
    def __init__(self, name: str, client: AptisClient, account: str):
        self.name = name
        self.client = client
        self.account = account
    
    @abstractmethod
    def generate_signals(self, date: date) -> List[Signal]:
        """
        Generate trading signals for the given date

        Override this method with your strategy logic

        Returns:
            List of Signal objects to execute
        """
        pass
    
    def run(self, date: date) -> Dict[str, Any]:
        """
        Run strategy for the given date

        1. Generate signals
        2. Submit to Aptis platform
        3. Return results
        """
        signals = self.generate_signals(date)
        
        results = []
        for signal in signals:
            response = self.client.submit_signal(signal, self.name)
            results.append(response)
        
        return {
            "date": date.isoformat(),
            "signals_generated": len(signals),
            "results": results,
        }
    
    def get_features(self, symbols: List[str], date: date, features: List[str]) -> Dict[str, Dict[str, float]]:
        """Get Dagster-calculated features"""
        return self.client.get_features(symbols, date, features)
    
    def get_positions(self) -> List:
        """Get current positions for this strategy"""
        return self.client.get_positions(self.account, self.name)
    
    def get_pnl(self, start_date: date, end_date: date) -> Dict[str, Any]:
        """Get P&L for this strategy"""
        return self.client.get_pnl(self.account, start_date, end_date, self.name)
