"""Data models for Aptis SDK"""
from dataclasses import dataclass
from typing import Optional, Dict, Any
from datetime import datetime

@dataclass
class Signal:
    """Trading signal"""
    symbol: str
    asset_class: str
    quantity: float
    side: str  # BUY or SELL
    signal_type: str  # ENTRY, EXIT, ADJUST
    order_parameters: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None

@dataclass
class Position:
    """Current position"""
    symbol: str
    asset_class: str
    quantity: float
    avg_entry_price: float
    current_price: float
    unrealized_pnl: float
    realized_pnl: float

@dataclass
class Bar:
    """OHLCV bar"""
    symbol: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float

@dataclass
class Quote:
    """Market quote"""
    symbol: str
    timestamp: datetime
    bid: float
    ask: float
    last: float
    volume: float
