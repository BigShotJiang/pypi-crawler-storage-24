# Aptis Strategy SDK

Python SDK for building trading strategies on the Aptis platform.

**Author:** Richard Chung

## Installation

```bash
pip install aptis-strategy-sdk
```

## Environment Variables

```bash
APTIS_API_KEY=your_api_key_here     # Your API key
APTIS_ACCOUNT=Theme                  # Account to trade under (Theme or QSpark)
APTIS_API_URL=http://localhost:8082  # Backend URL
```

Never hardcode these — always read from env vars.

## Quick Start

```python
import os
from aptis_strategy_sdk import AptisClient, Strategy, Signal
from datetime import date

client = AptisClient(
    api_key=os.getenv("APTIS_API_KEY", "test_key_123"),
    base_url=os.getenv("APTIS_API_URL", "http://localhost:8082")
)

class MyStrategy(Strategy):
    def generate_signals(self, run_date: date):
        # your logic here
        return [Signal(symbol="AAPL", asset_class="equity",
                       quantity=100, side="BUY", signal_type="ENTRY")]

strategy = MyStrategy(
    name="My Strategy",
    client=client,
    account=os.getenv("APTIS_ACCOUNT", "Theme")
)
result = strategy.run(date.today())
```

## Accounts

The platform supports multiple accounts (trading scenarios). Each account has its own API key. Set `APTIS_ACCOUNT` to target the correct account:

```bash
# Run against Theme account
APTIS_ACCOUNT=Theme APTIS_API_KEY=test_key_123 python my_strategy.py

# Run against QSpark account
APTIS_ACCOUNT=QSpark APTIS_API_KEY=qspark_key_123 python my_strategy.py
```

## API Methods

### AptisClient

- `submit_signal(signal, strategy_name, account)` — submit a trading signal
- `get_config(strategy_name)` — get NAV, funds, portfolio_weight, enabled
- `get_quotes(symbols, asset_class)` — get market quotes
- `get_bars(symbol, asset_class, timeframe, start, end)` — get OHLCV bars
- `get_positions(account, strategy_name)` — get current positions
- `get_pnl(account, start_date, end_date, strategy_name)` — get P&L

### Strategy Base Class

- `generate_signals(date)` — override with your logic, return `List[Signal]`
- `run(date)` — calls `generate_signals`, submits all signals
- `get_features(symbols, date, features)` — fetch Dagster features
- `get_positions()` — get positions for this strategy

## Signal Fields

| Field | Required | Description |
|-------|----------|-------------|
| `symbol` | Yes | Ticker |
| `asset_class` | Yes | `equity`, `etf`, `crypto`, `forex`, `commodity` |
| `quantity` | Yes | Units |
| `side` | Yes | `BUY` or `SELL` |
| `signal_type` | Yes | `ENTRY`, `EXIT`, `ADJUST` |
| `order_parameters` | No | `order_type`, `limit_price`, etc. |
| `metadata` | No | Notes only, not used for execution |

## Full Documentation

See [docs/customer-integration/](../docs/customer-integration/) for complete guides.
