"""Language-specific AST analyzers."""
