"""
Prajnyavan SDK — zero-friction client.
"""
from __future__ import annotations

import json
import os
import inspect
import warnings
from functools import lru_cache, wraps
from typing import Any, Callable, Dict, List, Optional

import requests

from ._daemon import MODEL_CACHE, ensure_daemon_running, _load_config, _save_config
from .exceptions import (
    PrajnyavanAuthError,
    PrajnyavanConfigError,
    PrajnyavanConnectionError,
    PrajnyavanError,
)

# ── Embedding helpers ────────────────────────────────────────────────────────

EMBED_DIM = 768
_LOCAL_MODELS: Dict[str, Any] = {}


def _fit_embedding(vec: List[float]) -> List[float]:
    if len(vec) == EMBED_DIM:
        return vec
    out = [0.0] * EMBED_DIM
    n = len(vec)
    for i in range(EMBED_DIM):
        src = int(i * n / EMBED_DIM)
        out[i] = float(vec[src])
    return out


def _embed_openai(text: str, api_key: str, model: str = "text-embedding-3-small") -> List[float]:
    import openai

    client = openai.OpenAI(api_key=api_key)
    response = client.embeddings.create(model=model, input=text)
    return _fit_embedding(response.data[0].embedding)


def _embed_cohere(text: str, api_key: str, model: str = "embed-english-v3.0") -> List[float]:
    import cohere

    co = cohere.Client(api_key)
    response = co.embed(texts=[text], model=model, input_type="search_document")
    return _fit_embedding(response.embeddings[0])


def _ensure_local_model(model_name: str) -> Any:
    if model_name in _LOCAL_MODELS:
        return _LOCAL_MODELS[model_name]

    MODEL_CACHE.mkdir(parents=True, exist_ok=True)
    try:
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer(model_name, cache_folder=str(MODEL_CACHE))
        _LOCAL_MODELS[model_name] = model
        return model
    except Exception:
        _LOCAL_MODELS[model_name] = None
        return None


def _hash_embed(text: str) -> List[float]:
    out = [0.0] * EMBED_DIM
    h = 14695981039346656037  # FNV-1a offset
    for b in text.encode("utf-8"):
        h ^= b
        h = (h * 1099511628211) & 0xFFFFFFFFFFFFFFFF
        idx = h % EMBED_DIM
        out[idx] = min(1.0, out[idx] + b / 255.0)
    return out


def _embed_local(text: str, model_name: str = "all-mpnet-base-v2") -> List[float]:
    model = _ensure_local_model(model_name)
    if model is None:
        return _hash_embed(text)
    return _fit_embedding(model.encode(text).tolist())


# ── Client ───────────────────────────────────────────────────────────────────


class MemoryClient:
    """
    Prajnyavan memory client.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        openai_api_key: Optional[str] = None,
        embedding_provider: str = "local",
        embedding_model: Optional[str] = None,
    ):
        if base_url is None or token is None:
            cfg = _load_config()
            if not cfg:
                raise PrajnyavanConfigError(
                    "base_url and token are required unless prajnyavan dev has been started."
                )
            base_url = base_url or cfg["base_url"]
            token = token or cfg["token"]

        self.base_url = base_url.rstrip("/")
        self.token = token
        self.embedding_provider = embedding_provider
        self.embedding_model = embedding_model
        self._openai_key = openai_api_key or os.environ.get("OPENAI_API_KEY")
        self._can_auto_refresh = False

        if self.base_url.startswith("http+unix://"):
            try:
                from requests_unixsocket import Session  # type: ignore
            except ImportError as e:
                raise PrajnyavanConfigError("requests-unixsocket is required for UDS mode") from e
            self.session = Session()
        else:
            self.session = requests.Session()

        self.session.headers.update(
            {
                "authorization": token,
                "content-type": "application/json",
            }
        )

        self._embed_cached = lru_cache(maxsize=512)(self._embed_uncached)

    # ---- Classmethods -------------------------------------------------------
    @classmethod
    def dev(cls, user_id: str = "developer", **kwargs) -> "MemoryClient":
        cfg = ensure_daemon_running()
        client = cls(
            base_url=cfg["base_url"],
            token=cfg["token"],
            embedding_provider=kwargs.pop("embedding_provider", "hash"),
            **kwargs,
        )
        client._can_auto_refresh = True
        return client

    @classmethod
    def from_env(cls, **kwargs) -> "MemoryClient":
        url = os.environ.get("PRAJNYAVAN_URL")
        token = os.environ.get("PRAJNYAVAN_TOKEN")
        if not url or not token:
            missing = [name for name, val in [("PRAJNYAVAN_URL", url), ("PRAJNYAVAN_TOKEN", token)] if not val]
            raise PrajnyavanConfigError(f"Missing env vars: {missing}. Use MemoryClient.dev() for local development.")
        provider = os.environ.get("PRAJNYAVAN_EMBEDDING_PROVIDER", "local")
        return cls(base_url=url, token=token, embedding_provider=provider, **kwargs)

    # ---- Internal HTTP helper ----------------------------------------------
    def _refresh_token(self) -> None:
        new_token = get_token(self.base_url)
        self.token = new_token
        self.session.headers["authorization"] = new_token
        cfg = _load_config() or {}
        if cfg:
            cfg["token"] = new_token
            _save_config(cfg)

    def _request(self, method: str, path: str, retry: bool = True, **kwargs) -> requests.Response:
        url = f"{self.base_url}{path}"
        try:
            resp = self.session.request(method, url, timeout=kwargs.pop("timeout", 10), **kwargs)
        except requests.exceptions.RequestException as e:
            raise PrajnyavanConnectionError(f"Daemon unreachable: {e}") from e

        if resp.status_code in (401, 403):
            if self._can_auto_refresh and retry:
                try:
                    self._refresh_token()
                    return self._request(method, path, retry=False, **kwargs)
                except Exception:
                    pass
            raise PrajnyavanAuthError("Token expired. Call MemoryClient.dev() again to refresh.")

        resp.raise_for_status()
        return resp

    # ---- Embedding ---------------------------------------------------------
    def _embed_uncached(self, text: str) -> tuple:
        return tuple(self._embed_raw(text))

    def _embed_raw(self, text: str) -> List[float]:
        if self.embedding_provider == "openai":
            if not self._openai_key:
                raise PrajnyavanConfigError("OPENAI_API_KEY required for openai embeddings.")
            model = self.embedding_model or "text-embedding-3-small"
            return _embed_openai(text, self._openai_key, model=model)
        if self.embedding_provider == "cohere":
            api_key = os.environ.get("COHERE_API_KEY")
            if not api_key:
                raise PrajnyavanConfigError("COHERE_API_KEY required for cohere embeddings.")
            model = self.embedding_model or "embed-english-v3.0"
            return _embed_cohere(text, api_key, model=model)
        if self.embedding_provider == "local":
            return _embed_local(text, self.embedding_model or "all-mpnet-base-v2")
        # hash fallback
        return _hash_embed(text)

    def embed(self, text: str) -> List[float]:
        return list(self._embed_cached(text))

    # ---- API surface --------------------------------------------------------
    def store(
        self,
        user_id: str,
        content: str,
        *,
        namespace: Optional[str] = None,
        importance: Optional[float] = None,
        category: Optional[str] = None,
        ttl_days: Optional[int] = None,
        tags: Optional[List[str]] = None,
        memory_id: Optional[str] = None,
    ) -> str:
        embedding = self.embed(content)
        payload: Dict[str, Any] = {
            "content": content,
            "embedding": embedding,
            "context": {"who": user_id},
            "tags": tags or [],
            "category": category,
            "ttl_days": ttl_days,
            "importance": importance,
            "memory_id": memory_id,
            "modality": "text",
        }
        if namespace:
            payload["tags"] = list(set((tags or []) + [f"ns:{namespace}"]))
        resp = self._request("post", "/memory", data=json.dumps(payload))
        return resp.json()["id"]

    def search(
        self,
        user_id: str,
        query: str,
        *,
        namespace: Optional[str] = None,
        k: int = 5,
        valence_bias: Optional[str] = None,
        min_importance: Optional[float] = None,
        category: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        embedding = self.embed(query)
        payload: Dict[str, Any] = {
            "query": query,
            "embedding": embedding,
            "k": k,
            "filters": {"person": user_id},
        }
        if valence_bias:
            payload["filters"]["valence_bias"] = valence_bias
        if min_importance is not None:
            payload["filters"]["min_importance"] = min_importance
        if category:
            payload["filters"]["category"] = category
        if namespace:
            payload["filters"]["tags"] = [f"ns:{namespace}"]
        resp = self._request("post", "/memory/search", data=json.dumps(payload))
        return resp.json().get("results", [])

    def store_batch(self, user_id: str, items: List[Dict[str, Any]], *, ttl_days=None) -> List[str]:
        return [
            self.store(
                user_id,
                i["content"],
                importance=i.get("importance"),
                category=i.get("category"),
                tags=i.get("tags"),
                ttl_days=ttl_days or i.get("ttl_days"),
                namespace=i.get("namespace"),
            )
            for i in items
        ]

    def search_batch(self, user_id: str, queries: List[str], *, k: int = 5) -> List[List[Dict[str, Any]]]:
        return [self.search(user_id, q, k=k) for q in queries]

    def delete_user(self, user_id: str) -> int:
        resp = self._request("delete", f"/memory/user/{user_id}")
        return resp.json().get("deleted", 0)

    def export_user(self, user_id: str) -> List[Dict[str, Any]]:
        resp = self._request("get", f"/memory/export/{user_id}")
        return resp.json().get("memories", [])

    def highlights(self, user_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        resp = self._request("get", f"/memory/highlights/{user_id}")
        return resp.json().get("highlights", [])[:limit]

    def summary(self, user_id: str, days: int = 7) -> str:
        resp = self._request("get", f"/memory/summary/{user_id}", params={"days": days})
        return resp.json().get("summary", "")

    def explain(self, query: str) -> List[Dict[str, Any]]:
        embedding = self.embed(query)
        payload = {"query": query, "embedding": embedding, "k": 5}
        resp = self._request("post", "/memory/explain", data=json.dumps(payload))
        return resp.json().get("results", [])

    # ---- Decorator ----------------------------------------------------------
    def wrap_llm(
        self,
        user_id: str,
        *,
        k: int = 5,
        valence_bias: Optional[str] = None,
        debug: bool = False,
    ):
        def decorator(fn: Callable[..., str]):
            @wraps(fn)
            def wrapper(prompt: str, *args, **kwargs):
                memories = self.search(user_id, prompt, k=k, valence_bias=valence_bias)

                if memories:
                    ctx_lines = [
                        f"- ({m.get('importance', 0):.2f} importance) {m.get('content_text') or m.get('content', '')}"
                        for m in memories
                    ]
                    enriched = "Relevant memories about this user:\n" + "\n".join(ctx_lines) + "\n\nUser message: " + prompt
                else:
                    enriched = prompt

                sig = inspect.signature(fn)
                accepts_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values())
                call_kwargs = dict(kwargs)

                if accepts_kwargs or "memory_context" in sig.parameters:
                    call_kwargs.setdefault("memory_context", memories)
                if accepts_kwargs or "enriched_prompt" in sig.parameters:
                    call_kwargs.setdefault("enriched_prompt", enriched)

                result = fn(prompt, *args, **call_kwargs)

                try:
                    self.store(user_id, f"User said: {prompt}")
                except PrajnyavanConnectionError:
                    warnings.warn(
                        "[prajnyavan] Memory store failed: daemon unreachable. Run: prajnyavan status",
                        RuntimeWarning,
                        stacklevel=3,
                    )
                except PrajnyavanError as e:
                    warnings.warn(f"[prajnyavan] Memory store failed: {e}", RuntimeWarning, stacklevel=3)

                if debug:
                    return {"result": result, "memories_used": memories}
                return result

            return wrapper

        return decorator


# ── Helpers -----------------------------------------------------------------


def get_token(base_url: str, user_id: str = "developer") -> str:
    resp = requests.post(
        f"{base_url.rstrip('/')}/auth/token",
        json={"user_id": user_id, "capabilities": ["read", "write"]},
        timeout=8,
    )
    resp.raise_for_status()
    return f"Bearer {resp.json()['token']}"


def auto_client(user_id: str = "developer", **kwargs: Any) -> MemoryClient:
    cfg = _load_config()
    if not cfg:
        cfg = ensure_daemon_running()
    base_url = cfg.get("base_url")
    token = get_token(base_url, user_id=user_id)
    client = MemoryClient(base_url=base_url, token=token, **kwargs)
    client._can_auto_refresh = True
    return client


__all__ = ["MemoryClient", "get_token", "auto_client"]
