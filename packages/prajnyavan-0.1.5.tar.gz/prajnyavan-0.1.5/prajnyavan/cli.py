"""
CLI entrypoint for Prajnyavan.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import sys
import time
from pathlib import Path

import requests

from ._daemon import (
    BASE_DIR,
    DAEMON_LOG,
    PID_FILE,
    MODEL_CACHE,
    _load_config,
    _pid_alive,
    ensure_daemon_running,
)
from .client import MemoryClient, get_token


def _tail_log(path: Path, n: int = 50) -> str:
    try:
        return "\n".join(path.read_text().splitlines()[-n:])
    except Exception:
        return ""


def cmd_dev(_: argparse.Namespace) -> int:
    cfg = ensure_daemon_running()
    snippet = (
        "from prajnyavan import MemoryClient\n"
        "mem = MemoryClient.dev(user_id=\"user_123\")\n"
        "@mem.wrap_llm(user_id=\"user_123\")\n"
        "def chat(prompt):\n"
        "    return \"Your LLM call here\"\n"
    )
    print(f"[prajnyavan] running at {cfg['base_url']} (pid={cfg.get('pid')})")
    print("[prajnyavan] paste this snippet into your app:\n")
    print(snippet)
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    cfg = _load_config()
    if not cfg:
        print("[prajnyavan] Not running. Start with: prajnyavan dev", file=sys.stderr)
        return 1
    pid = cfg.get("pid")
    url = cfg.get("base_url")
    alive = _pid_alive(pid) if pid else False
    health = {}
    if alive and url:
        try:
            health = requests.get(f"{url}/health", timeout=2).json()
        except Exception:
            health = {}
    icon = "●" if alive else "○"
    print(f"{icon} prajnyavan {'running' if alive else 'stopped'}")
    print(f"  url:      {url}")
    print(f"  pid:      {pid}")
    if args.verbose and health:
        print(f"  version:  {health.get('version', '?')}")
        print(f"  uptime:   {health.get('uptime_seconds', 0)}s")
        print(f"  memories: {health.get('memories_stored', 0)}")
        mb = (
            sum(p.stat().st_size for p in MODEL_CACHE.rglob("*")) / 1e6
            if MODEL_CACHE.exists()
            else 0
        )
        print(f"  cache:    {mb:.1f} MB")
        print(f"  log:      {DAEMON_LOG}")
    return 0 if alive else 1


def cmd_logs(args: argparse.Namespace) -> int:
    if not DAEMON_LOG.exists():
        print("[prajnyavan] No log file found. Run prajnyavan dev first.")
        return 1
    print(_tail_log(DAEMON_LOG, n=args.lines))
    return 0


def _kill_pid(pid: int) -> None:
    if os.name == "nt":
        os.system(f"taskkill /PID {pid} /F >NUL 2>&1")
    else:
        try:
            os.kill(pid, signal.SIGTERM)
        except Exception:
            pass


def cmd_stop(_: argparse.Namespace) -> int:
    if not PID_FILE.exists():
        print("[prajnyavan] No running daemon found.")
        return 0
    try:
        pid = int(PID_FILE.read_text().strip())
    except Exception:
        PID_FILE.unlink(missing_ok=True)
        return 0

    if _pid_alive(pid):
        _kill_pid(pid)
        time.sleep(0.5)
    PID_FILE.unlink(missing_ok=True)
    print("[prajnyavan] stopped.")
    return 0


def cmd_reset(_: argparse.Namespace) -> int:
    cmd_stop(_)
    if BASE_DIR.exists():
        shutil.rmtree(BASE_DIR, ignore_errors=True)
    print("[prajnyavan] reset: cleared data and model cache.")
    return 0


def cmd_export(args: argparse.Namespace) -> int:
    mem = MemoryClient.dev()
    data = mem.export_user(args.user)
    out = Path(args.output or f"prajnyavan_export_{args.user}.json")
    out.write_text(json.dumps(data, indent=2))
    print(f"[prajnyavan] Exported {len(data)} memories to {out}")
    return 0


def cmd_import(args: argparse.Namespace) -> int:
    mem = MemoryClient.dev()
    data = json.loads(Path(args.file).read_text())
    ids = mem.store_batch(
        args.user,
        [
            {
                "content": m["content_text"],
                "importance": m.get("importance"),
                "tags": m.get("tags", []),
            }
            for m in data
        ],
    )
    print(f"[prajnyavan] Imported {len(ids)} memories for user {args.user}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="prajnyavan", description="Prajnyavan CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("dev", help="Start local daemon")

    status_p = sub.add_parser("status", help="Show daemon status")
    status_p.add_argument("--verbose", "-v", action="store_true")

    logs_p = sub.add_parser("logs", help="Tail daemon log")
    logs_p.add_argument("--lines", "-n", type=int, default=50)

    sub.add_parser("stop", help="Stop daemon")
    sub.add_parser("reset", help="Stop and clear local data/cache")

    export_p = sub.add_parser("export", help="Export memories for a user")
    export_p.add_argument("--user", required=True)
    export_p.add_argument("--output", "-o")

    import_p = sub.add_parser("import", help="Import memories for a user")
    import_p.add_argument("--user", required=True)
    import_p.add_argument("--file", required=True)

    args = parser.parse_args()

    if args.cmd == "dev":
        return cmd_dev(args)
    if args.cmd == "status":
        return cmd_status(args)
    if args.cmd == "logs":
        return cmd_logs(args)
    if args.cmd == "stop":
        return cmd_stop(args)
    if args.cmd == "reset":
        return cmd_reset(args)
    if args.cmd == "export":
        return cmd_export(args)
    if args.cmd == "import":
        return cmd_import(args)

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
