class PrajnyavanError(Exception):
    """Base exception for Prajnyavan."""


class PrajnyavanConnectionError(PrajnyavanError):
    """Daemon unreachable."""


class PrajnyavanAuthError(PrajnyavanError):
    """Token expired or invalid."""


class PrajnyavanSetupError(PrajnyavanError):
    """Binary missing or daemon failed to start."""


class PrajnyavanConfigError(PrajnyavanError):
    """Required configuration missing."""
