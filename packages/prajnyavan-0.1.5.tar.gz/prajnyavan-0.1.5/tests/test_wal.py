import pytest


def test_wal_basic(tmp_path):
    try:
        from brain_db._native import PyWal
    except Exception:
        pytest.skip("brain_db native module not available")

    wal_path = tmp_path / "demo.wal"
    wal = PyWal(str(wal_path))

    # Write two payloads
    wal.append(b"hello")
    wal.append(b"world")

    # Replay and collect
    received = []

    def collector(data):
        received.append(bytes(data))

    wal.replay(collector)

    assert received == [b"hello", b"world"]
