import os
import subprocess
import sys
import time

import pytest

from prajnyavan import auto_client


@pytest.mark.integration
def test_dev_roundtrip():
    """Start local daemon, run a memory round-trip, then stop."""
    if not os.getenv("RUN_PRAJNYAVAN_INTEGRATION"):
        pytest.skip("Set RUN_PRAJNYAVAN_INTEGRATION=1 to run integration test.")

    subprocess.run([sys.executable, "-m", "prajnyavan.cli", "stop"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    subprocess.run([sys.executable, "-m", "prajnyavan.cli", "dev"], check=True, timeout=60)
    time.sleep(1)

    mem = auto_client(user_id="itest")

    @mem.wrap_llm(user_id="itest")
    def echo(prompt: str):
        return prompt + "!"

    out = echo("hello memory")
    assert out.startswith("hello memory")

    hits = mem.search("itest", "hello")
    assert len(hits) >= 1

    subprocess.run([sys.executable, "-m", "prajnyavan.cli", "stop"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
