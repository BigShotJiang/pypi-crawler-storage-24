import pytest


def test_hello():
    try:
        import brain_db._native as native
    except Exception:
        pytest.skip("brain_db native module not available")
    assert native.hello() == "🧠 Brain‑DB is alive!"
