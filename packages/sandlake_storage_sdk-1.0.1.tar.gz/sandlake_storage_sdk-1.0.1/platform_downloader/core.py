#!/usr/bin/env python3
"""
平台模型和数据集下载公共类库
提供类似ModelScope风格的API，基于S3存储后端

主要功能:
    - 模型下载: snapshot_download, model_file_download
    - 数据集下载: dataset_download, dataset_file_download
    - 支持模型ID到S3路径的映射
    - 支持断点续传、进度显示、并发下载

安装依赖:
    pip install boto3 requests tqdm

使用示例:
    >>> from platform_downloader import PlatformDownloader
    >>> downloader = PlatformDownloader()
    >>> model_dir = downloader.snapshot_download("org/model-name", local_dir="./models")
"""

import os
import sys
import json
import logging
import configparser
import tempfile
import threading
import urllib.parse
from pathlib import Path
from typing import Optional, List, Union, Dict, Callable, Any, Tuple
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import time

try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

try:
    import requests
    from requests.adapters import HTTPAdapter
    from requests.packages.urllib3.util.retry import Retry
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# ==================== 配置类 ====================

@dataclass
class PlatformConfig:
    """平台配置类"""
    # S3配置
    endpoint_url: str = "http://192.168.95.85:9000"
    access_key: str = "admin"
    secret_key: str = "2wsx@WSX"
    bucket: str = "sandlake"
    
    # 路径映射配置
    models_prefix: str = "models"      # 模型在bucket中的前缀
    datasets_prefix: str = "datasets"  # 数据集在bucket中的前缀
    
    # 下载配置
    cache_dir: str = field(default_factory=lambda: str(Path.home() / ".cache" / "platform"))
    max_workers: int = 4               # 并发下载线程数
    chunk_size: int = 8192             # 下载块大小
    retry_times: int = 3               # 重试次数
    timeout: int = 300                 # 超时时间（秒）
    connection_pool_size: int = 0      # 连接池大小 (0=自动计算: max_workers*2)
    
    # 认证配置
    api_token: Optional[str] = None    # API访问令牌
    
    @classmethod
    def from_config_file(cls, config_path: str) -> "PlatformConfig":
        """从配置文件加载配置"""
        config = configparser.ConfigParser()
        config.read(config_path)
        
        s3_section = config['s3'] if 's3' in config.sections() else {}
        platform_section = config['platform'] if 'platform' in config.sections() else {}
        
        return cls(
            endpoint_url=s3_section.get('endpoint_url', cls.endpoint_url),
            access_key=s3_section.get('access_key', cls.access_key),
            secret_key=s3_section.get('secret_key', cls.secret_key),
            bucket=s3_section.get('bucket', cls.bucket),
            models_prefix=platform_section.get('models_prefix', cls.models_prefix),
            datasets_prefix=platform_section.get('datasets_prefix', cls.datasets_prefix),
            cache_dir=platform_section.get('cache_dir', cls.cache_dir),
            max_workers=platform_section.getint('max_workers', cls.max_workers),
            api_token=platform_section.get('api_token', cls.api_token),
        )


# ==================== 异常类 ====================

class PlatformError(Exception):
    """平台基础异常"""
    pass

class ModelNotFoundError(PlatformError):
    """模型不存在异常"""
    pass

class DatasetNotFoundError(PlatformError):
    """数据集不存在异常"""
    pass

class AuthenticationError(PlatformError):
    """认证失败异常"""
    pass

class DownloadError(PlatformError):
    """下载失败异常"""
    pass


# ==================== 工具函数 ====================

class PathMapper:
    """模型ID到S3路径的映射器"""
    
    @staticmethod
    def model_id_to_s3_path(model_id: str, prefix: str = "models") -> str:
        """
        将模型ID转换为S3路径
        
        Args:
            model_id: 模型ID，格式如 "org/model-name" 或 "org/model-name/version"
            prefix: bucket中的前缀
            
        Returns:
            S3路径，如 "models/org/model-name/"
        """
        # 规范化模型ID
        model_id = model_id.strip("/")
        return f"{prefix}/{model_id}/"
    
    @staticmethod
    def dataset_id_to_s3_path(dataset_id: str, prefix: str = "datasets") -> str:
        """
        将数据集ID转换为S3路径
        
        Args:
            dataset_id: 数据集ID，格式如 "org/dataset-name"
            prefix: bucket中的前缀
            
        Returns:
            S3路径
        """
        dataset_id = dataset_id.strip("/")
        return f"{prefix}/{dataset_id}/"
    
    @staticmethod
    def parse_model_id(model_id: str) -> Dict[str, str]:
        """
        解析模型ID
        
        Args:
            model_id: 模型ID，如 "org/model-name" 或 "org/model-name/v1.0"
            
        Returns:
            包含org, name, version的字典
        """
        parts = model_id.strip("/").split("/")
        result = {
            "org": parts[0] if len(parts) > 0 else "",
            "name": parts[1] if len(parts) > 1 else "",
            "version": parts[2] if len(parts) > 2 else "latest"
        }
        return result


class ProgressTracker:
    """下载进度追踪器"""
    
    def __init__(self, total_size: int, desc: str = "Downloading", unit: str = "B"):
        self.total_size = total_size
        self.downloaded = 0
        self.lock = threading.Lock()
        
        if TQDM_AVAILABLE:
            self.pbar = tqdm(total=total_size, desc=desc, unit=unit, unit_scale=True)
        else:
            self.pbar = None
            logger.info(f"开始下载: {desc} (总大小: {self._format_size(total_size)})")
    
    def update(self, size: int):
        """更新进度"""
        with self.lock:
            self.downloaded += size
            if self.pbar:
                self.pbar.update(size)
    
    def close(self):
        """关闭进度条"""
        if self.pbar:
            self.pbar.close()
        else:
            logger.info(f"下载完成: {self._format_size(self.downloaded)}")
    
    @staticmethod
    def _format_size(size: int) -> str:
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.2f} {unit}"
            size /= 1024.0
        return f"{size:.2f} PB"


# ==================== S3客户端 ====================

class S3Client:
    """S3客户端封装"""
    
    def __init__(self, config: PlatformConfig):
        if not BOTO3_AVAILABLE:
            raise ImportError("boto3 is required. Install with: pip install boto3")
        
        from botocore.config import Config
        
        self.config = config
        self.session = boto3.Session(
            aws_access_key_id=config.access_key,
            aws_secret_access_key=config.secret_key
        )
        
        # 配置连接池和重试策略
        # max_pool_connections: 连接池大小，默认10，根据max_workers调整
        if config.connection_pool_size > 0:
            pool_size = config.connection_pool_size
        else:
            # 自动计算: 至少为 max_workers * 2 或 20
            pool_size = max(config.max_workers * 2, 20)
        
        botocore_config = Config(
            max_pool_connections=pool_size,
            retries={
                'max_attempts': config.retry_times,
                'mode': 'adaptive'  # 自适应重试模式
            },
            # 连接超时和读取超时
            connect_timeout=10,
            read_timeout=config.timeout,
        )
        
        s3_kwargs = {'config': botocore_config}
        if config.endpoint_url:
            s3_kwargs['endpoint_url'] = config.endpoint_url
        
        self.client = self.session.client('s3', **s3_kwargs)
        self.bucket = config.bucket
        
        logger.debug(f"S3Client initialized with pool_size={pool_size}, "
                    f"max_workers={config.max_workers}, retry_times={config.retry_times}")
    
    def list_objects(self, prefix: str) -> List[Dict[str, Any]]:
        """列出指定前缀下的所有对象"""
        objects = []
        paginator = self.client.get_paginator('list_objects_v2')
        
        try:
            for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
                if 'Contents' in page:
                    objects.extend(page['Contents'])
        except ClientError as e:
            logger.error(f"列出对象失败: {e}")
            raise
        
        return objects
    
    def object_exists(self, key: str) -> bool:
        """检查对象是否存在"""
        try:
            self.client.head_object(Bucket=self.bucket, Key=key)
            return True
        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                return False
            raise
    
    def get_object_size(self, key: str) -> int:
        """获取对象大小"""
        try:
            response = self.client.head_object(Bucket=self.bucket, Key=key)
            return response['ContentLength']
        except ClientError as e:
            logger.error(f"获取对象大小失败: {e}")
            raise
    
    def download_file(self, key: str, local_path: str, progress_callback: Optional[Callable] = None):
        """
        下载文件
        
        Args:
            key: S3对象键
            local_path: 本地保存路径
            progress_callback: 进度回调函数，接收(bytes_downloaded)参数
        """
        try:
            # 确保目录存在
            Path(local_path).parent.mkdir(parents=True, exist_ok=True)
            
            # 使用boto3的下载功能
            extra_args = {}
            
            if progress_callback:
                # 包装回调函数
                def _callback(bytes_amount):
                    progress_callback(bytes_amount)
                
                self.client.download_file(
                    self.bucket, key, local_path,
                    Callback=_callback
                )
            else:
                self.client.download_file(self.bucket, key, local_path)
                
        except ClientError as e:
            logger.error(f"下载文件失败 {key}: {e}")
            raise DownloadError(f"Failed to download {key}: {e}")
    
    def download_fileobj(self, key: str, fileobj, progress_callback: Optional[Callable] = None):
        """下载文件到文件对象"""
        try:
            extra_args = {}
            self.client.download_fileobj(
                self.bucket, key, fileobj,
                Callback=progress_callback
            )
        except ClientError as e:
            logger.error(f"下载文件失败 {key}: {e}")
            raise DownloadError(f"Failed to download {key}: {e}")
    
    def upload_file(self, local_path: str, key: str, progress_callback: Optional[Callable] = None):
        """
        上传文件到S3
        
        Args:
            local_path: 本地文件路径
            key: S3对象键
            progress_callback: 进度回调函数，接收(bytes_uploaded)参数
        """
        try:
            if progress_callback:
                self.client.upload_file(
                    local_path, self.bucket, key,
                    Callback=progress_callback
                )
            else:
                self.client.upload_file(local_path, self.bucket, key)
        except ClientError as e:
            logger.error(f"上传文件失败 {local_path} -> {key}: {e}")
            raise DownloadError(f"Failed to upload {local_path}: {e}")


# ==================== 下载器类 ====================

class PlatformDownloader:
    """
    平台模型和数据集下载器
    
    提供类似ModelScope的API风格:
        - snapshot_download: 下载整个模型/数据集
        - model_file_download: 下载单个文件
    """
    
    def __init__(self, config: Optional[PlatformConfig] = None, config_file: Optional[str] = None):
        """
        初始化下载器
        
        Args:
            config: PlatformConfig配置对象
            config_file: 配置文件路径（如果config为None则从此文件加载）
        """
        if config:
            self.config = config
        elif config_file:
            self.config = PlatformConfig.from_config_file(config_file)
        else:
            # 尝试加载默认配置文件
            default_config = Path(__file__).parent / "config.cfg"
            if default_config.exists():
                self.config = PlatformConfig.from_config_file(str(default_config))
            else:
                self.config = PlatformConfig()
        
        self.s3_client = S3Client(self.config)
        self.path_mapper = PathMapper()
        
        # 确保缓存目录存在
        Path(self.config.cache_dir).mkdir(parents=True, exist_ok=True)
    
    def snapshot_download(
        self,
        model_id: str,
        repo_type: str = "model",
        local_dir: Optional[str] = None,
        cache_dir: Optional[str] = None,
        revision: str = "latest",
        allow_patterns: Optional[Union[str, List[str]]] = None,
        ignore_patterns: Optional[Union[str, List[str]]] = None,
        show_progress: bool = True,
        max_workers: Optional[int] = None,
    ) -> str:
        """
        下载模型或数据集的完整快照
        
        Args:
            model_id: 模型/数据集ID，格式如 "org/name"
            repo_type: 仓库类型，"model" 或 "dataset"
            local_dir: 本地保存目录（优先级高于cache_dir）
            cache_dir: 缓存目录
            revision: 版本标签
            allow_patterns: 允许下载的文件模式，如 "*.bin" 或 ["*.bin", "*.json"]
            ignore_patterns: 忽略的文件模式
            show_progress: 是否显示进度条
            max_workers: 并发下载线程数
            
        Returns:
            str: 下载后的本地目录路径
            
        Raises:
            ModelNotFoundError: 模型不存在
            DownloadError: 下载失败
            
        Example:
            >>> downloader = PlatformDownloader()
            >>> model_dir = downloader.snapshot_download(
            ...     "company/llm-model",
            ...     local_dir="./models/llm"
            ... )
        """
        # 规范化参数
        if isinstance(allow_patterns, str):
            allow_patterns = [allow_patterns]
        if isinstance(ignore_patterns, str):
            ignore_patterns = [ignore_patterns]
        
        # 确定目标目录
        if local_dir:
            target_dir = Path(local_dir).expanduser().resolve()
        elif cache_dir:
            target_dir = Path(cache_dir).expanduser().resolve() / model_id.replace("/", "--")
        else:
            target_dir = Path(self.config.cache_dir) / model_id.replace("/", "--")
        
        target_dir.mkdir(parents=True, exist_ok=True)
        
        # 获取S3前缀
        if repo_type == "model":
            prefix = self.path_mapper.model_id_to_s3_path(model_id, self.config.models_prefix)
        elif repo_type == "dataset":
            prefix = self.path_mapper.dataset_id_to_s3_path(dataset_id=model_id, prefix=self.config.datasets_prefix)
        else:
            raise ValueError(f"Invalid repo_type: {repo_type}, must be 'model' or 'dataset'")
        
        # 添加版本
        if revision and revision != "latest":
            prefix = f"{prefix.rstrip('/')}/{revision}/"
        
        logger.info(f"开始下载 {repo_type}: {model_id}")
        logger.info(f"S3前缀: {prefix}")
        logger.info(f"目标目录: {target_dir}")
        
        # 列出所有对象
        objects = self.s3_client.list_objects(prefix)
        
        if not objects:
            if repo_type == "model":
                raise ModelNotFoundError(f"Model not found: {model_id}")
            else:
                raise DatasetNotFoundError(f"Dataset not found: {model_id}")
        
        # 过滤文件
        files_to_download = self._filter_files(
            objects, prefix, allow_patterns, ignore_patterns
        )
        
        if not files_to_download:
            logger.warning("没有匹配的文件需要下载")
            return str(target_dir)
        
        logger.info(f"共有 {len(files_to_download)} 个文件需要下载")
        
        # 下载文件
        max_workers = max_workers or self.config.max_workers
        self._download_files_concurrent(
            files_to_download, prefix, target_dir, show_progress, max_workers
        )
        
        logger.info(f"{repo_type} 下载完成: {target_dir}")
        return str(target_dir)
    
    def model_file_download(
        self,
        model_id: str,
        file_path: str,
        repo_type: str = "model",
        local_dir: Optional[str] = None,
        cache_dir: Optional[str] = None,
        revision: str = "latest",
        show_progress: bool = True,
    ) -> str:
        """
        下载模型/数据集中的单个文件
        
        Args:
            model_id: 模型/数据集ID
            file_path: 文件在仓库中的相对路径
            repo_type: 仓库类型
            local_dir: 本地保存目录
            cache_dir: 缓存目录
            revision: 版本标签
            show_progress: 是否显示进度
            
        Returns:
            str: 下载后的文件路径
            
        Example:
            >>> file_path = downloader.model_file_download(
            ...     "company/llm-model",
            ...     "config.json",
            ...     local_dir="./models/llm"
            ... )
        """
        # 确定目标路径
        if local_dir:
            target_path = Path(local_dir).expanduser().resolve() / file_path
        elif cache_dir:
            target_path = Path(cache_dir).expanduser().resolve() / model_id.replace("/", "--") / file_path
        else:
            target_path = Path(self.config.cache_dir) / model_id.replace("/", "--") / file_path
        
        target_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 获取S3键
        if repo_type == "model":
            prefix = self.path_mapper.model_id_to_s3_path(model_id, self.config.models_prefix)
        else:
            prefix = self.path_mapper.dataset_id_to_s3_path(model_id, self.config.datasets_prefix)
        
        if revision and revision != "latest":
            s3_key = f"{prefix.rstrip('/')}/{revision}/{file_path}"
        else:
            s3_key = f"{prefix}{file_path}"
        
        logger.info(f"下载文件: {s3_key}")
        
        # 检查文件是否存在
        if not self.s3_client.object_exists(s3_key):
            raise ModelNotFoundError(f"File not found: {file_path} in {model_id}")
        
        # 获取文件大小
        file_size = self.s3_client.get_object_size(s3_key)
        
        # 下载文件
        if show_progress:
            tracker = ProgressTracker(file_size, desc=file_path)
            try:
                self.s3_client.download_file(
                    s3_key, str(target_path),
                    progress_callback=lambda n: tracker.update(n)
                )
            finally:
                tracker.close()
        else:
            self.s3_client.download_file(s3_key, str(target_path))
        
        logger.info(f"文件下载完成: {target_path}")
        return str(target_path)
    
    def snapshot_upload(
        self,
        model_id: str,
        local_dir: str,
        repo_type: str = "model",
        revision: str = "latest",
        allow_patterns: Optional[Union[str, List[str]]] = None,
        ignore_patterns: Optional[Union[str, List[str]]] = None,
        show_progress: bool = True,
        max_workers: Optional[int] = None,
    ) -> str:
        """
        上传模型或数据集的完整快照
        
        Args:
            model_id: 模型/数据集ID，格式如 "org/name"
            local_dir: 本地目录路径
            repo_type: 仓库类型，"model" 或 "dataset"
            revision: 版本标签
            allow_patterns: 允许上传的文件模式
            ignore_patterns: 忽略的文件模式
            show_progress: 是否显示进度条
            max_workers: 并发上传线程数
            
        Returns:
            str: 上传的S3路径前缀
            
        Example:
            >>> downloader = PlatformDownloader()
            >>> s3_path = downloader.snapshot_upload(
            ...     model_id="company/llm-model",
            ...     local_dir="./models/llm-model"
            ... )
        """
        # 规范化参数
        if isinstance(allow_patterns, str):
            allow_patterns = [allow_patterns]
        if isinstance(ignore_patterns, str):
            ignore_patterns = [ignore_patterns]
        
        # 确定本地目录
        local_path = Path(local_dir).expanduser().resolve()
        if not local_path.exists():
            raise ValueError(f"Local directory does not exist: {local_dir}")
        
        # 获取S3前缀
        if repo_type == "model":
            prefix = self.path_mapper.model_id_to_s3_path(model_id, self.config.models_prefix)
        elif repo_type == "dataset":
            prefix = self.path_mapper.dataset_id_to_s3_path(model_id, self.config.datasets_prefix)
        else:
            raise ValueError(f"Invalid repo_type: {repo_type}, must be 'model' or 'dataset'")
        
        # 添加版本
        if revision and revision != "latest":
            prefix = f"{prefix.rstrip('/')}/{revision}/"
        
        logger.info(f"开始上传 {repo_type}: {model_id}")
        logger.info(f"本地目录: {local_path}")
        logger.info(f"S3前缀: {prefix}")
        
        # 收集要上传的文件
        files_to_upload = self._collect_local_files(
            local_path, allow_patterns, ignore_patterns
        )
        
        if not files_to_upload:
            logger.warning("没有匹配的文件需要上传")
            return prefix
        
        logger.info(f"共有 {len(files_to_upload)} 个文件需要上传")
        
        # 上传文件
        max_workers = max_workers or self.config.max_workers
        self._upload_files_concurrent(
            files_to_upload, local_path, prefix, show_progress, max_workers
        )
        
        logger.info(f"{repo_type} 上传完成: {prefix}")
        return prefix
    
    def model_file_upload(
        self,
        model_id: str,
        file_path: str,
        local_path: str,
        repo_type: str = "model",
        revision: str = "latest",
        show_progress: bool = True,
    ) -> str:
        """
        上传模型/数据集中的单个文件
        
        Args:
            model_id: 模型/数据集ID
            file_path: 文件在仓库中的相对路径
            local_path: 本地文件路径
            repo_type: 仓库类型
            revision: 版本标签
            show_progress: 是否显示进度
            
        Returns:
            str: 上传后的S3键
            
        Example:
            >>> s3_key = downloader.model_file_upload(
            ...     model_id="company/llm-model",
            ...     file_path="config.json",
            ...     local_path="./local/config.json"
            ... )
        """
        local_file = Path(local_path).expanduser().resolve()
        if not local_file.exists():
            raise ValueError(f"Local file does not exist: {local_path}")
        
        # 获取S3键
        if repo_type == "model":
            prefix = self.path_mapper.model_id_to_s3_path(model_id, self.config.models_prefix)
        else:
            prefix = self.path_mapper.dataset_id_to_s3_path(model_id, self.config.datasets_prefix)
        
        if revision and revision != "latest":
            s3_key = f"{prefix.rstrip('/')}/{revision}/{file_path}"
        else:
            s3_key = f"{prefix}{file_path}"
        
        logger.info(f"上传文件: {local_file} -> {s3_key}")
        
        # 上传文件
        file_size = local_file.stat().st_size
        if show_progress:
            tracker = ProgressTracker(file_size, desc=file_path)
            try:
                self.s3_client.upload_file(
                    str(local_file), s3_key,
                    progress_callback=lambda n: tracker.update(n)
                )
            finally:
                tracker.close()
        else:
            self.s3_client.upload_file(str(local_file), s3_key)
        
        logger.info(f"文件上传完成: {s3_key}")
        return s3_key
    
    def _collect_local_files(
        self,
        local_dir: Path,
        allow_patterns: Optional[List[str]],
        ignore_patterns: Optional[List[str]]
    ) -> List[Path]:
        """收集本地目录中要上传的文件"""
        import fnmatch
        
        files = []
        for file_path in local_dir.rglob("*"):
            if not file_path.is_file():
                continue
            
            # 获取相对路径
            rel_path = file_path.relative_to(local_dir).as_posix()
            
            # 检查允许模式
            if allow_patterns:
                if not any(fnmatch.fnmatch(rel_path, p) or fnmatch.fnmatch(file_path.name, p) 
                          for p in allow_patterns):
                    continue
            
            # 检查忽略模式
            if ignore_patterns:
                if any(fnmatch.fnmatch(rel_path, p) or fnmatch.fnmatch(file_path.name, p)
                      for p in ignore_patterns):
                    continue
            
            files.append(file_path)
        
        return sorted(files)
    
    def _upload_files_concurrent(
        self,
        files: List[Path],
        local_dir: Path,
        prefix: str,
        show_progress: bool,
        max_workers: int
    ):
        """并发上传多个文件"""
        
        def upload_single(local_file: Path) -> Tuple[str, bool]:
            rel_path = local_file.relative_to(local_dir).as_posix()
            s3_key = f"{prefix}{rel_path}"
            
            try:
                self.s3_client.upload_file(str(local_file), s3_key)
                return rel_path, True
            except Exception as e:
                logger.error(f"上传失败 {rel_path}: {e}")
                return rel_path, False
        
        if max_workers == 1:
            # 单线程上传
            for local_file in files:
                upload_single(local_file)
        else:
            # 多线程上传
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(upload_single, f): f for f in files}
                
                if show_progress and TQDM_AVAILABLE:
                    with tqdm(total=len(files), desc="Uploading") as pbar:
                        for future in as_completed(futures):
                            pbar.update(1)
                else:
                    for future in as_completed(futures):
                        future.result()
    
    def list_models(self, org: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        列出可用的模型
        
        Args:
            org: 组织名称过滤
            
        Returns:
            模型列表
        """
        prefix = f"{self.config.models_prefix}/"
        if org:
            prefix = f"{prefix}{org}/"
        
        objects = self.s3_client.list_objects(prefix)
        
        # 提取模型ID
        models = set()
        for obj in objects:
            key = obj['Key']
            # 解析 models/org/name/... 格式
            parts = key[len(f"{self.config.models_prefix}/"):].split("/")
            if len(parts) >= 2:
                model_id = f"{parts[0]}/{parts[1]}"
                models.add(model_id)
        
        return [{"model_id": m} for m in sorted(models)]
    
    def list_datasets(self, org: Optional[str] = None) -> List[Dict[str, Any]]:
        """列出可用的数据集"""
        prefix = f"{self.config.datasets_prefix}/"
        if org:
            prefix = f"{prefix}{org}/"
        
        objects = self.s3_client.list_objects(prefix)
        
        datasets = set()
        for obj in objects:
            key = obj['Key']
            parts = key[len(f"{self.config.datasets_prefix}/"):].split("/")
            if len(parts) >= 2:
                dataset_id = f"{parts[0]}/{parts[1]}"
                datasets.add(dataset_id)
        
        return [{"dataset_id": d} for d in sorted(datasets)]
    
    def get_model_info(self, model_id: str) -> Dict[str, Any]:
        """
        获取模型信息
        
        尝试从S3读取 model_info.json 或 README.md
        """
        prefix = self.path_mapper.model_id_to_s3_path(model_id, self.config.models_prefix)
        
        info = {
            "model_id": model_id,
            "s3_prefix": prefix,
            "files": []
        }
        
        # 列出所有文件
        objects = self.s3_client.list_objects(prefix)
        for obj in objects:
            info["files"].append({
                "key": obj['Key'],
                "size": obj['Size'],
                "last_modified": obj['LastModified'].isoformat()
            })
        
        # 尝试读取模型信息文件
        info_key = f"{prefix}model_info.json"
        try:
            with tempfile.NamedTemporaryFile(mode='w+', delete=False) as tmp:
                self.s3_client.download_file(info_key, tmp.name)
                with open(tmp.name, 'r') as f:
                    model_meta = json.load(f)
                info.update(model_meta)
                os.unlink(tmp.name)
        except:
            pass
        
        return info
    
    def _filter_files(
        self,
        objects: List[Dict[str, Any]],
        prefix: str,
        allow_patterns: Optional[List[str]],
        ignore_patterns: Optional[List[str]]
    ) -> List[Dict[str, Any]]:
        """根据模式过滤文件"""
        import fnmatch
        
        files = []
        for obj in objects:
            key = obj['Key']
            # 跳过目录
            if key.endswith('/'):
                continue
            
            # 获取相对路径
            rel_path = key[len(prefix):]
            
            # 检查允许模式
            if allow_patterns:
                if not any(fnmatch.fnmatch(rel_path, p) for p in allow_patterns):
                    continue
            
            # 检查忽略模式
            if ignore_patterns:
                if any(fnmatch.fnmatch(rel_path, p) for p in ignore_patterns):
                    continue
            
            files.append(obj)
        
        return files
    
    def _download_files_concurrent(
        self,
        files: List[Dict[str, Any]],
        prefix: str,
        target_dir: Path,
        show_progress: bool,
        max_workers: int
    ):
        """并发下载多个文件"""
        
        def download_single(file_obj: Dict[str, Any]) -> Tuple[str, bool]:
            key = file_obj['Key']
            rel_path = key[len(prefix):]
            local_path = target_dir / rel_path
            local_path.parent.mkdir(parents=True, exist_ok=True)
            
            try:
                self.s3_client.download_file(key, str(local_path))
                return rel_path, True
            except Exception as e:
                logger.error(f"下载失败 {rel_path}: {e}")
                return rel_path, False
        
        if max_workers == 1:
            # 单线程下载
            for file_obj in files:
                download_single(file_obj)
        else:
            # 多线程下载
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(download_single, f): f for f in files}
                
                if show_progress and TQDM_AVAILABLE:
                    with tqdm(total=len(files), desc="Files") as pbar:
                        for future in as_completed(futures):
                            pbar.update(1)
                else:
                    for future in as_completed(futures):
                        future.result()


# ==================== 便捷函数 ====================

def snapshot_download(
    model_id: str,
    repo_type: str = "model",
    local_dir: Optional[str] = None,
    **kwargs
) -> str:
    """
    便捷的模型/数据集下载函数
    
    类似 ModelScope 的 snapshot_download API
    
    Example:
        >>> from platform_downloader import snapshot_download
        >>> model_dir = snapshot_download("org/model", local_dir="./models")
    """
    downloader = PlatformDownloader()
    return downloader.snapshot_download(model_id, repo_type, local_dir, **kwargs)


def model_file_download(
    model_id: str,
    file_path: str,
    local_dir: Optional[str] = None,
    **kwargs
) -> str:
    """便捷的单文件下载函数"""
    downloader = PlatformDownloader()
    return downloader.model_file_download(model_id, file_path, "model", local_dir, **kwargs)


def dataset_file_download(
    dataset_id: str,
    file_path: str,
    local_dir: Optional[str] = None,
    **kwargs
) -> str:
    """便捷的数据集文件下载函数"""
    downloader = PlatformDownloader()
    return downloader.model_file_download(dataset_id, file_path, "dataset", local_dir, **kwargs)


# ==================== 上传便捷函数 ====================

def snapshot_upload(
    model_id: str,
    local_dir: str,
    repo_type: str = "model",
    **kwargs
) -> str:
    """
    便捷的模型/数据集上传函数
    
    Example:
        >>> from platform_downloader import snapshot_upload
        >>> s3_path = snapshot_upload("org/model", local_dir="./models")
    """
    downloader = PlatformDownloader()
    return downloader.snapshot_upload(model_id, local_dir, repo_type, **kwargs)


def model_file_upload(
    model_id: str,
    file_path: str,
    local_path: str,
    **kwargs
) -> str:
    """便捷的单文件上传函数（模型）"""
    downloader = PlatformDownloader()
    return downloader.model_file_upload(model_id, file_path, local_path, "model", **kwargs)


def dataset_file_upload(
    dataset_id: str,
    file_path: str,
    local_path: str,
    **kwargs
) -> str:
    """便捷的单文件上传函数（数据集）"""
    downloader = PlatformDownloader()
    return downloader.model_file_upload(dataset_id, file_path, local_path, "dataset", **kwargs)


# ==================== 主函数 ====================

def main():
    """示例用法"""
    
    # 初始化下载器
    downloader = PlatformDownloader()
    
    # 示例1: 下载模型
    try:
        model_dir = downloader.snapshot_download(
            model_id="demo/llm-model",
            local_dir="./downloads/models/llm-model",
            show_progress=True
        )
        print(f"模型下载完成: {model_dir}")
    except ModelNotFoundError:
        print("模型不存在，请检查ID是否正确")
    except Exception as e:
        print(f"下载失败: {e}")
    
    # 示例2: 下载数据集
    try:
        dataset_dir = downloader.snapshot_download(
            model_id="demo/training-data",
            repo_type="dataset",
            local_dir="./downloads/datasets/training-data"
        )
        print(f"数据集下载完成: {dataset_dir}")
    except Exception as e:
        print(f"下载失败: {e}")
    
    # 示例3: 下载特定文件
    try:
        file_path = downloader.model_file_download(
            model_id="demo/llm-model",
            file_path="config.json",
            local_dir="./downloads/models/llm-model"
        )
        print(f"文件下载完成: {file_path}")
    except Exception as e:
        print(f"下载失败: {e}")
    
    # 示例4: 列出可用模型
    models = downloader.list_models()
    print(f"可用模型: {models}")
    
    # 示例5: 带过滤条件的下载
    try:
        model_dir = downloader.snapshot_download(
            model_id="demo/llm-model",
            local_dir="./downloads/models/filtered",
            allow_patterns=["*.bin", "*.json"],  # 只下载bin和json文件
            ignore_patterns=["*.md", "*.txt"]    # 忽略文档文件
        )
        print(f"过滤下载完成: {model_dir}")
    except Exception as e:
        print(f"下载失败: {e}")


if __name__ == "__main__":
    main()
