#!/usr/bin/env python3
"""
Platform Downloader - 平台模型和数据集下载 SDK
"""

from setuptools import setup, find_packages
import os

# 读取 README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# 读取 requirements
with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    # 包名称（pip install 时使用的名字）
    name="sandlake-storage-sdk",
    
    # 版本号
    version="1.0.1",
    
    # 作者信息
    author="Your Name",
    author_email="your.email@example.com",
    
    # 包描述
    description="Sandlake Storage SDK - 基于 S3 存储后端的模型和数据集下载/上传 SDK，提供类似 ModelScope 风格的 API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    # 项目主页
    url="https://github.com/yourusername/sandlake-storage-sdk",
    
    # 包的内容 - 找到所有包
    packages=find_packages(),
    
    # 包含额外的文件
    include_package_data=True,
    
    # 依赖项
    install_requires=requirements,
    
    # Python 版本要求
    python_requires=">=3.7",
    
    # 分类信息
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    
    # 关键词
    keywords="s3, sandlake, storage, model, dataset, download, upload, snapshot, platform, downloader, modelscope",
    
    # 入口点 - 命令行工具
    entry_points={
        "console_scripts": [
            "platform-dl=platform_downloader.cli:main",
        ],
    },
)
