# RunIt SDK

Python SDK for building apps on RunIt.

## Installation

The SDK is automatically available in the RunIt runtime. For local development:

```bash
pip install -e .
```

Or install from PyPI:

```bash
pip install runit-sdk
```

## Quick Start

```python
from runit import app, remember

@app.action
def greet(name: str) -> dict:
    visits = (remember("visits") or 0) + 1
    remember("visits", visits)
    return {"message": f"Hello, {name}! Visit #{visits}"}
```

Paste this into RunIt, hit "Go Live," and share the link.

## Features

- **`@app.action`** - Mark functions as runnable actions with auto-generated UI
- **`remember()` / `forget()`** - Built-in key-value storage across runs
- **`storage`** - Full storage API (`get`, `set`, `delete`, `list`)
- **`save_artifact()`** - Write outputs that users can download
- **`save_dataframe()`** - Save pandas/polars DataFrames in multiple formats
- **`context`** - Access secrets and uploaded JSON data
- **Zero Dependencies** - Core functionality has no required dependencies

## Documentation

See the [SDK Guide](../../../docs/SDK_GUIDE.md) for complete documentation and examples.

## Sample Apps

Check out the sample apps in `../samples/`:

- `hello-world` - Minimal greeting action
- `extract-company` - URL scraping with artifacts
- `image-analysis` - File upload and image processing
- `bulk-processor` - Batch processing with error handling
- `opendraft` - Multi-action app example

## Development

```bash
# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run tests with coverage
pytest --cov=runit --cov-report=html
```

## License

MIT
