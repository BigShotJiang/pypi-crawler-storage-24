"""
Однофайловый bootstrap для инициализации проекта из шаблона.

Важно: этот скрипт выполняет init самостоятельно и использует `git clone`.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

TEMPLATE_REPO_URL = "https://gitlab.8525.ru/devtools/bsp-template.git"
TEMPLATE_REF = "main"
SKIP_DIRS: set[str] = {".git", ".ruff_cache"}


def _poetry_cmd() -> list[str]:
    if shutil.which("poetry") is not None:
        return ["poetry"]
    return [sys.executable, "-m", "poetry"]


def _clone_template() -> Path:
    tmp_dir = Path(tempfile.mkdtemp(prefix="tp-bootstrap-template-")).resolve()
    cmd = [
        "git",
        "clone",
        "--depth",
        "1",
        "--branch",
        TEMPLATE_REF,
        TEMPLATE_REPO_URL,
        str(tmp_dir),
    ]
    print(f"[tp-bootstrap] Команда clone: {' '.join(cmd)}")
    subprocess.check_call(cmd)
    return tmp_dir


def _copy_only_pyproject(template_root: Path, project_root: Path) -> None:
    src = template_root / "pyproject.toml"
    if not src.is_file():
        raise RuntimeError("В шаблоне не найден pyproject.toml")
    dest = project_root / "pyproject.toml"
    shutil.copy2(src, dest)
    print("[tp-bootstrap] Запись pyproject.toml")


def _ensure_project_name(pyproject_path: Path, name: str) -> None:
    if not pyproject_path.is_file():
        return
    lines = pyproject_path.read_text(encoding="utf-8").splitlines()
    for header in ("[tool.poetry]", "[project]"):
        in_section = False
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped == header:
                in_section = True
                continue
            if (
                in_section
                and stripped.startswith("[")
                and not stripped.startswith("#[")
            ):
                break
            if in_section and stripped.startswith("name"):
                indent = line[: len(line) - len(line.lstrip())]
                lines[i] = f'{indent}name = "{name}"'
                break
    pyproject_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _install_precommit_hooks(poetry: list[str], project_root: Path) -> None:
    check = subprocess.run(
        [*poetry, "run", "python", "-c", "import pre_commit"],
        cwd=project_root,
        capture_output=True,
        text=True,
        check=False,
    )
    if check.returncode != 0:
        print(
            "[tp-bootstrap] Предупреждение: pre-commit не установлен в зависимостях проекта. "
            "Шаг установки хуков пропущен."
        )
        print(
            "[tp-bootstrap] Добавьте pre-commit в dev-зависимости и выполните: "
            "poetry run pre-commit install"
        )
        return

    install = subprocess.run(
        [*poetry, "run", "pre-commit", "install"],
        cwd=project_root,
        capture_output=True,
        text=True,
        check=False,
    )
    if install.returncode != 0:
        err = (install.stderr or install.stdout or "").strip()
        if err:
            print(
                f"[tp-bootstrap] Предупреждение: pre-commit install не выполнен: {err}"
            )
        else:
            print("[tp-bootstrap] Предупреждение: pre-commit install не выполнен.")


def _init_project(project_root: Path) -> None:
    if project_root.exists() and not project_root.is_dir():
        raise NotADirectoryError(f"Не директория: {project_root}")
    if not project_root.exists():
        print(f"[tp-bootstrap] Шаг 1/6: создание директории {project_root}")
        project_root.mkdir(parents=True)
    else:
        print(f"[tp-bootstrap] Шаг 1/6: директория уже существует: {project_root}")

    print("[tp-bootstrap] Шаг 2/6: git clone шаблона и копирование pyproject.toml")
    template_root = _clone_template()
    try:
        _copy_only_pyproject(template_root, project_root)
    finally:
        shutil.rmtree(template_root, ignore_errors=True)

    pyproject = project_root / "pyproject.toml"
    if not pyproject.is_file():
        raise RuntimeError("После скачивания шаблона не найден pyproject.toml")
    _ensure_project_name(pyproject, project_root.name)

    print("[tp-bootstrap] Шаг 3/6: настройка poetry venv в проекте")
    poetry = _poetry_cmd()
    subprocess.check_call(
        [*poetry, "cache", "clear", "pypi", "--all", "--no-interaction"],
        cwd=project_root,
    )
    if not (project_root / ".venv").is_dir():
        subprocess.check_call(
            [*poetry, "config", "virtualenvs.in-project", "true", "--local"],
            cwd=project_root,
        )

    print("[tp-bootstrap] Шаг 4/6: poetry lock/install")
    subprocess.check_call([*poetry, "lock", "--no-interaction"], cwd=project_root)
    subprocess.check_call([*poetry, "install", "--no-interaction"], cwd=project_root)

    print("[tp-bootstrap] Шаг 5/6: tp-bootstrap update -f")
    subprocess.check_call(
        [*poetry, "run", "tp-bootstrap", "update", "-f"], cwd=project_root
    )
    subprocess.check_call([*poetry, "lock", "--no-interaction"], cwd=project_root)
    subprocess.check_call([*poetry, "install", "--no-interaction"], cwd=project_root)

    print("[tp-bootstrap] Шаг 6/6: git init и pre-commit install")
    if not (project_root / ".git").exists():
        subprocess.check_call(["git", "init"], cwd=project_root)
    _install_precommit_hooks(poetry, project_root)
    print(f"[tp-bootstrap] Готово. Проект: {project_root}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Bootstrap init проекта из шаблона.")
    subparsers = parser.add_subparsers(dest="command")
    init_parser = subparsers.add_parser("init", help="Инициализировать проект")
    init_parser.add_argument("project_name", nargs="?", default=".")
    args = parser.parse_args(sys.argv[1:] or ["init"])
    if args.command != "init":
        parser.error(
            "Поддерживается только init. Для обновления используйте tp-bootstrap update."
        )
    project_root = (Path(".").resolve() / args.project_name.strip()).resolve()
    _init_project(project_root)


if __name__ == "__main__":
    main()
