# project_scaffold (tp-bootstrap update)

Файлы сервиса берутся из репозитория шаблона [devtools/bsp-template](https://gitlab.8525.ru/devtools/bsp-template) через `git clone` (ветка `main`).

Требования: Python 3.12+, Poetry.

## Порядок работы

### 1) Инициализация проекта через curl (`init`)

Первый запуск всегда через `init`: создаётся папка проекта, клонируется шаблон и копируется **только** `pyproject.toml`, затем `poetry lock/install`, после чего `tp-bootstrap update -f` подтягивает остальные файлы/конфиги и снова выполняет `poetry lock/install`, затем `git init`, `pre-commit install` (если `pre-commit` есть в dev-зависимостях).

**Linux / macOS**

```bash
curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/curl_bootstrap.py" | python3 - init ИМЯ_ПРОЕКТА
```

**Windows (cmd.exe)**

```cmd
curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/curl_bootstrap.py" | python - init ИМЯ_ПРОЕКТА
```

Требуется `curl`, `python`, `git`, `poetry` в PATH.

### 2) Обновление проекта (`update` через tp-common)

После инициализации, когда нужно подтянуть изменения шаблона — используйте `tp-bootstrap update`.

**Linux / macOS**

```bash
poetry run tp-bootstrap update
poetry run tp-bootstrap update -f
```

**Windows (PowerShell)**

```powershell
poetry run tp-bootstrap update
poetry run tp-bootstrap update -f
```

`-f` — принудительная перезапись конфигов из шаблона.

## Примечание

`tp-bootstrap` больше не делает init — только update.
