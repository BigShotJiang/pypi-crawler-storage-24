"""Инициализация git при необходимости."""

from __future__ import annotations

import subprocess
from pathlib import Path


def ensure_git_repo(target_root: Path) -> None:
    """git init, если репозитория ещё нет (для pre-commit install)."""
    if (target_root / ".git").is_dir():
        return
    try:
        subprocess.run(
            ["git", "init"],
            cwd=target_root,
            shell=False,
            check=False,
        )
        print("[tp-bootstrap] Инициализация git-репозитория.")
    except FileNotFoundError:
        pass
