"""Загрузка списка файлов шаблона и содержимого по HTTP (GitLab raw / API)."""

from __future__ import annotations

import json
from urllib.error import URLError
from urllib.parse import quote, urlencode
from urllib.request import urlopen

from .constants import (
    BASE_URL,
    TEMPLATE_REL,
    TEMPLATE_RENAME,
    TEMPLATE_SKIP,
    TEMPLATE_SKIP_PREFIXES,
)


def _template_subdir() -> str:
    return TEMPLATE_REL.strip().strip("/")


def _raw_url_under_template(relative_path: str) -> str:
    """Путь к raw-файлу: BASE_URL + [подкаталог шаблона/] + relative_path."""
    base = BASE_URL.rstrip("/")
    sub = _template_subdir()
    rel = relative_path.lstrip("/")
    if sub:
        return f"{base}/{sub}/{rel}"
    return f"{base}/{rel}"


def _gitlab_tree_from_base_url() -> list[tuple[str, str]]:
    """Список файлов шаблона через GitLab API. [(src_rel, dest_rel), ...]."""
    parts = BASE_URL.rstrip("/").split("/-/raw/")
    if len(parts) != 2:
        raise ValueError(f"Не удалось разобрать BASE_URL: {BASE_URL!r}")
    base_and_project = parts[0]
    ref = parts[1].strip("/") or "main"
    after_scheme = base_and_project.find("://") + 3
    rest = base_and_project[after_scheme:]
    idx = rest.find("/")
    if idx == -1:
        raise ValueError(f"В BASE_URL нет пути проекта: {BASE_URL!r}")
    host = base_and_project[: after_scheme + idx]
    project_path = rest[idx + 1 :].lstrip("/")
    if not project_path:
        raise ValueError(f"Не удалось извлечь путь проекта из BASE_URL: {BASE_URL!r}")
    project_id_encoded = quote(project_path, safe="")

    sub = _template_subdir()
    prefix = f"{sub}/" if sub else ""

    page = 1
    items: list[dict] = []
    while True:
        qs: dict[str, str] = {
            "ref": ref,
            "recursive": "true",
            "per_page": "100",
            "page": str(page),
        }
        if sub:
            qs["path"] = sub
        api_url = (
            f"{host}/api/v4/projects/{project_id_encoded}/repository/tree?"
            + urlencode(qs)
        )
        with urlopen(api_url) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if not data:
            break
        items.extend(data)
        if len(data) < 100:
            break
        page += 1

    result: list[tuple[str, str]] = []
    for item in items:
        if item.get("type") != "blob":
            continue
        path = item.get("path") or ""
        if prefix and not path.startswith(prefix):
            continue
        src_rel = path[len(prefix) :] if prefix else path
        if not src_rel or src_rel in TEMPLATE_SKIP:
            continue
        if any(src_rel.startswith(p) for p in TEMPLATE_SKIP_PREFIXES):
            continue
        dest_rel = TEMPLATE_RENAME.get(src_rel, src_rel)
        result.append((src_rel, dest_rel if dest_rel is not None else src_rel))
    return sorted(result, key=lambda x: x[1])


def collect_template_files() -> list[tuple[str, str]]:
    """Пары (источник в шаблоне, назначение в проекте). Через GitLab API."""
    return _gitlab_tree_from_base_url()


def http_get(relative_path: str) -> str:
    """Скачивает файл из дерева шаблона (относительно TEMPLATE_REL)."""
    url = _raw_url_under_template(relative_path)
    try:
        with urlopen(url) as resp:
            return resp.read().decode("utf-8")
    except URLError as exc:
        raise RuntimeError(f"Не удалось скачать {relative_path!r}: {exc}") from exc


def http_get_root(relative_path: str) -> str:
    """Скачивает файл из корня репозитория (без TEMPLATE_REL), например pyproject.toml."""
    base = BASE_URL.rstrip("/")
    rel = relative_path.lstrip("/")
    url = f"{base}/{rel}"
    try:
        with urlopen(url) as resp:
            return resp.read().decode("utf-8")
    except URLError as exc:
        raise RuntimeError(f"Не удалось скачать {relative_path!r}: {exc}") from exc
