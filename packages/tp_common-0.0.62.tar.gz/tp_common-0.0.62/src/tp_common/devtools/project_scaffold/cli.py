"""Разбор аргументов и точка входа CLI."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .commands import cmd_update


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Обновление конфигурации проекта (tp-bootstrap)."
    )
    subparsers = parser.add_subparsers(dest="command", help="Команда")

    update_parser = subparsers.add_parser(
        "update", help="Подтянуть изменения шаблона в существующий проект"
    )
    update_parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Перезаписать существующие конфиги",
    )

    argv = sys.argv[1:]
    if argv and argv[0] == "-":
        argv = argv[1:]
    if not argv:
        argv = ["update"]
    elif argv[0] not in ("update",) and not argv[0].startswith("-"):
        parser.error("Поддерживается только команда update.")

    args = parser.parse_args(argv)

    if args.command == "update":
        cmd_update(Path("."), args.force)
    else:
        parser.print_help()
        sys.exit(0)
