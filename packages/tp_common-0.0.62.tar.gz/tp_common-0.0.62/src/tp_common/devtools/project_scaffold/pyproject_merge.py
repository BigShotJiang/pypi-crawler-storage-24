"""Merge зависимостей из шаблона в pyproject.toml проекта.

Мерджим только:
- [project].dependencies (список строк)
- [tool.poetry.group.dev.dependencies] (ключи = строки)

Остальное в pyproject.toml проекта не трогаем.
"""

from __future__ import annotations

import re
from pathlib import Path

from .pyproject_sync import find_section, section_range
from .template_sync import read_template_file_text


def _dep_name_from_project_item(line: str) -> str | None:
    s = line.strip().strip(",")
    m = re.match(r'^\s*"([^"]+)"\s*$', s)
    if not m:
        return None
    item = m.group(1).strip()
    if not item:
        return None
    # "pkg (>=1,<2)" / "pkg==1.2.3" -> "pkg"
    for sep in (" ", "(", "=", "<", ">", "!", "~", "^"):
        idx = item.find(sep)
        if idx > 0:
            return item[:idx].strip().lower().replace("_", "-")
    return item.strip().lower().replace("_", "-")


def _project_dep_lines_from_text(src_text: str) -> list[str]:
    lines = src_text.splitlines()
    idx = find_section(lines, "[project]")
    if idx is None:
        return []
    start, end = section_range(lines, idx)
    deps_idx = None
    for i in range(start, end):
        if re.match(r"^\s*dependencies\s*=\s*\[", lines[i]):
            deps_idx = i
            break
    if deps_idx is None:
        return []
    # collect until closing bracket
    dep_lines: list[str] = []
    i = deps_idx + 1
    while i < len(lines):
        if "]" in lines[i]:
            break
        dep_lines.append(lines[i])
        i += 1
    return dep_lines


def _dev_dep_map_from_text(src_text: str) -> dict[str, str]:
    lines = src_text.splitlines()
    section = "[tool.poetry.group.dev.dependencies]"
    idx = find_section(lines, section)
    if idx is None:
        return {}
    start, end = section_range(lines, idx)
    result: dict[str, str] = {}
    for line in lines[start:end]:
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        key = s.split("=", 1)[0].strip().lower().replace("_", "-")
        result[key] = line
    return result


def merge_dependencies_from_template(target_root: Path) -> None:
    """Обновляет только зависимости в pyproject.toml проекта по шаблону."""
    pyproject = target_root / "pyproject.toml"
    if not pyproject.is_file():
        return

    template_text = read_template_file_text("pyproject.toml")
    if not template_text:
        return

    template_project_dep_lines = _project_dep_lines_from_text(template_text)
    template_dev_deps = _dev_dep_map_from_text(template_text)

    tgt_lines = pyproject.read_text(encoding="utf-8").splitlines()

    # --- merge [project].dependencies ---
    proj_idx = find_section(tgt_lines, "[project]")
    if proj_idx is not None:
        start, end = section_range(tgt_lines, proj_idx)
        deps_line_idx = None
        for i in range(start, end):
            if re.match(r"^\s*dependencies\s*=\s*\[", tgt_lines[i]):
                deps_line_idx = i
                break
        if deps_line_idx is not None:
            # find closing bracket
            close_idx = deps_line_idx + 1
            while close_idx < len(tgt_lines) and "]" not in tgt_lines[close_idx]:
                close_idx += 1

            existing: dict[str, int] = {}
            for i in range(deps_line_idx + 1, close_idx):
                name = _dep_name_from_project_item(tgt_lines[i])
                if name:
                    existing[name] = i

            # replace/add template deps; keep unknown deps as-is
            template_items: list[tuple[str, str]] = []
            for line in template_project_dep_lines:
                name = _dep_name_from_project_item(line)
                if name:
                    template_items.append((name, line))

            for name, line in template_items:
                if name in existing:
                    tgt_lines[existing[name]] = line
                else:
                    tgt_lines.insert(close_idx, line)
                    close_idx += 1

    # --- merge dev deps section ---
    dev_section = "[tool.poetry.group.dev.dependencies]"
    dev_idx = find_section(tgt_lines, dev_section)
    if dev_idx is None:
        # append section at end
        if tgt_lines and tgt_lines[-1].strip():
            tgt_lines.append("")
        tgt_lines.append(dev_section)
        for _k, line in sorted(template_dev_deps.items()):
            tgt_lines.append(line)
    else:
        start, end = section_range(tgt_lines, dev_idx)
        existing_keys: dict[str, int] = {}
        for i in range(start, end):
            s = tgt_lines[i].strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            k = s.split("=", 1)[0].strip().lower().replace("_", "-")
            existing_keys[k] = i
        for k, line in template_dev_deps.items():
            if k in existing_keys:
                tgt_lines[existing_keys[k]] = line
            else:
                tgt_lines.insert(end, line)
                end += 1

    pyproject.write_text("\n".join(tgt_lines) + "\n", encoding="utf-8")
