# Пример: исключения (ApiException) в FastAPI

Минимальный пример того, как делать API-исключения: наследование от `ApiException` из `tp_common.exceptions`, передача `trace_id` из контекста запроса.

## Что показывает

- **Наследование от ApiException:** свой класс `NotFoundException` с заданными в `__init__` `message` и `status_code` (например, 404).
- **Передача trace_id:** при выбросе исключения передаётся `trace_id=logger.trace_id` из логгера запроса (из `get_request_logger`).
- **Поведение в FastAPI:** как наследник `HTTPException`, исключение обрабатывается FastAPI и отдаёт в ответ статус и JSON (detail); дополнительно в логах и при необходимости в заголовке ответа доступен trace_id (через TpMiddleware).

Использование: один класс исключения на один тип ошибки; в эндпоинте — `raise NotFoundException(message="...", trace_id=logger.trace_id)`.

## Запуск

```bash
uvicorn tp_common.tp_fastapi.examples.exceptions.app:app --reload --port 8000
```

## Проверка

```bash
curl -i http://127.0.0.1:8000/ok
curl -i http://127.0.0.1:8000/fail
curl -i -H "X-Trace-ID: 00000000-0000-0000-0000-000000000999" http://127.0.0.1:8000/fail
```

Эндпоинт `/fail` возвращает 404 и выбрасывает `NotFoundException` с переданным сообщением и trace_id.
