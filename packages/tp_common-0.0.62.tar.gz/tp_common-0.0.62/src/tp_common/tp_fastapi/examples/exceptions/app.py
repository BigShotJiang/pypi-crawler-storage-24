"""
Пример: как делать исключения — наследование от ApiException.

Показывает:
  - свой класс-исключение, наследник ApiException (message и status_code в __init__);
  - передачу trace_id из логгера запроса;
  - FastAPI обрабатывает наследника HTTPException и отдаёт JSON в ответ.

Запуск:
  uvicorn tp_common.tp_fastapi.examples.exceptions.app:app --reload --port 8000

Проверка:
  curl -i http://127.0.0.1:8000/ok
  curl -i http://127.0.0.1:8000/fail
  curl -i -H "X-Trace-ID: 00000000-0000-0000-0000-000000000999" http://127.0.0.1:8000/fail
"""

from __future__ import annotations

import uuid
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from http import HTTPStatus

from fastapi import Depends, FastAPI

from tp_common.exceptions import ApiException
from tp_common.tp_logger.fastapi_integration import (
    TpMiddleware,
    get_request_logger,
)
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory


class NotFoundException(ApiException):
    """Ресурс не найден (404)."""

    def __init__(
        self,
        *,
        message: str = "Not Found",
        trace_id: str | int | uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message=message,
            status_code=HTTPStatus.NOT_FOUND,
            trace_id=trace_id,
        )


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    env = EnvironmentType.DEV
    app.state.log_factory = TpLoggerFactory(env)
    TpLoggerFactory.setup_standard_loggers(env)
    yield


app = FastAPI(title="ApiException example", lifespan=lifespan)
app.add_middleware(TpMiddleware)


@app.get("/ok")
def ok(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    logger.info("Запрос /ok")
    return {"status": "ok", "trace_id": str(logger.trace_id) if logger.trace_id else ""}


@app.get("/fail")
def fail(logger: TpLogger = Depends(get_request_logger)) -> None:
    """Возвращает 404 с trace_id в ответе (как наследник HTTPException)."""
    logger.warning("Запрос /fail — выбрасываем NotFoundException")
    raise NotFoundException(
        message="Ресурс не найден",
        trace_id=logger.trace_id,
    )
