"""
Сервис для отправки и чтения результатов обработки с поддержкой source_system.

Тело сообщения — весь JSON (модель MESSAGE_CLASS без обёртки data). Поддерживает:
- чтение с offset по timestamp;
- таймаут чтения через asyncio.wait_for;
- source_system в __init__ для выбора топика (TOPIC_PREFIX или TOPIC_PREFIX.source_system).
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager, suppress
from typing import Any, ClassVar, Literal, TypeVar, cast

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer  # type: ignore[import-untyped]
from pydantic import ValidationError

from tp_common.decorators.decorator_retry_forever import retry_forever
from tp_common.kafka.app_event.schemas import BaseAppEventMessage
from tp_common.kafka.connector import KafkaConnector
from tp_common.tp_logger.tp_logging import TpLogger

logger = logging.getLogger(__name__)

MessageT = TypeVar("MessageT", bound=BaseAppEventMessage)


def _value_to_dict(value: bytes | str | dict[str, Any]) -> dict[str, Any]:
    """Парсит value из Kafka в словарь. Ожидается JSON-объект (тело сообщения)."""
    if isinstance(value, dict):
        return value
    if isinstance(value, bytes):
        data = json.loads(value.decode("utf-8"))
    elif isinstance(value, str):
        data = json.loads(value)
    else:
        raise TypeError(f"Неподдерживаемый тип value: {type(value).__name__}")
    if not isinstance(data, dict):
        raise ValueError("JSON не является объектом")
    return data


class _AsyncPopMessage[MessageT: BaseAppEventMessage]:
    """Async контекст: при входе — pop(); при успешном выходе — commit()."""

    __slots__ = ("_event", "_timeout", "_message")

    def __init__(
        self,
        event: AppEventService[MessageT],
        timeout: float,
    ) -> None:
        self._event = event
        self._timeout = timeout
        self._message: MessageT | None = None

    async def __aenter__(self) -> MessageT | None:
        self._message = await self._event._pop(timeout=self._timeout)
        return self._message

    async def __aexit__(
        self,
        exc_type: Any,
        exc_val: Any,
        exc_tb: Any,
    ) -> Literal[False]:
        if exc_type is None and self._message is not None:
            await self._event._commit()
        return False


class AppEventService[MessageT: BaseAppEventMessage]:
    """
    Асинхронный сервис для записи и чтения результатов (тело сообщения — JSON модели MESSAGE_CLASS).

    Один сервис пишет в топик (publish), другой читает (pop/subscription).
    Наследник задаёт TOPIC_PREFIX и MESSAGE_CLASS (схема сообщения = весь JSON).
    """

    TOPIC_PREFIX: ClassVar[str]
    MESSAGE_CLASS: ClassVar[type[BaseAppEventMessage]]

    def __init__(
        self,
        connector: KafkaConnector,
        logger: TpLogger,
        *,
        consumer_group: str | None = None,
        source_system: str | None = None,
        schema_alert_interval_seconds: float = 600,
        schema_alert_callback: (
            Callable[[str], None] | Callable[[str], Awaitable[None]] | None
        ) = None,
        skip_on_parse_error: bool = False,
    ) -> None:
        """
        source_system: если задан — топик TOPIC_PREFIX.source_system.
        schema_alert_callback: опциональный callback при несовпадении схем.
        skip_on_parse_error: при True — при ошибке парсинга коммитим и читаем дальше.
        """
        self.connector = connector
        self.consumer_group = consumer_group
        self._source_system = (
            source_system.strip() if isinstance(source_system, str) else None
        ) or None

        self._consumer: AIOKafkaConsumer | None = None
        self._producer: AIOKafkaProducer | None = None
        self._is_auto_commit: bool = False
        self._last_message: Any | None = None

        self._schema_alert_interval_seconds = schema_alert_interval_seconds
        self._schema_alert_callback = schema_alert_callback
        self._skip_on_parse_error = skip_on_parse_error

        self.logger = logger
        self._msg_cls = cast(type[MessageT], self.__class__.MESSAGE_CLASS)

        self.topic_name = self._topic(source_system)

    @property
    def source_system(self) -> str | None:
        return self._source_system

    def _topic(self, source_system: str | None = None) -> str:
        """Имя топика: TOPIC_PREFIX или TOPIC_PREFIX.source_system."""
        ss = source_system if source_system is not None else self._source_system
        if not ss or not str(ss).strip():
            return self.__class__.TOPIC_PREFIX
        return f"{self.__class__.TOPIC_PREFIX}.{ss.strip()}"

    # --- Consumer / подписка ---

    def enable_auto_commit(self) -> None:
        """Включает автоматический commit после каждого прочитанного сообщения."""
        self._is_auto_commit = True

    @retry_forever(
        start_message="Подписка на топик Kafka: {topic_name}",
        error_message="Ошибка при подписке на топик Kafka {topic_name}: {e}",
    )
    async def sub(self) -> None:
        """Подписывается на топик и запускает consumer."""
        consumer = await self._get_consumer()
        consumer.subscribe([self._topic()])
        await consumer.start()

    async def unsub(self) -> None:
        """Отписывается от топика и останавливает consumer."""
        if self._consumer is not None:
            with suppress(Exception):
                await self._consumer.stop()

    async def close(self) -> None:
        """Закрывает consumer и producer, освобождает соединения."""
        self._last_message = None
        if self._consumer is not None:
            with suppress(Exception):
                await self._consumer.stop()
            self._consumer = None
        if self._producer is not None:
            with suppress(Exception):
                await self._producer.stop()
            self._producer = None

    async def __aenter__(self) -> AppEventService[MessageT]:
        """Вход в контекст: возвращает self. При выходе вызывается close()."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> Literal[False]:
        """Выход из контекста: закрывает consumer и producer."""
        await self.close()
        return False

    @asynccontextmanager
    async def subscription(self) -> AsyncGenerator[None]:
        """Async контекст: при входе — подписка, при выходе — отписка и закрытие."""
        await self.sub()
        try:
            yield
        finally:
            await self.unsub()
            await self.close()

    @retry_forever(
        start_message="Коммит последнего сообщения в Kafka, топик {topic_name}",
        error_message="Ошибка при коммите в Kafka, топик {topic_name}: {e}",
    )
    async def _commit(self) -> None:
        """Коммитит последнее прочитанное сообщение в Kafka."""
        if self._last_message and self._consumer:
            await self._consumer.commit()

    @retry_forever(
        start_message="Коммит сообщения в Kafka без стартового лога, топик {topic_name}",
        error_message="Ошибка при коммите в Kafka, топик {topic_name}: {e}",
    )
    async def _commit_silent(self) -> None:
        """Коммитит без лога старта."""
        if self._last_message and self._consumer:
            await self._consumer.commit()

    @retry_forever(
        start_message="Смещение consumer в конец топика {topic_name} (seek_to_end)",
        error_message="Ошибка при смещении в конец топика {topic_name}: {e}",
    )
    async def seek_to_end(self) -> None:
        """
        Переводит offset consumer group на конец топика.
        Вызывать после sub() / внутри subscription().
        """
        consumer = await self._get_consumer()
        for _ in range(50):
            parts = consumer.assignment()
            if parts:
                await consumer.seek_to_end(*parts)
                await consumer.commit()
                self.logger.info(
                    "Смещение выполнено до конца топика (партиций: %s, топик: %s)",
                    len(parts),
                    self._topic(self.source_system),
                )
                return
            await asyncio.sleep(0.1)
        self.logger.warning(
            "Смещение в конец топика не выполнено: партиции ещё не назначены"
        )

    async def _seek_to_timestamp_impl(self, timestamp_ms: int) -> None:
        """
        Один раз переводит чтение на первое сообщение с timestamp >= timestamp_ms.
        При отсутствии партиций после ожидания выбрасывает ValueError.
        """
        consumer = await self._get_consumer()
        for _ in range(50):
            parts = consumer.assignment()
            if not parts:
                await asyncio.sleep(0.1)
                continue

            timestamps = dict.fromkeys(parts, timestamp_ms)
            offset_map = await consumer.offsets_for_times(timestamps)

            for tp in parts:
                ot = offset_map.get(tp)
                if ot is not None:
                    consumer.seek(tp, ot.offset)
                else:
                    await consumer.seek_to_end(tp)

            await consumer.commit()
            self.logger.info(
                "Смещение к timestamp=%s мс выполнено (партиций: %s)",
                timestamp_ms,
                len(parts),
            )
            return

        raise ValueError("Партиции не назначены: смещение по timestamp не выполнено")

    @retry_forever(
        start_message="Смещение чтения к offset по timestamp в топике {topic_name}",
        error_message="Ошибка при смещении по timestamp, топик {topic_name}: {e}",
    )
    async def seek_to_timestamp(self, timestamp_ms: int) -> None:
        """
        Переводит чтение на первое сообщение с timestamp >= timestamp_ms.
        Вызывать после sub() / внутри subscription().
        timestamp_ms: epoch миллисекунды (UTC).
        """
        await self._seek_to_timestamp_impl(timestamp_ms)

    async def wait_for_assignment(self, timeout_sec: float = 15.0) -> bool:
        """
        Ждёт назначения партиций консьюмеру (топик должен существовать).
        Возвращает True, если партиции назначены, False при таймауте.
        Вызывать после sub() / внутри subscription().
        """
        consumer = await self._get_consumer()
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout_sec
        while loop.time() < deadline:
            if consumer.assignment():
                return True
            await asyncio.sleep(0.1)
        return False

    @retry_forever(
        start_message="Отправка сообщения в Kafka в топик {topic_name}",
        error_message="Ошибка доставки в Kafka, топик {topic_name}: {e}",
    )
    async def publish(
        self,
        message: MessageT,
        target_source_system: str | None = None,
    ) -> None:
        """
        Отправляет сообщение в топик (JSON = model_dump сообщения).
        target_source_system: если задан — запись в TOPIC_PREFIX.target_source_system.
        """
        value = message.model_dump_json().encode("utf-8")
        effective_source = (
            target_source_system.strip()
            if isinstance(target_source_system, str)
            else None
        ) or self._source_system
        topic = self._topic(effective_source)
        producer = await self._get_producer()
        try:
            await producer.send_and_wait(topic, value=value)
            self.logger.debug("Сообщение доставлено в Kafka: topic=%s", topic)
        except Exception as e:
            self.logger.error("Ошибка доставки сообщения в Kafka: %s", e)
            raise

    def pop(self, timeout: float = 60) -> _AsyncPopMessage[MessageT]:
        """
        Async контекст: при входе — чтение одного сообщения с таймаутом;
        при успешном выходе — commit().
        """
        return _AsyncPopMessage[MessageT](self, timeout)

    @retry_forever(
        start_message="Чтение сообщения из Kafka из топика {topic_name}",
        error_message="Ошибка при чтении из Kafka, топик {topic_name}: {e}",
    )
    async def _pop(self, timeout: float = 60) -> MessageT | None:
        """Читает одно сообщение из топика (ожидается JSON тела сообщения)."""
        consumer = await self._get_consumer()

        while True:
            try:
                msg = await asyncio.wait_for(
                    consumer.getone(),
                    timeout=timeout,
                )
            except TimeoutError:
                return None
            except Exception as e:
                self.logger.warning("Ошибка Kafka при чтении: %s", e)
                continue

            if msg.value is None:
                self.logger.warning("Получено сообщение с пустым payload (value)")
                continue

            self._last_message = msg

            if self._is_auto_commit:
                await self._commit_silent()

            try:
                raw = _value_to_dict(msg.value)
                parsed = self._msg_cls.model_validate(raw)
            except (ValidationError, TypeError, ValueError, json.JSONDecodeError):
                if self._skip_on_parse_error:
                    self.logger.warning(
                        "Ошибка парсинга сообщения. Пропускаем.",
                        exc_info=True,
                    )
                    await self._commit_silent()
                    continue
                self.logger.critical(
                    "Ошибка парсинга сообщения. Останавливаем обработку.",
                    exc_info=True,
                )
                await self.unsub()
                await self.close()
                await self.run_schema_mismatch_alert_loop()
                return None

            return parsed

    async def read_from_timestamp(
        self,
        timestamp_ms: int,
        *,
        limit: int | None = None,
        _poll_sec: float = 0.5,
    ) -> list[MessageT]:
        """
        Читает сообщения начиная с timestamp_ms (первое с timestamp >= timestamp_ms).
        Возвращает пачку уже доступных сообщений; пауза _poll_sec без нового сообщения — конец пачки.
        limit: максимум сообщений (None — без ограничения).
        Без commit (для пакетного чтения по offset). Seek без retry — при ошибке выбрасывает.
        У каждого сообщения есть timestamp (из схемы); для следующего запроса используй timestamp последнего.
        """
        await self._seek_to_timestamp_impl(timestamp_ms)
        consumer = await self._get_consumer()
        result: list[MessageT] = []

        while True:
            if limit is not None and len(result) >= limit:
                break
            try:
                msg = await asyncio.wait_for(
                    consumer.getone(),
                    timeout=_poll_sec,
                )
            except TimeoutError:
                break

            if msg.value is None:
                continue

            self._last_message = msg
            try:
                raw = _value_to_dict(msg.value)
                parsed = self._msg_cls.model_validate(raw)
            except (ValidationError, TypeError, ValueError, json.JSONDecodeError):
                if self._skip_on_parse_error:
                    self.logger.warning(
                        "Ошибка парсинга сообщения при чтении от timestamp. Пропускаем сообщение.",
                        exc_info=True,
                    )
                    continue
                raise

            result.append(parsed)

        return result

    @retry_forever(
        start_message="Чтение событий из топика {topic_name} от указанного timestamp",
        error_message="Ошибка чтения событий, топик {topic_name}: {e}",
        max_errors=5,
    )
    async def read_from_timestamp_ready(
        self,
        timestamp_ms: int,
        *,
        limit: int | None = None,
        read_timeout_sec: float = 25.0,
        assignment_timeout_sec: float = 15.0,
    ) -> list[MessageT]:
        """
        Ждёт назначения партиций, затем читает сообщения с timestamp_ms.
        Одна точка входа вместо вызова wait_for_assignment + read_from_timestamp.
        При ошибках повторяет вызов (декоратор @retry_forever).
        Возвращает список сообщений (у каждого есть timestamp в схеме).
        """
        if not await self.wait_for_assignment(timeout_sec=assignment_timeout_sec):
            raise TimeoutError("Партиции не назначены в отведённое время")
        return await asyncio.wait_for(
            self.read_from_timestamp(timestamp_ms, limit=limit),
            timeout=read_timeout_sec,
        )

    # --- Парсинг ---

    def message_from_value(self, value: bytes | str | dict[str, Any]) -> MessageT:
        """Парсит value (JSON тела сообщения) в MessageT."""
        raw = _value_to_dict(value)
        return self._msg_cls.model_validate(raw)

    async def handle_schema_mismatch(self, exc: Exception | None = None) -> None:
        """При несовпадении схем — Critical, отписка, alert loop."""
        self.logger.critical(
            "Несовпадение схем. Останавливаем обработку.%s",
            "" if exc is None else f" {exc!s}",
            exc_info=exc is not None,
        )
        await self.unsub()
        await self.close()
        await self.run_schema_mismatch_alert_loop()

    async def run_schema_mismatch_alert_loop(self) -> None:
        """Цикл Critical и schema_alert_callback после остановки из-за схемы."""
        msg = (
            "Схема сообщений не соответствует ожидаемой. "
            "Обработка событий остановлена."
        )
        while True:
            self.logger.critical(msg)
            if self._schema_alert_callback:
                try:
                    if inspect.iscoroutinefunction(self._schema_alert_callback):
                        await self._schema_alert_callback(msg)
                    else:
                        self._schema_alert_callback(msg)
                except Exception as e:
                    self.logger.exception(
                        "Ошибка при вызове callback оповещения: %s", e
                    )
            await asyncio.sleep(self._schema_alert_interval_seconds)

    async def _get_consumer(self) -> AIOKafkaConsumer:
        """Возвращает async consumer; при первом вызове создаёт через connector."""
        if self.connector is None:
            raise ValueError("connector не задан")
        if not self.consumer_group or not str(self.consumer_group).strip():
            raise ValueError("consumer_group должен быть непустой строкой")
        if self._consumer is None:
            self.connector.set_logger(self.logger)
            self._consumer = self.connector.get_async_consumer(
                group_id=self.consumer_group
            )
        return self._consumer

    async def _get_producer(self) -> AIOKafkaProducer:
        """Возвращает async producer; при первом вызове создаёт и запускает через connector."""
        if self._producer is None:
            self.connector.set_logger(self.logger)
            producer = self.connector.get_async_producer()
            await producer.start()
            self._producer = producer
        return self._producer

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "TOPIC_PREFIX") or not isinstance(
            getattr(cls, "TOPIC_PREFIX", None), str
        ):
            raise TypeError(
                f"{cls.__name__} должен определить TOPIC_PREFIX (непустая строка)"
            )
        prefix = cls.TOPIC_PREFIX
        if not prefix or not prefix.strip():
            raise TypeError(
                f"{cls.__name__}.TOPIC_PREFIX не должен быть пустой строкой"
            )
        if not hasattr(cls, "MESSAGE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить MESSAGE_CLASS")
