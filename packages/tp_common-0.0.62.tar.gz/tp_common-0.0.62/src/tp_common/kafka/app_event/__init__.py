"""Сервис app-событий: запись/чтение результатов (сообщения с полем data), source_system."""

from tp_common.kafka.app_event.app_event import AppEventService
from tp_common.kafka.app_event.schemas import BaseAppEventMessage

__all__ = [
    "AppEventService",
    "BaseAppEventMessage",
]
