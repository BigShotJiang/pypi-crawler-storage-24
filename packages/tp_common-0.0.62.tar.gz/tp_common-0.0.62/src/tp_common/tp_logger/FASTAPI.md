# TpLogger в FastAPI

## Подключение

1. **Старт приложения** — фабрика и единый формат логов. Можно вынести в **lifespan** (как в примере `tp_common.tp_fastapi.examples.logger`):
   ```python
   from contextlib import asynccontextmanager
   from collections.abc import AsyncGenerator

   @asynccontextmanager
   async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
       env = EnvironmentType.DEV
       app.state.log_factory = TpLoggerFactory(env)
       TpLoggerFactory.setup_standard_loggers(env)
       yield

   app = FastAPI(lifespan=lifespan)
   ```
   Либо выполнить те же две строки при создании приложения (если lifespan не используется).

2. **Middleware** — `TraceIdMiddleware`: выставляет `trace_id` на запрос (из заголовка или новый), добавляет `X-Trace-ID` в ответ, перехватывает необработанные исключения и логирует их с `trace_id`, возвращает 500.
   ```python
   from tp_common.tp_logger.fastapi_integration import TpMiddleware
   app.add_middleware(TpMiddleware)
   ```

3. **Логгер в эндпоинтах** — через dependency, переменную называйте **`logger`**, тип — **`TpLogger`**:
   ```python
   from fastapi import Depends
   from tp_common.tp_logger.fastapi_integration import get_request_logger
   from tp_common.tp_logger.tp_logging import TpLogger

   @app.get("/")
   def root(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
       logger.info("Запрос")
       return {"trace_id": logger.trace_id or ""}
   ```
   Так аннотация корректна для type checker и IDE; логгер привязан к запросу и уже содержит `trace_id`.

## Быстрая инициализация логгера (без фабрики)

Если нужно получить `TpLogger` напрямую (например в скрипте/воркере), можно использовать функции:

```python
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import get_logger, get_thread_logger

logger = get_logger(env=EnvironmentType.DEV, name="api")
worker_logger = get_thread_logger(env=EnvironmentType.DEV, thread_name="worker_1")
```

## Обработка ошибок и trace_id

- В **любых** логах (info, warning, error, exception) из такого логгера в JSON попадает поле **`trace_id`**. Это нужно, чтобы по логам однозначно найти запрос, приведший к ошибке.
- Ошибки в эндпоинте логируйте через тот же `logger`:
  ```python
  try:
      result = await some_operation()
      return result
  except Exception as e:
      logger.exception("Операция не удалась: %s", e)
      raise HTTPException(status_code=500, detail="Internal Server Error") from e
  ```
- Необработанные исключения перехватывает `TraceIdMiddleware`: он получает логгер запроса и пишет `logger.exception(...)`, поэтому в логе тоже будет `trace_id`.

Итого: при любых ошибках (и в обработчике, и в middleware) в лог выходит `trace_id` — можно коррелировать с заголовком ответа `X-Trace-ID`.
