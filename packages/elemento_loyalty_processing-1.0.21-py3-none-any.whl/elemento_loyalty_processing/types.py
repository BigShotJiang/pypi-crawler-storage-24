from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Any, NewType, TypedDict

from elemento_customers.types import Customer, CustomerId
from msgspec import Struct

__all__ = [
    "DATE_MAXVALUE",
    "ListId",
    "CustomerId",
    "ItemList",
    "ItemListType",
    "EventTypeId",
    "BalanceStatus",
    "Balance",
    "TransactionType",
    "TransactionId",
    "CustomerId",
    "Transaction",
    "EventTypeId",
    "Item",
    "RefundItem",
    "Cart",
    "BalanceAction",
    "Customer",
    "StoredTransaction",
    "OfferId",
    "GroupId",
    "OfferEventType",
    "ConditionId",
    "LifetimeId",
    "ActionId",
    "Points",
    "StoreId",
    "AppliedOffer",
    "PointType",
    "TransactionExtId",
    "PurchaseStats",
    "PersonalOffer",
    "Position",
]

DATE_MAXVALUE = date.fromisoformat("3000-01-01")

TransactionExtId = NewType("TransactionExtId", str)
TransactionId = NewType("TransactionId", int)
EventTypeId = NewType("EventTypeId", str)
ListId = NewType("ListId", int)
StoreId = NewType("StoreId", int)
OfferId = NewType("OfferId", int)
LifetimeId = NewType("LifetimeId", str)
GroupId = NewType("GroupId", int)
ConditionId = NewType("ConditionId", int)
ActionId = NewType("ActionId", int)
Points = NewType("Points", int)
Position = NewType("Position", int)


class OfferEventType(Enum):
    PointsAdd = "PointsAdd"
    PointsUse = "PointsUse"
    Purchase = "Purchase"
    Return = "Return"
    Birthday = "Birthday"
    RegistrationDone = "RegistrationDone"
    Discount = "Discount"
    PointsAddLimit = "PointsAddLimit"
    ExternalPointsAdd = "ExternalPointsAdd"


class ItemListType(Enum):
    STORE = "STORE"
    PRODUCT = "PRODUCT"
    TERMINAL = "TERMINAL"


class ItemList(Struct):
    type: ItemListType
    id: ListId
    items: list[str]


class BalanceStatus(Enum):
    FUTURE = "FUTURE"
    HOLD = "HOLD"
    ACTIVE = "ACTIVE"


class Balance(Struct):
    customer_id: CustomerId
    active_from: date
    active_to: date
    status: BalanceStatus
    amount: int
    transaction_id: TransactionId | None = None


class TransactionType(Enum):
    ORDER = "ORDER"
    SCRIPT = "SCRIPT"


class _PointTypeData(TypedDict, total=False):
    func: str
    value: Any
    time_unit: str


class PointType(Struct):
    updated: datetime
    id: LifetimeId
    label: str
    activation: _PointTypeData
    expiration: _PointTypeData


class BalanceAction(Enum):
    CALC = "CALC"
    SUB = "SUB"
    ADD = "ADD"


class AppliedOffer(Struct):
    offer_id: int | None
    offer_name: str
    points_sub: Points
    points_sub_max: Points
    points_add: Points
    discount: Decimal
    active_from: date
    active_to: date
    promo_id: str | None = None


class PersonalOffer(Struct):
    id: str
    type: str
    discount_percent: int = 0
    cashback_percent: int = 0


class Item(Struct):
    pos: Position
    product_id: str
    quantity: int
    total: Decimal
    price: Decimal
    initial_total: Decimal | None = None
    cashback: Points = 0
    discount: Decimal = Decimal("0.00")
    initial_discount: Decimal = None
    points_add: Points = 0
    points_sub: Points = 0
    points_sub_max: Points = 0
    params: dict[str, Any] = {}
    offers_add: list[AppliedOffer] = []
    offers_sub: list[AppliedOffer] = []
    offers_discount: list[AppliedOffer] = []
    personal: list[PersonalOffer] = []

    def __post_init__(self):
        if self.initial_total is None:
            self.initial_total = self.total
        if self.initial_discount is None:
            self.initial_discount = self.discount


class RefundItem(TypedDict):
    pos: int
    quantity: int


class Cart(Struct):
    items: list[Item]
    total: Decimal = Decimal(0)
    initial_total: Decimal = Decimal(0)
    discount: Decimal = Decimal(0)
    points_add: Points = Points(0)
    points_sub: Points = Points(0)
    points_sub_max: Points = Points(0)
    points_available: Points = Points(0)
    cashier_message: str = ""
    customer_message: str = ""
    offers_add: list[AppliedOffer] = []
    personal: list[PersonalOffer] = []


class StoredTransaction(Struct):
    id: TransactionId
    created: datetime
    customer_id: CustomerId
    total: int
    type: TransactionType
    balance: list[int]
    quantity: list[int]
    ext_id: TransactionExtId
    source: str
    # data: dict[str, Any] = None
    active: bool = True


class Transaction(Struct):
    ext_id: TransactionExtId
    id: TransactionId
    source: str
    order_id: str | None = None
    customer_id: CustomerId = None
    timestamp: datetime = None
    cart: Cart = None
    confirmed: bool = False
    payment_type: str | None = None
    actions: list[BalanceAction] = []

    def set_current_action(self, action: BalanceAction, /) -> list[OfferEventType]:
        if action is BalanceAction.SUB:
            self.init_all()
            self.actions = [BalanceAction.SUB]
            return [OfferEventType.Discount, OfferEventType.PointsUse]

        if action is BalanceAction.ADD:
            if BalanceAction.SUB in self.actions:
                self.init_add()
                self.actions = [BalanceAction.SUB, BalanceAction.ADD]
                return [OfferEventType.PointsAdd, OfferEventType.PointsAddLimit]
            else:
                self.init_all()
                self.actions = [BalanceAction.ADD]
                return [OfferEventType.Discount, OfferEventType.PointsAdd, OfferEventType.PointsAddLimit]

        self.init_all()
        self.actions = [action]
        return []

    def init_all(self) -> None:
        self.cart.points_add = Points(0)
        self.cart.points_sub = Points(0)
        self.cart.points_sub_max = Points(0)
        self.cart.cashier_message = ""
        self.cart.customer_message = ""
        total = Decimal(0)

        for item in self.cart.items:
            item.initial_total = item.price * item.quantity
            item.total = item.initial_total - item.initial_discount
            total += item.total
            item.offers_add.clear()
            item.points_add = Points(0)
            item.offers_sub.clear()
            item.points_sub = Points(0)
            item.points_sub_max = Points(0)
            item.offers_discount.clear()
            item.discount = item.initial_discount

        self.cart.total = self.cart.initial_total = total

    def init_sub(self) -> None:
        self.cart.points_add = Points(0)
        self.cart.points_sub = Points(0)
        self.cart.points_sub_max = Points(0)
        self.cart.cashier_message = ""
        self.cart.customer_message = ""
        total, initial_total, discount = Decimal(0), Decimal(0), Decimal(0)

        for item in self.cart.items:
            item.initial_total = item.price * item.quantity
            initial_total += item.initial_total
            item.total = item.initial_total - item.discount
            discount += item.discount
            total += item.total
            item.offers_add.clear()
            item.points_add = Points(0)
            item.offers_sub.clear()
            item.points_sub = Points(0)
            item.points_sub_max = Points(0)

        self.cart.total = total
        self.cart.initial_total = initial_total
        self.cart.discount = discount

    def init_add(self) -> None:
        self.cart.total = self.cart.initial_total - self.cart.discount - self.cart.points_sub
        self.cart.points_add = Points(0)
        self.cart.cashier_message = ""
        self.cart.customer_message = ""
        total, initial_total, discount = Decimal(0), Decimal(0), Decimal(0)
        points_sub, points_sub_max = Points(0), Points(0)

        for item in self.cart.items:
            item.initial_total = item.price * item.quantity
            initial_total += item.initial_total
            item.total = item.initial_total - item.discount - item.points_sub
            total += item.total
            discount += item.discount
            points_sub += item.points_sub
            points_sub_max += item.points_sub_max
            item.offers_add.clear()
            item.points_add = Points(0)

        self.cart.total = total
        self.cart.initial_total = initial_total
        self.cart.discount = discount
        self.cart.points_sub = points_sub
        self.cart.points_sub_max = points_sub_max


class PurchaseStats(Struct):
    total: Decimal = Decimal(0)
    points_day: Points = Points(0)
    purchases_day: int = 0
    points_week: Points = Points(0)
    purchases_week: int = 0
    points_month: Points = Points(0)
    purchases_month: int = 0
