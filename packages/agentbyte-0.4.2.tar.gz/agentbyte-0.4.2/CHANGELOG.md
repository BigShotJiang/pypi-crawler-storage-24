# Changelog

All notable changes to Agentbyte are documented in this file.

The format follows Keep a Changelog principles and semantic versioning.

## [0.4.2] - 2026-03-25

### Added
- Added the copied picoagents `agent_framework_devui` assets under `src/agentbyte/webui/` for local parity/reference work.
- Added the upstream frontend workspace files that now live under `src/agentbyte/webui/frontend/`, including new public assets and shared UI components.

### Changed
- Replaced the previous in-repo WebUI frontend source with the picoagents frontend snapshot copied into `src/agentbyte/webui/frontend/`.
- Removed the redundant Hatch wheel `force-include` for `src/agentbyte/webui/ui`, fixing duplicate archive entries during wheel builds.

### Fixed
- Fixed PyPI publish failures caused by duplicate `agentbyte/webui/ui/*` filenames in the generated wheel.

## [0.4.1] - 2026-03-25

### Added
- Added a single-vector `embedding` field to `EmbeddingResult` while preserving the existing `embeddings`, `usage`, `model`, and `metadata` payload.

### Changed
- Updated OpenAI and Azure embedding clients so `create()` and `create_batch()` both return an `EmbeddingResult` with `embedding == embeddings[0]`.
- Shipped the packaged Chapter 8 WebUI assets and parity updates that landed after `0.4.0`.

### Testing
- Added focused embedding assertions for the dual-field result contract across OpenAI and Azure embedding clients.

## [0.4.0] - 2026-03-24

### Added
- New multi-agent orchestration module with shared `BaseOrchestrator` execution loop.
- New orchestration patterns:
  - `RoundRobinOrchestrator`
  - `AIOrchestrator`
  - `PlanBasedOrchestrator`
- New plan-based orchestration public models:
  - `PlanStep`
  - `ExecutionPlan`
  - `StepProgressEvaluation`
- New orchestration examples for basic, streaming, and OpenTelemetry-backed execution.
- New Chapter 7 study/tutorial docs for round-robin, AI-driven, and plan-based orchestration.

### Changed
- Extended orchestration execution to support focused message-list context payloads and pattern-level completion hooks.
- Improved agent-as-tool streaming telemetry so tool middleware spans are preserved for delegated agent execution.
- Added aggregate usage summaries on workflow and orchestration root spans while keeping detailed `chat ...` and `tool ...` spans at the agent/middleware layer.
- Updated study docs to clarify the telemetry boundary across agents, workflows, and orchestrators.

### Testing
- Added dedicated tests for plan-based orchestration behavior and package-level export coverage.
- Added telemetry regression coverage for delegated agent-as-tool execution and workflow root usage summaries.

## [0.3.6] - 2026-03-23

### Added
- New notebook-focused logging utility: `configure_notebook_logging()` in `agentbyte.notebook`
  - Simplifies logging setup in Jupyter notebooks
  - Always shows middleware logs at INFO level for demo visibility
  - Suppresses noisy HTTP/Azure/OpenAI logs in quiet mode by default
  - Exported from package root for easy notebook imports

### Changed
- Azure embedding client authentication simplified in notebook 02c:
  - Removed API-key auth path (certificate-only for Azure in notebooks)
  - Kept API-key auth for OpenAI embeddings
  - Notebook now supports on-the-fly model/API-version overrides

## [0.3.5] - 2026-03-18

### Added
- New async embeddings client foundation in `agentbyte.llm`:
	- `BaseEmbeddingClient`, `BaseEmbeddingClientConfig`
	- `OpenAIEmbeddingClient`, `OpenAIEmbeddingClientConfig`
	- `AzureOpenAIEmbeddingClient`, `AzureOpenAIEmbeddingClientConfig`
	- `EmbeddingResult` type export in `agentbyte.llm`.
- Separate embedding APIs for single and batch generation:
	- `create(input_text: str) -> list[float]`
	- `create_batch(input_texts: list[str]) -> list[list[float]]`

### Changed
- `AzureOpenAISettings` now supports `embedding_deployment_name` from
	`AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME` for embedding client factory resolution.

### Testing
- Added focused unit tests for OpenAI and Azure embedding clients covering
	single input, batch ordering, empty input validation, and env-based factory loading.

## [0.3.4] - 2026-03-18

### Changed
- `AzureServicePrincipalSettings`: replaced `model_post_init` with a `@model_validator(mode="after")` to normalize `cognitive_scope`. All three input forms are handled: bare URL → `/.default` appended; URL ending with `/` → `.default` appended; URL already ending with `/.default` → unchanged.

## [0.3.3] - 2026-03-18
### Changed
- `AzureServicePrincipalSettings.model_post_init` now automatically appends `/.default` to `cognitive_scope` if it is not already present (e.g. `https://cognitiveservices.azure.com` → `https://cognitiveservices.azure.com/.default`).

## [0.3.2] - 2026-03-18

### Changed
- Lowered package runtime requirement from Python 3.12+ to Python 3.11+.
- Updated local interpreter pin (`.python-version`) to 3.11.
- Updated CI pipeline default Python version to 3.11 for release jobs.

### Documentation
- Updated README release metadata and installation requirements to reflect Python 3.11+ and release `0.3.2`.

## [0.3.1] - 2026-03-07

### Added
- Interactive CLI wizard: running `agentbyte` with no arguments now launches a numbered menu that guides users through command and provider selection instead of printing static help.
- `_interactive_wizard()` — two-phase prompt (command → provider) with a single re-prompt on invalid input and clean `KeyboardInterrupt` / EOFError handling.

### Changed
- `agentbyte create-skills --provider=<name>` (non-interactive / CI path) is fully preserved; the wizard is only invoked when no arguments are supplied.

## [0.3.0] - 2026-03-06

### Breaking Changes
- `BaseAgent` no longer stores a context instance. `self.context`, `reset_context()`, `clear_messages()`, `window_messages()`, and `reset()` are removed. `Agent.__init__` no longer accepts a `context=` keyword argument.
- Multi-turn sessions must now be managed by the caller: pass `context=` to each `run()`/`run_stream()` call and capture the returned context from `AgentResponse.context`.

### Changed
- `Agent.run(task=None, context=None, ...)` and `Agent.run_stream(task=None, context=None, ...)` accept a per-call `AgentContext`. When `None`, a fresh context is created automatically.
- `AgentResponse.context` returns the fully-populated working context to the caller after every run.
- `AgentAsTool.execute(parameters, context=None)` and `execute_stream(parameters, context=None, ...)` thread the caller-supplied context through to the underlying agent.
- `AgentToolCompatible` protocol updated to include `context=None` on both `execute` and `execute_stream`.

### Documentation
- `topic_agents.md`: Parts 2.5 (lock-free context threading) and 2.6 (agent-as-tool context) added.
- `topic_approval.md`: Tool approval resume pattern updated to `agent.run(context=first_response.context)`.
- `topic_otel_spans.md`: Dummy trace ID notes added; `args: {}` vs `TOOL PARAMETERS` discrepancy explained; known limitation section for parsed args not captured in chat span attributes.
- Notebooks `04-agent-with-context`, `07-agent-as-tool-coordinator`, `04.2-metadata-extraction-large-doc` updated to caller-owned context pattern.

## [0.2.7] - 2026-03-03

### Added
- `run_stream()` is now fully instrumented with an OTel root span via the native `_root_span()` context manager — every streaming task gets a correctly nested `agent <name>` root span identical to `run()`.
- New OTel example `examples/otel/agent_with_stream_telemetry.py` — streaming agent with 3 queries of increasing tool complexity (service: `agentbyte-stream`).
- New `examples/otel/inspect_traces.py` — CLI utility to inspect Jaeger traces without opening the UI; requires a traceID positional argument.

### Changed
- `auto_instrument()` now patches **only** `Agent.__init__` (OTelMiddleware injection); root span creation is handled natively in `Agent.run_stream()` — no monkey-patching of `run` or `run_stream`.
- `Agent.run_stream` execution logic renamed internally to `_run_stream_impl`; public `run_stream` is a thin span-wrapping delegate.
- `_annotate_root_span()` is a module-level function in `otel.py` — all OTel instrumentation logic is now centralized in one file.

## [0.2.6] - 2026-03-03

### Added
- OpenTelemetry model-call usage enrichment:
	- `gen_ai.usage.total_tokens`
	- `gen_ai.usage.cost_estimate_usd`
	- `gen_ai.response.finish_reason`
- Root agent span usage enrichment (opt-in via `AGENTBYTE_OTEL_CAPTURE_USAGE=true`):
	- `gen_ai.agent.finish_reason`
	- `gen_ai.agent.llm_calls`
	- `gen_ai.usage.duration_ms`
	- `gen_ai.usage.input_tokens`
	- `gen_ai.usage.output_tokens`
	- `gen_ai.usage.total_tokens`
	- `gen_ai.usage.cost_estimate_usd`

### Changed
- OTel examples now set `AGENTBYTE_OTEL_CAPTURE_USAGE=true` to demonstrate final task-level usage aggregation on root spans.
- OTel middleware now uses `Usage.total_tokens` directly for span attribute emission.

### Documentation
- Updated README to position Agentbyte as an observability-first agentic AI framework.
- Added no-UI Jaeger debugging workflow (API-based trace inspection with `curl`).

## [0.2.5] - 2026-03-02

### Changed
- Synced release documentation with code version and updated release-facing project docs.
- Updated release process guidance in repository instructions to require `README.md` and `CHANGELOG.md` updates for every tag.

### Documentation
- Updated README release section to reflect the new version and current highlights.

## [0.2.4] - 2026-03-02

### Added
- New use-case notebook: `04.2-metadata-extraction-large-doc.ipynb` for progressive chunked metadata extraction with memory and aggregation.
- New concept sample-data JSON files for ASMD/ESMD synthetic contract metadata.
- Project logo asset at `logo/agent-byte-avatar-low.png`.

### Changed
- Reorganized notebooks into `notebooks/concepts/agent/` and `notebooks/usecases/` with updated naming.
- Refreshed multiple concept notebooks for agent, middleware, memory, OTel, and agent-as-tool flows.

## [0.2.3] - 2026-03-02

### Changed
- Unified `Conversation` and `Workspace` into a single `Session` model. Both were structurally identical; domain semantics now live in `Session.metadata` (e.g. `{"name": "Blog Post"}`).
- `session.py` now contains `Session(Entity)`, `BaseSession(ABC)`, and `InMemorySession` — flat pattern mirroring `memory/base.py`.
- `AgentContext.conversation_id` field removed. `session_id: Optional[str]` (already present) is the sole context-level session link.

### Removed
- `src/agentbyte/conversation/` module and all exports (`Conversation`, `BaseConversation`, `InMemoryConversation`).
- `src/agentbyte/workspace/` module and all exports (`Workspace`, `BaseWorkspace`, `InMemoryWorkspace`).
- `tests/test_conversation.py`, `tests/test_workspace.py`, `tests/agents/test_agent_conversation_integration.py`.

### Added
- `tests/test_session.py` — 19 tests covering `Session` identity/equality, `to_context()`/`from_context()`, `InMemorySession` CRUD, copy-safety, and ABC contract.

### Reorganized
- Notebooks moved from flat layout into `notebooks/agent/`, `notebooks/auth/`, and `notebooks/usecase/` subdirectories.

## [0.2.1] - 2026-02-27

### Changed
- Updated package metadata for project URLs (Homepage, Repository, Issues, Changelog).
- Updated README installation guidance for `pip`/`uv add` extras usage.

### Added
- Added root `LICENSE` file (MIT) for distribution compliance and clarity.

## [0.2.0] - 2026-02-27

### Added
- Memory serialization parity (`ListMemoryConfig`, `FileMemoryConfig`, `_to_config`, `_from_config`).
- Agent-managed memory tooling via `MemoryTool` and `MemoryBackend`.
- Middleware-driven memory access routing (`operation="memory_access"`).
- `ApprovalMiddleware` for centralized tool-approval policy.
- OpenTelemetry middleware and auto-instrumentation support.
- Notebook examples for middleware patterns and real-client logging middleware.
- New/expanded tests for middleware, memory, package API, and OTel integration.

### Changed
- Middleware execution and event pipeline now support richer parity behavior with request/response/error fan-out semantics.
- Agent run paths now integrate improved middleware handling and instrumentation.
- Package API now exposes `Agent` at package root and supports opt-in auto-instrumentation via environment variable.

### Fixed
- Token usage mapping alignment in telemetry paths (`tokens_input`, `tokens_output`).
- Auto-instrumentation idempotency for repeated setup calls.

## [0.1.2] - 2026-02-25

### Added
- Initial middleware and memory completion pass (streaming middleware baseline, approval pause integration, memory tooling foundations).
