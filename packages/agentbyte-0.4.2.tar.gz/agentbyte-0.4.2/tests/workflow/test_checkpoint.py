from __future__ import annotations

import asyncio

import pytest
from pydantic import BaseModel

from agentbyte.workflow import (
    CheckpointConfig,
    FileCheckpointStore,
    InMemoryCheckpointStore,
    StepMetadata,
    Workflow,
    WorkflowCheckpoint,
    WorkflowConfig,
    WorkflowRunner,
)
from agentbyte.workflow.core.models import Context, WorkflowExecution
from agentbyte.workflow.steps.function import FunctionStep
from agentbyte.workflow.steps.step import BaseStep


class NumberInput(BaseModel):
    value: int


class NumberOutput(BaseModel):
    result: int


@pytest.mark.asyncio
async def test_workflow_checkpoint_factory_and_inmemory_store() -> None:
    execution = WorkflowExecution(
        workflow_id="wf",
        state={"x": 1},
        step_executions={},
    )
    checkpoint = WorkflowCheckpoint.from_execution(
        execution=execution,
        workflow_id="wf",
        workflow_version="1.0.0",
        workflow_structure_hash="abc123",
        all_step_ids=["a", "b"],
    )
    store = InMemoryCheckpointStore()
    await store.save(checkpoint)

    loaded = await store.load(checkpoint.checkpoint_id)
    latest = await store.load_latest("wf")
    metadata = await store.list_metadata("wf")

    assert loaded is not None
    assert latest is not None
    assert latest.checkpoint_id == checkpoint.checkpoint_id
    assert metadata[0].total_steps == 2


@pytest.mark.asyncio
async def test_file_checkpoint_store_roundtrip(tmp_path) -> None:
    store = FileCheckpointStore(tmp_path / "checkpoints")
    execution = WorkflowExecution(workflow_id="wf")
    checkpoint = WorkflowCheckpoint.from_execution(
        execution=execution,
        workflow_id="wf",
        workflow_version="1.0.0",
        workflow_structure_hash="hash",
        all_step_ids=["a"],
    )

    await store.save(checkpoint)
    loaded = await store.load(checkpoint.checkpoint_id)
    latest = await store.load_latest("wf")
    metadata = await store.list_metadata("wf")

    assert loaded is not None
    assert latest is not None
    assert loaded.checkpoint_id == checkpoint.checkpoint_id
    assert metadata[0].size_bytes is not None


@pytest.mark.asyncio
async def test_runner_auto_saves_and_resumes_from_checkpoint() -> None:
    async def first_step(input_data: NumberInput, context: Context) -> NumberOutput:
        context.set("seen_first", True)
        await asyncio.sleep(0)
        return NumberOutput(result=input_data.value + 1)

    class FlakyStep(BaseStep[NumberOutput, NumberOutput]):
        def __init__(self) -> None:
            super().__init__(
                step_id="second",
                metadata=StepMetadata(name="second"),
                input_type=NumberOutput,
                output_type=NumberOutput,
            )
            self.calls = 0

        async def execute(self, input_data: NumberOutput, context: Context) -> NumberOutput:
            self.calls += 1
            if self.calls == 1:
                raise RuntimeError("fail once")
            context.set("resumed", True)
            return NumberOutput(result=input_data.result + 10)

    first = FunctionStep(
        step_id="first",
        metadata=StepMetadata(name="first"),
        input_type=NumberInput,
        output_type=NumberOutput,
        func=first_step,
    )
    second = FlakyStep()
    workflow = Workflow(WorkflowConfig(name="resume-flow"))
    workflow.chain(first, second)

    store = InMemoryCheckpointStore()
    checkpoint_config = CheckpointConfig(store=store, auto_save=True, save_interval_steps=1)
    runner = WorkflowRunner()

    with pytest.raises(RuntimeError, match="fail once"):
        await runner.run(workflow, {"value": 1}, checkpoint_config=checkpoint_config)

    latest = await store.load_latest("resume-flow")
    assert latest is not None
    assert latest.completed_step_ids == ["first"]

    execution = await runner.run(
        workflow,
        {"value": 999},
        checkpoint=latest,
        checkpoint_config=checkpoint_config,
    )

    assert second.calls == 2
    assert execution.step_executions["first"].output_data == {"result": 2}
    assert execution.step_executions["second"].output_data == {"result": 12}
    assert execution.state["resumed"] is True


@pytest.mark.asyncio
async def test_runner_rejects_mismatched_checkpoint() -> None:
    async def passthrough(input_data: NumberInput, _: Context) -> NumberOutput:
        return NumberOutput(result=input_data.value)

    workflow = Workflow(WorkflowConfig(name="wf-a"))
    workflow.set_start_step(
        FunctionStep(
            step_id="only",
            metadata=StepMetadata(name="only"),
            input_type=NumberInput,
            output_type=NumberOutput,
            func=passthrough,
        )
    ).add_end_step("only")

    other_workflow = Workflow(WorkflowConfig(name="wf-b"))
    other_workflow.set_start_step(
        FunctionStep(
            step_id="only",
            metadata=StepMetadata(name="only"),
            input_type=NumberInput,
            output_type=NumberOutput,
            func=passthrough,
        )
    ).add_end_step("only")

    checkpoint = WorkflowCheckpoint.from_execution(
        execution=WorkflowExecution(workflow_id="wf-b"),
        workflow_id="wf-b",
        workflow_version="1.0.0",
        workflow_structure_hash=other_workflow.compute_structure_hash(),
        all_step_ids=["only"],
    )

    events = [
        event
        async for event in WorkflowRunner().run_stream(
            workflow,
            {"value": 1},
            checkpoint=checkpoint,
        )
    ]

    assert "Checkpoint validation failed" in events[-1].error
