from __future__ import annotations

import asyncio
import sys
from types import ModuleType
from typing import Any

import pytest
from pydantic import BaseModel

from agentbyte.cancellation_token import CancellationToken
from agentbyte.workflow import (
    Context,
    StepMetadata,
    StepProgressEvent,
    Workflow,
    WorkflowCancelledEvent,
    WorkflowCompletedEvent,
    WorkflowCompletionMode,
    WorkflowConfig,
    WorkflowFailedEvent,
    WorkflowRunner,
)
from agentbyte.workflow.steps.echo import EchoOutput, EchoStep
from agentbyte.workflow.steps.function import FunctionStep
from agentbyte.workflow.steps.step import BaseStep


class NumberInput(BaseModel):
    value: int


class NumberOutput(BaseModel):
    result: int


def _build_math_workflow() -> Workflow:
    async def double(input_data: NumberInput, _: Context) -> NumberOutput:
        await asyncio.sleep(0)
        return NumberOutput(result=input_data.value * 2)

    async def add_ten(input_data: NumberOutput, _: Context) -> NumberOutput:
        await asyncio.sleep(0)
        return NumberOutput(result=input_data.result + 10)

    double_step = FunctionStep(
        step_id="double",
        metadata=StepMetadata(name="double"),
        input_type=NumberInput,
        output_type=NumberOutput,
        func=double,
    )
    add_ten_step = FunctionStep(
        step_id="add_ten",
        metadata=StepMetadata(name="add_ten"),
        input_type=NumberOutput,
        output_type=NumberOutput,
        func=add_ten,
    )
    return Workflow(WorkflowConfig(name="math-pipeline")).chain(double_step, add_ten_step)


@pytest.mark.asyncio
async def test_runner_supports_listing_6_2_style_fluent_chain_composition() -> None:
    class ListingInput(BaseModel):
        value: int

    class ListingOutput(BaseModel):
        result: int

    async def double(input_data: ListingInput, _: Context) -> ListingOutput:
        await asyncio.sleep(0)
        return ListingOutput(result=input_data.value * 2)

    async def add_ten(input_data: ListingOutput, _: Context) -> ListingOutput:
        await asyncio.sleep(0)
        return ListingOutput(result=input_data.result + 10)

    double_step = FunctionStep(
        step_id="double",
        metadata=StepMetadata(name="double"),
        input_type=ListingInput,
        output_type=ListingOutput,
        func=double,
    )
    add_ten_step = FunctionStep(
        step_id="add_ten",
        metadata=StepMetadata(name="add_ten"),
        input_type=ListingOutput,
        output_type=ListingOutput,
        func=add_ten,
    )

    workflow = (
        Workflow(WorkflowConfig(name="simple-math-pipeline"))
        .chain(double_step, add_ten_step)
    )

    assert workflow.start_step_id == "double"
    assert workflow.end_step_ids == ["add_ten"]

    runner = WorkflowRunner()
    execution = await runner.run(workflow, {"value": 7})

    assert execution.status.value == "completed"
    assert execution.step_executions["double"].output_data == {"result": 14}
    assert execution.step_executions["add_ten"].output_data == {"result": 24}


class _FakeStatusCode:
    OK = "OK"
    ERROR = "ERROR"


class _FakeStatus:
    def __init__(self, code: str, description: str | None = None) -> None:
        self.code = code
        self.description = description


class _FakeSpan:
    def __init__(self, name: str) -> None:
        self.name = name
        self.attributes: dict[str, Any] = {}
        self.status: _FakeStatus | None = None
        self.recorded_exceptions: list[Exception] = []
        self.parent_name: str | None = None

    def set_attribute(self, key: str, value: Any) -> None:
        self.attributes[key] = value

    def set_status(self, status: _FakeStatus) -> None:
        self.status = status

    def record_exception(self, exc: Exception) -> None:
        self.recorded_exceptions.append(exc)


class _FakeSpanContextManager:
    def __init__(self, span: _FakeSpan, active_stack: list[_FakeSpan]) -> None:
        self.span = span
        self._active_stack = active_stack

    def __enter__(self) -> _FakeSpan:
        if self._active_stack:
            self.span.parent_name = self._active_stack[-1].name
        self._active_stack.append(self.span)
        return self.span

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        self._active_stack.pop()
        return False


class _FakeTracer:
    def __init__(self, spans: list[_FakeSpan], active_stack: list[_FakeSpan]) -> None:
        self._spans = spans
        self._active_stack = active_stack

    def start_as_current_span(self, name: str) -> _FakeSpanContextManager:
        span = _FakeSpan(name)
        self._spans.append(span)
        return _FakeSpanContextManager(span, self._active_stack)


def _install_fake_opentelemetry(monkeypatch: pytest.MonkeyPatch, spans: list[_FakeSpan]) -> None:
    active_stack: list[_FakeSpan] = []
    trace_module = ModuleType("opentelemetry.trace")
    trace_module.get_tracer = lambda name: _FakeTracer(spans, active_stack)  # type: ignore[attr-defined]
    trace_module.Status = _FakeStatus  # type: ignore[attr-defined]
    trace_module.StatusCode = _FakeStatusCode  # type: ignore[attr-defined]

    otel_module = ModuleType("opentelemetry")
    otel_module.trace = trace_module  # type: ignore[attr-defined]

    monkeypatch.setitem(sys.modules, "opentelemetry", otel_module)
    monkeypatch.setitem(sys.modules, "opentelemetry.trace", trace_module)


@pytest.mark.asyncio
async def test_runner_completes_sequential_workflow() -> None:
    workflow = _build_math_workflow()
    runner = WorkflowRunner()

    execution = await runner.run(workflow, {"value": 3})

    assert execution.status.value == "completed"
    assert execution.step_executions["double"].output_data == {"result": 6}
    assert execution.step_executions["add_ten"].output_data == {"result": 16}
    assert execution.state["double_output"] == {"result": 6}
    assert execution.state["add_ten_output"] == {"result": 16}


@pytest.mark.asyncio
async def test_runner_emits_progress_events() -> None:
    class ProgressStep(BaseStep[NumberInput, NumberOutput]):
        def __init__(self) -> None:
            super().__init__(
                step_id="progress",
                metadata=StepMetadata(name="progress"),
                input_type=NumberInput,
                output_type=NumberOutput,
            )

        async def execute(self, input_data: NumberInput, context: Context) -> NumberOutput:
            context.emit_progress("working", completed=1, total=2)
            await asyncio.sleep(0)
            context.emit_progress("done", completed=2, total=2)
            return NumberOutput(result=input_data.value)

    workflow = Workflow(WorkflowConfig(name="progress-flow"))
    workflow.set_start_step(ProgressStep()).add_end_step("progress")
    runner = WorkflowRunner()

    events = [event async for event in runner.run_stream(workflow, {"value": 5})]

    progress_events = [event for event in events if isinstance(event, StepProgressEvent)]
    assert len(progress_events) == 2
    assert progress_events[0].message == "working"
    assert isinstance(events[-1], WorkflowCompletedEvent)


@pytest.mark.asyncio
async def test_runner_completes_when_end_step_reached_in_conditional_flow() -> None:
    start = EchoStep(step_id="start", metadata=StepMetadata(name="start"))
    go = EchoStep(
        step_id="go",
        metadata=StepMetadata(name="go"),
        input_type=EchoOutput,
        output_type=EchoOutput,
    )
    stop = EchoStep(
        step_id="stop",
        metadata=StepMetadata(name="stop"),
        input_type=EchoOutput,
        output_type=EchoOutput,
    )

    workflow = Workflow(WorkflowConfig(name="branch-flow"))
    workflow.add_step(start).add_step(go).add_step(stop)
    workflow.set_start_step(start).add_end_step(go)
    workflow.add_edge(
        start,
        go,
        {"type": "output_based", "field": "result", "operator": "==", "value": "go"},
    )
    workflow.add_edge(
        start,
        stop,
        {"type": "output_based", "field": "result", "operator": "==", "value": "stop"},
    )

    runner = WorkflowRunner()
    execution = await runner.run(workflow, {"message": "go"})

    assert execution.status.value == "completed"
    assert "go" in execution.step_executions
    assert "stop" not in execution.step_executions


@pytest.mark.asyncio
async def test_runner_detects_deadlock_when_no_steps_can_progress() -> None:
    start = EchoStep(step_id="start", metadata=StepMetadata(name="start"))
    blocked = EchoStep(
        step_id="blocked",
        metadata=StepMetadata(name="blocked"),
        input_type=EchoOutput,
        output_type=EchoOutput,
    )
    workflow = Workflow(WorkflowConfig(name="deadlock-flow"))
    workflow.add_edge(
        start,
        blocked,
        {"type": "output_based", "field": "result", "operator": "==", "value": "never"},
    ).set_start_step(start)

    runner = WorkflowRunner()

    with pytest.raises(RuntimeError, match="cannot be executed"):
        await runner.run(workflow, {"message": "hello"})


@pytest.mark.asyncio
async def test_runner_supports_cancellation() -> None:
    class SlowStep(BaseStep[NumberInput, NumberOutput]):
        def __init__(self) -> None:
            super().__init__(
                step_id="slow",
                metadata=StepMetadata(name="slow"),
                input_type=NumberInput,
                output_type=NumberOutput,
            )

        async def execute(self, input_data: NumberInput, context: Context) -> NumberOutput:  # noqa: ARG002
            await asyncio.sleep(0.2)
            return NumberOutput(result=input_data.value)

    workflow = Workflow(WorkflowConfig(name="cancel-flow"))
    workflow.set_start_step(SlowStep()).add_end_step("slow")
    runner = WorkflowRunner()
    token = CancellationToken()

    events: list[Any] = []
    async for event in runner.run_stream(workflow, {"value": 1}, token):
        events.append(event)
        if getattr(event, "step_id", None) == "slow":
            token.cancel()

    assert any(isinstance(event, WorkflowCancelledEvent) for event in events)


@pytest.mark.asyncio
async def test_runner_creates_workflow_and_step_spans_when_otel_enabled(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workflow = _build_math_workflow()
    runner = WorkflowRunner()
    spans: list[_FakeSpan] = []

    monkeypatch.setenv("AGENTBYTE_ENABLE_OTEL", "true")
    _install_fake_opentelemetry(monkeypatch, spans)

    execution = await runner.run(workflow, {"value": 3})

    assert execution.status.value == "completed"
    assert [span.name for span in spans] == [
        "workflow math-pipeline",
        "workflow step double",
        "workflow step add_ten",
    ]

    workflow_span = spans[0]
    assert workflow_span.attributes["agentbyte.workflow.name"] == "math-pipeline"
    assert workflow_span.attributes["agentbyte.workflow.status"] == "completed"
    assert workflow_span.attributes["agentbyte.workflow.completed_steps"] == 2
    assert workflow_span.status is not None
    assert workflow_span.status.code == _FakeStatusCode.OK

    first_step_span = spans[1]
    assert first_step_span.attributes["agentbyte.workflow.step.id"] == "double"
    assert first_step_span.attributes["agentbyte.workflow.step.status"] == "completed"
    assert first_step_span.attributes["agentbyte.workflow.step.output_keys"] == "result"
    assert first_step_span.parent_name == "workflow math-pipeline"


@pytest.mark.asyncio
async def test_runner_preserves_nested_span_hierarchy_inside_step(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class InnerSpanStep(BaseStep[NumberInput, NumberOutput]):
        def __init__(self) -> None:
            super().__init__(
                step_id="inner",
                metadata=StepMetadata(name="inner"),
                input_type=NumberInput,
                output_type=NumberOutput,
            )

        async def execute(self, input_data: NumberInput, context: Context) -> NumberOutput:  # noqa: ARG002
            from opentelemetry import trace

            tracer = trace.get_tracer("agentbyte.test")
            with tracer.start_as_current_span("inner operation"):
                await asyncio.sleep(0)
                return NumberOutput(result=input_data.value)

    workflow = Workflow(WorkflowConfig(name="nested-span-flow"))
    workflow.set_start_step(InnerSpanStep()).add_end_step("inner")
    runner = WorkflowRunner()
    spans: list[_FakeSpan] = []

    monkeypatch.setenv("AGENTBYTE_ENABLE_OTEL", "true")
    _install_fake_opentelemetry(monkeypatch, spans)

    execution = await runner.run(workflow, {"value": 7})

    assert execution.status.value == "completed"
    assert [span.name for span in spans] == [
        "workflow nested-span-flow",
        "workflow step inner",
        "inner operation",
    ]
    assert spans[1].parent_name == "workflow nested-span-flow"
    assert spans[2].parent_name == "workflow step inner"


@pytest.mark.asyncio
async def test_runner_surfaces_input_validation_failure() -> None:
    workflow = _build_math_workflow()
    runner = WorkflowRunner()

    events = [event async for event in runner.run_stream(workflow, {"bad": 3})]

    assert isinstance(events[-1], WorkflowFailedEvent)
    assert "Initial input validation failed" in events[-1].error


@pytest.mark.asyncio
async def test_runner_collects_all_fan_in_branch_outputs_as_envelope() -> None:
    """Fan-in join step must receive branch_outputs envelope with outputs from all branches."""

    class BranchOutput(BaseModel):
        value: int

    class FanInInput(BaseModel):
        branch_outputs: dict[str, Any]
        failed_branches: list[str] = []

    received: list[FanInInput] = []

    async def branch_a_fn(input_data: NumberInput, _: Context) -> BranchOutput:
        return BranchOutput(value=input_data.value * 2)

    async def branch_b_fn(input_data: NumberInput, _: Context) -> BranchOutput:
        return BranchOutput(value=input_data.value + 100)

    async def join_fn(input_data: FanInInput, _: Context) -> NumberOutput:
        received.append(input_data)
        total = sum(v["value"] for v in input_data.branch_outputs.values())
        return NumberOutput(result=total)

    start = FunctionStep(
        step_id="start",
        metadata=StepMetadata(name="start"),
        input_type=NumberInput,
        output_type=NumberInput,
        func=lambda i, c: i,
    )
    branch_a = FunctionStep(
        step_id="branch_a",
        metadata=StepMetadata(name="branch_a"),
        input_type=NumberInput,
        output_type=BranchOutput,
        func=branch_a_fn,
    )
    branch_b = FunctionStep(
        step_id="branch_b",
        metadata=StepMetadata(name="branch_b"),
        input_type=NumberInput,
        output_type=BranchOutput,
        func=branch_b_fn,
    )
    join = FunctionStep(
        step_id="join",
        metadata=StepMetadata(name="join"),
        input_type=FanInInput,
        output_type=NumberOutput,
        func=join_fn,
    )

    workflow = Workflow(WorkflowConfig(name="fan-in-flow"))
    workflow.set_start_step(start)
    workflow.add_edge(start, branch_a)
    workflow.add_edge(start, branch_b)
    workflow.add_edge(branch_a, join)
    workflow.add_edge(branch_b, join)
    workflow.add_end_step(join)

    runner = WorkflowRunner()
    execution = await runner.run(workflow, {"value": 5})

    assert execution.status.value == "completed"
    assert len(received) == 1
    env = received[0]
    assert env.failed_branches == []
    assert set(env.branch_outputs.keys()) == {"branch_a", "branch_b"}
    assert env.branch_outputs["branch_a"]["value"] == 10   # 5 * 2
    assert env.branch_outputs["branch_b"]["value"] == 105  # 5 + 100


@pytest.mark.asyncio
async def test_runner_waits_for_all_end_steps_in_all_end_mode() -> None:
    """With ALL_END mode the runner must wait for ALL declared end steps to complete."""

    async def left_fn(input_data: NumberInput, _: Context) -> NumberOutput:
        return NumberOutput(result=input_data.value + 1)

    async def right_fn(input_data: NumberInput, _: Context) -> NumberOutput:
        return NumberOutput(result=input_data.value + 2)

    start = FunctionStep(
        step_id="start",
        metadata=StepMetadata(name="start"),
        input_type=NumberInput,
        output_type=NumberInput,
        func=lambda i, c: i,
    )
    left = FunctionStep(
        step_id="left",
        metadata=StepMetadata(name="left"),
        input_type=NumberInput,
        output_type=NumberOutput,
        func=left_fn,
    )
    right = FunctionStep(
        step_id="right",
        metadata=StepMetadata(name="right"),
        input_type=NumberInput,
        output_type=NumberOutput,
        func=right_fn,
    )

    workflow = Workflow(WorkflowConfig(name="all-end-flow", completion_mode=WorkflowCompletionMode.ALL_END))
    workflow.set_start_step(start)
    workflow.add_edge(start, left)
    workflow.add_edge(start, right)
    workflow.add_end_step(left)
    workflow.add_end_step(right)

    runner = WorkflowRunner()
    execution = await runner.run(workflow, {"value": 10})

    assert execution.status.value == "completed"
    # Both declared end steps must have completed
    assert execution.step_executions["left"].status.value == "completed"
    assert execution.step_executions["right"].status.value == "completed"
    assert execution.step_executions["left"].output_data == {"result": 11}
    assert execution.step_executions["right"].output_data == {"result": 12}
