"""Tests for Session, BaseSession, and InMemorySession."""

from __future__ import annotations

from uuid import uuid4

import pytest

from agentbyte.messages import UserMessage
from agentbyte.session import BaseSession, InMemorySession, Session


# ── Session model ──────────────────────────────────────────────────────────────

def test_session_has_uuid_identity() -> None:
    s = Session()
    assert s.id is not None


def test_session_equality_by_id() -> None:
    id_ = uuid4()
    s1 = Session(id=id_)
    s2 = Session(id=id_)
    assert s1 == s2


def test_session_inequality_different_id() -> None:
    assert Session() != Session()


def test_session_hashable() -> None:
    s = Session()
    assert hash(s) == hash(s.id)


def test_session_default_empty_messages_and_metadata() -> None:
    s = Session()
    assert s.messages == []
    assert s.metadata == {}


def test_session_metadata_name_pattern() -> None:
    s = Session(metadata={"name": "Blog Post"})
    assert s.metadata["name"] == "Blog Post"


# ── to_context / from_context ─────────────────────────────────────────────────

def test_to_context_sets_session_id() -> None:
    s = Session()
    ctx = s.to_context()
    assert ctx.session_id == str(s.id)


def test_to_context_no_conversation_id() -> None:
    """AgentContext must NOT have a conversation_id field at all."""
    from agentbyte.context import AgentContext
    assert "conversation_id" not in AgentContext.model_fields


def test_to_context_carries_messages() -> None:
    msg = UserMessage(content="hello", source="user")
    s = Session(messages=[msg])
    ctx = s.to_context()
    assert len(ctx.messages) == 1
    assert ctx.messages[0].content == "hello"


def test_to_context_copy_safe() -> None:
    s = Session()
    ctx = s.to_context()
    ctx.messages.append(UserMessage(content="mutate", source="user"))
    assert len(s.messages) == 0


def test_from_context_round_trip() -> None:
    s = Session(metadata={"x": 1})
    ctx = s.to_context()
    s2 = Session.from_context(ctx, s.id)
    assert s2.id == s.id
    assert s2.metadata == {"x": 1}


# ── InMemorySession ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_inmemory_save_and_get() -> None:
    store = InMemorySession()
    s = Session()
    await store.save(s)
    loaded = await store.get(s.id)
    assert loaded is not None
    assert loaded.id == s.id


@pytest.mark.asyncio
async def test_inmemory_get_missing_returns_none() -> None:
    store = InMemorySession()
    assert await store.get(uuid4()) is None


@pytest.mark.asyncio
async def test_inmemory_get_is_copy_safe() -> None:
    store = InMemorySession()
    s = Session()
    await store.save(s)
    loaded = await store.get(s.id)
    assert loaded is not None
    loaded.messages.append(UserMessage(content="mutate", source="user"))
    fresh = await store.get(s.id)
    assert fresh is not None
    assert len(fresh.messages) == 0


@pytest.mark.asyncio
async def test_inmemory_append_message() -> None:
    store = InMemorySession()
    s = Session()
    await store.save(s)
    msg = UserMessage(content="turn 1", source="user")
    await store.append_message(s.id, msg)
    loaded = await store.get(s.id)
    assert loaded is not None
    assert len(loaded.messages) == 1
    assert loaded.messages[0].content == "turn 1"


@pytest.mark.asyncio
async def test_inmemory_append_message_missing_raises() -> None:
    store = InMemorySession()
    with pytest.raises(KeyError):
        await store.append_message(uuid4(), UserMessage(content="x", source="user"))


@pytest.mark.asyncio
async def test_inmemory_multi_turn_accumulates() -> None:
    store = InMemorySession()
    s = Session()
    await store.save(s)
    for i in range(3):
        await store.append_message(s.id, UserMessage(content=f"msg {i}", source="user"))
    final = await store.get(s.id)
    assert final is not None
    assert len(final.messages) == 3


# ── BaseSession is abstract ────────────────────────────────────────────────────

def test_base_session_is_abstract() -> None:
    import inspect
    assert inspect.isabstract(BaseSession)


def test_inmemory_session_is_concrete_base_session() -> None:
    store = InMemorySession()
    assert isinstance(store, BaseSession)
