"""Tests for package-level API and bootstrap behavior."""

from __future__ import annotations

import importlib


def test_package_root_exports_agent() -> None:
    """`from agentbyte import Agent` should be supported."""
    from agentbyte import Agent
    from agentbyte.agents import Agent as AgentClass

    assert Agent is AgentClass


def test_entity_import_path() -> None:
    """Entity should be importable from the root."""
    from agentbyte import Entity
    from agentbyte.entity import Entity as FlatEntity

    assert Entity is FlatEntity


def test_plan_orchestration_import_paths() -> None:
    """Plan orchestration types should be importable from package roots."""
    from agentbyte import ExecutionPlan, PlanBasedOrchestrator, PlanStep, StepProgressEvaluation
    from agentbyte.orchestration import (
        ExecutionPlan as FlatExecutionPlan,
        PlanBasedOrchestrator as FlatPlanBasedOrchestrator,
        PlanStep as FlatPlanStep,
        StepProgressEvaluation as FlatStepProgressEvaluation,
    )

    assert PlanBasedOrchestrator is FlatPlanBasedOrchestrator
    assert ExecutionPlan is FlatExecutionPlan
    assert PlanStep is FlatPlanStep
    assert StepProgressEvaluation is FlatStepProgressEvaluation


def test_session_import_paths() -> None:
    """Session types should be importable from agentbyte and agentbyte.session."""
    from agentbyte import BaseSession, InMemorySession, Session
    from agentbyte.session import BaseSession as FlatBase
    from agentbyte.session import InMemorySession as FlatInMemory
    from agentbyte.session import Session as FlatSession

    assert Session is FlatSession
    assert BaseSession is FlatBase
    assert InMemorySession is FlatInMemory


def test_package_root_otel_bootstrap_calls_auto_instrument(
    monkeypatch,
) -> None:
    """Importing package root should trigger auto-instrumentation when enabled."""
    monkeypatch.setenv("AGENTBYTE_ENABLE_OTEL", "true")

    import agentbyte.middleware as middleware

    called = {"value": False}

    def _fake_auto_instrument() -> None:
        called["value"] = True

    monkeypatch.setattr(middleware, "auto_instrument", _fake_auto_instrument)

    import agentbyte

    importlib.reload(agentbyte)
    assert called["value"] is True


def test_package_root_otel_bootstrap_instruments_agent_init(
    monkeypatch,
) -> None:
    """Importing package root with OTel enabled patches Agent.__init__."""
    monkeypatch.setenv("AGENTBYTE_ENABLE_OTEL", "true")

    from agentbyte.agents.agent import Agent as AgentClass

    original_init = getattr(
        AgentClass.__init__,
        "__agentbyte_original_init__",
        AgentClass.__init__,
    )
    AgentClass.__init__ = original_init

    try:
        import agentbyte

        importlib.reload(agentbyte)
        assert getattr(AgentClass.__init__, "__agentbyte_otel_instrumented__", False) is True
    finally:
        AgentClass.__init__ = original_init
