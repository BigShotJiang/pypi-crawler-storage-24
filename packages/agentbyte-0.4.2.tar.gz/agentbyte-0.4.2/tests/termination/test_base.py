from typing import Sequence
from agentbyte.termination.base import BaseTermination
from agentbyte.messages import Message, UserMessage
from agentbyte.types import StopMessage


class SimpleTermination(BaseTermination):
    def check(self, new_messages: Sequence[Message]) -> StopMessage | None:
        if len(new_messages) > 0:
            return self._set_termination("Message received")
        return None


class TestBaseTermination:
    def test_base_logic(self):
        term = SimpleTermination()
        assert not term.is_met()
        assert term.get_reason() == ""
        assert term.get_metadata() == {}

        msg = UserMessage(content="hello", source="user")
        stop = term.check([msg])

        assert stop is not None
        assert stop.content == "Message received"
        assert stop.source == "SimpleTermination"
        assert term.is_met()
        assert term.get_reason() == "Message received"

    def test_reset(self):
        term = SimpleTermination()
        term.check([UserMessage(content="hi", source="user")])
        assert term.is_met()

        term.reset()
        assert not term.is_met()
        assert term.get_reason() == ""
        assert term.get_metadata() == {}

    def test_composition_operators(self):
        t1 = SimpleTermination()
        t2 = SimpleTermination()

        # OR operator
        composite_or = t1 | t2
        from agentbyte.termination.composite import CompositeTermination

        assert isinstance(composite_or, CompositeTermination)
        assert composite_or.mode == "any"
        assert len(composite_or.conditions) == 2

        # AND operator
        composite_and = t1 & t2
        assert isinstance(composite_and, CompositeTermination)
        assert composite_and.mode == "all"
        assert len(composite_and.conditions) == 2
