from agentbyte.termination.external import ExternalTermination
from agentbyte.messages import UserMessage


class TestExternalTermination:
    def test_external_trigger(self):
        term = ExternalTermination()
        msg = UserMessage(content="test", source="user")

        assert term.check([msg]) is None

        term.trigger("Custom reason")
        stop = term.check([msg])
        assert stop is not None
        assert stop.content == "Custom reason"
        assert term.is_met()

    def test_reset(self):
        term = ExternalTermination()
        term.trigger()
        assert term.check([]) is not None

        term.reset()
        assert not term.is_met()
        assert term.check([]) is None
