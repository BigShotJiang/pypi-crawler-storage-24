import pytest
from agentbyte.termination.text_mention import TextMentionTermination
from agentbyte.messages import AssistantMessage, UserMessage


class TestTextMentionTermination:
    def test_text_mention_case_sensitive(self):
        term = TextMentionTermination(text="TERMINATE")

        # No match
        assert (
            term.check([UserMessage(content="Please continue", source="user")]) is None
        )

        # Partial match but wrong case
        assert (
            term.check([AssistantMessage(content="terminate now", source="agent")])
            is None
        )

        # Exact match
        stop = term.check(
            [AssistantMessage(content="I am done. TERMINATE", source="agent")]
        )
        assert stop is not None
        assert "Text mention found" in stop.content
        assert stop.metadata["trigger_text"] == "TERMINATE"

    def test_text_mention_case_insensitive(self):
        term = TextMentionTermination(text="DONE", case_sensitive=False)

        stop = term.check([AssistantMessage(content="i am done now", source="agent")])
        assert stop is not None
        assert "Text mention found" in stop.content

    def test_invalid_config(self):
        with pytest.raises(ValueError):
            TextMentionTermination(text="")

    def test_message_without_content(self):
        # Test handling of messages that might not have content attribute (though our models should)
        term = TextMentionTermination(text="TEST")

        class EmptyMsg:
            pass

        assert term.check([EmptyMsg()]) is None  # type: ignore
