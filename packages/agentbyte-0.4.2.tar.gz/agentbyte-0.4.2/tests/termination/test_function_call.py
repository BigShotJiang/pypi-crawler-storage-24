import pytest
from agentbyte.termination.function_call import FunctionCallTermination
from agentbyte.messages import AssistantMessage, ToolCallRequest


class TestFunctionCallTermination:
    def test_function_call_detection(self):
        term = FunctionCallTermination(["transfer_to_human", "end_chat"])

        # Non-matching tool call
        msg1 = AssistantMessage(
            content="calling tool",
            source="agent",
            tool_calls=[
                ToolCallRequest(tool_name="get_weather", parameters={}, call_id="1")
            ],
        )
        assert term.check([msg1]) is None

        # Matching tool call
        msg2 = AssistantMessage(
            content="transferring",
            source="agent",
            tool_calls=[
                ToolCallRequest(
                    tool_name="transfer_to_human", parameters={}, call_id="2"
                )
            ],
        )
        stop = term.check([msg2])
        assert stop is not None
        assert "Target function called: 'transfer_to_human'" in stop.content
        assert term.is_met()

    def test_invalid_config(self):
        with pytest.raises(ValueError):
            FunctionCallTermination([])
