import pytest
from agentbyte.termination.handoff import HandoffTermination
from agentbyte.messages import AssistantMessage


class TestHandoffTermination:
    def test_handoff_detection(self):
        term = HandoffTermination()

        # No handoff
        assert (
            term.check(
                [AssistantMessage(content="I can help with that", source="agent")]
            )
            is None
        )

        # Default handoff keyword
        stop = term.check(
            [AssistantMessage(content="HANDOFF_TO: researcher", source="agent")]
        )
        assert stop is not None
        assert "Handoff detected" in stop.content
        assert stop.metadata["target_agent"] == "researcher"

    def test_custom_keyword(self):
        term = HandoffTermination(handoff_keyword="TRANSFER_TO")

        stop = term.check(
            [AssistantMessage(content="TRANSFER_TO: support", source="agent")]
        )
        assert stop is not None
        assert stop.metadata["target_agent"] == "support"

    def test_invalid_config(self):
        with pytest.raises(ValueError):
            HandoffTermination(handoff_keyword="")
