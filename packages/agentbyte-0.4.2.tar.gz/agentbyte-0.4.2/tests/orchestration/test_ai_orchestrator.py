from collections.abc import AsyncGenerator
from typing import Any, Dict, List, Optional, Union

import pytest

from agentbyte.agents.base import BaseAgent
from agentbyte.agents.types import AgentResponse, Usage
from agentbyte.context import AgentContext
from agentbyte.llm.base import BaseChatCompletionClient, BaseChatCompletionClientConfig
from agentbyte.llm.types import ChatCompletionChunk, ChatCompletionResult
from agentbyte.messages import AssistantMessage, Message, UserMessage
from agentbyte.orchestration.ai import AIOrchestrator, AgentSelection
from agentbyte.termination.max_message import MaxMessageTermination
from agentbyte.types import AgentSelectionEvent, OrchestrationResponse


class FakeSelectorConfig(BaseChatCompletionClientConfig):
    pass


class FakeSelectorClient(BaseChatCompletionClient):
    def __init__(
        self,
        responses: List[ChatCompletionResult],
        fail_on_calls: Optional[set[int]] = None,
    ) -> None:
        super().__init__(model="selector-fake", client=object())
        self._responses = responses
        self._index = 0
        self._fail_on_calls = fail_on_calls or set()

    async def create(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        self._index += 1
        if self._index in self._fail_on_calls:
            raise RuntimeError("selector failed")

        response = self._responses[self._index - 1]
        return response

    async def create_stream(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        yield ChatCompletionChunk(content="", model="selector-fake", is_complete=True)

    def _to_config(self) -> BaseChatCompletionClientConfig:
        return FakeSelectorConfig(model=self.model, config=self.config)

    @classmethod
    def _from_config(cls, config: BaseChatCompletionClientConfig) -> "FakeSelectorClient":
        return cls(responses=[])


class MockAgent(BaseAgent):
    def __init__(self, name: str, response_text: str):
        self.name = name
        self.description = f"Description of {name}"
        self.response_text = response_text
        self.tools = []

    async def run(
        self,
        task: Optional[Union[UserMessage, List[Message]]] = None,
        context: Optional[AgentContext] = None,
        cancellation_token: Optional[Any] = None,
    ) -> AgentResponse:
        raise NotImplementedError("Use run_stream")

    async def run_stream(
        self,
        task: Optional[Union[UserMessage, List[Message]]] = None,
        context: Optional[AgentContext] = None,
        cancellation_token: Optional[Any] = None,
        verbose: bool = False,
        stream_tokens: bool = False,
    ) -> AsyncGenerator[Union[Message, Any, AgentResponse], None]:
        ctx = context or AgentContext()

        if isinstance(task, UserMessage):
            yield task
            if not ctx.messages:
                ctx.messages.append(task)

        message = AssistantMessage(content=self.response_text, source=self.name)
        yield message

        ctx.messages.append(message)
        yield AgentResponse(
            source=self.name,
            context=ctx,
            usage=Usage(tokens_input=5, tokens_output=5, llm_calls=1),
            finish_reason="stop",
        )


def make_selection_result(
    agent_name: str,
    reasoning: str,
    tokens_input: int = 3,
    tokens_output: int = 1,
) -> ChatCompletionResult:
    return ChatCompletionResult(
        message=AssistantMessage(content="selection", source="selector"),
        usage=Usage(
            tokens_input=tokens_input,
            tokens_output=tokens_output,
            llm_calls=1,
        ),
        model="selector-fake",
        structured_output=AgentSelection(selected_agent=agent_name, reasoning=reasoning),
    )


@pytest.mark.asyncio
class TestAIOrchestrator:
    async def test_ai_selection_chooses_requested_agent(self):
        a1 = MockAgent("researcher", "research output")
        a2 = MockAgent("writer", "writer output")

        selector = FakeSelectorClient(
            responses=[
                make_selection_result("writer", "Need synthesis first"),
                make_selection_result("researcher", "Need additional facts"),
            ]
        )

        orchestrator = AIOrchestrator(
            agents=[a1, a2],
            termination=MaxMessageTermination(3),
            model_client=selector,
            max_iterations=3,
        )

        response = await orchestrator.run(UserMessage(content="start", source="user"))

        assert isinstance(response, OrchestrationResponse)
        assert response.messages[1].source == "writer"
        assert response.messages[2].source == "researcher"
        assert response.pattern_metadata["selector_calls"] == 2

    async def test_unknown_agent_falls_back_to_round_robin(self):
        a1 = MockAgent("researcher", "research output")
        a2 = MockAgent("writer", "writer output")

        selector = FakeSelectorClient(
            responses=[
                make_selection_result("ghost", "Wrong agent name"),
            ]
        )

        orchestrator = AIOrchestrator(
            agents=[a1, a2],
            termination=MaxMessageTermination(2),
            model_client=selector,
        )

        selection_events: List[AgentSelectionEvent] = []
        async for item in orchestrator.run_stream(
            UserMessage(content="start", source="user"),
            verbose=True,
        ):
            if isinstance(item, AgentSelectionEvent):
                selection_events.append(item)

        assert selection_events
        assert "Fallback round-robin selected 'researcher'" in selection_events[0].selection_reason

    async def test_selector_error_falls_back_to_round_robin(self):
        a1 = MockAgent("researcher", "research output")
        a2 = MockAgent("writer", "writer output")

        selector = FakeSelectorClient(
            responses=[make_selection_result("writer", "unused")],
            fail_on_calls={1},
        )

        orchestrator = AIOrchestrator(
            agents=[a1, a2],
            termination=MaxMessageTermination(2),
            model_client=selector,
        )

        response = await orchestrator.run(UserMessage(content="start", source="user"))

        assert isinstance(response, OrchestrationResponse)
        assert response.messages[1].source == "researcher"

    async def test_usage_includes_selector_calls(self):
        a1 = MockAgent("researcher", "research output")
        selector = FakeSelectorClient(
            responses=[make_selection_result("researcher", "Only agent", 7, 2)]
        )

        orchestrator = AIOrchestrator(
            agents=[a1],
            termination=MaxMessageTermination(2),
            model_client=selector,
        )

        response = await orchestrator.run(UserMessage(content="start", source="user"))

        assert response.usage.tokens_input == 12
        assert response.usage.tokens_output == 7
        assert response.usage.llm_calls == 2

    async def test_selection_supports_case_insensitive_agent_match(self):
        a1 = MockAgent("researcher", "research output")
        a2 = MockAgent("writer", "writer output")

        selector = FakeSelectorClient(
            responses=[make_selection_result("WRITER", "Need writing")]
        )

        orchestrator = AIOrchestrator(
            agents=[a1, a2],
            termination=MaxMessageTermination(2),
            model_client=selector,
        )

        response = await orchestrator.run(UserMessage(content="start", source="user"))

        assert response.messages[1].source == "writer"
