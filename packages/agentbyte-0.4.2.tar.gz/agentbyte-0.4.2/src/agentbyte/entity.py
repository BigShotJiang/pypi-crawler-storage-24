"""Base entity type for the Agentbyte framework."""

from __future__ import annotations

from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class Entity(BaseModel):
    """Base class for objects with a stable UUID identity."""

    id: UUID = Field(
        default_factory=uuid4,
        description="Unique entity identifier",
    )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, type(self)):
            return NotImplemented
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)


__all__ = ["Entity"]
