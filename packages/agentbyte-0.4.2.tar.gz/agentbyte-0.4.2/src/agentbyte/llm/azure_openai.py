"""
Azure OpenAI chat completion client implementation.

This module provides a concrete implementation of BaseChatCompletionClient
for Azure OpenAI's GPT models (GPT-4, GPT-3.5-turbo, etc.) deployed on Azure.

Design Pattern:
    Follows the Three-Step Conversion Pattern:
    1. Convert Agentbyte Message types to Azure OpenAI API format
    2. Make API call using the injected AsyncAzureOpenAI client
    3. Convert Azure OpenAI response back to unified ChatCompletionResult

Dependency Injection Pattern:
    User is responsible for:
    - Creating AsyncAzureOpenAI with authentication (API key, credential chain, etc.)
    - Configuring Azure endpoint, API version, deployment
    - Passing the fully-configured client to this wrapper

    This wrapper only needs:
    - `model`: Deployment name for API calls
    - `client`: The configured AsyncAzureOpenAI
    - `config`: Default LLM parameters
    - Retry logic: Transient error handling

Authentication Examples:
    Pattern 1 - API Key:
        >>> from openai import AsyncAzureOpenAI
        >>> azure_client = AsyncAzureOpenAI(
        ...     api_key="your-key",
        ...     azure_endpoint="https://myresource.openai.azure.com/",
        ...     api_version="2024-10-21",
        ...     azure_deployment="gpt-4-prod"
        ... )
        >>> llm = AzureOpenAIChatCompletionClient(
        ...     model="gpt-4-prod",
        ...     client=azure_client,
        ...     config={"temperature": 0.7}
        ... )

    Pattern 2 - DefaultAzureCredential (managed identity, CLI, environment):
        >>> from openai import AsyncAzureOpenAI
        >>> from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        >>> token_provider = get_bearer_token_provider(
        ...     DefaultAzureCredential(),
        ...     "https://cognitiveservices.azure.com/.default"
        ... )
        >>> azure_client = AsyncAzureOpenAI(
        ...     azure_ad_token_provider=token_provider,
        ...     azure_endpoint="https://myresource.openai.azure.com/",
        ...     api_version="2024-10-21",
        ...     azure_deployment="gpt-4-prod"
        ... )
        >>> llm = AzureOpenAIChatCompletionClient(
        ...     model="gpt-4-prod",
        ...     client=azure_client
        ... )

    Pattern 3 - Certificate-based authentication
        >>> # Implementation deferred to Phase 2
        >>> # Users construct AsyncAzureOpenAI with certificate credentials
        >>> # from app settings
"""

import asyncio
import json
import logging
import time
from collections.abc import AsyncGenerator
from typing import Any, Callable, Dict, List, Optional, TypeVar

from openai import AsyncAzureOpenAI

from agentbyte.messages import AssistantMessage, Message, ToolCallRequest

from agentbyte.component import Component

from .base import (
    BaseChatCompletionClient,
    BaseChatCompletionClientConfig,
    RateLimitError,
    AuthenticationError,
    InvalidRequestError,
)
from .pricing import PricingRegistry
from .types import (
    ChatCompletionChunk,
    ChatCompletionResult,
    ModelPricing,
    ModelClientError,
    Usage,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")


class AzureOpenAIChatCompletionClientConfig(BaseChatCompletionClientConfig):
    """
    Configuration for AzureOpenAIChatCompletionClient serialization.

    Captures settings needed to reconstruct an Azure OpenAI client.

    Attributes:
        model: Deployment name (e.g., "gpt-4-prod", "gpt-35-turbo-dev").
            When empty, resolved at load time from ``deployment_env_var``.
        config: Default configuration dict (temperature, max_tokens, etc.)
        max_retries: Maximum retry attempts for transient errors
        initial_retry_delay: Initial backoff delay in seconds
        max_retry_delay: Maximum backoff delay in seconds
        key_env_var: Env var holding the Azure API key (default: AZURE_OPENAI_API_KEY).
        deployment_env_var: Env var holding the deployment name.
        api_version_env_var: Env var holding the API version string.

    Note:
        The API key, endpoint, and API version are never stored as plaintext.
        Only the env-var names are serialized — secrets are resolved at load time.
    """
    max_retries: int = 3
    initial_retry_delay: float = 1.0
    max_retry_delay: float = 60.0
    key_env_var: str = "AZURE_OPENAI_API_KEY"
    deployment_env_var: str = "AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"
    api_version_env_var: str = "AZURE_OPENAI_API_VERSION"


class AzureOpenAIChatCompletionClient(
    BaseChatCompletionClient,
    Component[AzureOpenAIChatCompletionClientConfig],
):
    """
    Azure OpenAI chat completion client implementation.

    Supports Azure-deployed GPT-4, GPT-4 Turbo, GPT-3.5-turbo, and other OpenAI models
    with streaming, function calling, and vision capabilities.

    Strict Dependency Injection Pattern:
        The user creates and fully configures AsyncAzureOpenAI with:
        - Authentication (API key, DefaultAzureCredential, certificates, etc.)
        - Azure endpoint URL
        - API version
        - Any other OpenAI SDK configuration (proxies, timeouts, etc.)
        
        Then injects the configured client here. This enforces:
        - Separation of concerns: User owns transport/auth, we own agent patterns
        - Enterprise flexibility: Support any authentication method
        - Testability: Mock clients can be injected for testing
        - No credential hardcoding: Credentials managed externally

    Minimal Wrapper:
        The wrapper only needs:
        - `model`: Deployment name to use in API calls
        - `client`: Pre-configured AsyncAzureOpenAI
        - `config`: Default LLM parameters (temperature, max_tokens, etc.)
        - Retry logic: Exponential backoff for transient errors

    Features:
        - Automatic retry logic with exponential backoff for transient errors
        - Support for function calling / tool use
        - Streaming for real-time token delivery
        - Vision capabilities through OpenAI SDK
    """

    component_type = "model_client"
    component_config_schema = AzureOpenAIChatCompletionClientConfig
    component_provider_override = "agentbyte.llm.AzureOpenAIChatCompletionClient"

    def __init__(
        self,
        model: str,
        client: AsyncAzureOpenAI,
        config: Optional[Dict[str, Any]] = None,
        model_pricing: Optional[ModelPricing] = None,
        max_retries: int = 3,
        initial_retry_delay: float = 1.0,
        max_retry_delay: float = 60.0,
    ):
        """
        Initialize Azure OpenAI client with pre-configured dependency.

        Args:
            model: Deployment name to use in API calls
                   This is what gets passed as the `model` parameter to Azure OpenAI API.
                   Example: "gpt-4-prod"
            
            client: Pre-configured AsyncAzureOpenAI HTTP client (REQUIRED)
                   User must create this with their preferred authentication and Azure config:
                   
                   Example with API Key:
                       >>> from openai import AsyncAzureOpenAI
                       >>> azure_client = AsyncAzureOpenAI(
                       ...     api_key="your-key",
                       ...     azure_endpoint="https://myresource.openai.azure.com/",
                       ...     api_version="2024-10-21",
                       ...     azure_deployment="gpt-4-prod"
                       ... )
                   
                   Example with DefaultAzureCredential:
                       >>> from azure.identity import DefaultAzureCredential, get_bearer_token_provider
                       >>> token_provider = get_bearer_token_provider(
                       ...     DefaultAzureCredential(),
                       ...     "https://cognitiveservices.azure.com/.default"
                       ... )
                       >>> azure_client = AsyncAzureOpenAI(
                       ...     azure_ad_token_provider=token_provider,
                       ...     azure_endpoint="https://myresource.openai.azure.com/",
                       ...     api_version="2024-10-21",
                       ...     azure_deployment="gpt-4-prod"
                       ... )
            
            config: Default LLM configuration dict (optional)
                   Applied to all API calls, can be overridden per-call.
                   Example: {"temperature": 0.7, "max_tokens": 2000}
            
            max_retries: Maximum retry attempts for transient errors (default: 3)
            
            initial_retry_delay: Initial backoff delay in seconds (default: 1.0)
            
            max_retry_delay: Maximum backoff delay in seconds (default: 60.0)

        Example:
            >>> from openai import AsyncAzureOpenAI
            >>> from agentbyte.llm import AzureOpenAIChatCompletionClient, UserMessage
            >>> 
            >>> # 1. User creates and configures Azure client (handles all auth/endpoint config)
            >>> azure_client = AsyncAzureOpenAI(
            ...     api_key="your-key",
            ...     azure_endpoint="https://myresource.openai.azure.com/",
            ...     api_version="2024-10-21",
            ...     azure_deployment="gpt-4-prod"
            ... )
            >>> 
            >>> # 2. Inject configured client into agentbyte wrapper
            >>> llm = AzureOpenAIChatCompletionClient(
            ...     model="gpt-4-prod",  # Deployment name for API calls
            ...     client=azure_client,  # Pre-configured with endpoint, auth, version
            ...     config={"temperature": 0.7}
            ... )
            >>> 
            >>> # 3. Use it
            >>> result = await llm.create(
            ...     messages=[UserMessage(content="Hello")]
            ... )
        """
        super().__init__(model, client, config)
        self.model_pricing = model_pricing
        self.max_retries = max_retries
        self.initial_retry_delay = initial_retry_delay
        self.max_retry_delay = max_retry_delay

    # ── Factory classmethods ────────────────────────────────────────────────────

    @classmethod
    def from_api_key(
        cls,
        model: Optional[str] = None,
        api_version: Optional[str] = None,
        api_key: Optional[str] = None,
        service_settings: Optional[Any] = None,
        config: Optional[Dict[str, Any]] = None,
        model_pricing: Optional[ModelPricing] = None,
        max_retries: int = 3,
        initial_retry_delay: float = 1.0,
        max_retry_delay: float = 60.0,
    ) -> "AzureOpenAIChatCompletionClient":
        """
        Create a client using an Azure OpenAI API key.

        Resolution order for each optional arg (explicit arg → env → ValueError):
        - ``model``       → ``AZURE_OPENAI_CHAT_DEPLOYMENT_NAME``
        - ``api_version`` → ``AZURE_OPENAI_API_VERSION``
        - ``api_key``     → ``AZURE_OPENAI_API_KEY``
        - ``endpoint``    → ``AZURE_OPENAI_ENDPOINT`` (always required in settings)

        Args:
            model:            Deployment name. Falls back to ``AZURE_OPENAI_CHAT_DEPLOYMENT_NAME``.
            api_version:      API version string. Falls back to ``AZURE_OPENAI_API_VERSION``.
            api_key:          API key. Falls back to ``AZURE_OPENAI_API_KEY``.
            service_settings: Pre-built ``AzureOpenAISettings``. Auto-loaded if omitted.
            config:           Default LLM params (temperature, max_tokens, etc.).
            max_retries:      Retry attempts for transient errors (default: 3).
            initial_retry_delay: Initial backoff delay in seconds (default: 1.0).
            max_retry_delay:  Maximum backoff delay in seconds (default: 60.0).

        Raises:
            ValueError: When endpoint, api_version, model, or api_key cannot be resolved.

        Example:
            >>> # All from env:
            >>> client = AzureOpenAIChatCompletionClient.from_api_key()
            >>> # Explicit args override env:
            >>> client = AzureOpenAIChatCompletionClient.from_api_key(
            ...     model="gpt-4.1-mini",
            ...     api_version="2024-10-21",
            ...     config={"temperature": 0.1},
            ... )
        """
        from .settings import AzureOpenAISettings
        from pydantic import ValidationError

        try:
            svc = service_settings or AzureOpenAISettings()
        except ValidationError as exc:
            raise ValueError(
                "Azure OpenAI service settings incomplete. Ensure AZURE_OPENAI_ENDPOINT "
                "is set, or pass service_settings= explicitly."
            ) from exc

        resolved_model = model or svc.chat_deployment_name
        if not resolved_model:
            raise ValueError(
                "No deployment name provided. Pass model= explicitly or set "
                "AZURE_OPENAI_CHAT_DEPLOYMENT_NAME."
            )

        resolved_version = api_version or svc.api_version
        if not resolved_version:
            raise ValueError(
                "No API version provided. Pass api_version= explicitly or set "
                "AZURE_OPENAI_API_VERSION."
            )

        resolved_key = api_key or (
            svc.api_key.get_secret_value() if svc.api_key else None
        )
        if not resolved_key:
            raise ValueError(
                "No Azure OpenAI API key provided. Pass api_key= explicitly, set "
                "AZURE_OPENAI_API_KEY, or use a different auth method."
            )

        azure_client = AsyncAzureOpenAI(
            api_key=resolved_key,
            azure_endpoint=svc.endpoint,
            api_version=resolved_version,
        )
        return cls(
            model=resolved_model,
            client=azure_client,
            config=config,
            model_pricing=model_pricing,
            max_retries=max_retries,
            initial_retry_delay=initial_retry_delay,
            max_retry_delay=max_retry_delay,
        )

    @classmethod
    def from_default_credential(
        cls,
        model: Optional[str] = None,
        api_version: Optional[str] = None,
        service_settings: Optional[Any] = None,
        scope: str = "https://cognitiveservices.azure.com/.default",
        config: Optional[Dict[str, Any]] = None,
        model_pricing: Optional[ModelPricing] = None,
        max_retries: int = 3,
        initial_retry_delay: float = 1.0,
        max_retry_delay: float = 60.0,
    ) -> "AzureOpenAIChatCompletionClient":
        """
        Create a client using ``DefaultAzureCredential`` (managed identity, CLI, env, etc.).

        Tries multiple credential sources automatically in order:
        managed identity → Azure CLI → environment variables → workload identity.
        Recommended for production deployments where no secret management is needed.

        Requires: ``azure-identity`` package.

        Resolution order for optional args (explicit arg → env → ValueError):
        - ``model``       → ``AZURE_OPENAI_CHAT_DEPLOYMENT_NAME``
        - ``api_version`` → ``AZURE_OPENAI_API_VERSION``

        Args:
            model:            Deployment name. Falls back to ``AZURE_OPENAI_CHAT_DEPLOYMENT_NAME``.
            api_version:      API version string. Falls back to ``AZURE_OPENAI_API_VERSION``.
            service_settings: Pre-built ``AzureOpenAISettings``. Auto-loaded if omitted.
            scope:            Azure AD token scope (default: Cognitive Services).
            config:           Default LLM params.
            max_retries:      Retry attempts for transient errors (default: 3).
            initial_retry_delay: Initial backoff delay in seconds (default: 1.0).
            max_retry_delay:  Maximum backoff delay in seconds (default: 60.0).

        Raises:
            ImportError: When ``azure-identity`` is not installed.
            ValueError:  When model, api_version, or Azure service settings cannot be resolved.

        Example:
            >>> # All from env:
            >>> client = AzureOpenAIChatCompletionClient.from_default_credential()
            >>> # Explicit args override env:
            >>> client = AzureOpenAIChatCompletionClient.from_default_credential(
            ...     model="gpt-4.1-mini",
            ...     api_version="2024-10-21",
            ...     config={"temperature": 0.1},
            ... )
        """
        try:
            from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        except ImportError as exc:
            raise ImportError(
                "azure-identity is required for from_default_credential(). "
                "Install it with: pip install azure-identity"
            ) from exc

        from .settings import AzureOpenAISettings
        from pydantic import ValidationError

        try:
            svc = service_settings or AzureOpenAISettings()
        except ValidationError as exc:
            raise ValueError(
                "Azure OpenAI service settings incomplete. Ensure AZURE_OPENAI_ENDPOINT "
                "is set, or pass service_settings= explicitly."
            ) from exc

        resolved_model = model or svc.chat_deployment_name
        if not resolved_model:
            raise ValueError(
                "No deployment name provided. Pass model= explicitly or set "
                "AZURE_OPENAI_CHAT_DEPLOYMENT_NAME."
            )

        resolved_version = api_version or svc.api_version
        if not resolved_version:
            raise ValueError(
                "No API version provided. Pass api_version= explicitly or set "
                "AZURE_OPENAI_API_VERSION."
            )

        token_provider = get_bearer_token_provider(DefaultAzureCredential(), scope)
        azure_client = AsyncAzureOpenAI(
            azure_ad_token_provider=token_provider,
            azure_endpoint=svc.endpoint,
            api_version=resolved_version,
        )
        return cls(
            model=resolved_model,
            client=azure_client,
            config=config,
            model_pricing=model_pricing,
            max_retries=max_retries,
            initial_retry_delay=initial_retry_delay,
            max_retry_delay=max_retry_delay,
        )

    @classmethod
    def from_certificate(
        cls,
        model: Optional[str] = None,
        api_version: Optional[str] = None,
        service_settings: Optional[Any] = None,
        principal_settings: Optional[Any] = None,
        scope: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        model_pricing: Optional[ModelPricing] = None,
        max_retries: int = 3,
        initial_retry_delay: float = 1.0,
        max_retry_delay: float = 60.0,
    ) -> "AzureOpenAIChatCompletionClient":
        """
        Create a client using certificate-based Azure AD service principal auth.

        Reads all identity fields from ``AzureServicePrincipalSettings`` (auto-loaded
        from env vars unless ``principal_settings`` is provided explicitly). The scope
        defaults to ``AzureServicePrincipalSettings.cognitive_scope``.

        Resolution order for optional args (explicit arg → env → ValueError):
        - ``model``       → ``AZURE_OPENAI_CHAT_DEPLOYMENT_NAME``
        - ``api_version`` → ``AZURE_OPENAI_API_VERSION``

        Args:
            model:               Deployment name. Falls back to ``AZURE_OPENAI_CHAT_DEPLOYMENT_NAME``.
            api_version:         API version string. Falls back to ``AZURE_OPENAI_API_VERSION``.
            service_settings:    Pre-built ``AzureOpenAISettings``. Auto-loaded if omitted.
            principal_settings:  Pre-built ``AzureServicePrincipalSettings``. Auto-loaded if omitted.
            scope:               Azure AD token scope. Defaults to ``principal_settings.cognitive_scope``.
            config:              Default LLM params.
            max_retries:         Retry attempts for transient errors (default: 3).
            initial_retry_delay: Initial backoff delay in seconds (default: 1.0).
            max_retry_delay:     Maximum backoff delay in seconds (default: 60.0).

        Raises:
            ValueError: When model, api_version, or service/principal settings cannot be resolved.

        Example:
            >>> # All from env:
            >>> client = AzureOpenAIChatCompletionClient.from_certificate()
            >>> # Explicit args override env:
            >>> client = AzureOpenAIChatCompletionClient.from_certificate(
            ...     model="gpt-4.1-mini",
            ...     api_version="2024-10-21",
            ...     config={"temperature": 0.1},
            ... )
        """
        from .settings import AzureOpenAISettings, AzureServicePrincipalSettings
        from .auth import get_certificate_token_provider
        from pydantic import ValidationError

        try:
            svc = service_settings or AzureOpenAISettings()
        except ValidationError as exc:
            raise ValueError(
                "Azure OpenAI service settings incomplete. Ensure AZURE_OPENAI_ENDPOINT "
                "is set, or pass service_settings= explicitly."
            ) from exc

        try:
            sp = principal_settings or AzureServicePrincipalSettings()
        except ValidationError as exc:
            raise ValueError(
                "Azure service principal settings incomplete. Ensure AZURE_TENANT_ID, "
                "AZURE_CLIENT_ID, AZURE_COGNITIVE_SCOPE, AZURE_CLIENT_CERTIFICATE_SECRET, "
                "and AZURE_CLIENT_PRIVATE_KEY_SECRET are set, or pass principal_settings= explicitly."
            ) from exc

        resolved_model = model or svc.chat_deployment_name
        if not resolved_model:
            raise ValueError(
                "No deployment name provided. Pass model= explicitly or set "
                "AZURE_OPENAI_CHAT_DEPLOYMENT_NAME."
            )

        resolved_version = api_version or svc.api_version
        if not resolved_version:
            raise ValueError(
                "No API version provided. Pass api_version= explicitly or set "
                "AZURE_OPENAI_API_VERSION."
            )

        resolved_scope = scope or sp.cognitive_scope
        token_provider = get_certificate_token_provider(
            tenant_id=sp.tenant_id,
            client_id=sp.client_id,
            certificate_data=sp.certificate_data,
            scope=resolved_scope,
        )
        azure_client = AsyncAzureOpenAI(
            azure_ad_token_provider=token_provider,
            azure_endpoint=svc.endpoint,
            api_version=resolved_version,
        )
        return cls(
            model=resolved_model,
            client=azure_client,
            config=config,
            model_pricing=model_pricing,
            max_retries=max_retries,
            initial_retry_delay=initial_retry_delay,
            max_retry_delay=max_retry_delay,
        )

    @classmethod
    def from_ad_token(
        cls,
        ad_token: str,
        model: Optional[str] = None,
        api_version: Optional[str] = None,
        service_settings: Optional[Any] = None,
        config: Optional[Dict[str, Any]] = None,
        model_pricing: Optional[ModelPricing] = None,
        max_retries: int = 3,
        initial_retry_delay: float = 1.0,
        max_retry_delay: float = 60.0,
    ) -> "AzureOpenAIChatCompletionClient":
        """
        Create a client using a pre-fetched Azure AD bearer token.

        Useful for batch operations or high-frequency calls within one token lifetime
        where you want to avoid repeated token acquisition overhead. The token must
        be obtained externally (e.g. from ``AzureServicePrincipalSettings.certificate_data``
        + ``get_certificate_token_provider()``).

        Resolution order for optional args (explicit arg → env → ValueError):
        - ``model``       → ``AZURE_OPENAI_CHAT_DEPLOYMENT_NAME``
        - ``api_version`` → ``AZURE_OPENAI_API_VERSION``

        Args:
            ad_token:         Pre-fetched Azure AD bearer token string (required).
            model:            Deployment name. Falls back to ``AZURE_OPENAI_CHAT_DEPLOYMENT_NAME``.
            api_version:      API version string. Falls back to ``AZURE_OPENAI_API_VERSION``.
            service_settings: Pre-built ``AzureOpenAISettings``. Auto-loaded if omitted.
            config:           Default LLM params.
            max_retries:      Retry attempts for transient errors (default: 3).
            initial_retry_delay: Initial backoff delay in seconds (default: 1.0).
            max_retry_delay:  Maximum backoff delay in seconds (default: 60.0).

        Raises:
            ValueError: When model, api_version, or service settings cannot be resolved.

        Example:
            >>> # All from env:
            >>> client = AzureOpenAIChatCompletionClient.from_ad_token(ad_token=token)
            >>> # Explicit overrides:
            >>> token = cert_token_provider()   # from get_certificate_token_provider()
            >>> client = AzureOpenAIChatCompletionClient.from_ad_token(
            ...     ad_token=token,
            ...     model="gpt-4.1-mini",
            ...     api_version="2024-10-21",
            ...     config={"temperature": 0.1},
            ... )
        """
        from .settings import AzureOpenAISettings
        from pydantic import ValidationError

        try:
            svc = service_settings or AzureOpenAISettings()
        except ValidationError as exc:
            raise ValueError(
                "Azure OpenAI service settings incomplete. Ensure AZURE_OPENAI_ENDPOINT "
                "is set, or pass service_settings= explicitly."
            ) from exc

        resolved_model = model or svc.chat_deployment_name
        if not resolved_model:
            raise ValueError(
                "No deployment name provided. Pass model= explicitly or set "
                "AZURE_OPENAI_CHAT_DEPLOYMENT_NAME."
            )

        resolved_version = api_version or svc.api_version
        if not resolved_version:
            raise ValueError(
                "No API version provided. Pass api_version= explicitly or set "
                "AZURE_OPENAI_API_VERSION."
            )

        azure_client = AsyncAzureOpenAI(
            azure_ad_token=ad_token,
            azure_endpoint=svc.endpoint,
            api_version=resolved_version,
        )
        return cls(
            model=resolved_model,
            client=azure_client,
            config=config,
            model_pricing=model_pricing,
            max_retries=max_retries,
            initial_retry_delay=initial_retry_delay,
            max_retry_delay=max_retry_delay,
        )

    async def _retry_with_backoff(
        self, func: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> Any:
        """
        Execute a function with exponential backoff retry logic.

        Retries on transient errors (RateLimitError, generic API errors).
        Does NOT retry on authentication or request validation errors.

        Args:
            func: Async function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function

        Returns:
            Function result

        Raises:
            The original exception if all retries are exhausted or error is non-transient

        Implementation Notes:
            - RateLimitError: Always transient, always retried
            - ModelClientError: Transient, retried (e.g., temporary API issues)
            - AuthenticationError: Non-transient, never retried
            - InvalidRequestError: Non-transient, never retried
            - Uses exponential backoff: delay *= 2, capped at max_retry_delay
        """
        last_exception = None
        current_delay = self.initial_retry_delay

        for attempt in range(self.max_retries + 1):
            try:
                return await func(*args, **kwargs)
            except (RateLimitError, ModelClientError) as e:
                # RateLimitError and generic ModelClientError are transient
                last_exception = e

                if attempt >= self.max_retries:
                    logger.warning(
                        f"Max retries ({self.max_retries}) reached for {func.__name__}"
                    )
                    raise

                # Log retry attempt
                logger.debug(
                    f"Transient error in {func.__name__} (attempt {attempt + 1}/{self.max_retries + 1}): {str(e)}. "
                    f"Retrying in {current_delay:.1f}s"
                )

                # Wait before retry with exponential backoff
                await asyncio.sleep(current_delay)
                current_delay = min(current_delay * 2, self.max_retry_delay)

            except (AuthenticationError, InvalidRequestError) as e:
                # Non-transient errors: don't retry
                logger.error(f"Non-transient error in {func.__name__}: {str(e)}")
                raise

            except Exception as e:
                # Unknown errors: don't retry
                logger.error(f"Unexpected error in {func.__name__}: {str(e)}")
                raise

        # Should not reach here, but just in case
        raise last_exception or ModelClientError("Retry logic error")

    async def _retry_stream_with_backoff(
        self, func: Callable[..., AsyncGenerator[ChatCompletionChunk, None]], *args: Any, **kwargs: Any
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Execute a streaming function with exponential backoff retry logic.

        Retries are only attempted if the stream fails before yielding any chunks
        to avoid duplicating partial output.
        """
        current_delay = self.initial_retry_delay

        for attempt in range(self.max_retries + 1):
            saw_chunk = False
            try:
                async for chunk in func(*args, **kwargs):
                    saw_chunk = True
                    yield chunk
                return
            except (RateLimitError, ModelClientError) as e:
                if saw_chunk or attempt >= self.max_retries:
                    raise
                logger.debug(
                    f"Transient stream error in {func.__name__} (attempt {attempt + 1}/{self.max_retries + 1}): {str(e)}. "
                    f"Retrying in {current_delay:.1f}s"
                )
                await asyncio.sleep(current_delay)
                current_delay = min(current_delay * 2, self.max_retry_delay)
            except (AuthenticationError, InvalidRequestError):
                raise

    async def create(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Make a single Azure OpenAI API call.

        Follows the Three-Step Conversion Pattern:
        1. Convert Agentbyte messages to Azure OpenAI format
        2. Call Azure OpenAI API with the injected client
        3. Parse response and convert back to unified format

        Args:
            messages: Conversation history with Agentbyte Message types
            tools: Optional list of tool/function schemas for function calling
            output_format: Optional Pydantic model for structured output validation
                          The model will attempt to parse the response as JSON
                          and validate it against this schema
            **kwargs: Azure OpenAI-specific parameters that override self.config
                     (temperature, max_tokens, top_p, frequency_penalty, etc.)

        Returns:
            ChatCompletionResult with:
            - message: AssistantMessage with content and optional tool_calls
            - usage: Token consumption statistics
            - model: Model used
            - metadata: Provider-specific data (finish_reason, etc.)
            - structured_output: Parsed output if output_format was provided (optional)

        Raises:
            RateLimitError: Azure OpenAI rate limits exceeded
            AuthenticationError: Invalid API key or credentials
            InvalidRequestError: Request format is invalid
            ModelClientError: Other API errors

        Implementation Notes:
            - Merges self.config with kwargs (kwargs takes precedence)
            - Handles tool calls in response and creates ToolCall objects
            - Extracts usage statistics for cost tracking
            - Automatically retries transient errors with exponential backoff
            - Structured output uses Azure OpenAI Structured Outputs API
            - If structured output parsing fails, continues with text response
        """
        try:
            # Delegate to retry wrapper
            return await self._retry_with_backoff(
                self._create_internal, messages, tools, output_format, **kwargs
            )

        except Exception as e:
            # Convert Azure OpenAI exceptions to unified error hierarchy
            self._handle_error(e)

    async def _create_internal(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Internal create implementation (handles API call, gets retried by wrapper).

        This is the actual API call that gets wrapped by retry logic.

        Args:
            messages: Conversation history
            tools: Optional tool definitions
            output_format: Optional Pydantic model for structured output
            **kwargs: Additional Azure OpenAI parameters

        Returns:
            ChatCompletionResult

        Raises:
            Azure OpenAI exceptions (converted by caller)
        """
        # Merge configuration: base config + request-specific kwargs
        api_kwargs = {**self.config, **kwargs}

        # Step 1: Convert internal Message types to Azure OpenAI format
        api_messages = self._convert_messages_to_api_format(messages)

        # Handle structured output if requested
        structured_output = None
        if output_format:
            try:
                # Convert Pydantic model to JSON schema for Azure OpenAI
                schema = output_format.model_json_schema()
                
                # Ensure Azure OpenAI Structured Outputs compatibility
                schema = self._make_schema_compatible(schema)
                
                # Add response_format to request
                api_kwargs["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": schema.get("title", output_format.__name__),
                        "description": schema.get(
                            "description",
                            f"Structured output for {output_format.__name__}",
                        ),
                        "strict": True,
                        "schema": schema,
                    },
                }
            except Exception as e:
                # If schema conversion fails, log warning but continue
                logger.warning(
                    f"Failed to convert {output_format.__name__} to JSON schema: {e}. "
                    f"Continuing without structured output."
                )

        # Step 2: Make API call using the injected client
        # Pass model (which is the deployment name)
        start_time = time.perf_counter()
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            tools=tools,
            **api_kwargs,
        )
        duration_ms = int((time.perf_counter() - start_time) * 1000)

        # Step 3: Parse response and convert to unified format
        choice = response.choices[0]
        message_content = choice.message.content or ""

        # Handle tool calls if present
        tool_calls = None
        if choice.message.tool_calls:
            tool_calls = [
                ToolCallRequest(
                    call_id=tc.id,
                    tool_name=tc.function.name,
                    parameters=json.loads(tc.function.arguments),
                )
                for tc in choice.message.tool_calls
            ]

        # Parse structured output if requested
        if output_format and message_content:
            try:
                structured_output = output_format.model_validate_json(message_content)
            except Exception as e:
                logger.warning(
                    f"Failed to parse structured output: {e}. Using raw content."
                )
                structured_output = None

        return ChatCompletionResult(
            message=AssistantMessage(
                content=message_content,
                source=self.model,
                tool_calls=tool_calls,
            ),
            usage=Usage(
                duration_ms=duration_ms,
                llm_calls=1,
                tokens_input=response.usage.prompt_tokens,
                tokens_output=response.usage.completion_tokens,
                tool_calls=len(tool_calls) if tool_calls else 0,
                cost_estimate=self._estimate_cost(
                    response.usage.prompt_tokens,
                    response.usage.completion_tokens,
                )
            ),
            model=response.model,
            metadata={
                "finish_reason": choice.finish_reason,
            },
            finish_reason=choice.finish_reason,
            structured_output=structured_output,
        )

    async def create_stream(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        stream_options: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Make a streaming Azure OpenAI API call.

        Yields response chunks as they arrive from the API, enabling real-time
        updates and reduced time-to-first-token perception.

        Args:
            messages: Conversation history with Agentbyte Message types
            tools: Optional list of tool/function schemas
            stream_options: Optional stream options (defaults to include usage when omitted)
            **kwargs: Azure OpenAI-specific parameters that override self.config

        Yields:
            ChatCompletionChunk with:
            - content: Partial text content from this chunk
            - model: Model name
            - metadata: Provider-specific data (finish_reason for final chunk)

        Raises:
            Same exception hierarchy as create()

        Implementation Notes:
            - Enables stream=True on Azure OpenAI API call
            - Yields chunks as they arrive
            - Final chunk may have empty content but includes finish_reason
            - Accumulate chunks by concatenating .content for full response
            - Includes retry logic for transient errors (rate limits, API errors)
            - Note: Entire stream is retried as a unit if transient error occurs
            - Structured output not supported in streaming (Azure limitation)
        """
        try:
            async for chunk in self._retry_stream_with_backoff(
                self._create_stream_internal,
                messages,
                tools,
                output_format,
                stream_options,
                **kwargs,
            ):
                yield chunk

        except Exception as e:
            # Convert exceptions to unified error hierarchy
            self._handle_error(e)

    async def _create_stream_internal(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        stream_options: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Internal streaming implementation (handles API call, gets retried by wrapper).

        This is the actual streaming API call that gets wrapped by retry logic.

        Args:
            messages: Conversation history
            tools: Optional tool definitions
            **kwargs: Additional Azure OpenAI parameters

        Yields:
            ChatCompletionChunk objects

        Raises:
            Azure OpenAI exceptions (converted by caller)
        """
        # Merge configuration
        api_kwargs = {**self.config, **kwargs}
        if "stream_options" in api_kwargs and stream_options is None:
            stream_options = api_kwargs.pop("stream_options")
        else:
            api_kwargs.pop("stream_options", None)
        if stream_options is None:
            stream_options = {"include_usage": True}
        if stream_options:
            api_kwargs["stream_options"] = stream_options

        # Convert messages to Azure OpenAI format
        api_messages = self._convert_messages_to_api_format(messages)

        # Make streaming API call
        start_time = time.perf_counter()
        stream = await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            tools=tools,
            stream=True,  # Enable streaming
            **api_kwargs,
        )

        tool_call_chunks: Dict[Any, Dict[str, Any]] = {}

        # Yield chunks as they arrive
        async for chunk in stream:
            # Usage-only chunk (final chunk when include_usage=true)
            if hasattr(chunk, "usage") and chunk.usage and (not chunk.choices or len(chunk.choices) == 0):
                duration_ms = int((time.perf_counter() - start_time) * 1000)
                usage = Usage(
                    duration_ms=duration_ms,
                    llm_calls=1,
                    tokens_input=chunk.usage.prompt_tokens,
                    tokens_output=chunk.usage.completion_tokens,
                    cost_estimate=self._estimate_cost(
                        chunk.usage.prompt_tokens,
                        chunk.usage.completion_tokens,
                    ),
                )
                yield ChatCompletionChunk(
                    content="",
                    model=chunk.model,
                    is_complete=True,
                    tool_call_chunk=None,
                    usage=usage,
                    metadata={},
                )
                break

            if not chunk.choices:
                continue

            chunk_choice = chunk.choices[0]
            delta = chunk_choice.delta

            # Content chunks
            if delta.content:
                yield ChatCompletionChunk(
                    content=delta.content,
                    model=chunk.model,
                    is_complete=False,
                    tool_call_chunk=None,
                    usage=None,
                    metadata={
                        "finish_reason": chunk_choice.finish_reason,
                    },
                )

            # Tool call chunks
            if delta.tool_calls:
                for tc_delta in delta.tool_calls:
                    index = getattr(tc_delta, "index", None)
                    call_id = tc_delta.id
                    tracking_key = index if index is not None else call_id

                    if tracking_key not in tool_call_chunks:
                        tool_call_chunks[tracking_key] = {
                            "id": call_id,
                            "function": {"name": "", "arguments": ""},
                        }

                    if call_id:
                        tool_call_chunks[tracking_key]["id"] = call_id

                    if tc_delta.function:
                        if tc_delta.function.name:
                            tool_call_chunks[tracking_key]["function"]["name"] = tc_delta.function.name
                        if tc_delta.function.arguments:
                            tool_call_chunks[tracking_key]["function"]["arguments"] += tc_delta.function.arguments

                    yield ChatCompletionChunk(
                        content="",
                        model=chunk.model,
                        is_complete=False,
                        tool_call_chunk=tool_call_chunks[tracking_key],
                        usage=None,
                        metadata={},
                    )

            # If stream ends without usage chunks, emit completion marker
            if chunk_choice.finish_reason and not stream_options.get("include_usage"):
                yield ChatCompletionChunk(
                    content="",
                    model=chunk.model,
                    is_complete=True,
                    tool_call_chunk=None,
                    usage=None,
                    metadata={"finish_reason": chunk_choice.finish_reason},
                )

    def _make_schema_compatible(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Modify JSON schema to be compatible with Azure OpenAI Structured Outputs.

       Azure OpenAI's Structured Outputs require certain schema constraints:
        - Object types must have additionalProperties=False
        - All properties must be defined in the schema
        - Schemas must be strict and unambiguous

        Args:
            schema: The JSON schema to make compatible

        Returns:
            Modified schema with Azure OpenAI compatibility fixes
        """
        # Recursively walk the full schema tree (including $defs / allOf / anyOf / oneOf)
        # and enforce Azure OpenAI requirement: object schemas must set additionalProperties=False.
        compatible_schema: Dict[str, Any] = {}
        for key, value in schema.items():
            if isinstance(value, dict):
                compatible_schema[key] = self._make_schema_compatible(value)
            elif isinstance(value, list):
                compatible_schema[key] = [
                    self._make_schema_compatible(item) if isinstance(item, dict) else item
                    for item in value
                ]
            else:
                compatible_schema[key] = value

        if compatible_schema.get("type") == "object":
            compatible_schema["additionalProperties"] = False

        return compatible_schema

    def _estimate_cost(self, prompt_tokens: int, completion_tokens: int) -> float:
        """
        Estimate the cost of the API call based on token usage.

        Uses current Azure OpenAI pricing for different model families.
        Note: These are approximate rates and may not reflect real-time changes.
        Azure pricing differs from standard OpenAI pricing.

        Args:
            prompt_tokens: Number of tokens in the prompt
            completion_tokens: Number of tokens generated

        Returns:
            Estimated cost in USD

        Pricing is resolved from PricingRegistry for Azure OpenAI; user-provided pricing always takes precedence.
        Unknown models trigger a warning and fall back to GPT-4 pricing.

        Note:
            Azure pricing is typically lower than standard OpenAI pricing.
            For production, validate pricing against your Azure account.
        """
        # User-provided pricing always takes precedence
        if self.model_pricing is not None:
            pricing = self.model_pricing
        else:
            # Resolve from registry (warns if not found, uses default GPT-4 pricing)
            pricing = PricingRegistry.resolve_azure_chat_pricing(self.model)

        return pricing.calculate_cost(prompt_tokens, completion_tokens)

    def _to_config(self) -> AzureOpenAIChatCompletionClientConfig:
        """Serialize to config. Env-var names are stored; secrets are never written."""
        return AzureOpenAIChatCompletionClientConfig(
            model=self.model,
            config=self.config.copy(),
            max_retries=self.max_retries,
            initial_retry_delay=self.initial_retry_delay,
            max_retry_delay=self.max_retry_delay,
            key_env_var=getattr(self, "_key_env_var", "AZURE_OPENAI_API_KEY"),
            deployment_env_var=getattr(self, "_deployment_env_var", "AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"),
            api_version_env_var=getattr(self, "_api_version_env_var", "AZURE_OPENAI_API_VERSION"),
        )

    @classmethod
    def _from_config(cls, config: AzureOpenAIChatCompletionClientConfig) -> "AzureOpenAIChatCompletionClient":
        """
        Reconstruct client from saved config.

        All secrets (API key, endpoint, API version) are resolved at load time
        from the environment variables named in the config.  Credentials are
        never stored on disk.

        Raises:
            ValueError: When a required environment variable is not set.
        """
        import os
        resolved_key = os.environ.get(config.key_env_var)
        if not resolved_key:
            raise ValueError(
                f"Cannot reconstruct AzureOpenAIChatCompletionClient: environment variable "
                f"'{config.key_env_var}' is not set."
            )
        # Use from_api_key which resolves endpoint/api_version from env automatically
        instance = cls.from_api_key(
            model=config.model if config.model != "gpt-4.1-mini" else None,
            api_key=resolved_key,
            config=config.config or None,
            max_retries=config.max_retries,
            initial_retry_delay=config.initial_retry_delay,
            max_retry_delay=config.max_retry_delay,
        )
        instance._key_env_var = config.key_env_var
        instance._deployment_env_var = config.deployment_env_var
        instance._api_version_env_var = config.api_version_env_var
        return instance

    def _handle_error(self, error: Exception) -> None:
        """
        Convert Azure OpenAI-specific exceptions to unified error hierarchy.

        Maps Azure OpenAI exceptions to agentbyte error types for consistent
        error handling across providers.

        Args:
            error: Exception raised by Azure OpenAI API

        Raises:
            RateLimitError: API rate limits exceeded
            AuthenticationError: Authentication failed
            InvalidRequestError: Request format is invalid
            ModelClientError: Other API errors
        """
        # Import here to avoid circular imports and handle optional dependency
        try:
            from openai import (
                RateLimitError as OpenAIRateLimitError,
                AuthenticationError as OpenAIAuthenticationError,
                BadRequestError,
                APIError,
            )
        except ImportError:
            # If openai not installed, convert to generic ModelClientError
            raise ModelClientError(f"Azure OpenAI error: {str(error)}") from error

        error_msg = str(error)
        error_type = type(error).__name__

        if isinstance(error, OpenAIRateLimitError):
            raise RateLimitError(f"Azure OpenAI rate limit exceeded: {error_msg}") from error

        elif isinstance(error, OpenAIAuthenticationError):
            raise AuthenticationError(
                f"Azure OpenAI authentication failed: {error_msg}"
            ) from error

        elif isinstance(error, BadRequestError):
            raise InvalidRequestError(
                f"Azure OpenAI request invalid: {error_msg}"
            ) from error

        elif isinstance(error, APIError):
            # Generic API error - try to extract more details
            raise ModelClientError(
                f"Azure OpenAI API error ({error_type}): {error_msg}"
            ) from error

        else:
            # Unknown error type
            raise ModelClientError(
                f"Unexpected error from Azure OpenAI ({error_type}): {error_msg}"
            ) from error


__all__ = ["AzureOpenAIChatCompletionClient", "AzureOpenAIChatCompletionClientConfig"]
