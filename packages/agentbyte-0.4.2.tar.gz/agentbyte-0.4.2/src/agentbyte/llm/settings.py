"""
LLM provider settings using pydantic-settings.

Each settings class auto-loads from environment variables using a prefix.
Fields can also be provided explicitly, which always takes priority over env.

Usage:
    # Load environment variables from a .env file:
    from dotenv import load_dotenv
    load_dotenv(".envs/local.env")
    
    # Then create settings from environment:
    settings = OpenAISettings()

    # Or explicit override (takes priority over env):
    settings = OpenAISettings(api_key="sk-...")
"""

from pydantic import SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class OpenAISettings(BaseSettings):
    """
    OpenAI provider settings.

    Reads from environment variables with the prefix ``OPENAI_``:
    - ``OPENAI_API_KEY``  → ``api_key``
    - ``OPENAI_ORG``      → ``org``

    Attributes:
        api_key: OpenAI API key. Stored as SecretStr so it is never
                 accidentally logged or serialised in plaintext.
        org:     Optional OpenAI organisation ID (e.g. ``org-abc123``).

    Example:
        >>> import os
        >>> from dotenv import load_dotenv
        >>> load_dotenv(".envs/local.env")
        >>> settings = OpenAISettings()
        >>> settings.api_key.get_secret_value()
        'sk-...'
        >>> # Or pass explicitly (takes priority):
        >>> settings = OpenAISettings(api_key="sk-explicit")
    """

    model_config = SettingsConfigDict(env_prefix="OPENAI_", extra="ignore")

    api_key: SecretStr
    org: str | None = None


class AzureOpenAISettings(BaseSettings):
    """
    Azure OpenAI service configuration.

    Reads from environment variables with the prefix ``AZURE_OPENAI_``:
    - ``AZURE_OPENAI_ENDPOINT``              → ``endpoint`` (required)
    - ``AZURE_OPENAI_API_VERSION``           → ``api_version`` (optional)
    - ``AZURE_OPENAI_CHAT_DEPLOYMENT_NAME``  → ``chat_deployment_name`` (optional)
    - ``AZURE_OPENAI_EMBEDDING_DEPLOYMENT_NAME`` → ``embedding_deployment_name`` (optional)
    - ``AZURE_OPENAI_API_KEY``               → ``api_key`` (optional, API-key auth only)

    Attributes:
        endpoint:             Azure OpenAI resource endpoint URL (required).
        api_version:          API version string. Optional — different agents on the same
                              endpoint may need different versions (e.g. chat completions
                              vs. responses API). Set as a shared default here, or pass
                              ``api_version=`` explicitly on each factory classmethod to override.
        chat_deployment_name: Deployment name. Optional — different agents use different
                              models. Set as a shared default here, or pass ``model=``
                              explicitly on each factory classmethod to override.
        embedding_deployment_name: Embedding deployment name. Optional — use this for
                      embedding clients, or pass ``model=`` explicitly per factory.
        api_key:              Optional API key — only required for ``from_api_key()`` auth.

    Example:
        >>> from dotenv import load_dotenv
        >>> load_dotenv(".envs/local.env")
        >>> settings = AzureOpenAISettings()  # all from env
    """

    model_config = SettingsConfigDict(env_prefix="AZURE_OPENAI_", extra="ignore")

    endpoint: str
    api_version: str | None = None
    chat_deployment_name: str | None = None
    embedding_deployment_name: str | None = None
    api_key: SecretStr | None = None


class AzureServicePrincipalSettings(BaseSettings):
    """
    Azure AD service principal identity settings for certificate-based auth.

    Reads from environment variables with the prefix ``AZURE_``:
    - ``AZURE_TENANT_ID``                     → ``tenant_id``
    - ``AZURE_CLIENT_ID``                     → ``client_id``
    - ``AZURE_COGNITIVE_SCOPE``               → ``cognitive_scope``
    - ``AZURE_CLIENT_CERTIFICATE_SECRET``     → ``client_certificate_secret``
    - ``AZURE_CLIENT_PRIVATE_KEY_SECRET``     → ``client_private_key_secret``

    Attributes:
        tenant_id:                    Azure AD tenant ID.
        client_id:                    Service principal (app) client ID.
        cognitive_scope:              Azure Cognitive Services OAuth scope.
        client_certificate_secret:    PEM certificate (public key portion) as a string.
        client_private_key_secret:    PEM private key as a string.

    Example:
        >>> from dotenv import load_dotenv
        >>> load_dotenv(".envs/local.env")
        >>> settings = AzureServicePrincipalSettings()  # all from env
        >>> cert_bytes = settings.certificate_data  # combined PEM bytes
    """

    model_config = SettingsConfigDict(env_prefix="AZURE_", extra="ignore")

    tenant_id: str
    client_id: str
    cognitive_scope: str
    client_certificate_secret: SecretStr
    client_private_key_secret: SecretStr

    @model_validator(mode="after")
    def _normalize_cognitive_scope(self) -> "AzureServicePrincipalSettings":
        """Ensure ``cognitive_scope`` always ends with ``/.default``."""
        if not self.cognitive_scope:
            return self

        scope = self.cognitive_scope.strip()
        if scope.endswith("/.default"):
            self.cognitive_scope = scope
        elif scope.endswith("/"):
            self.cognitive_scope = f"{scope}.default"
        else:
            self.cognitive_scope = f"{scope}/.default"
        return self

    @property
    def certificate_data(self) -> bytes:
        """Combined PEM bytes (certificate + private key) ready for ``CertificateCredential``."""
        return (
            self.client_certificate_secret.get_secret_value().encode()
            + b"\n"
            + self.client_private_key_secret.get_secret_value().encode()
        )


__all__ = ["OpenAISettings", "AzureOpenAISettings", "AzureServicePrincipalSettings"]
