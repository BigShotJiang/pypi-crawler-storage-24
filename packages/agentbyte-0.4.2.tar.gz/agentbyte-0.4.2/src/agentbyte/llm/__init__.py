"""
LLM client implementations for Agentbyte framework.

This module provides abstract interfaces and implementations for
communicating with various LLM providers (OpenAI, Anthropic, etc.).

Core Components:
    - BaseChatCompletionClient: Abstract base class for all LLM providers
    - Message Types: SystemMessage, UserMessage, AssistantMessage, ToolMessage
    - Response Types: ChatCompletionResult, ChatCompletionChunk
    - Exception Types: ModelClientError, RateLimitError, AuthenticationError

Example:
    from agentbyte.llm import (
        BaseChatCompletionClient,
        SystemMessage,
        UserMessage
    )

    # Use with any concrete provider implementation
    messages = [
        SystemMessage(content="You are helpful."),
        UserMessage(content="What is 2+2?")
    ]
"""

from .base import (
    BaseChatCompletionClient,
    BaseChatCompletionClientConfig,
    RateLimitError,
    AuthenticationError,
    InvalidRequestError,
)
from .embeddings_base import BaseEmbeddingClient, BaseEmbeddingClientConfig
from .openai import OpenAIChatCompletionClient, OpenAIChatCompletionClientConfig
from .openai_embedding import OpenAIEmbeddingClient, OpenAIEmbeddingClientConfig
from .azure_openai import (
    AzureOpenAIChatCompletionClient,
    AzureOpenAIChatCompletionClientConfig,
)
from .azure_openai_embedding import (
    AzureOpenAIEmbeddingClient,
    AzureOpenAIEmbeddingClientConfig,
)
from .auth import (
    get_default_token_provider,
    get_certificate_token_provider,
    create_token_provider_from_string,
)
from .settings import OpenAISettings, AzureOpenAISettings, AzureServicePrincipalSettings
# Import message types and usage from root module (picoagents-aligned)
from agentbyte.messages import (
    BaseMessage,
    Message,
    SystemMessage,
    UserMessage,
    AssistantMessage,
    ToolMessage,
    ToolCallRequest,
    MultiModalMessage,
    Usage,
)
# Import LLM response types from this module
from .types import (
    ChatCompletionChunk,
    ChatCompletionResult,
    EmbeddingResult,
    ModelClientError,
    ModelPricing,
)

__all__ = [
    # Base classes
    "BaseChatCompletionClient",
    "BaseChatCompletionClientConfig",
    "BaseEmbeddingClient",
    "BaseEmbeddingClientConfig",
    # Provider implementations
    "OpenAIChatCompletionClient",
    "OpenAIChatCompletionClientConfig",
    "OpenAIEmbeddingClient",
    "OpenAIEmbeddingClientConfig",
    "AzureOpenAIChatCompletionClient",
    "AzureOpenAIChatCompletionClientConfig",
    "AzureOpenAIEmbeddingClient",
    "AzureOpenAIEmbeddingClientConfig",
    # Authentication utilities
    "get_default_token_provider",
    "get_certificate_token_provider",
    "create_token_provider_from_string",
    # Settings
    "OpenAISettings",
    "AzureOpenAISettings",
    "AzureServicePrincipalSettings",
    # Exception types
    "ModelClientError",
    "RateLimitError",
    "AuthenticationError",
    "InvalidRequestError",
    # Message types (from agentbyte.messages)
    "BaseMessage",
    "Message",
    "SystemMessage",
    "UserMessage",
    "AssistantMessage",
    "ToolMessage",
    "ToolCallRequest",
    "MultiModalMessage",
    # Result types
    "Usage",
    "ChatCompletionResult",
    "ChatCompletionChunk",
    "EmbeddingResult",
    "ModelPricing",
]
