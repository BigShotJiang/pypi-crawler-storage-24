"""
OpenAI chat completion client implementation.

This module provides a concrete implementation of BaseChatCompletionClient
for OpenAI's GPT models (GPT-4, GPT-3.5-turbo, etc.).

Design Pattern:
    Follows the Three-Step Conversion Pattern:
    1. Convert Agentbyte Message types to OpenAI API format
    2. Make API call using the injected AsyncOpenAI client
    3. Convert OpenAI response back to unified ChatCompletionResult

Authentication:
    The OpenAI client is injected at initialization, enabling:
    - Different authentication methods (API keys, OAuth, etc.)
    - Custom configuration (proxies, timeouts, base URLs, etc.)
    - Multi-environment support with different credentials
    - Easy testing with mock clients
"""

import asyncio
import json
import logging
import time
from collections.abc import AsyncGenerator
from typing import Any, Callable, Dict, List, Optional

from openai import AsyncOpenAI

from agentbyte.messages import AssistantMessage, Message, ToolCallRequest

from agentbyte.component import Component

from .base import (
    BaseChatCompletionClient,
    BaseChatCompletionClientConfig,
    RateLimitError,
    AuthenticationError,
    InvalidRequestError,
)
from .pricing import PricingRegistry
from .types import (
    ChatCompletionChunk,
    ChatCompletionResult,
    ModelPricing,
    ModelClientError,
    Usage,
)

logger = logging.getLogger(__name__)


class OpenAIChatCompletionClientConfig(BaseChatCompletionClientConfig):
    """
    Configuration for OpenAIChatCompletionClient serialization.

    Captures all state needed to reconstruct an OpenAI client,
    enabling configuration file management and cross-environment deployment.

    Attributes:
        model: Model identifier (e.g., "gpt-4.1-mini", "gpt-4")
        config: Default configuration dict (temperature, max_tokens, etc.)
        max_retries: Maximum retry attempts for transient errors
        initial_retry_delay: Initial backoff delay in seconds
        max_retry_delay: Maximum backoff delay in seconds
        key_env_var: Environment variable name holding the API key (default: OPENAI_API_KEY).
            The secret itself is never stored — only the env-var name.

    Note:
        The API key is resolved at load time from the named environment variable.
        This ensures credentials are never written to config files.
    """
    max_retries: int = 3
    initial_retry_delay: float = 1.0
    max_retry_delay: float = 60.0
    key_env_var: str = "OPENAI_API_KEY"


class OpenAIChatCompletionClient(
    BaseChatCompletionClient,
    Component[OpenAIChatCompletionClientConfig],
):
    """
    OpenAI chat completion client implementation.

    Supports GPT-4, GPT-4 Turbo, GPT-3.5-turbo, and other OpenAI models
    with streaming, function calling, and vision capabilities.

    Strict Dependency Injection Pattern:
        The user creates and fully configures AsyncOpenAI with:
        - Authentication (API key, custom base URL, organization, etc.)
        - Custom configuration (proxies, timeouts, etc.)
        
        Then injects the configured client here. This enforces:
        - Separation of concerns: User owns transport/auth, we own agent patterns
        - Enterprise flexibility: Support any authentication method
        - Testability: Mock clients can be injected for testing
        - No credential hardcoding: Credentials managed externally

    Minimal Wrapper:
        The wrapper only needs:
        - `model`: Model name to use in API calls
        - `client`: Pre-configured AsyncOpenAI
        - `config`: Default LLM parameters (temperature, max_tokens, etc.)
        - Retry logic: Exponential backoff for transient errors

    Features:
        - Automatic retry logic with exponential backoff for transient errors
        - Support for function calling / tool use
        - Streaming for real-time token delivery
        - Vision capabilities through OpenAI SDK

    Example:
        ```python
        from openai import AsyncOpenAI
        from agentbyte.llm import OpenAIChatCompletionClient, UserMessage

        # 1. User creates and configures OpenAI client
        openai_client = AsyncOpenAI(
            api_key="sk-...",
            organization="org-123"
        )

        # 2. Inject configured client into agentbyte wrapper
        llm = OpenAIChatCompletionClient(
            model="gpt-4.1-mini",
            client=openai_client,
            config={"temperature": 0.7, "max_tokens": 2000},
            max_retries=3,
            initial_retry_delay=1.0,
            max_retry_delay=60.0
        )

        # 3. Use it - with automatic retry on transient errors
        result = await llm.create(
            messages=[UserMessage(content="What is 2+2?")]
        )
        print(result.message.content)  # "2+2 equals 4"

        # Streaming with retry
        async for chunk in llm.create_stream(
            messages=[UserMessage(content="Write a haiku")]
        ):
            print(chunk.content, end="", flush=True)
        ```

    Attributes:
        model: The model identifier (e.g., "gpt-4.1-mini", "gpt-4", "gpt-3.5-turbo")
        client: Injected AsyncOpenAI HTTP client
        config: Default configuration dict (temperature, max_tokens, etc.)
        max_retries: Maximum number of retries for transient errors (default: 3)
        initial_retry_delay: Initial delay in seconds before first retry (default: 1.0)
        max_retry_delay: Maximum delay in seconds between retries (default: 60.0)
    """

    component_type = "model_client"
    component_config_schema = OpenAIChatCompletionClientConfig
    component_provider_override = "agentbyte.llm.OpenAIChatCompletionClient"

    def __init__(
        self,
        model: str,
        client: AsyncOpenAI,
        config: Optional[Dict[str, Any]] = None,
        model_pricing: Optional[ModelPricing] = None,
        max_retries: int = 3,
        initial_retry_delay: float = 1.0,
        max_retry_delay: float = 60.0,
    ):
        """
        Initialize OpenAI client with pre-configured dependency.

        Args:
            model: Model name (e.g., "gpt-4.1-mini", "gpt-4", "gpt-3.5-turbo")
                   This is what gets passed as the `model` parameter to OpenAI API.
            
            client: Pre-configured AsyncOpenAI HTTP client (REQUIRED)
                   User must create this with their preferred authentication and config:
                   
                   Example with API Key:
                       >>> from openai import AsyncOpenAI
                       >>> openai_client = AsyncOpenAI(
                       ...     api_key="sk-...",
                       ...     organization="org-123"
                       ... )
                   
                   Example with Custom Base URL:
                       >>> openai_client = AsyncOpenAI(
                       ...     api_key="sk-...",
                       ...     base_url="https://api.openai.com/v1",
                       ...     organization="org-123"
                       ... )
            
            config: Default LLM configuration dict (optional)
                   Applied to all API calls, can be overridden per-call.
                   Example: {"temperature": 0.7, "max_tokens": 2000}
            
            max_retries: Maximum retry attempts for transient errors (default: 3)
            
            initial_retry_delay: Initial backoff delay in seconds (default: 1.0)
            
            max_retry_delay: Maximum backoff delay in seconds (default: 60.0)

        Example:
            >>> from openai import AsyncOpenAI
            >>> from agentbyte.llm import OpenAIChatCompletionClient, UserMessage
            >>> 
            >>> # 1. User creates and configures OpenAI client (handles auth/config)
            >>> openai_client = AsyncOpenAI(
            ...     api_key="sk-...",
            ...     organization="org-123"
            ... )
            >>> 
            >>> # 2. Inject configured client into agentbyte wrapper
            >>> llm = OpenAIChatCompletionClient(
            ...     model="gpt-4.1-mini",
            ...     client=openai_client,
            ...     config={"temperature": 0.7}
            ... )
            >>> 
            >>> # 3. Use it
            >>> result = await llm.create(
            ...     messages=[UserMessage(content="Hello")]
            ... )
        """
        super().__init__(model, client, config)
        self.model_pricing = model_pricing
        self.max_retries = max_retries
        self.initial_retry_delay = initial_retry_delay
        self.max_retry_delay = max_retry_delay

    @classmethod
    def from_api_key(
        cls,
        model: str,
        api_key: Optional[str] = None,
        org: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
        model_pricing: Optional[ModelPricing] = None,
        max_retries: int = 3,
        initial_retry_delay: float = 1.0,
        max_retry_delay: float = 60.0,
    ) -> "OpenAIChatCompletionClient":
        """
        Convenience factory — create a client without manually constructing AsyncOpenAI.

        Key resolution order:
        1. ``api_key`` argument (explicit, takes priority)
        2. ``OPENAI_API_KEY`` environment variable (via OpenAISettings)

        Args:
            model: Model name (e.g. ``"gpt-4.1-mini"``)
            api_key: OpenAI API key. When omitted, ``OPENAI_API_KEY`` env var is used.
            org: Optional organisation ID. When omitted, ``OPENAI_ORG`` env var is used.
            config: Default LLM parameters (e.g. ``{"temperature": 0.2, "max_tokens": 1000}``).
            max_retries: Maximum retry attempts for transient errors (default: 3)
            initial_retry_delay: Initial backoff delay in seconds (default: 1.0)
            max_retry_delay: Maximum backoff delay in seconds (default: 60.0)

        Returns:
            A fully initialised ``OpenAIChatCompletionClient``.

        Raises:
            ValueError: When no API key is found at all (neither explicit nor env).

        Example:
            >>> # Auto-load key from OPENAI_API_KEY env var:
            >>> client = OpenAIChatCompletionClient.from_api_key(
            ...     model="gpt-4.1-mini",
            ...     config={"temperature": 0.2},
            ... )
            >>> # Or pass it explicitly:
            >>> client = OpenAIChatCompletionClient.from_api_key(
            ...     model="gpt-4.1-mini",
            ...     api_key="sk-...",
            ...     config={"temperature": 0.2},
            ... )
        """
        from .settings import OpenAISettings
        from pydantic import ValidationError

        if api_key is None:
            # Attempt to load from OPENAI_API_KEY env var via OpenAISettings.
            # Raise a clear ValueError rather than exposing a pydantic ValidationError.
            try:
                settings = OpenAISettings()
                resolved_key = settings.api_key.get_secret_value()
                resolved_org = org or settings.org
            except ValidationError:
                raise ValueError(
                    "No OpenAI API key provided. "
                    "Pass api_key= explicitly or set the OPENAI_API_KEY environment variable."
                )
        else:
            resolved_key = api_key
            resolved_org = org

        openai_client = AsyncOpenAI(api_key=resolved_key, organization=resolved_org)
        return cls(
            model=model,
            client=openai_client,
            config=config,
            model_pricing=model_pricing,
            max_retries=max_retries,
            initial_retry_delay=initial_retry_delay,
            max_retry_delay=max_retry_delay,
        )

    async def _retry_with_backoff(
        self, func: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> Any:
        """
        Execute a function with exponential backoff retry logic.

        Retries on transient errors (RateLimitError, generic API errors).
        Does NOT retry on authentication or request validation errors.

        Args:
            func: Async function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function

        Returns:
            Function result

        Raises:
            The original exception if all retries are exhausted or error is non-transient

        Implementation Notes:
            - RateLimitError: Always transient, always retried
            - ModelClientError: Transient, retried (e.g., temporary API issues)
            - AuthenticationError: Non-transient, never retried
            - InvalidRequestError: Non-transient, never retried
            - Uses exponential backoff: delay *= 2, capped at max_retry_delay
        """
        last_exception = None
        current_delay = self.initial_retry_delay

        for attempt in range(self.max_retries + 1):
            try:
                return await func(*args, **kwargs)
            except (RateLimitError, ModelClientError) as e:
                # RateLimitError and generic ModelClientError are transient
                last_exception = e

                if attempt >= self.max_retries:
                    logger.warning(
                        f"Max retries ({self.max_retries}) reached for {func.__name__}"
                    )
                    raise

                # Log retry attempt
                logger.debug(
                    f"Transient error in {func.__name__} (attempt {attempt + 1}/{self.max_retries + 1}): {str(e)}. "
                    f"Retrying in {current_delay:.1f}s"
                )

                # Wait before retry with exponential backoff
                await asyncio.sleep(current_delay)
                current_delay = min(current_delay * 2, self.max_retry_delay)

            except (AuthenticationError, InvalidRequestError) as e:
                # Non-transient errors: don't retry
                logger.error(f"Non-transient error in {func.__name__}: {str(e)}")
                raise

            except Exception as e:
                # Unknown errors: don't retry
                logger.error(f"Unexpected error in {func.__name__}: {str(e)}")
                raise

        # Should not reach here, but just in case
        raise last_exception or ModelClientError("Retry logic error")

    async def _retry_stream_with_backoff(
        self, func: Callable[..., AsyncGenerator[ChatCompletionChunk, None]], *args: Any, **kwargs: Any
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Execute a streaming function with exponential backoff retry logic.

        Retries are only attempted if the stream fails before yielding any chunks
        to avoid duplicating partial output.
        """
        current_delay = self.initial_retry_delay

        for attempt in range(self.max_retries + 1):
            saw_chunk = False
            try:
                async for chunk in func(*args, **kwargs):
                    saw_chunk = True
                    yield chunk
                return
            except (RateLimitError, ModelClientError) as e:
                if saw_chunk or attempt >= self.max_retries:
                    raise
                logger.debug(
                    f"Transient stream error in {func.__name__} (attempt {attempt + 1}/{self.max_retries + 1}): {str(e)}. "
                    f"Retrying in {current_delay:.1f}s"
                )
                await asyncio.sleep(current_delay)
                current_delay = min(current_delay * 2, self.max_retry_delay)
            except (AuthenticationError, InvalidRequestError):
                raise

    async def create(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Make a single OpenAI API call.

        Follows the Three-Step Conversion Pattern:
        1. Convert Agentbyte messages to OpenAI format
        2. Call OpenAI API with the injected client
        3. Parse response and convert back to unified format

        Args:
            messages: Conversation history with Agentbyte Message types
            tools: Optional list of tool/function schemas for function calling
            output_format: Optional Pydantic model for structured output validation
                          The model will attempt to parse the response as JSON
                          and validate it against this schema
            **kwargs: OpenAI-specific parameters that override self.config
                     (temperature, max_tokens, top_p, frequency_penalty, etc.)

        Returns:
            ChatCompletionResult with:
            - message: AssistantMessage with content and optional tool_calls
            - usage: Token consumption statistics
            - model: Model used
            - metadata: Provider-specific data (finish_reason, etc.)
            - structured_output: Parsed output if output_format was provided (optional)

        Raises:
            RateLimitError: OpenAI rate limits exceeded
            AuthenticationError: Invalid API key or credentials
            InvalidRequestError: Request format is invalid
            ModelClientError: Other API errors

        Implementation Notes:
            - Merges self.config with kwargs (kwargs takes precedence)
            - Handles tool calls in response and creates ToolCall objects
            - Extracts usage statistics for cost tracking
            - Automatically retries transient errors with exponential backoff
            - Structured output uses OpenAI Structured Outputs API (requires compatible model)
            - If structured output parsing fails, continues with text response
        """
        try:
            # Delegate to retry wrapper
            return await self._retry_with_backoff(
                self._create_internal, messages, tools, output_format, **kwargs
            )

        except Exception as e:
            # Convert OpenAI exceptions to unified error hierarchy
            self._handle_error(e)

    async def _create_internal(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Internal create implementation (handles API call, gets retried by wrapper).

        This is the actual API call that gets wrapped by retry logic.

        Args:
            messages: Conversation history
            tools: Optional tool definitions
            output_format: Optional Pydantic model for structured output
            **kwargs: Additional OpenAI parameters

        Returns:
            ChatCompletionResult

        Raises:
        """
        # Merge configuration: base config + request-specific kwargs
        api_kwargs = {**self.config, **kwargs}

        # Step 1: Convert internal Message types to OpenAI format
        api_messages = self._convert_messages_to_api_format(messages)

        # Handle structured output if requested
        structured_output = None
        if output_format:
            try:
                # Convert Pydantic model to JSON schema for OpenAI
                schema = output_format.model_json_schema()
                
                # Ensure OpenAI Structured Outputs compatibility
                schema = self._make_schema_compatible(schema)
                
                # Add response_format to request
                api_kwargs["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": schema.get("title", output_format.__name__),
                        "description": schema.get(
                            "description",
                            f"Structured output for {output_format.__name__}",
                        ),
                        "strict": True,
                        "schema": schema,
                    },
                }
            except Exception as e:
                # If schema conversion fails, log warning but continue
                logger.warning(
                    f"Failed to convert {output_format.__name__} to JSON schema: {e}. "
                    f"Continuing without structured output."
                )

        # Step 2: Make API call using the injected client
        start_time = time.perf_counter()
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            tools=tools,
            **api_kwargs,
        )
        duration_ms = int((time.perf_counter() - start_time) * 1000)

        # Step 3: Parse response and convert to unified format
        choice = response.choices[0]
        message_content = choice.message.content or ""

        # Handle tool calls if present
        tool_calls = None
        if choice.message.tool_calls:
            tool_calls = [
                ToolCallRequest(
                    call_id=tc.id,
                    tool_name=tc.function.name,
                    parameters=json.loads(tc.function.arguments),
                )
                for tc in choice.message.tool_calls
            ]

        # Parse structured output if requested
        if output_format and message_content:
            try:
                structured_output = output_format.model_validate_json(message_content)
            except Exception as e:
                logger.warning(
                    f"Failed to parse structured output: {e}. Using raw content."
                )
                structured_output = None

        return ChatCompletionResult(
            message=AssistantMessage(
                content=message_content,
                source=self.model,
                tool_calls=tool_calls,
            ),
            usage=Usage(
                duration_ms=duration_ms,
                llm_calls=1,
                tokens_input=response.usage.prompt_tokens,
                tokens_output=response.usage.completion_tokens,
                tool_calls=len(tool_calls) if tool_calls else 0,
                cost_estimate=self._estimate_cost(
                    response.usage.prompt_tokens,
                    response.usage.completion_tokens,
                )
            ),
            model=response.model,
            metadata={
                "finish_reason": choice.finish_reason,
            },
            finish_reason=choice.finish_reason,
            structured_output=structured_output,
        )


    async def create_stream(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        stream_options: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Make a streaming OpenAI API call.

        Yields response chunks as they arrive from the API, enabling real-time
        updates and reduced time-to-first-token perception.

        Args:
            messages: Conversation history with Agentbyte Message types
            output_format: Optional Pydantic model for structured output
                          Note: Structured output is not fully supported in streaming
                          (OpenAI API limitation). Parameter accepted for API consistency.
            stream_options: Optional stream options (defaults to include usage when omitted)
            **kwargs: OpenAI-specific parameters that override self.config

        Yields:
            ChatCompletionChunk with:
            - content: Partial text content from this chunk
            - model: Model name
            - metadata: Provider-specific data (finish_reason for final chunk)

        Raises:
            Same exception hierarchy as create()

        Implementation Notes:
            - Enables stream=True on OpenAI API call
            - Yields chunks as they arrive
            - Final chunk may have empty content but includes finish_reason
            - Accumulate chunks by concatenating .content for full response
            - Includes retry logic for transient errors (rate limits, API errors)
            - Note: Entire stream is retried as a unit if transient error occurs
            - Structured output not supported in streaming (OpenAI limitation)
        """
        try:
            # Delegate to retry wrapper for streaming
            async for chunk in self._retry_stream_with_backoff(
                self._create_stream_internal,
                messages,
                tools,
                output_format,
                stream_options,
                **kwargs,
            ):
                yield chunk

        except Exception as e:
            # Convert exceptions to unified error hierarchy
            self._handle_error(e)

    async def _create_stream_internal(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        stream_options: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Internal streaming implementation (handles API call, gets retried by wrapper).
        This is the actual streaming API call that gets wrapped by retry logic.

        Args:
            messages: Conversation history
            tools: Optional tool definitions
            output_format: Optional Pydantic model (not used in streaming, for API consistency)
            **kwargs: Additional OpenAI parameters

        Yields:
            ChatCompletionChunk objects

        Raises:
            OpenAI exceptions (converted by caller)

        Note:
            Structured output (output_format) is not used here because OpenAI's
            streaming API does not support structured output. For structured responses,
            use create() instead.
        """
        # Merge configuration
        api_kwargs = {**self.config, **kwargs}
        if "stream_options" in api_kwargs and stream_options is None:
            stream_options = api_kwargs.pop("stream_options")
        else:
            api_kwargs.pop("stream_options", None)
        if stream_options is None:
            stream_options = {"include_usage": True}
        if stream_options:
            api_kwargs["stream_options"] = stream_options

        # Convert messages to OpenAI format
        api_messages = self._convert_messages_to_api_format(messages)

        # Make streaming API call
        start_time = time.perf_counter()
        stream = await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            tools=tools,
            stream=True,  # Enable streaming
            **api_kwargs,
        )

        tool_call_chunks: Dict[Any, Dict[str, Any]] = {}

        # Yield chunks as they arrive
        async for chunk in stream:
            # Usage-only chunk (final chunk when include_usage=true)
            if hasattr(chunk, "usage") and chunk.usage and (not chunk.choices or len(chunk.choices) == 0):
                duration_ms = int((time.perf_counter() - start_time) * 1000)
                usage = Usage(
                    duration_ms=duration_ms,
                    llm_calls=1,
                    tokens_input=chunk.usage.prompt_tokens,
                    tokens_output=chunk.usage.completion_tokens,
                    cost_estimate=self._estimate_cost(
                        chunk.usage.prompt_tokens,
                        chunk.usage.completion_tokens,
                    ),
                )
                yield ChatCompletionChunk(
                    content="",
                    model=chunk.model,
                    is_complete=True,
                    tool_call_chunk=None,
                    usage=usage,
                    metadata={},
                )
                break

            if not chunk.choices:
                continue

            chunk_choice = chunk.choices[0]
            delta = chunk_choice.delta

            # Content chunks
            if delta.content:
                yield ChatCompletionChunk(
                    content=delta.content,
                    model=chunk.model,
                    is_complete=False,
                    tool_call_chunk=None,
                    usage=None,
                    metadata={
                        "finish_reason": chunk_choice.finish_reason,
                    },
                )

            # Tool call chunks
            if delta.tool_calls:
                for tc_delta in delta.tool_calls:
                    index = getattr(tc_delta, "index", None)
                    call_id = tc_delta.id
                    tracking_key = index if index is not None else call_id

                    if tracking_key not in tool_call_chunks:
                        tool_call_chunks[tracking_key] = {
                            "id": call_id,
                            "function": {"name": "", "arguments": ""},
                        }

                    if call_id:
                        tool_call_chunks[tracking_key]["id"] = call_id

                    if tc_delta.function:
                        if tc_delta.function.name:
                            tool_call_chunks[tracking_key]["function"]["name"] = tc_delta.function.name
                        if tc_delta.function.arguments:
                            tool_call_chunks[tracking_key]["function"]["arguments"] += tc_delta.function.arguments

                    yield ChatCompletionChunk(
                        content="",
                        model=chunk.model,
                        is_complete=False,
                        tool_call_chunk=tool_call_chunks[tracking_key],
                        usage=None,
                        metadata={},
                    )

            # If stream ends without usage chunks, emit completion marker
            if chunk_choice.finish_reason and not stream_options.get("include_usage"):
                yield ChatCompletionChunk(
                    content="",
                    model=chunk.model,
                    is_complete=True,
                    tool_call_chunk=None,
                    usage=None,
                    metadata={"finish_reason": chunk_choice.finish_reason},
                )

    def _make_schema_compatible(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Modify JSON schema to be compatible with OpenAI Structured Outputs.

        OpenAI's Structured Outputs require certain schema constraints:
        - Object types must have additionalProperties=False
        - All properties must be defined in the schema
        - Schemas must be strict and unambiguous

        Args:
            schema: The JSON schema to make compatible

        Returns:
            Modified schema with OpenAI compatibility fixes
        """
        # Recursively walk the full schema tree (including $defs / allOf / anyOf / oneOf)
        # and enforce OpenAI requirement: object schemas must set additionalProperties=False.
        compatible_schema: Dict[str, Any] = {}
        for key, value in schema.items():
            if isinstance(value, dict):
                compatible_schema[key] = self._make_schema_compatible(value)
            elif isinstance(value, list):
                compatible_schema[key] = [
                    self._make_schema_compatible(item) if isinstance(item, dict) else item
                    for item in value
                ]
            else:
                compatible_schema[key] = value

        if compatible_schema.get("type") == "object":
            compatible_schema["additionalProperties"] = False

        return compatible_schema

    def _estimate_cost(self, prompt_tokens: int, completion_tokens: int) -> float:
        """
        Estimate the cost of the API call based on token usage.

        Uses current OpenAI pricing for different model families.
        Note: These are approximate rates and may not reflect real-time changes.

        Args:
            prompt_tokens: Number of tokens in the prompt
            completion_tokens: Number of tokens generated

        Returns:
            Estimated cost in USD

        Pricing is resolved from PricingRegistry; user-provided pricing always takes precedence.
        Unknown models trigger a warning and fall back to GPT-4 pricing.
        """
        # User-provided pricing always takes precedence
        if self.model_pricing is not None:
            pricing = self.model_pricing
        else:
            # Resolve from registry (warns if not found, uses default GPT-4 pricing)
            pricing = PricingRegistry.resolve_openai_chat_pricing(self.model)

        return pricing.calculate_cost(prompt_tokens, completion_tokens)

    def _to_config(self) -> OpenAIChatCompletionClientConfig:
        """Serialize to config. The API key env var name is stored; the secret is never written."""
        return OpenAIChatCompletionClientConfig(
            model=self.model,
            config=self.config.copy(),
            max_retries=self.max_retries,
            initial_retry_delay=self.initial_retry_delay,
            max_retry_delay=self.max_retry_delay,
            key_env_var=getattr(self, "_key_env_var", "OPENAI_API_KEY"),
        )

    @classmethod
    def _from_config(cls, config: OpenAIChatCompletionClientConfig) -> "OpenAIChatCompletionClient":
        """
        Reconstruct client from saved config.

        The API key is read at load time from the environment variable named in
        ``config.key_env_var`` (default: ``OPENAI_API_KEY``).  The key is never
        stored on disk — only the *name* of the env var is serialized.

        Raises:
            ValueError: When the named environment variable is not set.
        """
        import os
        api_key = os.environ.get(config.key_env_var)
        if not api_key:
            raise ValueError(
                f"Cannot reconstruct OpenAIChatCompletionClient: environment variable "
                f"'{config.key_env_var}' is not set."
            )
        instance = cls.from_api_key(
            model=config.model,
            api_key=api_key,
            config=config.config or None,

            max_retries=config.max_retries,
            initial_retry_delay=config.initial_retry_delay,
            max_retry_delay=config.max_retry_delay,
        )
        instance._key_env_var = config.key_env_var
        return instance

    def _handle_error(self, error: Exception) -> None:
        """
        Convert OpenAI-specific exceptions to unified error hierarchy.

        Maps OpenAI exceptions to agentbyte error types for consistent
        error handling across providers.

        Args:
            error: Exception raised by OpenAI API

        Raises:
            RateLimitError: API rate limits exceeded
            AuthenticationError: Authentication failed
            InvalidRequestError: Request format is invalid
            ModelClientError: Other API errors
        """
        # Import here to avoid circular imports and handle optional dependency
        try:
            from openai import (
                RateLimitError as OpenAIRateLimitError,
                AuthenticationError as OpenAIAuthenticationError,
                BadRequestError,
                APIError,
            )
        except ImportError:
            # If openai not installed, convert to generic ModelClientError
            raise ModelClientError(f"OpenAI error: {str(error)}") from error

        error_msg = str(error)
        error_type = type(error).__name__

        if isinstance(error, OpenAIRateLimitError):
            raise RateLimitError(f"OpenAI rate limit exceeded: {error_msg}") from error

        elif isinstance(error, OpenAIAuthenticationError):
            raise AuthenticationError(
                f"OpenAI authentication failed: {error_msg}"
            ) from error

        elif isinstance(error, BadRequestError):
            raise InvalidRequestError(
                f"OpenAI request invalid: {error_msg}"
            ) from error

        elif isinstance(error, APIError):
            # Generic API error - try to extract more details
            raise ModelClientError(
                f"OpenAI API error ({error_type}): {error_msg}"
            ) from error

        else:
            # Unknown error type
            raise ModelClientError(
                f"Unexpected error from OpenAI ({error_type}): {error_msg}"
            ) from error


__all__ = ["OpenAIChatCompletionClient", "OpenAIChatCompletionClientConfig"]
