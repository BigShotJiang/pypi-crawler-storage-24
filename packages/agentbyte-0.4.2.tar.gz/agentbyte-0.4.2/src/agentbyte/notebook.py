"""Notebook-focused helper utilities."""

from __future__ import annotations

import logging
from typing import Iterable


def configure_notebook_logging(
    verbose: bool = False,
    extra_loggers: Iterable[str] | None = None,
) -> None:
    """Configure logging defaults for notebook sessions.

    Args:
        verbose: When ``True``, enable INFO-level diagnostics.
            When ``False``, suppress noisy provider/HTTP logs.
        extra_loggers: Optional logger names to include in suppression/tuning.

    Note: Middleware logs (``agentbyte.middleware``) are always shown at INFO level,
    regardless of verbose mode, so that middleware demos remain visible in notebooks.
    """

    # Root logger: INFO if verbose, WARNING otherwise
    root_level = logging.INFO if verbose else logging.WARNING
    logging.basicConfig(
        level=root_level,
        format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
        force=True,
    )

    noisy_loggers = [
        "httpx",
        "httpcore",
        "openai",
        "azure",
        "azure.identity",
        "azure.core",
        "azure.core.pipeline",
        "azure.core.pipeline.policies.http_logging_policy",
    ]
    if extra_loggers:
        noisy_loggers.extend(extra_loggers)

    logger_level = logging.INFO if verbose else logging.WARNING
    for logger_name in noisy_loggers:
        logger = logging.getLogger(logger_name)
        logger.setLevel(logger_level)
        logger.propagate = bool(verbose)

    # Always show middleware logs at INFO level, regardless of verbose mode
    # This ensures middleware demos in notebooks are always visible
    middleware_logger = logging.getLogger("agentbyte.middleware")
    middleware_logger.setLevel(logging.INFO)
    middleware_logger.propagate = True


__all__ = ["configure_notebook_logging"]