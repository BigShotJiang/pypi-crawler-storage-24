"""Wrap an Agentbyte agent as a workflow step."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from agentbyte.agents import AgentResponse, BaseAgent
from agentbyte.workflow.core.models import Context, StepMetadata
from agentbyte.workflow.steps.step import BaseStep


class AgentbyteAgentInput(BaseModel):
    task: str
    additional_context: dict[str, Any] | None = None


class AgentbyteAgentOutput(BaseModel):
    response: str | None = None
    messages: list[dict[str, Any]] = Field(default_factory=list)
    usage: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None


class AgentbyteAgentStep(
    BaseStep[AgentbyteAgentInput, AgentbyteAgentOutput],
):
    """Executes an Agentbyte agent inside a workflow step."""

    def __init__(self, step_id: str, metadata: StepMetadata, agent: BaseAgent) -> None:
        super().__init__(step_id, metadata, AgentbyteAgentInput, AgentbyteAgentOutput)
        self.agent = agent

    async def execute(self, input_data: AgentbyteAgentInput, context: Context) -> AgentbyteAgentOutput:
        # The workflow Context is not the agent's AgentContext. We currently
        # treat additional_context as metadata for downstream workflow steps.
        response: AgentResponse = await self.agent.run(task=input_data.task)

        last_assistant = response.final_content
        messages = [msg.model_dump() for msg in response.messages]
        usage = response.usage.model_dump()

        if input_data.additional_context:
            context.set(f"{self.step_id}_context", input_data.additional_context)

        return AgentbyteAgentOutput(
            response=last_assistant,
            messages=messages,
            usage=usage,
            metadata=input_data.additional_context,
        )


__all__ = [
    "AgentbyteAgentStep",
    "AgentbyteAgentInput",
    "AgentbyteAgentOutput",
]
