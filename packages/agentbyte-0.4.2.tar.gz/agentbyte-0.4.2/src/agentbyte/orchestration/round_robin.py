"""Round-robin orchestration pattern."""

from typing import Any, Dict, List

from agentbyte.agents.base import BaseAgent
from agentbyte.agents.types import AgentResponse
from agentbyte.termination import BaseTermination

from .base import BaseOrchestrator


class RoundRobinOrchestrator(BaseOrchestrator):
    """
    Round-robin orchestration pattern.

    Cycles through agents in fixed order, giving each agent access to
    the complete shared conversation history.

    Use cases:
        - Collaborative tasks where all agents contribute equally
        - Iterative refinement (e.g., poet → critic → poet → critic)
        - Balanced participation from all agents

    Example:
        from agentbyte import Agent, RoundRobinOrchestrator
        from agentbyte.llm import OpenAIChatCompletionClient
        from agentbyte.termination import MaxMessageTermination, TextMentionTermination
        from agentbyte.messages import UserMessage

        poet = Agent(
            name="poet",
            description="Creative poet",
            instructions="Write creative poetry",
            model_client=OpenAIChatCompletionClient(model="gpt-4o-mini"),
        )

        critic = Agent(
            name="critic",
            description="Poetry critic",
            instructions="Critique poetry and suggest improvements",
            model_client=OpenAIChatCompletionClient(model="gpt-4o-mini"),
        )

        orchestrator = RoundRobinOrchestrator(
            agents=[poet, critic],
            termination=MaxMessageTermination(8) | TextMentionTermination("APPROVED"),
            max_iterations=4
        )

        result = await orchestrator.run(
            UserMessage(content="Write a haiku about coding")
        )
    """

    def __init__(
        self,
        agents: List[BaseAgent],
        termination: BaseTermination,
        max_iterations: int = 50,
    ):
        """
        Initialize round-robin orchestrator.

        Args:
            agents: List of agents to cycle through
            termination: When to stop coordination
            max_iterations: Safety limit on iterations
        """
        super().__init__(agents, termination, max_iterations)
        self.current_agent_index = 0

    async def select_next_agent(self) -> BaseAgent:
        """
        Select next agent in round-robin order.

        Cycles through agents: 0 → 1 → 2 → 0 → 1 → 2 → ...
        """
        agent = self.agents[self.current_agent_index]
        self.current_agent_index = (self.current_agent_index + 1) % len(self.agents)
        return agent

    async def prepare_context_for_agent(self, agent: BaseAgent) -> str:
        """
        Format full shared conversation history as a single context string.

        Provides complete conversation history to each agent so they have
        full context of what has been discussed.
        """
        if not self.shared_messages:
            return (
                "You are part of a team taking turns to collaboratively "
                "addressing a task. It is now your turn."
            )

        context = (
            "You are part of a team taking turns to collaboratively "
            "addressing a task. Here's the progress/history so far:\n\n"
        )
        for msg in self.shared_messages:
            context += f"{msg}\n"
        context += "\nIt is now your turn."
        return context

    async def update_shared_state(self, result: AgentResponse) -> None:
        """
        Add new messages to shared conversation.

        Skips the first message (which is just the context we sent),
        adds all subsequent messages to shared history.
        """
        # Skip the first message (context echo), add the rest
        new_messages = result.messages[1:] if len(result.messages) > 1 else []
        self.shared_messages.extend(new_messages)

    def _get_pattern_metadata(self) -> Dict[str, Any]:
        """
        Get round-robin specific metadata.

        Includes base metadata plus:
            - cycles_completed: How many full cycles through all agents
            - current_agent_index: Which agent is next
            - agents_order: Names of agents in order
        """
        base_metadata = super()._get_pattern_metadata()
        base_metadata.update(
            {
                "cycles_completed": self.iteration_count // len(self.agents),
                "current_agent_index": self.current_agent_index,
                "agents_order": [agent.name for agent in self.agents],
            }
        )
        return base_metadata

    def _reset_for_run(self) -> None:
        """Reset round-robin state for new run."""
        super()._reset_for_run()
        self.current_agent_index = 0
