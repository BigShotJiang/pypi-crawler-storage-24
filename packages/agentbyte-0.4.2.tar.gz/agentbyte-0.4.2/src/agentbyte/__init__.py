"""
Agentbyte - Enterprise-ready agent framework with DDD principles.

Building agents from scratch following Chapter 4 patterns with:
- Async-first architecture
- Event-based streaming
- Clean Architecture (Port/Adapter pattern)
- Domain-Driven Design

Architecture Layers:
- domain/         - Core business logic (entities, value objects, services)
- application/    - Use cases, ports (interfaces)
- infrastructure/ - Adapters, external integrations
"""

from agentbyte.__about__ import VERSION
from agentbyte.agents import Agent
from agentbyte.entity import Entity
from agentbyte.middleware import init_auto_instrumentation_from_env
from agentbyte.notebook import configure_notebook_logging
from agentbyte.messages import (
    AssistantMessage,
    Message,
    SystemMessage,
    ToolMessage,
    UserMessage,
)
from agentbyte.orchestration import (
    AIOrchestrator,
    BaseOrchestrator,
    ExecutionPlan,
    PlanBasedOrchestrator,
    PlanStep,
    RoundRobinOrchestrator,
    StepProgressEvaluation,
)
from agentbyte.session import BaseSession, InMemorySession, Session
from agentbyte.termination import (
    BaseTermination,
    CancellationTermination,
    CompositeTermination,
    ExternalTermination,
    FunctionCallTermination,
    HandoffTermination,
    MaxMessageTermination,
    TextMentionTermination,
    TimeoutTermination,
    TokenUsageTermination,
)
from agentbyte.webui import WebUIServer, create_app, serve

# Auto-instrument with OpenTelemetry if enabled.
# Must be set BEFORE importing agentbyte for transparent instrumentation.
try:
    init_auto_instrumentation_from_env()
except Exception:
    # Gracefully continue if instrumentation setup fails.
    pass


__all__ = [
    "VERSION",
    "Agent",
    "Entity",
    "Session",
    "BaseSession",
    "InMemorySession",
    "configure_notebook_logging",
    # Messages
    "Message",
    "UserMessage",
    "SystemMessage",
    "AssistantMessage",
    "ToolMessage",
    # Orchestration
    "AIOrchestrator",
    "BaseOrchestrator",
    "ExecutionPlan",
    "PlanBasedOrchestrator",
    "PlanStep",
    "RoundRobinOrchestrator",
    "StepProgressEvaluation",
    # Termination
    "BaseTermination",
    "MaxMessageTermination",
    "TextMentionTermination",
    "TokenUsageTermination",
    "TimeoutTermination",
    "FunctionCallTermination",
    "HandoffTermination",
    "ExternalTermination",
    "CancellationTermination",
    "CompositeTermination",
    # WebUI
    "WebUIServer",
    "create_app",
    "serve",
]
