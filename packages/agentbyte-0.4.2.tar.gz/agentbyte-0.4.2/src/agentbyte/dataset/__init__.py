"""Dataset loading and storage module for Agentbyte.

This module provides schema-driven dataset loading from JSON into engine-specific
backends. Currently supports:
    - SQLite: Structured data with strict schema and SQL queries
    - JSON: Semi-structured data with flexible JSON format

Architecture:
    Generic Classes (base.py):
        - Column: Column definition (engine-agnostic)
        - Schema: Schema definition (engine-agnostic)
        - DataRecord: Generic record type
        - DataStore: Abstract storage interface
        - BaseDataset: Abstract interface for all dataset types
        - DatasetConfig: Configuration (engine, table name, etc.)
        - SchemaFormat: Display format enum
    
    SQLite-Specific Classes (sqlite.py):
        - SqliteColumn: Column with SQL constraints (primary_key, not_null, unique, to_sql_def)
        - SqliteSchema: Schema with SQL generation and pretty/raw display (show method)
        - SQLiteDataset: SQLite implementation with JSON loading
    
    JSON-Specific Classes (json.py):
        - JSONDataset: JSON file-based dataset storage with flexible structure
    
    Loader:
        - load_dataset(): Factory function that routes to appropriate implementation

Public API:
    From base.py (Generic Classes):
        Column: Generic column (name, type)
        Schema: Generic schema (columns list)
        DataRecord: Generic record (id, data, metadata)
        DataStore: Abstract storage base class
        DatasetConfig: Configuration container
        SchemaFormat: Display format enum (RAW, PRETTY)
        BaseDataset: Abstract dataset interface
    
    From sqlite.py (SQLite-Specific):
        SqliteColumn: Column with SQL constraints + to_sql_def() method
        SqliteSchema: Schema with to_create_table_sql() and show() methods
        SQLiteDataset: SQLite implementation
    
    From json.py (JSON-Specific):
        JSONDataset: JSON implementation
    
    Loader:
        load_dataset(): Routes to correct implementation based on config.engine

Example:
    >>> from agentbyte.dataset import load_dataset, SchemaFormat
    
    # SQLite Dataset
    >>> ds = load_dataset("contracts/asmd")  # Returns SQLiteDataset
    >>> print(ds.engine)  # "sqlite"
    >>> conn = ds.connect()  # sqlite3.Connection
    >>> ds.schema.show()  # Display schema (SqliteSchema method)
    >>> rows = conn.execute("SELECT * FROM contracts_asmd").fetchall()
    
    # JSON Dataset
    >>> ds = load_dataset("documents/wiki")  # Returns JSONDataset if engine="json"
    >>> print(ds.engine)  # "json"
    >>> data = ds.connect()  # dict with {"records": [...]}
    >>> for record in data.get("records", []):
    ...     print(record)
"""

from agentbyte.dataset.base import (
    BaseDataset,
    Column,
    DataRecord,
    DataStore,
    DatasetConfig,
    Schema,
    SchemaFormat,
)
from agentbyte.dataset.sqlite import (
    SqliteColumn,
    SqliteSchema,
    SQLiteDataset,
)
from agentbyte.dataset.json import JSONDataset
from agentbyte.dataset.loader import load_dataset

__all__ = [
    # Schema definitions
    "Column",
    "SqliteColumn",
    "Schema",
    "SqliteSchema",
    "SchemaFormat",
    # Records and storage
    "DataRecord",
    "DataStore",
    # Configuration
    "DatasetConfig",
    # Base interface
    "BaseDataset",
    # Implementations
    "SQLiteDataset",
    "JSONDataset",
    # Loader
    "load_dataset",
]
