"""
Session persistence for agents.

Provides the Session data model, BaseSession abstract interface,
and InMemorySession — a volatile in-memory implementation suitable
for tests and examples (mirrors the ListMemory / BaseMemory pattern).

Callers use Session for any persistent, message-bearing agent context:
  - chatbot dialogues (use metadata={"type": "conversation"})
  - content generation workspaces (use metadata={"name": "Blog Post"})
  - any other multi-turn persistent session
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import UTC, datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import Field

from agentbyte.context import AgentContext
from agentbyte.entity import Entity
from agentbyte.messages import Message


class Session(Entity):
    """A persistent, message-bearing agent session.

    Serves as the single unified persistence model for all session types
    (chatbot dialogue, content generation, etc.). Callers use ``metadata``
    to attach domain-specific fields such as ``name`` or ``type``.
    """

    created_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When the session was created",
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When the session was last modified",
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Caller-supplied metadata (user id, topic, name, type, etc.)",
    )
    messages: List[Message] = Field(
        default_factory=list,
        description="All non-system messages in chronological order",
    )

    def to_context(self) -> AgentContext:
        """Hydrate an :class:`AgentContext` from this session."""
        return AgentContext(
            messages=list(self.messages),
            metadata=dict(self.metadata),
            session_id=str(self.id),
            created_at=self.created_at,
        )

    @classmethod
    def from_context(cls, context: AgentContext, id: UUID) -> "Session":
        """Build a new session snapshot from an existing context."""
        created = context.created_at if context.created_at else datetime.now(UTC)
        return cls(
            id=id,
            created_at=created,
            updated_at=datetime.now(UTC),
            metadata=dict(context.metadata),
            messages=list(context.messages),
        )


class BaseSession(ABC):
    """Abstract base for session stores (port / interface)."""

    @abstractmethod
    async def get(self, id: UUID) -> Optional[Session]:
        """Return the session for *id*, or ``None`` if not found."""

    @abstractmethod
    async def save(self, session: Session) -> None:
        """Persist a session (create or full replace)."""

    @abstractmethod
    async def append_message(self, id: UUID, message: Message) -> None:
        """Append *message* to an existing session.

        Raises :class:`KeyError` if *id* is not found.
        """


class InMemorySession(BaseSession):
    """Volatile in-memory session store.

    Suitable for unit tests and examples; not for production use.
    Follows the same semantics as :class:`~agentbyte.memory.ListMemory`.
    """

    def __init__(self) -> None:
        self._store: Dict[UUID, Session] = {}

    async def get(self, id: UUID) -> Optional[Session]:
        session = self._store.get(id)
        return session.model_copy(deep=True) if session is not None else None

    async def save(self, session: Session) -> None:
        stored = session.model_copy(deep=True)
        stored = stored.model_copy(update={"updated_at": datetime.now(UTC)})
        self._store[stored.id] = stored

    async def append_message(self, id: UUID, message: Message) -> None:
        session = self._store.get(id)
        if session is None:
            raise KeyError(f"Session {id!r} not found")
        session.messages.append(message)
        session.updated_at = datetime.now(UTC)


__all__ = ["Session", "BaseSession", "InMemorySession"]
