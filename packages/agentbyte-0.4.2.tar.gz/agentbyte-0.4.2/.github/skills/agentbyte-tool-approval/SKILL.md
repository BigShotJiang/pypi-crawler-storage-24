---
name: agentbyte-tool-approval
description: Guide for implementing Human-in-the-Loop workflows in Agentbyte. Use this for pausing execution on sensitive tool calls, inspecting pending requests, and resuming after approval.
---

Use this skill for high-risk operations where you need manual oversight.

## Pattern: Approval Workflow

### 1. Set Approval Mode on the Tool
```python
from agentbyte.tools import FunctionTool, ApprovalMode

risky_tool = FunctionTool(
    process_payment,
    description="Processes sensitive payments.",
    approval_mode=ApprovalMode.ALWAYS # Force pause
)
```

### 2. Handle the Pause in the Orchestrator
```python
response = await agent.run("Charge $50 to my account.", context=context)

if response.status == "approval_needed":
    # 3. Inspect pending requests in the context
    pending = context.pending_approval_requests[0]
    print(f"Approving call to: {pending.tool_name}")

    # 4. Approve and re-run
    context.approve_tool(pending.call_id)
    final_response = await agent.run(action=None, context=context)
```

## Key Statuses
- **`response.status`**: Check for `"approval_needed"`.
- **`context.approve_tool(call_id)`**: Marks the tool call for execution.

## Guardrails
- **Context Threading:** You **must** pass the same `AgentContext` object between the first run and the approved run.
- **Metadata:** Use `context.pending_approval_requests` to see the actual tool parameters before deciding to approve.
