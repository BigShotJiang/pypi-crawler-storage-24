---
name: agentbyte-memory-tool
description: Guide for sandboxed file-system operations in Agentbyte memory. Use this when agents need to read, write, and modify files in a safe project environment.
---

Use this skill when your agent needs to persist structured data or documents in a sandbox.

## Pattern: MemoryTool and Backend
```python
from agentbyte.tools.memory_tool import MemoryTool, MemoryBackend
from agentbyte.agents import Agent

# 1. Initialize backend (sandboxed or direct)
backend = MemoryBackend(root_dir="agent_knowledge_base", sandbox=True)

# 2. Initialize the tool
memory_tool = MemoryTool(memory_backend=backend)

# 3. Register as a tool
agent = Agent(
    name="knowledge-agent",
    model_client=client,
    tools=[memory_tool] # Agent gets 'create', 'view', 'str_replace', 'insert' commands
)

await agent.run("Create a file called 'notes.txt' with the text 'Hello World'.")
```

## Available Operations
- `create`: Create a new file with initial content.
- `view`: Read part or all of a file.
- `str_replace`: Change exact strings within a file.
- `insert`: Add content at a specific line.
- `delete`: Remove a file or directory.

## Guardrails
- **Sandbox:** Always use `sandbox=True` for agent-facing file operations to prevent path transversal.
- **Root Dir:** Ensure the `root_dir` exists or the backend has permissions to create it.
- **Context:** `MemoryTool` is meant for long-term file storage, separate from conversation history.
