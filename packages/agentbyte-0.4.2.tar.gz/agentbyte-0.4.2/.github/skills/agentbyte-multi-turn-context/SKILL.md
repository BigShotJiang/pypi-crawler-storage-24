---
name: agentbyte-multi-turn-context
description: Guide for managing Agentbyte multi-turn conversations using a caller-owned AgentContext. Use this when implementing stateful chats, threading conversation history, or isolating user sessions.
---

Use this skill when building conversational agents that need to remember previous turns.

## Pattern: Context Threading
```python
from agentbyte.context import AgentContext
from agentbyte.agents import Agent

# 1. Create caller-owned context
session_context = AgentContext(metadata={"session_id": "user-123"})

agent = Agent(name="chat-bot", ...)

# 2. First Turn
response1 = await agent.run("Hi, I am Alex", context=session_context)

# 3. Second Turn (Re-pass the context from the response)
response2 = await agent.run("What is my name?", context=response1.context)

print(response2.messages[-1].content) # "Your name is Alex"
```

## Key Attributes
- **`context.messages`**: Access the conversation history.
- **`context.metadata`**: Dictionary of custom data carried across turns.

## Guardrails
- **Stateless Agents:** Never store conversation history on the `Agent` object itself.
- **Context Ownership:** The application caller is responsible for persisting and passing the `AgentContext`.
- **Model Client vs Context:** `AgentContext` stores messages; `model_client` handles the LLM API calls.
