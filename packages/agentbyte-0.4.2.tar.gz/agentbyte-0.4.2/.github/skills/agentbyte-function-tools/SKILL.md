---
name: agentbyte-function-tools
description: Guide for creating Agentbyte FunctionTools from Python functions or using the @tool decorator. Use this when defining agent capabilities, configuring ToolResult objects, or setting tool ApprovalMode.
---

Use this skill when defining tools that an Agentbyte agent can execute.

## Patterns

### 1. Using the `@tool` decorator (Recommended for simple functions)
```python
from agentbyte.tools import tool

@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city."""
    return f"Weather in {city}: 25°C, Sunny"
```

### 2. Manual `FunctionTool` wrapping
```python
from agentbyte.tools import FunctionTool, ApprovalMode

def calculate_tax(amount: float) -> float:
    return amount * 0.15

# Manually wrapping with a description and approval mode
tax_tool = FunctionTool(
    calculate_tax,
    description="Calculate the 15% regional tax for a given amount.",
    approval_mode=ApprovalMode.ALWAYS  # Triggers explicit human-in-the-loop approval
)
```

## ToolResult usage
Returning structured data from tools:
```python
from agentbyte.types import ToolResult

def complex_operation():
    return ToolResult(content="Operation summary", metadata={"id": 123})
```

## Guardrails
- **Docstrings:** Always provide clear docstrings for tool functions; these are sent to the LLM as the tool description.
- **Imports:** Import from `agentbyte.tools` or `agentbyte.types`.
- **Statelessness:** Tools should ideally be stateless or operate on resources provided via arguments.
