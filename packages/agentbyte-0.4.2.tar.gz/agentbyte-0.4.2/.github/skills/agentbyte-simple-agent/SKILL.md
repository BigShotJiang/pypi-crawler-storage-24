---
name: agentbyte-simple-agent
description: Guide for creating basic Agentbyte agents for simple reasoning, tool use, and structured output. Use this when starting an agent project or setting up agents for single reasoning turns without complex state.
---

Use this skill when initializing the core reasoning agent in Agentbyte.

## Patterns

### 1. Simple Reasoning Agent
```python
from agentbyte.agents import Agent
from agentbyte.llm.openai import OpenAIChatCompletionClient

client = OpenAIChatCompletionClient.from_api_key(model="gpt-4o-mini")

simple_agent = Agent(
    name="concierge",
    description="A helpful assistant that answers user questions clearly.",
    instructions="You are a concierge. Be brief and professional.",
    model_client=client
)

result = await simple_agent.run("What is the time in London?")
print(result.messages[-1].content)
```

### 2. Structured Output Agent (Pydantic)
```python
from pydantic import BaseModel
from agentbyte.agents import Agent

class ProductReview(BaseModel):
    score: int
    summary: str

review_agent = Agent(
    name="reviewer",
    description="Extracts structured reviews from customer feedback.",
    instructions="Analyze the text and provide score (1-5) and summary.",
    model_client=client,
    output_format=ProductReview  # Enforces Pydantic model response
)
```

## Guardrails
- **Required Fields:** Always include `name`, `description`, and `instructions` in the `Agent` constructor.
- **Streaming:** Use `await agent.run_stream(...)` to access incremental message chunks.
- **Model Client:** Always pass a `model_client` (instantiated from `agentbyte.llm`).
