---
name: skill-authoring
description: Guide for creating GitHub Copilot skills with correct folder structure, SKILL.md frontmatter, and reusable instruction patterns. Use this when asked to create a new project or personal skill.
---

Use this skill when the user wants to create a new Copilot skill, structure an existing skill correctly, or convert notes/examples into a valid `SKILL.md`.

## What a valid skill requires
1. A dedicated folder for each skill inside `.github/skills/` or `~/.copilot/skills/`.
2. A file named exactly `SKILL.md` (**case-sensitive**).
3. YAML frontmatter with:
   - `name` (required, lowercase, hyphen-separated, unique, matches folder name)
   - `description` (required, clear trigger for when Copilot should use it)
   - `license` (optional)
4. A Markdown body with practical, directive instructions.

## Where to place skills
- Project-scoped (repository-specific behavior):
  - `.github/skills/<skill-name>/SKILL.md` (canonical path)
- Personal/shared across repositories:
  - `~/.copilot/skills/<skill-name>/SKILL.md`

## Naming rules
- Skill folder name and frontmatter `name` **must match**.
- Use lowercase, hyphen-separated strings.
- Keep names specific to the domain (e.g. `agentbyte-llm-client`).

## Copy-ready SKILL.md template
```markdown
---
name: your-skill-name
description: One-line description of what this skill does and when Copilot should use it.
license: MIT
---

Use this skill when <trigger condition>.

## Inputs to confirm
- <input 1>
- <input 2>

## Process
1. <step 1>
2. <step 2>
3. <step 3>

## Defaults
- If <condition>, use <default behavior>.

## Guardrails
- Do not <bad practice>.
- Prefer <good practice>.
```

## Example skill skeleton
```markdown
---
name: github-actions-failure-debugging
description: Guide for debugging failing GitHub Actions workflows. Use this when asked to debug failing GitHub Actions workflows.
---

To debug failing GitHub Actions workflows in a pull request:
1. List recent workflow runs and identify failed jobs using `list_workflow_runs`.
2. Summarize failure logs with `summarize_job_log_failures`.
3. Reproduce the failure locally.
4. Fix the failing build and verify before committing.
```

## Quality checklist
- `SKILL.md` filename is exact and correctly cased.
- Frontmatter is valid YAML.
- `name` is lowercase-hyphen format and unique.
- `description` clearly states when to invoke.
- Instructions are actionable, specific, and minimal.
- Any referenced files exist in the same skill folder.
- No secrets or environment-specific credentials in examples.

## Guardrails
- Do not create one folder for multiple unrelated skills.
- Do not omit frontmatter fields required for discovery.
- Do not rely on external docs when the skill can be self-contained.
- Do not include unsafe commands without explicit warning/context.
