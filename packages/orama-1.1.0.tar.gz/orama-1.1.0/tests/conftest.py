import datetime
from unittest.mock import MagicMock

import pytest
from fields_metadata import FieldMetadata
from polychromos import HSLColor


@pytest.fixture
def categorical_metadata() -> MagicMock:
    mock = MagicMock(spec=FieldMetadata)
    mock.categorical = True
    mock.numeric = False
    mock.derived = False
    mock.effective_type = str
    mock.extra = {}
    return mock


@pytest.fixture
def numeric_metadata() -> MagicMock:
    mock = MagicMock(spec=FieldMetadata)
    mock.categorical = False
    mock.numeric = True
    mock.derived = False
    mock.effective_type = float
    mock.extra = {}
    return mock


@pytest.fixture
def derived_numeric_metadata() -> MagicMock:
    mock = MagicMock(spec=FieldMetadata)
    mock.categorical = False
    mock.numeric = True
    mock.derived = True
    mock.effective_type = float
    mock.extra = {}
    return mock


@pytest.fixture
def datetime_metadata() -> MagicMock:
    mock = MagicMock(spec=FieldMetadata)
    mock.categorical = False
    mock.numeric = False
    mock.derived = False
    mock.effective_type = datetime.date
    mock.extra = {}
    return mock


@pytest.fixture
def datetime_datetime_metadata() -> MagicMock:
    mock = MagicMock(spec=FieldMetadata)
    mock.categorical = False
    mock.numeric = False
    mock.derived = False
    mock.effective_type = datetime.datetime
    mock.extra = {}
    return mock


@pytest.fixture
def country_code_metadata() -> MagicMock:
    mock = MagicMock(spec=FieldMetadata)
    mock.categorical = False
    mock.numeric = False
    mock.derived = False
    mock.effective_type = str
    mock.extra = {"suggested_validation": "iso_a2"}
    return mock


@pytest.fixture
def anchor_color() -> HSLColor:
    return HSLColor(hue=0.0, saturation=0.5, lightness=0.5)


@pytest.fixture
def anchor_colors(anchor_color: HSLColor) -> list[HSLColor]:
    return [anchor_color]


@pytest.fixture
def tr() -> MagicMock:
    from babel.support import Translations

    mock = MagicMock(spec=Translations)
    mock.gettext.side_effect = lambda x: x
    return mock


@pytest.fixture
def theme(anchor_color: HSLColor) -> MagicMock:
    from orama.theme import Theme

    mock = MagicMock(spec=Theme)
    mock.get_color.return_value = anchor_color
    mock.get_default_color_sequence.return_value = [anchor_color]
    mock.plotly_template.return_value = MagicMock()
    return mock


@pytest.fixture
def month_metadata() -> MagicMock:
    mock = MagicMock(spec=FieldMetadata)
    mock.effective_type = int
    mock.extra = {"suggested_validation": "month"}
    return mock


@pytest.fixture
def dow_metadata() -> MagicMock:
    mock = MagicMock(spec=FieldMetadata)
    mock.effective_type = int
    mock.extra = {"suggested_validation": "dow"}
    return mock
