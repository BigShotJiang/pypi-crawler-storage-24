from typing import Optional
from dataclasses import dataclass

from bussdcc.event import Event
from bussdcc.message import Message, Severity


@dataclass(slots=True, frozen=True)
class SinkHandlerError(Message):
    severity = Severity.ERROR

    sink: str
    error: str
    evt: Event[Message] | None = None
    traceback: str | None = None
