"""NVFlare adapter script - bridges FLTrainer interface to NVFlare Client API.

This script is copied into app/custom/ of every generated NVFlare job.
It is executed by PTInProcessClientAPIExecutor. Users never edit this file.

It:
1. Reads template.yaml to find the trainer class
2. Dynamically imports and instantiates the trainer
3. Calls setup() with data_path and hyperparams
4. FL loop: flare.receive() -> train() -> validate() -> flare.send()
"""

import importlib.util
import json
import logging
import os
import sys
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("fl_trainer_adapter")


def import_module_from_file(module_name, file_path):
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module from {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def find_fl_trainer_subclass(module):
    """Find the FLTrainer subclass in the given module."""
    from naira_fl_sdk.trainer import FLTrainer

    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if (
            isinstance(attr, type)
            and issubclass(attr, FLTrainer)
            and attr is not FLTrainer
        ):
            return attr
    return None


def main():
    import nvflare.client as flare
    import yaml

    # Find custom/ directory (where this script lives)
    custom_dir = Path(__file__).parent.resolve()
    if str(custom_dir) not in sys.path:
        sys.path.insert(0, str(custom_dir))

    # Load hyperparams from file (avoids NVFlare config curly-brace parsing issues)
    hp_file = custom_dir / "hyperparams.json"
    if hp_file.exists():
        with open(hp_file) as f:
            hyperparams = json.load(f)
    else:
        hyperparams = {}

    # Load template.yaml
    manifest_path = custom_dir / "template.yaml"
    if not manifest_path.exists():
        raise FileNotFoundError(f"template.yaml not found in {custom_dir}")

    with open(manifest_path) as f:
        manifest = yaml.safe_load(f)

    # Merge manifest hyperparams defaults with overrides
    manifest_hp = {}
    for k, v in manifest.get("hyperparameters", {}).items():
        if isinstance(v, dict):
            manifest_hp[k] = v.get("default", v)
        else:
            manifest_hp[k] = v
    manifest_hp.update(hyperparams)

    # Import trainer
    trainer_file = manifest.get("trainer", {}).get("file", "trainer.py")
    trainer_path = custom_dir / trainer_file
    trainer_module = import_module_from_file("_user_trainer", trainer_path)
    trainer_cls = find_fl_trainer_subclass(trainer_module)
    if trainer_cls is None:
        raise ValueError(f"No FLTrainer subclass found in {trainer_file}")

    # Initialize NVFlare Client API (must be called before get_site_name)
    flare.init()

    # Determine data path
    site_name = flare.get_site_name() if hasattr(flare, "get_site_name") else "site-1"
    data_path = f"/data/{site_name}"
    if not os.path.exists(data_path):
        data_path = "/data"
    trainer = trainer_cls()
    logger.info(f"Setting up trainer: {trainer_cls.__name__}, data: {data_path}")
    trainer.setup(data_path, manifest_hp)
    model = trainer.get_model()

    # FL training loop
    while flare.is_running():
        input_model = flare.receive()
        if input_model is None:
            break

        logger.info(f"Round {input_model.current_round + 1}")

        # Load global weights
        model.load_state_dict(input_model.params)

        # Train
        train_metrics = trainer.train(model)
        logger.info(f"Train metrics: {train_metrics}")

        # Validate
        val_metrics = trainer.validate(model)
        if val_metrics:
            logger.info(f"Val metrics: {val_metrics}")

        # Build phase-tagged metrics for flexible pipeline
        phased_metrics = {"train": train_metrics, "validate": val_metrics}
        num_samples = train_metrics.get("num_samples", 0)

        # Send updated weights back
        # FLModel.metrics stays flat (validate metrics) so IntimeModelSelector works unchanged
        output_model = flare.FLModel(
            params=model.state_dict(),
            params_type=input_model.params_type,
            metrics=val_metrics,
            meta={
                "NUM_STEPS_CURRENT_ROUND": num_samples,
                "phased_metrics": phased_metrics,
            },
        )
        flare.send(output_model)

    logger.info("Training complete.")


if __name__ == "__main__":
    main()
