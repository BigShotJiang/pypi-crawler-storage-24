"""
Command-line interface for pygsadf.

Usage:
    pygsadf --csv data.csv --col log_price --B 1499 --out result.pkl
    pygsadf --csv data.csv --col close --log --B 199 --plot result.png
"""

from __future__ import annotations

import argparse
import sys

import numpy as np
import pandas as pd


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="pygsadf",
        description="GSADF bubble detection (PSY 2015) with parallel wild bootstrap",
    )
    parser.add_argument("--csv", required=True, help="CSV file with time series")
    parser.add_argument("--col", required=True, help="Column name to test")
    parser.add_argument("--log", action="store_true",
                        help="Apply log() to the series (if raw prices)")
    parser.add_argument("--B", type=int, default=1499,
                        help="Bootstrap replications (default 1499)")
    parser.add_argument("--max-lag", type=int, default=12,
                        help="Maximum ADF lag (BIC selects)")
    parser.add_argument("--seed", type=int, default=42, help="RNG seed")
    parser.add_argument("--n-jobs", type=int, default=-1,
                        help="Parallel workers (-1 = all cores)")
    parser.add_argument("--out", help="Save result pickle to this path")
    parser.add_argument("--plot", help="Save BSADF plot to this path (PNG/PDF)")
    parser.add_argument("--quiet", action="store_true", help="Suppress output")

    args = parser.parse_args(argv)

    # Import here to show clean help even without dependencies
    from pygsadf import gsadf

    # Load data
    df = pd.read_csv(args.csv, index_col=0, parse_dates=True)
    if args.col not in df.columns:
        print(f"Error: column '{args.col}' not in {df.columns.tolist()}", file=sys.stderr)
        sys.exit(1)

    series = df[args.col].dropna()
    if args.log:
        series = np.log(series)

    # Run
    result = gsadf(
        series,
        B=args.B,
        max_lag=args.max_lag,
        seed=args.seed,
        n_jobs=args.n_jobs,
        verbose=not args.quiet,
    )

    # Output
    if not args.quiet:
        print(result.summary())

    if args.out:
        result.to_pickle(args.out)

    if args.plot:
        fig = result.plot()
        fig.savefig(args.plot, dpi=180, bbox_inches="tight")
        print(f"Plot saved: {args.plot}")


if __name__ == "__main__":
    main()
