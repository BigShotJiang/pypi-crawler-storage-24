"""
pygsadf -- Fast parallel GSADF bubble detection (PSY 2015)
==========================================================

The first Python package to deliver production-grade, parallelised
Generalised Sup ADF testing with wild-bootstrap critical values at
90 %, 95 %, and 99 % confidence levels.

Quick start
-----------
>>> import pygsadf
>>> result = pygsadf.gsadf(y)              # NumPy array of log-prices
>>> result = pygsadf.gsadf(series)         # or a pandas Series
>>> result.gsadf_stat                      # scalar GSADF statistic
>>> result.reject_h0(0.95)                 # True / False
>>> result.bubbles                         # list of (start, end) episodes
>>> result.plot()                          # matplotlib figure

Reference
---------
Phillips, Shi & Yu (2015). "Testing for Multiple Bubbles: Historical
Episodes of Exuberance and Collapse in the S&P 500."
*International Economic Review*, 56(4), 1043-1078.
"""

__version__ = "2.0.0"

from pygsadf.core import gsadf, GSADFResult
from pygsadf.bootstrap import wild_bootstrap_cv
from pygsadf.datestamp import date_stamp_bubbles

__all__ = [
    "gsadf",
    "GSADFResult",
    "wild_bootstrap_cv",
    "date_stamp_bubbles",
    "__version__",
]
