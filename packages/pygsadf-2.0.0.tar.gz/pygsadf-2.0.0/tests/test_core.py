"""
Tests for pygsadf core functionality.

Covers:
  - ADF kernel correctness
  - BSADF computation
  - Full pipeline with small B
  - Edge cases
  - Reproducibility
"""

import numpy as np
import pandas as pd
import pytest


class TestADFKernel:
    """Test the right-tailed ADF t-statistic."""

    def test_unit_root_tstat_near_zero(self):
        """Under unit root, ADF t-stat should NOT be large positive."""
        from pygsadf.adf import adf_tstat

        rng = np.random.default_rng(42)
        y = np.cumsum(rng.standard_normal(500))
        stat = adf_tstat(y, max_lag=4)
        # Unit root: stat should be negative or small
        assert stat < 3.0, f"Unit root series gave suspiciously high t-stat: {stat}"

    def test_explosive_series(self):
        """Explosive AR(1) should give large positive t-stat."""
        from pygsadf.adf import adf_tstat

        rng = np.random.default_rng(123)
        y = np.zeros(200)
        y[0] = 1.0
        for t in range(1, 200):
            y[t] = 1.05 * y[t - 1] + 0.1 * rng.standard_normal()
        stat = adf_tstat(y, max_lag=4)
        assert stat > 2.0, f"Explosive series gave low t-stat: {stat}"

    def test_fixed_lag(self):
        """Fixed lag should return a valid statistic."""
        from pygsadf.adf import adf_tstat

        rng = np.random.default_rng(42)
        y = np.cumsum(rng.standard_normal(200))
        stat = adf_tstat(y, max_lag=12, fixed_lag=2)
        assert np.isfinite(stat)

    def test_short_series(self):
        """Very short series should return NaN gracefully."""
        from pygsadf.adf import adf_tstat

        y = np.array([1.0, 1.1, 1.2])
        stat = adf_tstat(y, max_lag=1)
        # Should be NaN or a valid float, not crash
        assert isinstance(stat, float)


class TestBSADF:
    """Test BSADF computation."""

    def test_bsadf_shape(self):
        """BSADF output should match input length."""
        from pygsadf.bsadf import compute_gsadf_bsadf

        rng = np.random.default_rng(42)
        y = np.cumsum(rng.standard_normal(100))
        gsadf_stat, bsadf = compute_gsadf_bsadf(y, r0=0.2, max_lag=4, verbose=False)

        assert len(bsadf) == 100
        assert np.isfinite(gsadf_stat)
        assert gsadf_stat == pytest.approx(np.nanmax(bsadf), abs=1e-10)

    def test_gsadf_is_sup_of_bsadf(self):
        """GSADF should equal the supremum of the BSADF sequence."""
        from pygsadf.bsadf import compute_gsadf_bsadf

        rng = np.random.default_rng(99)
        y = np.cumsum(rng.standard_normal(150))
        gsadf_stat, bsadf = compute_gsadf_bsadf(y, r0=0.15, max_lag=4, verbose=False)

        assert gsadf_stat == pytest.approx(float(np.nanmax(bsadf)), abs=1e-10)


class TestDateStamp:
    """Test bubble date-stamping."""

    def test_no_bubbles_under_cv(self):
        """If BSADF is always below CV, no bubbles should be detected."""
        from pygsadf.datestamp import date_stamp_bubbles

        bsadf = np.array([0.5, 0.3, 0.4, 0.2, 0.1, 0.3, 0.2])
        cv = np.ones(7) * 1.0
        bubbles = date_stamp_bubbles(bsadf, cv, min_duration=2)
        assert len(bubbles) == 0

    def test_single_bubble(self):
        """Clear exceedance should produce one bubble."""
        from pygsadf.datestamp import date_stamp_bubbles

        bsadf = np.array([0.0, 0.0, 2.0, 2.0, 2.0, 2.0, 2.0, 0.0, 0.0])
        cv = np.ones(9) * 1.0
        bubbles = date_stamp_bubbles(bsadf, cv, min_duration=3)
        assert len(bubbles) == 1
        assert bubbles[0].duration_days == 4  # indices 2-6

    def test_min_duration_filter(self):
        """Short exceedance below min_duration should be filtered."""
        from pygsadf.datestamp import date_stamp_bubbles

        bsadf = np.array([0.0, 2.0, 2.0, 0.0, 0.0])
        cv = np.ones(5) * 1.0
        bubbles = date_stamp_bubbles(bsadf, cv, min_duration=5)
        assert len(bubbles) == 0


class TestFullPipeline:
    """Integration test for the full gsadf() function."""

    def test_quick_run(self):
        """Smoke test: full pipeline with tiny B."""
        from pygsadf import gsadf

        rng = np.random.default_rng(42)
        y = np.cumsum(rng.standard_normal(100))
        result = gsadf(y, B=9, max_lag=4, verbose=False, n_jobs=1)

        assert result.T == 100
        assert np.isfinite(result.gsadf_stat)
        assert "95%" in result.cv
        assert "99%" in result.cv
        assert len(result.bsadf) == 100
        assert isinstance(result.reject_h0(0.95), bool)
        assert result.B == 9

    def test_pandas_series_input(self):
        """Should accept pandas Series with DatetimeIndex."""
        from pygsadf import gsadf

        rng = np.random.default_rng(42)
        dates = pd.date_range("2020-01-01", periods=100, freq="D")
        series = pd.Series(np.cumsum(rng.standard_normal(100)), index=dates)

        result = gsadf(series, B=9, max_lag=4, verbose=False, n_jobs=1)
        assert result.dates is not None
        assert result.T == 100

    def test_reproducibility(self):
        """Same seed should give identical results."""
        from pygsadf import gsadf

        rng = np.random.default_rng(42)
        y = np.cumsum(rng.standard_normal(80))

        r1 = gsadf(y, B=9, seed=123, max_lag=4, verbose=False, n_jobs=1)
        r2 = gsadf(y, B=9, seed=123, max_lag=4, verbose=False, n_jobs=1)

        assert r1.gsadf_stat == r2.gsadf_stat
        assert r1.cv == r2.cv
        np.testing.assert_array_equal(r1.bsadf, r2.bsadf)

    def test_summary_string(self):
        """Summary should be a non-empty string."""
        from pygsadf import gsadf

        rng = np.random.default_rng(42)
        y = np.cumsum(rng.standard_normal(80))
        result = gsadf(y, B=9, max_lag=4, verbose=False, n_jobs=1)

        summary = result.summary()
        assert "GSADF" in summary
        assert "CV" in summary

    def test_short_series_error(self):
        """Series < 50 should raise ValueError."""
        from pygsadf import gsadf

        with pytest.raises(ValueError, match="too short"):
            gsadf(np.array([1.0, 2.0, 3.0]), B=9)

    def test_to_dict_roundtrip(self):
        """to_dict -> from_dict should preserve all data."""
        from pygsadf import gsadf, GSADFResult

        rng = np.random.default_rng(42)
        y = np.cumsum(rng.standard_normal(80))
        result = gsadf(y, B=9, max_lag=4, verbose=False, n_jobs=1)

        d = result.to_dict()
        restored = GSADFResult.from_dict(d)

        assert restored.gsadf_stat == result.gsadf_stat
        assert restored.cv == result.cv
        assert restored.T == result.T
