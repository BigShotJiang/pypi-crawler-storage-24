"""Tests for PDF generation."""

from __future__ import annotations

import base64
from unittest.mock import AsyncMock, patch

from browser_hybrid import Browser


class TestPDF:
    @patch("browser_hybrid.browser.Browser._get_connection")
    @patch("browser_hybrid.browser.Browser._send_cdp")
    def test_pdf_basic(self, mock_send_cdp, mock_get_conn, tmp_path):
        """Test basic PDF generation."""
        mock_get_conn.return_value = AsyncMock()
        mock_send_cdp.return_value = {"data": base64.b64encode(b"%PDF-1.4").decode()}

        browser = Browser()
        pdf_path = str(tmp_path / "output.pdf")
        result = browser.pdf(pdf_path)

        assert result == pdf_path
        assert mock_send_cdp.call_count == 1

        # Verify call parameters
        call_args = mock_send_cdp.call_args
        assert call_args.args[1] == "Page.printToPDF"
        params = call_args.args[2]
        assert params["landscape"] is False
        assert params["paperWidth"] == 8.5

    @patch("browser_hybrid.browser.Browser._get_connection")
    @patch("browser_hybrid.browser.Browser._send_cdp")
    def test_pdf_with_landscape(self, mock_send_cdp, mock_get_conn, tmp_path):
        """Test PDF with landscape orientation."""
        mock_get_conn.return_value = AsyncMock()
        mock_send_cdp.return_value = {"data": base64.b64encode(b"%PDF-1.4").decode()}

        browser = Browser()
        pdf_path = str(tmp_path / "landscape.pdf")
        browser.pdf(pdf_path, landscape=True)

        call_args = mock_send_cdp.call_args
        assert call_args.args[2]["landscape"] is True

    @patch("browser_hybrid.browser.Browser._get_connection")
    @patch("browser_hybrid.browser.Browser._send_cdp")
    def test_pdf_with_margin_params(self, mock_send_cdp, mock_get_conn, tmp_path):
        """Test PDF with custom margins."""
        mock_get_conn.return_value = AsyncMock()
        mock_send_cdp.return_value = {"data": base64.b64encode(b"%PDF-1.4").decode()}

        browser = Browser()
        pdf_path = str(tmp_path / "margins.pdf")
        browser.pdf(
            pdf_path, margin_top=0.5, margin_bottom=0.5, margin_left=0.75, margin_right=0.75
        )

        call_args = mock_send_cdp.call_args
        params = call_args.args[2]
        assert params["marginTop"] == 0.5
        assert params["marginBottom"] == 0.5
        assert params["marginLeft"] == 0.75
        assert params["marginRight"] == 0.75

    @patch("browser_hybrid.browser.Browser._get_connection")
    @patch("browser_hybrid.browser.Browser._send_cdp")
    def test_pdf_with_templates(self, mock_send_cdp, mock_get_conn, tmp_path):
        """Test PDF with header and footer templates."""
        mock_get_conn.return_value = AsyncMock()
        mock_send_cdp.return_value = {"data": base64.b64encode(b"%PDF-1.4").decode()}

        browser = Browser()
        pdf_path = str(tmp_path / "templates.pdf")
        header = "<div>Header</div>"
        footer = "<div>Footer</div>"
        browser.pdf(pdf_path, header_template=header, footer_template=footer)

        call_args = mock_send_cdp.call_args
        params = call_args.args[2]
        assert params["displayHeaderFooter"] is True
        assert params["headerTemplate"] == header
        assert params["footerTemplate"] == footer
