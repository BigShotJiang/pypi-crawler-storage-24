# Architecture Decision Records

This directory contains Architecture Decision Records (ADRs) for Browser Hybrid.

## What is an ADR?

An ADR is a document that captures an important architectural decision, including:

- **Context** — The issue we're facing
- **Decision** — What we decided
- **Consequences** — Trade-offs, benefits, and downsides

ADRs record the **why** behind decisions, so future developers understand the reasoning.

## ADR Index

| ADR | Title | Status |
|-----|-------|--------|
| [0001](0001-accessibility-tree-approach.md) | Accessibility Tree for Element Targeting | Accepted |
| [0002](0002-runtime-evaluate-result-structure.md) | Runtime.evaluate Result Structure | Accepted |
| [0003](0003-callfunctionon-this-binding.md) | Runtime.callFunctionOn `this` Binding | Accepted |
| [0004](0004-accessibility-node-id.md) | Accessibility Node Backend DOM ID Field | Accepted |
| [0005](0005-nested-async-handling.md) | Nested Async Function Handling | Accepted |

## Creating a New ADR

1. Copy the template:

```bash
cp docs/adr/0000-template.md docs/adr/NNNN-short-title.md
```

2. Fill in the sections:
   - **Status**: Proposed / Accepted / Deprecated / Superseded
   - **Context**: What's the issue?
   - **Decision**: What did we decide?
   - **Consequences**: What are the benefits/drawbacks?

3. Update this index.

## Template

```markdown
# ADR-NNNN: Title

## Status

Proposed | Accepted | Deprecated | Superseded by ADR-XXXX

## Context

What is the issue we're seeing that motivates this decision?

## Decision

What is the change we're proposing/have made?

## Consequences

What becomes easier or harder because of this change?

## References

- Links to relevant docs, discussions, code
```