"""PDF generation example.

Chrome must be running with --remote-debugging-port=9222
"""

from browser_hybrid import Browser


def main():
    browser = Browser()

    # Basic PDF
    print("Navigating to example.com...")
    browser.goto("https://example.com")
    browser.pdf("example.pdf")
    print("Saved example.pdf")

    # PDF with options
    print("Navigating to Hacker News...")
    browser.goto("https://news.ycombinator.com")
    browser.pdf(
        "hn.pdf",
        landscape=False,
        print_background=True,
        paper_width=8.5,
        paper_height=11.0,
        margin_top=0.5,
        margin_bottom=0.5,
    )
    print("Saved hn.pdf")

    browser.close()
    print("Done!")


if __name__ == "__main__":
    main()
