"""
Screenshots example for browser-hybrid.
Demonstrates both viewport screenshots and full-page screenshots, as well as
saving the resulting image to a local file.

NOTE: Requires Chrome running with --remote-debugging-port=9222
"""

import logging

from browser_hybrid import Browser

# Configure logging to see what's happening
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    # 1. Initialize Browser
    try:
        with Browser() as browser:
            # 2. Open GitHub for demonstration
            logger.info("Opening GitHub...")
            browser.goto("https://github.com")

            # 3. Take a standard viewport screenshot
            viewport_path = "github_viewport.png"
            logger.info(f"Taking viewport screenshot and saving to {viewport_path}...")
            browser.screenshot(viewport_path)

            # 4. Take a full-page screenshot
            # Some pages are very long, so browser-hybrid can capture the full content area.
            fullpage_path = "github_fullpage.png"
            logger.info(f"Taking full-page screenshot and saving to {fullpage_path}...")
            # Set full_page=True in browser-hybrid screenshot call
            browser.screenshot(fullpage_path, full_page=True)

            # 5. Success!
            logger.info("Screenshot demonstration completed successfully.")

    except ConnectionError as e:
        logger.error(f"Failed to connect to Chrome: {e}")
        logger.error("Is Chrome running with --remote-debugging-port=9222?")
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")


if __name__ == "__main__":
    main()
