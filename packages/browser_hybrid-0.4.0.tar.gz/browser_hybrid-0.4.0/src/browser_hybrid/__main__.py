"""CLI entry point for python -m browser_hybrid."""

from __future__ import annotations

from .cli import main

if __name__ == "__main__":
    main()
