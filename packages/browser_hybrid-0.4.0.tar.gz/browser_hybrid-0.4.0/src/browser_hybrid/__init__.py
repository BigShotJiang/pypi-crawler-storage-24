"""
Browser Hybrid - Chrome DevTools with accessibility-tree semantics.

A Python library combining Chrome DevTools Protocol with accessibility semantics
for browser automation using your authenticated Chrome sessions.

Example:
    from browser_hybrid import Browser

    browser = Browser()
    browser.goto("https://gmail.com")  # Uses your logged-in session

    tree = browser.accessibility_tree()
    print(tree.to_tree_str())

    browser.click_by_text("Sign in")
    browser.fill_form({"Email": "user@example.com"})
"""

from __future__ import annotations

import logging

from .browser import (
    Browser,
    BrowserError,
    CDPError,
    ConnectionError,
    TabError,
    TimeoutError,
)
from .models import AXNode, BrowserInfo, Tab

# Configure default logging for the package
logging.basicConfig(level=logging.WARNING)

__all__ = [
    "Browser",
    "Tab",
    "AXNode",
    "BrowserInfo",
    "BrowserError",
    "CDPError",
    "ConnectionError",
    "TabError",
    "TimeoutError",
]

__version__ = "0.4.0"
