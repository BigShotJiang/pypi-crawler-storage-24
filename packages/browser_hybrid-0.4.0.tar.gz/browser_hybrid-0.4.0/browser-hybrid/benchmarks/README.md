# Benchmarks

Performance benchmarks comparing browser-hybrid against Playwright, Selenium, and agent-browser.

## Setup

```bash
# Install browser-hybrid
pip install -e ..
# or: pip install browser-hybrid

# Install competitors
pip install playwright && playwright install chromium
pip install selenium
pip install agent-browser  # if available

# Chrome must be running with --remote-debugging-port=9222
# e.g.: google-chrome --remote-debugging-port=9222
```

## Run Benchmarks

```bash
python -m benchmarks.run_benchmarks
```

## Structure

```
benchmarks/
├── run_benchmarks.py     # CLI entry point
├── runner.py            # Benchmark runner + timing
├── compare.py           # Generate comparison tables
├── scenarios/
│   ├── base.py          # BaseScenario abstract class
│   ├── navigation.py    # Cold navigation benchmark
│   ├── click_performance.py
│   ├── form_fill.py
│   ├── screenshot.py
│   └── accessibility_tree.py
└── results/             # Stored JSON results
```

## Metrics

- `mean_ms` — mean latency
- `p50_ms` — median latency
- `p95_ms` — 95th percentile
- `p99_ms` — 99th percentile
- `success_rate` — % of runs without error
- `runs` — number of iterations

## Test URLs

Benchmarks use stable reference pages:
- `https://example.com` — minimal page for cold tests
- `https://www.wikipedia.org` — real-world content
- `https://www.google.com` — dynamic JS-heavy page
