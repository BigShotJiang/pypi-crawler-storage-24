"""Accessibility tree benchmark — browser-hybrid and agent-browser only.

Playwright and Selenium don't expose an accessibility tree API by default.
"""

from .base import BaseScenario


class AccessibilityTreeScenario(BaseScenario):
    """Benchmark accessibility tree retrieval.
    
    Only browser-hybrid and agent-browser expose accessibility trees.
    Playwright has ARIA roles but not the same semantic AX tree.
    
    Test: Get full accessibility tree of https://example.com
    """

    name = "accessibility_tree"
    description = "Get full accessibility tree"
    runs = 20

    TARGET_URL = "https://example.com"

    def setup(self) -> None:
        pass

    def warmup(self) -> None:
        browser = self._bh_browser()
        browser.navigate(self.TARGET_URL)
        browser.accessibility_tree()
        browser.close()

    def run_browser_hybrid(self):
        """browser-hybrid: get accessibility tree."""
        browser = self._bh_browser()
        browser.navigate(self.TARGET_URL)
        tree = browser.accessibility_tree()
        browser.close()
        return tree is not None and len(tree) > 0

    def run_playwright(self):
        """Playwright: No direct AX tree — skip."""
        # Playwright has accessibility API but it's different (snapshot-based)
        # We'll use page.accessibility.snapshot() for comparison
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(self.TARGET_URL)
            snapshot = page.accessibility.snapshot()
            browser.close()
        return snapshot is not None

    def run_selenium(self):
        """Selenium: No AX tree — skip."""
        # Selenium has no accessibility API
        return None  # Not applicable

    def run_agent_browser(self):
        """agent-browser: get accessibility tree."""
        try:
            from agent_browser import Browser
            browser = Browser()
            browser.navigate(self.TARGET_URL)
            tree = browser.accessibility_tree()
            browser.close()
            return tree is not None and len(tree) > 0
        except ImportError:
            return False

    def _bh_browser(self):
        from browser_hybrid import Browser
        return Browser()
