"""Click performance benchmark."""

from .base import BaseScenario


class ClickScenario(BaseScenario):
    """Benchmark click operations.
    
    Navigate to a page with clickable elements, measure time to
    complete a click operation (find element + click).
    
    Test: Click "More information" link on https://example.com
    """

    name = "click"
    description = "Click a link/button by text"
    runs = 20

    TARGET_URL = "https://example.com"
    TARGET_TEXT = "More information"

    def setup(self) -> None:
        pass

    def warmup(self) -> None:
        b = self._bh_browser()
        b.navigate(self.TARGET_URL)
        b.close()

    def run_browser_hybrid(self):
        """browser-hybrid: click by text."""
        browser = self._bh_browser()
        browser.navigate(self.TARGET_URL)
        browser.click_by_text(self.TARGET_TEXT)
        browser.close()
        return True

    def run_playwright(self):
        """Playwright: click by text."""
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(self.TARGET_URL)
            page.get_by_text(self.TARGET_TEXT).click()
            browser.close()
        return True

    def run_selenium(self):
        """Selenium: click by text."""
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        opts = Options()
        opts.add_argument("--headless")
        driver = webdriver.Chrome(options=opts)
        driver.get(self.TARGET_URL)
        driver.find_element("link text", self.TARGET_TEXT).click()
        driver.quit()
        return True

    def run_agent_browser(self):
        """agent-browser: click by text."""
        try:
            from agent_browser import Browser
            browser = Browser()
            browser.navigate(self.TARGET_URL)
            browser.click_by_text(self.TARGET_TEXT)
            browser.close()
            return True
        except ImportError:
            return False

    def _bh_browser(self):
        from browser_hybrid import Browser
        return Browser()
