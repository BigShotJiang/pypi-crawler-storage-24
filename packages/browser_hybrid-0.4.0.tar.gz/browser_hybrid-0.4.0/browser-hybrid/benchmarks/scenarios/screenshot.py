"""Screenshot benchmark."""

import tempfile
import os
from .base import BaseScenario


class ScreenshotScenario(BaseScenario):
    """Benchmark screenshot capture.
    
    Navigate to a page and take a screenshot.
    
    Test: Screenshot of https://example.com (simple) and
    https://www.wikipedia.org (more complex).
    """

    name = "screenshot"
    description = "Navigate and take screenshot"
    runs = 15

    TARGET_URL = "https://example.com"
    COMPLEX_URL = "https://www.wikipedia.org"

    def setup(self) -> None:
        self._tmpdir = tempfile.mkdtemp()
        self._simple_path = os.path.join(self._tmpdir, "simple.png")
        self._complex_path = os.path.join(self._tmpdir, "complex.png")

    def teardown(self) -> None:
        import shutil
        shutil.rmtree(self._tmpdir, ignore_errors=True)

    def run_browser_hybrid(self):
        """browser-hybrid: navigate + screenshot."""
        browser = self._bh_browser()
        browser.navigate(self.TARGET_URL)
        browser.screenshot(self._simple_path)
        browser.navigate(self.COMPLEX_URL)
        browser.screenshot(self._complex_path)
        browser.close()
        return os.path.exists(self._simple_path) and os.path.exists(self._complex_path)

    def run_playwright(self):
        """Playwright: navigate + screenshot."""
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(self.TARGET_URL)
            page.screenshot(path=self._simple_path)
            page.goto(self.COMPLEX_URL)
            page.screenshot(path=self._complex_path)
            browser.close()
        return os.path.exists(self._simple_path) and os.path.exists(self._complex_path)

    def run_selenium(self):
        """Selenium: navigate + screenshot."""
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        opts = Options()
        opts.add_argument("--headless")
        driver = webdriver.Chrome(options=opts)
        driver.get(self.TARGET_URL)
        driver.save_screenshot(self._simple_path)
        driver.get(self.COMPLEX_URL)
        driver.save_screenshot(self._complex_path)
        driver.quit()
        return os.path.exists(self._simple_path) and os.path.exists(self._complex_path)

    def run_agent_browser(self):
        """agent-browser: navigate + screenshot."""
        try:
            from agent_browser import Browser
            browser = Browser()
            browser.navigate(self.TARGET_URL)
            browser.screenshot(self._simple_path)
            browser.navigate(self.COMPLEX_URL)
            browser.screenshot(self._complex_path)
            browser.close()
            return os.path.exists(self._simple_path) and os.path.exists(self._complex_path)
        except ImportError:
            return False

    def _bh_browser(self):
        from browser_hybrid import Browser
        return Browser()
