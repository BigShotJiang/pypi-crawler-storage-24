"""Navigation benchmark — cold start to page load."""

from .base import BaseScenario


class NavigationScenario(BaseScenario):
    """Benchmark cold navigation to a URL.
    
    Note: browser-hybrid connects to an EXISTING Chrome instance,
    so "cold" here means first navigation after connect. Playwright/Selenium
    spin up a fresh browser. agent-browser also uses existing Chrome.
    
    Test URL: https://example.com (minimal, stable)
    """

    name = "navigation"
    description = "Navigate to a URL and wait for load (cold)"
    runs = 20

    TEST_URL = "https://example.com"

    def setup(self) -> None:
        pass

    def warmup(self) -> None:
        """Warmup: establish connections."""
        self.run_browser_hybrid()

    def run_browser_hybrid(self):
        """browser-hybrid: connect + navigate."""
        from browser_hybrid import Browser
        browser = Browser()
        browser.navigate(self.TEST_URL)
        browser.close()
        return True

    def run_playwright(self):
        """Playwright: launch + navigate."""
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(self.TEST_URL)
            page.wait_for_load_state("networkidle")
            browser.close()
        return True

    def run_selenium(self):
        """Selenium: launch + navigate."""
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.chrome.options import Options

        opts = Options()
        opts.add_argument("--headless")
        driver = webdriver.Chrome(options=opts)
        driver.get(self.TEST_URL)
        driver.quit()
        return True

    def run_agent_browser(self):
        """agent-browser: launch + navigate."""
        # agent-browser uses CDP directly like browser-hybrid
        try:
            from agent_browser import Browser
            browser = Browser()
            browser.navigate(self.TEST_URL)
            browser.close()
            return True
        except ImportError:
            return False
