#!/usr/bin/env python3
"""Run benchmarks and generate comparison report.

Usage:
    python -m benchmarks.run_benchmarks
    python -m benchmarks.run_benchmarks --scenarios navigation,screenshot
    python -m benchmarks.run_benchmarks --runs 30
"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(description="Run browser-hybrid benchmarks")
    parser.add_argument(
        "--scenarios",
        type=str,
        default="all",
        help="Comma-separated list of scenarios to run (default: all)",
    )
    parser.add_argument(
        "--runs",
        type=int,
        default=None,
        help="Override number of runs per scenario (default: scenario-defined)",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output file path for JSON results (default: auto-generated in results/)",
    )
    parser.add_argument(
        "--report",
        type=str,
        default=None,
        help="Output file path for markdown report (default: printed to stdout)",
    )
    args = parser.parse_args()

    print("=" * 60)
    print("browser-hybrid Benchmark Suite")
    print("=" * 60)
    print()
    print("Note: Chrome must be running with --remote-debugging-port=9222")
    print("      e.g.: google-chrome --remote-debugging-port=9222")
    print()

    # Import here so benchmark deps are optional
    from benchmarks.runner import BenchmarkRunner
    from benchmarks.compare import generate_markdown_report

    runner = BenchmarkRunner()

    print("Running benchmarks...")
    results = runner.run_all_scenarios()

    # Save JSON
    json_path = runner.save_results(results)
    print(f"\nResults saved to: {json_path}")

    # Generate and output report
    report = generate_markdown_report(results)
    if args.report:
        with open(args.report, "w") as f:
            f.write(report)
        print(f"Report saved to: {args.report}")
    else:
        print("\n" + "=" * 60)
        print("RESULTS")
        print("=" * 60)
        print(report)


if __name__ == "__main__":
    main()
