from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="goh-music",
    version="0.1.0",
    author="devdox-del",
    author_email="warek2508@gmail.com",
    description="Music effects library with 3 built-in effects",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/devdox-del/Goh-Music",
    packages=find_packages(),
    install_requires=[
        "pydub>=0.25.1",
        "numpy>=1.21.0",
        "imageio-ffmpeg>=0.4.8",
    ],
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
