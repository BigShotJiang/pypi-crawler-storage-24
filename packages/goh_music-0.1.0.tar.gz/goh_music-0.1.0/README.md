# 🎵 Goh Music Beta v0.1

Библиотека для обработки музыки с встроенными эффектами. Простая и легкая в использовании!

## ✨ Возможности

- 🎸 **3 встроенных эффекта** (reverb, speed_up, bass_boost)
- 🔒 **Ограничение на количество эффектов** - нельзя добавить больше 3-х
- 📦 **Простая интеграция** в ботов и приложения
- 🎧 **Поддержка MP3** формата
- ⚡ **FFmpeg включен** - не нужно ничего дополнительно устанавливать!

## 📥 Установка

```bash
pip install git+https://github.com/devdox-del/Goh-Music.git
```

Или клонируйте репозиторий:

```bash
git clone https://github.com/devdox-del/Goh-Music.git
cd Goh-Music
pip install -r requirements.txt
pip install -e .
```

## 🚀 Быстрый старт

```python
from goh_music import MusicProcessor

# Создаем процессор
processor = MusicProcessor()

# Смотрим доступные эффекты
effects = processor.get_available_effects()
print(effects)
# {'reverb': 'Реверберация (эхо)', 
#  'speed_up': 'Ускорение (nightcore)', 
#  'bass_boost': 'Усиление баса'}

# Обрабатываем музыку
processor.process_audio(
    input_path="music.mp3",
    output_path="music_reverb.mp3",
    effect_name="reverb"
)
```

## 🎛️ Доступные эффекты

1. **reverb** - Реверберация (эхо эффект)
2. **speed_up** - Ускорение музыки (nightcore стиль)
3. **bass_boost** - Усиление басов

## 🤖 Пример для бота

```python
from goh_music import MusicProcessor

processor = MusicProcessor()

# Когда пользователь отправил музыку
def handle_music(file_path):
    # Показываем эффекты
    effects = processor.get_available_effects()
    
    # Пользователь выбирает эффект
    chosen_effect = "reverb"  # из клавиатуры бота
    
    # Обрабатываем
    output_path = f"processed_{chosen_effect}.mp3"
    success = processor.process_audio(file_path, output_path, chosen_effect)
    
    if success:
        # Отправляем обработанный файл пользователю
        return output_path
```

## ⚠️ Важно

- Библиотека поддерживает **только 3 эффекта**
- Попытка добавить свои эффекты вызовет ошибку `NotImplementedError`
- **FFmpeg устанавливается автоматически** вместе с библиотекой - ничего дополнительно качать не нужно!

## 📝 Требования

- Python >= 3.7
- pydub >= 0.25.1
- numpy >= 1.21.0
- imageio-ffmpeg >= 0.4.8 (ffmpeg устанавливается автоматически!)

## 📄 Лицензия

MIT License

## 👤 Автор

**devdox-del**
- Email: warek2508@gmail.com
- GitHub: [@devdox-del](https://github.com/devdox-del)

## 🐛 Баги и предложения

Создавайте issues на GitHub: https://github.com/devdox-del/Goh-Music/issues

---

**Версия:** 0.1.0-beta
