"""
Goh Music Beta v0.1
Music effects library with 3 built-in effects
"""

import os
from pydub import AudioSegment

# Автоматическая настройка ffmpeg
try:
    from imageio_ffmpeg import get_ffmpeg_exe
    ffmpeg_path = get_ffmpeg_exe()
    AudioSegment.converter = ffmpeg_path
    AudioSegment.ffmpeg = ffmpeg_path
    AudioSegment.ffprobe = ffmpeg_path.replace("ffmpeg", "ffprobe")
except ImportError:
    pass  # Если imageio-ffmpeg не установлен, используем системный ffmpeg

from .processor import MusicProcessor
from .effects import AVAILABLE_EFFECTS

__version__ = "0.1.0-beta"
__all__ = ["MusicProcessor", "AVAILABLE_EFFECTS"]
