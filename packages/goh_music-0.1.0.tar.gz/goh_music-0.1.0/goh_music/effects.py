"""
Audio effects for Goh Music
Only 3 effects are available - this is a hard limit
"""

from pydub import AudioSegment
from pydub.effects import speedup
import numpy as np

# Максимум 3 эффекта - это жесткое ограничение
MAX_EFFECTS = 3

AVAILABLE_EFFECTS = {
    "reverb": "Реверберация (эхо)",
    "speed_up": "Ускорение (nightcore)",
    "bass_boost": "Усиление баса"
}


def apply_reverb(audio: AudioSegment) -> AudioSegment:
    """Добавляет эффект реверберации"""
    delay = 100  # миллисекунды
    decay = 0.4  # затухание
    
    echo = audio - 6
    result = audio.overlay(echo, position=delay)
    result = result.overlay(echo - 6, position=delay * 2)
    
    return result


def apply_speed_up(audio: AudioSegment) -> AudioSegment:
    """Ускоряет музыку (nightcore эффект)"""
    return speedup(audio, playback_speed=1.25)


def apply_bass_boost(audio: AudioSegment) -> AudioSegment:
    """Усиливает басы"""
    return audio.low_pass_filter(200).apply_gain(5) + audio


def get_effect_function(effect_name: str):
    """Возвращает функцию эффекта по имени"""
    effects_map = {
        "reverb": apply_reverb,
        "speed_up": apply_speed_up,
        "bass_boost": apply_bass_boost
    }
    return effects_map.get(effect_name)
