"""
Music processor for Goh Music
"""

from pydub import AudioSegment
from .effects import AVAILABLE_EFFECTS, get_effect_function, MAX_EFFECTS


class MusicProcessor:
    """Процессор музыки с ограничением на 3 эффекта"""
    
    def __init__(self):
        self._effects = list(AVAILABLE_EFFECTS.keys())
    
    def get_available_effects(self):
        """Возвращает список доступных эффектов"""
        return AVAILABLE_EFFECTS.copy()
    
    def validate_effect(self, effect_name: str) -> bool:
        """Проверяет, доступен ли эффект"""
        return effect_name in self._effects
    
    def process_audio(self, input_path: str, output_path: str, effect_name: str) -> bool:
        """
        Обрабатывает аудио файл с выбранным эффектом
        
        Args:
            input_path: путь к входному MP3 файлу
            output_path: путь для сохранения результата
            effect_name: название эффекта из AVAILABLE_EFFECTS
            
        Returns:
            True если успешно, False если ошибка
        """
        if not self.validate_effect(effect_name):
            raise ValueError(f"Эффект '{effect_name}' недоступен. Доступны только: {', '.join(self._effects)}")
        
        try:
            # Загружаем аудио
            audio = AudioSegment.from_mp3(input_path)
            
            # Применяем эффект
            effect_func = get_effect_function(effect_name)
            processed_audio = effect_func(audio)
            
            # Сохраняем результат
            processed_audio.export(output_path, format="mp3")
            
            return True
        except Exception as e:
            print(f"Ошибка обработки: {e}")
            return False
    
    def add_custom_effect(self, *args, **kwargs):
        """Блокирует добавление новых эффектов"""
        raise NotImplementedError(
            f"Нельзя добавить больше эффектов! Максимум {MAX_EFFECTS} эффекта доступно в этой версии."
        )
