"""Tests for review commands — fills, trades."""

import json
import os

import pytest

from hl_cli.main import app


def parse(result):
    return json.loads(result.output)


class TestFills:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["fills"])
        assert result.exit_code == 0
        assert parse(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["fills", "BTC"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 1
        assert data[0]["asset"] == "BTC"

    def test_limit(self, runner, patched):
        result = runner.invoke(app, ["fills", "--limit", "1"])
        assert result.exit_code == 0
        data = parse(result)
        assert len(data) == 1


