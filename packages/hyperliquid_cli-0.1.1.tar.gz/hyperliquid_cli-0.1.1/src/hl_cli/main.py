"""hl — Agent-first CLI for Hyperliquid trading."""

from importlib.metadata import version as pkg_version
from typing import Optional

import typer


def _version_callback(value: bool):
    if value:
        print(pkg_version("hyperliquid-cli"))
        raise typer.Exit()


app = typer.Typer(
    name="hl",
    add_completion=False,
    no_args_is_help=True,
    help="Agent-first CLI for Hyperliquid perp trading.",
)


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit"),
    fields: Optional[str] = typer.Option(None, "--fields", help="Comma-separated field projection"),
    verbose: bool = typer.Option(False, "--verbose", help="Debug info to stderr"),
    testnet: bool = typer.Option(False, "--testnet", help="Use testnet endpoints"),
):
    """Hyperliquid perp trading CLI. JSON output by default."""
    ctx.ensure_object(dict)
    ctx.obj["fields"] = fields
    ctx.obj["verbose"] = verbose
    ctx.obj["testnet"] = testnet


# Register all commands — must be after app is defined
from hl_cli.commands import orient, research, act, review  # noqa: E402, F401
