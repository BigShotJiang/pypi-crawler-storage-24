"""
PG Scheduler - A PostgreSQL-based async job scheduler with deduplication and reliability features.

This library provides a robust job scheduling system built on PostgreSQL with features like:
- Periodic jobs with @periodic decorator
- Cross-replica deduplication 
- Self-rescheduling jobs
- Advisory lock support
- Priority queues and retry logic
- Vacuum policies for job cleanup
- Graceful shutdown and error handling
"""

from .conflict_resolution import ConflictResolution
from .job_priority import JobPriority
from .job_spec import JobSpec
from .periodic import periodic
from .vacuum import VacuumConfig, VacuumPolicy, VacuumTrigger
from .scheduler import Scheduler

__version__ = "0.2.2"
__author__ = "Miguel Rebelo"
__email__ = "miguel.python.dev@gmail.com"

__all__ = [
    "Scheduler",
    "JobPriority", 
    "JobSpec",
    "ConflictResolution",
    "VacuumPolicy",
    "VacuumConfig", 
    "VacuumTrigger",
    "periodic",
]
