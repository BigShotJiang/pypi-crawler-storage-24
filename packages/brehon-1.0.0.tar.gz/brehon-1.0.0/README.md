# brehon

Python SDK for the [Brehon Privacy API](https://brehon.dev) — structured access to 32+ privacy and AI governance laws across 16+ jurisdictions.

## Install

```bash
pip install brehon
```

## Quick start

```python
import asyncio
from brehon import BrehonClient

async def main():
    async with BrehonClient("YOUR_API_KEY") as client:
        # Get a specific law
        gdpr = await client.laws.get("gdpr")

        # List all laws in a jurisdiction
        eu_laws = await client.laws.list(jurisdiction="EU")

        # Search across all laws
        results = await client.search("breach notification")

        # Compare laws side by side
        comparison = await client.laws.compare(["gdpr", "ccpa"])

        # Find applicable laws for jurisdictions
        applicable = await client.search.applicable(["India", "EU"])

asyncio.run(main())
```

## Documentation

Full docs at [brehon.dev/docs](https://brehon.dev/docs).
