"""Laws namespace — client.laws.*"""

from __future__ import annotations

from typing import Any

from brehon._http import HTTPTransport


class Laws:
    """Access privacy law data."""

    def __init__(self, transport: HTTPTransport) -> None:
        self._t = transport

    async def get(self, law_id: str) -> dict[str, Any]:
        """Get detailed information about a specific privacy law."""
        return await self._t.request("GET", f"/privacy-laws/{law_id}")

    async def list(
        self,
        *,
        jurisdiction: str | None = None,
        law_type: str | None = None,
        geographic_scope: str | None = None,
    ) -> list[dict[str, Any]]:
        """List all privacy laws, with optional filtering."""
        params: dict[str, str] = {}
        if jurisdiction:
            params["jurisdiction"] = jurisdiction
        if law_type:
            params["law_type"] = law_type
        if geographic_scope:
            params["geographic_scope"] = geographic_scope
        return await self._t.request("GET", "/privacy-laws", params=params or None)

    async def rights(self, law_id: str) -> dict[str, Any]:
        """Get data subject rights for a specific privacy law."""
        return await self._t.request("GET", f"/privacy-laws/{law_id}/rights")

    async def legal_bases(self, law_id: str) -> dict[str, Any]:
        """Get legal bases for processing under a specific privacy law."""
        return await self._t.request("GET", f"/privacy-laws/{law_id}/legal-bases")

    async def penalties(self, law_id: str) -> dict[str, Any]:
        """Get penalty information for a specific privacy law."""
        return await self._t.request("GET", f"/privacy-laws/{law_id}/penalties")

    async def compare(self, law_ids: list[str]) -> dict[str, Any]:
        """Compare compliance requirements across multiple privacy laws."""
        return await self._t.request("POST", "/privacy-laws/compare", json=law_ids)
