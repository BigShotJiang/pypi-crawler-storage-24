"""Search namespace — client.search() and client.search.applicable()"""

from __future__ import annotations

from typing import Any

from brehon._http import HTTPTransport


class Search:
    """Search privacy law content.

    Callable directly for content search::

        results = await client.search("breach notification")

    Also exposes sub-methods::

        applicable = await client.search.applicable(["India", "EU"])
    """

    def __init__(self, transport: HTTPTransport) -> None:
        self._t = transport

    async def __call__(
        self,
        query: str,
        *,
        fields: list[str] | None = None,
    ) -> dict[str, Any]:
        """Keyword search across all privacy law content."""
        params: dict[str, str] = {"q": query}
        if fields:
            params["fields"] = ",".join(fields)
        return await self._t.request("GET", "/privacy-laws/search", params=params)

    async def applicable(self, jurisdictions: list[str]) -> dict[str, Any]:
        """Get all privacy laws applicable to the given jurisdictions."""
        return await self._t.request(
            "POST",
            "/privacy-laws/applicable",
            json={"jurisdictions": jurisdictions},
        )
