"""BrehonClient — main entry point for the SDK."""

from __future__ import annotations

from typing import Any

from brehon._http import HTTPTransport
from brehon._laws import Laws
from brehon._search import Search


class BrehonClient:
    """Async client for the Brehon Privacy API.

    Usage::

        async with BrehonClient("YOUR_KEY") as client:
            gdpr = await client.laws.get("gdpr")
            results = await client.search("breach notification")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.brehon.dev",
        timeout: float = 30.0,
    ) -> None:
        self._transport = HTTPTransport(api_key, base_url=base_url, timeout=timeout)
        self.laws = Laws(self._transport)
        self.search = Search(self._transport)

    async def __aenter__(self) -> BrehonClient:
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying HTTP connection."""
        await self._transport.close()

    async def jurisdictions(self) -> dict[str, Any]:
        """Get list of available jurisdictions."""
        return await self._transport.request("GET", "/jurisdictions")

    async def law_types(self) -> dict[str, Any]:
        """Get list of available privacy law types with descriptions."""
        return await self._transport.request("GET", "/law-types")

    async def usage(self) -> dict[str, Any]:
        """Get current API usage statistics."""
        return await self._transport.request("GET", "/usage/current")
