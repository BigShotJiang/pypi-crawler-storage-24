import json
import os
import logging
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("pack-mcp-gitlab")

_client = None


def get_gitlab_client():
    """Inicializa e retorna o cliente GitLab com validação de config (singleton)."""
    global _client
    if _client is not None:
        return _client

    from pack_mcp_gitlab.client import GitLabClient

    log_level = os.environ.get("LOG_LEVEL", "WARNING").upper()
    logging.basicConfig(level=getattr(logging, log_level, logging.WARNING))

    gitlab_url = os.environ.get("GITLAB_URL", "")
    gitlab_token = os.environ.get("GITLAB_TOKEN", "")

    _client = GitLabClient(gitlab_url, gitlab_token)
    return _client


@mcp.tool()
async def list_merge_requests(project_path: str, state: str = "opened") -> str:
    """Lista Merge Requests de um projeto no GitLab.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        state: Filtro por estado do MR. Valores: "opened", "closed", "merged", "all". Padrão: "opened".

    Returns:
        JSON array com MRs contendo: iid, title, author (username), source_branch, target_branch, state, web_url, created_at, updated_at.
    """
    client = get_gitlab_client()
    result = client.list_merge_requests(project_path, state)
    return json.dumps(result)


@mcp.tool()
async def get_merge_request(project_path: str, mr_iid: int) -> str:
    """Obtém detalhes completos de um Merge Request específico.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.

    Returns:
        JSON com: iid, title, description, state, author (name, username), source_branch, target_branch, web_url, created_at, updated_at.
    """
    client = get_gitlab_client()
    result = client.get_merge_request(project_path, mr_iid)
    return json.dumps(result)


@mcp.tool()
async def get_merge_request_changes(project_path: str, mr_iid: int) -> str:
    """Obtém as alterações (diffs) de um Merge Request, arquivo por arquivo.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.

    Returns:
        JSON array com um objeto por arquivo alterado contendo: new_path, old_path, new_file, renamed_file, deleted_file, diff (texto do diff unificado).
    """
    client = get_gitlab_client()
    result = client.get_merge_request_changes(project_path, mr_iid)
    return json.dumps(result)


@mcp.tool()
async def get_file_content(project_path: str, file_path: str, ref: str = "HEAD") -> str:
    """Lê o conteúdo de um arquivo do repositório GitLab.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        file_path: Caminho do arquivo dentro do repositório (ex: "src/main/App.java").
        ref: Branch, tag ou commit SHA de onde ler o arquivo. Padrão: "HEAD".

    Returns:
        JSON com: file_path, ref, content (conteúdo UTF-8 do arquivo).
    """
    client = get_gitlab_client()
    result = client.get_file_content(project_path, file_path, ref)
    return json.dumps(result)


@mcp.tool()
async def create_merge_request_note(project_path: str, mr_iid: int, body: str) -> str:
    """Posta um comentário (note) em um Merge Request no GitLab.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.
        body: Texto do comentário a ser postado. Suporta Markdown do GitLab. Não pode ser vazio.

    Returns:
        JSON com: id (ID do comentário criado), success (true).
    """
    client = get_gitlab_client()
    result = client.create_merge_request_note(project_path, mr_iid, body)
    return json.dumps(result)


@mcp.tool()
async def list_merge_request_notes(project_path: str, mr_iid: int) -> str:
    """Lista todos os comentários (notes) de um Merge Request.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.

    Returns:
        JSON array com notes contendo: id, body, author (name, username), created_at, system (true se é nota automática do GitLab).
    """
    client = get_gitlab_client()
    result = client.list_merge_request_notes(project_path, mr_iid)
    return json.dumps(result)


@mcp.tool()
async def get_project(project_path: str) -> str:
    """Obtém informações de um projeto no GitLab.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").

    Returns:
        JSON com: id, name, path_with_namespace, description, default_branch, web_url, visibility.
    """
    client = get_gitlab_client()
    result = client.get_project(project_path)
    return json.dumps(result)


@mcp.tool()
async def search_projects(search: str) -> str:
    """Busca projetos no GitLab por nome. Use quando não souber o caminho exato do projeto.

    Args:
        search: Termo de busca (nome ou parte do nome do projeto).

    Returns:
        JSON array com projetos encontrados contendo: id, name, path_with_namespace, description, web_url. Retorna lista vazia se nenhum projeto corresponder.
    """
    client = get_gitlab_client()
    result = client.search_projects(search)
    return json.dumps(result)


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
