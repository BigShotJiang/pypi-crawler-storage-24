# Plano de Implementação: pack-mcp-gitlab

## Visão Geral

Implementação incremental do servidor MCP para GitLab em Python. Começa pela estrutura do projeto e empacotamento, segue com o tratamento de erros centralizado, depois o cliente GitLab, as tools do servidor, e finaliza com testes. Cada etapa constrói sobre a anterior, garantindo que não haja código órfão.

## Tarefas

- [x] 1. Estrutura do projeto e empacotamento
  - [x] 1.1 Criar `pyproject.toml` com metadados, dependências e entry point
    - Nome: `pack-mcp-gitlab`, versão `0.1.0`
    - Dependências: `python-gitlab>=4.0.0`, `mcp>=1.0.0`
    - Build system: `hatchling`
    - Entry point: `pack-mcp-gitlab = "pack_mcp_gitlab.server:main"`
    - Adicionar dependências de dev: `pytest`, `hypothesis`, `pytest-asyncio`
    - _Requisitos: 10.1_

  - [x] 1.2 Criar estrutura de diretórios e arquivos iniciais
    - Criar `src/pack_mcp_gitlab/__init__.py` (vazio)
    - Criar `src/pack_mcp_gitlab/server.py` com esqueleto do `main()` e instância `FastMCP`
    - Criar `src/pack_mcp_gitlab/client.py` com classe `GitLabClient` vazia
    - Criar `src/pack_mcp_gitlab/errors.py` com esqueleto do decorator
    - Criar `tests/__init__.py`, `tests/conftest.py` vazios
    - _Requisitos: 10.1, 10.2_

- [x] 2. Módulo de erros e validação de configuração
  - [x] 2.1 Implementar decorator `handle_gitlab_error` em `errors.py`
    - Mapear `GitlabAuthenticationError` → mensagem de autenticação
    - Mapear `GitlabGetError` (404) → mensagem de recurso não encontrado
    - Mapear `GitlabHttpError` (403) → mensagem de permissão negada
    - Mapear `requests.ConnectionError` e `requests.Timeout` → mensagem de rede
    - Capturar exceções genéricas com tipo e mensagem
    - Garantir que logs de erro não exponham tokens
    - _Requisitos: 11.1, 11.2, 11.3, 11.4_

  - [ ]* 2.2 Escrever testes unitários do error handler em `tests/test_errors.py`
    - Testar cada tipo de exceção mapeada
    - Testar que mensagens de erro são descritivas e corretas
    - Testar que exceções genéricas incluem tipo e mensagem
    - _Requisitos: 11.1, 11.2, 11.3_

  - [ ]* 2.3 Escrever teste de propriedade para tratamento de erros por tipo
    - **Propriedade 6: Tratamento de erros por tipo de exceção**
    - **Valida: Requisitos 2.4, 3.3, 4.3, 5.4, 6.4, 7.3, 8.3, 11.1, 11.2, 11.3**

  - [ ]* 2.4 Escrever teste de propriedade para logs sem dados sensíveis
    - **Propriedade 9: Logs de erro não expõem dados sensíveis**
    - **Valida: Requisitos 11.4**

- [x] 3. Checkpoint — Verificar módulo de erros
  - Garantir que todos os testes passam, perguntar ao usuário se houver dúvidas.

- [x] 4. GitLabClient — Inicialização e validação
  - [x] 4.1 Implementar `__init__` do `GitLabClient` em `client.py`
    - Validar que `gitlab_url` e `gitlab_token` não são vazios/whitespace
    - Levantar `ValueError` descritivo se parâmetros inválidos
    - Instanciar `gitlab.Gitlab` com URL e token
    - _Requisitos: 1.1, 1.2, 1.3, 1.4_

  - [x] 4.2 Implementar `get_gitlab_client()` em `server.py`
    - Ler `GITLAB_URL` e `GITLAB_TOKEN` de variáveis de ambiente
    - Instanciar e retornar `GitLabClient`
    - Configurar logging com nível via `LOG_LEVEL` (padrão: `WARNING`)
    - _Requisitos: 1.1, 1.2, 1.3, 1.4_

  - [ ]* 4.3 Escrever teste de propriedade para validação de config
    - **Propriedade 1: Validação de parâmetros obrigatórios na inicialização**
    - **Valida: Requisitos 1.1, 1.3, 1.4**

- [x] 5. GitLabClient — Métodos de Merge Request
  - [x] 5.1 Implementar `list_merge_requests` no `GitLabClient`
    - Buscar projeto por path, listar MRs filtrados por `state`
    - Formatar retorno com campos: `iid`, `title`, `author`, `source_branch`, `target_branch`, `state`, `web_url`, `created_at`, `updated_at`
    - Aplicar decorator `@handle_gitlab_error`
    - _Requisitos: 2.1, 2.2, 2.3_

  - [x] 5.2 Implementar `get_merge_request` no `GitLabClient`
    - Buscar MR por `project_path` e `mr_iid`
    - Formatar retorno com campos: `iid`, `title`, `description`, `state`, `author` (name, username), `source_branch`, `target_branch`, `web_url`, `created_at`, `updated_at`
    - Aplicar decorator `@handle_gitlab_error`
    - _Requisitos: 3.1, 3.2_

  - [x] 5.3 Implementar `get_merge_request_changes` no `GitLabClient`
    - Buscar alterações do MR por `project_path` e `mr_iid`
    - Formatar retorno com campos por arquivo: `new_path`, `old_path`, `new_file`, `renamed_file`, `deleted_file`, `diff`
    - Aplicar decorator `@handle_gitlab_error`
    - _Requisitos: 4.1, 4.2_

  - [ ]* 5.4 Escrever testes unitários dos métodos de MR em `tests/test_client.py`
    - Testar `list_merge_requests` com mock retornando lista de MRs
    - Testar `get_merge_request` com mock retornando MR detalhado
    - Testar `get_merge_request_changes` com mock retornando diffs
    - Testar cenários de erro: projeto não encontrado, MR não encontrado
    - _Requisitos: 2.2, 2.4, 3.2, 3.3, 4.2, 4.3_

  - [ ]* 5.5 Escrever teste de propriedade para formatação de MR
    - **Propriedade 2: Formatação de MR preserva todos os campos obrigatórios**
    - **Valida: Requisitos 2.2, 3.2**

  - [ ]* 5.6 Escrever teste de propriedade para formatação de changes
    - **Propriedade 3: Formatação de changes preserva todos os campos obrigatórios**
    - **Valida: Requisitos 4.2**

- [x] 6. GitLabClient — Arquivo, notas e projetos
  - [x] 6.1 Implementar `get_file_content` no `GitLabClient`
    - Buscar conteúdo do arquivo por `project_path`, `file_path` e `ref`
    - Decodificar conteúdo em UTF-8
    - Formatar retorno com `file_path`, `ref`, `content`
    - Aplicar decorator `@handle_gitlab_error`
    - _Requisitos: 5.1, 5.2, 5.3_

  - [x] 6.2 Implementar `create_merge_request_note` no `GitLabClient`
    - Validar que `body` não é vazio/whitespace antes de chamar API
    - Criar nota no MR e retornar `id` e `success: true`
    - Aplicar decorator `@handle_gitlab_error`
    - _Requisitos: 6.1, 6.2, 6.3, 6.5_

  - [x] 6.3 Implementar `list_merge_request_notes` no `GitLabClient`
    - Listar notas do MR com campos: `id`, `body`, `author` (name, username), `created_at`, `system`
    - Aplicar decorator `@handle_gitlab_error`
    - _Requisitos: 7.1, 7.2_

  - [x] 6.4 Implementar `get_project` no `GitLabClient`
    - Retornar dados do projeto: `id`, `name`, `path_with_namespace`, `description`, `default_branch`, `web_url`, `visibility`
    - Aplicar decorator `@handle_gitlab_error`
    - _Requisitos: 8.1, 8.2_

  - [x] 6.5 Implementar `search_projects` no `GitLabClient`
    - Buscar projetos por termo e retornar lista com: `id`, `name`, `path_with_namespace`, `description`, `web_url`
    - Aplicar decorator `@handle_gitlab_error`
    - _Requisitos: 9.1, 9.2, 9.3_

  - [ ]* 6.6 Escrever testes unitários dos métodos de arquivo, notas e projetos em `tests/test_client.py`
    - Testar `get_file_content` com mock, incluindo ref customizado
    - Testar `create_merge_request_note` com mock, incluindo body vazio
    - Testar `list_merge_request_notes` com mock
    - Testar `get_project` e `search_projects` com mock
    - Testar cenários de erro: arquivo não encontrado, MR não encontrado, projeto não encontrado
    - _Requisitos: 5.2, 5.4, 6.2, 6.3, 6.4, 6.5, 7.2, 7.3, 8.2, 8.3, 9.2, 9.3_

  - [ ]* 6.7 Escrever teste de propriedade para validação de body vazio
    - **Propriedade 8: Validação de body vazio em create_merge_request_note**
    - **Valida: Requisitos 6.5**

  - [ ]* 6.8 Escrever teste de propriedade para formatação de notes
    - **Propriedade 4: Formatação de notes preserva todos os campos obrigatórios**
    - **Valida: Requisitos 7.2**

  - [ ]* 6.9 Escrever teste de propriedade para formatação de projeto
    - **Propriedade 5: Formatação de projeto preserva todos os campos obrigatórios**
    - **Valida: Requisitos 8.2, 9.2**

  - [ ]* 6.10 Escrever teste de propriedade para resposta de criação de nota
    - **Propriedade 10: Resposta de criação de nota contém id e confirmação**
    - **Valida: Requisitos 6.3**

- [x] 7. Checkpoint — Verificar GitLabClient completo
  - Garantir que todos os testes passam, perguntar ao usuário se houver dúvidas.

- [x] 8. Registro de tools no servidor MCP
  - [x] 8.1 Registrar tools de Merge Request em `server.py`
    - Implementar `list_merge_requests` como `@mcp.tool()` delegando ao `GitLabClient`
    - Implementar `get_merge_request` como `@mcp.tool()` delegando ao `GitLabClient`
    - Implementar `get_merge_request_changes` como `@mcp.tool()` delegando ao `GitLabClient`
    - Cada tool retorna JSON serializado como string
    - _Requisitos: 2.1, 3.1, 4.1_

  - [x] 8.2 Registrar tools de arquivo, notas e projetos em `server.py`
    - Implementar `get_file_content` como `@mcp.tool()` delegando ao `GitLabClient`
    - Implementar `create_merge_request_note` como `@mcp.tool()` delegando ao `GitLabClient`
    - Implementar `list_merge_request_notes` como `@mcp.tool()` delegando ao `GitLabClient`
    - Implementar `get_project` como `@mcp.tool()` delegando ao `GitLabClient`
    - Implementar `search_projects` como `@mcp.tool()` delegando ao `GitLabClient`
    - _Requisitos: 5.1, 6.1, 7.1, 8.1, 9.1_

  - [x] 8.3 Configurar `main()` com transporte stdio
    - Inicializar `GitLabClient` via `get_gitlab_client()`
    - Chamar `mcp.run(transport="stdio")`
    - _Requisitos: 10.2_

  - [ ]* 8.4 Escrever testes unitários do registro de tools em `tests/test_server.py`
    - Verificar que as 8 tools estão registradas com nomes corretos
    - Verificar parâmetros de cada tool (obrigatórios e opcionais)
    - Verificar que transporte stdio está configurado
    - _Requisitos: 2.1, 3.1, 4.1, 5.1, 6.1, 7.1, 8.1, 9.1, 10.2_

  - [ ]* 8.5 Escrever teste de propriedade para parâmetros opcionais
    - **Propriedade 7: Parâmetros opcionais são repassados corretamente à API**
    - **Valida: Requisitos 2.3, 5.3**

- [x] 9. Estratégias Hypothesis e fixtures compartilhadas
  - [x] 9.1 Criar estratégias Hypothesis em `tests/strategies.py`
    - Estratégias para gerar dados de MR, changes, notes, projetos
    - Estratégias para gerar exceções GitLab com mensagens aleatórias
    - Estratégias para gerar strings vazias/whitespace
    - Estratégias para gerar tokens aleatórios
    - _Requisitos: Suporte a todas as propriedades (P1-P10)_

  - [x] 9.2 Configurar fixtures compartilhadas em `tests/conftest.py`
    - Fixture de mock do `gitlab.Gitlab`
    - Fixture de `GitLabClient` com mock injetado
    - Configuração do Hypothesis: mínimo 100 iterações
    - _Requisitos: Suporte a todos os testes_

- [x] 10. Checkpoint final — Validação completa
  - Garantir que todos os testes passam, perguntar ao usuário se houver dúvidas.

## Notas

- Tarefas marcadas com `*` são opcionais e podem ser puladas para um MVP mais rápido
- Cada tarefa referencia requisitos específicos para rastreabilidade
- Checkpoints garantem validação incremental
- Testes de propriedade validam propriedades universais de corretude
- Testes unitários validam exemplos específicos e edge cases
- Todas as chamadas à API do GitLab são mockadas nos testes
