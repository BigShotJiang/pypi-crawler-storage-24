# Documento de Requisitos — pack-mcp-gitlab

## Introdução

O `pack-mcp-gitlab` é um servidor MCP (Model Context Protocol) standalone, publicado no PyPI, que expõe ferramentas para agentes de IA interagirem com a API do GitLab. O servidor recebe URL e token do GitLab como parâmetros de configuração via JSON do MCP e disponibiliza tools para consultar Merge Requests, obter diffs, ler conteúdo de arquivos, postar comentários e listar projetos. Este servidor substitui a camada de interação com o GitLab que hoje existe no projeto KiroReview, isolando-a como pacote reutilizável.

## Glossário

- **MCP_Server**: O servidor MCP `pack-mcp-gitlab` que recebe requisições de agentes de IA e interage com a API do GitLab
- **GitLab_Client**: Componente interno do MCP_Server responsável por autenticar e executar chamadas à API do GitLab usando a biblioteca `python-gitlab`
- **MR**: Merge Request no GitLab — solicitação de mesclagem de código entre branches
- **Tool**: Uma ferramenta exposta pelo MCP_Server que agentes de IA podem invocar via protocolo MCP
- **Config_JSON**: Arquivo de configuração JSON do MCP que contém URL do GitLab, token de acesso e demais parâmetros
- **Diff**: Representação textual das diferenças entre versões de um arquivo em um MR
- **Note**: Comentário postado em um MR no GitLab
- **Project**: Repositório/projeto no GitLab identificado por path (ex: `grupo/subgrupo/projeto`)

## Requisitos

### Requisito 1: Configuração e Autenticação

**User Story:** Como agente de IA, eu quero configurar o MCP_Server com URL e token do GitLab via Config_JSON, para que o servidor autentique nas chamadas à API do GitLab.

#### Critérios de Aceitação

1. WHEN o MCP_Server é iniciado, THE MCP_Server SHALL ler os parâmetros `GITLAB_URL` e `GITLAB_TOKEN` das variáveis de ambiente fornecidas no Config_JSON
2. WHEN o MCP_Server é iniciado com `GITLAB_URL` e `GITLAB_TOKEN` válidos, THE GitLab_Client SHALL autenticar com sucesso na API do GitLab
3. IF o parâmetro `GITLAB_TOKEN` estiver ausente ou vazio, THEN THE MCP_Server SHALL retornar um erro descritivo informando que o token é obrigatório
4. IF o parâmetro `GITLAB_URL` estiver ausente ou vazio, THEN THE MCP_Server SHALL retornar um erro descritivo informando que a URL é obrigatória
5. IF o token fornecido for inválido ou expirado, THEN THE GitLab_Client SHALL retornar um erro descritivo informando falha de autenticação

### Requisito 2: Listar Merge Requests

**User Story:** Como agente de IA, eu quero listar Merge Requests de um projeto no GitLab, para que eu possa identificar MRs relevantes para análise.

#### Critérios de Aceitação

1. THE MCP_Server SHALL expor uma Tool chamada `list_merge_requests` que aceita os parâmetros `project_path` (obrigatório) e `state` (opcional, padrão: `opened`)
2. WHEN a Tool `list_merge_requests` é invocada com um `project_path` válido, THE GitLab_Client SHALL retornar uma lista de MRs contendo para cada MR: `iid`, `title`, `author`, `source_branch`, `target_branch`, `state`, `web_url`, `created_at` e `updated_at`
3. WHERE o parâmetro `state` é fornecido, THE GitLab_Client SHALL filtrar os MRs pelo estado informado (valores aceitos: `opened`, `closed`, `merged`, `all`)
4. IF o `project_path` não corresponder a um projeto existente, THEN THE MCP_Server SHALL retornar um erro descritivo informando que o projeto não foi encontrado

### Requisito 3: Obter Detalhes de um Merge Request

**User Story:** Como agente de IA, eu quero obter os detalhes completos de um MR específico, para que eu possa analisar o contexto da mudança.

#### Critérios de Aceitação

1. THE MCP_Server SHALL expor uma Tool chamada `get_merge_request` que aceita os parâmetros `project_path` (obrigatório) e `mr_iid` (obrigatório)
2. WHEN a Tool `get_merge_request` é invocada com parâmetros válidos, THE GitLab_Client SHALL retornar os dados do MR contendo: `iid`, `title`, `description`, `state`, `author` (nome e username), `source_branch`, `target_branch`, `web_url`, `created_at` e `updated_at`
3. IF o `mr_iid` não corresponder a um MR existente no projeto, THEN THE MCP_Server SHALL retornar um erro descritivo informando que o MR não foi encontrado

### Requisito 4: Obter Alterações (Diffs) de um Merge Request

**User Story:** Como agente de IA, eu quero obter os diffs de um MR, para que eu possa realizar code review analisando as mudanças linha a linha.

#### Critérios de Aceitação

1. THE MCP_Server SHALL expor uma Tool chamada `get_merge_request_changes` que aceita os parâmetros `project_path` (obrigatório) e `mr_iid` (obrigatório)
2. WHEN a Tool `get_merge_request_changes` é invocada com parâmetros válidos, THE GitLab_Client SHALL retornar a lista de arquivos alterados contendo para cada arquivo: `new_path`, `old_path`, `new_file` (booleano), `renamed_file` (booleano), `deleted_file` (booleano) e `diff` (texto do diff)
3. IF o MR não existir no projeto informado, THEN THE MCP_Server SHALL retornar um erro descritivo informando que o MR não foi encontrado

### Requisito 5: Ler Conteúdo de Arquivo do Repositório

**User Story:** Como agente de IA, eu quero ler o conteúdo completo de um arquivo no repositório, para que eu possa analisar o contexto além do diff durante um code review.

#### Critérios de Aceitação

1. THE MCP_Server SHALL expor uma Tool chamada `get_file_content` que aceita os parâmetros `project_path` (obrigatório), `file_path` (obrigatório) e `ref` (opcional, padrão: `HEAD`)
2. WHEN a Tool `get_file_content` é invocada com parâmetros válidos, THE GitLab_Client SHALL retornar o conteúdo do arquivo decodificado em UTF-8
3. WHERE o parâmetro `ref` é fornecido, THE GitLab_Client SHALL buscar o conteúdo do arquivo na branch ou commit especificado
4. IF o arquivo não existir no caminho ou ref informados, THEN THE MCP_Server SHALL retornar um erro descritivo informando que o arquivo não foi encontrado

### Requisito 6: Postar Comentário em um Merge Request

**User Story:** Como agente de IA, eu quero postar comentários em um MR, para que eu possa registrar resultados de code review diretamente no GitLab.

#### Critérios de Aceitação

1. THE MCP_Server SHALL expor uma Tool chamada `create_merge_request_note` que aceita os parâmetros `project_path` (obrigatório), `mr_iid` (obrigatório) e `body` (obrigatório)
2. WHEN a Tool `create_merge_request_note` é invocada com parâmetros válidos, THE GitLab_Client SHALL criar um comentário (Note) no MR com o conteúdo fornecido em `body`
3. WHEN o comentário é criado com sucesso, THE MCP_Server SHALL retornar o `id` do comentário criado e a confirmação de sucesso
4. IF o MR não existir no projeto informado, THEN THE MCP_Server SHALL retornar um erro descritivo informando que o MR não foi encontrado
5. IF o `body` estiver vazio, THEN THE MCP_Server SHALL retornar um erro descritivo informando que o conteúdo do comentário é obrigatório

### Requisito 7: Listar Comentários de um Merge Request

**User Story:** Como agente de IA, eu quero listar os comentários existentes em um MR, para que eu possa entender o histórico de discussões e evitar duplicar feedback.

#### Critérios de Aceitação

1. THE MCP_Server SHALL expor uma Tool chamada `list_merge_request_notes` que aceita os parâmetros `project_path` (obrigatório) e `mr_iid` (obrigatório)
2. WHEN a Tool `list_merge_request_notes` é invocada com parâmetros válidos, THE GitLab_Client SHALL retornar a lista de comentários do MR contendo para cada Note: `id`, `body`, `author` (nome e username), `created_at` e `system` (booleano indicando se é nota do sistema)
3. IF o MR não existir no projeto informado, THEN THE MCP_Server SHALL retornar um erro descritivo informando que o MR não foi encontrado

### Requisito 8: Obter Informações de um Projeto

**User Story:** Como agente de IA, eu quero obter informações de um projeto no GitLab, para que eu possa contextualizar análises com dados do repositório.

#### Critérios de Aceitação

1. THE MCP_Server SHALL expor uma Tool chamada `get_project` que aceita o parâmetro `project_path` (obrigatório)
2. WHEN a Tool `get_project` é invocada com um `project_path` válido, THE GitLab_Client SHALL retornar os dados do projeto contendo: `id`, `name`, `path_with_namespace`, `description`, `default_branch`, `web_url` e `visibility`
3. IF o `project_path` não corresponder a um projeto existente, THEN THE MCP_Server SHALL retornar um erro descritivo informando que o projeto não foi encontrado

### Requisito 9: Buscar Projetos

**User Story:** Como agente de IA, eu quero buscar projetos no GitLab por nome, para que eu possa descobrir o path correto de um projeto quando não o conheço.

#### Critérios de Aceitação

1. THE MCP_Server SHALL expor uma Tool chamada `search_projects` que aceita o parâmetro `search` (obrigatório)
2. WHEN a Tool `search_projects` é invocada com um termo de busca, THE GitLab_Client SHALL retornar uma lista de projetos correspondentes contendo para cada projeto: `id`, `name`, `path_with_namespace`, `description` e `web_url`
3. WHEN nenhum projeto corresponder ao termo de busca, THE MCP_Server SHALL retornar uma lista vazia

### Requisito 10: Publicação no PyPI

**User Story:** Como desenvolvedor, eu quero que o pacote seja publicável no PyPI como `pack-mcp-gitlab`, para que usuários possam instalá-lo via `uvx pack-mcp-gitlab@latest`.

#### Critérios de Aceitação

1. THE MCP_Server SHALL ser empacotado com `pyproject.toml` contendo o nome `pack-mcp-gitlab`, versão semântica, dependências (`python-gitlab`, `mcp`) e entry point para execução via `uvx`
2. THE MCP_Server SHALL utilizar o protocolo stdio para comunicação MCP
3. THE MCP_Server SHALL ser compatível com a configuração MCP no formato: `{"command": "uvx", "args": ["pack-mcp-gitlab@latest"], "env": {"GITLAB_URL": "...", "GITLAB_TOKEN": "..."}}`

### Requisito 11: Tratamento de Erros

**User Story:** Como agente de IA, eu quero receber mensagens de erro claras e estruturadas, para que eu possa entender e comunicar falhas ao usuário.

#### Critérios de Aceitação

1. IF uma chamada à API do GitLab falhar por erro de rede, THEN THE MCP_Server SHALL retornar um erro descritivo contendo o tipo de falha e a mensagem original da exceção
2. IF uma chamada à API do GitLab retornar erro de permissão (HTTP 403), THEN THE MCP_Server SHALL retornar um erro descritivo informando que o token não possui permissão para a operação solicitada
3. IF uma chamada à API do GitLab retornar erro de recurso não encontrado (HTTP 404), THEN THE MCP_Server SHALL retornar um erro descritivo informando que o recurso solicitado não existe
4. THE MCP_Server SHALL registrar logs de erro com detalhes suficientes para diagnóstico sem expor dados sensíveis como tokens
