# KiroReview

Gerador automatizado de code reviews que combina GitLab, Jira e Amazon Q para análises técnicas contextualizadas.

## 💡 Como Funciona

### Arquitetura v3.0

```
Amazon Q Chat
    ↓
python collect_mr_data.py <URL_MR>
    ↓
┌──────────────────────────┐
│ Coleta de Dados         │
├──────────────────────────┤
│ 🦊 GitLab API          │ → MR, diff, arquivos
│ 🎯 Jira API            │ → Issues, requisitos
│ 💾 Repos Locais        │ → Configs, dependências
└──────────────────────────┘
    ↓
mr_data.json (contexto completo)
    ↓
Amazon Q Chat (análise)
    ↓
review_mr_XXX.md (resumo do code-review)
```

### Por Que Amazon Q Chat?

- ✅ **Contexto persistente**: Mantém histórico da conversa
- ✅ **Interação natural**: Refine a análise com perguntas
- ✅ **Sem limites**: Gerencia contextos grandes automaticamente
- ✅ **Iterativo**: Aprofunde em problemas específicos

## 🚀 Como Usar

> **Nota**: Antes de usar, complete a [Configuração](#️-configuração) abaixo.

### 📋 Cenário 1: Análise de Merge Request (GitLab)

No Amazon Q Chat, digite um destes comandos:

```
Analise o MR: https://git.alterdata.com.br/pack/packup/ms-contabilidade/-/merge_requests/158
```

```
Review do MR: https://git.alterdata.com.br/.../merge_requests/3486
```

```
Faça code review: https://git.alterdata.com.br/.../merge_requests/4790
```

**O que acontece:**
1. ✅ Executa `collect_mr_data.py` automaticamente
2. ✅ Analisa código (OWASP, performance, arquitetura)
3. ✅ Gera `arquivos-gerados/code_reviews/review_mr_XXX.md`
4. ✅ Mostra resumo no chat
5. ❓ **Pergunta**: "Deseja que eu gere um parecer técnico para o Jira?"

### 📋 Cenário 2: Análise via Ticket Jira

No Amazon Q Chat, digite um destes comandos:

```
Analise o ticket: https://jira.alterdata.com.br/browse/PKW-57733
```

```
Review do Jira: PKW-57733
```

```
Analise a tarefa PKW-57578
```

**O que acontece:**
1. ✅ Acessa Jira com credenciais do `.env`
2. ✅ Extrai código do ticket (ex: PKW-57733)
3. ✅ Busca branches `feature/PKW-57733` no GitLab
4. ✅ Se encontrar: Analisa automaticamente
5. ❓ **Pergunta DIRETAMENTE**: "Deseja que eu gere um parecer técnico para o Jira?"

### 🎯 Análise Focada (Opcional)

Você pode direcionar a análise para aspectos específicos:

```
Analise o MR focando em segurança: https://git.alterdata.com.br/...
```

```
Review de performance do MR: https://git.alterdata.com.br/...
```

```
Verifique arquitetura do ticket PKW-57733
```

### 📝 Fluxo Completo de Exemplo

**Exemplo 1: GitLab → Parecer Jira**
```
Você: Analise o MR: https://git.alterdata.com.br/.../merge_requests/158

Amazon Q: [Analisa e gera review_mr_158.md]
          Deseja que eu gere um parecer técnico para o Jira?

Você: Sim

Amazon Q: [Gera parecer-jira-PKW-12345.html]
```

**Exemplo 2: Jira → Parecer Direto**
```
Você: Review do ticket PKW-57733

Amazon Q: [Busca branches, analisa]
          Deseja que eu gere um parecer técnico para o Jira?

Você: Sim

Amazon Q: [Gera parecer-jira-PKW-57733.html]
```

### 💡 Dicas de Uso

**✅ Recomendado (Mais Natural):**
- `Analise o MR: [link]`
- `Review do ticket PKW-12345`
- `Faça code review: [link]`

**⚠️ Evite (Muito Verboso):**
- ❌ "Por favor, você poderia analisar o merge request..."
- ❌ "Gostaria que você fizesse uma revisão completa..."

**🚀 Atalhos Rápidos:**
- Apenas o link: `https://git.alterdata.com.br/.../merge_requests/158`
- Apenas o ticket: `PKW-57733`

### 📁 Arquivos Gerados

**Code Reviews:**
- 📄 Localização: `arquivos-gerados/code_reviews/`
- 📄 Formato: `review_mr_{MR_IID}.md`
- 📄 Exemplo: `review_mr_3486.md`

**Pareceres Técnicos:**
- 📝 Localização: `arquivos-gerados/pareceres_tecnicos/`
- 📝 Formato: `parecer-jira-{TICKET}.html`
- 📝 Exemplo: `parecer-jira-PKW-57733.html`

## ⚙️ Configuração

### 1. Instalar Dependências

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configurar Variáveis

Crie `.env` na raiz do projeto (não versionado):

```bash
# Obrigatório
GITLAB_URL=https://git.alterdata.com.br
GITLAB_TOKEN=seu_token_gitlab

# Opcional (melhora contexto)
REPOS_PATH=C:\\Ferramentas\\projetos
JIRA_URL=https://jira.alterdata.com.br
JIRA_USERNAME=seu_usuario_jira
JIRA_PASSWORD=sua_senha_jira
```

**Token GitLab**: Precisa das permissões `api`, `read_api`, `read_user`, `read_repository`

## 📋 O Que Analisa

### 🔒 Segurança
- OWASP Top 10 (Injection, XSS, CSRF, etc.)
- Credenciais hardcoded
- Exposição de dados sensíveis
- Validação e sanitização de entradas

### ⚡ Performance
- Queries N+1
- Loops ineficientes
- Memory leaks
- Vazamento de recursos (conexões, streams)

### 🏛️ Arquitetura
- Padrões de projeto (Design Patterns)
- Acoplamento e coesão
- Responsabilidade única (SRP)
- Clean Code principles

### 🛠️ Débito Técnico
- Code smells
- Duplicação de código
- Complexidade ciclomática
- Violações de convenções

## 📄 Exemplo de Review Gerado

### 🔍 Code Review - MR #158

**📋 Informações**

| Autor | Branch | Status | Jira |
|-------|--------|--------|------|
| Gabriel | Feature/PKW-37711 → develop | ✅ merged | [PKW-37711](link) |

**⚠️ Problema 1: Lógica Condicional Invertida**

- **Arquivo**: `ExtratoContabilServiceImpl.java`
- **Linha**: 245
- **Severidade**: 🟡 Média

❌ **Código Problemático**
```java
if (!lancamentoModelo.isAtivo()) {
    processarLancamento(lancamentoModelo);
}
```

✅ **Solução**
```java
if (lancamentoModelo.isAtivo()) {
    processarLancamento(lancamentoModelo);
}
```

**📊 Resumo**
- Arquivos analisados: 2
- Problemas encontrados: 1
- Severidade: 🟡 Média

## 🎯 Análise Focada

Você pode direcionar a análise para aspectos específicos:

```
Analise o MR #123 focando em segurança
Revise apenas performance do MR #456
```

## 📁 Estrutura do Projeto

```
kiroreview/
├── collect_mr_data.py       # 📥 Coleta dados (GitLab + Jira + Repos)
├── generate_review_md.py    # 📝 Gera Markdown formatado
├── jira_client.py           # 🎯 Cliente API Jira
├── config.py                # ⚙️ Carrega .env
├── run_review_chat.py       # 🚀 Runner para chat (opcional)
├── review_rules.md          # 📋 Regras (OWASP, patterns)
├── requirements.txt         # 📦 Dependências
└── .env                     # 🔐 Credenciais (não versionado)
```

### Componentes Principais

**collect_mr_data.py**
- Orquestra coleta de todas as fontes
- Gera JSON estruturado com contexto completo
- Usado automaticamente pelo Amazon Q Chat

**generate_review_md.py**
- Formata análise em Markdown visual
- Adiciona emojis de severidade e status
- Organiza arquivos por diretório

**jira_client.py**
- Extrai código da issue da branch
- Busca contexto de negócio
- Suporta autenticação básica

**review_rules.md**
- Regras OWASP Top 10
- Padrões de performance
- Best practices arquiteturais

## 🔮 Roadmap

### [3.1.0] - 2026-01-29 (Atual) ✅

#### ✨ Adicionado
- Fluxo interativo de 2 cenários (GitLab e Jira)
- Geração automatizada de pareceres técnicos HTML para Jira
- Templates HTML profissionais com estilos inline
- Estrutura de pastas organizada (`arquivos-gerados/`)
- Documentação expandida com FAQ

#### 🔄 Modificado
- Fluxo de trabalho agora pergunta explicitamente sobre parecer técnico
- README reorganizado com guia completo dos 2 cenários
- `.gitignore` otimizado

📖 **[Ver histórico completo de mudanças →](CHANGELOG.md)**

---

### [3.0.0] - 2026-01-XX (Anterior) 📋

#### ✨ Inicial
- Integração GitLab + Jira + Repos locais
- Análise via Amazon Q Chat
- Reviews em Markdown visual
- Coleta automatizada de contexto
- Scripts Python para coleta de dados
- Regras de análise (OWASP, performance, arquitetura)

---

### [4.0.0] - Futuro 🚧

#### 🚧 Planejado
- **MCP Servers**: Eliminar scripts Python locais
- **Zero Config**: Sem instalação de dependências
- **Nativo**: Integração direta com Amazon Q
- **CI/CD**: Executar no pipeline com aprovação automática

📖 **[Detalhes da arquitetura v4.0 →](VISION.md)**

## 📌 Observações

### 🌱 Padrão de Branch para Jira

O KiroReview extrai automaticamente o código da issue do Jira a partir do nome da branch do MR.

**Exemplos de padrões reconhecidos:**
- `feature/PKW-12345` → Issue: PKW-12345
- `bugfix/PKW-12345-descricao` → Issue: PKW-12345
- `hotfix/PKW-12345` → Issue: PKW-12345

Se a branch não seguir esse padrão, o contexto do Jira não será incluído na análise.

### 📁 Estrutura de Arquivos Gerados

```
arquivos-gerados/
├── code_reviews/              # Code reviews de MRs
│   ├── review_mr_3486.md
│   ├── review_mr_3493.md
│   └── review_mr_4790.md
└── pareceres_tecnicos/        # Pareceres para Jira
    ├── parecer-jira-PKW-57578.html
    └── parecer-jira-PKW-57733.html
```

### 🔄 Fluxo de Trabalho Recomendado

1. **Desenvolvedor**: Cria MR no GitLab
2. **Revisor**: Pede análise no Amazon Q Chat
3. **Amazon Q**: Gera `review_mr_XXX.md` automaticamente
4. **Revisor**: Revisa problemas encontrados
5. **Revisor**: (Opcional) Solicita parecer técnico para Jira
6. **Amazon Q**: Gera `parecer-jira-XXX.html`
7. **Revisor**: Cola parecer no Jira para documentação

---

## ❓ FAQ (Perguntas Frequentes)

### Como faço para analisar um MR?
Simples! No Amazon Q Chat, digite: `Analise o MR: [link do GitLab]`

### Posso analisar direto pelo ticket do Jira?
Sim! Digite: `Review do ticket PKW-12345` e o Amazon Q buscará as branches relacionadas automaticamente.

### Onde ficam os arquivos gerados?
- **Code reviews**: `arquivos-gerados/code_reviews/review_mr_XXX.md`
- **Pareceres Jira**: `arquivos-gerados/pareceres_tecnicos/parecer-jira-XXX.html`

### O parecer técnico é gerado automaticamente?
Não. Após a análise do MR, o Amazon Q pergunta se você deseja gerar o parecer. Responda "Sim" para gerar.

### Preciso configurar algo antes de usar?
Sim. Você precisa criar o arquivo `.env` com suas credenciais do GitLab e Jira. Veja a seção [Configuração](#️-configuração).

### Posso focar a análise em segurança ou performance?
Sim! Use comandos como: `Analise o MR focando em segurança: [link]`

### O que acontece se a branch não tiver código do Jira?
A análise funciona normalmente, mas sem o contexto de negócio do Jira.

### Os arquivos gerados são versionados no Git?
Não. Eles estão no `.gitignore` e não são versionados. Apenas a estrutura de pastas é mantida.

---

**Desenvolvido para otimizar code reviews com automação inteligente e contexto de negócio.**
