"""
Coleta dados do Merge Request para análise
Retorna JSON com todas as informações necessárias
"""

import json
import sys
from pathlib import Path
import gitlab
from urllib.parse import urlparse
from jira_client import JiraClient
from config import GITLAB_URL, GITLAB_TOKEN, REPOS_PATH, JIRA_URL, JIRA_USERNAME, JIRA_PASSWORD


class MRDataCollector:
    def __init__(self, gitlab_url, token, mr_url, repos_path='', jira_url=None, jira_username=None, jira_password=None):
        self.gitlab_url = gitlab_url.rstrip('/')
        self.token = token
        self.mr_url = mr_url
        self.repos_path = repos_path
        self.gl = gitlab.Gitlab(self.gitlab_url, private_token=token)
        
        self.jira = None
        if jira_url and jira_username and jira_password:
            self.jira = JiraClient(jira_url, jira_username, jira_password)
    
    def _parse_mr_url(self):
        path = urlparse(self.mr_url).path
        parts = path.strip('/').split('/')
        dash_index = parts.index('-')
        project_path = '/'.join(parts[:dash_index])
        mr_iid = parts[-1]
        return project_path, int(mr_iid)
    
    def _get_project(self, project_path):
        try:
            return self.gl.projects.get(project_path)
        except:
            try:
                encoded_path = project_path.replace('/', '%2F')
                return self.gl.projects.get(encoded_path)
            except:
                projects = self.gl.projects.list(search=project_path.split('/')[-1], all=True)
                if not projects:
                    raise Exception(f"Projeto não encontrado: {project_path}")
                return projects[0]
    
    def _get_local_repo_path(self, project_path):
        if not self.repos_path:
            return None
        repo_name = project_path.split('/')[-1]
        local_path = Path(self.repos_path) / repo_name
        return str(local_path) if local_path.exists() else None
    
    def _get_gitlab_content(self, project, file_path):
        try:
            file_content = project.files.get(file_path, ref='HEAD')
            return file_content.decode().decode('utf-8')
        except:
            return None
    
    def collect(self):
        """Coleta todos os dados do MR"""
        project_path, mr_iid = self._parse_mr_url()
        project = self._get_project(project_path)
        mr = project.mergerequests.get(mr_iid)
        changes = mr.changes()
        local_repo = self._get_local_repo_path(project_path)
        
        # Dados básicos do MR
        mr_data = {
            'iid': mr.iid,
            'title': mr.title,
            'description': mr.description,
            'state': mr.state,
            'author': {
                'name': mr.author['name'],
                'username': mr.author['username']
            },
            'source_branch': mr.source_branch,
            'target_branch': mr.target_branch,
            'web_url': mr.web_url,
            'created_at': mr.created_at,
            'updated_at': mr.updated_at
        }
        
        # Arquivos modificados
        files_data = []
        for change in changes['changes']:
            if change['deleted_file']:
                continue
            
            file_info = {
                'path': change['new_path'],
                'old_path': change.get('old_path'),
                'new_file': change.get('new_file', False),
                'renamed_file': change.get('renamed_file', False),
                'diff': change.get('diff', ''),
                'content': self._get_gitlab_content(project, change['new_path'])
            }
            files_data.append(file_info)
        
        # Contexto do Jira
        jira_data = None
        if self.jira:
            issue_key = self.jira.extract_issue_key(mr.source_branch)
            if not issue_key:
                issue_key = self.jira.extract_issue_key(mr.target_branch)
            
            if issue_key:
                issue_context = self.jira.get_issue_context(issue_key)
                if issue_context:
                    jira_data = {
                        'key': issue_key,
                        'url': f"{self.jira.url}/browse/{issue_key}",
                        'summary': issue_context.get('summary'),
                        'description': issue_context.get('description'),
                        'issue_type': issue_context.get('issue_type'),
                        'status': issue_context.get('status'),
                        'priority': issue_context.get('priority')
                    }
        
        # Contexto do projeto local
        project_data = {
            'name': project.name,
            'path': project.path_with_namespace,
            'local_path': local_repo,
            'configs': {}
        }
        
        if local_repo:
            local_path = Path(local_repo)
            for config_file in ['pom.xml', 'package.json', 'requirements.txt', 'build.gradle']:
                config_path = local_path / config_file
                if config_path.exists():
                    try:
                        with open(config_path, 'r', encoding='utf-8') as f:
                            project_data['configs'][config_file] = f.read()
                    except:
                        pass
        
        return {
            'mr': mr_data,
            'files': files_data,
            'jira': jira_data,
            'project': project_data,
            'gitlab_url': self.gitlab_url
        }


def main():
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'URL do MR é obrigatória'}))
        sys.exit(1)
    
    mr_url = sys.argv[1]
    
    try:
        collector = MRDataCollector(
            GITLAB_URL, 
            GITLAB_TOKEN, 
            mr_url, 
            REPOS_PATH,
            JIRA_URL, 
            JIRA_USERNAME, 
            JIRA_PASSWORD
        )
        
        data = collector.collect()
        output = json.dumps(data, indent=2, ensure_ascii=False)
        
        # Write to stdout with UTF-8 encoding
        sys.stdout.reconfigure(encoding='utf-8')
        print(output)
        
    except Exception as e:
        sys.stdout.reconfigure(encoding='utf-8')
        print(json.dumps({'error': str(e)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
