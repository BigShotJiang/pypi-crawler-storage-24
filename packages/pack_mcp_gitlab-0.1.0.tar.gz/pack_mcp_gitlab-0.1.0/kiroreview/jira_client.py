import re
import requests
from urllib.parse import quote_plus


class JiraClient:
    def __init__(self, url, username, password):
        self.url = url.rstrip('/')
        self.username = username
        self.password = password
        self.session = requests.Session()
        # Configura headers padrão para parecer um navegador
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        })
        self.authenticated = self._login()
    
    def extract_issue_key(self, branch_name):
        """Extrai código do Jira da branch (ex: feature/PKW-12345 -> PKW-12345)"""
        if not branch_name:
            return None
            
        # Tenta padrões comuns: PKW-12345, PACK-123, etc.
        patterns = [
            r'([A-Z]+-\d+)',     # PKW-12345, PACK-123
            r'([A-Z]{2,}\d+)',   # PKW12345, PACK123
        ]
        
        for pattern in patterns:
            match = re.search(pattern, branch_name, re.IGNORECASE)
            if match:
                return match.group(1).upper()
        return None
    
    def _login(self):
        """Faz login no Jira e mantém sessão com cookies corretos"""
        try:
            # Acessa página inicial para obter cookies básicos
            self.session.get(f"{self.url}/", timeout=10)
            
            # Login via formulário
            login_page_url = f"{self.url}/login.jsp"
            response = self.session.get(login_page_url, timeout=10)
            
            if response.status_code == 200:
                html = response.text
                
                # Extrai tokens necessários
                atl_token_match = re.search(r'name="atl_token"[^>]*value="([^"]+)"', html)
                atl_token = atl_token_match.group(1) if atl_token_match else ''
                
                # Dados do login
                login_data = {
                    'os_username': self.username,
                    'os_password': self.password,
                    'os_cookie': 'true',
                    'login': 'Entrar no Sistema'
                }
                
                if atl_token:
                    login_data['atl_token'] = atl_token
                
                # Headers que imitam navegador real
                headers = {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Referer': login_page_url,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                }
                
                response = self.session.post(login_page_url, data=login_data, headers=headers, timeout=10, allow_redirects=True)
                
                # Verifica se obteve JSESSIONID
                if 'JSESSIONID' in self.session.cookies:
                    # Testa acesso autenticado
                    test_response = self.session.get(f"{self.url}/secure/Dashboard.jspa", timeout=10)
                    if test_response.status_code == 200 and 'login-form' not in test_response.text.lower():
                        return True
            
            return False
            
        except Exception:
            return False
    
    def get_issue_context(self, issue_key):
        """Busca contexto da issue no Jira incluindo aba Estimativa e requisito"""
        if not issue_key:
            return None
            
        try:
            # Tenta acesso direto à issue
            url = f"{self.url}/browse/{issue_key}"
            response = self.session.get(url, timeout=15)
            
            # Se foi redirecionado para login, tenta fazer login novamente
            if 'login.jsp' in response.url or response.status_code == 401:
                if self._login():
                    response = self.session.get(url, timeout=15)
                else:
                    return self._get_basic_issue_info(issue_key)
            
            if response.status_code == 200:
                html = response.text
                
                # Verifica se ainda está na página de login
                if 'login-form' in html or 'Entrar no Sistema' in html or 'Log In' in html:
                    # Tenta API REST mesmo sem autenticação web completa
                    api_result = self._try_api_access(issue_key)
                    if api_result and 'Ver no Jira' not in api_result.get('summary', ''):
                        return api_result
                    return self._get_basic_issue_info(issue_key)
                
                # Tenta API REST primeiro (mais confiável)
                api_result = self._try_api_access(issue_key)
                if api_result and 'Ver no Jira' not in api_result.get('summary', ''):
                    return api_result
                
                # Fallback: extrai da página HTML
                return self._parse_issue_page(issue_key, html)
            
            # Última tentativa: API REST
            api_result = self._try_api_access(issue_key)
            if api_result and 'Ver no Jira' not in api_result.get('summary', ''):
                return api_result
            
            return self._get_basic_issue_info(issue_key)
            
        except Exception as e:
            return self._get_basic_issue_info(issue_key)
    
    def _try_api_access(self, issue_key):
        """Tenta acessar issue via API REST"""
        try:
            # Tenta API com expand para pegar campos customizados
            api_url = f"{self.url}/rest/api/2/issue/{issue_key}"
            params = {
                'expand': 'names,schema,operations,editmeta,changelog,renderedFields'
            }
            
            response = self.session.get(api_url, params=params, timeout=15)
            
            if response.status_code == 200:
                data = response.json()
                fields = data.get('fields', {})
                
                # Extrai título
                summary = fields.get('summary', f'Issue {issue_key}')
                
                # Extrai descrição
                description_parts = []
                
                # Descrição padrão
                desc = fields.get('description', '')
                if isinstance(desc, str) and desc.strip():
                    # Remove HTML tags e limpa texto
                    clean_desc = re.sub(r'<[^>]+>', '', desc)
                    clean_desc = clean_desc.replace('\r', '').replace('\n\n', '\n')
                    clean_desc = clean_desc.strip()
                    if clean_desc:
                        description_parts.append(clean_desc)
                
                # Busca apenas campos customizados relevantes
                for field_key, field_value in fields.items():
                    if field_key.startswith('customfield_') and field_value:
                        if isinstance(field_value, str) and len(field_value.strip()) > 50:
                            # Filtra campos irrelevantes
                            clean_value = field_value.strip()
                            if (not clean_value.isdigit() and 
                                'almoço' not in clean_value.lower() and
                                'jePanel' not in clean_value and
                                'table border' not in clean_value and
                                not clean_value.startswith('(') and
                                len(clean_value.split()) > 5):  # Pelo menos 5 palavras
                                # Remove HTML se houver
                                clean_value = re.sub(r'<[^>]+>', '', clean_value)
                                clean_value = clean_value.strip()
                                if len(clean_value) > 100:
                                    description_parts.append(f"Requisito: {clean_value[:500]}")
                        elif isinstance(field_value, dict) and 'value' in field_value:
                            clean_value = str(field_value['value']).strip()
                            if (len(clean_value) > 50 and len(clean_value.split()) > 3):
                                description_parts.append(f"Requisito: {clean_value[:300]}")
                
                # Pega apenas a descrição principal se for boa
                if description_parts and len(description_parts[0]) > 200:
                    description = description_parts[0]  # Apenas descrição principal
                else:
                    description = '\n\n'.join(description_parts[:2]) if description_parts else 'Ver no Jira'
                
                return {
                    'key': issue_key,
                    'summary': summary,
                    'description': description[:800],
                    'issue_type': fields.get('issuetype', {}).get('name', 'API'),
                    'status': fields.get('status', {}).get('name', 'API'),
                    'priority': fields.get('priority', {}).get('name', 'API')
                }
            
            # Se API falhar, tenta busca simples
            simple_response = self.session.get(f"{self.url}/rest/api/2/issue/{issue_key}", timeout=10)
            if simple_response.status_code == 200:
                data = simple_response.json()
                fields = data.get('fields', {})
                
                return {
                    'key': issue_key,
                    'summary': fields.get('summary', f'Issue {issue_key}'),
                    'description': str(fields.get('description', 'Ver no Jira'))[:300],
                    'issue_type': fields.get('issuetype', {}).get('name', 'API'),
                    'status': fields.get('status', {}).get('name', 'API'),
                    'priority': fields.get('priority', {}).get('name', 'API')
                }
            
            return self._get_basic_issue_info(issue_key)
            
        except Exception:
            return self._get_basic_issue_info(issue_key)
    
    def _parse_issue_page(self, issue_key, html):
        """Extrai informações da página HTML da issue"""
        try:
            # Extrai título/resumo
            title_patterns = [
                r'<title>\[([^\]]+)\]\s*([^<]+)</title>',
                r'<h1[^>]*id="summary-val"[^>]*>([^<]+)</h1>',
                r'<span[^>]*id="summary-val"[^>]*>([^<]+)</span>'
            ]
            
            summary = f'Issue {issue_key}'
            for pattern in title_patterns:
                match = re.search(pattern, html, re.IGNORECASE | re.DOTALL)
                if match:
                    text = match.group(-1).strip()
                    text = re.sub(r'<[^>]+>', '', text)
                    if text and len(text) > 3:
                        summary = text[:200]
                        break
            
            # Busca especificamente por "Estimativa e requisito" ou campos customizados
            estimativa_patterns = [
                r'Estimativa e requisito[^>]*>.*?<div[^>]*class="[^"]*user-content-block[^"]*"[^>]*>([^<]+)</div>',
                r'customfield_[0-9]+.*?Estimativa.*?<div[^>]*>([^<]+)</div>',
                r'Requisito[^>]*>.*?<div[^>]*>([^<]+)</div>',
                r'Estimativa[^>]*>.*?<div[^>]*>([^<]+)</div>'
            ]
            
            estimativa_requisito = ''
            for pattern in estimativa_patterns:
                match = re.search(pattern, html, re.IGNORECASE | re.DOTALL)
                if match:
                    text = re.sub(r'<[^>]+>', '', match.group(1))
                    text = text.strip()
                    if text and len(text) > 10:
                        estimativa_requisito = text[:500]
                        break
            
            # Extrai descrição padrão
            desc_patterns = [
                r'<div[^>]*id="description-val"[^>]*>([^<]+)</div>',
                r'<div[^>]*class="[^"]*description[^"]*"[^>]*>([^<]+)</div>'
            ]
            
            description = 'Ver descrição no Jira'
            for pattern in desc_patterns:
                match = re.search(pattern, html, re.IGNORECASE | re.DOTALL)
                if match:
                    desc_text = re.sub(r'<[^>]+>', '', match.group(1))
                    desc_text = desc_text.strip()
                    if desc_text and len(desc_text) > 5:
                        description = desc_text[:300]
                        break
            
            # Combina descrição com estimativa e requisito
            if estimativa_requisito:
                description = f"{description}\n\nEstimativa e Requisito: {estimativa_requisito}"
            
            # Extrai status
            status_patterns = [
                r'<span[^>]*id="status-val"[^>]*>([^<]+)</span>',
                r'<span[^>]*class="[^"]*status[^"]*"[^>]*>([^<]+)</span>'
            ]
            
            status = 'Ver no Jira'
            for pattern in status_patterns:
                match = re.search(pattern, html, re.IGNORECASE)
                if match:
                    text = re.sub(r'<[^>]+>', '', match.group(1)).strip()
                    if text:
                        status = text
                        break
            
            # Extrai tipo
            type_patterns = [
                r'<span[^>]*id="type-val"[^>]*>([^<]+)</span>',
                r'<img[^>]*alt="([^"]+)"[^>]*title="Issue Type"'
            ]
            
            issue_type = 'Ver no Jira'
            for pattern in type_patterns:
                match = re.search(pattern, html, re.IGNORECASE)
                if match:
                    text = re.sub(r'<[^>]+>', '', match.group(1)).strip()
                    if text:
                        issue_type = text
                        break
            
            # Extrai prioridade
            priority_patterns = [
                r'<img[^>]*alt="Priority: ([^"]+)"',
                r'<span[^>]*id="priority-val"[^>]*>([^<]+)</span>'
            ]
            
            priority = 'Ver no Jira'
            for pattern in priority_patterns:
                match = re.search(pattern, html, re.IGNORECASE)
                if match:
                    text = re.sub(r'<[^>]+>', '', match.group(1)).strip()
                    if text:
                        priority = text
                        break
            
            return {
                'key': issue_key,
                'summary': summary,
                'description': description,
                'issue_type': issue_type,
                'status': status,
                'priority': priority
            }
            
        except Exception:
            return self._get_basic_issue_info(issue_key)
    
    def _get_ajax_issue_data(self, issue_key, html):
        """Extrai dados via chamada AJAX do Jira com headers corretos"""
        try:
            # Extrai issueId da página
            issue_id_patterns = [
                r'issueId["\s]*[:=]["\s]*([0-9]+)',
                r'data-issue-id="([0-9]+)"',
                r'"id"\s*:\s*([0-9]+)',
                r'issue["\s]*[:-]["\s]*([0-9]+)'
            ]
            
            issue_id = None
            for pattern in issue_id_patterns:
                match = re.search(pattern, html)
                if match:
                    issue_id = match.group(1)
                    break
            
            if not issue_id:
                return None
            
            # Extrai XSRF token se disponível
            xsrf_match = re.search(r'atlassian\.xsrf\.token["\s]*[:=]["\s]*([^"\s]+)', html)
            xsrf_token = xsrf_match.group(1) if xsrf_match else ''
            
            # Faz chamada AJAX com headers do curl
            ajax_url = f"{self.url}/secure/AjaxIssueEditAction!default.jspa"
            params = {
                'decorator': 'none',
                'issueId': issue_id,
                '_': '1759867344062'
            }
            
            headers = {
                'Accept': '*/*',
                'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                'Pragma': 'no-cache',
                'Referer': f'{self.url}/browse/{issue_key}',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'X-Requested-With': 'XMLHttpRequest',
                'X-SITEMESH-OFF': 'true',
                'sec-ch-ua': '"Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"'
            }
            
            if xsrf_token:
                headers['X-Atlassian-Token'] = xsrf_token
            
            response = self.session.get(ajax_url, params=params, headers=headers, timeout=15)
            
            if response.status_code == 200:
                return self._parse_ajax_response(issue_key, response.text)
            
            return None
            
        except Exception:
            return None
    
    def _parse_ajax_response(self, issue_key, html):
        """Parse da resposta AJAX com dados completos"""
        try:
            # Extrai título
            title_match = re.search(r'<h1[^>]*>([^<]+)</h1>', html, re.IGNORECASE)
            summary = title_match.group(1).strip() if title_match else f'Issue {issue_key}'
            
            # Busca por campos customizados
            field_patterns = [
                r'customfield_[0-9]+[^>]*>.*?<div[^>]*class="[^"]*field-value[^"]*"[^>]*>([^<]+)</div>',
                r'Estimativa[^>]*>.*?<div[^>]*>([^<]+)</div>',
                r'Requisito[^>]*>.*?<div[^>]*>([^<]+)</div>',
                r'<textarea[^>]*name="[^"]*customfield[^"]*"[^>]*>([^<]+)</textarea>'
            ]
            
            description_parts = []
            
            for pattern in field_patterns:
                matches = re.findall(pattern, html, re.IGNORECASE | re.DOTALL)
                for match in matches:
                    clean_text = re.sub(r'<[^>]+>', '', match).strip()
                    if clean_text and len(clean_text) > 10:
                        description_parts.append(clean_text)
            
            description = '\n\n'.join(description_parts[:3]) if description_parts else 'Ver no Jira'
            
            return {
                'key': issue_key,
                'summary': summary,
                'description': description[:800],
                'issue_type': 'AJAX',
                'status': 'AJAX',
                'priority': 'AJAX'
            }
            
        except Exception:
            return None
    
    def _get_basic_issue_info(self, issue_key):
        """Retorna informações básicas da issue quando não consegue acessar o Jira"""
        return {
            'key': issue_key,
            'summary': f'Issue {issue_key} - Acesse {self.url}/browse/{issue_key} para ver detalhes',
            'description': f'Acesse {self.url}/browse/{issue_key} para ver a descrição completa',
            'issue_type': 'Ver no Jira',
            'status': 'Ver no Jira', 
            'priority': 'Ver no Jira'
        }