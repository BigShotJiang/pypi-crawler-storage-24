# 🔍 Code Review — MR #874: Task/correcao testes

**📋 Informações do MR**
| Campo | Valor |
|-------|-------|
| **MR** | [#874](https://git.alterdata.com.br/pack/packup/radar-ecac/ms-radar-ecac/-/merge_requests/874) |
| **Título** | Task/correcao testes |
| **Autor** | Lyllys de Souza Galhardo (`lyllys.dsn.pack`) |
| **Branch Origem** | `task/correcao-testes` |
| **Branch Destino** | `correcao-testes-com-erro-ao-atualizar-ambientes` |
| **Estado** | Aberto |
| **Criado em** | 25/02/2026 |
| **Arquivos Modificados** | 2 |
| **Jira** | Não vinculado |

**🛠️ Stack Detectada**: Java · Spring Boot · JUnit 5 · Mockito · JPA/Hibernate

**📝 Resumo das Alterações**:
Este MR corrige testes unitários em dois arquivos:
1. `ReceberSituacaoFiscalTransactionalServiceTest.java` — Ajusta matcher de `isNull()` para `eq("Erro desconhecido")` no teste de justificativa nula.
2. `EmissaoGuiaControllerTest.java` — Remove imports e mocks duplicados, refatora método helper `criarParcelaMock` para `criarParcela`, e reorganiza a ordem dos stubs nos testes.

---

## 🌱 Hábito de Desenvolvimento: Nomenclatura de Branch Incorreta

**📁 Branch Origem**: `task/correcao-testes` **🎯 Branch Destino**: `correcao-testes-com-erro-ao-atualizar-ambientes` **🟡 Severidade**: Média

#### ❌ Padrão Atual
```
Origem: task/correcao-testes
Destino: correcao-testes-com-erro-ao-atualizar-ambientes
```

#### 🔍 O que está incorreto?
A branch de destino não segue o padrão `feature/CODIGO-PROCESSO`. Está usando um nome descritivo livre em vez de referenciar o código do processo/ticket.

#### ✅ Padrão Esperado
```
Origem: task/correcao-testes
Destino: feature/CODIGO-PROCESSO (ex: feature/PKW-XXXXX)
```

#### 💡 Por que padronizar?
- ✅ Facilita rastreabilidade entre branches e tickets do Jira
- ✅ Melhora organização do histórico de branches
- ✅ Padroniza workflow da equipe

**📌 Observação**: Não é impeditivo para merge, mas ajuda a manter consistência no projeto.

---

## ⚠️ Problema 1: Migração Incompleta do Método Helper de Teste

**📁 Arquivo**: `EmissaoGuiaControllerTest.java` **📍 Contexto**: Métodos de teste **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
// O MR adiciona o novo método:
private ParcelaParcelamento criarParcela() {
    Empresa empresa = new Empresa();
    empresa.setId(1L);
    empresa.setCpfCnpj(12345678000190L);
    ParcelamentoFiscal parcelamento = new ParcelamentoFiscal();
    parcelamento.setId(1L);
    parcelamento.setEmpresa(empresa);
    ParcelaParcelamento parcela = new ParcelaParcelamento();
    parcela.setId(1L);
    parcela.setParcelamentoFiscal(parcelamento);
    return parcela;
}

// Mas o método antigo criarParcelaMock(Long, Long) permanece no arquivo
// e ainda é usado por testes não tocados pelo diff:
// - deve_compartilhar_guia_unica (conteúdo original)
// - deve_compartilhar_guias_em_lote (conteúdo original)
// - deve_emitir_guias_em_lote (conteúdo original)
```

#### 🔍 O que está errado?
O MR migra parte dos testes para usar `criarParcela()` mas não remove o método antigo `criarParcelaMock(Long, Long)` nem migra os testes restantes. Isso deixa dois helpers com propósitos similares coexistindo na mesma classe de teste, gerando inconsistência.

#### ✅ Solução Sugerida
```java
// Migrar TODOS os testes para usar criarParcela()
// e remover completamente criarParcelaMock(Long, Long)
```

#### 💡 Por que melhorar?
- ✅ Elimina código duplicado na classe de teste
- ✅ Mantém consistência entre todos os testes
- ✅ Facilita manutenção futura

---

## ✅ Pontos Positivos

1. **Correção precisa do matcher no teste de justificativa nula**: A mudança de `isNull()` para `eq("Erro desconhecido")` no `ReceberSituacaoFiscalTransactionalServiceTest` reflete corretamente uma mudança no código de produção que agora trata justificativa nula com mensagem padrão.

2. **Limpeza de imports e mocks duplicados**: O MR remove duplicações pré-existentes de `Empresa` (import) e `AtividadeParcelamento` (import), além de mocks duplicados de `AtividadeParcelamentoService` e `ParcelaParcelamentoRepository`. Boa iniciativa de limpeza.

3. **Reorganização da ordem dos stubs**: Mover os `when()` para antes da execução melhora a legibilidade seguindo o padrão Given-When-Then.

4. **Novo helper `criarParcela()` mais completo**: Inclui `setCpfCnpj` e `setId` no parcelamento, fornecendo dados mais realistas para os testes.

---

## 📊 Resumo da Análise

| Severidade | Quantidade |
|------------|-----------|
| 🔴 Alta | 0 |
| 🟡 Média | 1 |
| 🟢 Baixa | 0 |
| 🌱 Hábito | 1 |

**Veredicto**: MR com boas correções de testes. O único ponto introduzido por este MR é a migração incompleta do helper `criarParcelaMock` → `criarParcela()`. Recomendo completar a migração de todos os testes antes do merge para evitar dois métodos com propósito similar na mesma classe.
