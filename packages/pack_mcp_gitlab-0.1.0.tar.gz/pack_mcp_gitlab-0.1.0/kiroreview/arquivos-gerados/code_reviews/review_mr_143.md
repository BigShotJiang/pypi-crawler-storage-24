# 📋 Code Review — MR #143

## 📌 Informações Gerais

| Campo | Valor |
|-------|-------|
| **MR** | [#143](https://git.alterdata.com.br/pack/packbots/packbots-core/-/merge_requests/143) |
| **Título** | CND-11151: Ajuste para receber via parametro elementos do CapMonster |
| **Autor** | Leonardo Pires de Aguiar |
| **Branch Origem** | `task/CND-11151-melhoria-no-reconhecimento-CapMonster` |
| **Branch Destino** | `feature/CND-11151` |
| **Estado** | Aberto |
| **Arquivos Alterados** | 3 |

## 📝 Descrição do MR

- Criada nova sobrecarga do método `quebrarCaptchaEmTexto` para aceitar novos parâmetros, tornando o CapMonster mais preciso.
- Mantida a lógica original para os robôs que já usam a assinatura antiga.
- Melhorias sutis para remover warnings da classe.
- Atualização da versão (2.30.8-SNAPSHOT → 2.31.0-SNAPSHOT).

## 📁 Arquivos Modificados

1. `src/main/java/br/com/alterdata/pack/web/robo/captcha/QuebradorCaptchaFacade.java`
2. `src/main/java/br/com/alterdata/pack/web/robo/Robo.java`
3. `pom.xml`

## 🔍 Análise Detalhada

### ✅ Pontos Positivos

1. **Retrocompatibilidade preservada**: O método original `quebrar(BufferedImage, Provedor)` foi mantido delegando para a nova sobrecarga com valores padrão. Isso garante que robôs existentes continuem funcionando sem alteração.

2. **Migração de `com.google.common.io.Files` para `java.nio.file.Files`**: Substituição correta de API Guava por API padrão do Java (`Files.write(Paths.get(...), bytes)`). Reduz dependência externa e segue boas práticas.

3. **Remoção de warnings**: Uso de `QuebradorCaptchaFacade.class` em vez do fully qualified name no Logger, e uso de `TypeToken<Map<String, Object>>` para eliminar unchecked cast warnings no Gson.

4. **Javadoc na nova sobrecarga**: Documentação dos parâmetros com link para a documentação oficial do CapMonster. Facilita o uso por outros desenvolvedores.

5. **Eliminação de método intermediário desnecessário**: `quebrarOnProvedor` foi removido, simplificando a cadeia de chamadas.

---

### 🌱 Hábito de Desenvolvimento: Nomenclatura de Branch Incorreta

**📁 Branch Origem**: `task/CND-11151-melhoria-no-reconhecimento-CapMonster` **🎯 Branch Destino**: `feature/CND-11151` **🟡 Severidade**: Média

#### ❌ Padrão Atual
```
Origem: task/CND-11151-melhoria-no-reconhecimento-CapMonster
Destino: feature/CND-11151
```

#### 🔍 O que está incorreto?
A branch de origem contém o código do processo (`CND-11151`) após `task/`. O padrão esperado é que a task descreva o que está sendo feito, sem repetir o código do ticket.

#### ✅ Padrão Esperado
```
Origem: task/melhoria-no-reconhecimento-CapMonster
Destino: feature/CND-11151
```

#### 💡 Por que padronizar?
- ✅ Facilita identificação do propósito da task
- ✅ Melhora rastreabilidade no histórico
- ✅ Padroniza workflow da equipe

**📌 Observação**: Não é impeditivo para merge, mas ajuda a manter consistência no projeto.

---

### ⚠️ Problema 1: Import Wildcard (`java.awt.*`)

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: 3 **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
import java.awt.*;
```

#### 🔍 O que está errado?
Import wildcard traz todas as classes do pacote `java.awt` para o escopo, poluindo o namespace e podendo causar conflitos de nomes. Além disso, não fica claro quais classes do pacote são realmente utilizadas.

#### ✅ Solução Sugerida
```java
// Importar apenas as classes efetivamente utilizadas
// Se nenhuma classe de java.awt é usada diretamente (BufferedImage já está importado separadamente),
// este import pode ser removido completamente.
```

#### 💡 Por que melhorar?
- ✅ Evita conflitos de nomes entre pacotes
- ✅ Melhora legibilidade e clareza das dependências
- ✅ Segue convenções de código Java (Checkstyle, SonarQube)

---

### ⚠️ Problema 2: Import Não Utilizado (`java.lang.reflect.Type` como campo)

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: 6 **🟢 Severidade**: Baixa

#### 🔍 Observação
O import de `java.lang.reflect.Type` é utilizado para declarar a constante `MAP_TYPE`. Isso está correto e é uma boa prática para evitar a criação repetida de `TypeToken` a cada chamada de `gson.fromJson`. Ponto positivo.

---

### ⚠️ Problema 3: Lógica de `clientKey` com Concatenação de Module

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: ~107 **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
body.put("clientKey", module.equals("universal") ? provedor.getkey() : provedor.getkey() + "__" + module);
```

#### 🔍 O que está errado?
1. Se `module` for `null`, haverá `NullPointerException` no `module.equals(...)`.
2. A lógica de concatenação da clientKey com o módulo (`key__module`) é uma convenção específica do CapMonster que não está documentada no código. Futuros desenvolvedores podem não entender o propósito do separador `__`.

#### ✅ Solução Sugerida
```java
// Proteção contra null e documentação da convenção
String clientKey = provedor.getkey();
if (module != null && !"universal".equals(module)) {
    // Convenção CapMonster: clientKey__moduleName para módulos específicos
    clientKey = clientKey + "__" + module;
}
body.put("clientKey", clientKey);
```

#### 💡 Por que melhorar?
- ✅ Elimina risco de NullPointerException
- ✅ Documenta a convenção de concatenação do CapMonster
- ✅ Melhora legibilidade com variável intermediária

---

### ⚠️ Problema 4: Parâmetro `module` Sem Validação

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: ~55 **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
public static String quebrar(BufferedImage img, Provedor provedor, boolean caseSensitive, int numeric, String module, int recognizingThreshold) throws IOException {
    return quebrarOn(img, provedor, caseSensitive, numeric, module, recognizingThreshold);
}
```

#### 🔍 O que está errado?
Os parâmetros `module`, `numeric` e `recognizingThreshold` não possuem validação de entrada. Valores inválidos (ex: `numeric` fora de 0-2, `recognizingThreshold` fora de 0-100, `module` nulo ou vazio) serão enviados diretamente à API do CapMonster, resultando em erros difíceis de diagnosticar.

#### ✅ Solução Sugerida
```java
public static String quebrar(BufferedImage img, Provedor provedor, boolean caseSensitive, int numeric, String module, int recognizingThreshold) throws IOException {
    if (numeric < 0 || numeric > 2) {
        throw new IllegalArgumentException("numeric deve ser 0 (qualquer), 1 (somente números) ou 2 (somente letras)");
    }
    if (recognizingThreshold < 0 || recognizingThreshold > 100) {
        throw new IllegalArgumentException("recognizingThreshold deve estar entre 0 e 100");
    }
    if (Strings.isNullOrEmpty(module)) {
        module = "universal";
    }
    return quebrarOn(img, provedor, caseSensitive, numeric, module, recognizingThreshold);
}
```

#### 💡 Por que melhorar?
- ✅ Fail-fast com mensagens claras de erro
- ✅ Evita chamadas inválidas à API externa
- ✅ Documenta os ranges válidos via exceções

---

### ⚠️ Problema 5: Remoção do `CapMonsterModule` do Task Body

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: ~98-107 **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
// ANTES (removido):
task.put("CapMonsterModule", "universal");

// DEPOIS: o módulo é passado via clientKey concatenada
body.put("clientKey", module.equals("universal") ? provedor.getkey() : provedor.getkey() + "__" + module);
```

#### 🔍 O que está errado?
A propriedade `CapMonsterModule` foi removida do body da task e o módulo agora é passado via concatenação na `clientKey`. Essa mudança de abordagem pode ter impacto nos robôs existentes que usam a sobrecarga original (sem parâmetros extras), pois o método antigo agora chama `quebrar(img, provedor, false, 0, "universal", 0)` — que por sua vez usa `module.equals("universal")` e envia apenas `provedor.getkey()` sem o `CapMonsterModule` no body.

Ou seja, para chamadas via a assinatura antiga, o `CapMonsterModule` que antes era enviado como `"universal"` agora não é mais enviado. Isso pode alterar o comportamento da API do CapMonster para os robôs existentes.

#### ✅ Solução Sugerida
```java
// Manter o CapMonsterModule no task body para garantir compatibilidade
task.put("CapMonsterModule", module);

// E manter a lógica da clientKey conforme implementado
```

#### 💡 Por que melhorar?
- ✅ Garante retrocompatibilidade com robôs existentes
- ✅ Envia o módulo de forma explícita na task
- ✅ Evita mudança silenciosa de comportamento

---

### ⚠️ Problema 6: Muitos Parâmetros Primitivos na Assinatura do Método

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: ~55 **🟢 Severidade**: Baixa

#### ❌ Código Problemático
```java
public static String quebrar(BufferedImage img, Provedor provedor, boolean caseSensitive, int numeric, String module, int recognizingThreshold)
```

#### 🔍 O que está errado?
A assinatura possui 6 parâmetros, sendo 4 deles configurações do CapMonster. Isso dificulta a leitura e aumenta o risco de erros na ordem dos argumentos (ex: trocar `numeric` com `recognizingThreshold`, ambos `int`).

#### ✅ Solução Sugerida
```java
// Criar um objeto de configuração
public class CapMonsterConfig {
    private boolean caseSensitive;
    private int numeric;          // 0=qualquer, 1=números, 2=letras
    private String module;        // "universal", "google", "yandex"
    private int recognizingThreshold; // 0-100

    // Builder pattern ou construtor com defaults
    public static CapMonsterConfig padrao() {
        return new CapMonsterConfig(false, 0, "universal", 0);
    }
}

// Uso simplificado
public static String quebrar(BufferedImage img, Provedor provedor, CapMonsterConfig config) throws IOException {
    return quebrarOn(img, provedor, config);
}
```

#### 💡 Por que melhorar?
- ✅ Elimina risco de trocar parâmetros de mesmo tipo
- ✅ Facilita adição de novos parâmetros no futuro
- ✅ Melhora legibilidade nas chamadas

---

### 💡 Débito Técnico: Conversão Redundante do Solution Map

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Contexto**: Método `obterResultadoCaptcha` **🟢 Severidade**: Baixa

#### 📋 Situação Atual
```java
Map<String, Object> solution = gson.fromJson(gson.toJsonTree(parsedResponse.get("solution")), MAP_TYPE);
```

#### 🎯 Oportunidade de Melhoria
A conversão `gson.toJsonTree` → `gson.fromJson` é uma forma de fazer um "deep cast" seguro do mapa interno. Funciona, mas é uma serialização/deserialização desnecessária quando o objeto já é um `Map<String, Object>` vindo do parse original.

#### 🔄 Sugestão para Futuro
```java
// Se o parse original já usa MAP_TYPE, o solution já será Map<String, Object>
@SuppressWarnings("unchecked")
Map<String, Object> solution = (Map<String, Object>) parsedResponse.get("solution");
```

#### 📈 Benefícios Futuros
- ✅ Elimina serialização/deserialização desnecessária
- ✅ Melhora performance (marginal)
- ✅ Código mais direto e legível

**💼 Recomendação**: Considerar em backlog para futuras melhorias.

---

## 📊 Resumo da Análise

| Severidade | Quantidade |
|------------|-----------|
| 🔴 Alta | 0 |
| 🟡 Média | 4 |
| 🟢 Baixa | 2 |
| 💡 Débito Técnico | 1 |
| 🌱 Hábito de Desenvolvimento | 1 |

## 🎯 Veredito

O MR implementa uma melhoria válida e bem estruturada no reconhecimento de captchas via CapMonster, com boa retrocompatibilidade. Os principais pontos de atenção são:

1. **Risco de regressão** (Problema 5): A remoção do `CapMonsterModule` do body da task pode impactar robôs existentes que dependiam desse campo.
2. **Proteção contra null** (Problema 3): O parâmetro `module` pode causar NPE se receber `null`.
3. **Validação de entrada** (Problema 4): Parâmetros numéricos sem validação de range.

**Recomendação**: Aprovar com as correções dos problemas 3 e 5 (risco de NPE e retrocompatibilidade do CapMonsterModule).

---

*Review gerado em 20/02/2026 por Kiro Code Review*
