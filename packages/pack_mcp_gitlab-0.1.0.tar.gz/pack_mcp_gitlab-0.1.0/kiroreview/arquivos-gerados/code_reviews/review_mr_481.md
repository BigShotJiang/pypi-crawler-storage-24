# 📋 Code Review — MR !481

| Campo | Valor |
|-------|-------|
| **Título** | PKW-60059: Corrige query de consulta para o status CNPJ INVÁLIDO |
| **Autor** | Fellipe Carreiro Rangel (`fellipecr.dsn.pack`) |
| **Branch** | `task/corrige-totalizador` → `feature/PKW-60059` |
| **Status** | 🔄 Aberto |
| **Projeto** | ms-eSindical |
| **Criado em** | 04/03/2026 17:20 |
| **GitLab** | [MR !481](https://git.alterdata.com.br/pack/packup/hub-de-acordos-coletivos/ms-eSindical/-/merge_requests/481) |
| **Jira** | [PKW-60059](https://jira.alterdata.com.br/browse/PKW-60059) |

---

## 📂 Arquivos Modificados

| Arquivo | Tipo |
|---------|------|
| `src/main/java/.../filter/AgendamentoFilter.java` | 🔧 Modificado |
| `pom.xml` | 🔧 Modificado |

---

## 🔍 Análise do Diff

### Resumo das Alterações

O MR corrige a query SQL do filtro de status "CNPJ Inválido" no `AgendamentoFilter.java`. A query antiga era simplista e incorreta, e foi substituída por uma query mais robusta e consistente com os demais filtros da classe (`gerarFiltroEmMonitoramento` e `gerarFiltroAtualizado`). Também houve bump de versão no `pom.xml` de `1.7.0-RC1` para `1.7.1-RC1`.

---

## ✅ Pontos Positivos

- ✅ A nova query segue o mesmo padrão estrutural dos métodos `gerarFiltroEmMonitoramento` e `gerarFiltroAtualizado`, trazendo consistência ao código
- ✅ Substituição de `LEFT JOIN` por `INNER JOIN` é mais correta semanticamente para este caso (precisa que o agendamento exista)
- ✅ Adição da verificação de `data_vigencia_final` e `s3_key IS NOT NULL` alinha a lógica com os demais filtros
- ✅ Adição da verificação de CNPJ do assinante (`cnpj_empresa = ANY(ar_check.cnpjs_empresas)`) torna o filtro mais preciso
- ✅ Bump de versão no `pom.xml` está correto para uma correção (patch version: 1.7.0 → 1.7.1)
- ✅ Branch de origem descritiva (`task/corrige-totalizador`) e destino correto (`feature/PKW-60059`)

---

## ⚠️ Problemas Identificados

### ⚠️ Problema 1: Risco de SQL Injection via String.format com data

**📁 Arquivo**: `AgendamentoFilter.java` **📍 Linha**: ~99 **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
var filtroCnpjInvalido = String.format(
		"NOT EXISTS (SELECT 1 FROM esindical.arquivo ar_check "
		+ "INNER JOIN esindical.agendamento ag_check ON ar_check.agendamento_id = ag_check.id "
		+ "WHERE ag_check.sindicato_id = ag.sindicato_id "
		+ "AND ar_check.s3_key IS NOT NULL "
		+ "AND EXISTS ("
		+ "SELECT 1 FROM esindical.assinante_agendamento asa_check "
		+ "INNER JOIN esindical.assinante assi_check ON assi_check.id = asa_check.assinante_id "
		+ "WHERE asa_check.agendamento_id = ag_check.id "
		+ "AND (assi_check.cnpj_empresa = ANY (ar_check.cnpjs_empresas) OR ar_check.cnpjs_empresas IS NULL))"
		+ "AND ar_check.data_vigencia_final > '%s') "
		+ "AND ag.mensagem_status = 'Cnpj inválido ou incorreto'",
		LocalDate.now().format(dateTimeFormatter));
```

#### 🔍 O que está errado?
A data é interpolada diretamente na string SQL via `String.format`. Embora neste caso o valor venha de `LocalDate.now()` (sem input do usuário), o padrão de concatenação de valores em SQL é um anti-pattern. Além disso, este mesmo padrão já existe nos métodos `gerarFiltroEmMonitoramento` e `gerarFiltroAtualizado`, então é um débito técnico herdado e não introduzido por este MR.

#### ✅ Solução Sugerida
Como o padrão já é utilizado nos demais métodos da classe e o valor vem de `LocalDate.now()` (controlado pela aplicação), o risco real é baixo. Idealmente, em uma refatoração futura, todos os filtros deveriam usar prepared statements ou parâmetros bind. Para este MR, manter a consistência com os demais métodos é aceitável.

#### 💡 Por que melhorar?
- ✅ Prepared statements previnem SQL injection por design
- ✅ Melhor performance com cache de plano de execução
- ✅ Padrão mais seguro e manutenível

**📌 Nota**: Não é impeditivo para merge — o padrão já existe na classe e o valor é controlado internamente.

---

### ⚠️ Problema 2: Espaço ausente antes de "AND" na concatenação de strings

**📁 Arquivo**: `AgendamentoFilter.java` **📍 Linha**: ~99 **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
+ "AND (assi_check.cnpj_empresa = ANY (ar_check.cnpjs_empresas) OR ar_check.cnpjs_empresas IS NULL))"
+ "AND ar_check.data_vigencia_final > '%s') "
```

#### 🔍 O que está errado?
Na concatenação entre as duas linhas, o fechamento do parêntese `)` da subquery `EXISTS` fica colado com o `AND` seguinte, gerando `...IS NULL))AND ar_check...` sem espaço. Isso pode causar erro de sintaxe SQL em tempo de execução.

#### ✅ Solução Sugerida
```java
+ "AND (assi_check.cnpj_empresa = ANY (ar_check.cnpjs_empresas) OR ar_check.cnpjs_empresas IS NULL)) "
+ "AND ar_check.data_vigencia_final > '%s') "
```

Ou alternativamente:
```java
+ "AND (assi_check.cnpj_empresa = ANY (ar_check.cnpjs_empresas) OR ar_check.cnpjs_empresas IS NULL))"
+ " AND ar_check.data_vigencia_final > '%s') "
```

#### 💡 Por que melhorar?
- ✅ Evita erro de sintaxe SQL em runtime
- ✅ Garante que a query seja executada corretamente
- ✅ Melhora legibilidade da query montada

**🔴 ATENÇÃO**: Este é um bug potencial que pode impedir o funcionamento correto do filtro. Recomendo verificar se a query gerada está sintaticamente correta antes do merge.

---

### ⚠️ Problema 3: Lógica invertida em relação ao filtro "Em Monitoramento"

**📁 Arquivo**: `AgendamentoFilter.java` **📍 Linha**: ~90-101 **🟢 Severidade**: Baixa

#### 🔍 Análise Comparativa

Comparando a nova query de `gerarFiltroCNPJInvalido` com `gerarFiltroEmMonitoramento`:

| Aspecto | CNPJ Inválido (novo) | Em Monitoramento |
|---------|---------------------|------------------|
| Operador principal | `NOT EXISTS` | `NOT EXISTS` |
| Condição mensagem_status | `= 'Cnpj inválido ou incorreto'` | `<> 'Cnpj inválido ou incorreto' OR ... is null` |

A lógica parece correta: o filtro de "CNPJ Inválido" busca registros que NÃO possuem arquivo válido vigente **E** que têm a mensagem de status "Cnpj inválido ou incorreto". Isso é o complemento lógico correto do filtro "Em Monitoramento".

#### 💡 Observação
A lógica está semanticamente correta. O `NOT EXISTS` garante que não há arquivo válido vigente, e o `AND ag.mensagem_status = 'Cnpj inválido ou incorreto'` filtra apenas os que têm esse status específico. Boa implementação.

---

## 📊 Resumo da Análise

| Métrica | Valor |
|---------|-------|
| Arquivos analisados | 2 |
| Problemas encontrados | 2 |
| 🔴 Alta severidade | 0 |
| 🟡 Média severidade | 2 |
| 🟢 Baixa severidade | 0 |
| ✅ Pontos positivos | 6 |

---

## 🎯 Recomendações Finais

1. **Corrigir o espaço ausente** entre `))"` e `"AND` na concatenação da query (Problema 2) — este é o ponto mais crítico e pode causar falha em runtime
2. **Testar a query gerada** executando-a diretamente no banco para validar a sintaxe antes do merge
3. O padrão de `String.format` para datas (Problema 1) é um débito técnico herdado e aceitável neste contexto

**Veredicto**: ✅ Aprovado com ressalva — corrigir o espaço na concatenação SQL (Problema 2) antes do merge.

---

*Review gerado em 04/03/2026 por KiroReview v3.1*
