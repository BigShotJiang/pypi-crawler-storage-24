# 📋 Code Review — MR #144

## 📌 Informações Gerais

| Campo | Valor |
|-------|-------|
| **MR** | [#144](https://git.alterdata.com.br/pack/packbots/packbots-core/-/merge_requests/144) |
| **Título** | Feature/cnd 11151 |
| **Autor** | Leonardo Pires de Aguiar |
| **Branch Origem** | `feature/CND-11151` |
| **Branch Destino** | `develop` |
| **Estado** | Aberto |
| **Arquivos Alterados** | 3 |

## 📝 Descrição do MR

Descrição não informada no MR. Este MR é o merge da feature `CND-11151` para `develop`, contendo as mesmas alterações já revisadas no [MR #143](https://git.alterdata.com.br/pack/packbots/packbots-core/-/merge_requests/143) (task → feature).

## ⚠️ Observação Importante

O diff deste MR é idêntico ao do MR #143. Trata-se do fluxo padrão: a task foi mergeada na feature (MR #143), e agora a feature está sendo mergeada na `develop` (MR #144). Todos os problemas e observações do review anterior se aplicam integralmente aqui.

## 📁 Arquivos Modificados

1. `src/main/java/br/com/alterdata/pack/web/robo/captcha/QuebradorCaptchaFacade.java`
2. `src/main/java/br/com/alterdata/pack/web/robo/Robo.java`
3. `pom.xml`

## 🔍 Análise Detalhada

### ✅ Pontos Positivos

1. **Retrocompatibilidade preservada**: O método original `quebrar(BufferedImage, Provedor)` foi mantido delegando para a nova sobrecarga com valores padrão.
2. **Migração de `com.google.common.io.Files` para `java.nio.file.Files`**: Reduz dependência do Guava, usa API padrão do Java.
3. **Remoção de warnings**: Logger com classe simplificada, `TypeToken` para eliminar unchecked casts no Gson.
4. **Javadoc na nova sobrecarga**: Documentação dos parâmetros com link para docs do CapMonster.
5. **Eliminação de método intermediário**: `quebrarOnProvedor` removido, simplificando a cadeia de chamadas.
6. **Bump de versão**: `2.30.8-SNAPSHOT` → `2.31.0-SNAPSHOT` (minor version, coerente com adição de funcionalidade).

---

### ⚠️ Problema 1: Descrição do MR Vazia

**📁 Arquivo**: MR metadata **📍 Contexto**: Descrição do Merge Request **🟡 Severidade**: Média

#### 🔍 O que está errado?
O MR não possui descrição. Para um merge de feature → develop, é importante documentar o que está sendo entregue, especialmente porque outros desenvolvedores e revisores precisam entender o escopo da mudança sem precisar navegar até o MR da task.

#### ✅ Sugestão
Adicionar descrição resumindo as alterações, por exemplo:
```
## Resumo
- Nova sobrecarga do método `quebrarCaptchaEmTexto` com parâmetros de configuração do CapMonster
- Migração de Guava Files para java.nio.file.Files
- Remoção de warnings e cleanup da classe QuebradorCaptchaFacade
- Bump de versão para 2.31.0-SNAPSHOT

## MR relacionado
- MR #143: task/CND-11151-melhoria-no-reconhecimento-CapMonster
```

#### 💡 Por que melhorar?
- ✅ Facilita o review e rastreabilidade
- ✅ Documenta o que entra na develop
- ✅ Histórico mais claro para a equipe

---

### ⚠️ Problema 2: Import Wildcard (`java.awt.*`)

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: 3 **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
import java.awt.*;
```

#### 🔍 O que está errado?
Import wildcard traz todas as classes do pacote `java.awt` para o escopo, poluindo o namespace. Se nenhuma classe adicional de `java.awt` é usada diretamente (além de `BufferedImage` que já tem import próprio), este import pode ser removido.

#### ✅ Solução Sugerida
```java
// Remover se não há uso direto, ou importar apenas o necessário
// import java.awt.SomeSpecificClass;
```

#### 💡 Por que melhorar?
- ✅ Evita conflitos de nomes entre pacotes
- ✅ Melhora clareza das dependências
- ✅ Segue convenções Java (Checkstyle, SonarQube)

---

### ⚠️ Problema 3: Risco de NPE no Parâmetro `module`

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: ~107 **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
body.put("clientKey", module.equals("universal") ? provedor.getkey() : provedor.getkey() + "__" + module);
```

#### 🔍 O que está errado?
Se `module` for `null`, haverá `NullPointerException`. Como este é um método público, chamadores externos podem passar `null`.

#### ✅ Solução Sugerida
```java
String clientKey = provedor.getkey();
if (module != null && !"universal".equals(module)) {
    clientKey = clientKey + "__" + module;
}
body.put("clientKey", clientKey);
```

#### 💡 Por que melhorar?
- ✅ Elimina risco de NullPointerException
- ✅ Usa comparação null-safe (`"universal".equals(module)`)
- ✅ Melhora legibilidade

---

### ⚠️ Problema 4: Remoção do `CapMonsterModule` do Body da Task

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: ~98 **🟡 Severidade**: Média

#### ❌ Código Problemático
```diff
-		task.put("CapMonsterModule", "universal");
```

#### 🔍 O que está errado?
O campo `CapMonsterModule` era enviado como `"universal"` no body da task e foi removido. Agora o módulo é controlado via concatenação na `clientKey`. Para chamadas pela assinatura antiga (sem parâmetros extras), o método delega com `module = "universal"`, resultando em `clientKey` = apenas `provedor.getkey()` — sem `CapMonsterModule` no body e sem concatenação na key.

Se a API do CapMonster não trata a ausência desse campo como default `"universal"`, pode haver mudança de comportamento silenciosa para robôs existentes.

#### ✅ Solução Sugerida
```java
// Manter o CapMonsterModule no task body para garantir compatibilidade
task.put("CapMonsterModule", module);
```

#### 💡 Por que melhorar?
- ✅ Garante retrocompatibilidade com robôs existentes
- ✅ Envia o módulo de forma explícita
- ✅ Evita mudança silenciosa de comportamento

---

### ⚠️ Problema 5: Falta Validação de Parâmetros

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Linha**: ~55 **🟢 Severidade**: Baixa

#### ❌ Código Problemático
```java
public static String quebrar(BufferedImage img, Provedor provedor, boolean caseSensitive, int numeric, String module, int recognizingThreshold) throws IOException {
    return quebrarOn(img, provedor, caseSensitive, numeric, module, recognizingThreshold);
}
```

#### 🔍 O que está errado?
Os parâmetros `numeric` (0-2) e `recognizingThreshold` (0-100) não possuem validação de range. Valores inválidos serão enviados diretamente à API do CapMonster.

#### ✅ Solução Sugerida
```java
public static String quebrar(BufferedImage img, Provedor provedor, boolean caseSensitive, int numeric, String module, int recognizingThreshold) throws IOException {
    if (numeric < 0 || numeric > 2) {
        throw new IllegalArgumentException("numeric deve ser 0, 1 ou 2");
    }
    if (recognizingThreshold < 0 || recognizingThreshold > 100) {
        throw new IllegalArgumentException("recognizingThreshold deve estar entre 0 e 100");
    }
    if (Strings.isNullOrEmpty(module)) {
        module = "universal";
    }
    return quebrarOn(img, provedor, caseSensitive, numeric, module, recognizingThreshold);
}
```

#### 💡 Por que melhorar?
- ✅ Fail-fast com mensagens claras
- ✅ Evita chamadas inválidas à API externa
- ✅ Documenta ranges válidos via código

---

### 💡 Débito Técnico: Muitos Parâmetros Primitivos

**📁 Arquivo**: `QuebradorCaptchaFacade.java` **📍 Contexto**: Assinatura do método `quebrar` **🟢 Severidade**: Baixa

#### 📋 Situação Atual
```java
public static String quebrar(BufferedImage img, Provedor provedor, boolean caseSensitive, int numeric, String module, int recognizingThreshold)
```

#### 🎯 Oportunidade de Melhoria
6 parâmetros na assinatura, sendo 4 configurações do CapMonster. Dois deles são `int`, o que facilita troca acidental de argumentos.

#### 🔄 Sugestão para Futuro
```java
public class CapMonsterConfig {
    private boolean caseSensitive;
    private int numeric;
    private String module;
    private int recognizingThreshold;

    public static CapMonsterConfig padrao() {
        return new CapMonsterConfig(false, 0, "universal", 0);
    }
}

public static String quebrar(BufferedImage img, Provedor provedor, CapMonsterConfig config) throws IOException { ... }
```

#### 📈 Benefícios Futuros
- ✅ Elimina risco de trocar parâmetros de mesmo tipo
- ✅ Facilita adição de novos parâmetros
- ✅ Melhora legibilidade nas chamadas

**💼 Recomendação**: Considerar em backlog para futuras melhorias.

---

## 📊 Resumo da Análise

| Severidade | Quantidade |
|------------|-----------|
| 🔴 Alta | 0 |
| 🟡 Média | 4 |
| 🟢 Baixa | 1 |
| 💡 Débito Técnico | 1 |

## 🎯 Veredito

Este MR é o merge da feature CND-11151 para `develop`, com diff idêntico ao MR #143. As alterações são válidas e bem estruturadas, adicionando flexibilidade ao reconhecimento de captchas via CapMonster.

Pontos críticos antes do merge para develop:

1. **Remoção do `CapMonsterModule`** (Problema 4): Pode causar regressão em robôs existentes. Validar se a API do CapMonster trata a ausência como default.
2. **NPE no `module`** (Problema 3): Método público sem proteção contra null.
3. **Descrição vazia** (Problema 1): Importante documentar o que entra na develop.

**Recomendação**: Aprovar com as correções dos problemas 3 e 4 antes do merge para develop.

---

*Review gerado em 20/02/2026 por Kiro Code Review*
