# 📋 Code Review — MR !964

| Campo | Valor |
|-------|-------|
| **Título** | ERE-490: Corrige parse de caracteres especiais no nome da empresa |
| **Autor** | Alec do Canto (`alec.dsn.pack`) |
| **Branch** | `task/ERE-490` → `hotfix/ERE-490` |
| **Status** | 🔄 Aberto |
| **Projeto** | ms-radar-ecac |
| **Criado em** | 16/03/2026 11:00 |
| **GitLab** | [MR !964](https://git.alterdata.com.br/pack/packup/radar-ecac/ms-radar-ecac/-/merge_requests/964) |
| **Jira** | [ERE-490](https://jira.alterdata.com.br/browse/ERE-490) |

---

## 📂 Arquivos Modificados

| Arquivo | Tipo |
|---------|------|
| `src/main/java/.../service/ProcuracaoServiceImpl.java` | 🔧 Modificado |
| `src/test/java/.../service/ProcuracaoServiceTest.java` | 🔧 Modificado |
| `src/test/java/.../service/ProcuracaoServiceXmlEscapeTest.java` | 🆕 Novo |
| `pom.xml` | 🔧 Modificado |

---

## 🔍 Análise do Diff

### Resumo das Alterações

O MR resolve um bug de caracteres especiais no nome da empresa ao gerar XML de procuração. A abordagem anterior usava `String.format` com text blocks para montar o XML, o que não fazia escape de caracteres especiais XML (`&`, `<`, `>`, `"`, `'`). A nova abordagem usa a API DOM (`javax.xml.parsers.DocumentBuilder`) para construir o XML programaticamente, garantindo que os valores dos atributos sejam escapados automaticamente pelo parser.

A mudança afeta dois métodos que geravam XML:
1. `gerarXmlProcuracao(...)` — procuração com destinatário customizado
2. `gerarXmlProcuracaoCorrigido(...)` — procuração com dados da Alterdata

Ambos agora delegam para o novo método privado `buildXmlProcuracao(...)`.

Bump de versão no `pom.xml`: `1.5.4-RC1` → `1.5.5-RC1`.

Os testes foram atualizados para validar o XML via DOM parsing em vez de `String.contains`, e um novo arquivo de teste para escape de caracteres especiais foi criado (conteúdo não disponível no diff).

---

## ✅ Pontos Positivos

- ✅ Excelente escolha ao usar DOM API para construção de XML — resolve o problema de escape de caracteres especiais de forma definitiva e robusta
- ✅ Eliminação de duplicação de código: dois métodos que tinham XML duplicado agora delegam para `buildXmlProcuracao`
- ✅ Os testes foram atualizados para usar DOM parsing, tornando as asserções mais precisas e menos frágeis que `String.contains`
- ✅ Criação de teste específico para escape de caracteres especiais (`ProcuracaoServiceXmlEscapeTest`)
- ✅ Bump de versão correto para hotfix (patch: 1.5.4 → 1.5.5)
- ✅ O método `buildXmlProcuracao` trata valores nulos nos atributos com fallback para `"null"`, evitando NPE

---

## ⚠️ Problemas Identificados

### 🌱 Hábito de Desenvolvimento: Nomenclatura de Branch Incorreta

**📁 Branch Origem**: `task/ERE-490` **🎯 Branch Destino**: `hotfix/ERE-490` **🟡 Severidade**: Média

#### ❌ Padrão Atual
```
Origem: task/ERE-490
Destino: hotfix/ERE-490
```

#### 🔍 O que está incorreto?
A branch de origem `task/ERE-490` usa o código do ticket Jira em vez de uma descrição do que está sendo feito. O padrão esperado é que `task/` seja seguido de uma descrição semântica da tarefa.

#### ✅ Padrão Esperado
```
Origem: task/corrige-parse-caracteres-especiais-xml
Destino: hotfix/ERE-490
```

#### 💡 Por que padronizar?
- ✅ Facilita identificação do propósito da task sem consultar o Jira
- ✅ Melhora rastreabilidade no histórico do Git
- ✅ Padroniza workflow da equipe

**📌 Observação**: Não é impeditivo para merge, mas ajuda a manter consistência no projeto.

---

### ⚠️ Problema 1: Valores nulos substituídos por string literal "null" nos atributos XML

**📁 Arquivo**: `ProcuracaoServiceImpl.java` **📍 Linha**: ~330-340 **🟡 Severidade**: Média

#### ❌ Código Problemático
```java
Element destinatario = doc.createElement("destinatario");
destinatario.setAttribute("numero", cnpjDestinatario != null ? cnpjDestinatario : "null");
destinatario.setAttribute("nome", nomeDestinatario != null ? nomeDestinatario : "null");
destinatario.setAttribute("tipo", "PJ");
destinatario.setAttribute("papel", "contratante");
dados.appendChild(destinatario);

Element assinadoPor = doc.createElement("assinadoPor");
assinadoPor.setAttribute("numero", numeroAssinante != null ? numeroAssinante : "null");
assinadoPor.setAttribute("nome", nomeAssinante != null ? nomeAssinante : "null");
assinadoPor.setAttribute("tipo", tipoAssinante != null ? tipoAssinante : "null");
assinadoPor.setAttribute("papel", "autor pedido de dados");
```

#### 🔍 O que está errado?
Quando um valor é nulo, o atributo XML recebe a string literal `"null"` (ex: `numero="null"`). Isso pode causar problemas na API do Serpro/Integra Contador, que pode interpretar `"null"` como um CNPJ ou nome válido. O comportamento anterior com `String.format` também colocava `"null"`, mas a migração para DOM era uma oportunidade de tratar isso melhor.

#### ✅ Solução Sugerida
```java
Element destinatario = doc.createElement("destinatario");
destinatario.setAttribute("numero", cnpjDestinatario != null ? cnpjDestinatario : "");
destinatario.setAttribute("nome", nomeDestinatario != null ? nomeDestinatario : "");
destinatario.setAttribute("tipo", "PJ");
destinatario.setAttribute("papel", "contratante");
dados.appendChild(destinatario);

Element assinadoPor = doc.createElement("assinadoPor");
assinadoPor.setAttribute("numero", numeroAssinante != null ? numeroAssinante : "");
assinadoPor.setAttribute("nome", nomeAssinante != null ? nomeAssinante : "");
assinadoPor.setAttribute("tipo", tipoAssinante != null ? tipoAssinante : "");
assinadoPor.setAttribute("papel", "autor pedido de dados");
```

Ou, idealmente, lançar uma exceção se valores obrigatórios forem nulos:
```java
if (numeroAssinante == null || nomeAssinante == null) {
    throw new IllegalArgumentException("Número e nome do assinante são obrigatórios para gerar procuração");
}
```

#### 💡 Por que melhorar?
- ✅ Evita enviar dados inválidos para a API do Serpro
- ✅ Fail-fast em caso de dados incompletos
- ✅ Facilita diagnóstico de problemas em produção

---

### ⚠️ Problema 2: Método `gerarXmlProcuracaoCorrigido` não foi migrado para usar `buildXmlProcuracao`

**📁 Arquivo**: `ProcuracaoServiceImpl.java` **📍 Contexto**: Método `gerarXmlProcuracaoCorrigido` **🟡 Severidade**: Média

#### ❌ Código Problemático
O diff mostra que apenas dois dos três métodos que geram XML foram migrados para usar `buildXmlProcuracao`. O método `gerarXmlProcuracaoCorrigido` (usado por `gerarProcuracaoAssinada` e `gerarProcuracaoAssinadaForAutomatedOperations`) ainda usa `String.format` com text block:

```java
private String gerarXmlProcuracaoCorrigido(String numeroAssinante, String nomeAssinante, 
        LocalDateTime vigencia, Certificado certificado) {
    // ...
    return String.format(
            """
            <?xml version="1.0" encoding="UTF-8"?>
            <termoDeAutorizacao>
                <dados>
                    ...
                    <destinatario numero="%s" nome="%s" .../>
                    <assinadoPor numero="%s" nome="%s" tipo="%s" .../>
                </dados>
            </termoDeAutorizacao>
            """,
            hoje.format(DATE_FORMATTER), vigencia.format(DATE_FORMATTER), cnpjAlterdata,
            "ALTERDATA TECNOLOGIA EM INFORMATICA LTDA", numeroAssinante, nomeAssinante, tipoAssinante);
}
```

#### 🔍 O que está errado?
Este é o método mais crítico, pois é usado no fluxo automatizado de geração de procuração assinada (`gerarProcuracaoAssinadaForAutomatedOperations`). Se o nome da empresa contiver caracteres especiais XML (o bug que este MR visa corrigir), o problema persistirá neste fluxo. A correção ficou incompleta.

#### ✅ Solução Sugerida
```java
private String gerarXmlProcuracaoCorrigido(String numeroAssinante, String nomeAssinante, 
        LocalDateTime vigencia, Certificado certificado) {
    LocalDateTime hoje = LocalDateTime.now();
    String tipoAssinante = numeroAssinante.length() == 11 ? "PF" : "PJ";
    String cnpjCertificado = extrairCnpjDoCertificado(certificado);

    log.info("Gerando XML com CNPJ empresa: {}, CNPJ certificado: {}", numeroAssinante, cnpjCertificado);

    return buildXmlProcuracao(hoje.format(DATE_FORMATTER), vigencia.format(DATE_FORMATTER),
            cnpjAlterdata, "ALTERDATA TECNOLOGIA EM INFORMATICA LTDA",
            numeroAssinante, nomeAssinante, tipoAssinante);
}
```

#### 💡 Por que melhorar?
- ✅ Garante que o fix de caracteres especiais se aplique a todos os fluxos
- ✅ Elimina a última duplicação de XML na classe
- ✅ O fluxo automatizado é o mais crítico e precisa da correção

**🔴 ATENÇÃO**: Este é o ponto mais importante do review. O método `gerarXmlProcuracaoCorrigido` é usado nos fluxos automatizados e continua vulnerável ao bug original de caracteres especiais.

---

### ⚠️ Problema 3: Ausência de `xml declaration` com `standalone` e formatação diferente do original

**📁 Arquivo**: `ProcuracaoServiceImpl.java` **📍 Linha**: ~345-350 **🟢 Severidade**: Baixa

#### ❌ Código Problemático
```java
TransformerFactory transformerFactory = TransformerFactory.newInstance();
Transformer transformer = transformerFactory.newTransformer();
transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
```

#### 🔍 O que está errado?
O XML gerado pelo DOM Transformer pode ter formatação diferente do original (indentação, quebras de linha, atributo `standalone` na declaração XML). O XML anterior tinha `<?xml version="1.0" encoding="UTF-8"?>` e o DOM pode gerar `<?xml version="1.0" encoding="UTF-8" standalone="no"?>`. Se a API do Serpro fizer validação estrita do XML declaration, isso pode causar rejeição.

#### ✅ Solução Sugerida
```java
transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
transformer.setOutputProperty(OutputKeys.STANDALONE, "yes"); // ou omitir standalone
transformer.setOutputProperty(OutputKeys.INDENT, "yes");
transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
```

Ou, se a API for sensível ao `standalone`:
```java
doc.setXmlStandalone(true); // Remove standalone="no" da declaração
```

#### 💡 Por que melhorar?
- ✅ Garante compatibilidade com a API do Serpro
- ✅ Mantém formatação legível do XML
- ✅ Evita rejeições por diferenças na declaração XML

---

### ⚠️ Problema 4: Vulnerabilidade XXE (XML External Entity) no `DocumentBuilderFactory`

**📁 Arquivo**: `ProcuracaoServiceImpl.java` **📍 Linha**: ~300 **🟢 Severidade**: Baixa

#### ❌ Código Problemático
```java
DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
```

#### 🔍 O que está errado?
O `DocumentBuilderFactory` é criado sem desabilitar features de entidades externas (XXE). Embora neste caso o XML esteja sendo **construído** (não parseado de input externo), é uma boa prática de segurança configurar o factory de forma segura, especialmente porque o mesmo padrão pode ser copiado para outros contextos onde há parsing de XML externo.

#### ✅ Solução Sugerida
```java
DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
docFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
docFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
docFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
```

#### 💡 Por que melhorar?
- ✅ Segue OWASP guidelines para prevenção de XXE
- ✅ Previne que o padrão seja copiado sem proteção para parsing de XML externo
- ✅ Defense in depth — proteção mesmo quando não estritamente necessário

---

## 📊 Resumo da Análise

| Métrica | Valor |
|---------|-------|
| Arquivos analisados | 4 |
| Problemas encontrados | 4 |
| 🔴 Alta severidade | 0 |
| 🟡 Média severidade | 2 |
| 🟢 Baixa severidade | 2 |
| ✅ Pontos positivos | 6 |
| 🌱 Hábitos de desenvolvimento | 1 |

---

## 🎯 Recomendações Finais

1. **Migrar `gerarXmlProcuracaoCorrigido` para usar `buildXmlProcuracao`** (Problema 2) — este é o ponto mais crítico. Sem essa mudança, o fluxo automatizado de procuração assinada continua vulnerável ao bug de caracteres especiais que o MR visa corrigir.
2. **Tratar valores nulos** de forma mais adequada nos atributos XML (Problema 1) — usar string vazia ou validação fail-fast em vez de `"null"`.
3. **Testar o XML gerado** contra a API do Serpro para garantir que a formatação do DOM é aceita (Problema 3).
4. A proteção XXE (Problema 4) é uma melhoria de segurança preventiva e pode ser feita neste MR ou em um futuro.

**Veredicto**: ⚠️ Aprovado com ressalvas — o Problema 2 (método `gerarXmlProcuracaoCorrigido` não migrado) é crítico e deve ser corrigido antes do merge, pois deixa o fluxo principal vulnerável ao bug original.

---

*Review gerado em 16/03/2026 por KiroReview v3.1*
