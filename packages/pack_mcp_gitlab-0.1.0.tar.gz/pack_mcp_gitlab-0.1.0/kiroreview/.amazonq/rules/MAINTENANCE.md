# 📋 Guia de Manutenção - Atualizações de Versão

Este documento define o processo para atualizar a versão do KiroReview e garantir consistência em toda a documentação.

---

## 🎯 Quando Atualizar a Versão

### Semantic Versioning (MAJOR.MINOR.PATCH)

- **MAJOR (X.0.0)**: Mudanças incompatíveis na API/arquitetura
  - Exemplo: v3.0 → v4.0 (Python → MCP)
  
- **MINOR (0.X.0)**: Novas funcionalidades compatíveis
  - Exemplo: v3.0 → v3.1 (adição de pareceres técnicos)
  
- **PATCH (0.0.X)**: Correções de bugs
  - Exemplo: v3.1.0 → v3.1.1 (fix em validação)

---

## 📝 Checklist de Atualização

Quando criar uma nova versão, siga este checklist:

### 1. ✅ Atualizar CHANGELOG.md

**Localização**: `CHANGELOG.md`

**O que fazer**:
- [ ] Adicionar nova seção com versão e data
- [ ] Listar mudanças em categorias:
  - ✨ Adicionado
  - 🔄 Modificado
  - 🗑️ Removido
  - 🐛 Corrigido
  - 🔒 Segurança
- [ ] Mover versão anterior para seção "Anterior"

**Exemplo**:
```markdown
## [3.2.0] - 2026-02-15

### ✨ Adicionado
- Nova funcionalidade X
- Suporte para Y

### 🔄 Modificado
- Melhorias em Z
```

---

### 2. ✅ Atualizar README.md

**Localização**: `README.md`

**Seções a atualizar**:

#### a) Arquitetura (se mudou)
```markdown
### Arquitetura v3.X  # ← Atualizar versão
```

#### b) Roadmap
```markdown
### [3.X.0] - YYYY-MM-DD (Atual) ✅

#### ✨ Adicionado
- Lista de novas funcionalidades

#### 🔄 Modificado
- Lista de modificações

📖 **[Ver histórico completo de mudanças →](CHANGELOG.md)**

---

### [3.X-1.0] - YYYY-MM-DD (Anterior) 📋
```

**Checklist**:
- [ ] Atualizar número da versão atual
- [ ] Mover versão anterior para seção "Anterior"
- [ ] Adicionar novas funcionalidades
- [ ] Atualizar data

---

### 3. ✅ Atualizar VISION.md

**Localização**: `VISION.md`

**Seções a atualizar**:

#### a) Estado Atual
```markdown
### Estado Atual (v3.X)  # ← Atualizar versão

O KiroReview v3.X usa...
- ✅ Funcionalidade 1
- ✅ Funcionalidade 2 (nova)
```

#### b) Comparação de Arquiteturas
```markdown
### v3.X (Atual) - Scripts Python  # ← Atualizar versão
```

#### c) Tabela de Benefícios
```markdown
| Aspecto | v3.X (Python) | v4.0 (MCP) |  # ← Atualizar versão
```

#### d) Experiência do Usuário
```markdown
### v3.X (Atual)  # ← Atualizar versão
```

#### e) Timeline
```markdown
**QX YYYY** - v3.X (Atual) ✅  # ← Atualizar versão e data
- Funcionalidade 1
- Funcionalidade 2 (nova)
```

#### f) Próximos Passos
```markdown
1. ✅ Consolidar v3.X (concluído)  # ← Atualizar versão
```

**Checklist**:
- [ ] Atualizar todas as menções à versão atual
- [ ] Adicionar novas funcionalidades na lista
- [ ] Atualizar timeline
- [ ] Atualizar comparações

---

### 4. ✅ Atualizar review_rules.md

**Localização**: `.amazonq/rules/review_rules.md`

**O que fazer**:
- [ ] Atualizar cabeçalho com nova versão

```markdown
# ==========================================
# CODE REVIEW RULES — v3.X  # ← Atualizar aqui
# ==========================================
```

---

### 5. ✅ Atualizar structure.md

**Localização**: `.amazonq/rules/memory-bank/structure.md`

**O que fazer**:
- [ ] Atualizar referência à versão nas regras

```markdown
**review_rules.md** - Analysis guidelines
- Defines formal code review rules (v3.X)  # ← Atualizar aqui
```

---

### 6. ✅ Verificar Consistência

**Checklist final**:
- [ ] Todas as menções à versão estão atualizadas?
- [ ] CHANGELOG.md tem a nova versão?
- [ ] README.md roadmap está atualizado?
- [ ] VISION.md reflete a versão atual?
- [ ] review_rules.md tem a versão correta?
- [ ] structure.md está consistente?
- [ ] Datas estão corretas?

---

## 🔍 Arquivos que Mencionam Versão

### Lista Completa de Arquivos

1. **CHANGELOG.md** - Histórico de versões
2. **README.md** - Seção Roadmap
3. **VISION.md** - Estado atual e comparações
4. **.amazonq/rules/review_rules.md** - Cabeçalho
5. **.amazonq/rules/memory-bank/structure.md** - Referência às regras

### Busca Rápida

Para encontrar todas as menções à versão atual:
```bash
# Windows
findstr /s /i "v3.1" *.md

# Unix/Linux/macOS
grep -r "v3.1" *.md
```

---

## 📋 Template de Atualização

Use este template ao criar uma nova versão:

```markdown
## Atualização para v3.X.0

### Mudanças
- [ ] Funcionalidade 1 adicionada
- [ ] Funcionalidade 2 modificada
- [ ] Bug X corrigido

### Arquivos Atualizados
- [ ] CHANGELOG.md - Nova seção criada
- [ ] README.md - Roadmap atualizado
- [ ] VISION.md - Estado atual atualizado
- [ ] review_rules.md - Versão atualizada
- [ ] structure.md - Referência atualizada

### Verificação
- [ ] Todas as versões consistentes
- [ ] Datas corretas
- [ ] Links funcionando
- [ ] Exemplos atualizados
```

---

## 🚨 Erros Comuns a Evitar

1. ❌ **Esquecer de atualizar VISION.md**
   - Sempre atualizar estado atual e comparações

2. ❌ **Versões inconsistentes**
   - Verificar todos os 5 arquivos

3. ❌ **Datas incorretas**
   - Usar formato: YYYY-MM-DD

4. ❌ **Não mover versão anterior**
   - Sempre mover versão atual para "Anterior"

5. ❌ **Esquecer review_rules.md**
   - Atualizar cabeçalho do arquivo

---

## 🎯 Exemplo Prático: v3.1 → v3.2

### Cenário
Adicionamos suporte para GitHub além do GitLab.

### Passo a Passo

1. **CHANGELOG.md**
```markdown
## [3.2.0] - 2026-02-15

### ✨ Adicionado
- Suporte para análise de Pull Requests do GitHub
- Integração com GitHub API
```

2. **README.md**
```markdown
### [3.2.0] - 2026-02-15 (Atual) ✅

#### ✨ Adicionado
- Suporte para GitHub (Pull Requests)
- Integração com GitHub API

---

### [3.1.0] - 2026-01-29 (Anterior) 📋
```

3. **VISION.md**
```markdown
### Estado Atual (v3.2)

O KiroReview v3.2 usa...
- ✅ Suporte GitLab e GitHub
```

4. **review_rules.md**
```markdown
# CODE REVIEW RULES — v3.2
```

5. **structure.md**
```markdown
- Defines formal code review rules (v3.2)
```

---

## 📞 Dúvidas?

Se tiver dúvidas sobre o processo de atualização:
1. Consulte este guia
2. Veja o histórico no CHANGELOG.md
3. Compare com atualizações anteriores (ex: v3.0 → v3.1)

---

**Última atualização**: 2026-01-29 (v3.1)
