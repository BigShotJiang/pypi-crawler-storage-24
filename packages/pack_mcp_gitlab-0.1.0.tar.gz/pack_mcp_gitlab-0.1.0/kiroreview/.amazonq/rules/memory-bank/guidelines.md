# Development Guidelines

## Code Quality Standards

### 1. Module Documentation
- **Pattern**: Every module starts with a triple-quoted docstring explaining its purpose
- **Example**:
  ```python
  """
  Coleta dados do Merge Request para análise
  Retorna JSON com todas as informações necessárias
  """
  ```
- **Frequency**: 4/5 files (80%)
- **Rationale**: Provides immediate context for module purpose and usage

### 2. Naming Conventions
- **Classes**: PascalCase (e.g., `MRDataCollector`, `JiraClient`)
- **Functions/Methods**: snake_case with descriptive verbs (e.g., `extract_issue_key`, `collect`, `generate_review_md`)
- **Private Methods**: Prefix with underscore (e.g., `_parse_mr_url`, `_get_project`, `_login`)
- **Constants**: UPPER_SNAKE_CASE (e.g., `GITLAB_URL`, `GITLAB_TOKEN`, `REPOS_PATH`)
- **Variables**: snake_case with descriptive nouns (e.g., `mr_data`, `files_data`, `jira_data`)

### 3. Import Organization
- **Pattern**: Standard library → Third-party → Local modules
- **Example**:
  ```python
  import json
  import sys
  from pathlib import Path
  import gitlab
  from urllib.parse import urlparse
  from jira_client import JiraClient
  from config import GITLAB_URL, GITLAB_TOKEN
  ```
- **Frequency**: 5/5 files (100%)

### 4. Error Handling Philosophy
- **Graceful Degradation**: Optional features fail silently, core features raise exceptions
- **Pattern**: Try-except blocks with fallback values or alternative methods
- **Example**:
  ```python
  try:
      return self.gl.projects.get(project_path)
  except:
      try:
          encoded_path = project_path.replace('/', '%2F')
          return self.gl.projects.get(encoded_path)
      except:
          projects = self.gl.projects.list(search=project_path.split('/')[-1])
          return projects[0]
  ```
- **Frequency**: Extensive throughout codebase

### 5. Configuration Management
- **Pattern**: Centralized configuration via environment variables
- **Implementation**: Single `config.py` module loads `.env` file
- **Validation**: Required variables raise `ValueError` if missing
- **Example**:
  ```python
  if not GITLAB_TOKEN:
      raise ValueError("GITLAB_TOKEN é obrigatório")
  ```

## Architectural Patterns

### 1. Class-Based Orchestration
- **Pattern**: Main functionality encapsulated in classes with clear responsibilities
- **Examples**:
  - `MRDataCollector`: Orchestrates GitLab, Jira, and local repo data collection
  - `JiraClient`: Handles all Jira API interactions and authentication
- **Benefits**: Encapsulation, state management, reusability

### 2. Private Method Decomposition
- **Pattern**: Public methods delegate to private helper methods
- **Naming**: Private methods prefixed with `_` (e.g., `_parse_mr_url`, `_get_project`)
- **Rationale**: Separates public API from implementation details
- **Example**:
  ```python
  def collect(self):
      """Public method - orchestrates collection"""
      project_path, mr_iid = self._parse_mr_url()  # Private helper
      project = self._get_project(project_path)     # Private helper
      # ... more logic
  ```

### 3. Fallback Chain Pattern
- **Pattern**: Multiple attempts with progressively simpler approaches
- **Usage**: API access, authentication, data extraction
- **Example** (Jira authentication):
  ```python
  # Try API with full expansion
  response = self.session.get(api_url, params={'expand': '...'})
  if response.status_code == 200:
      return parse_full_data()
  
  # Fallback: Try simple API
  simple_response = self.session.get(simple_api_url)
  if simple_response.status_code == 200:
      return parse_simple_data()
  
  # Final fallback: Return basic info
  return self._get_basic_issue_info(issue_key)
  ```

### 4. Data Structure Consistency
- **Pattern**: Consistent dictionary structures for data exchange
- **Example** (Jira issue data):
  ```python
  return {
      'key': issue_key,
      'summary': summary,
      'description': description,
      'issue_type': issue_type,
      'status': status,
      'priority': priority
  }
  ```
- **Benefits**: Predictable data contracts, easy serialization to JSON

### 5. Optional Feature Pattern
- **Pattern**: Check for optional dependencies/configs before using
- **Example**:
  ```python
  self.jira = None
  if jira_url and jira_username and jira_password:
      self.jira = JiraClient(jira_url, jira_username, jira_password)
  
  # Later usage
  if self.jira:
      issue_key = self.jira.extract_issue_key(branch_name)
  ```

## API Integration Patterns

### 1. Session Management
- **Pattern**: Use `requests.Session()` for persistent connections
- **Benefits**: Cookie persistence, connection pooling, header reuse
- **Example**:
  ```python
  self.session = requests.Session()
  self.session.headers.update({
      'User-Agent': 'Mozilla/5.0...',
      'Accept': 'application/json'
  })
  ```

### 2. Browser Emulation
- **Pattern**: Set comprehensive headers to mimic real browser requests
- **Usage**: Jira web scraping when API access limited
- **Headers**: User-Agent, Accept, Accept-Language, Referer, sec-ch-ua
- **Rationale**: Bypass bot detection, ensure consistent responses

### 3. Multiple Extraction Strategies
- **Pattern**: Try multiple regex patterns or parsing approaches
- **Example**:
  ```python
  patterns = [
      r'<title>\[([^\]]+)\]\s*([^<]+)</title>',
      r'<h1[^>]*id="summary-val"[^>]*>([^<]+)</h1>',
      r'<span[^>]*id="summary-val"[^>]*>([^<]+)</span>'
  ]
  
  for pattern in patterns:
      match = re.search(pattern, html)
      if match:
          return match.group(-1).strip()
  ```

### 4. GitLab API Wrapper Usage
- **Pattern**: Use `python-gitlab` library for type-safe GitLab interactions
- **Example**:
  ```python
  self.gl = gitlab.Gitlab(gitlab_url, private_token=token)
  project = self.gl.projects.get(project_path)
  mr = project.mergerequests.get(mr_iid)
  changes = mr.changes()
  ```

## Data Processing Patterns

### 1. JSON as Intermediate Format
- **Pattern**: Collect data → JSON → Analysis → Markdown
- **Benefits**: Decoupling, caching, debugging, testability
- **Example**:
  ```python
  data = collector.collect()
  output = json.dumps(data, indent=2, ensure_ascii=False)
  print(output)  # Consumed by Amazon Q
  ```

### 2. UTF-8 Encoding Enforcement
- **Pattern**: Explicitly configure UTF-8 for all I/O operations
- **Example**:
  ```python
  sys.stdout.reconfigure(encoding='utf-8')
  with open(file, 'w', encoding='utf-8') as f:
      f.write(content)
  ```
- **Rationale**: Ensures proper handling of international characters

### 3. Path Handling with pathlib
- **Pattern**: Use `pathlib.Path` for cross-platform path operations
- **Example**:
  ```python
  local_path = Path(self.repos_path) / repo_name
  if local_path.exists():
      config_path = local_path / 'pom.xml'
  ```

### 4. Structured Data Collection
- **Pattern**: Organize collected data into logical sections
- **Structure**:
  ```python
  {
      'mr': {...},           # MR metadata
      'files': [...],        # Changed files with diffs
      'jira': {...},         # Business context
      'project': {...},      # Project configs
      'gitlab_url': '...'    # Source URL
  }
  ```

## Output Formatting Patterns

### 0. Markdown File Generation (CRITICAL)
- **Pattern**: ALWAYS generate a Markdown file with the complete code review
- **Filename**: `review_mr_{MR_IID}.md` (e.g., `review_mr_4373.md`)
- **Location**: arquivos-gerados/code_reviews/ in Root directory of kiroreview project
- **Timing**: Generate AFTER completing the analysis, BEFORE showing results to user
- **Content**: Complete review with all sections (header, problems, summary, recommendations)
- **Example**:
  ```python
  # After analysis is complete:
  with open(f'review_mr_{mr_iid}.md', 'w', encoding='utf-8') as f:
      f.write(markdown_content)
  ```
- **IMPORTANT**: This is a MANDATORY step - never skip file generation

### 1. Emoji-Based Visual Hierarchy
- **Pattern**: Use emojis for quick visual scanning
- **Categories**:
  - Status: ✅ (merged), 🔄 (opened), ❌ (closed)
  - Severity: 🔴 (high), 🟡 (medium), 🟢 (low)
  - Types: 📖 (story), 🐛 (bug), 🛠️ (task)
  - Files: 📂 (directory), 📄 (file), 🔧 (code file)

### 2. Markdown Table Formatting
- **Pattern**: Use tables for structured information display
- **Example**:
  ```python
  md_content = f"""
  | Campo | Valor |
  |-------|-------|
  | **Autor** | {author} |
  | **Branch** | `{source}` → `{target}` |
  | **Status** | {emoji} {state} |
  """
  ```

### 3. Directory Tree Visualization
- **Pattern**: Group files by directory with tree-like structure
- **Example**:
  ```
  📂 src/main/java/
  ├── 🔧 Service.java
  └── 🔧 Controller.java
  ```

### 4. Timestamp Formatting
- **Pattern**: Brazilian date format (DD/MM/YYYY HH:MM)
- **Example**:
  ```python
  datetime.now().strftime('%d/%m/%Y %H:%M')
  ```

## Command-Line Interface Patterns

### 1. Argument Validation
- **Pattern**: Check argument count before processing
- **Example**:
  ```python
  if len(sys.argv) < 2:
      print(json.dumps({'error': 'URL do MR é obrigatória'}))
      sys.exit(1)
  ```

### 2. Structured Error Responses
- **Pattern**: Return JSON with error field for programmatic handling
- **Example**:
  ```python
  try:
      data = collector.collect()
      print(json.dumps(data, ensure_ascii=False))
  except Exception as e:
      print(json.dumps({'error': str(e)}, ensure_ascii=False))
      sys.exit(1)
  ```

### 3. Progress Indicators
- **Pattern**: Use emoji and descriptive messages for user feedback
- **Example**:
  ```python
  print("🔄 Coletando dados do MR...")
  print("✅ Dados coletados com sucesso!")
  print("❌ Erro ao coletar dados")
  ```

## Security and Best Practices

### 1. Credential Management
- **Pattern**: Never hardcode credentials, always use environment variables
- **Implementation**: `.env` file (not versioned) + `.env.example` (versioned template)
- **Validation**: Raise error if required credentials missing

### 2. HTML Sanitization
- **Pattern**: Strip HTML tags when extracting text from web pages
- **Example**:
  ```python
  clean_text = re.sub(r'<[^>]+>', '', html_content)
  clean_text = clean_text.strip()
  ```

### 3. Timeout Configuration
- **Pattern**: Always specify timeouts for network requests
- **Example**:
  ```python
  response = self.session.get(url, timeout=15)
  ```

### 4. Content Length Limiting
- **Pattern**: Truncate long content to prevent memory issues
- **Example**:
  ```python
  description = description[:800]  # Limit to 800 chars
  summary = summary[:200]          # Limit to 200 chars
  ```

## Testing and Debugging Patterns

### 1. Dual Execution Modes
- **Pattern**: Support both automated (Amazon Q) and manual (CLI) execution
- **Implementation**: `if __name__ == "__main__":` blocks with standalone logic

### 2. Intermediate File Output
- **Pattern**: Save intermediate data for inspection and debugging
- **Example**: `mr_data.json` saved before analysis

### 3. Verbose Error Messages
- **Pattern**: Include context in error messages
- **Example**:
  ```python
  raise Exception(f"Projeto não encontrado: {project_path}")
  ```

## Code Idioms and Conventions

### 1. String Manipulation
- **f-strings**: Preferred for string formatting
- **strip()**: Always strip whitespace from extracted text
- **rstrip('/')**: Remove trailing slashes from URLs

### 2. Dictionary Access
- **get() with defaults**: `data.get('key', default_value)`
- **Nested access**: `fields.get('author', {}).get('name', 'Unknown')`

### 3. List Comprehensions
- **Pattern**: Used sparingly, prefer explicit loops for clarity
- **Example**: `[Path(file_path).name for file_path in files]`

### 4. Boolean Checks
- **Truthiness**: Leverage Python's truthiness (empty strings, None, empty lists are falsy)
- **Example**: `if not branch_name:` instead of `if branch_name == None or branch_name == '':`

### 5. Regular Expressions
- **Flags**: Use `re.IGNORECASE` and `re.DOTALL` for flexible matching
- **Multiple patterns**: Try multiple patterns in sequence for robustness
- **Extraction**: Use `match.group(1)` or `match.group(-1)` for captured groups
