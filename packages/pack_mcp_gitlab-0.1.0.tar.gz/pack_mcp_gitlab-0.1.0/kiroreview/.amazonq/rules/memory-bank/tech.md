# Technology Stack

## Programming Language
- **Python 3.7+**
  - Modern Python features (f-strings, type hints)
  - Standard library for file I/O and JSON processing
  - Cross-platform compatibility (Windows, Linux, macOS)

## Core Dependencies

### HTTP and API Clients
```
requests==2.31.0
```
- General-purpose HTTP client for REST API calls
- Used for Jira API integration
- Session management and authentication support

```
python-gitlab==4.4.0
```
- Official GitLab API wrapper
- Simplifies MR, diff, and file retrieval
- Handles pagination and rate limiting
- Provides typed objects for GitLab resources

### Configuration Management
```
python-dotenv==1.0.1
```
- Loads environment variables from `.env` files
- Separates secrets from code
- Supports development and production configurations

## Development Environment

### Setup Commands
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment (Windows)
venv\Scripts\activate

# Activate virtual environment (Unix/macOS)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Environment Configuration
Create `.env` file in project root:
```bash
# Required
GITLAB_URL=https://git.alterdata.com.br
GITLAB_TOKEN=your_gitlab_token_here

# Optional (enhances analysis)
REPOS_PATH=C:\\path\\to\\local\\repositories
JIRA_URL=https://jira.alterdata.com.br
JIRA_USERNAME=your_jira_username
JIRA_PASSWORD=your_jira_password
```

### GitLab Token Permissions
Required scopes:
- `api` - Full API access
- `read_api` - Read-only API access
- `read_user` - Read user information
- `read_repository` - Read repository data

## Runtime Environment

### Execution Context
- **Primary**: Amazon Q Chat (automated invocation)
- **Alternative**: Command-line (manual testing)

### Command-Line Usage
```bash
# Collect MR data
python collect_mr_data.py <MR_URL>

# Example
python collect_mr_data.py https://git.alterdata.com.br/pack/packup/ms-contabilidade/-/merge_requests/158
```

### Output Files
- `mr_data.json` - Structured context data (intermediate)
- `review_mr_{MR_IID}.md` - Final review report

## Integration Points

### Amazon Q Chat Integration
- Amazon Q invokes Python scripts via subprocess
- Scripts output JSON to stdout
- Amazon Q parses JSON and performs analysis
- Results formatted via `generate_review_md.py`

### GitLab API Integration
- **Endpoint**: Configured via `GITLAB_URL`
- **Authentication**: Personal access token via `GITLAB_TOKEN`
- **Resources**: Merge requests, diffs, files, commits
- **Rate Limiting**: Handled by `python-gitlab` library

### Jira API Integration
- **Endpoint**: Configured via `JIRA_URL`
- **Authentication**: Basic auth (username/password)
- **Resources**: Issues, comments, transitions
- **Optional**: Gracefully degrades if not configured

### Local Repository Integration
- **Path**: Configured via `REPOS_PATH`
- **Access**: Direct filesystem reads
- **Targets**: Configuration files (pom.xml, package.json, etc.)
- **Optional**: Enhances context but not required

## Platform Support

### Operating Systems
- **Windows**: Primary development platform
- **Linux**: Fully supported
- **macOS**: Fully supported

### Path Handling
- Uses `os.path` for cross-platform compatibility
- Windows paths in `.env` use double backslashes: `C:\\path\\to\\repos`
- Unix paths use forward slashes: `/path/to/repos`

## Build and Deployment

### No Build Step Required
- Python scripts run directly (interpreted)
- No compilation or bundling needed
- Dependencies installed via pip

### Deployment Model
- **Current (v3.0)**: Local installation per user
- **Future (v4.0)**: MCP servers (zero local installation)

### Version Control
- **Versioned**: All `.py` files, `requirements.txt`, `.env.example`, documentation
- **Not Versioned**: `.env` (secrets), `mr_data.json` (temporary), `review_mr_*.md` (generated)

## Development Tools

### Recommended IDE
- **Amazon Q Plugin**: Integrated code review and chat
- **VS Code**: Python extension for development
- **PyCharm**: Full-featured Python IDE

### Testing
- Manual testing via command-line execution
- Amazon Q Chat integration testing
- No automated test suite (current version)

### Debugging
- Standard Python debugging tools
- JSON output inspection (`mr_data.json`)
- Environment variable validation via `config.py`

## Performance Characteristics

### Data Collection
- **GitLab API**: ~1-3 seconds per MR (network dependent)
- **Jira API**: ~0.5-1 second per issue (network dependent)
- **Local Repos**: <1 second (filesystem I/O)

### Analysis
- **Amazon Q**: Variable (depends on context size and complexity)
- **Markdown Generation**: <1 second (formatting only)

### Scalability
- Single MR analysis: Optimized
- Batch processing: Not currently supported
- Large diffs: Handled by Amazon Q context management

## Future Technology Direction (v4.0)

### Model Context Protocol (MCP)
- **Language**: TypeScript/Node.js
- **Protocol**: JSON-RPC over stdio/HTTP
- **Deployment**: Docker containers
- **Benefits**: Zero local installation, shared servers, native Amazon Q integration

### Migration Path
- v3.0 (Python scripts) remains functional during transition
- MCP servers developed in parallel
- Gradual migration with fallback support
- Full deprecation of Python scripts in v4.0 GA
