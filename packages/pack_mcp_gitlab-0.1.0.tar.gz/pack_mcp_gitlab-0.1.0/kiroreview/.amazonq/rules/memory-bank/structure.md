# Project Structure

## Directory Layout

```
kiroreview/
├── .amazonq/
│   └── rules/
│       └── memory-bank/          # Project documentation (auto-generated)
├── arquivos-gerados/
│   ├── code_reviews/         # 📄 Generated code review files (review_mr_*.md)
│   └── pareceres_tecnicos/   # 📝 Generated technical reports (parecer-jira-*.html)
├── templates/
│   ├── jira-parecer-prompt.md    # 📝 Jira report generation instructions
│   └── jira-parecer-template.md  # 🎭 HTML template for Jira reports
├── collect_mr_data.py            # 📥 Main data collection orchestrator
├── generate_review_md.py         # 📝 Markdown report formatter
├── jira_client.py                # 🎯 Jira API client
├── config.py                     # ⚙️ Environment configuration loader
├── run_review_chat.py            # 🚀 Optional chat runner
├── review_rules.md               # 📋 Analysis rules and guidelines
├── requirements.txt              # 📦 Python dependencies
├── .env                          # 🔐 Credentials (not versioned)
├── .env.example                  # 📄 Environment template
├── .gitignore                    # 🚫 Git exclusions
├── README.md                     # 📖 User documentation
└── VISION.md                     # 🔮 Future architecture (v4.0 MCP)
```

## Core Components

### 1. Data Collection Layer

**collect_mr_data.py** - Main orchestrator
- Accepts MR URL as command-line argument
- Coordinates GitLab, Jira, and local repository data collection
- Outputs structured JSON (`mr_data.json`) with complete context
- Invoked automatically by Amazon Q Chat

**jira_client.py** - Jira integration
- Extracts issue code from branch names (e.g., `feature/PKW-12345` → `PKW-12345`)
- Fetches issue details: summary, description, status, assignee
- Supports basic authentication
- Gracefully handles missing Jira configuration

**config.py** - Configuration management
- Loads environment variables from `.env` file
- Provides centralized access to credentials and paths
- Validates required configuration (GitLab URL/token)
- Supports optional Jira and local repository paths

### 2. Analysis Layer

**review_rules.md** - Analysis guidelines
- Defines formal code review rules (v3.1)
- OWASP Top 10 security checks
- Performance patterns (N+1 queries, memory leaks)
- Architecture principles (SRP, coupling, patterns)
- Stack-specific conventions (REST, naming, formatting)
- Diff-aware analysis instructions (focus on changes, not existing code)
- Severity classification (🔴 High, 🟡 Medium, 🟢 Low)
- Output format templates with emojis and code blocks
- Two-scenario workflow (GitLab and Jira)

### 3. Report Generation Layer

**generate_review_md.py** - Markdown formatter
- Transforms analysis results into visual Markdown reports
- Organizes findings by file and directory
- Adds severity emojis and status indicators
- Generates side-by-side code comparisons
- Creates summary metrics table
- Outputs `review_mr_{MR_IID}.md` files to `arquivos-gerados/code_reviews/`

### 4. Execution Layer

**run_review_chat.py** - Optional runner
- Provides standalone execution outside Amazon Q Chat
- Useful for testing and debugging
- Not required for normal workflow (Amazon Q handles execution)

## Architectural Patterns

### Data Flow Architecture
```
User Request (Amazon Q Chat)
    ↓
collect_mr_data.py (orchestrator)
    ↓
┌─────────────────────────────────┐
│ Parallel Data Collection        │
├─────────────────────────────────┤
│ GitLab API → MR, diff, files    │
│ Jira API → Issue context        │
│ Local Repos → Configs, deps     │
└─────────────────────────────────┘
    ↓
mr_data.json (structured context)
    ↓
Amazon Q Chat (analysis engine)
    ↓
generate_review_md.py (formatter)
    ↓
review_mr_XXX.md (final report)
```

### Component Relationships

**Orchestration Pattern**
- `collect_mr_data.py` acts as facade, coordinating specialized clients
- Each client (GitLab, Jira, local repos) is independent and optional
- Failures in optional components (Jira) don't block core functionality

**Configuration Pattern**
- Centralized configuration via `config.py`
- Environment-based secrets management (`.env`)
- Graceful degradation when optional configs missing

**Template Pattern**
- `review_rules.md` defines analysis templates
- `generate_review_md.py` applies templates to findings
- Consistent output format across all reviews

## Key Design Decisions

### 1. JSON Intermediate Format
- `mr_data.json` decouples data collection from analysis
- Enables caching and offline analysis
- Facilitates debugging and testing
- Allows manual inspection of collected context

### 2. Amazon Q Chat Integration
- Leverages persistent conversation context
- Enables iterative refinement of analysis
- Handles large contexts automatically
- Provides natural language interaction

### 3. Modular Client Architecture
- GitLab client: Required (core functionality)
- Jira client: Optional (enhances context)
- Local repos: Optional (adds configuration insights)
- Each client can be extended independently

### 4. Markdown Output Format
- Human-readable and version-controllable
- Supports rich formatting (code blocks, tables, emojis)
- Easy to share and archive
- Compatible with documentation systems

## Configuration Files

**.env** (not versioned)
- GitLab URL and access token (required)
- Jira URL, username, password (optional)
- Local repositories path (optional)

**.env.example** (versioned template)
- Documents required and optional variables
- Provides example values
- Guides initial setup

**requirements.txt**
- `requests==2.31.0` - HTTP client for API calls
- `python-gitlab==4.4.0` - GitLab API wrapper
- `python-dotenv==1.0.1` - Environment variable loader

## Extension Points

### Adding New Data Sources
1. Create new client module (e.g., `github_client.py`)
2. Implement data collection function
3. Integrate into `collect_mr_data.py` orchestrator
4. Update `mr_data.json` schema

### Adding New Analysis Rules
1. Update `review_rules.md` with new patterns
2. Define severity and detection criteria
3. Add output format template
4. Amazon Q automatically applies new rules

### Customizing Output Format
1. Modify templates in `review_rules.md`
2. Update `generate_review_md.py` formatting logic
3. Adjust emoji and severity mappings
