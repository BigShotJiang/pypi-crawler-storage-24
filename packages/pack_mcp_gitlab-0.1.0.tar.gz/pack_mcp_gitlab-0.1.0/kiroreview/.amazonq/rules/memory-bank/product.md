# Product Overview

## Purpose
KiroReview is an automated code review generator that combines GitLab, Jira, and Amazon Q to deliver contextualized technical analysis of merge requests. It eliminates manual review overhead by automatically collecting MR data, business context, and repository configurations to produce comprehensive, actionable code reviews.

## Value Proposition
- **Automated Context Collection**: Automatically gathers MR diffs, Jira issue details, and local repository configurations
- **Business-Aware Analysis**: Links code changes to business requirements via Jira integration
- **Intelligent Review**: Leverages Amazon Q Chat for OWASP, performance, and architecture analysis
- **Zero Manual Setup**: Single command execution from Amazon Q Chat interface
- **Iterative Refinement**: Natural conversation interface allows drilling into specific concerns

## Key Features

### 1. Multi-Source Data Collection
- **GitLab Integration**: Fetches MR metadata, file changes, diffs, and commit history
- **Jira Integration**: Extracts issue codes from branch names, retrieves business context
- **Local Repository Analysis**: Scans project configurations (pom.xml, package.json), dependencies, and related files

### 2. Comprehensive Code Analysis
- **Security**: OWASP Top 10 vulnerabilities, secrets detection, injection risks
- **Performance**: N+1 queries, inefficient loops, memory leaks, caching opportunities
- **Architecture**: Design patterns, coupling analysis, responsibility violations (SRP)
- **Technical Debt**: Code smells, duplication, complexity metrics

### 3. Contextual Intelligence
- **Branch Pattern Recognition**: Automatically extracts Jira issue codes from branch names (feature/PKW-12345)
- **Task Type Awareness**: Adjusts severity based on task type (Hotfix, Feature, Refactor)
- **Stack Detection**: Identifies programming language, framework, and architectural patterns
- **Diff-Aware Analysis**: Focuses on changes introduced, not existing code

### 4. Visual Markdown Reports
- **Structured Output**: Organized by severity (🔴 High, 🟡 Medium, 🟢 Low)
- **Code Comparisons**: Side-by-side before/after code blocks
- **Actionable Recommendations**: Specific fixes with implementation examples
- **Summary Metrics**: Files analyzed, problems found, severity distribution

## Target Users
- **Development Teams**: Streamline code review process with automated first-pass analysis
- **Tech Leads**: Ensure consistency and quality standards across merge requests
- **DevOps Engineers**: Integrate quality gates into CI/CD pipelines
- **Solo Developers**: Get expert-level feedback without manual peer review

## Use Cases

### Primary Use Case: MR Analysis
```
User: Analyze MR https://git.alterdata.com.br/pack/packup/ms-contabilidade/-/merge_requests/158
Amazon Q: [Executes collect_mr_data.py → Analyzes → Generates review_mr_158.md]
```

### Focused Analysis
```
User: Review MR #123 focusing on security
Amazon Q: [Prioritizes OWASP checks, injection risks, secrets detection]
```

### Iterative Deep Dive
```
User: Explain the SQL injection risk in more detail
Amazon Q: [Provides detailed explanation with attack vectors and mitigation strategies]
```

## Current Version: v3.0
- Python-based data collection scripts
- Amazon Q Chat integration for analysis
- GitLab + Jira + Local repository support
- Markdown report generation
- Persistent conversation context

## Future Vision: v4.0 (MCP Servers)
- Zero local installation (no Python dependencies)
- Native Amazon Q integration via Model Context Protocol
- Shared MCP servers for GitLab, Jira, and repository analysis
- Improved scalability and extensibility
