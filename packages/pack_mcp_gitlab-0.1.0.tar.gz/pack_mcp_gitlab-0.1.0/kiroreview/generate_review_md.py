"""
Gera arquivo Markdown de review a partir dos dados coletados e análise
"""

import json
import sys
from pathlib import Path
from datetime import datetime


def generate_review_md(data, analysis, output_file=None):
    """Gera arquivo MD de review"""
    
    mr = data['mr']
    files = data['files']
    jira = data.get('jira')
    project = data['project']
    
    # Determina emoji do status
    status_emoji = "✅" if mr['state'] == "merged" else "🔄" if mr['state'] == "opened" else "❌"
    
    # Monta conteúdo
    md_content = f"""# 🔍 Code Review - MR #{mr['iid']}

> **{mr['title']}**

## 📋 Informações Gerais

| Campo | Valor |
|-------|-------|
| **Autor** | {mr['author']['name']} |
| **Branch** | `{mr['source_branch']}` → `{mr['target_branch']}` |
| **Status** | {status_emoji} {mr['state']} |
| **Repositório** | {project['name']} |
| **URL** | {mr['web_url']} |
"""
    
    # Contexto Jira
    if jira:
        type_emoji = "📖" if jira['issue_type'] == "Story" else "🐛" if "Bug" in jira['issue_type'] else "🛠️"
        priority_emoji = "🔴" if "High" in jira['priority'] else "🟡" if "Medium" in jira['priority'] else "🟢"
        
        md_content += f"""
## 🎯 Contexto Jira

**[{jira['key']}]({jira['url']})** - {jira['summary']}

| | |
|---|---|
| **Tipo** | {type_emoji} {jira['issue_type']} |
| **Status** | ✅ {jira['status']} |
| **Prioridade** | {priority_emoji} {jira['priority']} |

**Descrição**: {jira['description'][:500] if jira['description'] else 'N/A'}
"""
    
    # Arquivos modificados
    md_content += """
## 📁 Arquivos Modificados

```
"""
    
    files_by_dir = {}
    for file_info in files:
        file_path = file_info['path']
        dir_path = str(Path(file_path).parent)
        if dir_path not in files_by_dir:
            files_by_dir[dir_path] = []
        files_by_dir[dir_path].append(Path(file_path).name)
    
    for dir_path, file_names in files_by_dir.items():
        if dir_path == '.':
            for file in file_names:
                md_content += f"📄 {file}\n"
        else:
            md_content += f"📂 {dir_path}/\n"
            for i, file in enumerate(file_names):
                prefix = "└──" if i == len(file_names) - 1 else "├──"
                icon = "🔧" if file.endswith(('.java', '.py', '.js', '.ts')) else "📄"
                md_content += f"{prefix} {icon} {file}\n"
    
    md_content += "```\n"
    
    # Análise
    md_content += f"""
## 🤖 Análise Amazon Q

{analysis}

---
*Análise gerada automaticamente via Amazon Q Chat em {datetime.now().strftime('%d/%m/%Y %H:%M')}*
"""
    
    # Salva arquivo
    if not output_file:
        output_file = f"review_mr_{mr['iid']}.md"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(md_content)
    
    return output_file


def main():
    if len(sys.argv) < 3:
        print("Uso: python generate_review_md.py <mr_data.json> <analysis.txt>")
        sys.exit(1)
    
    data_file = sys.argv[1]
    analysis_file = sys.argv[2]
    
    with open(data_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    with open(analysis_file, 'r', encoding='utf-8') as f:
        analysis = f.read()
    
    output = generate_review_md(data, analysis)
    print(f"✅ Review gerado: {output}")


if __name__ == "__main__":
    main()
