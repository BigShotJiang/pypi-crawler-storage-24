"""
Code Review automatizado via pipeline do GitLab.
Coleta dados do MR, envia para LLM e posta resultado como comentário.
"""

import os
import sys
import json
import gitlab
import requests
from collect_mr_data import MRDataCollector


def get_review_prompt(data):
    """Monta o prompt para a LLM analisar o MR."""
    mr = data['mr']
    files = data['files']
    jira = data.get('jira')

    prompt = f"""Você é um revisor de código sênior. Analise o seguinte Merge Request.

## MR #{mr['iid']}: {mr['title']}
- Autor: {mr['author']['name']}
- Branch: {mr['source_branch']} → {mr['target_branch']}
"""

    if jira:
        prompt += f"""
## Contexto Jira
- Ticket: {jira['key']} - {jira['summary']}
- Tipo: {jira['issue_type']} | Status: {jira['status']} | Prioridade: {jira['priority']}
- Descrição: {jira.get('description', 'N/A')[:500]}
"""

    prompt += "\n## Arquivos Modificados\n"
    for f in files:
        prompt += f"\n### {f['path']}\n```diff\n{f['diff'][:3000]}\n```\n"

    prompt += """
## Instruções
Analise o código considerando:
1. Bugs e problemas de lógica
2. Segurança (OWASP Top 10)
3. Performance e uso de recursos
4. Boas práticas e clean code
5. Nomenclatura de branches (task/descricao → feature/CODIGO)

Para cada problema encontrado, use o formato:
### ⚠️ Problema: [Título]
- 📁 Arquivo: `arquivo` | 📍 Linha: X | Severidade: 🔴/🟡/🟢
- 🔍 O que está errado: [explicação]
- ✅ Sugestão: [código corrigido]

Se não encontrar problemas relevantes, elogie os pontos positivos.
Responda em português.
"""
    return prompt


def call_bedrock(prompt):
    """Chama Amazon Bedrock (Claude) para análise."""
    import boto3

    client = boto3.client(
        'bedrock-runtime',
        region_name=os.getenv('AWS_REGION', 'us-east-1')
    )

    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-01",
        "max_tokens": 4096,
        "messages": [{"role": "user", "content": prompt}]
    })

    response = client.invoke_model(
        modelId=os.getenv('BEDROCK_MODEL_ID', 'anthropic.claude-3-sonnet-20240229-v1:0'),
        body=body,
        contentType='application/json'
    )

    result = json.loads(response['body'].read())
    return result['content'][0]['text']


def call_openai(prompt):
    """Chama OpenAI API para análise."""
    api_key = os.getenv('OPENAI_API_KEY')
    response = requests.post(
        'https://api.openai.com/v1/chat/completions',
        headers={'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'},
        json={
            'model': os.getenv('OPENAI_MODEL', 'gpt-4o'),
            'messages': [{'role': 'user', 'content': prompt}],
            'max_tokens': 4096
        },
        timeout=120
    )
    response.raise_for_status()
    return response.json()['choices'][0]['message']['content']


def post_comment_to_mr(gitlab_url, token, project_path, mr_iid, review_text):
    """Posta o review como comentário no MR."""
    gl = gitlab.Gitlab(gitlab_url, private_token=token)
    project = gl.projects.get(project_path)
    mr = project.mergerequests.get(mr_iid)
    mr.notes.create({'body': f"## 🤖 Code Review Automatizado\n\n{review_text}"})
    print(f"✅ Review postado como comentário no MR !{mr_iid}")


def main():
    # Variáveis injetadas pelo GitLab CI
    gitlab_url = os.getenv('CI_SERVER_URL', os.getenv('GITLAB_URL'))
    token = os.getenv('GITLAB_TOKEN')
    project_path = os.getenv('CI_PROJECT_PATH')
    mr_iid = os.getenv('CI_MERGE_REQUEST_IID')

    if not all([gitlab_url, token, project_path, mr_iid]):
        print("❌ Variáveis de ambiente obrigatórias não definidas.")
        print("   Necessário: CI_SERVER_URL/GITLAB_URL, GITLAB_TOKEN, CI_PROJECT_PATH, CI_MERGE_REQUEST_IID")
        sys.exit(1)

    mr_url = f"{gitlab_url}/{project_path}/-/merge_requests/{mr_iid}"
    print(f"🔄 Analisando MR: {mr_url}")

    # Coleta dados
    jira_url = os.getenv('JIRA_URL')
    jira_user = os.getenv('JIRA_USERNAME')
    jira_pass = os.getenv('JIRA_PASSWORD')

    collector = MRDataCollector(
        gitlab_url, token, mr_url,
        jira_url=jira_url, jira_username=jira_user, jira_password=jira_pass
    )
    data = collector.collect()
    print(f"📋 MR #{data['mr']['iid']}: {data['mr']['title']} ({len(data['files'])} arquivos)")

    # Gera prompt e chama LLM
    prompt = get_review_prompt(data)

    llm_provider = os.getenv('LLM_PROVIDER', 'bedrock').lower()
    print(f"🤖 Enviando para análise via {llm_provider}...")

    if llm_provider == 'openai':
        review = call_openai(prompt)
    else:
        review = call_bedrock(prompt)

    # Posta como comentário no MR
    post_comment_to_mr(gitlab_url, token, project_path, int(mr_iid), review)

    # Também salva localmente (útil como artefato do pipeline)
    output_file = f"review_mr_{mr_iid}.md"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(f"# 🔍 Code Review - MR #{mr_iid}\n\n{review}")
    print(f"📄 Review salvo em: {output_file}")


if __name__ == "__main__":
    main()
