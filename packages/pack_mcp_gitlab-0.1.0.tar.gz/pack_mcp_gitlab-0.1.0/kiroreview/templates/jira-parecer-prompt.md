# 📋 PROMPT BASE PARA GERAÇÃO DE PARECER TÉCNICO

## Variaveis de Texto
Considere as seguintes variaveis de texto, quero que substitua no texto uma por uma

[TICKET] = "Será algo como 'PKW-57733', deve ter esse numero da tarefa no jira ou no titulo das branchs do GitLab"
[BRANCH_DESTINO] = "develop"
[LISTA_CAMINHOS_PROJETOS] = "Caminho dos arquivos alterados, consultar no GitLab no link da analise"
[TEXTO_COMPLETO_DA_TAREFA] = "Estará na tarefa principal do Jira em estimativas, lá o QA vai fornecer um texto bem informativo do que fazer.​"

## 🎯 Template de Prompt

```
Contexto:
Trabalhei em múltiplos projetos que compartilharam a mesma estrutura de desenvolvimento.
Cada projeto teve sua própria branch chamada feature/[TICKET] e todas essas branches já foram mergeadas para a branch "[BRANCH_DESTINO]".

Estes projetos estão localizados nos seguintes caminhos:
[LISTA_CAMINHOS_PROJETOS]

Objetivo:
Quero que você analise as alterações realizadas nas branches feature/[TICKET] de cada projeto (agora refletidas na "[BRANCH_DESTINO]") e gere um parecer técnico sobre a tarefa.

Referência:
Aqui está o texto base da tarefa que motivou essas alterações:

[TEXTO_COMPLETO_DA_TAREFA]
			
Instruções:
1. Para cada projeto listado, identifique as mudanças introduzidas pela branch feature/[TICKET] em relação ao estado anterior à mesclagem na "[BRANCH_DESTINO]".
2. Avalie se as implementações atendem ao objetivo descrito no texto base.
3. Gere um parecer técnico consolidado, contendo:
   - Estrutura Técnica – visão geral da arquitetura, integrações e tecnologias envolvidas.
   - Documentar a solução utilizada para tarefa, assim como ajustes como evoluções de schema e novos end-points.
   - Liste o que foi alterado em cada projeto
   - Use uma linguagem simples, direta e equilibrada entre técnica e funcional
   - Quando aplicável adicione detalhes sobre banco de dados relacionado a criação de tabelas ou novas colunas. Deve ser adicoonado detalhes do nome da tabela/coluna e qual é o objetivo dela. 
   - Quando aplicável adicione detalhes sobre endpoints
   - Quando aplicável adicione detalhes sobre a arquitetura do frontend
   - Quando aplicável adicione serviços de suporte (exemplo: AWS S3, AWS SQS, etc)
   - Liste pontos de atenção que o QA deve ter ao realizar os testes. Não inclua pontos de atenção/testes que já estão inclusos no escopo da tarefa. Aqui devem ser listado pontos que vão além do que foi contemplado, mas que durante a análise foi identificado que são pontos de impacto ou pontos cruciais na rotina. 
   - Adicione, quando aplicável, as rotas, views, componentes e serviços criados/alterados.
   - Não adicione o código em si implementado, mas sim uma descrição do que a implementação faz.
   - Sempre adicione o identificado #parecerDEV no parecer (pois será utilizado para reastreabilidade)
4. Salve o parecer gerado na pasta: arquivos-gerados/pareceres_tecnicos/
   Nome do arquivo: parecer-jira-[TICKET].html 
```

## 📝 Estrutura do Texto da Tarefa

O texto da tarefa deve conter:

### 1. Visão Geral
- Objetivo principal da implementação
- Contexto do produto/funcionalidade
- Integração com sistemas existentes

## 🎯 Resultado Esperado

O parecer técnico gerado deve seguir o template HTML definido no arquivo jira-parecer-template.md na pasta templates deste projeto. O caminho relativo é: `templates\jira-parecer-template.md`. O parecer técnico gerado deve conter:

### Seções Obrigatórias:
1. **Título Principal** com ticket e funcionalidade
2. **Projetos Modificados** (Frontend/Backend separados)
3. **Estrutura de Banco** (se aplicável)
4. **APIs e Endpoints** (se aplicável)
5. **Pontos de Atenção QA** (Frontend/Backend separados)
6. **Observações Importantes**

### Características do Parecer:
- ✅ Linguagem técnica mas acessível
- ✅ Foco em implementações concretas
- ✅ Pontos específicos ou de impacto para QA