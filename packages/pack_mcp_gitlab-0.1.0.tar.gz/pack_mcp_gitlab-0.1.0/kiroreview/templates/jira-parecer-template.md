# 📋 TEMPLATE PARA PARECER TÉCNICO

## 🎯 Estrutura Base

O parecer deve ser criado como conteúdo HTML direto, sem estrutura DOCTYPE/html/body. Use apenas os elementos de conteúdo com estilos inline.

## 📝 Seções Obrigatórias

### 1. TÍTULO PRINCIPAL
```html
<h1 style="color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; margin-bottom: 30px;">
    <span style="font-size: 1.2em;">📋</span> PARECER TÉCNICO [FRONTEND/BACKEND] - [FUNCIONALIDADE] ([TICKET])
</h1>
```

### 2. PROJETOS MODIFICADOS
```html
<h2 style="color: #34495e; margin-top: 30px; margin-bottom: 15px; border-left: 4px solid #3498db; padding-left: 15px;">
    <span style="font-size: 1.2em;">📁</span> Projetos [Frontend/Backend] Modificados
</h2>

<div style="background: #f8f9fa; padding: 15px; margin: 15px 0; border-left: 4px solid #27ae60; border-radius: 0 5px 5px 0;">
    <h3 style="color: #2c3e50; margin-top: 25px; margin-bottom: 10px;">1. [NOME_PROJETO] ([TECNOLOGIA])</h3>
    <div style="background: #f8f9fa; padding: 10px; border-radius: 3px; font-family: monospace; font-size: 0.9em;">
        <strong>Arquivos Modificados:</strong><br>
        - [caminho/arquivo1]<br>
        - [caminho/arquivo2]
    </div>
    <p><strong>Implementações:</strong></p>
    <ul style="padding-left: 20px;">
        <li style="color: #333; margin-bottom: 5px;">✅ [Descrição da implementação]</li>
    </ul>
</div>
```

### 3. ESTRUTURA DE BANCO (Backend)
```html
<h2 style="color: #34495e; margin-top: 30px; margin-bottom: 15px; border-left: 4px solid #3498db; padding-left: 15px;">
    <span style="font-size: 1.2em;">🗄️</span> Estrutura de Banco de Dados
</h2>
<div style="background: #ecf0f1; padding: 20px; border-radius: 5px; margin: 20px 0;">
    <h3 style="color: #2c3e50; margin-top: 25px; margin-bottom: 10px;">Alterações no Schema:</h3>
    <div style="background: #2d3748; color: #e2e8f0; padding: 15px; border-radius: 5px; overflow-x: auto; margin: 10px 0;">
        [Descrição das colunas e tabelas utilizadas ou criadas durante a implementação]
    </div>
</div>
```

### 4. ENDPOINTS (Backend)
```html
<h2 style="color: #34495e; margin-top: 30px; margin-bottom: 15px; border-left: 4px solid #3498db; padding-left: 15px;">
    <span style="font-size: 1.2em;">🔗</span> APIs e Endpoints
</h2>
<div style="background: #ecf0f1; padding: 20px; border-radius: 5px; margin: 20px 0;">
    <h3 style="color: #2c3e50; margin-top: 25px; margin-bottom: 10px;">Endpoints Protegidos:</h3>
    <ul style="padding-left: 20px;">
        <li style="margin-bottom: 8px;"><strong>[MÉTODO]</strong> <code style="background: #f1f2f6; padding: 2px 6px; border-radius: 3px; font-family: 'Courier New', monospace;">[ENDPOINT]</code> - [Descrição]</li>
    </ul>
</div>
```

### 5. ARQUITETURA DE SEGURANÇA (Frontend)
```html
<h2 style="color: #34495e; margin-top: 30px; margin-bottom: 15px; border-left: 4px solid #3498db; padding-left: 15px;">
    <span style="font-size: 1.2em;">🛡️</span> Arquitetura de Segurança Frontend
</h2>
<div style="background: #ecf0f1; padding: 20px; border-radius: 5px; margin: 20px 0;">
    <h3 style="color: #2c3e50; margin-top: 25px; margin-bottom: 10px;">Proteção de Rotas:</h3>
    <div style="background: #2d3748; color: #e2e8f0; padding: 15px; border-radius: 5px; overflow-x: auto; margin: 10px 0;">
        [CÓDIGO_PROTEÇÃO]
    </div>
</div>
```

### 6. PONTOS DE ATENÇÃO QA
```html
<h2 style="color: #34495e; margin-top: 30px; margin-bottom: 15px; border-left: 4px solid #3498db; padding-left: 15px;">
    <span style="font-size: 1.2em;">⚠️</span> Pontos de Atenção QA - [Frontend/Backend]
</h2>
<div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 20px; border-radius: 5px; margin: 20px 0;">
    <ul style="padding-left: 20px;">
        <li style="color: #333; margin-bottom: 5px;"> [Ponto de teste específico]</li>
    </ul>
</div>
```

### 7. OBSERVAÇÕES IMPORTANTES (Quando aplicável)
```html
<h2 style="color: #34495e; margin-top: 30px; margin-bottom: 15px; border-left: 4px solid #3498db; padding-left: 15px;">
    <span style="font-size: 1.2em;">📝</span> Observações Importantes
</h2>
<div style="background: #e8f4fd; border: 1px solid #bee5eb; padding: 20px; border-radius: 5px; margin: 20px 0;">
    <p>[Observações específicas do projeto]</p>
    <div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 15px 0;">
        <p><strong>⚠️ Ponto de Atenção:</strong></p>
        <p>[Ponto crítico que deve ser observado]</p>
    </div>
</div>
```

## 🎨 Estilos CSS Inline Padrão

### Cores
- **Azul Principal**: `#3498db`
- **Azul Escuro**: `#2c3e50`
- **Cinza Médio**: `#34495e`
- **Verde Sucesso**: `#27ae60`
- **Amarelo Atenção**: `#fff3cd` / `#ffeaa7`
- **Azul Info**: `#e8f4fd` / `#bee5eb`
- **Cinza Fundo**: `#f8f9fa`
- **Cinza Code**: `#f1f2f6`

### Elementos Code
```html
<code style="background: #f1f2f6; padding: 2px 6px; border-radius: 3px; font-family: 'Courier New', monospace;">[CÓDIGO]</code>
```

### Blocos de Código
```html
<div style="background: #2d3748; color: #e2e8f0; padding: 15px; border-radius: 5px; overflow-x: auto; margin: 10px 0;">
[CÓDIGO]
</div>
```

## 📋 Checklist de Informações Obrigatórias

### Para TODOS os pareceres:
- [ ] Título com ticket e nome da funcionalidade
- [ ] Lista de projetos modificados com tecnologias
- [ ] Arquivos específicos alterados
- [ ] Implementações detalhadas com checkmarks
- [ ] Pontos de atenção para QA

### Para pareceres BACKEND:
- [ ] Estrutura de banco de dados (tabelas/colunas + descrição)
- [ ] Endpoints implementados (Método + URL + descrição + parâmetros que suporta)
- [ ] Validações de segurança implementadas
- [ ] Integração com sistemas externos (UpdateCenter, etc.)
- [ ] Códigos de licença e produtos Bimer
- [ ] Testes unitários mencionados

### Para pareceres FRONTEND:
- [ ] Proteção de rotas implementada
- [ ] Validações de permissão e perfil
- [ ] Configurações de ambiente (envs)
- [ ] Web Components e integrações
- [ ] Responsividade e acessibilidade
- [ ] Testes unitários mencionados

## 🚀 Dicas de Uso

1. **Substitua todos os placeholders** entre colchetes `[PLACEHOLDER]`
2. **Mantenha estilos inline** para portabilidade
3. **Use emojis consistentes** para cada seção
4. **Agrupe alterações** por projeto/tecnologia
5. **Seja específico** nos pontos de atenção QA. Incluindo apenas pontos importantes e de destaque. Não mencione testes que já estão inclusos no parecer da tarefa, mas sim pontos de impacto ou testes específicos que precisem ser feitos devido a implementação realizada.
6. **Inclua códigos relevantes** em blocos destacados
7. **Mantenha linguagem técnica** mas acessível