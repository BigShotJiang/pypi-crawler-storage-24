import os
from pathlib import Path

# Carrega variáveis do .env se existir
env_file = Path('.env')
if env_file.exists():
    with open(env_file) as f:
        for line in f:
            if '=' in line and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                # Remove aspas se existirem
                if value.startswith('"') and value.endswith('"'):
                    value = value[1:-1]
                elif value.startswith("'") and value.endswith("'"):
                    value = value[1:-1]
                os.environ[key] = value

# Configurações do GitLab
GITLAB_URL = os.getenv('GITLAB_URL', 'https://git.alterdata.com.br')
GITLAB_TOKEN = os.getenv('GITLAB_TOKEN', '')
REPOS_PATH = os.getenv('REPOS_PATH', '')

# Configurações do Jira (opcional)
JIRA_URL = os.getenv('JIRA_URL')
JIRA_USERNAME = os.getenv('JIRA_USERNAME')
JIRA_PASSWORD = os.getenv('JIRA_PASSWORD')

# Validação
if not GITLAB_TOKEN:
    raise ValueError("GITLAB_TOKEN é obrigatório")