# Changelog

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/),
e este projeto adere ao [Semantic Versioning](https://semver.org/lang/pt-BR/).

---

## [3.1.0] - 2026-01-29

### ✨ Adicionado
- **Fluxo interativo de 2 cenários**: Suporte completo para análise via link do GitLab ou link do Jira
- **Geração de pareceres técnicos**: Sistema automatizado de geração de pareceres HTML para o Jira
- **Templates HTML**: Templates profissionais para pareceres técnicos com estilos inline
- **Estrutura de pastas organizada**: 
  - `arquivos-gerados/code_reviews/` para reviews de MR
  - `arquivos-gerados/pareceres_tecnicos/` para pareceres Jira
  - `templates/` para templates reutilizáveis
- **Documentação expandida**: README completo com guia de uso dos 2 cenários
- **FAQ**: Seção de perguntas frequentes no README
- **Arquivos .gitkeep**: Mantém estrutura de pastas no Git
- **README em arquivos-gerados/**: Documenta propósito das pastas

### 🔄 Modificado
- **Fluxo de trabalho**: Agora pergunta explicitamente se deseja gerar parecer técnico
- **README**: Reorganizado com seções claras para cada cenário de uso
- **review_rules.md**: Atualizado com instruções dos 2 cenários
- **.gitignore**: Otimizado para ignorar conteúdo mas manter estrutura

### 🐛 Corrigido
- Inconsistências na documentação sobre localização de arquivos gerados
- Falta de clareza sobre quando usar cada cenário (GitLab vs Jira)

---

## [3.0.0] - 2026-01-XX

### ✨ Inicial
- Integração GitLab + Jira + Repos locais
- Análise via Amazon Q Chat
- Reviews em Markdown visual
- Coleta automatizada de contexto
- Scripts Python para coleta de dados
- Regras de análise (OWASP, performance, arquitetura)

---

## [Unreleased] - v4.0.0

### 🚧 Planejado
- **MCP Servers**: Eliminar scripts Python locais
- **Zero Config**: Sem instalação de dependências
- **Nativo**: Integração direta com Amazon Q
- **CI/CD**: Executar no pipeline com aprovação automática de mudanças de baixo risco

---

## Tipos de Mudanças

- `✨ Adicionado` - para novas funcionalidades
- `🔄 Modificado` - para mudanças em funcionalidades existentes
- `🗑️ Removido` - para funcionalidades removidas
- `🐛 Corrigido` - para correção de bugs
- `🔒 Segurança` - para correções de vulnerabilidades
- `📝 Documentação` - para mudanças apenas em documentação
- `🚧 Planejado` - para funcionalidades futuras

---

## Links de Comparação

- [3.1.0] - Versão atual com fluxo interativo e pareceres técnicos
- [3.0.0] - Versão inicial com Python scripts
