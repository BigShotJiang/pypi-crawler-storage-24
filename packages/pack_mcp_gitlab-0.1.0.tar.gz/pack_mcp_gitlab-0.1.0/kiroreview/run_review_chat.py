"""
Script simplificado para executar via Amazon Q Chat
Apenas coleta dados e exibe para análise manual no chat
"""

import sys
import subprocess
import json


def main():
    if len(sys.argv) < 2:
        print("❌ Uso: python run_review_chat.py <URL_DO_MR>")
        sys.exit(1)
    
    mr_url = sys.argv[1]
    
    print(f"🔄 Coletando dados do MR: {mr_url}")
    print("=" * 60)
    
    try:
        # Executa coleta de dados
        result = subprocess.run(
            ['python', 'collect_mr_data.py', mr_url],
            capture_output=True,
            text=True,
            encoding='utf-8'
        )
        
        if result.returncode != 0:
            print(f"❌ Erro ao coletar dados:\n{result.stderr}")
            sys.exit(1)
        
        # Parse JSON
        data = json.loads(result.stdout)
        
        if 'error' in data:
            print(f"❌ Erro: {data['error']}")
            sys.exit(1)
        
        # Exibe resumo
        print("\n✅ Dados coletados com sucesso!\n")
        print(f"📋 MR #{data['mr']['iid']}: {data['mr']['title']}")
        print(f"👤 Autor: {data['mr']['author']['name']}")
        print(f"🌿 Branch: {data['mr']['source_branch']} → {data['mr']['target_branch']}")
        print(f"📁 Arquivos modificados: {len(data['files'])}")
        
        if data['jira']:
            print(f"🎯 Jira: {data['jira']['key']} - {data['jira']['summary']}")
        
        if data['project']['local_path']:
            print(f"💾 Repo local: {data['project']['local_path']}")
        
        print("\n" + "=" * 60)
        print("📊 JSON completo salvo em: mr_data.json")
        print("=" * 60)
        
        # Salva JSON para análise
        with open('mr_data.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        print("\n💡 Próximo passo:")
        print("   Cole no chat do Amazon Q:")
        print("   'Analise o MR usando os dados em mr_data.json'")
        
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
