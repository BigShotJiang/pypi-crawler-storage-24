# Visão de Evolução: KiroReview v4.0

## Da Arquitetura Python para MCP Servers

### Estado Atual (v3.1)

O KiroReview v3.1 usa **scripts Python locais** executados pelo Amazon Q Chat:
- ✅ Funcional e eficiente
- ✅ Contexto rico (GitLab + Jira + Repos)
- ✅ Fluxo interativo de 2 cenários
- ✅ Geração de pareceres técnicos para Jira
- ⚠️ Requer instalação Python + dependências
- ⚠️ Scripts locais por usuário

### Próxima Geração (v4.0)

Migração para **MCP (Model Context Protocol) Servers**:
- ✅ Zero instalação local
- ✅ Integração nativa com Amazon Q
- ✅ Servers compartilhados
- ✅ Extensível via protocolo padrão

## Comparação de Arquiteturas

### v3.1 (Atual) - Scripts Python

```
Amazon Q Chat
    ↓
python collect_mr_data.py
    ↓
┌────────────────────────┐
│ Scripts Locais         │
├────────────────────────┤
│ GitLab API             │
│ Jira API               │
│ Repos Locais           │
└────────────────────────┘
    ↓
JSON → Amazon Q → Markdown + HTML
    ↓
arquivos-gerados/
├── code_reviews/
└── pareceres_tecnicos/
```

### v4.0 (Futuro) - MCP Servers

```
Amazon Q Chat
    ↓ (protocolo MCP nativo)
┌────────────────────────┐
│ MCP Servers            │
├────────────────────────┤
│ 🦊 GitLab MCP         │ ← get_mr(), get_diff()
│ 🎯 Jira MCP           │ ← get_issue(), search()
│ 💾 Repo MCP           │ ← analyze_config()
└────────────────────────┘
    ↓
Amazon Q (análise + geração)
    ↓
Markdown direto
```

## Benefícios da Migração MCP

| Aspecto | v3.1 (Python) | v4.0 (MCP) |
|---------|---------------|------------|
| **Setup** | pip install + .env | Zero config |
| **Dependências** | Python 3.7+ | Nenhuma |
| **Execução** | Scripts locais | Servers remotos |
| **Compartilhamento** | Por usuário | Centralizado |
| **Manutenção** | Atualizar scripts | Atualizar servers |
| **Extensão** | Modificar código | Adicionar servers |
| **Performance** | Rápido | Rápido + cache |
| **Integração** | subprocess | Protocolo nativo |
| **Pareceres Jira** | Geração local | Geração server-side |

### Vantagens Chave

**🚀 Zero Friction**
- Usuário não instala nada
- Amazon Q conecta diretamente aos servers
- Funciona imediatamente

**🔧 Extensível**
- Adicionar GitHub MCP → suporte GitHub
- Adicionar Confluence MCP → contexto de docs
- Protocolo padrão, sem modificar core

**📊 Escalável**
- Servers compartilhados entre times
- Cache de dados frequentes
- Deploy em cloud/containers

## Roadmap de Migração

### Fase 1: MCP GitLab Server 🚧
```typescript
// Ferramentas disponíveis:
- get_merge_request(url)     // Busca dados do MR
- get_mr_diff(project, mr_id) // Busca alterações
- get_file_content(project, path, ref) // Lê arquivo
- list_project_files(project) // Lista arquivos
```

### Fase 2: MCP Jira Server 🚧
```typescript
// Ferramentas disponíveis:
- get_issue(key)              // Busca issue completa
- extract_issue_from_branch(branch) // Extrai key da branch
- search_issues(jql)          // Busca avançada
- get_issue_comments(key)     // Busca comentários
```

### Fase 3: MCP Repository Server 🚧
```typescript
// Ferramentas disponíveis:
- analyze_project_config(path) // Analisa pom.xml, package.json
- get_dependencies(path)       // Lista dependências
- find_related_files(path)     // Busca arquivos relacionados
```



## Experiência do Usuário

### v3.1 (Atual)
```
Você: Analise o MR: https://git.alterdata.com.br/.../merge_requests/158

Amazon Q:
🔄 Executando collect_mr_data.py...
✅ Dados coletados
🧠 Analisando código...

### ⚠️ Problema 1: SQL Injection
...

✅ Review salvo: arquivos-gerados/code_reviews/review_mr_158.md

Deseja que eu gere um parecer técnico para o Jira?
```

### v4.0 (Futuro)
```
Você: Analise o MR: https://git.alterdata.com.br/.../merge_requests/158

Amazon Q:
🔄 Conectando MCP servers...
✅ GitLab: MR #158 encontrado
✅ Jira: PKW-37711 encontrada
🧠 Analisando...

### ⚠️ Problema 1: SQL Injection
...

✅ Review completo
✅ Parecer técnico gerado automaticamente
```

**Diferença**: Usuário não precisa ter Python instalado!

## Detalhes Técnicos MCP

### Stack Tecnológico

- **Linguagem**: TypeScript/Node.js
- **Protocolo**: [Model Context Protocol](https://modelcontextprotocol.io/)
- **Transporte**: JSON-RPC sobre stdio/HTTP
- **Deployment**: Docker containers
- **Autenticação**: OAuth2 / API tokens

### Exemplo de MCP Server

```typescript
// gitlab-mcp-server/src/index.ts
import { MCPServer } from '@modelcontextprotocol/sdk';

const server = new MCPServer({
  name: 'gitlab-mcp',
  version: '1.0.0'
});

server.tool('get_merge_request', async (params) => {
  const { url } = params;
  // Busca MR do GitLab
  return {
    mr: { /* dados */ },
    files: [ /* arquivos */ ],
    diff: '...'
  };
});

server.listen();
```

## Plano de Migração

### Timeline

**Q1 2026** - v3.1 (Atual) ✅
- Arquitetura Python consolidada
- Coleta automatizada de contexto
- Integração Amazon Q Chat
- Fluxo interativo de 2 cenários (GitLab e Jira)
- Geração de pareceres técnicos HTML

**Q2-Q3 2026** - Prototipação MCP 🚧
- Desenvolver GitLab MCP Server
- Testar protocolo MCP com Amazon Q
- Validar performance e usabilidade

**Q4 2026** - v4.0 Beta 🚧
- Lançar MCP servers em produção
- Manter v3.1 como fallback
- Coletar feedback de early adopters

**2027** - v4.0 GA 🎯
- MCP como arquitetura padrão
- Deprecar scripts Python
- Documentar migração completa

### Próximos Passos

1. ✅ Consolidar v3.1 (concluído)
2. 🔄 Estudar especificação MCP
3. 🚧 Prototipar GitLab MCP Server
4. 🚧 Testar integração com Amazon Q
5. 🚧 Migrar gradualmente

---

**Nota**: A v3.1 continuará funcional e mantida durante toda a transição.
