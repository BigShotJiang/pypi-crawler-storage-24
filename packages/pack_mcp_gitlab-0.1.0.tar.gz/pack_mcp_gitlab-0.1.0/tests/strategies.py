"""Hypothesis strategies for pack-mcp-gitlab property-based tests.

Provides data generators for all domain models (MR, changes, notes, projects),
GitLab exceptions, whitespace strings, and tokens. Supports properties P1-P10.
"""

import string

import hypothesis.strategies as st
from gitlab.exceptions import (
    GitlabAuthenticationError,
    GitlabGetError,
    GitlabHttpError,
)


# ---------------------------------------------------------------------------
# Primitive helpers
# ---------------------------------------------------------------------------

def iso8601_timestamps() -> st.SearchStrategy[str]:
    """Generates ISO 8601 timestamp strings."""
    return st.from_regex(
        r"20[0-9]{2}-[01][0-9]-[0-3][0-9]T[0-2][0-9]:[0-5][0-9]:[0-5][0-9]Z",
        fullmatch=True,
    )


def usernames() -> st.SearchStrategy[str]:
    """Generates GitLab-style usernames (lowercase alphanumeric + dots/hyphens)."""
    return st.from_regex(r"[a-z][a-z0-9.\-]{1,30}", fullmatch=True)


def branch_names() -> st.SearchStrategy[str]:
    """Generates plausible branch names."""
    return st.from_regex(r"[a-z][a-z0-9\-/]{1,40}", fullmatch=True)


def web_urls() -> st.SearchStrategy[str]:
    """Generates plausible web URLs."""
    return st.builds(
        lambda host, path: f"https://{host}/{path}",
        host=st.from_regex(r"gitlab\.[a-z]{2,8}\.[a-z]{2,4}", fullmatch=True),
        path=st.from_regex(r"[a-z][a-z0-9/\-]{2,40}", fullmatch=True),
    )


def project_paths() -> st.SearchStrategy[str]:
    """Generates GitLab project paths like 'group/project'."""
    return st.from_regex(r"[a-z][a-z0-9\-]{1,15}/[a-z][a-z0-9\-]{1,20}", fullmatch=True)



def file_paths() -> st.SearchStrategy[str]:
    """Generates plausible file paths."""
    return st.from_regex(r"[a-z][a-z0-9_/]{1,30}\.[a-z]{1,5}", fullmatch=True)


def mr_states() -> st.SearchStrategy[str]:
    """Generates valid MR state values."""
    return st.sampled_from(["opened", "closed", "merged", "all"])


def visibility_values() -> st.SearchStrategy[str]:
    """Generates valid GitLab project visibility values."""
    return st.sampled_from(["private", "internal", "public"])


# ---------------------------------------------------------------------------
# Whitespace / empty strings  (P1, P8)
# ---------------------------------------------------------------------------

def whitespace_strings() -> st.SearchStrategy[str]:
    """Generates empty or whitespace-only strings."""
    return st.one_of(
        st.just(""),
        st.text(alphabet=" \t\n\r", min_size=1, max_size=20),
    )


# ---------------------------------------------------------------------------
# Tokens  (P9)
# ---------------------------------------------------------------------------

def gitlab_tokens() -> st.SearchStrategy[str]:
    """Generates random GitLab-style personal access tokens."""
    return st.builds(
        lambda suffix: f"glpat-{suffix}",
        suffix=st.text(
            alphabet=string.ascii_letters + string.digits + "_-",
            min_size=20,
            max_size=40,
        ),
    )


# ---------------------------------------------------------------------------
# GitLab exceptions  (P6)
# ---------------------------------------------------------------------------

_error_messages = st.text(
    alphabet=string.ascii_letters + string.digits + " .:/-_",
    min_size=1,
    max_size=80,
)


def gitlab_auth_errors() -> st.SearchStrategy[GitlabAuthenticationError]:
    """Generates GitlabAuthenticationError with random messages."""
    return st.builds(GitlabAuthenticationError, _error_messages)


def gitlab_get_errors(response_code: int | None = None) -> st.SearchStrategy[GitlabGetError]:
    """Generates GitlabGetError, optionally pinned to a specific HTTP code."""
    code = st.just(response_code) if response_code is not None else st.sampled_from([404, 400, 500])
    return st.builds(
        lambda msg, rc: _make_gitlab_get_error(msg, rc),
        msg=_error_messages,
        rc=code,
    )


def gitlab_http_errors(response_code: int | None = None) -> st.SearchStrategy[GitlabHttpError]:
    """Generates GitlabHttpError, optionally pinned to a specific HTTP code."""
    code = st.just(response_code) if response_code is not None else st.sampled_from([403, 500, 502])
    return st.builds(
        lambda msg, rc: _make_gitlab_http_error(msg, rc),
        msg=_error_messages,
        rc=code,
    )


def gitlab_exceptions() -> st.SearchStrategy[Exception]:
    """Generates a random GitLab exception (auth, get, or http)."""
    return st.one_of(
        gitlab_auth_errors(),
        gitlab_get_errors(),
        gitlab_http_errors(),
    )


def _make_gitlab_get_error(msg: str, response_code: int) -> GitlabGetError:
    err = GitlabGetError(msg)
    err.response_code = response_code
    return err


def _make_gitlab_http_error(msg: str, response_code: int) -> GitlabHttpError:
    err = GitlabHttpError(msg)
    err.response_code = response_code
    return err



# ---------------------------------------------------------------------------
# Domain model strategies
# ---------------------------------------------------------------------------

# -- MergeRequestSummary (P2 — list_merge_requests) --

def mr_summary_data() -> st.SearchStrategy[dict]:
    """Generates raw MR summary dicts as returned by the GitLab API mock."""
    return st.fixed_dictionaries({
        "iid": st.integers(min_value=1, max_value=999_999),
        "title": st.text(min_size=1, max_size=120),
        "author": st.fixed_dictionaries({"username": usernames(), "name": st.text(min_size=1, max_size=60)}),
        "source_branch": branch_names(),
        "target_branch": branch_names(),
        "state": st.sampled_from(["opened", "closed", "merged"]),
        "web_url": web_urls(),
        "created_at": iso8601_timestamps(),
        "updated_at": iso8601_timestamps(),
    })


# -- MergeRequestDetail (P2 — get_merge_request) --

def mr_detail_data() -> st.SearchStrategy[dict]:
    """Generates raw MR detail dicts as returned by the GitLab API mock."""
    return st.fixed_dictionaries({
        "iid": st.integers(min_value=1, max_value=999_999),
        "title": st.text(min_size=1, max_size=120),
        "description": st.one_of(st.none(), st.text(max_size=500)),
        "state": st.sampled_from(["opened", "closed", "merged"]),
        "author": st.fixed_dictionaries({"name": st.text(min_size=1, max_size=60), "username": usernames()}),
        "source_branch": branch_names(),
        "target_branch": branch_names(),
        "web_url": web_urls(),
        "created_at": iso8601_timestamps(),
        "updated_at": iso8601_timestamps(),
    })


# -- MergeRequestChange (P3) --

def mr_change_data() -> st.SearchStrategy[dict]:
    """Generates a single MR change dict."""
    return st.fixed_dictionaries({
        "new_path": file_paths(),
        "old_path": file_paths(),
        "new_file": st.booleans(),
        "renamed_file": st.booleans(),
        "deleted_file": st.booleans(),
        "diff": st.text(max_size=500),
    })


def mr_changes_list() -> st.SearchStrategy[list[dict]]:
    """Generates a list of MR change dicts."""
    return st.lists(mr_change_data(), min_size=0, max_size=15)


# -- Note (P4) --

def note_data() -> st.SearchStrategy[dict]:
    """Generates a single note dict as returned by the GitLab API mock."""
    return st.fixed_dictionaries({
        "id": st.integers(min_value=1, max_value=999_999),
        "body": st.text(min_size=1, max_size=500),
        "author": st.fixed_dictionaries({"name": st.text(min_size=1, max_size=60), "username": usernames()}),
        "created_at": iso8601_timestamps(),
        "system": st.booleans(),
    })


def notes_list() -> st.SearchStrategy[list[dict]]:
    """Generates a list of note dicts."""
    return st.lists(note_data(), min_size=0, max_size=20)


# -- ProjectInfo (P5 — get_project) --

def project_info_data() -> st.SearchStrategy[dict]:
    """Generates a project info dict as returned by the GitLab API mock."""
    return st.fixed_dictionaries({
        "id": st.integers(min_value=1, max_value=999_999),
        "name": st.text(min_size=1, max_size=60),
        "path_with_namespace": project_paths(),
        "description": st.one_of(st.none(), st.text(max_size=300)),
        "default_branch": branch_names(),
        "web_url": web_urls(),
        "visibility": visibility_values(),
    })


# -- ProjectSearchResult (P5 — search_projects) --

def project_search_data() -> st.SearchStrategy[dict]:
    """Generates a project search result dict."""
    return st.fixed_dictionaries({
        "id": st.integers(min_value=1, max_value=999_999),
        "name": st.text(min_size=1, max_size=60),
        "path_with_namespace": project_paths(),
        "description": st.one_of(st.none(), st.text(max_size=300)),
        "web_url": web_urls(),
    })


# -- NoteCreated response (P10) --

def note_ids() -> st.SearchStrategy[int]:
    """Generates valid note IDs for creation responses."""
    return st.integers(min_value=1, max_value=999_999)
