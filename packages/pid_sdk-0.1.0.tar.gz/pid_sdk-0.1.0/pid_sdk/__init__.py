"""pid-sdk — Universal Portable Identity for the Agentic Era"""

__version__ = "0.1.0"

from .pid import PID

__all__ = ["PID"]
