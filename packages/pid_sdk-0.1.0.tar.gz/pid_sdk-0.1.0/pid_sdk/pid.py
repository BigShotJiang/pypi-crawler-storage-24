"""PID — Passport ID"""
import uuid
import time
from dataclasses import dataclass, field
from typing import Dict, Any

@dataclass
class PID:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    domain: str = ""
    context: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)

    @classmethod
    def create(cls, name: str, domain: str = "", **kwargs) -> "PID":
        return cls(name=name, domain=domain, context=kwargs)

    def board(self, domain: str, context: dict):
        self.domain = domain
        self.context.update(context)

    def export(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "domain": self.domain,
            "context": self.context,
            "created_at": self.created_at,
        }

    @classmethod
    def load(cls, data: dict) -> "PID":
        return cls(
            id=data["id"],
            name=data["name"],
            domain=data.get("domain", ""),
            context=data.get("context", {}),
            created_at=data.get("created_at", time.time()),
        )
