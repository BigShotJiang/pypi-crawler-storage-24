# pid-sdk

Universal Portable Identity SDK for the Agentic Era.

## Install

```bash
pip install pid-sdk
```

## Quick Start

```python
from pid_sdk import PID

passport = PID.create(name="Sarah", domain="ad-intelligence")
passport.board("ad-intelligence", {"brand": "Glow Beauty", "budget": "$200K/month"})
```

- [GitHub](https://github.com/XYANDZ-iO/pid-sdk)
- [xyandz.io](https://xyandz.io)
