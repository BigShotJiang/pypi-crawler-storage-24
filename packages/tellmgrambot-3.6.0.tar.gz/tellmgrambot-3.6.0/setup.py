from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name='TeLLMgramBot',
    version='3.6.0',
    packages=find_packages(),
    license='MIT',
    author='Digital Heresy',
    author_email='ronin.atx@gmail.com',
    description='LLM-powered Telegram bot (OpenAI + Anthropic)',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url='https://github.com/Digital-Heresy/TeLLMgramBot',
    install_requires=[
        'openai>2.0',
        'anthropic>=0.40',
        'PyYAML',
        'httpx',
        'beautifulsoup4',
        'validators',
        'tiktoken>=0.12',
        'python-telegram-bot>=20.8',
        'aiosqlite>=0.19'
    ],
    python_requires='>=3.10'
)
