from .client import CedricAI
__version__ = "7.0.0"
__all__ = ["CedricAI"]
