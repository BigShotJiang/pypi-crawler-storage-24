from iocmng.api.app import create_app

__all__ = ["create_app"]
