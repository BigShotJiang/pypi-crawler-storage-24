"""specter-host: Transparent remote GPU execution.

Run ``python train.py`` on cloud GPUs as if they were local.
"""

__version__ = "0.2.0"
