
import pathlib

from random import randint
from math import floor

class Path(pathlib.Path):
    """A brief extension of the Path class from pathlib to allow for addition operations."""
    def __add__(self, otherPath:str|pathlib.Path):
        return Path(f"{self}/{otherPath}")

# Pick a random entry from a list.
def pick(py_list:list):
    return py_list[randint(0, len(py_list)-1)]

# Pick a random entry from a list, and additionally prepend its index
def pick_rank(py_list:list) -> str:
    index = randint(0, len(py_list))
    return f"#{index}: {py_list[index]}"

# Beautify a list for printing.
def pretty_print_list(py_list:list, nesting = 0) -> str:
    outstr = ""
    nesting += 1
    for item in py_list:
        outstr += "".ljust(nesting*2, " ")
        if isinstance(item, dict):
            outstr += pretty_print_dict(item, nesting)
        elif isinstance(item, list):
            outstr += pretty_print_list(item, nesting)
        else:
            outstr += str(item)
        outstr += ",\n"
    outstr = outstr.rstrip("\n")
    nesting -= 1
    return outstr

# Beautify a dictionary for printing.
def pretty_print_dict(py_dict:dict, nesting = 0) -> str:
    outstr = ""
    for key in py_dict.keys():
        format_key = ""
        format_value = ""

        nesting += 1
        if isinstance(py_dict[key], dict):
            format_value += "\n"
            format_value += pretty_print_dict(py_dict[key], nesting)
        elif isinstance(py_dict[key], list):
            format_value += "\n"
            format_value += pretty_print_list(py_dict[key], nesting)
        else:
            format_value += f" {py_dict[key]}\n"
        nesting -= 1

        format_key += f"{"".ljust(nesting*2, " ")}{str(key).title()}:"
        outstr += f"{format_key}{format_value}"
    return outstr

def plural(n:int|float) -> str:
    return "s" if n != 1 else ''

def format_seconds_to_times(seconds:float|int) -> str:
    # Largest to smallest denominator
    seconds_in_one_minute = 1 * 60
    seconds_in_one_hour = 60 * seconds_in_one_minute
    seconds_in_one_day = seconds_in_one_hour * 24
    seconds_in_one_week = seconds_in_one_day * 7
    seconds_in_one_year = seconds_in_one_day * 365.25 # Slightly innacurate, but i dont care
    seconds_in_one_month = seconds_in_one_day * (365.25/12) # Also slightly innacurate, and i still dont care

    years = floor(seconds/seconds_in_one_year)
    seconds -= years * seconds_in_one_year

    months = floor(seconds/seconds_in_one_month)
    seconds -= months * seconds_in_one_month

    weeks = floor(seconds/seconds_in_one_week)
    seconds -= weeks * seconds_in_one_week

    days = floor(seconds/seconds_in_one_day)
    seconds -= days * seconds_in_one_day

    hours = floor(seconds/seconds_in_one_hour)
    seconds -= hours * seconds_in_one_hour

    minutes = floor(seconds/seconds_in_one_minute)
    seconds -= minutes * seconds_in_one_minute

    # and then seconds is left as it ought to be
    seconds = floor(seconds)

    toformat = [[years, "year"], [months, "month"], [weeks, "week"], [days, "day"], [hours, "hour"], [minutes, "minute"], [seconds, "second"]]
    output_str = ""
    for num_unit, unit in toformat:
        if num_unit == 0:
            continue
        output_str += f"{num_unit} {unit}{plural(num_unit)}, "
    output_str = output_str.rstrip(", ")
    return output_str

def profile(func, *args, **kwargs):
    import time
    start = time.perf_counter()
    func(*args, **kwargs)
    return time.perf_counter() - start

def dprint(debug:bool = False, values = '', sep = " ", end = "\n", file = None, flush = False) -> None:
    if not debug: return
    print(*values, sep, end, file, flush)
