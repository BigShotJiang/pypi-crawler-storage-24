from typing import Any, Optional

from vicentin.kernels import Kernel
from vicentin.utils import Dispatcher
from vicentin.utils.logging import debug

disp_l1 = Dispatcher()

try:
    from scipy.spatial.distance import cdist

    def l1_dist(x, y):
        if y is None:
            y = x

        return cdist(x, y, metric="cityblock")

    disp_l1.register("numpy", l1_dist)
except ModuleNotFoundError:
    pass


try:
    import torch

    def torch_l1_dist(x, y):
        if y is None:
            y = x

        return torch.cdist(x, y, p=1.0)

    disp_l1.register("torch", torch_l1_dist)
except ModuleNotFoundError:
    pass


class LaplacianKernel(Kernel):
    def __init__(
        self, X: Optional[Any] = None, gamma: Optional[float] = None, **kwargs
    ):
        self.gamma = gamma
        self._auto_gamma = gamma is None

        super().__init__(X, **kwargs)

        self.disp_exp = Dispatcher()

        try:
            import numpy as np

            self.disp_exp.register("numpy", np.exp)
        except ImportError:
            pass

        try:
            import torch

            self.disp_exp.register("torch", torch.exp)
        except ImportError:
            pass

    def set_X(self, X: Any):
        super().set_X(X)

        if self._auto_gamma:
            self.gamma = 1 / (X.shape[1] * X.var())
            debug(f"LaplacianKernel: auto-calculated gamma={self.gamma:.4e}")

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        if self.gamma is None:
            raise RuntimeError("gamma is None.")

        ctx_l1 = disp_l1.detect_backend(x)
        ctx_exp = self.disp_exp.detect_backend(x)

        ctx_l1.verbose = False
        ctx_exp.verbose = False

        if getattr(x, "ndim", 1) == 1:
            x = x[None, :]
        if y is not None and getattr(y, "ndim", 1) == 1:
            y = y[None, :]

        dists = disp_l1(ctx_l1, x, y)
        return self.disp_exp(ctx_exp, -self.gamma * dists).squeeze()

    def __repr__(self):
        return (
            f"LaplacianKernel(gamma={self.gamma:.2e}, alpha={self._alpha:.2e})"
        )
