from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True, frozen=True)
class TriggerDecision:
    accept: bool
    reason: str


def is_openclaw_command(text: str | None) -> bool:
    if not text:
        return False
    stripped = text.strip()
    if not stripped.startswith("/"):
        return False
    head = stripped.split(maxsplit=1)[0]
    name = head[1:].split("@", 1)[0].lower()
    return name == "openclaw"


def should_trigger_agent(
    text: str | None,
    *,
    is_reply_to_bot: bool,
    has_active_session: bool = False,
) -> TriggerDecision:
    if is_openclaw_command(text):
        return TriggerDecision(True, "openclaw_command")
    if is_reply_to_bot:
        return TriggerDecision(True, "reply_to_bot")
    return TriggerDecision(False, "ignored_plain_message")
