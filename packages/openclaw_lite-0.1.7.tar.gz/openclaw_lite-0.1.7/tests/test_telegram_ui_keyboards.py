from __future__ import annotations

import pytest

from openclaw_lite.interfaces.telegram_ui_keyboards import build_settings_action_rows, build_settings_keyboard, chunk_inline_buttons



def test_chunk_inline_buttons_rejects_non_positive_row_size() -> None:
    with pytest.raises(ValueError):
        chunk_inline_buttons([], 0)



def test_build_settings_action_rows_exposes_refresh_reload_and_help() -> None:
    rows = build_settings_action_rows()
    assert len(rows) == 1
    assert rows[0][0].text == "↻ Refresh"
    assert rows[0][1].text == "♻ Reload"
    assert rows[0][2].text == "❓ Help"



def test_build_settings_keyboard_places_provider_rows_before_action_row() -> None:
    keyboard = build_settings_keyboard(
        [
            {
                "name": "gemini",
                "enabled": True,
                "has_api_key": False,
                "default_model": "gemini-2.5-flash",
                "is_default": False,
            },
            {
                "name": "openai",
                "enabled": True,
                "has_api_key": True,
                "default_model": "gpt-4.1-mini",
                "is_default": True,
            },
        ],
        current_provider="openai",
        current_model="gpt-5.4-ultra-preview",
    )

    rows = keyboard.inline_keyboard
    assert len(rows) == 3
    assert rows[0][0].callback_data == "settings:provider:openai"
    assert rows[0][0].text == "🟢 OpenAI"
    assert rows[0][1].text == "✅ Key"
    assert rows[0][2].text.startswith("🧠 gpt-5.4")
    assert rows[1][0].callback_data == "settings:provider:gemini"
    assert rows[1][1].text == "🔑 Add key"
    assert rows[2][0].callback_data == "settings:refresh"
    assert rows[2][1].callback_data == "settings:reload"
    assert rows[2][2].callback_data == "settings:help"



def test_build_settings_keyboard_marks_disabled_provider() -> None:
    keyboard = build_settings_keyboard(
        [
            {
                "name": "claude",
                "enabled": False,
                "has_api_key": True,
                "default_model": "claude-3-7-sonnet-latest",
                "is_default": False,
            }
        ],
        current_provider="openai",
        current_model="gpt-4.1-mini",
    )
    provider_row = keyboard.inline_keyboard[0]
    assert provider_row[0].text == "⛔ Claude"
    assert provider_row[1].text == "🔒 Disabled"
    assert provider_row[2].text == "🧠 Disabled"
