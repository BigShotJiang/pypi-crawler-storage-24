from __future__ import annotations

from openclaw_lite.interfaces.telegram_ui_keyboards import build_settings_keyboard
from openclaw_lite.interfaces.telegram_ui_progress import preview_html, render_progress_finish, render_progress_status
from openclaw_lite.interfaces.telegram_ui_text import (
    BOT_COMMAND_SPECS,
    build_help_text,
    render_auth_text,
    render_models_text,
    render_settings_input_prompt,
    render_settings_text,
    render_status_text,
)


class DummySession:
    provider = "openai"
    model = "gpt-4.1-mini"
    security_mode = "safe"



def test_help_text_groups_core_commands_and_strict_chat_rules() -> None:
    text = build_help_text()
    assert "<b>🚀 Быстрый старт</b>" in text
    assert "/openclaw [запрос]" in text
    assert "reply на сообщение бота" in text
    assert "в личке активная сессия" not in text
    assert any(name == "settings" for name, _ in BOT_COMMAND_SPECS)



def test_render_settings_text_builds_readable_control_panel() -> None:
    text = render_settings_text(
        DummySession(),
        [
            {
                "name": "openai",
                "enabled": True,
                "has_api_key": True,
                "default_model": "gpt-4.1-mini",
                "is_default": True,
            },
            {
                "name": "gemini",
                "enabled": True,
                "has_api_key": False,
                "default_model": "gemini-2.5-flash",
                "is_default": False,
            },
        ],
    )
    assert "<b>⚙️ LiteClaw Settings</b>" in text
    assert "<b>🧵 Current session</b>" in text
    assert "<b>🧠 Provider overview</b>" in text
    assert "default model" in text
    assert "OpenAI" in text
    assert "Gemini" in text



def test_settings_keyboard_has_one_provider_row_each_plus_action_row() -> None:
    keyboard = build_settings_keyboard(
        [
            {"name": "openai", "enabled": True, "has_api_key": True, "is_default": True},
            {"name": "gemini", "enabled": True, "has_api_key": False, "is_default": False},
        ],
        current_provider="openai",
        current_model="gpt-4.1-mini",
    )
    rows = keyboard.inline_keyboard
    assert len(rows) == 3
    assert rows[0][0].text.startswith("🟢")
    assert rows[0][1].callback_data == "settings:key:openai"
    assert rows[1][2].callback_data == "settings:model:gemini"
    assert rows[-1][0].callback_data == "settings:refresh"
    assert rows[-1][1].callback_data == "settings:reload"
    assert rows[-1][2].callback_data == "settings:help"



def test_progress_status_marks_nonzero_exit_as_issue() -> None:
    rendered = render_progress_status(
        {
            "event": "tool_call_finished",
            "iteration": 3,
            "tool": "shell_run",
            "result": {"exit_code": 1, "stdout": "", "stderr": "requests missing"},
        }
    )
    assert rendered is not None
    assert "Tool result" in rendered
    assert "exit code 1" in rendered
    assert "requests missing" in rendered



def test_progress_finish_renders_next_state() -> None:
    rendered = render_progress_finish({"iterations": 4, "session_closed": False, "security_mode": "safe"})
    assert "Agent Mode finished" in rendered
    assert "waiting for next message" in rendered



def test_settings_input_prompt_mentions_cancel_and_provider() -> None:
    rendered = render_settings_input_prompt("api_key", "openai")
    assert "API key" in rendered
    assert "/cancel" in rendered
    assert "openai" in rendered



def test_status_models_and_auth_text_stay_html_friendly() -> None:
    status = render_status_text(
        {
            "session_id": "telegram:100:main",
            "provider": "openai",
            "model": "gpt-4.1-mini",
            "security_mode": "safe",
            "history_messages": 7,
            "closed": False,
            "skills": [{"name": "search", "enabled": True}],
        }
    )
    models = render_models_text({"openai": ["gpt-4.1-mini"], "gemini": ["gemini-2.5-flash"]})
    auth = render_auth_text(
        {
            "owner_user_ids": [42],
            "owner_chat_ids": [100],
            "allowed_user_ids": [7, 8],
            "allowed_chat_ids": [-10022],
            "pairing_codes": [{"code": "ABC123", "expires_at": "tomorrow"}],
        }
    )
    assert "<code>telegram:100:main</code>" in status
    assert "<b>🧪 Models</b>" in models
    assert "<b>🔐 Access & Auth</b>" in auth
    assert preview_html("<raw>") == "&lt;raw&gt;"
