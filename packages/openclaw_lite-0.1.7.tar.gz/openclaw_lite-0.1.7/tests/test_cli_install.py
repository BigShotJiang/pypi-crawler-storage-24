from __future__ import annotations

import tomllib
from pathlib import Path

import pytest

from openclaw_lite.cli import _resolve_config_path, build_parser
from openclaw_lite.version import __version__


def test_cli_supports_config_before_subcommand() -> None:
    parser = build_parser()
    args = parser.parse_args(["--config", "custom.yaml", "doctor"])
    assert args.command == "doctor"
    assert args.config == "custom.yaml"


def test_cli_supports_config_after_subcommand() -> None:
    parser = build_parser()
    args = parser.parse_args(["doctor", "--config", "custom.yaml"])
    assert args.command == "doctor"
    assert args.config == "custom.yaml"


def test_agent_alias_parses_like_ask() -> None:
    parser = build_parser()
    args = parser.parse_args(["agent", "hello", "--session-id", "demo"])
    assert args.command == "agent"
    assert args.message == "hello"
    assert args.session_id == "demo"


def test_pair_create_parser_shape() -> None:
    parser = build_parser()
    args = parser.parse_args(["pair", "create", "--ttl-seconds", "300", "--owner-user-id", "42"])
    assert args.command == "pair"
    assert args.pair_command == "create"
    assert args.ttl_seconds == 300
    assert args.owner_user_id == 42


def test_pyproject_exposes_liteclaw_entrypoint() -> None:
    pyproject = Path(__file__).resolve().parent.parent / "pyproject.toml"
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    scripts = data["project"]["scripts"]
    assert scripts["openclaw-lite"] == "openclaw_lite.cli:main"
    assert scripts["liteclaw"] == "openclaw_lite.cli:main"


def test_web_parser_shape() -> None:
    parser = build_parser()
    args = parser.parse_args(["web", "--host", "0.0.0.0", "--port", "9999"])
    assert args.command == "web"
    assert args.host == "0.0.0.0"
    assert args.port == 9999


def test_onboard_parser_shape() -> None:
    parser = build_parser()
    args = parser.parse_args(["onboard", "--config", "custom.yaml"])
    assert args.command == "onboard"
    assert args.config == "custom.yaml"


def test_config_get_parser_shape() -> None:
    parser = build_parser()
    args = parser.parse_args(["config", "get", "providers.default", "--json"])
    assert args.command == "config"
    assert args.config_command == "get"
    assert args.path == "providers.default"
    assert args.json is True


def test_pyproject_no_longer_advertises_liveclaw() -> None:
    pyproject = Path(__file__).resolve().parent.parent / "pyproject.toml"
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    scripts = data["project"]["scripts"]
    assert "liveclaw" not in scripts


def test_pyproject_has_basic_release_metadata() -> None:
    pyproject = Path(__file__).resolve().parent.parent / "pyproject.toml"
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    project = data["project"]
    readme = project["readme"]
    classifiers = set(project["classifiers"])
    keywords = set(project["keywords"])

    assert readme["file"] == "README.md"
    assert readme["content-type"] == "text/markdown"
    assert {"telegram", "llm", "cli"} <= keywords
    assert "Programming Language :: Python :: 3.11" in classifiers
    assert "Framework :: AsyncIO" in classifiers


def test_resolve_config_path_prefers_nearest_parent_config(tmp_path, monkeypatch) -> None:
    project = tmp_path / "project"
    nested = project / "a" / "b"
    nested.mkdir(parents=True)
    config_path = project / "config.yaml"
    config_path.write_text("telegram:\n  bot_token: ''\n", encoding="utf-8")
    monkeypatch.chdir(nested)

    resolved = _resolve_config_path(None, explicit=False, command="onboard")

    assert Path(resolved) == config_path.resolve()


def test_resolve_config_path_for_init_stays_in_current_directory(tmp_path, monkeypatch) -> None:
    project = tmp_path / "project"
    nested = project / "new-app"
    nested.mkdir(parents=True)
    (project / "config.yaml").write_text("telegram:\n  bot_token: ''\n", encoding="utf-8")
    monkeypatch.chdir(nested)

    resolved = _resolve_config_path(None, explicit=False, command="init")

    assert Path(resolved) == (nested / "config.yaml").resolve()


def test_cli_version_flag() -> None:
    parser = build_parser()
    with pytest.raises(SystemExit) as exc_info:
        parser.parse_args(["-v"])
    assert exc_info.value.code == 0


def test_cli_version_flag_long() -> None:
    parser = build_parser()
    with pytest.raises(SystemExit) as exc_info:
        parser.parse_args(["--version"])
    assert exc_info.value.code == 0
