from __future__ import annotations

from openclaw_lite.interfaces.telegram_ui_text import (
    BOT_COMMAND_SPECS,
    build_auth_text,
    build_help_text,
    build_models_text,
    build_settings_overview,
    build_status_text,
    render_settings_input_prompt,
)


class DummySession:
    provider = "openai"
    model = "gpt-4.1-mini"
    security_mode = "safe"



def test_help_text_exposes_sections_and_strict_trigger_rules() -> None:
    text = build_help_text()
    assert "<b>🚀 Быстрый старт</b>" in text
    assert "/openclaw [запрос]" in text
    assert "reply на сообщение бота" in text
    assert "в личке активная сессия" not in text
    assert any(name == "settings" for name, _ in BOT_COMMAND_SPECS)



def test_status_and_models_text_are_html_friendly() -> None:
    status = build_status_text(
        {
            "session_id": "telegram:100:main",
            "provider": "openai",
            "model": "gpt-4.1-mini",
            "security_mode": "safe",
            "history_messages": 7,
            "closed": False,
            "skills": [{"name": "search", "enabled": True}],
        }
    )
    models = build_models_text({"openai": ["gpt-4.1-mini"], "gemini": ["gemini-2.5-flash"]})
    assert "<code>telegram:100:main</code>" in status
    assert "<b>🧪 Models</b>" in models



def test_auth_text_uses_new_title() -> None:
    rendered = build_auth_text(
        {
            "owner_user_ids": [42],
            "owner_chat_ids": [100],
            "allowed_user_ids": [7],
            "allowed_chat_ids": [-10022],
            "pairing_codes": [{"code": "ABC123", "expires_at": "tomorrow"}],
        }
    )
    assert "<b>🔐 Access & Auth</b>" in rendered
    assert "ABC123" in rendered



def test_settings_overview_is_readable_and_uses_human_labels() -> None:
    rendered = build_settings_overview(
        session=DummySession(),
        providers=[
            {
                "name": "openai",
                "enabled": True,
                "has_api_key": True,
                "default_model": "gpt-4.1-mini",
                "is_default": True,
            },
            {
                "name": "gemini",
                "enabled": True,
                "has_api_key": False,
                "default_model": "gemini-2.5-flash",
                "is_default": False,
            },
        ],
    )
    assert "<b>⚙️ LiteClaw Settings</b>" in rendered
    assert "<b>🧵 Current session</b>" in rendered
    assert "OpenAI" in rendered
    assert "Gemini" in rendered



def test_settings_input_prompt_mentions_cancel_and_provider() -> None:
    rendered = render_settings_input_prompt("api_key", "openai")
    assert "API key" in rendered
    assert "/cancel" in rendered
    assert "OpenAI" in rendered
