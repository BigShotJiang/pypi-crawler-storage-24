from __future__ import annotations

from pathlib import Path

from openclaw_lite.config import ConfigManager
from openclaw_lite.core.runtime import OpenClawLiteRuntime


def test_set_provider_same_provider_keeps_custom_session_model(tmp_path: Path) -> None:
    config_path = tmp_path / "config.yaml"
    runtime = OpenClawLiteRuntime(config_path)
    session = runtime.get_session(session_id="telegram:1:main", chat_id="1", user_id=42)

    runtime.set_model(session, "gpt-5.4")
    result = runtime.set_provider(session, "openai")

    assert result["provider"] == "openai"
    assert result["model"] == "gpt-5.4"


def test_set_model_can_persist_provider_default_to_config(tmp_path: Path) -> None:
    config_path = tmp_path / "config.yaml"
    runtime = OpenClawLiteRuntime(config_path)
    session = runtime.get_session(session_id="telegram:1:main", chat_id="1", user_id=42)

    result = runtime.set_model(session, "gpt-5.4", persist_default=True)
    reloaded = ConfigManager(config_path)

    assert result["model"] == "gpt-5.4"
    assert reloaded.get("providers.items.openai.default_model") == "gpt-5.4"
