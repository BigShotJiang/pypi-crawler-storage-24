from __future__ import annotations

from openclaw_lite.interfaces.telegram_ui_progress import build_progress_status, preview_text



def test_preview_text_escapes_and_truncates() -> None:
    rendered = preview_text("<hello>" * 200, limit=20)
    assert "&lt;hello&gt;" in rendered
    assert rendered.endswith("…")



def test_build_progress_status_iteration_started() -> None:
    text = build_progress_status(
        {
            "event": "agent_iteration_started",
            "iteration": 3,
            "provider": "openai",
            "model": "gpt-5.4",
        }
    )
    assert text is not None
    assert "Agent is thinking" in text
    assert "openai" in text



def test_build_progress_status_tool_finished_nonzero_exit_is_warning() -> None:
    text = build_progress_status(
        {
            "event": "tool_call_finished",
            "iteration": 4,
            "tool": "shell_run",
            "result": {"exit_code": 1, "stderr": "boom"},
        }
    )
    assert text is not None
    assert "exit code 1" in text
    assert "shell_run" in text



def test_build_progress_status_unknown_event_returns_none() -> None:
    assert build_progress_status({"event": "unknown_event"}) is None
