"""MCP tool handlers for GitHub data scraping."""

import json
import logging
import os

import httpx

from mcp.types import TextContent

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

GITHUB_API_BASE = f"{CRAWLNEST_API_URL}/api/github"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None) -> list[TextContent]:
    resp: dict = {"success": False, "error": error}
    if details:
        resp["details"] = details
    return [TextContent(type="text", text=json.dumps(resp))]


async def _post(endpoint: str, payload: dict, timeout: float = 120.0) -> list[TextContent]:
    """Make a POST request to a GitHub API endpoint and return the response."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{GITHUB_API_BASE}/{endpoint}",
                json=payload,
                headers=_headers(),
                timeout=timeout,
            )

            if response.status_code == 503:
                return _error_response(
                    "GitHub service not initialized — GITHUB_PAT_TOKEN may not be set.",
                    details=response.text,
                )

            if response.status_code != 200:
                return _error_response(
                    f"GitHub API returned HTTP {response.status_code}",
                    details=response.text,
                )

            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))


async def _get(endpoint: str, params: dict, timeout: float = 120.0) -> list[TextContent]:
    """Make a GET request to a GitHub API endpoint and return the response."""
    try:
        # Remove None values from params
        params = {k: v for k, v in params.items() if v is not None}

        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"{GITHUB_API_BASE}/{endpoint}",
                params=params,
                headers=_headers(),
                timeout=timeout,
            )

            if response.status_code == 503:
                return _error_response(
                    "GitHub service not initialized — GITHUB_PAT_TOKEN may not be set.",
                    details=response.text,
                )

            if response.status_code != 200:
                return _error_response(
                    f"GitHub API returned HTTP {response.status_code}",
                    details=response.text,
                )

            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))


# --- Tool handlers ---


async def handle_github_repo(arguments: dict) -> list[TextContent]:
    """Fetch repository data (detail, readme, languages)."""
    owner = arguments.get("owner")
    repo = arguments.get("repo")
    if not owner or not repo:
        return _error_response("owner and repo are required")

    payload: dict = {"owner": owner, "repo": repo}
    if arguments.get("include"):
        payload["include"] = arguments["include"]

    logger.info(f"[github_repo] {owner}/{repo} include={payload.get('include', ['detail'])}")
    return await _post("repo", payload)


async def handle_github_releases(arguments: dict) -> list[TextContent]:
    """Fetch repository release history."""
    owner = arguments.get("owner")
    repo = arguments.get("repo")
    if not owner or not repo:
        return _error_response("owner and repo are required")

    payload: dict = {"owner": owner, "repo": repo}
    if arguments.get("per_page"):
        payload["per_page"] = arguments["per_page"]
    if arguments.get("page"):
        payload["page"] = arguments["page"]

    logger.info(f"[github_releases] {owner}/{repo}")
    return await _post("repo/releases", payload)


async def handle_github_forks(arguments: dict) -> list[TextContent]:
    """Fetch repository forks."""
    owner = arguments.get("owner")
    repo = arguments.get("repo")
    if not owner or not repo:
        return _error_response("owner and repo are required")

    payload: dict = {"owner": owner, "repo": repo}
    if arguments.get("sort"):
        payload["sort"] = arguments["sort"]
    if arguments.get("per_page"):
        payload["per_page"] = arguments["per_page"]
    if arguments.get("page"):
        payload["page"] = arguments["page"]

    logger.info(f"[github_forks] {owner}/{repo}")
    return await _post("repo/forks", payload)


async def handle_github_stargazers(arguments: dict) -> list[TextContent]:
    """Fetch repository stargazers."""
    owner = arguments.get("owner")
    repo = arguments.get("repo")
    if not owner or not repo:
        return _error_response("owner and repo are required")

    payload: dict = {"owner": owner, "repo": repo}
    if arguments.get("sort"):
        payload["sort"] = arguments["sort"]
    if arguments.get("per_page"):
        payload["per_page"] = arguments["per_page"]
    if arguments.get("page"):
        payload["page"] = arguments["page"]

    logger.info(f"[github_stargazers] {owner}/{repo}")
    return await _post("repo/stargazers", payload)


async def handle_github_contributors(arguments: dict) -> list[TextContent]:
    """Fetch repository contributors."""
    owner = arguments.get("owner")
    repo = arguments.get("repo")
    if not owner or not repo:
        return _error_response("owner and repo are required")

    payload: dict = {"owner": owner, "repo": repo}
    if arguments.get("per_page"):
        payload["per_page"] = arguments["per_page"]
    if arguments.get("page"):
        payload["page"] = arguments["page"]

    logger.info(f"[github_contributors] {owner}/{repo}")
    return await _post("repo/contributors", payload)


async def handle_github_user(arguments: dict) -> list[TextContent]:
    """Fetch a GitHub user or organization profile."""
    username = arguments.get("username")
    if not username:
        return _error_response("username is required")

    logger.info(f"[github_user] {username}")
    return await _post("user", {"username": username})


async def handle_github_user_repos(arguments: dict) -> list[TextContent]:
    """Fetch a user's public repositories."""
    username = arguments.get("username")
    if not username:
        return _error_response("username is required")

    payload: dict = {"username": username}
    if arguments.get("sort"):
        payload["sort"] = arguments["sort"]
    if arguments.get("per_page"):
        payload["per_page"] = arguments["per_page"]
    if arguments.get("page"):
        payload["page"] = arguments["page"]

    logger.info(f"[github_user_repos] {username}")
    return await _post("user/repos", payload)


async def handle_github_user_starred(arguments: dict) -> list[TextContent]:
    """Fetch a user's starred repositories."""
    username = arguments.get("username")
    if not username:
        return _error_response("username is required")

    payload: dict = {"username": username}
    if arguments.get("sort"):
        payload["sort"] = arguments["sort"]
    if arguments.get("direction"):
        payload["direction"] = arguments["direction"]
    if arguments.get("per_page"):
        payload["per_page"] = arguments["per_page"]
    if arguments.get("page"):
        payload["page"] = arguments["page"]

    logger.info(f"[github_user_starred] {username}")
    return await _post("user/starred", payload)


async def handle_github_trending(arguments: dict) -> list[TextContent]:
    """Fetch trending repositories or developers."""
    params: dict = {}
    if arguments.get("type"):
        params["type"] = arguments["type"]
    if arguments.get("language"):
        params["language"] = arguments["language"]
    if arguments.get("since"):
        params["since"] = arguments["since"]
    if arguments.get("spoken_language_code"):
        params["spoken_language_code"] = arguments["spoken_language_code"]
    if arguments.get("sponsorable"):
        params["sponsorable"] = arguments["sponsorable"]

    logger.info(f"[github_trending] type={params.get('type', 'repositories')}")
    return await _get("trending", params)


async def handle_github_search_repos(arguments: dict) -> list[TextContent]:
    """Search GitHub repositories."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")

    payload: dict = {"query": query}
    for key in [
        "language", "stars_min", "stars_max", "forks_min", "forks_max",
        "pushed_after", "pushed_before", "created_after", "created_before",
        "topic", "license", "user", "org", "archived", "include_forks",
        "sort", "order", "per_page", "page",
    ]:
        if arguments.get(key) is not None:
            payload[key] = arguments[key]

    logger.info(f"[github_search_repos] query={query}")
    return await _post("search/repos", payload)


async def handle_github_search_users(arguments: dict) -> list[TextContent]:
    """Search GitHub users."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")

    payload: dict = {"query": query}
    for key in [
        "location", "language", "followers_min", "followers_max",
        "repos_min", "repos_max", "created_after", "created_before",
        "fullname", "account_type", "sort", "order", "per_page", "page",
    ]:
        if arguments.get(key) is not None:
            payload[key] = arguments[key]

    logger.info(f"[github_search_users] query={query}")
    return await _post("search/users", payload)


async def handle_github_search_topics(arguments: dict) -> list[TextContent]:
    """Search GitHub topics."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")

    payload: dict = {"query": query}
    for key in ["curation", "repositories_min", "repositories_max", "per_page", "page"]:
        if arguments.get(key) is not None:
            payload[key] = arguments[key]

    logger.info(f"[github_search_topics] query={query}")
    return await _post("search/topics", payload)


async def handle_github_search_issues(arguments: dict) -> list[TextContent]:
    """Search GitHub issues and pull requests."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")

    payload: dict = {"query": query}
    for key in [
        "issue_type", "state", "label", "language", "repo", "author", "assignee",
        "mentions", "involves", "comments_min", "comments_max",
        "reactions_min", "reactions_max", "created_after", "created_before",
        "updated_after", "updated_before", "is_merged", "is_draft", "review",
        "no_label", "no_assignee", "no_milestone", "user", "org",
        "sort", "order", "per_page", "page",
    ]:
        if arguments.get(key) is not None:
            payload[key] = arguments[key]

    logger.info(f"[github_search_issues] query={query}")
    return await _post("search/issues", payload)


async def handle_github_topic_repos(arguments: dict) -> list[TextContent]:
    """Fetch repositories tagged with a specific topic."""
    topic = arguments.get("topic")
    if not topic:
        return _error_response("topic is required")

    payload: dict = {"topic": topic}
    for key in ["sort", "order", "per_page", "page"]:
        if arguments.get(key) is not None:
            payload[key] = arguments[key]

    logger.info(f"[github_topic_repos] topic={topic}")
    return await _post("topic/repos", payload)
