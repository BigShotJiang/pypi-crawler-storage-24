"""
Result store for structured backtest results.
"""
from dataclasses import dataclass, field
from typing import Any, Optional, Dict
import pandas as pd


@dataclass
class StatsStore:
    """
    Statistics store for performance metrics.

    This class provides a container for performance statistics
    with dict-like access for backward compatibility.

    Attributes:
        turnover: Annualized turnover rate
    """
    turnover: float = 0.0

    def __getitem__(self, key: str) -> Any:
        """Support dict-style access."""
        return getattr(self, key, None)

    def __setitem__(self, key: str, value: Any) -> None:
        """Support dict-style setting."""
        setattr(self, key, value)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {'turnover': self.turnover}


@dataclass
class ResultStore:
    """
    Structured result store for backtest results.

    This class replaces addict.Dict with a typed, structured container
    that supports both attribute and dict-style access for backward
    compatibility.

    Attributes:
        nav: DataFrame containing NAV series for asset, future, hedge
        signal: DataFrame with original signal in long format
        hold: DataFrame with final holdings
        benchmark: Benchmark symbol
        stats: Statistics store with performance metrics
    """
    nav: pd.DataFrame = field(default_factory=pd.DataFrame)
    signal: pd.DataFrame = field(default_factory=pd.DataFrame)
    hold: pd.DataFrame = field(default_factory=pd.DataFrame)
    benchmark: str = ""
    stats: StatsStore = field(default_factory=StatsStore)

    def __getitem__(self, key: str) -> Any:
        """Support dict-style access for backward compatibility."""
        return getattr(self, key, None)

    def __setitem__(self, key: str, value: Any) -> None:
        """Support dict-style setting for backward compatibility."""
        if hasattr(self, key):
            setattr(self, key, value)
        else:
            # For unknown keys, set as attribute (for flexibility)
            setattr(self, key, value)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary format (compatible with addict.Dict).

        Returns:
            Dictionary with all result data
        """
        return {
            'nav': self.nav,
            'signal': self.signal,
            'hold': self.hold,
            'benchmark': self.benchmark,
            'stats': self.stats.to_dict()
        }

    def to_addict_compatible(self) -> Dict[str, Any]:
        """
        Convert to addict-compatible dictionary.

        This method returns a dictionary that can be used as a drop-in
        replacement for the original addict.Dict result.

        Returns:
            Dictionary mimicking addict.Dict structure
        """
        return self.to_dict()

    @property
    def is_empty(self) -> bool:
        """Check if result contains any data."""
        return self.nav.empty and self.signal.empty and self.hold.empty
