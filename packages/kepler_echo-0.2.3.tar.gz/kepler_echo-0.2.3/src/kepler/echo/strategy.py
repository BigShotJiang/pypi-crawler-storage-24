"""
Vector backtesting strategy class.
"""
import datetime as dt
from dataclasses import dataclass, field
from typing import Tuple, Optional, Literal, Union

import numpy as np
import pandas as pd

from kepler.echo.commons import Commons
from kepler.echo.signal import SignalProcessor
from kepler.echo.returns import ReturnCalculator
from kepler.echo.performance import PerformanceAnalyzer
from kepler.echo.result import ResultStore


@dataclass
class Strategy:
    """
    Vector backtesting strategy.

    Attributes:
        begin: Backtest start date
        end: Backtest end date
        matching: Order matching type ('next_bar' or 'current_bar')
    """
    begin: pd.Timestamp = field(default_factory=lambda: pd.to_datetime("20010101"))
    end: pd.Timestamp = field(default_factory=lambda: pd.to_datetime(dt.date.today()))
    matching: Literal["next_bar", "current_bar"] = "next_bar"

    _open: Optional[pd.DataFrame] = field(default=None, repr=False)
    _close: Optional[pd.DataFrame] = field(default=None, repr=False)
    _signal: Optional[pd.DataFrame] = field(default=None, repr=False)
    _signal_processor: SignalProcessor = field(default=None, repr=False)
    _return_calculator: ReturnCalculator = field(default=None, repr=False)
    _performance_analyzer: PerformanceAnalyzer = field(default=None, repr=False)
    result: ResultStore = field(default_factory=ResultStore, repr=False)
    _commission: Tuple[float, float] = field(default=(0.0, 0.0), repr=False)
    _benchmark: str = field(default="", repr=False)

    def __post_init__(self):
        """Initialize after construction."""
        self.begin = pd.to_datetime(self.begin)
        self.end = pd.to_datetime(self.end)

        if self.matching not in ("next_bar", "current_bar"):
            raise ValueError("matching must be 'next_bar' or 'current_bar'")
        if len(self._commission) != 2:
            raise ValueError("commission must be tuple like (0.001, 0.001)")

        self._signal_processor = SignalProcessor(self.matching)
        self._return_calculator = ReturnCalculator(self.matching)
        self._performance_analyzer = PerformanceAnalyzer()

    def signal(self, signal: pd.DataFrame) -> 'Strategy':
        """Add trading signal."""
        if not isinstance(signal, pd.DataFrame):
            raise TypeError("signal must be a DataFrame")

        self._signal = self._signal_processor.process(signal)
        return self

    def data(
        self,
        data,
        exec_price: str = 'open',
        feature_dim: str = None
    ) -> 'Strategy':
        """
        Add price data.

        Supports two formats:
        1. pandas DataFrame with MultiIndex ['date', 'item'] and columns including 'close'
        2. xarray DataArray with dimensions (date, item, feature) - feature auto-detected

        Args:
            data: Price data (DataFrame or xarray DataArray)
            exec_price: Column/feature name for execution price (default: 'open')
            feature_dim: Name of feature dimension for xarray (auto-detected if None)

        Example:
            .data(price_df)                       # pandas DataFrame
            .data(price_xr, exec_price='vwap')    # xarray DataArray
        """
        # Detect data type and process accordingly
        try:
            import xarray as xr
            is_xarray = isinstance(data, xr.DataArray)
        except ImportError:
            is_xarray = False

        if is_xarray:
            self._process_xarray_data(data, exec_price, feature_dim)
        elif isinstance(data, pd.DataFrame):
            self._process_dataframe(data, exec_price)
        else:
            raise TypeError("data must be a pandas DataFrame or xarray DataArray")

        self.begin = max(self.begin, self._open.index[0])
        self.end = min(self.end, self._open.index[-1])

        self._open = self._open.loc[self.begin : self.end].copy()
        self._open = self._open.shift(-1)
        self._open.index = self._open.index + Commons.SHIFT_TIME
        self._close = self._close.loc[self.begin : self.end].copy()

        self._open["cash"] = 1.0
        self._close["cash"] = 1.0
        return self

    def _process_dataframe(self, data: pd.DataFrame, exec_price: str) -> None:
        """Process pandas DataFrame format."""
        exec_col = exec_price.lower()
        data_cols = set(data.columns.str.lower())

        if 'close' not in data_cols:
            raise ValueError("data must contain 'close' column")
        if exec_col not in data_cols:
            raise ValueError(f"Column '{exec_price}' not found in data")

        self._open = data[exec_col].unstack()
        self._close = data['close'].unstack()
        self._open.index = pd.to_datetime(self._open.index)
        self._close.index = pd.to_datetime(self._close.index)

    def _process_xarray_data(self, data, exec_price: str, feature_dim: str = None) -> None:
        """Process xarray DataArray format."""
        exec_col = exec_price.lower()

        # Auto-detect feature dimension if not specified
        if feature_dim is None:
            dims = set(data.dims)
            if 'date' in dims and 'item' in dims:
                remaining = dims - {'date', 'item'}
                if len(remaining) == 1:
                    feature_dim = remaining.pop()
                else:
                    raise ValueError(f"Cannot auto-detect feature dimension. Available dims: {dims}")
            else:
                raise ValueError(f"xarray must have 'date' and 'item' dimensions. Got: {dims}")

        # Validate dimensions
        required_dims = {'date', 'item', feature_dim}
        actual_dims = set(data.dims)
        if not required_dims.issubset(actual_dims):
            missing = required_dims - actual_dims
            raise ValueError(f"xarray must contain dimensions: {missing}")

        # Get features
        features = [str(f).lower() for f in data[feature_dim].values]
        if 'close' not in features:
            raise ValueError("xarray must contain 'close' in feature dimension")
        if exec_col not in features:
            raise ValueError(f"Feature '{exec_price}' not found in feature dimension")

        # Extract exec_price and close
        exec_idx = features.index(exec_col)
        close_idx = features.index('close')

        exec_data = data.isel({feature_dim: exec_idx})
        close_data = data.isel({feature_dim: close_idx})

        self._open = exec_data.to_pandas()
        self._close = close_data.to_pandas()
        self._open.index = pd.to_datetime(self._open.index)
        self._close.index = pd.to_datetime(self._close.index)

    def commission(self, commission: Tuple[float, float]) -> 'Strategy':
        """
        Set commission rates.

        Args:
            commission: (long_rate, short_rate)

        Example:
            .commission((0.001, 0.001))
        """
        self._commission = commission
        return self

    def benchmark(self, symbol: str) -> 'Strategy':
        """Set benchmark symbol."""
        self._benchmark = symbol
        return self

    def run(self) -> ResultStore:
        """Run backtest and return results."""
        if not all([
            isinstance(self._open, pd.DataFrame),
            isinstance(self._close, pd.DataFrame),
            isinstance(self._signal, pd.DataFrame),
        ]):
            raise ValueError("Please add signal and data first")

        self._align_signals()

        ret_strategy, hold = self._return_calculator.calculate(
            self._signal, self._open, self._close, self._commission
        )

        ret_all = ret_strategy.to_frame("strategy")

        self._process_benchmark(ret_all)

        self.result.nav = ret_all
        self.result.hold = hold[hold["stockid"] != "cash"].copy()
        self.result.signal = self._signal_processor.get_original_signal()
        self.result.benchmark = self._benchmark
        self.result.stats.turnover = self._calculate_turnover(len(ret_all))

        return self.result

    def _align_signals(self) -> None:
        """Align signal dates with available data dates."""
        idx = self._open.index if self.matching == "next_bar" else self._close.index
        idx = idx[(idx >= self.begin) & (idx <= self.end)]

        valid = self._signal.index.intersection(idx)
        self._signal = self._signal.loc[valid]

    def _process_benchmark(self, ret_all: pd.DataFrame) -> None:
        """Add benchmark, relative return and drawdown to results."""
        if self._benchmark:
            if self._benchmark not in self._close.columns:
                raise ValueError(f"Benchmark '{self._benchmark}' not found in data")

            # Benchmark NAV
            benchmark = self._close[self._benchmark].reindex(ret_all.index)
            ret_all[self._benchmark] = benchmark
            ret_all[self._benchmark] /= ret_all[self._benchmark].dropna().iloc[0]

            # Relative return (strategy / benchmark)
            ret_all["relative"] = ret_all["strategy"] / ret_all[self._benchmark]

            # Drawdown of relative return
            ret_all["drawdown"] = self._calculate_drawdown(ret_all["relative"])
        else:
            # Drawdown of strategy
            ret_all["drawdown"] = self._calculate_drawdown(ret_all["strategy"])

    @staticmethod
    def _calculate_drawdown(nav: pd.Series) -> pd.Series:
        """Calculate drawdown from NAV series."""
        rolling_max = nav.cummax()
        return nav / rolling_max - 1

    def _calculate_turnover(self, periods: int) -> float:
        """Calculate turnover."""
        return self._performance_analyzer.calculate_turnover(
            self._signal.drop(["cash"], axis=1, errors="ignore"), periods
        )

    def plot(self, log: bool = True, **kwargs) -> None:
        """
        Plot NAV and drawdown.

        Left axis: NAV (strategy or relative if benchmark provided)
        Right axis: Drawdown
        """
        import matplotlib.pyplot as plt

        nav = self.result.nav
        fontsize = kwargs.get("fontsize", 12)

        # Determine which series to plot
        if "relative" in nav.columns:
            main_nav = nav["relative"]
            main_label = "Relative"
        else:
            main_nav = nav["strategy"]
            main_label = "Strategy"

        drawdown = nav["drawdown"]

        fig, ax1 = plt.subplots(figsize=kwargs.get("figsize", (12, 6)))

        # Left axis: NAV
        if log:
            ax1.plot(main_nav.index, np.log(main_nav), label=main_label, color="blue")
            ax1.set_ylabel("Log NAV", fontsize=fontsize)
        else:
            ax1.plot(main_nav.index, main_nav, label=main_label, color="blue")
            ax1.set_ylabel("NAV", fontsize=fontsize)
        ax1.legend(loc="upper left", fontsize=fontsize)
        ax1.tick_params(axis='both', labelsize=fontsize)

        # Right axis: Drawdown
        ax2 = ax1.twinx()
        ax2.fill_between(drawdown.index, drawdown, 0, alpha=0.3, color="red", label="Drawdown")
        ax2.set_ylabel("Drawdown", fontsize=fontsize)
        ax2.legend(loc="lower left", fontsize=fontsize)
        ax2.tick_params(axis='y', labelsize=fontsize)

        ax1.set_title(f"{main_label} NAV & Drawdown", fontsize=fontsize)
        plt.tight_layout()
        plt.show()


if __name__ == "__main__":
    pass
