"""
Return calculator for vectorized backtesting. (State-Machine Zero-Allocation Version)
"""
from typing import Tuple, Optional
import pandas as pd
import numpy as np

from kepler.echo.types import MatchingType

class ReturnCalculator:
    def __init__(self, matching: str = "next_bar"):
        if not MatchingType.is_valid(matching):
            raise ValueError("matching must be next_bar or current_bar")
        self.matching = matching

    def calculate(
        self,
        signal: pd.DataFrame,
        open_data: pd.DataFrame,
        close_data: pd.DataFrame,
        commission: Tuple[float, float]
    ) -> Tuple[pd.Series, pd.DataFrame]:

        universe_returns = self._get_universe_returns(signal, open_data, close_data)

        if universe_returns.empty:
            return pd.Series(dtype=float), pd.DataFrame(columns=["date", "stockid", "weight"])

        trade_dt_list = universe_returns.index
        # 将调仓信号与收益率矩阵列对齐
        signal_tmp = signal.reindex(columns=universe_returns.columns).fillna(0)

        ur_vals = universe_returns.values
        target_weights = signal_tmp.values
        locs = trade_dt_list.get_indexer(signal_tmp.index)

        # 🚀 核心飞跃：进入纯 Numpy 状态机迭代，消灭所有二维大矩阵分配！
        daily_ret, commissions, final_weights = self._run_simulation(
            ur_vals, target_weights, locs, commission
        )

        ret_all = pd.Series(daily_ret, index=trade_dt_list)
        commission_cost = pd.Series(commissions, index=trade_dt_list)

        ret_all = ret_all + commission_cost

        # 最终资金曲线计算
        ret_all = np.exp(np.log1p(ret_all).cumsum())
        ret_all = ret_all[ret_all.index.second == 0]

        hold_last = self._extract_final_holdings(final_weights, universe_returns.columns, trade_dt_list[-1])

        return ret_all, hold_last

    @staticmethod
    def _run_simulation(
        ur_vals: np.ndarray,
        target_weights: np.ndarray,
        locs: np.ndarray,
        commission: Tuple[float, float]
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """纯一维状态机推演，内存占用从 1GB 降至 100KB"""
        T, N = ur_vals.shape

        daily_ret = np.zeros(T, dtype=np.float64)
        commissions = np.zeros(T, dtype=np.float64)

        # 仅维护当天的一维权重（长度5000）
        current_weights = np.zeros(N, dtype=np.float64)

        # 预处理调仓日映射
        is_rebalance = np.zeros(T, dtype=bool)
        rebalance_targets = np.zeros((T, N), dtype=np.float64)

        valid_locs = locs >= 0
        is_rebalance[locs[valid_locs]] = True
        rebalance_targets[locs[valid_locs]] = target_weights[valid_locs]

        # 每日步进推演
        for t in range(T):
            if t > 0:
                # 1. np.dot 底层 C 加速计算当天组合收益
                daily_ret[t] = np.dot(current_weights, ur_vals[t-1])

            if is_rebalance[t]:
                # 2A. 触发调仓
                target = rebalance_targets[t]
                diff = target - current_weights

                # 极速手续费计算 (仅对变动部分切片)
                long_diff = diff[diff > 0]
                short_diff = -diff[diff < 0]

                commissions[t] = (-np.sum(long_diff) * commission[0]
                                  - np.sum(short_diff) * commission[1])

                # 更新为目标权重
                current_weights = target.copy()
            else:
                # 2B. 无调仓日：权重随当天收益率自然漂移 (原地乘法，零分配)
                if t > 0:
                    current_weights *= (1.0 + ur_vals[t-1])

        return daily_ret, commissions, current_weights

    def _get_universe_returns(self, signal: pd.DataFrame, open_data: pd.DataFrame, close_data: pd.DataFrame) -> pd.DataFrame:
        df = close_data.reindex(columns=signal.columns)
        if self.matching == MatchingType.NEXT_BAR:
            df_o = open_data.reindex(index=signal.index, columns=signal.columns)
            df = pd.concat([df, df_o], axis=0, sort=False)
            df.sort_index(inplace=True)

        vals = df.values
        pct_vals = np.empty_like(vals)
        with np.errstate(divide='ignore', invalid='ignore'):
            pct_vals[0] = np.nan
            pct_vals[1:] = vals[1:] / vals[:-1] - 1.0

        # ==========================================================
        # 🚀 核心数据清洗防线：彻底阻断价格为 0 导致的虚假收益！
        # 如果昨天的价格为 0，或者今天的价格为 0，收益率强制设为 0.0
        # 这完美防御了 VWAP(10) -> Close(0) 产生的 -100% 暴利漏洞
        zero_mask = (vals[:-1] == 0) | (vals[1:] == 0)
        pct_vals[1:][zero_mask] = 0.0
        # ==========================================================

        pct_vals[np.isinf(pct_vals)] = 0
        shifted_pct = np.roll(pct_vals, -1, axis=0)
        if shifted_pct.shape[0] > 0:
            shifted_pct[-1] = 0

        shifted_pct = np.nan_to_num(shifted_pct, nan=0.0)
        return pd.DataFrame(shifted_pct, index=df.index, columns=df.columns)

    def _extract_final_holdings(self, last_row_vals: np.ndarray, columns: pd.Index, date: pd.Timestamp) -> pd.DataFrame:
        mask = np.abs(last_row_vals) > 1e-6
        if not np.any(mask):
            return pd.DataFrame(columns=["date", "stockid", "weight"])

        hold_last = pd.DataFrame({
            'stockid': columns[mask],
            'weight': last_row_vals[mask]
        })
        hold_last['date'] = date
        hold_last = hold_last.sort_values('weight', ascending=False, key=abs)
        return hold_last
