"""
Kepler Echo - Vector Backtesting Framework

A lightweight, high-performance vector backtesting framework for quantitative strategies.
"""

from kepler.echo.strategy import Strategy
from kepler.echo.exceptions import (
    KeplerEchoError,
    DataError,
    SignalError,
    ConfigurationError,
    BacktestError,
)

__version__ = "0.2.0"

__all__ = [
    "Strategy",
    "KeplerEchoError",
    "DataError",
    "SignalError",
    "ConfigurationError",
    "BacktestError",
]
