"""Socrates test suite"""
