# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2024-03-21

### Added
- Initial PyPI release of socrates-ai
- Core Socratic method tutoring system with Claude AI integration
- Multi-agent orchestration system
- RAG (Retrieval-Augmented Generation) support
- Project context management
- Workflow builder for defining learning paths
- Question selector for adaptive questioning
- Code structure analysis and code extraction
- File change tracking and Git integration
- Dependency validation
- Comprehensive test suite (500+ tests)
- FastAPI integration for building applications
- Vector database support via ChromaDB
- Database operations with SQLAlchemy
- User authentication with JWT and bcrypt
- Rate limiting with SlowAPI
- Prometheus metrics support
- Docker and Kubernetes ready
- GitHub integration and export capabilities

### Features
- Socratic method-based tutoring
- Multi-agent system for complex tasks
- RAG with sentence transformers and ChromaDB
- Real-time collaboration support
- Knowledge management system
- Project lifecycle management
- Code generation and validation
- Git repository management
- Workflow and questionnaire support
- User and subscription management
- Chat sessions and message history
- Project invitations and collaboration
- Activity logging and analytics
- Performance monitoring
- Security features (encryption, password hashing)

### Documentation
- Comprehensive README
- Setup and installation guide
- API documentation
- Contributing guidelines

### Testing
- 500+ comprehensive tests across all modules
- Unit tests for core functionality
- Integration tests for multi-module workflows
- End-to-end scenario testing
- 50%+ code coverage

## [Unreleased]

### Planned Features
- Advanced workflow orchestration
- Enhanced RAG capabilities
- Real-time streaming responses
- Advanced analytics dashboard
- Enterprise features
- Plugin system for extensibility
