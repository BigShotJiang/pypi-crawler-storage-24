import os
import time


def print_time(func):
    def inner(*args, **kwargs):
        old_time = time.time()
        result = func(*args, **kwargs)
        func_name = str(func).split(' ')[1]
        print('{}: <{}> use time: {}s'.format(os.getpid(), func_name, time.time() - old_time))
        return result

    return inner
