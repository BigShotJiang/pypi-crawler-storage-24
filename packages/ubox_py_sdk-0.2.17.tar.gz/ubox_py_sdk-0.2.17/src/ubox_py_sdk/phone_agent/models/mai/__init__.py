"""MAI-UI 模型实现模块。"""

from .adapter import MAIAdapter
from .prompts import SYSTEM_PROMPT

__all__ = [
    # 适配器
    "MAIAdapter",
    # 提示词
    "SYSTEM_PROMPT",
]
