"""AutoGLM 模型适配器实现。"""

import ast
import re
import time
from typing import Any, Dict, Generator, List, Optional

from openai import OpenAI

from ubox_py_sdk.logger import get_logger

from ..base import (
    HandlerAction,
    BaseModelAdapter,
    MessageDict,
    ModelResponse,
)
from ..registry import ModelConfig
from .prompts import SYSTEM_PROMPT, EXTRACT_DESC_PROMPT

logger = get_logger("ubox_py_sdk.phone_agent.models.autoglm")


class AutoGLMAdapter(BaseModelAdapter):
    """AutoGLM-Phone 模型适配器。
    
    专门针对 AutoGLM-Phone 系列模型优化的适配器，支持：
    - 视觉输入（截图）
    - 流式输出
    - 思考过程和动作分离
    - 0-1000 相对坐标系统
    
    Attributes:
        client: OpenAI 客户端实例
    """
    
    def __init__(self, config: Optional[ModelConfig] = None):
        """初始化 AutoGLM 适配器。
        
        Args:
            config: 模型配置，如果为 None 则使用默认配置
        """
        # 如果没有提供配置，使用默认的 ModelConfig
        if config is None:
            config = ModelConfig()
        super().__init__(config)
        self.client = OpenAI(
            base_url=self.config.base_url, 
            api_key=self.config.api_key
        )
    
    @property
    def name(self) -> str:
        """返回适配器名称。"""
        return "AutoGLM"
    
    def get_system_prompt(self) -> str:
        """获取 AutoGLM 模型的系统提示词。
        
        系统提示词定义在 prompts.py 中，是模型实现的核心部分，
        包含了操作指令格式、规则说明、探索性测试规则等关键内容。
        
        注意：系统提示词不建议外部修改，因为它影响模型输出的格式和内容解析。
        
        Returns:
            系统提示词字符串
        """
        return SYSTEM_PROMPT
    
    def request_stream(
        self, 
        messages: List[MessageDict]
    ) -> Generator[str, None, None]:
        """向 AutoGLM 模型发送流式请求。
        
        Args:
            messages: 消息列表
            
        Yields:
            思考过程的文本块
        """
        start_time = time.time()
        time_to_first_token = None
        time_to_thinking_end = None
        first_token_received = False
        
        stream = self.client.chat.completions.create(
            messages=messages,
            model=self.config.model_name,
            max_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            top_p=self.config.top_p,
            frequency_penalty=self.config.frequency_penalty,
            extra_body=self.config.extra_body,
            stream=True,
        )
        
        raw_content = ""
        buffer = ""
        action_markers = ["finish(message=", "do(action="]
        in_action_phase = False
        usage_info = None
        
        for chunk in stream:
            if hasattr(chunk, 'usage') and chunk.usage is not None:
                usage_info = chunk.usage
            
            if len(chunk.choices) == 0:
                continue
            if chunk.choices[0].delta.content is not None:
                content = chunk.choices[0].delta.content
                raw_content += content
                
                if not first_token_received:
                    time_to_first_token = time.time() - start_time
                    first_token_received = True
                
                if in_action_phase:
                    continue
                
                buffer += content
                
                marker_found = False
                for marker in action_markers:
                    if marker in buffer:
                        thinking_part = buffer.split(marker, 1)[0]
                        if thinking_part:
                            yield thinking_part
                        in_action_phase = True
                        marker_found = True
                        
                        if time_to_thinking_end is None:
                            time_to_thinking_end = time.time() - start_time
                        break
                
                if marker_found:
                    continue
                
                is_potential_marker = False
                for marker in action_markers:
                    for i in range(1, len(marker)):
                        if buffer.endswith(marker[:i]):
                            is_potential_marker = True
                            break
                    if is_potential_marker:
                        break
                
                if not is_potential_marker and buffer:
                    yield buffer
                    buffer = ""
        
        total_time = time.time() - start_time
        
        thinking, action = self._parse_response(raw_content)
        
        # 提取 token 使用信息
        prompt_tokens = None
        completion_tokens = None
        total_tokens = None
        if usage_info:
            prompt_tokens = getattr(usage_info, 'prompt_tokens', None)
            completion_tokens = getattr(usage_info, 'completion_tokens', None)
            total_tokens = getattr(usage_info, 'total_tokens', None)
        
        self._last_response = ModelResponse(
            thinking=thinking,
            action=action,
            raw_content=raw_content,
            time_to_first_token=time_to_first_token,
            time_to_thinking_end=time_to_thinking_end,
            total_time=total_time,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        )
        
        logger.debug("")
        logger.debug("=" * 50)
        logger.debug("⏱️  性能指标:")
        logger.debug("-" * 50)
        if time_to_first_token is not None:
            logger.debug(f"首 Token 延迟 (TTFT): {time_to_first_token:.3f}s")
        if time_to_thinking_end is not None:
            logger.debug(f"思考完成延迟:        {time_to_thinking_end:.3f}s")
        logger.debug(f"总推理时间:          {total_time:.3f}s")
        if total_tokens is not None:
            logger.debug("")
            logger.debug("📊 Token统计:")
            logger.debug("-" * 50)
            if prompt_tokens is not None:
                logger.debug(f"输入 Token:          {prompt_tokens}")
            if completion_tokens is not None:
                logger.debug(f"输出 Token:          {completion_tokens}")
            if total_tokens is not None:
                logger.debug(f"总 Token:            {total_tokens}")
        logger.debug("=" * 50)
    
    def get_last_response(self) -> Optional[ModelResponse]:
        """获取最后一次请求的完整响应。"""
        return self._last_response
    
    def parse_action(self, response: str) -> HandlerAction:
        """解析 AutoGLM 模型输出的动作。
        
        支持两种格式：
        1. do(action="...", element=[x,y], desc="...")
        2. finish(message="...")
        
        Args:
            response: 模型响应中的动作部分
            
        Returns:
            解析后的动作字典
            
        Raises:
            ValueError: 如果动作无法解析
        """
        try:
            response = response.strip()
            if response.startswith("do"):
                try:
                    # 处理转义字符
                    response = response.replace('\n', '\\n')
                    response = response.replace('\r', '\\r')
                    response = response.replace('\t', '\\t')
                    
                    tree = ast.parse(response, mode="eval")
                    if not isinstance(tree.body, ast.Call):
                        raise ValueError("期望一个函数调用")
                    
                    call = tree.body
                    action = {"_metadata": "do"}
                    for keyword in call.keywords:
                        key = keyword.arg
                        value = ast.literal_eval(keyword.value)
                        action[key] = value
                    
                    return action
                except (SyntaxError, ValueError) as e:
                    raise ValueError(f"解析 do() 动作失败: {e}")
            
            elif response.startswith("finish"):
                action = {
                    "_metadata": "finish",
                    "message": response.replace("finish(message=", "")[1:-2],
                }
            else:
                raise ValueError("解析动作失败: 模型没有明确描述要执行的 action")
            return action
        except Exception as e:
            raise ValueError(f"解析动作失败: {e}")
    
    def build_user_message(
        self, 
        text: str, 
        image_base64: Optional[str] = None,
        mime_type: str = "image/png"
    ) -> MessageDict:
        """构建用户消息。
        
        Args:
            text: 文本内容
            image_base64: 可选的 base64 编码图片
            mime_type: 图片的 MIME 类型，默认为 "image/png"
            
        Returns:
            用户消息字典
        """
        content = []
        
        if image_base64:
            content.append({
                "type": "image_url",
                "image_url": {"url": f"data:{mime_type};base64,{image_base64}"},
            })
        
        content.append({"type": "text", "text": text})
        
        return {"role": "user", "content": content}
    
    def build_assistant_message(
        self, 
        thinking: str, 
        action: str
    ) -> MessageDict:
        """构建助手消息。
        
        AutoGLM 使用 <think>...</think><answer>...</answer> 格式。
        
        Args:
            thinking: 思考过程
            action: 执行的动作
            
        Returns:
            助手消息字典
        """
        content = f"<think>{thinking}</think><answer>{action}</answer>"
        return {"role": "assistant", "content": content}
    
    def _parse_response(self, content: str) -> tuple[str, str]:
        """将模型响应解析为思考和动作部分。
        
        解析规则：
        1. 如果内容包含 'finish(message='，之前的所有内容为思考部分
        2. 如果内容包含 'do(action='，之前的所有内容为思考部分
        3. 回退到传统的 XML 标签解析
        
        Args:
            content: 原始响应内容
            
        Returns:
            (思考, 动作) 元组
        """
        # 规则1：检查 finish(message=
        if "finish(message=" in content:
            parts = content.split("finish(message=", 1)
            thinking = parts[0].strip()
            action = "finish(message=" + parts[1]
            return thinking, action
        
        # 规则2：检查 do(action=
        if "do(action=" in content:
            parts = content.split("do(action=", 1)
            thinking = parts[0].strip()
            action = "do(action=" + parts[1]
            return thinking, action
        
        # 规则3：回退到传统的 XML 标签解析
        thinking = ""
        action = ""
        
        if "<think>" in content:
            thinking_match = re.search(r'<think>(.*?)</think>', content, re.DOTALL)
            if thinking_match:
                thinking = thinking_match.group(1).strip()
        
        if "<answer>" in content:
            answer_match = re.search(r'<answer>(.*?)</answer>', content, re.DOTALL)
            if answer_match:
                action = answer_match.group(1).strip()
        
        if thinking or action:
            return thinking, action
        
        # 规则4：未找到标记，返回内容作为动作
        return "", content
    
    def extract_description_from_thinking(
        self, 
        thinking: str
    ) -> tuple[Optional[str], Optional[Dict[str, int]]]:
        """从思考内容中提取操作描述。
        
        使用模型进行简短描述提取，比规则提取更灵活准确。
        
        Args:
            thinking: 模型的思考内容
            
        Returns:
            (操作描述, token 消耗信息) 元组
        """
        if not thinking or not thinking.strip():
            return None, None
        
        try:
            prompt = EXTRACT_DESC_PROMPT.format(thinking=thinking.strip())
            
            response = self.client.chat.completions.create(
                messages=[{"role": "user", "content": prompt}],
                model=self.config.model_name,
                max_tokens=50,
                temperature=0.0,
                stream=False,
            )
            
            # 提取 token 统计
            token_info = self._extract_token_info(response)
            
            # 解析并清理描述
            desc = self._parse_description(response)
            
            return desc, token_info
            
        except Exception as e:
            logger.debug(f"模型提取操作描述时出错: {e}")
            return None, None
    
    def _extract_token_info(self, response) -> Optional[Dict[str, int]]:
        """从响应中提取 token 统计信息。"""
        if not hasattr(response, 'usage') or not response.usage:
            return None
        
        return {
            "prompt_tokens": getattr(response.usage, 'prompt_tokens', None),
            "completion_tokens": getattr(response.usage, 'completion_tokens', None),
            "total_tokens": getattr(response.usage, 'total_tokens', None),
        }
    
    def _parse_description(self, response) -> Optional[str]:
        """解析并清理模型返回的描述。"""
        if not response.choices or len(response.choices) == 0:
            return None
        
        desc = response.choices[0].message.content
        if not desc:
            return None
        
        desc = desc.strip()
        
        # 清理常见前缀
        prefixes_to_remove = ["操作描述：", "操作描述:", "描述：", "描述:"]
        for prefix in prefixes_to_remove:
            if desc.startswith(prefix):
                desc = desc[len(prefix):].strip()
        
        # 取第一行（避免多行输出）
        desc = desc.split('\n')[0].strip()
        
        # 清理末尾标点
        desc = desc.rstrip('。.，,')
        
        # 校验长度
        if desc and 3 <= len(desc) <= 50:
            return desc
        
        return None
