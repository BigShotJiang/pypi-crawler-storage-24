"""Phone Agent 的通用配置模块。

此模块包含与模型无关的通用配置，如时序配置等。

注意：
- 应用映射表 (APP_PACKAGES) 已移至 phone_agent/apps.py
- 模型相关的配置（系统提示词等）在 models/ 目录下的各模型子目录
"""

from .timing import (
    TIMING_CONFIG,
    ActionTimingConfig,
    DeviceTimingConfig,
    TimingConfig,
    get_timing_config,
    update_timing_config,
)

__all__ = [
    # 时序配置
    "TIMING_CONFIG",
    "TimingConfig",
    "ActionTimingConfig",
    "DeviceTimingConfig",
    "get_timing_config",
    "update_timing_config",
]
