"""应用包名映射表（通用资源）。

此文件包含应用名称到包名/Bundle ID 的映射，用于 Launch 操作时的应用识别。
包含 Android、iOS、HarmonyOS 三个平台的应用映射。

此映射表是所有模型共用的通用资源，不属于特定模型实现。
"""

from typing import Optional


# Android 应用包名映射
APP_PACKAGES_ANDROID: dict[str, str] = {
    # Social & Messaging
    "微信": "com.tencent.mm",
    "QQ": "com.tencent.mobileqq",
    "微博": "com.sina.weibo",
    # E-commerce
    "淘宝": "com.taobao.taobao",
    "京东": "com.jingdong.app.mall",
    "拼多多": "com.xunmeng.pinduoduo",
    "淘宝闪购": "com.taobao.taobao",
    "京东秒送": "com.jingdong.app.mall",
    # Lifestyle & Social
    "小红书": "com.xingin.xhs",
    "豆瓣": "com.douban.frodo",
    "知乎": "com.zhihu.android",
    # Maps & Navigation
    "高德地图": "com.autonavi.minimap",
    "百度地图": "com.baidu.BaiduMap",
    # Food & Services
    "美团": "com.sankuai.meituan",
    "大众点评": "com.dianping.v1",
    "饿了么": "me.ele",
    "肯德基": "com.yek.android.kfc.activitys",
    # Travel
    "携程": "ctrip.android.view",
    "铁路12306": "com.MobileTicket",
    "12306": "com.MobileTicket",
    "去哪儿": "com.Qunar",
    "去哪儿旅行": "com.Qunar",
    "滴滴出行": "com.sdu.didi.psnger",
    # Video & Entertainment
    "bilibili": "tv.danmaku.bili",
    "抖音": "com.ss.android.ugc.aweme",
    "快手": "com.smile.gifmaker",
    "腾讯视频": "com.tencent.qqlive",
    "爱奇艺": "com.qiyi.video",
    "优酷视频": "com.youku.phone",
    "芒果TV": "com.hunantv.imgo.activity",
    "红果短剧": "com.phoenix.read",
    # Music & Audio
    "网易云音乐": "com.netease.cloudmusic",
    "QQ音乐": "com.tencent.qqmusic",
    "汽水音乐": "com.luna.music",
    "喜马拉雅": "com.ximalaya.ting.android",
    # Reading
    "番茄小说": "com.dragon.read",
    "番茄免费小说": "com.dragon.read",
    "七猫免费小说": "com.kmxs.reader",
    # Productivity
    "飞书": "com.ss.android.lark",
    "QQ邮箱": "com.tencent.androidqqmail",
    # AI & Tools
    "豆包": "com.larus.nova",
    # Health & Fitness
    "keep": "com.gotokeep.keep",
    "美柚": "com.lingan.seeyou",
    # News & Information
    "腾讯新闻": "com.tencent.news",
    "今日头条": "com.ss.android.article.news",
    # Real Estate
    "贝壳找房": "com.lianjia.beike",
    "安居客": "com.anjuke.android.app",
    # Finance
    "同花顺": "com.hexin.plat.android",
    # Games
    "星穹铁道": "com.miHoYo.hkrpg",
    "崩坏：星穹铁道": "com.miHoYo.hkrpg",
    "恋与深空": "com.papegames.lysk.cn",
    # System
    "AndroidSystemSettings": "com.android.settings",
    "Android System Settings": "com.android.settings",
    "Settings": "com.android.settings",
    "AudioRecorder": "com.android.soundrecorder",
    "Chrome": "com.android.chrome",
    "Google Chrome": "com.android.chrome",
    "Clock": "com.android.deskclock",
    "Contacts": "com.android.contacts",
    "Files": "com.android.fileexplorer",
    "Gmail": "com.google.android.gm",
    "Google Maps": "com.google.android.apps.maps",
    "Google Play Store": "com.android.vending",
    # International Apps
    "Telegram": "org.telegram.messenger",
    "Temu": "com.einnovation.temu",
    "Tiktok": "com.zhiliaoapp.musically",
    "Twitter": "com.twitter.android",
    "X": "com.twitter.android",
    "WhatsApp": "com.whatsapp",
    "WeChat": "com.tencent.mm",
}


# iOS 应用 Bundle ID 映射
APP_PACKAGES_IOS: dict[str, str] = {
    # Social & Messaging
    "微信": "com.tencent.xin",
    "QQ": "com.tencent.mqq",
    "微博": "com.sina.weibo",
    # E-commerce
    "淘宝": "com.taobao.taobao4iphone",
    "京东": "com.360buy.jdmobile",
    "拼多多": "com.xunmeng.pinduoduo",
    # Lifestyle & Social
    "小红书": "com.xingin.discover",
    "豆瓣": "com.douban.frodo",
    "知乎": "com.zhihu.ios",
    # Maps & Navigation
    "高德地图": "com.autonavi.amap",
    "百度地图": "com.baidu.map",
    # Food & Services
    "美团": "com.meituan.imeituan",
    "大众点评": "com.dianping.dpscope",
    "饿了么": "me.ele.ios.eleme",
    # Travel
    "携程": "ctrip.com",
    "12306": "com.MobileTicket",
    "滴滴出行": "com.xiaojukeji.didi",
    # Video & Entertainment
    "bilibili": "tv.danmaku.bilianime",
    "抖音": "com.ss.iphone.ugc.Aweme",
    "快手": "com.jiangjia.gif",
    "腾讯视频": "com.tencent.live4iphone",
    "爱奇艺": "com.qiyi.iphone",
    # Music & Audio
    "网易云音乐": "com.netease.cloudmusic",
    "QQ音乐": "com.tencent.QQMusic",
    # System
    "Safari": "com.apple.mobilesafari",
    "Settings": "com.apple.Preferences",
    "App Store": "com.apple.AppStore",
    "Maps": "com.apple.Maps",
}


# HarmonyOS 应用包名映射
APP_PACKAGES_HARMONYOS: dict[str, str] = {
    # Social & Messaging
    "微信": "com.tencent.mm",
    "QQ": "com.tencent.mobileqq",
    "微博": "com.sina.weibo",
    # E-commerce
    "淘宝": "com.taobao.taobao",
    "京东": "com.jingdong.app.mall",
    "拼多多": "com.xunmeng.pinduoduo",
    # Lifestyle & Social
    "小红书": "com.xingin.xhs",
    "知乎": "com.zhihu.android",
    # Maps & Navigation
    "高德地图": "com.autonavi.minimap",
    "百度地图": "com.baidu.BaiduMap",
    # Food & Services
    "美团": "com.sankuai.meituan",
    "大众点评": "com.dianping.v1",
    "饿了么": "me.ele",
    # Video & Entertainment
    "bilibili": "tv.danmaku.bili",
    "抖音": "com.ss.android.ugc.aweme",
    "快手": "com.smile.gifmaker",
    "腾讯视频": "com.tencent.qqlive",
    # Music & Audio
    "网易云音乐": "com.netease.cloudmusic",
    "QQ音乐": "com.tencent.qqmusic",
    # System
    "Settings": "com.huawei.settings",
    "AppGallery": "com.huawei.appmarket",
}


# 默认使用 Android 映射（向后兼容）
APP_PACKAGES = APP_PACKAGES_ANDROID


def get_package_name(app_name: str, platform: str = "android") -> Optional[str]:
    """根据应用名称获取包名/Bundle ID。
    
    Args:
        app_name: 应用名称
        platform: 平台类型，可选值：android, ios, harmonyos
        
    Returns:
        包名/Bundle ID，如果未找到则返回 None
    """
    platform_map = {
        "android": APP_PACKAGES_ANDROID,
        "ios": APP_PACKAGES_IOS,
        "harmonyos": APP_PACKAGES_HARMONYOS,
    }
    packages = platform_map.get(platform.lower(), APP_PACKAGES_ANDROID)
    return packages.get(app_name)


def get_app_name(package_name: str, platform: str = "android") -> Optional[str]:
    """根据包名/Bundle ID 获取应用名称。
    
    Args:
        package_name: 包名/Bundle ID
        platform: 平台类型，可选值：android, ios, harmonyos
        
    Returns:
        应用名称，如果未找到则返回 None
    """
    platform_map = {
        "android": APP_PACKAGES_ANDROID,
        "ios": APP_PACKAGES_IOS,
        "harmonyos": APP_PACKAGES_HARMONYOS,
    }
    packages = platform_map.get(platform.lower(), APP_PACKAGES_ANDROID)
    for name, package in packages.items():
        if package == package_name:
            return name
    return None


def list_supported_apps(platform: str = "android") -> list[str]:
    """获取支持的应用列表。
    
    Args:
        platform: 平台类型，可选值：android, ios, harmonyos
        
    Returns:
        支持的应用名称列表
    """
    platform_map = {
        "android": APP_PACKAGES_ANDROID,
        "ios": APP_PACKAGES_IOS,
        "harmonyos": APP_PACKAGES_HARMONYOS,
    }
    packages = platform_map.get(platform.lower(), APP_PACKAGES_ANDROID)
    return list(packages.keys())
