# Phone Agent 模块

Phone Agent 是一个基于大语言模型的手机自动化操作框架，支持多种模型适配器。

## 设计理念

**每个模型单独配置，清晰明确**

- 每个模型单独配置服务地址、密钥和参数
- Agent 的行为逻辑由模型类型（ModelType）决定
- 支持多模型配置，可在运行时切换

## 目录结构

```
phone_agent/
├── __init__.py             # 模块入口，导出所有公共接口
├── agent.py                # Agent 核心实现
├── device_interface.py     # 设备接口定义
├── apps.py                 # 应用包名映射（通用资源，所有模型共用）
├── README.md               # 本文档
├── actions/                # 动作处理模块
│   ├── __init__.py
│   └── handler.py         # 动作执行处理器
├── config/                 # 通用配置
│   ├── __init__.py
│   └── timing.py          # 时序配置
└── models/                 # 模型实现目录
    ├── __init__.py        # 导出所有模型相关内容
    ├── base.py            # 基础类（BaseModelAdapter, ModelResponse）
    ├── registry.py        # 模型注册表、ModelType、ModelConfig、AgentModelConfig、create_adapter
    └── autoglm/           # AutoGLM 模型实现
        ├── __init__.py
        ├── adapter.py     # 适配器实现
        └── prompts.py     # 系统提示词
```

## 使用方式

### 基本用法

```python
from ubox_py_sdk.phone_agent import (
    ExplorationAgent,
    ModelType,
    ModelConfig,
    AgentModelConfig
)

# 配置模型
config = AgentModelConfig(
    model=ModelType.AUTOGLM_PHONE_9B,
    models={
        ModelType.AUTOGLM_PHONE_9B: ModelConfig(
            base_url="http://localhost:8000/v1"
        ),
    }
)

# 创建并使用 Agent
agent = ExplorationAgent(model_config=config, device=device)
for update in agent.run_stream("打开微信"):
    if update.update_type == "thinking":
        print(f"思考: {update.content}")
    elif update.update_type == "action":
        print(f"动作: {update.content}")
    elif update.update_type == "finished":
        print(f"完成: {update.content.get('message')}")
```

### 配置多个模型（可运行时切换）

```python
from ubox_py_sdk.phone_agent import (
    ExplorationAgent,
    ModelType,
    ModelConfig,
    AgentModelConfig
)

# 配置多个模型
config = AgentModelConfig(
    model=ModelType.AUTOGLM_PHONE_9B,  # 当前使用的模型
    models={
        ModelType.AUTOGLM_PHONE_9B: ModelConfig(
            base_url="http://localhost:8000/v1"
        ),
        ModelType.MAI_UI_8B: ModelConfig(
            base_url="https://api.example.com/v1",
            api_key="your-api-key",
            model_name="MAI-v2",  # 可选，指定实际请求的模型名称
            max_tokens=4000
        ),
    }
)

agent = ExplorationAgent(model_config=config, device=device)

```

### 使用应用映射

```python
from ubox_py_sdk.phone_agent import get_package_name, list_supported_apps

# 获取应用包名
android_package = get_package_name("微信", platform="android")  # com.tencent.mm
ios_bundle_id = get_package_name("微信", platform="ios")        # com.tencent.xin

# 获取支持的应用列表
apps = list_supported_apps(platform="android")
```

---

## 扩展新模型指南

### 场景1：添加同一适配器类型的新模型

如果新模型使用与现有模型相同的 API 协议（如都是 OpenAI 兼容格式），只需：

1. **在 `ModelType` 枚举中添加新模型**

```python
# models/registry.py
class ModelType(Enum):
    AUTOGLM_PHONE_9B = "autoglm-phone-9b"
    MY_NEW_MODEL = "my-new-model"  # 新增
```

2. **在 `_MODEL_ADAPTER_TYPE` 中注册映射**

```python
# models/registry.py
_MODEL_ADAPTER_TYPE: Dict[ModelType, str] = {
    ModelType.AUTOGLM_PHONE_9B: "autoglm",
    ModelType.MY_NEW_MODEL: "autoglm",  # 使用已有的 autoglm 适配器
}
```

3. **使用新模型**

```python
config = AgentModelConfig(
    model=ModelType.MY_NEW_MODEL,
    models={
        ModelType.MY_NEW_MODEL: ModelConfig(
            base_url="http://my-server:8000/v1"
        ),
    }
)
```

### 场景2：添加全新的适配器类型

如果新模型需要不同的 API 协议或处理逻辑，需要创建新的适配器：

#### 步骤 1：创建模型目录

```
models/
└── qwen/
    ├── __init__.py
    ├── adapter.py
    └── prompts.py
```

#### 步骤 2：创建适配器 (`adapter.py`)

```python
"""Qwen-VL 模型适配器实现。"""

from typing import Generator, List, Optional
from openai import OpenAI

from ..base import BaseModelAdapter, MessageDict, ModelResponse
from ..registry import ModelConfig
from .prompts import SYSTEM_PROMPT

class QwenVLAdapter(BaseModelAdapter):
    """Qwen-VL 模型适配器。"""
    
    def __init__(self, config: ModelConfig):
        super().__init__(config)
        self._client = OpenAI(
            api_key=config.api_key,
            base_url=config.base_url
        )
    
    @property
    def name(self) -> str:
        return "Qwen-VL"
    
    def get_system_prompt(self) -> str:
        return SYSTEM_PROMPT
    
    # 实现其他抽象方法...
```

#### 步骤 3：创建系统提示词 (`prompts.py`)

```python
"""Qwen-VL 模型系统提示词。"""

SYSTEM_PROMPT = """你是一个手机操作助手...
# 根据模型特点定义输出格式
"""
```

#### 步骤 4：注册适配器

```python
# models/registry.py

# 1. 添加模型类型
class ModelType(Enum):
    QWEN_VL_7B = "qwen-vl-7b"

# 2. 注册模型到适配器类型映射
_MODEL_ADAPTER_TYPE[ModelType.QWEN_VL_7B] = "qwen"

# 3. 在 _ensure_registry_initialized 中注册适配器类
def _ensure_registry_initialized():
    from .autoglm import AutoGLMAdapter
    from .qwen import QwenVLAdapter  # 新增
    
    _ADAPTER_REGISTRY = {
        "autoglm": AutoGLMAdapter,
        "qwen": QwenVLAdapter,  # 新增
    }
```

---

## 配置类说明

### ModelConfig

单个模型的服务配置：

```python
@dataclass
class ModelConfig:
    base_url: str = "http://localhost:8000/v1"  # API 地址
    api_key: str = "EMPTY"                       # API 密钥
    model_name: Optional[str] = None             # 实际请求时的模型名称（可选）
    max_tokens: int = 3000                       # 最大 token 数
    temperature: float = 0.0                     # 温度参数
    top_p: float = 0.85                          # Top-p 采样
    frequency_penalty: float = 0.2               # 频率惩罚
    extra_body: Dict[str, Any] = field(...)     # 额外参数
```

**关于 `model_name`**：
- 如果不设置（None），则使用 `ModelType` 的 value（如 `"autoglm-phone-9b"`）
- 如果设置，则使用指定的名称请求服务（如某云服务商要求传 `"autoglm-9b-v1"`）

### AgentModelConfig

Agent 模型配置：

```python
@dataclass
class AgentModelConfig:
    model: ModelType = ModelType.AUTOGLM_PHONE_9B
    """当前使用的模型类型。"""
    
    models: Dict[ModelType, ModelConfig] = field(default_factory=dict)
    """模型配置字典，每个模型单独配置服务地址、密钥等参数。"""
```

**方法**：
- `get_model_config(model)`: 获取指定模型的配置
- `get_adapter_config(model)`: 获取带有实际 `model_name` 的配置（供适配器使用）
- `with_model(model)`: 创建使用指定模型的新配置

---

## 适配器接口说明

所有模型适配器必须继承 `BaseModelAdapter` 并实现以下抽象方法：

| 方法 | 说明 |
|------|------|
| `name` | 属性，返回适配器名称 |
| `get_system_prompt()` | 返回该模型专用的系统提示词 |
| `request_stream(messages)` | 流式请求模型，返回思考过程 |
| `get_last_response()` | 获取最后一次请求的完整响应 |
| `parse_action(response)` | 解析模型输出的动作 |
| `build_user_message(text, image_base64)` | 构建用户消息 |
| `build_assistant_message(thinking, action)` | 构建助手消息 |

### ModelResponse 格式

```python
@dataclass
class ModelResponse:
    thinking: str           # 思考过程
    action: str             # 动作字符串
    raw_content: str        # 原始响应
    # 性能指标
    time_to_first_token: Optional[float]
    total_time: Optional[float]
    # Token 统计
    prompt_tokens: Optional[int]
    completion_tokens: Optional[int]
    total_tokens: Optional[int]
```

---

## 注意事项

1. **系统提示词**：每个模型的系统提示词是其实现的核心部分，影响输出格式的解析。不建议用户修改，只允许通过 `rules` 参数补充额外规则，或通过 `system_prompt` 参数完全替换（高级用法，需谨慎）。

2. **应用映射**：应用包名映射 (`apps.py`) 是所有模型共用的通用资源，位于 `phone_agent/` 根目录下。

3. **多模型配置**：使用 `models` 字典为每个模型单独配置，运行时通过 `model` 参数或 `switch_model()` 方法切换。
