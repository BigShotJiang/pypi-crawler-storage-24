#!/usr/bin/env bash
# 作者: ingerma
# 功能: 检测本地连接的手机设备状态, 输出 Prometheus metrics

# 遇到管道错误时失败, 但允许单个命令失败后继续处理其它设备
set -o pipefail

# ==============================
# 1. 检测当前操作系统
# ==============================
HOST_UNAME=$(uname -s)

case "$HOST_UNAME" in
  Darwin)
    # macOS 系统
    HOST_OS="darwin"
    ;;
  Linux)
    # Linux 系统
    HOST_OS="linux"
    ;;
  *)
    # 不支持的系统直接输出空指标头并退出
    echo "# Unsupported OS: $HOST_UNAME" >&2
    metrics=$(cat <<'EOF'
# HELP utest_device_status 本地手机设备状态 (1=正常,0=异常)
# TYPE utest_device_status gauge
EOF
)
    echo "$metrics"
    exit 0
    ;;
esac

# ==============================
# 2. 通用工具函数
# ==============================

# 检查命令是否存在
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# ==============================
# 3. 各平台设备枚举函数
# ==============================

# 枚举 Android 设备 (adb)
get_android_devices() {
  # 如果没装 adb, 直接返回空
  if ! command_exists adb; then
    return
  fi

  # adb devices 输出中, 从第 2 行开始, 状态为 "device" 的行, 第 1 列为 udid
  adb devices 2>/dev/null | awk 'NR>1 && $2=="device"{print $1}'
}

# 枚举 鸿蒙 设备 (hdc)
get_hm_devices() {
  # 如果没装 hdc, 直接返回空
  if ! command_exists hdc; then
    return
  fi

  # hdc list targets 一般首行为标题, 过滤空行和以 "[" 开头的行, 第 1 列为 udid
  hdc list targets 2>/dev/null | awk 'NF>0 && $1 !~ /^\[/ {print $1}'
}

# 枚举 iOS 设备 (tidevice) - 仅 macOS 使用
get_ios_devices() {
  # 如果没装 tidevice, 直接返回空
  if ! command_exists tidevice; then
    return
  fi

  # tidevice list 输出首行为表头, 从第 2 行开始取第 1 列为 udid
  tidevice list 2>/dev/null | awk 'NR>1 && NF>=1{print $1}'
}

# ==============================
# 4. 设备健康检查函数
# ==============================

# 调用本地 RPC 接口检查设备是否正常
# 参数1: os_type (android / hm / ios)
# 参数2: udid
check_device() {
  local os_type="$1"
  local udid="$2"

  # 构造 JSON 请求体, method 固定为 screen_size
  local payload
  payload=$(printf '{"os_type":"%s","udid":"%s","method":"screen_size"}' "$os_type" "$udid")

  # 发送 HTTP 请求到本地 RPC 服务, 设置超时并静默错误输出
  local response
  response=$(curl -sS --max-time 5 -X POST \
    -H "Accept: application/json" \
    -H "Content-Type: application/json" \
    -d "$payload" \
    "http://127.0.0.1:26000/rpc" 2>/dev/null || true)

  # 如果返回非空且包含 "result" 字段, 认为设备正常, 否则认为有问题
  local status
  if [ -n "$response" ] && printf '%s' "$response" | grep -q '"result"'; then
    status=1
  else
    status=0
  fi

  # 按 Prometheus 格式输出一行指标(调用方会收集这一行)
  # utest_device_status: 1=设备正常, 0=设备异常或无响应
  printf '    "utest_device_status{host_os=\"%s\",os_type=\"%s\",udid=\"%s\"} %s"\n' "$HOST_OS" "$os_type" "$udid" "$status"
}

# ==============================
# 5. 遍历设备, 生成 metrics_body
# ==============================

# 用于收集所有设备指标行的变量
metrics_body=""

# 通用函数: 遍历设备列表并检查状态
# 参数1: os_type, 参数2: 设备列表(每行一个 udid)
collect_metrics() {
  local os_type="$1"
  local device_list="$2"
  local result=""

  if [ -z "$device_list" ]; then
    return
  fi

  echo "$device_list" | while read -r udid; do
    [ -z "$udid" ] && continue
    check_device "$os_type" "$udid"
  done
}

# ------- Android 设备 (adb) -------
if command_exists adb; then
  _devs=$(get_android_devices)
  if [ -n "$_devs" ]; then
    _lines=$(collect_metrics "android" "$_devs")
    metrics_body="${metrics_body}${_lines}
"
  fi
fi

# ------- 鸿蒙 设备 (hdc) -------
if command_exists hdc; then
  _devs=$(get_hm_devices)
  if [ -n "$_devs" ]; then
    _lines=$(collect_metrics "hm" "$_devs")
    metrics_body="${metrics_body}${_lines}
"
  fi
fi

# ------- iOS 设备 (tidevice) 只在 macOS 下检查 -------
if [ "$HOST_OS" = "darwin" ] && command_exists tidevice; then
  _devs=$(get_ios_devices)
  if [ -n "$_devs" ]; then
    _lines=$(collect_metrics "ios" "$_devs")
    metrics_body="${metrics_body}${_lines}
"
  fi
fi

# 如果一个设备都没有发现, metrics_body 会为空, 后面会补一条占位指标

# ==============================
# 6. 组装最终 Prometheus metrics 文本并输出
#    格式严格按照你给的形式:
#    metrics=$(cat <<'EOF' ... EOF)
#    echo "$metrics"
# ==============================

# 如果有设备行, 按 --prometheus:[ ... ] 格式组装并输出; 否则不输出任何指标
if [ -n "$metrics_body" ]; then
  # 去除 metrics_body 末尾多余的空行
  metrics_body=$(printf '%s' "$metrics_body" | sed '/^$/d')

  # 在每行末尾(除最后一行)加上逗号, 构成类 JSON 数组格式
  formatted=$(echo "$metrics_body" | sed '$!s/$/,/')

  metrics=$(cat <<EOF
--prometheus:[
${formatted}
    ]
EOF
)
  echo "$metrics"
fi