"""Auto-generated stub for module: streaming_gateway_manager."""
from typing import Any, Dict, List, Optional, Set, Tuple

from __future__ import annotations
from dataclasses import dataclass, asdict
import logging

# Classes
class NetworkSettings:
    """
    Network settings data class for streaming gateway configurations.
    
    Attributes:
        ip_address: IP address of the gateway
        port: Port number for the gateway
        access_scale: Access scale (local|regional|global)
        region: Region identifier (e.g., us-east-1)
        max_bandwidth_mbps: Maximum bandwidth in Mbps
        current_bandwidth_mbps: Current bandwidth usage in Mbps
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create NetworkSettings instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert network settings to dictionary for API calls.
        """

class StreamingGateway:
    """
    Streaming gateway instance class for managing individual streaming gateways.
    
    This class represents a single streaming gateway and provides methods to manage
    its configuration, camera groups, and operational status.
    
    Example:
        Basic usage:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.streaming_gateway_manager import StreamingGateway, StreamingGatewayConfig
    
        session = Session(account_number="...", access_key="...", secret_key="...")
    
        # Create network settings
        network_settings = NetworkSettings(
            ip_address="10.0.0.5",
            port=9092,
            access_scale="regional",
            region="us-east-1",
            max_bandwidth_mbps=150.5,
            current_bandwidth_mbps=120.3
        )
    
        # Create gateway config
        config = StreamingGatewayConfig(
            gateway_name="Main Gateway",
            description="Primary streaming gateway",
            status="active",
            network_settings=network_settings,
            account_number="ACC-123"
        )
    
        # Create gateway instance
        gateway = StreamingGateway(session, config)
    
        # Save to backend
        result, error, message = gateway.save()
        if not error:
            print(f"Gateway created with ID: {gateway.id}")
    
        # Update configuration
        gateway.description = "Updated description"
        result, error, message = gateway.update()
    
        # Start streaming
        result, error, message = gateway.start_streaming()
    
        # Update status
        result, error, message = gateway.update_status("active")
    
        # Stop streaming
        result, error, message = gateway.stop_streaming()
        ```
    """

    def __init__(self: Any, session: Any, config: Optional[StreamingGatewayConfig] = None, gateway_id: Optional[str] = None) -> None: ...
        """
        Initialize a StreamingGateway instance.
        
        Args:
            session: Session object containing RPC client for API communication
            config: StreamingGatewayConfig object (for new gateways)
            gateway_id: ID of existing gateway to load (mutually exclusive with config)
        """

    def account_number(self: Any) -> Optional[str]: ...
        """
        Get the account number.
        """

    def account_number(self: Any, value: str) -> Any: ...
        """
        Set the account number.
        """

    def delete(self: Any, force: bool = False) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Delete the gateway from the backend.
        
        Args:
            force: Force delete even if active
        
        Returns:
            tuple: (result, error, message)
        """

    def description(self: Any) -> Optional[str]: ...
        """
        Get the gateway description.
        """

    def description(self: Any, value: str) -> Any: ...
        """
        Set the gateway description.
        """

    def gateway_name(self: Any) -> str: ...
        """
        Get the gateway name.
        """

    def gateway_name(self: Any, value: str) -> Any: ...
        """
        Set the gateway name.
        """

    def id(self: Any) -> Optional[str]: ...
        """
        Get the gateway ID.
        """

    def name(self: Any) -> str: ...
        """
        Get the gateway name (alias for gateway_name).
        """

    def name(self: Any, value: str) -> Any: ...
        """
        Set the gateway name (alias for gateway_name).
        """

    def network_settings(self: Any) -> Optional[NetworkSettings]: ...
        """
        Get the network settings.
        """

    def network_settings(self: Any, value: Any) -> Any: ...
        """
        Set the network settings.
        """

    def refresh(self: Any) -> Any: ...
        """
        Refresh the gateway configuration from the backend.
        """

    def save(self: Any, account_number: Optional[str] = None) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Save the gateway configuration to the backend (create new).
        
        Args:
            account_number: The account number to associate with the gateway
        
        Returns:
            tuple: (result, error, message)
        """

    def start_streaming(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Start the streaming gateway.
        
        Returns:
            tuple: (result, error, message)
        """

    def status(self: Any) -> Optional[str]: ...
        """
        Get the gateway status.
        """

    def stop_streaming(self: Any) -> None: ...
        """
        Stop the streaming gateway.
        
        Returns:
            tuple: (result, error, message)
        """

    def update(self: Any) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Update the gateway configuration in the backend.
        
        Returns:
            tuple: (result, error, message)
        """

    def update_status(self: Any, status: str) -> None: ...
        """
        Update the status of the streaming gateway.
        
        Args:
            status: New status (active, inactive, starting, stopped, etc.)
        
        Returns:
            tuple: (result, error, message)
        """

class StreamingGatewayConfig:
    """
    Streaming gateway configuration data class.
    
    Attributes:
        gateway_name: Name of the streaming gateway
        description: Description of the streaming gateway
        status: Status of the streaming gateway (active, inactive, starting, stopped)
        network_settings: Network configuration settings
        account_number: Account number for the gateway
        action_record_id: Action record ID for tracking
        start_time: Start time timestamp
        last_stream_time: Last streaming time timestamp
        id: Unique identifier for the streaming gateway (MongoDB ObjectID)
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """

    def from_dict(cls: Any, data: Dict) -> Any: ...
        """
        Create a StreamingGatewayConfig instance from API response data.
        """

    def to_dict(self: Any) -> Dict: ...
        """
        Convert the streaming gateway config to a dictionary for API calls.
        """

class StreamingGatewayManager:
    """
    Streaming gateway manager client for handling streaming gateway configurations in deployments.
    
    This class provides methods to create, read, update, and delete streaming gateway configurations
    that manage collections of camera groups for efficient video processing and distribution.
    
    Example:
        Basic usage:
        ```python
        from matrice import Session
        from matrice_streaming.deployment.streaming_gateway_manager import StreamingGatewayManager, StreamingGatewayConfig
    
        session = Session(account_number="...", access_key="...", secret_key="...")
        gateway_manager = StreamingGatewayManager(session)
    
        # Create network settings
        network_settings = NetworkSettings(
            ip_address="10.0.0.5",
            port=9092,
            access_scale="regional",
            region="us-east-1"
        )
    
        # Create a streaming gateway config
        config = StreamingGatewayConfig(
            gateway_name="Main Streaming Gateway",
            description="Primary gateway for building A camera groups",
            status="active",
            network_settings=network_settings
        )
    
        # Create gateway through manager
        gateway, error, message = gateway_manager.create_streaming_gateway(config)
        if error:
            print(f"Error: {error}")
        else:
            print(f"Streaming gateway created: {gateway.name}")
    
        # Get all gateways for the account
        gateways, error, message = gateway_manager.get_streaming_gateways()
        if not error:
            for gateway in gateways:
                print(f"Gateway: {gateway.name} - Status: {gateway.status}")
        ```
    """

    def __init__(self: Any, session: Any, account_number: Optional[str] = None, service_id: Optional[str] = None) -> None: ...
        """
        Initialize the StreamingGatewayManager client.
        
        Args:
            session: Session object containing RPC client for API communication
            account_number: The account number for API calls
            service_id: The ID of the deployment or inference pipeline
        """

    def create_streaming_gateway(self: Any, config: Any) -> Tuple[Optional['StreamingGateway'], Optional[str], str]: ...
        """
        Create a new streaming gateway from configuration.
        
        Args:
            config: StreamingGatewayConfig object containing the gateway configuration
        
        Returns:
            tuple: (streaming_gateway, error, message)
                - streaming_gateway: StreamingGateway instance if successful, None otherwise
                - error: Error message if failed, None otherwise
                - message: Status message
        """

    def get_streaming_gateway_by_id(self: Any, gateway_id: str) -> Tuple[StreamingGateway, Optional[str], str]: ...
        """
        Get a streaming gateway by its ID.
        
        Args:
            gateway_id: The ID of the streaming gateway to retrieve
        
        Returns:
            tuple: (streaming_gateway, error, message)
        """

    def get_streaming_gateways(self: Any, page: int = 1, limit: int = 10, search: Optional[str] = None) -> Tuple[Optional[List['StreamingGateway']], Optional[str], str]: ...
        """
        Get all streaming gateways for the account.
        
        Args:
            page: Page number for pagination
            limit: Items per page
            search: Optional search term
        
        Returns:
            tuple: (streaming_gateways, error, message)
        """

    def get_streaming_gateways_paginated(self: Any, page: int = 1, limit: int = 10) -> Tuple[Optional[List['StreamingGateway']], Optional[str], str]: ...
        """
        Get paginated streaming gateways for the account.
        
        Args:
            page: Page number for pagination
            limit: Items per page
        
        Returns:
            tuple: (streaming_gateways, error, message)
        """

    def handle_response(self: Any, response: Dict, success_message: str, failure_message: str) -> Tuple[Optional[Dict], Optional[str], str]: ...
        """
        Handle API response and return standardized tuple.
        """

