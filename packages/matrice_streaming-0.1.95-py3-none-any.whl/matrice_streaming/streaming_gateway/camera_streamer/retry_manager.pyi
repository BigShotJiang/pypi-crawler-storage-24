"""Auto-generated stub for module: retry_manager."""
from typing import Any, Optional

from __future__ import annotations
import logging
import time

# Classes
class RetryConfig:
    """
    Configuration for retry logic.
    """

    pass
class RetryManager:
    """
    Manages retry logic and connection state with infinite retries.
    """

    def __init__(self: Any, stream_key: str) -> None: ...
        """
        Initialize retry manager.
        
                Args:
                    stream_key: Stream identifier for logging
        """

    def get_stats(self: Any) -> dict: ...
        """
        Get retry statistics.
        
                Returns:
                    Dictionary with retry statistics
        """

    def handle_connection_failure(self: Any, error: Any) -> Any: ...
        """
        Handle connection failure and calculate backoff.
        
                Args:
                    error: The exception that occurred
        """

    def handle_successful_reconnect(self: Any) -> Any: ...
        """
        Handle successful reconnection.
        """

    def record_read_failure(self: Any) -> Any: ...
        """
        Record a frame read failure.
        """

    def record_success(self: Any) -> Any: ...
        """
        Record a successful operation (resets failure counter).
        """

    def should_reconnect(self: Any) -> bool: ...
        """
        Check if should reconnect due to consecutive failures.
        
                Returns:
                    True if should reconnect
        """

    def wait_after_read_failure(self: Any) -> Any: ...
        """
        Brief pause after read failure before retrying.
        """

    def wait_before_restart(self: Any) -> Any: ...
        """
        Brief pause before restarting video file.
        """

    def wait_before_retry(self: Any) -> Any: ...
        """
        Wait with exponential backoff before retry.
        
                This implements exponential backoff with a maximum cooldown.
                The system will NEVER give up - it retries forever.
        """

