"""Auto-generated stub for module: device_detection."""
from typing import Any, Dict, List, Optional, Set

from dataclasses import dataclass, field
from enum import Enum
from gi.repository import Gst
import gi
import logging
import os
import platform
import subprocess
import threading

# Functions
def get_platform_info(force_redetect: bool = False) -> Any: ...
    """
    Convenience function to get platform information.
    
        Args:
            force_redetect: Force re-detection even if cached
    
        Returns:
            PlatformInfo with detected capabilities
    """

# Classes
class PlatformDetector:
    """
    Singleton platform detector with caching.
    
        Detects hardware platform and GStreamer capabilities, caching results
        for efficient reuse across multiple pipeline instances.
    """

    def __init__(self: Any) -> None: ...
        """
        Private constructor - use get_instance() instead.
        """

    def clear_cache(self: Any) -> Any: ...
        """
        Clear cached platform detection results.
        """

    def detect(self: Any, force_redetect: bool = False) -> Any: ...
        """
        Detect platform and cache results.
        
                Args:
                    force_redetect: Force re-detection even if cached result exists
        
                Returns:
                    PlatformInfo with detected capabilities
        """

    def get_instance(cls: Any) -> Any: ...
        """
        Get singleton instance of PlatformDetector.
        """

    def override_platform(self: Any, platform_type: Any, model: str = 'Manual Override') -> Any: ...
        """
        Manually override platform detection (for testing).
        
                Args:
                    platform_type: Platform type to force
                    model: Optional model description
        """

class PlatformInfo:
    """
    Detected platform information and capabilities.
    """

    pass
class PlatformType(Enum):
    """
    Supported hardware platform types.
    """

    AMD_GPU: str
    CPU_ONLY: str
    DESKTOP_NVIDIA_GPU: str
    INTEL_GPU: str
    JETSON: str

    pass
