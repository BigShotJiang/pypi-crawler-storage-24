"""Auto-generated stub for module: ffmpeg_camera_streamer."""
from typing import Any, Dict, List, Optional, Tuple, Union

from __future__ import annotations
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from ffmpeg_config import FFmpegConfig, is_ffmpeg_available, detect_hwaccel
from matrice_common.optimize import FrameOptimizer
from matrice_common.stream import MatriceStream, StreamType
from matrice_common.stream.shm_ring_buffer import ShmRingBuffer
from matrice_common.stream.shm_ring_buffer import bgr_to_nv12
import asyncio
import atexit
import cv2
import logging
import numpy as np
import os
import psutil
import signal
import subprocess
import sys
import threading
import time
import uuid
import uuid

# Classes
class FFmpegCameraStreamer:
    """
    FFmpeg-based camera streamer with same API as CameraStreamer.
    
        This class provides a drop-in replacement for CameraStreamer using
        FFmpeg subprocess pipelines for video ingestion. It supports:
        - Background streaming to Redis/Kafka
        - Dynamic camera add/remove/update
        - Frame optimization (similarity detection)
        - SHM mode for raw frame sharing
    """

    def __init__(self: Any, session: Any, service_id: str, server_type: str = 'redis', video_codec: Optional[str] = None, gateway_util: Any = None, ffmpeg_config: Optional[FFmpegConfig] = None, use_shm: bool = False, shm_slot_count: int = 1000, shm_frame_format: str = 'BGR', frame_optimizer_enabled: bool = False, frame_optimizer_config: Optional[Dict[str, Any]] = None, pin_cpu_affinity: bool = False, cpu_affinity_core: Optional[int] = None) -> None: ...
        """
        Initialize FFmpeg camera streamer.
        
                Args:
                    session: Session object for authentication
                    service_id: Service identifier
                    server_type: Backend type (redis or kafka)
                    video_codec: Video codec (h264 or h265)
                    gateway_util: Gateway utility for API interactions
                    ffmpeg_config: FFmpeg configuration
                    use_shm: Enable SHM mode for raw frame sharing
                    shm_slot_count: Number of frame slots per camera ring buffer
                    shm_frame_format: Frame format for SHM storage ("BGR", "RGB", or "NV12")
                    frame_optimizer_enabled: Enable frame optimizer for skipping similar frames
                    frame_optimizer_config: Frame optimizer configuration dict
                    pin_cpu_affinity: Pin process to specific CPU core
                    cpu_affinity_core: CPU core to pin to (None = auto-assign)
        """

    def get_transmission_stats(self: Any) -> Dict[str, Any]: ...
        """
        Get transmission statistics.
        
                Returns:
                    Dictionary of statistics
        """

    def register_stream_topic(self: Any, stream_key: str, topic: str) -> Any: ...
        """
        Register a topic for a stream.
        
                Args:
                    stream_key: Stream identifier
                    topic: Topic name for this stream
        """

    def reset_transmission_stats(self: Any) -> Any: ...
        """
        Reset transmission statistics.
        """

    def setup_stream_for_topic(self: Any, topic: str) -> Any: ...
        """
        Setup stream for a topic (create topic if needed).
        
                Args:
                    topic: Topic name to setup
        """

    def start_background_stream(self: Any, input: Union[str, int], fps: int = 30, stream_key: str = 'default', stream_group_key: str = 'default', quality: int = 90, width: Optional[int] = None, height: Optional[int] = None, simulate_video_file_stream: bool = False, camera_location: str = 'Unknown') -> bool: ...
        """
        Start background streaming for a camera.
        
                Args:
                    input: Video source (file path, URL, or device ID)
                    fps: Target FPS
                    stream_key: Unique stream identifier
                    stream_group_key: Stream group identifier
                    quality: JPEG quality (1-100)
                    width: Target width (None = use source)
                    height: Target height (None = use source)
                    simulate_video_file_stream: Loop video files
                    camera_location: Camera location description
        
                Returns:
                    True if stream started successfully
        """

    def stop_streaming(self: Any, stream_key: Optional[str] = None) -> None: ...
        """
        Stop streaming for one or all cameras.
        
                Args:
                    stream_key: Stream to stop (None = stop all)
        """

class FFmpegPipeline:
    """
    FFmpeg subprocess-based frame capture pipeline.
    
        This class manages an FFmpeg subprocess that decodes video and outputs
        raw frames via stdout pipe. It provides both sync and async interfaces.
    """

    def __init__(self: Any, source: str, width: int, height: int, config: Optional[FFmpegConfig] = None, stream_key: str = 'default') -> None: ...
        """
        Initialize FFmpeg pipeline.
        
                Args:
                    source: Video source (file path, RTSP URL, HTTP URL, device)
                    width: Frame width (0 = auto-detect from source)
                    height: Frame height (0 = auto-detect from source)
                    config: FFmpeg configuration options
                    stream_key: Stream identifier for logging
        """

    def close(self: Any) -> Any: ...
        """
        Close the pipeline and release resources.
        """

    def get_metrics(self: Any) -> Dict[str, Any]: ...
        """
        Get pipeline metrics.
        
                Returns:
                    Dictionary of metrics
        """

    def read_frame(self: Any) -> Optional[np.ndarray]: ...
        """
        Read one raw frame from FFmpeg pipe (blocking).
        
                Returns:
                    numpy array of shape (height, width, 3) or None if failed
        """

    async def read_frame_async(self: Any, executor: Optional[ThreadPoolExecutor] = None) -> Optional[np.ndarray]: ...
        """
        Read frame asynchronously using executor.
        
                Args:
                    executor: Thread pool executor (uses default if None)
        
                Returns:
                    numpy array or None if failed
        """

    def restart(self: Any) -> bool: ...
        """
        Restart the FFmpeg pipeline.
        
                Returns:
                    True if restart succeeded
        """

