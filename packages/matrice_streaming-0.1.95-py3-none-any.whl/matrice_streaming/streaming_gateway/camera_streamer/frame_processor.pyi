"""Auto-generated stub for module: frame_processor."""
from typing import Any, Optional, Tuple

from __future__ import annotations
import cv2
import numpy as np

# Classes
class FrameProcessor:
    """
    Handles frame processing operations like resizing.
    """

    def calculate_actual_dimensions(video_width: int, video_height: int, target_width: Optional[int], target_height: Optional[int]) -> Tuple[int, int]: ...
        """
        Calculate actual output dimensions.
        
                Args:
                    video_width: Original video width
                    video_height: Original video height
                    target_width: Target width (None for original)
                    target_height: Target height (None for original)
        
                Returns:
                    Tuple of (actual_width, actual_height)
        """

    def resize_frame(frame: Any, target_width: Optional[int], target_height: Optional[int]) -> Any: ...
        """
        Resize frame if needed.
        
                Args:
                    frame: Input frame
                    target_width: Target width (None to keep current)
                    target_height: Target height (None to keep current)
        
                Returns:
                    Resized frame or original if no resize needed
        """

    def should_skip_frame(frame_counter: int, frame_skip: int) -> bool: ...
        """
        Check if frame should be skipped based on skip rate.
        
                Args:
                    frame_counter: Current frame count
                    frame_skip: Frame skip rate
        
                Returns:
                    True if frame should be skipped
        """

