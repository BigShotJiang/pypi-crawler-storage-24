"""Auto-generated stub for module: gstreamer_worker."""
from typing import Any, Dict, List, Optional, Union

from __future__ import annotations
from collections import deque
from device_detection import PlatformDetector
from gi.repository import Gst, GstApp, GLib
from gstreamer_camera_streamer import GStreamerConfig
from matrice_common.optimize import FrameOptimizer
from matrice_common.stream import MatriceStream, StreamType
from message_builder import StreamMessageBuilder
from platform_pipelines import PipelineFactory
from stream_statistics import StreamStatistics
import asyncio
import gi
import hashlib
import logging
import multiprocessing
import os
import psutil
import time

# Constants
GST_AVAILABLE: bool

# Functions
def is_gstreamer_available() -> bool: ...
    """
    Check if GStreamer is available.
    """
def run_gstreamer_worker(worker_id: int, camera_configs: List[Dict[str, Any]], stream_config: Dict[str, Any], stop_event: Any, health_queue: Any, command_queue: Optional[Any] = None, response_queue: Optional[Any] = None, gstreamer_encoder: str = 'auto', gstreamer_codec: str = 'h264', gstreamer_preset: str = 'low-latency', gpu_id: int = 0, platform: str = 'auto', use_hardware_decode: bool = True, use_hardware_jpeg: bool = True, jetson_use_nvmm: bool = True, frame_optimizer_mode: str = 'hash-only', fallback_on_error: bool = True, verbose_pipeline_logging: bool = False) -> Any: ...
    """
    Entry point for GStreamer worker process.
    
        Args:
            worker_id: Worker identifier
            camera_configs: Camera configurations
            stream_config: Streaming configuration
            stop_event: Shutdown event
            health_queue: Health reporting queue
            command_queue: Command queue
            response_queue: Response queue
            gstreamer_encoder: Encoder type
            gstreamer_codec: Codec
            gstreamer_preset: NVENC preset
            gpu_id: GPU device ID
            platform: Platform override
            use_hardware_decode: Enable hardware decode
            use_hardware_jpeg: Enable hardware JPEG
            jetson_use_nvmm: Use NVMM on Jetson
            frame_optimizer_mode: Frame optimization mode
            fallback_on_error: Fallback to CPU on errors
            verbose_pipeline_logging: Verbose logging
    """

# Classes
class GStreamerAsyncWorker:
    """
    Async worker process that handles multiple cameras using GStreamer.
    
        This worker runs an async event loop to manage GStreamer pipelines
        for multiple cameras with efficient encoding (NVENC/x264/JPEG).
    """

    def __init__(self: Any, worker_id: int, camera_configs: List[Dict[str, Any]], stream_config: Dict[str, Any], stop_event: Any, health_queue: Any, command_queue: Optional[Any] = None, response_queue: Optional[Any] = None, gstreamer_encoder: str = 'auto', gstreamer_codec: str = 'h264', gstreamer_preset: str = 'low-latency', gpu_id: int = 0, platform: str = 'auto', use_hardware_decode: bool = True, use_hardware_jpeg: bool = True, jetson_use_nvmm: bool = True, frame_optimizer_mode: str = 'hash-only', fallback_on_error: bool = True, verbose_pipeline_logging: bool = False) -> None: ...
        """
        Initialize GStreamer async worker.
        
                Args:
                    worker_id: Unique identifier for this worker
                    camera_configs: List of camera configurations
                    stream_config: Streaming configuration (Redis, Kafka, etc.)
                    stop_event: Event to signal worker shutdown
                    health_queue: Queue for reporting health status
                    command_queue: Queue for receiving dynamic commands
                    response_queue: Queue for sending responses
                    gstreamer_encoder: Encoder type (auto, nvenc, x264, openh264, jpeg)
                    gstreamer_codec: Codec (h264, h265)
                    gstreamer_preset: NVENC preset
                    gpu_id: GPU device ID for NVENC
                    platform: Platform override (auto, jetson, desktop-gpu, intel, amd, cpu)
                    use_hardware_decode: Enable hardware decode
                    use_hardware_jpeg: Enable hardware JPEG encoding
                    jetson_use_nvmm: Use NVMM zero-copy on Jetson
                    frame_optimizer_mode: Frame optimization mode
                    fallback_on_error: Fallback to CPU on errors
                    verbose_pipeline_logging: Enable verbose logging
        """

    async def initialize(self: Any) -> Any: ...
        """
        Initialize async resources.
        """

    async def run(self: Any) -> Any: ...
        """
        Main worker loop.
        """

