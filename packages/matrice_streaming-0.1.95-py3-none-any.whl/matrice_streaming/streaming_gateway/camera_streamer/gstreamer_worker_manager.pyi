"""Auto-generated stub for module: gstreamer_worker_manager."""
from typing import Any, Dict, List, Optional

from __future__ import annotations
from camera_streamer import CameraStreamer
from device_detection import PlatformDetector, PlatformType
from gstreamer_worker import run_gstreamer_worker, is_gstreamer_available
import logging
import multiprocessing
import os
import signal
import sys
import time

# Classes
class GStreamerWorkerManager:
    """
    Manages multiple GStreamer async camera worker processes.
    
        This manager coordinates worker processes using GStreamer pipelines
        for efficient hardware/software video encoding. It follows the same
        API as WorkerManager for drop-in replacement.
    """

    def __init__(self: Any, camera_configs: List[Dict[str, Any]], stream_config: Dict[str, Any], num_workers: Optional[int] = None, cpu_percentage: float = 0.9, max_cameras_per_worker: int = 100, gstreamer_encoder: str = 'auto', gstreamer_codec: str = 'h264', gstreamer_preset: str = 'low-latency', gpu_id: int = 0, platform: str = 'auto', use_hardware_decode: bool = True, use_hardware_jpeg: bool = True, jetson_use_nvmm: bool = True, frame_optimizer_mode: str = 'hash-only', fallback_on_error: bool = True, verbose_pipeline_logging: bool = False) -> None: ...
        """
        Initialize GStreamer worker manager.
        
                Args:
                    camera_configs: List of all camera configurations
                    stream_config: Streaming configuration (Redis, Kafka, etc.)
                    num_workers: Number of worker processes (auto-calculated if None)
                    cpu_percentage: Percentage of CPU cores to use (default: 90%)
                    max_cameras_per_worker: Maximum cameras per worker
                    gstreamer_encoder: Encoder type (auto, nvenc, x264, openh264, jpeg)
                    gstreamer_codec: Codec (h264, h265)
                    gstreamer_preset: NVENC preset
                    gpu_id: GPU device ID for NVENC
                    platform: Platform override (auto, jetson, desktop-gpu, intel, amd, cpu)
                    use_hardware_decode: Enable hardware decode
                    use_hardware_jpeg: Enable hardware JPEG encoding
                    jetson_use_nvmm: Use NVMM zero-copy on Jetson
                    frame_optimizer_mode: Frame optimization mode (hash-only, dual-appsink, disabled)
                    fallback_on_error: Fallback to CPU pipeline on errors
                    verbose_pipeline_logging: Enable verbose pipeline logging
        """

    def add_camera(self: Any, camera_config: Dict[str, Any]) -> bool: ...
        """
        Add a camera to least-loaded worker.
        """

    def get_camera_assignments(self: Any) -> Dict[str, int]: ...
        """
        Get camera-to-worker assignments.
        """

    def get_worker_statistics(self: Any) -> Dict[str, Any]: ...
        """
        Get worker statistics.
        """

    def monitor(self: Any, duration: Optional[float] = None) -> Any: ...
        """
        Monitor workers and collect health reports.
        """

    def remove_camera(self: Any, stream_key: str) -> bool: ...
        """
        Remove a camera.
        """

    def run(self: Any, duration: Optional[float] = None) -> Any: ...
        """
        Start workers and monitor.
        """

    def start(self: Any) -> Any: ...
        """
        Start all workers.
        """

    def stop(self: Any, timeout: float = 15.0) -> Any: ...
        """
        Stop all workers.
        """

    def update_camera(self: Any, camera_config: Dict[str, Any]) -> bool: ...
        """
        Update a camera's configuration.
        """

