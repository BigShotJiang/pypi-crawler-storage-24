"""Auto-generated stub for module: message_builder."""
from typing import Any, Dict, Optional, Union

from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import base64
import hashlib
import uuid
import xxhash

# Classes
class StreamMessageBuilder:
    """
    Builds stream messages with proper structure and metadata.
    """

    def __init__(self: Any, service_id: str, strip_input_content: bool = False) -> None: ...
        """
        Initialize message builder.
        
                Args:
                    service_id: Service/deployment identifier
                    strip_input_content: Strip content for out-of-band retrieval
        """

    def build_frame_metadata(self: Any, input_source: Union[str, int], video_props: Dict[str, Any], fps: int, quality: int, actual_width: int, actual_height: int, stream_type: str, frame_counter: int, is_video_chunk: bool, chunk_duration_seconds: Optional[float], chunk_frames: Optional[int], camera_location: Optional[str]) -> Dict[str, Any]: ...
        """
        Build frame metadata dictionary.
        
                Args:
                    input_source: Input source identifier
                    video_props: Video properties dictionary
                    fps: Target FPS
                    quality: Quality setting
                    actual_width: Frame width
                    actual_height: Frame height
                    stream_type: Type of stream source
                    frame_counter: Current frame number
                    is_video_chunk: Whether this is a chunked stream
                    chunk_duration_seconds: Chunk duration
                    chunk_frames: Number of frames per chunk
                    camera_location: Camera location description
        
                Returns:
                    Metadata dictionary
        """

    def build_message(self: Any, frame_data: Any, stream_key: str, stream_group_key: str, codec: str, metadata: Dict[str, Any], topic: str, broker_config: str, input_order: int, last_read_time: float, last_write_time: float, last_process_time: float, cached_frame_id: Optional[str] = None) -> Dict[str, Any]: ...
        """
        Build complete stream message.
        
                Supports both normal frames (with content) and cached frames (empty content + cached_frame_id).
        
                Args:
                    frame_data: Encoded frame bytes (can be empty for cached frames)
                    stream_key: Stream identifier
                    stream_group_key: Stream group identifier
                    codec: Video codec (use "cached" for cached frames)
                    metadata: Frame metadata
                    topic: Topic name
                    broker_config: Broker configuration string
                    input_order: Input order number
                    last_read_time: Last read time
                    last_write_time: Last write time
                    last_process_time: Last process time
                    cached_frame_id: Frame ID to use cached results from (None for normal frames)
        
                Returns:
                    Complete message dictionary
        """

