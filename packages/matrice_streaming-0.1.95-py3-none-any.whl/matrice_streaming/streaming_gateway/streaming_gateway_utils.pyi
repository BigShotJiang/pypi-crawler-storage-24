"""Auto-generated stub for module: streaming_gateway_utils."""
from typing import Any, Dict, List, Optional, Union

from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from matrice_common.session import Session
from matrice_streaming.streaming_gateway.camera_streamer.codec_detect import normalize_codec
from metrics_reporter import HeartbeatReporter
import logging
import os
import re
import time

# Functions
def build_stream_config(gateway_util: Any, server_type: str, service_id: str, stream_maxlen: Optional[int] = None) -> Dict: ...
    """
    Build stream_config dict for WorkerManager from gateway connection info.
    
        This function retrieves connection information from the API and builds
        a configuration dictionary suitable for WorkerManager and AsyncCameraWorker.
    
        Args:
            gateway_util: StreamingGatewayUtil instance for API calls
            server_type: 'kafka' or 'redis'
            service_id: Streaming gateway ID (used as service_id)
            stream_maxlen: Maximum entries per Redis stream (approximate mode, default: None = unlimited)
    
        Returns:
            Dict with connection configuration for WorkerManager
    """
def input_stream_to_camera_config(input_stream: Any) -> Dict: ...
    """
    Convert InputStream dataclass to camera_config dict for WorkerManager.
    
        This adapter function converts the InputStream configuration format used by
        StreamingGateway to the dictionary format expected by WorkerManager and
        AsyncCameraWorker.
    
        Args:
            input_stream: InputStream dataclass instance
    
        Returns:
            Dict compatible with WorkerManager/AsyncCameraWorker
    """

# Classes
class InputStream:
    """
    Configuration for input sources.
    """

    pass
class StreamingGatewayUtil:
    def __init__(self: Any, session: Session, streaming_gateway_id: str, server_id: Optional[str] = None, action_id: Optional[str] = None) -> None: ...

    def get_and_wait_for_connection_info(self: Any, server_type: Optional[str] = None, server_id: Optional[str] = None, connection_timeout: int = 300) -> Dict: ...
        """
        Get and wait for connection information for the streaming gateway.
        
                Args:
                    server_type: Type of server ('kafka' or 'redis'). Required.
                    server_id: ID of the server. If not provided, uses self.server_id.
                    connection_timeout: Timeout in seconds to wait for connection info (default: 300).
        
                Returns:
                    Dict: Connection configuration
        
                Raises:
                    ValueError: If server_type or server_id is not provided
                    RuntimeError: If timeout is reached while waiting for connection info
        """

    def get_camera_groups(self: Any) -> Any: ...

    def get_cameras(self: Any) -> Any: ...

    def get_input_streams(self: Any) -> List[InputStream]: ...
        """
        Get cameras as list of InputStream objects with proper configuration.
        """

    def get_nvdec_input_streams(self: Any, mediamtx_host: str = 'localhost', mediamtx_port: int = 8554) -> List[InputStream]: ...
        """
        Get camera input streams with MediaMTX RTSP URLs for NVDEC hardware decode.
        
                This method fetches cameras from the streaming gateway API and constructs
                RTSP URLs pointing to the local MediaMTX server for each camera. Used by the
                CUDA SHM / NVDEC inference pipeline where frames are decoded on GPU via
                GStreamer NVDEC instead of the CPU-based AsyncCameraWorker flow.
        
                All camera types (RTSP and FILE) use the MediaMTX RTSP URL as their source,
                since MediaMTX handles both live RTSP relay and file playback.
        
                Args:
                    mediamtx_host: MediaMTX server hostname (default: "localhost")
                    mediamtx_port: MediaMTX server RTSP port (default: 8554)
        
                Returns:
                    List[InputStream]: Camera configurations with MediaMTX RTSP URLs as source
        """

    def get_simulated_stream_url(self: Any, camera_id: str) -> Any: ...

    def get_streaming_gateway_by_id(self: Any) -> Any: ...

    def get_streaming_input_topics(self: Any) -> Any: ...

    def get_streaming_output_topics(self: Any) -> Any: ...

    def send_heartbeat(self: Any, camera_config: Optional[Dict] = None) -> bool: ...
        """
        Send a heartbeat to the streaming gateway via Kafka.
        
        Args:
            camera_config: Camera configuration data to include in heartbeat
                           Should contain 'cameras' list and 'stats' dict
        
        Returns:
            bool: True if heartbeat sent successfully, False otherwise
        """

    def start_streaming(self: Any) -> Optional[Dict]: ...
        """
        Start the streaming gateway.
        
        Returns:
            Dict: API response data or None if failed
        """

    def stop_streaming(self: Any) -> None: ...
        """
        Stop the streaming gateway.
        
        Returns:
            Dict: API response data or None if failed
        """

    def update_status(self: Any, status: str) -> None: ...
        """
        Update the status of the streaming gateway.
        
        Args:
            status: New status (active, inactive, starting, stopped, etc.)
        
        Returns:
            Dict: API response data or None if failed
        """

