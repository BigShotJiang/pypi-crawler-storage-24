"""Auto-generated stub for module: benchmark."""
from typing import Any, Dict, List, Optional, Tuple

from dataclasses import dataclass, asdict
from debug_gstreamer_gateway import DebugGStreamerGateway
from debug_streaming_gateway import DebugStreamingGateway
from pathlib import Path
import json
import logging
import psutil
import statistics
import threading
import time

# Classes
class BenchmarkResult:
    """
    Benchmark result for a single test.
    """

    def to_dict(self: Any) -> Dict[str, Any]: ...
        """
        Convert to dictionary.
        """

    def to_json(self: Any, indent: int = 2) -> str: ...
        """
        Convert to JSON string.
        """

class GStreamerBenchmark:
    """
    Comprehensive benchmark suite for all streaming methods.
    """

    def __init__(self: Any, video_paths: List[str], output_dir: Optional[str] = None, log_level: int = logging.INFO) -> None: ...
        """
        Initialize benchmark suite.
        
                Args:
                    video_paths: List of video files to use for testing
                    output_dir: Directory to save benchmark results
                    log_level: Logging level
        """

    def benchmark_gstreamer_camera_streamer(self: Any, fps: int = 30, duration: float = 60.0, encoder: str = 'jpeg', codec: str = 'h264', jpeg_quality: int = 85, enable_frame_optimizer: bool = True) -> Any: ...
        """
        Benchmark GStreamerCameraStreamer (single-process GStreamer).
        
                Args:
                    fps: Target FPS
                    duration: Test duration in seconds
                    encoder: GStreamer encoder (jpeg, nvenc, x264, openh264, auto)
                    codec: Codec for hardware/software encoders (h264, h265)
                    jpeg_quality: JPEG quality (1-100)
                    enable_frame_optimizer: Enable frame similarity detection
        
                Returns:
                    BenchmarkResult with performance metrics
        """

    def benchmark_standard_camera_streamer(self: Any, fps: int = 30, duration: float = 60.0, codec: str = 'h264') -> Any: ...
        """
        Benchmark standard CameraStreamer (OpenCV + OpenH264/x264).
        
                Args:
                    fps: Target FPS
                    duration: Test duration in seconds
                    codec: Video codec (h264, h265-frame, h265-chunk)
        
                Returns:
                    BenchmarkResult with performance metrics
        """

    def print_summary(self: Any) -> Any: ...
        """
        Print benchmark summary to console.
        """

    def run_comprehensive_benchmark(self: Any, fps: int = 30, duration: float = 60.0, test_encoders: List[str] = None) -> Dict[str, Any]: ...
        """
        Run comprehensive benchmark across all methods and encoders.
        
                Args:
                    fps: Target FPS
                    duration: Test duration per benchmark
                    test_encoders: List of encoders to test (default: jpeg, nvenc, x264)
        
                Returns:
                    Dictionary with all benchmark results and comparisons
        """

class ResourceMonitor:
    """
    Monitor CPU and memory usage during benchmark.
    """

    def __init__(self: Any, process: Any) -> None: ...
        """
        Initialize monitor.
        
                Args:
                    process: Process to monitor
        """

    def get_stats(self: Any) -> Dict[str, float]: ...
        """
        Get resource usage statistics.
        
                Returns:
                    Dictionary with CPU and memory stats
        """

    def start(self: Any) -> Any: ...
        """
        Start monitoring.
        """

    def stop(self: Any) -> Any: ...
        """
        Stop monitoring.
        """

