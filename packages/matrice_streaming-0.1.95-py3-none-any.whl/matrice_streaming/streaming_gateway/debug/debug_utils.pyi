"""Auto-generated stub for module: debug_utils."""
from typing import Any, Dict, List, Optional

from dataclasses import dataclass
from streaming_gateway_utils import InputStream
import logging

# Functions
def create_camera_configs_from_streams(input_streams: List) -> List[Dict[str, Any]]: ...
    """
    Convert InputStream objects to camera configs for WorkerManager.
    
        Args:
            input_streams: List of InputStream objects
    
        Returns:
            List of camera configuration dictionaries for WorkerManager
    """
def create_debug_input_streams(video_paths: List[str], fps: int = 10, loop: bool = True) -> List: ...
    """
    Create InputStream objects for debug mode.
    
        Args:
            video_paths: List of video file paths
            fps: Frames per second
            loop: Whether to loop video files
    
        Returns:
            List of InputStream objects
    """
def create_debug_video_config(video_paths: List[str]) -> List[Dict[str, Any]]: ...
    """
    Create debug configuration from video file paths.
    
        Args:
            video_paths: List of video file paths to stream
    
        Returns:
            List of camera configurations
    """

# Classes
class MockRPC:
    """
    Mock RPC client for testing without real API.
    """

    def __init__(self: Any) -> None: ...

    def get(self: Any, path: str) -> Dict[str, Any]: ...
        """
        Mock GET request.
        """

    def post(self: Any, path: str, payload: Dict = None) -> Dict[str, Any]: ...
        """
        Mock POST request.
        """

    def put(self: Any, path: str, payload: Dict = None) -> Dict[str, Any]: ...
        """
        Mock PUT request.
        """

class MockSession:
    """
    Mock session for testing without authentication.
    """

    def __init__(self: Any) -> None: ...

    pass
