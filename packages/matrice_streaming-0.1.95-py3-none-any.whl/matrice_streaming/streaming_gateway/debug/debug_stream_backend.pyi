"""Auto-generated stub for module: debug_stream_backend."""
from typing import Any, Dict, Optional

from datetime import datetime
from pathlib import Path
import json
import logging
import time

# Classes
class DebugStreamBackend:
    """
    Mock stream backend that logs messages instead of sending to Kafka/Redis.
    
        This allows testing the full streaming pipeline without actual message brokers.
        Messages can be:
        - Logged to console
        - Saved to JSON files
        - Counted for statistics
        - Inspected for debugging
    """

    def __init__(self: Any, output_dir: Optional[str] = None, save_to_files: bool = False, log_messages: bool = True, save_frame_data: bool = False) -> None: ...
        """
        Initialize debug stream backend.
        
                Args:
                    output_dir: Directory to save messages (if save_to_files=True)
                    save_to_files: Save messages to JSON files
                    log_messages: Log message metadata to console
                    save_frame_data: Include frame data in saved files (can be large!)
        """

    def add_message(self: Any, topic_or_channel: str, message: Dict[str, Any], key: Optional[str] = None) -> Any: ...
        """
        Add a message (mock send operation).
        
                Args:
                    topic_or_channel: Topic/channel name
                    message: Message dictionary
                    key: Message key
        """

    async def async_add_message(self: Any, topic_or_channel: str, message: Dict[str, Any], key: Optional[str] = None) -> Any: ...
        """
        Async add message (mock operation).
        """

    async def async_close(self: Any) -> Any: ...
        """
        Async close (mock operation).
        """

    async def async_setup(self: Any, topic: str) -> Any: ...
        """
        Async setup (mock operation).
        """

    def close(self: Any) -> Any: ...
        """
        Close backend.
        """

    def config(self: Any) -> Dict[str, Any]: ...
        """
        Get config (mock).
        """

    def get_statistics(self: Any) -> Dict[str, Any]: ...
        """
        Get stream statistics.
        """

    def is_async_setup(self: Any) -> bool: ...
        """
        Check if async is setup.
        """

    def setup(self: Any, topic: str) -> Any: ...
        """
        Setup a topic (mock operation).
        """

