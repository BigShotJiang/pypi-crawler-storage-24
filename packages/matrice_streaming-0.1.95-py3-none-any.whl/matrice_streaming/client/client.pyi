"""Auto-generated stub for module: client."""
from typing import Any, Dict, Optional, Union

from __future__ import annotations
from matrice.projects import Projects
from matrice_streaming.client.client_utils import ClientUtils
import logging
import time

# Classes
class MatriceDeployClient:
    """
    Client for interacting with Matrice model deployments.
    
        This client provides both synchronous and asynchronous methods for making
        predictions and streaming video data to deployed models.
    
        Example:
            Basic usage:
            ```python
            from matrice import Session
            from matrice_streaming.client import MatriceDeployClient
    
            session = Session(account_number="...", access_key="...", secret_key="...")
            client = MatriceDeployClient(
                session=session,
                deployment_id="your_deployment_id",
                auth_key="your_auth_key"
            )
    
            # Check if client is healthy
            if client.is_healthy():
                # Make a prediction
                result = client.get_prediction(input_path="image.jpg")
                print(result)
    
            # Clean up resources
            client.close()
            ```
    """

    def __init__(self: Any, session: Any, deployment_id: str, auth_key: Optional[str] = None, create_deployment_config: Optional[Dict] = None) -> None: ...
        """
        Initialize MatriceDeployClient.
        
                Args:
                    session: Session object for making RPC calls
                    deployment_id: ID of the deployment
                    auth_key: Authentication key
                    create_deployment_config: Deployment configuration
        
                Raises:
                    ValueError: If required parameters are missing or invalid
                    RuntimeError: If deployment info cannot be retrieved
        """

    async def aclose(self: Any) -> None: ...
        """
        Close all client connections asynchronously and clean up resources.
        
                This method should be called when you're done using the client
                to properly clean up HTTP connections and other resources.
        """

    def close(self: Any) -> None: ...
        """
        Close all client connections and clean up resources.
        
                This method should be called when you're done using the client
                to properly clean up HTTP connections and other resources.
        """

    def create_auth_key_if_not_exists(self: Any, expiry_days: int = 30) -> str: ...
        """
        Create an authentication key if one doesn't exist.
        
                Args:
                    expiry_days: Number of days until the key expires
        
                Returns:
                    str: The created authentication key
        
                Raises:
                    ValueError: If expiry_days is invalid
                    RuntimeError: If key creation fails
        """

    def create_deployment(self: Any, deployment_name: Any, model_id: Any = '', gpu_required: Any = True, auto_scale: Any = False, auto_shutdown: Any = True, shutdown_threshold: Any = 5, compute_alias: Any = '', model_type: Any = 'trained', deployment_type: Any = 'regular', checkpoint_type: Any = 'pretrained', checkpoint_value: Any = '', checkpoint_dataset: Any = 'COCO', runtime_framework: Any = 'Pytorch', server_type: Any = 'fastapi', deployment_params: Any = {}, model_input: Any = 'image', model_output: Any = 'classification', suggested_classes: Any = [], model_family: Any = '', model_key: Any = '', is_kafka_enabled: Any = False, is_optimized: Any = False, instance_range: Any = [1, 1], custom_schedule: Any = False, schedule_deployment: Any = [], post_processing_config: Any = None, create_deployment_config: Dict = {}, wait_for_deployment: bool = True, max_wait_time: int = 1200) -> Any: ...

    def get_deployment_info(self: Any) -> Dict: ...
        """
        Get deployment information.
        
                Returns:
                    Dict containing deployment information
        
                Raises:
                    RuntimeError: If deployment info cannot be retrieved
        """

    def get_index_to_category(self: Any) -> Dict: ...
        """
        Get index to category mapping.
        
                Returns:
                    Dict mapping indices to category names
        
                Raises:
                    RuntimeError: If category mapping cannot be retrieved
        """

    def get_prediction(self: Any, input_path: Optional[str] = None, input_bytes: Optional[bytes] = None, input_url: Optional[str] = None, extra_params: Optional[Dict] = None, auth_key: Optional[str] = None, apply_post_processing: bool = False) -> Union[Dict, str]: ...
        """
        Get prediction from the deployed model.
        
                Args:
                    input_path: Path to input file
                    input_bytes: Input data as bytes
                    input_url: URL to input data
                    extra_params: Additional parameters for the prediction
                    auth_key: Authentication key (uses instance auth_key if not provided)
                    apply_post_processing: Whether to apply post-processing
        
                Returns:
                    Prediction result from the model
        
                Raises:
                    ValueError: If no input is provided or auth key is missing
                    Exception: If prediction request fails
        """

    async def get_prediction_async(self: Any, input_path: Optional[str] = None, input_bytes: Optional[bytes] = None, input_url: Optional[str] = None, extra_params: Optional[Dict] = None, auth_key: Optional[str] = None, apply_post_processing: bool = False) -> Union[Dict, str]: ...
        """
        Get prediction from the deployed model asynchronously.
        
                Args:
                    input_path: Path to input file
                    input_bytes: Input data as bytes
                    input_url: URL to input data
                    extra_params: Additional parameters for the prediction
                    auth_key: Authentication key (uses instance auth_key if not provided)
                    apply_post_processing: Whether to apply post-processing
        
                Returns:
                    Prediction result from the model
        
                Raises:
                    ValueError: If no input is provided or auth key is missing
                    Exception: If prediction request fails
        """

    def get_status(self: Any) -> Dict: ...
        """
        Get comprehensive status information about the client and deployment.
        
                Returns:
                    Dict containing status information
        """

    def is_healthy(self: Any) -> bool: ...
        """
        Check if the deployment is healthy and ready to serve requests.
        
                Returns:
                    bool: True if deployment is healthy, False otherwise
        """

    def refresh_instances_info(self: Any, force: bool = False) -> Any: ...
        """
        Refresh instances information from the deployment.
        
                Args:
                    force: Whether to force refresh regardless of time elapsed
        """

    def wait_for_deployment(self: Any, timeout: Any = 1200) -> Any: ...

