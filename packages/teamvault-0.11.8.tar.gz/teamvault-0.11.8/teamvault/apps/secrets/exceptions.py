class PermissionError(Exception):
    pass
