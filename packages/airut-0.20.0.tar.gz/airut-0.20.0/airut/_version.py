"""Auto-generated at build time — do not edit."""

VERSION = 'v0.20.0'
GIT_SHA_SHORT = '597cb5a'
GIT_SHA_FULL = '597cb5adeb27d77fe403193944e71eb013d69b20'
