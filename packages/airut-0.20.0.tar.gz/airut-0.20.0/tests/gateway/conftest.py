# Copyright (c) 2026 Pyry Haulos
#
# This software is released under the MIT License.
# https://opensource.org/licenses/MIT

"""Shared pytest fixtures for email gateway tests."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture(autouse=True)
def _mock_sandbox(tmp_path: Path):
    """Mock Sandbox, ClaudeBinaryCache, and redirect XDG state.

    The sandbox calls podman which isn't available in test
    environments. Provide a mock that returns sensible defaults.

    ClaudeBinaryCache is also mocked to prevent network calls
    during tests.  The mock ``ensure()`` returns a fake path
    and version string.

    Also redirects ``get_storage_dir()`` to use ``tmp_path`` so
    tests don't touch the real filesystem.
    """
    mock_sandbox_class = MagicMock()
    mock_sandbox_instance = MagicMock()
    mock_sandbox_class.return_value = mock_sandbox_instance

    mock_binary_cache_class = MagicMock()
    mock_binary_cache = MagicMock()
    mock_binary_cache.ensure.return_value = (
        Path("/fake/claude"),
        "1.0.0",
    )
    mock_binary_cache_class.return_value = mock_binary_cache

    storage_root = tmp_path / "state"
    storage_root.mkdir(exist_ok=True)
    with (
        patch("airut.gateway.service.gateway.Sandbox", mock_sandbox_class),
        patch(
            "airut.gateway.service.gateway.ClaudeBinaryCache",
            mock_binary_cache_class,
        ),
        patch(
            "airut.gateway.config.user_state_path",
            return_value=storage_root,
        ),
    ):
        yield


@pytest.fixture
def email_config(tmp_path: Path, master_repo: Path):
    """Test email service configuration."""
    from airut.gateway.config import (
        EmailAccountConfig,
        EmailAuthConfig,
        EmailChannelConfig,
        ImapConfig,
        RepoServerConfig,
        SmtpConfig,
    )

    return RepoServerConfig(
        repo_id="test",
        git_repo_url=str(master_repo),
        channels={
            "email": EmailChannelConfig(
                account=EmailAccountConfig(
                    username="test@example.com",
                    from_address="Test Service <test@example.com>",
                    password="test_password",
                ),
                imap=ImapConfig(server="imap.example.com", port=993),
                smtp=SmtpConfig(server="smtp.example.com", port=587),
                auth=EmailAuthConfig(
                    authorized_senders=["authorized@example.com"],
                    trusted_authserv_id="mx.example.com",
                ),
            )
        },
    )


@pytest.fixture
def email_channel(email_config):
    """Return the EmailChannelConfig from the test config."""
    from airut.gateway.config import EmailChannelConfig

    ch = email_config.channels["email"]
    assert isinstance(ch, EmailChannelConfig)
    return ch


@pytest.fixture
def microsoft_oauth2_email_config(tmp_path: Path, master_repo: Path):
    """Test email config with Microsoft OAuth2 credentials.

    Mocks MSAL ConfidentialClientApplication to prevent network requests
    during tests.
    """
    from airut.gateway.config import (
        EmailAccountConfig,
        EmailAuthConfig,
        EmailChannelConfig,
        ImapConfig,
        MicrosoftOAuth2Config,
        RepoServerConfig,
        SmtpConfig,
    )

    with patch(
        "airut.gateway.email.microsoft_oauth2.ConfidentialClientApplication"
    ):
        yield RepoServerConfig(
            repo_id="test",
            git_repo_url=str(master_repo),
            channels={
                "email": EmailChannelConfig(
                    account=EmailAccountConfig(
                        username="test@company.com",
                        from_address="Test Service <test@company.com>",
                    ),
                    imap=ImapConfig(server="outlook.office365.com", port=993),
                    smtp=SmtpConfig(server="smtp.office365.com", port=587),
                    auth=EmailAuthConfig(
                        authorized_senders=["authorized@company.com"],
                        trusted_authserv_id="mx.company.com",
                    ),
                    microsoft_oauth2=MicrosoftOAuth2Config(
                        tenant_id="test-tenant-id",
                        client_id="test-client-id",
                        client_secret="test-client-secret",
                    ),
                )
            },
        )
