"""
Shared API handler functions for the admin dashboard.

Pure functions that take a Runtime and return a dict (or list).
handle_approval_resolve returns a (status_code, body_dict) tuple.
Used by both:
  - GatewayServer (FastAPI endpoints in server.py)
  - CloudChannel admin relay (_handle_admin_endpoint in cloud.py)
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from workpilot import __version__

if TYPE_CHECKING:
    from workpilot.runtime import Runtime


def handle_status(
    rt: Runtime,
    *,
    uptime_seconds: int | None = None,
    started_at: str | None = None,
    channels: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """GET /api/status — comprehensive runtime snapshot.

    Optional kwargs are added by the local gateway server which tracks
    uptime and channel state; the cloud relay omits them.
    """
    tools = rt.tool_registry.list_tools()
    by_risk: dict[str, int] = {"low": 0, "medium": 0, "high": 0, "critical": 0}
    for t in tools:
        risk = str(getattr(t.metadata, "risk_level", "low")).lower() if t.metadata else "low"
        by_risk[risk] = by_risk.get(risk, 0) + 1

    try:
        session_count = len(rt.session_manager.list_sessions())
    except Exception:
        session_count = 0

    sched_health = rt.scheduler.health() if rt.scheduler else {}

    result: dict[str, Any] = {
        "version": __version__,
        "status": "halted" if rt.estop.is_halted else "ok",
        "estop": rt.estop.status(),
        "bus": {
            "inbound_qsize": rt.bus.inbound_qsize,
            "outbound_qsize": rt.bus.outbound_qsize,
        },
        "provider": {"model": rt.config.agents.default.model},
        "sessions": {"count": session_count},
        "tools": {"count": len(tools), "by_risk": by_risk},
        "scheduler": {
            "enabled": sched_health.get("running", False),
            "job_count": sched_health.get("total_jobs", 0),
            "active_jobs": sched_health.get("active_jobs", 0),
        },
        "workspace": str(rt.workspace),
        "agent": {
            "name": rt.config.agents.default.name,
            "max_iterations": rt.config.agents.default.max_iterations,
        },
        "security": {
            "profile": rt.config.security.profile.value,
            "audit_enabled": rt.config.security.audit.enabled,
            "audit_redact": rt.config.security.audit.redact_secrets,
            "estop_on_leak": rt.config.security.estop.trigger_on_leak,
            "require_auth": rt.config.security.require_auth,
        },
    }
    if uptime_seconds is not None:
        result["uptime_seconds"] = uptime_seconds
    if started_at is not None:
        result["started_at"] = started_at
    if channels is not None:
        result["channels"] = channels
    return result


def handle_health(rt: Runtime) -> dict[str, Any]:
    """GET /api/health — basic health with E-stop and bus state."""
    return {
        "status": "halted" if rt.estop.is_halted else "ok",
        "version": __version__,
        "estop": rt.estop.status(),
        "bus": {
            "inbound_qsize": rt.bus.inbound_qsize,
            "outbound_qsize": rt.bus.outbound_qsize,
        },
    }


def handle_models(rt: Runtime) -> dict[str, Any]:
    """GET /api/models — list all configured models with context windows."""
    from workpilot.providers.model_catalog import get_context_window as get_model_context_window
    from workpilot.providers.resolver import resolve_model_chain

    providers = rt.config.providers
    agents_cfg = rt.config.agents

    def _chain_with_ctx(chain: list[str]) -> list[dict[str, Any]]:
        return [{"model": m, "context_window": get_model_context_window(m)} for m in chain]

    # Collect all agent models (builtin + user-defined)
    agents: dict[str, Any] = {}
    all_agents = dict(getattr(rt, "_all_agents", {}))
    if "default" not in all_agents:
        all_agents["default"] = agents_cfg.default
    for name, cfg in all_agents.items():
        model = cfg.model
        chain = resolve_model_chain(model, providers)
        entry: dict[str, Any] = {
            "alias": model,
            "chain": _chain_with_ctx(chain),
        }
        if cfg.metadata.get("internal"):
            entry["internal"] = True
        agents[name] = entry

    # Collect alias mappings
    aliases: dict[str, Any] = {}
    for alias in ("auto", "fast", "reasoning", "coding"):
        chain = resolve_model_chain(alias, providers)
        aliases[alias] = {"chain": _chain_with_ctx(chain)}

    return {"agents": agents, "aliases": aliases}


def handle_sessions(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/sessions — list all sessions."""
    return rt.session_manager.list_sessions()


def handle_session_detail(rt: Runtime, session_id: str) -> dict[str, Any] | None:
    """GET /api/sessions/{id} — session messages. Returns None if not found."""
    messages = rt.session_manager.get_messages(session_id)
    if not messages:
        return None
    return {"session_id": session_id, "messages": messages}


def handle_session_recent(
    rt: Runtime,
    channel: str = "web",
    sender_id: str = "ws-user",
    limit: int = 10,
) -> list[dict[str, Any]]:
    """GET /api/session/recent — last N visible messages for a channel/sender.

    Returns user, assistant, and approval_request turns (tool messages excluded).
    """
    session_id = rt.session_manager.get_or_create_id(channel, sender_id)
    messages = rt.session_manager.get_messages(session_id)
    visible = [m for m in messages if m.get("role") in ("user", "assistant", "approval_request")]
    return visible[-limit:]


def handle_tools(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/tools — list all registered tools and MCP servers with status."""
    active_names = {t.name for t in rt.tool_registry.get_active_tools()}
    result: list[dict[str, Any]] = []

    for t in rt.tool_registry.list_tools():
        category = t.metadata.category if t.metadata else "builtin"
        is_mcp_tool = category == "mcp"
        result.append(
            {
                "name": t.name,
                "description": t.description,
                "risk_level": t.metadata.risk_level if t.metadata else "low",
                "approval": t.metadata.approval if t.metadata else "auto",
                "tier": "mcp" if is_mcp_tool else (t.metadata.tier if t.metadata else "core"),
                "active": t.name in active_names,
                "type": "mcp_tool" if is_mcp_tool else "builtin",
            }
        )

    # MCP servers (connection-level entries)
    mcp_mgr = getattr(rt, "_mcp_manager", None)
    if mcp_mgr:
        for s in mcp_mgr.list_servers():
            if not s.enabled:
                continue
            result.append(
                {
                    "name": f"MCP_{s.name}",
                    "description": s.description or "",
                    "risk_level": "medium",
                    "approval": "auto",
                    "tier": "mcp",
                    "active": s.state.value == "connected",
                    "type": "mcp_server",
                    "state": s.state.value,
                    "tool_count": s.tool_count,
                }
            )

    return result


def handle_memory(rt: Runtime) -> dict[str, Any]:
    """GET /api/memory — MEMORY.md content + knowledge store entries."""
    result: dict[str, Any] = {"memory_md": "", "knowledge": []}

    memory_path = Path.home() / ".workpilot" / "MEMORY.md"
    if memory_path.exists():
        try:
            result["memory_md"] = memory_path.read_text(encoding="utf-8")
        except Exception:
            result["memory_md"] = "(error reading MEMORY.md)"

    try:
        mem = getattr(rt.agent, "_memory", None)
        if mem and hasattr(mem, "knowledge"):
            entries = mem.knowledge.search("", top_k=50)
            result["knowledge"] = [
                {
                    "id": e.get("id"),
                    "content": e.get("content", ""),
                    "category": e.get("category", ""),
                    "source": e.get("source", ""),
                    "created_at": e.get("created_at", ""),
                }
                for e in entries
            ]
    except Exception:
        pass

    return result


def handle_audit(rt: Runtime) -> dict[str, Any]:
    """GET /api/audit — recent audit log entries (last 200, newest first)."""
    return {"entries": rt.audit.recent_entries(200)}


def handle_cost(rt: Runtime) -> dict[str, Any]:
    """GET /api/cost — token usage stats."""
    return rt.usage_tracker.stats()


def handle_config(rt: Runtime) -> dict[str, Any] | None:
    """GET /api/config — read-only config snapshot. Returns None on error."""
    try:
        config_dict = rt.config.model_dump(mode="json")
        _redact_secrets(config_dict)
        return config_dict
    except Exception:
        return None


def handle_approvals(rt: Runtime) -> dict[str, Any]:
    """GET /api/approvals — pending + recently resolved approval queue."""
    pending: list[dict[str, Any]] = []
    resolved: list[dict[str, Any]] = []
    if hasattr(rt, "approval_manager") and rt.approval_manager:
        mgr = rt.approval_manager
        try:
            for req in mgr.get_pending():
                pending.append(
                    {
                        "id": req.id,
                        "tool_name": req.tool_name,
                        "args": req.args,
                        "agent_name": req.agent_name,
                        "risk": req.risk,
                        "reason": req.reason,
                        "status": req.status.value if hasattr(req.status, "value") else req.status,
                        "created_at": req.created_at.isoformat() if req.created_at else None,
                    }
                )
        except (AttributeError, Exception):
            pass
        # Include recently resolved requests (kept for 60s in _resolved)
        try:
            for req in mgr._resolved.values():
                resolved.append(
                    {
                        "id": req.id,
                        "tool_name": req.tool_name,
                        "status": req.status.value if hasattr(req.status, "value") else req.status,
                        "resolver": req.resolver,
                        "resolved_at": req.resolved_at.isoformat() if req.resolved_at else None,
                    }
                )
        except (AttributeError, Exception):
            pass
    return {"pending": pending, "resolved": resolved}


def handle_estop(rt: Runtime, reason: str = "admin dashboard") -> dict[str, Any]:
    """POST /api/estop — trigger emergency stop."""
    rt.estop.trigger(reason, actor="admin")
    return rt.estop.status()


def handle_reset(rt: Runtime, actor: str = "admin") -> dict[str, Any]:
    """POST /api/reset — reset emergency stop."""
    rt.estop.reset(actor=actor)
    return rt.estop.status()


def handle_approval_resolve(
    rt: Runtime,
    request_id: str,
    approved: bool,
    resolver: str = "admin",
    always: bool = False,
) -> tuple[int, dict[str, Any]]:
    """POST /api/approvals/{id}/resolve — returns (status_code, body)."""
    if not hasattr(rt, "approval_manager") or not rt.approval_manager:
        return 503, {"error": "Approval manager not available."}
    try:
        req = rt.approval_manager.get_request(request_id)
        rt.approval_manager.resolve(request_id, approved=approved, resolver=resolver)
        allowlist = getattr(rt, "_allowlist", None)
        if always and approved and req and allowlist:
            allowlist.add(req.tool_name, added_by=resolver, note="Added via web UI 'Always Allow'")

        # Persist resolution to session history directly
        # (Don't emit APPROVAL_RESOLVED — that handler also calls
        # approval_manager.resolve() which would fail with "already resolved")
        import json as _json

        status = "approved" if approved else "denied"
        for sid, msgs in rt.session_manager._sessions.items():
            for m in msgs:
                if m.get("role") != "approval_request":
                    continue
                try:
                    data = _json.loads(m.get("content", "{}"))
                except Exception:  # noqa: S112
                    continue
                if data.get("request_id") != request_id:
                    continue
                rt.session_manager.add_message(
                    sid,
                    {
                        "role": "approval_resolved",
                        "content": _json.dumps(
                            {
                                "request_id": request_id,
                                "status": status,
                                "resolver": resolver,
                            }
                        ),
                    },
                )
                break  # unique request_id

        return 200, {"status": "resolved", "approved": approved, "always": always}
    except Exception as exc:
        return 404, {"error": f"Approval not found or already resolved: {exc}"}


# ── Helpers ──────────────────────────────────────────────────────────────────


def _redact_secrets(d: dict[str, Any], _secret_keys: set[str] | None = None) -> None:
    """Recursively redact values for keys that look like secrets."""
    if _secret_keys is None:
        _secret_keys = {
            "api_key",
            "secret",
            "token",
            "password",
            "client_secret",
            "connection_string",
            "bypass_token",
        }
    for key in list(d.keys()):
        if isinstance(d[key], dict):
            _redact_secrets(d[key], _secret_keys)
        elif isinstance(d[key], str) and any(s in key.lower() for s in _secret_keys):
            if d[key]:
                d[key] = "***REDACTED***"
