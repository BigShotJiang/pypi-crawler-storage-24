"""
AgentLoop — the core agentic execution engine.

Implements: LLM call → tool calls → LLM call → ... → final response.

Inspired by HKUDS/nanobot's loop.py but enterprise-hardened with:
- Audit logging on every tool call
- Sandbox enforcement
- Memory consolidation
- RBAC-aware tool filtering
- Prompt injection detection
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger

from workpilot.agent.compaction import ContextCompactor
from workpilot.agent.context import ContextBuilder
from workpilot.agent.loop_detect import LoopDetector
from workpilot.agent.memory import MemoryStore
from workpilot.agent.reminders import ReminderTracker
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.bus.events import EventType, InboundMessage, OutboundMessage, StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.config.schema import AgentConfig
from workpilot.hooks.manager import (
    HookManager,
    HookVerdict,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from workpilot.providers.base import LLMProvider, LLMResponse
from workpilot.providers.resolver import resolve_model_chain
from workpilot.security.audit import AuditLogger
from workpilot.security.sanitizer import Sanitizer
from workpilot.session.manager import SessionManager

if TYPE_CHECKING:
    from workpilot.security.allowlist import AllowlistManager
    from workpilot.security.approval import ApprovalManager


class AgentLoop:
    """
    Main agent loop. Consumes inbound messages from the bus,
    runs the LLM+tool loop, publishes outbound responses.
    """

    def __init__(
        self,
        *,
        config: AgentConfig,
        provider: LLMProvider,
        tool_registry: ToolRegistry,
        bus: MessageBus,
        session_manager: SessionManager,
        audit: AuditLogger,
        workspace: Path,
        hooks: HookManager | None = None,
        available_agents: dict | None = None,
        prompt_mode: Literal["full", "minimal"] = "full",
        skills: list | None = None,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        mcp_configs: dict | None = None,
    ) -> None:
        self._config = config
        self._provider = provider
        self._tools = tool_registry
        self._bus = bus
        self._sessions = session_manager
        self._audit = audit
        self._workspace = workspace
        self._prompt_mode = prompt_mode
        self._context = ContextBuilder(
            config,
            workspace,
            available_agents=available_agents,
            tool_registry=tool_registry,
            mcp_configs=mcp_configs,
        )
        self._context.set_skills(skills or [])
        self._memory = MemoryStore(workspace)
        self._hooks = hooks
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._running = False

    async def start(self) -> None:
        """Start consuming messages from the bus."""
        self._running = True
        logger.info(f"Agent loop started (model={self._config.model})")
        while self._running:
            try:
                msg = await asyncio.wait_for(self._bus.get_inbound(), timeout=1.0)
                await self._process_message(msg)
            except TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error(f"Agent loop error: {exc}")

    async def stop(self) -> None:
        self._running = False

    async def run_once(
        self,
        prompt: str,
        session_id: str | None = None,
        *,
        channel: str | None = None,
        channel_id: str | None = None,
        exclude_tools: list[str] | None = None,
    ) -> str:
        """Run a single prompt through the agent (for CLI/API use)."""
        sid = session_id or self._sessions.get_or_create_id("cli", "local")
        logger.info(f"run_once: channel={channel or 'cli'} session={sid}")
        history = self._sessions.get_messages(sid, llm_only=True)
        response, _streamed = await self._agent_loop(
            prompt,
            history,
            sid,
            channel=channel,
            channel_id=channel_id,
            exclude_tools=exclude_tools,
        )
        return response

    # ── Typing indicators ───────────────────────────────────────────────

    def _start_typing(
        self, channel: str | None, channel_id: str | None, metadata: dict | None = None
    ) -> asyncio.Task | None:
        """Start a periodic typing indicator task. Returns the task (or None for CLI)."""
        if not channel or not channel_id or channel == "cli":
            return None

        payload = {"channel": channel, "channel_id": channel_id, "metadata": metadata or {}}

        # Emit immediately so the first indicator fires without waiting 3s
        self._bus.events.emit(EventType.TYPING_STARTED, payload)

        async def _typing_loop() -> None:
            try:
                while True:
                    await asyncio.sleep(3.0)
                    self._bus.events.emit(EventType.TYPING_STARTED, payload)
            except asyncio.CancelledError:
                pass

        task = asyncio.create_task(_typing_loop(), name="typing-indicator")
        return task

    def _stop_typing(
        self,
        task: asyncio.Task | None,
        channel: str | None = None,
        channel_id: str | None = None,
    ) -> None:
        """Cancel the typing indicator task and emit TYPING_STOPPED."""
        if task and not task.done():
            task.cancel()
        if channel and channel_id and channel != "cli":
            self._bus.events.emit(
                EventType.TYPING_STOPPED,
                {"channel": channel, "channel_id": channel_id},
            )

    # ── Slash commands ────────────────────────────────────────────────────

    async def _handle_slash(self, cmd: str, session_id: str, msg: InboundMessage) -> str | None:
        """Handle REPL slash commands. Returns reply string or None if not a known command."""

        parts = cmd.split(maxsplit=1)
        verb = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if verb == "/new":
            self._sessions.clear(session_id)
            return "Session cleared. Starting fresh."

        if verb == "/exit":
            return "Use Ctrl+C to exit the REPL."

        if verb == "/help":
            return (
                "**Available commands:**\n"
                "| Command | Description |\n|---------|-------------|\n"
                "| `/new` | Clear session, start fresh |\n"
                "| `/stop` | (use Ctrl+C to interrupt) |\n"
                "| `/status` | Show agent status |\n"
                "| `/memory` | Show MEMORY.md content |\n"
                "| `/tools` | List available tools |\n"
                "| `/skills` | List available skills |\n"
                "| `/history [N]` | Show last N messages (default 10) |\n"
                "| `/model [name]` | Show current model or switch to a new one mid-session |\n"
                "| `/exit` | Exit hint |\n"
            )

        if verb == "/status":
            msgs = self._sessions.get_messages(session_id)
            return (
                f"**Agent:** {self._config.name}  \n"
                f"**Model:** {self._config.model}  \n"
                f"**Session:** {session_id}  \n"
                f"**Messages:** {len(msgs)}  \n"
                f"**Max iterations:** {self._config.max_iterations}"
            )

        if verb == "/memory":
            content = self._memory.read_shared()
            return content if content.strip() else "_MEMORY.md is empty._"

        if verb == "/tools":
            tools = self._tools.list_tools()
            lines = ["**Available tools:**"]
            for t in tools:
                lines.append(f"- `{t.name}` — {t.description[:60]}")
            return "\n".join(lines)

        if verb == "/skills":
            try:
                skills = self._context._skills or []
                if not skills:
                    return "_No skills loaded._"
                lines = ["**Loaded skills:**"]
                for s in skills:
                    lines.append(f"- `{s.name}` — {getattr(s, 'description', '')[:60]}")
                return "\n".join(lines)
            except Exception:
                return "_Skills unavailable._"

        if verb == "/history":
            n = int(arg) if arg.isdigit() else 10
            msgs = self._sessions.get_messages(session_id)
            recent = msgs[-n:]
            if not recent:
                return "_No messages in history._"
            lines = []
            for m in recent:
                role = m.get("role", "?")
                content = m.get("content") or ""
                if isinstance(content, list):
                    content = " ".join(p.get("text", "") for p in content if isinstance(p, dict))
                snippet = str(content)[:120].replace("\n", " ")
                lines.append(f"**{role}:** {snippet}")
            return "\n".join(lines)

        if verb == "/model":
            if not arg:
                return f"Current model: `{self._config.model}`"
            new_model = arg.strip()
            # Validate aliases eagerly; concrete IDs (e.g. github/gpt-5.4) pass
            # through — they can only be validated at call time.
            chain = resolve_model_chain(new_model, getattr(self._provider, "_providers", None))
            if not chain:
                return (
                    f"Cannot switch to `{new_model}`: no provider credentials "
                    f"configured for this alias. Configure provider credentials "
                    f"(e.g. GITHUB_TOKEN, OPENAI_API_KEY, AZURE_OPENAI_API_KEY) "
                    f"or use a concrete model ID."
                )
            old_model = self._config.model
            self._config.model = new_model
            logger.info("Model switched: {} -> {}", old_model, new_model)
            resolved = chain[0] if chain[0] != new_model else None
            suffix = f" (resolves to `{resolved}`)" if resolved else ""
            reply = f"Model switched: `{old_model}` \u2192 `{new_model}`{suffix}"

            # Warn if history has tool calls from the old model — cross-model
            # call IDs can cause Responses API errors on the next message.
            history = self._sessions.get_messages(session_id)
            has_tool_history = any(
                m.get("role") == "tool" or (m.get("role") == "assistant" and m.get("tool_calls"))
                for m in history
            )
            if has_tool_history:
                reply += (
                    "\n\n\u26a0 History contains tool calls from the previous model."
                    " Run `/new` to clear history and avoid cross-model errors."
                )
            return reply

        if verb == "/stop":
            return "Use Ctrl+C to interrupt the current operation."

        # Unknown slash command — don't intercept, let it go to the agent
        return None

    # ── Internal ─────────────────────────────────────────────────────────

    async def _process_message(self, msg: InboundMessage) -> None:
        """Process a single inbound message through the agent loop."""
        session_id = (
            msg.session_key
            or msg.session_id
            or self._sessions.get_or_create_id(msg.channel, msg.sender_id)
        )

        logger.info(
            f"Inbound: channel={msg.channel} channel_id={msg.channel_id} session={session_id}"
        )
        self._audit.log_message(
            channel=msg.channel,
            direction="inbound",
            actor=msg.sender_id,
            session_id=session_id,
        )

        # Check for approval response commands
        if await self._try_route_approval(msg):
            return

        # Check for slash commands
        cmd = msg.content.strip()
        if cmd.startswith("/"):
            reply = await self._handle_slash(cmd, session_id, msg)
            if reply is not None:
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=msg.channel,
                        channel_id=msg.channel_id,
                        content=reply,
                        thread_id=msg.thread_id,
                    )
                )
                return

        # ── Hook: on_message_received ────────────────────────────────
        if self._hooks:
            hook_ctx = MessageHookContext(
                content=msg.content,
                channel=msg.channel,
                sender_id=msg.sender_id,
                session_id=session_id,
            )
            result = await self._hooks.dispatch_checked("on_message_received", hook_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Message rejected by hook: {}", result.reason)
                await self._bus.publish_outbound(
                    OutboundMessage(
                        channel=msg.channel,
                        channel_id=msg.channel_id,
                        content=f"Message blocked: {result.reason}",
                        thread_id=msg.thread_id,
                    )
                )
                return
        else:
            # Fallback: inline injection check when no hooks configured
            findings = Sanitizer.check_prompt_injection(msg.content)
            if findings:
                self._audit.log_security(
                    event="prompt_injection_detected",
                    details={"findings": findings, "sender": msg.sender_id},
                    severity="warning",
                )
                logger.warning(f"Prompt injection detected from {msg.sender_id}: {findings}")

        # Get history and run agent loop (filter UI-only roles like approval_request)
        history = self._sessions.get_messages(session_id, llm_only=True)

        # Start typing indicator (Teams/Cloud channels show "typing..." to the user)
        typing_task = self._start_typing(msg.channel, msg.channel_id, metadata=msg.metadata)
        try:
            response, streamed = await self._agent_loop(
                msg.content,
                history,
                session_id,
                channel=msg.channel,
                channel_id=msg.channel_id,
                thread_id=msg.thread_id,
                typing_task=typing_task,
            )
        except Exception as exc:
            logger.error(f"Agent loop error: {exc}")
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    content=f"Error: {exc}",
                    thread_id=msg.thread_id,
                )
            )
            return
        finally:
            # Stop typing indicator when response is ready (or on error)
            self._stop_typing(typing_task, msg.channel, msg.channel_id)

        # ── Hook: on_message_sent ────────────────────────────────────
        # Skip when streamed — _stream_response already ran this hook.
        if self._hooks and not streamed:
            out_ctx = MessageHookContext(
                content=response,
                channel=msg.channel,
                session_id=session_id,
            )
            result = await self._hooks.dispatch_checked("on_message_sent", out_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Outbound message blocked by hook: {}", result.reason)
                response = "[Message blocked by security policy]"
            elif result.data and isinstance(result.data, MessageHookContext):
                response = result.data.content

        # Skip the full OutboundMessage when content was already streamed —
        # channels already received every token via StreamingChunks.
        if not streamed:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    content=response,
                    thread_id=msg.thread_id,
                )
            )

        self._audit.log_message(
            channel=msg.channel,
            direction="outbound",
            actor="agent",
            session_id=session_id,
        )

    async def _agent_loop(
        self,
        user_input: str,
        history: list[dict[str, Any]],
        session_id: str,
        *,
        channel: str | None = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        typing_task: asyncio.Task | None = None,
        exclude_tools: list[str] | None = None,
    ) -> tuple[str, bool]:
        """
        Core agentic loop:
        1. Build context (system + history + user message)
        2. Call LLM with tools
        3. If tool calls → execute → append results → loop
        4. If text response → return
        """
        # Build messages
        messages = self._context.build_messages(
            history,
            user_input,
            mode=self._prompt_mode,
            channel=channel,
            channel_id=channel_id,
        )

        # Save user message to session
        self._sessions.add_message(session_id, {"role": "user", "content": user_input})

        max_iter = self._config.max_iterations
        iteration = 0
        loop_detector = LoopDetector()
        # Auto-detect context window from model catalog when not set explicitly
        from workpilot.providers.model_catalog import get_context_window as get_model_context_window

        context_limit = self._config.context_limit
        if context_limit is None:  # None = auto-detect from model catalog
            from workpilot.providers.resolver import resolve_model_chain

            chain = resolve_model_chain(
                self._config.model, getattr(self._provider, "_providers", None)
            )
            resolved = chain[0] if chain else self._config.model
            context_limit = get_model_context_window(resolved)

        compactor = ContextCompactor(
            context_limit=context_limit,
            provider=self._provider,
            model=self._config.model,
        )
        reminder = ReminderTracker(
            interval=self._config.reminder_interval,
            agent_name=self._config.name,
            user_task=user_input,
            workspace=self._workspace,
        )

        while iteration < max_iter:
            iteration += 1
            logger.debug(f"Agent iteration {iteration}/{max_iter}")

            # Refresh tool schemas each iteration (progressive loading may
            # have activated new tools since the last iteration)
            tool_schemas = self._tools.get_schemas(
                self._config.tools or None,
                exclude=exclude_tools,
            )

            # ── Context compaction check ───────────────────────────────
            pre_compact_len = len(messages)
            messages = await compactor.maybe_compact(messages)
            if len(messages) < pre_compact_len:
                # Compaction occurred — re-inject memory + task reminder
                new_reminders = reminder.build_post_compaction_reminders()
                # De-duplicate: remove any existing identical reminders to
                # prevent unbounded accumulation across repeated compactions.
                reminder_keys = {(m.get("role"), m.get("content")) for m in new_reminders}
                messages = [
                    m for m in messages if (m.get("role"), m.get("content")) not in reminder_keys
                ]
                messages.extend(new_reminders)

            # ── Graceful termination: Stage 1 — Nudge ────────────────
            if iteration == max_iter - 2:
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "You are approaching the iteration limit. "
                            "Please wrap up your current task and provide a final answer soon."
                        ),
                    }
                )

            # ── Graceful termination: Stage 2 — Force text ───────────
            # At iteration max-1, call LLM WITHOUT tools to force a text summary
            tools_for_call = tool_schemas if (tool_schemas and iteration < max_iter - 1) else None

            # When no tools are offered, use streaming for real-time token delivery
            if tools_for_call is None and channel and channel_id:
                # Stop typing indicator before streaming starts — the user
                # will see real tokens arriving instead of "typing…".
                self._stop_typing(typing_task, channel, channel_id)
                typing_task = None  # prevent double-cancel in finally block
                content = await self._stream_response(
                    messages=messages,
                    channel=channel,
                    channel_id=channel_id,
                    session_id=session_id,
                )
                self._sessions.add_message(session_id, {"role": "assistant", "content": content})
                messages.append({"role": "assistant", "content": content})
                # Fire-and-forget: don't block the response
                asyncio.create_task(self._maybe_consolidate(session_id))
                return content, True

            # Call LLM
            response: LLMResponse = await self._provider.complete(
                model=self._config.model,
                messages=messages,
                tools=tools_for_call,
            )

            # No tool calls → done
            if not response.tool_calls:
                content = response.content
                self._sessions.add_message(session_id, {"role": "assistant", "content": content})
                messages.append({"role": "assistant", "content": content})

                # Fire-and-forget: don't block the response
                asyncio.create_task(self._maybe_consolidate(session_id))

                return content, False

            # Has tool calls → execute them
            # Add assistant message with tool calls
            assistant_msg: dict[str, Any] = {
                "role": "assistant",
                "content": response.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments, ensure_ascii=False)
                            if isinstance(tc.arguments, dict)
                            else tc.arguments,
                        },
                    }
                    for tc in response.tool_calls
                ],
            }
            messages.append(assistant_msg)
            self._sessions.add_message(session_id, assistant_msg)

            # ── IronClaw 3-phase tool execution ─────────────────────
            tool_calls = response.tool_calls

            # Phase 1: Preflight — pre_tool_use hooks (sequential)
            approved: list[tuple[Any, bool]] = []  # (tc, blocked)
            preflight_results: dict[str, str] = {}  # tc.id → error msg
            for tc in tool_calls:
                logger.info(f"Tool call: {tc.name}({list(tc.arguments.keys())})")
                blocked = False
                # Block excluded tools even if LLM hallucinates them
                if exclude_tools and tc.name in exclude_tools:
                    blocked = True
                    preflight_results[tc.id] = f"Tool '{tc.name}' is not available."
                    approved.append((tc, blocked))
                    continue
                if self._hooks:
                    _tool = self._tools.get(tc.name)
                    pre_ctx = PreToolHookContext(
                        tool_name=tc.name,
                        args=tc.arguments,
                        agent_name=self._config.name,
                        session_id=session_id,
                        channel=channel or "",
                        channel_id=channel_id or "",
                        user_message=user_input,
                        tool_risk=_tool.metadata.risk_level if _tool else None,
                    )
                    pre_result = await self._hooks.dispatch_checked("pre_tool_use", pre_ctx)
                    if pre_result.verdict == HookVerdict.REJECT:
                        preflight_results[tc.id] = f"Tool '{tc.name}' blocked: {pre_result.reason}"
                        logger.warning(preflight_results[tc.id])
                        blocked = True
                approved.append((tc, blocked))

            # Phase 2: Execute — parallel for independent tools (asyncio.gather)
            # Safety: tools that share state (e.g., browser) are serialized
            # by deduplicating tool names — only one call per tool name runs concurrently.
            _STATEFUL_TOOLS = {"browser"}

            async def _execute_tool(tc: Any) -> str:
                return await self._tools.execute(
                    tc.name,
                    tc.arguments,
                    actor="agent",
                    session_id=session_id,
                    bus=self._bus,
                    channel=channel,
                    channel_id=channel_id,
                    thread_id=thread_id,
                )

            runnable = [(tc, blocked) for tc, blocked in approved if not blocked]
            # Split into parallelizable and serializable
            parallel_batch = []
            serial_batch = []
            seen_names: set[str] = set()
            for tc, _ in runnable:
                if tc.name in _STATEFUL_TOOLS or tc.name in seen_names:
                    serial_batch.append(tc)
                else:
                    parallel_batch.append(tc)
                    seen_names.add(tc.name)

            # Run parallel batch
            if parallel_batch:
                tasks = [_execute_tool(tc) for tc in parallel_batch]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                for tc, result in zip(parallel_batch, results):
                    if isinstance(result, Exception):
                        preflight_results[tc.id] = f"Error executing {tc.name}: {result}"
                    else:
                        preflight_results[tc.id] = str(result)

            # Run serial batch (stateful or duplicate tool names)
            for tc in serial_batch:
                try:
                    preflight_results[tc.id] = await _execute_tool(tc)
                except Exception as exc:
                    preflight_results[tc.id] = f"Error executing {tc.name}: {exc}"

            # Phase 3: Postflight — hooks see raw output, then redact (sequential)
            for tc, blocked in approved:
                result = preflight_results.get(tc.id, "")

                # post_tool_use hook BEFORE redaction (LeakScanner needs raw output)
                if self._hooks and not blocked:
                    post_ctx = PostToolHookContext(
                        tool_name=tc.name,
                        args=tc.arguments,
                        result=result,
                        agent_name=self._config.name,
                        session_id=session_id,
                    )
                    hook_result = await self._hooks.dispatch_checked("post_tool_use", post_ctx)
                    # Apply hook modifications (e.g., Redactor updates ctx.result)
                    if hook_result.data and isinstance(hook_result.data, PostToolHookContext):
                        result = hook_result.data.result

                # Redact secrets AFTER hooks have inspected raw output
                result = Sanitizer.redact_env_values(result)
                result = Sanitizer.truncate(result, 100_000)

                tool_msg: dict[str, Any] = {
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": result,
                }
                is_error = blocked or result.startswith("Error") or result.startswith("BLOCKED")
                messages.append(tool_msg)
                # Persist all results; errors marked with is_error flag so
                # get_messages(llm_only=True) skips them (prevents replay loops).
                if is_error:
                    tool_msg["is_error"] = True
                self._sessions.add_message(session_id, tool_msg)

            # ── Loop detection (AFTER all tool messages to preserve ordering) ─
            # OpenAI requires all tool-role messages to immediately follow
            # their assistant message with tool_calls — no system messages
            # may be inserted between them.
            for tc, _blocked in approved:
                warning, should_terminate = loop_detector.check(tc.name, tc.arguments)
                if warning:
                    messages.append({"role": "system", "content": warning})
                    if should_terminate:
                        return (
                            "I detected a repetitive loop and stopped to avoid wasting resources. "
                            f"Pattern: {warning}"
                        ), False

            # ── System reminders ──────────────────────────────────────
            # Track tool calls and inject periodic reminder if due
            reminder.record_tool_calls(len(tool_calls))
            if reminder.should_inject():
                messages.append(reminder.build_reminder())

            # Post-spawn reminder: if any tool call was a 'spawn' that
            # succeeded, inject a parent-task reminder so the agent
            # re-orients after processing delegated sub-agent results.
            spawn_calls = [tc for tc in tool_calls if tc.name == "spawn"]
            for sc in spawn_calls:
                result = preflight_results.get(sc.id, "")
                is_spawn_error = result.startswith("Error") or result.startswith("BLOCKED")
                if not is_spawn_error:
                    child_name = sc.arguments.get("agent", "sub-agent")
                    messages.append(reminder.build_post_spawn_reminder(child_name))

        # ── Graceful termination: Stage 3 — Hard stop ────────────────
        return (
            f"I reached the maximum number of iterations ({max_iter}). "
            "You can try breaking the task into smaller steps."
        ), False

    async def _try_route_approval(self, msg: InboundMessage) -> bool:
        """Intercept /approve, /deny, /always commands and metadata.approval_action.

        Returns ``True`` if the message was an approval response (consumed),
        ``False`` if it should proceed to the normal agent loop.
        """
        if self._approval_manager is None:
            return False

        mgr: ApprovalManager = self._approval_manager  # type: ignore[assignment]

        content = msg.content.strip()
        content_lower = content.lower()
        action: str | None = None
        request_id: str | None = None

        # Check metadata first (Teams Adaptive Card / Cloud structured response)
        if msg.metadata.get("approval_action"):
            action = msg.metadata["approval_action"]
            request_id = msg.metadata.get("approval_request_id")

        # Slash commands with explicit ID: /approve <id>, /deny <id>, /always <id>
        elif content.startswith("/approve "):
            action = "approve"
            request_id = content.split(maxsplit=1)[1].strip()
        elif content.startswith("/deny "):
            action = "deny"
            request_id = content.split(maxsplit=1)[1].strip()
        elif content.startswith("/always "):
            action = "always"
            request_id = content.split(maxsplit=1)[1].strip()

        # Simple keywords / bare commands — resolve against the single pending request
        # (fallback for web/Teams when UI buttons are not available)
        else:
            pending = mgr.get_pending()
            if len(pending) == 1:
                sole = pending[0]
                if content_lower in ("yes", "y", "approve", "/approve"):
                    action, request_id = "approve", sole.id
                elif content_lower in ("no", "n", "deny", "/deny"):
                    action, request_id = "deny", sole.id
                elif content_lower in ("always", "a", "/always"):
                    action, request_id = "always", sole.id

        if not action or not request_id:
            return False

        try:
            approved = action in ("approve", "always")
            mgr.resolve(request_id, approved=approved, resolver=msg.sender_id or "user")

            # "always" also adds to allowlist
            if action == "always" and self._allowlist is not None:
                resolved_req = mgr.get_request(request_id)
                if resolved_req:
                    self._allowlist.add(  # type: ignore[union-attr]
                        resolved_req.tool_name,
                        added_by=msg.sender_id or "user",
                        note="Added via /always command",
                    )

            status = "approved" if approved else "denied"
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    content=f"Tool call {status}.",
                    thread_id=msg.thread_id,
                )
            )
        except (KeyError, ValueError) as exc:
            await self._bus.publish_outbound(
                OutboundMessage(
                    channel=msg.channel,
                    channel_id=msg.channel_id,
                    content=f"Approval error: {exc}",
                    thread_id=msg.thread_id,
                )
            )
        return True

    async def _stream_response(
        self,
        *,
        messages: list[dict[str, Any]],
        channel: str,
        channel_id: str,
        session_id: str | None = None,
    ) -> str:
        """Stream a text-only LLM response, publishing chunks to the bus.

        Uses dispatch_outbound (handler-only, no queue) to avoid filling the
        bounded outbound queue with high-frequency StreamingChunks.  The done
        marker is always sent via try/finally so channels exit streaming state
        even when the provider raises mid-stream.
        """
        parts: list[str] = []
        try:
            async for chunk in self._provider.stream(
                model=self._config.model,
                messages=messages,
            ):
                if chunk.content:
                    parts.append(chunk.content)
                    await self._bus.dispatch_outbound(
                        StreamingChunk(
                            channel=channel,
                            channel_id=channel_id,
                            content=chunk.content,
                            done=False,
                        )
                    )
        finally:
            # Always send the done marker so channels exit streaming state
            await self._bus.dispatch_outbound(
                StreamingChunk(
                    channel=channel,
                    channel_id=channel_id,
                    content="",
                    done=True,
                )
            )
        content = "".join(parts)
        # Run on_message_sent hook on full accumulated content so outbound
        # hooks (e.g. leak scanner) can inspect the complete streamed response.
        if self._hooks:
            msg_ctx = MessageHookContext(
                content=content, channel=channel, session_id=session_id or ""
            )
            result = await self._hooks.dispatch_checked("on_message_sent", msg_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning(
                    "Streamed outbound message blocked by hook: {}",
                    result.reason,
                )
                content = "[Message blocked by security policy]"
            elif result.data and isinstance(result.data, MessageHookContext):
                content = result.data.content
        return content

    async def _maybe_consolidate(self, session_id: str) -> None:
        """Consolidate memory if conversation exceeds window size.

        Uses MemoryStore's per-workspace lock shared across all AgentLoop instances.
        """
        async with self._memory.consolidation_lock:
            await self._do_consolidate(session_id)

    async def _do_consolidate(self, session_id: str) -> None:
        messages = self._sessions.get_messages(session_id, llm_only=True)
        if len(messages) < self._config.memory_window:
            return

        trimmed = self._sessions.trim(session_id, self._config.memory_window // 2)
        if not trimmed:
            return

        logger.info(f"Consolidating {len(trimmed)} messages into memory")
        prompt = self._memory.build_consolidation_prompt(trimmed)
        try:
            response = await self._provider.complete(
                model=self._config.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=2048,
            )
            self._memory.apply_consolidation(response.content)
            logger.info("Memory consolidation complete")
        except Exception as exc:
            logger.error(f"Memory consolidation failed: {exc}")
