use kore::ffi::kore_version;

#[test]
fn ffi_version_matches_cargo_package_version() {
    let mut major = 0u32;
    let mut minor = 0u32;
    let mut patch = 0u32;
    let expected = (
        env!("CARGO_PKG_VERSION_MAJOR").parse::<u32>().unwrap(),
        env!("CARGO_PKG_VERSION_MINOR").parse::<u32>().unwrap(),
        env!("CARGO_PKG_VERSION_PATCH").parse::<u32>().unwrap(),
    );

    unsafe { kore_version(&mut major, &mut minor, &mut patch) };

    assert_eq!((major, minor, patch), expected);
}
