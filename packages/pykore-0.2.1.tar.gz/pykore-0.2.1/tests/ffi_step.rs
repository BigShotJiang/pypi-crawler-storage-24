use std::ptr;

use kore::ffi::{
    kore_create, kore_destroy, kore_step, kore_step_n, KoreConfig, KoreDiagnosticsSummary,
    KoreGrid, KoreStatus,
};
use kore::{Grid3, SpConfig, SpKernel3, State3};
use num_complex::Complex64;

#[test]
fn ffi_step_mutates_caller_owned_buffer() {
    let grid = KoreGrid {
        nx: 2,
        ny: 2,
        nz: 2,
        lx: 4.0,
        ly: 2.0,
        lz: 1.0,
    };
    let config = KoreConfig {
        dt: 0.01,
        hbar_over_m: 1.0,
        poisson_scale: 1.0,
        threads: 0,
    };
    let mut status = KoreStatus::KORE_ERR_INTERNAL;
    let kernel = unsafe { kore_create(grid, config, &mut status) };
    assert!(!kernel.is_null());
    assert_eq!(status, KoreStatus::KORE_OK);

    let mut psi = vec![
        Complex64::new(1.0, 0.5),
        Complex64::new(-0.25, 0.75),
        Complex64::new(0.0, -1.0),
        Complex64::new(0.5, 0.5),
        Complex64::new(-1.5, 0.0),
        Complex64::new(0.25, -0.25),
        Complex64::new(0.75, 1.25),
        Complex64::new(-0.5, -0.5),
    ];

    let ffi_status = unsafe { kore_step(kernel, psi.as_mut_ptr(), psi.len(), &mut status) };

    let native_grid = Grid3::new([2, 2, 2], [4.0, 2.0, 1.0]).unwrap();
    let native_config = SpConfig {
        dt: 0.01,
        poisson_scale: 1.0,
        threads: None,
    };
    let mut native_kernel = SpKernel3::new(native_grid, native_config).unwrap();
    let mut native_state = State3 {
        psi: vec![
            Complex64::new(1.0, 0.5),
            Complex64::new(-0.25, 0.75),
            Complex64::new(0.0, -1.0),
            Complex64::new(0.5, 0.5),
            Complex64::new(-1.5, 0.0),
            Complex64::new(0.25, -0.25),
            Complex64::new(0.75, 1.25),
            Complex64::new(-0.5, -0.5),
        ],
    };
    native_kernel.step(&mut native_state).unwrap();

    assert_eq!(ffi_status, KoreStatus::KORE_OK);
    assert_eq!(status, KoreStatus::KORE_OK);
    assert_eq!(psi, native_state.psi);

    unsafe { kore_destroy(kernel) };
}

#[test]
fn ffi_step_rejects_invalid_buffer_length_at_abi_boundary() {
    let grid = KoreGrid {
        nx: 2,
        ny: 2,
        nz: 2,
        lx: 4.0,
        ly: 2.0,
        lz: 1.0,
    };
    let config = KoreConfig {
        dt: 0.01,
        hbar_over_m: 1.0,
        poisson_scale: 1.0,
        threads: 0,
    };
    let mut status = KoreStatus::KORE_ERR_INTERNAL;
    let kernel = unsafe { kore_create(grid, config, &mut status) };
    assert!(!kernel.is_null());

    let mut psi = vec![Complex64::new(0.0, 0.0); 7];

    let ffi_status = unsafe { kore_step(kernel, psi.as_mut_ptr(), psi.len(), &mut status) };

    assert_eq!(ffi_status, KoreStatus::KORE_ERR_INVALID);
    assert_eq!(status, KoreStatus::KORE_ERR_INVALID);

    unsafe { kore_destroy(kernel) };
}

#[test]
fn ffi_step_n_writes_summary_with_relative_mass_drift() {
    let grid = KoreGrid {
        nx: 2,
        ny: 2,
        nz: 2,
        lx: 4.0,
        ly: 2.0,
        lz: 1.0,
    };
    let config = KoreConfig {
        dt: 0.01,
        hbar_over_m: 1.0,
        poisson_scale: 1.0,
        threads: 0,
    };
    let mut status = KoreStatus::KORE_ERR_INTERNAL;
    let kernel = unsafe { kore_create(grid, config, &mut status) };
    assert!(!kernel.is_null());
    assert_eq!(status, KoreStatus::KORE_OK);

    let mut psi = vec![
        Complex64::new(1.0, 0.5),
        Complex64::new(-0.25, 0.75),
        Complex64::new(0.0, -1.0),
        Complex64::new(0.5, 0.5),
        Complex64::new(-1.5, 0.0),
        Complex64::new(0.25, -0.25),
        Complex64::new(0.75, 1.25),
        Complex64::new(-0.5, -0.5),
    ];
    let mut summary = KoreDiagnosticsSummary::default();

    let ffi_status = unsafe {
        kore_step_n(
            kernel,
            psi.as_mut_ptr(),
            psi.len(),
            4,
            &mut summary,
            &mut status,
        )
    };

    let native_grid = Grid3::new([2, 2, 2], [4.0, 2.0, 1.0]).unwrap();
    let native_config = SpConfig {
        dt: 0.01,
        poisson_scale: 1.0,
        threads: None,
    };
    let mut native_kernel = SpKernel3::new(native_grid, native_config).unwrap();
    let mut native_state = State3 {
        psi: vec![
            Complex64::new(1.0, 0.5),
            Complex64::new(-0.25, 0.75),
            Complex64::new(0.0, -1.0),
            Complex64::new(0.5, 0.5),
            Complex64::new(-1.5, 0.0),
            Complex64::new(0.25, -0.25),
            Complex64::new(0.75, 1.25),
            Complex64::new(-0.5, -0.5),
        ],
    };
    let native_summary = native_kernel.step_n(&mut native_state, 4).unwrap();

    assert_eq!(ffi_status, KoreStatus::KORE_OK);
    assert_eq!(status, KoreStatus::KORE_OK);
    assert_eq!(psi, native_state.psi);
    assert_eq!(summary.initial_mass, native_summary.initial_mass);
    assert_eq!(summary.final_mass, native_summary.final_mass);
    assert_eq!(summary.min_mass, native_summary.min_mass);
    assert_eq!(summary.max_mass, native_summary.max_mass);
    assert_eq!(summary.steps, native_summary.steps as u64);
    assert_eq!(
        summary.max_mass_drift,
        native_summary.max_mass_drift / native_summary.initial_mass
    );

    unsafe { kore_destroy(kernel) };
}

#[test]
fn ffi_step_n_accepts_null_summary_pointer() {
    let grid = KoreGrid {
        nx: 2,
        ny: 2,
        nz: 2,
        lx: 4.0,
        ly: 2.0,
        lz: 1.0,
    };
    let config = KoreConfig {
        dt: 0.01,
        hbar_over_m: 1.0,
        poisson_scale: 1.0,
        threads: 0,
    };
    let mut status = KoreStatus::KORE_ERR_INTERNAL;
    let kernel = unsafe { kore_create(grid, config, &mut status) };
    assert!(!kernel.is_null());
    assert_eq!(status, KoreStatus::KORE_OK);

    let mut psi = vec![
        Complex64::new(1.0, 0.5),
        Complex64::new(-0.25, 0.75),
        Complex64::new(0.0, -1.0),
        Complex64::new(0.5, 0.5),
        Complex64::new(-1.5, 0.0),
        Complex64::new(0.25, -0.25),
        Complex64::new(0.75, 1.25),
        Complex64::new(-0.5, -0.5),
    ];
    let before = psi.clone();

    let ffi_status = unsafe {
        kore_step_n(
            kernel,
            psi.as_mut_ptr(),
            psi.len(),
            1,
            ptr::null_mut(),
            &mut status,
        )
    };

    assert_eq!(ffi_status, KoreStatus::KORE_OK);
    assert_eq!(status, KoreStatus::KORE_OK);
    assert_ne!(psi, before);

    unsafe { kore_destroy(kernel) };
}

#[test]
fn ffi_step_n_reports_zero_relative_drift_for_zero_mass_run() {
    let grid = KoreGrid {
        nx: 2,
        ny: 2,
        nz: 2,
        lx: 4.0,
        ly: 2.0,
        lz: 1.0,
    };
    let config = KoreConfig {
        dt: 0.01,
        hbar_over_m: 1.0,
        poisson_scale: 1.0,
        threads: 0,
    };
    let mut status = KoreStatus::KORE_ERR_INTERNAL;
    let kernel = unsafe { kore_create(grid, config, &mut status) };
    assert!(!kernel.is_null());
    assert_eq!(status, KoreStatus::KORE_OK);

    let mut psi = vec![Complex64::new(0.0, 0.0); 8];
    let mut summary = KoreDiagnosticsSummary::default();

    let ffi_status = unsafe {
        kore_step_n(
            kernel,
            psi.as_mut_ptr(),
            psi.len(),
            3,
            &mut summary,
            &mut status,
        )
    };

    assert_eq!(ffi_status, KoreStatus::KORE_OK);
    assert_eq!(status, KoreStatus::KORE_OK);
    assert!(psi.iter().all(|value| *value == Complex64::new(0.0, 0.0)));
    assert_eq!(summary.initial_mass, 0.0);
    assert_eq!(summary.final_mass, 0.0);
    assert_eq!(summary.min_mass, 0.0);
    assert_eq!(summary.max_mass, 0.0);
    assert_eq!(summary.max_mass_drift, 0.0);
    assert_eq!(summary.steps, 3);

    unsafe { kore_destroy(kernel) };
}
