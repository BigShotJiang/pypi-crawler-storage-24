use kore::ffi::{kore_create, kore_destroy, KoreConfig, KoreGrid, KoreStatus};

#[test]
fn ffi_create_and_destroy_kernel_handle() {
    let grid = KoreGrid {
        nx: 4,
        ny: 4,
        nz: 4,
        lx: 1.0,
        ly: 1.0,
        lz: 1.0,
    };
    let config = KoreConfig {
        dt: 0.01,
        hbar_over_m: 1.0,
        poisson_scale: 1.0,
        threads: 0,
    };
    let mut status = KoreStatus::KORE_ERR_INTERNAL;

    let kernel = unsafe { kore_create(grid, config, &mut status) };

    assert!(!kernel.is_null());
    assert_eq!(status, KoreStatus::KORE_OK);

    unsafe { kore_destroy(kernel) };
}

#[test]
fn ffi_create_returns_null_for_invalid_grid_without_status_pointer() {
    let grid = KoreGrid {
        nx: 0,
        ny: 4,
        nz: 4,
        lx: 1.0,
        ly: 1.0,
        lz: 1.0,
    };
    let config = KoreConfig {
        dt: 0.01,
        hbar_over_m: 1.0,
        poisson_scale: 1.0,
        threads: 0,
    };

    let kernel = unsafe { kore_create(grid, config, std::ptr::null_mut()) };

    assert!(kernel.is_null());
}

#[test]
fn ffi_create_returns_invalid_status_for_invalid_grid() {
    let grid = KoreGrid {
        nx: 0,
        ny: 4,
        nz: 4,
        lx: 1.0,
        ly: 1.0,
        lz: 1.0,
    };
    let config = KoreConfig {
        dt: 0.01,
        hbar_over_m: 1.0,
        poisson_scale: 1.0,
        threads: 0,
    };
    let mut status = KoreStatus::KORE_OK;

    let kernel = unsafe { kore_create(grid, config, &mut status) };

    assert!(kernel.is_null());
    assert_eq!(status, KoreStatus::KORE_ERR_INVALID);
}

#[test]
fn ffi_destroy_accepts_null_kernel() {
    unsafe { kore_destroy(std::ptr::null_mut()) };
}
