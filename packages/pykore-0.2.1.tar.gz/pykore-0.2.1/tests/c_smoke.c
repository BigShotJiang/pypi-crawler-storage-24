#include "kore.h"

#include <stdint.h>

int main(void) {
    uint32_t major = 0;
    uint32_t minor = 0;
    uint32_t patch = 0;

    kore_version(&major, &minor, &patch);

    return 0;
}
