use kore::DiagnosticsSummary;

#[test]
fn diagnostics_summary_tracks_mass_extrema() {
    let mut summary = DiagnosticsSummary::new(1.0);

    summary.record_step(0.99);
    summary.record_step(1.01);

    assert_eq!(summary.min_mass, 0.99);
    assert_eq!(summary.max_mass, 1.01);
    assert_eq!(summary.final_mass, 1.01);
    assert_eq!(summary.steps, 2);
    assert!((summary.max_mass_drift - 0.01).abs() < 1e-12);
}
