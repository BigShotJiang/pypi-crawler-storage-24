#![cfg(feature = "checkpoint-hdf5")]

use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

use kore::{
    io::{load_checkpoint, save_checkpoint, CURRENT_SCHEMA_VERSION},
    Error, Grid3, State3,
};
use num_complex::Complex64;
fn temp_file(name: &str) -> PathBuf {
    let unique = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_nanos();
    std::env::temp_dir().join(format!("{name}-{unique}.h5"))
}

#[test]
fn save_checkpoint_writes_minimal_grid_and_state() {
    let path = temp_file("minimal.h5");
    let grid = Grid3::new([4, 4, 4], [1.0, 1.0, 1.0]).unwrap();
    let state = State3::zeros(&grid);

    save_checkpoint(&path, &grid, &state).unwrap();

    let file = hdf5::File::open(&path).unwrap();
    let root = file.group("kore_checkpoint").unwrap();
    assert_eq!(
        root.attr("version")
            .unwrap()
            .read_scalar::<hdf5::types::VarLenUnicode>()
            .unwrap()
            .as_str(),
        CURRENT_SCHEMA_VERSION
    );
    assert!(root.group("grid").is_ok());
    assert!(root.group("state").unwrap().dataset("psi").is_ok());
}

#[test]
fn load_checkpoint_restores_saved_grid_and_state() {
    let path = temp_file("roundtrip.h5");
    let grid = Grid3::new([4, 4, 4], [1.0, 2.0, 3.0]).unwrap();
    let mut state = State3::zeros(&grid);
    state.psi[0] = Complex64::new(1.0, 0.5);
    state.psi[7] = Complex64::new(-0.5, 2.0);

    save_checkpoint(&path, &grid, &state).unwrap();
    let (loaded_grid, loaded_state) = load_checkpoint(&path).unwrap();

    assert_eq!(loaded_grid.shape(), grid.shape());
    assert_eq!(loaded_grid.lengths(), grid.lengths());
    assert_eq!(loaded_state.psi, state.psi);
}

#[test]
fn load_checkpoint_rejects_incompatible_version() {
    let path = temp_file("bad_version.h5");
    let file = hdf5::File::create(&path).unwrap();
    let root = file.create_group("kore_checkpoint").unwrap();
    let version: hdf5::types::VarLenUnicode = "2.0".parse().unwrap();
    root.new_attr::<hdf5::types::VarLenUnicode>()
        .shape(())
        .create("version")
        .unwrap()
        .write_scalar(&version)
        .unwrap();

    let err = load_checkpoint(&path).unwrap_err();
    assert_eq!(
        err,
        Error::IncompatibleCheckpoint {
            found: "2.0".into(),
            expected: "1.0".into(),
        }
    );
}

#[test]
fn anisotropic_roundtrip_preserves_row_major_psi_layout() {
    let path = temp_file("anisotropic.h5");
    let grid = Grid3::new([16, 8, 4], [1.0, 1.0, 1.0]).unwrap();
    let mut state = State3::zeros(&grid);
    for (index, value) in state.psi.iter_mut().enumerate() {
        *value = Complex64::new(index as f64, -(index as f64));
    }

    save_checkpoint(&path, &grid, &state).unwrap();
    let (_, loaded_state) = load_checkpoint(&path).unwrap();

    assert_eq!(loaded_state.psi, state.psi);
}

#[test]
fn missing_optional_groups_are_accepted() {
    let path = temp_file("missing_optional.h5");
    let grid = Grid3::new([4, 4, 4], [1.0, 1.0, 1.0]).unwrap();
    let state = State3::zeros(&grid);
    save_checkpoint(&path, &grid, &state).unwrap();

    assert!(load_checkpoint(&path).is_ok());
}

#[test]
fn malformed_optional_groups_are_errors() {
    let path = temp_file("bad_optional.h5");
    let grid = Grid3::new([4, 4, 4], [1.0, 1.0, 1.0]).unwrap();
    let state = State3::zeros(&grid);
    save_checkpoint(&path, &grid, &state).unwrap();

    let file = hdf5::File::open_rw(&path).unwrap();
    let root = file.group("kore_checkpoint").unwrap();
    let config = root.create_group("config").unwrap();
    config
        .new_attr::<f64>()
        .shape(())
        .create("dt")
        .unwrap()
        .write_scalar(&0.01)
        .unwrap();

    let err = load_checkpoint(&path).unwrap_err();
    assert_eq!(err, Error::MalformedCheckpointField("hbar_over_m"));
}

#[test]
fn malformed_required_checkpoint_data_are_errors() {
    let path = temp_file("missing_psi.h5");
    let file = hdf5::File::create(&path).unwrap();
    let root = file.create_group("kore_checkpoint").unwrap();
    let version: hdf5::types::VarLenUnicode = CURRENT_SCHEMA_VERSION.parse().unwrap();
    root.new_attr::<hdf5::types::VarLenUnicode>()
        .shape(())
        .create("version")
        .unwrap()
        .write_scalar(&version)
        .unwrap();
    let grid = root.create_group("grid").unwrap();
    for (name, value) in [("nx", 4_u64), ("ny", 4_u64), ("nz", 4_u64)] {
        grid.new_attr::<u64>()
            .shape(())
            .create(name)
            .unwrap()
            .write_scalar(&value)
            .unwrap();
    }
    for (name, value) in [("lx", 1.0_f64), ("ly", 1.0_f64), ("lz", 1.0_f64)] {
        grid.new_attr::<f64>()
            .shape(())
            .create(name)
            .unwrap()
            .write_scalar(&value)
            .unwrap();
    }
    root.create_group("state").unwrap();

    let err = load_checkpoint(&path).unwrap_err();
    assert_eq!(err, Error::MissingCheckpointField("state/psi"));
}

#[test]
fn golden_v1_fixture_loads_exactly() {
    let path = PathBuf::from("tests/fixtures/golden_v1.h5");
    let (grid, state) = load_checkpoint(&path).unwrap();

    assert_eq!(grid.shape(), [4, 4, 4]);
    assert_eq!(grid.lengths(), [1.0, 1.0, 1.0]);
    assert_eq!(state.psi.len(), 64);
    assert_eq!(state.psi[0], Complex64::new(1.0, 0.0));
    assert!(state
        .psi
        .iter()
        .skip(1)
        .all(|value| *value == Complex64::new(0.0, 0.0)));
}
