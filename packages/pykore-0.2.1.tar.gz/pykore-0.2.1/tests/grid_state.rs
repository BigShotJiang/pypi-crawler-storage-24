use kore::{Error, Grid3, State3};

#[test]
fn grid_reports_expected_shape_and_len() {
    let grid = Grid3::new([4, 5, 6], [1.0, 2.0, 3.0]).unwrap();
    assert_eq!(grid.shape(), [4, 5, 6]);
    assert_eq!(grid.len(), 120);
    assert_eq!(State3::zeros(&grid).psi.len(), 120);
}

#[test]
fn grid_rejects_zero_shape_with_crate_error() {
    let result = Grid3::new([0, 5, 6], [1.0, 2.0, 3.0]);
    assert!(matches!(result, Err(Error::InvalidGridShape)));
}

#[test]
fn grid_round_trips_flat_indices() {
    let grid = Grid3::new([3, 4, 5], [1.0, 1.0, 1.0]).unwrap();
    let flat = grid.flatten([2, 1, 4]).unwrap();

    assert_eq!(grid.unflatten(flat).unwrap(), [2, 1, 4]);
}

#[test]
fn grid_rejects_out_of_bounds_indices_with_crate_error() {
    let grid = Grid3::new([3, 4, 5], [1.0, 1.0, 1.0]).unwrap();

    assert!(matches!(
        grid.flatten([3, 1, 4]),
        Err(Error::InvalidGridIndex)
    ));
}

#[test]
fn grid_rejects_out_of_bounds_flat_index_with_crate_error() {
    let grid = Grid3::new([3, 4, 5], [1.0, 1.0, 1.0]).unwrap();

    assert!(matches!(
        grid.unflatten(grid.len()),
        Err(Error::InvalidGridIndex)
    ));
}
