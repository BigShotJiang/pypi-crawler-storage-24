use kore::{Diagnostics, Grid3, State3};
use num_complex::Complex64;

#[test]
fn diagnostics_from_zero_state_are_zeroed() {
    let grid = Grid3::new([2, 2, 2], [1.0, 1.0, 1.0]).unwrap();
    let state = State3::zeros(&grid);
    let diagnostics = Diagnostics::from_state(&grid, &state);

    assert_eq!(diagnostics.max_density, 0.0);
    assert_eq!(diagnostics.mass, 0.0);
    assert_eq!(diagnostics.l2_norm, 0.0);
}

#[test]
fn diagnostics_from_nonzero_state_use_cell_volume_scaled_norms() {
    let grid = Grid3::new([2, 1, 1], [4.0, 1.0, 1.0]).unwrap();
    let state = State3 {
        psi: vec![Complex64::new(1.0, 0.0), Complex64::new(0.0, 2.0)],
    };
    let diagnostics = Diagnostics::from_state(&grid, &state);

    assert_eq!(diagnostics.max_density, 4.0);
    assert_eq!(diagnostics.mass, 10.0);
    assert_eq!(diagnostics.l2_norm, 10.0_f64.sqrt());
}
