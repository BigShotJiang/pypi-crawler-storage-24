use kore::{Diagnostics, Grid3, State3};

#[test]
fn threaded_and_default_diagnostics_match() {
    let grid = Grid3::new([4, 4, 4], [1.0, 1.0, 1.0]).unwrap();
    let state = State3::plane_wave(&grid, [1, 0, 0]);
    let default = Diagnostics::from_state(&grid, &state);
    let threaded = Diagnostics::from_state_with_threads(&grid, &state, Some(2));

    assert!((default.mass - threaded.mass).abs() < 1e-12);
    assert!((default.max_density - threaded.max_density).abs() < 1e-12);
    assert!((default.l2_norm - threaded.l2_norm).abs() < 1e-12);
}
