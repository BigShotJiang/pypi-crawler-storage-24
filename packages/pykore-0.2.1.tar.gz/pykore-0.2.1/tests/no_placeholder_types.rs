const STUB_FILES: &[&str] = &["src/threading.rs", "src/fft/rustfft.rs"];

#[test]
fn task_one_stub_modules_do_not_define_placeholder_public_types() {
    for path in STUB_FILES {
        let full_path = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join(path);
        let contents = std::fs::read_to_string(&full_path).expect("stub file should exist");

        assert!(
            !contents.contains("pub struct ")
                && !contents.contains("pub enum ")
                && !contents.contains("pub trait ")
                && !contents.contains("pub type "),
            "{} still defines a placeholder public item",
            full_path.display()
        );
    }
}
