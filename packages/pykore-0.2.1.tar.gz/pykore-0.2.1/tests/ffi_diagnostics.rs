use kore::ffi::{
    kore_create, kore_destroy, kore_diagnostics, KoreConfig, KoreDiagnostics, KoreGrid, KoreStatus,
};
use kore::{Grid3, SpConfig, SpKernel3, State3};
use num_complex::Complex64;

#[test]
fn ffi_diagnostics_matches_rust_kernel_for_caller_owned_complex_buffer() {
    let grid = KoreGrid {
        nx: 2,
        ny: 2,
        nz: 2,
        lx: 4.0,
        ly: 2.0,
        lz: 1.0,
    };
    let config = KoreConfig {
        dt: 0.01,
        hbar_over_m: 1.0,
        poisson_scale: 1.0,
        threads: 0,
    };
    let mut status = KoreStatus::KORE_ERR_INTERNAL;
    let kernel = unsafe { kore_create(grid, config, &mut status) };
    assert!(!kernel.is_null());
    assert_eq!(status, KoreStatus::KORE_OK);

    let psi = vec![
        Complex64::new(1.0, 0.5),
        Complex64::new(-0.25, 0.75),
        Complex64::new(0.0, -1.0),
        Complex64::new(0.5, 0.5),
        Complex64::new(-1.5, 0.0),
        Complex64::new(0.25, -0.25),
        Complex64::new(0.75, 1.25),
        Complex64::new(-0.5, -0.5),
    ];
    let mut diagnostics = KoreDiagnostics::default();

    let ffi_status = unsafe {
        kore_diagnostics(
            kernel,
            psi.as_ptr(),
            psi.len(),
            &mut diagnostics,
            &mut status,
        )
    };

    let native_grid = Grid3::new([2, 2, 2], [4.0, 2.0, 1.0]).unwrap();
    let native_config = SpConfig {
        dt: 0.01,
        poisson_scale: 1.0,
        threads: None,
    };
    let native_kernel = SpKernel3::new(native_grid.clone(), native_config).unwrap();
    let native_state = State3 { psi };
    let native = native_kernel.diagnostics(&native_state).unwrap();

    assert_eq!(ffi_status, KoreStatus::KORE_OK);
    assert_eq!(status, KoreStatus::KORE_OK);
    assert_eq!(diagnostics.mass, native.mass);
    assert_eq!(diagnostics.max_density, native.max_density);
    assert_eq!(diagnostics.l2_norm, native.l2_norm);

    unsafe { kore_destroy(kernel) };
}
