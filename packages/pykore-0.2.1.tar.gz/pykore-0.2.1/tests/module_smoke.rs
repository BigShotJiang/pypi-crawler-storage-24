#[allow(unused_imports)]
use kore::ffi::{KoreConfig, KoreDiagnostics, KoreDiagnosticsSummary, KoreGrid, KoreStatus};
#[allow(unused_imports)]
use kore::{Diagnostics, DiagnosticsSummary, Error, Grid3, SpConfig, SpKernel3, State3};

#[test]
fn crate_root_exposes_stable_direct_imports() {
    let _ = stringify!(
        Grid3,
        State3,
        SpConfig,
        SpKernel3,
        Diagnostics,
        DiagnosticsSummary,
        Error
    );
}

#[test]
fn ffi_module_exposes_stable_abi_types() {
    let _grid = KoreGrid {
        nx: 8,
        ny: 8,
        nz: 8,
        lx: 1.0,
        ly: 1.0,
        lz: 1.0,
    };

    let _config = KoreConfig {
        dt: 0.1,
        hbar_over_m: 1.0,
        poisson_scale: 2.0,
        threads: 4,
    };

    let _diagnostics = KoreDiagnostics {
        mass: 1.0,
        max_density: 2.0,
        l2_norm: 3.0,
    };

    let _summary = KoreDiagnosticsSummary {
        initial_mass: 1.0,
        final_mass: 1.0,
        min_mass: 0.9,
        max_mass: 1.1,
        max_mass_drift: 0.1,
        steps: 16,
    };

    let _ = KoreStatus::KORE_OK;
    let _ = KoreStatus::KORE_ERR_NULL;
    let _ = KoreStatus::KORE_ERR_INVALID;
    let _ = KoreStatus::KORE_ERR_INTERNAL;
}
