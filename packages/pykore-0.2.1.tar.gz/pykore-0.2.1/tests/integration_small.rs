use kore::{Grid3, SpConfig, SpKernel3, State3};

#[test]
fn small_smoke_suite_runs_on_multiple_shapes() {
    for shape in [[8, 8, 8], [16, 8, 4]] {
        let grid = Grid3::new(shape, [1.0, 1.0, 1.0]).unwrap();
        let config = SpConfig::default();
        let mut kernel = SpKernel3::new(grid.clone(), config).unwrap();
        let mut state = State3::plane_wave(&grid, [1, 0, 0]);
        let initial_mass = kernel.diagnostics(&state).unwrap().mass;

        let diagnostics = kernel.step(&mut state).unwrap();

        assert!(diagnostics.mass.is_finite());
        assert!(diagnostics.max_density.is_finite());
        assert!(diagnostics.l2_norm.is_finite());
        assert!((diagnostics.mass - initial_mass).abs() < 1e-8);
    }
}
