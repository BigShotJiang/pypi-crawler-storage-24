use std::f64::consts::TAU;

use kore::{Grid3, SpConfig, SpKernel3, State3};
use num_complex::Complex64;

#[test]
fn zero_state_remains_zero_after_one_step() {
    let grid = Grid3::new([4, 4, 4], [1.0, 1.0, 1.0]).unwrap();
    let config = SpConfig::default();
    let mut kernel = SpKernel3::new(grid.clone(), config).unwrap();
    let mut state = State3::zeros(&grid);
    let diagnostics = kernel.step(&mut state).unwrap();

    assert!(state.psi.iter().all(|value| value.norm() < 1e-12));
    assert_eq!(diagnostics.mass, 0.0);
}

#[test]
fn repeated_steps_keep_mass_bounded() {
    let grid = Grid3::new([8, 8, 8], [1.0, 1.0, 1.0]).unwrap();
    let config = SpConfig::default();
    let mut kernel = SpKernel3::new(grid.clone(), config).unwrap();
    let mut state = State3::plane_wave(&grid, [1, 0, 0]);
    let initial = kernel.diagnostics(&state).unwrap().mass;
    let summary = kernel.step_n(&mut state, 4).unwrap();

    assert!((summary.final_mass - initial).abs() < 1e-8);
    assert!(summary.max_mass_drift < 1e-8);
}

#[test]
fn step_recomputes_second_half_kick_from_post_kinetic_state() {
    let grid = Grid3::new([4, 4, 4], [1.0, 1.0, 1.0]).unwrap();
    let config = SpConfig {
        dt: 0.2,
        ..SpConfig::default()
    };
    let mut kernel = SpKernel3::new(grid.clone(), config).unwrap();
    let mut state = State3::zeros(&grid);

    state.psi[grid.flatten([0, 0, 0]).unwrap()] = Complex64::new(1.0, 0.0);
    state.psi[grid.flatten([1, 2, 3]).unwrap()] = Complex64::new(-0.25, 0.75);
    state.psi[grid.flatten([3, 1, 2]).unwrap()] = Complex64::new(0.5, -0.5);

    let initial = state.psi.clone();
    let expected = direct_strang_step(&grid, &initial, config, true);
    let stale = direct_strang_step(&grid, &initial, config, false);

    assert!(expected
        .iter()
        .zip(stale.iter())
        .any(|(left, right)| (*left - *right).norm() > 1.0e-6));

    kernel.step(&mut state).unwrap();

    for (got, want) in state.psi.iter().zip(expected.iter()) {
        assert!((*got - *want).norm() < 1.0e-10, "got {got}, want {want}");
    }
}

fn direct_strang_step(
    grid: &Grid3,
    initial: &[Complex64],
    config: SpConfig,
    recompute_second_potential: bool,
) -> Vec<Complex64> {
    let mut psi = initial.to_vec();
    let first_potential = direct_poisson_potential(grid, &psi, config.poisson_scale);

    for (value, &potential) in psi.iter_mut().zip(first_potential.iter()) {
        *value *= unit_phase(-0.5 * config.dt * potential);
    }

    let mut spectrum = direct_forward_fft(grid, &psi);
    for (value, &k2) in spectrum.iter_mut().zip(squared_wave_numbers(grid).iter()) {
        *value *= unit_phase(-config.dt * k2);
    }
    psi = direct_inverse_fft(grid, &spectrum);

    let second_potential = if recompute_second_potential {
        direct_poisson_potential(grid, &psi, config.poisson_scale)
    } else {
        first_potential
    };

    for (value, &potential) in psi.iter_mut().zip(second_potential.iter()) {
        *value *= unit_phase(-0.5 * config.dt * potential);
    }

    psi
}

fn direct_poisson_potential(grid: &Grid3, psi: &[Complex64], poisson_scale: f64) -> Vec<f64> {
    let shape = grid.shape();
    let lengths = grid.lengths();
    let density: Vec<f64> = psi.iter().map(|value| value.norm_sqr()).collect();
    let mut spectrum = vec![Complex64::new(0.0, 0.0); grid.len()];

    for kx in 0..shape[0] {
        for ky in 0..shape[1] {
            for kz in 0..shape[2] {
                let mut sum = Complex64::new(0.0, 0.0);
                for x in 0..shape[0] {
                    for y in 0..shape[1] {
                        for z in 0..shape[2] {
                            let index = grid.flatten([x, y, z]).unwrap();
                            let phase = -TAU
                                * ((kx * x) as f64 / shape[0] as f64
                                    + (ky * y) as f64 / shape[1] as f64
                                    + (kz * z) as f64 / shape[2] as f64);
                            sum += density[index] * unit_phase(phase);
                        }
                    }
                }

                let k2 = squared_wave_number([kx, ky, kz], shape, lengths);
                let coeff = if k2 == 0.0 { 0.0 } else { -poisson_scale / k2 };
                let index = grid.flatten([kx, ky, kz]).unwrap();
                spectrum[index] = sum * coeff;
            }
        }
    }

    direct_inverse_fft(grid, &spectrum)
        .into_iter()
        .map(|value| value.re)
        .collect()
}

fn direct_forward_fft(grid: &Grid3, input: &[Complex64]) -> Vec<Complex64> {
    let shape = grid.shape();
    let mut spectrum = vec![Complex64::new(0.0, 0.0); grid.len()];

    for kx in 0..shape[0] {
        for ky in 0..shape[1] {
            for kz in 0..shape[2] {
                let mut sum = Complex64::new(0.0, 0.0);
                for x in 0..shape[0] {
                    for y in 0..shape[1] {
                        for z in 0..shape[2] {
                            let index = grid.flatten([x, y, z]).unwrap();
                            let phase = -TAU
                                * ((kx * x) as f64 / shape[0] as f64
                                    + (ky * y) as f64 / shape[1] as f64
                                    + (kz * z) as f64 / shape[2] as f64);
                            sum += input[index] * unit_phase(phase);
                        }
                    }
                }

                let index = grid.flatten([kx, ky, kz]).unwrap();
                spectrum[index] = sum;
            }
        }
    }

    spectrum
}

fn direct_inverse_fft(grid: &Grid3, spectrum: &[Complex64]) -> Vec<Complex64> {
    let shape = grid.shape();
    let norm = grid.len() as f64;
    let mut output = vec![Complex64::new(0.0, 0.0); grid.len()];

    for x in 0..shape[0] {
        for y in 0..shape[1] {
            for z in 0..shape[2] {
                let mut sum = Complex64::new(0.0, 0.0);
                for kx in 0..shape[0] {
                    for ky in 0..shape[1] {
                        for kz in 0..shape[2] {
                            let index = grid.flatten([kx, ky, kz]).unwrap();
                            let phase = TAU
                                * ((kx * x) as f64 / shape[0] as f64
                                    + (ky * y) as f64 / shape[1] as f64
                                    + (kz * z) as f64 / shape[2] as f64);
                            sum += spectrum[index] * unit_phase(phase);
                        }
                    }
                }

                let index = grid.flatten([x, y, z]).unwrap();
                output[index] = sum / norm;
            }
        }
    }

    output
}

fn squared_wave_numbers(grid: &Grid3) -> Vec<f64> {
    let shape = grid.shape();
    let lengths = grid.lengths();
    let mut values = Vec::with_capacity(grid.len());

    for kx in 0..shape[0] {
        for ky in 0..shape[1] {
            for kz in 0..shape[2] {
                values.push(squared_wave_number([kx, ky, kz], shape, lengths));
            }
        }
    }

    values
}

fn squared_wave_number(mode: [usize; 3], shape: [usize; 3], lengths: [f64; 3]) -> f64 {
    mode.into_iter()
        .zip(shape)
        .zip(lengths)
        .map(|((index, size), length)| {
            let signed = if index <= size / 2 {
                index as isize
            } else {
                index as isize - size as isize
            };
            let k = signed as f64 * TAU / length;
            k * k
        })
        .sum()
}

fn unit_phase(theta: f64) -> Complex64 {
    Complex64::new(theta.cos(), theta.sin())
}
