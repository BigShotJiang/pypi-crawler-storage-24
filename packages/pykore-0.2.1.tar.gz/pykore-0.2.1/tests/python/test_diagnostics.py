import pytest


def test_diagnostics_value_objects_expose_attributes_and_informative_repr():
    import pykore

    diagnostics = pykore.Diagnostics(mass=1.5, max_density=2.5, l2_norm=3.5)
    summary = pykore.DiagnosticsSummary(
        initial_mass=1.0,
        final_mass=0.99,
        min_mass=0.98,
        max_mass=1.01,
        max_mass_drift=0.02,
        steps=4,
    )

    assert diagnostics.mass == 1.5
    assert diagnostics.max_density == 2.5
    assert diagnostics.l2_norm == 3.5
    assert repr(diagnostics) == ("Diagnostics(mass=1.5, max_density=2.5, l2_norm=3.5)")

    assert summary.initial_mass == 1.0
    assert summary.final_mass == 0.99
    assert summary.min_mass == 0.98
    assert summary.max_mass == 1.01
    assert summary.max_mass_drift == 0.02
    assert summary.steps == 4
    assert repr(summary) == (
        "DiagnosticsSummary(initial_mass=1.0, final_mass=0.99, min_mass=0.98, "
        "max_mass=1.01, max_mass_drift=0.02, steps=4)"
    )

    with pytest.raises(AttributeError):
        diagnostics.mass = 9.0

    with pytest.raises(AttributeError):
        summary.steps = 5
