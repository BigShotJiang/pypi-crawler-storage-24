def test_grid_and_config_expose_constructor_values_and_thread_default():
    import pykore

    grid = pykore.Grid((4, 4, 4), (1.0, 1.0, 1.0))
    config = pykore.Config(dt=0.01, poisson_scale=1.0)
    config_with_none = pykore.Config(dt=0.01, poisson_scale=1.0, threads=None)
    config_with_zero = pykore.Config(dt=0.01, poisson_scale=1.0, threads=0)

    assert grid.shape == (4, 4, 4)
    assert grid.lengths == (1.0, 1.0, 1.0)
    assert config.dt == 0.01
    assert config.poisson_scale == 1.0
    assert config.threads is None
    assert config_with_none.threads is None
    assert config_with_zero.threads is None
