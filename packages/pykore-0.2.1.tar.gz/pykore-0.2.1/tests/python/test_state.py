import numpy as np
import pytest


def test_state_exposes_original_numpy_wavefunction_array():
    import pykore

    psi = np.zeros((4, 4, 4), dtype=np.complex128)

    state = pykore.State(psi)

    assert state.psi is psi


def test_state_rejects_wrong_dtype():
    import pykore

    psi = np.zeros((4, 4, 4), dtype=np.float64)

    with pytest.raises(ValueError):
        pykore.State(psi)


def test_state_rejects_wrong_dimensionality():
    import pykore

    psi = np.zeros((4, 4), dtype=np.complex128)

    with pytest.raises(ValueError):
        pykore.State(psi)


def test_state_rejects_non_contiguous_arrays():
    import pykore

    psi = np.zeros((4, 4, 4), dtype=np.complex128).transpose(1, 0, 2)

    with pytest.raises(ValueError):
        pykore.State(psi)


def test_state_rejects_fortran_contiguous_arrays():
    import pykore

    psi = np.asfortranarray(np.zeros((4, 4, 4), dtype=np.complex128))

    with pytest.raises(ValueError):
        pykore.State(psi)
