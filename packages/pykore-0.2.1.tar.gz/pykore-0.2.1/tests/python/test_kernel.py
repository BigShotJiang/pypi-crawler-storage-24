import threading
import time

import numpy as np


def make_kernel_and_state(shape=(4, 4, 4), dt=0.01, poisson_scale=1.0):
    import pykore

    grid = pykore.Grid(shape, (1.0, 1.0, 1.0))
    config = pykore.Config(dt=dt, poisson_scale=poisson_scale)
    coords = np.indices(shape, dtype=np.float64)
    phase = 0.17 * coords[0] + 0.11 * coords[1] + 0.07 * coords[2]
    amplitude = 1.0 + 0.05 * coords[0] + 0.03 * coords[1]
    psi = (amplitude * np.exp(1j * phase)).astype(np.complex128)
    state = pykore.State(psi)
    kernel = pykore.Kernel(grid, config)
    return kernel, state, psi


def test_kernel_diagnostics_returns_zero_mass_for_zero_state():
    import pykore

    grid = pykore.Grid((4, 4, 4), (1.0, 1.0, 1.0))
    config = pykore.Config(dt=0.01, poisson_scale=1.0)
    state = pykore.State(np.zeros((4, 4, 4), dtype=np.complex128))
    kernel = pykore.Kernel(grid, config)

    assert kernel.diagnostics(state).mass == 0.0


def test_kernel_step_mutates_state_in_place_and_returns_diagnostics():
    import pykore

    kernel, state, psi = make_kernel_and_state(dt=0.05)
    psi_before = psi.copy()

    diagnostics = kernel.step(state)

    assert isinstance(diagnostics, pykore.Diagnostics)
    assert state.psi is psi
    assert not np.allclose(psi, psi_before)


def test_kernel_step_n_returns_diagnostics_summary():
    import pykore

    kernel, state, _ = make_kernel_and_state(dt=0.05)

    summary = kernel.step_n(state, 3)

    assert isinstance(summary, pykore.DiagnosticsSummary)
    assert summary.steps == 3
    assert summary.min_mass <= summary.final_mass <= summary.max_mass
    assert summary.max_mass_drift >= 0.0


def test_kernel_step_n_releases_gil_for_concurrent_python_threads():
    kernels_and_states = [
        make_kernel_and_state(shape=(32, 32, 32), dt=0.05),
        make_kernel_and_state(shape=(32, 32, 32), dt=0.05),
    ]
    steps = 6

    def run_step_n(index, durations):
        kernel, state, _ = kernels_and_states[index]
        start = time.monotonic()
        kernel.step_n(state, steps)
        durations[index] = time.monotonic() - start

    baseline = [None]
    run_step_n(0, baseline)
    baseline_duration = baseline[0]

    durations = [None, None]
    threads = [
        threading.Thread(target=run_step_n, args=(0, durations)),
        threading.Thread(target=run_step_n, args=(1, durations)),
    ]

    started = time.monotonic()
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=max(5.0, baseline_duration * 4.0))
        assert not thread.is_alive(), "step_n thread did not complete before timeout"
    assert all(duration is not None for duration in durations)
    assert all(duration > 0.0 for duration in durations)
