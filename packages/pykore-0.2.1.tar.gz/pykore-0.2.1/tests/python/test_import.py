def test_import_exposes_grid_and_kernel():
    import pykore

    assert hasattr(pykore, "Grid")
    assert hasattr(pykore, "Kernel")
