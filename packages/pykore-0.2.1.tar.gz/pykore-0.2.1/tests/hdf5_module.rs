#![cfg(feature = "checkpoint-hdf5")]

use kore::io::CURRENT_SCHEMA_VERSION;

#[test]
fn checkpoint_hdf5_feature_exposes_io_module() {
    assert_eq!(CURRENT_SCHEMA_VERSION, "1.0");
}
