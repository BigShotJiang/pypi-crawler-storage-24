#![cfg(feature = "checkpoint-hdf5")]

use kore::Error;

#[test]
fn incompatible_checkpoint_error_formats_readably() {
    let err = Error::IncompatibleCheckpoint {
        found: "2.0".into(),
        expected: "1.0".into(),
    };

    assert_eq!(
        err.to_string(),
        "checkpoint schema version \"2.0\" is not compatible with this version of kore (expected \"1.0\")"
    );
}
