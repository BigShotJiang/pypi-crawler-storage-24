use std::hint::black_box;

use criterion::{criterion_group, criterion_main, BatchSize, Criterion};
use kore::{config::SpConfig, sp::kernel::SpKernel3, state::State3, Grid3};

fn bench_single_step(c: &mut Criterion) {
    let grid = Grid3::new([16, 16, 16], [1.0, 1.0, 1.0]).unwrap();
    let config = SpConfig::default();
    let mut kernel = SpKernel3::new(grid.clone(), config).unwrap();

    c.bench_function("spkernel3/step/16^3", |b| {
        b.iter_batched(
            || State3::plane_wave(&grid, [1, 2, 3]),
            |mut state| {
                kernel.step(black_box(&mut state)).unwrap();
            },
            BatchSize::SmallInput,
        );
    });
}

criterion_group!(benches, bench_single_step);
criterion_main!(benches);
