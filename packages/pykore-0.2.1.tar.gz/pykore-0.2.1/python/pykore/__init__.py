from importlib import import_module
from importlib.metadata import version as _package_version

__all__ = [
    "Grid",
    "Config",
    "State",
    "Kernel",
    "Diagnostics",
    "DiagnosticsSummary",
]

__version__ = _package_version("pykore")


def __getattr__(name: str):
    if name not in __all__:
        raise AttributeError(f"module 'pykore' has no attribute {name!r}")

    try:
        module = import_module("pykore._kore")
    except ImportError as exc:
        raise ImportError(
            "pykore native extension is not built yet; run `maturin develop` first"
        ) from exc

    return getattr(module, name)
