#[cfg(not(feature = "checkpoint-hdf5"))]
compile_error!(
    "The `io` module requires the `checkpoint-hdf5` feature. Add `features = [\"checkpoint-hdf5\"]` to your dependency."
);

mod checkpoint;

pub use checkpoint::{load_checkpoint, save_checkpoint, CURRENT_SCHEMA_VERSION};
