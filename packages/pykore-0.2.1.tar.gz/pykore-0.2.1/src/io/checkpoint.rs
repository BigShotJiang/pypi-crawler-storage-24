use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use hdf5::types::VarLenUnicode;
use hdf5::{File, H5Type};
use ndarray::ArrayView3;
use num_complex::Complex64;

use crate::{Error, Grid3, State3};

pub const CURRENT_SCHEMA_VERSION: &str = "1.0";

const ROOT_GROUP: &str = "kore_checkpoint";
const GRID_GROUP: &str = "grid";
const STATE_GROUP: &str = "state";
const CONFIG_GROUP: &str = "config";
const DIAGNOSTICS_GROUP: &str = "diagnostics";
const PSI_DATASET: &str = "psi";

type ComplexRepr = [f64; 2];

fn to_repr(value: Complex64) -> ComplexRepr {
    [value.re, value.im]
}

fn from_repr(value: ComplexRepr) -> Complex64 {
    Complex64::new(value[0], value[1])
}

fn io_error(err: impl std::fmt::Display) -> Error {
    Error::CheckpointIo(err.to_string())
}

fn write_string_attr(location: &hdf5::Location, name: &str, value: &str) -> Result<(), Error> {
    let value: VarLenUnicode = value.parse().map_err(io_error)?;
    location
        .new_attr::<VarLenUnicode>()
        .shape(())
        .create(name)
        .and_then(|attr| attr.write_scalar(&value))
        .map_err(io_error)
}

fn read_string_attr(location: &hdf5::Location, name: &'static str) -> Result<String, Error> {
    let attr = location
        .attr(name)
        .map_err(|_| Error::MissingCheckpointField(name))?;
    let value: VarLenUnicode = attr
        .read_scalar()
        .map_err(|_| Error::MalformedCheckpointField(name))?;
    Ok(value.as_str().to_owned())
}

fn create_attr<T: H5Type + Copy>(
    location: &hdf5::Location,
    name: &str,
    value: &T,
) -> Result<(), Error> {
    location
        .new_attr::<T>()
        .shape(())
        .create(name)
        .and_then(|attr| attr.write_scalar(value))
        .map_err(io_error)
}

fn read_required_attr<T: H5Type + Copy>(
    location: &hdf5::Location,
    name: &'static str,
) -> Result<T, Error> {
    let attr = location
        .attr(name)
        .map_err(|_| Error::MissingCheckpointField(name))?;
    attr.read_scalar()
        .map_err(|_| Error::MalformedCheckpointField(name))
}

fn open_required_group(parent: &hdf5::Group, name: &'static str) -> Result<hdf5::Group, Error> {
    parent
        .group(name)
        .map_err(|_| Error::MissingCheckpointField(name))
}

fn maybe_group(parent: &hdf5::Group, name: &'static str) -> Result<Option<hdf5::Group>, Error> {
    match parent.group(name) {
        Ok(group) => Ok(Some(group)),
        Err(_) => Ok(None),
    }
}

fn validate_optional_group(group: &hdf5::Group, attrs: &[&'static str]) -> Result<(), Error> {
    for &attr in attrs {
        if group.attr(attr).is_err() {
            return Err(Error::MalformedCheckpointField(attr));
        }
    }
    Ok(())
}

pub fn save_checkpoint(path: &Path, grid: &Grid3, state: &State3) -> Result<(), Error> {
    if state.psi.len() != grid.len() {
        return Err(Error::InvalidFftInputLength);
    }

    let file = File::create(path).map_err(io_error)?;
    let root = file.create_group(ROOT_GROUP).map_err(io_error)?;

    write_string_attr(&root, "version", CURRENT_SCHEMA_VERSION)?;
    write_string_attr(&root, "kore_version", env!("CARGO_PKG_VERSION"))?;
    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(io_error)?
        .as_secs() as i64;
    create_attr(&root, "timestamp", &timestamp)?;

    let grid_group = root.create_group(GRID_GROUP).map_err(io_error)?;
    let shape = grid.shape();
    let lengths = grid.lengths();
    create_attr(&grid_group, "nx", &(shape[0] as u64))?;
    create_attr(&grid_group, "ny", &(shape[1] as u64))?;
    create_attr(&grid_group, "nz", &(shape[2] as u64))?;
    create_attr(&grid_group, "lx", &lengths[0])?;
    create_attr(&grid_group, "ly", &lengths[1])?;
    create_attr(&grid_group, "lz", &lengths[2])?;

    let state_group = root.create_group(STATE_GROUP).map_err(io_error)?;
    let psi_repr: Vec<ComplexRepr> = state.psi.iter().copied().map(to_repr).collect();
    let psi_view = ArrayView3::from_shape((shape[0], shape[1], shape[2]), &psi_repr)
        .map_err(|_| Error::InvalidFftInputLength)?;

    // Explicitly C-order to match Vec<Complex64> row-major layout.
    state_group
        .new_dataset_builder()
        .with_data(psi_view)
        .create(PSI_DATASET)
        .map_err(io_error)?;

    Ok(())
}

pub fn load_checkpoint(path: &Path) -> Result<(Grid3, State3), Error> {
    let file = File::open(path).map_err(io_error)?;
    let root = file
        .group(ROOT_GROUP)
        .map_err(|_| Error::MissingCheckpointField(ROOT_GROUP))?;

    let found = read_string_attr(&root, "version")?;
    if found != CURRENT_SCHEMA_VERSION {
        return Err(Error::IncompatibleCheckpoint {
            found,
            expected: CURRENT_SCHEMA_VERSION.to_owned(),
        });
    }

    let grid_group = open_required_group(&root, GRID_GROUP)?;
    let nx = read_required_attr::<u64>(&grid_group, "nx")? as usize;
    let ny = read_required_attr::<u64>(&grid_group, "ny")? as usize;
    let nz = read_required_attr::<u64>(&grid_group, "nz")? as usize;
    let lx = read_required_attr::<f64>(&grid_group, "lx")?;
    let ly = read_required_attr::<f64>(&grid_group, "ly")?;
    let lz = read_required_attr::<f64>(&grid_group, "lz")?;
    let grid = Grid3::new([nx, ny, nz], [lx, ly, lz])?;

    let state_group = open_required_group(&root, STATE_GROUP)?;
    let psi_dataset = state_group
        .dataset(PSI_DATASET)
        .map_err(|_| Error::MissingCheckpointField("state/psi"))?;
    let psi_shape = psi_dataset.shape();
    let psi: Vec<Complex64> = match psi_shape.as_slice() {
        [sx, sy, sz] if [*sx, *sy, *sz] == [nx, ny, nz] => {
            let psi_raw: Vec<ComplexRepr> = psi_dataset
                .read_raw()
                .map_err(|_| Error::MalformedCheckpointField("state/psi"))?;
            if psi_raw.len() != grid.len() {
                return Err(Error::MalformedCheckpointField("state/psi"));
            }
            psi_raw.into_iter().map(from_repr).collect()
        }
        [sx, sy, sz, 2] if [*sx, *sy, *sz] == [nx, ny, nz] => {
            let psi_raw: Vec<f64> = psi_dataset
                .read_raw()
                .map_err(|_| Error::MalformedCheckpointField("state/psi"))?;
            if psi_raw.len() != grid.len() * 2 {
                return Err(Error::MalformedCheckpointField("state/psi"));
            }
            psi_raw
                .chunks_exact(2)
                .map(|pair| Complex64::new(pair[0], pair[1]))
                .collect()
        }
        _ => return Err(Error::MalformedCheckpointField("state/psi")),
    };

    if let Some(config_group) = maybe_group(&root, CONFIG_GROUP)? {
        validate_optional_group(&config_group, &["dt", "hbar_over_m", "poisson_scale"])?;
    }
    if let Some(diagnostics_group) = maybe_group(&root, DIAGNOSTICS_GROUP)? {
        validate_optional_group(
            &diagnostics_group,
            &[
                "initial_mass",
                "final_mass",
                "min_mass",
                "max_mass",
                "max_mass_drift",
                "steps",
            ],
        )?;
    }

    Ok((grid, State3 { psi }))
}
