use crate::operators::kspace::KSpace3;
use num_complex::Complex64;

pub struct Poisson3 {
    coeffs: Vec<f64>,
}

impl Poisson3 {
    pub fn new(kspace: &KSpace3, poisson_scale: f64) -> Self {
        let coeffs = kspace
            .k2()
            .iter()
            .map(|&k2| if k2 == 0.0 { 0.0 } else { -poisson_scale / k2 })
            .collect();

        Self { coeffs }
    }

    #[cfg(test)]
    fn coefficients(&self) -> &[f64] {
        &self.coeffs
    }

    pub fn apply_in_place(&self, spectrum: &mut [Complex64]) {
        debug_assert_eq!(self.coeffs.len(), spectrum.len());

        for (value, coeff) in spectrum.iter_mut().zip(self.coeffs.iter().copied()) {
            *value *= coeff;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::Poisson3;
    use crate::{grid::Grid3, operators::kspace::KSpace3};

    #[test]
    fn poisson_coefficients_zero_out_zero_mode() {
        let grid = Grid3::new([4, 4, 4], [1.0, 1.0, 1.0]).unwrap();
        let kspace = KSpace3::new(&grid);
        let poisson = Poisson3::new(&kspace, 2.0);

        assert_eq!(poisson.coefficients()[0], 0.0);
    }

    #[test]
    fn poisson_coefficients_scale_nonzero_modes_by_inverse_k2() {
        let grid = Grid3::new([4, 4, 4], [1.0, 1.0, 1.0]).unwrap();
        let kspace = KSpace3::new(&grid);
        let poisson = Poisson3::new(&kspace, 2.0);
        let index = grid.flatten([1, 0, 0]).unwrap();
        let expected = -1.0 / (2.0 * std::f64::consts::PI.powi(2));

        assert!((poisson.coefficients()[index] - expected).abs() <= 1.0e-12);
    }
}
