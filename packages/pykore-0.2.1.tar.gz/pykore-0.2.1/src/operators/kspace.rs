use std::f64::consts::TAU;

use num_complex::Complex64;

use crate::grid::Grid3;

pub struct KSpace3 {
    k2: Vec<f64>,
}

impl KSpace3 {
    pub fn new(grid: &Grid3) -> Self {
        let shape = grid.shape();
        let lengths = grid.lengths();

        let kx = spectral_axis(shape[0], lengths[0]);
        let ky = spectral_axis(shape[1], lengths[1]);
        let kz = spectral_axis(shape[2], lengths[2]);

        let mut k2 = Vec::with_capacity(grid.len());

        for &kx_value in &kx {
            for &ky_value in &ky {
                for &kz_value in &kz {
                    k2.push(kx_value * kx_value + ky_value * ky_value + kz_value * kz_value);
                }
            }
        }

        Self { k2 }
    }

    pub fn k2(&self) -> &[f64] {
        &self.k2
    }
}

fn spectral_axis(size: usize, length: f64) -> Vec<f64> {
    let scale = TAU / length;

    (0..size)
        .map(|index| signed_mode(index, size) as f64 * scale)
        .collect()
}

fn signed_mode(index: usize, size: usize) -> isize {
    if index <= size / 2 {
        index as isize
    } else {
        index as isize - size as isize
    }
}

#[allow(dead_code)]
pub(crate) fn unit_phase(theta: f64) -> Complex64 {
    Complex64::new(theta.cos(), theta.sin())
}

#[cfg(test)]
mod tests {
    use super::KSpace3;
    use crate::Grid3;

    #[test]
    fn kspace_builds_expected_squared_norms() {
        let grid = Grid3::new([4, 4, 4], [2.0, 2.0, 2.0]).unwrap();
        let spec = KSpace3::new(&grid);
        let pi2 = std::f64::consts::PI.powi(2);

        assert_eq!(spec.k2().len(), grid.len());
        assert_k2_close(spec.k2()[grid.flatten([0, 0, 0]).unwrap()], 0.0);
        assert_k2_close(spec.k2()[grid.flatten([1, 0, 0]).unwrap()], pi2);
        assert_k2_close(spec.k2()[grid.flatten([3, 0, 0]).unwrap()], pi2);
        assert_k2_close(spec.k2()[grid.flatten([2, 0, 0]).unwrap()], 4.0 * pi2);
        assert_k2_close(spec.k2()[grid.flatten([1, 1, 1]).unwrap()], 3.0 * pi2);
        assert_k2_close(spec.k2()[grid.flatten([0, 1, 2]).unwrap()], 5.0 * pi2);
    }

    fn assert_k2_close(actual: f64, expected: f64) {
        let tolerance = 1.0e-12;
        assert!((actual - expected).abs() <= tolerance);
    }
}
