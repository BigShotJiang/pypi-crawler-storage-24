#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SpConfig {
    pub dt: f64,
    pub poisson_scale: f64,
    pub threads: Option<usize>,
}

impl Default for SpConfig {
    fn default() -> Self {
        Self {
            dt: 0.01,
            poisson_scale: 1.0,
            threads: None,
        }
    }
}
