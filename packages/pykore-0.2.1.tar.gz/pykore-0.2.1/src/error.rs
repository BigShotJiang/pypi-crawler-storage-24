use std::fmt::{Display, Formatter};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error {
    InvalidGridShape,
    InvalidGridLengths,
    InvalidGridIndex,
    InvalidFftInputLength,
    CheckpointIo(String),
    MissingCheckpointField(&'static str),
    MalformedCheckpointField(&'static str),
    IncompatibleCheckpoint { found: String, expected: String },
}

impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidGridShape => write!(f, "grid shape must contain only positive dimensions"),
            Self::InvalidGridLengths => write!(f, "grid lengths must be finite and positive"),
            Self::InvalidGridIndex => write!(f, "grid index out of bounds"),
            Self::InvalidFftInputLength => write!(f, "state shape does not match kernel grid"),
            Self::CheckpointIo(message) => write!(f, "checkpoint I/O error: {message}"),
            Self::MissingCheckpointField(field) => {
                write!(f, "checkpoint is missing required field `{field}`")
            }
            Self::MalformedCheckpointField(field) => {
                write!(f, "checkpoint field `{field}` is malformed")
            }
            Self::IncompatibleCheckpoint { found, expected } => write!(
                f,
                "checkpoint schema version \"{found}\" is not compatible with this version of kore (expected \"{expected}\")"
            ),
        }
    }
}

impl std::error::Error for Error {}
