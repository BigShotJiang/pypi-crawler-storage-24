//! Stable crate-root imports:
//!
//! ```
//! use kore::{
//!     Diagnostics, DiagnosticsSummary, Error, Grid3, SpConfig, SpKernel3, State3,
//! };
//! ```
//!
//! Internal implementation modules are not part of the public API surface.
//!
//! ```compile_fail
//! use kore::{fft::RustFftBackend, operators::kspace::KSpace3, threading::install_with_threads};
//! ```

mod config;
mod error;
pub mod ffi;
mod fft;
mod grid;
#[cfg(feature = "checkpoint-hdf5")]
pub mod io;
mod operators;
#[cfg(feature = "python")]
mod python;
mod sp;
mod state;
mod threading;

pub use config::SpConfig;
pub use error::Error;
pub use grid::Grid3;
pub use sp::diagnostics::{Diagnostics, DiagnosticsSummary};
pub use sp::kernel::SpKernel3;
pub use state::State3;
