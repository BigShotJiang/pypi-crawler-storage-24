use crate::error::Error;

#[derive(Debug, Clone, PartialEq)]
pub struct Grid3 {
    shape: [usize; 3],
    #[allow(dead_code)]
    lengths: [f64; 3],
}

impl Grid3 {
    pub fn new(shape: [usize; 3], lengths: [f64; 3]) -> Result<Self, Error> {
        if shape.contains(&0) {
            return Err(Error::InvalidGridShape);
        }

        if lengths
            .iter()
            .any(|&length| !length.is_finite() || length <= 0.0)
        {
            return Err(Error::InvalidGridLengths);
        }

        Ok(Self { shape, lengths })
    }

    pub fn shape(&self) -> [usize; 3] {
        self.shape
    }

    pub fn len(&self) -> usize {
        self.shape.iter().product()
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn lengths(&self) -> [f64; 3] {
        self.lengths
    }

    pub fn flatten(&self, ijk: [usize; 3]) -> Result<usize, Error> {
        if ijk[0] >= self.shape[0] || ijk[1] >= self.shape[1] || ijk[2] >= self.shape[2] {
            return Err(Error::InvalidGridIndex);
        }

        Ok((ijk[0] * self.shape[1] + ijk[1]) * self.shape[2] + ijk[2])
    }

    pub fn unflatten(&self, flat: usize) -> Result<[usize; 3], Error> {
        if flat >= self.len() {
            return Err(Error::InvalidGridIndex);
        }

        let yz = self.shape[1] * self.shape[2];
        let i = flat / yz;
        let rem = flat % yz;
        let j = rem / self.shape[2];
        let k = rem % self.shape[2];

        Ok([i, j, k])
    }
}
