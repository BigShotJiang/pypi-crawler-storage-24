use num_complex::Complex64;
use rayon::prelude::*;

use crate::{
    config::SpConfig,
    error::Error,
    fft::RustFftBackend,
    grid::Grid3,
    operators::{kspace::KSpace3, poisson::Poisson3},
    sp::{
        diagnostics::Diagnostics,
        stepper::{apply_kinetic_phase, apply_real_space_phase},
    },
    state::State3,
    threading::install_with_threads,
};

pub use super::diagnostics::DiagnosticsSummary;

pub struct SpKernel3 {
    grid: Grid3,
    dt: f64,
    threads: Option<usize>,
    k2: Vec<f64>,
    fft: RustFftBackend,
    poisson: Poisson3,
    spectral_scratch: Vec<Complex64>,
    potential_scratch: Vec<f64>,
}

impl SpKernel3 {
    pub fn new(grid: Grid3, config: SpConfig) -> Result<Self, Error> {
        let fft = RustFftBackend::new(grid.shape())?;
        let kspace = KSpace3::new(&grid);
        let k2 = kspace.k2().to_vec();
        let poisson = Poisson3::new(&kspace, config.poisson_scale);
        let spectral_scratch = vec![Complex64::new(0.0, 0.0); grid.len()];
        let potential_scratch = vec![0.0; grid.len()];

        Ok(Self {
            grid,
            dt: config.dt,
            threads: config.threads,
            k2,
            fft,
            poisson,
            spectral_scratch,
            potential_scratch,
        })
    }

    #[cfg(test)]
    pub(crate) fn compute_potential(&mut self, state: &State3) -> Result<&[f64], Error> {
        self.compute_potential_buffer(&state.psi)
    }

    pub(crate) fn compute_potential_buffer(&mut self, psi: &[Complex64]) -> Result<&[f64], Error> {
        if psi.len() != self.grid.len() {
            return Err(Error::InvalidFftInputLength);
        }

        install_with_threads(self.threads, || {
            self.spectral_scratch
                .par_iter_mut()
                .zip(psi.par_iter())
                .for_each(|(value, psi)| {
                    *value = Complex64::new(psi.norm_sqr(), 0.0);
                });
        });
        self.fft.forward_complex(&mut self.spectral_scratch)?;
        self.poisson.apply_in_place(&mut self.spectral_scratch);
        self.fft.inverse_complex(&mut self.spectral_scratch)?;

        install_with_threads(self.threads, || {
            self.potential_scratch
                .par_iter_mut()
                .zip(self.spectral_scratch.par_iter())
                .for_each(|(potential, value)| {
                    *potential = value.re;
                });
        });

        Ok(&self.potential_scratch)
    }

    pub fn diagnostics(&self, state: &State3) -> Result<Diagnostics, Error> {
        self.diagnostics_buffer(&state.psi)
    }

    pub(crate) fn diagnostics_buffer(&self, psi: &[Complex64]) -> Result<Diagnostics, Error> {
        if psi.len() != self.grid.len() {
            return Err(Error::InvalidFftInputLength);
        }

        Ok(Diagnostics::from_slice_with_threads(
            &self.grid,
            psi,
            self.threads,
        ))
    }

    pub(crate) fn state_len(&self) -> usize {
        self.grid.len()
    }

    pub fn step(&mut self, state: &mut State3) -> Result<Diagnostics, Error> {
        self.step_buffer(&mut state.psi)
    }

    pub(crate) fn step_buffer(&mut self, psi: &mut [Complex64]) -> Result<Diagnostics, Error> {
        if psi.len() != self.grid.len() {
            return Err(Error::InvalidFftInputLength);
        }

        self.compute_potential_buffer(psi)?;
        install_with_threads(self.threads, || {
            psi.par_iter_mut()
                .zip(self.potential_scratch.par_iter())
                .for_each(|(psi, &potential)| {
                    *psi = apply_real_space_phase(*psi, potential, 0.5 * self.dt);
                });
        });

        self.fft.forward_complex(psi)?;
        install_with_threads(self.threads, || {
            psi.par_iter_mut()
                .zip(self.k2.par_iter())
                .for_each(|(psi, &k2)| {
                    *psi = apply_kinetic_phase(*psi, k2, self.dt);
                });
        });
        self.fft.inverse_complex(psi)?;

        self.compute_potential_buffer(psi)?;
        install_with_threads(self.threads, || {
            psi.par_iter_mut()
                .zip(self.potential_scratch.par_iter())
                .for_each(|(psi, &potential)| {
                    *psi = apply_real_space_phase(*psi, potential, 0.5 * self.dt);
                });
        });

        Ok(Diagnostics::from_slice_with_threads(
            &self.grid,
            psi,
            self.threads,
        ))
    }

    pub fn step_n(
        &mut self,
        state: &mut State3,
        steps: usize,
    ) -> Result<DiagnosticsSummary, Error> {
        self.step_n_buffer(&mut state.psi, steps)
    }

    pub(crate) fn step_n_buffer(
        &mut self,
        psi: &mut [Complex64],
        steps: usize,
    ) -> Result<DiagnosticsSummary, Error> {
        let initial_mass = self.diagnostics_buffer(psi)?.mass;
        let mut summary = DiagnosticsSummary::new(initial_mass);

        for _ in 0..steps {
            let diagnostics = self.step_buffer(psi)?;
            summary.record_step(diagnostics.mass);
        }

        Ok(summary)
    }
}

#[cfg(test)]
mod tests {
    use std::f64::consts::TAU;

    use num_complex::Complex64;

    use super::SpKernel3;
    use crate::{config::SpConfig, grid::Grid3, state::State3};

    #[test]
    fn zero_density_produces_zero_potential() {
        let grid = Grid3::new([4, 4, 4], [1.0, 1.0, 1.0]).unwrap();
        let config = SpConfig::default();
        let mut kernel = SpKernel3::new(grid.clone(), config).unwrap();
        let state = State3::zeros(&grid);
        let potential = kernel.compute_potential(&state).unwrap();

        assert!(potential.iter().all(|value| value.abs() < 1e-12));
    }

    #[test]
    fn nonzero_density_matches_direct_poisson_solution() {
        let grid = Grid3::new([2, 2, 2], [1.0, 1.0, 1.0]).unwrap();
        let config = SpConfig::default();
        let mut kernel = SpKernel3::new(grid.clone(), config).unwrap();
        let mut state = State3::zeros(&grid);

        for y in 0..2 {
            for z in 0..2 {
                let low = grid.flatten([0, y, z]).unwrap();
                let high = grid.flatten([1, y, z]).unwrap();
                state.psi[low] = Complex64::new(1.0, 0.0);
                state.psi[high] = Complex64::new(2.0, 0.0);
            }
        }

        let potential = kernel.compute_potential(&state).unwrap();
        let expected = direct_poisson_potential(&grid, &state, config.poisson_scale);

        for (got, want) in potential.iter().zip(expected.iter()) {
            assert!((got - want).abs() < 1.0e-10, "got {got}, want {want}");
        }

        let low = grid.flatten([0, 0, 0]).unwrap();
        let high = grid.flatten([1, 0, 0]).unwrap();
        let expected_value = 3.0 / (8.0 * std::f64::consts::PI.powi(2));
        assert!((potential[low] - expected_value).abs() < 1.0e-10);
        assert!((potential[high] + expected_value).abs() < 1.0e-10);
    }

    fn direct_poisson_potential(grid: &Grid3, state: &State3, poisson_scale: f64) -> Vec<f64> {
        let shape = grid.shape();
        let lengths = grid.lengths();
        let density: Vec<f64> = state.psi.iter().map(|psi| psi.norm_sqr()).collect();
        let mut spectrum = vec![Complex64::new(0.0, 0.0); grid.len()];

        for kx in 0..shape[0] {
            for ky in 0..shape[1] {
                for kz in 0..shape[2] {
                    let mut sum = Complex64::new(0.0, 0.0);
                    for x in 0..shape[0] {
                        for y in 0..shape[1] {
                            for z in 0..shape[2] {
                                let index = grid.flatten([x, y, z]).unwrap();
                                let phase = -TAU
                                    * ((kx * x) as f64 / shape[0] as f64
                                        + (ky * y) as f64 / shape[1] as f64
                                        + (kz * z) as f64 / shape[2] as f64);
                                sum += Complex64::new(density[index], 0.0)
                                    * Complex64::new(phase.cos(), phase.sin());
                            }
                        }
                    }

                    let k2 = squared_wave_number([kx, ky, kz], shape, lengths);
                    let coeff = if k2 == 0.0 { 0.0 } else { -poisson_scale / k2 };
                    let index = grid.flatten([kx, ky, kz]).unwrap();
                    spectrum[index] = sum * coeff;
                }
            }
        }

        let norm = grid.len() as f64;
        let mut potential = vec![0.0; grid.len()];

        for x in 0..shape[0] {
            for y in 0..shape[1] {
                for z in 0..shape[2] {
                    let mut sum = Complex64::new(0.0, 0.0);
                    for kx in 0..shape[0] {
                        for ky in 0..shape[1] {
                            for kz in 0..shape[2] {
                                let index = grid.flatten([kx, ky, kz]).unwrap();
                                let phase = TAU
                                    * ((kx * x) as f64 / shape[0] as f64
                                        + (ky * y) as f64 / shape[1] as f64
                                        + (kz * z) as f64 / shape[2] as f64);
                                sum += spectrum[index] * Complex64::new(phase.cos(), phase.sin());
                            }
                        }
                    }

                    let index = grid.flatten([x, y, z]).unwrap();
                    potential[index] = (sum / norm).re;
                }
            }
        }

        potential
    }

    fn squared_wave_number(mode: [usize; 3], shape: [usize; 3], lengths: [f64; 3]) -> f64 {
        mode.into_iter()
            .zip(shape)
            .zip(lengths)
            .map(|((index, size), length)| {
                let signed = if index <= size / 2 {
                    index as isize
                } else {
                    index as isize - size as isize
                };
                let k = signed as f64 * TAU / length;
                k * k
            })
            .sum()
    }
}
