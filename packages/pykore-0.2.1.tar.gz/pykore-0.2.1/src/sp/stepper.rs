use num_complex::Complex64;

use crate::operators::kspace::unit_phase;

pub(crate) fn apply_real_space_phase(value: Complex64, potential: f64, dt: f64) -> Complex64 {
    let theta = -potential * dt;
    value * unit_phase(theta)
}

pub(crate) fn apply_kinetic_phase(value: Complex64, k2: f64, dt: f64) -> Complex64 {
    let theta = -k2 * dt;
    value * unit_phase(theta)
}

#[cfg(test)]
mod tests {
    use num_complex::Complex64;

    use super::apply_kinetic_phase;

    #[test]
    fn kinetic_phase_preserves_magnitude() {
        let value = Complex64::new(0.3, -0.7);
        let phased = apply_kinetic_phase(value, 1.2, 0.05);
        let expected = Complex64::new(0.25748535744495, -0.7167295798984762);

        assert!((phased.re - expected.re).abs() < 1e-12);
        assert!((phased.im - expected.im).abs() < 1e-12);
        assert!((phased.norm() - value.norm()).abs() < 1e-12);
    }
}
