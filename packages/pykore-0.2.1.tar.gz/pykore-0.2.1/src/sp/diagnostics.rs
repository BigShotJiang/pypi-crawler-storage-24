use num_complex::Complex64;
use rayon::prelude::*;

use crate::threading::install_with_threads;
use crate::{grid::Grid3, state::State3};

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Diagnostics {
    pub mass: f64,
    pub max_density: f64,
    pub l2_norm: f64,
}

impl Diagnostics {
    pub fn from_state(grid: &Grid3, state: &State3) -> Self {
        Self::from_state_with_threads(grid, state, None)
    }

    pub fn from_state_with_threads(grid: &Grid3, state: &State3, threads: Option<usize>) -> Self {
        Self::from_slice_with_threads(grid, &state.psi, threads)
    }

    pub fn from_slice_with_threads(
        grid: &Grid3,
        psi: &[Complex64],
        threads: Option<usize>,
    ) -> Self {
        let (density_sum, max_density) = install_with_threads(threads, || {
            psi.par_iter()
                .map(|psi| {
                    let density = psi.norm_sqr();
                    (density, density)
                })
                .reduce(
                    || (0.0_f64, 0.0_f64),
                    |(sum_a, max_a), (sum_b, max_b)| (sum_a + sum_b, max_a.max(max_b)),
                )
        });

        let cell_volume = grid.lengths().iter().product::<f64>() / grid.len() as f64;

        let mass = density_sum * cell_volume;

        Self {
            mass,
            max_density,
            l2_norm: mass.sqrt(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DiagnosticsSummary {
    pub initial_mass: f64,
    pub final_mass: f64,
    pub min_mass: f64,
    pub max_mass: f64,
    pub max_mass_drift: f64,
    pub steps: usize,
}

impl DiagnosticsSummary {
    pub fn new(initial_mass: f64) -> Self {
        Self {
            initial_mass,
            final_mass: initial_mass,
            min_mass: initial_mass,
            max_mass: initial_mass,
            max_mass_drift: 0.0,
            steps: 0,
        }
    }

    pub fn from_initial_mass(initial_mass: f64) -> Self {
        Self::new(initial_mass)
    }

    pub fn record_step(&mut self, mass: f64) {
        self.final_mass = mass;
        self.min_mass = self.min_mass.min(mass);
        self.max_mass = self.max_mass.max(mass);
        self.max_mass_drift = self.max_mass_drift.max((mass - self.initial_mass).abs());
        self.steps += 1;
    }
}
