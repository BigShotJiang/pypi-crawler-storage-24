#![allow(unsafe_op_in_unsafe_fn)]
#![allow(clippy::useless_conversion)]

use numpy::{Complex64, PyArrayDyn, PyArrayMethods, PyUntypedArrayMethods};
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;

use crate::{Error, Grid3, SpConfig, SpKernel3};

#[pyclass]
pub struct Grid {
    #[pyo3(get)]
    shape: (usize, usize, usize),
    #[pyo3(get)]
    lengths: (f64, f64, f64),
}

#[pymethods]
impl Grid {
    #[new]
    fn new(shape: (usize, usize, usize), lengths: (f64, f64, f64)) -> Self {
        Self { shape, lengths }
    }
}

impl Grid {
    fn as_core(&self) -> PyResult<Grid3> {
        Grid3::new(
            [self.shape.0, self.shape.1, self.shape.2],
            [self.lengths.0, self.lengths.1, self.lengths.2],
        )
        .map_err(map_error)
    }
}

#[pyclass]
pub struct Config {
    #[pyo3(get)]
    dt: f64,
    #[pyo3(get)]
    poisson_scale: f64,
    threads: Option<usize>,
}

#[pymethods]
impl Config {
    #[new]
    #[pyo3(signature = (dt, poisson_scale, threads=None))]
    fn new(dt: f64, poisson_scale: f64, threads: Option<usize>) -> Self {
        Self {
            dt,
            poisson_scale,
            threads: threads.filter(|&value| value > 0),
        }
    }

    #[getter]
    fn threads(&self) -> Option<usize> {
        self.threads
    }
}

impl Config {
    fn as_core(&self) -> SpConfig {
        SpConfig {
            dt: self.dt,
            poisson_scale: self.poisson_scale,
            threads: self.threads,
        }
    }
}

#[pyclass]
pub struct State {
    psi: Py<PyArrayDyn<Complex64>>,
}

#[pymethods]
impl State {
    #[new]
    fn new(psi: &Bound<'_, PyAny>) -> PyResult<Self> {
        let is_c_contiguous = psi
            .getattr("flags")?
            .get_item("C_CONTIGUOUS")?
            .extract::<bool>()?;
        let psi = psi.downcast::<PyArrayDyn<Complex64>>().map_err(|_| {
            PyValueError::new_err("psi must be a numpy.ndarray with dtype complex128")
        })?;

        if psi.ndim() != 3 {
            return Err(PyValueError::new_err("psi must be a 3D numpy.ndarray"));
        }

        if !is_c_contiguous {
            return Err(PyValueError::new_err(
                "psi must be a C-contiguous numpy.ndarray",
            ));
        }

        Ok(Self {
            psi: psi.clone().unbind(),
        })
    }

    #[getter]
    fn psi(&self, py: Python<'_>) -> Py<PyArrayDyn<Complex64>> {
        self.psi.clone_ref(py)
    }
}

impl State {
    fn array<'py>(&self, py: Python<'py>) -> &Bound<'py, PyArrayDyn<Complex64>> {
        self.psi.bind(py)
    }

    fn readwrite_slice<'py>(&'py self, py: Python<'py>) -> PyResult<&'py mut [Complex64]> {
        let psi = self.array(py);
        let psi = unsafe { psi.as_slice_mut() }
            .map_err(|_| PyValueError::new_err("psi must be a C-contiguous numpy.ndarray"))?;

        Ok(psi)
    }

    fn readonly_slice<'py>(&'py self, py: Python<'py>) -> PyResult<&'py [Complex64]> {
        let psi = self.array(py);
        let psi = unsafe { psi.as_slice() }
            .map_err(|_| PyValueError::new_err("psi must be a C-contiguous numpy.ndarray"))?;

        Ok(psi)
    }
}

#[pyclass]
pub struct Kernel {
    inner: SpKernel3,
}

#[pymethods]
impl Kernel {
    #[new]
    fn new(grid: &Grid, config: &Config) -> PyResult<Self> {
        Ok(Self {
            inner: SpKernel3::new(grid.as_core()?, config.as_core()).map_err(map_error)?,
        })
    }

    #[allow(clippy::useless_conversion)]
    fn diagnostics(&self, py: Python<'_>, state: &State) -> PyResult<Diagnostics> {
        let diagnostics = match self.inner.diagnostics_buffer(state.readonly_slice(py)?) {
            Ok(diagnostics) => diagnostics,
            Err(err) => return Err(map_error(err)),
        };

        Ok(Diagnostics::from_core(diagnostics))
    }

    #[allow(clippy::useless_conversion)]
    fn step(&mut self, py: Python<'_>, state: &mut State) -> PyResult<Diagnostics> {
        let psi = state.readwrite_slice(py)?;
        let result = match py.allow_threads(|| self.inner.step_buffer(psi)) {
            Ok(result) => result,
            Err(err) => return Err(map_error(err)),
        };

        Ok(Diagnostics::from_core(result))
    }

    #[allow(clippy::useless_conversion)]
    fn step_n(
        &mut self,
        py: Python<'_>,
        state: &mut State,
        steps: usize,
    ) -> PyResult<DiagnosticsSummary> {
        let psi = state.readwrite_slice(py)?;
        let result = match py.allow_threads(|| self.inner.step_n_buffer(psi, steps)) {
            Ok(result) => result,
            Err(err) => return Err(map_error(err)),
        };

        Ok(DiagnosticsSummary::from_core(result))
    }
}

#[pyclass(frozen)]
pub struct Diagnostics {
    #[pyo3(get)]
    mass: f64,
    #[pyo3(get)]
    max_density: f64,
    #[pyo3(get)]
    l2_norm: f64,
}

#[pymethods]
impl Diagnostics {
    #[new]
    #[pyo3(signature = (mass, max_density, l2_norm))]
    fn new(mass: f64, max_density: f64, l2_norm: f64) -> Self {
        Self {
            mass,
            max_density,
            l2_norm,
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "Diagnostics(mass={:?}, max_density={:?}, l2_norm={:?})",
            self.mass, self.max_density, self.l2_norm
        )
    }
}

impl Diagnostics {
    fn from_core(diagnostics: crate::Diagnostics) -> Self {
        Self::new(
            diagnostics.mass,
            diagnostics.max_density,
            diagnostics.l2_norm,
        )
    }
}

#[pyclass(frozen)]
pub struct DiagnosticsSummary {
    #[pyo3(get)]
    initial_mass: f64,
    #[pyo3(get)]
    final_mass: f64,
    #[pyo3(get)]
    min_mass: f64,
    #[pyo3(get)]
    max_mass: f64,
    #[pyo3(get)]
    max_mass_drift: f64,
    #[pyo3(get)]
    steps: usize,
}

#[pymethods]
impl DiagnosticsSummary {
    #[new]
    #[pyo3(signature = (
        initial_mass,
        final_mass,
        min_mass,
        max_mass,
        max_mass_drift,
        steps,
    ))]
    fn new(
        initial_mass: f64,
        final_mass: f64,
        min_mass: f64,
        max_mass: f64,
        max_mass_drift: f64,
        steps: usize,
    ) -> Self {
        Self {
            initial_mass,
            final_mass,
            min_mass,
            max_mass,
            max_mass_drift,
            steps,
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "DiagnosticsSummary(initial_mass={:?}, final_mass={:?}, min_mass={:?}, max_mass={:?}, max_mass_drift={:?}, steps={})",
            self.initial_mass,
            self.final_mass,
            self.min_mass,
            self.max_mass,
            self.max_mass_drift,
            self.steps
        )
    }
}

impl DiagnosticsSummary {
    fn from_core(summary: crate::DiagnosticsSummary) -> Self {
        Self::new(
            summary.initial_mass,
            summary.final_mass,
            summary.min_mass,
            summary.max_mass,
            summary.max_mass_drift,
            summary.steps,
        )
    }
}

#[pymodule]
pub fn _kore(_py: Python<'_>, module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_class::<Grid>()?;
    module.add_class::<Config>()?;
    module.add_class::<State>()?;
    module.add_class::<Kernel>()?;
    module.add_class::<Diagnostics>()?;
    module.add_class::<DiagnosticsSummary>()?;
    Ok(())
}

fn map_error(error: Error) -> PyErr {
    match error {
        Error::InvalidGridShape => {
            PyValueError::new_err("grid shape must contain only positive dimensions")
        }
        Error::InvalidGridLengths => {
            PyValueError::new_err("grid lengths must be finite and positive")
        }
        Error::InvalidGridIndex => PyValueError::new_err("grid index out of bounds"),
        Error::InvalidFftInputLength => {
            PyValueError::new_err("state shape does not match kernel grid")
        }
        Error::CheckpointIo(message) => pyo3::exceptions::PyRuntimeError::new_err(message),
        Error::MissingCheckpointField(field) => {
            pyo3::exceptions::PyRuntimeError::new_err(format!(
                "checkpoint is missing required field `{field}`"
            ))
        }
        Error::MalformedCheckpointField(field) => {
            pyo3::exceptions::PyRuntimeError::new_err(format!(
                "checkpoint field `{field}` is malformed"
            ))
        }
        Error::IncompatibleCheckpoint { found, expected } => {
            pyo3::exceptions::PyRuntimeError::new_err(format!(
                "checkpoint schema version \"{found}\" is not compatible with this version of kore (expected \"{expected}\")"
            ))
        }
    }
}
