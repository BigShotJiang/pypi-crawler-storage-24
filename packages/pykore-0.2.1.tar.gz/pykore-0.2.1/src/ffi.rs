//! C ABI surface types.

use std::{ptr, ptr::NonNull, slice};

use num_complex::Complex64;

use crate::{
    DiagnosticsSummary as SpDiagnosticsSummary, Error, Grid3, SpConfig, SpKernel3, State3,
};

#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
#[allow(non_camel_case_types)]
pub enum KoreStatus {
    #[default]
    KORE_OK = 0,
    KORE_ERR_NULL = 1,
    KORE_ERR_INVALID = 2,
    KORE_ERR_INTERNAL = 3,
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct KoreGrid {
    pub nx: u64,
    pub ny: u64,
    pub nz: u64,
    pub lx: f64,
    pub ly: f64,
    pub lz: f64,
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct KoreConfig {
    pub dt: f64,
    /// Reserved for future Rust-core support; currently ignored by `kore_create`.
    pub hbar_over_m: f64,
    pub poisson_scale: f64,
    pub threads: u32,
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct KoreDiagnostics {
    pub mass: f64,
    pub max_density: f64,
    pub l2_norm: f64,
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct KoreDiagnosticsSummary {
    pub initial_mass: f64,
    pub final_mass: f64,
    pub min_mass: f64,
    pub max_mass: f64,
    pub max_mass_drift: f64,
    pub steps: u64,
}

pub enum KoreKernel {}

impl KoreGrid {
    fn try_into_grid3(self) -> Result<Grid3, KoreStatus> {
        let shape = [
            usize::try_from(self.nx).map_err(|_| KoreStatus::KORE_ERR_INVALID)?,
            usize::try_from(self.ny).map_err(|_| KoreStatus::KORE_ERR_INVALID)?,
            usize::try_from(self.nz).map_err(|_| KoreStatus::KORE_ERR_INVALID)?,
        ];
        let lengths = [self.lx, self.ly, self.lz];

        Grid3::new(shape, lengths).map_err(map_error_status)
    }
}

impl KoreConfig {
    fn try_into_sp_config(self) -> Result<SpConfig, KoreStatus> {
        let Self {
            dt,
            hbar_over_m: _,
            poisson_scale,
            threads,
        } = self;

        Ok(SpConfig {
            dt,
            poisson_scale,
            threads: threads_to_option(threads)?,
        })
    }
}

fn threads_to_option<T>(threads: T) -> Result<Option<usize>, KoreStatus>
where
    T: TryInto<usize> + Copy,
{
    let threads = threads
        .try_into()
        .map_err(|_| KoreStatus::KORE_ERR_INVALID)?;

    Ok(match threads {
        0 => None,
        value => Some(value),
    })
}

fn map_error_status(error: Error) -> KoreStatus {
    match error {
        Error::InvalidGridShape | Error::InvalidGridLengths | Error::InvalidGridIndex => {
            KoreStatus::KORE_ERR_INVALID
        }
        Error::InvalidFftInputLength
        | Error::CheckpointIo(_)
        | Error::MissingCheckpointField(_)
        | Error::MalformedCheckpointField(_)
        | Error::IncompatibleCheckpoint { .. } => KoreStatus::KORE_ERR_INTERNAL,
    }
}

#[derive(Clone, Copy)]
struct StatusSlot(*mut KoreStatus);

impl StatusSlot {
    fn write(self, status: KoreStatus) {
        if !self.0.is_null() {
            // SAFETY: The C ABI contract requires a non-null `out_status`
            // pointer to be valid for one `KoreStatus` write.
            unsafe {
                self.0.write(status);
            }
        }
    }

    fn write_result<T>(self, result: Result<T, KoreStatus>) -> Result<T, KoreStatus> {
        match result {
            Ok(value) => {
                self.write(KoreStatus::KORE_OK);
                Ok(value)
            }
            Err(status) => {
                self.write(status);
                Err(status)
            }
        }
    }
}

fn status_slot(out_status: *mut KoreStatus) -> StatusSlot {
    StatusSlot(out_status)
}

unsafe fn out_ptr<'a, T>(ptr: *mut T) -> Result<&'a mut T, KoreStatus> {
    let mut ptr = NonNull::new(ptr).ok_or(KoreStatus::KORE_ERR_NULL)?;

    // SAFETY: The null check above ensures the pointer is non-null. The C ABI
    // contract requires non-null out-pointers to be valid for one write.
    Ok(unsafe { ptr.as_mut() })
}

unsafe fn borrowed_slice<'a, T>(ptr: *const T, len: usize) -> Result<&'a [T], KoreStatus> {
    NonNull::new(ptr.cast_mut())
        .ok_or(KoreStatus::KORE_ERR_NULL)
        .map(|_| {
            // SAFETY: The null check above ensures the pointer is non-null. The
            // C ABI contract requires caller-owned buffers to be valid for `len`
            // contiguous elements.
            unsafe { slice::from_raw_parts(ptr, len) }
        })
}

unsafe fn borrowed_slice_mut<'a, T>(ptr: *mut T, len: usize) -> Result<&'a mut [T], KoreStatus> {
    let mut ptr = NonNull::new(ptr).ok_or(KoreStatus::KORE_ERR_NULL)?;

    // SAFETY: The null check above ensures the pointer is non-null. The C ABI
    // contract requires caller-owned buffers to be valid for `len`
    // contiguous elements.
    Ok(unsafe { slice::from_raw_parts_mut(ptr.as_mut(), len) })
}

fn validate_len(actual: usize, expected: usize) -> Result<(), KoreStatus> {
    if actual == expected {
        Ok(())
    } else {
        Err(KoreStatus::KORE_ERR_INVALID)
    }
}

fn ffi_summary(summary: SpDiagnosticsSummary) -> Result<KoreDiagnosticsSummary, KoreStatus> {
    let max_mass_drift = if summary.initial_mass == 0.0 {
        if summary.min_mass == 0.0 && summary.max_mass == 0.0 && summary.final_mass == 0.0 {
            0.0
        } else {
            return Err(KoreStatus::KORE_ERR_INVALID);
        }
    } else {
        summary.max_mass_drift / summary.initial_mass.abs()
    };

    Ok(KoreDiagnosticsSummary {
        initial_mass: summary.initial_mass,
        final_mass: summary.final_mass,
        min_mass: summary.min_mass,
        max_mass: summary.max_mass,
        max_mass_drift,
        steps: summary.steps as u64,
    })
}

unsafe fn kernel_ptr(kernel: *mut KoreKernel) -> Result<NonNull<SpKernel3>, KoreStatus> {
    NonNull::new(kernel.cast::<SpKernel3>()).ok_or(KoreStatus::KORE_ERR_NULL)
}

#[allow(dead_code)]
unsafe fn borrowed_kernel<'a>(kernel: *mut KoreKernel) -> Result<&'a mut SpKernel3, KoreStatus> {
    let mut kernel = unsafe { kernel_ptr(kernel)? };

    // SAFETY: `kernel_ptr` rejects null pointers. Non-null handles must be
    // valid `kore_create` allocations by the C ABI contract.
    Ok(unsafe { kernel.as_mut() })
}

unsafe fn shared_kernel<'a>(kernel: *mut KoreKernel) -> Result<&'a SpKernel3, KoreStatus> {
    let kernel = unsafe { kernel_ptr(kernel)? };

    // SAFETY: `kernel_ptr` rejects null pointers. Non-null handles must be
    // valid `kore_create` allocations by the C ABI contract.
    Ok(unsafe { kernel.as_ref() })
}

unsafe fn owned_kernel(kernel: *mut KoreKernel) -> Option<Box<SpKernel3>> {
    match unsafe { kernel_ptr(kernel) } {
        Ok(kernel) => {
            // SAFETY: `kernel_ptr` validated non-nullness, and destroy consumes
            // ownership of the original `kore_create` allocation exactly once.
            Some(unsafe { Box::from_raw(kernel.as_ptr()) })
        }
        Err(KoreStatus::KORE_ERR_NULL) => None,
        Err(_) => None,
    }
}

#[unsafe(no_mangle)]
/// Create a new opaque kernel handle.
///
/// # Safety
/// `out_status` may be null. If non-null, it must be valid for one `KoreStatus`
/// write. The returned pointer must later be released with `kore_destroy`.
pub unsafe extern "C" fn kore_create(
    grid: KoreGrid,
    config: KoreConfig,
    out_status: *mut KoreStatus,
) -> *mut KoreKernel {
    status_slot(out_status)
        .write_result(grid.try_into_grid3().and_then(|grid| {
            config
                .try_into_sp_config()
                .and_then(|config| SpKernel3::new(grid, config).map_err(map_error_status))
        }))
        .map(|kernel| Box::into_raw(Box::new(kernel)).cast::<KoreKernel>())
        .unwrap_or(ptr::null_mut())
}

#[unsafe(no_mangle)]
/// Destroy an opaque kernel handle created by `kore_create`.
///
/// # Safety
/// `kernel` may be null. If non-null, it must be a live handle originally
/// returned by `kore_create` and must not be destroyed more than once.
pub unsafe extern "C" fn kore_destroy(kernel: *mut KoreKernel) {
    // SAFETY: `owned_kernel` performs the null guard before reconstructing the
    // box from a `kore_create` allocation.
    if let Some(kernel) = unsafe { owned_kernel(kernel) } {
        drop(kernel);
    }
}

#[unsafe(no_mangle)]
/// Query the library version sourced from Cargo package metadata.
///
/// # Safety
/// Each output pointer may be null. Any non-null pointer must be valid for one
/// `u32` write.
pub unsafe extern "C" fn kore_version(major: *mut u32, minor: *mut u32, patch: *mut u32) {
    let version_major = env!("CARGO_PKG_VERSION_MAJOR")
        .parse::<u32>()
        .expect("CARGO_PKG_VERSION_MAJOR must parse as u32");
    let version_minor = env!("CARGO_PKG_VERSION_MINOR")
        .parse::<u32>()
        .expect("CARGO_PKG_VERSION_MINOR must parse as u32");
    let version_patch = env!("CARGO_PKG_VERSION_PATCH")
        .parse::<u32>()
        .expect("CARGO_PKG_VERSION_PATCH must parse as u32");

    if let Some(mut major) = NonNull::new(major) {
        // SAFETY: The null check above ensures the pointer is non-null. The C ABI
        // contract requires non-null optional out-pointers to be valid for one
        // write.
        unsafe {
            *major.as_mut() = version_major;
        }
    }

    if let Some(mut minor) = NonNull::new(minor) {
        // SAFETY: The null check above ensures the pointer is non-null. The C ABI
        // contract requires non-null optional out-pointers to be valid for one
        // write.
        unsafe {
            *minor.as_mut() = version_minor;
        }
    }

    if let Some(mut patch) = NonNull::new(patch) {
        // SAFETY: The null check above ensures the pointer is non-null. The C ABI
        // contract requires non-null optional out-pointers to be valid for one
        // write.
        unsafe {
            *patch.as_mut() = version_patch;
        }
    }
}

#[unsafe(no_mangle)]
/// Compute diagnostics for a caller-owned state buffer.
///
/// # Safety
/// `kernel`, `psi`, and `out_diagnostics` must be non-null and valid for the
/// duration of the call. `psi` must reference `psi_len` contiguous complex
/// values. `out_status` may be null.
pub unsafe extern "C" fn kore_diagnostics(
    kernel: *mut KoreKernel,
    psi: *const Complex64,
    psi_len: usize,
    out_diagnostics: *mut KoreDiagnostics,
    out_status: *mut KoreStatus,
) -> KoreStatus {
    match status_slot(out_status).write_result((|| {
        let kernel = unsafe { shared_kernel(kernel)? };
        let psi = unsafe { borrowed_slice(psi, psi_len)? };
        let out_diagnostics = unsafe { out_ptr(out_diagnostics)? };
        let diagnostics = kernel
            .diagnostics(&crate::State3 { psi: psi.to_vec() })
            .map_err(map_error_status)?;

        *out_diagnostics = KoreDiagnostics {
            mass: diagnostics.mass,
            max_density: diagnostics.max_density,
            l2_norm: diagnostics.l2_norm,
        };

        Ok(())
    })()) {
        Ok(()) => KoreStatus::KORE_OK,
        Err(status) => status,
    }
}

#[unsafe(no_mangle)]
/// Advance a caller-owned state buffer by one step.
///
/// # Safety
/// `kernel` and `psi` must be non-null and valid for the duration of the call.
/// `psi` must reference `psi_len` contiguous complex values matching the kernel
/// grid size. `out_status` may be null.
pub unsafe extern "C" fn kore_step(
    kernel: *mut KoreKernel,
    psi: *mut Complex64,
    psi_len: usize,
    out_status: *mut KoreStatus,
) -> KoreStatus {
    match status_slot(out_status).write_result((|| {
        let kernel = unsafe { borrowed_kernel(kernel)? };
        validate_len(psi_len, kernel.state_len())?;
        let psi = unsafe { borrowed_slice_mut(psi, psi_len)? };
        let mut state = State3 { psi: psi.to_vec() };

        kernel.step(&mut state).map_err(map_error_status)?;
        psi.copy_from_slice(&state.psi);

        Ok(())
    })()) {
        Ok(()) => KoreStatus::KORE_OK,
        Err(status) => status,
    }
}

#[unsafe(no_mangle)]
/// Advance a caller-owned state buffer by multiple steps.
///
/// # Safety
/// `kernel` and `psi` must be non-null and valid for the duration of the call.
/// `psi` must reference `psi_len` contiguous complex values matching the kernel
/// grid size. `out_summary` and `out_status` may be null.
pub unsafe extern "C" fn kore_step_n(
    kernel: *mut KoreKernel,
    psi: *mut Complex64,
    psi_len: usize,
    steps: u64,
    out_summary: *mut KoreDiagnosticsSummary,
    out_status: *mut KoreStatus,
) -> KoreStatus {
    match status_slot(out_status).write_result((|| {
        let kernel = unsafe { borrowed_kernel(kernel)? };
        validate_len(psi_len, kernel.state_len())?;
        let psi = unsafe { borrowed_slice_mut(psi, psi_len)? };
        let steps = usize::try_from(steps).map_err(|_| KoreStatus::KORE_ERR_INVALID)?;
        let mut state = State3 { psi: psi.to_vec() };
        let summary = ffi_summary(kernel.step_n(&mut state, steps).map_err(map_error_status)?)?;

        psi.copy_from_slice(&state.psi);

        if let Some(mut out_summary) = NonNull::new(out_summary) {
            // SAFETY: The null check above ensures the pointer is non-null. The
            // C ABI contract requires non-null optional out-pointers to be valid
            // for one write.
            unsafe {
                *out_summary.as_mut() = summary;
            }
        }

        Ok(())
    })()) {
        Ok(()) => KoreStatus::KORE_OK,
        Err(status) => status,
    }
}

#[cfg(test)]
mod tests {
    use std::ptr;

    use crate::{Grid3, SpConfig, SpKernel3};

    use super::{
        borrowed_kernel, shared_kernel, status_slot, threads_to_option, KoreStatus,
        KoreStatus::KORE_ERR_INVALID,
    };

    #[derive(Clone, Copy)]
    struct FailingThreads;

    impl TryInto<usize> for FailingThreads {
        type Error = ();

        fn try_into(self) -> Result<usize, Self::Error> {
            Err(())
        }
    }

    #[test]
    fn threads_to_option_uses_none_for_zero() {
        assert_eq!(threads_to_option(0u32), Ok(None));
    }

    #[test]
    fn threads_to_option_preserves_nonzero_value() {
        assert_eq!(threads_to_option(4u32), Ok(Some(4)));
    }

    #[test]
    fn threads_to_option_returns_invalid_status_on_failed_conversion() {
        assert_eq!(threads_to_option(FailingThreads), Err(KORE_ERR_INVALID));
    }

    #[test]
    fn status_slot_ignores_null_pointer_writes() {
        status_slot(ptr::null_mut()).write(KoreStatus::KORE_ERR_INVALID);
    }

    #[test]
    fn status_slot_writes_to_valid_pointer() {
        let mut status = KoreStatus::KORE_OK;

        status_slot(&mut status).write(KoreStatus::KORE_ERR_INVALID);

        assert_eq!(status, KoreStatus::KORE_ERR_INVALID);
    }

    #[test]
    fn status_slot_writes_ok_for_successful_result() {
        let mut status = KoreStatus::KORE_ERR_INTERNAL;

        let result = status_slot(&mut status).write_result::<u32>(Ok(7));

        assert_eq!(result, Ok(7));
        assert_eq!(status, KoreStatus::KORE_OK);
    }

    #[test]
    fn borrowed_kernel_returns_null_status_for_null_pointer() {
        let kernel = unsafe { borrowed_kernel(ptr::null_mut()) };

        assert!(matches!(kernel, Err(KoreStatus::KORE_ERR_NULL)));
    }

    #[test]
    fn shared_kernel_returns_null_status_for_null_pointer() {
        let kernel = unsafe { shared_kernel(ptr::null_mut()) };

        assert!(matches!(kernel, Err(KoreStatus::KORE_ERR_NULL)));
    }

    #[test]
    fn borrowed_kernel_returns_mutable_reference_for_valid_pointer() {
        let grid = Grid3::new([2, 2, 2], [1.0, 1.0, 1.0]).unwrap();
        let config = SpConfig {
            dt: 0.01,
            poisson_scale: 1.0,
            threads: None,
        };
        let kernel = Box::new(SpKernel3::new(grid, config).unwrap());
        let raw = Box::into_raw(kernel).cast::<super::KoreKernel>();

        let borrowed = unsafe { borrowed_kernel(raw) };

        assert!(borrowed.is_ok());

        unsafe {
            drop(Box::from_raw(raw.cast::<SpKernel3>()));
        }
    }
}
