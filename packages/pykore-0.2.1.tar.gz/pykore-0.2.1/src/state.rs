use num_complex::Complex64;

use crate::grid::Grid3;

#[derive(Debug, Clone, PartialEq)]
pub struct State3 {
    pub psi: Vec<Complex64>,
}

impl State3 {
    pub fn zeros(grid: &Grid3) -> Self {
        Self {
            psi: vec![Complex64::new(0.0, 0.0); grid.len()],
        }
    }

    pub fn plane_wave(grid: &Grid3, mode: [usize; 3]) -> Self {
        let shape = grid.shape();
        let mut psi = Vec::with_capacity(grid.len());

        for ix in 0..shape[0] {
            for iy in 0..shape[1] {
                for iz in 0..shape[2] {
                    let phase = std::f64::consts::TAU
                        * (mode[0] as f64 * ix as f64 / shape[0] as f64
                            + mode[1] as f64 * iy as f64 / shape[1] as f64
                            + mode[2] as f64 * iz as f64 / shape[2] as f64);
                    psi.push(Complex64::new(phase.cos(), phase.sin()));
                }
            }
        }

        Self { psi }
    }
}
