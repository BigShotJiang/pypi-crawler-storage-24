use std::sync::Arc;

use num_complex::Complex64;
use rustfft::{Fft, FftPlanner};

use crate::{error::Error, fft::FftBackend3};

pub(crate) struct RustFftEngine3 {
    shape: [usize; 3],
    forward_x: Arc<dyn Fft<f64>>,
    forward_y: Arc<dyn Fft<f64>>,
    forward_z: Arc<dyn Fft<f64>>,
    inverse_x: Arc<dyn Fft<f64>>,
    inverse_y: Arc<dyn Fft<f64>>,
    inverse_z: Arc<dyn Fft<f64>>,
}

impl RustFftEngine3 {
    pub(crate) fn new(shape: [usize; 3]) -> Result<Self, Error> {
        if shape.contains(&0) {
            return Err(Error::InvalidGridShape);
        }

        let mut planner = FftPlanner::<f64>::new();

        Ok(Self {
            shape,
            forward_x: planner.plan_fft_forward(shape[0]),
            forward_y: planner.plan_fft_forward(shape[1]),
            forward_z: planner.plan_fft_forward(shape[2]),
            inverse_x: planner.plan_fft_inverse(shape[0]),
            inverse_y: planner.plan_fft_inverse(shape[1]),
            inverse_z: planner.plan_fft_inverse(shape[2]),
        })
    }

    fn expected_len(&self) -> usize {
        self.shape.iter().product()
    }

    fn validate_len(&self, data: &[Complex64]) -> Result<(), Error> {
        if data.len() == self.expected_len() {
            Ok(())
        } else {
            Err(Error::InvalidFftInputLength)
        }
    }
}

impl FftBackend3 for RustFftEngine3 {
    fn forward_complex(&mut self, data: &mut [Complex64]) -> Result<(), Error> {
        self.validate_len(data)?;

        transform_x(data, self.shape, self.forward_x.as_ref());
        transform_y(data, self.shape, self.forward_y.as_ref());
        transform_z(data, self.shape, self.forward_z.as_ref());

        Ok(())
    }

    fn inverse_complex(&mut self, data: &mut [Complex64]) -> Result<(), Error> {
        self.validate_len(data)?;

        transform_x(data, self.shape, self.inverse_x.as_ref());
        transform_y(data, self.shape, self.inverse_y.as_ref());
        transform_z(data, self.shape, self.inverse_z.as_ref());

        let scale = 1.0 / self.expected_len() as f64;
        for value in data.iter_mut() {
            *value *= scale;
        }

        Ok(())
    }
}

fn transform_x(data: &mut [Complex64], shape: [usize; 3], fft: &dyn Fft<f64>) {
    let [nx, ny, nz] = shape;
    let yz = ny * nz;
    let mut line = vec![Complex64::new(0.0, 0.0); nx];

    for y in 0..ny {
        for z in 0..nz {
            for x in 0..nx {
                line[x] = data[x * yz + y * nz + z];
            }
            fft.process(&mut line);
            for x in 0..nx {
                data[x * yz + y * nz + z] = line[x];
            }
        }
    }
}

fn transform_y(data: &mut [Complex64], shape: [usize; 3], fft: &dyn Fft<f64>) {
    let [nx, ny, nz] = shape;
    let yz = ny * nz;
    let mut line = vec![Complex64::new(0.0, 0.0); ny];

    for x in 0..nx {
        for z in 0..nz {
            let base = x * yz + z;
            for y in 0..ny {
                line[y] = data[base + y * nz];
            }
            fft.process(&mut line);
            for y in 0..ny {
                data[base + y * nz] = line[y];
            }
        }
    }
}

fn transform_z(data: &mut [Complex64], shape: [usize; 3], fft: &dyn Fft<f64>) {
    let [nx, ny, nz] = shape;

    for x in 0..nx {
        for y in 0..ny {
            let start = (x * ny + y) * nz;
            fft.process(&mut data[start..start + nz]);
        }
    }
}
