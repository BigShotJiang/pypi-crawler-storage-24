use num_complex::Complex64;

use crate::error::Error;

pub mod rustfft;

pub(crate) trait FftBackend3 {
    fn forward_complex(&mut self, data: &mut [Complex64]) -> Result<(), Error>;
    fn inverse_complex(&mut self, data: &mut [Complex64]) -> Result<(), Error>;
}

pub struct RustFftBackend {
    inner: rustfft::RustFftEngine3,
}

impl RustFftBackend {
    pub fn new(shape: [usize; 3]) -> Result<Self, Error> {
        Ok(Self {
            inner: rustfft::RustFftEngine3::new(shape)?,
        })
    }

    pub fn forward_complex(&mut self, data: &mut [Complex64]) -> Result<(), Error> {
        FftBackend3::forward_complex(self, data)
    }

    pub fn inverse_complex(&mut self, data: &mut [Complex64]) -> Result<(), Error> {
        FftBackend3::inverse_complex(self, data)
    }
}

impl FftBackend3 for RustFftBackend {
    fn forward_complex(&mut self, data: &mut [Complex64]) -> Result<(), Error> {
        self.inner.forward_complex(data)
    }

    fn inverse_complex(&mut self, data: &mut [Complex64]) -> Result<(), Error> {
        self.inner.inverse_complex(data)
    }
}

#[cfg(test)]
mod tests {
    use super::RustFftBackend;
    use crate::Error;
    use num_complex::Complex64;

    #[test]
    fn fft_backend_rejects_zero_sized_shape() {
        assert!(matches!(
            RustFftBackend::new([0, 2, 2]),
            Err(Error::InvalidGridShape)
        ));
    }

    #[test]
    fn fft_round_trip_restores_input() {
        let mut data = vec![
            Complex64::new(1.0, 0.0),
            Complex64::new(-2.0, 0.5),
            Complex64::new(0.25, -1.25),
            Complex64::new(3.5, 2.0),
            Complex64::new(-0.75, 1.5),
            Complex64::new(2.25, -3.0),
            Complex64::new(0.0, 4.0),
            Complex64::new(-1.5, -0.25),
        ];
        let mut fft = RustFftBackend::new([2, 2, 2]).unwrap();
        let original = data.clone();

        fft.forward_complex(&mut data).unwrap();
        fft.inverse_complex(&mut data).unwrap();

        for (got, want) in data.iter().zip(original.iter()) {
            assert!((got - want).norm() < 1.0e-10);
        }
    }
}
