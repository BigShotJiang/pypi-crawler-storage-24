use rayon::ThreadPoolBuilder;

pub fn install_with_threads<R, F>(threads: Option<usize>, operation: F) -> R
where
    R: Send,
    F: FnOnce() -> R + Send,
{
    match threads.filter(|&count| count > 0) {
        None => operation(),
        Some(count) => ThreadPoolBuilder::new()
            .num_threads(count)
            .build_scoped(|thread| thread.run(), |pool| pool.install(operation))
            .expect("failed to build scoped rayon thread pool"),
    }
}
