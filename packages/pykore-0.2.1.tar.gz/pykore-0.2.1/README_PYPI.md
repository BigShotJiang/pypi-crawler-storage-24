# pykore

pykore provides Python bindings for kore, a portable Schrödinger-Poisson pseudo-spectral kernel written in Rust.

## Install

```bash
pip install pykore
```

## Quick start

```python
import numpy as np
import pykore

grid = pykore.Grid((64, 64, 64), (1.0, 1.0, 1.0))
config = pykore.Config(dt=0.01, poisson_scale=1.0)
state = pykore.State(np.zeros((64, 64, 64), dtype=np.complex128))
kernel = pykore.Kernel(grid, config)
print(kernel.diagnostics(state))
```

Paper: https://arxiv.org/abs/1807.04037
Repository: https://github.com/edengilbertus/kore
