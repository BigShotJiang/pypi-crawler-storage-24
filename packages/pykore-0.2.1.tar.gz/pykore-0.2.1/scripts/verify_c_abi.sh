#!/bin/sh

set -eu

cbindgen --config cbindgen.toml --output /tmp/kore_check.h
diff include/kore.h /tmp/kore_check.h

cargo build

${CC:-cc} -Iinclude tests/c_smoke.c target/debug/libkore.a -o /tmp/kore_c_smoke
