#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd -- "$SCRIPT_DIR/.." && pwd)"

PYTHON_BIN="${PYTHON_BIN:-python3}"
PYKORE_VERSION="${PYKORE_VERSION:-$(REPO_ROOT="$REPO_ROOT" $PYTHON_BIN - <<'PY'
from pathlib import Path
import tomllib
import os

data = tomllib.loads(Path(os.environ['REPO_ROOT'], 'pyproject.toml').read_text())
print(data['project']['version'])
PY
)}"
PACKAGE_SPEC="pykore==${PYKORE_VERSION}"
VENV_DIR="$(mktemp -d "${TMPDIR:-/tmp}/pykore-testpypi.XXXXXX")"

trap 'rm -rf "$VENV_DIR"' EXIT

"$PYTHON_BIN" -m venv "$VENV_DIR"
"$VENV_DIR/bin/pip" install \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple/ \
  "$PACKAGE_SPEC"

"$VENV_DIR/bin/python" -c "import pykore; print(pykore.__version__)"
"$VENV_DIR/bin/python" - <<'PY'
import pykore

grid = pykore.Grid((2, 2, 2), (1.0, 1.0, 1.0))
print(type(grid).__name__)
PY
