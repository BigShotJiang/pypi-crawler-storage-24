from __future__ import annotations

from typing import Any

from utils.name import Name

NAME_PROPERTIES = [
    "raw", "snake_case", "kebab_case", "pascal_case",
    "camel_case", "macro_case", "macro_snake_case", "micro_case",
]


class PathError(Exception):
    pass


def parse_path(path_str: str) -> list[str | int]:
    """Tokenize a path like ``message[.pkg.Foo].fields[0]`` into segments.

    Returns a list of string keys and integer indices.
    """
    segments: list[str | int] = []
    s = path_str.strip()
    if not s:
        return segments

    i = 0
    while i < len(s):
        if s[i] == "[":
            try:
                end = s.index("]", i + 1)
            except ValueError:
                raise PathError(f"unmatched '[' at position {i} in: {path_str}")
            inner = s[i + 1 : end]
            if not inner:
                raise PathError(f"empty brackets at position {i} in: {path_str}")
            try:
                segments.append(int(inner))
            except ValueError:
                segments.append(inner)
            i = end + 1
            if i < len(s) and s[i] == ".":
                i += 1
        elif s[i] == ".":
            i += 1
        else:
            end = i
            while end < len(s) and s[end] not in ".[]":
                end += 1
            segments.append(s[i:end])
            i = end
            if i < len(s) and s[i] == ".":
                i += 1

    return segments


def _step_into(data: Any, segment: str | int) -> Any:
    if isinstance(segment, int):
        if isinstance(data, list):
            if 0 <= segment < len(data):
                return data[segment]
            raise PathError(f"index {segment} out of range (length {len(data)})")
        raise PathError(f"cannot index into {type(data).__name__}")

    if isinstance(data, dict):
        if segment in data:
            return data[segment]
        available = ", ".join(list(data.keys())[:10])
        if len(data) > 10:
            available += ", ..."
        raise PathError(f"key '{segment}' not found. Available: {available}")

    if isinstance(data, Name):
        if segment in NAME_PROPERTIES:
            return getattr(data, segment)
        raise PathError(
            f"Name has no property '{segment}'. "
            f"Available: {', '.join(NAME_PROPERTIES)}"
        )

    if isinstance(data, list):
        raise PathError(f"use bracket index [N] for lists (length {len(data)})")

    raise PathError(f"cannot navigate into {type(data).__name__}")


def resolve_segments(data: Any, segments: list[str | int]) -> Any:
    """Navigate into *data* following pre-parsed *segments*."""
    current = data
    for seg in segments:
        current = _step_into(current, seg)
    return current


def resolve_path(data: Any, path_str: str) -> Any:
    """Navigate into *data* using a dot/bracket path string."""
    return resolve_segments(data, parse_path(path_str))


def get_keys(data: Any) -> list[str]:
    """Return navigable keys/indices for *data*.

    List indices are returned as plain digit strings (``"0"``, ``"1"``).
    Callers that need bracket notation for display should wrap them.
    """
    if isinstance(data, dict):
        return list(str(k) for k in data.keys())
    if isinstance(data, list):
        return [str(i) for i in range(len(data))]
    if isinstance(data, Name):
        return list(NAME_PROPERTIES)
    return []


def needs_brackets(key: str) -> bool:
    """True when *key* must be wrapped in ``[...]`` because it contains dots."""
    return "." in key or key.startswith(".")
