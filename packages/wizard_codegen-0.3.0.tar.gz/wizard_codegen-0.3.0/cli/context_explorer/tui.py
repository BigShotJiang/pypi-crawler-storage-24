from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path as FilePath
from typing import Any

from rich.console import Group as RichGroup
from rich.syntax import Syntax
from rich.text import Text
from rich.table import Table
from rich.tree import Tree as RichTree

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.widgets import Footer, Header, Input, Static
from textual.widgets import Tree as TextualTree
from textual.widgets.tree import TreeNode

from utils.name import Name

from .path_resolver import (
    NAME_PROPERTIES,
    PathError,
    needs_brackets,
    parse_path,
    resolve_segments,
)
from .tree import _is_scalar, _should_skip, build_tree


@dataclass
class NodeData:
    """Data attached to each tree node for lazy loading."""

    value: Any
    key: str | int | None = None
    loaded: bool = False


def _type_summary(value: Any) -> str:
    if isinstance(value, Name):
        return "Name"
    if _should_skip(value):
        return f"<{type(value).__name__}>"
    if isinstance(value, dict):
        return f"dict ({len(value)} keys)"
    if isinstance(value, list):
        return f"list ({len(value)} items)"
    if isinstance(value, str):
        return "str"
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"
    if value is None:
        return "NoneType"
    if isinstance(value, FilePath):
        return "Path"
    return type(value).__name__


def _scalar_preview(value: Any) -> str:
    if isinstance(value, str):
        if len(value) > 60:
            return f'"{value[:57]}..."'
        return f'"{value}"'
    if value is None:
        return "None"
    return str(value)


def _to_json_serializable(value: Any) -> Any:
    """Convert a context value into a JSON-serializable structure."""
    if isinstance(value, Name):
        return value.raw
    if isinstance(value, FilePath):
        return str(value)
    if _should_skip(value):
        return f"<{type(value).__name__}>"
    if isinstance(value, dict):
        return {str(k): _to_json_serializable(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_to_json_serializable(v) for v in value]
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    return repr(value)


def node_label(key: str | int | None, value: Any) -> Text:
    """Build a Rich Text label for a tree node."""
    label = Text()

    if key is not None:
        if isinstance(key, int):
            label.append(f"[{key}] ", style="dim")
        else:
            label.append(f"{key}", style="bold")
            label.append(": " if _is_scalar(value) or isinstance(value, Name) else " ", style="")

    if _should_skip(value):
        label.append(f"<{type(value).__name__}>", style="dim")
    elif isinstance(value, Name):
        label.append(value.raw, style="cyan")
    elif isinstance(value, str):
        preview = value if len(value) <= 60 else value[:57] + "..."
        label.append(f'"{preview}"', style="green")
    elif isinstance(value, bool):
        label.append(str(value), style="cyan")
    elif isinstance(value, (int, float)):
        label.append(str(value), style="cyan")
    elif value is None:
        label.append("None", style="dim")
    elif isinstance(value, FilePath):
        label.append(str(value), style="blue")
    elif isinstance(value, dict):
        if not value:
            label.append("{}", style="dim")
        else:
            label.append(f"({len(value)} keys)", style="dim")
    elif isinstance(value, list):
        if not value:
            label.append("[]", style="dim")
        else:
            label.append(f"({len(value)} items)", style="dim")
    else:
        label.append(repr(value), style="dim")

    return label


def _is_expandable(value: Any) -> bool:
    if _should_skip(value):
        return False
    if isinstance(value, Name):
        return True
    if isinstance(value, dict) and value:
        return True
    if isinstance(value, list) and value:
        return True
    return False


def add_children(node: TreeNode[NodeData], data: Any) -> None:
    """Populate direct children of *node* from *data*."""
    if isinstance(data, Name):
        for prop in NAME_PROPERTIES:
            val = getattr(data, prop)
            child_data = NodeData(value=val, key=prop)
            node.add_leaf(node_label(prop, val), data=child_data)
        return

    if isinstance(data, dict):
        for k, v in data.items():
            child_data = NodeData(value=v, key=k)
            lbl = node_label(k, v)
            if _is_expandable(v):
                node.add(lbl, data=child_data)
            else:
                node.add_leaf(lbl, data=child_data)
        return

    if isinstance(data, list):
        for i, item in enumerate(data):
            child_data = NodeData(value=item, key=i)
            lbl = node_label(i, item)
            if _is_expandable(item):
                node.add(lbl, data=child_data)
            else:
                node.add_leaf(lbl, data=child_data)
        return


def _build_path_breadcrumb(node: TreeNode[NodeData]) -> str:
    """Walk up from *node* to root and build a path string."""
    segments: list[str | int] = []
    current: TreeNode[NodeData] | None = node
    while current is not None and current.parent is not None:
        nd = current.data
        if nd and nd.key is not None:
            segments.append(nd.key)
        current = current.parent

    segments.reverse()

    if not segments:
        return "/"

    parts: list[str] = []
    for seg in segments:
        if isinstance(seg, int):
            parts.append(f"[{seg}]")
        elif needs_brackets(str(seg)):
            parts.append(f"[{seg}]")
        else:
            if parts:
                parts.append(f".{seg}")
            else:
                parts.append(str(seg))
    return "".join(parts)


DISPLAY_MODES = ("panel", "tree", "json")


def _detail_header(path: str, value: Any, mode: str) -> Text:
    header = Text()
    header.append("Path: ", style="dim")
    header.append(path, style="bold")
    header.append("\n")
    header.append("Type: ", style="dim")
    header.append(_type_summary(value), style="bold cyan")
    header.append("  ")
    header.append("Mode: ", style="dim")
    header.append(mode, style="bold yellow")
    header.append("  ")
    header.append("(m to cycle)", style="dim")
    header.append("\n")
    return header


def _render_panel(node: TreeNode[NodeData]) -> Table | Text | RichGroup:
    """Summary table view (original detail panel)."""
    nd = node.data
    if nd is None:
        return Text("(no data)")

    value = nd.value
    path = _build_path_breadcrumb(node)
    header = _detail_header(path, value, "panel")

    if isinstance(value, Name):
        tbl = Table(show_header=True, expand=True)
        tbl.add_column("Property", style="bold")
        tbl.add_column("Value", style="green")
        for prop in NAME_PROPERTIES:
            tbl.add_row(prop, getattr(value, prop))
        return RichGroup(header, tbl)

    if isinstance(value, dict):
        tbl = Table(show_header=True, expand=True)
        tbl.add_column("Key", style="bold")
        tbl.add_column("Type", style="dim")
        tbl.add_column("Preview")
        for k, v in value.items():
            preview = ""
            if isinstance(v, Name):
                preview = v.raw
            elif isinstance(v, dict):
                sample = ", ".join(list(v.keys())[:3])
                preview = sample + (", ..." if len(v) > 3 else "")
            elif isinstance(v, list):
                preview = ""
            elif _should_skip(v):
                preview = ""
            elif _is_scalar(v):
                preview = _scalar_preview(v)
            tbl.add_row(str(k), _type_summary(v), preview)
        return RichGroup(header, tbl)

    if isinstance(value, list):
        tbl = Table(show_header=True, expand=True)
        tbl.add_column("Index", style="dim")
        tbl.add_column("Type", style="dim")
        tbl.add_column("Preview")
        for i, item in enumerate(value):
            preview = ""
            if isinstance(item, Name):
                preview = item.raw
            elif isinstance(item, dict):
                fn = item.get("full_name")
                n = item.get("name")
                if fn:
                    preview = str(fn)
                elif isinstance(n, Name):
                    preview = n.raw
                elif isinstance(n, str):
                    preview = n
            elif _is_scalar(item):
                preview = _scalar_preview(item)
            tbl.add_row(str(i), _type_summary(item), preview)
        return RichGroup(header, tbl)

    result = Text()
    result.append_text(header)
    result.append("\nValue: ", style="dim")
    result.append(_scalar_preview(value), style="green")
    return result


def _render_tree(node: TreeNode[NodeData]) -> RichGroup | Text:
    """Rich tree view (like REPL ``tree`` command)."""
    nd = node.data
    if nd is None:
        return Text("(no data)")

    value = nd.value
    path = _build_path_breadcrumb(node)
    header = _detail_header(path, value, "tree")

    if isinstance(value, Name):
        tbl = Table(show_header=True, expand=True)
        tbl.add_column("Property", style="bold")
        tbl.add_column("Value", style="green")
        for prop in NAME_PROPERTIES:
            tbl.add_row(prop, getattr(value, prop))
        return RichGroup(header, tbl)

    if isinstance(value, (dict, list)):
        tree = RichTree(f"[bold]{_type_summary(value)}[/]")
        build_tree(value, tree)
        return RichGroup(header, tree)

    result = Text()
    result.append_text(header)
    result.append("\nValue: ", style="dim")
    result.append(_scalar_preview(value), style="green")
    return result


def _render_json(node: TreeNode[NodeData]) -> RichGroup | Text:
    """Syntax-highlighted JSON view."""
    nd = node.data
    if nd is None:
        return Text("(no data)")

    value = nd.value
    path = _build_path_breadcrumb(node)
    header = _detail_header(path, value, "json")

    try:
        serializable = _to_json_serializable(value)
        json_str = json.dumps(serializable, indent=2, ensure_ascii=False)
    except (TypeError, ValueError):
        json_str = repr(value)

    syntax = Syntax(json_str, "json", theme="monokai", word_wrap=True)
    return RichGroup(header, syntax)


RENDER_BY_MODE = {
    "panel": _render_panel,
    "tree": _render_tree,
    "json": _render_json,
}


def render_detail(
    node: TreeNode[NodeData], mode: str = "panel"
) -> Table | Text | RichGroup:
    """Render the detail panel for *node* using the given display *mode*."""
    return RENDER_BY_MODE.get(mode, _render_panel)(node)


def _filter_dict(d: dict, text: str) -> dict:
    """Return a copy of *d* keeping only keys that contain *text* (case-insensitive)."""
    lower = text.lower()
    return {k: v for k, v in d.items() if lower in str(k).lower()}


def _apply_filter(context: dict, filter_text: str) -> dict:
    """Build a filtered view of *context*.

    For dict values at the top level (message, enum, service, types),
    only keys matching the filter are kept.  Other top-level entries
    are passed through unchanged.
    """
    if not filter_text:
        return context
    filtered: dict = {}
    for key, value in context.items():
        if isinstance(value, dict) and value:
            kept = _filter_dict(value, filter_text)
            filtered[key] = kept
        else:
            filtered[key] = value
    return filtered


class ContextExplorerApp(App[None]):
    """Interactive TUI for exploring the Jinja2 template context."""

    CSS = """
    #main-layout {
        layout: horizontal;
        height: 1fr;
    }
    #left-pane {
        width: 1fr;
        min-width: 40;
    }
    #tree-pane {
        height: 1fr;
    }
    #filter-input {
        dock: top;
        height: 3;
    }
    #detail-scroll {
        width: 1fr;
        min-width: 30;
        border-left: thick $secondary;
    }
    #detail-panel {
        width: 100%;
        padding: 1 2;
    }
    """

    TITLE = "Context Explorer"

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("slash", "focus_filter", "Filter", key_display="/"),
        Binding("m", "cycle_mode", "Mode", key_display="m"),
    ]

    def __init__(self, context: dict, initial_path: str | None = None) -> None:
        super().__init__()
        self._jinja_context = context
        self._initial_path = initial_path
        self._filter_text = ""
        self._display_mode: str = "panel"

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main-layout"):
            with Vertical(id="left-pane"):
                yield Input(
                    placeholder="Type to filter keys... (Esc to clear)",
                    id="filter-input",
                )
                yield TextualTree[NodeData]("Context", id="tree-pane")
            with VerticalScroll(id="detail-scroll"):
                yield Static("Select a node to inspect", id="detail-panel")
        yield Footer()

    def on_mount(self) -> None:
        tree = self.query_one("#tree-pane", TextualTree)
        tree.root.data = NodeData(value=self._jinja_context, loaded=True)
        add_children(tree.root, self._jinja_context)
        tree.root.expand()

        if self._initial_path:
            self._expand_to_path(tree, self._initial_path)

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "filter-input":
            self._filter_text = event.value
            self._apply_tree_filter()

    def _apply_tree_filter(self) -> None:
        """Incrementally show/hide children of root-level dict nodes.

        Nodes that still match the filter keep their expand state and
        lazily-loaded children intact.  Only children that no longer
        match are removed, and only newly-matching children are added.
        """
        tree = self.query_one("#tree-pane", TextualTree)
        filter_lower = self._filter_text.lower()

        for root_child in tree.root.children:
            nd = root_child.data
            if nd is None or nd.key is None:
                continue

            original_value = self._jinja_context.get(nd.key)
            if not isinstance(original_value, dict) or not original_value:
                continue

            if filter_lower:
                visible_keys = {
                    k for k in original_value if filter_lower in str(k).lower()
                }
            else:
                visible_keys = set(original_value.keys())

            filtered_view = {
                k: v for k, v in original_value.items() if k in visible_keys
            }
            nd.value = filtered_view
            root_child.set_label(node_label(nd.key, filtered_view))

            if not nd.loaded:
                continue

            for child in list(root_child.children):
                if child.data and child.data.key not in visible_keys:
                    child.remove()

            current_keys = {
                c.data.key for c in root_child.children if c.data
            }
            for key in visible_keys - current_keys:
                v = original_value[key]
                child_data = NodeData(value=v, key=key)
                lbl = node_label(key, v)
                if _is_expandable(v):
                    root_child.add(lbl, data=child_data)
                else:
                    root_child.add_leaf(lbl, data=child_data)

    def action_focus_filter(self) -> None:
        self.query_one("#filter-input", Input).focus()

    def on_key(self, event) -> None:
        inp = self.query_one("#filter-input", Input)
        if event.key == "escape" and inp.has_focus:
            inp.value = ""
            self.query_one("#tree-pane", TextualTree).focus()
            event.prevent_default()

    def _expand_to_path(
        self, tree: TextualTree[NodeData], path_str: str
    ) -> None:
        """Walk path segments and expand each intermediate node."""
        try:
            segments = parse_path(path_str)
        except Exception:
            return

        current_node = tree.root
        current_data = self._jinja_context

        for seg in segments:
            try:
                child_data_value = resolve_segments(current_data, [seg])
            except PathError:
                return

            nd = current_node.data
            if nd and not nd.loaded:
                add_children(current_node, nd.value)
                nd.loaded = True
            current_node.expand()

            target: TreeNode[NodeData] | None = None
            for child in current_node.children:
                if child.data and child.data.key == seg:
                    target = child
                    break

            if target is None:
                return

            current_node = target
            current_data = child_data_value

        current_node.expand()
        tree.select_node(current_node)

    def on_tree_node_expanded(
        self, event: TextualTree.NodeExpanded[NodeData]
    ) -> None:
        nd = event.node.data
        if nd is None:
            return
        if nd.loaded:
            return
        add_children(event.node, nd.value)
        nd.loaded = True

    def _refresh_detail(self, node: TreeNode[NodeData]) -> None:
        panel = self.query_one("#detail-panel", Static)
        panel.update(render_detail(node, self._display_mode))

    def on_tree_node_highlighted(
        self, event: TextualTree.NodeHighlighted[NodeData]
    ) -> None:
        self._refresh_detail(event.node)

    def action_cycle_mode(self) -> None:
        """Cycle through panel / tree / json display modes."""
        inp = self.query_one("#filter-input", Input)
        if inp.has_focus:
            return
        idx = DISPLAY_MODES.index(self._display_mode)
        self._display_mode = DISPLAY_MODES[(idx + 1) % len(DISPLAY_MODES)]
        tree = self.query_one("#tree-pane", TextualTree)
        node = tree.cursor_node
        if node is not None and node.data is not None:
            self._refresh_detail(node)


def run_tui(context: dict, path: str | None = None) -> None:
    """Launch the interactive TUI context explorer."""
    app = ContextExplorerApp(context, initial_path=path)
    app.run()
