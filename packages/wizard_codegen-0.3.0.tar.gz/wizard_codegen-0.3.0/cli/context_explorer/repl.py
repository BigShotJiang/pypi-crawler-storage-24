from __future__ import annotations

from typing import Any

from prompt_toolkit import PromptSession
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.history import InMemoryHistory
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree

from utils.name import Name

from .path_resolver import (
    PathError,
    get_keys,
    needs_brackets,
    parse_path,
    resolve_path,
    resolve_segments,
)
from .tree import (
    _format_name,
    _format_scalar,
    _is_scalar,
    _should_skip,
    build_tree,
)

_COMMANDS = ["help", "keys", "tree", "quit", "exit", "..", "/"]


class ContextCompleter(Completer):
    """Tab-complete context keys and REPL commands."""

    def __init__(self, root_context: dict) -> None:
        self.root = root_context
        self.cwd_segments: list[str | int] = []

    def _cwd_data(self) -> Any:
        try:
            return resolve_segments(self.root, self.cwd_segments)
        except PathError:
            return self.root

    @staticmethod
    def _display_key(key: str, parent: Any) -> str:
        """Format *key* for display/insertion, adding brackets when needed."""
        if isinstance(parent, list):
            return f"[{key}]"
        if needs_brackets(key):
            return f"[{key}]"
        return key

    def get_completions(self, document, complete_event):  # noqa: ANN001,ANN201
        text = document.text_before_cursor
        cwd = self._cwd_data()

        if not any(c in text for c in ".[]"):
            yield from self._complete_flat(text, cwd)
            return

        inside_bracket = text.count("[") > text.count("]")

        if inside_bracket:
            open_pos = text.rfind("[")
            base_text = text[:open_pos]
            partial = text[open_pos + 1 :]
            try:
                parent = resolve_path(cwd, base_text) if base_text else cwd
            except PathError:
                return
            for key in get_keys(parent):
                if key.lower().startswith(partial.lower()):
                    yield Completion(key + "]", start_position=-len(partial))
            return

        if text.endswith("]"):
            try:
                parent = resolve_path(cwd, text)
            except PathError:
                return
            for key in get_keys(parent):
                display = self._display_key(key, parent)
                if not display.startswith("["):
                    display = f".{display}"
                yield Completion(display, start_position=0)
            return

        last_dot = text.rfind(".")
        last_close = text.rfind("]")
        if last_dot > last_close:
            base_text = text[:last_dot]
            partial = text[last_dot + 1 :]
            try:
                parent = resolve_path(cwd, base_text)
            except PathError:
                return
            for key in get_keys(parent):
                display = self._display_key(key, parent)
                if display.lower().startswith(partial.lower()):
                    yield Completion(display, start_position=-len(partial))
            return

    def _complete_flat(self, text: str, cwd: Any):  # noqa: ANN201
        for cmd in _COMMANDS:
            if cmd.startswith(text):
                yield Completion(cmd, start_position=-len(text))
        for key in get_keys(cwd):
            display = self._display_key(key, cwd)
            if display.lower().startswith(text.lower()) or key.lower().startswith(
                text.lower()
            ):
                yield Completion(display, start_position=-len(text))


def _prompt_label(segments: list[str | int]) -> str:
    if not segments:
        return "/"
    parts: list[str] = []
    for seg in segments:
        if isinstance(seg, int):
            parts.append(f"[{seg}]")
        elif needs_brackets(str(seg)):
            parts.append(f"[{seg}]")
        else:
            if parts:
                parts.append(f".{seg}")
            else:
                parts.append(str(seg))
    return "".join(parts)


def _show_value(data: Any, console: Console) -> None:
    if isinstance(data, Name):
        console.print(_format_name(data))
    elif _is_scalar(data):
        console.print(_format_scalar(data))
    elif isinstance(data, (dict, list)):
        tree = Tree("[bold]value[/]")
        build_tree(data, tree)
        console.print(tree)
    elif _should_skip(data):
        console.print(f"[dim]<{type(data).__name__}>[/]")
    else:
        console.print(repr(data))


def _show_keys_table(data: Any, console: Console) -> None:
    keys = get_keys(data)
    if not keys:
        console.print("[dim]No navigable keys[/]")
        return

    table = Table(show_lines=False)
    table.add_column("Key", style="bold")
    table.add_column("Type", style="dim")
    table.add_column("Preview")

    is_list = isinstance(data, list)

    for key in keys:
        if is_list or needs_brackets(key):
            display_key = f"[{key}]"
        else:
            display_key = key
        try:
            if is_list:
                val = data[int(key)]
            elif isinstance(data, dict):
                val = data[key]
            elif isinstance(data, Name):
                val = getattr(data, key)
            else:  # pragma: no cover — get_keys only returns keys for dict/list/Name
                val = None

            type_str = type(val).__name__
            if isinstance(val, Name):
                type_str = "Name"
                preview = val.raw
            elif isinstance(val, dict):
                type_str = f"dict ({len(val)} keys)"
                sample = ", ".join(list(val.keys())[:3])
                preview = sample + (", ..." if len(val) > 3 else "")
            elif isinstance(val, list):
                type_str = f"list ({len(val)} items)"
                preview = ""
            elif _should_skip(val):
                type_str = f"<{type(val).__name__}>"
                preview = ""
            elif _is_scalar(val):
                preview = str(val) if val is not None else "None"
                if len(preview) > 60:
                    preview = preview[:57] + "..."
            else:
                preview = f"<{type_str}>"

            table.add_row(display_key, type_str, preview)
        except (KeyError, IndexError, AttributeError):  # pragma: no cover — defensive
            table.add_row(display_key, "?", "")

    console.print(table)


def _show_help(console: Console) -> None:
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Command", style="cyan bold")
    table.add_column("Description")
    table.add_row("<path>", "Navigate to path (dot-separated, [brackets] for dict/list index)")
    table.add_row("keys", "Show available keys at current level")
    table.add_row("..", "Go up one level")
    table.add_row("/", "Go to root")
    table.add_row("tree [depth]", "Show tree from current position (optional depth limit)")
    table.add_row("help", "Show this help")
    table.add_row("quit", "Exit the explorer")
    console.print(Panel(table, title="[bold]Commands[/]", border_style="cyan"))


def run_repl(context: dict, console: Console | None = None) -> None:
    """Launch the interactive context explorer REPL."""
    console = console or Console()
    completer = ContextCompleter(context)
    session: PromptSession = PromptSession(
        history=InMemoryHistory(),
        completer=completer,
        complete_while_typing=True,
        reserve_space_for_menu=6,
    )

    cwd_segments: list[str | int] = []

    console.print("[bold]Context Explorer[/] - type [cyan]help[/] for commands\n")
    _show_keys_table(context, console)

    while True:
        path_label = _prompt_label(cwd_segments)
        try:
            text = session.prompt(f"context:{path_label}> ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not text:
            continue

        if text in ("quit", "exit"):
            break

        if text == "help":
            _show_help(console)
            continue

        if text == "/":
            cwd_segments.clear()
            completer.cwd_segments = cwd_segments
            console.print("[dim]At root[/]")
            _show_keys_table(context, console)
            continue

        if text == "..":
            if cwd_segments:
                cwd_segments.pop()
                completer.cwd_segments = cwd_segments
            cwd_data = _resolve_cwd(context, cwd_segments, console)
            if cwd_data is not None:
                _show_keys_table(cwd_data, console)
            continue

        if text == "keys":
            cwd_data = _resolve_cwd(context, cwd_segments, console)
            if cwd_data is not None:
                _show_keys_table(cwd_data, console)
            continue

        if text.startswith("tree"):
            parts = text.split(maxsplit=1)
            depth: int | None = None
            if len(parts) > 1:
                try:
                    depth = int(parts[1])
                except ValueError:
                    console.print("[bold red]Usage:[/] tree [depth]")
                    continue
            cwd_data = _resolve_cwd(context, cwd_segments, console)
            if cwd_data is not None:
                tree = Tree(f"[bold]{path_label}[/]")
                build_tree(cwd_data, tree, max_depth=depth)
                console.print(Panel(tree, border_style="cyan"))
            continue

        try:
            cwd_data = _resolve_cwd(context, cwd_segments, console)
            if cwd_data is None:
                continue
            resolved = resolve_path(cwd_data, text)
            new_segments = parse_path(text)
            cwd_segments.extend(new_segments)
            completer.cwd_segments = cwd_segments

            if isinstance(resolved, (dict, list)):
                _show_keys_table(resolved, console)
            else:
                _show_value(resolved, console)
        except PathError as e:
            console.print(f"[bold red]Error:[/] {e}")


def _resolve_cwd(
    context: dict,
    cwd_segments: list[str | int],
    console: Console,
) -> Any | None:
    if not cwd_segments:
        return context
    try:
        return resolve_segments(context, cwd_segments)
    except PathError as e:
        console.print(f"[bold red]Error:[/] current path is invalid: {e}")
        return None
