from __future__ import annotations

from pathlib import Path as FilePath
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.tree import Tree

from utils.name import Name

from .path_resolver import PathError, resolve_path

try:
    from google.protobuf.message import Message as _ProtoMessage
except ImportError:  # pragma: no cover
    _ProtoMessage = None  # type: ignore[assignment,misc]


def _format_name(name: Name) -> str:
    return (
        f"[bold]{name.raw}[/] "
        f"[dim](raw=[/]{name.raw}[dim], snake=[/]{name.snake_case}"
        f"[dim], kebab=[/]{name.kebab_case}"
        f"[dim], pascal=[/]{name.pascal_case}[dim], camel=[/]{name.camel_case}"
        f"[dim], macro=[/]{name.macro_case}[dim], macro_snake=[/]{name.macro_snake_case}"
        f"[dim], micro=[/]{name.micro_case}[dim])[/]"
    )


def _is_scalar(value: Any) -> bool:
    return isinstance(value, (str, int, float, bool, type(None), FilePath))


def _format_scalar(value: Any) -> str:
    if isinstance(value, str):
        if len(value) > 120:
            return f'[green]"{value[:117]}..."[/]'
        return f'[green]"{value}"[/]'
    if isinstance(value, bool):
        return f"[cyan]{value}[/]"
    if isinstance(value, (int, float)):
        return f"[cyan]{value}[/]"
    if value is None:
        return "[dim]None[/]"
    if isinstance(value, FilePath):
        return f"[blue]{value}[/]"
    return repr(value)


def _should_skip(value: Any) -> bool:
    if _ProtoMessage and isinstance(value, _ProtoMessage):
        return True
    return False


def _item_label(item: dict) -> str:
    full_name = item.get("full_name")
    if full_name:
        return f"[bold]{full_name}[/]"
    name = item.get("name")
    if isinstance(name, Name):
        return f"[bold]{name.raw}[/]"
    if isinstance(name, str):
        return f"[bold]{name}[/]"
    return f"[dim]({len(item)} keys)[/]"


def build_tree(
    data: Any,
    tree: Tree,
    depth: int = 0,
    max_depth: int | None = None,
) -> None:
    """Recursively populate a Rich *tree* from context *data*."""
    if max_depth is not None and depth >= max_depth:
        if isinstance(data, dict) and data:
            tree.add(f"[dim]... ({len(data)} keys)[/]")
        elif isinstance(data, list) and data:
            tree.add(f"[dim]... ({len(data)} items)[/]")
        return

    if isinstance(data, Name):
        tree.add(_format_name(data))
        return

    if _should_skip(data):
        tree.add(f"[dim]<{type(data).__name__}>[/]")
        return

    if _is_scalar(data):
        tree.add(_format_scalar(data))
        return

    if isinstance(data, dict):
        for key, value in data.items():
            if _should_skip(value):
                tree.add(f"[bold]{key}[/]: [dim]<{type(value).__name__}>[/]")
            elif isinstance(value, Name):
                tree.add(f"[bold]{key}[/]: {_format_name(value)}")
            elif _is_scalar(value):
                tree.add(f"[bold]{key}[/]: {_format_scalar(value)}")
            elif isinstance(value, dict):
                if not value:
                    tree.add(f"[bold]{key}[/]: [dim]{{}}[/]")
                else:
                    branch = tree.add(f"[bold]{key}[/] [dim]({len(value)} keys)[/]")
                    build_tree(value, branch, depth + 1, max_depth)
            elif isinstance(value, list):
                if not value:
                    tree.add(f"[bold]{key}[/]: [dim]\\[][/]")
                else:
                    branch = tree.add(f"[bold]{key}[/] [dim]({len(value)} items)[/]")
                    build_tree(value, branch, depth + 1, max_depth)
            else:
                branch = tree.add(f"[bold]{key}[/]")
                build_tree(value, branch, depth + 1, max_depth)
        return

    if isinstance(data, list):
        for i, item in enumerate(data):
            if _should_skip(item):
                tree.add(f"[dim][{i}][/]: [dim]<{type(item).__name__}>[/]")
            elif isinstance(item, Name):
                tree.add(f"[dim][{i}][/]: {_format_name(item)}")
            elif _is_scalar(item):
                tree.add(f"[dim][{i}][/]: {_format_scalar(item)}")
            elif isinstance(item, dict):
                label = _item_label(item)
                branch = tree.add(f"[dim][{i}][/] {label}")
                build_tree(item, branch, depth + 1, max_depth)
            elif isinstance(item, list):
                branch = tree.add(f"[dim][{i}][/] [dim]({len(item)} items)[/]")
                build_tree(item, branch, depth + 1, max_depth)
            else:
                branch = tree.add(f"[dim][{i}][/]")
                build_tree(item, branch, depth + 1, max_depth)
        return

    tree.add(f"[dim]{repr(data)}[/]")


def show_context_tree(
    context: dict,
    path: str | None = None,
    max_depth: int | None = 4,
    console: Console | None = None,
) -> None:
    """Render *context* (or a sub-path of it) as a Rich Tree in a Panel."""
    console = console or Console()
    data = context
    title = "Context"

    if path:
        try:
            data = resolve_path(context, path)
            title = f"Context > {path}"
        except PathError as e:
            console.print(f"[bold red]Error:[/] {e}")
            return

    tree = Tree(f"[bold]{title}[/]")
    build_tree(data, tree, max_depth=max_depth)
    console.print(Panel(tree, border_style="cyan"))
