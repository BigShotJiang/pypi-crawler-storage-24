from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

TYPE_BOOL = 8
TYPE_STRING = 9
TYPE_MESSAGE = 11
TYPE_BYTES = 12
TYPE_ENUM = 14

NUMERIC_TYPES = {1, 2, 3, 4, 5, 6, 7, 13, 15, 16, 17, 18}

LABEL_REPEATED = 3

def _resolve_default_sample(samples: list[dict]) -> dict | None:
    for s in samples:
        if s.get("name") == "default":
            return s
    return samples[0] if samples else None


def _samples_path_for(proto_root: Path, file_rel: str) -> Path:
    proto_path = proto_root / file_rel
    return proto_path.with_suffix(".samples.json")


def _parse_samples_file(path: Path) -> list[dict] | None:
    """Load JSON from *path* and normalise to a list of sample dicts.

    Returns ``None`` when the file cannot be parsed (caller decides
    whether to warn or error).
    """
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.warning("cannot read %s: %s", path, exc)
        return None

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        logger.warning("invalid JSON in %s: %s", path, exc)
        return None

    if isinstance(data, dict):
        return [data]
    if isinstance(data, list):
        return data
    logger.warning("unexpected top-level type in %s: %s", path, type(data).__name__)
    return None


def _is_top_level(msg: dict) -> bool:
    """True when *msg* is a top-level message (not nested inside another)."""
    prefix = f".{msg['package']}."
    full = msg["full_name"]
    if not full.startswith(prefix):
        return False
    rest = full[len(prefix):]
    return "." not in rest


def _propagate_samples_to_nested(
    msg: dict, message_index: dict[str, dict]
) -> None:
    """Extract sub-objects from the parent's samples and attach them
    to nested message definitions so they also carry sample data.

    The sample key for a nested message is resolved by looking at the
    parent's fields first: if a field of TYPE_MESSAGE references the
    nested type, the field's ``json_name`` is used (e.g. a field
    ``InputField name_field = 2`` uses ``"nameField"``).  When no
    matching field exists (e.g. the wizard-page pattern where
    ``Context`` / ``Form`` are fieldless nested types), the camelCase
    of the type name is used as a fallback.
    """
    parent_samples = msg.get("samples", [])
    parent_default = msg.get("default_sample")

    field_key_by_type: dict[str, str] = {}
    for field in msg.get("fields", []):
        if field.get("type") == TYPE_MESSAGE and field.get("type_name"):
            field_key_by_type[field["type_name"]] = field["json_name"]

    for nested in msg.get("nested_messages", []):
        full_name = nested.get("full_name")
        if not full_name or full_name not in message_index:
            continue

        sample_key = field_key_by_type.get(full_name)
        if sample_key is None:
            name_obj = nested.get("name")
            sample_key = getattr(name_obj, "camel_case", None)
        if not sample_key:
            continue

        nested_msg = message_index[full_name]

        nested_samples = []
        for sample in parent_samples:
            sub = sample.get(sample_key)
            if isinstance(sub, dict):
                nested_samples.append(sub)

        nested_default = None
        if parent_default:
            sub = parent_default.get(sample_key)
            if isinstance(sub, dict):
                nested_default = sub

        nested_msg["samples"] = nested_samples
        nested_msg["default_sample"] = nested_default

        if nested_samples:
            _propagate_samples_to_nested(nested_msg, message_index)


def load_samples(context: dict, proto_root: Path) -> None:
    """Enrich every message in *context* with samples from co-located
    ``.samples.json`` files.  Safe to call even when no samples exist.

    Top-level messages receive the full samples from the file.  Nested
    messages receive the relevant sub-object extracted from each parent
    sample, matched by the field ``json_name`` that references the
    nested type (falling back to the type name's camelCase when no
    field exists).
    """
    proto_root = proto_root.resolve()
    message_index = context["message"]
    cache: dict[str, tuple[list[dict], dict | None]] = {}

    for msg in message_index.values():
        if not _is_top_level(msg):
            msg["samples"] = []
            msg["default_sample"] = None
            continue

        file_rel = msg["file"]
        if file_rel not in cache:
            samples_path = _samples_path_for(proto_root, file_rel)
            if not samples_path.exists():
                cache[file_rel] = ([], None)
            else:
                parsed = _parse_samples_file(samples_path)
                if parsed is None:
                    cache[file_rel] = ([], None)
                else:
                    cache[file_rel] = (parsed, _resolve_default_sample(parsed))

        msg["samples"], msg["default_sample"] = cache[file_rel]

    for msg in message_index.values():
        if _is_top_level(msg) and msg.get("samples"):
            _propagate_samples_to_nested(msg, message_index)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _build_field_index(msg_data: dict) -> dict[str, dict]:
    """Map ``json_name`` -> field descriptor dict for a message."""
    return {f["json_name"]: f for f in msg_data.get("fields", [])}


def _build_nested_msg_index(msg_data: dict) -> dict[str, dict]:
    """Map camelCase nested message type name -> nested message dict.

    Wizard page protos define ``Context`` and ``Form`` as nested message
    types without top-level fields.  The sample JSON uses the camelCase
    type name as the key (e.g. ``"context": {...}``).
    """
    index: dict[str, dict] = {}
    for nested in msg_data.get("nested_messages", []):
        name_obj = nested.get("name")
        camel = getattr(name_obj, "camel_case", None)
        if camel:
            index[camel] = nested
    return index


def _check_json_type(value: Any, field: dict) -> str | None:
    """Return an error fragment if *value* doesn't match *field*'s proto type,
    or ``None`` when the value is acceptable."""
    ftype = field["type"]

    if ftype == TYPE_STRING:
        if not isinstance(value, str):
            return f"expected string but got {type(value).__name__}"
    elif ftype in NUMERIC_TYPES:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return f"expected number but got {type(value).__name__}"
    elif ftype == TYPE_BOOL:
        if not isinstance(value, bool):
            return f"expected bool but got {type(value).__name__}"
    elif ftype == TYPE_BYTES:
        if not isinstance(value, str):
            return f"expected string (base64) but got {type(value).__name__}"
    elif ftype == TYPE_ENUM:
        if not isinstance(value, (str, int)) or isinstance(value, bool):
            return f"expected string or number (enum) but got {type(value).__name__}"
    elif ftype == TYPE_MESSAGE:
        if not isinstance(value, dict):
            return f"expected object but got {type(value).__name__}"
    return None


def _validate_object(
    obj: dict,
    msg_data: dict,
    message_index: dict,
    path: str,
    errors: list[str],
    file_label: str,
    sample_idx: int,
) -> None:
    """Recursively validate *obj* against *msg_data*'s fields."""
    field_index = _build_field_index(msg_data)
    nested_index = _build_nested_msg_index(msg_data)

    for key, value in obj.items():
        if key == "name" and not path:
            continue

        if key not in field_index:
            nested_msg = nested_index.get(key)
            if nested_msg is not None:
                json_path = f"{path}.{key}" if path else key
                if not isinstance(value, dict):
                    errors.append(
                        f'sample[{sample_idx}] in {file_label}: '
                        f'field "{json_path}" expected object but got {type(value).__name__}'
                    )
                else:
                    _validate_object(value, nested_msg, message_index, json_path, errors, file_label, sample_idx)
                continue

            errors.append(
                f'sample[{sample_idx}] in {file_label}: unknown field "{key}" at {path}'
            )
            continue

        field = field_index[key]
        json_path = f"{path}.{key}" if path else key

        if field["label"] == LABEL_REPEATED:
            if not isinstance(value, list):
                errors.append(
                    f"sample[{sample_idx}] in {file_label}: "
                    f'field "{json_path}" expected array but got {type(value).__name__}'
                )
                continue
            for i, elem in enumerate(value):
                elem_path = f"{json_path}[{i}]"
                type_err = _check_json_type(elem, field)
                if type_err:
                    errors.append(
                        f'sample[{sample_idx}] in {file_label}: field "{elem_path}" {type_err}'
                    )
                elif field["type"] == TYPE_MESSAGE:
                    ref = message_index.get(field["type_name"])
                    if ref:
                        _validate_object(elem, ref, message_index, elem_path, errors, file_label, sample_idx)
            continue

        type_err = _check_json_type(value, field)
        if type_err:
            errors.append(
                f'sample[{sample_idx}] in {file_label}: field "{json_path}" {type_err}'
            )
            continue

        if field["type"] == TYPE_MESSAGE:
            ref = message_index.get(field["type_name"])
            if ref:
                _validate_object(value, ref, message_index, json_path, errors, file_label, sample_idx)


def validate_samples(context: dict, proto_root: Path) -> list[str]:
    """Validate all ``.samples.json`` files found next to proto files.

    Returns a list of human-readable error strings (empty == all good).
    """
    proto_root = proto_root.resolve()
    message_index = context["message"]
    errors: list[str] = []

    seen_files: set[str] = set()

    for msg in message_index.values():
        if not _is_top_level(msg):
            continue

        file_rel = msg["file"]
        if file_rel in seen_files:
            continue
        seen_files.add(file_rel)

        samples_path = _samples_path_for(proto_root, file_rel)
        if not samples_path.exists():
            continue

        file_label = str(samples_path)

        try:
            text = samples_path.read_text(encoding="utf-8")
        except OSError as exc:
            errors.append(f"cannot read {file_label}: {exc}")
            continue

        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            errors.append(f"invalid samples file {file_label}: {exc}")
            continue

        if isinstance(data, dict):
            samples: list[dict] = [data]
        elif isinstance(data, list):
            samples = data
        else:
            errors.append(
                f"invalid samples file {file_label}: "
                f"expected object or array, got {type(data).__name__}"
            )
            continue

        if not samples:
            errors.append(
                f"samples file {file_label} must contain at least one sample"
            )
            continue

        for idx, sample in enumerate(samples):
            if not isinstance(sample, dict):
                errors.append(
                    f"sample[{idx}] in {file_label}: expected object but got {type(sample).__name__}"
                )
                continue
            _validate_object(sample, msg, message_index, "", errors, file_label, idx)

    return errors
