"""
Utility functions and classes.

Contains helper functions for name transformations and other utilities.
"""

from .name import Name, to_snake, to_kebab, to_pascal, to_camel, to_macro_snake, to_macro, to_micro
from .path import expand_path
from .options import extract_options, has_option, get_option, build_extension_registry

__all__ = [
    "Name",
    "to_snake",
    "to_kebab",
    "to_pascal",
    "to_camel",
    "to_macro",
    "to_micro",
    "to_macro_snake",
    "expand_path",
    "extract_options",
    "has_option",
    "get_option",
    "build_extension_registry",
]
