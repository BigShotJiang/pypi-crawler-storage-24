"""Utility functions for extracting protobuf options and annotations."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple
import logging
import struct

# Global extension registry: maps (extendee_type, field_number) -> (full_name, type_name, field_type)
# field_type is the protobuf type enum (TYPE_BOOL, TYPE_INT32, etc.) for decoding primitives.
# This is populated by build_extension_registry() when loading the FDS
_extension_registry: Dict[tuple, Tuple[str, str, int]] = {}

# Global message registry: maps full_name -> list of (field_number, field_name, field_type)
_message_registry: Dict[str, List[Tuple[int, str, int]]] = {}

# Proto wire types
WIRETYPE_VARINT = 0
WIRETYPE_FIXED64 = 1
WIRETYPE_LENGTH_DELIMITED = 2
WIRETYPE_FIXED32 = 5

# Proto field types
TYPE_DOUBLE = 1
TYPE_FLOAT = 2
TYPE_INT64 = 3
TYPE_UINT64 = 4
TYPE_INT32 = 5
TYPE_FIXED64 = 6
TYPE_FIXED32 = 7
TYPE_BOOL = 8
TYPE_STRING = 9
TYPE_MESSAGE = 11
TYPE_BYTES = 12
TYPE_UINT32 = 13
TYPE_ENUM = 14
TYPE_SFIXED32 = 15
TYPE_SFIXED64 = 16
TYPE_SINT32 = 17
TYPE_SINT64 = 18


def build_extension_registry(fds: Any) -> Dict[tuple, Tuple[str, str, int]]:
    """
    Build a registry of extensions from a FileDescriptorSet.

    This extracts all extension definitions and creates a mapping from
    (extendee, field_number) to (extension_full_name, extension_type_name, field_type).

    Also builds a message registry for parsing extension message values.

    Args:
        fds: A FileDescriptorSet protobuf message

    Returns:
        A dictionary mapping (extendee_type, field_number) to (full_name, type_name, field_type).
    """
    global _extension_registry, _message_registry
    registry: Dict[tuple, Tuple[str, str, int]] = {}
    msg_registry: Dict[str, List[Tuple[int, str, int]]] = {}

    try:
        for file_desc in fds.file:
            # Get package prefix for building full names
            package = file_desc.package

            # Build message registry for all messages
            def register_message(msg, parent_name: str):
                msg_full_name = f"{parent_name}.{msg.name}" if parent_name else f".{msg.name}"
                if package and not parent_name:
                    msg_full_name = f".{package}.{msg.name}"

                fields = []
                for field in msg.field:
                    fields.append((field.number, field.name, field.type))
                msg_registry[msg_full_name] = fields

                for nested in msg.nested_type:
                    register_message(nested, msg_full_name)

            for msg in file_desc.message_type:
                register_message(msg, "")

            # Process file-level extensions
            for ext in file_desc.extension:
                extendee = ext.extendee  # e.g., ".google.protobuf.MessageOptions"
                field_number = ext.number
                type_name = ext.type_name  # e.g., ".annotations.wizard.v1.WizardPageOptions"
                raw_type = getattr(ext, "type", 0)
                field_type = int(raw_type) if isinstance(raw_type, int) else 0  # TYPE_* enum for decoding primitives
                # Build full name: package.name
                full_name = f"{package}.{ext.name}" if package else ext.name
                registry[(extendee, field_number)] = (full_name, type_name, field_type)

            # Process extensions nested in messages
            def process_nested_extensions(msg, parent_name: str):
                for ext in msg.extension:
                    extendee = ext.extendee
                    field_number = ext.number
                    type_name = ext.type_name
                    raw_type = getattr(ext, "type", 0)
                    field_type = int(raw_type) if isinstance(raw_type, int) else 0
                    full_name = f"{parent_name}.{ext.name}"
                    registry[(extendee, field_number)] = (full_name, type_name, field_type)

                for nested in msg.nested_type:
                    nested_name = f"{parent_name}.{nested.name}"
                    process_nested_extensions(nested, nested_name)

            for msg in file_desc.message_type:
                msg_name = f"{package}.{msg.name}" if package else msg.name
                process_nested_extensions(msg, msg_name)
    except (AttributeError, TypeError) as e:
        # Intentionally ignore descriptor shape/type issues and fall back to empty registries.
        # This allows callers to treat "unparseable" FileDescriptorSet objects as having no extensions.
        _ = e

    _extension_registry = registry
    _message_registry = msg_registry
    return registry


def _parse_varint(data: bytes, pos: int) -> tuple:
    """Parse a varint from bytes at the given position."""
    result = 0
    shift = 0
    while pos < len(data):
        byte = data[pos]
        result |= (byte & 0x7f) << shift
        pos += 1
        if not (byte & 0x80):
            break
        shift += 7
    return result, pos


def _decode_zigzag(n: int) -> int:
    """Decode a ZigZag-encoded signed integer."""
    return (n >> 1) ^ -(n & 1)


def _decode_varint_value(raw: int, field_type: int) -> Any:
    """Decode a varint value according to protobuf field type (TYPE_*)."""
    if field_type == TYPE_BOOL:
        return bool(raw)
    if field_type in (TYPE_SINT32, TYPE_SINT64):
        return _decode_zigzag(raw)
    return raw


def _decode_fixed64_value(data: bytes, pos: int, field_type: int) -> Tuple[Any, int]:
    """Decode 8 bytes at pos as FIXED64; return (value, new_pos)."""
    if field_type == TYPE_DOUBLE:
        return struct.unpack("<d", data[pos : pos + 8])[0], pos + 8
    return int.from_bytes(data[pos : pos + 8], "little"), pos + 8


def _decode_fixed32_value(data: bytes, pos: int, field_type: int) -> Tuple[Any, int]:
    """Decode 4 bytes at pos as FIXED32; return (value, new_pos)."""
    if field_type == TYPE_FLOAT:
        return struct.unpack("<f", data[pos : pos + 4])[0], pos + 4
    return int.from_bytes(data[pos : pos + 4], "little"), pos + 4


def _parse_message_bytes(data: bytes, type_name: str) -> Dict[str, Any]:
    """
    Parse a serialized protobuf message into a dictionary.

    Uses the message registry to map field numbers to names.

    Args:
        data: Serialized protobuf message bytes
        type_name: Full name of the message type (e.g., ".annotations.wizard.v1.WizardPageOptions")

    Returns:
        A dictionary of field names to values.
    """
    result: Dict[str, Any] = {}

    # Get field definitions for this message type
    fields = _message_registry.get(type_name, [])
    if not fields:
        return result

    # Build field lookup: number -> (name, type)
    field_lookup: Dict[int, Tuple[str, int]] = {
        f[0]: (f[1], f[2]) for f in fields
    }

    pos = 0
    while pos < len(data):
        try:
            # Parse tag
            tag, pos = _parse_varint(data, pos)
            field_number = tag >> 3
            wire_type = tag & 0x7

            value: Any = None

            if wire_type == WIRETYPE_VARINT:
                value, pos = _parse_varint(data, pos)
                # Check if it's a bool
                if field_number in field_lookup:
                    _, field_type = field_lookup[field_number]
                    if field_type == TYPE_BOOL:
                        value = bool(value)
                    elif field_type in (TYPE_SINT32, TYPE_SINT64):
                        value = _decode_zigzag(value)

            elif wire_type == WIRETYPE_FIXED64:
                value = int.from_bytes(data[pos:pos+8], 'little')
                pos += 8

            elif wire_type == WIRETYPE_LENGTH_DELIMITED:
                length, pos = _parse_varint(data, pos)
                raw_bytes = data[pos:pos+length]
                pos += length

                # Determine if it's a string or bytes based on field type
                if field_number in field_lookup:
                    _, field_type = field_lookup[field_number]
                    if field_type == TYPE_STRING:
                        value = raw_bytes.decode('utf-8')
                    elif field_type == TYPE_BYTES:
                        value = raw_bytes
                    elif field_type == TYPE_MESSAGE:
                        # Recursively parse nested message
                        # We'd need to look up the nested type - for now just mark as present
                        value = True
                    else:
                        value = raw_bytes
                else:
                    # Try to decode as string, fall back to bytes
                    try:
                        value = raw_bytes.decode('utf-8')
                    except UnicodeDecodeError:
                        value = raw_bytes

            elif wire_type == WIRETYPE_FIXED32:
                value = int.from_bytes(data[pos:pos+4], 'little')
                pos += 4
            else:
                # Unknown wire type, skip
                break

            # Map field number to name
            if field_number in field_lookup:
                field_name, _ = field_lookup[field_number]
                result[field_name] = value

        except (IndexError, UnicodeDecodeError):
            break

    return result


def _extract_unknown_extensions(options: Any, extendee_type: str) -> Dict[str, Any]:
    """
    Extract extension options from serialized unknown fields.

    Custom extensions that aren't registered with Python protobuf are stored
    as serialized bytes. This function parses those bytes to extract
    extension field numbers and matches them against our registry.

    Args:
        options: A protobuf options message
        extendee_type: The full name of the options type (e.g., ".google.protobuf.MessageOptions")

    Returns:
        A dictionary of extension names to values.
    """
    result: Dict[str, Any] = {}

    try:
        # Serialize the options to get all data including unknown fields
        serialized = options.SerializeToString()
        if not serialized:
            return result

        # Parse the wire format to find field numbers
        pos = 0
        while pos < len(serialized):
            # Parse the tag (field number + wire type)
            tag, pos = _parse_varint(serialized, pos)
            field_number = tag >> 3
            wire_type = tag & 0x7

            value_bytes: bytes = b""
            scalar_value: Any = None  # For VARINT/FIXED32/FIXED64

            # Extract the value based on wire type
            if wire_type == WIRETYPE_VARINT:
                raw_varint, pos = _parse_varint(serialized, pos)
                scalar_value = raw_varint
            elif wire_type == WIRETYPE_FIXED64:
                if (extendee_type, field_number) in _extension_registry:
                    _, __, field_type = _extension_registry[(extendee_type, field_number)]
                    scalar_value, pos = _decode_fixed64_value(serialized, pos, field_type)
                else:
                    pos += 8
            elif wire_type == WIRETYPE_LENGTH_DELIMITED:
                length, pos = _parse_varint(serialized, pos)
                value_bytes = serialized[pos : pos + length]
                pos += length
            elif wire_type == WIRETYPE_FIXED32:
                if (extendee_type, field_number) in _extension_registry:
                    _, __, field_type = _extension_registry[(extendee_type, field_number)]
                    scalar_value, pos = _decode_fixed32_value(serialized, pos, field_type)
                else:
                    pos += 4
            else:
                # Unknown wire type, can't continue
                break

            # Check if this field number is a known extension
            key = (extendee_type, field_number)
            if key in _extension_registry:
                ext_name, ext_type_name, field_type = _extension_registry[key]

                # If it's a message type (length-delimited), try to parse the value
                if wire_type == WIRETYPE_LENGTH_DELIMITED and ext_type_name:
                    parsed_value = _parse_message_bytes(value_bytes, ext_type_name)
                    # If no fields were set, return True to indicate presence
                    result[ext_name] = parsed_value if parsed_value else True
                elif scalar_value is not None:
                    # VARINT, FIXED32, or FIXED64: use actual decoded value
                    if wire_type == WIRETYPE_VARINT:
                        result[ext_name] = _decode_varint_value(scalar_value, field_type)
                    else:
                        result[ext_name] = scalar_value
                else:
                    result[ext_name] = True

    except (AttributeError, TypeError, IndexError) as e:
        # Intentionally ignore malformed / unexpected option data and fall back to an empty result.
        # Log at debug level to aid troubleshooting without breaking callers.
        logging.debug("Failed to extract unknown extensions from options %r: %s", options, e)

    return result


def extract_options(options: Any, extendee_type: Optional[str] = None) -> Dict[str, Any]:
    """
    Extract options from a protobuf options message into a dictionary.

    This function handles both standard protobuf options (like 'deprecated')
    and custom extension options (like 'annotations.wizard.v1.page').

    Args:
        options: A protobuf options message (MessageOptions, FieldOptions, etc.)
                 or None
        extendee_type: Optional. The full name of the options message type
                       (e.g., ".google.protobuf.MessageOptions"). Required for
                       extracting custom extensions.

    Returns:
        A dictionary mapping option names to their values.
        Standard options use short names (e.g., 'deprecated').
        Extension options use their full qualified name
        (e.g., 'annotations.wizard.v1.page').

    Example:
        For a message with option (annotations.wizard.v1.page) = {};
        Returns: {'annotations.wizard.v1.page': True}

        For a message with option deprecated = true;
        Returns: {'deprecated': True}
    """
    if options is None:
        return {}

    result: Dict[str, Any] = {}

    # First, extract known fields via ListFields()
    try:
        for field_desc, value in options.ListFields():
            # Check if this is an extension field
            if field_desc.is_extension:
                # Use the full name for extension options
                # e.g., "annotations.wizard.v1.page"
                key = field_desc.full_name
            else:
                # Use the simple name for standard options
                # e.g., "deprecated", "java_package"
                key = field_desc.name

            # Convert the value to a Python-friendly format
            result[key] = _convert_value(value)
    except (AttributeError, TypeError):
        # If options doesn't support ListFields (e.g., Mock object without setup)
        pass

    # Then, extract unknown extensions from serialized data.
    # Only add entries for keys not already in result, so we never overwrite
    # extensions that were properly extracted via ListFields() with lower-fidelity
    # wire-parsed values (e.g., nested messages would become True).
    if extendee_type and _extension_registry:
        unknown_extensions = _extract_unknown_extensions(options, extendee_type)
        for k, v in unknown_extensions.items():
            if k not in result:
                result[k] = v

    return result


def _convert_value(value: Any) -> Any:
    """
    Convert a protobuf value to a Python-friendly format.

    Args:
        value: A protobuf value (could be a message, repeated field, etc.)

    Returns:
        A Python-native representation of the value.
    """
    # Check if it's a repeated field (list-like)
    if hasattr(value, '__iter__') and not isinstance(value, (str, bytes)):
        try:
            # Try to convert as a list
            return [_convert_value(v) for v in value]
        except TypeError:
            pass

    # Check if it's a message type with fields
    if hasattr(value, 'ListFields'):
        # It's a nested message, convert it to a dict
        nested = {}
        try:
            for field_desc, field_value in value.ListFields():
                nested[field_desc.name] = _convert_value(field_value)
        except (AttributeError, TypeError) as exc:
            # Intentionally ignore descriptor/type issues when inspecting nested messages.
            # This keeps option extraction robust for mock or non-standard message-like objects.
            logging.debug("Failed to ListFields() on nested value %r: %s", value, exc)
        # If the message is empty (no fields set), return True to indicate presence
        return nested if nested else True

    # Check if it's an enum value
    if hasattr(value, 'number') and hasattr(value, 'name'):
        return value.name

    # Return primitive values as-is
    return value


def has_option(options: Dict[str, Any], option_name: str) -> bool:
    """
    Check if an option is present in the extracted options dictionary.

    Matching modes:
    - Exact match: `"annotations.wizard.v1.page"` matches only that exact key
    - Glob pattern (with `*`): `"*.page"` matches any option ending with `.page`
    - Glob pattern: `"annotations.*"` matches any option starting with `annotations.`

    Args:
        options: The extracted options dictionary
        option_name: The option name or glob pattern to check for

    Returns:
        True if the option is present, False otherwise.

    Examples:
        has_option({"annotations.wizard.v1.page": True}, "annotations.wizard.v1.page")  # True
        has_option({"annotations.wizard.v1.page": True}, "*.page")  # True
        has_option({"annotations.wizard.v1.page": True}, "page")  # False (no wildcard)
    """
    import fnmatch

    if not options:
        return False

    # Check if it's a glob pattern (contains *)
    if "*" in option_name:
        for key in options:
            if fnmatch.fnmatch(key, option_name):
                return True
        return False

    # Exact match only
    return option_name in options


def get_option(options: Dict[str, Any], option_name: str) -> Any:
    """
    Get an option value from the extracted options dictionary.

    Supports the same matching as has_option:
    - Exact match: `"annotations.wizard.v1.page"` matches only that exact key
    - Glob pattern (with `*`): `"*.page"` matches any option ending with `.page`

    Args:
        options: The extracted options dictionary
        option_name: The option name or glob pattern to get

    Returns:
        The option value if found, None otherwise.
    """
    import fnmatch

    if not options:
        return None

    # Check if it's a glob pattern (contains *)
    if "*" in option_name:
        for key, value in options.items():
            if fnmatch.fnmatch(key, option_name):
                return value
        return None

    # Exact match only
    return options.get(option_name)
