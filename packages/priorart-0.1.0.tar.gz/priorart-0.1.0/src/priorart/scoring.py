"""Reality signal computation from search results."""

from __future__ import annotations


def compute_signal(
    repos: list[dict],
    hn_posts: list[dict],
) -> dict:
    """Compute a 0-100 reality signal from search results.

    Returns a dict with score, verdict, and breakdown.
    """
    # GitHub component (0-60)
    total_repos = len(repos)
    max_stars = max((r["stars"] for r in repos), default=0)

    if total_repos == 0:
        gh_score = 0
    elif total_repos <= 3:
        gh_score = 15
    elif total_repos <= 7:
        gh_score = 30
    else:
        gh_score = 45

    if max_stars >= 5000:
        gh_score = min(60, gh_score + 20)
    elif max_stars >= 1000:
        gh_score = min(60, gh_score + 15)
    elif max_stars >= 100:
        gh_score = min(60, gh_score + 10)

    # HN component (0-40)
    total_hn = len(hn_posts)
    max_points = max((p["points"] for p in hn_posts), default=0)

    if total_hn == 0:
        hn_score = 0
    elif total_hn <= 2:
        hn_score = 10
    else:
        hn_score = 25

    if max_points >= 100:
        hn_score = min(40, hn_score + 15)
    elif max_points >= 30:
        hn_score = min(40, hn_score + 10)

    score = min(100, gh_score + hn_score)

    if score < 30:
        verdict = "LOW"
    elif score <= 60:
        verdict = "MODERATE"
    else:
        verdict = "HIGH"

    return {
        "score": score,
        "verdict": verdict,
        "breakdown": {
            "github": gh_score,
            "hn": hn_score,
        },
    }
