"""Source adapters for prior art search."""
