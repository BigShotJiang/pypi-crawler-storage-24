"""Tests for scanner module — query building."""


from priorart.scanner import build_queries


class TestBuildQueries:
    def test_simple_idea(self):
        queries = build_queries("AI personal finance tracker")
        assert len(queries) >= 1
        assert "AI personal finance tracker" in queries

    def test_strips_idea_prefix(self):
        queries = build_queries("idea: AI personal finance tracker")
        for q in queries:
            assert not q.lower().startswith("idea:")

    def test_strips_idea_bracket_prefix(self):
        queries = build_queries("[idea] AI personal finance tracker")
        for q in queries:
            assert not q.lower().startswith("[idea]")

    def test_splits_on_dash_separator(self):
        queries = build_queries("Kuma — Self-hosted uptime monitor")
        # Should produce multi-word queries, not just "Kuma"
        assert any(len(q.split()) > 1 for q in queries)

    def test_splits_on_em_dash(self):
        queries = build_queries("FinTrack — AI finance tracker")
        assert any("AI finance tracker" in q or "finance tracker" in q for q in queries)

    def test_long_title_adds_shortened_variants(self):
        long_title = "AI-powered personal finance tracking application for mobile"
        queries = build_queries(long_title)
        # Should add 5-word and 3-word variants
        assert len(queries) >= 2

    def test_no_duplicate_queries(self):
        queries = build_queries("AI personal finance tracker")
        lower = [q.lower() for q in queries]
        assert len(lower) == len(set(lower))

    def test_body_adds_extra_query(self):
        queries = build_queries(
            "Finance app",
            body="Smart budgeting with machine learning insights",
        )
        assert any("Smart budgeting" in q or "budgeting" in q for q in queries)

    def test_body_ignores_http_lines(self):
        queries = build_queries(
            "Finance app",
            body="https://example.com/something\nSmart budgeting tool",
        )
        # URL line should be skipped
        for q in queries:
            assert "https://" not in q

    def test_returns_list_of_strings(self):
        queries = build_queries("test idea")
        assert isinstance(queries, list)
        assert all(isinstance(q, str) for q in queries)

    def test_empty_title_edge_case(self):
        # Should not raise, returns whatever makes sense
        queries = build_queries("   ")
        assert isinstance(queries, list)
