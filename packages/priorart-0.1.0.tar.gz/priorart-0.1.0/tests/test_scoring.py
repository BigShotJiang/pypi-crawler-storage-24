"""Tests for scoring module."""


from priorart.scoring import compute_signal


def make_repo(stars: int) -> dict:
    return {
        "name": "org/repo",
        "stars": stars,
        "description": "test",
        "url": "https://github.com/org/repo",
        "updated": "2024-01-01",
        "language": "Python",
    }


def make_hn(points: int) -> dict:
    return {
        "title": "Test post",
        "points": points,
        "comments": 10,
        "url": "https://news.ycombinator.com/item?id=1",
        "date": "2024-01-01",
    }


class TestComputeSignal:
    def test_empty_results_returns_zero(self):
        result = compute_signal([], [])
        assert result["score"] == 0
        assert result["verdict"] == "LOW"
        assert result["breakdown"]["github"] == 0
        assert result["breakdown"]["hn"] == 0

    def test_low_verdict_under_30(self):
        result = compute_signal([], [])
        assert result["verdict"] == "LOW"
        assert result["score"] < 30

    def test_moderate_verdict_30_to_60(self):
        # 4 repos with low stars → gh=30, no HN → score=30 → MODERATE
        repos = [make_repo(10) for _ in range(4)]
        result = compute_signal(repos, [])
        assert result["verdict"] == "MODERATE"
        assert 30 <= result["score"] <= 60

    def test_high_verdict_over_60(self):
        # 8+ repos with 5000+ stars + 3+ HN posts → HIGH
        repos = [make_repo(10000) for _ in range(10)]
        hn = [make_hn(200) for _ in range(5)]
        result = compute_signal(repos, hn)
        assert result["verdict"] == "HIGH"
        assert result["score"] > 60

    def test_max_stars_boost_github(self):
        one_repo = [make_repo(5000)]
        result = compute_signal(one_repo, [])
        # 1 repo = 15, 5000 stars = +20 → 35
        assert result["breakdown"]["github"] == 35

    def test_score_capped_at_100(self):
        repos = [make_repo(10000) for _ in range(20)]
        hn = [make_hn(500) for _ in range(20)]
        result = compute_signal(repos, hn)
        assert result["score"] <= 100

    def test_breakdown_keys_present(self):
        result = compute_signal([], [])
        assert "github" in result["breakdown"]
        assert "hn" in result["breakdown"]
