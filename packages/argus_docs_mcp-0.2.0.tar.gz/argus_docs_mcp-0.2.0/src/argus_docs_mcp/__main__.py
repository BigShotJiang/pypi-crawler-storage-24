"""Entry point for the Argus documentation MCP server.

Usage:
    argus-docs-mcp              # via console script
    python -m argus_docs_mcp    # via module

Environment variables:
    ARGUS_API_URL:    Base URL of the Argus API (required)
    ARGUS_API_KEY:    API key for authentication (required)
    ARGUS_PROJECT_ID: Default project UUID, slug, or name (optional).
                      When set, tools auto-scope to this project without
                      needing to pass project_id on every call.
"""

from __future__ import annotations

import os
import sys


def _log(msg: str) -> None:
    print(f"[argus-docs] {msg}", file=sys.stderr)


def _check_env() -> bool:
    """Validate environment before starting. Returns True if OK."""
    ok = True
    api_key = os.environ.get("ARGUS_API_KEY", "")
    api_url = os.environ.get("ARGUS_API_URL", "")

    if not api_key:
        _log(
            "ERROR: ARGUS_API_KEY not set.\n"
            "  Set it in your MCP client config or export it in your shell.\n"
            "  Create a key in Argus -> Settings -> API Keys."
        )
        ok = False

    if not api_url:
        _log(
            "ERROR: ARGUS_API_URL not set.\n"
            "  Set it to your Argus instance URL, e.g. https://your-instance.com/api"
        )
        ok = False

    return ok


def _preflight_check() -> bool:
    """Quick HTTP check that the API is reachable and the key is valid."""
    import httpx

    api_url = os.environ.get("ARGUS_API_URL", "")
    api_key = os.environ.get("ARGUS_API_KEY", "")
    try:
        resp = httpx.get(
            f"{api_url}/mcp/projects",
            headers={"X-API-Key": api_key},
            timeout=10.0,
        )
        if resp.status_code == 401:
            _log(
                "ERROR: API key rejected (401 Unauthorized).\n"
                "  Check that ARGUS_API_KEY is correct and not revoked."
            )
            return False
        if resp.status_code == 403:
            _log(
                "ERROR: API key lacks 'documents' scope (403).\n"
                "  Revoke this key and create a new one with 'documents' scope."
            )
            return False
        resp.raise_for_status()
        projects = resp.json().get("projects", [])
        project_id = os.environ.get("ARGUS_PROJECT_ID", "")
        _log(
            f"Connected — {len(projects)} project(s) accessible"
            + (f", default: {project_id}" if project_id else "")
        )
        return True
    except httpx.ConnectError:
        _log(
            f"ERROR: Cannot reach API at {api_url}\n"
            "  Check ARGUS_API_URL and that the server is running."
        )
        return False
    except httpx.TimeoutException:
        _log(
            f"WARNING: API at {api_url} timed out.\n"
            "  Server may be slow — starting anyway."
        )
        return True
    except Exception as e:
        _log(f"WARNING: Preflight check failed: {e}")
        return True


def main() -> None:
    if not _check_env():
        sys.exit(1)
    if not _preflight_check():
        sys.exit(1)

    from argus_docs_mcp.server import create_server

    server = create_server()
    server.run(transport="stdio")


if __name__ == "__main__":
    main()
