"""MCP server definition with tool implementations."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from argus_docs_mcp.client import ArgusApiError, ArgusClient

_client: ArgusClient | None = None
_resolved: bool = False


def _get_client() -> ArgusClient:
    global _client
    if _client is None:
        _client = ArgusClient()
    return _client


async def _ensure_resolved() -> None:
    """Resolve the default project ID once on first tool call."""
    global _resolved
    if not _resolved:
        client = _get_client()
        await client.resolve_default_project()
        _resolved = True


def create_server() -> FastMCP:
    """Create and configure the Argus documentation MCP server."""
    mcp = FastMCP("Argus Docs")

    # ── Projects ──────────────────────────────────────────────────

    @mcp.tool()
    async def list_projects() -> str:
        """List all accessible projects.

        Returns a formatted list of projects with their IDs and names.
        Use the project ID when calling other documentation tools.
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            projects = await client.list_projects()
            if not projects:
                return "No projects found."
            lines = ["# Projects\n"]
            default_id = client.default_project_id
            for p in projects:
                prefix = p.get("task_prefix", "")
                marker = " ← **default**" if default_id and p["id"] == default_id else ""
                lines.append(f"- **{p['name']}** (ID: `{p['id']}`, prefix: {prefix}){marker}")
            return "\n".join(lines)
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    # ── List / Read ───────────────────────────────────────────────

    @mcp.tool()
    async def list_docs(
        project_id: str | None = None,
        category: str = "documentation",
    ) -> str:
        """List documentation pages for a project.

        Args:
            project_id: Project UUID (optional if ARGUS_PROJECT_ID is configured)
            category: Filter by category. Options: documentation, api_reference,
                      guide, changelog, note. Default: documentation
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            pid = project_id or client.default_project_id
            if not pid:
                return "Error: project_id is required (no default project configured). Call list_projects first."
            docs = await client.list_docs(pid, category)
            if not docs:
                return f"No documents found (category: {category})."
            lines = [f"# Documentation ({len(docs)} pages)\n"]
            for d in docs:
                parent = f" (child of {d['parent_document_id']})" if d.get("parent_document_id") else ""
                lines.append(
                    f"- **{d['title']}** — ID: `{d['id']}`, "
                    f"category: {d['doc_category']}, slug: {d['slug']}{parent}"
                )
            return "\n".join(lines)
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    @mcp.tool()
    async def read_doc(doc_id: str) -> str:
        """Read a document's full content as markdown.

        Args:
            doc_id: Document UUID (get from list_docs or search_docs)
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            doc = await client.read_doc(doc_id)
            header = (
                f"# {doc['title']}\n"
                f"*ID: {doc['id']} | Category: {doc['doc_category']} | "
                f"Updated: {doc.get('updated_at', 'unknown')}*\n\n---\n\n"
            )
            return header + (doc.get("content_markdown") or "_Empty document_")
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    # ── Create / Update / Delete ──────────────────────────────────

    @mcp.tool()
    async def create_doc(
        title: str,
        content_markdown: str,
        project_id: str | None = None,
        parent_doc_id: str | None = None,
        category: str = "documentation",
    ) -> str:
        """Create a new documentation page.

        Args:
            title: Document title
            content_markdown: Full document content in markdown format
            project_id: Project UUID (optional if ARGUS_PROJECT_ID is configured)
            parent_doc_id: Optional parent document UUID for nesting under a section
            category: Document category (documentation, api_reference, guide, changelog)
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            pid = project_id or client.default_project_id
            if not pid:
                return "Error: project_id is required (no default project configured)."
            doc = await client.create_doc(
                pid, title, content_markdown, parent_doc_id, category
            )
            return (
                f"Created: **{doc['title']}**\n"
                f"- ID: `{doc['id']}`\n"
                f"- Slug: {doc['slug']}\n"
                f"- Category: {doc['doc_category']}"
            )
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    @mcp.tool()
    async def update_doc(
        doc_id: str,
        title: str | None = None,
        content_markdown: str | None = None,
    ) -> str:
        """Update an existing documentation page.

        Args:
            doc_id: Document UUID
            title: New title (optional, omit to keep current)
            content_markdown: New content in markdown (optional, omit to keep current)
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            doc = await client.update_doc(doc_id, title, content_markdown)
            return (
                f"Updated: **{doc['title']}**\n"
                f"- ID: `{doc['id']}`\n"
                f"- Updated at: {doc.get('updated_at', 'now')}"
            )
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    @mcp.tool()
    async def delete_doc(doc_id: str) -> str:
        """Delete a documentation page permanently.

        Args:
            doc_id: Document UUID of the page to delete
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            result = await client.delete_doc(doc_id)
            title = result.get("title", "document")
            return f"Deleted: **{title}**"
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    # ── Search ────────────────────────────────────────────────────

    @mcp.tool()
    async def search_docs(
        query: str,
        project_id: str | None = None,
    ) -> str:
        """Search documentation by title and content.

        Args:
            query: Search text (matches against document titles and content)
            project_id: Optional project UUID to scope the search (defaults to configured project)
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            pid = project_id or client.default_project_id
            docs = await client.search_docs(query, pid)
            if not docs:
                return f"No documents matching '{query}'."
            lines = [f"# Search results for '{query}' ({len(docs)} matches)\n"]
            for d in docs:
                snippet = ""
                if d.get("snippet"):
                    snippet = f"\n  > {d['snippet']}"
                lines.append(
                    f"- **{d['title']}** — ID: `{d['id']}`, category: {d['doc_category']}{snippet}"
                )
            return "\n".join(lines)
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    # ── Tasks ──────────────────────────────────────────────────

    @mcp.tool()
    async def list_tasks(
        project_id: str | None = None,
        status: str | None = None,
        priority: str | None = None,
    ) -> str:
        """List tasks for a project.

        Args:
            project_id: Project UUID (optional if ARGUS_PROJECT_ID is configured)
            status: Filter by status slug (e.g. 'open', 'in-progress', 'done')
            priority: Filter by priority (urgent, high, normal, low, none)
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            pid = project_id or client.default_project_id
            if not pid:
                return "Error: project_id is required (no default project configured). Call list_projects first."
            tasks = await client.list_tasks(pid, status, priority)
            if not tasks:
                return "No tasks found."
            lines = [f"# Tasks ({len(tasks)})\n"]
            for t in tasks:
                key = t.get("task_key") or "—"
                prio = t.get("priority") or ""
                st = t.get("status") or ""
                tags = ", ".join(t.get("tags") or [])
                info_parts = []
                if st:
                    info_parts.append(f"status: {st}")
                if prio and prio != "none":
                    info_parts.append(f"priority: {prio}")
                if tags:
                    info_parts.append(f"tags: {tags}")
                info = ", ".join(info_parts)
                lines.append(f"- **[{key}]** {t['title']} — ID: `{t['id']}`{', ' + info if info else ''}")
            return "\n".join(lines)
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    @mcp.tool()
    async def read_task(task_id: str) -> str:
        """Read a single task's details.

        Args:
            task_id: Task UUID (get from list_tasks)
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            t = await client.read_task(task_id)
            key = t.get("task_key") or "—"
            lines = [
                f"# {key} — {t['title']}",
                f"*ID: {t['id']} | Priority: {t.get('priority', 'none')} | Status: {t.get('status', 'none')}*",
            ]
            if t.get("tags"):
                lines.append(f"**Tags**: {', '.join(t['tags'])}")
            if t.get("due_date"):
                lines.append(f"**Due**: {t['due_date']}")
            if t.get("description"):
                lines.append(f"\n---\n\n{t['description']}")
            return "\n".join(lines)
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    @mcp.tool()
    async def create_task(
        title: str,
        project_id: str | None = None,
        description: str | None = None,
        priority: str = "normal",
        status: str | None = None,
        tags: list[str] | None = None,
        parent_task_id: str | None = None,
    ) -> str:
        """Create a new task in a project.

        Args:
            title: Task title
            project_id: Project UUID (optional if ARGUS_PROJECT_ID is configured)
            description: Task description (plain text)
            priority: Priority level (urgent, high, normal, low, none). Default: normal
            status: Status slug (e.g. 'open', 'in-progress'). Optional.
            tags: List of tag strings. Optional.
            parent_task_id: Parent task UUID for creating subtasks. Optional.
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            pid = project_id or client.default_project_id
            if not pid:
                return "Error: project_id is required (no default project configured)."
            t = await client.create_task(
                pid, title, description, priority, status, tags, parent_task_id
            )
            return (
                f"Created: **[{t.get('task_key', '—')}]** {t['title']}\n"
                f"- ID: `{t['id']}`\n"
                f"- Priority: {t.get('priority', 'normal')}\n"
                f"- Status: {t.get('status', 'none')}"
            )
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    @mcp.tool()
    async def update_task(
        task_id: str,
        title: str | None = None,
        description: str | None = None,
        priority: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
    ) -> str:
        """Update an existing task.

        Args:
            task_id: Task UUID
            title: New title (optional, omit to keep current)
            description: New description (optional, omit to keep current)
            priority: New priority (urgent, high, normal, low, none). Optional.
            status: New status slug. Optional.
            tags: New tags list. Optional.
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            t = await client.update_task(task_id, title, description, priority, status, tags)
            return (
                f"Updated: **[{t.get('task_key', '—')}]** {t['title']}\n"
                f"- ID: `{t['id']}`\n"
                f"- Updated at: {t.get('updated_at', 'now')}"
            )
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    @mcp.tool()
    async def delete_task(task_id: str) -> str:
        """Delete a task permanently.

        Args:
            task_id: Task UUID of the task to delete
        """
        try:
            await _ensure_resolved()
            client = _get_client()
            result = await client.delete_task(task_id)
            key = result.get("task_key") or ""
            title = result.get("title", "task")
            return f"Deleted: **[{key}]** {title}"
        except ArgusApiError as e:
            return f"Error: {e.detail}"

    return mcp
