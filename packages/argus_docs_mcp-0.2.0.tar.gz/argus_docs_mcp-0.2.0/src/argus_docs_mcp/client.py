"""HTTP client wrapper for the Argus documentation API."""

from __future__ import annotations

import os
import sys

import httpx


def _log(msg: str) -> None:
    print(f"[argus-docs] {msg}", file=sys.stderr)


class ArgusApiError(Exception):
    """Raised when the Argus API returns an error with a human-readable message."""

    def __init__(self, status: int, detail: str) -> None:
        self.status = status
        self.detail = detail
        super().__init__(f"HTTP {status}: {detail}")


class ArgusClient:
    """Async HTTP client for Argus API documentation endpoints."""

    def __init__(self) -> None:
        self.base_url = os.environ.get("ARGUS_API_URL", "")
        self.api_key = os.environ.get("ARGUS_API_KEY", "")
        if not self.api_key:
            raise ValueError("ARGUS_API_KEY environment variable is required")
        if not self.base_url:
            raise ValueError("ARGUS_API_URL environment variable is required")
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"X-API-Key": self.api_key, "Content-Type": "application/json"},
            timeout=30.0,
        )
        self.default_project_id: str | None = os.environ.get("ARGUS_PROJECT_ID") or None

    async def _request(
        self,
        method: str,
        path: str,
        **kwargs,
    ) -> httpx.Response:
        """Send an HTTP request with user-friendly error handling."""
        try:
            resp = await self._client.request(method, path, **kwargs)
        except httpx.ConnectError:
            raise ArgusApiError(0, f"Cannot connect to {self.base_url} — is the server running?")
        except httpx.TimeoutException:
            raise ArgusApiError(0, f"Request to {self.base_url}{path} timed out after 30s")

        if resp.status_code == 401:
            raise ArgusApiError(401, "API key rejected — check ARGUS_API_KEY is valid and not revoked")
        if resp.status_code == 403:
            body = resp.json() if resp.headers.get("content-type", "").startswith("application/json") else {}
            raise ArgusApiError(403, body.get("error", "Forbidden — key may lack required scope"))
        if resp.status_code == 404:
            raise ArgusApiError(404, f"Not found: {path}")
        if resp.status_code >= 400:
            detail = resp.text[:200] if resp.text else f"HTTP {resp.status_code}"
            raise ArgusApiError(resp.status_code, detail)

        return resp

    async def resolve_default_project(self) -> str | None:
        """Resolve ARGUS_PROJECT_ID if it looks like a slug/name (not a UUID)."""
        raw = self.default_project_id
        if not raw:
            return None
        # Already looks like a UUID — use as-is
        if len(raw) > 20 and "-" in raw:
            return raw
        # Otherwise treat as slug or name — resolve via list_projects
        projects = await self.list_projects()
        for p in projects:
            if p.get("slug") == raw or (p.get("name") or "").lower() == raw.lower():
                self.default_project_id = p["id"]
                return p["id"]
            if (p.get("task_prefix") or "").lower() == raw.lower():
                self.default_project_id = p["id"]
                return p["id"]
        # Didn't match — assume it's a UUID
        return raw

    # ── Projects ──────────────────────────────────────────────────

    async def list_projects(self) -> list[dict]:
        resp = await self._request("GET", "/mcp/projects")
        return resp.json()["projects"]

    # ── Documents ─────────────────────────────────────────────────

    async def list_docs(
        self, project_id: str, category: str | None = None
    ) -> list[dict]:
        params: dict[str, str] = {"project_id": project_id}
        if category:
            params["category"] = category
        resp = await self._request("GET", "/mcp/documents", params=params)
        return resp.json()["documents"]

    async def read_doc(self, doc_id: str) -> dict:
        resp = await self._request("GET", f"/mcp/documents/{doc_id}")
        return resp.json()["document"]

    async def create_doc(
        self,
        project_id: str,
        title: str,
        content_markdown: str,
        parent_doc_id: str | None = None,
        category: str = "documentation",
    ) -> dict:
        body: dict = {
            "project_id": project_id,
            "title": title,
            "content_markdown": content_markdown,
            "doc_category": category,
        }
        if parent_doc_id:
            body["parent_document_id"] = parent_doc_id
        resp = await self._request("POST", "/mcp/documents", json=body)
        return resp.json()["document"]

    async def update_doc(
        self,
        doc_id: str,
        title: str | None = None,
        content_markdown: str | None = None,
    ) -> dict:
        body: dict = {}
        if title is not None:
            body["title"] = title
        if content_markdown is not None:
            body["content_markdown"] = content_markdown
        resp = await self._request("PUT", f"/mcp/documents/{doc_id}", json=body)
        return resp.json()["document"]

    async def delete_doc(self, doc_id: str) -> dict:
        resp = await self._request("DELETE", f"/mcp/documents/{doc_id}")
        return resp.json()

    async def search_docs(
        self, query: str, project_id: str | None = None
    ) -> list[dict]:
        params: dict[str, str] = {"q": query}
        if project_id:
            params["project_id"] = project_id
        resp = await self._request("GET", "/mcp/documents/search", params=params)
        return resp.json()["documents"]

    # ── Tasks ───────────────────────────────────────────────────

    async def list_tasks(
        self,
        project_id: str,
        status: str | None = None,
        priority: str | None = None,
    ) -> list[dict]:
        params: dict[str, str] = {"project_id": project_id}
        if status:
            params["status"] = status
        if priority:
            params["priority"] = priority
        resp = await self._request("GET", "/mcp/tasks", params=params)
        return resp.json()["tasks"]

    async def read_task(self, task_id: str) -> dict:
        resp = await self._request("GET", f"/mcp/tasks/{task_id}")
        return resp.json()["task"]

    async def create_task(
        self,
        project_id: str,
        title: str,
        description: str | None = None,
        priority: str = "normal",
        status: str | None = None,
        tags: list[str] | None = None,
        parent_task_id: str | None = None,
    ) -> dict:
        body: dict = {
            "project_id": project_id,
            "title": title,
            "priority": priority,
        }
        if description:
            body["description"] = description
        if status:
            body["status"] = status
        if tags:
            body["tags"] = tags
        if parent_task_id:
            body["parent_task_id"] = parent_task_id
        resp = await self._request("POST", "/mcp/tasks", json=body)
        return resp.json()["task"]

    async def update_task(
        self,
        task_id: str,
        title: str | None = None,
        description: str | None = None,
        priority: str | None = None,
        status: str | None = None,
        tags: list[str] | None = None,
    ) -> dict:
        body: dict = {}
        if title is not None:
            body["title"] = title
        if description is not None:
            body["description"] = description
        if priority is not None:
            body["priority"] = priority
        if status is not None:
            body["status"] = status
        if tags is not None:
            body["tags"] = tags
        resp = await self._request("PUT", f"/mcp/tasks/{task_id}", json=body)
        return resp.json()["task"]

    async def delete_task(self, task_id: str) -> dict:
        resp = await self._request("DELETE", f"/mcp/tasks/{task_id}")
        return resp.json()

    async def close(self) -> None:
        await self._client.aclose()
