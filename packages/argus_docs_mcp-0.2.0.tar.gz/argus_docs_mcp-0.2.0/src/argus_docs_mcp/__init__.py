"""Argus Documentation MCP Server.

A Model Context Protocol server that connects AI clients to Argus project
documentation.  Read, create, update, delete, and search docs — all from
your editor or chat client.

Usage (after install):
    argus-docs-mcp          # stdio transport (default for AI clients)

Environment variables:
    ARGUS_API_URL    Base URL of the Argus API  (required, e.g. https://your-instance.com/api)
    ARGUS_API_KEY    API key with 'documents' scope  (required)
    ARGUS_PROJECT_ID Default project UUID, slug, or name  (optional — auto-scopes tools)
"""

from argus_docs_mcp.__main__ import main  # noqa: F401

__version__ = "0.2.0"
