.. _installation_ref:

=================
Installation
=================

Stable release
--------------

To install covmats, run this command in your terminal:

.. code-block:: console

    $ pip install covmats

This is the preferred method to install covmats, as it will always install the most recent stable release.

If you don't have `pip`_ installed, this `Python installation guide`_ can guide
you through the process.

.. _pip: https://pip.pypa.io
.. _Python installation guide: http://docs.python-guide.org/en/latest/starting/installation/


From sources
------------

The sources for covmats can be downloaded from the `Github repo`_.

You can either clone the public repository:

.. code-block:: console

    $ git clone git://github.com/antoinecollet5/covmats

Once you have a copy of the source, you can install it with:

.. code-block:: console

    $ pip install -e .[all]


Tutorials
---------

For a quick overview of covmats functionality, see the :ref:`user guide<user_guide_ref>`.

You can also refer to the :ref:`reference guide<api_ref>` for an exhaustive
list of all what is possible with covmats.

.. _Github repo: https://github.com/antoinecollet5/covmats
.. _tarball: https://github.com/antoinecollet5/covmats/tarball/master
