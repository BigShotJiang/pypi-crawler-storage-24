﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.ConstantPriorTerm
=========================

.. currentmodule:: covmats

.. autoclass:: ConstantPriorTerm

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~ConstantPriorTerm.get_gradient_dot_product
      
      ~ConstantPriorTerm.get_values
      
   

   