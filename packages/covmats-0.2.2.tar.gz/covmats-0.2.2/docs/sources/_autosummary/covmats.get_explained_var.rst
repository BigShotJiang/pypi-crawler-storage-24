﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.get\_explained\_var
===========================

.. currentmodule:: covmats

.. autofunction:: get_explained_var