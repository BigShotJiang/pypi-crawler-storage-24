﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.LinearDriftMatrix
=========================

.. currentmodule:: covmats

.. autoclass:: LinearDriftMatrix

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~LinearDriftMatrix.mat
      
      ~LinearDriftMatrix.beta_dim
      
      ~LinearDriftMatrix.s_dim
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~LinearDriftMatrix.dot
      
      ~LinearDriftMatrix.get_gradient_dot_product
      
      ~LinearDriftMatrix.get_values
      
   

   