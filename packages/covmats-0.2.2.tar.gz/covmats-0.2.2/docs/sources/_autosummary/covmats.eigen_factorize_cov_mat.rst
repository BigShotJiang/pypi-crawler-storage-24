﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.eigen\_factorize\_cov\_mat
==================================

.. currentmodule:: covmats

.. autofunction:: eigen_factorize_cov_mat