﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.get\_linop\_eigen\_factorization
========================================

.. currentmodule:: covmats

.. autofunction:: get_linop_eigen_factorization