﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.DriftMatrix
===================

.. currentmodule:: covmats

.. autoclass:: DriftMatrix

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~DriftMatrix.mat
      
      ~DriftMatrix.beta_dim
      
      ~DriftMatrix.s_dim
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~DriftMatrix.dot
      
      ~DriftMatrix.get_gradient_dot_product
      
      ~DriftMatrix.get_values
      
   

   