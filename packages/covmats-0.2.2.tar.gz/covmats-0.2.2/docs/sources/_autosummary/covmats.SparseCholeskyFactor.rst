﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.SparseCholeskyFactor
============================

.. currentmodule:: covmats

.. autoclass:: SparseCholeskyFactor

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~SparseCholeskyFactor.D
      
      ~SparseCholeskyFactor.H
      
      ~SparseCholeskyFactor.L
      
      ~SparseCholeskyFactor.P
      
      ~SparseCholeskyFactor.Pt
      
      ~SparseCholeskyFactor.T
      
      ~SparseCholeskyFactor.invD
      
      ~SparseCholeskyFactor.log_pdet
      
      ~SparseCholeskyFactor.mat
      
      ~SparseCholeskyFactor.n_pts
      
      ~SparseCholeskyFactor.ndim
      
      ~SparseCholeskyFactor.shape
      
      ~SparseCholeskyFactor.sqrtD
      
      ~SparseCholeskyFactor.sqrtinvD
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~SparseCholeskyFactor.adjoint
      
      ~SparseCholeskyFactor.apply_P
      
      ~SparseCholeskyFactor.apply_Pt
      
      ~SparseCholeskyFactor.colorize
      
      ~SparseCholeskyFactor.colorize_inv
      
      ~SparseCholeskyFactor.dot
      
      ~SparseCholeskyFactor.get_diagonal
      
      ~SparseCholeskyFactor.get_invdiagonal
      
      ~SparseCholeskyFactor.inv
      
      ~SparseCholeskyFactor.matmat
      
      ~SparseCholeskyFactor.matvec
      
      ~SparseCholeskyFactor.rmatmat
      
      ~SparseCholeskyFactor.rmatvec
      
      ~SparseCholeskyFactor.solve
      
      ~SparseCholeskyFactor.todense
      
      ~SparseCholeskyFactor.transpose
      
      ~SparseCholeskyFactor.whiten
      
      ~SparseCholeskyFactor.whiten_inv
      
   

   