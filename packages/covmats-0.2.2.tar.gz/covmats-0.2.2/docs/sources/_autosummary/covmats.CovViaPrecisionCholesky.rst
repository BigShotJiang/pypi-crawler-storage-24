﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovViaPrecisionCholesky
===============================

.. currentmodule:: covmats

.. autoclass:: CovViaPrecisionCholesky

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaPrecisionCholesky.H
      
      ~CovViaPrecisionCholesky.L
      
      ~CovViaPrecisionCholesky.T
      
      ~CovViaPrecisionCholesky.covariance
      
      ~CovViaPrecisionCholesky.log_pdet
      
      ~CovViaPrecisionCholesky.n_pts
      
      ~CovViaPrecisionCholesky.ndim
      
      ~CovViaPrecisionCholesky.precision
      
      ~CovViaPrecisionCholesky.rank
      
      ~CovViaPrecisionCholesky.shape
      
      ~CovViaPrecisionCholesky.subspace_size
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaPrecisionCholesky.adjoint
      
      ~CovViaPrecisionCholesky.colorize
      
      ~CovViaPrecisionCholesky.dot
      
      ~CovViaPrecisionCholesky.from_cholesky
      
      ~CovViaPrecisionCholesky.from_diagonal
      
      ~CovViaPrecisionCholesky.from_eigendecomposition
      
      ~CovViaPrecisionCholesky.from_precision
      
      ~CovViaPrecisionCholesky.get_diagonal
      
      ~CovViaPrecisionCholesky.get_trace
      
      ~CovViaPrecisionCholesky.matmat
      
      ~CovViaPrecisionCholesky.matvec
      
      ~CovViaPrecisionCholesky.rmatmat
      
      ~CovViaPrecisionCholesky.rmatvec
      
      ~CovViaPrecisionCholesky.sample_mvnormal
      
      ~CovViaPrecisionCholesky.solve
      
      ~CovViaPrecisionCholesky.todense
      
      ~CovViaPrecisionCholesky.transpose
      
      ~CovViaPrecisionCholesky.whiten
      
   

   