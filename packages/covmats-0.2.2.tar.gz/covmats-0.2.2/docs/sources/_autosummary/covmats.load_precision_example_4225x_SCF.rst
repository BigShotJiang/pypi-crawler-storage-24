﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.load\_precision\_example\_4225x\_SCF
============================================

.. currentmodule:: covmats

.. autofunction:: load_precision_example_4225x_SCF