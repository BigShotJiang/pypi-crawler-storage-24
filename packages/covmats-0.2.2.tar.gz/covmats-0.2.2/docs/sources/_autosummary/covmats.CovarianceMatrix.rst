﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovarianceMatrix
========================

.. currentmodule:: covmats

.. autoclass:: CovarianceMatrix

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovarianceMatrix.H
      
      ~CovarianceMatrix.T
      
      ~CovarianceMatrix.covariance
      
      ~CovarianceMatrix.log_pdet
      
      ~CovarianceMatrix.n_pts
      
      ~CovarianceMatrix.ndim
      
      ~CovarianceMatrix.precision
      
      ~CovarianceMatrix.rank
      
      ~CovarianceMatrix.shape
      
      ~CovarianceMatrix.subspace_size
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovarianceMatrix.adjoint
      
      ~CovarianceMatrix.colorize
      
      ~CovarianceMatrix.dot
      
      ~CovarianceMatrix.from_cholesky
      
      ~CovarianceMatrix.from_diagonal
      
      ~CovarianceMatrix.from_eigendecomposition
      
      ~CovarianceMatrix.from_precision
      
      ~CovarianceMatrix.get_diagonal
      
      ~CovarianceMatrix.get_trace
      
      ~CovarianceMatrix.matmat
      
      ~CovarianceMatrix.matvec
      
      ~CovarianceMatrix.rmatmat
      
      ~CovarianceMatrix.rmatvec
      
      ~CovarianceMatrix.sample_mvnormal
      
      ~CovarianceMatrix.solve
      
      ~CovarianceMatrix.todense
      
      ~CovarianceMatrix.transpose
      
      ~CovarianceMatrix.whiten
      
   

   