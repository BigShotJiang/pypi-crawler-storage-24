﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.ConstantDriftMatrix
===========================

.. currentmodule:: covmats

.. autoclass:: ConstantDriftMatrix

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~ConstantDriftMatrix.mat
      
      ~ConstantDriftMatrix.beta_dim
      
      ~ConstantDriftMatrix.s_dim
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~ConstantDriftMatrix.dot
      
      ~ConstantDriftMatrix.get_gradient_dot_product
      
      ~ConstantDriftMatrix.get_values
      
   

   