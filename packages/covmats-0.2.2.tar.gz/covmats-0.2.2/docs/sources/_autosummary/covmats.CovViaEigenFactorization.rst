﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovViaEigenFactorization
================================

.. currentmodule:: covmats

.. autoclass:: CovViaEigenFactorization

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaEigenFactorization.H
      
      ~CovViaEigenFactorization.T
      
      ~CovViaEigenFactorization.covariance
      
      ~CovViaEigenFactorization.eig_vals
      
      ~CovViaEigenFactorization.eig_vects
      
      ~CovViaEigenFactorization.log_pdet
      
      ~CovViaEigenFactorization.n_pc
      
      ~CovViaEigenFactorization.n_pts
      
      ~CovViaEigenFactorization.ndim
      
      ~CovViaEigenFactorization.precision
      
      ~CovViaEigenFactorization.rank
      
      ~CovViaEigenFactorization.shape
      
      ~CovViaEigenFactorization.subspace_size
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaEigenFactorization.adjoint
      
      ~CovViaEigenFactorization.colorize
      
      ~CovViaEigenFactorization.dot
      
      ~CovViaEigenFactorization.from_cholesky
      
      ~CovViaEigenFactorization.from_diagonal
      
      ~CovViaEigenFactorization.from_eigendecomposition
      
      ~CovViaEigenFactorization.from_precision
      
      ~CovViaEigenFactorization.get_diagonal
      
      ~CovViaEigenFactorization.get_sparse_LLT_factor
      
      ~CovViaEigenFactorization.get_trace
      
      ~CovViaEigenFactorization.matmat
      
      ~CovViaEigenFactorization.matvec
      
      ~CovViaEigenFactorization.rmatmat
      
      ~CovViaEigenFactorization.rmatvec
      
      ~CovViaEigenFactorization.sample_mvnormal
      
      ~CovViaEigenFactorization.solve
      
      ~CovViaEigenFactorization.todense
      
      ~CovViaEigenFactorization.transpose
      
      ~CovViaEigenFactorization.whiten
      
   

   