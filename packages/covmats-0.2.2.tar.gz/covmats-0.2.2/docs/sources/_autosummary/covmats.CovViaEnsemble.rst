﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovViaEnsemble
======================

.. currentmodule:: covmats

.. autoclass:: CovViaEnsemble

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaEnsemble.H
      
      ~CovViaEnsemble.T
      
      ~CovViaEnsemble.anomalies
      
      ~CovViaEnsemble.covariance
      
      ~CovViaEnsemble.ensemble
      
      ~CovViaEnsemble.log_pdet
      
      ~CovViaEnsemble.n_ens
      
      ~CovViaEnsemble.n_pts
      
      ~CovViaEnsemble.ndim
      
      ~CovViaEnsemble.precision
      
      ~CovViaEnsemble.rank
      
      ~CovViaEnsemble.shape
      
      ~CovViaEnsemble.subspace_size
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaEnsemble.adjoint
      
      ~CovViaEnsemble.colorize
      
      ~CovViaEnsemble.dot
      
      ~CovViaEnsemble.from_cholesky
      
      ~CovViaEnsemble.from_diagonal
      
      ~CovViaEnsemble.from_eigendecomposition
      
      ~CovViaEnsemble.from_precision
      
      ~CovViaEnsemble.get_diagonal
      
      ~CovViaEnsemble.get_trace
      
      ~CovViaEnsemble.matmat
      
      ~CovViaEnsemble.matvec
      
      ~CovViaEnsemble.rmatmat
      
      ~CovViaEnsemble.rmatvec
      
      ~CovViaEnsemble.sample_mvnormal
      
      ~CovViaEnsemble.solve
      
      ~CovViaEnsemble.todense
      
      ~CovViaEnsemble.transpose
      
      ~CovViaEnsemble.whiten
      
   

   