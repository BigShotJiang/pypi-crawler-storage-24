﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovKernelAsLinopViaFFT
==============================

.. currentmodule:: covmats

.. autoclass:: CovKernelAsLinopViaFFT

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovKernelAsLinopViaFFT.H
      
      ~CovKernelAsLinopViaFFT.T
      
      ~CovKernelAsLinopViaFFT.count
      
      ~CovKernelAsLinopViaFFT.n_pts
      
      ~CovKernelAsLinopViaFFT.ndim
      
      ~CovKernelAsLinopViaFFT.solvematvecs
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovKernelAsLinopViaFFT.adjoint
      
      ~CovKernelAsLinopViaFFT.dot
      
      ~CovKernelAsLinopViaFFT.get_diagonal
      
      ~CovKernelAsLinopViaFFT.itercount
      
      ~CovKernelAsLinopViaFFT.matmat
      
      ~CovKernelAsLinopViaFFT.matvec
      
      ~CovKernelAsLinopViaFFT.reset_comptors
      
      ~CovKernelAsLinopViaFFT.rmatmat
      
      ~CovKernelAsLinopViaFFT.rmatvec
      
      ~CovKernelAsLinopViaFFT.solve
      
      ~CovKernelAsLinopViaFFT.todense
      
      ~CovKernelAsLinopViaFFT.transpose
      
   

   