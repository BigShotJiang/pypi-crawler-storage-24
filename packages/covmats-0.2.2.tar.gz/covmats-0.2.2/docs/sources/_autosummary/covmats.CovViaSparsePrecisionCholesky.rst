﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovViaSparsePrecisionCholesky
=====================================

.. currentmodule:: covmats

.. autoclass:: CovViaSparsePrecisionCholesky

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaSparsePrecisionCholesky.H
      
      ~CovViaSparsePrecisionCholesky.T
      
      ~CovViaSparsePrecisionCholesky.covariance
      
      ~CovViaSparsePrecisionCholesky.log_pdet
      
      ~CovViaSparsePrecisionCholesky.n_pts
      
      ~CovViaSparsePrecisionCholesky.ndim
      
      ~CovViaSparsePrecisionCholesky.precision
      
      ~CovViaSparsePrecisionCholesky.rank
      
      ~CovViaSparsePrecisionCholesky.scf
      
      ~CovViaSparsePrecisionCholesky.shape
      
      ~CovViaSparsePrecisionCholesky.subspace_size
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaSparsePrecisionCholesky.adjoint
      
      ~CovViaSparsePrecisionCholesky.colorize
      
      ~CovViaSparsePrecisionCholesky.dot
      
      ~CovViaSparsePrecisionCholesky.from_cholesky
      
      ~CovViaSparsePrecisionCholesky.from_diagonal
      
      ~CovViaSparsePrecisionCholesky.from_eigendecomposition
      
      ~CovViaSparsePrecisionCholesky.from_precision
      
      ~CovViaSparsePrecisionCholesky.get_diagonal
      
      ~CovViaSparsePrecisionCholesky.get_trace
      
      ~CovViaSparsePrecisionCholesky.matmat
      
      ~CovViaSparsePrecisionCholesky.matvec
      
      ~CovViaSparsePrecisionCholesky.rmatmat
      
      ~CovViaSparsePrecisionCholesky.rmatvec
      
      ~CovViaSparsePrecisionCholesky.sample_mvnormal
      
      ~CovViaSparsePrecisionCholesky.solve
      
      ~CovViaSparsePrecisionCholesky.todense
      
      ~CovViaSparsePrecisionCholesky.transpose
      
      ~CovViaSparsePrecisionCholesky.whiten
      
   

   