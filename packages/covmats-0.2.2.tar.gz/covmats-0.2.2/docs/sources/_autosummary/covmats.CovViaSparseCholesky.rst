﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovViaSparseCholesky
============================

.. currentmodule:: covmats

.. autoclass:: CovViaSparseCholesky

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaSparseCholesky.H
      
      ~CovViaSparseCholesky.T
      
      ~CovViaSparseCholesky.covariance
      
      ~CovViaSparseCholesky.log_pdet
      
      ~CovViaSparseCholesky.n_pts
      
      ~CovViaSparseCholesky.ndim
      
      ~CovViaSparseCholesky.precision
      
      ~CovViaSparseCholesky.rank
      
      ~CovViaSparseCholesky.scf
      
      ~CovViaSparseCholesky.shape
      
      ~CovViaSparseCholesky.subspace_size
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaSparseCholesky.adjoint
      
      ~CovViaSparseCholesky.colorize
      
      ~CovViaSparseCholesky.dot
      
      ~CovViaSparseCholesky.from_cholesky
      
      ~CovViaSparseCholesky.from_diagonal
      
      ~CovViaSparseCholesky.from_eigendecomposition
      
      ~CovViaSparseCholesky.from_precision
      
      ~CovViaSparseCholesky.get_diagonal
      
      ~CovViaSparseCholesky.get_trace
      
      ~CovViaSparseCholesky.matmat
      
      ~CovViaSparseCholesky.matvec
      
      ~CovViaSparseCholesky.rmatmat
      
      ~CovViaSparseCholesky.rmatvec
      
      ~CovViaSparseCholesky.sample_mvnormal
      
      ~CovViaSparseCholesky.solve
      
      ~CovViaSparseCholesky.todense
      
      ~CovViaSparseCholesky.transpose
      
      ~CovViaSparseCholesky.whiten
      
   

   