..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.ConstantDriftMatrix.s\_dim
==================================

.. currentmodule:: covmats

.. autoproperty:: ConstantDriftMatrix.s_dim