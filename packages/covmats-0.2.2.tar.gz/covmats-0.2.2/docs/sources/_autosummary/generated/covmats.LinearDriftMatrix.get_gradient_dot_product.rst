..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.LinearDriftMatrix.get\_gradient\_dot\_product
=====================================================

.. currentmodule:: covmats

.. automethod:: LinearDriftMatrix.get_gradient_dot_product