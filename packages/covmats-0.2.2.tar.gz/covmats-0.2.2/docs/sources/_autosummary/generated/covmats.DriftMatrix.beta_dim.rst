..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.DriftMatrix.beta\_dim
=============================

.. currentmodule:: covmats

.. autoproperty:: DriftMatrix.beta_dim