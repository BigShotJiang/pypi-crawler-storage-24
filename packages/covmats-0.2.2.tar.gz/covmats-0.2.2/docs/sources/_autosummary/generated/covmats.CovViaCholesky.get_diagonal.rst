..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.CovViaCholesky.get\_diagonal
====================================

.. currentmodule:: covmats

.. automethod:: CovViaCholesky.get_diagonal