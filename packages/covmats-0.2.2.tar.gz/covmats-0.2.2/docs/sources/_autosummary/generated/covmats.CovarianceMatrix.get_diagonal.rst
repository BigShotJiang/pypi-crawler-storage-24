..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.CovarianceMatrix.get\_diagonal
======================================

.. currentmodule:: covmats

.. automethod:: CovarianceMatrix.get_diagonal