..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.CovViaDiagonal.from\_cholesky
=====================================

.. currentmodule:: covmats

.. automethod:: CovViaDiagonal.from_cholesky