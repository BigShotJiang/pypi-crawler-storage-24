..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.LinearDriftMatrix.s\_dim
================================

.. currentmodule:: covmats

.. autoproperty:: LinearDriftMatrix.s_dim