..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.DriftMatrix.s\_dim
==========================

.. currentmodule:: covmats

.. autoproperty:: DriftMatrix.s_dim