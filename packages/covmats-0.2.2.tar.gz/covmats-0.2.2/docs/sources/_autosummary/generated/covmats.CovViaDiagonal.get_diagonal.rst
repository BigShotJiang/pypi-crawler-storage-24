..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.CovViaDiagonal.get\_diagonal
====================================

.. currentmodule:: covmats

.. automethod:: CovViaDiagonal.get_diagonal