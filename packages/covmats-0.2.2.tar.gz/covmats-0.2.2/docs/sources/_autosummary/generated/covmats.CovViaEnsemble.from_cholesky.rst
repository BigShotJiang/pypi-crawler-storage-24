..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.CovViaEnsemble.from\_cholesky
=====================================

.. currentmodule:: covmats

.. automethod:: CovViaEnsemble.from_cholesky