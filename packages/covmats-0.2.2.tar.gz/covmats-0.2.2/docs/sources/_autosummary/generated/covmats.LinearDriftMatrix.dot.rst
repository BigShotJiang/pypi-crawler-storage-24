..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.LinearDriftMatrix.dot
=============================

.. currentmodule:: covmats

.. automethod:: LinearDriftMatrix.dot