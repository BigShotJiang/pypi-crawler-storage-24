..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.DriftMatrix.get\_gradient\_dot\_product
===============================================

.. currentmodule:: covmats

.. automethod:: DriftMatrix.get_gradient_dot_product