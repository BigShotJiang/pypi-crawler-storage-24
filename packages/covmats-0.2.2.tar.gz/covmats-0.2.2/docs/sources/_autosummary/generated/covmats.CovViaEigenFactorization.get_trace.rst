..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.CovViaEigenFactorization.get\_trace
===========================================

.. currentmodule:: covmats

.. automethod:: CovViaEigenFactorization.get_trace