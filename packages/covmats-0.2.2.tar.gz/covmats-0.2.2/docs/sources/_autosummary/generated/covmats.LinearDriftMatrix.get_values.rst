..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.LinearDriftMatrix.get\_values
=====================================

.. currentmodule:: covmats

.. automethod:: LinearDriftMatrix.get_values