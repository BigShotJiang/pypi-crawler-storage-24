..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.CovViaEigenFactorization.get\_sparse\_LLT\_factor
=========================================================

.. currentmodule:: covmats

.. automethod:: CovViaEigenFactorization.get_sparse_LLT_factor