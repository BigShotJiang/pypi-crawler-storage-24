..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.CovKernelAsLinopViaFFT.reset\_comptors
==============================================

.. currentmodule:: covmats

.. automethod:: CovKernelAsLinopViaFFT.reset_comptors