..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.CovViaSparseCholesky.n\_pts
===================================

.. currentmodule:: covmats

.. autoproperty:: CovViaSparseCholesky.n_pts