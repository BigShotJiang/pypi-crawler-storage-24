﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovViaCholesky
======================

.. currentmodule:: covmats

.. autoclass:: CovViaCholesky

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaCholesky.H
      
      ~CovViaCholesky.L
      
      ~CovViaCholesky.T
      
      ~CovViaCholesky.covariance
      
      ~CovViaCholesky.log_pdet
      
      ~CovViaCholesky.n_pts
      
      ~CovViaCholesky.ndim
      
      ~CovViaCholesky.precision
      
      ~CovViaCholesky.rank
      
      ~CovViaCholesky.shape
      
      ~CovViaCholesky.subspace_size
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaCholesky.adjoint
      
      ~CovViaCholesky.colorize
      
      ~CovViaCholesky.dot
      
      ~CovViaCholesky.from_cholesky
      
      ~CovViaCholesky.from_diagonal
      
      ~CovViaCholesky.from_eigendecomposition
      
      ~CovViaCholesky.from_precision
      
      ~CovViaCholesky.get_diagonal
      
      ~CovViaCholesky.get_trace
      
      ~CovViaCholesky.matmat
      
      ~CovViaCholesky.matvec
      
      ~CovViaCholesky.rmatmat
      
      ~CovViaCholesky.rmatvec
      
      ~CovViaCholesky.sample_mvnormal
      
      ~CovViaCholesky.solve
      
      ~CovViaCholesky.todense
      
      ~CovViaCholesky.transpose
      
      ~CovViaCholesky.whiten
      
   

   