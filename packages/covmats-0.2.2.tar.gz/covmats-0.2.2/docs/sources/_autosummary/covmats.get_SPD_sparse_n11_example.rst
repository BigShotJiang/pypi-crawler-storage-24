﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

covmats.get\_SPD\_sparse\_n11\_example
======================================

.. currentmodule:: covmats

.. autofunction:: get_SPD_sparse_n11_example