﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovViaDiagonal
======================

.. currentmodule:: covmats

.. autoclass:: CovViaDiagonal

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaDiagonal.D
      
      ~CovViaDiagonal.H
      
      ~CovViaDiagonal.T
      
      ~CovViaDiagonal.covariance
      
      ~CovViaDiagonal.log_pdet
      
      ~CovViaDiagonal.n_pts
      
      ~CovViaDiagonal.ndim
      
      ~CovViaDiagonal.precision
      
      ~CovViaDiagonal.rank
      
      ~CovViaDiagonal.shape
      
      ~CovViaDiagonal.subspace_size
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovViaDiagonal.adjoint
      
      ~CovViaDiagonal.colorize
      
      ~CovViaDiagonal.dot
      
      ~CovViaDiagonal.from_cholesky
      
      ~CovViaDiagonal.from_diagonal
      
      ~CovViaDiagonal.from_eigendecomposition
      
      ~CovViaDiagonal.from_precision
      
      ~CovViaDiagonal.get_diagonal
      
      ~CovViaDiagonal.get_trace
      
      ~CovViaDiagonal.matmat
      
      ~CovViaDiagonal.matvec
      
      ~CovViaDiagonal.rmatmat
      
      ~CovViaDiagonal.rmatvec
      
      ~CovViaDiagonal.sample_mvnormal
      
      ~CovViaDiagonal.solve
      
      ~CovViaDiagonal.todense
      
      ~CovViaDiagonal.transpose
      
      ~CovViaDiagonal.whiten
      
   

   