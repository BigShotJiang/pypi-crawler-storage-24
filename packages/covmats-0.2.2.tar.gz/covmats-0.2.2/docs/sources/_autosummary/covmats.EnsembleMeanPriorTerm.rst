﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.EnsembleMeanPriorTerm
=============================

.. currentmodule:: covmats

.. autoclass:: EnsembleMeanPriorTerm

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~EnsembleMeanPriorTerm.get_gradient_dot_product
      
      ~EnsembleMeanPriorTerm.get_values
      
   

   