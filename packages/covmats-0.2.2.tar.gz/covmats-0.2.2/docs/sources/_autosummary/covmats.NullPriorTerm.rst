﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.NullPriorTerm
=====================

.. currentmodule:: covmats

.. autoclass:: NullPriorTerm

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~NullPriorTerm.get_gradient_dot_product
      
      ~NullPriorTerm.get_values
      
   

   