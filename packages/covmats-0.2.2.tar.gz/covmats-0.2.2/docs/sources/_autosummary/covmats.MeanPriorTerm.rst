﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.MeanPriorTerm
=====================

.. currentmodule:: covmats

.. autoclass:: MeanPriorTerm

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~MeanPriorTerm.get_gradient_dot_product
      
      ~MeanPriorTerm.get_values
      
   

   