﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

covmats.CovKernelAsLinop
========================

.. currentmodule:: covmats

.. autoclass:: CovKernelAsLinop

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovKernelAsLinop.count
      
      ~CovKernelAsLinop.solvematvecs
      
      ~CovKernelAsLinop.H
      
      ~CovKernelAsLinop.T
      
      ~CovKernelAsLinop.n_pts
      
      ~CovKernelAsLinop.ndim
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~CovKernelAsLinop.adjoint
      
      ~CovKernelAsLinop.dot
      
      ~CovKernelAsLinop.get_diagonal
      
      ~CovKernelAsLinop.itercount
      
      ~CovKernelAsLinop.matmat
      
      ~CovKernelAsLinop.matvec
      
      ~CovKernelAsLinop.reset_comptors
      
      ~CovKernelAsLinop.rmatmat
      
      ~CovKernelAsLinop.rmatvec
      
      ~CovKernelAsLinop.solve
      
      ~CovKernelAsLinop.todense
      
      ~CovKernelAsLinop.transpose
      
   

   