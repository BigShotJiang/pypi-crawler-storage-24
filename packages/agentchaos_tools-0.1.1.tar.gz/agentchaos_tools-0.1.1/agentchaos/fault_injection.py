"""
agentchaos — chaos testing for agentic AI workflows.

Inject faults into tool calls to test agent resilience.
"""

from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from enum import Enum


class FaultType(str, Enum):
    EXCEPTION = "exception"
    LATENCY = "latency"
    CORRUPTION = "corruption"


@dataclass
class ToolFault:
    """Defines a fault to inject into a specific tool."""
    tool_name: str
    fault_type: FaultType
    rate: float = 1.0
    latency_seconds: float = 1.0
    exception_message: str = "Simulated tool failure (agentchaos)"
    corrupt_output: str = "[CORRUPTED]"


@dataclass
class FaultEvent:
    """Records a single fault that was triggered during a run."""
    tool_name: str
    fault_type: FaultType
    triggered_at: float = field(default_factory=time.time)


class FaultInjectionHooks:
    """
    A RunHooks-compatible class that injects configurable faults
    into agent tool calls for chaos testing.

    Compatible with openai-agents-python's Runner.run(hooks=...) parameter.

    Example:
        hooks = FaultInjectionHooks(
            faults=[
                ToolFault("web_search", FaultType.EXCEPTION, rate=0.5),
                ToolFault("calculator", FaultType.LATENCY, latency_seconds=2.0),
            ],
            seed=42,
        )
        result = await Runner.run(agent, "Hello", hooks=hooks)
        hooks.report()
    """

    def __init__(self, faults: list[ToolFault], seed: int | None = None) -> None:
        self._faults: dict[str, ToolFault] = {f.tool_name: f for f in faults}
        self._rng = random.Random(seed)
        self._events: list[FaultEvent] = []

    @property
    def triggered_faults(self) -> list[FaultEvent]:
        return list(self._events)

    async def on_tool_start(self, context, agent, tool) -> None:
        fault = self._faults.get(tool.name)
        if fault is None or self._rng.random() > fault.rate:
            return

        if fault.fault_type == FaultType.LATENCY:
            self._events.append(FaultEvent(tool.name, FaultType.LATENCY))
            await asyncio.sleep(fault.latency_seconds)

        elif fault.fault_type == FaultType.EXCEPTION:
            self._events.append(FaultEvent(tool.name, FaultType.EXCEPTION))
            raise RuntimeError(fault.exception_message)

    async def on_tool_end(self, context, agent, tool, result: str) -> None:
        fault = self._faults.get(tool.name)
        if fault is None or fault.fault_type != FaultType.CORRUPTION:
            return
        if self._rng.random() > fault.rate:
            return
        self._events.append(FaultEvent(tool.name, FaultType.CORRUPTION))

    def report(self) -> str:
        if not self._events:
            summary = "No faults triggered."
            print(summary)
            return summary

        lines = [f"agentchaos report — {len(self._events)} fault(s) triggered:"]
        for i, event in enumerate(self._events, 1):
            lines.append(f"  {i}. [{event.fault_type.upper()}] tool={event.tool_name!r}")
        summary = "\n".join(lines)
        print(summary)
        return summary