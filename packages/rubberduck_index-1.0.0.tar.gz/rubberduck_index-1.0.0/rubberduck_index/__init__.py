"""RubberDuck Index — local project indexer for RubberDuck Semantic Intelligence.

Scans a local Python project, computes SHA-256 hashes, and syncs changed files
to the RubberDuck server via HTTP. The server builds code analysis models
automatically so the LLM can query them instantly.

Usage:
    rubberduck-index init
    rubberduck-index sync
    rubberduck-index watch
    rubberduck-index status
    rubberduck-index list
"""

__version__ = "1.0.0"
