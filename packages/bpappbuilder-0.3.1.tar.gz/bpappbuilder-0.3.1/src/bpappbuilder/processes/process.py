from ..tabs.table_tab import TableTab
from ..tabs.table import (Table, FormRow, FormFieldWidget, TableColumn, BeforeSaveHandler,
                          AfterSaveHandler, CreateFormHandler, TableRowChangeHandler)
from ..fields.field import (Field, LabelField, TextLineField, TextAreaField, CheckField,
                            DateTimeField, DataLabel)
from .task import TaskTab
from ..app.db import DataBase

from PySide6.QtWidgets import QTableWidget
from PySide6.QtCore import QDateTime

from typing import Union, Optional, Callable, Any
from enum import Enum, auto


class StageStatus(Enum):
    Completed = auto()  # Задача выполнена
    Started = auto()  # Задача начата, но ещё не выполнена
    NotStarted = auto()  # Задача не начата


class ProcessStage:
    """
    Базовый класс этапа процесса. Он выполняется только тогда, когда выполнены все его родительские этапы
    (connected_previous)    
    """
    
    def __init__(self, name: str, is_first: bool = False):
        """
        Args:
            name (str): Название этапа, которое будет отображаться в поле текущих этапов процесса
            is_first (bool, optional): Является ли данный этап первым в процессе. По умолчанию False
        """
        
        self.name = name
        self.is_first = is_first
        
        self.connected_previous: list[ProcessStage] = []
        self.connected_next: list[ProcessStage] = []
        self.id = 0
        self.process: Union[ProcessTab, None] = None
        self.db: Union[DataBase, None] = None

        if is_first:
            self.next_list: list[ProcessStage] = []  # Список всех следующих этапов процесса, то есть он
                                                     # Содержит все этап процесса, кроме первого
        else:
            self.first_parent: Union[ProcessStage, None] = None  # Первый этап цепочки

    def connect_one_next(self, next: "ProcessStage"):
        """
        Подключение следующего этапа, но без добавления его в список.
        Это нужно для того, чтобы в функции connect_next можно было определить
        тот список, к которому он будет добавлен
        """
        
        next.connected_previous.append(self)
        if self.is_first:
            next.first_parent = self
            self.next_list.append(next)
            next.id = len(self.next_list)
        else:
            next.first_parent = self.first_parent
            self.first_parent.next_list.append(next)
            next.id = len(self.first_parent.next_list)

    def connect_one_previous(self, previous: "ProcessStage"):
        """
        Тоже, что и connect_one_next, только оподключение предыдущих, а не следующих, этапов
        """
        self.first_parent = previous if previous.is_first else previous.first_parent
        self.first_parent.next_list.append(self)
        self.id = len(self.first_parent.next_list)
                
        previous.connected_next.append(self)
    
    def connect_next(self, next: Union["ProcessStage", list["ProcessStage"]]):
        """
        Подключение следующих этапов, то есть тех, которые будут выполнены после этого этапа
        Args:
            next (ProcessStage | list[ProcessStage]): Один этап или список подключаемых этапов
        """
        
        if isinstance(next, ProcessStage):
            next = [next]

        self.connected_next += next
        for n in next:
            self.connect_one_next(n)

    def connect_previous(self, previous: Union["ProcessStage", list["ProcessStage"]]):
        """
        Подключение предыдущих этапов, то есть тех, после которых будет выполнен данный этап
        Args:
            next (ProcessStage | list[ProcessStage]): Один этап или список подключаемых этапов
        """
        
        if isinstance(next, ProcessStage):
            previous = [previous]

        self.connected_previous += previous
        for p in previous:
            self.connect_one_previous(p)

    def run_stage(self, data: dict[str, Any], completed_stages: tuple[int]) -> tuple[StageStatus, tuple[int]]:
        """
        Запуск этапа
        Args:
            data (dict[str, Any]): Словарь с данными о процессе, взятых ил БД
            completed_stages (tuple[int]): Кортеж номеров выполненных этапов
        Returns:
            tuple: Кортеж из двух значений; tuple[status, next_stages]
                - status (StageStatus): Статус этапа после попытки запуска: выполнен,
                    начат, но не выполнен, или не начат
                - next_steges (tuple[int]): Кортеж номеров этапов, которые должны буду выполнены после этого
        """
        
        if {prev.id for prev in self.connected_previous}.issubset(completed_stages):
            return StageStatus.Completed, tuple(next.id for next in self.connected_next)
        else:
            return StageStatus.NotStarted, ()


CreateTaskStageFn = Callable[[dict[str, Any], dict[str, Any]], None]

class TaskProcessStage(ProcessStage):
    """
    Этап процесса, который создаёт задачу (добавляет её запись в БД).
    Запускается, когда выполнены все родительские процессы, а выполняется, когда пользователь
    нажимает кнопку "Пометить выполненой" в форме задачи
    """
    
    def __init__(self, stage_name: str, task_name: str, task_tab: TaskTab, executor: Optional[str] = None,
                 create_task: Optional[CreateTaskStageFn] = None, columns_data: Optional[dict[str, str]] = None,
                 is_first: bool = False):
        """
        Args:
            stage_name (str): Название этапа, отображаемое в процессе
            task_name (str): Название процесса, отображаемое в таблице процессов
            task_tab (TaskTab): Вкладка таблицы с задачами
            executor (str, optional): Исполнитель задачи в формате column:data, где
                - column: SQL-название колонки таблицы
                - data: Строка, которой должно быть равно содержимое колонки column
                То есть исполнителем считается тот, у кого содержимое column соответствует data
            create_task ((process_data, stage_data) -> None, optional): Функция, обрабатывающая  данные,
                которые будут потом записаны в таблицу задач
                - process_data (dict[str, Any]): Словарь данных процесса, взятых из БД
                - stage_data (dict[str, Any]): Сгенерированные данные задачи, которые будут записаны в БД
            columns_data (dict[str, Any]): Словарь, содержимое которого будет добавлено к данным задачи
        """
        
        super().__init__(stage_name, is_first)

        self.task_name = task_name
        self.task_tab = task_tab
        self.executor = executor
        self.create_task = create_task
        self.columns_data = columns_data

    def run_stage(self, process_data: dict[str, Any], completed_stages: tuple[int]) -> tuple[StageStatus, tuple[int]]:
        """
        Выполнение этого этапа заключается в том, что создаётся запись задачи в БД, этап помечается
        как начатый, он становится выполняемым этапом (что отображается в таблице процесса).
        Когда пользователь делает задачу выполненной, выполнение цепочки этапов продолжается
        """
        
        if not {prev.id for prev in self.connected_previous}.issubset(completed_stages):
            return StageStatus.NotStarted, ()
                
        stage_data = {"name": self.task_name, "completed": 0, "process_table": process_data["_table"],
                      "stage": process_data["_table"] + ":" + str(process_data["id"]) + ":" + str(self.id),
                      "date_start": QDateTime.currentDateTime().toString(DateTimeField.datetime_format)}
        if self.task_tab.auth_table is not None:
            stage_data["executor"] = self.executor

        if self.columns_data is not None:
            stage_data.update(self.columns_data)
        if self.create_task is not None:
            self.create_task(process_data, stage_data)
        
        # stage_data["name"] = self.task_name
        # stage_data["completed"] = 0  # False
        # stage_data["process_table"] = process_data["_table"]
        # stage_data["stage"] = process_data["_table"] + ":" + str(process_data["id"]) + ":" + str(self.id)
        # if self.task_tab.auth_table is not None:
        #     stage_data["executor"] = self.executor
        # stage_data["date_start"] = QDateTime.currentDateTime().toString(DateTimeField.datetime_format)

        self.task_tab.db.cur.execute(f"INSERT INTO {self.task_tab.sql_name} \
                                    ({','.join(self.task_tab.fields.keys())}) \
                                    VALUES ({','.join('?'*len(self.task_tab.fields))})",
                                    tuple(stage_data[field] for field in self.task_tab.fields.keys()))
        self.task_tab.db.conn.commit()

        return StageStatus.Started, ()


ConditionStageFn = Callable[[dict[str, Any], DataBase], bool]

class ConditionProcessStage(ProcessStage):
    """
    Этап, после которого выполнение может пойти по одному из двух путей, в зависимвости от того,
    выполнится условие этапа или нет. То есть если условие истино, выполнятся одни этапы, если ложно,
    то другие
    """
    
    def __init__(self, condition: ConditionStageFn, is_first: bool = False):
        """
        Args:
            condition ((process_data, db) -> result): Функция, проверяющая условие этапа в зависимости от
                данных процесса
                - process_data (dict[str, Any]): Словарь данных процесса, взятых из БД
                - db (DataBase): База данных
            ``
        """
        
        super().__init__("", is_first)
        self.condition_fn = condition
        self.connected_next_true: list[ProcessStage] = []
        self.connected_next_false: list[ProcessStage] = []

    def connect_next(self, next: Union[ProcessStage, list[ProcessStage]], condition: bool):
        """
        Подключение следующих этапов к разным ветвям выполнения
        Args:
            condition (bool): Если True, этапы будут подключены к ветке, выполняемой при истинном уловии,
                если False, то к ветки, выполняемой при ложном условии этапа
        """
        
        if isinstance(next, ProcessStage):
            next = [next]

        self.connected_next += next
        if condition:
            self.connected_next_true += next
        else:
            self.connected_next_false += next

        for n in next:
            self.connect_one_next(n)

    def run_stage(self, process_data: dict[str, Any], completed_stages: tuple[int]) -> tuple[StageStatus, tuple[int]]:
        if not {prev.id for prev in self.connected_previous}.issubset(completed_stages):
            return StageStatus.NotStarted, ()

        result = self.condition_fn(process_data, self.db)
        if result:
            return StageStatus.Completed, tuple(next.id for next in self.connected_next_true)
        else:
            return StageStatus.Completed, tuple(next.id for next in self.connected_next_false)


class OrProcessStage(ProcessStage):
    """
    Обычный ничего не делющий этап. Только он выполняется не когда ВСЕ родительские этапы выполнены,
    а когда ХОТЯ БЫ ОДИН из них выполнен.
    """
    
    def run_stage(self, data: dict[str, Any], completed_stages: tuple[int]) -> tuple[StageStatus, tuple[int]]:
        if len({prev.id for prev in self.connected_previous}.intersection(completed_stages)) >= 1:
            return StageStatus.Completed, tuple(next.id for next in self.connected_next)
        else:
            return StageStatus.NotStarted, ()


class CurrentProcessStepField(Field):
    """
    Поле списка текущих выполняемых этапов процесса
    - Таблица: DataLabel
    - Форма: DataLabel
    - - Получить данные виджета: widget.field_data
    """
    
    sql_type = "TEXT"

    def __init__(self, name: str, sql_name: str, first_stage: Optional[ProcessStage] = None,
                 tooltip: Optional[str] = None, column_width: Optional[int] = None,
                 primary_key: bool = False, unique: bool = False, not_null: bool = False,
                 default: Optional[int] = None):
        """
        Args:
            first_stage (ProcessStage, optional): Первый этап процесса
        """

        super().__init__(name, sql_name, tooltip, column_width, True, primary_key, unique, False,
                         not_null, str(default), None, False)

        self.first_stage = first_stage
        if first_stage is None:
            self.stages: Union[list[ProcessStage], None] = None

    def get_stages_names(self, data: str) -> str:
        """
        Создаёт строку, которая будут отображена в таблице или ворме по данным из БД
        Args:
            data (str): Перечеслинные через точку с запятой данные о выполненных этапах. Формат данных
                об одном этапе - stage_id:next_stege_id1,next_stage_id2,... где stage_id - id выполненного
                этапа, а next_stage_id - номера этапов, которые должны вполниться после него
        """
        
        return "; ".join(self.stages[int(stage_data.split(":")[0])].name for stage_data in data.split(";"))
        
    def create_for_form(self, data: Optional[str]) -> DataLabel:
        if data is None:
            return DataLabel(self.first_stage.name, "0")
        elif len(data) == 0:
            return DataLabel("", data)
        else:
            return DataLabel(self.get_stages_names(data), data)

    def create_for_table(self, data: str) -> DataLabel:
        if len(data) == 0:
            return DataLabel("", data)
        else:
            return DataLabel(self.get_stages_names(data), data)

    def change_widget_data(self, widget: DataLabel, data: str):
        widget.field_data = data
        if len(data) == 0:
            widget.setText("")
        else:
            return DataLabel(self.get_stages_names(data), data)

    def get_widget_data(self, widget: DataLabel, form: bool) -> str:
        return widget.field_data

    def check_widget(self, widget: DataLabel, form: bool) -> tuple[bool, str]:
        return True, ""

    def fetch_data_from_db(self, parent_table_sql_name: str):
        """
        Когда все этапы созданы и соединены друг с другом, они записываются в переменную self.stages
        """
        
        if self.stages is None:
            self.stages = [self.first_stage] + self.first_stage.next_list


class ProcessTable(Table):
    """
    Класс таблицы, отличающийся от родительского тем, что при добавлении записи в БД также запускается
    первый этап
    """
    
    def __init__(self, name: str, sql_name: str, fields: dict[str, Any], process,
                 db: DataBase, additional_columns: Optional[dict[str, TableColumn]] = None,
                 before_save_handler: Optional[BeforeSaveHandler] = None,
                 after_save_handler: Optional[AfterSaveHandler] = None,
                 create_form_handler: Optional[CreateFormHandler] = None,
                 table_row_change_handler: Optional[TableRowChangeHandler] = None,
                 system_invisible_fields: Optional[list[str]] = None, request_end: str = ""):
        super().__init__(name, sql_name, fields, db, additional_columns, before_save_handler,
                         after_save_handler, create_form_handler, table_row_change_handler,
                         system_invisible_fields, request_end)
        self.process = process

    def add_data(self, form_data_widgets: dict[str, FormFieldWidget], tables: list[QTableWidget], no_db: bool = False,
                 additional_system_data: Optional[dict[str, str]] = None) -> dict[str, str]:
        data = super().add_data(form_data_widgets, tables, no_db, additional_system_data)
        
        if data is not None:
            self.process.next_stage(int(data["id"]), 0, run=True)
        
        return data


class ProcessTab(TableTab):
    """
    Вкладка таблицы бизнес-процессов. От обычной вкладки таблицы она отличается только некоторыми
    дополнительными обязательнями полями, добавляемыми автоматически: состояние процесса
    выполнен/не выполнен (completed), список текущих этапов (current_stages) и невидимое
    поле выполненных этапов (completed_stages).

    Процесс состоит из цепочки этапов, выполняемых друг за другом.
    """
    
    def __init__(self, name: str, sql_name: str, description: str = "",
                 first_stage: Optional[ProcessStage] = None,
                 hide_form: bool = False, form_under_table: bool = False,
                 additional_columns: Optional[list[TableColumn]] = None, unique: list[list[str]] = None,
                 before_save_handler: Optional[BeforeSaveHandler] = None,
                 after_save_handler: Optional[AfterSaveHandler] = None,
                 create_form_handler: Optional[CreateFormHandler] = None,
                 table_row_change_handler: Optional[TableRowChangeHandler] = None):
        """
        Args:
            first_stage (ProcessStage, optional): Первый этап процесса, с которого начинается его выоплнение.
            Первый этап должен быть создан с аргументом is_first равным True. Можно указать с помощью
            функции set_first_stage
        """

        super().__init__(name, sql_name, description, hide_form, form_under_table, additional_columns,
                         unique, before_save_handler, after_save_handler, create_form_handler,
                         table_row_change_handler)

        self.system_invisible_fields = ["completed_stages TEXT DEFAULT ''"]
        # completed_stages: Перечеслинные через точку с запятой уже выполненные этапы

        self.add_field(CheckField("Выполнено", "completed", default=False, column_width=75, const=True))
        self.add_field(CurrentProcessStepField("Текущие этапы", "current_stages", first_stage, default="0"))
        # current_stages: Перечеслинные через точку с запятой данные о выполненных этапах. Формат данных
        # об одном этапе - stage_id:next_stege_id1,next_stage_id2,... где stage_id - id выполненного этапа,
        # а next_stage_id - номера этапов, которые должны вполниться после него

        if first_stage is None:
            self.first_stage = first_stage
            self.stages: list[ProcessStage] = []
        else:
            self.set_first_stage(first_stage)

    def set_first_stage(self, first_stage: ProcessStage):
        """
        Указывает первый этап
        """
        
        self.first_stage = first_stage
        self.stages = [first_stage] + first_stage.next_list
        self.fields["current_stages"].first_stage = first_stage

        for stage in self.stages:
            stage.process = self

        # for stage in [first_stage] + first_stage.next_list:
        #     print(stage.name)
        #     print("\tid:", stage.id)
        #     print("\tprevious:", *[s.id for s in stage.connected_previous])
        #     print("\tnext:", *[s.id for s in stage.connected_next])

    def run_stages(self, stages: list[int], completed_stages: dict[int, tuple[int]], current_stages: set[int],
                   process_data: dict[str, Any]):
        """
        Поочерёдно выполняет указанные этапы со всеми их следующими этапами
        Args:
            stages (list[int]): Список номеров этапов, которые недо выполнить
            completed_stages (dict[int, tuple(int)]): Словарь уже выполненных этапов, где ключи - их номера,
                а значения - кортежи из номеров этапов, выполняемых за ними
            current_stages (set[int]): Набор номеров выполняемых в данный момент этапов
            process_data: (dict[str, Any]): Словарь данных о процессе, взятых напрямую из БД
        """
        
        if len(stages) == 0:
            return
        
        for stage_id in stages:
            if stage_id in completed_stages:
                continue

            cs = tuple(x[0] for x in completed_stages.items() if stage_id in x[1])
            # cs - выполненные этапы, от которых зависит текущий обрабатываемый этап
            
            status, next_list = self.stages[stage_id].run_stage(process_data, cs)
            
            if status == StageStatus.Completed:
                completed_stages[stage_id] = next_list
                self.run_stages(next_list, completed_stages, current_stages, process_data)
            elif status == StageStatus.Started:
                current_stages.add(stage_id)
            elif status == StageStatus.NotStarted:
                pass
    
    def next_stage(self, process_id: int, stage_id: int, run: bool = False):
        """
        Запуск определённого этапа определённого процесса со всеми его следующими этапами и сохранение
        результатов в БД

        Args:
            process_id (int): ID запускаемого процесса
            stage_id (int): Номер запускаемого этапа (под номером имеется ввиду номер процесса в цепочке)
            run (bool, optional): Если True, этап будет запущен, иначе он просто сразу будет помечен
                выполненным. По умолчанию False
        """
        
        process_data = self.db.cur.execute(f"SELECT * FROM {self.sql_name} WHERE id = ?", (process_id,)).fetchone()

        process_data_dict = {}
        for key in process_data.keys():
            process_data_dict[key] = process_data[key]
        process_data_dict["_table"] = self.sql_name

        if len(process_data["completed_stages"]) > 0:
            # completed_stages = set(int(x) for x in process_data["completed_stages"].split(","))
            completed_stages = {int(x.split(":")[0]):tuple(int(y) for y in x.split(":")[1].split(",")) for x in process_data["completed_stages"].split(";")}
        else:
            completed_stages = dict()
        current_stages = set(int(x) for x in process_data["current_stages"].split(";"))

        if run:
            self.run_stages([stage_id], completed_stages, current_stages, process_data_dict)
        else:
            completed_stages[stage_id] = tuple(stage.id for stage in self.stages[stage_id].connected_next)
            current_stages.remove(stage_id)

            self.run_stages([stage.id for stage in self.stages[stage_id].connected_next], completed_stages, current_stages, process_data_dict)

        completed = False
        for strge_id in completed_stages:
            if len(self.stages[stage_id].connected_next) == 0:
                completed = True
                break

        self.db.cur.execute(f"UPDATE {self.sql_name} SET current_stages = ?, completed_stages = ?, completed = ? \
                            WHERE id = ?",
                            (
                                ";".join(str(x) for x in current_stages),
                                ";".join(str(x[0]) + (":" if len(x[1]) > 0 else "") + ",".join(str(y) for y in x[1]) for x in completed_stages.items()),
                                int(completed),
                                process_id
                            ))
        self.db.conn.commit()

    def app_add_tab(self, app):
        """
        Обычный вызов app_add_tab, но с подменой простого Table на специальный ProcessTable.
        Также этапам указывается БД
        """
        
        super().app_add_tab(app)

        self.table = ProcessTable(self.name, self.sql_name, self.fields, self, self.db,
                                 self.additional_columns, self.before_save_handler, self.after_save_handler,
                                 self.create_form_handler, self.table_row_change_handler, self.system_invisible_fields,
                                 "" if self.unique is None else ",\n".join(map(lambda x: f"\tUNIQUE ({', '.join(x)})", self.unique)))

        for stage in self.stages:
            stage.db = app.db
