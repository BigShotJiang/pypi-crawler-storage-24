from ..tabs.table_tab import TableTab
from ..tabs.table import (Table, FormRow, FormFieldWidget, TableColumn, BeforeSaveHandler,
                          AfterSaveHandler, CreateFormHandler, TableRowChangeHandler,
                          RowDataDialog)
from ..fields.field import (Field, LabelField, TextLineField, TextAreaField, CheckField,
                            DateTimeField, DataLabel, DataWidget)
from ..app.app import App
from ..app.db import DataBase

from PySide6.QtWidgets import (QWidget, QComboBox, QHBoxLayout, QCheckBox, QLabel, QPushButton,
                               QLineEdit)
from PySide6.QtCore import Qt

from typing import Union, Sequence, Any, Optional


class ExecutorDataWidget(QWidget):
    def __init__(self, column: str, data: str, text: Any = None):
        super().__init__()
        self.column = column
        self.data = data
        self.field_data = column + ":" + data
        self.text = text

class ExecutorField(Field):
    """
    Поле исполнителя задачи
    - Таблица: ExecutorDataWidget
    - Форма: ExecutorDataWidget
    - - Получить данные виджета: widget.field_data
    """
    
    sql_type = "TEXT"
    
    def __init__(self, name: str, sql_name: str, auth_table: TableTab, tooltip: Optional[str] = None,
                 column_width: Optional[int] = None):
        super().__init__(name, sql_name, tooltip, column_width)
        self.auth_table = auth_table
    
    def create_for_form(self, data: str) -> ExecutorDataWidget:
        # format - "column:data"
        
        column = data.split(":", maxsplit=1)[0]
        ex_name = data.split(":", maxsplit=1)[1]

        widget = ExecutorDataWidget(column, ex_name)
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)

        prefix = self.auth_table.name + ": " + self.auth_table.fields[column].name + ":"
        w = self.auth_table.fields[column].create_for_table(ex_name)
        layout.addWidget(QLabel(prefix))
        layout.addWidget(w)
        layout.addStretch()

        widget.text = prefix + self.auth_table.fields[column].get_widget_text(w)
        widget.setLayout(layout)
        return widget

    def create_for_table(self, data: str) -> ExecutorDataWidget:
        return self.create_for_form(data)
        
    def change_widget_data(self, widget: ExecutorDataWidget, data: str):
        pass

    def get_widget_data(self, widget: ExecutorDataWidget, form: bool) -> str:
        return widget.field_data

    def get_widget_text(self, widget: ExecutorDataWidget) -> str:
        return widget.text
    
    def check_widget(self, widget: ExecutorDataWidget, form: bool) -> tuple[bool, str]:
        return True, ""

class TaskProcessNameField(Field):
    """
    Поле названия процесса, к которому относится задача
    - Таблица: DataLabel
    - Форма: DataLabel
    - - Получить данные виджета: widget.field_data
    """
    
    sql_type = "TEXT"
    
    def __init__(self, name: str, sql_name: str, tooltip: Optional[str] = None,
                 column_width: Optional[int] = None):
        super().__init__(name, sql_name, tooltip, column_width)
        self.app: App
    
    def get_table_name(self, table_sql_name: str) -> Union[str, None]:
        for table_tab in self.app.tabs:
            if isinstance(table_tab, TableTab) and table_tab.sql_name == table_sql_name:
                return table_tab.name
        return None
    
    def create_for_form(self, data: str) -> DataLabel:
        table_name = self.get_table_name(data)
        return DataLabel(table_name if table_name is not None else "", data)
    
    def create_for_table(self, data: str) -> DataLabel:
        table_name = self.get_table_name(data)
        return DataLabel(table_name if table_name is not None else "", data)
    
    def change_widget_data(self, widget: DataLabel, data: str):
        table_name = self.get_table_name(data)
        widget.setText(table_name if table_name is not None else "")
        widget.field_data = data

    def get_widget_data(self, widget: DataLabel, form: bool) -> Union[str, None]:
        return widget.field_data

    def check_widget(self, widget: DataLabel, form: bool) -> tuple[bool, str]:
        return True, ""

class TaskStageNameField(Field):
    """
    Поле названия этапа, который создаёт эту задачу
    - Таблица: DataLabel
    - Форма: DataLabel
    - - Получить данные виджета: widget.field_data
    """
    
    sql_type = "TEXT"

    def __init__(self, name: str, sql_name: str, tooltip: Optional[str] = None,
                 column_width: Optional[int] = None):
        super().__init__(name, sql_name, tooltip, column_width)
        self.app: App

    def get_stage_name(self, table_sql_name: str, stage_id: int) -> Union[str, None]:
        for table_tab in self.app.tabs:
            if isinstance(table_tab, TableTab) and table_tab.sql_name == table_sql_name:
                return table_tab.stages[stage_id].name
        return None

    def create_for_form(self, data: str) -> DataLabel:
        # format - process_table_name:process_id:stage_id
        
        task_name = self.get_stage_name(data.split(":")[0], int(data.split(":")[2]))
        return DataLabel(task_name if task_name is not None else "", data)

    def create_for_table(self, data: str) -> DataLabel:
        task_name = self.get_stage_name(data.split(":")[0], int(data.split(":")[2]))
        return DataLabel(task_name if task_name is not None else "", data)

    def change_widget_data(self, widget: DataLabel, data: str):
        task_name = self.get_stage_name(data.split(":")[0], int(data.split(":")[2]))
        widget.setText(task_name if task_name is not None else "")
        widget.field_data = data

    def get_widget_data(self, widget: DataLabel, form: bool) -> Union[str, None]:
        return widget.field_data

    def check_widget(self, widget: DataLabel, form: bool) -> tuple[bool, str]:
        return True, ""


class TaskRowDataDialog(RowDataDialog):
    """
    Форма для просмотри и измененияд данных определённой строки таблицы задач, но с добавлением кнопки
    "Пометить выполненой и сохранить"
    """
    
    def __init__(self, data: Sequence[Any], fields: dict[str, Any], table_name: str, table_sql_name: str,
                 before_save_handler: Optional[BeforeSaveHandler],
                 create_form_handler: Optional[CreateFormHandler], db: DataBase, app, hidden_id: bool = False):
        super().__init__(data, fields, table_name, table_sql_name, before_save_handler, create_form_handler,
                         db, app, hidden_id)
        self.table_sql_name = table_sql_name

        complete_button = QPushButton("Пометить выполненой и сохранить")
        complete_button.clicked.connect(lambda: self.mark_completed(data))

        self.form_layout.addWidget(complete_button)

    def mark_completed(self, data: Sequence[Any]):
        c: QCheckBox = self.form_widgets["completed"].field_widget
        c.setChecked(True)

        # self.db.cur.execute(f"UPDATE {self.table_sql_name} SET completed = 1 WHERE id = ?", (int(data["id"]),))
        # self.db.conn.commit()

        for tab in self.app.tabs:
            if isinstance(tab, TableTab) and tab.sql_name == data["process_table"]:
                process_id = int(data["stage"].split(":")[1])
                stage_id = int(data["stage"].split(":")[2])
                tab.next_stage(process_id, stage_id)
                self.check_and_accept()


class TaskTab(TableTab):
    """
    Вкладка таблицы с задачами, подключенными к некоторым бизнес-процессам. Они создаются автоматически,
    когда выполнение процесса доходит до этапа-задачи. Такой этап считается пройденым, когда пользователь
    укажет задачу выполненой
    """
    
    def __init__(self, name: str, sql_name: str, auth_table: Optional[TableTab] = None, description: str = "",
                 additional_columns: Optional[list[TableColumn]] = None, unique: list[list[str]] = None,
                 before_save_handler: Optional[BeforeSaveHandler] = None,
                 after_save_handler: Optional[AfterSaveHandler] = None,
                 table_row_change_handler: Optional[TableRowChangeHandler] = None):
        """
        Args:
            auth_table (TableTab, optional): Таблица, используемая для авторизации
        """
        
        super().__init__(name, sql_name, description, True, False,
                         additional_columns, unique, before_save_handler, after_save_handler,
                         None, table_row_change_handler)

        self.auth_table = auth_table
        
        self.add_field(TextAreaField("Название", "name", column_width=200))
        self.add_field(CheckField("Выполнено", "completed", default=False, const=True, column_width=75))
        self.add_field(TaskProcessNameField("Бизнес-процесс", "process_table"))
        self.add_field(TaskStageNameField("Этап", "stage"))  # format - table_name:process_id:stage_id
        if auth_table is not None:
            self.add_field(ExecutorField("Исполнитель", "executor", auth_table, column_width=200))
        self.add_field(DateTimeField("Дата начала", "date_start", only_current=True, column_width=100))

    def create_tab_widget(self) -> QWidget:
        """
        К обычной строке поиска добавляется галочка "Только мои задачи" для фильтрации строк
        """
        
        widget = super().create_tab_widget()

        if self.auth_table is not None:
            search_line: QHBoxLayout = widget.findChild(QWidget).layout()

            check = QCheckBox()
            check.stateChanged.connect(lambda _, t=self.tables_count-1, c=check: self.search_in_table(t, c.parent().findChild(QLineEdit)))
        
            search_line.insertWidget(2, QLabel("Только мои задачи:"))
            search_line.insertWidget(3, check)

        return widget

    def search_in_table(self, table_id: int, search_line: QLineEdit):
        """
        Поиск и по строке, и по фильтру "Только мои задачи"
        """
        
        check_state = search_line.parent().findChild(QCheckBox).checkState()
        search_text = search_line.text().strip().lower()
        
        if check_state == Qt.CheckState.Checked and self.app.auth_id is not None and self.auth_table is not None:
            user_data = self.db.cur.execute(f"SELECT * FROM {self.auth_table.sql_name} WHERE id = ?",
                                            (self.app.auth_id,)).fetchone()
            column = list(self.fields.keys()).index("executor") + 1

        for row in range(self.tables_widgets[table_id].rowCount()):
            if check_state == Qt.CheckState.Unchecked or self.app.auth_id is None or self.auth_table is None:
                only_my_show = True
            elif check_state == Qt.CheckState.Checked:
                cell: ExecutorDataWidget = self.tables_widgets[table_id].cellWidget(row, column)
                only_my_show = str(user_data[cell.column]) == str(cell.data)

            if search_text == "":
                search_show = True
            else:
                search_show = False
                for column, field in enumerate(self.fields.values()):
                    if search_text in str(field.get_widget_text(self.tables_widgets[table_id].cellWidget(row, column+1))).lower():
                        search_show = True
                        break

            self.tables_widgets[table_id].setRowHidden(row, not (only_my_show and search_show))

    def app_add_tab(self, app):
        super().app_add_tab(app)
        self.table.row_data_dialog = TaskRowDataDialog  # Замена формы просмотра данных строки
