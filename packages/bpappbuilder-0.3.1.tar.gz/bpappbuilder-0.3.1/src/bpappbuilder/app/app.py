from PySide6.QtWidgets import (QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QLabel,
                               QDialog, QDialogButtonBox, QFormLayout, QLineEdit, QComboBox)
from PySide6.QtGui import QIcon

from ..tabs.tab import Tab
from ..tabs.table_tab import TableTab
from ..tabs.group import TabGroup
from ..tabs.table_tab import CreateFormHandler
from .db import DataBase
from .themes import apply_styles
from ..fields.field import Field

from typing import Optional, Union
from dataclasses import dataclass
import logging
import sys
import os


logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s %(module)s %(funcName)s: %(lineno)d - %(levelname)s - %(message)s",
                    datefmt='%H:%M:%S')


@dataclass
class AuthData:
    """
    Данные об авторизации в приложении
    """
    
    table: TableTab  # Таблица с пользователями
    main_field: str  # Поле, которое пользователь заполняет в форме для авторизации
    displayed_fields: Optional[list[str]] = None  # Дополнительные поля (кроме главного), отображаемые в форме
    text_main_field: bool = False  # Если True, главное поле будет текстовым, а не полем выбора

class AuthDialog(QDialog):
    def __init__(self, auth: AuthData, parent: QWidget, db: DataBase):
        self.auth = auth
        self.db = db
        self.selected_id: Optional[int] = None
        
        super().__init__(parent=parent)
        self.setWindowTitle("Авторизация")
        
        apply_styles(self)

        buttonBox = QDialogButtonBox(QDialogButtonBox.StandardButton.Apply)
        buttonBox.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.accept)
        
        layout = QVBoxLayout()
        self.setLayout(layout)

        label = QLabel("<b>Авторизация</b>")
        label.setProperty("class", "rowdatadialog-label")
        layout.addWidget(label)
        
        form = QWidget()
        form_layout = QFormLayout()
        form.setLayout(form_layout)

        main_field = auth.table.fields[auth.main_field]
        if auth.text_main_field:
            self.main_field_widget = QLineEdit()
            self.main_field_widget.returnPressed.connect(self.main_field_update)
        else:
            data = db.cur.execute(f"SELECT {main_field.sql_name} FROM {auth.table.sql_name}").fetchall()
            data = [row[main_field.sql_name] for row in data]
            self.main_field_widget = QComboBox()
            self.main_field_widget.addItems(data)
            self.main_field_widget.setCurrentIndex(-1)
            self.main_field_widget.currentTextChanged.connect(lambda _: self.main_field_update())
            # for row in data:
            #     self.main_field_widget.addItem(row[main_field.sql_name], int(row['id']))
        form_layout.addRow(main_field.name, self.main_field_widget)

        self.fields = {}
        for field_name in auth.displayed_fields:
            field_widget = QLabel()
            self.fields[field_name] = field_widget
            form_layout.addRow(auth.table.fields[field_name].name, field_widget)
        
        layout.addWidget(form)
        layout.addStretch()
        layout.addWidget(buttonBox)

    def main_field_update(self):
        if self.auth.text_main_field:
            main_field_text = self.main_field_widget.text()
        else:
            main_field_text = self.main_field_widget.currentText()

        data = self.db.cur.execute(f"SELECT id, {', '.join(self.auth.displayed_fields)} \
                                     FROM {self.auth.table.sql_name} \
                                     WHERE {self.auth.main_field} = ?", (main_field_text,)).fetchone()
        for field_name, field in self.fields.items():
            field.setText(str(data[field_name]))
        self.selected_id = int(data["id"])
        

class App:
    """
    Класс приложения с таблицами
    """

    def __init__(self, name: str, db: DataBase, window_width: int, window_height: int,
                 auth: Optional[AuthData] = None, icon_path: Optional[str] = None):
        """
        Args:
            name (str): Отображаемое название приложения
            db (DataBase): Объект базы данных
            window_width (int): Начальная ширина окна приложения в пикселях
            window_height (int): Начальная ширина окна приложения в пикселях
            auth (AuthData, optional): Данные для авторизации
            icon_path (str, optional): Путь к файлу изображения, который будет использоваться как иконка приложения
        """

        self.tabs: list[Tab] = []
        self.groups: list[TabGroup] = []
        self.icon_path = icon_path

        self.db = db
        self.name = name
        self.window_width = window_width
        self.window_height = window_height
        self.auth = auth

        self.auth_id: Union[int, None] = None

    def set_auth(self, auth: AuthData):
        self.auth = auth
    
    def add_tab(self, tab: Tab):
        """
        Добавление вкладки в приложение

        Args:
            tab (Tab): Объект вкладки
        """

        tab.app_add_tab(self)
        
        self.tabs.append(tab)

    def add_group(self, group: TabGroup):
        """
        Добавление группы вкладок в приложение.
        После добавления хотя бы одной группы, добавленные вне групп вкладки отображаться не будут.
        Args:
            group (TabGroup): Объект группы вкладок
        """
        
        for tab in group.tabs:
            tab.app_add_tab(self)
        
        self.groups.append(group)

    def run(self):
        """
        Запуск приложения
        """

        # Создание базы данных
        if len(self.groups) > 0:  # Если есть группы, то используем только вкладки из них
            self.tabs = []
            for group in self.groups:
                self.tabs.extend(group.tabs)

        # Создание объекта приложения
        app = QApplication(sys.argv)

        # Создание главного окна
        window_widget = QMainWindow()
        window_widget.setWindowTitle(self.name)
        if self.icon_path is not None:
            window_widget.setWindowIcon(QIcon(self.icon_path))
        window_widget.resize(self.window_width, self.window_height)

        container = QWidget()
        container.setProperty("class", "main-container")
        container_layout = QVBoxLayout()
        container_layout.setContentsMargins(0, 0, 0, 0)
        container.setLayout(container_layout)

        apply_styles(window_widget)
        QApplication.instance().paletteChanged.connect(lambda: apply_styles(window_widget))

        if len(self.groups) > 0:
            groups_tab_widget = QTabWidget()
            groups_tab_widget.setProperty("class", "groups-tab")

            tab_bar = groups_tab_widget.tabBar()
            tab_bar.setProperty("class", "groups-tab-bar")

            for group in self.groups:
                tabs_tab_widget = QTabWidget()
                for tab in group.tabs:
                    tabs_tab_widget.addTab(tab.create_tab_widget(), tab.name)
                tabs_tab_widget.setCurrentIndex(0)

                groups_tab_widget.addTab(tabs_tab_widget, group.name)
            
            groups_tab_widget.setCurrentIndex(0)
            container_layout.addWidget(groups_tab_widget)
        else:
            tabs_widget = QTabWidget()

            for tab in self.tabs:
                tabs_widget.addTab(tab.create_tab_widget(), tab.name)
            
            tabs_widget.setCurrentIndex(0)
            container_layout.addWidget(tabs_widget)
        
        window_widget.setCentralWidget(container)

        window_widget.show()

        if self.auth is not None:
            dialog = AuthDialog(self.auth, window_widget, self.db)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                self.auth_id = dialog.selected_id
        
        app.exec()
        self.db.close()
