"""Typing definitions for context, channels and features."""

from typing import Any, Generic, Literal, Mapping, TypeAlias, TypeVar, TypedDict

ContextType: TypeAlias = Mapping[str, Any]
ChannelType: TypeAlias = Mapping[str, Any]
FeatureType: TypeAlias = Mapping[str, Any]

T = TypeVar("T", bound=ChannelType)


class TimestreamPublishEnvelope(TypedDict, Generic[T]):
    """Typed envelope for timestream messages."""

    type: Literal["TIMESTREAM"]
    data: T


class AudioPublishEnvelope(TypedDict, Generic[T]):
    """Typed envelope for audio messages."""

    type: Literal["AUDIO"]
    data: T


PublishEnvelope: TypeAlias = TimestreamPublishEnvelope[T] | AudioPublishEnvelope[T]
