"""
Traewelling Pydantic Models

Based on the traewelling data export format (2026-03-09) and the traewelling API
"""

import enum
from datetime import datetime
from typing import Optional
from uuid import UUID

import pydantic


class TraewellingModel(pydantic.BaseModel):
    model_config = pydantic.ConfigDict(extra="ignore")


class LightUser(TraewellingModel):
    id: int
    uuid: UUID
    displayName: str
    username: str
    profilePicture: str
    preventIndex: bool
    mastodon: Optional[dict] = None


class ProfileLink(TraewellingModel):
    name: str
    url: str


class User(TraewellingModel):
    id: int
    uuid: UUID
    displayName: str
    username: str
    profilePicture: str
    preventIndex: bool
    totalDistance: int
    totalDuration: int
    points: int
    mastodonUrl: Optional[str] = None
    privateProfile: bool
    points_enabled: bool
    likes_enabled: bool
    pointsEnabled: bool
    userInvisibleToMe: bool
    muted: bool
    blocked: bool
    following: bool
    followPending: bool
    followedBy: bool
    bio: str
    profileLinks: list[ProfileLink] = []


class Area(TraewellingModel):
    name: str
    default: bool
    adminLevel: int


class StationIdentifier(TraewellingModel):
    type: str
    identifier: str


class Station(TraewellingModel):
    id: int
    name: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    areas: list[Area] = []
    identifiers: list[StationIdentifier] = []
    rilIdentifier: Optional[str] = pydantic.Field(default=None, deprecated=True)
    ibnr: Optional[int] = pydantic.Field(default=None, deprecated=True)


class Stopover(TraewellingModel):
    id: int
    rilIdentifier: Optional[str] = pydantic.Field(default=None, deprecated=True)
    ibnr: Optional[int] = pydantic.Field(
        default=None, alias="evaIdentifier", deprecated=True
    )
    name: str

    arrivalPlanned: Optional[datetime] = None
    arrivalReal: Optional[datetime] = pydantic.Field(default=None, alias="arrival")
    arrivalPlatformPlanned: Optional[str] = None
    arrivalPlatformReal: Optional[str] = None

    departurePlanned: Optional[datetime] = None
    departureReal: Optional[datetime] = pydantic.Field(default=None, alias="departure")
    departurePlatformPlanned: Optional[str] = None
    departurePlatformReal: Optional[str] = None

    platform: Optional[str] = None

    isArrivalDelayed: bool
    isDepartureDelayed: bool
    cancelled: bool


class Operator(TraewellingModel):
    id: int
    identifier: Optional[str] = None
    name: str


class Category(str, enum.Enum):
    nationalExpress = "nationalExpress"
    national = "national"
    regionalExp = "regionalExp"
    regional = "regional"
    suburban = "suburban"
    bus = "bus"
    ferry = "ferry"
    subway = "subway"
    tram = "tram"
    taxi = "taxi"
    plane = "plane"


class Mode(str, enum.Enum):
    walk = "WALK"
    bike = "BIKE"
    rental = "RENTAL"
    car = "CAR"
    carParking = "CAR_PARKING"
    carDropoff = "CAR_DROPOFF"
    odm = "ODM"
    rideSharing = "RIDE_SHARING"
    flex = "FLEX"
    transit = "TRANSIT"
    tram = "TRAM"
    subway = "SUBWAY"
    ferry = "FERRY"
    airplane = "AIRPLANE"
    suburban = "SUBURBAN"
    bus = "BUS"
    coach = "COACH"
    rail = "RAIL"
    highspeedRail = "HIGHSPEED_RAIL"
    longDistance = "LONG_DISTANCE"
    nightRail = "NIGHT_RAIL"
    regionalFastRail = "REGIONAL_FAST_RAIL"
    regionalRail = "REGIONAL_RAIL"
    cableCar = "CABLE_CAR"
    funicular = "FUNICULAR"
    aerialLift = "AERIAL_LIFT"
    other = "OTHER"
    aeralLift = "AERAL_LIFT"
    metro = "METRO"


class DataSource(TraewellingModel):
    id: str
    attribution: str


class Transport(TraewellingModel):
    trip: int
    hafasId: str
    category: Category
    mode: Optional[Mode] = None
    number: str
    lineName: str
    routeColor: Optional[str] = None
    routeTextColor: Optional[str] = None
    journeyNumber: Optional[int] = None
    manualJourneyNumber: Optional[str] = None
    distance: int
    points: int
    duration: int
    manualDeparture: Optional[datetime] = None
    manualArrival: Optional[datetime] = None
    origin: Stopover
    destination: Stopover
    operator: Optional[Operator] = None
    dataSource: Optional[DataSource]


class Trip(TraewellingModel):
    id: int
    category: Category
    mode: Optional[Mode] = None
    number: str
    lineName: str
    journeyNumber: Optional[int] = None
    origin: Station
    destination: Station
    stopovers: list[Stopover]
    dataSource: Optional[DataSource]


class Mention(TraewellingModel):
    user: Optional[LightUser] = None
    position: int
    length: int


class Business(enum.IntEnum):
    private = 0
    business = 1
    commute = 2


class Visibility(enum.IntEnum):
    public = 0
    unlisted = 1
    followers = 2
    private = 3
    authenticated = 4
    trusted = 5


class Client(TraewellingModel):
    id: int
    name: str
    privacyPolicyUrl: str


class Event(TraewellingModel):
    id: int
    name: str
    slug: str
    hashtag: Optional[str] = None
    host: Optional[str] = None
    url: Optional[str] = None
    begin: datetime
    end: datetime
    station: Optional[Station] = None
    isPride: bool


class Tag(TraewellingModel):
    key: str
    value: str
    visibility: int


class Status(TraewellingModel):
    id: int
    body: str
    bodyMentions: list[Mention]
    business: Business
    visibility: Visibility
    likes: int
    liked: bool
    isLikable: bool
    client: Optional[Client] = None
    checkin: Transport
    event: Optional[Event] = None
    user: LightUser
    createdBy: Optional[LightUser] = None
    tags: list[Tag]
    createdAt: datetime


class Checkin(TraewellingModel):
    status: Status
    trip: Trip
