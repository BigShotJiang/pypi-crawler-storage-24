# Traewelling-Pydantic

A simple package which provides some Traewelling API models as Pydantic models.
