from typing import (
    IO,
    Any,
    AsyncIterable,
    AsyncIterator,
    Generic,
    Iterable,
    Iterator,
    Literal,
    NamedTuple,
    Sequence,
    TypeVar,
    cast,
)
from uuid import UUID

from pydantic import BaseModel, Field

T = TypeVar("T")


class Page(BaseModel, Generic[T]):
    items: Sequence[T]
    total: int
    page: int = Field(ge=1)
    size: int = Field(ge=1)


__all__ = [
    "Any",
    "AsyncIterator",
    "AsyncIterable",
    "BaseModel",
    "cast",
    "Field",
    "IO",
    "Iterable",
    "Iterator",
    "Literal",
    "NamedTuple",
    "Page",
    "Sequence",
    "UUID",
]
