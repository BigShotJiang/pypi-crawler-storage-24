import json
from typing import IO, Any, Iterator, TypeVar

import httpx
from pydantic import BaseModel, TypeAdapter

from .. import errors

_ReturnModelT = TypeVar("_ReturnModelT")


class RawIteratorIO(IO[bytes]):
    """
    Creates a IO[bytes] from a bytes iterator.

    Adapted from https://stackoverflow.com/a/12604375/7426717
    """

    def __init__(self, it: Iterator[bytes]) -> None:
        self._it = it
        self._memory = b""

        super().__init__()

    def _read1(self, n: int | None = None) -> bytes:
        while not self._memory:
            try:
                next_memory = next(self._it)
            except StopIteration:
                break
            else:
                self._memory = next_memory

        chunk = self._memory[:n]
        self._memory = self._memory[len(chunk) :]

        return chunk

    def read(self, n: int | None = None) -> bytes:
        chunks: list[bytes] = []
        if n is None or n < 0:
            while True:
                m = self._read1()
                if not m:
                    break
                chunks.append(m)
        else:
            while n > 0:
                m = self._read1(n)
                if not m:
                    break
                n -= len(m)
                chunks.append(m)
        return b"".join(chunks)


CHUNK_SIZE = 1024


class BaseClient:
    name: str
    path: str
    _sync_client: httpx.Client
    _async_client: httpx.AsyncClient

    def __init__(
        self, sync_client: httpx.Client, async_client: httpx.AsyncClient, path: str
    ) -> None:
        self._sync_client = sync_client
        self._async_client = async_client
        if path.startswith("/"):
            path = path[1:]
        self.name = path.split("/")[-1]
        self.path = f"/{path}"

    def request(
        self,
        method: str,
        *,
        endpoint: str,
        params: None | BaseModel | dict[str, Any] = None,
        data: None | BaseModel | dict[str, Any] = None,
        files: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        page: int | None = None,
        size: int | None = None,
        params_model: type[BaseModel] | None = None,
        body_model: type[BaseModel] | None = None,
        return_model: type[_ReturnModelT] | None = None,
        stream: bool = False,
        timeout: (
            httpx._types.TimeoutTypes | httpx._client.UseClientDefault
        ) = httpx.USE_CLIENT_DEFAULT,
    ) -> _ReturnModelT | IO[bytes] | None:
        req = self._get_validated_request(
            method=method,
            endpoint=endpoint,
            params=params,
            data=data,
            files=files,
            params_model=params_model,
            body_model=body_model,
            headers=headers,
            page=page,
            size=size,
            timeout=timeout,
        )
        response = self._sync_client.send(req, stream=stream)
        self._raise_and_handle_errors(response)
        content = None
        if (
            response.headers.get("content-type") == "application/json"
            and response.status_code != 204
        ):
            content = response.json()
        if return_model is not None:
            return self._convert_response_to_model(content, return_model)
        return RawIteratorIO(response.iter_bytes(chunk_size=CHUNK_SIZE))

    async def request_async(
        self,
        method: str,
        *,
        endpoint: str,
        params: None | BaseModel | dict[str, Any] = None,
        data: None | BaseModel | dict[str, Any] = None,
        files: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        page: int | None = None,
        size: int | None = None,
        params_model: type[BaseModel] | None = None,
        body_model: type[BaseModel] | None = None,
        return_model: type[_ReturnModelT] | None = None,
        stream: bool = False,
        timeout: (
            httpx._types.TimeoutTypes | httpx._client.UseClientDefault
        ) = httpx.USE_CLIENT_DEFAULT,
    ) -> _ReturnModelT | IO[bytes] | None:
        req = self._get_validated_request(
            method=method,
            endpoint=endpoint,
            params=params,
            data=data,
            files=files,
            params_model=params_model,
            body_model=body_model,
            headers=headers,
            page=page,
            size=size,
            timeout=timeout,
        )
        response = await self._async_client.send(req, stream=stream)
        self._raise_and_handle_errors(response)
        content = None
        if (
            response.headers.get("content-type") == "application/json"
            and response.status_code != 204
        ):
            content = response.json()
        if return_model is not None:
            return self._convert_response_to_model(content, return_model)
        return RawIteratorIO(response.iter_bytes(CHUNK_SIZE))

    def _get_validated_request(
        self,
        *,
        method: str,
        endpoint: str,
        params: None | BaseModel | dict[str, Any] = None,
        data: None | BaseModel | dict[str, Any] = None,
        files: dict[str, Any] | None = None,
        params_model: type[BaseModel] | None = None,
        body_model: type[BaseModel] | None = None,
        headers: dict[str, str] | None = None,
        page: int | None = None,
        size: int | None = None,
        timeout: (
            httpx._types.TimeoutTypes | httpx._client.UseClientDefault
        ) = httpx.USE_CLIENT_DEFAULT,
    ) -> httpx.Request:
        url = self.path
        if endpoint:
            if endpoint.startswith("/"):
                url = endpoint
            else:
                url = f"{self.path}/{endpoint}"
        local_params: dict[str, Any] = {}
        if page is not None:
            local_params["page"] = page
        if size is not None:
            local_params["size"] = size
        if params is not None:
            if isinstance(params, dict):
                params.update(local_params)
                if params_model is not None:
                    # if params_model is passed, use Pydantic to validate params
                    params = params_model(**params)
                    params = params.model_dump()
            elif isinstance(params, BaseModel):
                params = params.model_dump(exclude_none=True, exclude_defaults=True)
                params.update(local_params)
        content = None
        if data is not None:
            if isinstance(data, dict):
                if body_model is not None:
                    body = body_model(**data)
                    content = body.model_dump_json()
                else:
                    content = json.dumps(data)
            elif isinstance(data, BaseModel):
                content = data.model_dump_json()
        req = self._sync_client.build_request(
            method,
            url,
            headers=headers,
            params=params,
            content=content,
            files=files,
            timeout=timeout,
        )
        return req

    def _raise_and_handle_errors(self, response: httpx.Response) -> None:
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as e:
            status = e.response.status_code
            error_type: str | None = None
            sdk_error: type[errors.BrokerError] | None = None
            detail_message: str | None = None
            try:
                error_data = e.response.json()
            except json.JSONDecodeError:
                error_data = {}
            detail = error_data.get("detail")
            if detail and isinstance(detail, dict):
                error_type = detail.get("type")
                detail_message = detail.get("message", json.dumps(detail))
            else:
                detail_message = json.dumps(error_data)
            if error_type:
                sdk_error = getattr(errors, error_type, None)
            if sdk_error:
                raise sdk_error(detail=detail_message or "") from e
            elif status == 401:
                raise errors.AuthError(detail=detail_message or "") from e
            else:
                raise

    def _convert_response_to_model(
        self, data: Any, return_model: type[_ReturnModelT]
    ) -> _ReturnModelT | None:
        """Convert the JSON response to the correct Pydantic model"""
        if data is None:
            return data
        return TypeAdapter(return_model).validate_python(data)
