from typing import IO, cast

import httpx

from ..models import (
    Copying,
    CopyPlan,
    Deleting,
    Downloading,
    FileStats,
    Listing,
    PathList,
    RsyncPlan,
    SignedUrl,
    Statting,
)
from .base import BaseClient


class Files(BaseClient):
    def get_signed_url(self, *, path: str, method: str) -> SignedUrl:
        res = self.request(
            "POST",
            endpoint="signed-url",
            return_model=SignedUrl,
            data={"path": path, "method": method},
        )
        return cast(SignedUrl, res)

    async def get_signed_url_async(self, *, path: str, method: str) -> SignedUrl:
        res = await self.request_async(
            "POST",
            endpoint="signed-url",
            return_model=SignedUrl,
            data={"path": path, "method": method},
        )
        return cast(SignedUrl, res)

    def upload(
        self, file: IO[bytes], *, dest: str, overwrite: bool, make_dirs: bool
    ) -> None:
        self.request(
            "POST",
            endpoint="upload",
            files={"file": file},
            params={"dest": dest, "overwrite": overwrite, "make_dirs": make_dirs},
            return_model=SignedUrl,
            timeout=httpx.Timeout(5.0, read=300.0, write=300.0),
        )

    async def upload_async(
        self, file: IO[bytes], *, dest: str, overwrite: bool, make_dirs: bool
    ) -> None:
        await self.request_async(
            "POST",
            endpoint="upload",
            files={"file": file},
            params={"dest": dest, "overwrite": overwrite, "make_dirs": make_dirs},
            return_model=None,
            timeout=httpx.Timeout(5.0, read=300.0, write=300.0),
        )

    def copy(self, body: Copying) -> None:
        self.request("POST", endpoint="copy", data=body, return_model=None)

    async def copy_async(self, body: Copying) -> None:
        await self.request_async("POST", endpoint="copy", data=body, return_model=None)

    def delete(self, body: Deleting) -> None:
        self.request("POST", endpoint="delete", data=body, return_model=None)

    async def delete_async(self, body: Deleting) -> None:
        await self.request_async(
            "POST", endpoint="delete", data=body, return_model=None
        )

    def stat(self, body: Statting) -> FileStats:
        res = self.request("POST", endpoint="stat", data=body, return_model=FileStats)
        return cast(FileStats, res)

    async def stat_async(self, body: Statting) -> FileStats:
        res = await self.request_async(
            "POST", endpoint="stat", data=body, return_model=FileStats
        )
        return cast(FileStats, res)

    def list_dir(self, body: Listing) -> PathList:
        res = self.request(
            "POST",
            endpoint="list-dir",
            data=body,
            return_model=PathList,
            timeout=httpx.Timeout(5.0, read=20.0),
        )
        return cast(PathList, res)

    async def list_dir_async(self, body: Listing) -> PathList:
        res = await self.request_async(
            "POST",
            endpoint="list-dir",
            data=body,
            return_model=PathList,
            timeout=httpx.Timeout(5.0, read=20.0),
        )
        return cast(PathList, res)

    def plan_directory_copy(self, body: Copying) -> CopyPlan:
        res = self.request(
            "POST", endpoint="plan-directory-copy", data=body, return_model=CopyPlan
        )
        return cast(CopyPlan, res)

    async def plan_directory_copy_async(self, body: Copying) -> CopyPlan:
        res = await self.request_async(
            "POST", endpoint="plan-directory-copy", data=body, return_model=CopyPlan
        )
        return cast(CopyPlan, res)

    def plan_directory_rsync(self, body: Copying) -> RsyncPlan:
        res = self.request(
            "POST", endpoint="plan-directory-rsync", data=body, return_model=RsyncPlan
        )
        return cast(RsyncPlan, res)

    async def plan_directory_rsync_async(self, body: Copying) -> RsyncPlan:
        res = await self.request_async(
            "POST", endpoint="plan-directory-rsync", data=body, return_model=RsyncPlan
        )
        return cast(RsyncPlan, res)

    def download(self, body: Downloading) -> IO[bytes]:
        res = self.request("POST", endpoint="download", data=body, stream=True)
        return cast(IO[bytes], res)

    async def download_async(self, body: Downloading) -> IO[bytes]:
        res = await self.request_async(
            "POST", endpoint="download", data=body, stream=True
        )
        return cast(IO[bytes], res)
