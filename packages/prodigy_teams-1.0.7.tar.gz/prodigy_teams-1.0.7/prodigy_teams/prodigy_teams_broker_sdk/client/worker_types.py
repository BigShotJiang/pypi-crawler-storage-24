from __future__ import annotations

from typing import cast

from ..models import WorkerType
from .base import BaseClient


class WorkerTypes(BaseClient):
    def list(self) -> list[WorkerType]:
        res = self.request("GET", endpoint="", return_model=list[WorkerType])
        return cast(list[WorkerType], res)

    async def list_async(self) -> list[WorkerType]:
        res = await self.request_async(
            "GET", endpoint="", return_model=list[WorkerType]
        )
        return cast(list[WorkerType], res)
