from typing import cast

from ..models import Secret, SecretResponse
from .base import BaseClient


class SecretClient(BaseClient):
    def create(self, secret: Secret) -> bool:
        res = self.request("POST", endpoint="create", data=secret)
        return cast(bool, res)

    async def create_async(self, secret: Secret) -> bool:
        res = await self.request_async("POST", endpoint="create", data=secret)
        return cast(bool, res)

    def read(self, key: str) -> list[SecretResponse]:
        res = self.request(
            "POST",
            endpoint="read",
            data={"key": key},
            return_model=list[SecretResponse],
        )
        return cast(list[SecretResponse], res)

    async def read_async(self, key: str) -> list[SecretResponse]:
        res = await self.request_async(
            "POST",
            endpoint="read",
            data={"key": key},
            return_model=list[SecretResponse],
        )
        return cast(list[SecretResponse], res)

    def delete(self, key: str) -> bool:
        res = self.request("POST", endpoint="delete", data={"key": key})
        return cast(bool, res)

    async def delete_async(self, key: str) -> bool:
        res = await self.request_async("POST", endpoint="delete", data={"key": key})
        return cast(bool, res)
