from typing import Any


class BrokerError(Exception):
    message: str | None
    detail: str | None
    status: int | None

    def __init__(
        self,
        message: str | None = None,
        detail: str | None = None,
        status: int | None = None,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self.message = message
        self.detail = detail
        self.status = status
        self.args = args
        self.kwargs = kwargs

    def __str__(self) -> str:
        output = ""
        if self.message:
            output = self.message
        if self.detail:
            output += f"\n{self.detail}" if output else self.detail
        return output


class NotFound(BrokerError):
    pass


class Exists(BrokerError):
    pass


class ClientError(BrokerError):
    pass


class PT_MaintenanceMode(BrokerError):
    pass


class DatasetCreateFailed(BrokerError):
    pass


class DatasetExists(BrokerError):
    pass


class DatasetNotFound(BrokerError):
    pass


class PT_Package_Exists(BrokerError):
    pass


class PT_Package_NotFound(BrokerError):
    pass


class PackageNotWheel(BrokerError):
    pass


class EnvNotFound(BrokerError):
    pass


class JobMetaNotFound(BrokerError):
    pass


class FileError(BrokerError):
    pass


class RmPathNotFoundError(FileError):
    pass


class RmPathIsADirectoryError(FileError):
    pass


class SecretCreateFailed(BrokerError):
    pass


class SecretExists(BrokerError):
    pass


class SecretNotFound(BrokerError):
    pass


class AuthError(BrokerError):
    def __init__(self, detail: str = "Auth Error") -> None:
        self.status = 401
        self.detail = detail

    def __str__(self) -> str:
        return self.detail or ""
