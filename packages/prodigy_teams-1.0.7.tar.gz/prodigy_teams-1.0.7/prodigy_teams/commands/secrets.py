import builtins
from collections.abc import Sequence
from getpass import getpass
from typing import Optional, Union
from uuid import UUID

from radicli import Arg
from wasabi import msg

from ..cli import cli
from ..errors import CLIError, HTTPXErrors, ProdigyTeamsErrors
from ..messages import Messages
from ..prodigy_teams_broker_sdk.errors import AuthError as BrokerAuthError
from ..prodigy_teams_broker_sdk.errors import BrokerError
from ..prodigy_teams_broker_sdk.models import Secret
from ..prodigy_teams_pam_sdk.models import SecretDetail, SecretSummary
from ..query import resolve_secret
from ..ui import (
    isatty,
    print_info_table,
    print_mutation_result,
    print_table_with_select,
)
from ._state import get_auth_state


@cli.subcommand(
    "secrets",
    "list",
    # fmt: off
    select=Arg("--select", help=Messages.select.format(opts=builtins.list(SecretSummary.model_fields))),
    as_json=Arg("--json", help=Messages.as_json),
    # fmt: on
)
def list(
    select: builtins.list[str] = ["created", "id", "name", "path"],
    as_json: bool = False,
) -> Sequence[SecretSummary]:
    """List all named pointers to secrets on the cluster"""
    client = get_auth_state().client
    res = client.secret.all()
    print_table_with_select(res.items, select=select, as_json=as_json)
    return res.items


@cli.subcommand(
    "secrets",
    "info",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="secret")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="secret")),
    select=Arg(
        "--select",
        help=Messages.select.format(opts=builtins.list(SecretDetail.model_fields)),
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def info(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[UUID] = None,
    select: Optional[builtins.list[str]] = None,
    as_json: bool = False,
) -> SecretDetail:
    """Show info about a secret on the cluster"""
    res = resolve_secret(name_or_id, broker_id=cluster_id)
    print_info_table(res, as_json=as_json, select=select)
    return res


@cli.subcommand_with_extra(
    "secrets",
    "create",
    name=Arg(help=Messages.name.format(noun="secret")),
    secrets_path=Arg("--secrets-path", help=Messages.secrets_path),
    exists_ok=Arg("--exists-ok", help=Messages.exists_ok),
    as_json=Arg("--json", help=Messages.as_json),
)
def create(
    name: str,
    _extra: builtins.list[str],
    secrets_path: str = "/",
    exists_ok: bool = False,
    as_json: bool = False,
) -> UUID | None:
    """Create a named pointer to a secret on the cluster"""
    auth = get_auth_state()
    client = auth.client
    broker_client = auth.broker_client
    broker_id = auth.broker_id

    import sys

    secret_dict = {}
    for arg in _extra:
        if "=" not in arg:
            raise CLIError(Messages.E056)
        else:
            key, value = arg.split("=", 1)
            if value == "-":
                if not isatty(sys.stdin):
                    raise CLIError(
                        "Cannot prompt for secret in non-interactive mode",
                        "Provide values as KEY=VALUE arguments",
                    )
                editor_value = getpass(f"Enter secret value for {key}: ")
                secret_dict[key] = editor_value
            else:
                secret_dict[key] = value
    if not secret_dict:
        # No KEY=VALUE pairs provided — prompt for a single value using
        # the secret name as the environment-variable key.
        if not isatty(sys.stdin):
            raise CLIError(
                "Cannot prompt for secret in non-interactive mode",
                "Provide values as KEY=VALUE arguments",
            )
        value = getpass(f"Enter secret value for {name}: ")
        secret_dict[name] = value

    key_prefix = secrets_path.strip("/")
    key = name
    if key_prefix:
        key = f"{key_prefix}/{name}"
    broker_secret = Secret(key=key, value=secret_dict)
    try:
        broker_client.secrets.create(broker_secret)
    except BrokerAuthError:
        raise CLIError(
            Messages.E039.format(
                message="Could not store secret on cluster: authentication failed"
            ),
            "Try re-authenticating with `ptc login`",
        )
    except (BrokerError, *HTTPXErrors) as e:
        raise CLIError(Messages.E003.format(noun="secret", name=name), str(e))

    try:
        res = client.secret.create(name=name, path=secrets_path, broker_id=broker_id)
    except ProdigyTeamsErrors.SecretExists:
        if exists_ok:
            msg.info(Messages.T001.format(noun="secret", name=name))
            return None
        raise CLIError(Messages.E002.format(noun="secret", name=name))
    except ProdigyTeamsErrors.SecretInvalid:
        raise CLIError(Messages.E004.format(noun="secret", name=name))
    except ProdigyTeamsErrors.SecretForbiddenCreate:
        raise CLIError(Messages.E003.format(noun="secret", name=name))
    print_mutation_result(
        {"id": str(res.id), "name": res.name},
        Messages.T002.format(noun="secret", name=res.name),
        as_json=as_json,
    )
    if not as_json:
        print_info_table(res)
    return res.id


@cli.subcommand(
    "secrets",
    "delete",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="secret")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="secret")),
    as_json=Arg("--json", help=Messages.as_json),
)
def delete(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[UUID] = None,
    as_json: bool = False,
) -> UUID:
    """Delete a secret by name or ID"""

    auth = get_auth_state()
    client = auth.client
    broker_client = auth.broker_client
    cluster_id = cluster_id or auth.broker_id

    pam_secret = resolve_secret(name_or_id, broker_id=cluster_id)
    key_prefix = pam_secret.path.strip("/")
    key = f"{key_prefix}/{pam_secret.name}" if key_prefix else pam_secret.name
    try:
        broker_client.secrets.delete(key=key)
    except BrokerAuthError:
        raise CLIError(
            Messages.E039.format(
                message="Could not delete secret from cluster: authentication failed"
            ),
            "Try re-authenticating with `ptc login`",
        )
    except (BrokerError, *HTTPXErrors) as e:
        raise CLIError(Messages.E006.format(noun="secret", name=name_or_id), str(e))

    try:
        client.secret.delete(id=pam_secret.id)
    except (
        ProdigyTeamsErrors.SecretForbiddenDelete,
        ProdigyTeamsErrors.SecretNotFound,
    ):
        raise CLIError(Messages.E006.format(noun="secret", name=name_or_id))
    else:
        print_mutation_result(
            {"id": str(pam_secret.id), "deleted": True},
            Messages.T003.format(noun="secret", name=name_or_id),
            as_json=as_json,
        )
    return pam_secret.id
