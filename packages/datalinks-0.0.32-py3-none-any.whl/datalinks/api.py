import datetime
import json
import logging
import os
import time
from dataclasses import dataclass
from typing import List, Dict, Any, Optional, Type, TypeAlias, Tuple, Iterator

import requests
from requests import Request, Response, Session, RequestException
import dotenv

from datalinks.pipeline import Pipeline
from datalinks.links import MatchTypeConfig

_logger = logging.getLogger(__name__)

CONNECT_TIMEOUT = 30  # seconds
READ_TIMEOUT = 600  # seconds
MAX_INGEST_ATTEMPTS = 3


@dataclass
class DLConfig:
    """
    DLConfig class is a configuration container for managing the required settings
    to interact with DataLinks. It loads configuration values from environment
    variables to provide flexibility across different environments.

    This class is designed to simplify the initialization and storage of connection
    and namespace details required to communicate with DataLinks.

    :ivar host: The host URL for the data layer connection.
    :type host: str
    :ivar apikey: The API key for authentication with the data layer.
    :type apikey: str
    :ivar index: The index name to be used in the data layer operations.
    :type index: str
    :ivar namespace: The namespace for organizing data in the data layer.
    :type namespace: str
    :ivar objectname: The name of the object associated with the configuration.
                      Defaults to an empty string.
    :type objectname: str
    """
    host: str
    apikey: str
    index: str
    namespace: str
    objectname: str

    @classmethod
    def from_env(cls: Type["DLConfig"], load_dotenv: bool = True):
        if load_dotenv: dotenv.load_dotenv()
        return cls(
            host=os.getenv("HOST", "host-notset"),
            apikey=os.getenv("DL_API_KEY", "api-key-notset"),
            index=os.getenv("INDEX", "index-notset"),
            namespace=os.getenv("NAMESPACE", "namespace-notset"),
            objectname=os.getenv("OBJECT_NAME", ""),
        )


Dataset: TypeAlias = List[Dict[str, Any]]


@dataclass
class AskEvent:
    """
    Represents a single SSE event from the /query/ask streaming endpoint.

    :ivar type: Event type — one of ``plan``, ``step``, ``answer``, or ``error``.
    :type type: str
    :ivar data: Parsed JSON payload for the event.
    :type data: Dict[str, Any]
    """
    type: str
    data: Dict[str, Any]


@dataclass
class IngestionResult:
    """
    Represents the result of a data ingestion process into DataLinks.

    This class is a data structure used to store the results of a data ingestion
    operation. It separates the successfully ingested items from the failed ones,
    enabling users to track and handle both cases effectively.

    :ivar successful: A list of records successfully ingested. Each record is
        represented as a dictionary.
    :type successful: Dataset
    :ivar failed: A list of records that failed ingestion. Each record is
        represented as a dictionary.
    :type failed: Dataset
    """
    successful: Dataset
    failed: Dataset


class DataLinksRequestError(Exception):
    def __init__(self, endpoint: str, e: RequestException):
        self.status_code = getattr(e.response, 'status_code', None)
        self.content = getattr(e.response, 'content', None)

        _logger.error(
            "Request to %s failed with status %s: %s",
            endpoint,
            self.status_code if self.status_code is not None else "N/A",
            self.content
        )
        super().__init__(f"Request to {endpoint} failed with status {self.status_code}: {self.content}")


class DataLinksAPI:
    """
    Class for interfacing with the DataLinks API.

    Provides methods for ingesting data, managing namespaces, and querying data
    from DataLinks. Designed to interact with a configurable
    backend, providing flexibility for deployment environments.

    :ivar config: Configuration object containing API key, host, index, namespace,
        and object name.
    :type config: Optional[DLConfig]
    """

    def __init__(self, config: Optional[DLConfig] = None):
        self.config: DLConfig = config if config else DLConfig.from_env()

    @property
    def __headers(self) -> dict:
        return {"Authorization": f"Bearer {self.config.apikey}"}

    @property
    def __ingest_url(self) -> str:
        return f"{self.config.host}/ingest/{self.config.namespace}/{self.config.objectname}"

    @property
    def __create_url(self) -> str:
        return f"{self.config.host}/ingest/new/{self.config.namespace}/{self.config.objectname}"

    @property
    def __data_url(self) -> str:
        return f"{self.config.host}/data/self/{self.config.namespace}/{self.config.objectname}"

    @property
    def __query_url(self) -> str:
        return f"{self.config.host}/query"

    @property
    def __ask_url(self) -> str:
        return f"{self.config.host}/query/ask"

    @property
    def __datasets_url(self) -> str:
        return f"{self.config.host}/data"

    @property
    def __multipart_url(self) -> str:
        return f"{self.config.host}/upload/multipart/self/{self.config.namespace}/{self.config.objectname}"

    @property
    def __links_url(self) -> str:
        return f"{self.config.host}/links/self/{self.config.namespace}/{self.config.objectname}"

    @property
    def __links_add_url(self) -> str:
        return f"{self.config.host}/links/add"

    @property
    def __infer_description_url(self) -> str:
        return f"{self.config.host}/infer/description"

    @property
    def __sort_order_url(self) -> str:
        return f"{self.config.host}/schema/self/{self.config.namespace}/{self.config.objectname}/sort-order"

    def __post_request(self, payload: str | Dict[str, Any], endpoint: str,
                       content_type: Optional[str] = None) -> Response:
        s = Session()
        headers = {**self.__headers}
        if content_type:
            headers["Content-Type"] = content_type
        if isinstance(payload, dict):
            req = Request('POST', url=endpoint, json=payload, headers=headers)
        else:
            req = Request('POST', url=endpoint, data=payload, headers=headers)

        prepped = req.prepare()
        if _logger.getEffectiveLevel() == logging.DEBUG:
            tag = datetime.datetime.today().strftime("%Y%m%d_%H%M%S")
            with open(f"request_debug_{tag}.json", "wt") as f:
                json.dump({
                    "method": prepped.method,
                    "url": prepped.url,
                    "headers": dict(prepped.headers),
                    "body": prepped.body.decode() if isinstance(prepped.body, bytes) else prepped.body
                }, f, indent=2)

        try:
            response = s.send(prepped, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            raise DataLinksRequestError(endpoint, e)

    def __put_request(self, payload: Dict[str, Any], endpoint: str) -> Response:
        try:
            response = requests.put(
                endpoint,
                json=payload,
                timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                headers=self.__headers
            )
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            raise DataLinksRequestError(endpoint, e)

    def __delete_request(self, endpoint: str) -> Response:
        try:
            response = requests.delete(
                endpoint,
                timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                headers=self.__headers
            )
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            raise DataLinksRequestError(endpoint, e)

    def __get_request(self, endpoint: str) -> Response:
        try:
            response = requests.get(
                endpoint,
                timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                headers=self.__headers
            )
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            raise DataLinksRequestError(endpoint, e)

    def ingest(self, data: Dataset,
               inference_steps: Pipeline | None = None,
               entity_resolution: MatchTypeConfig | None = None,
               batch_size=0,
               max_attempts=MAX_INGEST_ATTEMPTS) -> IngestionResult:
        """
        Ingests data into the namespace by batching the given data and performing multiple retries
        in case of failures. This function sends data in chunks (batches), to be processed through configured
        inference steps, and to resolve entities based on the provided configuration. If a batch fails, it
        is retried up to a maximum number of attempts.

        :param data: List of dictionaries, where each dictionary represents a data block to be ingested.
        :param inference_steps: Pipeline of inference steps to be applied for processing the data. If `None` the data will be ingested as is.
        :param entity_resolution: Configuration specifying how entity resolution is to be performed.
        :param batch_size: Number of data blocks to be included in each batch. Defaults to the size of the
            entire dataset if not provided.
        :param max_attempts: Maximum number of retry attempts for failed batches. Defaults to the
            provided constant MAX_INGEST_ATTEMPTS.
        :return: An IngestionResult object containing lists of successfully ingested data blocks and
            data blocks that failed to be ingested.
        """
        start = time.perf_counter()

        if not batch_size:
            batch_size = len(data)
        _logger.info(f"Sending {len(data)} data blocks to ingestion endpoint (batch size {batch_size})")

        retry_data: Dataset = []
        successful_batches = []

        for attempt in range(max_attempts):
            _logger.debug(f"Attempt {attempt + 1} of {max_attempts}")
            retry_data = []

            for start_idx in range(0, len(data), batch_size):
                batch = data[start_idx:start_idx + batch_size]
                payload: dict[str, Any] = {
                    "data": batch
                }
                if inference_steps is not None:
                    payload["infer"] = {"steps": inference_steps.to_list()}
                if entity_resolution is not None:
                    payload["link"] = entity_resolution.config

                try:
                    response = self.__post_request(payload, self.__ingest_url)
                    if response.status_code == 200:
                        successful_batches.extend(batch)
                    else:
                        _logger.error(f"Batch failed with status {response.status_code}. "
                                      f"{response.content.decode()}")
                        retry_data.extend(batch)
                except DataLinksRequestError:
                    retry_data.extend(batch)

            if retry_data:
                data = retry_data
            else:
                break

        end = time.perf_counter()
        _logger.info(f"Ingestion took {end - start:.2f} seconds.")
        return IngestionResult(
            successful=successful_batches,
            failed=retry_data
        )

    def create_space(self, is_private: bool = True,
                     data_description: Optional[str] = "",
                     field_definitions: Optional[str] = "") -> None:
        """
        Creates a new space with the specified privacy settings. This function sends a
        POST request to create a namespace with the given privacy status. Information
        about the namespace creation will be logged, including the HTTP status code
        and response reason. If the namespace already exists, a warning will be logged.

        :param is_private: Determines whether the created namespace will be private
            or public.
        :type is_private: bool
        :return: None
        :raises HTTPError: If the HTTP request fails due to connectivity issues or
            server-side problems.
        """
        payload = {
            "inferDefinition": {
                "dataDescription": data_description,
                "fieldDefinition": field_definitions
            },
            "visibility": "Private" if is_private else "Public"
        }

        try:
            response = self.__post_request(payload, self.__create_url)

            _logger.info(f"Namespace creation (private: {is_private}) | "
                         f"{response.status_code} | {response.reason}")
        except DataLinksRequestError as e:
            if e.status_code == 409: pass
            else: raise

    def update_infer_definition(self, data_description: str, field_definition: str) -> None:
        """
        Update the saved inference definition for the configured dataset.

        The inference definition is used automatically on future ingest calls to guide
        field extraction and normalization.

        :param data_description: Free-text description of the dataset (max 10,000 chars).
        :type data_description: str
        :param field_definition: Field-level definitions, one per line as ``field=description``
            (max 10,000 chars).
        :type field_definition: str
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        payload = {
            "dataDescription": data_description,
            "fieldDefinition": field_definition,
        }
        self.__put_request(payload, f"{self.__data_url}/inferDefinition")

    def infer_dataset_description(self, sample: Dataset,
                                   model: Optional[str] = None,
                                   provider: Optional[str] = None,
                                   current_description: Optional[str] = None,
                                   current_schema: Optional[Dict[str, str]] = None) -> Dict:
        """
        Ask an agent to infer a data description and field schema from sampled data.

        :param sample: A sample of data rows to analyse.
        :type sample: Dataset
        :param model: LLM model name.
        :type model: Optional[str]
        :param provider: LLM provider (e.g. ``"openai"``, ``"ollama"``).
        :type provider: Optional[str]
        :param current_description: Existing description to refine.
        :type current_description: Optional[str]
        :param current_schema: Existing field schema to refine (field → description mapping).
        :type current_schema: Optional[Dict[str, str]]
        :return: Inferred ``dataDescription`` and ``fieldDefinition``.
        :rtype: Dict
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        payload: Dict[str, Any] = {"sample": sample, "model": model, "provider": provider}
        if current_description is not None or current_schema is not None:
            payload["currentValue"] = {}
            if current_description is not None:
                payload["currentValue"]["description"] = current_description
            if current_schema is not None:
                payload["currentValue"]["schema"] = current_schema
        response = self.__post_request(payload, self.__infer_description_url)
        return response.json()

    def update_sort_order(self, order: List[str]) -> None:
        """
        Update the display order of columns for the configured dataset.

        :param order: Ordered list of all column names in the desired sequence.
        :type order: List[str]
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        self.__put_request({"order": order}, self.__sort_order_url)

    def prepare_multipart_upload(self, filename: str, size: int) -> Dict:
        """
        Initiate a multipart upload and receive presigned URLs for each part.

        Use this for large files. Upload each part directly to its presigned URL,
        then call :meth:`finish_multipart_upload` with the returned ETags.

        :param filename: Name of the file being uploaded.
        :type filename: str
        :param size: File size in bytes.
        :type size: int
        :return: Response containing ``uploadId``, ``key``, and presigned part URLs.
        :rtype: Dict
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        payload = {"filename": filename, "size": size}
        response = self.__post_request(payload, f"{self.__multipart_url}/prepare")
        return response.json()

    def finish_multipart_upload(self, upload_id: str, key: str,
                                parts: List[Dict[str, Any]],
                                name: Optional[str] = None) -> Dict:
        """
        Complete a multipart upload after all parts have been uploaded.

        :param upload_id: Upload ID from :meth:`prepare_multipart_upload`.
        :type upload_id: str
        :param key: S3 object key from :meth:`prepare_multipart_upload`.
        :type key: str
        :param parts: List of completed parts, each with ``partNumber`` (int) and
            ``etag`` (str) returned by S3.
        :type parts: List[Dict[str, Any]]
        :param name: Optional label for the ingestion (e.g. original filename).
        :type name: Optional[str]
        :return: Ingestion result from the server.
        :rtype: Dict
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        payload: Dict[str, Any] = {"uploadId": upload_id, "key": key, "parts": parts}
        if name is not None:
            payload["name"] = name
        response = self.__post_request(payload, f"{self.__multipart_url}/finish")
        return response.json()

    def abort_multipart_upload(self, upload_id: str, key: str) -> None:
        """
        Abort a multipart upload and clean up partial data.

        :param upload_id: Upload ID from :meth:`prepare_multipart_upload`.
        :type upload_id: str
        :param key: S3 object key from :meth:`prepare_multipart_upload`.
        :type key: str
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        payload = {"uploadId": upload_id, "key": key}
        self.__post_request(payload, f"{self.__multipart_url}/abort")

    def list_ingestions(self, page_size: int = 25) -> Optional[List[Dict]]:
        """
        List ingestion attempts for the configured dataset, most recent first.

        Each record contains ``id``, ``status``, ``statusMessage``,
        ``processedBytes``, ``expectedTotalBytes``, ``processedRows``,
        and ``attributes``.

        :param page_size: Number of records to return (1-100, default 25).
        :type page_size: int
        :return: List of ingestion attempt dicts, or None on failure.
        :rtype: Optional[List[Dict]]
        """
        url = f"{self.__data_url}/ingest/attempts?pageSize={page_size}"
        try:
            response = self.__get_request(url)
            return response.json().get("data")
        except DataLinksRequestError:
            return None

    def wait_for_ingestion(self, ingestion_id: str,
                           poll_interval: int = 5,
                           timeout: int = 1200) -> Dict:
        """
        Poll until the given ingestion reaches a terminal status.

        Polls :meth:`list_ingestions` every *poll_interval* seconds until the
        ingestion with *ingestion_id* is no longer in a pending/processing
        state, or until *timeout* seconds have elapsed.

        :param ingestion_id: Ingestion ID returned by :meth:`finish_multipart_upload`.
        :type ingestion_id: str
        :param poll_interval: Seconds between polls (default 5).
        :type poll_interval: int
        :param timeout: Maximum seconds to wait before raising (default 600).
        :type timeout: int
        :return: The final ingestion record dict.
        :rtype: Dict
        :raises TimeoutError: If *timeout* is exceeded before a terminal status.
        :raises DataLinksRequestError: If polling requests fail.
        """
        _TERMINAL = {"complete", "completed", "done", "success", "failed", "error"}

        deadline = time.monotonic() + timeout
        last_status = None
        last_pct = -1.0

        while time.monotonic() < deadline:
            records = self.list_ingestions(page_size=100)
            if records is not None:
                match = next((r for r in records if r.get("id") == ingestion_id), None)
                if match:
                    status = (match.get("status") or "").strip()
                    processed = match.get("processedBytes", 0) or 0
                    total = match.get("expectedTotalBytes", 0) or 0
                    pct = processed / total * 100 if total else -1.0
                    pct_str = f"{pct:.1f}%" if pct >= 0 else "?%"

                    if status != last_status or pct - last_pct >= 5.0:
                        _logger.info(
                            "Ingestion %s status: %s (%s rows, %s)",
                            ingestion_id,
                            status,
                            match.get("processedRows", "?"),
                            pct_str,
                        )
                        last_status = status
                        last_pct = pct

                    if status.lower().replace(" ", "") in _TERMINAL:
                        return match
            time.sleep(poll_interval)

        raise TimeoutError(
            f"Ingestion {ingestion_id} did not reach a terminal status within {timeout}s "
            f"(last status: {last_status!r})"
        )

    def get_dataset_info(self) -> Optional[Dict]:
        """
        Retrieve metadata for the configured dataset.

        Returns a dict with ``dataset``, ``metadata``, and ``inferDefinition`` keys,
        or ``None`` if the request fails.

        :return: Dataset metadata dict, or None on failure.
        :rtype: Optional[Dict]
        """
        try:
            response = self.__get_request(self.__data_url)
            return response.json()
        except DataLinksRequestError:
            return None

    def delete_dataset(self) -> None:
        """
        Permanently delete the configured dataset, including all data, links, and metadata.

        This action is irreversible (balefire).

        :raises DataLinksRequestError: If the HTTP request fails.
        """
        self.__delete_request(f"{self.__data_url}/balefire")

    def rename_dataset(self, new_name: str) -> None:
        """
        Rename the configured dataset.

        :param new_name: The new dataset name.
        :type new_name: str
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        self.__post_request(new_name, f"{self.__data_url}/rename", content_type="text/plain")

    def clear_dataset(self) -> None:
        """
        Remove all data and links from the configured dataset.

        The dataset itself (metadata, schema) is preserved. This action is irreversible.

        :raises DataLinksRequestError: If the HTTP request fails.
        """
        self.__post_request({}, f"{self.__data_url}/clear")

    def add_link(self, from_namespace: str, from_dataset: str, from_column: str,
                 to_namespace: str, to_dataset: str, to_column: str,
                 match_type: str,
                 options: Optional[Dict[str, Any]] = None) -> Optional[Dict]:
        """
        Create a manual link between two dataset columns.

        :param from_namespace: Source namespace.
        :param from_dataset: Source dataset name.
        :param from_column: Source column name.
        :param to_namespace: Target namespace.
        :param to_dataset: Target dataset name.
        :param to_column: Target column name.
        :param match_type: Match type — ``"ExactMatch"`` or ``"GeoMatch"``.
        :param options: Optional match configuration (e.g. ``minDistinct``, ``distance``).
        :return: The created link object, or None on failure.
        :rtype: Optional[Dict]
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        payload: Dict[str, Any] = {
            "from": {"username": "self", "namespace": from_namespace, "dataset": from_dataset, "columnName": from_column},
            "to": {"username": "self", "namespace": to_namespace, "dataset": to_dataset, "columnName": to_column},
            "matchType": match_type,
        }
        if options is not None:
            payload["options"] = options
        try:
            response = self.__post_request(payload, self.__links_add_url)
            return response.json()
        except DataLinksRequestError:
            return None

    def preview_links(self, data: Dataset,
                      entity_resolution: Optional[MatchTypeConfig] = None) -> Optional[List[Dict]]:
        """
        Preview what recalculating links would produce without saving changes.

        :param data: Array of ontology data objects (e.g. from :meth:`query_data`).
        :type data: Dataset
        :param entity_resolution: Optional link matching configuration.
        :type entity_resolution: Optional[MatchTypeConfig]
        :return: Preview of link objects, or None on failure.
        :rtype: Optional[List[Dict]]
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        payload: Dict[str, Any] = {"data": data}
        if entity_resolution is not None:
            payload["link"] = entity_resolution.config
        url = f"{self.config.host}/links/preview/self/{self.config.namespace}/{self.config.objectname}"
        try:
            response = self.__post_request(payload, url)
            return response.json()
        except DataLinksRequestError:
            return None

    def rebuild_links(self, data: Dataset,
                      entity_resolution: Optional[MatchTypeConfig] = None) -> Optional[List[Dict]]:
        """
        Recalculate links for the configured dataset based on current data.

        :param data: Array of ontology data objects (e.g. from :meth:`query_data`).
        :type data: Dataset
        :param entity_resolution: Optional link matching configuration.
        :type entity_resolution: Optional[MatchTypeConfig]
        :return: Updated list of link objects, or None on failure.
        :rtype: Optional[List[Dict]]
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        payload: Dict[str, Any] = {"data": data}
        if entity_resolution is not None:
            payload["link"] = entity_resolution.config
        try:
            response = self.__post_request(payload, self.__links_url)
            return response.json()
        except DataLinksRequestError:
            return None

    def load_links(self) -> Optional[List[Dict]]:
        """
        Retrieve active and suggested links for the configured dataset.

        :return: A list of link objects, or None on failure.
        :rtype: Optional[List[Dict]]
        """
        try:
            response = self.__get_request(self.__links_url)
            return response.json()
        except DataLinksRequestError:
            return None

    def list_datasets(self, namespace: Optional[str] = None) -> List[Dict] | None:
        """
        Retrieves the list of datasets for the user, optionally filtered by a specific namespace.

        :param namespace: Optional namespace to filter the datasets by.
            If provided, only datasets associated with the given
            namespace will be returned. If not provided, all datasets are
            retrieved.
        :type namespace: Optional[AnyStr]

        :return: A list of datasets represented as dictionaries if the
            query is successful and returns a status code of 200, or
            None if the query fails or encounters an error.
        :rtype: List[Dict] | None
        """
        _url = self.__datasets_url
        if namespace:
            _url += f"/{namespace}"
        try:
            response = self.__get_request(_url)
            if response.status_code == 200:
                return response.json()
            else:
                _logger.error(f"Query data failed with status {response.status_code}")
        except DataLinksRequestError:
            pass

        return None

    def query_data(self, query: Optional[str] = None,
                   is_natural_language: Optional[bool] = False,
                   model: Optional[str] = None, provider: Optional[str] = None,
                   include_metadata: bool = False) -> Optional[Dataset]:
        """
        Queries data from a specified data source and processes the response.

        The method allows querying with a specific query string or with a wildcard
        ("*") for all data. The response from the query can be filtered to exclude
        metadata fields if `include_metadata` is set to False. Metadata fields are
        identified by key names starting with an underscore.

        :param query: The query string to use for fetching data. Defaults to "*",
                      which retrieves all data.
        :type query: str
        :param model: The model name to use for inference.
        :type model: str
        :param provider: The provider of the LLM model (ollama, openai, etc)
        :type provider: str
        :param include_metadata: Specifies whether to include metadata fields in
                                 the returned data. Defaults to False.
        :type include_metadata: bool
        :return: A list of records represented as dictionaries, or None if the query
                 fails or an exception occurs during the request.
        :rtype: List[Dict] | None
        :raises requests.exceptions.RequestException: If a request-related error
            occurs during querying.
        """
        if query is None:
            query = f"Ontology({self.config.namespace}/{self.config.objectname})"
        query_param_name = "query" if not is_natural_language else "naturalLanguageQuery"
        payload = {
            "username": "self",
            "namespace": self.config.namespace,
            "dataset": self.config.objectname,
            f"{query_param_name}": query,
            "model": model,
            "provider": provider
        }
        return self.__handle_data_query(payload, include_metadata)

    def ask(self, query: str, model: Optional[str] = None, provider: Optional[str] = None,
            helper_prompt: Optional[str] = None) -> Iterator[AskEvent]:
        """
        Talk to your data with natural language using the DataLinks AutoRAG agent.

        Streams the agent's reasoning and final answer as Server-Sent Events. Events are
        yielded in order: one ``plan`` event, one or more ``step`` events, then either an
        ``answer`` event or an ``error`` event.

        :param query: The natural language question to answer.
        :type query: str
        :param model: The model name to use for inference.
        :type model: str
        :param provider: The LLM provider (e.g. ``openai``, ``ollama``).
        :type provider: str
        :param helper_prompt: Optional custom system prompt.
        :type helper_prompt: str
        :return: An iterator of :class:`AskEvent` objects.
        :rtype: Iterator[AskEvent]
        :raises DataLinksRequestError: If the HTTP request fails.
        """
        payload = {
            "username": "self",
            "namespace": self.config.namespace,
            "query": query,
            "model": model,
            "provider": provider,
            "helperPrompt": helper_prompt,
        }
        headers = {**self.__headers, "Accept": "text/event-stream"}

        try:
            with requests.post(
                self.__ask_url,
                json=payload,
                headers=headers,
                stream=True,
                timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
            ) as response:
                response.raise_for_status()
                event_type: Optional[str] = None
                for raw_line in response.iter_lines():
                    line: str = raw_line.decode("utf-8") if isinstance(raw_line, bytes) else raw_line
                    if line.startswith("event:"):
                        event_type = line[6:].strip()
                    elif line.startswith("data:") and event_type:
                        data_str = line[5:].strip()
                        try:
                            yield AskEvent(type=event_type, data=json.loads(data_str))
                        except json.JSONDecodeError:
                            _logger.error("Failed to parse SSE data for event '%s': %s", event_type, data_str)
                        event_type = None
        except requests.exceptions.RequestException as e:
            raise DataLinksRequestError(self.__ask_url, e)

    def __handle_data_query(self, payload: Dict[str, Any], include_metadata: bool) -> Dataset | None:
        json_data = {}
        try:
            response = self.__post_request(payload, self.__query_url)
            json_data = response.json()
        except DataLinksRequestError:
            pass


        if isinstance(json_data, list):
            raise NotImplementedError
        elif json_data and not include_metadata:
            return [dict(filter(lambda key_value: not str(key_value[0]).startswith("_"),
                                record.items()))
                    for record in json_data.get("data", [])]
        return json_data.get("data", []) if json_data else None
