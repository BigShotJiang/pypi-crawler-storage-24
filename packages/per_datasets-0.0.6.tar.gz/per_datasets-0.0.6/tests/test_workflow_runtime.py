import json

import pytest
import requests

from per_datasets.utils import api as api_module
from per_datasets.utils import init as init_module


class FakeResponse:
    def __init__(self, *, json_data=None, status_code=200):
        self._json_data = json_data
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.exceptions.HTTPError(f"HTTP {self.status_code}")

    def json(self):
        return self._json_data


class FakeSocketClient:
    def __init__(self):
        self.connected = False
        self.handlers = {}
        self.emit_calls = []
        self._start_by_job = {}
        self._chunks_by_job = {}
        self.behavior_by_rpc = {}

    def on(self, event):
        def decorator(func):
            self.handlers[event] = func
            return func

        return decorator

    def connect(self, url, auth=None, transports=None, wait_timeout=None):
        self.connected = True
        self.emit_calls.append(
            {
                "event": "__connect__",
                "data": {
                    "url": url,
                    "auth": auth,
                    "transports": transports,
                    "wait_timeout": wait_timeout,
                },
            }
        )

    def disconnect(self):
        self.connected = False
        handler = self.handlers.get("disconnect")
        if handler is not None:
            handler()

    def emit(self, event, data, callback=None):
        payload = dict(data)
        self.emit_calls.append({"event": event, "data": payload, "callback": callback})

        if event == "workflow_stream_start":
            job_id = str(payload.get("job_id", ""))
            if job_id:
                self._start_by_job[job_id] = payload
                self._chunks_by_job[job_id] = []
            self._dispatch("workflow_stream_started", payload)
            return

        if event != "workflow_stream_chunk":
            return

        job_id = str(payload.get("job_id", ""))
        start_payload = self._start_by_job.get(job_id, {})
        rpc_name = str(start_payload.get("rpc_name", ""))
        behavior = self.behavior_by_rpc.get(rpc_name, {})

        if not payload.get("is_final"):
            self._chunks_by_job.setdefault(job_id, []).append(payload)
            chunk_updates = behavior.get("chunk_updates", [])
            idx = len(self._chunks_by_job[job_id]) - 1
            if idx < len(chunk_updates):
                self._dispatch(
                    "workflow_stream_update",
                    {
                        "job_id": job_id,
                        "workflow_name": start_payload.get("workflow_name", ""),
                        "rpc_name": rpc_name,
                        "result_json": json.dumps(chunk_updates[idx]),
                    },
                )
            return

        error_message = behavior.get("error")
        if error_message:
            self._dispatch(
                "workflow_stream_error",
                {
                    "job_id": job_id,
                    "workflow_name": start_payload.get("workflow_name", ""),
                    "rpc_name": rpc_name,
                    "message": error_message,
                },
            )
            return

        for item in behavior.get("updates", []):
            self._dispatch(
                "workflow_stream_update",
                {
                    "job_id": job_id,
                    "workflow_name": start_payload.get("workflow_name", ""),
                    "rpc_name": rpc_name,
                    "result_json": json.dumps(item),
                },
            )

        if behavior.get("complete", True):
            self._dispatch(
                "workflow_stream_completed",
                {
                    "job_id": job_id,
                    "workflow_name": start_payload.get("workflow_name", ""),
                    "rpc_name": rpc_name,
                },
            )

    def sleep(self, _seconds):
        return None

    def _dispatch(self, event, payload):
        handler = self.handlers.get(event)
        if handler is not None:
            try:
                handler(payload)
            except TypeError:
                handler()


@pytest.fixture(autouse=True)
def reset_state(monkeypatch):
    api_module._API_CONFIG.update(
        {
            "api_key": None,
            "api_key_hash": None,
            "base_url": "http://localhost:8080",
        }
    )
    monkeypatch.setattr("per_datasets.utils.display.digital_screen", lambda *_args, **_kwargs: None)


def _workflow_definitions(*items):
    return {item["id"]: item for item in items}


def _configure_http(monkeypatch, workflow_definitions):
    def fake_post(url, json=None, headers=None, stream=False):
        if url.endswith("/internal/validate-key"):
            return FakeResponse(json_data={"valid": True, "user": {"id": "user-1"}})
        raise AssertionError(f"Unexpected POST URL: {url}")

    def fake_get(url, headers=None):
        workflow_id = url.rsplit("/", 1)[-1]
        data = workflow_definitions.get(workflow_id)
        if data is None:
            return FakeResponse(status_code=404)
        return FakeResponse(json_data={"data": dict(data)})

    monkeypatch.setattr(api_module.requests, "post", fake_post)
    monkeypatch.setattr(api_module.requests, "get", fake_get)


def _build_session(monkeypatch, fake_socket, workflow_definitions, **kwargs):
    _configure_http(monkeypatch, workflow_definitions)
    monkeypatch.setattr(init_module.socketio, "Client", lambda: fake_socket)
    return init_module.initialize(
        api_key="pk_test_key",
        master_url="https://master.example",
        **kwargs,
    )


def test_selector_resolution_and_alias_ambiguity(monkeypatch):
    fake_socket = FakeSocketClient()
    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "alpha",
            "operation_manifest": [{"function_name": "add", "rpc_name": "Add", "mode": "unary", "params": [{"name": "a"}, {"name": "b"}]}],
        },
        {
            "id": "dep-2",
            "workflow_name": "alpha",
            "operation_manifest": [{"function_name": "add", "rpc_name": "Add", "mode": "unary", "params": [{"name": "a"}, {"name": "b"}]}],
        },
    )

    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1", "dep-2"])
    assert session.workflows("dep-1")._spec.deployment_id == "dep-1"

    with pytest.raises(KeyError, match="ambiguous"):
        session.workflows("alpha")


def test_unary_operation_payload_and_result(monkeypatch):
    fake_socket = FakeSocketClient()
    fake_socket.behavior_by_rpc["Add"] = {"updates": [4]}

    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "rcXP7rD",
            "operation_manifest": [
                {
                    "function_name": "add",
                    "rpc_name": "Add",
                    "mode": "unary",
                    "input_streaming": False,
                    "output_streaming": False,
                    "params": [{"name": "a"}, {"name": "b"}],
                }
            ],
        }
    )

    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1"])
    result = session.workflows("dep-1").add(2, 2)
    assert result == 4

    start = next(call for call in fake_socket.emit_calls if call["event"] == "workflow_stream_start")
    chunk = next(call for call in fake_socket.emit_calls if call["event"] == "workflow_stream_chunk")

    assert start["data"]["workflow_name"] == "rcXP7rD"
    assert start["data"]["rpc_name"] == "Add"
    assert start["data"]["mode"] == "unary"
    assert json.loads(chunk["data"]["payload_json"]) == {"a": 2, "b": 2}
    assert chunk["data"]["is_final"] is True


def test_input_stream_emits_chunk_sequence_with_trailing_unary_params(monkeypatch):
    fake_socket = FakeSocketClient()
    fake_socket.behavior_by_rpc["ComputeNnLayer"] = {"updates": [8.0]}

    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "sumFlow",
            "operation_manifest": [
                {
                    "function_name": "compute_nn_layer",
                    "rpc_name": "ComputeNnLayer",
                    "mode": "input_stream",
                    "input_streaming": True,
                    "output_streaming": False,
                    "params": [
                        {"name": "item_1"},
                        {"name": "item_2"},
                        {"name": "item_3"},
                        {"name": "max_iters"},
                    ],
                    "input_stream_fields": ["item_1", "item_2", "item_3"],
                    "stream_unary_param_names": ["max_iters"],
                    "input_stream_arity": 3,
                    "output_stream_fields": ["result"],
                    "output_stream_arity": 1,
                }
            ],
        }
    )

    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1"])
    result = session.workflows("dep-1").compute_nn_layer([[3.0, 2.0, True], [5.0, 1.0, False]], max_iters=2)
    assert result == 8.0

    start = next(call for call in fake_socket.emit_calls if call["event"] == "workflow_stream_start")
    assert json.loads(start["data"]["params_json"]) == {"max_iters": 2}

    chunks = [call for call in fake_socket.emit_calls if call["event"] == "workflow_stream_chunk"]
    assert len(chunks) == 3
    assert json.loads(chunks[0]["data"]["payload_json"]) == {"item_1": 3.0, "item_2": 2.0, "item_3": True}
    assert json.loads(chunks[1]["data"]["payload_json"]) == {"item_1": 5.0, "item_2": 1.0, "item_3": False}
    assert chunks[-1]["data"]["is_final"] is True


def test_input_stream_rejects_dict_key_order_mismatch(monkeypatch):
    fake_socket = FakeSocketClient()
    fake_socket.behavior_by_rpc["ComputeNnLayer"] = {"updates": [8.0]}

    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "sumFlow",
            "operation_manifest": [
                {
                    "function_name": "compute_nn_layer",
                    "rpc_name": "ComputeNnLayer",
                    "mode": "input_stream",
                    "input_streaming": True,
                    "output_streaming": False,
                    "params": [
                        {"name": "item_1"},
                        {"name": "item_2"},
                        {"name": "item_3"},
                    ],
                    "input_stream_fields": ["item_1", "item_2", "item_3"],
                    "stream_unary_param_names": [],
                    "input_stream_arity": 3,
                    "output_stream_fields": ["result"],
                    "output_stream_arity": 1,
                }
            ],
        }
    )

    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1"])
    with pytest.raises(RuntimeError, match="key order mismatch"):
        session.workflows("dep-1").compute_nn_layer(
            [
                {"value": 3.0, "scale": 2.0, "bias": 1.0},
                {"scale": 0.5, "value": 5.0, "bias": -0.5},
            ]
        )


def test_input_stream_type_mismatch_reports_field_and_expected_type(monkeypatch):
    fake_socket = FakeSocketClient()
    fake_socket.behavior_by_rpc["ComputeNnLayer"] = {"updates": [8.0]}

    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "typedFlow",
            "operation_manifest": [
                {
                    "function_name": "compute_nn_layer",
                    "rpc_name": "ComputeNnLayer",
                    "mode": "input_stream",
                    "input_streaming": True,
                    "output_streaming": False,
                    "params": [
                        {"name": "item_1", "proto_type": "double"},
                        {"name": "item_2", "proto_type": "int64"},
                        {"name": "item_3", "proto_type": "bool"},
                    ],
                    "input_stream_fields": ["item_1", "item_2", "item_3"],
                    "stream_unary_param_names": [],
                    "input_stream_arity": 3,
                    "output_stream_fields": ["result"],
                    "output_stream_arity": 1,
                }
            ],
        }
    )

    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1"])
    with pytest.raises(RuntimeError, match="item_2.*expects int"):
        session.workflows("dep-1").compute_nn_layer([[3.0, 0.5, True]])


def test_unary_type_mismatch_reports_expected_type(monkeypatch):
    fake_socket = FakeSocketClient()
    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "typedUnary",
            "operation_manifest": [
                {
                    "function_name": "add",
                    "rpc_name": "Add",
                    "mode": "unary",
                    "params": [
                        {"name": "a", "proto_type": "double"},
                        {"name": "b", "proto_type": "double"},
                    ],
                }
            ],
        }
    )

    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1"])
    with pytest.raises(TypeError, match="Parameter 'b'"):
        session.workflows("dep-1").add(1.0, "two")


def test_output_stream_and_bidi_generators(monkeypatch):
    fake_socket = FakeSocketClient()
    fake_socket.behavior_by_rpc["CountTo"] = {"updates": [1, 2, 3]}
    fake_socket.behavior_by_rpc["Chat"] = {"chunk_updates": ["pong-1", "pong-2"], "updates": []}

    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "streamFlow",
            "operation_manifest": [
                {
                    "function_name": "count_to",
                    "rpc_name": "CountTo",
                    "mode": "output_stream",
                    "input_streaming": False,
                    "output_streaming": True,
                    "params": [{"name": "n"}],
                    "output_stream_fields": ["result"],
                    "output_stream_arity": 1,
                },
                {
                    "function_name": "chat",
                    "rpc_name": "Chat",
                    "mode": "bi_di",
                    "input_streaming": True,
                    "output_streaming": True,
                    "params": [{"name": "item_1"}],
                    "input_stream_fields": ["item_1"],
                    "stream_unary_param_names": [],
                    "input_stream_arity": 1,
                    "output_stream_fields": ["result"],
                    "output_stream_arity": 1,
                },
            ],
        }
    )

    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1"])

    assert list(session.workflows("dep-1").count_to(3)) == [1, 2, 3]
    assert list(session.workflows("dep-1").chat(["ping-1", "ping-2"])) == ["pong-1", "pong-2"]


def test_multi_output_stream_decodes_to_tuples(monkeypatch):
    fake_socket = FakeSocketClient()
    fake_socket.behavior_by_rpc["Split"] = {"updates": [{"item_1": 1.5, "item_2": 2}, {"item_1": 2.5, "item_2": 3}]}

    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "multiOut",
            "operation_manifest": [
                {
                    "function_name": "split",
                    "rpc_name": "Split",
                    "mode": "output_stream",
                    "input_streaming": False,
                    "output_streaming": True,
                    "params": [{"name": "seed"}],
                    "output_stream_fields": ["item_1", "item_2"],
                    "output_stream_arity": 2,
                }
            ],
        }
    )

    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1"])
    assert list(session.workflows("dep-1").split(seed=1.0)) == [(1.5, 2), (2.5, 3)]


def test_runtime_error_timeout_and_disconnect_cleanup(monkeypatch):
    fake_socket = FakeSocketClient()
    fake_socket.behavior_by_rpc["Add"] = {"error": "rpc failed"}

    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "alpha",
            "operation_manifest": [
                {
                    "function_name": "add",
                    "rpc_name": "Add",
                    "mode": "unary",
                    "params": [{"name": "a"}, {"name": "b"}],
                },
                {
                    "function_name": "count_to",
                    "rpc_name": "CountTo",
                    "mode": "output_stream",
                    "output_streaming": True,
                    "params": [{"name": "n"}],
                    "output_stream_fields": ["result"],
                    "output_stream_arity": 1,
                },
            ],
        }
    )

    session = _build_session(
        monkeypatch,
        fake_socket,
        definitions,
        workflows=["dep-1"],
        workflow_call_timeout=0.05,
    )

    with pytest.raises(RuntimeError, match="rpc failed"):
        session.workflows("dep-1").add(1, 2)

    fake_socket.behavior_by_rpc["CountTo"] = {"updates": [], "complete": False}
    stream = session.workflows("dep-1").count_to(3)
    fake_socket._dispatch("disconnect", {})
    with pytest.raises(TimeoutError, match="timed out"):
        list(stream)

    fake_socket.behavior_by_rpc["Add"] = {"updates": [], "complete": False}
    with pytest.raises(TimeoutError, match="timed out"):
        session.workflows("dep-1").add(1, 2)


def test_workflow_metadata_lookup_errors(monkeypatch):
    fake_socket = FakeSocketClient()

    definitions = _workflow_definitions(
        {
            "id": "dep-bad",
            "workflow_name": "bad",
            "operation_manifest": [{"rpc_name": "Add", "mode": "unary"}],
        }
    )

    with pytest.raises(ConnectionError, match="dep-missing"):
        _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-missing"])

    with pytest.raises(ValueError, match="function_name"):
        _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-bad"])


def test_rejects_legacy_manifest_modes(monkeypatch):
    fake_socket = FakeSocketClient()

    definitions = _workflow_definitions(
        {
            "id": "dep-legacy",
            "workflow_name": "legacy",
            "operation_manifest": [
                {
                    "function_name": "sum_stream",
                    "rpc_name": "SumStream",
                    "mode": "client_stream",
                    "params": [{"name": "value"}],
                }
            ],
        }
    )

    with pytest.raises(ValueError, match="Unsupported legacy workflow mode"):
        _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-legacy"])


def test_default_workflow_call_timeout_is_unbounded(monkeypatch):
    fake_socket = FakeSocketClient()
    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "alpha",
            "operation_manifest": [
                {
                    "function_name": "add",
                    "rpc_name": "Add",
                    "mode": "unary",
                    "params": [{"name": "a"}, {"name": "b"}],
                }
            ],
        }
    )
    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1"])
    assert session.workflows._call_timeout is None


def test_reconnect_emits_stream_resume_for_pending_jobs(monkeypatch):
    fake_socket = FakeSocketClient()
    fake_socket.behavior_by_rpc["CountTo"] = {"updates": [], "complete": False}
    definitions = _workflow_definitions(
        {
            "id": "dep-1",
            "workflow_name": "alpha",
            "operation_manifest": [
                {
                    "function_name": "count_to",
                    "rpc_name": "CountTo",
                    "mode": "output_stream",
                    "output_streaming": True,
                    "params": [{"name": "n"}],
                    "output_stream_fields": ["result"],
                    "output_stream_arity": 1,
                }
            ],
        }
    )

    session = _build_session(monkeypatch, fake_socket, definitions, workflows=["dep-1"], workflow_call_timeout=0.05)
    _stream = session.workflows("dep-1").count_to(3)
    fake_socket._dispatch("disconnect", {})
    fake_socket._dispatch("connection_response", {"message": "Connected and authenticated."})

    resume_events = [call for call in fake_socket.emit_calls if call["event"] == "workflow_stream_resume"]
    assert resume_events
    assert resume_events[-1]["data"]["workflow_name"] == "alpha"
    assert isinstance(resume_events[-1]["data"]["last_result_seq"], int)
