"""Initialization utilities for the per_datasets module."""

import logging
import time
from typing import Any, Dict, List, Optional

import socketio

from .api import get_auth_payload, initialize_workspace, process_orchestration_stream, set_api_key, validate_api_key
from .config import load_stored_api_key
from .display import digital_screen

logger = logging.getLogger(__name__)


def _normalize_workflow_call_timeout(raw_timeout: Optional[float]) -> Optional[float]:
    if raw_timeout is None:
        return None
    timeout_seconds = float(raw_timeout)
    if timeout_seconds <= 0:
        raise ValueError("workflow_call_timeout must be > 0 when provided, or None for no timeout")
    return timeout_seconds


class PDS_Session:
    """Session object for maintaining a master-service Socket.IO connection."""

    def __init__(self, api_key: str, master_url: str, **kwargs):
        normalized_master_url = (master_url or "").strip().rstrip("/")
        if not normalized_master_url:
            raise ValueError("A valid master_url is required to create a PDS session.")

        self.api_key = api_key
        self.master_url = normalized_master_url
        self.config = kwargs
        self._sio = socketio.Client()
        self._closed = False

        from ..workflows.runtime import WorkflowsClient

        # Late imports to avoid circular dependencies
        from .. import visual

        self.visual = visual
        self.workflows = WorkflowsClient(
            session=self,
            deployment_ids=self.config.get("workflows", []),
            call_timeout=_normalize_workflow_call_timeout(self.config.get("workflow_call_timeout")),
        )

        self._register_handlers()

        if not self._sio.connected:
            self.__enter__()

    def _register_handlers(self):
        """Register Socket.IO event handlers."""

        @self._sio.on("connection_response")
        def on_connect_response(data):
            masked_key = f"pk...{self.api_key[-4:]}" if len(self.api_key) > 4 else "pk..."
            status_text = f"STATUS: ACTIVE\nAPI KEY: {masked_key}\nMASTER: {self.master_url}"
            digital_screen(status_text)
            self.workflows.on_socket_reconnected()

            if isinstance(data, dict) and "message" in data:
                print(f"\n[SERVER] {data['message']}")

        @self._sio.on("server_response")
        def on_server_response(data):
            message = data.get("message", "No message") if isinstance(data, dict) else str(data)
            print(f"\n[SERVER] Response: {message}")

        @self._sio.on("connect_error")
        def on_connect_error(data):
            error_msg = data.get("error") if isinstance(data, dict) else (str(data) if data else "connection failed")
            print(f"\n[ERROR] Connection failed: {error_msg}")

        @self._sio.on("disconnect")
        def on_disconnect():
            self.workflows.on_socket_disconnected()
            if self._closed:
                self.workflows.fail_all_pending("Socket disconnected before workflow call completed.")

        @self._sio.on("workflow_stream_started")
        def on_workflow_stream_started(data):
            self.workflows.on_stream_started(data if isinstance(data, dict) else {})

        @self._sio.on("workflow_stream_update")
        def on_workflow_stream_update(data):
            self.workflows.on_stream_update(data if isinstance(data, dict) else {})

        @self._sio.on("workflow_stream_error")
        def on_workflow_stream_error(data):
            self.workflows.on_stream_error(data if isinstance(data, dict) else {})

        @self._sio.on("workflow_error")
        def on_workflow_error(data):
            message = (data or {}).get("message") if isinstance(data, dict) else str(data)
            self.workflows.fail_all_pending(f"Workflow error: {message}")

        @self._sio.on("workflow_stream_completed")
        def on_workflow_stream_completed(data):
            self.workflows.on_stream_completed(data if isinstance(data, dict) else {})

    def __enter__(self):
        """Connect to master-service Socket.IO server."""
        if self._sio.connected:
            return self

        wait_timeout = float(self.config.get("socket_wait_timeout", 30))
        max_attempts = int(self.config.get("socket_max_attempts", 3))

        for attempt in range(1, max_attempts + 1):
            try:
                self._sio.connect(
                    self.master_url,
                    auth=get_auth_payload(),
                    transports=["websocket"],
                    wait_timeout=wait_timeout,
                )
                return self
            except Exception as exc:
                logger.warning(
                    "Socket connect attempt %s/%s to %s failed: %s",
                    attempt,
                    max_attempts,
                    self.master_url,
                    exc,
                )
                if attempt >= max_attempts:
                    raise ConnectionError(
                        f"Could not connect to workspace master at {self.master_url} "
                        f"after {max_attempts} attempts. Last error: {exc}"
                    ) from exc
                time.sleep(min(2.0, 0.5 * attempt))

        return self

    def __destroy__(self):
        """Disconnect on exit and shut down subsystems."""
        if self._closed:
            return
        self._closed = True

        self.workflows.fail_all_pending("Session closed before workflow call completed.")

        if hasattr(self, "visual") and hasattr(self.visual, "shutdown"):
            try:
                self.visual.shutdown()
                print("[INFO] Visualization engine shut down.")
            except Exception as exc:
                logger.debug("Visual shutdown error: %s", exc)

        if self._sio.connected:
            self._sio.sleep(1)
            self._sio.disconnect()

        print("[INFO] PERD Session closed.")

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.__destroy__()

    def close(self):
        """Manually close the session."""
        self.__destroy__()

    @property
    def connected(self) -> bool:
        return bool(self._sio.connected)

    def emit(self, event: str, data: Dict[str, Any], callback=None, require_connected: bool = False):
        """Emit a custom event to the server."""
        if not self._sio.connected:
            if require_connected:
                raise ConnectionError(f"WebSocket not connected. Cannot emit '{event}'.")
            logger.warning("WebSocket not connected. Cannot emit '%s'.", event)
            return

        if callback:
            self._sio.emit(event, data, callback=callback)
            self._sio.sleep(0.1)
            return

        self._sio.emit(event, data)

    def send(self, text: str, **kwargs):
        """Send a standard client message event."""
        data = {"text": text}
        data.update(kwargs)
        self.emit("client_message", data)

    def load_random(self, filters=None, fields=None, partitions=None):
        """Load a random dataset through the session."""
        from ..reservoir import load_random

        return load_random(filters=filters, fields=fields, partitions=partitions)

    def load(self, reservoir_id: str):
        """Load a dataset by ID through the session."""
        from ..reservoir import load

        return load(reservoir_id)


def _normalize_deployment_ids(workflows: Optional[List[str]]) -> List[str]:
    if workflows is None:
        return []

    if isinstance(workflows, str):
        raise TypeError("workflows must be a list of deployment IDs, not a string")

    deployment_ids: List[str] = []
    for workflow_id in workflows:
        if workflow_id is None:
            continue
        normalized_id = str(workflow_id).strip()
        if normalized_id:
            deployment_ids.append(normalized_id)
    return deployment_ids


def _normalize_machine_overrides(machine_overrides: Optional[Dict[str, str]]) -> Dict[str, str]:
    if machine_overrides is None:
        return {}

    if not isinstance(machine_overrides, dict):
        raise TypeError("machine_overrides must be a dictionary of deployment_id -> machine type")

    normalized: Dict[str, str] = {}
    for deployment_id, machine_type in machine_overrides.items():
        normalized_id = str(deployment_id).strip()
        normalized_machine = str(machine_type).strip()
        if normalized_id and normalized_machine:
            normalized[normalized_id] = normalized_machine
    return normalized


def initialize(
    api_key: Optional[str] = None,
    master_url: Optional[str] = None,
    workflows: Optional[List[str]] = None,
    machine_overrides: Optional[Dict[str, str]] = None,
    default_machine: str = "e2-standard-4",
    region: Optional[str] = None,
    zone: Optional[str] = None,
    project: Optional[str] = None,
    master_image: Optional[str] = None,
    socket_wait_timeout: float = 30.0,
    socket_max_attempts: int = 3,
    workflow_call_timeout: Optional[float] = None,
    **kwargs,
) -> PDS_Session:
    """Initialize the module and return a connected `PDS_Session`."""
    if "machine_overides" in kwargs:
        raise TypeError("Use `machine_overrides` (canonical); `machine_overides` is unsupported.")
    if kwargs:
        unknown = ", ".join(sorted(kwargs.keys()))
        raise TypeError(f"Unsupported initialize() arguments: {unknown}")

    if not api_key:
        api_key = load_stored_api_key()
        if not api_key:
            raise ValueError(
                "No API key provided and no global API key found. "
                "Please provide an API key or set one globally using: "
                "per-datasets set-key <your_api_key>"
            )

    if not api_key or not api_key.strip():
        raise ValueError("API key cannot be empty")

    api_key = api_key.strip()

    print("Validating API key...")
    auth_info = validate_api_key(api_key)
    if not auth_info.get("valid"):
        raise ValueError(f"Invalid API key: {auth_info.get('error', 'Authentication failed')}")

    user_id = auth_info.get("user", {}).get("id") or "anonymous"
    print(f"Authenticated as user: {user_id}")

    # Required for both orchestration request hashing and Socket.IO auth payload.
    set_api_key(api_key)

    deployment_ids = _normalize_deployment_ids(workflows)
    normalized_overrides = _normalize_machine_overrides(machine_overrides)

    resolved_master_url = (master_url or "").strip()
    if not resolved_master_url:
        print("Initializing workspace via orchestration...")
        init_resp = initialize_workspace(
            api_key,
            user_id=user_id,
            deployment_ids=deployment_ids,
            default_machine=default_machine,
            machine_overrides=normalized_overrides,
            region=region,
            zone=zone,
            project=project,
            master_image=master_image,
        )

        if init_resp.get("status") == "error":
            raise RuntimeError(f"Orchestration failed: {init_resp.get('error')}")

        response = init_resp.get("response")
        if response is None:
            raise RuntimeError("Orchestration failed: missing streaming response")

        resolved_master_url = process_orchestration_stream(response)

    return PDS_Session(
        api_key,
        master_url=resolved_master_url,
        workflows=deployment_ids,
        machine_overrides=normalized_overrides,
        default_machine=default_machine,
        region=region,
        zone=zone,
        project=project,
        master_image=master_image,
        socket_wait_timeout=socket_wait_timeout,
        socket_max_attempts=socket_max_attempts,
        workflow_call_timeout=workflow_call_timeout,
    )
