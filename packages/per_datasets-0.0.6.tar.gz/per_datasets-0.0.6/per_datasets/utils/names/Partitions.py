"""Partition names used to group PER Datasets query responses."""

UFM = "ufm"
RESERVOIR = "reservoir"
WELL = "well"
