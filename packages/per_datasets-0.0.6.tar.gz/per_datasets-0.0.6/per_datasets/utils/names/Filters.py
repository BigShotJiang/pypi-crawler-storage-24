"""Filter field names used by PER Datasets queries."""

RESERVOIR_STOIIP = "stoiip"

WELL_PRODUCTION_COUNT_GT = "well_production_count__gt"
WELL_PRODUCTION_COUNT_LE = "well_production_count__le"

RESERVOIR_WELL_COUNT_EQ = "reservoir_well_count"
