"""Selectable data field names used by PER Datasets queries."""

# PRODUCTION
PRODUCTION_TIME = "production_time"
PRODUCTION_OIL_FLOW_RATE = "production_oil_flow_rate"
PRODUCTION_GAS_FLOW_RATE = "production_gas_flow_rate"
PRODUCTION_WATER_FLOW_RATE = "production_water_flow_rate"

# RESERVIOR
RESERVOIR_NAME = "name"
RESERVOIR_COLL_PATH = lambda ufm_id: f"datasets/{ufm_id}/Reservoirs"