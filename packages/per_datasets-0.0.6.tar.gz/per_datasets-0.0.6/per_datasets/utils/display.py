"""
Display utilities for the per_datasets module
"""


def digital_screen(text: str) -> None:
    """Display text in a digital screen format"""
    previous_line_count = getattr(digital_screen, "_previous_line_count", 0)
    if previous_line_count:
        # Move cursor to the beginning of the previously rendered block.
        print(f"\033[{previous_line_count}F", end="")

    # Split text into lines
    lines = text.split('\n')

    # Find the longest line to determine width
    max_length = max(len(line) for line in lines) if lines else 0
    width = max(max_length + 4, 50)  # Minimum width of 50, plus padding

    rendered_lines = []
    # Top border
    rendered_lines.append("\033[1m\033[48;5;91m" + " " * (width + 2) + "\033[0m")
    # Empty line for padding
    rendered_lines.append("\033[1m\033[48;5;91m" + " " + " " * width + " " + "\033[0m")

    # Print each line with left alignment and padding
    for line in lines:
        # Add left padding of 2 spaces and right padding to fill the container
        padded_line = "  " + line  # 2 spaces for left padding
        right_padding = width - len(padded_line)
        rendered_lines.append("\033[1m\033[48;5;91m" + " " + padded_line + " " * right_padding + " " + "\033[0m")

    # Empty line for padding
    rendered_lines.append("\033[1m\033[48;5;91m" + " " + " " * width + " " + "\033[0m")
    # Bottom border
    rendered_lines.append("\033[1m\033[48;5;91m" + " " * (width + 2) + "\033[0m")

    # Clear and rewrite all lines in-place.
    output = "".join(f"\033[2K{line}\n" for line in rendered_lines)
    print(output, end="", flush=True)
    digital_screen._previous_line_count = len(rendered_lines)
