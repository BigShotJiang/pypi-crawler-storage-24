"""Unit helpers for query parameters."""


def years(value: int | float) -> int:
    """Convert years to months for production-length filter inputs."""
    return int(round(value * 12))
