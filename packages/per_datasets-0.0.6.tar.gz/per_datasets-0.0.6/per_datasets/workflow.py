"""Workflow decorator and stream wrapper declarations."""

from __future__ import annotations

from collections.abc import AsyncIterator, Awaitable
from types import TracebackType
from typing import Any, Generic, Protocol, TypeVarTuple, Unpack, overload


_InputTs = TypeVarTuple("_InputTs")
_OutputTs = TypeVarTuple("_OutputTs")


class WorkflowStreamInput(Protocol, Generic[Unpack[_InputTs]]):
    """Type wrapper for streaming workflow inputs."""

    def __aiter__(self) -> AsyncIterator[Any]:
        ...

    def __anext__(self) -> Awaitable[Any]:
        ...


class WorkflowStreamOutput(Protocol, Generic[Unpack[_OutputTs]]):
    """Type wrapper for streaming workflow outputs."""

    def __aiter__(self) -> AsyncIterator[Any]:
        ...

    def __anext__(self) -> Awaitable[Any]:
        ...

    def asend(self, value: Any, /) -> Awaitable[Any]:
        ...

    @overload
    def athrow(
        self,
        typ: type[BaseException],
        val: BaseException | object = ...,
        tb: TracebackType | None = ...,
        /,
    ) -> Awaitable[Any]:
        ...

    @overload
    def athrow(
        self,
        typ: BaseException,
        val: None = ...,
        tb: TracebackType | None = ...,
        /,
    ) -> Awaitable[Any]:
        ...

    def athrow(
        self,
        typ: type[BaseException] | BaseException,
        val: BaseException | object | None = ...,
        tb: TracebackType | None = ...,
        /,
    ) -> Awaitable[Any]:
        ...

    def aclose(self) -> Awaitable[None]:
        ...


class workflow:
    """No-op decorators used for build-time workflow discovery."""

    @staticmethod
    def unary(func: Any) -> Any:
        return func

    @staticmethod
    def input_stream(func: Any) -> Any:
        return func

    @staticmethod
    def output_stream(func: Any) -> Any:
        return func

    @staticmethod
    def bi_di(func: Any) -> Any:
        return func


__all__ = ["workflow", "WorkflowStreamInput", "WorkflowStreamOutput"]
