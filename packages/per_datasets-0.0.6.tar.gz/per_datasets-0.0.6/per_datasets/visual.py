"""
Enterprise-grade visualization engine for per_datasets.
Architectural Upgrades:
- UI-Thread Safe: Asyncio-based scheduling on the main Jupyter event loop.
- No Global State: Context-bound VisualRuntime using Dependency Injection.
- High Performance: Numpy-backed RingBuffers to minimize GC pressure and reallocation.
- Explicit Lifecycle: Context manager support (__enter__/__exit__) for deterministic cleanup.
- Backpressure: Coalesced rendering updates (intermediate frame dropping).
"""

import time
import logging
import threading
import uuid
import asyncio
import weakref
from collections import deque
from typing import Union, Dict, List, Optional, Any, Iterator, Tuple, Generator

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from IPython.display import display

# Logger configuration
logger = logging.getLogger(__name__)

# --- Constants ---
MAX_BUFFER_SIZE = 1_000_000  
DEFAULT_FLUSH_INTERVAL = 0.1 # 10fps
DOWNSAMPLE_THRESHOLD = 20_000

class NumpyRingBuffer:
    """
    Enterprise-grade RingBuffer using fixed-size Numpy arrays.
    Eliminates memory reallocation and GC churn during streaming.
    """
    def __init__(self, capacity: int, dtype=np.float64):
        self.capacity = capacity
        self.data = np.zeros(capacity, dtype=dtype)
        self.head = 0
        self.size = 0
        self.lock = threading.Lock()

    def append(self, value: Any):
        with self.lock:
            self.data[self.head] = value
            self.head = (self.head + 1) % self.capacity
            if self.size < self.capacity:
                self.size += 1

    def extend(self, values: np.ndarray):
        with self.lock:
            n = len(values)
            if n >= self.capacity:
                # Optimized for bulk overflow
                self.data[:] = values[-self.capacity:]
                self.head = 0
                self.size = self.capacity
                return

            remaining = self.capacity - self.head
            if n <= remaining:
                self.data[self.head:self.head + n] = values
            else:
                self.data[self.head:] = values[:remaining]
                self.data[:n - remaining] = values[remaining:]
            
            self.head = (self.head + n) % self.capacity
            self.size = min(self.size + n, self.capacity)

    def view(self) -> np.ndarray:
        """Returns a stable chronological view of the data."""
        with self.lock:
            if self.size < self.capacity:
                return self.data[:self.size].copy()
            else:
                # Linearize: [Older Part] + [Newer Part]
                return np.concatenate((self.data[self.head:], self.data[:self.head]))

class RenderScheduler:
    """
    Asynchronous UI-Thread Scheduler.
    Schedules renders onto the main Jupyter/IPython event loop.
    This ensures absolute thread safety for Plotly/ipywidgets mutations.
    """
    def __init__(self, interval: float = DEFAULT_FLUSH_INTERVAL):
        self.interval = interval
        self._dirty_registry = set()
        self._registry = weakref.WeakValueDictionary()
        self._lock = threading.Lock()
        self._task = None
        self._running = False

    def register(self, item: Any):
        with self._lock:
            self._registry[item.id] = item
            if not self._running:
                self._start_task()

    def mark_dirty(self, item_id: str):
        with self._lock:
            self._dirty_registry.add(item_id)
            if not self._running:
                self._start_task()

    def unregister(self, item_id: str):
        with self._lock:
            self._registry.pop(item_id, None)
            self._dirty_registry.discard(item_id)

    def _start_task(self):
        try:
            loop = asyncio.get_running_loop()
            self._running = True
            self._task = loop.create_task(self._run_loop())
        except RuntimeError:
            # Fallback for environments without a running event loop
            logger.debug("No running event loop found. Scheduler will start when an async context is available.")
        except Exception as e:
            logger.error(f"Failed to start RenderScheduler task: {e}")

    async def _run_loop(self):
        """Pure async loop running on the UI thread's event loop."""
        from IPython import get_ipython
        ip = get_ipython()
        
        try:
            while self._running:
                await asyncio.sleep(self.interval)
                
                with self._lock:
                    if not self._dirty_registry:
                        continue
                    to_update = list(self._dirty_registry)
                    self._dirty_registry.clear()
                
                # We use the kernel's IO loop to force a flush to the frontend
                for vid in to_update:
                    item = self._registry.get(vid)
                    if item and not item._disposed:
                        try:
                            if ip and hasattr(ip, 'kernel'):
                                # Force schedule on the kernel's heartbeat for immediate sync
                                ip.kernel.io_loop.add_callback(item._update_plot)
                            else:
                                item._update_plot()
                        except Exception as e:
                            logger.error(f"Render heartbeat failure for {vid}: {e}")
        except asyncio.CancelledError:
            pass
        finally:
            self._running = False

    def stop(self):
        self._running = False
        if self._task:
            self._task.cancel()


class VisualRuntime:
    """
    Context-bound runtime management.
    Ensures lifecycle isolation between sessions.
    """
    def __init__(self):
        self.scheduler = RenderScheduler()

    def shutdown(self):
        self.scheduler.stop()

class Downsampler:
    """Trend-preserving signal processing."""
    @staticmethod
    def min_max(x: np.ndarray, y: np.ndarray, threshold: int) -> Tuple[np.ndarray, np.ndarray]:
        n = len(y)
        if n <= threshold:
            return x, y
        
        bucket_size = n // (threshold // 2)
        if bucket_size < 2: return x, y
            
        n_buckets = n // bucket_size
        y_cut = y[:n_buckets * bucket_size].reshape(n_buckets, bucket_size)
        x_cut = x[:n_buckets * bucket_size].reshape(n_buckets, bucket_size)
        
        idx_min = np.argmin(y_cut, axis=1)
        idx_max = np.argmax(y_cut, axis=1)
        
        out_x = np.zeros(n_buckets * 2)
        out_y = np.zeros(n_buckets * 2)
        
        for i in range(n_buckets):
            # Interleave to preserve oscillation order
            first, second = sorted([idx_min[i], idx_max[i]])
            out_x[i*2] = x_cut[i, first]
            out_y[i*2] = y_cut[i, first]
            out_x[i*2+1] = x_cut[i, second]
            out_y[i*2+1] = y_cut[i, second]
            
        return out_x, out_y

class StreamManager:
    """High-performance buffer manager leveraging RingBuffers."""
    def __init__(self, channels: List[str], maxlen=MAX_BUFFER_SIZE):
        self.channels = channels
        self.x_buffer = NumpyRingBuffer(maxlen)
        self.y_buffers = {c: NumpyRingBuffer(maxlen) for c in channels}
        self.maxlen = maxlen
        self._cnt = 0

    def add_data(self, data: Dict[str, Any], x_val: Optional[Any] = None):
        x = x_val if x_val is not None else self._cnt
        self.x_buffer.append(x)
        for c in self.channels:
            self.y_buffers[c].append(data.get(c, 0.0))
        self._cnt += 1

    def add_batch(self, x_batch: np.ndarray, y_batches: Dict[str, np.ndarray]):
        self.x_buffer.extend(x_batch)
        for c, vals in y_batches.items():
            if c in self.y_buffers:
                self.y_buffers[c].extend(vals)
        self._cnt += len(x_batch)

    def get_view(self, channel: str) -> Tuple[np.ndarray, np.ndarray]:
        x = self.x_buffer.view()
        y = self.y_buffers[channel].view()
        return Downsampler.min_max(x, y, DOWNSAMPLE_THRESHOLD)

class Visual:
    """
    Grade Visualization Artifact.
    Thread-safe, reactive, and explicitly managed.
    """
    def __init__(self, 
                 runtime: VisualRuntime,
                 data_source: Any, 
                 y: Union[str, List[str]], 
                 x: Optional[str] = None, 
                 title: str = "",
                 **kwargs):
        
        self.id = str(uuid.uuid4())
        self.runtime = runtime
        self.title = title
        self.y_keys = [y] if isinstance(y, str) else y
        self.x_key = x
        self.config = kwargs
        self._observers = []
        
        self._running = False
        self._thread = None
        self._disposed = False
        
        self.stream_manager = StreamManager(self.y_keys)
        self.figure = go.FigureWidget()
        self._setup_layout()
        
        # Scheduling
        self.runtime.scheduler.register(self)
        self._setup_ingestion(data_source)

    def _setup_layout(self):
        self.figure.update_layout(
            title=self.title,
            template="plotly_dark",
            margin=dict(l=20, r=20, t=40, b=20),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        self._apply_axis_config(self.figure)
        
        colors = self.config.get('colors', [self.config.get('color')] * len(self.y_keys))
        for i, key in enumerate(self.y_keys):
            color = colors[i] if i < len(colors) else None
            self.figure.add_trace(go.Scatter(
                x=[], y=[], mode='lines', 
                name=self.config.get('y_label') if len(self.y_keys) == 1 else key,
                line=dict(color=color) if color else None
            ))

    def _apply_axis_config(self, fig, row=None, col=None):
        c = self.config
        args = dict(row=row, col=col)
        
        # Grid settings
        gg = c.get('grid', c.get('show_grid', True))
        gx, gy = c.get('grid_x', gg), c.get('grid_y', gg)
        gw, gc = c.get('grid_width', 1.0), c.get('grid_color', '#444')
        mw, mc = c.get('minor_width', 0.5), c.get('minor_color', '#222')
        mxt = c.get('x_minor', c.get('x_minor_ticks', 0))
        myt = c.get('y_minor', c.get('y_minor_ticks', 0))

        common = dict(showline=True, linewidth=2.5, linecolor='#ccc', zeroline=True, zerolinewidth=2.5, zerolinecolor='#ccc', mirror=False)

        fig.update_xaxes(title_text=c.get('x_label') or self.x_key or "Index", type=c.get('x_scale', 'linear'), dtick=c.get('x_dtick'), 
                        showgrid=gx, gridcolor=gc, gridwidth=gw, 
                        minor=dict(showgrid=gx, gridcolor=mc, gridwidth=mw, nticks=mxt) if mxt > 0 or (c.get('x_scale') == 'log' and gx) else None,
                        **common, **args)
        
        fig.update_yaxes(title_text=c.get('y_label') or (self.y_keys[0] if len(self.y_keys) == 1 else "Value"), type=c.get('y_scale', 'linear'), dtick=c.get('y_dtick'), 
                        showgrid=gy, gridcolor=gc, gridwidth=gw, 
                        minor=dict(showgrid=gy, gridcolor=mc, gridwidth=mw, nticks=myt) if myt > 0 or (c.get('y_scale') == 'log' and gy) else None,
                        **common, **args)

    def mark_dirty(self):
        self.runtime.scheduler.mark_dirty(self.id)
        for ob in self._observers:
            if hasattr(ob, 'mark_dirty'): ob.mark_dirty()

    def add_observer(self, ob): self._observers.append(ob)

    def _setup_ingestion(self, source):
        if isinstance(source, (Iterator, Generator)):
            self._start_consumer(source)
        elif isinstance(source, (dict, list, np.ndarray)):
            self._ingest_static(source)
        elif hasattr(source, "stream"):
            self._start_consumer(source.stream())

    def _ingest_static(self, data):
        if isinstance(data, dict):
            fv = next(iter(data.values()))
            if isinstance(fv, (list, np.ndarray)):
                x = np.array(data.get(self.x_key, range(len(fv))))
                ys = {k: np.array(data[k]) for k in self.y_keys if k in data}
                self.stream_manager.add_batch(x, ys)
            else:
                self.stream_manager.add_data(data, data.get(self.x_key))
        elif isinstance(data, (list, np.ndarray)):
            for it in data:
                if isinstance(it, dict): self.stream_manager.add_data(it, it.get(self.x_key))
        self.mark_dirty()

    def _start_consumer(self, it):
        self._running = True
        def worker():
            try:
                for packet in it:
                    if not self._running or self._disposed: break
                    if isinstance(packet, dict):
                        self.stream_manager.add_data(packet, packet.get(self.x_key))
                    self.mark_dirty()
            except Exception as e: logger.error(f"Ingestion failed: {e}")
            finally: self._running = False
        self._thread = threading.Thread(target=worker, daemon=True, name=f"PDS-In-{self.id[:8]}")
        self._thread.start()

    def _update_plot(self):
        """Executed solely on the UI thread by the RenderScheduler."""
        if self._disposed: return
        with self.figure.batch_update():
            for i, channel in enumerate(self.y_keys):
                x, y = self.stream_manager.get_view(channel)
                if len(x) == 0: continue
                self.figure.data[i].x = x
                self.figure.data[i].y = y


    def show(self):
        # Force a synchronous update before displaying to prevent "white/blank" visuals
        self._update_plot()
        display(self.figure)
        return self

    def dispose(self):
        self._running = False
        self._disposed = True
        self.runtime.scheduler.unregister(self.id)
        if self._thread: self._thread.join(timeout=0.1)

    def __enter__(self): return self
    def __exit__(self, *args): self.dispose()

class Grid:
    """Enterprise composable layout with shared runtime."""
    def __init__(self, runtime: VisualRuntime, visuals: List[Visual], placement: List[Any]):
        self.id = str(uuid.uuid4())
        self.runtime = runtime
        self.visuals = visuals
        self.placement = placement
        self.figure = None
        self._build_grid()
        for v in self.visuals: v.add_observer(self)
        self.runtime.scheduler.register(self)
        self.mark_dirty()

    def mark_dirty(self): self.runtime.scheduler.mark_dirty(self.id)

    def _build_grid(self):
        max_r, max_c = 0, 0
        for item in self.placement:
            r, c = item[0], item[1]
            max_r = max(max_r, r)
            max_c = max(max_c, c[-1] if isinstance(c, list) else c)
        
        specs = [[{} for _ in range(max_c)] for _ in range(max_r)]
        for loc in self.placement:
            r, c = loc[0], loc[1]
            if isinstance(c, list):
                csp = c[-1] - c[0] + 1
                specs[r-1][c[0]-1] = {"colspan": csp}
                for i in range(1, csp): specs[r-1][c[0]-1+i] = None

        self.figure = make_subplots(rows=max_r, cols=max_c, specs=specs, print_grid=False)
        self.figure.update_layout(template="plotly_dark", height=350*max_r, showlegend=True)

        for v, loc in zip(self.visuals, self.placement):
            row, col = loc[0], loc[1][0] if isinstance(loc[1], list) else loc[1]
            for i, _ in enumerate(v.y_keys):
                v._apply_axis_config(self.figure, row=row, col=col)
                
                # Use a descriptive name for the legend
                metric_name = v.y_keys[i]
                trace_name = f"{v.title}: {metric_name}" if v.title else metric_name
                if len(v.y_keys) == 1 and v.title:
                    trace_name = v.title

                tr = go.Scatter(
                    x=[], y=[], 
                    mode='lines', 
                    name=trace_name, 
                    line=dict(color=v.figure.data[i].line.color)
                )
                self.figure.add_trace(tr, row=row, col=col)

    def _update_plot(self):
        if not self.figure: return
        with self.figure.batch_update():
            idx = 0
            for v in self.visuals:
                for channel in v.y_keys:
                    x, y = v.stream_manager.get_view(channel)
                    if len(x) > 0 and idx < len(self.figure.data):
                        self.figure.data[idx].x, self.figure.data[idx].y = x, y
                    idx += 1

    def show(self):
        # Force a synchronous update before displaying to prevent "white/blank" visuals
        self._update_plot()
        display(self.figure)

    def __enter__(self): return self
    def __exit__(self, *args): pass # Grid lifecycle tied to visuals

class Visualizer:
    """Enterprise factory with dependency-injected runtime."""
    def __init__(self, runtime: Optional[VisualRuntime] = None):
        self.runtime = runtime or VisualRuntime()

    def line_plot(self, data: Any, y: Union[str, List[str]], **kwargs) -> Visual:
        return Visual(self.runtime, data, y=y, **kwargs)

    def grid(self, visuals: List[Visual], placement: List[Any]) -> Grid:
        return Grid(self.runtime, visuals, placement)

    def shutdown(self):
        self.runtime.shutdown()
