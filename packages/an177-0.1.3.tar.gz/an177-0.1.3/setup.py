from setuptools import setup, find_packages
import os

# Đọc mô tả từ README
long_description = "A private tool for Python code obfuscation and protection."
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()

setup(
    name="an177",
    version="0.1.3",
    author="vinh_an17",
    author_email="anvu1772013@example.com",
    description="A lightweight offline code protection tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/vinh_an17/an177",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Security",
    ],
    python_requires='>=3.6',
    install_requires=[],
    include_package_data=True,
)