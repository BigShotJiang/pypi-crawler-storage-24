from typing import Any, Tuple


def 求和(元组数据: Tuple[Any, ...]):
    """返回元组中所有成员的求和结果。

    Args:
        元组数据: 待求和的元组。

    Returns:
        成功时返回求和结果；失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return None
        return sum(元组数据)
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：普通求和 =====")
    数据 = (1, 2, 3, 4)
    print("结果:", 求和(数据))

    print("\n===== 示例2：包含布尔值 =====")
    数据 = (True, False, 2)
    print("结果:", 求和(数据))

    print("\n===== 示例3：包含非数字 =====")
    数据 = (1, "2", 3)
    print("结果:", 求和(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 求和(数据))

    print("\n===== 示例5：浮点数求和 =====")
    数据 = (1.5, 2.5, 3.0)
    print("结果:", 求和(数据))

    print("\n===== 示例6：应用场景-汇总本周订单金额 =====")
    本周订单金额 = (188.5, 320.0, 99.9, 560.0, 210.0)
    print("结果:", 求和(本周订单金额))
