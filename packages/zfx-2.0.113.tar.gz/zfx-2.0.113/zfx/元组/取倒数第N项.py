from typing import Any, Tuple


def 取倒数第N项(元组数据: Tuple[Any, ...], 倒数位置: int):
    """返回元组中倒数第 N 项。

    Args:
        元组数据: 待处理的元组。
        倒数位置: 倒数位置，从 ``1`` 开始计数。

    Returns:
        成功时返回对应成员；失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple) or not isinstance(倒数位置, int) or 倒数位置 <= 0:
            return None
        return 元组数据[-倒数位置]
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：取倒数第1项 =====")
    数据 = (1, 2, 3, 4)
    print("结果:", 取倒数第N项(数据, 1))

    print("\n===== 示例2：取倒数第3项 =====")
    数据 = ("a", "b", "c", "d", "e")
    print("结果:", 取倒数第N项(数据, 3))

    print("\n===== 示例3：倒数位置超过长度 =====")
    数据 = (1, 2)
    print("结果:", 取倒数第N项(数据, 5))

    print("\n===== 示例4：倒数位置非法 =====")
    数据 = (1, 2, 3)
    print("结果:", 取倒数第N项(数据, 0))

    print("\n===== 示例5：空元组 =====")
    数据 = ()
    print("结果:", 取倒数第N项(数据, 1))

    print("\n===== 示例6：应用场景-取最近一次失败前的上一步状态 =====")
    状态流 = ("已创建", "已审核", "已支付", "已发货", "退款中")
    print("结果:", 取倒数第N项(状态流, 2))
