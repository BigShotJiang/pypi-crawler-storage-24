from typing import Any, Iterable, Tuple


def 是否包含任意成员(元组数据: Tuple[Any, ...], 候选成员组: Iterable[Any]) -> bool:
    """判断元组是否包含候选成员中的任意一个。

    Args:
        元组数据: 待检查的元组。
        候选成员组: 候选成员序列。

    Returns:
        命中任意成员时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return False

        候选列表 = tuple(候选成员组)
        if not 候选列表:
            return False
        return any(成员 in 元组数据 for 成员 in 候选列表)
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：命中其中一个成员 =====")
    数据 = ("a", "b", "c")
    print("结果:", 是否包含任意成员(数据, ("x", "b", "z")))

    print("\n===== 示例2：一个都没命中 =====")
    数据 = (1, 2, 3)
    print("结果:", 是否包含任意成员(数据, (8, 9)))

    print("\n===== 示例3：候选成员为空 =====")
    数据 = ("a", "b")
    print("结果:", 是否包含任意成员(数据, ()))

    print("\n===== 示例4：候选成员不是元组也可迭代 =====")
    数据 = ("a", "b", "c")
    print("结果:", 是否包含任意成员(数据, ["x", "y", "c"]))

    print("\n===== 示例5：复杂对象比较 =====")
    数据 = ([1], {"x": 1}, ("a",))
    print("结果:", 是否包含任意成员(数据, ({"x": 1}, "b")))

    print("\n===== 示例6：应用场景-检查用户是否拥有任一高权限 =====")
    用户权限 = ("查看", "编辑", "导出")
    高权限 = ("管理员", "超级管理员", "导出")
    print("结果:", 是否包含任意成员(用户权限, 高权限))
