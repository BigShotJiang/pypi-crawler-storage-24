from typing import Any, Tuple


def 取头项(元组数据: Tuple[Any, ...]):
    """返回元组的第一个成员。

    Args:
        元组数据: 待处理的元组。

    Returns:
        成功时返回第一个成员；元组为空或失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return None
        return 元组数据[0]
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：正常取头项 =====")
    数据 = ("头", "中", "尾")
    print("结果:", 取头项(数据))

    print("\n===== 示例2：空元组 =====")
    数据 = ()
    print("结果:", 取头项(数据))

    print("\n===== 示例3：数据不是元组 =====")
    数据 = ["头", "尾"]
    print("结果:", 取头项(数据))

    print("\n===== 示例4：单成员元组 =====")
    数据 = ("唯一",)
    print("结果:", 取头项(数据))

    print("\n===== 示例5：头项是复杂对象 =====")
    数据 = ({"a": 1}, "中", "尾")
    print("结果:", 取头项(数据))

    print("\n===== 示例6：应用场景-取队列中下一个任务 =====")
    任务队列 = ("同步订单", "抓取库存", "生成日报")
    print("结果:", 取头项(任务队列))
