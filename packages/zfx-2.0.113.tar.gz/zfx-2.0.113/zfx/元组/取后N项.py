from typing import Any, Tuple


def 取后N项(元组数据: Tuple[Any, ...], 数量: int):
    """返回元组后 N 项。

    Args:
        元组数据: 待处理的元组。
        数量: 需要截取的成员数量。

    Returns:
        成功时返回新元组；失败时返回空元组 ``()``。
    """
    try:
        if not isinstance(元组数据, tuple) or not isinstance(数量, int) or 数量 < 0:
            return ()
        if 数量 == 0:
            return ()
        return 元组数据[-数量:]
    except Exception:
        return ()


if __name__ == "__main__":
    print("===== 示例1：取后2项 =====")
    数据 = (1, 2, 3, 4, 5)
    print("结果:", 取后N项(数据, 2))

    print("\n===== 示例2：数量为0 =====")
    数据 = (1, 2, 3)
    print("结果:", 取后N项(数据, 0))

    print("\n===== 示例3：数量超过长度 =====")
    数据 = (1, 2)
    print("结果:", 取后N项(数据, 10))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 取后N项(数据, 3))

    print("\n===== 示例5：数量非法 =====")
    数据 = (1, 2, 3)
    print("结果:", 取后N项(数据, -1))

    print("\n===== 示例6：应用场景-取最近3条日志 =====")
    日志编号 = ("log-001", "log-002", "log-003", "log-004", "log-005")
    print("结果:", 取后N项(日志编号, 3))
