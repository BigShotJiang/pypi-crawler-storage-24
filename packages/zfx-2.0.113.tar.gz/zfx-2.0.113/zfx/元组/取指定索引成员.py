from typing import Any, Tuple


def 取指定索引成员(元组数据: Tuple[Any, ...], 索引: int):
    """返回指定索引位置的成员。

    Args:
        元组数据: 待处理的元组。
        索引: 目标索引，支持负索引。

    Returns:
        成功时返回对应成员；失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple) or not isinstance(索引, int):
            return None
        return 元组数据[索引]
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：取正向索引 =====")
    数据 = ("a", "b", "c")
    print("结果:", 取指定索引成员(数据, 1))

    print("\n===== 示例2：取负索引 =====")
    数据 = ("a", "b", "c")
    print("结果:", 取指定索引成员(数据, -1))

    print("\n===== 示例3：索引越界 =====")
    数据 = ("a", "b", "c")
    print("结果:", 取指定索引成员(数据, 99))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 取指定索引成员(数据, 0))

    print("\n===== 示例5：索引类型错误 =====")
    数据 = ("a", "b", "c")
    print("结果:", 取指定索引成员(数据, "1"))

    print("\n===== 示例6：应用场景-按字段位置读取用户邮箱 =====")
    用户记录 = (1001, "张三", "zhangsan@example.com", "技术部")
    print("结果:", 取指定索引成员(用户记录, 2))
