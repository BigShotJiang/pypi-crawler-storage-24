from typing import Any, Tuple


def 取尾项(元组数据: Tuple[Any, ...]):
    """返回元组的最后一个成员。

    Args:
        元组数据: 待处理的元组。

    Returns:
        成功时返回最后一个成员；元组为空或失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return None
        return 元组数据[-1]
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：正常取尾项 =====")
    数据 = ("头", "中", "尾")
    print("结果:", 取尾项(数据))

    print("\n===== 示例2：空元组 =====")
    数据 = ()
    print("结果:", 取尾项(数据))

    print("\n===== 示例3：数据不是元组 =====")
    数据 = ["头", "尾"]
    print("结果:", 取尾项(数据))

    print("\n===== 示例4：单成员元组 =====")
    数据 = ("唯一",)
    print("结果:", 取尾项(数据))

    print("\n===== 示例5：尾项是复杂对象 =====")
    数据 = ("头", "中", {"x": 1})
    print("结果:", 取尾项(数据))

    print("\n===== 示例6：应用场景-取最后一个处理结果 =====")
    处理结果 = ("已连接", "已鉴权", "已下载", "已完成")
    print("结果:", 取尾项(处理结果))
