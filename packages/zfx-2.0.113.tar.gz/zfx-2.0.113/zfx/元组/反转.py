from typing import Any, Tuple


def 反转(元组数据: Tuple[Any, ...]) -> Tuple[Any, ...]:
    """返回反转后的新元组。

    Args:
        元组数据: 要反转的元组。

    Returns:
        成功时返回反转后的新元组；失败时返回空元组 ``()``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return ()
        return tuple(reversed(元组数据))
    except Exception:
        return ()


if __name__ == "__main__":
    print("===== 示例1：基础反转 =====")
    数据 = (1, 2, 3, 4)
    print("结果:", 反转(数据))

    print("\n===== 示例2：空元组 =====")
    数据 = ()
    print("结果:", 反转(数据))

    print("\n===== 示例3：数据不是元组 =====")
    数据 = [1, 2, 3]
    print("结果:", 反转(数据))

    print("\n===== 示例4：单成员元组 =====")
    数据 = ("唯一",)
    print("结果:", 反转(数据))

    print("\n===== 示例5：包含嵌套对象 =====")
    数据 = ("a", [1, 2], {"x": 1})
    print("结果:", 反转(数据))

    print("\n===== 示例6：应用场景-按回滚顺序执行步骤 =====")
    部署步骤 = ("拉代码", "安装依赖", "构建", "发布")
    print("结果:", 反转(部署步骤))
