from numbers import Number
from typing import Any, Tuple


def 验证_全为数字(元组数据: Tuple[Any, ...]) -> bool:
    """验证元组成员是否全部为数字类型。

    Args:
        元组数据: 待验证的元组。

    Returns:
        全部为数字时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return False
        return all(isinstance(元素, Number) for 元素 in 元组数据)
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：全部为数字 =====")
    数据 = (1, 2.5, 3)
    print("结果:", 验证_全为数字(数据))

    print("\n===== 示例2：布尔值也会被视为数字 =====")
    数据 = (1, True, 3)
    print("结果:", 验证_全为数字(数据))

    print("\n===== 示例3：包含非数字 =====")
    数据 = (1, "2", 3)
    print("结果:", 验证_全为数字(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 验证_全为数字(数据))

    print("\n===== 示例5：复数也属于数字 =====")
    数据 = (1 + 2j, 3, 4.5)
    print("结果:", 验证_全为数字(数据))

    print("\n===== 示例6：应用场景-验证报表金额列是否全为数值 =====")
    金额列 = (1200.5, 980, 450.0, 300)
    print("结果:", 验证_全为数字(金额列))
