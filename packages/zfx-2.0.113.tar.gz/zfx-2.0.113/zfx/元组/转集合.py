from typing import Any, Set, Tuple


def 转集合(元组数据: Tuple[Any, ...]) -> Set[Any]:
    """将元组转换为集合。

    Args:
        元组数据: 待转换的元组。

    Returns:
        成功时返回集合；失败时返回空集合 ``set()``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return set()
        return set(元组数据)
    except Exception:
        return set()


if __name__ == "__main__":
    print("===== 示例1：普通转换 =====")
    数据 = (1, 2, 2, 3)
    print("结果:", 转集合(数据))

    print("\n===== 示例2：包含不可哈希成员 =====")
    数据 = (1, [2], 3)
    print("结果:", 转集合(数据))

    print("\n===== 示例3：数据不是元组 =====")
    数据 = [1, 2, 3]
    print("结果:", 转集合(数据))

    print("\n===== 示例4：空元组转换 =====")
    数据 = ()
    print("结果:", 转集合(数据))

    print("\n===== 示例5：字符串去重效果 =====")
    数据 = ("a", "b", "a", "c")
    print("结果:", 转集合(数据))

    print("\n===== 示例6：应用场景-提取所有不重复角色 =====")
    角色列表 = ("管理员", "编辑", "访客", "管理员", "编辑")
    print("结果:", 转集合(角色列表))
