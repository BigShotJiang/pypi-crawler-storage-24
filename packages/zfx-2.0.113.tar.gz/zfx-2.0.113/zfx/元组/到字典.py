from typing import Any, Dict, Tuple


def 到字典(元组数据: Tuple[Tuple[Any, Any], ...]) -> Dict[Any, Any]:
    """将二元键值对元组转换为字典。

    Args:
        元组数据: 由多个二元元组组成的元组，例如 ``((键1, 值1), (键2, 值2))``。

    Returns:
        转换成功时返回字典；失败时返回空字典 ``{}``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return {}

        结果 = {}
        for 项 in 元组数据:
            if not isinstance(项, tuple) or len(项) != 2:
                return {}
            键, 值 = 项
            结果[键] = 值
        return 结果
    except Exception:
        return {}


if __name__ == "__main__":
    print("===== 示例1：正常转换 =====")
    数据 = (("a", 1), ("b", 2))
    print("结果:", 到字典(数据))

    print("\n===== 示例2：重复键后者覆盖前者 =====")
    数据 = (("a", 1), ("a", 999), ("b", 2))
    print("结果:", 到字典(数据))

    print("\n===== 示例3：结构不合法 =====")
    数据 = (("a", 1), ("b", 2, 3))
    print("结果:", 到字典(数据))

    print("\n===== 示例4：空元组转换 =====")
    数据 = ()
    print("结果:", 到字典(数据))

    print("\n===== 示例5：键不可哈希会失败 =====")
    数据 = ((["x"], 1), ("b", 2))
    print("结果:", 到字典(数据))

    print("\n===== 示例6：应用场景-把配置项转为字典 =====")
    配置项 = (
        ("host", "127.0.0.1"),
        ("port", 3306),
        ("user", "root"),
        ("debug", True),
    )
    print("结果:", 到字典(配置项))
