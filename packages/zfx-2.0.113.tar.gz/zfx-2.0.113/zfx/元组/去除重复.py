from typing import Any, Tuple


def 去除重复(元组数据: Tuple[Any, ...]) -> Tuple[Any, ...]:
    """去除重复成员并保持首次出现顺序。

    Args:
        元组数据: 待处理的元组。

    Returns:
        成功时返回去重后的新元组；失败时返回空元组 ``()``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return ()

        结果 = []
        for 元素 in 元组数据:
            if 元素 not in 结果:
                结果.append(元素)
        return tuple(结果)
    except Exception:
        return ()


if __name__ == "__main__":
    print("===== 示例1：基础去重 =====")
    数据 = (1, 2, 2, 3, 1, 4)
    print("结果:", 去除重复(数据))

    print("\n===== 示例2：保留首次出现顺序 =====")
    数据 = ("a", "b", "a", "c", "b")
    print("结果:", 去除重复(数据))

    print("\n===== 示例3：包含不可哈希成员 =====")
    数据 = ([1], [1], {"a": 1}, {"a": 1})
    print("结果:", 去除重复(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 去除重复(数据))

    print("\n===== 示例5：布尔值与数字相等性 =====")
    数据 = (0, False, 1, True, 2)
    print("结果:", 去除重复(数据))

    print("\n===== 示例6：应用场景-清洗搜索关键词历史 =====")
    搜索词 = ("苹果", "手机", "苹果", "电脑", "手机", "耳机")
    print("结果:", 去除重复(搜索词))
