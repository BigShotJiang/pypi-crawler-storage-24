from typing import Any, List, Tuple


def 转列表(元组数据: Tuple[Any, ...]) -> List[Any]:
    """将元组转换为列表。

    Args:
        元组数据: 要转换的元组。

    Returns:
        成功时返回列表；失败时返回空列表 ``[]``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return []
        return list(元组数据)
    except Exception:
        return []


if __name__ == "__main__":
    print("===== 示例1：普通转换 =====")
    数据 = (1, 2, 3)
    print("结果:", 转列表(数据))

    print("\n===== 示例2：包含嵌套对象 =====")
    数据 = ("a", [1, 2], {"x": 1})
    print("结果:", 转列表(数据))

    print("\n===== 示例3：数据不是元组 =====")
    数据 = [1, 2, 3]
    print("结果:", 转列表(数据))

    print("\n===== 示例4：空元组转换 =====")
    数据 = ()
    print("结果:", 转列表(数据))

    print("\n===== 示例5：单成员元组 =====")
    数据 = ("唯一",)
    print("结果:", 转列表(数据))

    print("\n===== 示例6：应用场景-把只读任务序列转成可编辑列表 =====")
    任务元组 = ("抓单", "发货", "回传物流")
    print("结果:", 转列表(任务元组))
