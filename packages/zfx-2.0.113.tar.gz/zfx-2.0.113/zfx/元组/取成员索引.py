from typing import Any, Tuple


def 取成员索引(元组数据: Tuple[Any, ...], 成员: Any):
    """返回指定成员首次出现的索引。

    Args:
        元组数据: 待查找的元组。
        成员: 要查找的成员。

    Returns:
        找到时返回索引整数；未找到或失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return None
        return 元组数据.index(成员)
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：正常查找 =====")
    数据 = ("a", "b", "c")
    print("结果:", 取成员索引(数据, "b"))

    print("\n===== 示例2：成员不存在 =====")
    数据 = ("a", "b", "c")
    print("结果:", 取成员索引(数据, "x"))

    print("\n===== 示例3：相等性影响 =====")
    数据 = (0, False, 1)
    print("结果:", 取成员索引(数据, False))

    print("\n===== 示例4：复杂对象查找 =====")
    数据 = ([1], {"x": 1}, [2])
    print("结果:", 取成员索引(数据, {"x": 1}))

    print("\n===== 示例5：空元组 =====")
    数据 = ()
    print("结果:", 取成员索引(数据, "a"))

    print("\n===== 示例6：应用场景-定位指定流程节点位置 =====")
    流程节点 = ("待创建", "待审核", "待支付", "待发货", "已完成")
    print("结果:", 取成员索引(流程节点, "待发货"))
