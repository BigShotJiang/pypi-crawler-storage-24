from typing import Any, Tuple


def 转字符串(元组数据: Tuple[Any, ...], 分隔符: str = ", "):
    """将元组成员转换并拼接为字符串。

    Args:
        元组数据: 待转换的元组。
        分隔符: 成员拼接时使用的分隔符，默认为 ``, ``。

    Returns:
        成功时返回拼接后的字符串；失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple) or not isinstance(分隔符, str):
            return None
        return 分隔符.join(str(元素) for 元素 in 元组数据)
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：默认分隔符 =====")
    数据 = ("a", "b", "c")
    print("结果:", 转字符串(数据))

    print("\n===== 示例2：自定义分隔符 =====")
    数据 = (1, 2, 3)
    print("结果:", 转字符串(数据, " | "))

    print("\n===== 示例3：分隔符类型错误 =====")
    数据 = ("a", "b")
    print("结果:", 转字符串(数据, 123))

    print("\n===== 示例4：空元组转换 =====")
    数据 = ()
    print("结果:", 转字符串(数据))

    print("\n===== 示例5：包含复杂对象 =====")
    数据 = ("a", [1, 2], {"x": 1})
    print("结果:", 转字符串(数据, " / "))

    print("\n===== 示例6：应用场景-拼接生成日志摘要 =====")
    日志信息 = ("订单同步", "成功", "耗时120ms", "重试0次")
    print("结果:", 转字符串(日志信息, " | "))
