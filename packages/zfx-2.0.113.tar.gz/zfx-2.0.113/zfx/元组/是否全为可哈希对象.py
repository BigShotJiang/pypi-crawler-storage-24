from typing import Any, Tuple


def 是否全为可哈希对象(元组数据: Tuple[Any, ...]) -> bool:
    """判断元组成员是否全部可哈希。

    Args:
        元组数据: 待验证的元组。

    Returns:
        全部可哈希时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return False

        for 元素 in 元组数据:
            hash(元素)
        return True
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：全部可哈希 =====")
    数据 = ("a", 1, (2, 3))
    print("结果:", 是否全为可哈希对象(数据))

    print("\n===== 示例2：包含列表 =====")
    数据 = ("a", [1, 2], 3)
    print("结果:", 是否全为可哈希对象(数据))

    print("\n===== 示例3：包含字典 =====")
    数据 = ("a", {"x": 1}, 3)
    print("结果:", 是否全为可哈希对象(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 是否全为可哈希对象(数据))

    print("\n===== 示例5：嵌套元组中含不可哈希成员 =====")
    数据 = ((1, 2), ([3],), "ok")
    print("结果:", 是否全为可哈希对象(数据))

    print("\n===== 示例6：应用场景-验证标签是否都可作为字典键 =====")
    标签集合 = ("已支付", "待发货", "高优先级")
    print("结果:", 是否全为可哈希对象(标签集合))
