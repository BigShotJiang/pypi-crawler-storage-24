from typing import Any, Tuple


def 取最小值及索引(元组数据: Tuple[Any, ...]):
    """返回元组中的最小值及其索引。

    说明:
        当最小值出现多次时，返回首次出现的位置。

    Args:
        元组数据: 待处理的元组。

    Returns:
        成功时返回 ``(最小值, 索引, True)``；失败时返回 ``(None, None, False)``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return None, None, False

        最小值 = 元组数据[0]
        最小值索引 = 0
        for 索引, 元素 in enumerate(元组数据[1:], start=1):
            if 元素 < 最小值:
                最小值 = 元素
                最小值索引 = 索引
        return 最小值, 最小值索引, True
    except Exception:
        return None, None, False


if __name__ == "__main__":
    print("===== 示例1：基础最小值及索引 =====")
    数据 = (3, 9, 1, 6)
    print("结果:", 取最小值及索引(数据))

    print("\n===== 示例2：最小值重复时取首次索引 =====")
    数据 = (5, 1, 9, 1, 3)
    print("结果:", 取最小值及索引(数据))

    print("\n===== 示例3：字符串比较 =====")
    数据 = ("apple", "pear", "banana")
    print("结果:", 取最小值及索引(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 取最小值及索引(数据))

    print("\n===== 示例5：混合不可比较类型 =====")
    数据 = (1, "2", 3)
    print("结果:", 取最小值及索引(数据))

    print("\n===== 示例6：应用场景-找出库存最低的仓位位置 =====")
    仓位库存 = (55, 12, 88, 6, 34)
    print("结果:", 取最小值及索引(仓位库存))
