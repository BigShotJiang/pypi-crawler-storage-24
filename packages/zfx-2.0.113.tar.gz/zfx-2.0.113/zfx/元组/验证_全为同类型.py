from typing import Any, Tuple


def 验证_全为同类型(元组数据: Tuple[Any, ...]) -> bool:
    """验证元组成员是否全部属于同一类型。

    Args:
        元组数据: 待验证的元组。

    Returns:
        元组为空时返回 ``False``；全部同类型时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return False

        首项类型 = type(元组数据[0])
        return all(type(元素) is 首项类型 for 元素 in 元组数据)
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：全部同类型 =====")
    数据 = ("a", "b", "c")
    print("结果:", 验证_全为同类型(数据))

    print("\n===== 示例2：bool 与 int 不算同类型 =====")
    数据 = (1, True, 3)
    print("结果:", 验证_全为同类型(数据))

    print("\n===== 示例3：空元组 =====")
    数据 = ()
    print("结果:", 验证_全为同类型(数据))

    print("\n===== 示例4：全部为 list 类型 =====")
    数据 = ([1], [2], [3])
    print("结果:", 验证_全为同类型(数据))

    print("\n===== 示例5：父子类也按不同类型处理 =====")
    class 父类:
        pass

    class 子类(父类):
        pass

    数据 = (父类(), 子类())
    print("结果:", 验证_全为同类型(数据))

    print("\n===== 示例6：应用场景-验证导入的手机号是否全是字符串 =====")
    手机号数据 = ("13800000001", "13800000002", "13800000003")
    print("结果:", 验证_全为同类型(手机号数据))
