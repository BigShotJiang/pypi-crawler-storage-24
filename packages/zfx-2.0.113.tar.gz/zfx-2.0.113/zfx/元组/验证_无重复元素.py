from typing import Any, Tuple


def 验证_无重复元素(元组数据: Tuple[Any, ...]) -> bool:
    """验证元组中是否不存在重复元素。

    Args:
        元组数据: 要验证的元组。

    Returns:
        不存在重复元素时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return False

        已见成员 = []
        for 元素 in 元组数据:
            if 元素 in 已见成员:
                return False
            已见成员.append(元素)
        return True
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：没有重复 =====")
    数据 = (1, 2, 3, 4)
    print("结果:", 验证_无重复元素(数据))

    print("\n===== 示例2：存在重复 =====")
    数据 = ("a", "b", "a")
    print("结果:", 验证_无重复元素(数据))

    print("\n===== 示例3：不可哈希成员也可判断 =====")
    数据 = ([1], [2], [1])
    print("结果:", 验证_无重复元素(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 验证_无重复元素(数据))

    print("\n===== 示例5：布尔值与数字相等性 =====")
    数据 = (0, False, 1)
    print("结果:", 验证_无重复元素(数据))

    print("\n===== 示例6：应用场景-检查订单编号是否存在重复 =====")
    订单编号 = ("ORD-001", "ORD-002", "ORD-003", "ORD-002")
    print("结果:", 验证_无重复元素(订单编号))
