from typing import Any, Tuple


def 是否包含(元组数据: Tuple[Any, ...], 成员: Any) -> bool:
    """判断元组中是否包含指定成员。

    Args:
        元组数据: 待查询的元组。
        成员: 要查找的成员。

    Returns:
        包含时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return False
        return 成员 in 元组数据
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：正常包含判断 =====")
    数据 = ("a", "b", "c")
    print("结果:", 是否包含(数据, "b"))

    print("\n===== 示例2：不存在的成员 =====")
    数据 = ("a", "b", "c")
    print("结果:", 是否包含(数据, "x"))

    print("\n===== 示例3：相等性陷阱 =====")
    数据 = (0, 1, 2)
    print("结果:", 是否包含(数据, False))

    print("\n===== 示例4：复杂对象查找 =====")
    数据 = ([1], {"x": 1}, ("a",))
    print("结果:", 是否包含(数据, {"x": 1}))

    print("\n===== 示例5：空元组 =====")
    数据 = ()
    print("结果:", 是否包含(数据, "a"))

    print("\n===== 示例6：应用场景-检查用户权限中是否包含管理员 =====")
    权限列表 = ("查看", "编辑", "导出", "管理员")
    print("结果:", 是否包含(权限列表, "管理员"))
