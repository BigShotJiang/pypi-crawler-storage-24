from typing import Any, Tuple


def 取最小值(元组数据: Tuple[Any, ...]):
    """返回元组中的最小值。

    Args:
        元组数据: 待处理的元组。

    Returns:
        成功时返回最小值；元组为空或失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return None
        return min(元组数据)
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：基础最小值 =====")
    数据 = (3, 9, 1, 6)
    print("结果:", 取最小值(数据))

    print("\n===== 示例2：字符串比较 =====")
    数据 = ("apple", "pear", "banana")
    print("结果:", 取最小值(数据))

    print("\n===== 示例3：混合不可比较类型 =====")
    数据 = (1, "2", 3)
    print("结果:", 取最小值(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 取最小值(数据))

    print("\n===== 示例5：布尔值与数字混合 =====")
    数据 = (False, 2, True, 1)
    print("结果:", 取最小值(数据))

    print("\n===== 示例6：应用场景-找出最低库存值 =====")
    库存数量 = (55, 12, 88, 6, 34)
    print("结果:", 取最小值(库存数量))
