from typing import Any, Tuple


def 取长度(元组数据: Tuple[Any, ...]):
    """返回元组成员数量。

    Args:
        元组数据: 待处理的元组。

    Returns:
        成功时返回长度整数；失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return None
        return len(元组数据)
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：普通元组长度 =====")
    数据 = (1, 2, 3, 4)
    print("结果:", 取长度(数据))

    print("\n===== 示例2：空元组长度 =====")
    数据 = ()
    print("结果:", 取长度(数据))

    print("\n===== 示例3：数据不是元组 =====")
    数据 = [1, 2, 3]
    print("结果:", 取长度(数据))

    print("\n===== 示例4：单成员元组 =====")
    数据 = ("唯一",)
    print("结果:", 取长度(数据))

    print("\n===== 示例5：嵌套对象只算成员个数 =====")
    数据 = ("a", [1, 2], {"x": 1})
    print("结果:", 取长度(数据))

    print("\n===== 示例6：应用场景-统计待处理任务总数 =====")
    待处理任务 = ("抓单", "对账", "发货", "回传物流", "通知客户")
    print("结果:", 取长度(待处理任务))
