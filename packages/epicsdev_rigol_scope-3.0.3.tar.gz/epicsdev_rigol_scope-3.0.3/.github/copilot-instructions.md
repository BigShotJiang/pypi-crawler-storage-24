# Copilot Instructions — epicsdev_rigol_scope

## Overview
Python EPICS PVAccess server for RIGOL oscilloscopes. Bridges **VISA/SCPI** instrument communication to **EPICS PVs** using the [`epicsdev`](https://github.com/ASukhanov/epicsdev) framework (built on `p4p`). All server logic lives in a single file: [`epicsdev_rigol_scope/__main__.py`](../epicsdev_rigol_scope/__main__.py).

## Architecture & Data Flow
```
RIGOL scope (VISA/SCPI)
  ↕  pyvisa (Threadlock-protected)
__main__.py  →  edev.publish() → EPICS PVAccess network
                ↑
              poll() → trigger_is_detected() → acquire_waveforms()
              periodicUpdate()  (infrequent: scope params, timing)
```
- `C_` is a **module-level namespace class** (not instantiated) holding shared state: `C_.scope`, `C_.scpi`, `C_.channelsTriggered`, etc.
- `Threadlock` (threading.Lock) guards **all** VISA calls — never call `C_.scope.write/query` without `with Threadlock:`.

## PV Definition Pattern
PVs are declared in `myPVDefs()` as lists:
```python
['pvName', 'description', initial_value, {options}]
```
Option keys: `'features'` (`W`=writable, `D`=discrete/enum), `'setter'` (callback), `'units'`, `'limitLow'`/`'limitHigh'`, `'scpi'` (maps PV to SCPI command), `'valueAlarm'`.

**Channel PVs** use `<n>` placeholder in `ChannelTemplates`; it is expanded per channel at startup:
```python
['c<n>VoltsPerDiv', 'Vertical scale', 1e-3, {F:'W', SCPI:'CHANnel<n>:SCALe', SET:set_scpi}]
# → c01VoltsPerDiv, c02VoltsPerDiv, ...
```

## SCPI Conventions
- `scpi` values in pvDefs are mixed-case (human-readable); at runtime, **lowercase letters are stripped** to produce the actual SCPI string (e.g., `'ACQuire:SRATe'` → `'ACQ:SRAT'`).
- Combined queries join multiple SCPIs: `'SCPI1?;:SCPI2?;:SCPI3?'` — parsed by splitting on `';'`.
- The generic setter `set_scpi(value, pv)` resolves the SCPI from `C_.scpi[pv.name]` and replaces `<n>` with `pv.name[2]` (the channel digit).

## Key epicsdev API
```python
edev.init_epicsdev(prefix, pvDefs, verbose, serverStateChanged, None, autosave, recall, putlogPV)
edev.publish('pvName', value)          # push value to network
edev.pvv('pvName')                     # read current PV value
edev.pvobj('pvName')                   # get PV object (has .post(), .current())
edev.set_server('Start'|'Stop'|'Exit') # control server lifecycle
edev.printi/printw/printe/printv/printvv(msg)  # leveled logging
```
`serverStateChanged('Start')` calls `configure_scope()` → `adopt_local_setting()` → `:RUN`.

## Running
```bash
# Start the server (INSTR or SOCKET resource):
python -m epicsdev_rigol_scope -r 'TCPIP::192.168.27.31::INSTR'
python -m epicsdev_rigol_scope -r 'TCPIP::192.168.27.31::5555::SOCKET' -d rigol -i 0

# Launch control GUI (requires pypeto):
python -m pypeto -irigol0: -c<repo>/config -fepicsScope

# Launch waveform plots (requires pvplot):
python -m pvplot -aV:rigol0: -#0"c01Peak2Peak c02Peak2Peak" -#1"c01Waveform c02Waveform"
```
PV names follow the pattern `<device><index>:<pvname>` (default: `rigol0:trigLevel`).

## Build & Install
```bash
pip install epicsdev_rigol_scope        # from PyPI
pip install -e .                        # editable install (uses hatchling)
pip install pypeto pvplot               # optional GUI/plotting tools
```
Dependencies: `p4p`, `epicsdev>=3.0.1`, `pyvisa`.

## Config Files
- [`config/epicsScope_pp.py`](../config/epicsScope_pp.py) — generic pypeto page class for any epicsdev oscilloscope server; reused across instruments.
- [`config/epicsdev_rigol_scope_pp.py`](../config/epicsdev_rigol_scope_pp.py) — thin wrapper that binds `epicsScope_pp.PyPage` to `rigol0:` instance.

## VISA Resource Notes
- `SOCKET` resource (port 5555) gives ~50% higher throughput than `INSTR`.
- If SOCKET connection fails: disable the VXI-11 server on the instrument.
- `C_.scope.read_termination = '\n'` and `write_termination = '\n'` are required.
- Timeout is set to 2000 ms; `*CLS` is sent on init and after VISA exceptions.
