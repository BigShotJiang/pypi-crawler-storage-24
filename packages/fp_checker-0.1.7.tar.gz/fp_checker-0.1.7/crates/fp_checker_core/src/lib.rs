mod assessment;
mod checker;
mod config;
mod model;
mod parser;
mod report;
mod rules;

pub use checker::{check_code, check_path, CheckerError};
pub use config::{
    discover_config, load_config_from_path, AllowlistsConfig, CheckerConfig, ConfigError,
    CustomRuleConfig, CustomRuleMatchType, CustomRuleTarget, OutputFormat, PurityConfig,
    PuritySeverityConfig, StyleConfig, StyleSeverityConfig, UnknownCallBehavior,
};
pub use model::{
    Diagnostic, ExternalPurityAssessment, ExternalPurityCategory, ExternalPurityReason, FixHint,
    FixKind, FunctionAssessment, FunctionDef, IgnoreDirective, ImplementationStyleAssessment,
    ImplementationStyleCategory, Module, Parameter, ParameterKind, RuleId, Severity,
    SourceLocation, SourceSpan, StyleMetrics,
};
pub use parser::{ParseOutcome, ParserAdapter, RustPythonParser};
pub use report::{render_report, FileReport, Report, Summary};
