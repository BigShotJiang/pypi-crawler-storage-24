# MCP Service

A Model Context Protocol (MCP) service for data retrieval and query operations.

## Features

- Query data from external sources
- Retrieve real-time information
- Support multiple data sources
- Flexible query parameters

## Installation

```bash
pip install bus-query-mcp
```

Or using uv:

```bash
uv pip install bus-query-mcp
```

## Usage

### Start MCP Server

```bash
bus-query-mcp
```

### Available Tools

#### 1. search_data

Search for available data records.

**Parameters:**
- `key` (str): Search keyword

**Returns:**
- List of matching records with details

#### 2. get_location_info

Query real-time location information.

**Parameters:**
- `detail_url` (str): Detail URL for precise query
- `direction` (str, optional): Query direction

**Returns:**
- Location information with coordinates

#### 3. get_record_info

Query basic record information.

**Parameters:**
- `detail_url` (str): Detail URL for precise query

**Returns:**
- Basic information about the record

## Dependencies

- Python >= 3.10
- aiohttp >= 3.9.0
- mcp >= 0.9.0
- beautifulsoup4 >= 4.12.0

## Development

### Install Dependencies

```bash
pip install -e .
```

### Run Tests

```bash
python -m bus_query_mcp.main
```

## License

MIT License

## Notes

- This service is for educational purposes
- Please respect rate limits
- Data accuracy may vary