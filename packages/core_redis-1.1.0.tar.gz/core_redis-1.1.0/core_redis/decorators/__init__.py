# -*- coding: utf-8 -*-

"""Reusable decorators for caching function results to Redis."""

from core_redis.decorators.cache_redis_based import cache_redis_based


__all__ = [
    "cache_redis_based",
]
