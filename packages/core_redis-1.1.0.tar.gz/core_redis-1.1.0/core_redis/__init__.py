# -*- coding: utf-8 -*-

"""Redis integration utilities."""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version

from core_redis.client import RedisClient

try:
    __version__ = version("core-redis")

except PackageNotFoundError:
    __version__ = "unknown"


__all__ = [
    "RedisClient",
]
