"""DialogBrain Python SDK."""
from dialogbrain._client import DialogBrainClient
from dialogbrain._webhooks import verify_webhook

__all__ = ["DialogBrainClient", "verify_webhook", "get_langchain_tools"]


def get_langchain_tools(api_key: str, base_url: str = "https://api.dialogbrain.com"):
    """
    Async context manager that yields LangChain-compatible tools from DialogBrain's MCP server.

    Requires: pip install "dialogbrain[langchain]"

    Usage:
        async with get_langchain_tools(api_key="db_live_...") as tools:
            agent = create_react_agent(llm, tools)
            result = await agent.ainvoke({"messages": [{"role": "user", "content": "..."}]})
    """
    from dialogbrain._langchain import get_langchain_tools as _get
    return _get(api_key=api_key, base_url=base_url)
