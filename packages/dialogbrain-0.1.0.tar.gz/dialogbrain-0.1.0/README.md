# DialogBrain Python SDK

Python client for the [DialogBrain](https://dialogbrain.com) messaging API.

## Install

```bash
pip install dialogbrain

# With LangChain/MCP support:
pip install "dialogbrain[langchain]"
```

## Quick Start

```python
import asyncio
from dialogbrain import DialogBrainClient

async def main():
    async with DialogBrainClient(api_key="db_live_YOUR_KEY") as client:
        conversations = await client.conversations.list()
        await client.messages.send(
            thread_id=conversations[0]["id"],
            message_text="Hello from Python!",
        )

asyncio.run(main())
```

## Docs

Full documentation at [docs.dialogbrain.com](https://docs.dialogbrain.com/integrations/python-sdk)
