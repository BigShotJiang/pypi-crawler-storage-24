# Milestones

## v1.2 Performance (Shipped: 2026-03-20)

**Phases completed:** 4 phases, 5 plans, 8 tasks

**Key accomplishments:**

- Bounded ThreadPoolExecutor(max_workers=2) replaces unbounded threading.Thread in Telegram log sink, with dedicated 3s timeout to prevent thread exhaustion during kintsugi batch repairs
- Thread-local CH cache eliminates per-call fd churn in kintsugi workers, and 3-tier concurrency control prevents REST-only shards from diluting Parquet/Vision throughput
- Zero-allocation FixedPoint::from_f64() eliminates 4M allocs/day, cached CSV decompression removes O(N^2) ZIP re-parsing in IntraDayChunkIterator
- Eliminate per-iteration Vec::with_capacity(32) allocation in WS select loop via clear()+reuse pattern (RUST-03)
- Cached kintsugi config per repair (3 instantiations eliminated), dynamic Vision 404 TTL (15min for T-2 dates), and removed redundant DataFrame copy in bulk operations

## v1.3 Atomic Restart Recovery (In Progress)

**Goal:** Every sidecar restart produces a clean bar chain for today -- zero gaps, zero overlaps, zero legacy fragments.

**Phases:** 2 phases

| Phase | Name                          | Requirements                       |
| ----- | ----------------------------- | ---------------------------------- |
| 1     | Atomic Replace + Heal Scoping | ATOM-01, ATOM-02, HEAL-01, HEAL-02 |
| 2     | Legacy Pruning                | PRUNE-01..04                       |

---
