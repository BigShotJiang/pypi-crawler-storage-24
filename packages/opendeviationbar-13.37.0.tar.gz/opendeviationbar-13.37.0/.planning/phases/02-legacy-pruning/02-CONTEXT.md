# Phase 2: Legacy Pruning - Context

**Gathered:** 2026-03-20
**Status:** Ready for planning

<domain>
## Phase Boundary

Delete dead restart-gap code paths from sidecar.py. Remove `_inline_startup_backfill()` (never called), `_startup_tid_reconciliation()` (redundant with fill_from_rest), `_gap_fill()` from watchdog restart path, and dead `gap_fill_on_startup` config field.

</domain>

<decisions>
## Implementation Decisions

### Claude's Discretion

All implementation choices are at Claude's discretion — pure dead code deletion phase.

### Safety

- Verify each function is truly dead before deleting (grep for call sites)
- Run existing tests after each deletion to catch unexpected breakage
- `_gap_fill()` is NOT deleted — only its call in `_restart_engine_with_recovery()` is removed

</decisions>

<code_context>

## Existing Code Insights

### Functions to Delete

- `python/opendeviationbar/sidecar.py:528-615` — `_inline_startup_backfill()` (never called, superseded by fill_from_rest #286)
- `python/opendeviationbar/sidecar.py:708-759` — `_startup_tid_reconciliation()` (redundant; call site at line ~2241)

### Call Sites to Remove

- `python/opendeviationbar/sidecar.py:~1123` — `_gap_fill()` call in `_restart_engine_with_recovery()` (pass `gap_fill_results=None` to `_create_engine` instead)
- `python/opendeviationbar/sidecar.py:~2241` — `_startup_tid_reconciliation()` call in `run_sidecar()`

### Config to Remove

- `python/opendeviationbar/config/sidecar.py` — `gap_fill_on_startup` field (dead, never read in run_sidecar)

### Integration Points

- `_inject_checkpoints()` accepts `gap_fill_results` parameter — still needed for API but watchdog path should pass `None`
- Tests in `test_sidecar.py` reference `_inject_checkpoints` with gap_fill_results — may need updating

</code_context>

<specifics>
## Specific Ideas

No specific requirements — infrastructure phase.

</specifics>

<deferred>
## Deferred Ideas

None — discussion stayed within phase scope.

</deferred>
