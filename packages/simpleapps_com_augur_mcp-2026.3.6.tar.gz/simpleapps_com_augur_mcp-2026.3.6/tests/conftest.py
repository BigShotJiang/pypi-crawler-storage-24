"""Shared fixtures for MCP server tests."""

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from augur_mcp import server


@pytest.fixture(autouse=True)
def _reset_server_state():
    """Reset module-level state before each test."""
    server.reset_state()
    yield
    server.reset_state()


@pytest.fixture()
def endpoints_dir():
    """Path to the shared specs directory (used by load_specs)."""
    specs_dir = Path(__file__).parent.parent.parent.parent / "shared" / "specs"
    if specs_dir.is_dir():
        return specs_dir
    # Fallback to bundled endpoints for CI
    return Path(__file__).parent.parent / "src" / "augur_mcp" / "endpoints"


@pytest.fixture()
def mock_api():
    """Create a mock AugurAPI instance with config.site_id set."""
    api = MagicMock()
    api.config.site_id = "test-site"
    return api
