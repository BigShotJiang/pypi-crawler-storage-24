"""Tests for the spec-based router module."""

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, PropertyMock

import pytest

from augur_mcp.router import (
    _camel_to_snake,
    _kebab_to_snake,
    _resolve_method_name,
    get_resource_map,
    get_resource_map_from_spec,
    load_catalog,
    load_descriptions,
    load_specs,
    resolve_and_call,
)


# --- _camel_to_snake ---


class TestCamelToSnake:
    def test_simple(self):
        assert _camel_to_snake("invMast") == "inv_mast"

    def test_multiple_humps(self):
        assert _camel_to_snake("invMastAttributeValues") == "inv_mast_attribute_values"

    def test_already_lowercase(self):
        assert _camel_to_snake("settings") == "settings"

    def test_single_char(self):
        assert _camel_to_snake("a") == "a"

    def test_leading_upper(self):
        assert _camel_to_snake("Doc") == "doc"


# --- _kebab_to_snake ---


class TestKebabToSnake:
    def test_simple(self):
        assert _kebab_to_snake("agr-site") == "agr_site"

    def test_multiple_hyphens(self):
        assert _kebab_to_snake("geo-codes-postal-codes") == "geo_codes_postal_codes"

    def test_no_hyphens(self):
        assert _kebab_to_snake("items") == "items"

    def test_single_char(self):
        assert _kebab_to_snake("a") == "a"


# --- load_specs ---


class TestLoadSpecs:
    def test_load_from_temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            spec = {"service": "test-svc", "endpoints": [{"chain": "settings", "action": "list", "method": "GET", "path": "/api/settings"}]}
            spec_file = Path(tmpdir) / "test-svc.json"
            spec_file.write_text(json.dumps(spec))

            catalog = load_specs(Path(tmpdir))
            assert "test-svc" in catalog
            assert catalog["test-svc"]["service"] == "test-svc"
            assert len(catalog["test-svc"]["endpoints"]) == 1

    def test_load_multiple_specs(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            for name in ["alpha", "beta"]:
                spec = {"service": name, "endpoints": []}
                (Path(tmpdir) / f"{name}.json").write_text(json.dumps(spec))

            catalog = load_specs(Path(tmpdir))
            assert len(catalog) == 2
            assert "alpha" in catalog
            assert "beta" in catalog

    def test_load_empty_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            catalog = load_specs(Path(tmpdir))
            assert catalog == {}

    def test_load_nonexistent_dir(self):
        catalog = load_specs(Path("/nonexistent"))
        assert catalog == {}


# --- load_descriptions ---


class TestLoadDescriptions:
    def test_load_custom_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            desc_file = Path(tmpdir) / "descriptions.json"
            desc_file.write_text(json.dumps({"test-svc": "A test service"}))
            descriptions = load_descriptions(Path(tmpdir))
            assert descriptions == {"test-svc": "A test service"}

    def test_load_empty_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            descriptions = load_descriptions(Path(tmpdir))
            assert descriptions == {}

    def test_load_nonexistent_dir(self):
        descriptions = load_descriptions(Path("/nonexistent"))
        assert descriptions == {}

    def test_load_non_dict_json(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            desc_file = Path(tmpdir) / "descriptions.json"
            desc_file.write_text(json.dumps([1, 2, 3]))
            descriptions = load_descriptions(Path(tmpdir))
            assert descriptions == {}

    def test_load_filters_non_string_values(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            desc_file = Path(tmpdir) / "descriptions.json"
            desc_file.write_text(json.dumps({"good": "desc", "bad": 123}))
            descriptions = load_descriptions(Path(tmpdir))
            assert descriptions == {"good": "desc"}

    def test_load_bundled(self):
        """Load descriptions from bundled package data (not specs dir)."""
        descriptions = load_descriptions()
        assert len(descriptions) == 27
        assert "items" in descriptions
        assert "agr-site" in descriptions

    def test_load_default_path(self):
        descriptions = load_descriptions()
        assert len(descriptions) == 27


# --- _resolve_method_name ---


class TestResolveMethodName:
    def test_top_level_list(self):
        assert _resolve_method_name("invMast", "list", None) == "list"

    def test_top_level_get(self):
        assert _resolve_method_name("invMast", "get", None) == "get"

    def test_top_level_create(self):
        assert _resolve_method_name("settings", "create", None) == "create"

    def test_one_level_nested_list(self):
        assert _resolve_method_name("invMast.doc", "list", None) == "list_doc"

    def test_one_level_nested_get(self):
        assert _resolve_method_name("invMast.doc", "get", None) == "get_doc"

    def test_two_level_nested_list(self):
        assert _resolve_method_name("invMast.attributes.values", "list", None) == "list_attributes_values"

    def test_two_level_nested_get(self):
        assert _resolve_method_name("invMast.attributes.values", "get", None) == "get_attributes_values"

    def test_camel_suffix_converted(self):
        assert _resolve_method_name("invMast.attributeValues", "list", None) == "list_attribute_values"


# --- resolve_and_call ---


class TestResolveAndCall:
    def test_unknown_service(self):
        api = MagicMock(spec=[])
        with pytest.raises(ValueError, match="Unknown service"):
            resolve_and_call(api, "nonexistent", "resource", "list")

    def test_unknown_resource(self, mock_api):
        mock_svc = MagicMock()
        mock_svc.configure_mock(**{"nonexistent": MagicMock(side_effect=AttributeError)})
        del mock_svc.nonexistent
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)
        with pytest.raises(ValueError, match="Unknown resource"):
            resolve_and_call(mock_api, "agr-site", "nonexistent", "list")

    def test_unknown_method(self, mock_api):
        mock_resource = MagicMock(spec=[])
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)
        with pytest.raises(ValueError, match="No method"):
            resolve_and_call(mock_api, "agr-site", "settings", "list")

    def test_list_simple(self, mock_api):
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": [], "count": 0, "total": 0}
        mock_resource = MagicMock()
        mock_resource.list.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = resolve_and_call(mock_api, "agr-site", "settings", "list")
        assert result == {"data": [], "count": 0, "total": 0}
        mock_resource.list.assert_called_once_with()

    def test_list_with_params(self, mock_api):
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": [{"id": 1}], "count": 1, "total": 1}
        mock_resource = MagicMock()
        mock_resource.list.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = resolve_and_call(
            mock_api, "agr-site", "settings", "list", params={"limit": 10}
        )
        assert result["count"] == 1
        mock_resource.list.assert_called_once_with({"limit": 10})

    def test_get_simple(self, mock_api):
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": {"id": 5}, "count": 1}
        mock_resource = MagicMock()
        mock_resource.get.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = resolve_and_call(mock_api, "agr-site", "settings", "get", record_id="5")
        assert result["data"]["id"] == 5
        mock_resource.get.assert_called_once_with(5)

    def test_create_simple(self, mock_api):
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": {"id": 10, "name": "new"}}
        mock_resource = MagicMock()
        mock_resource.create.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = resolve_and_call(
            mock_api, "agr-site", "settings", "create", data={"name": "new"}
        )
        assert result["data"]["name"] == "new"
        mock_resource.create.assert_called_once_with({"name": "new"})

    def test_update_simple(self, mock_api):
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": {"id": 5, "name": "updated"}}
        mock_resource = MagicMock()
        mock_resource.update.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = resolve_and_call(
            mock_api, "agr-site", "settings", "update", record_id="5", data={"name": "updated"}
        )
        assert result["data"]["name"] == "updated"
        mock_resource.update.assert_called_once_with(5, {"name": "updated"})

    def test_delete_simple(self, mock_api):
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": True}
        mock_resource = MagicMock()
        mock_resource.delete.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = resolve_and_call(mock_api, "agr-site", "settings", "delete", record_id="5")
        assert result["data"] is True
        mock_resource.delete.assert_called_once_with(5)

    def test_nested_list(self, mock_api):
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": [], "count": 0}
        mock_resource = MagicMock()
        mock_resource.list_conversations.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.training = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = resolve_and_call(
            mock_api, "agr-site", "training/1/conversations", "list"
        )
        assert result["data"] == []
        mock_resource.list_conversations.assert_called_once_with(1)

    def test_nested_get(self, mock_api):
        mock_response = MagicMock()
        mock_response.model_dump.return_value = {"data": {"id": 5}}
        mock_resource = MagicMock()
        mock_resource.get_conversations.return_value = mock_response
        mock_svc = MagicMock()
        mock_svc.training = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = resolve_and_call(
            mock_api, "agr-site", "training/1/conversations", "get", record_id="5"
        )
        mock_resource.get_conversations.assert_called_once_with(1, 5)

    def test_response_without_model_dump(self, mock_api):
        """Test fallback for responses without model_dump."""
        mock_resource = MagicMock()
        mock_resource.list.return_value = {"data": [], "count": 0}
        mock_svc = MagicMock()
        mock_svc.settings = mock_resource
        type(mock_api).agr_site = PropertyMock(return_value=mock_svc)

        result = resolve_and_call(mock_api, "agr-site", "settings", "list")
        assert result == {"data": [], "count": 0}


# --- get_resource_map_from_spec ---


class TestGetResourceMapFromSpec:
    def test_simple_resource(self):
        spec = {
            "endpoints": [
                {"chain": "settings", "action": "list", "method": "GET", "path": "/api/settings"},
                {"chain": "settings", "action": "get", "method": "GET", "path": "/api/settings/{id}"},
                {"chain": "settings", "action": "create", "method": "POST", "path": "/api/settings"},
            ]
        }
        rmap = get_resource_map_from_spec(spec)
        assert "settings" in rmap
        assert sorted(rmap["settings"]) == ["create", "get", "list"]

    def test_nested_resource(self):
        spec = {
            "endpoints": [
                {"chain": "training", "action": "list", "method": "GET", "path": "/api/training"},
                {"chain": "training.conversations", "action": "list", "method": "GET", "path": "/api/training/{id}/conversations"},
                {"chain": "training.conversations", "action": "get", "method": "GET", "path": "/api/training/{id}/conversations/{cid}"},
            ]
        }
        rmap = get_resource_map_from_spec(spec)
        assert "training" in rmap
        assert "training/conversations" in rmap
        assert sorted(rmap["training/conversations"]) == ["get", "list"]

    def test_camel_case_chain_to_kebab_display(self):
        spec = {
            "endpoints": [
                {"chain": "invMast", "action": "list", "method": "GET", "path": "/api/inv-mast"},
                {"chain": "invMast.doc", "action": "list", "method": "GET", "path": "/api/inv-mast/{id}/doc"},
            ]
        }
        rmap = get_resource_map_from_spec(spec)
        assert "inv-mast" in rmap
        assert "inv-mast/doc" in rmap

    def test_empty_spec(self):
        rmap = get_resource_map_from_spec({"endpoints": []})
        assert rmap == {}

    def test_no_endpoints_key(self):
        rmap = get_resource_map_from_spec({})
        assert rmap == {}

    def test_no_duplicate_actions(self):
        spec = {
            "endpoints": [
                {"chain": "settings", "action": "list", "method": "GET", "path": "/api/settings"},
                {"chain": "settings", "action": "list", "method": "GET", "path": "/api/settings"},
            ]
        }
        rmap = get_resource_map_from_spec(spec)
        assert rmap["settings"].count("list") == 1


# --- load_catalog (legacy compat) ---


class TestLoadCatalog:
    def test_load_from_temp_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            spec = {"service": "test-svc", "endpoints": [{"chain": "settings", "action": "list", "method": "GET", "path": "/api/settings"}]}
            (Path(tmpdir) / "test-svc.json").write_text(json.dumps(spec))

            catalog = load_catalog(Path(tmpdir))
            assert "test-svc" in catalog
            assert len(catalog["test-svc"]) == 1
            assert catalog["test-svc"][0]["chain"] == "settings"

    def test_load_empty_dir(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            catalog = load_catalog(Path(tmpdir))
            assert catalog == {}

    def test_load_nonexistent_dir(self):
        catalog = load_catalog(Path("/nonexistent"))
        assert catalog == {}


# --- get_resource_map (legacy compat) ---


class TestGetResourceMap:
    def test_simple_endpoints(self):
        endpoints = [
            {"method": "GET", "path": "/api/settings"},
            {"method": "POST", "path": "/api/settings"},
            {"method": "GET", "path": "/api/settings/{settingsUid}"},
            {"method": "PUT", "path": "/api/settings/{settingsUid}"},
            {"method": "DELETE", "path": "/api/settings/{settingsUid}"},
        ]
        resource_map = get_resource_map(endpoints)
        assert "settings" in resource_map
        assert sorted(resource_map["settings"]) == ["DELETE", "GET", "POST", "PUT"]

    def test_nested_endpoints(self):
        endpoints = [
            {"method": "GET", "path": "/api/training"},
            {"method": "GET", "path": "/api/training/{id}/conversations"},
            {"method": "POST", "path": "/api/training/{id}/conversations"},
        ]
        resource_map = get_resource_map(endpoints)
        assert "training" in resource_map
        assert "training/conversations" in resource_map
