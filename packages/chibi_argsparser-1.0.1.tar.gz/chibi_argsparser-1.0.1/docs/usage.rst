=====
Usage
=====

To use chibi_argsparser in a project::

    import chibi_argsparser
