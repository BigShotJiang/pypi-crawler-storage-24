=======
History
=======

********************
1.0.1 ( 2026-03-27 )
********************

* se agrega dependencia chibi_atlas a setup.py

********************
1.0.0 ( 2026-03-27 )
********************

* se agrega clase Chibi_args y Chibi_arguments 
	ambos siendo hijos de chibi_atlas
* se agrego ejemplo de compatibilidad con ArgumentParser en readme
* prueba unitaria de compatibilidad

********************
0.0.1 ( 2026-03-26 )
********************

* First release on PyPI.
