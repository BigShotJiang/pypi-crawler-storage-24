================
chibi_argsparser
================


.. image:: https://img.shields.io/pypi/v/chibi_argsparser.svg
        :target: https://pypi.python.org/pypi/chibi_argsparser

.. image:: https://readthedocs.org/projects/chibi-argsparser/badge/?version=latest
        :target: https://chibi-argsparser.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


wrapper for ArgumentParser to make more human the definition of the parser

* Free software: WTFPL
* Documentation: https://chibi-argsparser.readthedocs.io.

*********************************
Chibi_argparser vs ArgumentParser
*********************************

Chibi_argparser
===============

.. code-block:: python

	from chibi_argsparser import Chibi_args

	parser = Chibi_args( "small example for ArgumentParser" )
	parser.log_level.params = [ '--log_level' ]
	parser.log_level.help = "level of logger"
	parser.log_level.default = "INFO"

	parser.command.set_as_subparser()
	parser.command.help = "sub-comamnd help"

	parser.command.list.help = "list the backups"
	parser.command.backup.help = "do a backups"

	parser.command.backup.block.params = [ "-b", '--block' ]
	parser.command.backup.block.help = "block"
	parser.command.backup.block.kind = Chibi_path
	parser.command.backup.block.required = True

	parser.command.profile.set_as_subparser()
	parser.command.profile.dest = "profile_command"

	parser.command.profile.backup
	parser.command.profile.list
	parser.command.profile.restore


ArgumentParser
==============

.. code-block:: python

	from chibi_argsparser import Chibi_args
	from argparse import ArgumentParser

	parser_argparser = argparse.ArgumentParser(
		description="small example for ArgumentParser" )

	parser_argparser.add_argument(
		"--log_level", dest="log_level", default="INFO",
		help="level of logger", )

	sub_parsers = parser.add_subparsers(
		dest='command', help='sub-command help' )
	parser_list = sub_parsers.add_parser( 'list', help='list the backups', )
	parser_backup = sub_parsers.add_parser( 'backup', help='do a backup', )

	parser_backup.add_argument(
		'--block', '-b', required=True, type=Chibi_path, help='block' )

	profile_parser = sub_parsers.add_subparsers(
		dest='profile_command', help='', )

	profile_parser.add_argument(
		'--block', '-b', required=True, type=Chibi_path, help='block' )

	parser_backup = sub_parsers.add_parser( 'backup', )
	parser_list = sub_parsers.add_parser( 'list', )
	parser_list = sub_parsers.add_parser( 'restore', )


results
=======

.. code-block:: python

	from chibi_argsparser import Chibi_args
	from argparse import ArgumentParser

	params = [
		"profile", '--block', '/dev/sda', 'backup', '--other', '--home' ]

	# parser Chibi_args
	result = parser( params )
	# parse ArgumentParser
	result_argparser = parser_arg_parser.parse_args( params )

	assert result.command.list == False
	assert result.command.profile == True
	assert result.command.backup == False

	assert result_2.command == "profile"
	assert result.log_level == result_2.log_level
	assert result.block == result_2.block

	assert result.profile_command.list == False
	assert result.profile_command.restore == False
	assert result.profile_command.backup == True
	assert result_2.profile_command == "backup"

	assert result.home == result_2.home
	assert result.other == result_2.other

	assert result == {
		'block': '/dev/sda',
		'command': {'backup': False, 'list': False, 'profile': True},
		'home': True,
		'log_level': 'INFO',
		'other': False,
		'profile_command': {'backup': True, 'list': False, 'restore': False}
	}

	assert result_argparser == {
		'block': '/dev/sda',
		'command': 'profile',
		'home': True,
		'log_level': 'INFO',
		'other': False,
		'profile_command': 'backup'
	}


