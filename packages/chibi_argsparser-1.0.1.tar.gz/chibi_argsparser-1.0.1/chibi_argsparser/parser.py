# -*- coding: utf-8 -*-
from argparse import ArgumentParser
from chibi_atlas import Chibi_atlas
from chibi_argsparser.argument import Chibi_argument


class Chibi_args( Chibi_atlas ):
    def __init__( self, description=None, *args, **kw ):
        super().__init__( *args, **kw )
        self._description = description

    def __call__( self, arguments=None ):
        parser = self._build_parser()
        if arguments is not None:
            if isinstance( arguments, str ):
                arguments = [ arguments ]
            args = parser.parse_args( arguments )
        else:
            args = parser.parse_args()
        kw = dict( args._get_kwargs() )
        # posicional = args._get_args()
        self._parse_sub_parsers( kw )
        return Chibi_atlas( kw )

    def __getattr__( self, name ):
        try:
            attr = super().__getattr__( name )
            return attr
        except AttributeError:
            attr = self.__setattr__( name, Chibi_argument( name ) )
            return self[ name ]

    def __setattr__( self, name, value ):
        return super().__setattr__( name, value )

    def _build_parser( self ):
        description = self._description
        if self.exit_on_error:
            parser = ArgumentParser( description=description )
        else:
            parser = ArgumentParser(
                description=description, exit_on_error=self.exit_on_error )
        for k, v in self.items():
            if isinstance( v, Chibi_argument ):
                v.parser( parser )
            else:
                continue
                raise NotImplementedError(
                    f"el tipo de argumento '{k}' de tipo: {type(v)} "
                    "no esta implementado" )
        return parser

    def _parse_sub_parsers( self, kw, sub_parsers=None ):
        if sub_parsers is None:
            sub_parsers = self._subparser_by_keys()
        else:
            pass
        for k, v in sub_parsers.items():
            if k in kw:
                current = kw.pop( k )
                kw[ v.argument.dest ] = {}
                for sub_args in v.argument.sub_arguments.keys():
                    if current == sub_args:
                        kw[ k ][ sub_args ] = True
                    else:
                        kw[ k ][ sub_args ] = False
                for child in v.child:
                    self._parse_sub_parsers( kw, sub_parsers=child )
        return kw

        """
        for k, v in self._sub_parsers.items():
            if k in kw:
                current_k = kw.pop( k )
                kw[ k ] = Chibi_atlas()
                for sub_args in v.sub_arguments.keys():
                    if current_k == sub_args:
                        kw[ k ][ sub_args ] = True
                    else:
                        kw[ k ][ sub_args ] = False
        """

    def _subparser_by_keys( self, ):
        return self.__subparser_by_keys()

    def __subparser_by_keys( self, arguments=None ):
        result = Chibi_atlas()
        if not arguments:
            arguments = self._arguments
        for args in arguments.values():
            if not isinstance( args, Chibi_argument ):
                continue
            if args.sub_arguments:
                result[ args.dest ] = Chibi_atlas()
                result[ args.dest ].argument = args
                if args._is_subparser:
                    result[ args.dest ].child = []
                    child = result[ args.dest ].child
                    for child_subs in args.sub_arguments.values():
                        child_result = self.__subparser_by_keys( child_subs )
                        if child_result:
                            child.append( child_result )
        return result

    @property
    def _sub_parsers( self ):
        return Chibi_atlas( dict( self.__sub_parsers ) )

    @property
    def __sub_parsers( self ):
        for k, v in self.__arguments:
            if v.sub_arguments:
                yield k, v

    @property
    def _arguments( self ):
        return Chibi_atlas( dict( self.__arguments ) )

    @property
    def __arguments( self ):
        for k, v in self.items():
            if isinstance( v, Chibi_argument ):
                yield k, v

    @property
    def exit_on_error( self ):
        if '_exit_on_error' not in self:
            return False
        return self._exit_on_error

    @exit_on_error.setter
    def exit_on_error( self, value ):
        self._exit_on_error = value
