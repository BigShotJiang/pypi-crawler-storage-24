# -*- coding: utf-8 -*-
from chibi_argsparser.parser import Chibi_args


__all__ = [ 'Chibi_args' ]
__author__ = """dem4ply"""
__email__ = 'dem4ply@gmail.com'
__version__ = '1.0.1'
