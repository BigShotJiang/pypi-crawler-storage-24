from chibi_atlas import Chibi_atlas


class Chibi_argument( Chibi_atlas ):
    def __init__( self, name ):
        self.name = name
        self._dest = None
        self.params = None
        self.default = None
        self.help = None
        self.required = None
        self.action = None
        self.kind = None

        self._is_subparser = False

    def parser( self, parser ):
        if self._is_subparser:
            return self._parser_sub_parser( parser )

        dest = self.name
        params = self.params
        default = self.default
        help = self.help
        required = self.required
        action = self.action
        kind = self.kind

        if action == 'store_true' and default is None:
            default = False
        if action == "store_false" and default is None:
            default = True

        if params:
            if kind:
                parser.add_argument(
                    *params, dest=dest, default=default, help=help,
                    required=required, action=action, type=kind,
                )
            else:
                parser.add_argument(
                    *params, dest=dest, default=default, help=help,
                    required=required, action=action,
                )
        else:
            if default or not required:
                nargs = "?"
            else:
                nargs = None
            parser.add_argument(
                dest, default=default, nargs=nargs, help=help,
                action=action, type=kind,
            )

    def set_as_subparser( self ):
        self._is_subparser = True

    @property
    def dest( self ):
        return self._dest or self.name

    @dest.setter
    def dest( self, value ):
        self._dest = value

    def _parser_sub_parser( self, parser ):
        dest = self.dest
        params = self.params
        default = self.default
        help = self.help

        if default:
            raise NotImplementedError
        if params:
            raise NotImplementedError
        sub_parsers = parser.add_subparsers( dest=dest, help=help )

        for k, v in self.sub_arguments.items():
            if v.default:
                raise NotImplementedError
            if v.params:
                raise NotImplementedError
            sub_parser = sub_parsers.add_parser( k, help=v.help )
            for sub_argument in v.sub_arguments.values():
                sub_argument.parser( sub_parser )

    @property
    def sub_arguments( self ):
        return Chibi_atlas( dict( self._sub_arguments ) )

    @property
    def _sub_arguments( self ):
        for k, v in self.items():
            if isinstance( v, Chibi_argument ):
                yield k, v

    def __getattr__( self, name ):
        try:
            attr = super().__getattr__( name )
            return attr
        except AttributeError:
            attr = self.__setattr__( name, Chibi_argument( name ) )
            return self[ name ]

    def __setattr__( self, name, value ):
        return super().__setattr__( name, value )
