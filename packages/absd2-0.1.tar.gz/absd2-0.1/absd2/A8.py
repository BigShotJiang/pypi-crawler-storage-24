def run():
    code = """
# Tower of Hanoi



def TowerOfHanoi(n, A, C, B):
    if n == 1:
        print("Move disk 1 from rod", A, "to rod", C)
        return

    TowerOfHanoi(n - 1, A, B, C)
    print("Move disk", n, "from rod", A, "to rod", C)
    TowerOfHanoi(n - 1, B, C, A)


n = 3
TowerOfHanoi(n, 'A', 'C', 'B')
"""
    print(code)