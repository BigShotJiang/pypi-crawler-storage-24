def run():
    code = """
# Practical 1 : BFS and DFS



# ---------------- BFS ----------------

graph = {
'a': ['b','c'],
'b': ['d','e'],
'c': ['f'],
'd': [],
'e': [],
'f': []
}

vis = []
q = []
node = 'a'

vis.append(node)
q.append(node)

print("BFS Traversal:")

while q:
    s = q.pop(0)
    print(s, end=' ')

    for n in graph[s]:
        if n not in vis:
            vis.append(n)
            q.append(n)

print("\\n")


# ---------------- DFS ----------------

graph = {
'a': ['d','c','b'],
'b': ['e'],
'c': ['g','f'],
'd': ['h'],
'e': ['i'],
'f': ['j']
}

path = []
stack = ['a']

print("DFS Traversal:")

while len(stack) != 0:
    s = stack.pop()

    if s not in path:
        path.append(s)

    if s not in graph:
        continue

    for n in graph[s]:
        stack.append(n)

print(path)
"""
    print(code)