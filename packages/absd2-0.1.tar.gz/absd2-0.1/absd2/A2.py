def run():
    code = """

a = int(input('Enter Jug A Capacity : '))
b = int(input('Enter Jug B Capacity : '))
af = int(input('Enter Final State Capacity of Jug A : '))

ai = 0   # current Jug A
bi = 0   # current Jug B

print("\\nList of Operations you can do :")
print('1.) Fill Jug A Completely')
print('2.) Empty Jug A Completely')
print('3.) Fill Jug B Completely')
print('4.) Empty Jug B Completely')
print('5.) Pour Jug B into Jug A')
print('6.) Pour Jug A into Jug B')
print('7.) Pour Jug A into Jug B until it is full')
print('8.) Pour Jug B into Jug A until it is full')

print("\\nInitial State: ", ai, bi)

while ai != af and bi <= b:
    op = int(input("\\nEnter your operation: "))

    # 1. Fill A completely
    if op == 1:
        ai = a

    # 2. Empty A
    elif op == 2:
        ai = 0

    # 3. Fill B completely
    elif op == 3:
        bi = b

    # 4. Empty B
    elif op == 4:
        bi = 0

    # 5. Pour B → A
    elif op == 5:
        if ai + bi <= a and bi > 0:
            ai = ai + bi
            bi = 0

    # 6. Pour A → B
    elif op == 6:
        if ai + bi <= b and ai > 0:
            bi = ai + bi
            ai = 0

    # 7. Pour A → B until B is full
    elif op == 7:
        if bi < b and ai > 0:
            space = b - bi
            if ai >= space:
                ai -= space
                bi = b
            else:
                bi += ai
                ai = 0

    # 8. Pour B → A until A is full
    elif op == 8:
        if ai < a and bi > 0:
            space = a - ai
            if bi >= space:
                bi -= space
                ai = a
            else:
                ai += bi
                bi = 0

    print("Current State:", ai, bi)

print("\\nFinal Reached State:", ai, bi)
"""
    print(code)