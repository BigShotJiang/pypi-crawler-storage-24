def run():
    code = """
# Write a program to shuffle deck of cards


import itertools, random

# Create deck : (1–13, Suit)
deck = list(itertools.product(range(1, 14), ['Spades', 'Heart', 'Diamond', 'Clubs']))

# Shuffle deck
random.shuffle(deck)

print("You got:")

for i in range(5):   # draw 5 cards
    card = deck[i][0]
    suit = deck[i][1]

    if card == 11:
        print("Jack of", suit)
    elif card == 12:
        print("Queen of", suit)
    elif card == 13:
        print("King of", suit)
    elif card == 1:
        print("Ace of", suit)
    else:
        print(card, "of", suit)


# Solve Travelling Salesman Problem using AI Technique
# Travelling Salesman

from sys import maxsize
from itertools import permutations

V = 4   # number of vertices

def tsp(g, s):

    ver = [1, 2, 3]
    print("Vertex :", ver)

    minpath = maxsize
    nextper = permutations(ver)

    for i in nextper:
        print("i:", i)

        currentpath = 0
        k = s

        for j in i:
            currentpath += g[k][j]
            print("cw =", currentpath, "g[k][j] =", g[k][j], "k =", k, "j =", j)
            k = j

        currentpath += g[k][s]

        print("final cw at j and graph[k][s]:", g[k][s], "=", currentpath, "\\n")

        minpath = min(minpath, currentpath)

    return minpath


graph = [
[0, 10, 15, 20],
[10, 0, 35, 25],
[15, 35, 0, 30],
[20, 25, 30, 0]
]

s = 0
print("Minimum path =", tsp(graph, s))
"""
    print(code)