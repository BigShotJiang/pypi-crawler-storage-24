def run():
    code = """
# Practical 7 : Speech, Translation and Speech Recognition



# Text to Speech
import pyttsx3

engine = pyttsx3.init()

text = "My name is Raj"
engine.say(text)
engine.runAndWait()


# Speech + Translation to Hindi
import pyttsx3
from googletrans import Translator
from gtts import gTTS

engine = pyttsx3.init()

tl = input("Enter something: ")

# Speak input
engine.say(tl)
engine.runAndWait()

translator = Translator()
t = translator.translate(tl, dest='hi')

print("Translated text:", t.text)

# Convert translated text to audio
s = gTTS(t.text, lang='hi')
s.save("Raj.mp3")

print("Audio saved as Raj.mp3")


# Speech + Translation to French
import pyttsx3
from googletrans import Translator
from gtts import gTTS

engine = pyttsx3.init()

tl = input("Enter something: ")

engine.say(tl)
engine.runAndWait()

translator = Translator()
t = translator.translate(tl, dest='fr')

print("Translated text:", t.text)

# Convert translated text to mp3
s = gTTS(t.text, lang='fr')
s.save("Raj2.mp3")

print("Audio saved as Raj2.mp3")


# Speech Recognition
import speech_recognition as sr

filename = r"C:\\Users\\HP\\Downloads\\kk.wav"

r = sr.Recognizer()

with sr.AudioFile(filename) as source:
    audio_data = r.record(source)
    text = r.recognize_google(audio_data)

print(text)
"""
    print(code)