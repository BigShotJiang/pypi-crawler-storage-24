def run():
    code = """
# Practical 9 : Fuzzy Set Operations

elt = ['w', 'x', 'y', 'z']

A = [0.5, 0.4, 0.3, 0.2]
B = [0.2, 0.1, 0.2, 1]

def printset(m):
    for i in range(4):
        print("(", elt[i], ",", m[i], ")", end=" ")
    print()

print("Set A = ", end="")
printset(A)

print("Set B = ", end="")
printset(B)

# ---------------- UNION ----------------
U = []

for i in range(4):
    if A[i] > B[i]:
        U.append(A[i])
    else:
        U.append(B[i])

print("\\nUnion = ")
printset(U)

# ---------------- INTERSECTION ----------------
I = []

for i in range(4):
    if A[i] < B[i]:
        I.append(A[i])
    else:
        I.append(B[i])

print("\\nIntersection = ")
printset(I)

# ---------------- COMPLEMENT OF A ----------------
AC = []

for i in range(4):
    AC.append(1 - A[i])

print("\\nA Complement = ")
printset(AC)

# ---------------- COMPLEMENT OF B ----------------
BC = []

for i in range(4):
    BC.append(1 - B[i])

print("B Complement = ")
printset(BC)

# ---------------- DIFFERENCE A - B = min(A, BC) ----------------
AMB = []

for i in range(4):
    if A[i] < BC[i]:
        AMB.append(A[i])
    else:
        AMB.append(BC[i])

print("\\nDifference A - B = ")
printset(AMB)

# ---------------- DIFFERENCE B - A = min(B, AC) ----------------
BMA = []

for i in range(4):
    if B[i] < AC[i]:
        BMA.append(B[i])
    else:
        BMA.append(AC[i])

print("\\nDifference B - A = ")
printset(BMA)
"""
    print(code)