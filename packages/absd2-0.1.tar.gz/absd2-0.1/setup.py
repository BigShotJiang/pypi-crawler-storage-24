from setuptools import setup, find_packages

setup(
    name="absd2",
    version="0.1",
    packages=find_packages(),
    description="Imp",
    author="Unknown",
)