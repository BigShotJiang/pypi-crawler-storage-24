import csv
import smtplib
import time
from email.mime.text import MIMEText
from string import Template
from datetime import datetime

# ---------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USERNAME = "your_email@example.com"
SMTP_PASSWORD = "your_app_password"  # Use an app password, not your real password

INVESTOR_CSV = "investors.csv"
LOG_CSV = "outreach_log.csv"

SUBJECT_TEMPLATE_FILE = "subject.txt"
BODY_TEMPLATE_FILE = "body.txt"

SECONDS_BETWEEN_EMAILS = 15  # Safe rate limit


# ---------------------------------------------------------
# LOAD TEMPLATES
# ---------------------------------------------------------

def load_template(path):
    with open(path, "r", encoding="utf-8") as f:
        return Template(f.read())


subject_template = load_template(SUBJECT_TEMPLATE_FILE)
body_template = load_template(BODY_TEMPLATE_FILE)


# ---------------------------------------------------------
# LOAD INVESTORS
# ---------------------------------------------------------

def load_investors(csv_path):
    investors = []
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            investors.append(row)
    return investors


investors = load_investors(INVESTOR_CSV)


# ---------------------------------------------------------
# PREVIEW EMAILS
# ---------------------------------------------------------

def preview_emails(investors):
    print("\n--- EMAIL PREVIEW ---\n")
    for inv in investors:
        rendered_subject = subject_template.substitute(inv)
        rendered_body = body_template.substitute(inv)

        print("--------------------------------------------------")
        print(f"TO: {inv['email']}")
        print(f"SUBJECT: {rendered_subject}")
        print("BODY:")
        print(rendered_body)
        print("--------------------------------------------------\n")


preview_emails(investors)

confirm = input("Send this batch? (y/n): ").strip().lower()
if confirm != "y":
    print("Aborted.")
    exit()


# ---------------------------------------------------------
# SEND EMAILS
# ---------------------------------------------------------

def send_email(to_email, subject, body):
    msg = MIMEText(body, "plain")
    msg["From"] = SMTP_USERNAME
    msg["To"] = to_email
    msg["Subject"] = subject

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        server.sendmail(SMTP_USERNAME, to_email, msg.as_string())


# ---------------------------------------------------------
# LOGGING
# ---------------------------------------------------------

def log_outreach(investor, subject):
    exists = False
    try:
        with open(LOG_CSV, "r", encoding="utf-8") as f:
            exists = True
    except FileNotFoundError:
        pass

    with open(LOG_CSV, "a", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        if not exists:
            writer.writerow(["timestamp", "email", "first_name", "last_name", "firm_name", "subject"])
        writer.writerow([
            datetime.utcnow().isoformat(),
            investor["email"],
            investor["first_name"],
            investor["last_name"],
            investor["firm_name"],
            subject
        ])


# ---------------------------------------------------------
# EXECUTE BATCH SEND
# ---------------------------------------------------------

print("\nSending emails...\n")

for inv in investors:
    rendered_subject = subject_template.substitute(inv)
    rendered_body = body_template.substitute(inv)

    try:
        send_email(inv["email"], rendered_subject, rendered_body)
        log_outreach(inv, rendered_subject)
        print(f"Sent to {inv['email']}")
    except Exception as e:
        print(f"Failed to send to {inv['email']}: {e}")

    time.sleep(SECONDS_BETWEEN_EMAILS)

print("\nBatch complete.\n")
