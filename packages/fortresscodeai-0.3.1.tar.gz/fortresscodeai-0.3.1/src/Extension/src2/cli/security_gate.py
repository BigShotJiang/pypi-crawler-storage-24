from __future__ import annotations

import sys
import json
from pathlib import Path

from ...safety_layer.vuln_scanner.scanner import SecurityScanner
from ..core.logging import setup_logging, get_logger

setup_logging()
logger = get_logger("cli.security_gate")


def main() -> None:
    root = Path.cwd()
    scanner = SecurityScanner(root=str(root))
    result = scanner.run()

    py_vulns = result.get("python_dependency_vulnerabilities", [])
    js_vulns = result.get("node_dependency_vulnerabilities", [])
    config_findings = result.get("config_findings", [])

    high_or_critical = [
        v
        for v in py_vulns
        if v.get("severity") in ("HIGH", "CRITICAL", "high", "critical")
    ]
    js_high_or_critical = [
        v
        for v in js_vulns
        if str(v.get("severity", "")).lower() in ("high", "critical")
    ]
    blocking_config = [
        f for f in config_findings if f.get("severity") in ("high", "critical", "medium")
    ]

    if high_or_critical or js_high_or_critical or blocking_config:
        logger.error("Security gate FAILED")
        print("=== Fortress Security Gate FAILED ===")
        print(json.dumps(result, indent=2))
        sys.exit(1)

    logger.info("Security gate PASSED")
    print("=== Fortress Security Gate PASSED ===")
    sys.exit(0)


if __name__ == "__main__":
    main()
