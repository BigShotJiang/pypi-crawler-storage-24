from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from typing import List
import asyncio
import json
import time
import psutil

router = APIRouter()

metrics_clients: List[WebSocket] = []


@router.websocket("/metrics/stream")
async def metrics_stream(ws: WebSocket):
    await ws.accept()
    metrics_clients.append(ws)
    try:
        while True:
            cpu = psutil.cpu_percent(interval=0.0)
            mem = psutil.virtual_memory()
            net = psutil.net_io_counters()
            payload = {
                "timestamp": time.time(),
                "cpu_percent": cpu,
                "memory_percent": mem.percent,
                "bytes_sent": net.bytes_sent,
                "bytes_recv": net.bytes_recv,
            }
            data = json.dumps(payload)
            for client in list(metrics_clients):
                try:
                    await client.send_text(data)
                except Exception:
                    try:
                        await client.close()
                    except Exception:
                        pass
                    metrics_clients.remove(client)
            await asyncio.sleep(2.0)
    except WebSocketDisconnect:
        if ws in metrics_clients:
            metrics_clients.remove(ws)
