from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Optional

from ..core.logging import get_logger
from ..services.agents.orchestrator import orchestrator as single_agent_orchestrator
from ..services.audit.logger import audit_event

logger = get_logger("dev.agents")

router = APIRouter()


class AgentRequest(BaseModel):
    agent: str
    task: str
    context: Dict[str, Any]
    actor: Optional[str] = None


class AgentResponse(BaseModel):
    success: bool
    output: str
    patch: Optional[str] = None


@router.post("/agents/complete", response_model=AgentResponse)
async def agent_complete(req: AgentRequest):
    try:
        result = await single_agent_orchestrator.execute(
            agent_name=req.agent,
            task=req.task,
            context=req.context,
        )

        audit_event(
            action="agent_task",
            actor=req.actor,
            target=req.agent,
            metadata={
                "task": req.task[:200],
                "success": result.get("success"),
            },
        )

        return AgentResponse(
            success=result.get("success", False),
            output=result.get("output", ""),
            patch=result.get("patch"),
        )
    except Exception as e:
        logger.error("Agent execution failed: %s", e)
        raise HTTPException(status_code=500, detail="Agent execution failed")
