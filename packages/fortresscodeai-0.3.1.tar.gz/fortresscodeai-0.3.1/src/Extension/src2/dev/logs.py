from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from typing import List, Dict, Any
import asyncio
import json
import time

router = APIRouter()

connected_log_clients: List[WebSocket] = []


async def broadcast_log(message: Dict[str, Any]) -> None:
    data = json.dumps(message)
    for ws in list(connected_log_clients):
        try:
            await ws.send_text(data)
        except Exception:
            try:
                await ws.close()
            except Exception:
                pass
            connected_log_clients.remove(ws)


@router.websocket("/logs/stream")
async def logs_stream(ws: WebSocket):
    await ws.accept()
    connected_log_clients.append(ws)
    try:
        while True:
            await asyncio.sleep(60)
    except WebSocketDisconnect:
        if ws in connected_log_clients:
            connected_log_clients.remove(ws)


# Example: call this from your code when logging
async def log_example_event():
    await broadcast_log(
        {
            "timestamp": time.time(),
            "service": "backend",
            "severity": "info",
            "message": "Example log event",
            "correlation_id": "demo-123",
        }
    )
