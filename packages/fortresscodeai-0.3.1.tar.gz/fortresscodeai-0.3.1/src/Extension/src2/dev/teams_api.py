from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Optional

from ..services.teams.orchestrator_full import orchestrator
from ..core.logging import get_logger
from ..services.audit.logger import audit_event

logger = get_logger("dev.teams")

router = APIRouter()


class TeamReviewRequest(BaseModel):
    file_path: str
    diff: str
    content_before: str
    content_after: str
    metadata: Dict[str, Any] = {}
    actor: Optional[str] = None


class TeamReviewResponse(BaseModel):
    final_verdict: str
    security: Dict[str, Any]
    compliance: Dict[str, Any]
    governance: Dict[str, Any]


@router.post("/teams/review", response_model=TeamReviewResponse)
async def teams_review(req: TeamReviewRequest):
    try:
        result = await orchestrator.review_change(
            file_path=req.file_path,
            diff=req.diff,
            content_before=req.content_before,
            content_after=req.content_after,
            metadata=req.metadata,
        )

        audit_event(
            action="multi_team_review",
            actor=req.actor,
            target=req.file_path,
            metadata={
                "final_verdict": result.get("final_verdict"),
                "security_score": result.get("security", {}).get("score"),
                "compliance_score": result.get("compliance", {}).get("score"),
                "governance_score": result.get("governance", {}).get("score"),
            },
        )

        return TeamReviewResponse(**result)
    except Exception as e:
        logger.error("Multi-team review failed: %s", e)
        raise HTTPException(status_code=500, detail="Multi-team review failed")
