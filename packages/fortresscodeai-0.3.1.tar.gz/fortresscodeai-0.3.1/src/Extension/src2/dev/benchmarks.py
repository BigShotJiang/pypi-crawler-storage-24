from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
import httpx
import asyncio
import statistics
import time

router = APIRouter()


class HttpBenchmarkRequest(BaseModel):
    url: str
    method: str = "GET"
    concurrency: int = 5
    requests: int = 50
    headers: Dict[str, str] | None = None
    body: Dict[str, Any] | None = None


class BenchmarkResult(BaseModel):
    p50: float
    p90: float
    p95: float
    p99: float
    throughput: float
    errors: int
    samples: int


def compute_stats(latencies: List[float], errors: int) -> BenchmarkResult:
    if not latencies:
        return BenchmarkResult(
            p50=0, p90=0, p95=0, p99=0, throughput=0, errors=errors, samples=0
        )
    latencies_sorted = sorted(latencies)
    n = len(latencies_sorted)

    def pct(p: float) -> float:
        idx = int(p * (n - 1))
        return latencies_sorted[idx]

    duration = sum(latencies_sorted)
    throughput = n / duration if duration > 0 else 0

    return BenchmarkResult(
        p50=pct(0.5),
        p90=pct(0.9),
        p95=pct(0.95),
        p99=pct(0.99),
        throughput=throughput,
        errors=errors,
        samples=n,
    )


@router.post("/benchmarks/http", response_model=BenchmarkResult)
async def benchmark_http(req: HttpBenchmarkRequest):
    if req.concurrency <= 0 or req.requests <= 0:
        raise HTTPException(status_code=400, detail="Invalid concurrency or requests")

    latencies: List[float] = []
    errors = 0

    async def worker(client: httpx.AsyncClient, count: int):
        nonlocal errors
        for _ in range(count):
            start = time.perf_counter()
            try:
                response = await client.request(
                    req.method,
                    req.url,
                    headers=req.headers,
                    json=req.body,
                    timeout=10.0,
                )
                response.raise_for_status()
                elapsed = time.perf_counter() - start
                latencies.append(elapsed)
            except Exception:
                errors += 1

    per_worker = req.requests // req.concurrency
    remainder = req.requests % req.concurrency
    tasks = []

    async with httpx.AsyncClient() as client:
        for i in range(req.concurrency):
            count = per_worker + (1 if i < remainder else 0)
            if count > 0:
                tasks.append(asyncio.create_task(worker(client, count)))
        await asyncio.gather(*tasks)

    return compute_stats(latencies, errors)


# Stubs for model/db/network/storage benchmarks

class SimpleBenchmarkRequest(BaseModel):
    target: str
    iterations: int = 20


@router.post("/benchmarks/model", response_model=BenchmarkResult)
async def benchmark_model(req: SimpleBenchmarkRequest):
    latencies = []
    errors = 0
    for _ in range(req.iterations):
        start = time.perf_counter()
        try:
            await asyncio.sleep(0.05)  # simulate model call
            latencies.append(time.perf_counter() - start)
        except Exception:
            errors += 1
    return compute_stats(latencies, errors)


@router.post("/benchmarks/db", response_model=BenchmarkResult)
async def benchmark_db(req: SimpleBenchmarkRequest):
    latencies = []
    errors = 0
    for _ in range(req.iterations):
        start = time.perf_counter()
        try:
            await asyncio.sleep(0.01)  # simulate db query
            latencies.append(time.perf_counter() - start)
        except Exception:
            errors += 1
    return compute_stats(latencies, errors)


@router.post("/benchmarks/network", response_model=BenchmarkResult)
async def benchmark_network(req: SimpleBenchmarkRequest):
    latencies = []
    errors = 0
    for _ in range(req.iterations):
        start = time.perf_counter()
        try:
            await asyncio.sleep(0.02)  # simulate ping
            latencies.append(time.perf_counter() - start)
        except Exception:
            errors += 1
    return compute_stats(latencies, errors)


@router.post("/benchmarks/storage", response_model=BenchmarkResult)
async def benchmark_storage(req: SimpleBenchmarkRequest):
    latencies = []
    errors = 0
    for _ in range(req.iterations):
        start = time.perf_counter()
        try:
            await asyncio.sleep(0.015)  # simulate disk IO
            latencies.append(time.perf_counter() - start)
        except Exception:
            errors += 1
    return compute_stats(latencies, errors)
