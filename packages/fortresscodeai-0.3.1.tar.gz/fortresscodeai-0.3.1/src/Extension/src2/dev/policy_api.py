from __future__ import annotations

from typing import List, Dict, Any, Optional

from fastapi import APIRouter
from pydantic import BaseModel

from ..core.logging import get_logger
from ..services.policy_evaluator import PolicyEvaluator
from ..services.proposals_generator import ProposalsGenerator
from ..services.github_integration import GitHubClient
from ..services.audit.logger import audit_event

logger = get_logger("dev.policy")

router = APIRouter()

evaluator = PolicyEvaluator()
proposals_generator = ProposalsGenerator()
github_client = GitHubClient()


class ViolationIn(BaseModel):
    file_path: str
    line: int
    code: str
    message: str
    severity: str
    metadata: Dict[str, Any] = {}


class PolicyEvaluationRequest(BaseModel):
    file_path: str
    content: str
    violations: List[ViolationIn]
    repo_owner: Optional[str] = None
    repo_name: Optional[str] = None
    create_github_issues: bool = False
    actor: Optional[str] = None


class ProposalOut(BaseModel):
    title: str
    description: str
    file_path: str
    line: int
    code: str
    suggested_change: str
    github_issue_number: Optional[int] = None
    github_issue_url: Optional[str] = None


class PolicyEvaluationResponse(BaseModel):
    proposals: List[ProposalOut]


@router.post("/policy/evaluate", response_model=PolicyEvaluationResponse)
async def evaluate_policy(req: PolicyEvaluationRequest):
    payload = {
        "file_path": req.file_path,
        "content": req.content,
        "violations": [v.dict() for v in req.violations],
    }

    eval_result = evaluator.evaluate(payload)
    proposals_resp = proposals_generator.generate(
        {
            "violations": [v.__dict__ for v in eval_result.violations],
            "codegraph_context": eval_result.codegraph_context,
        }
    )

    proposals_out: List[ProposalOut] = []

    for p in proposals_resp.proposals:
        issue_number = None
        issue_url = None

        if req.create_github_issues and req.repo_owner and req.repo_name:
            try:
                body = (
                    f"**Policy violation:** `{p.code}`\n\n"
                    f"**File:** `{p.file_path}` (line {p.line})\n\n"
                    f"**Description:** {p.description}\n\n"
                    f"**Suggested change:**\n\n{p.suggested_change}"
                )
                issue = await github_client.create_issue(
                    owner=req.repo_owner,
                    repo=req.repo_name,
                    title=p.title,
                    body=body,
                    labels=["fortress", "policy-violation"],
                )
                issue_number = issue.get("number")
                issue_url = issue.get("html_url")
                audit_event(
                    action="github_issue_created",
                    actor=req.actor,
                    target=p.file_path,
                    metadata={
                        "code": p.code,
                        "issue_number": issue_number,
                        "issue_url": issue_url,
                    },
                )
            except Exception as e:
                logger.error("Failed to create GitHub issue: %s", e)

        proposals_out.append(
            ProposalOut(
                title=p.title,
                description=p.description,
                file_path=p.file_path,
                line=p.line,
                code=p.code,
                suggested_change=p.suggested_change,
                github_issue_number=issue_number,
                github_issue_url=issue_url,
            )
        )

    return PolicyEvaluationResponse(proposals=proposals_out)
