from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

from ..core.logging import get_logger
from ..services.codegraph.search import CodeGraphIndex, get_default_root
from ..services.agents.client import AgentClient
from ..services.audit.logger import audit_ai_fix

logger = get_logger("dev.ai_fix")

router = APIRouter()

root = get_default_root()
index = CodeGraphIndex(root=root)
index.load()
agent_client = AgentClient()


class AiFixRequest(BaseModel):
    file_path: str
    content: str
    violation_code: str
    description: str
    range_start_line: int
    range_start_char: int
    range_end_line: int
    range_end_char: int
    actor: Optional[str] = None


class AiFixResponse(BaseModel):
    success: bool
    message: str
    patch: Optional[str] = None


@router.post("/ai-fix", response_model=AiFixResponse)
async def ai_fix(req: AiFixRequest):
    try:
        codegraph_context = {
            "symbols": index._data.get(req.file_path.replace("\\", "/"), []),
        }

        context = {
            "file_path": req.file_path,
            "content": req.content,
            "violation_code": req.violation_code,
            "description": req.description,
            "range": {
                "start_line": req.range_start_line,
                "start_char": req.range_start_char,
                "end_line": req.range_end_line,
                "end_char": req.range_end_char,
            },
            "codegraph": codegraph_context,
        }

        task = (
            "Given the file content, violation, and range, produce a patched version "
            "of the file that resolves the violation while preserving behavior. "
            "Return only the full new file content as 'patch'."
        )

        agent_result = await agent_client.complete(task=task, context=context)
        patch = agent_result.get("patch")

        if not patch:
            audit_ai_fix(
                file_path=req.file_path,
                violation_code=req.violation_code,
                actor=req.actor,
                success=False,
                message="Agent returned no patch",
            )
            return AiFixResponse(
                success=False,
                message="Agent did not return a patch.",
                patch=None,
            )

        audit_ai_fix(
            file_path=req.file_path,
            violation_code=req.violation_code,
            actor=req.actor,
            success=True,
            message="AI fix applied",
        )

        return AiFixResponse(
            success=True,
            message="AI fix generated.",
            patch=patch,
        )
    except Exception as e:
        logger.error("AI fix failed: %s", e)
        audit_ai_fix(
            file_path=req.file_path,
            violation_code=req.violation_code,
            actor=req.actor,
            success=False,
            message=str(e),
        )
        raise HTTPException(status_code=500, detail="AI fix failed")
