import time
import psutil
from fastapi import APIRouter
from typing import Any, Dict, List

router = APIRouter()

START_TIME = time.time()


@router.get("/health")
async def get_health() -> Dict[str, Any]:
    cpu_percent = psutil.cpu_percent(interval=0.1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    net = psutil.net_io_counters()
    load_avg = psutil.getloadavg() if hasattr(psutil, "getloadavg") else (0.0, 0.0, 0.0)
    uptime = time.time() - START_TIME

    return {
        "system": {
            "cpu": {"percent": cpu_percent},
            "memory": {"used": mem.used, "total": mem.total, "percent": mem.percent},
            "disk": {"used": disk.used, "total": disk.total, "percent": disk.percent},
            "network": {"bytes_sent": net.bytes_sent, "bytes_recv": net.bytes_recv},
            "uptime_seconds": uptime,
            "load_average": load_avg,
            "temperature": None,
            "throttling": False,
        },
        "containers": [],
        "agents": [
            {"name": "planner", "status": "healthy"},
            {"name": "implementer", "status": "healthy"},
            {"name": "reviewer", "status": "healthy"},
        ],
    }
