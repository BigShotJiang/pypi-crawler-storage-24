from fastapi import Header, HTTPException
import time
from .auth import SESSIONS

def require_dev_token(x_dev_token: str = Header(None)):
    if not x_dev_token:
        raise HTTPException(status_code=401, detail="Missing dev token")

    expiry = SESSIONS.get(x_dev_token)
    if not expiry:
        raise HTTPException(status_code=401, detail="Invalid dev token")

    if expiry < time.time():
        raise HTTPException(status_code=401, detail="Dev session expired")
