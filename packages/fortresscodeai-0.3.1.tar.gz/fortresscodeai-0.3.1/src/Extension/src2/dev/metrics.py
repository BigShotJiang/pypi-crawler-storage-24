from fastapi import APIRouter
from typing import Dict, Any
import time
import psutil

router = APIRouter()


@router.get("/metrics")
async def get_metrics() -> Dict[str, Any]:
    cpu = psutil.cpu_percent(interval=0.0)
    mem = psutil.virtual_memory()
    net = psutil.net_io_counters()
    return {
        "timestamp": time.time(),
        "cpu_percent": cpu,
        "memory_percent": mem.percent,
        "bytes_sent": net.bytes_sent,
        "bytes_recv": net.bytes_recv,
    }
