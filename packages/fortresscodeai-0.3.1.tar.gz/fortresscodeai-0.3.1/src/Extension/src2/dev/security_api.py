from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel
from typing import Dict, Any

from ..services.security.security_scanner import SecurityScanner
from ..core.logging import get_logger

logger = get_logger("dev.security")

router = APIRouter()


class SecurityScanResponse(BaseModel):
    python_dependency_vulnerabilities: list
    node_dependency_vulnerabilities: list
    config_findings: list


@router.get("/security/scan", response_model=SecurityScanResponse)
async def security_scan():
    scanner = SecurityScanner()
    result = scanner.run()
    return SecurityScanResponse(**result)
