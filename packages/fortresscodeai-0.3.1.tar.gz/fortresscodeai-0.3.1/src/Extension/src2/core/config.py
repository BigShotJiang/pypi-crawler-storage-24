from pydantic import BaseSettings
from typing import Dict, List


class Settings(BaseSettings):
    DATABASE_URL: str = "sqlite:///./dev.db"
    OLLAMA_BASE_URL: str = "http://localhost:11434"

    OLLAMA_MODEL_DEFAULT: str = "llama3"

    OLLAMA_AGENT_MODELS: Dict[str, List[str]] = {
        "implementer": ["deepseek-coder", "codellama", "llama3"],
        "architect": ["llama3", "mistral"],
        "security": ["llama3", "phi3"],
        "compliance": ["llama3", "mistral"],
        "reviewer": ["llama3", "mistral"],
    }

    AGENT_CONFIG_DEFAULTS: Dict[str, Dict[str, float | bool]] = {
        "implementer": {"temperature": 0.2, "use_cache": False},
        "architect": {"temperature": 0.1, "use_cache": True},
        "security": {"temperature": 0.1, "use_cache": True},
        "compliance": {"temperature": 0.1, "use_cache": True},
        "reviewer": {"temperature": 0.1, "use_cache": True},
    }


settings = Settings()
