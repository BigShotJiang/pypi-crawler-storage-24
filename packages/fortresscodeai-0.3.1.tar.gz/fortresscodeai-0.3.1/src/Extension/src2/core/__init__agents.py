from sqlalchemy.orm import Session
from .models import AgentStat

DEFAULT_AGENTS = [
    ("architect", 1.0),
    ("implementer", 1.0),
    ("security", 1.2),
    ("compliance", 1.2),
    ("tester", 1.0),
    ("reviewer", 1.0),
]

def ensure_default_agents(db: Session):
    for name, weight in DEFAULT_AGENTS:
        existing = db.query(AgentStat).filter(AgentStat.name == name).first()
        if not existing:
            db.add(AgentStat(name=name, weight=weight))
    db.commit()
