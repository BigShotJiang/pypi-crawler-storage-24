import logging
import logging.config
import os
from typing import Optional

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_JSON = os.getenv("LOG_JSON", "false").lower() == "true"
SERVICE_NAME = os.getenv("SERVICE_NAME", "fortress-backend")


class ServiceNameFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.service = SERVICE_NAME
        return True


def get_default_logging_config() -> dict:
    fmt = (
        '{"level": "%(levelname)s", "time": "%(asctime)s", '
        '"service": "%(service)s", "logger": "%(name)s", '
        '"message": "%(message)s", "module": "%(module)s", '
        '"func": "%(funcName)s", "line": %(lineno)d}'
        if LOG_JSON
        else "[%(asctime)s] [%(levelname)s] [%(service)s] %(name)s: %(message)s"
    )

    return {
        "version": 1,
        "disable_existing_loggers": False,
        "filters": {
            "service_name": {
                "()": ServiceNameFilter,
            }
        },
        "formatters": {
            "default": {
                "format": fmt,
                "datefmt": "%Y-%m-%dT%H:%M:%S%z",
            }
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "level": LOG_LEVEL,
                "formatter": "default",
                "filters": ["service_name"],
            }
        },
        "root": {
            "level": LOG_LEVEL,
            "handlers": ["console"],
        },
        "loggers": {
            "uvicorn": {"level": LOG_LEVEL, "handlers": ["console"], "propagate": False},
            "uvicorn.error": {
                "level": LOG_LEVEL,
                "handlers": ["console"],
                "propagate": False,
            },
            "uvicorn.access": {
                "level": LOG_LEVEL,
                "handlers": ["console"],
                "propagate": False,
            },
        },
    }


def setup_logging(config: Optional[dict] = None) -> None:
    if config is None:
        config = get_default_logging_config()
    logging.config.dictConfig(config)


def get_logger(name: Optional[str] = None) -> logging.Logger:
    return logging.getLogger(name or SERVICE_NAME)
