from typing import Dict, Any
from sqlalchemy.orm import Session
from .config import settings
from .models import ModelUsage

_agent_runtime_config: Dict[str, Dict[str, Any]] = {}


def get_agent_config(agent_name: str) -> Dict[str, Any]:
    base = settings.AGENT_CONFIG_DEFAULTS.get(
        agent_name, {"temperature": 0.2, "use_cache": True}
    )
    override = _agent_runtime_config.get(agent_name, {})
    return {**base, **override}


def set_agent_config(agent_name: str, config: Dict[str, Any]):
    _agent_runtime_config[agent_name] = config


def record_model_usage(
    db: Session, agent_name: str, model_name: str, fallback_used: bool
):
    usage = (
        db.query(ModelUsage)
        .filter(
            ModelUsage.agent_name == agent_name,
            ModelUsage.model_name == model_name,
        )
        .first()
    )
    if not usage:
        usage = ModelUsage(
            agent_name=agent_name, model_name=model_name, calls=0, fallbacks=0
        )
    usage.calls += 1
    if fallback_used:
        usage.fallbacks += 1
    db.add(usage)
    db.commit()
