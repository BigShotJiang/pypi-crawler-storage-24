from sqlalchemy import Column, Integer, String, Text, DateTime, JSON, Float
from sqlalchemy.sql import func
from .db import Base


class Repo(Base):
    __tablename__ = "repos"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(Text, nullable=True)


class Task(Base):
    __tablename__ = "tasks"
    id = Column(Integer, primary_key=True, index=True)
    repo_id = Column(Integer, index=True)
    description = Column(Text)
    status = Column(String, default="pending")
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Proposal(Base):
    __tablename__ = "proposals"
    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, index=True)
    repo_id = Column(Integer, index=True)
    title = Column(String)
    diff = Column(Text)
    status = Column(String, default="draft")  # draft | approved | rejected
    risk_score = Column(Integer, default=50)
    policy_report = Column(JSON, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Policy(Base):
    __tablename__ = "policies"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    severity = Column(String, default="medium")  # low | medium | high
    dsl = Column(Text)  # YAML DSL


class AuditEvent(Base):
    __tablename__ = "audit_events"
    id = Column(Integer, primary_key=True, index=True)
    event_type = Column(String, index=True)
    payload = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class AgentStat(Base):
    __tablename__ = "agent_stats"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)  # e.g. "architect"
    weight = Column(Float, default=1.0)
    total_votes = Column(Integer, default=0)
    correct_votes = Column(Integer, default=0)


class ProposalOutcome(Base):
    __tablename__ = "proposal_outcomes"
    id = Column(Integer, primary_key=True, index=True)
    proposal_id = Column(Integer, index=True)
    final_decision = Column(String)  # approved | rejected
    human_feedback = Column(Text, nullable=True)


class ModelUsage(Base):
    __tablename__ = "model_usage"
    id = Column(Integer, primary_key=True, index=True)
    agent_name = Column(String, index=True)
    model_name = Column(String, index=True)
    calls = Column(Integer, default=0)
    fallbacks = Column(Integer, default=0)
