from fastapi import APIRouter
from pydantic import BaseModel
from typing import Dict, Any, List
from core.config import settings
from core.agent_config import get_agent_config, set_agent_config


router = APIRouter(prefix="/dev", tags=["dev"])


class AgentConfigOut(BaseModel):
    agent_name: str
    config: Dict[str, Any]


class AgentConfigUpdate(BaseModel):
    agent_name: str
    config: Dict[str, Any]


@router.get("/agent-config", response_model=List[AgentConfigOut])
def list_agent_configs():
    out: List[AgentConfigOut] = []
    for name in settings.OLLAMA_AGENT_MODELS.keys():
        out.append(AgentConfigOut(agent_name=name, config=get_agent_config(name)))
    return out


@router.post("/agent-config")
def update_agent_config(payload: AgentConfigUpdate):
    set_agent_config(payload.agent_name, payload.config)
    return {"status": "ok"}
