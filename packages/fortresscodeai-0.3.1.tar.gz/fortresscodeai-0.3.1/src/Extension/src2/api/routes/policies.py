from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from core.db import get_db
from core.models import Policy
from pydantic import BaseModel
from typing import List

router = APIRouter(prefix="/policies", tags=["policies"])

class PolicyCreate(BaseModel):
    name: str
    severity: str
    dsl: str

class PolicyOut(BaseModel):
    id: int
    name: str
    severity: str
    dsl: str

    class Config:
        orm_mode = True

@router.get("/", response_model=List[PolicyOut])
def list_policies(db: Session = Depends(get_db)):
    return db.query(Policy).all()

@router.post("/", response_model=PolicyOut)
def create_policy(payload: PolicyCreate, db: Session = Depends(get_db)):
    policy = Policy(name=payload.name, severity=payload.severity, dsl=payload.dsl)
    db.add(policy)
    db.commit()
    db.refresh(policy)
    return policy
