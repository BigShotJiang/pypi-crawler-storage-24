from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from core.db import get_db
from core.models import AuditEvent
from pydantic import BaseModel
from typing import List, Any, Dict

router = APIRouter(prefix="/audit", tags=["audit"])

class AuditOut(BaseModel):
    id: int
    event_type: str
    payload: Dict[str, Any]

    class Config:
        orm_mode = True

@router.get("/", response_model=List[AuditOut])
def list_events(db: Session = Depends(get_db)):
    return db.query(AuditEvent).order_by(AuditEvent.id.desc()).limit(100).all()
