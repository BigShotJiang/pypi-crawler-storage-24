from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from core.db import get_db
from core.models import ModelUsage
from core.config import settings
from pydantic import BaseModel
from typing import List


router = APIRouter(prefix="/models", tags=["models"])


class ModelUsageOut(BaseModel):
    agent_name: str
    model_name: str
    calls: int
    fallbacks: int


class AgentModelConfigOut(BaseModel):
    agent_name: str
    models: List[str]


class ModelDashboardOut(BaseModel):
    usage: List[ModelUsageOut]
    configs: List[AgentModelConfigOut]


@router.get("/dashboard", response_model=ModelDashboardOut)
def get_model_dashboard(db: Session = Depends(get_db)):
    usage_rows = db.query(ModelUsage).all()
    usage = [
        ModelUsageOut(
            agent_name=u.agent_name,
            model_name=u.model_name,
            calls=u.calls,
            fallbacks=u.fallbacks,
        )
        for u in usage_rows
    ]

    configs = [
        AgentModelConfigOut(agent_name=name, models=models)
        for name, models in settings.OLLAMA_AGENT_MODELS.items()
    ]

    return ModelDashboardOut(usage=usage, configs=configs)
