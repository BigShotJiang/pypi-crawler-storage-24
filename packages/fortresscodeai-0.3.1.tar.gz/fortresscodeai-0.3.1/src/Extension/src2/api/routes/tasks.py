from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from core.db import get_db
from core.models import Task, Repo, AuditEvent
from pydantic import BaseModel
from typing import List
from services.agents.orchestrator import Orchestrator

router = APIRouter(prefix="/tasks", tags=["tasks"])

class TaskCreate(BaseModel):
    repo_id: int
    description: str

class TaskOut(BaseModel):
    id: int
    repo_id: int
    description: str
    status: str

    class Config:
        orm_mode = True

@router.post("/", response_model=TaskOut)
def create_task(payload: TaskCreate, db: Session = Depends(get_db)):
    repo = db.query(Repo).filter(Repo.id == payload.repo_id).first()
    if not repo:
        raise HTTPException(status_code=404, detail="Repo not found")

    task = Task(repo_id=payload.repo_id, description=payload.description, status="processing")
    db.add(task)
    db.commit()
    db.refresh(task)

    orchestrator = Orchestrator(db)
    proposal = orchestrator.run_for_task(task)

    task.status = "completed"
    db.add(task)
    db.add(AuditEvent(event_type="task_completed", payload={"task_id": task.id, "proposal_id": proposal.id}))
    db.commit()
    db.refresh(task)

    return task
