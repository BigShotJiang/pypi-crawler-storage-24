from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os
import hashlib
import hmac
import time
import secrets

router = APIRouter()

DEV_KEY_HASH = os.getenv("DEV_KEY_HASH")  # SHA256 hash stored in env
SESSIONS = {}  # token -> expiry timestamp


class DevAuthRequest(BaseModel):
    key: str


class DevAuthResponse(BaseModel):
    token: str
    expires_at: float


def verify_key(provided: str) -> bool:
    if not DEV_KEY_HASH:
        return False
    provided_hash = hashlib.sha256(provided.encode()).hexdigest()
    return hmac.compare_digest(provided_hash, DEV_KEY_HASH)


@router.post("/auth", response_model=DevAuthResponse)
async def dev_auth(req: DevAuthRequest):
    if not verify_key(req.key):
        raise HTTPException(status_code=401, detail="Invalid key")

    token = secrets.token_hex(32)
    expires = time.time() + 3600  # 1 hour session

    SESSIONS[token] = expires

    return DevAuthResponse(token=token, expires_at=expires)
