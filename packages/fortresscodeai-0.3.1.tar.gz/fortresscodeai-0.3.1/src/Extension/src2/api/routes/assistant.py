from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Literal, Optional
from services.llm.ollama_client import OllamaClient
from core.config import settings

router = APIRouter(prefix="/assistant", tags=["assistant"])


class Message(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    messages: List[Message]
    language: Optional[str] = None
    file_path: Optional[str] = None
    model: Optional[str] = None  # override primary model


class ChatResponse(BaseModel):
    reply: str
    model_used: str


class FixRequest(BaseModel):
    file_path: str
    language: Optional[str] = None
    instruction: str
    content: str
    model: Optional[str] = None  # override primary model


class FixResponse(BaseModel):
    diff: str
    model_used: str


SYSTEM_PROMPT = """You are FortressCodeAI's coding assistant.
You help the developer reason about code, debug issues, and propose changes.
Be concise, but show complete code snippets when needed.
If you propose changes, explain them briefly.
"""

FIX_SYSTEM_PROMPT = """You are FortressCodeAI's implementer agent.
You receive a single file's content and an instruction.
You must respond with a unified diff that applies ONLY to that file.

Constraints:
- Keep changes minimal and safe.
- Do not introduce unrelated refactors.
- The diff must be valid unified diff format.

Format:
--- {file_path}
+++ {file_path}
@@ -old_start,old_count +new_start,new_count @@
- old line
+ new line

Do NOT wrap the diff in backticks or add commentary outside the diff.
"""


def _build_models_for_request(model_override: Optional[str]) -> list[str]:
    base_models = settings.OLLAMA_AGENT_MODELS.get("implementer", [settings.OLLAMA_MODEL_DEFAULT])
    if model_override and model_override not in base_models:
        return [model_override] + base_models
    if model_override:
        # move override to front
        return [model_override] + [m for m in base_models if m != model_override]
    return base_models


@router.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    models = _build_models_for_request(req.model)
    llm = OllamaClient(models=models)

    conversation = [f"System: {SYSTEM_PROMPT}"]
    for m in req.messages:
        conversation.append(f"{m.role.capitalize()}: {m.content}")
    if req.language:
        conversation.append(f"System: The primary language is {req.language}.")
    if req.file_path:
        conversation.append(f"System: The file path is {req.file_path}.")

    prompt = "\n\n".join(conversation)

    text, model_used, _ = llm.generate(prompt, temperature=0.2, use_cache=False)

    return ChatResponse(reply=text, model_used=model_used)


@router.post("/fix", response_model=FixResponse)
def fix(req: FixRequest):
    models = _build_models_for_request(req.model)
    llm = OllamaClient(models=models)

    prompt = FIX_SYSTEM_PROMPT.format(file_path=req.file_path) + "\n\n" + f"""
File path: {req.file_path}
Language: {req.language or "unknown"}

Instruction:
{req.instruction}

Current file content:
{req.content}
"""

    diff, model_used, _ = llm.generate(prompt, temperature=0.2, use_cache=False)

    return FixResponse(diff=diff, model_used=model_used)
