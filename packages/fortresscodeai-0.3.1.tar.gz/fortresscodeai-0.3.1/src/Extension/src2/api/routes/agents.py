from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from core.db import get_db
from core.models import AgentStat
from pydantic import BaseModel
from typing import List


router = APIRouter(prefix="/agents", tags=["agents"])


class AgentStatOut(BaseModel):
    name: str
    weight: float
    total_votes: int
    correct_votes: int
    accuracy: float

    class Config:
        orm_mode = True


@router.get("/", response_model=List[AgentStatOut])
def list_agents(db: Session = Depends(get_db)):
    stats = db.query(AgentStat).all()
    out: List[AgentStatOut] = []
    for s in stats:
        accuracy = s.correct_votes / s.total_votes if s.total_votes > 0 else 0.0
        out.append(
            AgentStatOut(
                name=s.name,
                weight=s.weight,
                total_votes=s.total_votes,
                correct_votes=s.correct_votes,
                accuracy=accuracy,
            )
        )
    return out
