from __future__ import annotations

from typing import Optional, Dict, Any, List
import os

import httpx

from ..core.logging import get_logger

logger = get_logger("github.integration")


class GitHubClient:
    def __init__(self, token: Optional[str] = None) -> None:
        self.token = token or os.getenv("GITHUB_TOKEN")
        self.base_url = "https://api.github.com"

    def _headers(self) -> Dict[str, str]:
        headers = {"Accept": "application/vnd.github+json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    async def create_issue(
        self,
        owner: str,
        repo: str,
        title: str,
        body: str,
        labels: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}/repos/{owner}/{repo}/issues"
        payload = {"title": title, "body": body}
        if labels:
            payload["labels"] = labels

        async with httpx.AsyncClient() as client:
            resp = await client.post(url, headers=self._headers(), json=payload)
            resp.raise_for_status()
            data = resp.json()
            logger.info("Created GitHub issue #%s", data.get("number"))
            return data

    async def comment_on_issue(
        self, owner: str, repo: str, issue_number: int, body: str
    ) -> Dict[str, Any]:
        url = f"{self.base_url}/repos/{owner}/{repo}/issues/{issue_number}/comments"
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, headers=self._headers(), json={"body": body})
            resp.raise_for_status()
            data = resp.json()
            logger.info("Commented on GitHub issue #%s", issue_number)
            return data
