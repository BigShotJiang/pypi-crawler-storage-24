from __future__ import annotations
from typing import Dict, Any, List
import httpx
import os

from .base import Agent
from ...core.logging import get_logger

logger = get_logger("agent.security_review")


class SecurityReviewAgent(Agent):
    name = "security-review"
    description = "Reviews diffs for security issues and produces a structured report with risk score."

    def __init__(self) -> None:
        self.model_url = os.getenv("MODEL_URL", "http://localhost:11434/api/generate")

    async def run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expected context:
        {
          "diff": str,
          "file_path": str,
          "metadata": {...}
        }
        """
        diff = context.get("diff", "")
        file_path = context.get("file_path", "")

        prompt = (
            "You are a senior application security engineer.\n"
            "You will be given a code diff. Perform a security review and respond in JSON.\n\n"
            "JSON schema:\n"
            "{\n"
            '  "risk_score": number (0-10),\n'
            '  "severity": "info" | "low" | "medium" | "high" | "critical",\n'
            '  "findings": [\n'
            "    {\n"
            '      "title": string,\n'
            '      "description": string,\n'
            '      "category": string,\n'
            '      "owasp": string | null,\n'
            '      "recommendation": string\n'
            "    }\n"
            "  ]\n"
            "}\n\n"
            "Focus on:\n"
            "- insecure defaults\n"
            "- unsafe libraries\n"
            "- injection risks\n"
            "- misconfigurations\n"
            "- dependency or auth issues\n\n"
            f"Task:\n{task}\n\n"
            f"File: {file_path}\n\n"
            f"Diff:\n{diff}\n\n"
            "Return ONLY the JSON. No extra text."
        )

        try:
            async with httpx.AsyncClient(timeout=90) as client:
                resp = await client.post(
                    self.model_url,
                    json={"prompt": prompt, "stream": False},
                )
                resp.raise_for_status()
                data = resp.json()
                raw = data.get("response") or data.get("output") or ""
        except Exception as e:
            logger.error("SecurityReviewAgent model call failed: %s", e)
            return {
                "success": False,
                "output": str(e),
                "patch": None,
                "review": None,
            }

        # Try to parse JSON from model output
        import json

        try:
            review = json.loads(raw)
        except Exception as e:
            logger.error("SecurityReviewAgent JSON parse failed: %s", e)
            return {
                "success": False,
                "output": "Model returned invalid JSON",
                "patch": None,
                "review": None,
            }

        risk_score = review.get("risk_score", 0)
        severity = review.get("severity", "info")
        findings: List[dict] = review.get("findings", [])

        logger.info(
            "Security review for %s: risk_score=%s severity=%s findings=%d",
            file_path,
            risk_score,
            severity,
            len(findings),
        )

        return {
            "success": True,
            "output": "Security review completed",
            "patch": None,
            "review": review,
        }
