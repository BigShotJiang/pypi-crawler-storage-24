from __future__ import annotations
from typing import Dict, Any, List

from .base import Agent
from ..compliance.rules_service import ComplianceRulesService
from ...core.logging import get_logger

logger = get_logger("agent.license_compliance")


class LicenseComplianceAgent(Agent):
    name = "license-compliance"
    description = "Checks dependencies and code for license compliance."

    def __init__(self) -> None:
        self.rules_service = ComplianceRulesService()

    async def run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expected context:
        {
          "dependencies": [
            {"name": "...", "version": "...", "license": "..."},
            ...
          ]
        }
        """
        deps: List[Dict[str, Any]] = context.get("dependencies", [])
        rules = self.rules_service.get_license_rules()
        disallowed = set(rules.get("disallowed", []))
        allowed = set(rules.get("allowed", [])) if rules.get("allowed") else None

        violations: List[Dict[str, Any]] = []

        for d in deps:
            lic = (d.get("license") or "").strip()
            name = d.get("name") or "unknown"
            if lic in disallowed:
                violations.append(
                    {
                        "title": f"Disallowed license: {lic}",
                        "description": f"Dependency {name} uses disallowed license {lic}.",
                        "category": "license",
                        "severity": "high",
                        "license": lic,
                        "dependency": name,
                    }
                )
            if allowed is not None and lic and lic not in allowed:
                violations.append(
                    {
                        "title": f"Unapproved license: {lic}",
                        "description": f"Dependency {name} uses license {lic} which is not in the approved list.",
                        "category": "license",
                        "severity": "medium",
                        "license": lic,
                        "dependency": name,
                    }
                )

        if violations:
            logger.info(
                "LicenseComplianceAgent: %d violations found", len(violations)
            )
            return {
                "success": True,
                "output": "License violations detected",
                "patch": None,
                "violations": violations,
            }

        logger.info("LicenseComplianceAgent: no license violations")
        return {
            "success": True,
            "output": "No license violations",
            "patch": None,
            "violations": [],
        }
