from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ..agents.architectural_agent import ArchitectureAgent
from ..agents.style_agent import StyleAgent
from ..agents.policy_enforcer_agent import PolicyEnforcerAgent
from ...core.logging import get_logger

logger = get_logger("team.governance")


class GovernanceTeam(Team):
    name = "governance"

    def __init__(self) -> None:
        self.arch_agent = ArchitectureAgent()
        self.style_agent = StyleAgent()
        self.policy_agent = PolicyEnforcerAgent()

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        # Architecture
        arch_ctx = {
            "file_path": context.file_path,
            "diff": context.diff,
            "metadata": context.metadata,
        }
        arch_result = await self.arch_agent.run(
            "Evaluate architectural impact of this change.", arch_ctx
        )
        for v in arch_result.get("violations", []):
            findings.append(
                Finding(
                    title=v.get("title", "Architecture issue"),
                    description=v.get("description", ""),
                    category=v.get("category", "architecture"),
                    severity=str(v.get("severity", "medium")).lower(),  # type: ignore
                    metadata=v,
                )
            )
            required_changes.append(v.get("description", ""))

        # Style
        style_ctx = {
            "file_path": context.file_path,
            "content": context.content_after,
            "language": context.metadata.get("language", "unknown"),
        }
        style_result = await self.style_agent.run(
            "Check style and formatting.", style_ctx
        )
        for v in style_result.get("violations", []):
            findings.append(
                Finding(
                    title=v.get("title", "Style issue"),
                    description=v.get("description", ""),
                    category=v.get("category", "style"),
                    severity=str(v.get("severity", "low")).lower(),  # type: ignore
                    metadata=v,
                )
            )
            required_changes.append(v.get("description", ""))

        # Policy enforcement
        policy_ctx = {
            "policy_violations": context.metadata.get("policy_violations", []),
        }
        policy_result = await self.policy_agent.run(
            "Aggregate policy violations for governance.", policy_ctx
        )
        for v in policy_result.get("violations", []):
            findings.append(
                Finding(
                    title=v.get("title", "Policy violation"),
                    description=v.get("message", v.get("description", "")),
                    category=v.get("category", "policy"),
                    severity=str(v.get("severity", "medium")).lower(),  # type: ignore
                    metadata=v,
                )
            )
            required_changes.append(
                v.get("message", v.get("description", "Resolve policy violation."))
            )

        # Aggregate score
        severity_weight = {
            "info": 0,
            "low": 1,
            "medium": 2,
            "high": 4,
            "critical": 8,
        }
        score = 0.0
        for f in findings:
            score += severity_weight.get(f.severity, 0)

        verdict = "approve"
        if any(f.category == "policy" and f.severity in ("high", "critical") for f in findings):
            verdict = "reject"
        elif findings:
            verdict = "revise"

        logger.info(
            "GovernanceTeam verdict=%s score=%.1f findings=%d",
            verdict,
            score,
            len(findings),
        )

        return TeamOutput(
            team="governance",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={
                "architecture": arch_result,
                "style": style_result,
                "policy": policy_result,
            },
        )
