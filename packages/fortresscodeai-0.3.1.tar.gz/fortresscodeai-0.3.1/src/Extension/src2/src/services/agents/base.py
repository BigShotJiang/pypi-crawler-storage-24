from __future__ import annotations
from typing import Dict, Any, Optional
from abc import ABC, abstractmethod


class Agent(ABC):
    """
    Base class for all agents.
    """

    name: str = "base-agent"
    description: str = "Base agent"

    @abstractmethod
    async def run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the agent task.
        Must return a dict with at least:
        {
            "success": bool,
            "output": str,
            "patch": Optional[str]
        }
        """
        raise NotImplementedError
