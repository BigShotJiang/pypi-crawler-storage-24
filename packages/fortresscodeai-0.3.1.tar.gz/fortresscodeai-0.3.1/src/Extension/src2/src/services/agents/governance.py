from __future__ import annotations
from typing import Dict, Any

from .orchestrator import orchestrator
from ...core.logging import get_logger

logger = get_logger("agents.governance")


class AgentGovernance:
    """
    Enforces:
    - agent-to-agent communication rules
    - sandboxing / permission boundaries
    - action approval workflows
    """

    async def execute(
        self,
        agent_name: str,
        task: str,
        context: Dict[str, Any],
    ) -> Dict[str, Any]:
        # Example: deny certain tasks or contexts
        if "raw_shell" in context.get("capabilities", []):
            raise PermissionError("Raw shell access is not permitted.")

        # Example: require explicit approval for high-risk actions
        if context.get("risk_level") == "high":
            # later: integrate with approval workflow
            logger.warning("High-risk agent task requested: %s", task[:200])

        return await orchestrator.execute(agent_name, task, context)


governance = AgentGovernance()
