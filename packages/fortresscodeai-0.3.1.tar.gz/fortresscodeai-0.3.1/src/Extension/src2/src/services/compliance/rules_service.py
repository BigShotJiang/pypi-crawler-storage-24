from __future__ import annotations
from typing import Dict, Any, List
from pathlib import Path
import json
import os

from ...core.logging import get_logger

logger = get_logger("compliance.rules")


class ComplianceRulesService:
    """
    Loads and manages compliance rules from JSON files.
    This is your "living" rules layer:
    - license rules
    - regulatory rules
    - internal standards
    """

    def __init__(self, root: str | None = None) -> None:
        self.root = Path(root or os.getenv("FORTRESS_RULES_ROOT", os.getcwd()))
        self.rules_dir = self.root / ".fortress" / "rules"
        self.rules_dir.mkdir(parents=True, exist_ok=True)

        self.license_rules: Dict[str, Any] = {}
        self.regulatory_rules: Dict[str, Any] = {}
        self.internal_rules: Dict[str, Any] = {}

        self.load_all()

    def _load_json(self, name: str) -> Dict[str, Any]:
        path = self.rules_dir / f"{name}.json"
        if not path.exists():
            logger.warning("Compliance rules file missing: %s", path)
            return {}
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.error("Failed to load rules file %s: %s", path, e)
            return {}

    def load_all(self) -> None:
        self.license_rules = self._load_json("license")
        self.regulatory_rules = self._load_json("regulatory")
        self.internal_rules = self._load_json("internal")

    def get_license_rules(self) -> Dict[str, Any]:
        return self.license_rules

    def get_regulatory_rules(self) -> Dict[str, Any]:
        return self.regulatory_rules

    def get_internal_rules(self) -> Dict[str, Any]:
        return self.internal_rules

    def refresh(self) -> None:
        """
        Reload rules from disk. You can call this when rules are updated
        (e.g., via an admin UI or a Git pull).
        """
        logger.info("Refreshing compliance rules from disk")
        self.load_all()
