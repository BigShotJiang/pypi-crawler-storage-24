from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import subprocess
import os

from ...core.logging import get_logger
from ..codegraph.search import CodeGraphIndex, build_symbols_for_file, get_default_root

logger = get_logger("ingestion.git")


def get_changed_files(
    root: str, base_ref: str = "origin/main"
) -> list[str]:
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", base_ref],
            cwd=root,
            capture_output=True,
            text=True,
            check=True,
        )
        files = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        return files
    except Exception as e:
        logger.error("Failed to get changed files from git: %s", e)
        return []


def ingest_changed_files(
    root: Optional[str] = None,
    base_ref: str = "origin/main",
    include_untracked: bool = True,
) -> None:
    root = root or get_default_root()
    index = CodeGraphIndex(root=root)

    changed = get_changed_files(root, base_ref=base_ref)

    if include_untracked:
        try:
            result = subprocess.run(
                ["git", "ls-files", "--others", "--exclude-standard"],
                cwd=root,
                capture_output=True,
                text=True,
                check=True,
            )
            untracked = [line.strip() for line in result.stdout.splitlines() if line.strip()]
            changed.extend(untracked)
        except Exception as e:
            logger.error("Failed to get untracked files from git: %s", e)

    seen = set()
    for rel in changed:
        if rel in seen:
            continue
        seen.add(rel)
        path = Path(root) / rel
        if not path.exists() or not path.is_file():
            continue
        if path.suffix not in {".py", ".ts", ".tsx", ".js", ".jsx"}:
            continue

        try:
            symbols = build_symbols_for_file(str(path))
            index.update_file(str(path), symbols)
        except Exception as e:
            logger.error("Failed to ingest changed file %s: %s", path, e)

    logger.info("Git-based ingestion complete. Files processed: %d", len(seen))
