from sqlalchemy.orm import Session
from typing import List
from core.models import Task, Repo
from core.config import settings
from core.agent_config import get_agent_config, record_model_usage
from services.llm.ollama_client import OllamaClient
from .orchestrator import AgentResult
import json

SUSPICIOUS_PATTERNS = ["password", "secret", "token", "eval(", "exec("]

SECURITY_SYSTEM_PROMPT = """You are the Security Agent in an Autonomous Codebase Management System.
Your job is to evaluate whether a proposed code change introduces security risk.

Consider:
- Hardcoded secrets
- Insecure cryptography
- Injection risks
- Dangerous functions (eval, exec, etc.)
- Logging of sensitive data

You must output a JSON object with:
- verdict: "approve" | "reject" | "revise"
- confidence: float between 0 and 1
- reasoning: short natural language explanation

Only output valid JSON. No backticks, no extra text.
"""


class SecurityAgent:
    def __init__(self, db: Session):
        self.db = db
        models = settings.OLLAMA_AGENT_MODELS.get("security")
        self.llm = OllamaClient(models=models)

    def review(self, task: Task, repo: Repo, diff: str) -> AgentResult:
        cfg = get_agent_config("security")

        heuristic_reasons: List[str] = []
        lower_diff = diff.lower()
        found = [p for p in SUSPICIOUS_PATTERNS if p in lower_diff]

        if found:
            heuristic_reasons.append(
                f"Heuristic: detected potentially sensitive patterns: {', '.join(found)}."
            )

        user_prompt = f"""
Task description:
{task.description}

Repository: {repo.name}

Proposed diff:
{diff}

Heuristic findings:
{'; '.join(heuristic_reasons) if heuristic_reasons else 'None.'}
"""

        prompt = SECURITY_SYSTEM_PROMPT + "\n\n" + user_prompt
        raw, model_used, fallback_used = self.llm.generate(
            prompt,
            temperature=float(cfg.get("temperature", 0.1)),
            use_cache=bool(cfg.get("use_cache", True)),
        )

        record_model_usage(self.db, "security", model_used, fallback_used)

        try:
            data = json.loads(raw)
            verdict = data.get("verdict", "revise")
            confidence = float(data.get("confidence", 0.7))
            reasoning = data.get("reasoning", "")
        except Exception:
            verdict = "revise"
            confidence = 0.6
            reasoning = f"Failed to parse security JSON response. Raw: {raw[:200]}"

        if heuristic_reasons:
            reasoning = " ".join(heuristic_reasons) + " " + reasoning

        return AgentResult(
            name="security",
            verdict=verdict,
            confidence=confidence,
            reasoning=reasoning,
        )
