from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.audit")


class AuditTeam(Team):
    name = "audit"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        # Heuristic: if diff is huge or touches many critical areas, flag for stress testing.
        diff_size = len(context.diff)
        critical_paths = context.metadata.get("critical_paths", [])
        is_critical = any(cp in context.file_path for cp in critical_paths)

        if diff_size > 5000 or is_critical:
            findings.append(
                Finding(
                    title="High-impact change requires stress testing",
                    description="This change is large and/or touches critical paths. Run full stress and chaos tests.",
                    category="audit",
                    severity="medium",
                )
            )
            required_changes.append("Schedule and run full stress/chaos tests for this change.")

        score = 0.0
        if findings:
            score = 5.0

        verdict = "approve" if not findings else "revise"

        logger.info("AuditTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="audit",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={"diff_size": diff_size, "is_critical": is_critical},
        )
