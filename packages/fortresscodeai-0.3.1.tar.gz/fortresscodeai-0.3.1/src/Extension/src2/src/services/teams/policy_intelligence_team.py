from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.policy_intelligence")


class PolicyIntelligenceTeam(Team):
    name = "policy_intelligence"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        # Look at recurring policy violations in metadata and suggest new/updated policies.
        history = context.metadata.get("recent_policy_violations", [])
        categories = {}
        for v in history:
            cat = v.get("category", "unknown")
            categories[cat] = categories.get(cat, 0) + 1

        for cat, count in categories.items():
            if count >= 3:
                findings.append(
                    Finding(
                        title="Recurring policy violation pattern",
                        description=f"Category '{cat}' has {count} recent violations. Consider strengthening or clarifying policies.",
                        category="policy_intelligence",
                        severity="medium",
                        metadata={"category": cat, "count": count},
                    )
                )
                required_changes.append(
                    f"Review and update policies related to category '{cat}'."
                )

        score = float(sum(categories.values()))
        verdict = "approve" if not findings else "revise"

        logger.info("PolicyIntelligenceTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="policy_intelligence",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={"violation_categories": categories},
        )
