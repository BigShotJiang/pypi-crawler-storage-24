from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.supply_chain")


class SupplyChainTeam(Team):
    name = "supply_chain"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        deps = context.metadata.get("dependencies", [])
        new_deps = [d for d in deps if d.get("status") == "added"]

        for d in new_deps:
            name = d.get("name", "unknown")
            version = d.get("version", "unknown")
            findings.append(
                Finding(
                    title="New dependency introduced",
                    description=f"New dependency {name}@{version} added. Ensure SBOM and security review are updated.",
                    category="supply_chain",
                    severity="medium",
                    metadata=d,
                )
            )
            required_changes.append(
                f"Add {name}@{version} to SBOM and run dependency security scan."
            )

        score = float(len(new_deps)) * 2.0
        verdict = "approve" if not findings else "revise"

        logger.info("SupplyChainTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="supply_chain",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={"new_dependencies": new_deps},
        )
