from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any, Optional

import os
import json
import fnmatch

from ...core.logging import get_logger

logger = get_logger("codegraph.search")


@dataclass
class CodeSymbol:
    file_path: str
    line: int
    kind: str
    name: str
    context: str


@dataclass
class SearchResult:
    query: str
    matches: List[CodeSymbol]


class CodeGraphIndex:
    """
    Minimal file-based index:
    - stores per-file metadata in JSON
    - supports simple text + glob search
    """

    def __init__(self, root: str):
        self.root = Path(root)
        self.index_dir = self.root / ".fortress" / "codegraph"
        self.index_dir.mkdir(parents=True, exist_ok=True)
        self.index_file = self.index_dir / "index.json"
        self._data: Dict[str, Any] = {}
        self._loaded = False

    def load(self) -> None:
        if self._loaded:
            return
        if self.index_file.exists():
            try:
                self._data = json.loads(self.index_file.read_text(encoding="utf-8"))
            except Exception as e:
                logger.error("Failed to load codegraph index: %s", e)
                self._data = {}
        else:
            self._data = {}
        self._loaded = True

    def save(self) -> None:
        self.index_dir.mkdir(parents=True, exist_ok=True)
        self.index_file.write_text(json.dumps(self._data, indent=2), encoding="utf-8")

    def update_file(self, file_path: str, symbols: List[CodeSymbol]) -> None:
        self.load()
        rel = str(Path(file_path).as_posix())
        self._data[rel] = [symbol.__dict__ for symbol in symbols]
        self.save()

    def remove_file(self, file_path: str) -> None:
        self.load()
        rel = str(Path(file_path).as_posix())
        if rel in self._data:
            del self._data[rel]
            self.save()

    def search_text(self, query: str, glob: Optional[str] = None) -> SearchResult:
        self.load()
        matches: List[CodeSymbol] = []
        for file_path, symbols in self._data.items():
            if glob and not fnmatch.fnmatch(file_path, glob):
                continue
            for s in symbols:
                if query.lower() in s.get("context", "").lower():
                    matches.append(
                        CodeSymbol(
                            file_path=file_path,
                            line=s.get("line", 0),
                            kind=s.get("kind", "unknown"),
                            name=s.get("name", ""),
                            context=s.get("context", ""),
                        )
                    )
        return SearchResult(query=query, matches=matches)


def build_symbols_for_file(file_path: str) -> List[CodeSymbol]:
    """
    Very naive symbol extraction:
    - Python: def/class lines
    - TS/JS: function/class lines
    """
    path = Path(file_path)
    try:
        text = path.read_text(encoding="utf-8")
    except Exception as e:
        logger.error("Failed to read file for symbol extraction: %s", e)
        return []

    symbols: List[CodeSymbol] = []
    lines = text.splitlines()
    for i, line in enumerate(lines):
        stripped = line.strip()
        if path.suffix == ".py":
            if stripped.startswith("def "):
                name = stripped.split("def ", 1)[1].split("(", 1)[0]
                symbols.append(
                    CodeSymbol(
                        file_path=str(path),
                        line=i + 1,
                        kind="function",
                        name=name,
                        context=line,
                    )
                )
            elif stripped.startswith("class "):
                name = stripped.split("class ", 1)[1].split("(", 1)[0].split(":")[0]
                symbols.append(
                    CodeSymbol(
                        file_path=str(path),
                        line=i + 1,
                        kind="class",
                        name=name,
                        context=line,
                    )
                )
        else:
            if "function " in stripped or stripped.startswith("function "):
                name = stripped.split("function ", 1)[1].split("(", 1)[0]
                symbols.append(
                    CodeSymbol(
                        file_path=str(path),
                        line=i + 1,
                        kind="function",
                        name=name,
                        context=line,
                    )
                )
            elif stripped.startswith("class "):
                name = stripped.split("class ", 1)[1].split("{", 1)[0].strip()
                symbols.append(
                    CodeSymbol(
                        file_path=str(path),
                        line=i + 1,
                        kind="class",
                        name=name,
                        context=line,
                    )
                )
    return symbols


def get_default_root() -> str:
    return os.getenv("FORTRESS_WORKSPACE_ROOT", os.getcwd())
