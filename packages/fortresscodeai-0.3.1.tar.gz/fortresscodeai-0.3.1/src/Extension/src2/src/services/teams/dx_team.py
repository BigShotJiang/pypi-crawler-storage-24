from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.dx")


class DXTeam(Team):
    name = "dx"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        # Heuristic: if change adds complex config or manual steps, suggest DX improvements.
        content = context.content_after.lower()
        if "manual step" in content or "run this command" in content:
            findings.append(
                Finding(
                    title="Manual workflow detected",
                    description="Change introduces manual steps. Consider automating or documenting via scripts.",
                    category="dx",
                    severity="low",
                )
            )
            required_changes.append("Automate manual steps or provide clear DX tooling/commands.")

        score = 0.0
        if findings:
            score = 2.0

        verdict = "approve" if not findings else "revise"

        logger.info("DXTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="dx",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={},
        )
