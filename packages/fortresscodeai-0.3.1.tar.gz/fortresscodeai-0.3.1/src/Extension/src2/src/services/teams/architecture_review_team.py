from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.architecture_review")


class ArchitectureReviewTeam(Team):
    name = "architecture_review"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        layer = context.metadata.get("layer", "unknown")
        deps = context.metadata.get("dependencies", [])

        if layer == "api" and any("db" in str(d).lower() for d in deps):
            findings.append(
                Finding(
                    title="API layer depends directly on DB",
                    description="API layer should depend on domain/services, not directly on DB.",
                    category="architecture",
                    severity="medium",
                )
            )
            required_changes.append("Refactor to route DB access through domain/service layer.")

        score = 0.0
        if findings:
            score = 5.0

        verdict = "approve" if not findings else "revise"

        logger.info("ArchitectureReviewTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="architecture_review",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={"layer": layer, "dependencies": deps},
        )
