from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.incident_response")


class IncidentResponseTeam(Team):
    name = "incident_response"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        # If change touches incident-related modules or logging, ensure runbooks and alerts exist.
        incident_keywords = ["incident", "alert", "pager", "oncall"]
        content = context.content_after.lower()
        touches_incident = any(k in content for k in incident_keywords)

        if touches_incident:
            findings.append(
                Finding(
                    title="Incident handling change",
                    description="Change affects incident/alerting logic. Ensure runbooks and alert routing are updated.",
                    category="incident_response",
                    severity="medium",
                )
            )
            required_changes.append("Review and update incident response runbooks and alert routing.")

        score = 0.0
        if findings:
            score = 3.0

        verdict = "approve" if not findings else "revise"

        logger.info("IncidentResponseTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="incident_response",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={"touches_incident": touches_incident},
        )
