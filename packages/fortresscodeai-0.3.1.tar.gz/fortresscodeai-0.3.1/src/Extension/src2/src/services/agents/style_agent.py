from __future__ import annotations
from typing import Dict, Any, List

from .base import Agent
from ...core.logging import get_logger

logger = get_logger("agent.style")


class StyleAgent(Agent):
    name = "style"
    description = "Checks style and formatting against internal guidelines."

    async def run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expected context:
        {
          "file_path": str,
          "content": str,
          "language": str
        }
        """
        content = context.get("content", "") or ""
        language = context.get("language", "unknown")

        violations: List[Dict[str, Any]] = []

        # Very simple example: long lines
        for i, line in enumerate(content.splitlines(), start=1):
            if len(line) > 120:
                violations.append(
                    {
                        "title": "Line exceeds 120 characters",
                        "description": f"Line {i} is longer than 120 characters.",
                        "category": "style",
                        "severity": "low",
                        "line": i,
                    }
                )

        if violations:
            return {
                "success": True,
                "output": "Style issues detected",
                "patch": None,
                "violations": violations,
            }

        return {
            "success": True,
            "output": "No style issues",
            "patch": None,
            "violations": [],
        }
