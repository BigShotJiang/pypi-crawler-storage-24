from __future__ import annotations
from typing import Dict, Any

from .schemas import TeamContext, TeamOutput
from .security_team import SecurityTeam
from .compliance_team import ComplianceTeam
from .governance_team import GovernanceTeam
from .audit_team import AuditTeam
from .risk_threat_team import RiskThreatTeam
from .supply_chain_team import SupplyChainTeam
from .observability_team import ObservabilityTeam
from .policy_intelligence_team import PolicyIntelligenceTeam
from .incident_response_team import IncidentResponseTeam
from .privacy_team import PrivacyTeam
from .architecture_review_team import ArchitectureReviewTeam
from .dx_team import DXTeam
from .cost_optimization_team import CostOptimizationTeam
from ...core.logging import get_logger

logger = get_logger("teams.orchestrator_full")


class FullMultiTeamOrchestrator:
    """
    Orchestrates all teams over a diff.
    """

    def __init__(self) -> None:
        self.security_team = SecurityTeam()
        self.compliance_team = ComplianceTeam()
        self.governance_team = GovernanceTeam()
        self.audit_team = AuditTeam()
        self.risk_team = RiskThreatTeam()
        self.supply_chain_team = SupplyChainTeam()
        self.observability_team = ObservabilityTeam()
        self.policy_intel_team = PolicyIntelligenceTeam()
        self.incident_team = IncidentResponseTeam()
        self.privacy_team = PrivacyTeam()
        self.arch_team = ArchitectureReviewTeam()
        self.dx_team = DXTeam()
        self.cost_team = CostOptimizationTeam()

    async def review_change(
        self,
        file_path: str,
        diff: str,
        content_before: str,
        content_after: str,
        metadata: Dict[str, Any],
    ) -> Dict[str, Any]:
        ctx = TeamContext(
            file_path=file_path,
            diff=diff,
            content_before=content_before,
            content_after=content_after,
            metadata=metadata,
        )

        teams: Dict[str, TeamOutput] = {}

        teams["security"] = await self.security_team.run(ctx)
        teams["compliance"] = await self.compliance_team.run(ctx)
        teams["governance"] = await self.governance_team.run(ctx)
        teams["audit"] = await self.audit_team.run(ctx)
        teams["risk_threat"] = await self.risk_team.run(ctx)
        teams["supply_chain"] = await self.supply_chain_team.run(ctx)
        teams["observability"] = await self.observability_team.run(ctx)
        teams["policy_intelligence"] = await self.policy_intel_team.run(ctx)
        teams["incident_response"] = await self.incident_team.run(ctx)
        teams["privacy"] = await self.privacy_team.run(ctx)
        teams["architecture_review"] = await self.arch_team.run(ctx)
        teams["dx"] = await self.dx_team.run(ctx)
        teams["cost_optimization"] = await self.cost_team.run(ctx)

        final_verdict = self._aggregate_verdicts(teams)

        return {
            "final_verdict": final_verdict,
            "teams": {name: self._serialize_team_output(out) for name, out in teams.items()},
        }

    def _aggregate_verdicts(self, teams: Dict[str, TeamOutput]) -> str:
        # Hard reject if any critical team rejects.
        critical_reject_teams = ["security", "compliance", "privacy", "incident_response"]
        for name in critical_reject_teams:
            out = teams.get(name)
            if out and out.verdict == "reject":
                return "reject"

        # If any team wants revision, revise.
        if any(out.verdict == "revise" for out in teams.values()):
            return "revise"

        return "approve"

    def _serialize_team_output(self, out: TeamOutput) -> Dict[str, Any]:
        return {
            "team": out.team,
            "verdict": out.verdict,
            "score": out.score,
            "findings": [
                {
                    "title": f.title,
                    "description": f.description,
                    "category": f.category,
                    "severity": f.severity,
                    "owasp": f.owasp,
                    "recommendation": f.recommendation,
                    "metadata": f.metadata,
                }
                for f in out.findings
            ],
            "required_changes": out.required_changes,
            "raw": out.raw,
        }


orchestrator_full = FullMultiTeamOrchestrator()
