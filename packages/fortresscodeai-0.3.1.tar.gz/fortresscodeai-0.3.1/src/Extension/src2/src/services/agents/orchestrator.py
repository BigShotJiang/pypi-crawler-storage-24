from typing import List, Tuple
from sqlalchemy.orm import Session
from core.models import Proposal, Task, Repo, AuditEvent, Policy
from services.agents.architectural_agent import ArchitectureAgent
from .implementer_agent import ImplementerAgent
from .security_agent import SecurityAgent
from services.agents.compliance_agent import ComplianceAgent
from .reviewer_agent import ReviewerAgent
from services.policy.dsl import PolicyEvaluator


class AgentResult:
    def __init__(self, name: str, verdict: str, confidence: float, reasoning: str):
        self.name = name
        self.verdict = verdict
        self.confidence = confidence
        self.reasoning = reasoning


class Orchestrator:
    def __init__(self, db: Session):
        self.db = db
        self.architect = ArchitectureAgent()
        self.implementer = ImplementerAgent(db)
        self.security = SecurityAgent(db)
        self.compliance = ComplianceAgent(db)
        self.reviewer = ReviewerAgent(db)

    def run_for_task(self, task: Task) -> Proposal:
        repo = self.db.query(Repo).filter(Repo.id == task.repo_id).first()
        if not repo:
            raise ValueError("Repo not found")

        draft_diff, impl_reasoning = self.implementer.propose_change(task, repo)

        architect_result = self.architect.(task, repo, draft_diff)
        security_result = self.security.review(task, repo, draft_diff)
        compliance_result = self.compliance.review(task, repo, draft_diff)

        agent_results: List[AgentResult] = [
            architect_result,
            security_result,
            compliance_result,
        ]

        policies = [
            {
                "id": p.id,
                "name": p.name,
                "severity": p.severity,
                "dsl": p.dsl,
            }
            for p in self.db.query(Policy).all()
        ]
        evaluator = PolicyEvaluator(policies)
        policy_eval = evaluator.evaluate_diff(draft_diff)

        final_verdict, risk_score, summary = self.reviewer.aggregate(
            task=task,
            repo=repo,
            draft_diff=draft_diff,
            implementer_reasoning=impl_reasoning,
            agent_results=agent_results,
        )

        policy_report = {
            "status": policy_eval["status"],
            "violations": policy_eval["violations"],
            "summary": summary,
            "agents": [
                {
                    "name": r.name,
                    "verdict": r.verdict,
                    "confidence": r.confidence,
                    "reasoning": r.reasoning,
                }
                for r in agent_results
            ],
        }

        proposal = Proposal(
            task_id=task.id,
            repo_id=task.repo_id,
            title=f"AI proposal for task {task.id}",
            diff=draft_diff,
            status="draft",
            risk_score=risk_score,
            policy_report=policy_report,
        )
        self.db.add(proposal)
        self.db.add(
            AuditEvent(
                event_type="orchestrator_run",
                payload={
                    "task_id": task.id,
                    "proposal_preview": draft_diff[:200],
                    "risk_score": risk_score,
                    "policy_status": policy_eval["status"],
                },
            )
        )
        self.db.commit()
        self.db.refresh(proposal)
        return proposal
