from __future__ import annotations

from typing import Dict, Any, List, Optional
import os

import httpx

from ...core.logging import get_logger

logger = get_logger("agents.client")


class AgentClient:
    """
    Thin client to your multi-agent backend.
    For now, it calls a generic /dev/agents/complete endpoint.
    You can later route by agent, task type, etc.
    """

    def __init__(self, base_url: Optional[str] = None) -> None:
        self.base_url = base_url or os.getenv("AGENT_BACKEND_URL", "http://localhost:8000")

    async def complete(
        self,
        task: str,
        context: Dict[str, Any],
        agent: str = "code-refactor",
    ) -> Dict[str, Any]:
        url = f"{self.base_url}/dev/agents/complete"
        payload = {
            "agent": agent,
            "task": task,
            "context": context,
        }

        async with httpx.AsyncClient() as client:
            resp = await client.post(url, json=payload, timeout=60)
            resp.raise_for_status()
            data = resp.json()
            logger.info("Agent %s completed task: %s", agent, task[:80])
            return data
