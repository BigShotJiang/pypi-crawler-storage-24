from __future__ import annotations
from typing import Dict, Any, List

from .base import Agent
from ..compliance.rules_service import ComplianceRulesService
from ...core.logging import get_logger

logger = get_logger("agent.internal_standards")


class InternalStandardsAgent(Agent):
    name = "internal-standards"
    description = "Checks code against internal engineering and compliance standards."

    def __init__(self) -> None:
        self.rules_service = ComplianceRulesService()

    async def run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expected context:
        {
          "file_path": str,
          "content": str,
          "metadata": {...}
        }
        """
        rules = self.rules_service.get_internal_rules()
        content = context.get("content", "") or ""
        file_path = context.get("file_path", "")

        violations: List[Dict[str, Any]] = []

        for rule in rules.get("patterns", []):
            pattern = rule.get("pattern")
            if not pattern:
                continue
            if pattern in content:
                violations.append(
                    {
                        "title": rule.get("title", "Internal standard violation"),
                        "description": rule.get("description", ""),
                        "category": "internal",
                        "severity": rule.get("severity", "low"),
                        "pattern": pattern,
                        "file_path": file_path,
                    }
                )

        if violations:
            logger.info(
                "InternalStandardsAgent: %d violations found", len(violations)
            )
            return {
                "success": True,
                "output": "Internal standards violations detected",
                "patch": None,
                "violations": violations,
            }

        logger.info("InternalStandardsAgent: no violations")
        return {
            "success": True,
            "output": "No internal standards violations",
            "patch": None,
            "violations": [],
        }
