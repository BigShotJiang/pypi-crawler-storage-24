from __future__ import annotations
from typing import Dict, Any

from .registry import registry
from ...core.logging import get_logger


logger = get_logger("agents.orchestrator")


class AgentOrchestrator:
    """
    Simple orchestrator:
    - Selects agent
    - Executes task
    - Returns result
    """

    async def execute(
        self,
        agent_name: str,
        task: str,
        context: Dict[str, Any],
    ) -> Dict[str, Any]:
        agent = registry.get(agent_name)
        logger.info("Executing agent '%s' for task: %s", agent_name, task[:80])

        result = await agent.run(task, context)

        logger.info(
            "Agent '%s' completed: success=%s",
            agent_name,
            result.get("success"),
        )

        return result


orchestrator = AgentOrchestrator()
