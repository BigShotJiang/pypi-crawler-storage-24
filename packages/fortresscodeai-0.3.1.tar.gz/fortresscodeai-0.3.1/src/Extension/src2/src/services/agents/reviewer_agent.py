from typing import List, Tuple
from sqlalchemy.orm import Session
from core.models import Task, Repo, AgentStat
from .orchestrator import AgentResult


class ReviewerAgent:
    def __init__(self, db: Session):
        self.db = db

    def _get_agent_weight(self, name: str) -> float:
        stat = self.db.query(AgentStat).filter(AgentStat.name == name).first()
        return stat.weight if stat else 1.0

    def aggregate(
        self,
        task: Task,
        repo: Repo,
        draft_diff: str,
        implementer_reasoning: str,
        agent_results: List[AgentResult],
    ) -> Tuple[str, int, str]:
        score = 0.0
        total_weight = 0.0
        reasons = []

        for r in agent_results:
            weight = self._get_agent_weight(r.name)
            total_weight += weight
            if r.verdict == "approve":
                score += weight * r.confidence
            elif r.verdict == "reject":
                score -= weight * r.confidence
            reasons.append(
                f"[{r.name}] {r.verdict.upper()} (conf={r.confidence:.2f}): {r.reasoning}"
            )

        normalized = score / total_weight if total_weight > 0 else 0.0

        if normalized >= 0.4:
            final_verdict = "approve"
        elif normalized <= -0.2:
            final_verdict = "reject"
        else:
            final_verdict = "revise"

        risk_score = int((1.0 - max(-1.0, min(1.0, normalized))) * 50)

        summary = (
            f"Task: {task.description}. "
            f"Implementer reasoning: {implementer_reasoning} "
            f"Aggregate verdict: {final_verdict} (normalized={normalized:.2f}, risk={risk_score}). "
            f"Agent reasons: {' | '.join(reasons)}"
        )

        return final_verdict, risk_score, summary
