from __future__ import annotations
from typing import List, Dict, Any, Literal, Optional
from dataclasses import dataclass, field

Verdict = Literal["approve", "reject", "revise"]

TeamName = Literal[
    "security",
    "compliance",
    "governance",
    "audit",
    "risk_threat",
    "supply_chain",
    "observability",
    "policy_intelligence",
    "incident_response",
    "privacy",
    "architecture_review",
    "dx",
    "cost_optimization"
]


@dataclass
class Finding:
    title: str
    description: str
    category: str
    severity: Literal["info", "low", "medium", "high", "critical"]
    owasp: Optional[str] = None
    recommendation: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TeamOutput:
    team: TeamName
    verdict: Verdict
    score: float
    findings: List[Finding] = field(default_factory=list)
    required_changes: List[str] = field(default_factory=list)
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TeamContext:
    file_path: str
    diff: str
    content_before: str
    content_after: str
    metadata: Dict[str, Any] = field(default_factory=dict)
