from __future__ import annotations
from typing import Dict, Any, List

from .base import Agent
from ..compliance.rules_service import ComplianceRulesService
from ...core.logging import get_logger

logger = get_logger("agent.regulatory_rules")


class RegulatoryRulesAgent(Agent):
    name = "regulatory-rules"
    description = "Checks code and metadata against regulatory rules (e.g., GDPR, SOC2)."

    def __init__(self) -> None:
        self.rules_service = ComplianceRulesService()

    async def run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expected context:
        {
          "file_path": str,
          "content": str,
          "metadata": {
            "data_categories": [...],
            "regions": [...],
            ...
          }
        }
        """
        rules = self.rules_service.get_regulatory_rules()
        metadata = context.get("metadata", {})
        data_categories = set(metadata.get("data_categories", []))
        regions = set(metadata.get("regions", []))

        violations: List[Dict[str, Any]] = []

        for rule in rules.get("rules", []):
            applies_to_regions = set(rule.get("regions", []))
            applies_to_data = set(rule.get("data_categories", []))
            if applies_to_regions and not (applies_to_regions & regions):
                continue
            if applies_to_data and not (applies_to_data & data_categories):
                continue

            # Simple flag: if rule is marked "required" and metadata says "missing"
            if rule.get("required") and rule.get("id") in metadata.get(
                "missing_controls", []
            ):
                violations.append(
                    {
                        "title": f"Regulatory control missing: {rule.get('id')}",
                        "description": rule.get("description", ""),
                        "category": "regulatory",
                        "severity": rule.get("severity", "medium"),
                        "rule_id": rule.get("id"),
                    }
                )

        if violations:
            logger.info(
                "RegulatoryRulesAgent: %d violations found", len(violations)
            )
            return {
                "success": True,
                "output": "Regulatory violations detected",
                "patch": None,
                "violations": violations,
            }

        logger.info("RegulatoryRulesAgent: no violations")
        return {
            "success": True,
            "output": "No regulatory violations",
            "patch": None,
            "violations": [],
        }
