from __future__ import annotations
from typing import Dict

from .base import Agent
from .code_refactor_agent import CodeRefactorAgent
from .security_review_agent import SecurityReviewAgent


class AgentRegistry:
  """
  Holds all available agents.
  """

  def __init__(self) -> None:
    self.agents: Dict[str, Agent] = {
      "code-refactor": CodeRefactorAgent(),
      "security-review": SecurityReviewAgent(),
    }

  def get(self, name: str) -> Agent:
    if name not in self.agents:
      raise ValueError(f"Unknown agent: {name}")
    return self.agents[name]


registry = AgentRegistry()
