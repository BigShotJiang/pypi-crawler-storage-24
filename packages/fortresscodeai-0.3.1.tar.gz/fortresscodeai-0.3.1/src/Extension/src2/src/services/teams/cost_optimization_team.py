from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.cost_optimization")


class CostOptimizationTeam(Team):
    name = "cost_optimization"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        metadata = context.metadata
        model_calls = metadata.get("estimated_model_calls", 0)
        new_background_jobs = metadata.get("new_background_jobs", 0)

        if model_calls > 1000:
            findings.append(
                Finding(
                    title="High AI usage cost",
                    description=f"Change is estimated to add {model_calls} model calls per day.",
                    category="cost",
                    severity="medium",
                )
            )
            required_changes.append("Optimize prompts, caching, or batching to reduce model calls.")

        if new_background_jobs > 0:
            findings.append(
                Finding(
                    title="New background jobs added",
                    description=f"{new_background_jobs} new background jobs introduced. Review infra and cost impact.",
                    category="cost",
                    severity="low",
                )
            )
            required_changes.append("Review scheduling, resource limits, and scaling for new jobs.")

        score = float(model_calls) / 100.0 + float(new_background_jobs)
        verdict = "approve" if not findings else "revise"

        logger.info("CostOptimizationTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="cost_optimization",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={"model_calls": model_calls, "new_background_jobs": new_background_jobs},
        )
