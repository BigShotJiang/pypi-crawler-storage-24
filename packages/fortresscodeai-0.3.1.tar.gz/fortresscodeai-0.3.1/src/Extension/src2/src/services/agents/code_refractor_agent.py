from __future__ import annotations
from typing import Dict, Any
import httpx
import os

from .base import Agent
from ...core.logging import get_logger

logger = get_logger("agent.code_refactor")


class CodeRefactorAgent(Agent):
    name = "code-refactor"
    description = "Generates code patches to fix violations."

    def __init__(self):
        self.model_url = os.getenv("MODEL_URL", "http://localhost:11434/api/generate")

    async def run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        prompt = (
            "You are a senior software engineer. "
            "Given the following task and context, produce a corrected version of the file.\n\n"
            f"Task:\n{task}\n\n"
            f"Context:\n{context}\n\n"
            "Return ONLY the full corrected file content."
        )

        try:
            async with httpx.AsyncClient(timeout=60) as client:
                resp = await client.post(
                    self.model_url,
                    json={"prompt": prompt, "stream": False},
                )
                resp.raise_for_status()
                data = resp.json()
                patch = data.get("response") or data.get("output")

                return {
                    "success": True,
                    "output": "Patch generated",
                    "patch": patch,
                }
        except Exception as e:
            logger.error("CodeRefactorAgent failed: %s", e)
            return {
                "success": False,
                "output": str(e),
                "patch": None,
            }
