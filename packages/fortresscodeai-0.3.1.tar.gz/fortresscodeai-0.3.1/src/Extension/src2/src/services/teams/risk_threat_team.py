from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.risk_threat")


class RiskThreatTeam(Team):
    name = "risk_threat"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        # Simple heuristic: if change touches auth, payments, or secrets, raise risk.
        high_risk_keywords = ["auth", "token", "payment", "crypto", "jwt", "session"]
        content = context.content_after.lower()
        triggered = [k for k in high_risk_keywords if k in content]

        if triggered:
            findings.append(
                Finding(
                    title="High-risk domain change",
                    description=f"Change touches high-risk domains: {', '.join(triggered)}.",
                    category="risk_threat",
                    severity="high",
                )
            )
            required_changes.append("Perform dedicated threat modeling and security review for this change.")

        score = 0.0
        if findings:
            score = 7.0

        verdict = "approve" if not findings else "revise"

        logger.info("RiskThreatTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="risk_threat",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={"triggered_keywords": triggered},
        )
