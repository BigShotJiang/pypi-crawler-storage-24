from sqlalchemy.orm import Session
from core.models import Task, Repo
from core.config import settings
from core.agent_config import get_agent_config, record_model_usage
from services.llm.ollama_client import OllamaClient
from .orchestrator import AgentResult
import json

COMPLIANCE_SYSTEM_PROMPT = """You are the Compliance Agent in an Autonomous Codebase Management System.
Your job is to evaluate whether a proposed code change respects compliance constraints.

Focus on:
- PII handling (emails, names, addresses, phone numbers, SSNs, etc.)
- Logging of sensitive data
- Encryption of sensitive fields
- Regulatory posture (GDPR-like, SOC2-like concerns)

You must output a JSON object with:
- verdict: "approve" | "reject" | "revise"
- confidence: float between 0 and 1
- reasoning: short natural language explanation

Only output valid JSON. No backticks, no extra text.
"""


class ComplianceAgent:
    def __init__(self, db: Session):
        self.db = db
        models = settings.OLLAMA_AGENT_MODELS.get("compliance")
        self.llm = OllamaClient(models=models)

    def review(self, task: Task, repo: Repo, diff: str) -> AgentResult:
        cfg = get_agent_config("compliance")

        user_prompt = f"""
Task description:
{task.description}

Repository: {repo.name}

Proposed diff:
{diff}
"""

        prompt = COMPLIANCE_SYSTEM_PROMPT + "\n\n" + user_prompt
        raw, model_used, fallback_used = self.llm.generate(
            prompt,
            temperature=float(cfg.get("temperature", 0.1)),
            use_cache=bool(cfg.get("use_cache", True)),
        )

        record_model_usage(self.db, "compliance", model_used, fallback_used)

        try:
            data = json.loads(raw)
            verdict = data.get("verdict", "revise")
            confidence = float(data.get("confidence", 0.7))
            reasoning = data.get("reasoning", "No reasoning provided.")
        except Exception:
            verdict = "revise"
            confidence = 0.5
            reasoning = f"Failed to parse compliance JSON response. Raw: {raw[:200]}"

        return AgentResult(
            name="compliance",
            verdict=verdict,
            confidence=confidence,
            reasoning=reasoning,
        )
