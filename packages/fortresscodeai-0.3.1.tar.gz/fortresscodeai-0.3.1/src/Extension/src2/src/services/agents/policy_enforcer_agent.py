from __future__ import annotations
from typing import Dict, Any, List

from .base import Agent
from ...core.logging import get_logger

logger = get_logger("agent.policy_enforcer")


class PolicyEnforcerAgent(Agent):
    name = "policy-enforcer"
    description = "Aggregates policy violations and determines governance impact."

    async def run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expected context:
        {
          "policy_violations": [
            {
              "code": str,
              "severity": str,
              "message": str,
              ...
            }
          ]
        }
        """
        violations: List[Dict[str, Any]] = context.get("policy_violations", [])

        if not violations:
            return {
                "success": True,
                "output": "No policy violations",
                "patch": None,
                "violations": [],
            }

        # Simple severity aggregation
        severity_order = ["info", "low", "medium", "high", "critical"]
        max_severity = "info"
        for v in violations:
            sev = str(v.get("severity", "info")).lower()
            if severity_order.index(sev) > severity_order.index(max_severity):
                max_severity = sev

        return {
            "success": True,
            "output": "Policy violations present",
            "patch": None,
            "violations": violations,
            "max_severity": max_severity,
        }
