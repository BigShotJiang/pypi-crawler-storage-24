from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.observability")


class ObservabilityTeam(Team):
    name = "observability"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        # Heuristic: if change adds new external calls or critical logic without logging, flag it.
        content = context.content_after
        has_logging = "logger." in content or "logging." in content
        touches_external = any(k in content for k in ["httpx.", "requests.", "fetch("])

        if touches_external and not has_logging:
            findings.append(
                Finding(
                    title="Missing observability for external interaction",
                    description="Change adds or modifies external calls without corresponding logging/metrics.",
                    category="observability",
                    severity="medium",
                )
            )
            required_changes.append("Add structured logging and/or metrics around external calls.")

        score = 0.0
        if findings:
            score = 4.0

        verdict = "approve" if not findings else "revise"

        logger.info("ObservabilityTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="observability",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={"has_logging": has_logging, "touches_external": touches_external},
        )
