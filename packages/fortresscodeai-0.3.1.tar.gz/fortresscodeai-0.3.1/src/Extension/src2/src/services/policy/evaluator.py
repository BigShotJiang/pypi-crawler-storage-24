from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Any

from .codegraph.search import CodeGraphIndex, get_default_root
from ..core.logging import get_logger

logger = get_logger("policy.evaluator")


@dataclass
class PolicyViolationRecord:
    file_path: str
    line: int
    code: str
    message: str
    severity: str
    metadata: Dict[str, Any]


@dataclass
class PolicyEvaluationResult:
    violations: List[PolicyViolationRecord]
    codegraph_context: Dict[str, Any]


class PolicyEvaluator:
    """
    Backend-side policy evaluator that:
    - Accepts violations from the VS Code extension
    - Enriches them with codegraph context (symbols, related files)
    """

    def __init__(self, root: str | None = None) -> None:
        self.root = root or get_default_root()
        self.index = CodeGraphIndex(root=self.root)
        self.index.load()

    def _build_codegraph_context(self, file_path: str) -> Dict[str, Any]:
        # For now, just return symbols for this file and a simple search
        symbols = self.index._data.get(file_path.replace("\\", "/"), [])
        related = self.index.search_text(file_path.split("/")[-1]).matches
        return {
            "symbols": symbols,
            "related": [r.__dict__ for r in related],
        }

    def evaluate(self, payload: Dict[str, Any]) -> PolicyEvaluationResult:
        violations: List[PolicyViolationRecord] = []

        for v in payload.get("violations", []):
            violations.append(
                PolicyViolationRecord(
                    file_path=v.get("file_path", payload.get("file_path", "")),
                    line=v.get("line", 0),
                    code=v.get("code", "unknown"),
                    message=v.get("message", ""),
                    severity=v.get("severity", "warning"),
                    metadata=v.get("metadata", {}),
                )
            )

        file_path = payload.get("file_path", "")
        codegraph_context = self._build_codegraph_context(file_path)

        logger.info(
            "Policy evaluation: %d violations for %s",
            len(violations),
            file_path,
        )

        return PolicyEvaluationResult(
            violations=violations,
            codegraph_context=codegraph_context,
        )
