from __future__ import annotations
from typing import List, Dict, Any
import yaml
import re


class PolicyViolation:
    def __init__(self, policy_id: int, policy_name: str, severity: str, message: str):
        self.policy_id = policy_id
        self.policy_name = policy_name
        self.severity = severity
        self.message = message

    def to_dict(self) -> Dict[str, Any]:
        return {
            "policy_id": self.policy_id,
            "policy_name": self.policy_name,
            "severity": self.severity,
            "message": self.message,
        }


class PolicyEvaluator:
    def __init__(self, policies: List[Dict[str, Any]]):
        self.policies = policies

    def evaluate_diff(self, diff: str) -> Dict[str, Any]:
        violations: List[PolicyViolation] = []

        for p in self.policies:
            pid = p["id"]
            name = p["name"]
            severity = p["severity"]
            dsl_text = p["dsl"]

            try:
                spec = yaml.safe_load(dsl_text) or {}
            except Exception as e:
                violations.append(
                    PolicyViolation(
                        policy_id=pid,
                        policy_name=name,
                        severity="medium",
                        message=f"Failed to parse policy DSL: {e}",
                    )
                )
                continue

            rules = spec.get("rules", [])
            for rule in rules:
                rtype = rule.get("type")
                if rtype == "forbidden_pattern":
                    pattern = rule.get("pattern")
                    if not pattern:
                        continue
                    if re.search(pattern, diff, re.MULTILINE):
                        violations.append(
                            PolicyViolation(
                                policy_id=pid,
                                policy_name=name,
                                severity=severity,
                                message=f"Forbidden pattern matched: {pattern}",
                            )
                        )
                elif rtype == "forbidden_import":
                    pattern = rule.get("pattern")
                    if not pattern:
                        continue
                    for line in diff.splitlines():
                        if line.lstrip().startswith(("import ", "from ")):
                            if re.search(pattern, line):
                                violations.append(
                                    PolicyViolation(
                                        policy_id=pid,
                                        policy_name=name,
                                        severity=severity,
                                        message=f"Forbidden import matched: {line.strip()}",
                                    )
                                )

        status = "pass" if not violations else "fail"
        return {
            "status": status,
            "violations": [v.to_dict() for v in violations],
        }
