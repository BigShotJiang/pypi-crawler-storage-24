from __future__ import annotations
from typing import Dict, Any
from abc import ABC, abstractmethod

from .schemas import TeamOutput, TeamContext


class Team(ABC):
    name: str

    @abstractmethod
    async def run(self, context: TeamContext) -> TeamOutput:
        raise NotImplementedError
