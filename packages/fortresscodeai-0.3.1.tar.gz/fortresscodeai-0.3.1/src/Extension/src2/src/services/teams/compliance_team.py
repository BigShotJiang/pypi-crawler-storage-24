from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ..agents.license_compliance_agent import LicenseComplianceAgent
from ..agents.regulatory_rules_agent import RegulatoryRulesAgent
from ..agents.internal_standards_agent import InternalStandardsAgent
from ...core.logging import get_logger

logger = get_logger("team.compliance")


class ComplianceTeam(Team):
    name = "compliance"

    def __init__(self) -> None:
        self.license_agent = LicenseComplianceAgent()
        self.regulatory_agent = RegulatoryRulesAgent()
        self.internal_agent = InternalStandardsAgent()

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        # License compliance
        license_ctx = {
            "dependencies": context.metadata.get("dependencies", []),
        }
        lic_result = await self.license_agent.run(
            "Check license compliance for dependencies.", license_ctx
        )
        for v in lic_result.get("violations", []):
            findings.append(
                Finding(
                    title=v.get("title", "License violation"),
                    description=v.get("description", ""),
                    category=v.get("category", "license"),
                    severity=str(v.get("severity", "medium")).lower(),  # type: ignore
                    metadata=v,
                )
            )
            required_changes.append(v.get("description", ""))

        # Regulatory rules
        reg_ctx = {
            "file_path": context.file_path,
            "content": context.content_after,
            "metadata": context.metadata,
        }
        reg_result = await self.regulatory_agent.run(
            "Check regulatory compliance for this change.", reg_ctx
        )
        for v in reg_result.get("violations", []):
            findings.append(
                Finding(
                    title=v.get("title", "Regulatory violation"),
                    description=v.get("description", ""),
                    category=v.get("category", "regulatory"),
                    severity=str(v.get("severity", "medium")).lower(),  # type: ignore
                    metadata=v,
                )
            )
            required_changes.append(v.get("description", ""))

        # Internal standards
        int_ctx = {
            "file_path": context.file_path,
            "content": context.content_after,
            "metadata": context.metadata,
        }
        int_result = await self.internal_agent.run(
            "Check internal standards for this change.", int_ctx
        )
        for v in int_result.get("violations", []):
            findings.append(
                Finding(
                    title=v.get("title", "Internal standard violation"),
                    description=v.get("description", ""),
                    category=v.get("category", "internal"),
                    severity=str(v.get("severity", "low")).lower(),  # type: ignore
                    metadata=v,
                )
            )
            required_changes.append(v.get("description", ""))

        # Aggregate score: simple heuristic
        severity_weight = {
            "info": 0,
            "low": 1,
            "medium": 3,
            "high": 6,
            "critical": 10,
        }
        score = 0.0
        for f in findings:
            score += severity_weight.get(f.severity, 0)

        verdict = "approve"
        if any(f.severity in ("high", "critical") for f in findings):
            verdict = "reject"
        elif findings:
            verdict = "revise"

        logger.info(
            "ComplianceTeam verdict=%s score=%.1f findings=%d",
            verdict,
            score,
            len(findings),
        )

        return TeamOutput(
            team="compliance",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={
                "license": lic_result,
                "regulatory": reg_result,
                "internal": int_result,
            },
        )
