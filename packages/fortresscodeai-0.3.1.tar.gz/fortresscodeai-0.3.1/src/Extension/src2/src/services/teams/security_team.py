from __future__ import annotations
from typing import Dict, Any, List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ..agents.security_review_agent import SecurityReviewAgent
from ...core.logging import get_logger

logger = get_logger("team.security")


class SecurityTeam(Team):
    name = "security"

    def __init__(self) -> None:
        self.review_agent = SecurityReviewAgent()

    async def run(self, context: TeamContext) -> TeamOutput:
        # For now, we use only the security_review_agent; later you can fan out to more.
        task = "Perform a security review of this diff and assess risk."
        agent_context = {
            "diff": context.diff,
            "file_path": context.file_path,
            "metadata": context.metadata,
        }

        result = await self.review_agent.run(task, agent_context)

        if not result.get("success"):
            logger.error("SecurityTeam: review agent failed: %s", result.get("output"))
            return TeamOutput(
                team="security",
                verdict="reject",
                score=8.0,
                findings=[
                    Finding(
                        title="Security review failed",
                        description="The security review agent failed to complete.",
                        category="process",
                        severity="high",
                    )
                ],
                required_changes=["Investigate security review failure before merging."],
                raw=result,
            )

        review = result.get("review") or {}
        risk_score = float(review.get("risk_score", 0.0))
        severity = str(review.get("severity", "info")).lower()
        findings_raw = review.get("findings", [])

        findings: List[Finding] = []
        for f in findings_raw:
            findings.append(
                Finding(
                    title=f.get("title", "Security finding"),
                    description=f.get("description", ""),
                    category=f.get("category", "general"),
                    severity=str(f.get("severity", "info")).lower()  # type: ignore
                    if f.get("severity")
                    else "info",
                    owasp=f.get("owasp"),
                    recommendation=f.get("recommendation"),
                    metadata={k: v for k, v in f.items() if k not in {"title", "description", "category", "severity", "owasp", "recommendation"}},
                )
            )

        # Simple verdict logic
        if risk_score >= 8:
            verdict = "reject"
        elif risk_score >= 4:
            verdict = "revise"
        else:
            verdict = "approve"

        required_changes: List[str] = []
        if verdict != "approve":
            for f in findings:
                if f.recommendation:
                    required_changes.append(f.recommendation)

        logger.info(
            "SecurityTeam verdict=%s score=%.2f findings=%d",
            verdict,
            risk_score,
            len(findings),
        )

        return TeamOutput(
            team="security",
            verdict=verdict,
            score=risk_score,
            findings=findings,
            required_changes=required_changes,
            raw=review,
        )
