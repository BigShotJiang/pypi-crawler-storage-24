from __future__ import annotations

from pathlib import Path
from typing import Iterable

import fnmatch
import os

from ...core.logging import get_logger
from ..codegraph.search import CodeGraphIndex, build_symbols_for_file, get_default_root

logger = get_logger("ingestion.fs")


DEFAULT_IGNORE = ["**/node_modules/**", "**/.git/**", "**/.fortress/**", "**/__pycache__/**"]


def should_ignore(path: Path, ignore_patterns: Iterable[str]) -> bool:
    as_posix = path.as_posix()
    for pattern in ignore_patterns:
        if fnmatch.fnmatch(as_posix, pattern):
            return True
    return False


def ingest_workspace(root: str | None = None, ignore_patterns: Iterable[str] | None = None) -> None:
    root = root or get_default_root()
    ignore_patterns = list(ignore_patterns or DEFAULT_IGNORE)
    logger.info("Starting workspace ingestion at %s", root)

    index = CodeGraphIndex(root=root)

    for path in Path(root).rglob("*"):
        if not path.is_file():
            continue
        if should_ignore(path, ignore_patterns):
            continue
        if path.suffix not in {".py", ".ts", ".tsx", ".js", ".jsx"}:
            continue

        try:
            symbols = build_symbols_for_file(str(path))
            index.update_file(str(path), symbols)
        except Exception as e:
            logger.error("Failed to ingest file %s: %s", path, e)

    logger.info("Workspace ingestion complete.")
