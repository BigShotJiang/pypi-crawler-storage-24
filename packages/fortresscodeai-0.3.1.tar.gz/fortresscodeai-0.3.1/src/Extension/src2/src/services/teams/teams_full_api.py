from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Optional

from services.teams.orchestrator_full import orchestrator_full
from core.logging import get_logger
from services.audit.logger import audit_event

logger = get_logger("dev.teams_full")

router = APIRouter()


class FullTeamReviewRequest(BaseModel):
    file_path: str
    diff: str
    content_before: str
    content_after: str
    metadata: Dict[str, Any] = {}
    actor: Optional[str] = None


class FullTeamReviewResponse(BaseModel):
    final_verdict: str
    teams: Dict[str, Any]


@router.post("/teams/full_review", response_model=FullTeamReviewResponse)
async def full_teams_review(req: FullTeamReviewRequest):
    try:
        result = await orchestrator_full.review_change(
            file_path=req.file_path,
            diff=req.diff,
            content_before=req.content_before,
            content_after=req.content_after,
            metadata=req.metadata,
        )

        audit_event(
            action="multi_team_full_review",
            actor=req.actor,
            target=req.file_path,
            metadata={"final_verdict": result.get("final_verdict")},
        )

        return FullTeamReviewResponse(**result)
    except Exception as e:
        logger.error("Full multi-team review failed: %s", e)
        raise HTTPException(status_code=500, detail="Full multi-team review failed")
