from typing import Any, Dict, Optional
import time
import json
from ...core.logging import get_logger

logger = get_logger("audit")

def audit_event(
    action: str,
    actor: Optional[str] = None,
    target: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    payload = {
        "type": "audit",
        "timestamp": time.time(),
        "action": action,
        "actor": actor,
        "target": target,
        "metadata": metadata or {},
    }
    # Keep it structured so you can ship to ELK/ClickHouse later
    logger.info(json.dumps(payload))


def audit_dev_console_access(user: Optional[str], success: bool, reason: str = ""):
    audit_event(
        action="dev_console_access",
        actor=user,
        target="dev_console",
        metadata={"success": success, "reason": reason},
    )


def audit_ai_fix(
    file_path: str,
    violation_code: str,
    actor: Optional[str] = None,
    success: bool = True,
    message: str = "",
):
    audit_event(
        action="ai_fix",
        actor=actor,
        target=file_path,
        metadata={
            "violation_code": violation_code,
            "success": success,
            "message": message,
        },
    )
