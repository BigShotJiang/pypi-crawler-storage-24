from typing import Tuple
from sqlalchemy.orm import Session
from core.models import Task, Repo
from core.config import settings
from core.agent_config import get_agent_config, record_model_usage
from services.llm.ollama_client import OllamaClient

IMPLEMENTER_SYSTEM_PROMPT = """You are the Implementer Agent in an Autonomous Codebase Management System.
Your job is to propose SMALL, SAFE code changes as unified diffs.

Constraints:
- Prefer minimal, incremental changes.
- Do not introduce breaking changes unless explicitly requested.
- Assume the codebase exists, but you only see partial context.
- When in doubt, add TODO comments instead of guessing.

Output format:
1. First, a short explanation of what you are changing and why.
2. Then, a unified diff starting with lines like:
   --- path/to/file.ext
   +++ path/to/file.ext
   @@ -1,0 +1,10 @@
   ...

Do NOT wrap the diff in backticks.
"""


class ImplementerAgent:
    def __init__(self, db: Session):
        self.db = db
        models = settings.OLLAMA_AGENT_MODELS.get("implementer")
        self.llm = OllamaClient(models=models)

    def propose_change(self, task: Task, repo: Repo) -> Tuple[str, str]:
        cfg = get_agent_config("implementer")

        user_prompt = f"""
Task description:
{task.description}

Repository name: {repo.name}

Goal:
Propose a small, safe change that moves this task forward.
If you lack enough context, add TODO comments and explain assumptions.
"""

        full_prompt = IMPLEMENTER_SYSTEM_PROMPT + "\n\n" + user_prompt
        response, model_used, fallback_used = self.llm.generate(
            full_prompt,
            temperature=float(cfg.get("temperature", 0.2)),
            use_cache=bool(cfg.get("use_cache", False)),
        )

        record_model_usage(self.db, "implementer", model_used, fallback_used)

        lines = response.splitlines()
        diff_start = None
        for i, line in enumerate(lines):
            if line.startswith("--- "):
                diff_start = i
                break

        if diff_start is None:
            explanation = response
            diff = (
                "// ImplementerAgent could not produce a diff.\n"
                "// Explanation:\n"
                f"// {response}"
            )
        else:
            explanation = "\n".join(lines[:diff_start]).strip()
            diff = "\n".join(lines[diff_start:]).strip()

        return diff, explanation
