from __future__ import annotations
from typing import Dict, Any, List

from .base import Agent
from ...core.logging import get_logger

logger = get_logger("agent.architecture")


class ArchitectureAgent(Agent):
    name = "architecture"
    description = "Evaluates architectural impact and governance alignment of changes."

    async def run(self, task: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expected context:
        {
          "file_path": str,
          "diff": str,
          "metadata": {
            "layer": "api" | "domain" | "infra" | ...,
            "dependencies": [...],
            ...
          }
        }
        """
        # For now, this is heuristic; later you can plug in a model.
        metadata = context.get("metadata", {})
        layer = metadata.get("layer", "unknown")
        deps = metadata.get("dependencies", [])

        violations: List[Dict[str, Any]] = []

        if layer == "api" and any("db" in str(d).lower() for d in deps):
            violations.append(
                {
                    "title": "API layer depends directly on DB",
                    "description": "API layer should depend on domain/services, not directly on DB.",
                    "category": "architecture",
                    "severity": "medium",
                }
            )

        if violations:
            return {
                "success": True,
                "output": "Architecture issues detected",
                "patch": None,
                "violations": violations,
            }

        return {
            "success": True,
            "output": "No architecture issues",
            "patch": None,
            "violations": [],
        }
