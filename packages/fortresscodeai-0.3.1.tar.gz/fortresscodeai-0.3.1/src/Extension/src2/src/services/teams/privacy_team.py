from __future__ import annotations
from typing import List

from .base_team import Team
from .schemas import TeamOutput, TeamContext, Finding
from ...core.logging import get_logger

logger = get_logger("team.privacy")


class PrivacyTeam(Team):
    name = "privacy"

    def __init__(self) -> None:
        ...

    async def run(self, context: TeamContext) -> TeamOutput:
        findings: List[Finding] = []
        required_changes: List[str] = []

        metadata = context.metadata
        data_categories = set(metadata.get("data_categories", []))
        touches_personal = bool(data_categories & {"personal", "sensitive", "health", "financial"})

        if touches_personal:
            findings.append(
                Finding(
                    title="Personal data handling change",
                    description="Change affects handling of personal or sensitive data. Ensure privacy controls are applied.",
                    category="privacy",
                    severity="high",
                )
            )
            required_changes.append("Perform privacy impact assessment and verify data minimization and access controls.")

        score = 0.0
        if findings:
            score = 8.0

        verdict = "approve" if not findings else "revise"

        logger.info("PrivacyTeam verdict=%s score=%.1f findings=%d", verdict, score, len(findings))

        return TeamOutput(
            team="privacy",
            verdict=verdict,
            score=score,
            findings=findings,
            required_changes=required_changes,
            raw={"data_categories": list(data_categories)},
        )
