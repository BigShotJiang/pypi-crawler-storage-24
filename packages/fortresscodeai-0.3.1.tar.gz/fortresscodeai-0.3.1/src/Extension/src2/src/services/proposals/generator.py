from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Any

from ..core.logging import get_logger

logger = get_logger("proposals.generator")


@dataclass
class RefactorProposal:
    title: str
    description: str
    file_path: str
    line: int
    code: str
    suggested_change: str


@dataclass
class ProposalResponse:
    proposals: List[RefactorProposal]


class ProposalsGenerator:
    """
    Takes policy violations + codegraph context and generates
    higher-level proposals (e.g., "Extract repository layer", "Add auth guard").
    """

    def __init__(self) -> None:
        ...

    def generate(self, evaluation: Dict[str, Any]) -> ProposalResponse:
        violations = evaluation.get("violations", [])
        codegraph_context = evaluation.get("codegraph_context", {})
        proposals: List[RefactorProposal] = []

        for v in violations:
            code = v.get("code")
            file_path = v.get("file_path", "")
            line = v.get("line", 0)

            if code == "no-direct-db-in-routes":
                proposals.append(
                    RefactorProposal(
                        title="Introduce Repository Layer for Route",
                        description=(
                            "This route accesses the database directly. "
                            "Introduce a repository/service layer to encapsulate DB access. "
                            "Use the existing DB utilities and inject a repository into the route."
                        ),
                        file_path=file_path,
                        line=line,
                        code=code,
                        suggested_change=(
                            "1. Create a repository module (e.g., repositories/user_repository.py).\n"
                            "2. Move DB access logic from the route into repository methods.\n"
                            "3. Inject the repository into the route via dependency injection.\n"
                        ),
                    )
                )
            elif code == "external-http-must-be-wrapped":
                proposals.append(
                    RefactorProposal(
                        title="Wrap External HTTP Call",
                        description=(
                            "External HTTP calls should be wrapped in a shared helper "
                            "with retries, logging, and error handling. "
                            "This improves resilience and observability."
                        ),
                        file_path=file_path,
                        line=line,
                        code=code,
                        suggested_change=(
                            "1. Create an http_client helper module.\n"
                            "2. Implement retry logic, logging, and error handling.\n"
                            "3. Replace direct requests/httpx calls with the helper.\n"
                        ),
                    )
                )
            elif code == "routes-must-have-auth":
                proposals.append(
                    RefactorProposal(
                        title="Add Auth Guard to Route",
                        description=(
                            "Protected routes should enforce authentication via a dependency "
                            "such as get_current_user. This ensures only authorized users "
                            "can access sensitive endpoints."
                        ),
                        file_path=file_path,
                        line=line,
                        code=code,
                        suggested_change=(
                            "1. Import get_current_user dependency.\n"
                            "2. Add Depends(get_current_user) to the route signature.\n"
                        ),
                    )
                )

        logger.info(
            "Generated %d proposals (violations=%d, symbols=%d)",
            len(proposals),
            len(violations),
            len(codegraph_context.get("symbols", [])),
        )
        return ProposalResponse(proposals=proposals)
