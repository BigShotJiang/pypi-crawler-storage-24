import hashlib
import json
import threading
from typing import Generator, List, Optional, Tuple

import requests

from core.config import settings

_llm_cache_lock = threading.Lock()
_llm_cache: dict[str, str] = {}


def _hash_prompt(model: str, prompt: str, temperature: float) -> str:
    h = hashlib.sha256()
    h.update(model.encode("utf-8"))
    h.update(prompt.encode("utf-8"))
    h.update(str(temperature).encode("utf-8"))
    return h.hexdigest()


class OllamaClient:
    def __init__(self, models: Optional[List[str]] = None):
        self.base_url = settings.OLLAMA_BASE_URL
        self.models = models or [settings.OLLAMA_MODEL_DEFAULT]

    def _call_generate(
        self,
        model: str,
        prompt: str,
        temperature: float,
        max_tokens: Optional[int],
        stream: bool,
    ):
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": stream,
            "options": {"temperature": temperature},
        }
        if max_tokens is not None:
            payload["options"]["num_predict"] = max_tokens

        resp = requests.post(
            f"{self.base_url}/api/generate",
            json=payload,
            timeout=300,
            stream=stream,
        )
        resp.raise_for_status()
        return resp

    def generate(
        self,
        prompt: str,
        temperature: float = 0.2,
        max_tokens: Optional[int] = None,
        use_cache: bool = True,
    ) -> Tuple[str, str, bool]:
        """
        Returns: (text, model_used, fallback_used)
        """
        last_error: Optional[Exception] = None

        for idx, model in enumerate(self.models):
            cache_key = _hash_prompt(model, prompt, temperature)
            if use_cache:
                with _llm_cache_lock:
                    if cache_key in _llm_cache:
                        return _llm_cache[cache_key], model, (idx > 0)

            try:
                resp = self._call_generate(
                    model, prompt, temperature, max_tokens, stream=False
                )
                data = resp.json()
                text = data.get("response", "").strip()

                if use_cache:
                    with _llm_cache_lock:
                        _llm_cache[cache_key] = text

                return text, model, (idx > 0)
            except Exception as e:
                last_error = e
                continue

        raise RuntimeError(
            f"OllamaClient: all models failed: {self.models}. Last error: {last_error}"
        )

    def stream(
        self,
        prompt: str,
        temperature: float = 0.2,
        max_tokens: Optional[int] = None,
    ) -> Generator[str, None, None]:
        last_error: Optional[Exception] = None

        for model in self.models:
            try:
                resp = self._call_generate(
                    model, prompt, temperature, max_tokens, stream=True
                )
                for line in resp.iter_lines():
                    if not line:
                        continue
                    try:
                        data = json.loads(line.decode("utf-8"))
                        chunk = data.get("response", "")
                        if chunk:
                            yield chunk
                    except Exception:
                        continue
                return
            except Exception as e:
                last_error = e
                continue

        raise RuntimeError(
            f"OllamaClient.stream: all models failed: {self.models}. Last error: {last_error}"
        )
