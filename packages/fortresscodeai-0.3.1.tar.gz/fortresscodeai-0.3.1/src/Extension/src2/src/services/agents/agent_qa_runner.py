# agent_qa_runner.py
import json

def run_tests(agent, test_suite_path):
    with open(test_suite_path) as f:
        tests = json.load(f)
    results = []
    for test in tests:
        output = agent.run(test["input"])
        passed = output.strip() == test["expected_output"].strip()
        results.append({"test": test["name"], "passed": passed})
    return results
