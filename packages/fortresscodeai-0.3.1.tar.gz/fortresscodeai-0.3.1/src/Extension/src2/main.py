from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware

from .core.logging import setup_logging
from .dev.auth import router as auth_router
from .dev.health import router as health_router
from .dev.logs import router as logs_router
from .dev.benchmarks import router as benchmarks_router
from .dev.metrics import router as metrics_router
from .dev.websocket_bus import router as ws_router
from .dev.ai_fix import router as ai_fix_router
from .dev.policy_api import router as policy_router
from .dev.agents_api import router as agents_router
from .dev.security_api import router as security_router
from .dev.teams_api import router as teams_router
from .dev.security import require_dev_token

setup_logging()

app = FastAPI(title="FortressCodeAI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Unprotected
app.include_router(auth_router, prefix="/dev", tags=["dev-auth"])

protected = [Depends(require_dev_token)]

# Protected
app.include_router(health_router, prefix="/dev", tags=["dev-health"], dependencies=protected)
app.include_router(logs_router, prefix="/dev", tags=["dev-logs"], dependencies=protected)
app.include_router(benchmarks_router, prefix="/dev", tags=["dev-benchmarks"], dependencies=protected)
app.include_router(metrics_router, prefix="/dev", tags=["dev-metrics"], dependencies=protected)
app.include_router(ws_router, prefix="/dev", tags=["dev-websocket"], dependencies=protected)
app.include_router(ai_fix_router, prefix="/dev", tags=["dev-ai"], dependencies=protected)
app.include_router(policy_router, prefix="/dev", tags=["dev-policy"], dependencies=protected)
app.include_router(agents_router, prefix="/dev", tags=["dev-agents"], dependencies=protected)
app.include_router(security_router, prefix="/dev", tags=["dev-security"], dependencies=protected)
app.include_router(teams_router, prefix="/dev", tags=["dev-teams"], dependencies=protected)
