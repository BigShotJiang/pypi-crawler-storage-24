# fortress_env/cli.py
import argparse
from .loop import run_environment_builder

def main():
    parser = argparse.ArgumentParser(description="Fortress Environment Builder")
    parser.add_argument(
        "project_path",
        help="Path to the project to analyze and prepare environment for",
    )
    args = parser.parse_args()
    run_environment_builder(args.project_path)

if __name__ == "__main__":
    main()
