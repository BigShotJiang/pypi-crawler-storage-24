# fortress_env/governance_policy.py
from __future__ import annotations
from pathlib import Path
from typing import List, Pattern
import re

# Directories/files that should never be touched
FORBIDDEN_PATHS: List[str] = [
    ".git",
    ".github",
    ".vscode",
    "node_modules",
    "__pycache__",
    ".env",
    ".env.local",
    "secrets",
    "keys",
    "certs",
    "config/production",
]

# File patterns considered sensitive
SENSITIVE_FILE_PATTERNS: List[Pattern] = [
    re.compile(r".*\.pem$", re.IGNORECASE),
    re.compile(r".*\.key$", re.IGNORECASE),
    re.compile(r".*\.pfx$", re.IGNORECASE),
    re.compile(r".*\.p12$", re.IGNORECASE),
    re.compile(r".*\.env(\..+)?$", re.IGNORECASE),
]

# Content patterns considered sensitive
SENSITIVE_CONTENT_PATTERNS: List[Pattern] = [
    re.compile(r"aws_access_key_id\s*=", re.IGNORECASE),
    re.compile(r"aws_secret_access_key\s*=", re.IGNORECASE),
    re.compile(r"api[_-]?key\s*[:=]", re.IGNORECASE),
    re.compile(r"secret[_-]?key\s*[:=]", re.IGNORECASE),
    re.compile(r"PRIVATE KEY-----", re.IGNORECASE),
]
