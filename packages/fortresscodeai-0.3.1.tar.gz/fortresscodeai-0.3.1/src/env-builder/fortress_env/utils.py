# fortress_env/utils.py
from __future__ import annotations
import subprocess
from pathlib import Path
from typing import Tuple

def run_cmd(cmd: str, cwd: Path) -> Tuple[int, str, str]:
    """Run a shell command and capture exit code, stdout, stderr."""
    print(f"[CMD] {cmd} (cwd={cwd})")
    proc = subprocess.Popen(
        cmd,
        cwd=str(cwd),
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    out, err = proc.communicate()
    return proc.returncode, out or "", err or ""

def safe_read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return ""

def safe_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
