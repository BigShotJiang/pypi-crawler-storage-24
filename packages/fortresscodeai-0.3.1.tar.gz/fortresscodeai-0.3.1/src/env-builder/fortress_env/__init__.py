# fortress_env/__init__.py
__version__ = "0.1.0"
