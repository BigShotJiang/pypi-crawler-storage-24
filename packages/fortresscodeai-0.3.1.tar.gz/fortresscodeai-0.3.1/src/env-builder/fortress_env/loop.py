# fortress_env/loop.py
from __future__ import annotations
from pathlib import Path

from .governance import is_path_allowed
from .modules.repo_scanner import run as scan_repo
from .modules.env_generator import run as generate_env
from .modules.installer import run as install_env
from .modules.validator import run as validate_env
from .modules.debug_agent import run as debug_env

MAX_ITERATIONS = 5

def run_environment_builder(project_path: str) -> None:
    project_root = Path(project_path).resolve()
    print(f"[Fortress] 🔍 Starting environment build for: {project_root}")

    # Governance: ensure project root is allowed
    if not is_path_allowed(project_root, project_root):
        print("[Fortress] Project path blocked by governance. Aborting.")
        return

    scan_result = scan_repo({"project_path": str(project_root)})
    print("[Fortress] Scan result:", scan_result)

    env_spec = generate_env({
        "project_path": str(project_root),
        "scan_result": scan_result,
    })
    print("[Fortress] Initial env spec:", env_spec)

    for iteration in range(1, MAX_ITERATIONS + 1):
        print(f"\n[Fortress] 🔁 Iteration {iteration}/{MAX_ITERATIONS}")

        install_result = install_env({
            "project_path": str(project_root),
            "env_spec": env_spec,
        })
        print("[Fortress] Install result:", install_result)

        validate_result = validate_env({
            "project_path": str(project_root),
            "env_spec": env_spec,
        })
        print("[Fortress] Validate result:", validate_result)

        if validate_result.get("status") == "ok":
            print("\n[Fortress] ✅ Environment is valid and ready.")
            return

        debug_result = debug_env({
            "project_path": str(project_root),
            "env_spec": env_spec,
            "validate_result": validate_result,
        })
        print("[Fortress] Debug result:", debug_result)

        env_spec = debug_result.get("env_spec", env_spec)

    print("\n[Fortress] ❌ Max iterations reached. Environment may still be broken.")
