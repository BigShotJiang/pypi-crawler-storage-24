# fortress_env/governance.py
from __future__ import annotations
from pathlib import Path
import yaml
import fnmatch
import datetime
import os

_policy_path = Path(__file__).parent / "fortress.policy.yaml"
_default_policy = {
    "forbidden_paths": ["infra/", ".github/"],
    "sensitive_files": [".env", ".env.local", "secrets.yml", "credentials.json", "id_rsa"],
    "max_files_changed": 10,
    "allow_system_installs": False,
    "announce_on_sensitive_discovery": True,
    "audit_log": "./fortress_governance.log",
}

def _load_policy() -> dict:
    try:
        if _policy_path.exists():
            with _policy_path.open("r", encoding="utf-8") as f:
                return yaml.safe_load(f) or _default_policy
    except Exception:
        pass
    return _default_policy

_policy = _load_policy()

def _write_audit(entry: str) -> None:
    try:
        log_path = Path(_policy.get("audit_log", "./fortress_governance.log"))
        timestamp = datetime.datetime.utcnow().isoformat() + "Z"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(f"{timestamp} {entry}\n")
    except Exception:
        pass

def is_path_allowed(project_root: str | Path, target_path: str | Path) -> bool:
    """
    Returns True if the target_path is allowed to be read/written.
    If disallowed, announces and writes to audit log.
    """
    project_root = Path(project_root).resolve()
    target = Path(target_path)
    if not target.is_absolute():
        target = (project_root / target).resolve()

    # Normalize
    try:
        target_str = str(target)
    except Exception:
        target_str = str(target)

    # Check forbidden path prefixes
    for forbidden in _policy.get("forbidden_paths", []):
        forbidden_path = (project_root / forbidden).resolve()
        try:
            # If target is inside forbidden_path
            if forbidden_path == target or forbidden_path in target.parents:
                msg = f"[Governance] BLOCKED access to forbidden path: {target_str}"
                if _policy.get("announce_on_sensitive_discovery", True):
                    print(msg)
                _write_audit(msg)
                return False
        except Exception:
            continue

    # Check sensitive file names (glob)
    for pattern in _policy.get("sensitive_files", []):
        try:
            if fnmatch.fnmatch(target.name, pattern) or fnmatch.fnmatch(target_str, f"*{pattern}*"):
                msg = f"[Governance] SENSITIVE file discovered: {target_str}"
                if _policy.get("announce_on_sensitive_discovery", True):
                    print(msg)
                _write_audit(msg)
                return False
        except Exception:
            continue

    # If path is outside project root, block by default
    try:
        if not str(target).startswith(str(project_root)):
            msg = f"[Governance] BLOCKED access outside project root: {target_str}"
            if _policy.get("announce_on_sensitive_discovery", True):
                print(msg)
            _write_audit(msg)
            return False
    except Exception:
        pass

    return True

def check_system_install_allowed() -> bool:
    return bool(_policy.get("allow_system_installs", False))
