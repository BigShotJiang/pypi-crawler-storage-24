# fortress_env/modules/installer.py
from __future__ import annotations
from pathlib import Path
from typing import Dict

from ..utils import run_cmd
from ..governance import is_path_allowed, check_system_install_allowed

def run(input: dict) -> dict:
    project_path = Path(input["project_path"]).resolve()
    env_spec = input.get("env_spec", {})

    status: Dict[str, str] = {}
    logs: Dict[str, dict] = {}

    # Python
    req_file = env_spec.get("python", {}).get("requirements_file")
    if req_file and Path(req_file).exists():
        req_path = Path(req_file)
        if not is_path_allowed(project_path, req_path):
            status["python"] = "blocked_by_governance"
            logs["python"] = {"code": None, "stdout": "", "stderr": "Governance blocked install"}
        else:
            code, out, err = run_cmd("pip install -r requirements.txt", cwd=project_path)
            status["python"] = "ok" if code == 0 else "error"
            logs["python"] = {"code": code, "stdout": out, "stderr": err}

    # Node
    pkg_file = env_spec.get("node", {}).get("package_json")
    if pkg_file and Path(pkg_file).exists():
        pkg_path = Path(pkg_file)
        if not is_path_allowed(project_path, pkg_path):
            status["node"] = "blocked_by_governance"
            logs["node"] = {"code": None, "stdout": "", "stderr": "Governance blocked install"}
        else:
            code, out, err = run_cmd("npm install --no-audit --no-fund", cwd=project_path)
            status["node"] = "ok" if code == 0 else "error"
            logs["node"] = {"code": code, "stdout": out, "stderr": err}

    # Docker (optional) - skip by default
    dockerfile = env_spec.get("docker", {}).get("dockerfile")
    if dockerfile and Path(dockerfile).exists():
        status["docker"] = "skipped"

    # System-level installs guard
    if not check_system_install_allowed():
        logs["system_installs"] = {"allowed": False, "note": "System installs are disabled by governance."}

    return {"status": status, "logs": logs}
