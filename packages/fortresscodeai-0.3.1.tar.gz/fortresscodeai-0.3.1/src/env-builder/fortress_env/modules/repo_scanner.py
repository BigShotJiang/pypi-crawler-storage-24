# fortress_env/modules/repo_scanner.py
from __future__ import annotations
from pathlib import Path
import ast
import json
from typing import Dict, List, Set

from ..utils import safe_read
from ..governance import is_path_allowed

PY_IMPORT_BUILTINS = set([
    "sys", "os", "typing", "pathlib", "json", "re", "math", "logging",
    "itertools", "functools", "subprocess", "datetime", "time", "collections",
])

JS_TS_BUILTINS = set([
    "react", "react-dom",
])

def _scan_python_imports(files: List[Path]) -> Set[str]:
    imports: Set[str] = set()
    for f in files:
        if not is_path_allowed(f.parent, f):
            continue
        text = safe_read(f)
        if not text:
            continue
        try:
            tree = ast.parse(text)
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split(".")[0]
                    if root not in PY_IMPORT_BUILTINS:
                        imports.add(root)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    root = node.module.split(".")[0]
                    if root not in PY_IMPORT_BUILTINS:
                        imports.add(root)
    return imports

def _scan_js_ts_imports(files: List[Path]) -> Set[str]:
    imports: Set[str] = set()
    for f in files:
        if not is_path_allowed(f.parent, f):
            continue
        text = safe_read(f)
        if not text:
            continue
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("import "):
                if " from " in line:
                    _, rest = line.split(" from ", 1)
                    mod = rest.strip().strip(";").strip("'").strip('"')
                    if not mod.startswith(".") and mod not in JS_TS_BUILTINS:
                        imports.add(mod.split("/")[0])
    return imports

def _parse_requirements(req_path: Path) -> Set[str]:
    if not req_path.exists() or not is_path_allowed(req_path.parent, req_path):
        return set()
    deps = set()
    for line in safe_read(req_path).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        name = line.split("==")[0].split(">=")[0].split("<=")[0].strip()
        if name:
            deps.add(name.lower())
    return deps

def _parse_package_json(pkg_path: Path) -> Dict[str, str]:
    if not pkg_path.exists() or not is_path_allowed(pkg_path.parent, pkg_path):
        return {}
    try:
        data = json.loads(safe_read(pkg_path))
    except Exception:
        return {}
    deps = {}
    for section in ("dependencies", "devDependencies", "peerDependencies"):
        for k, v in data.get(section, {}).items():
            deps[k] = v
    return deps

def run(input: dict) -> dict:
    project_path = Path(input["project_path"]).resolve()

    # If project root is disallowed, abort early
    if not is_path_allowed(project_path, project_path):
        return {"error": "project path disallowed by governance"}

    py_files = []
    ts_js_files = []
    for f in project_path.rglob("*"):
        if f.is_file():
            if f.suffix == ".py" and is_path_allowed(project_path, f):
                py_files.append(f)
            if f.suffix in (".ts", ".tsx", ".js", ".jsx") and is_path_allowed(project_path, f):
                ts_js_files.append(f)

    languages: List[str] = []
    if py_files:
        languages.append("python")
    if ts_js_files:
        languages.append("javascript/typescript")

    package_managers: List[str] = []
    if (project_path / "pyproject.toml").exists() or (project_path / "requirements.txt").exists():
        package_managers.append("pip")
    if (project_path / "package.json").exists():
        package_managers.append("npm")

    frameworks_detected = set()
    for f in py_files[:200]:
        text = safe_read(f)
        if "fastapi" in text:
            frameworks_detected.add("fastapi")
        if "django" in text:
            frameworks_detected.add("django")
    for f in ts_js_files[:200]:
        text = safe_read(f)
        if "react" in text:
            frameworks_detected.add("react")
        if "next/router" in text or "next/navigation" in text:
            frameworks_detected.add("nextjs")

    py_imports = _scan_python_imports(py_files[:500])
    js_imports = _scan_js_ts_imports(ts_js_files[:500])

    req_deps = _parse_requirements(project_path / "requirements.txt")
    pkg_deps = _parse_package_json(project_path / "package.json")

    missing_py = sorted([m for m in py_imports if m.lower() not in req_deps])
    missing_js = sorted([m for m in js_imports if m not in pkg_deps])

    return {
        "project_path": str(project_path),
        "languages": languages,
        "frameworks": sorted(frameworks_detected),
        "package_managers": package_managers,
        "python_imports": sorted(py_imports),
        "js_imports": sorted(js_imports),
        "python_requirements": sorted(req_deps),
        "node_dependencies": pkg_deps,
        "missing_python_deps": missing_py,
        "missing_node_deps": missing_js,
    }
