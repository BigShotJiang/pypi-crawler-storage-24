# fortress_env/modules/validator.py
from __future__ import annotations
from pathlib import Path
from typing import Dict

from ..utils import run_cmd
from ..governance import is_path_allowed

def run(input: dict) -> dict:
    project_path = Path(input["project_path"]).resolve()

    results: Dict[str, str] = {}
    logs: Dict[str, dict] = {}
    overall_status = "ok"

    # Python tests
    has_pytests = (project_path / "pytest.ini").exists() or any(project_path.rglob("test_*.py"))
    if has_pytests:
        # ensure pytest files allowed
        if not is_path_allowed(project_path, project_path / "pytest.ini"):
            results["pytest"] = "blocked_by_governance"
            logs["pytest"] = {"code": None, "stdout": "", "stderr": "Governance blocked pytest"}
            overall_status = "error"
        else:
            code, out, err = run_cmd("pytest -q", cwd=project_path)
            results["pytest"] = "ok" if code == 0 else "error"
            logs["pytest"] = {"code": code, "stdout": out, "stderr": err}
            if code != 0:
                overall_status = "error"

    # Node tests and build
    pkg = project_path / "package.json"
    if pkg.exists():
        if not is_path_allowed(project_path, pkg):
            results["npm_test"] = "blocked_by_governance"
            logs["npm_test"] = {"code": None, "stdout": "", "stderr": "Governance blocked npm test"}
            results["npm_build"] = "blocked_by_governance"
            logs["npm_build"] = {"code": None, "stdout": "", "stderr": "Governance blocked npm build"}
            overall_status = "error"
        else:
            code, out, err = run_cmd("npm test --silent", cwd=project_path)
            results["npm_test"] = "ok" if code == 0 else "error"
            logs["npm_test"] = {"code": code, "stdout": out, "stderr": err}
            if code != 0:
                overall_status = "error"

            code, out, err = run_cmd("npm run build --silent", cwd=project_path)
            results["npm_build"] = "ok" if code == 0 else "error"
            logs["npm_build"] = {"code": code, "stdout": out, "stderr": err}
            if code != 0:
                overall_status = "error"

    return {
        "status": overall_status,
        "results": results,
        "logs": logs,
    }
