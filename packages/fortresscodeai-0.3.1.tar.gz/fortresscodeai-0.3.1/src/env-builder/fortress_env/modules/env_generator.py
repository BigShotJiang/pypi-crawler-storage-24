# fortress_env/modules/env_generator.py
from __future__ import annotations
from pathlib import Path
import json
from typing import Dict

from ..utils import safe_read, safe_write
from ..governance import is_path_allowed

def run(input: dict) -> dict:
    project_path = Path(input["project_path"]).resolve()
    scan = input.get("scan_result", {})

    env_spec: Dict[str, dict] = {
        "python": {},
        "node": {},
        "docker": {},
    }

    # ---------- Python ----------
    if "python" in scan.get("languages", []):
        req_path = project_path / "requirements.txt"
        if not is_path_allowed(project_path, req_path):
            print(f"[EnvGen] Governance blocked access to {req_path}")
        else:
            existing = set()
            if req_path.exists():
                for line in safe_read(req_path).splitlines():
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    name = line.split("==")[0].split(">=")[0].split("<=")[0].strip()
                    if name:
                        existing.add(name.lower())

            missing = [m for m in scan.get("missing_python_deps", []) if m.lower() not in existing]

            if missing:
                print(f"[EnvGen] Adding missing Python deps to requirements.txt: {missing}")
                content = safe_read(req_path) if req_path.exists() else "# Fortress-generated requirements\n"
                for dep in missing:
                    content += f"{dep}\n"
                safe_write(req_path, content)

            env_spec["python"]["requirements_file"] = str(req_path)

    # ---------- Node ----------
    if "npm" in scan.get("package_managers", []):
        pkg_path = project_path / "package.json"
        if not is_path_allowed(project_path, pkg_path):
            print(f"[EnvGen] Governance blocked access to {pkg_path}")
        else:
            if pkg_path.exists():
                try:
                    data = json.loads(safe_read(pkg_path))
                except Exception:
                    data = {"name": "fortress-app", "version": "0.1.0", "dependencies": {}, "scripts": {}}
            else:
                print("[EnvGen] Creating package.json")
                data = {"name": "fortress-app", "version": "0.1.0", "dependencies": {}, "scripts": {}}

            deps = data.setdefault("dependencies", {})
            dev_deps = data.setdefault("devDependencies", {})
            scripts = data.setdefault("scripts", {})

            missing_js = scan.get("missing_node_deps", [])
            if missing_js:
                print(f"[EnvGen] Adding missing Node deps to package.json: {missing_js}")
                for dep in missing_js:
                    if dep not in deps and dep not in dev_deps:
                        deps[dep] = "latest"

            scripts.setdefault("build", "vite build || echo \"no build script defined\"")
            scripts.setdefault("dev", "vite dev || echo \"no dev script defined\"")
            scripts.setdefault("test", "echo \"no test script defined\"")

            safe_write(pkg_path, json.dumps(data, indent=2))
            env_spec["node"]["package_json"] = str(pkg_path)

    # ---------- Docker ----------
    dockerfile = project_path / "Dockerfile"
    if not is_path_allowed(project_path, dockerfile):
        print(f"[EnvGen] Governance blocked creating Dockerfile at {dockerfile}")
    else:
        if not dockerfile.exists():
            print("[EnvGen] Creating basic Dockerfile")
            docker_content = """FROM python:3.11-slim

WORKDIR /app
COPY . .

RUN pip install -r requirements.txt || true

EXPOSE 8000
CMD ["python", "-m", "http.server", "8000"]
"""
            safe_write(dockerfile, docker_content)
        env_spec["docker"]["dockerfile"] = str(dockerfile)

    return env_spec
