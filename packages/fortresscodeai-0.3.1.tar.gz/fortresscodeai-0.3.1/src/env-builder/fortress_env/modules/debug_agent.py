# fortress_env/modules/debug_agent.py
from __future__ import annotations
from pathlib import Path
import json
from typing import Dict, Any

from ..utils import safe_read, safe_write
from ..governance import is_path_allowed

def _fix_missing_node_script(project_path: Path, script_name: str, fallback_cmd: str) -> bool:
    pkg_path = project_path / "package.json"
    if not pkg_path.exists() or not is_path_allowed(project_path, pkg_path):
        return False
    try:
        data = json.loads(safe_read(pkg_path))
    except Exception:
        return False
    scripts = data.setdefault("scripts", {})
    if script_name not in scripts:
        print(f"[Debug] Adding missing npm script '{script_name}'")
        scripts[script_name] = fallback_cmd
        safe_write(pkg_path, json.dumps(data, indent=2))
        return True
    return False

def _detect_missing_python_module(stderr: str) -> str | None:
    # Very naive: look for "ModuleNotFoundError: No module named 'x'"
    for line in stderr.splitlines():
        line = line.strip()
        if "ModuleNotFoundError" in line and "No module named" in line:
            parts = line.split("'")
            if len(parts) >= 2:
                return parts[1]
    return None

def _add_python_dep_to_requirements(project_path: Path, dep: str) -> bool:
    req_path = project_path / "requirements.txt"
    if not is_path_allowed(project_path, req_path):
        print(f"[Debug] Governance blocked modifying {req_path}")
        return False
    content = safe_read(req_path) if req_path.exists() else "# Fortress-generated requirements\n"
    if dep.lower() in content.lower():
        return False
    print(f"[Debug] Adding missing Python dep '{dep}' to requirements.txt")
    content += f"{dep}\n"
    safe_write(req_path, content)
    return True

def run(input: dict) -> dict:
    project_path = Path(input["project_path"]).resolve()
    env_spec: Dict[str, Any] = input.get("env_spec", {})
    validate_result = input.get("validate_result", {})

    print("[Debug] Analyzing validation failures...")

    logs = validate_result.get("logs", {})
    changed = False

    # Fix missing npm scripts
    npm_test_log = logs.get("npm_test", {})
    if npm_test_log.get("code") not in (0, None):
        stderr = npm_test_log.get("stderr", "")
        if "Missing script: \"test\"" in stderr or "npm ERR! Missing script: \"test\"" in stderr:
            if _fix_missing_node_script(project_path, "test", "echo \"no test script defined\""):
                changed = True

    npm_build_log = logs.get("npm_build", {})
    if npm_build_log.get("code") not in (0, None):
        stderr = npm_build_log.get("stderr", "")
        if "Missing script: \"build\"" in stderr or "npm ERR! Missing script: \"build\"" in stderr:
            if _fix_missing_node_script(project_path, "build", "vite build || echo \"no build script defined\""):
                changed = True

    # Fix missing Python modules
    pytest_log = logs.get("pytest", {})
    if pytest_log.get("code") not in (0, None):
        stderr = pytest_log.get("stderr", "")
        missing_mod = _detect_missing_python_module(stderr)
        if missing_mod:
            if _add_python_dep_to_requirements(project_path, missing_mod):
                changed = True

    if changed:
        # Update env_spec to reflect new files
        if "python" in env_spec:
            env_spec["python"]["requirements_file"] = str(project_path / "requirements.txt")
        if "node" in env_spec:
            env_spec["node"]["package_json"] = str(project_path / "package.json")

    return {
        "env_spec": env_spec,
        "changed": changed,
        "notes": "Applied basic auto-fixes for missing scripts/deps." if changed else "No automatic fixes applied.",
    }
