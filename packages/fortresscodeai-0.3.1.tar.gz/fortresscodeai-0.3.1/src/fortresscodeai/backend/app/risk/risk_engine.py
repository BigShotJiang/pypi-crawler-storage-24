# src/fortresscodeai/backend/app/risk/risk_engine.py

from typing import Any, Dict

from app.risk.risk_map import RiskMap
from app.risk.risk_matrix import RiskMatrix
from app.risk.risk_rules import RiskRules


class RiskEngine:
    def __init__(self):
        self.map = RiskMap()
        self.matrix = RiskMatrix()
        self.rules = RiskRules()

    def score(
        self,
        workflow_id: str,
        step_name: str,
        input_data: Dict[str, Any]
    ) -> float:
        """
        Compute a risk score for a workflow step.
        Range: 0.0 (low risk) to 1.0 (critical risk)
        """

        # 1. Identify applicable risk factors
        factors = self.map.get_factors(
            workflow_id=workflow_id,
            step_name=step_name,
            input_data=input_data,
        )

        # 2. Apply rules to interpret factors
        rule_results = self.rules.evaluate(factors)

        # 3. Use the matrix to compute a final score
        score = self.matrix.compute(rule_results)

        # 4. Clamp to [0.0, 1.0]
        return max(0.0, min(score, 1.0))
