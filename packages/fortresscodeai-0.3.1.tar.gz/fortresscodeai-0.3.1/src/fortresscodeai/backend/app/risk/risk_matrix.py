import os
import re

def build_risk_matrix(rules):
    """
    Applies risk rules to workspace files and builds a risk matrix.
    """

    matrix = {"rows": [], "labels": []}

    for root, _, files in os.walk("."):
        for file in files:
            path = os.path.join(root, file)
            score = 0
            reasons = []

            for rule in rules:
                if re.search(rule["pattern"], path):
                    if rule["severity"] == "high":
                        score += 10
                    elif rule["severity"] == "medium":
                        score += 5
                    else:
                        score += 2

                    reasons.append(rule["name"])

            if score > 0:
                matrix["rows"].append({
                    "file": path,
                    "score": score,
                    "reasons": reasons
                })

    return matrix
