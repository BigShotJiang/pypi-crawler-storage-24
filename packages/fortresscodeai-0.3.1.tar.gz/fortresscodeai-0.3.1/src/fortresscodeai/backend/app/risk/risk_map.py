def build_risk_map(matrix):
    """
    Converts risk matrix into a list of risk signals per file.
    """

    risk_map = []

    for row in matrix["rows"]:
        file_path = row["file"]
        score = row["score"]
        reasons = row["reasons"]

        risk_map.append({
            "file": file_path,
            "riskScore": score,
            "reasons": reasons
        })

    return risk_map
