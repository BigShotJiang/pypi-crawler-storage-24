import json
import os

RISK_RULES_FILE = "risk_rules.json"

def load_risk_rules():
    """
    Loads risk rules from risk_rules.json.
    """

    if not os.path.exists(RISK_RULES_FILE):
        return []

    with open(RISK_RULES_FILE, "r") as f:
        return json.load(f)