def compute_integrity(sbom):
    """
    Computes SBOM integrity based on:
    - missing metadata
    - missing versions
    - missing licenses
    """

    components = sbom.get("components", [])
    total = len(components)

    if total == 0:
        return {
            "integrity": 0,
            "totalDependencies": 0,
            "vulnerableDependencies": 0,
            "missingMetadata": 0
        }

    missing = 0
    for c in components:
        if not c.get("version") or not c.get("licenses"):
            missing += 1

    integrity_score = max(0, 100 - (missing / total * 100))

    return {
        "integrity": round(integrity_score, 2),
        "totalDependencies": total,
        "vulnerableDependencies": 0,  # real vuln scanning can be added later
        "missingMetadata": missing
    }
