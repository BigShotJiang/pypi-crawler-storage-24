import json
import os

UNAPPROVED_FILE = "unapproved_dependencies.json"


def find_unapproved_dependencies(sbom):
    """
    Detects dependencies that violate supply chain rules.
    """

    if not os.path.exists(UNAPPROVED_FILE):
        return []

    with open(UNAPPROVED_FILE, "r") as f:
        rules = json.load(f)

    unapproved = []
    for c in sbom.get("components", []):
        if c["name"] in rules.get("blocked", []):
            unapproved.append(c)

    return unapproved
