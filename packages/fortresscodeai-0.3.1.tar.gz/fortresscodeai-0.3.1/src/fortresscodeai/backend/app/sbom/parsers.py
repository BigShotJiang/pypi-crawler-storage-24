import os
import json
from cyclonedx.parser import JSONParser
from cyclonedx.model import Bom

SBOM_FILE = "sbom.json"


def load_sbom():
    """
    Loads and parses a CycloneDX SBOM.
    """

    if not os.path.exists(SBOM_FILE):
        return {"components": []}

    with open(SBOM_FILE, "r") as f:
        data = json.load(f)

    try:
        parser = JSONParser(json_data=data)
        bom: Bom = parser.get_bom()

        components = []
        for c in bom.components:
            components.append({
                "name": c.name,
                "version": c.version,
                "purl": c.purl.to_string() if c.purl else None,
                "licenses": [lic.id for lic in c.licenses] if c.licenses else []
            })

        return {"components": components}

    except Exception:
        # Fallback: raw JSON
        return data
