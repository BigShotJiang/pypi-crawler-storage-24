from __future__ import annotations

from .workflow_models import WorkflowDefinition, WorkflowStep


class PolicyEngine:
    def validate_workflow(self, workflow: WorkflowDefinition) -> bool:
        if workflow.metadata.get("risk_tag") == "role_displacement":
            return False
        if workflow.metadata.get("requires_union_review"):
            return False
        return True

    def validate_step(self, step: WorkflowStep, workflow: WorkflowDefinition) -> bool:
        if workflow.metadata.get("sensitivity") == "high" and step.action == "call_external_api":
            return False
        return True
