from __future__ import annotations

import time
from typing import Dict, Any

from .workflow_models import WorkflowExecutionContext, WorkflowStep


class HITLManager:
    def __init__(self):
        self._pending: Dict[str, Dict[str, Any]] = {}
        self._approved: Dict[str, Dict[str, Any]] = {}

    def request_approval(self, ctx: WorkflowExecutionContext, step: WorkflowStep) -> None:
        self._pending.setdefault(ctx.execution_id, {})[step.id] = {
            "step": step,
            "requested_at": time.time(),
        }

    def is_approved(self, ctx: WorkflowExecutionContext, step: WorkflowStep) -> bool:
        return step.id in self._approved.get(ctx.execution_id, {})

    def approve(self, ctx: WorkflowExecutionContext, step_id: str, approved_by: str) -> bool:
        pending_steps = self._pending.get(ctx.execution_id, {})
        if step_id not in pending_steps:
            return False

        step_info = pending_steps.pop(step_id)
        self._approved.setdefault(ctx.execution_id, {})[step_id] = {
            "approved_by": approved_by,
            "approved_at": time.time(),
            "step": step_info["step"],
        }
        return True
