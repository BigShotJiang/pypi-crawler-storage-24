from __future__ import annotations

import logging
from typing import Optional, Dict, Any

logger = logging.getLogger("autobuilder_orchestration")
logger.setLevel(logging.INFO)


class SecurityEvents:
    def alert(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        logger.warning(f"[SECURITY_ALERT] {message} | context={context or {}}")
