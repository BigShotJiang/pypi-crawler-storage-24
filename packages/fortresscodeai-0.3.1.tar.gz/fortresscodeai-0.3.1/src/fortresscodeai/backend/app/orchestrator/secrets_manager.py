from __future__ import annotations


class SecretsManager:
    def get_secret(self, name: str) -> str:
        # Placeholder – wire to real secret backend later
        return f"SECRET({name})"
