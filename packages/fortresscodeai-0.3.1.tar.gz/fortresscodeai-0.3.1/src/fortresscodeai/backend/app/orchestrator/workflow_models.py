from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Any

from pydantic import BaseModel, Field


class WorkflowStatus(str, Enum):
    PENDING_VALIDATION = "PENDING_VALIDATION"
    BLOCKED_POLICY = "BLOCKED_POLICY"
    PENDING_HITL = "PENDING_HITL"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class WorkflowStepModel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    action: str
    params: Dict[str, Any] = Field(default_factory=dict)
    requires_hitl: bool = False


class WorkflowDefinitionModel(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    created_by: str
    steps: List[WorkflowStepModel]
    metadata: Dict[str, Any] = Field(default_factory=dict)


class WorkflowExecutionResponse(BaseModel):
    execution_id: str
    workflow_id: str
    status: WorkflowStatus
    current_step_index: int
    results: Dict[str, Any]
    logs: List[Dict[str, Any]]


@dataclass
class WorkflowStep:
    id: str
    name: str
    action: str
    params: Dict[str, Any]
    requires_hitl: bool = False


@dataclass
class WorkflowDefinition:
    id: str
    name: str
    created_by: str
    steps: List[WorkflowStep]
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class WorkflowExecutionContext:
    execution_id: str
    workflow: WorkflowDefinition
    status: WorkflowStatus
    current_step_index: int = 0
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    logs: List[Dict[str, Any]] = field(default_factory=list)
    results: Dict[str, Any] = field(default_factory=dict)
