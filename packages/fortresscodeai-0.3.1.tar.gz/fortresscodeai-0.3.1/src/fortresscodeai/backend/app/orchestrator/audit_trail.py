from __future__ import annotations

import time
from typing import Dict, Any

from .workflow_models import WorkflowExecutionContext


class AuditTrail:
    def record(self, ctx: WorkflowExecutionContext, event: Dict[str, Any]) -> None:
        event["timestamp"] = time.time()
        event["execution_id"] = ctx.execution_id
        ctx.logs.append(event)
