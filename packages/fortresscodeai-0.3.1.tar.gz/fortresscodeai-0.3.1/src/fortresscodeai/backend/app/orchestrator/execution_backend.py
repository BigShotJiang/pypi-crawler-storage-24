from __future__ import annotations

from typing import Any

from .workflow_models import WorkflowStep, WorkflowExecutionContext


class ExecutionBackend:
    async def execute_step(self, step: WorkflowStep, ctx: WorkflowExecutionContext) -> Any:
        if step.action == "call_llm":
            prompt = step.params.get("prompt", "")
            return {"status": "ok", "type": "llm_response", "content": f"LLM_RESPONSE_FOR: {prompt}"}

        if step.action == "transform_data":
            data = step.params.get("data", "")
            op = step.params.get("operation", "identity")
            if op == "uppercase" and isinstance(data, str):
                return {"status": "ok", "type": "transform", "result": data.upper()}
            return {"status": "ok", "type": "transform", "result": data}

        if step.action == "call_external_api":
            endpoint = step.params.get("endpoint", "unknown")
            return {"status": "ok", "type": "external_api", "endpoint": endpoint}

        return {"status": "ok", "type": "noop"}
