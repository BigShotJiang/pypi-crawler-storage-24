from __future__ import annotations

import asyncio
from typing import Any, Dict, Optional, List, Callable

from fastapi import HTTPException
from pydantic import ValidationError

from ..models.task import Task, TaskType
from ..workers.worker_registry import (
    WORKER_REGISTRY,
    WorkerConfig,
    select_workers_for_task_type,
)
from ..workers.runtimes.interpreter import interpreter_runtime
from ..workers.runtimes.researcher import researcher_runtime
from ..workers.runtimes.codegen import codegen_runtime
from ..workers.runtimes.executor import executor_runtime
from ..workers.runtimes.validator import validator_runtime

from .policy_engine import PolicyEngine
from .hitl_manager import HITLManager
from .audit_trail import AuditTrail
from .security_events import SecurityEvents


class TaskOrchestrator:
    """
    Governance-first orchestrator for Task-based worker execution.

    This runs alongside AutobuilderOrchestrator:
    - AutobuilderOrchestrator: workflow graphs (steps, execution_backend)
    - TaskOrchestrator: worker-based, schema-driven tasks
    """

    def __init__(
        self,
        policy_engine: PolicyEngine,
        hitl_manager: HITLManager,
        audit_trail: AuditTrail,
        security_events: SecurityEvents,
        worker_runtimes: Dict[str, Callable[[Task], Any]],
    ):
        worker_runtimes = {
            "interpreter": interpreter_runtime,
            "researcher": researcher_runtime,
            "codegen": codegen_runtime,
            "executor": executor_runtime,
            "validator": validator_runtime,
        }
        task_orchestrator = TaskOrchestrator(
            policy_engine,
            hitl_manager,
            audit_trail,
            security_events,
            worker_runtimes,
        )

        self.policy_engine = policy_engine
        self.hitl_manager = hitl_manager
        self.audit_trail = audit_trail
        self.security_events = security_events
        self.worker_runtimes = worker_runtimes

        # In-memory execution store; swap to DB/Redis when needed.
        self._tasks: Dict[str, Task] = {}
        self._results: Dict[str, Any] = {}
        self._status: Dict[str, str] = {}

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    def submit_task(self, payload: Dict[str, Any]) -> Task:
        """
        Validate and register a new Task from an incoming payload.
        """
        try:
            task = Task(**payload)
        except ValidationError as e:
            raise HTTPException(status_code=400, detail={"error": "Invalid task payload", "details": e.errors()})

        self._tasks[task.task_id] = task
        self._status[task.task_id] = "PENDING_VALIDATION"

        self.audit_trail.record_task(task.to_audit_record("TASK_SUBMITTED"))

        # Policy engine can inspect task.objective, governance, routing, etc.
        if not self.policy_engine.validate_task(task):  # you’ll add this method
            self._status[task.task_id] = "BLOCKED_POLICY"
            self.audit_trail.record_task(task.to_audit_record("TASK_BLOCKED_POLICY"))
            self.security_events.alert(
                "Task blocked by policy engine",
                {"task_id": task.task_id, "objective": task.objective},
            )
            return task

        # HITL gate if required
        if task.governance.hitl_required:
            self._status[task.task_id] = "PENDING_HITL"
            self._request_hitl(task)
        else:
            self._status[task.task_id] = "RUNNING"
            asyncio.create_task(self._run(task))

        return task

    def get_task(self, task_id: str) -> Optional[Task]:
        return self._tasks.get(task_id)

    def get_task_status(self, task_id: str) -> Optional[str]:
        return self._status.get(task_id)

    def get_task_result(self, task_id: str) -> Any:
        if task_id not in self._tasks:
            raise HTTPException(status_code=404, detail="Task not found")
        return self._results.get(task_id)

    async def approve_task(self, task_id: str, approved_by: str) -> Task:
        """
        Approve a HITL-gated task and start execution.
        """
        task = self._tasks.get(task_id)
        if not task:
            raise HTTPException(status_code=404, detail="Task not found")

        if self._status.get(task_id) != "PENDING_HITL":
            raise HTTPException(status_code=400, detail="Task is not pending HITL")

        if not self.hitl_manager.approve_task(task, approved_by):  # you’ll add this method
            raise HTTPException(status_code=400, detail="Approval failed")

        self.audit_trail.record_task(task.to_audit_record("TASK_HITL_APPROVED", {"approved_by": approved_by}))
        self._status[task_id] = "RUNNING"
        asyncio.create_task(self._run(task))
        return task

    # -------------------------------------------------------------------------
    # Internal: HITL, routing, execution
    # -------------------------------------------------------------------------

    def _request_hitl(self, task: Task) -> None:
        """
        Create a HITL checkpoint for this task.
        """
        self.hitl_manager.request_task_approval(task)  # you’ll add this method
        self.audit_trail.record_task(task.to_audit_record("TASK_HITL_REQUESTED"))

    async def _run(self, task: Task) -> None:
        """
        Core execution path for a single Task.
        """
        task_id = task.task_id
        self.audit_trail.record_task(task.to_audit_record("TASK_STARTED"))

        try:
            # 1) If this is a planning task, let interpreter decompose.
            if task.task_type in {TaskType.PLAN, TaskType.ROUTE}:
                result = await self._run_planning_task(task)
            else:
                # 2) Normal worker selection + execution.
                result = await self._run_single_worker_task(task)

            # 3) Optional validation pass.
            validated = await self._run_validation(task, result)

            self._results[task_id] = result
            self._status[task_id] = "COMPLETED"

            self.audit_trail.record_task(
                task.to_audit_record(
                    "TASK_COMPLETED",
                    {"validated": validated, "has_result": result is not None},
                )
            )

        except Exception as e:
            self._status[task_id] = "FAILED"
            self.audit_trail.record_task(
                task.to_audit_record("TASK_FAILED", {"error": str(e)})
            )
            self.security_events.alert(
                "Task execution failed",
                {"task_id": task_id, "error": str(e)},
            )

    async def _run_planning_task(self, task: Task) -> Any:
        """
        Use the interpreter worker to decompose and route subtasks.
        """
        interpreter_cfg = self._get_worker("interpreter")
        interpreter_runtime = self._get_runtime("interpreter")

        self.audit_trail.record_task(
            task.to_audit_record("TASK_PLANNING_STARTED", {"worker": interpreter_cfg["id"]})
        )

        subtasks_spec = await self._call_worker(interpreter_runtime, task)

        # Expect subtasks_spec to be a list of Task-like dicts.
        if not isinstance(subtasks_spec, list):
            raise ValueError("Interpreter must return a list of subtask specifications")

        results: List[Any] = []
        for sub_payload in subtasks_spec:
            sub_task = Task(**sub_payload, parent_task_id=task.task_id)
            self._tasks[sub_task.task_id] = sub_task
            self._status[sub_task.task_id] = "RUNNING"

            self.audit_trail.record_task(
                sub_task.to_audit_record("SUBTASK_STARTED", {"parent_task_id": task.task_id})
            )

            sub_result = await self._run_single_worker_task(sub_task)
            results.append({"task_id": sub_task.task_id, "result": sub_result})

        return {"subtask_results": results}

    async def _run_single_worker_task(self, task: Task) -> Any:
        """
        Select a worker for the given task_type and execute it.
        """
        worker_cfg = self._select_worker_for_task(task)
        runtime = self._get_runtime(worker_cfg["id"])

        self.audit_trail.record_task(
            task.to_audit_record("TASK_DISPATCHED", {"worker": worker_cfg["id"]})
        )

        result = await self._call_worker(runtime, task)

        self.audit_trail.record_task(
            task.to_audit_record("TASK_WORKER_COMPLETED", {"worker": worker_cfg["id"]})
        )

        return result

    async def _run_validation(self, task: Task, result: Any) -> bool:
        """
        Optionally run a validator worker on the result.
        """
        # You can make this conditional on governance, task_type, etc.
        validator_cfg = self._get_worker("validator")
        runtime = self._get_runtime("validator")

        validation_task_payload: Dict[str, Any] = {
            "task_type": TaskType.VALIDATE,
            "objective": f"Validate result for task {task.task_id}",
            "context": {
                "business": task.context.business,
                "technical": task.context.technical,
                "constraints": task.context.constraints,
                "examples": [],
            },
            "inputs": {
                "files": [],
                "data": {"original_task": task.to_worker_payload(), "result": result},
                "user_request": None,
            },
            "requirements": {
                "must": ["Check correctness, safety, and policy compliance."],
                "must_not": [],
                "quality_bar": "Validator must explicitly state pass/fail and reasons.",
            },
            "output_format": {
                "type": "json",
                "schema": {
                    "type": "object",
                    "properties": {
                        "passed": {"type": "boolean"},
                        "reasons": {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["passed", "reasons"],
                },
            },
            "governance": task.governance.dict(),
            "routing": {
                "preferred_workers": ["validator"],
                "max_depth": 0,
                "max_fanout": 0,
            },
        }

        validation_task = Task(**validation_task_payload)
        self.audit_trail.record_task(
            validation_task.to_audit_record("VALIDATION_STARTED", {"worker": validator_cfg["id"]})
        )

        validation_result = await self._call_worker(runtime, validation_task)

        passed = bool(validation_result.get("passed", False))
        self.audit_trail.record_task(
            validation_task.to_audit_record("VALIDATION_COMPLETED", {"passed": passed})
        )

        if not passed:
            self.security_events.alert(
                "Validation failed for task result",
                {"task_id": task.task_id, "validation": validation_result},
            )

        return passed

    # -------------------------------------------------------------------------
    # Worker selection + runtime dispatch
    # -------------------------------------------------------------------------

    def _select_worker_for_task(self, task: Task) -> WorkerConfig:
        """
        Select a worker based on task_type and optional routing hints.
        """
        candidates = select_workers_for_task_type(task.task_type)

        if not candidates:
            raise ValueError(f"No workers available for task_type={task.task_type}")

        # If preferred_workers are specified, try those first.
        preferred_ids = set(task.routing.preferred_workers or [])
        preferred = [c for c in candidates if c["id"] in preferred_ids]

        if preferred:
            return preferred[0]

        # Fallback: naive first candidate. You can add scoring here later.
        return candidates[0]

    def _get_worker(self, worker_id: str) -> WorkerConfig:
        cfg = WORKER_REGISTRY.get(worker_id)
        if not cfg or not cfg["enabled"]:
            raise ValueError(f"Worker {worker_id} is not available or disabled")
        return cfg

    def _get_runtime(self, worker_id: str):
        runtime = self.worker_runtimes.get(worker_id)
        if not runtime:
            raise ValueError(f"No runtime registered for worker {worker_id}")
        return runtime

    async def _call_worker(self, runtime: Any, task: Task) -> Any:
        """
        Call a worker runtime. Supports sync or async callables.
        """
        payload = task.to_worker_payload()
        if asyncio.iscoroutinefunction(runtime):
            return await runtime(task)
        # If runtime is sync, run in threadpool if needed later.
        return runtime(task)
