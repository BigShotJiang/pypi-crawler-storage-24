from __future__ import annotations

import asyncio
import uuid
from typing import Dict, Any, Optional

from fastapi import HTTPException

from .workflow_models import (
    WorkflowDefinitionModel,
    WorkflowDefinition,
    WorkflowStep,
    WorkflowExecutionContext,
    WorkflowStatus,
)
from .policy_engine import PolicyEngine
from .hitl_manager import HITLManager
from .audit_trail import AuditTrail
from .security_events import SecurityEvents
from .secrets_manager import SecretsManager
from .execution_backend import ExecutionBackend


class AutobuilderOrchestrator:
    def __init__(
        self,
        policy_engine: PolicyEngine,
        hitl_manager: HITLManager,
        audit_trail: AuditTrail,
        security_events: SecurityEvents,
        secrets_manager: SecretsManager,
        execution_backend: ExecutionBackend,
    ):
        self.policy_engine = policy_engine
        self.hitl_manager = hitl_manager
        self.audit_trail = audit_trail
        self.security_events = security_events
        self.secrets_manager = secrets_manager
        self.execution_backend = execution_backend

        self._executions: Dict[str, WorkflowExecutionContext] = {}

    def _requires_any_hitl(self, workflow: WorkflowDefinition) -> bool:
        return any(step.requires_hitl for step in workflow.steps)

    def _current_step(self, ctx: WorkflowExecutionContext) -> Optional[WorkflowStep]:
        if ctx.current_step_index >= len(ctx.workflow.steps):
            return None
        return ctx.workflow.steps[ctx.current_step_index]

    def get_execution(self, execution_id: str) -> Optional[WorkflowExecutionContext]:
        return self._executions.get(execution_id)

    def submit_workflow(self, wf_model: WorkflowDefinitionModel) -> WorkflowExecutionContext:
        workflow = WorkflowDefinition(
            id=wf_model.id,
            name=wf_model.name,
            created_by=wf_model.created_by,
            steps=[
                WorkflowStep(
                    id=s.id,
                    name=s.name,
                    action=s.action,
                    params=s.params,
                    requires_hitl=s.requires_hitl,
                )
                for s in wf_model.steps
            ],
            metadata=wf_model.metadata,
        )

        exec_id = str(uuid.uuid4())
        ctx = WorkflowExecutionContext(
            execution_id=exec_id,
            workflow=workflow,
            status=WorkflowStatus.PENDING_VALIDATION,
        )
        self._executions[exec_id] = ctx

        self.audit_trail.record(ctx, {"event": "workflow_submitted", "workflow_id": workflow.id})

        if not self.policy_engine.validate_workflow(workflow):
            ctx.status = WorkflowStatus.BLOCKED_POLICY
            self.audit_trail.record(ctx, {"event": "workflow_blocked_policy"})
            self.security_events.alert("Workflow blocked by policy engine", {"workflow_id": workflow.id})
            return ctx

        ctx.status = WorkflowStatus.PENDING_HITL if self._requires_any_hitl(workflow) else WorkflowStatus.RUNNING

        if ctx.status == WorkflowStatus.PENDING_HITL:
            step = self._current_step(ctx)
            if step and step.requires_hitl:
                self.hitl_manager.request_approval(ctx, step)
                self.audit_trail.record(ctx, {"event": "hitl_requested", "step_id": step.id})
        else:
            asyncio.create_task(self._run(ctx))

        return ctx

    async def approve_step(self, execution_id: str, step_id: str, approved_by: str) -> WorkflowExecutionContext:
        ctx = self._executions.get(execution_id)
        if not ctx:
            raise HTTPException(status_code=404, detail="Execution not found")

        step = self._current_step(ctx)
        if not step or step.id != step_id:
            raise HTTPException(status_code=400, detail="Step not pending approval")

        if not self.hitl_manager.approve(ctx, step_id, approved_by):
            raise HTTPException(status_code=400, detail="Approval failed")

        self.audit_trail.record(ctx, {"event": "hitl_approved", "step_id": step_id})
        ctx.status = WorkflowStatus.RUNNING
        asyncio.create_task(self._run(ctx))
        return ctx

    async def _run(self, ctx: WorkflowExecutionContext) -> None:
        while True:
            step = self._current_step(ctx)
            if not step:
                ctx.status = WorkflowStatus.COMPLETED
                self.audit_trail.record(ctx, {"event": "workflow_completed"})
                break

            if not self.policy_engine.validate_step(step, ctx.workflow):
                ctx.status = WorkflowStatus.BLOCKED_POLICY
                self.audit_trail.record(ctx, {"event": "step_blocked_policy", "step_id": step.id})
                self.security_events.alert("Step blocked by policy engine", {"step_id": step.id})
                break

            if step.requires_hitl and not self.hitl_manager.is_approved(ctx, step):
                ctx.status = WorkflowStatus.PENDING_HITL
                self.hitl_manager.request_approval(ctx, step)
                self.audit_trail.record(ctx, {"event": "hitl_requested", "step_id": step.id})
                break

            try:
                self.audit_trail.record(ctx, {"event": "step_started", "step_id": step.id})
                result = await self.execution_backend.execute_step(step, ctx)
                ctx.results[step.id] = result
                ctx.current_step_index += 1
                self.audit_trail.record(ctx, {"event": "step_completed", "step_id": step.id})
            except Exception as e:
                ctx.status = WorkflowStatus.FAILED
                self.audit_trail.record(ctx, {"event": "step_failed", "error": str(e)})
                self.security_events.alert("Step execution failed", {"error": str(e)})
                break
