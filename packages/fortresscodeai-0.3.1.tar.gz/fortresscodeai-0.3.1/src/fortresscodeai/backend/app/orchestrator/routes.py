from __future__ import annotations

import time
from typing import List, Dict

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import APIKeyHeader
from pydantic import BaseModel

from .workflow_models import (
    WorkflowDefinitionModel,
    WorkflowExecutionResponse,
    WorkflowExecutionContext,
)
from .workflow_models import WorkflowStatus  # for response typing


router = APIRouter(tags=["orchestrator"])

# -------------------------------------------------
# Security: API Key + Simple Rate Limiting
# -------------------------------------------------

API_KEY_NAME = "X-API-Key"
API_KEY = "CHANGE_ME_TO_SECURE_KEY"

api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

rate_limit_window_seconds = 10
rate_limit_max_requests = 30
_rate_limit_store: Dict[str, List[float]] = {}


async def rate_limiter(request: Request):
    ip = request.client.host
    now = time.time()
    window_start = now - rate_limit_window_seconds

    timestamps = _rate_limit_store.get(ip, [])
    timestamps = [t for t in timestamps if t >= window_start]

    if len(timestamps) >= rate_limit_max_requests:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded",
        )

    timestamps.append(now)
    _rate_limit_store[ip] = timestamps


async def get_api_key(api_key: str = Depends(api_key_header)):
    if api_key != API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
        )
    return api_key


# -------------------------------------------------
# Helpers
# -------------------------------------------------


def ctx_to_response(ctx: WorkflowExecutionContext) -> WorkflowExecutionResponse:
    return WorkflowExecutionResponse(
        execution_id=ctx.execution_id,
        workflow_id=ctx.workflow.id,
        status=ctx.status,
        current_step_index=ctx.current_step_index,
        results=ctx.results,
        logs=ctx.logs,
    )


def get_orchestrator(request: Request):
    orchestrator = getattr(request.app.state, "orchestrator", None)
    if orchestrator is None:
        raise HTTPException(status_code=500, detail="Orchestrator not initialized")
    return orchestrator


# -------------------------------------------------
# Routes
# -------------------------------------------------


@router.post("/submit", response_model=WorkflowExecutionResponse)
async def submit_workflow(
    wf: WorkflowDefinitionModel,
    api_key: str = Depends(get_api_key),
    _: None = Depends(rate_limiter),
    orchestrator=Depends(get_orchestrator),
):
    ctx = orchestrator.submit_workflow(wf)
    return ctx_to_response(ctx)


@router.get("/{execution_id}", response_model=WorkflowExecutionResponse)
async def get_workflow(
    execution_id: str,
    api_key: str = Depends(get_api_key),
    _: None = Depends(rate_limiter),
    orchestrator=Depends(get_orchestrator),
):
    ctx = orchestrator.get_execution(execution_id)
    if not ctx:
        raise HTTPException(status_code=404, detail="Execution not found")
    return ctx_to_response(ctx)


class ApproveStepRequest(BaseModel):
    step_id: str
    approved_by: str


@router.post("/{execution_id}/approve", response_model=WorkflowExecutionResponse)
async def approve_step(
    execution_id: str,
    body: ApproveStepRequest,
    api_key: str = Depends(get_api_key),
    _: None = Depends(rate_limiter),
    orchestrator=Depends(get_orchestrator),
):
    ctx = await orchestrator.approve_step(execution_id, body.step_id, body.approved_by)
    return ctx_to_response(ctx)
