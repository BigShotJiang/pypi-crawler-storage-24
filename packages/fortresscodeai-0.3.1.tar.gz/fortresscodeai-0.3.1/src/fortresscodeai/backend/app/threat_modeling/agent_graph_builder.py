# src/threat_modeling/agent_graph_builder.py

import networkx as nx
import json

class AgentGraphBuilder:
    def __init__(self):
        self.graph = nx.DiGraph()

    def add_agent(self, agent_id, label, role):
        self.graph.add_node(agent_id, label=label, role=role)

    def add_interaction(self, source, target, channel):
        self.graph.add_edge(source, target, channel=channel)

    def to_dict(self):
        return nx.readwrite.json_graph.node_link_data(self.graph)

    def export_json(self, path):
        with open(path, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
