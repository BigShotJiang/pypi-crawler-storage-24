# src/threat_modeling/threat_model_generator.py

from pytm import TM, Server, Dataflow, Boundary, Actor

def generate_model():
    tm = TM("Fortress Threat Model")
    tm.description = "Auto-generated threat model for backend services"
    tm.boundary = Boundary("Cloud")

    user = Actor("User")
    api = Server("API Gateway")
    db = Server("Database")

    api.inBoundary = tm.boundary
    db.inBoundary = tm.boundary

    Dataflow(user, api, "HTTPS Request")
    Dataflow(api, db, "SQL Query")
    Dataflow(db, api, "Query Result")
    Dataflow(api, user, "HTTPS Response")

    tm.process()
    tm.report("threat_model_report.pdf", "pdf")

if __name__ == "__main__":
    generate_model()
