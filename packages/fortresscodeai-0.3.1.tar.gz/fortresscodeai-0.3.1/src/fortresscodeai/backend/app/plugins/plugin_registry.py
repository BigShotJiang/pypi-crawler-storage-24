class PluginRegistry:
    def __init__(self):
        self.plugins = []

    def register(self, plugin):
        """
        Registers a plugin instance.
        Plugins may optionally define:
        - router (FastAPI router)
        - name
        - version
        - init(app)
        """
        self.plugins.append(plugin)

    def get(self, name: str):
        for plugin in self.plugins:
            if getattr(plugin, "name", None) == name:
                return plugin
        return None

    def list(self):
        return self.plugins


plugin_registry = PluginRegistry()
