import importlib.util
import sys
from pathlib import Path
from typing import List, Any


def load_plugins(plugins_path: Path) -> List[Any]:
    """
    Dynamically loads Python modules from the plugins directory.
    Each plugin must define a `Plugin` class.
    """
    loaded_plugins = []

    if not plugins_path.exists():
        return loaded_plugins

    for file in plugins_path.glob("*.py"):
        if file.name.startswith("_"):
            continue

        module_name = f"plugin_{file.stem}"
        spec = importlib.util.spec_from_file_location(module_name, file)
        if spec is None:
            continue

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module

        try:
            spec.loader.exec_module(module)  # type: ignore
        except Exception as e:
            print(f"[PluginLoader] Failed to load {file.name}: {e}")
            continue

        if hasattr(module, "Plugin"):
            try:
                plugin_instance = module.Plugin()
                loaded_plugins.append(plugin_instance)
            except Exception as e:
                print(f"[PluginLoader] Failed to instantiate Plugin in {file.name}: {e}")

    return loaded_plugins
