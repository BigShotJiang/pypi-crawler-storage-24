"""
workflow_engine.py

Governance-first workflow orchestration for FortressCodeAI.

This module defines:
- WorkflowStepDef: static definition of a workflow step
- WorkflowDef: static definition of a workflow
- WorkflowRun: runtime instance of a workflow execution
- InMemoryDB: simple in-memory store for workflows, agents, and runs
- WorkflowEngine: orchestrates step-by-step workflow execution

This file is intentionally DB-agnostic and safe to import at startup.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Callable

from backend.app.agent_runtime import AgentRuntime
from backend.app.storage import Storage


# ------------------------------------------------------------
# Workflow Step Definition
# ------------------------------------------------------------

@dataclass
class WorkflowStepDef:
    """
    Static definition of a workflow step.

    step_index: execution order
    agent_id: which agent to invoke
    input_key: key in workflow context to read as input
    output_key: key in workflow context to write the result
    """
    step_index: int
    agent_id: str
    input_key: str
    output_key: str


# ------------------------------------------------------------
# Workflow Definition
# ------------------------------------------------------------

@dataclass
class WorkflowDef:
    """
    Static definition of a workflow.

    id: unique workflow identifier
    tenant_id: owner tenant
    name: human-readable name
    steps: ordered list of WorkflowStepDef
    """
    id: str
    tenant_id: str
    name: str
    steps: List[WorkflowStepDef] = field(default_factory=list)


# ------------------------------------------------------------
# Workflow Run Instance
# ------------------------------------------------------------

@dataclass
class WorkflowRun:
    """
    Runtime instance of a workflow execution.

    id: unique run identifier
    tenant_id: owner tenant
    workflow_id: which workflow definition
    status: pending/running/succeeded/failed
    context: mutable dict shared across steps
    """
    id: str
    tenant_id: str
    workflow_id: str
    status: str = "pending"
    context: Dict[str, Any] = field(default_factory=dict)


# ------------------------------------------------------------
# In-Memory Database (safe for import)
# ------------------------------------------------------------

class InMemoryDB:
    """
    Minimal in-memory store for workflows, agents, and runs.

    This is a stand-in for a real database layer.
    """

    def __init__(self):
        self.workflows: Dict[str, WorkflowDef] = {}
        self.agents: Dict[str, Dict[str, Any]] = {}
        self.runs: Dict[str, WorkflowRun] = {}

    # Workflows
    def add_workflow(self, wf: WorkflowDef) -> None:
        self.workflows[wf.id] = wf

    def get_workflow(self, workflow_id: str) -> WorkflowDef:
        return self.workflows[workflow_id]

    # Agents
    def add_agent(self, agent_id: str, agent_def: Dict[str, Any]) -> None:
        self.agents[agent_id] = agent_def

    def get_agent(self, agent_id: str) -> Dict[str, Any]:
        return self.agents[agent_id]

    # Runs
    def create_run(self, run: WorkflowRun) -> None:
        self.runs[run.id] = run

    def get_run(self, run_id: str) -> WorkflowRun:
        return self.runs[run_id]

    def update_run(self, run: WorkflowRun) -> None:
        self.runs[run.id] = run


# ------------------------------------------------------------
# Workflow Engine
# ------------------------------------------------------------

class WorkflowEngine:
    """
    Step-based workflow engine.

    Responsibilities:
    - Load workflow + agent definitions
    - Execute steps in order
    - Pass context between steps
    - Invoke AgentRuntime with tenant + policy
    - Update run status and context
    """

    def __init__(
        self,
        db: InMemoryDB,
        storage: Storage,
        logger: Callable[[str], None],
    ):
        self.db = db
        self.storage = storage
        self.logger = logger

    # Logging helper
    def _log(self, msg: str) -> None:
        self.logger(f"[workflow] {msg}")

    # --------------------------------------------------------
    # Create a workflow run
    # --------------------------------------------------------

    def create_run(
        self,
        tenant_id: str,
        workflow_id: str,
        initial_context: Optional[Dict[str, Any]] = None,
    ) -> WorkflowRun:

        wf = self.db.get_workflow(workflow_id)

        if wf.tenant_id != tenant_id:
            raise ValueError("Workflow does not belong to this tenant")

        run_id = str(uuid.uuid4())
        run = WorkflowRun(
            id=run_id,
            tenant_id=tenant_id,
            workflow_id=workflow_id,
            status="pending",
            context=initial_context or {},
        )

        self.db.create_run(run)
        self._log(f"created run {run.id} for workflow {wf.name} (tenant={tenant_id})")
        return run

    # --------------------------------------------------------
    # Execute a workflow run
    # --------------------------------------------------------

    def execute_run(self, run_id: str) -> WorkflowRun:
        run = self.db.get_run(run_id)
        wf = self.db.get_workflow(run.workflow_id)

        if run.tenant_id != wf.tenant_id:
            raise ValueError("Run and workflow tenant mismatch")

        self._log(f"starting run {run.id} for workflow {wf.name}")
        run.status = "running"
        self.db.update_run(run)

        steps = sorted(wf.steps, key=lambda s: s.step_index)

        for step_def in steps:
            self._log(
                f"step {step_def.step_index} "
                f"agent={step_def.agent_id} "
                f"input_key={step_def.input_key} "
                f"output_key={step_def.output_key}"
            )

            agent_def = self.db.get_agent(step_def.agent_id)

            runtime = AgentRuntime(
                tenant_id=run.tenant_id,
                agent_def=agent_def,
                workflow_ctx=run.context,
                storage=self.storage,
                logger=self.logger,
            )

            step_input = run.context.get(step_def.input_key, {})
            if not isinstance(step_input, dict):
                step_input = {"value": step_input}

            result = runtime.run(step_input)

            run.context[step_def.output_key] = result
            self.db.update_run(run)

            if result.get("status") != "ok":
                self._log(
                    f"step {step_def.step_index} failed with error_type="
                    f"{result.get('error_type')}"
                )
                run.status = "failed"
                self.db.update_run(run)
                return run

        run.status = "succeeded"
        self.db.update_run(run)
        self._log(f"run {run.id} completed successfully")
        return run
