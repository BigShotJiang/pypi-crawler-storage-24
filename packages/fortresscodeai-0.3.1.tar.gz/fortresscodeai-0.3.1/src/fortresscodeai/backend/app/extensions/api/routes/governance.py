from fastapi import APIRouter
from services.governance_service import (
    get_policies,
    get_policy_coverage,
    get_policy_impact,
    get_policy_diff,
    get_governance_drift,
    get_governance_as_code
)

router = APIRouter()

@router.get("/policies")
async def policies():
    return await get_policies()

@router.get("/coverage")
async def coverage():
    return await get_policy_coverage()

@router.get("/impact")
async def impact():
    return await get_policy_impact()

@router.get("/diff")
async def diff():
    return await get_policy_diff()

@router.get("/drift")
async def drift():
    return await get_governance_drift()

@router.get("/as-code")
async def as_code():
    return await get_governance_as_code()
