from fastapi import APIRouter
from services.sbom_service import (
    analyze_sbom,
    get_sbom_integrity,
    get_unapproved_dependencies
)

router = APIRouter()

@router.get("/")
async def sbom_root():
    return await analyze_sbom()

@router.get("/integrity")
async def sbom_integrity():
    return await get_sbom_integrity()

@router.get("/unapproved")
async def sbom_unapproved():
    return await get_unapproved_dependencies()
