from fastapi import APIRouter
from services.agent_service import (
    analyze_agents,
    get_agent_behavior,
    get_agent_performance,
    get_model_routing,
    get_agent_chain
)

router = APIRouter()

@router.get("/")
async def agents_root():
    return await analyze_agents()

@router.get("/behavior")
async def agent_behavior():
    return await get_agent_behavior()

@router.get("/performance")
async def agent_performance():
    return await get_agent_performance()

@router.get("/routing")
async def model_routing():
    return await get_model_routing()

@router.get("/chain/{chain_id}")
async def agent_chain(chain_id: str):
    return await get_agent_chain(chain_id)
