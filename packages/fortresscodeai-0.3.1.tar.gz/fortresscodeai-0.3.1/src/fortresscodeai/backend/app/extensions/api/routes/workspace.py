from fastapi import APIRouter
from services.workspace_service import build_workspace_summary

router = APIRouter()

@router.get("/summary")
async def workspace_summary():
    """
    Aggregates governance, risk, trust, SBOM, agent, and audit signals
    into a unified workspace summary.
    """
    summary = await build_workspace_summary()
    return summary
