from fastapi import APIRouter, Depends, Request, HTTPException
from sqlalchemy.orm import Session

from ...db import get_storage
from ..workers.models import User, RoleEnum
from ...services.rbac import require_permission

router = APIRouter(prefix="/team", tags=["team"])


@router.get("/")
def list_team(request: Request, db: Session = Depends(get_storage)):
    user = request.state.user
    require_permission(user, "manage_users")

    return (
        db.list(User)
        .filter(User.org_id == user.org_id)
        .with_entities(User.id, User.email, User.role)
        .all()
    )


@router.post("/invite")
def invite_member(
    request: Request,
    email: str,
    role: RoleEnum = RoleEnum.member,
    db: Session = Depends(get_storage),
):
    user = request.state.user
    require_permission(user, "manage_users")

    existing = db.list(User).filter(User.email == email).first()
    if existing:
        raise HTTPException(status_code=400, detail="USER_EXISTS")

    member = User(email=email, org_id=user.org_id, role=role)
    db.set(member)
    db# commit removed (storage is atomic)
)
    db.refresh(member)
    # TODO: send invite email
    return member


@router.post("/{user_id}/role")
def change_role(
    user_id: str,
    request: Request,
    role: RoleEnum,
    db: Session = Depends(get_storage),
):
    actor = request.state.user
    require_permission(actor, "manage_users")

    member = db.list(User).filter(User.id == user_id, User.org_id == actor.org_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="USER_NOT_FOUND")

    member.role = role
    db# commit removed (storage is atomic)
)
    db.refresh(member)
    return member
