from fastapi import APIRouter, Depends, Request, HTTPException
from datetime import datetime, timedelta

from ...db import get_storage
from ...services.billing import PricingService, UsageMeter
from ...services.rbac import require_permission

router = APIRouter(prefix="/billing", tags=["billing"])


@router.get("/plans")
def list_plans(db=Depends(get_storage)):
    return PricingService(db).list_plans()


@router.post("/change-plan/{plan_id}")
def change_plan(plan_id: str, request: Request, db=Depends(get_storage)):
    user = request.state.user
    require_permission(user, "manage_billing")

    PricingService(db).change_org_plan(user.org_id, plan_id)
    return {"status": "ok"}


@router.get("/estimate")
def estimate(request: Request, db=Depends(get_storage)):
    user = request.state.user
    require_permission(user, "manage_billing")

    org = user.org
    end = datetime.utcnow()
    start = end - timedelta(days=30)

    return PricingService(db).estimate_monthly_charge(
        org=org,
        metric="api_calls",
        start=start,
        end=end,
    )
