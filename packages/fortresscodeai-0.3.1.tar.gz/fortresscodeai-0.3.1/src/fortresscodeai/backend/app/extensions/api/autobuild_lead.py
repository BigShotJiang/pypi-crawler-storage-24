from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any

from fortress.autobuilder.lead.service import build_lead_packet

router = APIRouter(prefix="/internal/autobuild", tags=["autobuilder"])


class LeadInput(BaseModel):
    name: Optional[str] = None
    company: Optional[str] = None
    linkedin_url: Optional[str] = None
    email_domain: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None


@router.post("/lead")
def autobuild_lead(input_data: LeadInput):
    try:
        raw = {
            "name": input_data.name,
            "company": input_data.company,
            "linkedin_url": input_data.linkedin_url,
            "email_domain": input_data.email_domain,
        }

        if input_data.extra:
            raw.update(input_data.extra)

        packet = build_lead_packet(raw)

        return {
            "markdown": packet.markdown,
            "audit_log": packet.audit_log,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
