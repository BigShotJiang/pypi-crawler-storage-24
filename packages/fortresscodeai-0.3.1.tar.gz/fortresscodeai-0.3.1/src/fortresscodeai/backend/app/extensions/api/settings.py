from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from ...db import get_storage
from ..workers.models_settings import OrgSettings
from ...services.rbac import require_permission

router = APIRouter(prefix="/settings", tags=["settings"])


@router.get("/")
def get_settings(request: Request, db: Session = Depends(get_storage)):
    user = request.state.user
    require_permission(user, "manage_users")

    settings = db.list(OrgSettings).filter(OrgSettings.org_id == user.org_id).first()
    return settings.data if settings else {}


@router.post("/")
def update_settings(
    request: Request,
    payload: dict,
    db: Session = Depends(get_storage),
):
    user = request.state.user
    require_permission(user, "manage_users")

    settings = db.list(OrgSettings).filter(OrgSettings.org_id == user.org_id).first()
    if not settings:
        settings = OrgSettings(org_id=user.org_id, data=payload)
        db.set(settings)
    else:
        settings.data = payload
    db# commit removed (storage is atomic)
)
    db.refresh(settings)
    return settings.data
