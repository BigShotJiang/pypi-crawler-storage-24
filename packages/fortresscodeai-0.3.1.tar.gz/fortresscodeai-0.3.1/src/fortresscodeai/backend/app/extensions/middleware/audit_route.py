from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
import json
import traceback
from typing import Optional

from ..audit import AuditLogger
from ..db import SessionLocal
from ..policies import evaluate_policies
from ..validation import validate_preconditions, validate_postconditions


MAX_BODY_SIZE = 50_000  # 50 KB safety cap


class AuditRouteMiddleware(BaseHTTPMiddleware):
    """
    Governance‑grade audit middleware.
    Captures:
      - pre‑transition attempt
      - post‑transition result
      - exception path
      - policy evaluation
      - pre/post condition validation
      - request metadata
      - agent/workflow context
    """

    def __init__(self, app, *, type: str, entity_type: str):
        super().__init__(app)
        self.type = type
        self.entity_type = entity_type

    async def dispatch(self, request: Request, call_next):
        # -----------------------------
        # Capture request body safely
        # -----------------------------
        body_bytes = await request.body()
        if len(body_bytes) > MAX_BODY_SIZE:
            body_bytes = body_bytes[:MAX_BODY_SIZE]

        try:
            body = body_bytes.decode("utf-8")
        except Exception:
            body = "<unreadable>"

        # -----------------------------
        # Extract state (validated)
        # -----------------------------
        org_id = getattr(request.state, "org_id", None)
        user = getattr(request.state, "user", None)
        entity_id = getattr(request.state, "entity_id", None)
        agent = getattr(request.state, "agent", None)
        workflow = getattr(request.state, "workflow", None)

        # Enforce required fields
        missing_fields = []
        if org_id is None:
            missing_fields.append("org_id")
        if user is None:
            missing_fields.append("user")

        # -----------------------------
        # Pre‑condition validation
        # -----------------------------
        precondition_result = validate_preconditions(
            type=self.type,
            entity_type=self.entity_type,
            org_id=org_id,
            user=user,
            entity_id=entity_id,
            request_body=body,
        )

        # -----------------------------
        # Policy evaluation
        # -----------------------------
        policy_result = evaluate_policies(
            type=self.type,
            entity_type=self.entity_type,
            org_id=org_id,
            user=user,
            entity_id=entity_id,
            request_body=body,
        )

        # -----------------------------
        # PRE‑TRANSITION AUDIT ENTRY
        # -----------------------------
        self._log(
            org_id=org_id,
            user=user,
            entity_id=entity_id,
            agent=agent,
            workflow=workflow,
            stage="pre",
            status="attempt",
            request=request,
            body=body,
            preconditions=precondition_result,
            policies=policy_result,
            missing_fields=missing_fields,
        )

        # If preconditions or policies block execution, stop here
        if precondition_result.get("blocked") or policy_result.get("blocked"):
            return Response(
                content=json.dumps({
                    "error": "Action blocked by governance layer",
                    "preconditions": precondition_result,
                    "policies": policy_result,
                }),
                status_code=403,
                media_type="application/json",
            )

        # -----------------------------
        # MAIN EXECUTION (with exception capture)
        # -----------------------------
        try:
            response = await call_next(request)
            status_code = response.status_code

            # -----------------------------
            # Post‑condition validation
            # -----------------------------
            postcondition_result = validate_postconditions(
                type=self.type,
                entity_type=self.entity_type,
                org_id=org_id,
                user=user,
                entity_id=entity_id,
                response=response,
            )

            # -----------------------------
            # POST‑TRANSITION AUDIT ENTRY
            # -----------------------------
            self._log(
                org_id=org_id,
                user=user,
                entity_id=entity_id,
                agent=agent,
                workflow=workflow,
                stage="post",
                status="success" if 200 <= status_code < 400 else "error",
                request=request,
                body=body,
                response_status=status_code,
                preconditions=precondition_result,
                postconditions=postcondition_result,
                policies=policy_result,
            )

            return response

        except Exception as exc:
            # -----------------------------
            # EXCEPTION‑PATH AUDIT ENTRY
            # -----------------------------
            self._log(
                org_id=org_id,
                user=user,
                entity_id=entity_id,
                agent=agent,
                workflow=workflow,
                stage="exception",
                status="failure",
                request=request,
                body=body,
                error=str(exc),
                traceback=traceback.format_exc(),
                preconditions=precondition_result,
                policies=policy_result,
            )

            raise exc  # rethrow for FastAPI to handle

    # ---------------------------------------------------------
    # INTERNAL LOGGING FUNCTION
    # ---------------------------------------------------------
    def _log(
        self,
        *,
        org_id: Optional[str],
        user: Optional[str],
        entity_id: Optional[str],
        agent: Optional[str],
        workflow: Optional[str],
        stage: str,
        status: str,
        request: Request,
        body: str,
        response_status: Optional[int] = None,
        preconditions=None,
        postconditions=None,
        policies=None,
        missing_fields=None,
        error=None,
        traceback=None,
    ):
        db = SessionLocal()
        try:
            logger = AuditLogger(db)
            logger.log(
                org_id=org_id,
                user=user,
                type=self.type,
                entity_type=self.entity_type,
                entity_id=entity_id,
                metadata={
                    "stage": stage,
                    "status": status,
                    "path": request.url.path,
                    "method": request.method,
                    "request_body": body,
                    "response_status": response_status,
                    "agent": agent,
                    "workflow": workflow,
                    "preconditions": preconditions,
                    "postconditions": postconditions,
                    "policies": policies,
                    "missing_fields": missing_fields,
                    "error": error,
                    "traceback": traceback,
                },
            )
        finally:
            db.close()
