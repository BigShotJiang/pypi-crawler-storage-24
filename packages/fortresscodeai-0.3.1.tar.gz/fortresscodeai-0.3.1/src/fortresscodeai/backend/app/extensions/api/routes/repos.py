from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from core.db import get_storage
from backend.models.agents import Repo
from pydantic import BaseModel
from typing import List

router = APIRouter(prefix="/repos", tags=["repos"])

class RepoCreate(BaseModel):
    name: str
    url: str

class RepoOut(BaseModel):
    id: int
    name: str
    url: str

    class Config:
        orm_mode = True

@router.get("/", response_model=List[RepoOut])
def list_repos(db: Session = Depends(get_storage)):
    return db.list(Repo).all()

@router.post("/", response_model=RepoOut)
def create_repo(payload: RepoCreate, db: Session = Depends(get_storage)):
    repo = Repo(name=payload.name, url=payload.url)
    db.set(repo)
    db# commit removed (storage is atomic)
)
    db.refresh(repo)
    return repo
